from __future__ import annotations

import hashlib
import logging
import os
import sys
import tempfile
import uuid
from threading import RLock
from typing import Callable, Dict, Iterable, List, Mapping, Optional, Tuple, Union

from .base import Runner
from .._bootstrap import build_bootstrap
from .._shipping import (
    DEFAULT_SOURCE_INCLUDE,
    REMOTE_ROOT,
    auto_resolve_or_none,
    normalize_source_paths,
    remote_path_for,
    tar_directory,
)
from .._workspace import (
    Manifest,
    RUNNER_SCAN_SCRIPT,
    delete_paths as _ws_delete_paths,
    extract_tar_atomic as _ws_extract_tar_atomic,
    normalize_workspace,
    pack_files as _ws_pack_files,
    parse_runner_manifest,
    runner_scan_args,
)

_log = logging.getLogger("yonder.runners.docker")


class DockerRunner(Runner):
    """A Runner backed by the Docker SDK for Python (``docker-py``).

    Specify the runtime one of three ways (exactly one is required):

    - ``image="repo/name:tag"`` — pull/use an existing image. yonder creates
      and manages the container.
    - ``dockerfile="path/to/Dockerfile"`` — build an image locally first.
      Context defaults to the Dockerfile's parent; override with
      ``build_context=``. Pass ``build_args={}`` for ARGs.
    - ``container="name-or-id"`` — attach to a container you manage outside
      yonder. yonder will ``start()`` it if it's stopped but will never
      remove it on ``close()``. ``env``/``build_args``/``on_demand`` are
      properties of the existing container and may not be set in this
      mode. ``workspace=`` is allowed but always uses the sync path
      (yonder can't add bind mounts to a container it didn't create).

    Two execution modes (image/dockerfile only):

    - ``on_demand=False`` (default): a long-lived container is created lazily
      on the first call (or eagerly via :meth:`start`) and reused. Call
      :meth:`close` (or use the runner as a context manager) to remove it.
    - ``on_demand=True``: a fresh container is started for every call and
      removed after — no shared state between calls.

    ``user=`` controls the UID:GID the container's processes run as. By
    default (``None``) the image's default user is used (typically
    root), which means files the container writes to bind-mounted host
    paths land as ``root:root`` on the host. Set ``user="host"`` to run
    as the calling process's UID:GID — host-readable/deletable files
    without sudo. You can also pass an explicit ``"uid:gid"`` string, a
    bare UID, or a username known to the image. Some images expect to
    run as root (license setup, package installs at runtime); for those,
    leave ``user=None``.

    ``silent=False`` (default) forwards the container's stderr to the
    host's ``sys.stderr`` on every successful call, so ``print``/``logging``
    output from inside the runner shows up in the calling terminal. Note
    that the in-container bootstrap redirects user-code stdout to fd 2
    (fd 1 is reserved for the result envelope), so *all* runner-side
    output arrives via stderr. Set ``silent=True`` to suppress this
    forwarding — the bytes are still captured and surfaced verbatim when
    a call fails, regardless of this setting.

    Requires the ``docker`` package: ``pip install 'yonder[docker]'``.
    """

    def __init__(
        self,
        image: Optional[str] = None,
        dockerfile: Optional[str] = None,
        container: Optional[str] = None,
        build_context: Optional[str] = None,
        build_args: Optional[Mapping[str, str]] = None,
        env: Optional[Mapping[str, str]] = None,
        workspace: Optional[Mapping[str, object]] = None,
        sync_deletes: bool = False,
        on_demand: bool = False,
        name: Optional[str] = None,
        inject_cloudpickle: bool = False,
        when: Optional[Callable[[], bool]] = None,
        mode: str = "cloudpickle",
        source_path: Optional[Union[str, Iterable[str]]] = None,
        source_include: Optional[Iterable[str]] = DEFAULT_SOURCE_INCLUDE,
        user: Optional[Union[str, int]] = "host",
        silent: bool = False,
        client=None,
    ):
        try:
            import docker  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "DockerRunner requires the docker SDK. "
                "Install with: pip install 'yonder[docker]'"
            ) from exc

        sources = (image, dockerfile, container)
        if sum(s is not None for s in sources) != 1:
            raise TypeError(
                "DockerRunner requires exactly one of "
                "`image=`, `dockerfile=`, or `container=`"
            )

        if mode not in ("cloudpickle", "reference"):
            raise ValueError(
                f"mode must be 'cloudpickle' or 'reference', got {mode!r}"
            )

        # Reference mode almost always needs the caller's source tree
        # reachable inside the container — default to the caller's
        # __file__ directory when the user didn't specify. Pass
        # `source_path=[]` to opt out (e.g. when the image already
        # bakes the function's module in). REPL/Jupyter contexts where
        # __file__ isn't available silently fall through to no default.
        if mode == "reference" and source_path is None:
            source_path = auto_resolve_or_none()

        self._client = client
        self._container = None
        self._lock = RLock()
        self._python_version_checked = False
        self.when = when
        self.mode = mode
        self.silent = silent
        self.workspace = normalize_workspace(
            workspace, sync_deletes=sync_deletes,
        )
        # Workspace sync runs `docker exec` against a persistent container.
        # on_demand=True spins up a fresh container per call with no
        # state to carry between syncs, so the feature combination is
        # silently useless — refuse it up front.
        if self.workspace is not None and on_demand:
            raise TypeError(
                "workspace= is not supported with on_demand=True. The "
                "container is destroyed after each call, so there's "
                "nothing to sync to. Use the default (persistent) mode "
                "or container=."
            )

        # Per-runner cache of {digest: extract_dir} for shipped source
        # trees. Populated lazily on first run() call for runners that
        # ship sources (attached containers); always empty for runners
        # that mount instead.
        self._shipped_sources: dict = {}
        self._ship_paths: List[str] = []
        # In-container paths derived from mount-mode source_path entries.
        # Inserted into sys.path by the bootstrap (rather than via the
        # PYTHONPATH env var) so the image's PYTHONPATH stays intact.
        self._mount_path_entries: List[str] = []
        # UID/GID to run container/exec processes as. Files created on
        # bind-mounted host paths are owned by this user, so passing the
        # host user's UID:GID (``user="host"``) avoids the classic
        # "container wrote root-owned files into my repo" papercut.
        # ``None`` keeps the image's default (typically root).
        if user == "host":
            self.user: Optional[str] = f"{os.getuid()}:{os.getgid()}"
        elif user is None:
            self.user = None
        else:
            self.user = str(user)
        # Extension allowlist applied when shipping (ignored for mount
        # mode — the whole directory is bind-mounted there). None means
        # ship every file.
        self.source_include: Optional[Tuple[str, ...]] = (
            None if source_include is None else tuple(source_include)
        )

        if container is not None:
            if env or build_args or build_context:
                raise TypeError(
                    "`container=` attaches to an existing container; "
                    "env/build_args/build_context are properties "
                    "of that container and must not be set here"
                )
            if on_demand:
                raise TypeError(
                    "`container=` cannot be combined with on_demand=True"
                )
            if inject_cloudpickle:
                raise TypeError(
                    "`inject_cloudpickle=True` is not supported with "
                    "`container=`. Injection works by building a derived "
                    "image (FROM <base> + RUN pip install cloudpickle), so "
                    "it only applies when yonder owns the image — yonder "
                    "won't mutate a container you manage. Either install "
                    "cloudpickle in the container yourself "
                    "(`docker exec <name> pip install cloudpickle`), bake "
                    "it into the image and use `image=` instead, or switch "
                    "to `mode='reference'` to avoid the dependency."
                )
            self._mode = "attach"
            self.container_ref: Optional[str] = container
            # Use the existing container's name as the runner name.
            self.name = name or container
            self.dockerfile = None
            self.build_context = None
            self.build_args = {}
            self.env = {}
            # Internal bind-mount table — always empty in attach mode
            # since yonder can't add mounts to a container it didn't
            # author.
            self.mounts: Dict[str, str] = {}
            self.on_demand = False
            self.inject_cloudpickle = False
            self._inject_base: Optional[str] = None
            self.image = ""  # not applicable; populated on attach
            self._image_ready = True
            self._owned = False  # we did not create this container
            # source_path is allowed with container= — yonder can't mount
            # into a container it didn't create, so the source tree is
            # tarred and shipped via put_archive on first call (cached
            # by content digest).
            self._ship_paths = normalize_source_paths(source_path)
        else:
            if inject_cloudpickle and dockerfile is not None:
                raise TypeError(
                    "`inject_cloudpickle=True` is not supported with "
                    "`dockerfile=`. Injection is only applied to images "
                    "yonder pulls (`image=`); when you supply a Dockerfile "
                    "you already own the build, so yonder won't rewrite it. "
                    "Add `RUN pip install cloudpickle` to your Dockerfile "
                    "instead, or switch to `mode='reference'` to avoid the "
                    "dependency."
                )
            self._mode = "build" if dockerfile is not None else "image"
            self.container_ref = None
            self.name = name or f"yonder-{uuid.uuid4().hex[:8]}"
            self.dockerfile = dockerfile
            self.build_context = build_context
            self.build_args = dict(build_args or {})
            self.env = dict(env or {})
            # Internal bind-mount table — populated by source_path
            # shipping and by the workspace auto-promotion below. Not
            # a user-facing knob: bind mounts get declared through
            # workspace= (with empty include/exclude), which keeps the
            # vocabulary to one concept.
            self.mounts: Dict[str, str] = {}
            self.on_demand = on_demand
            self.inject_cloudpickle = inject_cloudpickle
            self._apply_source_path(source_path)
            # For image mode with injection, derive a tag from a hash of the
            # base image so re-runs hit the docker layer cache without
            # accumulating orphan tags.
            if inject_cloudpickle:
                self._inject_base = image
                digest = hashlib.sha256(image.encode("utf-8")).hexdigest()[:12]
                self.image = f"yonder-cloudpickle:{digest}"
                self._image_ready = False
            else:
                self._inject_base = None
                # For dockerfile builds, image is a generated tag populated
                # by `_ensure_image_built`. For image mode, use the
                # user-supplied tag.
                self.image = image if image is not None else f"{self.name}:latest"
                self._image_ready = image is not None and dockerfile is None
            self._owned = True

        # In image= / dockerfile= modes the kernel can give the function
        # zero-copy access via a bind mount — strictly faster than the
        # sync path. Promote eligible workspace entries to bind mounts.
        self._absorb_workspace_into_mounts()

    def _absorb_workspace_into_mounts(self) -> None:
        """Convert simple workspace entries into bind mounts.

        Eligible when the runner owns the container (``image=`` /
        ``dockerfile=`` modes — yonder gets to add mounts at create time)
        *and* the entry has no ``include`` / ``exclude`` filter *and*
        the workspace is not configured for ``sync_deletes``. The kernel
        can't honor globs or track deletions through a plain bind mount;
        those entries keep the sync path.

        Promoted entries swap snapshot-around-each-call semantics for
        live shared semantics — what the function writes shows up on
        the host immediately, not after the call returns. The conversion
        is logged so a user comparing wall times can see what
        happened.
        """
        if self.workspace is None or self._mode == "attach":
            return
        if self.workspace.sync_deletes:
            # sync_deletes is most often used as a "clean as you go"
            # signal — keep the sync path so the explicit deletion list
            # actually runs.
            return
        keep: List = []
        for entry in self.workspace.entries:
            if entry.direction == "translate":
                # `translate` says: don't sync, don't mount — just
                # rewrite paths. The user is telling us the runner
                # side already has the files (image-baked path, NFS
                # share, etc.), so leave it on the workspace for
                # HostPath translation and move on.
                keep.append(entry)
                continue
            if entry.include or entry.exclude:
                keep.append(entry)
                continue
            host = entry.host_path
            # docker auto-creates a missing bind source as root-owned,
            # which then collides with user="host". Try to materialize
            # the directory ourselves so it ends up owned by the
            # caller. Best-effort: paths outside a writable parent
            # (e.g. /etc/something) just get docker's default behavior.
            try:
                os.makedirs(host, exist_ok=True)
            except OSError:
                pass
            existing = self.mounts.get(host)
            if existing is not None and existing != entry.runner_path:
                raise ValueError(
                    f"workspace entry {host!r} -> {entry.runner_path!r} "
                    f"conflicts with mounts={{{host!r}: {existing!r}}}. "
                    f"Pick one or rename the runner-side path."
                )
            self.mounts[host] = entry.runner_path
            _log.info(
                "DockerRunner %s: workspace entry %s -> %s converted to "
                "bind mount (zero-copy; live shared semantics, not "
                "per-call snapshot)",
                self.name, host, entry.runner_path,
            )
        self.workspace.entries = keep
        # Drop the workspace entirely when nothing's left so sync_in /
        # sync_out short-circuit without scanning empty entry lists.
        if not self.workspace.entries:
            self.workspace = None

    @property
    def client(self):
        if self._client is None:
            import docker

            self._client = docker.from_env()
        return self._client

    def start(self) -> None:
        """Bring the runner to "available": build/pull the image, and for
        persistent runners, create and start the container."""
        # Fail fast if the daemon isn't reachable, instead of hanging
        # inside a build/pull request.
        self.client.ping()
        self._ensure_image_built()
        if not self.on_demand:
            self._ensure_container_started()
        self._check_python_version()

    def run(self, payload: bytes) -> bytes:
        self._ensure_image_built()
        if self.on_demand:
            self._check_python_version()
            return self._run_oneshot(payload)
        self._ensure_container_started()
        self._check_python_version()
        return self._exec_in_persistent(payload)

    def close(self) -> None:
        with self._lock:
            container = self._container
            self._container = None
        if container is None:
            return
        if not self._owned:
            # We attached to a container we didn't create; never remove it.
            _log.info("detaching from container %s", self.name)
            return
        _log.info("removing container %s", self.name)
        try:
            container.remove(force=True)
        except Exception:
            # Cleanup is best-effort; the container may already be gone.
            pass

    def _ensure_image_built(self) -> None:
        with self._lock:
            if self._image_ready:
                return
            if self.inject_cloudpickle:
                self._build_injected_image()
            elif self.dockerfile is not None:
                self._build_from_dockerfile()
            else:
                self._ensure_image_present()
            self._image_ready = True

    def _build_from_dockerfile(self) -> None:
        dockerfile_path = os.path.abspath(self.dockerfile)
        context = os.path.abspath(
            self.build_context or os.path.dirname(dockerfile_path) or "."
        )
        try:
            rel_dockerfile = os.path.relpath(dockerfile_path, context)
        except ValueError:
            rel_dockerfile = dockerfile_path
        _log.info(
            "building image %s from %s (context=%s)",
            self.image, dockerfile_path, context,
        )
        self._run_build(
            path=context,
            dockerfile=rel_dockerfile,
            tag=self.image,
            buildargs=self.build_args,
        )

    def _build_injected_image(self) -> None:
        """Build a derived image: FROM <base> + RUN pip install cloudpickle.

        Tag is derived from a hash of the base image so identical base ->
        identical tag, which lets the Docker layer cache make this cheap
        across re-runs.
        """
        with tempfile.TemporaryDirectory(prefix="yonder-inject-") as tmpdir:
            dockerfile_path = os.path.join(tmpdir, "Dockerfile")
            with open(dockerfile_path, "w") as f:
                f.write(f"FROM {self._inject_base}\n")
                f.write("RUN pip install --no-cache-dir cloudpickle\n")
            _log.info(
                "injecting cloudpickle: FROM %s -> %s",
                self._inject_base, self.image,
            )
            self._run_build(
                path=tmpdir,
                dockerfile="Dockerfile",
                tag=self.image,
                buildargs={},
            )

    def _run_build(self, *, path: str, dockerfile: str, tag: str, buildargs: Mapping[str, str]) -> None:
        """Drive ``client.api.build`` and stream output to the logger."""
        stream = self.client.api.build(
            path=path,
            dockerfile=dockerfile,
            tag=tag,
            buildargs=dict(buildargs),
            rm=True,
            decode=True,
        )
        image_id: Optional[str] = None
        for chunk in stream:
            if "error" in chunk:
                raise RuntimeError(f"docker build failed: {chunk['error'].rstrip()}")
            if "stream" in chunk:
                line = chunk["stream"].rstrip()
                if line:
                    _log.info("build: %s", line)
            if "aux" in chunk and isinstance(chunk["aux"], dict):
                image_id = chunk["aux"].get("ID") or image_id
        _log.info("built image %s (%s)", tag, image_id or "id-unknown")

    def _ensure_image_present(self) -> None:
        import docker.errors

        try:
            self.client.images.get(self.image)
            return
        except docker.errors.ImageNotFound:
            pass
        _log.info("pulling image %s", self.image)
        for chunk in self.client.api.pull(self.image, stream=True, decode=True):
            status = chunk.get("status")
            if not status:
                continue
            cid = chunk.get("id")
            prefix = f"[{cid}] " if cid else ""
            _log.debug("pull: %s%s", prefix, status)

    def _ensure_container_started(self) -> None:
        with self._lock:
            if self._container is not None:
                return
            if self._mode == "attach":
                self._container = self._attach_to_existing()
            else:
                _log.info(
                    "starting persistent container %s (image=%s)", self.name, self.image
                )
                # entrypoint= goes in the ENTRYPOINT slot (always overrides
                # the image's ENTRYPOINT); command= only fills the CMD slot
                # and would be appended to whatever entrypoint the image
                # declares. Images like `ENTRYPOINT ["python3"]` would turn
                # our intended `sleep infinity` into `python3 sleep infinity`
                # and exit immediately. Splitting across both slots keeps
                # the container alive regardless of the image's entrypoint.
                container = self.client.containers.run(
                    self.image,
                    entrypoint=["sleep"],
                    command=["infinity"],
                    name=self.name,
                    detach=True,
                    environment=self.env,
                    volumes=self._volumes_dict(),
                    **self._user_kwarg(),
                )
                container.reload()
                if container.status != "running":
                    logs = b""
                    try:
                        logs = container.logs(stdout=True, stderr=True, tail=200)
                    except Exception:
                        pass
                    try:
                        container.remove(force=True)
                    except Exception:
                        pass
                    raise RuntimeError(
                        f"persistent container {self.name} for image "
                        f"{self.image} did not stay running "
                        f"(status={container.status!r}). The image's "
                        f"ENTRYPOINT/CMD likely refused yonder's override "
                        f"`sleep infinity`. Last 200 log lines:\n"
                        f"{logs.decode('utf-8', 'replace') or '<empty>'}"
                    )
                self._container = container

    def _attach_to_existing(self):
        import docker.errors

        try:
            container = self.client.containers.get(self.container_ref)
        except docker.errors.NotFound as exc:
            raise RuntimeError(
                f"DockerRunner: container {self.container_ref!r} not found"
            ) from exc
        container.reload()
        if container.status != "running":
            _log.info(
                "starting existing container %s (was %s)",
                container.name, container.status,
            )
            container.start()
            container.reload()
        # Record the image so logs/error messages stay informative.
        image_tags = getattr(container.image, "tags", None) or [container.image.id]
        self.image = image_tags[0]
        _log.info("attached to container %s (image=%s)", container.name, self.image)
        return container

    def _forward_stderr(self, stderr: bytes) -> None:
        """Prefix each line of the container's stderr with ``[<name>]`` and
        write it to host stderr. No-op when ``silent=True`` or empty."""
        if self.silent or not stderr:
            return
        prefix = f"[{self.name}] "
        # keepends=True preserves whether the final line had a newline,
        # so a trailing partial line still renders without an extra \n.
        text = stderr.decode("utf-8", "replace")
        sys.stderr.write(
            "".join(prefix + line for line in text.splitlines(keepends=True))
        )
        sys.stderr.flush()

    def _exec_in_persistent(self, payload: bytes) -> bytes:
        sys_path_prepend = (
            list(self._mount_path_entries) + self._ensure_sources_shipped()
        )
        _log.debug("exec in container %s (%d bytes)", self.name, len(payload))
        result = self._container.exec_run(
            [
                "python", "-c",
                build_bootstrap(payload, self.mode, sys_path_prepend),
            ],
            stdout=True,
            stderr=True,
            demux=True,
            **self._user_kwarg(),
        )
        stdout, stderr = result.output
        _check_envelope(stdout or b"", stderr or b"", result.exit_code)
        self._forward_stderr(stderr or b"")
        return stdout

    def _run_oneshot(self, payload: bytes) -> bytes:
        # on_demand mode mounts source paths into the fresh container
        # (see _apply_source_path), so no shipping is needed here.
        _log.debug("running one-shot container from image %s", self.image)
        client = self.client
        # See _ensure_container_started for why python goes in entrypoint=
        # instead of command=.
        bootstrap = build_bootstrap(
            payload, self.mode, list(self._mount_path_entries)
        )
        container = client.containers.create(
            self.image,
            entrypoint=["python"],
            command=["-c", bootstrap],
            environment=self.env,
            volumes=self._volumes_dict(),
            **self._user_kwarg(),
        )
        try:
            container.start()
            exit_status = container.wait()
            stdout = container.logs(stdout=True, stderr=False)
            stderr = container.logs(stdout=False, stderr=True)
            _check_envelope(stdout, stderr, exit_status.get("StatusCode"))
            self._forward_stderr(stderr)
            return stdout
        finally:
            try:
                container.remove(force=True)
            except Exception:
                pass

    def _volumes_dict(self) -> dict:
        return {
            host: {"bind": ctr, "mode": "rw"}
            for host, ctr in self.mounts.items()
        }

    def _user_kwarg(self) -> dict:
        """``{"user": "<uid:gid>"}`` when ``self.user`` is set, else ``{}``.

        Returning the kwarg as a dict (rather than always passing
        ``user=self.user``) lets the docker SDK fall back to the image's
        default user when no override is configured.
        """
        return {"user": self.user} if self.user is not None else {}

    def _ensure_sources_shipped(self) -> List[str]:
        """Tar each entry in ``self._ship_paths``, upload via put_archive
        if not already in the per-runner cache, and return the list of
        in-container sys.path entries to prepend in the bootstrap.

        Used in ``container=`` mode where yonder cannot mount host paths
        into the container. No-op (returns ``[]``) for image/dockerfile
        modes — those wire source paths in via ``_mount_path_entries``
        (see :meth:`_apply_source_path`).
        """
        if not self._ship_paths:
            return []
        pythonpath_entries: List[str] = []
        for abs_host in self._ship_paths:
            tar_bytes, digest, basename = tar_directory(
                abs_host, include=self.source_include
            )
            extract_dir, pp_entry = remote_path_for(digest, basename)
            pythonpath_entries.append(pp_entry)
            if digest in self._shipped_sources:
                continue
            _log.info(
                "shipping source tree %s (%d bytes, digest=%s) to %s",
                abs_host, len(tar_bytes), digest, extract_dir,
            )
            # put_archive needs the destination dir to exist.
            mk = self._container.exec_run(["mkdir", "-p", extract_dir])
            if mk.exit_code != 0:
                raise RuntimeError(
                    f"failed to mkdir {extract_dir} in container "
                    f"{self.name}: {(mk.output or b'').decode(errors='replace')}"
                )
            if not self._container.put_archive(extract_dir, tar_bytes):
                raise RuntimeError(
                    f"put_archive failed shipping {abs_host} to container "
                    f"{self.name} (target {extract_dir})"
                )
            self._shipped_sources[digest] = extract_dir
        return pythonpath_entries

    def translate_host_path(self, path: str) -> str:
        """Translate a host path to its in-container equivalent.

        Walks workspace entries first (the user's declarative table),
        then the internal bind-mount table populated by workspace
        auto-promotion and ``source_path=`` shipping. Raises
        :class:`ValueError` if neither covers the path.
        """
        translated = self._workspace_translate(path)
        if translated is not None:
            _log.debug("translate %r -> %r (via workspace)", path, translated)
            return translated
        if not self.mounts:
            raise ValueError(
                f"HostPath({str(path)!r}) cannot be translated: this runner "
                f"has no workspace or source_path covering it. Pass "
                f"`workspace={{host_path: runner_path}}` (or `source_path=`) "
                f"to the DockerRunner so the path is reachable inside the "
                f"container."
            )
        abs_path = os.path.abspath(path)
        for host_root, container_root in self.mounts.items():
            host_abs = os.path.abspath(host_root)
            if abs_path == host_abs:
                _log.debug("translate %r -> %r (via mount %r)", path, container_root, host_root)
                return container_root
            if abs_path.startswith(host_abs + os.sep):
                rel = os.path.relpath(abs_path, host_abs)
                translated = os.path.join(container_root, rel)
                _log.debug("translate %r -> %r (via mount %r)", path, translated, host_root)
                return translated
        raise ValueError(
            f"HostPath({str(path)!r}) is not covered by any workspace or "
            f"source_path on this runner. Known bind mounts: "
            f"{dict(self.mounts)}"
        )

    def _apply_source_path(self, source_path) -> None:
        """Mount one or more host directories into the container and add
        their in-container paths to ``sys.path`` via the bootstrap.
        No-op when ``source_path`` is None.

        ``source_path="auto"`` (or ``"auto"`` as an entry in a list)
        resolves to the directory of the file that constructed the
        runner — useful to drop the ``HERE = os.path.dirname(__file__)``
        boilerplate.

        Each entry is mounted at ``/workspace/<basename>``; conflicts on
        the basename are disambiguated with an index. The resulting
        in-container paths are stored on ``self._mount_path_entries``
        and inserted at the front of ``sys.path`` by the bootstrap.
        The container's ``PYTHONPATH`` env var is intentionally left
        alone — overriding it would shadow whatever the image set (e.g.
        Binary Ninja's image puts ``/opt/binaryninja/python`` there).
        """
        paths = normalize_source_paths(source_path)
        if not paths:
            return

        seen: dict = {}
        for abs_host in paths:
            base = os.path.basename(abs_host.rstrip("/")) or "root"
            target = f"/workspace/{base}"
            if target in seen:
                target = f"/workspace/{base}-{len(seen)}"
            seen[target] = abs_host
            self.mounts[abs_host] = target
            self._mount_path_entries.append(target)

    def _check_python_version(self) -> None:
        # cloudpickle ships function bytecode, which the CPython unmarshaller
        # rejects across minor versions ("code() takes at most 16 arguments
        # (18 given)" and friends). Catch the mismatch up front so the user
        # sees an actionable error instead of a stack trace from the
        # bootstrap. Reference mode imports the user's module under the
        # container's Python, so version skew is harmless and the check
        # is skipped.
        if self._python_version_checked:
            return
        if self.mode == "reference":
            self._python_version_checked = True
            return
        container_version = self._probe_container_python_version()
        host_version = (sys.version_info.major, sys.version_info.minor)
        if container_version != host_version:
            host_str = f"{host_version[0]}.{host_version[1]}"
            ctr_str = f"{container_version[0]}.{container_version[1]}"
            target = self.container_ref or self.image
            raise RuntimeError(
                f"Python minor version mismatch: container ({target}) runs"
                f"Python {ctr_str}, host runs Python {host_str}. cloudpickle"
                f"pickles function bytecode, which is not portable across"
                f"CPython minor versions.\n"
                f" Possible fixes:\n"
                f"   - Run your script in a Python {ctr_str} virtualenv on the host, so the bytecode is compatible with the container's Python.\n"
                f"   - Use/build an image whose Python matches your host version (currently {host_str}).\n"
                f"   - Switch the runner's mode to 'reference', which is portable across python versions\n"
            )
        self._python_version_checked = True

    def _probe_container_python_version(self) -> Tuple[int, int]:
        snippet = (
            "import sys; "
            "print(sys.version_info.major, sys.version_info.minor)"
        )
        stdout: bytes
        stderr: bytes
        if self._container is not None:
            # persistent / attached — exec in the running container
            result = self._container.exec_run(
                ["python", "-c", snippet],
                stdout=True,
                stderr=True,
                demux=True,
            )
            out, err = result.output
            stdout = out or b""
            stderr = err or b""
        else:
            # on-demand — spin up a one-shot probe container. See
            # _ensure_container_started for why python goes in entrypoint=.
            container = self.client.containers.create(
                self.image,
                entrypoint=["python"],
                command=["-c", snippet],
            )
            try:
                container.start()
                container.wait()
                stdout = container.logs(stdout=True, stderr=False)
                stderr = container.logs(stdout=False, stderr=True)
            finally:
                try:
                    container.remove(force=True)
                except Exception:
                    pass

        text = stdout.decode("utf-8", "replace").strip()
        parts = text.split()
        if len(parts) != 2:
            err_text = stderr.decode("utf-8", "replace").strip() or "<no stderr>"
            raise RuntimeError(
                "could not probe container Python version "
                f"(stdout={text!r}, stderr={err_text})"
            )
        _log.debug("container python version: %s", text)
        return (int(parts[0]), int(parts[1]))

    # ------------------------------------------------------------------
    # Workspace hooks
    #
    # All three hooks need a live container, so they call
    # _ensure_container_started() (a no-op after the first call). They
    # use the same docker primitives as source shipping: exec_run for
    # the scan, put_archive for uploads, get_archive for downloads.
    # ------------------------------------------------------------------

    def _ensure_workspace_path(self, runner_path: str) -> None:
        """Make sure ``runner_path`` exists in the container and is
        writable by whichever user yonder will exec as.

        DockerRunner defaults to ``user="host"`` (the calling user's
        UID/GID), which typically can't ``mkdir`` directly under ``/``.
        We run the mkdir as root via ``user="0:0"`` and chmod the
        directory ``0777`` so subsequent user-namespaced execs and the
        function's own writes both work."""
        cmd = ["sh", "-c", f"mkdir -p '{runner_path}' && chmod 0777 '{runner_path}'"]
        res = self._container.exec_run(cmd, user="0:0")
        if res.exit_code != 0:
            err = (res.output or b"").decode("utf-8", "replace")
            raise RuntimeError(
                f"workspace prepare {runner_path} in {self.name} failed: {err}"
            )

    def scan_workspace(self, *, runner_path, include, exclude, hint) -> Manifest:
        self._ensure_image_built()
        self._ensure_container_started()
        self._ensure_workspace_path(runner_path)
        args = runner_scan_args(runner_path, include, exclude, hint)
        result = self._container.exec_run(
            ["python", "-c", RUNNER_SCAN_SCRIPT, *args],
            stdout=True,
            stderr=True,
            demux=True,
            **self._user_kwarg(),
        )
        stdout, stderr = result.output
        if result.exit_code != 0:
            err = (stderr or b"").decode("utf-8", "replace").strip() or "<no stderr>"
            raise RuntimeError(
                f"workspace scan in container {self.name} exited "
                f"{result.exit_code}: {err}"
            )
        return parse_runner_manifest(stdout or b"")

    def upload_workspace(self, *, runner_path, tar_bytes, deletes) -> None:
        self._ensure_image_built()
        self._ensure_container_started()
        self._ensure_workspace_path(runner_path)
        if tar_bytes:
            if not self._container.put_archive(runner_path, tar_bytes):
                raise RuntimeError(
                    f"workspace upload put_archive failed "
                    f"(target {runner_path} in {self.name})"
                )
        if deletes:
            # Delete by exec'ing rm — paths are joined and escaped via
            # shell single-quoting since we go through `sh -c`.
            quoted = " ".join("'" + p.replace("'", "'\\''") + "'" for p in deletes)
            cmd = [
                "sh", "-c",
                f"cd '{runner_path}' && rm -f -- {quoted}",
            ]
            rm = self._container.exec_run(cmd, **self._user_kwarg())
            if rm.exit_code != 0:
                # Deletes are best-effort; log and continue.
                _log.warning(
                    "workspace delete in %s exited %d: %s",
                    self.name,
                    rm.exit_code,
                    (rm.output or b"").decode("utf-8", "replace"),
                )

    def download_workspace(self, *, runner_path, paths) -> bytes:
        self._ensure_image_built()
        self._ensure_container_started()
        self._ensure_workspace_path(runner_path)
        if not paths:
            # An empty list still needs to be a valid (empty) tar. Build
            # one locally rather than asking docker to tar zero files.
            return _ws_pack_files(runner_path, [])
        # The cheapest path is to ask `tar` inside the container to pack
        # exactly the files we want, list piped through stdin. docker-py
        # has no equivalent to `get_archive` for a file list — it tars
        # whole subtrees — so we go through exec_run and capture stdout.
        # Tar reads paths relative to its `-C` directory.
        manifest = "\n".join(paths).encode("utf-8")
        exec_id = self.client.api.exec_create(
            self._container.id,
            ["tar", "c", "-C", runner_path, "-T", "-"],
            stdout=True,
            stderr=True,
            stdin=True,
            **self._user_kwarg(),
        )["Id"]
        sock = self.client.api.exec_start(exec_id, socket=True, demux=True)
        try:
            raw = sock._sock if hasattr(sock, "_sock") else sock
            raw.sendall(manifest)
            try:
                raw.shutdown(1)  # half-close so tar sees EOF on its file list
            except OSError:
                pass
            stdout_chunks: List[bytes] = []
            stderr_chunks: List[bytes] = []
            # demux=True yields (stdout, stderr) tuples.
            for chunk in sock:
                if isinstance(chunk, tuple):
                    out, err = chunk
                    if out:
                        stdout_chunks.append(out)
                    if err:
                        stderr_chunks.append(err)
                elif chunk:
                    stdout_chunks.append(chunk)
        finally:
            try:
                sock.close()
            except Exception:
                pass
        info = self.client.api.exec_inspect(exec_id)
        if info.get("ExitCode"):
            err = b"".join(stderr_chunks).decode("utf-8", "replace")
            raise RuntimeError(
                f"workspace download tar in {self.name} exited "
                f"{info.get('ExitCode')}: {err}"
            )
        return b"".join(stdout_chunks)


def _check_envelope(stdout: bytes, stderr: bytes, exit_code: Optional[int]) -> None:
    if not stdout:
        msg = stderr.decode("utf-8", "replace").strip() or "<no stderr>"
        raise RuntimeError(
            f"yonder runner returned no stdout (exit_code={exit_code}). stderr:\n{msg}"
        )
