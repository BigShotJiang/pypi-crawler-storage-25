from __future__ import annotations

from typing import Callable, List, Optional

from .._workspace import (
    Manifest,
    Workspace,
    run_download_phase,
    run_upload_phase,
    translate_via_workspace,
)


class Runner:
    """A self-contained execution target for a yonder-decorated function.

    Concrete runners hold their own configuration (image, env, mounts, etc.)
    and expose a single :meth:`run` method that takes a cloudpickled payload
    of the form ``{"func": ..., "args": (...), "kwargs": {...}}`` and returns
    the cloudpickled envelope produced by the in-container bootstrap.

    :meth:`start` and :meth:`close` are optional lifecycle hooks; the default
    implementations are no-ops, which is correct for stateless / on-demand
    runners. Long-lived runners override them to manage their container.

    ``when`` is an optional zero-arg predicate stored on the runner itself.
    If set and it returns ``False``, the decorator skips this runner and
    runs the function locally — independent of any ``when=`` passed to the
    ``@yonder.to`` decorator. It composes with the decorator's predicate as
    AND: the runner is used only when both return ``True``.

    ``mode`` selects the transport. ``"cloudpickle"`` (default) ships the
    function as bytecode via cloudpickle; the host and container Pythons
    must match minor versions. ``"reference"`` ships the function as
    ``(module, qualname, args, kwargs)`` and lets the container import
    its own copy — bytecode never crosses the wire and host/container
    Python versions can differ. Reference mode requires the function to
    be defined at module scope in a non-``__main__`` module.

    Workspace file sync
    -------------------

    Runners that override the three workspace hooks (:meth:`scan_workspace`,
    :meth:`upload_workspace`, :meth:`download_workspace`) can carry a
    :class:`~yonder._workspace.Workspace` and synchronize files with the
    host filesystem around each call. The decorator drives this through
    :meth:`sync_in` (before dispatch) and :meth:`sync_out` (after).
    """

    when: Optional[Callable[[], bool]] = None
    mode: str = "cloudpickle"
    workspace: Optional[Workspace] = None
    name: str = ""

    def run(self, payload: bytes) -> bytes:
        raise NotImplementedError

    # ------------------------------------------------------------------
    # HostPath translation
    # ------------------------------------------------------------------

    def translate_host_path(self, path: str) -> str:
        """Translate a host-side path to its equivalent inside the runner.

        Called by the decorator on every :class:`yonder.HostPath` it finds
        in a call's args/kwargs before dispatching. The default
        implementation honors :attr:`workspace` entries; subclasses that
        also support ``mounts=`` should override and fall through to
        this base via :meth:`_workspace_translate` when their own table
        doesn't cover the path.

        Raises :class:`ValueError` when no mapping covers ``path``.
        """
        translated = self._workspace_translate(path)
        if translated is not None:
            return translated
        raise NotImplementedError(
            f"{type(self).__name__} does not support HostPath translation. "
            f"Pass the in-runner path directly instead."
        )

    def _workspace_translate(self, path: str) -> Optional[str]:
        """Try to translate via the runner's workspace. Returns ``None``
        when no workspace entry covers the path so subclasses can fall
        back to their own translation tables (e.g. bind mounts)."""
        return translate_via_workspace(self.workspace, path)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Optional eager initialization. Default no-op."""

    def close(self) -> None:
        """Optional cleanup. Default no-op."""

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    # ------------------------------------------------------------------
    # Workspace sync — called by the decorator before/after dispatch
    # ------------------------------------------------------------------

    def sync_in(self) -> None:
        """Upload-phase sync. Drives ``up`` and ``both`` workspace entries
        from host to runner. No-op when :attr:`workspace` is None."""
        if self.workspace is None:
            return
        run_upload_phase(self, self.workspace)

    def sync_out(self) -> None:
        """Download-phase sync. Drives ``down`` and ``both`` workspace
        entries from runner to host. No-op when :attr:`workspace` is None."""
        if self.workspace is None:
            return
        run_download_phase(self, self.workspace)

    # ------------------------------------------------------------------
    # Workspace hooks — implemented per runner
    # ------------------------------------------------------------------

    def scan_workspace(
        self,
        *,
        runner_path: str,
        include: Optional[List[str]],
        exclude: Optional[List[str]],
        hint: Optional[Manifest],
    ) -> Manifest:
        """Walk ``runner_path`` inside the runner and return a manifest of
        ``{relpath: (size, mtime_ns, sha256)}``.

        ``include`` / ``exclude`` are the same glob lists the host side
        applied. ``hint`` is the manifest from the previous successful
        sync — runner-side implementations should treat it as a
        hash cache and skip rehashing any file whose ``(size, mtime_ns)``
        still matches.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not implement workspace file sync"
        )

    def upload_workspace(
        self,
        *,
        runner_path: str,
        tar_bytes: bytes,
        deletes: List[str],
    ) -> None:
        """Extract ``tar_bytes`` into ``runner_path`` and remove each path
        in ``deletes`` (relative to ``runner_path``). Implementations
        should be atomic per file (stage + rename) so a crash mid-write
        leaves each file either old or new, never partial."""
        raise NotImplementedError(
            f"{type(self).__name__} does not implement workspace file sync"
        )

    def download_workspace(
        self,
        *,
        runner_path: str,
        paths: List[str],
    ) -> bytes:
        """Pack the listed relative paths under ``runner_path`` into a tar
        and return the bytes. Empty ``paths`` should produce an empty
        (but well-formed) tar."""
        raise NotImplementedError(
            f"{type(self).__name__} does not implement workspace file sync"
        )
