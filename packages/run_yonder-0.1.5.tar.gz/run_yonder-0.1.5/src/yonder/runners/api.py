"""ApiRunner — dispatches calls to a remote yonder-server over HTTP.

The companion to the server in :mod:`yonder.server`. Where
:class:`~yonder.DockerRunner` and :class:`~yonder.K8sRunner` exec into
their runtime via the Docker/k8s API, ApiRunner POSTs the payload to a
service the runtime is hosting on a network port — no daemon socket or
RBAC required on the client side.

Wire protocol details live in :mod:`yonder._wire`; the server's
endpoint contract lives in :mod:`yonder.server.app`.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import uuid
from threading import RLock
from typing import Callable, Iterable, List, Mapping, Optional, Union

from .base import Runner
from .._shipping import (
    DEFAULT_SOURCE_INCLUDE,
    auto_resolve_or_none,
    normalize_source_paths,
    tar_directory,
)
from .._wire import (
    HEADER_SIZE,
    HEADER_STRUCT,
    TAG_RESULT,
    TAG_STDERR,
)
from .._workspace import Manifest, normalize_workspace, parse_runner_manifest

_log = logging.getLogger("yonder.runners.api")


class ApiRunner(Runner):
    """A Runner that dispatches calls over HTTP to a ``yonder-server`` host.

    Unlike :class:`~yonder.DockerRunner` and :class:`~yonder.K8sRunner`,
    the client never touches a container runtime. Everything goes over
    a single TCP connection to the server, which spawns a fresh Python
    subprocess per call (see :mod:`yonder.server.app`).

    Multi-client by design: one running server can host many concurrent
    ApiRunner clients. Calls are isolated from each other (subprocess
    per call), but they share the server's source-tarball cache so a
    given source tree is uploaded at most once across all clients.

    Constructor arguments:

    - ``url`` — base URL of the server, e.g. ``"http://10.0.0.7:8765"``
      or ``"https://yonder.example.com"``. Trailing slash optional.
    - ``token`` — optional bearer token. If set, sent as
      ``Authorization: Bearer <token>`` on every request.
    - ``verify`` — passed through to ``requests``: ``True`` to verify
      against the system CA bundle, a path to a custom CA bundle, or
      ``False`` to disable verification (avoid in production).
    - ``mode`` — ``"cloudpickle"`` (default; server must have
      cloudpickle and a matching Python minor version) or
      ``"reference"`` (server only needs the function's module
      importable; bytecode does not cross the wire).
    - ``source_path`` — host path(s) to ship into the server so the
      function's module is importable in reference mode. Defaults to
      the caller's ``__file__`` directory in reference mode; pass
      ``[]`` to opt out (e.g. when the server image already bakes the
      module in). Pass ``"auto"`` for the caller's source dir.
    - ``source_include`` — file-extension allowlist applied when
      shipping. Defaults to ``.py / .yaml / .yml / .json``. Pass
      ``None`` to ship everything (still subject to the dir-level skip
      list in :mod:`yonder._shipping`).
    - ``workspace`` — optional ``{host_path: runner_path_or_spec}`` map
      that declares files to sync around each call (and/or paths to
      rewrite via :class:`yonder.HostPath`). See :doc:`/pages/workspace`
      for the full surface. For paths that the server already has
      (shared NFS, baked into the image), declare them with
      ``dir="translate"`` so yonder only rewrites the path and never
      copies bytes. Leave ``None`` if you don't use ``HostPath`` and
      don't need file sync.
    - ``sync_deletes`` — when ``True``, files deleted on either side
      propagate to the other during sync. Default ``False`` is the
      conservative choice.
    - ``silent`` — when ``False`` (default), every stderr chunk the
      server streams back is forwarded to the calling process's
      ``sys.stderr`` (prefixed with ``[<runner-name>]``). Set to
      ``True`` to suppress this; the bytes are still surfaced verbatim
      if a call fails.
    - ``when`` — zero-arg predicate; runs locally instead of remotely
      when it returns ``False`` (same contract as :class:`~yonder.Runner`).
    - ``timeout`` — per-request timeout in seconds. ``None`` waits
      forever (appropriate for long Binary Ninja-style jobs).
    - ``name`` — human-readable identifier used in log prefixes.

    Requires the ``requests`` package: ``pip install 'yonder[api]'``.
    """

    def __init__(
        self,
        url: str,
        token: Optional[str] = None,
        verify: Union[bool, str] = True,
        mode: str = "cloudpickle",
        source_path: Optional[Union[str, Iterable[str]]] = None,
        source_include: Optional[Iterable[str]] = DEFAULT_SOURCE_INCLUDE,
        workspace: Optional[Mapping[str, object]] = None,
        sync_deletes: bool = False,
        silent: bool = False,
        when: Optional[Callable[[], bool]] = None,
        timeout: Optional[float] = None,
        name: Optional[str] = None,
    ):
        try:
            import requests  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "ApiRunner requires the requests package. "
                "Install with: pip install 'yonder[api]'"
            ) from exc

        if mode not in ("cloudpickle", "reference"):
            raise ValueError(f"mode must be 'cloudpickle' or 'reference', got {mode!r}")

        if mode == "reference" and source_path is None:
            source_path = auto_resolve_or_none()

        self.url = url.rstrip("/")
        self.token = token
        self.verify = verify
        self.mode = mode
        self.when = when
        self.silent = silent
        self.timeout = timeout
        self.name = name or f"yonder-api-{uuid.uuid4().hex[:8]}"
        self.workspace = normalize_workspace(
            workspace, sync_deletes=sync_deletes,
        )
        self.source_include = (
            None if source_include is None else tuple(source_include)
        )

        self._ship_paths: List[str] = normalize_source_paths(source_path)
        # Cache of digests we've confirmed are on the server. Lets repeat
        # calls skip even the HEAD round-trip.
        self._shipped_digests: set = set()
        self._lock = RLock()
        self._session = None  # lazily built
        self._health_checked = False

    @property
    def session(self):
        if self._session is None:
            import requests

            s = requests.Session()
            if self.token:
                s.headers["Authorization"] = f"Bearer {self.token}"
            s.verify = self.verify
            self._session = s
        return self._session

    def start(self) -> None:
        """Probe ``/health`` to fail fast on Python-version mismatch."""
        self._check_health()

    def close(self) -> None:
        if self._session is not None:
            try:
                self._session.close()
            except Exception:
                pass
            self._session = None

    def _check_health(self) -> None:
        with self._lock:
            if self._health_checked:
                return
            r = self.session.get(f"{self.url}/health", timeout=self.timeout)
            r.raise_for_status()
            info = r.json()
            # cloudpickle ships bytecode, which is not portable across
            # CPython minor versions. Reference mode is portable, so we
            # only enforce the match for cloudpickle.
            if self.mode == "cloudpickle":
                host_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
                server_ver = info.get("python")
                if server_ver != host_ver:
                    raise RuntimeError(
                        f"ApiRunner {self.name}: Python minor version mismatch — "
                        f"server runs {server_ver}, client runs {host_ver}. "
                        f"cloudpickle pickles function bytecode, which is not "
                        f"portable across CPython minor versions.\n"
                        f"  Fixes:\n"
                        f"   - Run your script in a Python {server_ver} env on the client.\n"
                        f"   - Deploy a server whose Python matches the client ({host_ver}).\n"
                        f"   - Switch the runner to mode='reference' (version-portable)."
                    )
                if not info.get("cloudpickle", False):
                    raise RuntimeError(
                        f"ApiRunner {self.name}: server reports cloudpickle is "
                        f"not installed but mode='cloudpickle'. Install "
                        f"cloudpickle on the server or use mode='reference'."
                    )
            self._health_checked = True

    def run(self, payload: bytes) -> bytes:
        self._check_health()
        digests = self._ensure_sources_shipped()

        headers = {
            "X-Yonder-Mode": self.mode,
            "Content-Type": "application/octet-stream",
        }
        if digests:
            headers["X-Yonder-Sources"] = ",".join(digests)

        _log.debug("POST /run to %s (%d bytes, %d sources)", self.url, len(payload), len(digests))
        resp = self.session.post(
            f"{self.url}/run",
            data=payload,
            headers=headers,
            stream=True,
            timeout=self.timeout,
        )
        if resp.status_code >= 400:
            # Body is plain text / JSON on errors, not framed.
            text = resp.text
            raise RuntimeError(
                f"ApiRunner {self.name}: /run returned {resp.status_code}: {text}"
            )

        return self._consume_framed_response(resp)

    def _consume_framed_response(self, resp) -> bytes:
        """Read length-prefixed E/R frames from the response body.

        Forwards E (stderr) frames to ``sys.stderr`` (unless ``silent``),
        returns the bytes of the terminal R (result) frame.
        """
        raw = resp.raw  # urllib3.HTTPResponse — supports read(n)

        def _read_exact(n: int) -> bytes:
            buf = bytearray()
            while len(buf) < n:
                chunk = raw.read(n - len(buf))
                if not chunk:
                    raise RuntimeError(
                        f"ApiRunner {self.name}: connection closed mid-frame "
                        f"(wanted {n} bytes, got {len(buf)}). The server "
                        f"likely crashed or was killed."
                    )
                buf.extend(chunk)
            return bytes(buf)

        envelope: Optional[bytes] = None
        prefix = f"[{self.name}] " if not self.silent else None
        while True:
            header = _read_exact(HEADER_SIZE)
            tag, length = HEADER_STRUCT.unpack(header)
            data = _read_exact(length) if length else b""
            if tag == TAG_STDERR:
                if prefix is not None and data:
                    text = data.decode("utf-8", "replace")
                    sys.stderr.write(
                        "".join(prefix + line for line in text.splitlines(keepends=True))
                    )
                    sys.stderr.flush()
                continue
            if tag == TAG_RESULT:
                envelope = data
                break
            raise RuntimeError(
                f"ApiRunner {self.name}: unknown frame tag {tag!r} in response"
            )

        if envelope is None:
            raise RuntimeError(
                f"ApiRunner {self.name}: response ended without a result frame"
            )
        return envelope

    def _ensure_sources_shipped(self) -> List[str]:
        """Tar each entry in ``self._ship_paths`` and PUT it to the server
        (skipping anything already cached). Returns the list of digests
        for the ``X-Yonder-Sources`` header.
        """
        if not self._ship_paths:
            return []
        digests: List[str] = []
        for abs_host in self._ship_paths:
            tar_bytes, digest, _basename = tar_directory(
                abs_host, include=self.source_include
            )
            digests.append(digest)
            if digest in self._shipped_digests:
                continue
            # HEAD lets us skip the upload across process restarts (this
            # client doesn't know what the server has cached on first
            # contact). 200 = cached, 404 = need to upload.
            head = self.session.head(
                f"{self.url}/sources/{digest}", timeout=self.timeout
            )
            if head.status_code == 200:
                self._shipped_digests.add(digest)
                continue
            if head.status_code != 404:
                head.raise_for_status()
            _log.info(
                "shipping source tree %s (%d bytes, digest=%s) to %s",
                abs_host, len(tar_bytes), digest, self.url,
            )
            put = self.session.put(
                f"{self.url}/sources/{digest}",
                data=tar_bytes,
                headers={"Content-Type": "application/x-tar"},
                timeout=self.timeout,
            )
            put.raise_for_status()
            self._shipped_digests.add(digest)
        return digests

    def translate_host_path(self, path: str) -> str:
        """Translate a host path to its server-side equivalent.

        Walks the workspace entries — the only translation source on
        ApiRunner since the server is on a different machine. For
        paths that the server already has (shared NFS, baked into the
        image), declare them with ``dir="translate"`` so yonder
        rewrites the path without syncing bytes.

        Raises :class:`ValueError` when no entry covers the path.
        """
        translated = self._workspace_translate(path)
        if translated is not None:
            return translated
        raise ValueError(
            f"HostPath({str(path)!r}) cannot be translated: this runner "
            f"has no workspace entry covering it. Either pass a "
            f"server-side path directly as a string, or declare "
            f"`workspace={{host_path: server_path}}` on the ApiRunner. "
            f"Use `dir='translate'` for entries that the server already "
            f"has (no bytes are synced)."
        )

    # ------------------------------------------------------------------
    # Workspace hooks
    # ------------------------------------------------------------------

    def scan_workspace(self, *, runner_path, include, exclude, hint):
        resp = self.session.post(
            f"{self.url}/workspace/scan",
            json={
                "path": runner_path,
                "include": include or [],
                "exclude": exclude or [],
                "hint": (
                    {k: list(v) for k, v in hint.items()} if hint else {}
                ),
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return parse_runner_manifest(resp.content)

    def upload_workspace(self, *, runner_path, tar_bytes, deletes):
        resp = self.session.post(
            f"{self.url}/workspace/upload",
            data=tar_bytes,
            headers={
                "Content-Type": "application/x-tar",
                "X-Yonder-Workspace-Path": runner_path,
                "X-Yonder-Workspace-Deletes": json.dumps(deletes or []),
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()

    def download_workspace(self, *, runner_path, paths):
        resp = self.session.post(
            f"{self.url}/workspace/download",
            json={"path": runner_path, "paths": list(paths)},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.content
