from __future__ import annotations

import base64
import logging
import uuid
from threading import RLock
from typing import Iterable, List, Mapping, Optional, Union

from .base import Runner
from .._bootstrap import build_bootstrap
from .._shipping import (
    DEFAULT_SOURCE_INCLUDE,
    REMOTE_ROOT,
    auto_resolve_or_none,
    normalize_source_paths,
    remote_path_for,
    tar_directory,
)
from .._workspace import (
    Manifest,
    RUNNER_SCAN_SCRIPT,
    normalize_workspace,
    parse_runner_manifest,
    runner_scan_args,
)

_log = logging.getLogger("yonder.runners.k8s")


class K8sRunner(Runner):
    """A Runner that execs Python inside a Kubernetes pod.

    Specify the target pod one of three ways (exactly one is required):

    - ``image="repo/name:tag"`` — create a new pod from the image. Yonder
      owns this pod: ``start()`` creates it (``command: ["sleep",
      "infinity"]`` so it stays around for exec calls), and ``close()``
      deletes it. The container inside is always named ``"yonder"``.
    - ``pod="pod-name"`` — attach to a specific existing pod by name.
      Yonder never creates or removes it; ``close()`` is a no-op.
    - ``selector="key=value,key2=value2"`` — attach via Kubernetes label
      selector. The first Running pod that matches is used. Resolution
      is lazy (first call or eager via :meth:`start`). Like ``pod=``,
      yonder doesn't manage the pod's lifecycle.

    Options that apply to all modes:

    - ``namespace`` — pod namespace (default ``"default"``).
    - ``container`` — container within the pod (default for attach modes:
      the pod's first container; for ``image=`` mode: always ``"yonder"``).
    - ``kubeconfig`` — path to a kubeconfig file. If omitted, standard
      ``KUBECONFIG`` / ``~/.kube/config`` discovery is used; failing that,
      the in-cluster service-account config is loaded.
    - ``context`` — kubeconfig context name.
    - ``name`` — runner name (auto-derived from pod/selector/image if omitted).
    - ``api_client`` — pre-built ``kubernetes.client.ApiClient``. When
      provided, ``kubeconfig`` and ``context`` are ignored.

    Options that apply only to ``image=`` mode:

    - ``env`` — dict of environment variables to set on the container.
    - ``image_pull_secrets`` — list of existing Secret names to use as
      ``imagePullSecrets`` (for private registries).
    - ``startup_timeout`` — seconds to wait for the pod to reach Running
      before failing. Default 60. ``ImagePullBackOff`` /
      ``ErrImagePull`` / ``CreateContainerConfigError`` raise
      immediately instead of waiting out the timeout.

    For anything beyond this surface (resources, service account,
    tolerations, affinity, custom volumes, sidecars, …) deploy the pod
    out-of-band with the tooling of your choice and attach via ``pod=``
    or ``selector=``.

    Requires the ``kubernetes`` package: ``pip install 'yonder[k8s]'``.
    The target container must have ``python`` on ``PATH``. In the default
    ``mode="cloudpickle"`` it must also have ``cloudpickle`` installed and
    a Python minor version matching the host; ``mode="reference"`` drops
    both requirements but needs the function's module to be importable
    inside the pod. Pass ``source_path=`` to ship a host source tree into
    the pod automatically — yonder tars the tree, exec-streams it to
    ``/tmp/yonder-src/<digest>/``, and prepends that path to
    ``sys.path`` in the bootstrap. The upload is cached per content
    digest so an unchanged tree is shipped at most once per process.
    """

    def __init__(
        self,
        pod: Optional[str] = None,
        selector: Optional[str] = None,
        image: Optional[str] = None,
        namespace: str = "default",
        container: Optional[str] = None,
        kubeconfig: Optional[str] = None,
        context: Optional[str] = None,
        name: Optional[str] = None,
        mode: str = "cloudpickle",
        inject_cloudpickle: bool = False,
        source_path: Optional[Union[str, Iterable[str]]] = None,
        source_include: Optional[Iterable[str]] = DEFAULT_SOURCE_INCLUDE,
        env: Optional[Mapping[str, str]] = None,
        image_pull_secrets: Optional[Iterable[str]] = None,
        startup_timeout: float = 60.0,
        workspace: Optional[Mapping[str, object]] = None,
        sync_deletes: bool = False,
        api_client=None,
    ):
        try:
            import kubernetes  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "K8sRunner requires the kubernetes client. "
                "Install with: pip install 'yonder[k8s]'"
            ) from exc

        if sum(s is not None for s in (pod, selector, image)) != 1:
            raise TypeError(
                "K8sRunner requires exactly one of `pod=`, `selector=`, "
                "or `image=`"
            )

        if mode not in ("cloudpickle", "reference"):
            raise ValueError(
                f"mode must be 'cloudpickle' or 'reference', got {mode!r}"
            )

        if inject_cloudpickle:
            raise TypeError(
                "`inject_cloudpickle=True` is not supported on K8sRunner. "
                "K8sRunner attaches to a pod you manage and never mutates "
                "it — injection only works on images yonder builds itself "
                "(DockerRunner with `image=`). Either bake cloudpickle "
                "into the pod's image (`RUN pip install cloudpickle`), "
                "install it ahead of time "
                "(`kubectl exec <pod> -- pip install cloudpickle`), or "
                "switch to `mode='reference'` to avoid the dependency."
            )

        if image is None and (env or image_pull_secrets):
            raise TypeError(
                "`env=` and `image_pull_secrets=` only apply to `image=` "
                "mode (yonder is creating the pod). When attaching to an "
                "existing pod via `pod=` or `selector=`, set them in the "
                "pod spec yourself."
            )

        # Reference mode almost always needs the caller's source tree
        # shipped into the pod — default to the caller's __file__
        # directory when the user didn't specify. Pass `source_path=[]`
        # to opt out (e.g. when the pod's image already has the module).
        # REPL/Jupyter contexts silently fall through to no default.
        if mode == "reference" and source_path is None:
            source_path = auto_resolve_or_none()

        self.pod = pod
        self.selector = selector
        self.image = image
        self.namespace = namespace
        self.container = container
        self.kubeconfig = kubeconfig
        self.context = context
        self.mode = mode
        self.env = dict(env or {})
        self.image_pull_secrets = list(image_pull_secrets or [])
        self.startup_timeout = float(startup_timeout)
        self._owned = image is not None
        self._pod_created = False
        self._api_client = api_client
        self._core_v1 = None
        self._lock = RLock()
        self._resolved_pod: Optional[str] = pod
        self._resolved_container: Optional[str] = container
        self._ship_paths: List[str] = normalize_source_paths(source_path)
        self._shipped_sources: dict = {}
        self.source_include: Optional[tuple] = (
            None if source_include is None else tuple(source_include)
        )
        self.workspace = normalize_workspace(
            workspace, sync_deletes=sync_deletes,
        )

        if name is not None:
            self.name = name
        elif pod is not None:
            self.name = pod
        else:
            self.name = f"yonder-k8s-{uuid.uuid4().hex[:8]}"

        # For image= mode, the pod we create has this exact name and a
        # single container named "yonder" — pre-populate the resolved
        # targets so exec works without a separate pod-read round-trip.
        if self._owned:
            self._resolved_pod = self.name
            if self._resolved_container is None:
                self._resolved_container = "yonder"

    @property
    def core_v1(self):
        if self._core_v1 is None:
            from kubernetes import client, config

            if self._api_client is None:
                try:
                    config.load_kube_config(
                        config_file=self.kubeconfig, context=self.context
                    )
                except Exception:
                    config.load_incluster_config()
                self._api_client = client.ApiClient()
            self._core_v1 = client.CoreV1Api(self._api_client)
        return self._core_v1

    def start(self) -> None:
        """Bring the runner online.

        In ``image=`` mode, creates the pod (if not already created) and
        waits for it to reach ``Running``. In attach modes, resolves the
        pod name / container eagerly. Safe to call more than once.
        """
        with self._lock:
            self._ensure_pod_created()
            self._ensure_target_resolved()

    def run(self, payload: bytes) -> bytes:
        with self._lock:
            self._ensure_pod_created()
            self._ensure_target_resolved()
            pod = self._resolved_pod
            ctr = self._resolved_container

        from kubernetes.client.rest import ApiException
        from kubernetes.stream import stream

        sys_path_prepend = self._ensure_sources_shipped(pod, ctr)
        bootstrap = build_bootstrap(
            payload, self.mode, sys_path_prepend, envelope_encoding="base64"
        )
        _log.debug(
            "exec in pod %s/%s container=%s (%d bytes)",
            self.namespace, pod, ctr, len(payload),
        )
        kwargs = dict(
            name=pod,
            namespace=self.namespace,
            command=["python", "-c", bootstrap],
            stderr=True,
            stdin=False,
            stdout=True,
            tty=False,
            _preload_content=False,
        )
        if ctr is not None:
            kwargs["container"] = ctr

        try:
            ws = stream(self.core_v1.connect_get_namespaced_pod_exec, **kwargs)
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: pod exec failed for {self.namespace}/{pod}: {exc}"
            ) from exc

        stdout_chunks = []
        stderr_chunks = []
        try:
            while ws.is_open():
                ws.update(timeout=1)
                if ws.peek_stdout():
                    stdout_chunks.append(ws.read_stdout())
                if ws.peek_stderr():
                    stderr_chunks.append(ws.read_stderr())
            # Drain anything buffered after the channel closed.
            if ws.peek_stdout():
                stdout_chunks.append(ws.read_stdout())
            if ws.peek_stderr():
                stderr_chunks.append(ws.read_stderr())
        finally:
            ws.close()

        stdout = "".join(stdout_chunks).strip()
        stderr = "".join(stderr_chunks)

        if not stdout:
            msg = stderr.strip() or "<no stderr>"
            raise RuntimeError(
                f"yonder runner returned no stdout from pod "
                f"{self.namespace}/{pod}. stderr:\n{msg}"
            )
        try:
            return base64.b64decode(stdout)
        except Exception as exc:
            raise RuntimeError(
                f"K8sRunner: failed to decode envelope from pod "
                f"{self.namespace}/{pod}: {exc}\n"
                f"raw stdout (truncated): {stdout[:200]!r}\n"
                f"stderr: {stderr.strip() or '<no stderr>'}"
            ) from exc

    def close(self) -> None:
        with self._lock:
            if not self._owned or not self._pod_created:
                _log.info(
                    "detaching from pod %s/%s",
                    self.namespace,
                    self._resolved_pod or self.pod or self.selector,
                )
                return
            from kubernetes.client.rest import ApiException

            pod_name = self._resolved_pod
            _log.info("deleting pod %s/%s", self.namespace, pod_name)
            try:
                self.core_v1.delete_namespaced_pod(
                    name=pod_name,
                    namespace=self.namespace,
                    grace_period_seconds=0,
                )
            except ApiException as exc:
                # 404 = already gone; anything else is best-effort.
                if getattr(exc, "status", None) != 404:
                    _log.warning(
                        "failed to delete pod %s/%s: %s",
                        self.namespace, pod_name, exc,
                    )
            self._pod_created = False

    def _ensure_pod_created(self) -> None:
        """In ``image=`` mode, create the pod and wait for Running.

        No-op for attach modes (``pod=`` / ``selector=``) and after the
        first successful creation in ``image=`` mode.
        """
        if not self._owned or self._pod_created:
            return
        from kubernetes import client
        from kubernetes.client.rest import ApiException

        env_vars = [
            client.V1EnvVar(name=k, value=v) for k, v in self.env.items()
        ]
        container = client.V1Container(
            name="yonder",
            image=self.image,
            command=["sleep", "infinity"],
            env=env_vars or None,
        )
        spec = client.V1PodSpec(
            containers=[container],
            restart_policy="Never",
            image_pull_secrets=[
                client.V1LocalObjectReference(name=n)
                for n in self.image_pull_secrets
            ] or None,
        )
        pod = client.V1Pod(
            metadata=client.V1ObjectMeta(
                name=self.name,
                namespace=self.namespace,
                labels={"app.kubernetes.io/managed-by": "yonder"},
            ),
            spec=spec,
        )

        _log.info(
            "creating pod %s/%s (image=%s)",
            self.namespace, self.name, self.image,
        )
        try:
            self.core_v1.create_namespaced_pod(
                namespace=self.namespace, body=pod
            )
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: failed to create pod "
                f"{self.namespace}/{self.name}: {exc}"
            ) from exc
        # Flag set before the wait so close() on a creation-then-timeout
        # path still tries to delete the (likely-stuck) pod.
        self._pod_created = True
        self._wait_for_pod_running()

    def _wait_for_pod_running(self) -> None:
        """Watch the pod until status.phase == 'Running'.

        Uses the Kubernetes watch API rather than per-second polling —
        one long-lived stream connection instead of N HTTPS requests
        (which is both more efficient and avoids spamming
        ``InsecureRequestWarning`` on clusters with self-signed certs).

        Fails fast — and with rich detail — when the pod can't reach
        Running: ``ImagePullBackOff`` and friends raise as soon as the
        condition appears, and a terminal phase (``Failed`` /
        ``Succeeded``) includes container exit codes, container reasons,
        and the last few lines of container logs in the error.
        """
        from kubernetes import watch
        from kubernetes.client.rest import ApiException

        fail_reasons = {
            "ImagePullBackOff",
            "ErrImagePull",
            "InvalidImageName",
            "CreateContainerConfigError",
            "CreateContainerError",
        }

        w = watch.Watch()
        last_pod = None
        try:
            try:
                stream = w.stream(
                    self.core_v1.list_namespaced_pod,
                    namespace=self.namespace,
                    field_selector=f"metadata.name={self.name}",
                    timeout_seconds=int(self.startup_timeout),
                )
            except ApiException as exc:
                raise RuntimeError(
                    f"K8sRunner: failed to watch pod "
                    f"{self.namespace}/{self.name}: {exc}"
                ) from exc
            for event in stream:
                pod = event.get("object")
                if pod is None:
                    continue
                last_pod = pod
                phase = pod.status.phase if pod.status else None
                if phase == "Running":
                    return
                # Surface container-state failures before pod phase goes
                # terminal — for image-pull problems the user wants the
                # specific reason, not just "pod failed".
                for cs in (
                    (pod.status.container_statuses or [])
                    if pod.status else []
                ):
                    waiting = cs.state.waiting if cs.state else None
                    reason = waiting.reason if waiting else None
                    if reason in fail_reasons:
                        msg = waiting.message or "<no message>"
                        raise RuntimeError(
                            f"K8sRunner: pod {self.namespace}/{self.name} "
                            f"container {cs.name!r} is stuck in {reason!r}: "
                            f"{msg}"
                        )
                if phase in ("Failed", "Succeeded"):
                    raise RuntimeError(self._format_terminal_pod_error(pod))
        finally:
            w.stop()

        # Watch stream ended without seeing Running — that's the
        # server-side timeout firing.
        last_phase = (
            last_pod.status.phase if last_pod and last_pod.status else None
        )
        raise RuntimeError(
            f"K8sRunner: pod {self.namespace}/{self.name} did not reach "
            f"Running within {self.startup_timeout}s "
            f"(last phase: {last_phase!r})"
        )

    def _format_terminal_pod_error(self, pod) -> str:
        """Build a rich error string for a pod that reached a terminal phase.

        Includes the pod-level reason/message, each container's state
        (waiting / terminated, with exit code and reason), and — if the
        container actually ran — the tail of its logs. Best-effort: any
        single piece that can't be fetched is silently omitted.
        """
        from kubernetes.client.rest import ApiException

        phase = pod.status.phase if pod.status else None
        lines = [
            f"K8sRunner: pod {self.namespace}/{self.name} reached "
            f"terminal phase {phase!r} before Running"
        ]
        if pod.status:
            if pod.status.reason:
                lines.append(f"  pod reason: {pod.status.reason}")
            if pod.status.message:
                lines.append(f"  pod message: {pod.status.message}")
        for cs in (pod.status.container_statuses or []) if pod.status else []:
            state = cs.state
            if state and state.terminated:
                t = state.terminated
                lines.append(
                    f"  container {cs.name!r} terminated: "
                    f"exit={t.exit_code} reason={t.reason!r} "
                    f"message={t.message!r}"
                )
            elif state and state.waiting:
                wait = state.waiting
                lines.append(
                    f"  container {cs.name!r} waiting: "
                    f"reason={wait.reason!r} message={wait.message!r}"
                )
        # Container logs are often the most useful thing. Tolerate any
        # error — the container may have never run far enough to produce
        # output, or logs may be unavailable for other reasons.
        try:
            logs = self.core_v1.read_namespaced_pod_log(
                name=self.name,
                namespace=self.namespace,
                container="yonder",
                tail_lines=20,
            )
            if logs and logs.strip():
                lines.append("  recent container logs:")
                for ln in logs.rstrip().splitlines():
                    lines.append(f"    {ln}")
        except ApiException:
            pass
        return "\n".join(lines)

    def _ensure_sources_shipped(self, pod: str, ctr: Optional[str]) -> List[str]:
        """Tar each entry in ``self._ship_paths``, stream into the pod via
        exec stdin if not already in the per-runner cache, and return the
        list of in-pod PYTHONPATH entries to prepend in the bootstrap.

        Uses ``sh -c "mkdir -p <dir> && tar xf - -C <dir>"`` as the exec
        command and pipes the tar bytes to stdin. Requires the target
        container to have ``sh`` and ``tar`` on PATH (true for nearly
        every base image, but a hard requirement). Cached per content
        digest so an unchanged tree is shipped at most once per runner.
        """
        if not self._ship_paths:
            return []
        from kubernetes.client.rest import ApiException
        from kubernetes.stream import stream

        pythonpath_entries: List[str] = []
        for abs_host in self._ship_paths:
            tar_bytes, digest, basename = tar_directory(
                abs_host, include=self.source_include
            )
            extract_dir, pp_entry = remote_path_for(digest, basename)
            pythonpath_entries.append(pp_entry)
            if digest in self._shipped_sources:
                continue
            _log.info(
                "shipping source tree %s (%d bytes, digest=%s) to pod %s/%s:%s",
                abs_host, len(tar_bytes), digest,
                self.namespace, pod, extract_dir,
            )
            kwargs = dict(
                name=pod,
                namespace=self.namespace,
                command=["sh", "-c", f"mkdir -p {extract_dir} && tar xf - -C {extract_dir}"],
                stderr=True,
                stdin=True,
                stdout=True,
                tty=False,
                _preload_content=False,
            )
            if ctr is not None:
                kwargs["container"] = ctr
            try:
                ws = stream(
                    self.core_v1.connect_get_namespaced_pod_exec, **kwargs
                )
            except ApiException as exc:
                raise RuntimeError(
                    f"K8sRunner: failed to open exec stream for source ship "
                    f"into {self.namespace}/{pod}: {exc}"
                ) from exc
            stderr_chunks: List[str] = []
            try:
                # The tar bytes from tar_directory() include the standard
                # end-of-archive marker (two zero blocks), so `tar xf -`
                # exits cleanly after reading them and the exec session
                # closes on its own.
                ws.write_stdin(tar_bytes)
                while ws.is_open():
                    ws.update(timeout=1)
                    if ws.peek_stderr():
                        stderr_chunks.append(ws.read_stderr())
                if ws.peek_stderr():
                    stderr_chunks.append(ws.read_stderr())
            finally:
                ws.close()
            stderr = "".join(stderr_chunks).strip()
            if stderr:
                raise RuntimeError(
                    f"K8sRunner: source ship into {self.namespace}/{pod} "
                    f"reported errors: {stderr}"
                )
            self._shipped_sources[digest] = extract_dir
        return pythonpath_entries

    # ------------------------------------------------------------------
    # Workspace hooks
    #
    # All three hooks share the same exec-stream plumbing as
    # _ensure_sources_shipped: open a one-shot WebSocket against the
    # pod's exec endpoint and pipe data through stdin/stdout.
    #
    # Binary data coming *back* from the pod goes through base64
    # because the k8s python client's WSClient.read_stdout() /
    # read_stderr() decode the channel as UTF-8. Encoded tar adds ~33%
    # wire bytes but avoids decode errors and matches the pattern
    # build_bootstrap() already uses for the result envelope. Stdin
    # going *into* the pod is sent as raw binary (WSClient.write_channel
    # picks OPCODE_BINARY for bytes), so uploads don't need this hop.
    # ------------------------------------------------------------------

    def _ws_exec(self, command, stdin: bytes = b"", *, decode_stdout: bool = True):
        """Run ``command`` in the resolved pod and return ``(stdout, stderr, rc)``.

        ``stdin``, if provided, is written before draining. ``stdout`` is
        a ``str`` (default — fine for JSON, base64, plain text) when
        ``decode_stdout`` is True; pass False to get raw bytes. ``stderr``
        is always str. ``rc`` is the exec exit code parsed from the
        Kubernetes exec status frame, or 0 if no error frame arrived.
        """
        with self._lock:
            self._ensure_pod_created()
            self._ensure_target_resolved()
            pod = self._resolved_pod
            ctr = self._resolved_container

        from kubernetes.client.rest import ApiException
        from kubernetes.stream import stream

        kwargs = dict(
            name=pod,
            namespace=self.namespace,
            command=command,
            stderr=True,
            stdin=bool(stdin),
            stdout=True,
            tty=False,
            _preload_content=False,
        )
        if ctr is not None:
            kwargs["container"] = ctr
        try:
            ws = stream(self.core_v1.connect_get_namespaced_pod_exec, **kwargs)
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: pod exec failed for {self.namespace}/{pod}: {exc}"
            ) from exc

        stdout_chunks: List[str] = []
        stderr_chunks: List[str] = []
        try:
            if stdin:
                ws.write_stdin(stdin)
            while ws.is_open():
                ws.update(timeout=1)
                if ws.peek_stdout():
                    stdout_chunks.append(ws.read_stdout())
                if ws.peek_stderr():
                    stderr_chunks.append(ws.read_stderr())
            if ws.peek_stdout():
                stdout_chunks.append(ws.read_stdout())
            if ws.peek_stderr():
                stderr_chunks.append(ws.read_stderr())
            # Kubernetes signals the exit code via an out-of-band channel
            # the python client surfaces as `returncode`; on older
            # clients we fall back to "rc=0 if no stderr".
            rc = getattr(ws, "returncode", None)
        finally:
            ws.close()
        stdout = "".join(stdout_chunks)
        stderr = "".join(stderr_chunks)
        if rc is None:
            rc = 1 if stderr.strip() else 0
        return stdout, stderr, rc

    def scan_workspace(self, *, runner_path, include, exclude, hint) -> Manifest:
        args = runner_scan_args(runner_path, include, exclude, hint)
        out, err, rc = self._ws_exec(
            ["python", "-c", RUNNER_SCAN_SCRIPT, *args],
        )
        if rc != 0:
            raise RuntimeError(
                f"K8sRunner: workspace scan in {self.namespace}/{self._resolved_pod} "
                f"exited {rc}: {err.strip() or '<no stderr>'}"
            )
        return parse_runner_manifest(out.encode("utf-8"))

    def upload_workspace(self, *, runner_path, tar_bytes, deletes) -> None:
        # The k8s Python WSClient has no way to half-close stdin, so any
        # remote command that reads stdin until EOF will hang forever
        # after we finish writing. We work around this two ways:
        #   * `tar x` self-terminates on the end-of-archive marker, so
        #     it doesn't need EOF — but only if it's the *direct* reader
        #     of stdin (no `base64 -d |` in front of it, which would itself
        #     block on EOF after tar exits).
        #   * For commands that genuinely need EOF (xargs, tar -T -), we
        #     prefix the pipeline with `head -c <LEN>`, which reads exactly
        #     LEN bytes and then exits, closing the pipe and signaling EOF
        #     downstream.
        quoted_path = runner_path.replace("'", "'\\''")
        if tar_bytes:
            cmd = [
                "sh", "-c",
                f"mkdir -p '{quoted_path}' && cd '{quoted_path}' && tar x",
            ]
            _, err, rc = self._ws_exec(cmd, stdin=tar_bytes)
            if rc != 0:
                raise RuntimeError(
                    f"K8sRunner: workspace upload to {runner_path} in pod "
                    f"{self.namespace}/{self._resolved_pod} failed "
                    f"(rc={rc}): {err.strip() or '<no stderr>'}"
                )
        if deletes:
            payload = b"\0".join(p.encode("utf-8") for p in deletes)
            cmd = [
                "sh", "-c",
                f"cd '{quoted_path}' && head -c {len(payload)} | "
                f"xargs -0 -r rm -f --",
            ]
            _, err, rc = self._ws_exec(cmd, stdin=payload)
            if rc != 0:
                # Best-effort — log and continue.
                _log.warning(
                    "K8sRunner: workspace delete in %s/%s reported errors: %s",
                    self.namespace, self._resolved_pod, err.strip(),
                )

    def download_workspace(self, *, runner_path, paths) -> bytes:
        if not paths:
            from .._workspace import pack_files as _pack
            return _pack(runner_path, [])
        # File list is sent via stdin (`-T -` reads paths from stdin),
        # avoiding arg-length and shell-escaping problems. `head -c LEN`
        # gives tar a clean EOF on stdin (see upload_workspace for the
        # rationale). tar's stdout is piped through base64 so the bytes
        # survive the WebSocket's UTF-8 decoding.
        manifest = "\n".join(paths).encode("utf-8")
        quoted_path = runner_path.replace("'", "'\\''")
        cmd = [
            "sh", "-c",
            f"cd '{quoted_path}' && head -c {len(manifest)} | "
            f"tar c -T - | base64",
        ]
        out, err, rc = self._ws_exec(cmd, stdin=manifest)
        if rc != 0:
            raise RuntimeError(
                f"K8sRunner: workspace download from {runner_path} in pod "
                f"{self.namespace}/{self._resolved_pod} failed "
                f"(rc={rc}): {err.strip() or '<no stderr>'}"
            )
        try:
            return base64.b64decode(out)
        except Exception as exc:
            raise RuntimeError(
                f"K8sRunner: failed to decode tar from {runner_path}: {exc}\n"
                f"raw stdout (truncated): {out[:200]!r}"
            ) from exc

    def translate_host_path(self, path: str) -> str:
        """Workspace declarations are the only host-path mapping
        K8sRunner supports — pods don't bind-mount the client's
        filesystem. Falls through to the base class's NotImplementedError
        when no workspace covers the path."""
        translated = self._workspace_translate(path)
        if translated is not None:
            return translated
        raise ValueError(
            f"HostPath({str(path)!r}) cannot be translated: K8sRunner has "
            f"no workspace covering it. Pass `workspace={{host: pod_path}}` "
            f"or use a plain string path inside the pod."
        )

    def _ensure_target_resolved(self) -> None:
        if self._resolved_pod is not None and self._resolved_container is not None:
            return

        pod_obj = None
        if self._resolved_pod is None:
            pod_obj = self._find_pod_by_selector()
            self._resolved_pod = pod_obj.metadata.name

        if self._resolved_container is None:
            if pod_obj is None:
                pod_obj = self._read_pod(self._resolved_pod)
            containers = pod_obj.spec.containers or []
            if not containers:
                raise RuntimeError(
                    f"K8sRunner: pod {self.namespace}/{self._resolved_pod} "
                    f"has no containers"
                )
            self._resolved_container = containers[0].name

        _log.info(
            "K8sRunner %r targeting pod %s/%s (container=%s)",
            self.name, self.namespace, self._resolved_pod, self._resolved_container,
        )

    def _find_pod_by_selector(self):
        from kubernetes.client.rest import ApiException

        try:
            pods = self.core_v1.list_namespaced_pod(
                namespace=self.namespace,
                label_selector=self.selector,
            )
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: failed to list pods with selector "
                f"{self.selector!r} in namespace {self.namespace!r}: {exc}"
            ) from exc

        running = [
            p for p in pods.items
            if p.status and p.status.phase == "Running"
        ]
        if not running:
            raise RuntimeError(
                f"K8sRunner: no Running pods match selector "
                f"{self.selector!r} in namespace {self.namespace!r}"
            )
        return running[0]

    def _read_pod(self, pod_name: str):
        from kubernetes.client.rest import ApiException

        try:
            return self.core_v1.read_namespaced_pod(
                name=pod_name, namespace=self.namespace,
            )
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: pod {self.namespace}/{pod_name} not found: {exc}"
            ) from exc
