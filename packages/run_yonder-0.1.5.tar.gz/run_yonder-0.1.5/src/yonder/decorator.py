from __future__ import annotations

import functools
import inspect
import pickle
from typing import Any, Iterable, Optional

import cloudpickle

from .paths import HostPath, translate as _translate_host_paths
from .session import get as _get_runner

_DOCS_BASE = "https://jason-berger.gitlab.io/yonder"
_REF_MODE_DOCS = f"{_DOCS_BASE}/pages/runners.html#runner-modes"
_REF_MODE_EXAMPLE = f"{_DOCS_BASE}/pages/examples.html#rdkit-example"


class _TranslationError(Exception):
    """Internal carrier for a translation failure plus the arg name it
    happened in. Caught at the dispatch boundary and surfaced to the
    user as a ``ValueError`` that names the offending parameter."""

    def __init__(self, cause: ValueError):
        super().__init__(str(cause))
        self.cause = cause


def _translate_arg(qualname: str, key, value, runner_obj):
    """Wrap :func:`translate` so the runner-side ``ValueError`` from
    :meth:`translate_host_path` is re-raised with the function name and
    parameter (or positional index) the offending value came from.

    ``key`` is the parameter name for kwargs, an int index for positional
    args.
    """
    try:
        return _translate_host_paths(value, runner_obj.translate_host_path)
    except ValueError as exc:
        where = (
            f"argument {key!r}" if isinstance(key, str)
            else f"positional argument #{key}"
        )
        raise _TranslationError(
            ValueError(
                f"{qualname}: {where} could not be translated for runner "
                f"{getattr(runner_obj, 'name', type(runner_obj).__name__)!r}.\n"
                f"  {exc}"
            )
        ) from exc


def _promote_to_host_paths(value: Any) -> Any:
    """Recursively wrap plain strings as :class:`HostPath`.

    Used by ``@yonder.to(..., paths=[...])`` to opt named arguments
    into translation without making callers type ``HostPath(...)`` at
    every call site. Walks the same shape as :func:`translate`
    (``list`` / ``tuple`` / ``dict``) so a parameter typed as
    ``list[str]`` of paths also works.

    ``None`` and non-string scalars pass through unchanged.
    """
    if isinstance(value, HostPath):
        return value
    if isinstance(value, str):
        return HostPath(value)
    if isinstance(value, list):
        return [_promote_to_host_paths(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_promote_to_host_paths(v) for v in value)
    if isinstance(value, dict):
        return {k: _promote_to_host_paths(v) for k, v in value.items()}
    return value


def to(runner: str, *, paths: Optional[Iterable[str]] = None):
    """Decorator: run the wrapped function on a registered runner.

    Used as ``@yonder.to("runner-name")``. ``runner`` is the name
    previously registered via :func:`yonder.register`.

    Whether a call dispatches to the runner or runs locally is controlled
    by the runner's own ``when`` predicate (see :class:`~yonder.Runner`).
    If the runner has no ``when``, every call dispatches.

    Transport is selected by the runner via its ``mode`` attribute. With
    ``mode="cloudpickle"`` (the default), the function is shipped as
    bytecode via cloudpickle and host/container Python minor versions must
    match. With ``mode="reference"``, the function is shipped as
    ``(module, qualname, args, kwargs)`` and the container imports the
    module under its own Python; the function must be defined at module
    scope in a non-``__main__`` module.

    ``paths`` is an optional list of parameter names whose values are
    host filesystem paths and should be translated to their runner-side
    equivalents on every remote dispatch. Equivalent to wrapping each
    listed argument in :class:`HostPath` at every call site; lets call
    sites use plain strings instead. Names are validated against the
    function signature at decoration time, so typos fail fast. Pass
    individual call-site values as :class:`HostPath` for the same
    behavior when you don't control the decorator.
    """
    path_names = tuple(paths or ())

    def decorate(func):
        # Cache the signature on the decoration once. Used to (a)
        # validate `paths=` names at decoration time and (b) name
        # positional args in translation error messages.
        try:
            sig = inspect.signature(func)
        except (TypeError, ValueError):
            sig = None  # builtins / C-implemented callables
        if sig is not None and path_names:
            param_names = set(sig.parameters)
            unknown = [n for n in path_names if n not in param_names]
            if unknown:
                raise TypeError(
                    f"@yonder.to({runner!r}, paths={list(path_names)!r}): "
                    f"the function `{func.__qualname__}` has no "
                    f"parameter(s) named {unknown}. "
                    f"Valid parameters: {sorted(param_names)}"
                )

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            runner_obj = _get_runner(runner)
            runner_when = getattr(runner_obj, "when", None)
            if runner_when is not None and not runner_when():
                # Local dispatch: HostPath instances pass through unchanged
                # (they're str subclasses, so open(p)/Path(p)/etc. all work).
                return func(*args, **kwargs)

            # Promote `paths=`-named args to HostPath before the walker
            # runs. Existing call-site HostPath instances pass through
            # idempotently — the two ways to opt in compose cleanly.
            if path_names:
                bound = sig.bind_partial(*args, **kwargs)
                for name in path_names:
                    if name in bound.arguments:
                        bound.arguments[name] = _promote_to_host_paths(
                            bound.arguments[name]
                        )
                args = bound.args
                kwargs = bound.kwargs

            # Remote dispatch: rewrite any HostPath in args/kwargs to its
            # in-runner equivalent before serializing. Wrap translation
            # failures with the offending parameter name so a `paths=`
            # typo or a missing workspace entry points at the right
            # call-site argument, not just an opaque HostPath value.
            # Build a positional->name map from the signature so we can
            # name positional args in error messages.
            pos_names: list = []
            if sig is not None:
                for p in sig.parameters.values():
                    if p.kind in (
                        inspect.Parameter.POSITIONAL_ONLY,
                        inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    ):
                        pos_names.append(p.name)
            try:
                args = tuple(
                    _translate_arg(
                        func.__qualname__,
                        pos_names[i] if i < len(pos_names) else i,
                        a,
                        runner_obj,
                    )
                    for i, a in enumerate(args)
                )
                kwargs = {
                    k: _translate_arg(func.__qualname__, k, v, runner_obj)
                    for k, v in kwargs.items()
                }
            except _TranslationError as exc:
                raise exc.cause from None

            mode = getattr(runner_obj, "mode", "cloudpickle")
            if mode == "reference":
                _validate_reference(func)
                payload = pickle.dumps(
                    {
                        "module": func.__module__,
                        "qualname": func.__qualname__,
                        "args": args,
                        "kwargs": kwargs,
                    }
                )
                loads = pickle.loads
            else:
                payload = cloudpickle.dumps(
                    {"func": func, "args": args, "kwargs": kwargs}
                )
                loads = cloudpickle.loads

            # Workspace upload happens before the call so the function
            # sees fresh inputs; download happens after so the host
            # picks up whatever the function wrote. Download runs in a
            # finally so partial outputs from a failed call are still
            # pulled back — the user asked for those bytes either way.
            runner_obj.sync_in()
            try:
                result_bytes = runner_obj.run(payload)
            finally:
                runner_obj.sync_out()
            envelope = loads(result_bytes)

            if envelope["status"] == "ok":
                return envelope["value"]
            raise envelope["exception"]

        wrapper.__yonder__ = True
        wrapper.__yonder_runner__ = runner
        # Reference-mode bootstrap reads this to skip the wrapper and call
        # the original function inside the container.
        wrapper.__yonder_inner__ = func
        return wrapper

    return decorate


def _validate_reference(func) -> None:
    if func.__qualname__ != func.__name__:
        raise TypeError(
            f"reference-mode runners require module-scope functions, but "
            f"`{func.__qualname__}` is defined inside another scope. Move "
            f"the function to the top of a module file (e.g. tasks.py) and "
            f"import it where you need it.\n"
            f"  docs:    {_REF_MODE_DOCS}\n"
            f"  example: {_REF_MODE_EXAMPLE}"
        )
    if func.__module__ == "__main__":
        raise TypeError(
            f"reference-mode runners cannot ship `{func.__name__}` because "
            f"it is defined in the same script you're running "
            f"(module `__main__`). The container would have to re-execute "
            f"your script to import it, which loops back through this code "
            f"and recurses. Move `{func.__name__}` into a separate "
            f"importable module (e.g. tasks.py) and import it from your "
            f"script — see the rdkit example below.\n"
            f"  docs:    {_REF_MODE_DOCS}\n"
            f"  example: {_REF_MODE_EXAMPLE}"
        )
