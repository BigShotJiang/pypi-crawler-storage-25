"""yonder — run Python functions on registered container runners."""

from .decorator import to
from .paths import HostPath
from .predicates import missing
from .runners.api import ApiRunner
from .runners.base import Runner
from .runners.docker import DockerRunner
from .runners.k8s import K8sRunner
from .session import (
    YonderSession,
    closeAll,
    get,
    getSession,
    register,
    setLogLevel,
    wait,
)

__all__ = [
    "to",
    "register",
    "get",
    "wait",
    "closeAll",
    "setLogLevel",
    "getSession",
    "YonderSession",
    "Runner",
    "ApiRunner",
    "DockerRunner",
    "K8sRunner",
    "HostPath",
    "missing",
]

__version__ = "0.1.0"
