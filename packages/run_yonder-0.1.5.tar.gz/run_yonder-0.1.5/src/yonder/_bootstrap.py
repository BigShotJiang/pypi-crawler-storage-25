"""Shared bootstrap-script generator used by every runner.

Every runner-side bootstrap does the same five things:

1. Insert any shipped source directories at the front of ``sys.path``.
2. Decode the payload (cloudpickle or stdlib pickle).
3. Redirect fd 1 → fd 2 so user-code prints don't corrupt the envelope.
4. Run the user function (cloudpickle bytecode call, or
   ``importlib.import_module`` + qualname walk in reference mode).
5. Restore fd 1 and write the envelope back.

The only thing that varies between runners is *how* the envelope leaves
the container. Docker's exec stdout and HTTP responses can carry raw
binary; the Kubernetes pod-exec WebSocket can corrupt unframed bytes
across channels, so K8s wants the envelope base64-encoded first.
``envelope_encoding`` selects between the two.

Bringing the generator into one place was the right moment to add a new
runner (ApiRunner) — there's now exactly one place that knows how the
in-container Python is invoked.
"""
from __future__ import annotations

import base64
from typing import List, Optional


def build_bootstrap(
    payload: bytes,
    mode: str = "cloudpickle",
    sys_path_prepend: Optional[List[str]] = None,
    envelope_encoding: str = "raw",
) -> str:
    """Return a self-contained ``python -c`` script for the runner to execute.

    ``payload`` is the bytes the decorator handed the runner — either a
    cloudpickled ``{"func", "args", "kwargs"}`` dict (``mode="cloudpickle"``)
    or a stdlib-pickled ``{"module", "qualname", "args", "kwargs"}`` dict
    (``mode="reference"``). The bytes are embedded as a base64 literal so
    the script doesn't have to read stdin (some transports — docker-py's
    exec_run, in particular — make piping stdin awkward).

    ``sys_path_prepend`` is a list of absolute in-runner paths to insert
    at the front of ``sys.path`` before any user code runs. Used by
    runners that ship a host source tree into the runtime.

    ``envelope_encoding`` is ``"raw"`` (write envelope bytes directly to
    fd 1) or ``"base64"`` (write the base64-encoded envelope as ASCII).
    Use ``"base64"`` only for transports that can't carry binary cleanly
    (the K8s pod-exec WebSocket). Everything else should stay on
    ``"raw"`` so the runner doesn't pay a 33% size tax for no reason.
    """
    if mode not in ("cloudpickle", "reference"):
        raise ValueError(f"mode must be 'cloudpickle' or 'reference', got {mode!r}")
    if envelope_encoding not in ("raw", "base64"):
        raise ValueError(
            f"envelope_encoding must be 'raw' or 'base64', got {envelope_encoding!r}"
        )

    encoded = base64.b64encode(payload).decode("ascii")
    sys_path_lines = ""
    if sys_path_prepend:
        # Insert in reverse so the first entry in ``sys_path_prepend`` ends
        # up first on ``sys.path``.
        for p in reversed(sys_path_prepend):
            sys_path_lines += f"sys.path.insert(0, {p!r})\n"

    if envelope_encoding == "raw":
        envelope_write = (
            "sys.stdout.buffer.write({serializer}.dumps(_e))\n"
        )
    else:
        envelope_write = (
            "sys.stdout.write(base64.b64encode({serializer}.dumps(_e)).decode('ascii'))\n"
        )

    if mode == "reference":
        # Install a yonder shim if no real yonder is importable in the
        # runtime, OR if ``import yonder`` resolves to something that
        # doesn't expose a callable ``to`` decorator (e.g. an accidental
        # namespace package shadowing the name). The shim returns the
        # function unchanged so user modules using ``@yonder.to(...)``
        # still import cleanly. The ``__yonder_inner__`` unwrap below
        # skips the dispatcher wrapper so we don't recurse through the
        # runner inside the runtime.
        body = (
            "_install_shim = False\n"
            "try:\n"
            "    import yonder as _y\n"
            "    if not callable(getattr(_y, 'to', None)):\n"
            "        _install_shim = True\n"
            "except ImportError:\n"
            "    _install_shim = True\n"
            "if _install_shim:\n"
            "    _shim = types.ModuleType('yonder')\n"
            "    def _noop(*a, **kw):\n"
            "        def _d(f):\n"
            "            return f\n"
            "        return _d\n"
            "    _shim.to = _noop\n"
            "    sys.modules['yonder'] = _shim\n"
            f"_p = pickle.loads(base64.b64decode({encoded!r}))\n"
            # fd 1 is reserved for the envelope. Native libraries (Binary
            # Ninja's C core, etc.) write log/banner output directly to
            # fd 1, bypassing sys.stdout's TextIOWrapper buffer, and would
            # land in the stream before our envelope. Redirect fd 1 to
            # fd 2 for the duration of user code; restore right before
            # the envelope write.
            "_saved_fd1 = os.dup(1)\n"
            "os.dup2(2, 1)\n"
            "try:\n"
            "    _mod = importlib.import_module(_p['module'])\n"
            "    _obj = _mod\n"
            "    for _part in _p['qualname'].split('.'):\n"
            "        _obj = getattr(_obj, _part)\n"
            "    _inner = getattr(_obj, '__yonder_inner__', _obj)\n"
            "    _v = _inner(*_p['args'], **_p['kwargs'])\n"
            "    _e = {'status': 'ok', 'value': _v}\n"
            "except BaseException as _exc:\n"
            "    _e = {'status': 'err', 'exception': _exc}\n"
            "finally:\n"
            "    sys.stdout.flush()\n"
            "    os.dup2(_saved_fd1, 1)\n"
            "    os.close(_saved_fd1)\n"
            + envelope_write.format(serializer="pickle")
        )
        return (
            "import base64, importlib, os, pickle, sys, types\n"
            + sys_path_lines
            + body
        )

    # cloudpickle mode
    body = (
        "import cloudpickle\n"
        f"_p = cloudpickle.loads(base64.b64decode({encoded!r}))\n"
        "_saved_fd1 = os.dup(1)\n"
        "os.dup2(2, 1)\n"
        "try:\n"
        "    _v = _p['func'](*_p['args'], **_p['kwargs'])\n"
        "    _e = {'status': 'ok', 'value': _v}\n"
        "except BaseException as _exc:\n"
        "    _e = {'status': 'err', 'exception': _exc}\n"
        "finally:\n"
        "    sys.stdout.flush()\n"
        "    os.dup2(_saved_fd1, 1)\n"
        "    os.close(_saved_fd1)\n"
        + envelope_write.format(serializer="cloudpickle")
    )
    return "import base64, os, sys\n" + sys_path_lines + body
