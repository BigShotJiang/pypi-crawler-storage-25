"""Zero-arg predicates for use with :class:`~yonder.Runner` ``when=``.

A runner's ``when=`` is checked every time a decorated function is called.
If it returns ``False``, the call runs locally instead of being dispatched
to the runner. The helpers here build common predicates without lambda
boilerplate.
"""
from __future__ import annotations

import importlib.util
from typing import Callable


def missing(*names: str) -> Callable[[], bool]:
    """Predicate factory: ``True`` when any of ``names`` can't be imported.

    Slots straight into a runner's ``when=`` so the runner dispatches only
    when the host is missing the package(s) it provides:

    .. code:: python

        runner = DockerRunner(
            image="org/rdkit:latest",
            when=missing("rdkit"),  # use the container when host lacks rdkit
        )

        runner = DockerRunner(
            image="org/ml:latest",
            when=missing("torch", "numpy"),  # any missing -> dispatch
        )

    ``names`` are *import* names (``sklearn``, not ``scikit-learn``). The
    check runs :func:`importlib.util.find_spec` on each name, which is
    cheap and re-evaluated on every call — installing a package
    mid-process is reflected immediately. Any exception raised by
    ``find_spec`` (malformed name, missing parent package, …) counts as
    "missing".
    """

    def _check() -> bool:
        for n in names:
            try:
                if importlib.util.find_spec(n) is None:
                    return True
            except (ImportError, ValueError):
                return True
        return False

    return _check
