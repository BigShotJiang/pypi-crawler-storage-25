"""HTTP service that hosts a yonder runtime for :class:`yonder.ApiRunner`.

Install with ``pip install 'yonder[server]'`` and run with ``yonder serve``
(or programmatically via :func:`create_app` for embedding in another ASGI
stack).
"""
from __future__ import annotations

from .app import create_app

__all__ = ["create_app"]
