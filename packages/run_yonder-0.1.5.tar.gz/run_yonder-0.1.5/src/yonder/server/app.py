"""FastAPI application for ``yonder serve``.

Endpoints:

* ``GET /health`` — Python version, supported modes, cloudpickle
  availability, yonder version. ``ApiRunner.start()`` calls this to
  fail fast on a Python minor-version mismatch (cloudpickle bytecode
  doesn't survive across minor versions).
* ``HEAD /sources/{digest}`` — 200 if the source tarball is cached on
  the server, 404 if not. Lets the client skip the upload on cache hits.
* ``PUT /sources/{digest}`` — body is the tar bytes produced by
  :func:`yonder._shipping.tar_directory`. Idempotent; second upload of
  the same digest is a no-op. Returns the in-runtime ``sys.path`` entry
  the bootstrap should prepend for this source tree.
* ``POST /run`` — body is the opaque pickle payload. Headers:
  ``X-Yonder-Mode`` (``cloudpickle`` | ``reference``) and
  ``X-Yonder-Sources`` (comma-separated digests previously uploaded).
  The response is a stream of length-prefixed frames (see
  :mod:`yonder._wire`) — zero or more ``E`` (stderr) frames followed by
  exactly one ``R`` (result envelope) frame.

Execution is stateless: each ``/run`` spawns a fresh
``python -c <bootstrap>`` subprocess. The bootstrap is the same one
DockerRunner and K8sRunner use (see :mod:`yonder._bootstrap`), so the
three runners share one well-tested code path for unwrapping payloads
and writing envelopes. Crashes, ``sys.exit``, or interpreter-state
mutation in one call cannot leak into another.
"""
from __future__ import annotations

import asyncio
import importlib.util
import json
import logging
import os
import sys
import tarfile
import tempfile
from typing import List, Optional

from fastapi import FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse

from .. import __version__ as _yonder_version
from .._bootstrap import build_bootstrap
from .._wire import TAG_RESULT, TAG_STDERR, encode_frame
from .._workspace import (
    delete_paths as _ws_delete_paths,
    extract_tar_atomic as _ws_extract_tar_atomic,
    pack_files as _ws_pack_files,
    parse_runner_manifest as _ws_parse_manifest,
    RUNNER_SCAN_SCRIPT as _WS_SCAN_SCRIPT,
    runner_scan_args as _ws_scan_args,
)

_log = logging.getLogger("yonder.server")

# Default location for extracted source trees. Each digest gets its own
# subdirectory; the contents are extracted under ``<workdir>/<digest>/``
# and the in-runtime sys.path entry is computed by listing that dir
# (the tar always contains exactly one top-level directory — the
# basename of the original host path).
DEFAULT_WORKDIR = os.path.join(tempfile.gettempdir(), "yonder-server")


def _have_cloudpickle() -> bool:
    return importlib.util.find_spec("cloudpickle") is not None


def create_app(
    *,
    token: Optional[str] = None,
    workdir: Optional[str] = None,
    max_upload_bytes: int = 256 * 1024 * 1024,
) -> FastAPI:
    """Build the FastAPI application.

    ``token`` — if set, every request must carry
    ``Authorization: Bearer <token>``. If ``None``, the server is open
    (intended for trusted networks / localhost).

    ``workdir`` — directory to extract uploaded source trees into.
    Defaults to ``<tmp>/yonder-server``. Created if missing.

    ``max_upload_bytes`` — hard cap on a single source upload. Source
    trees over 256 MiB are almost certainly a misconfiguration (the
    default include filter is ``.py / .yaml / .yml / .json``).
    """
    workdir = workdir or DEFAULT_WORKDIR
    os.makedirs(workdir, exist_ok=True)

    # In-memory cache of {digest: absolute sys.path entry}. Populated on
    # successful PUT and on startup by scanning the workdir so a server
    # restart doesn't lose its caches.
    sources: dict = {}
    for entry in os.listdir(workdir):
        sub = os.path.join(workdir, entry)
        if not os.path.isdir(sub):
            continue
        children = [c for c in os.listdir(sub) if not c.startswith(".")]
        if len(children) == 1:
            sources[entry] = os.path.join(sub, children[0])

    app = FastAPI(title="yonder-server", version=_yonder_version)
    app.state.token = token
    app.state.workdir = workdir
    app.state.max_upload_bytes = max_upload_bytes
    app.state.sources = sources

    def _check_auth(authorization: Optional[str]) -> None:
        if app.state.token is None:
            return
        expected = f"Bearer {app.state.token}"
        if authorization != expected:
            raise HTTPException(status_code=401, detail="invalid or missing bearer token")

    @app.get("/health")
    async def health(authorization: Optional[str] = Header(default=None)):
        _check_auth(authorization)
        return {
            "service": "yonder-server",
            "version": _yonder_version,
            "python": f"{sys.version_info.major}.{sys.version_info.minor}",
            "python_full": sys.version.split()[0],
            "modes": ["cloudpickle", "reference"] if _have_cloudpickle() else ["reference"],
            "cloudpickle": _have_cloudpickle(),
        }

    @app.head("/sources/{digest}")
    async def source_exists(
        digest: str, authorization: Optional[str] = Header(default=None)
    ):
        _check_auth(authorization)
        if digest in app.state.sources:
            return Response(status_code=200)
        return Response(status_code=404)

    @app.put("/sources/{digest}")
    async def source_upload(
        digest: str,
        request: Request,
        authorization: Optional[str] = Header(default=None),
    ):
        _check_auth(authorization)
        # Reject digests outside the [a-f0-9]+ shape that _shipping produces.
        # Stops any path traversal via odd characters before we touch the FS.
        if not digest or not all(c in "0123456789abcdef" for c in digest):
            raise HTTPException(status_code=400, detail="digest must be hex")
        if digest in app.state.sources:
            return JSONResponse({"cached": True, "sys_path": app.state.sources[digest]})

        body = await request.body()
        if len(body) > app.state.max_upload_bytes:
            raise HTTPException(
                status_code=413,
                detail=f"upload exceeds {app.state.max_upload_bytes} bytes",
            )

        target_dir = os.path.join(app.state.workdir, digest)
        os.makedirs(target_dir, exist_ok=True)
        try:
            with tarfile.open(fileobj=_BytesReader(body), mode="r") as tf:
                # Defense in depth: refuse any tar entry that escapes the
                # extraction root via absolute paths or ".." segments.
                # _shipping.tar_directory only emits relative entries
                # under <basename>/, but the upload is attacker-controlled.
                for member in tf.getmembers():
                    if member.name.startswith("/") or ".." in member.name.split("/"):
                        raise HTTPException(
                            status_code=400,
                            detail=f"refusing tar entry with unsafe path {member.name!r}",
                        )
                tf.extractall(target_dir)
        except tarfile.TarError as exc:
            raise HTTPException(status_code=400, detail=f"invalid tar: {exc}") from exc

        children = [c for c in os.listdir(target_dir) if not c.startswith(".")]
        if len(children) != 1:
            raise HTTPException(
                status_code=400,
                detail=f"tar must contain exactly one top-level directory, got {children}",
            )
        sys_path = os.path.join(target_dir, children[0])
        app.state.sources[digest] = sys_path
        _log.info("cached source digest=%s at %s (%d bytes)", digest, sys_path, len(body))
        return JSONResponse({"cached": False, "sys_path": sys_path}, status_code=201)

    # ------------------------------------------------------------------
    # Workspace file sync
    #
    # Three small endpoints back the Workspace API: scan, upload, download.
    # The server side is stateless — paths it reads/writes are absolute
    # paths the client supplied (the runner-side path the user declared
    # in their workspace dict). For multi-client safety in production
    # deployments, run yonder-server inside per-client containers or
    # behind an auth proxy that namespaces /work paths.
    # ------------------------------------------------------------------

    @app.post("/workspace/scan")
    async def workspace_scan(
        request: Request,
        authorization: Optional[str] = Header(default=None),
    ):
        _check_auth(authorization)
        body = await request.json()
        runner_path = body.get("path")
        if not isinstance(runner_path, str) or not runner_path:
            raise HTTPException(status_code=400, detail="missing 'path' in request body")
        include = body.get("include") or []
        exclude = body.get("exclude") or []
        hint = body.get("hint") or {}

        # Run the same scan script the docker/k8s runners ship to their
        # containers — keeps the manifest format identical across all
        # transports.
        args = _ws_scan_args(runner_path, include, exclude, hint)
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-c", _WS_SCAN_SCRIPT, *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out, err = await proc.communicate()
        if proc.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"workspace scan failed: {err.decode('utf-8', 'replace')}",
            )
        return Response(content=out, media_type="application/json")

    @app.post("/workspace/upload")
    async def workspace_upload(
        request: Request,
        authorization: Optional[str] = Header(default=None),
        x_yonder_workspace_path: Optional[str] = Header(default=None),
        x_yonder_workspace_deletes: Optional[str] = Header(default=None),
    ):
        _check_auth(authorization)
        if not x_yonder_workspace_path:
            raise HTTPException(
                status_code=400,
                detail="missing X-Yonder-Workspace-Path header",
            )
        body = await request.body()
        if len(body) > app.state.max_upload_bytes:
            raise HTTPException(
                status_code=413,
                detail=f"upload exceeds {app.state.max_upload_bytes} bytes",
            )
        try:
            _ws_extract_tar_atomic(x_yonder_workspace_path, body)
        except RuntimeError as exc:
            # Path-traversal refusal raised by extract_tar_atomic.
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        deletes: List[str] = (
            json.loads(x_yonder_workspace_deletes) if x_yonder_workspace_deletes else []
        )
        if deletes:
            _ws_delete_paths(x_yonder_workspace_path, deletes)
        _log.info(
            "workspace upload to %s: %d bytes, %d deletes",
            x_yonder_workspace_path, len(body), len(deletes),
        )
        return JSONResponse({"ok": True, "deleted": len(deletes)})

    @app.post("/workspace/download")
    async def workspace_download(
        request: Request,
        authorization: Optional[str] = Header(default=None),
    ):
        _check_auth(authorization)
        body = await request.json()
        runner_path = body.get("path")
        paths = body.get("paths") or []
        if not isinstance(runner_path, str) or not runner_path:
            raise HTTPException(status_code=400, detail="missing 'path' in request body")
        if not isinstance(paths, list):
            raise HTTPException(status_code=400, detail="'paths' must be a list")
        tar_bytes = _ws_pack_files(runner_path, [str(p) for p in paths])
        _log.info(
            "workspace download from %s: %d files, %d bytes",
            runner_path, len(paths), len(tar_bytes),
        )
        return Response(content=tar_bytes, media_type="application/x-tar")

    @app.post("/run")
    async def run(
        request: Request,
        authorization: Optional[str] = Header(default=None),
        x_yonder_mode: str = Header(default="cloudpickle"),
        x_yonder_sources: Optional[str] = Header(default=None),
    ):
        _check_auth(authorization)
        if x_yonder_mode not in ("cloudpickle", "reference"):
            raise HTTPException(
                status_code=400,
                detail=f"X-Yonder-Mode must be cloudpickle or reference, got {x_yonder_mode!r}",
            )

        sys_path_prepend = []
        if x_yonder_sources:
            for digest in (d.strip() for d in x_yonder_sources.split(",") if d.strip()):
                entry = app.state.sources.get(digest)
                if entry is None:
                    raise HTTPException(
                        status_code=409,
                        detail=f"source digest {digest!r} not uploaded — PUT /sources/{digest} first",
                    )
                sys_path_prepend.append(entry)

        payload = await request.body()
        bootstrap = build_bootstrap(payload, x_yonder_mode, sys_path_prepend)

        return StreamingResponse(
            _stream_run(bootstrap),
            media_type="application/vnd.yonder.frames",
        )

    return app


class _BytesReader:
    """Minimal binary file-like wrapper around a ``bytes`` buffer.

    ``tarfile.open(fileobj=...)`` wants a binary file with ``read`` and
    ``seek``; wrapping a ``bytes`` in ``io.BytesIO`` works too, but this
    keeps the import surface minimal.
    """

    def __init__(self, data: bytes):
        self._data = data
        self._pos = 0

    def read(self, n: int = -1) -> bytes:
        if n < 0:
            chunk = self._data[self._pos:]
            self._pos = len(self._data)
            return chunk
        chunk = self._data[self._pos : self._pos + n]
        self._pos += len(chunk)
        return chunk

    def seek(self, pos: int, whence: int = 0) -> int:
        if whence == 0:
            self._pos = pos
        elif whence == 1:
            self._pos += pos
        elif whence == 2:
            self._pos = len(self._data) + pos
        return self._pos

    def tell(self) -> int:
        return self._pos


async def _stream_run(bootstrap: str):
    """Spawn ``python -c <bootstrap>``, frame stderr live, frame envelope at end.

    Uses ``asyncio.create_subprocess_exec`` so reading stderr doesn't
    block reading stdout. Stderr is yielded as ``E`` frames the moment
    data arrives; stdout is buffered (it's the envelope — only useful
    in one piece) and yielded as a single ``R`` frame after the
    subprocess exits.
    """
    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-c",
        bootstrap,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    stdout_chunks: list = []
    stderr_queue: asyncio.Queue = asyncio.Queue()

    async def pump_stderr():
        assert proc.stderr is not None
        while True:
            chunk = await proc.stderr.read(4096)
            if not chunk:
                break
            await stderr_queue.put(chunk)
        await stderr_queue.put(None)  # sentinel

    async def pump_stdout():
        assert proc.stdout is not None
        while True:
            chunk = await proc.stdout.read(65536)
            if not chunk:
                break
            stdout_chunks.append(chunk)

    stderr_task = asyncio.create_task(pump_stderr())
    stdout_task = asyncio.create_task(pump_stdout())

    # Drain stderr as it arrives — yield E frames live for streaming UX.
    while True:
        chunk = await stderr_queue.get()
        if chunk is None:
            break
        yield encode_frame(TAG_STDERR, chunk)

    # Stderr closed → process has either exited or is about to. Wait for
    # stdout to finish and for the process to reap so we know stdout is
    # complete and we have an exit code.
    await stdout_task
    await stderr_task
    rc = await proc.wait()

    envelope = b"".join(stdout_chunks)
    if not envelope:
        # No envelope means the subprocess died before reaching the
        # bootstrap's final write. Surface that as a pickled error
        # envelope so the client side raises a normal RuntimeError
        # instead of throwing on an empty unpickle.
        import pickle

        envelope = pickle.dumps(
            {
                "status": "err",
                "exception": RuntimeError(
                    f"yonder-server: bootstrap produced no envelope (exit={rc})"
                ),
            }
        )
    yield encode_frame(TAG_RESULT, envelope)
