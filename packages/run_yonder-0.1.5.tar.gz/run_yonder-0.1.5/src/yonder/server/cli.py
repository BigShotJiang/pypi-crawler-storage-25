"""Entry point for ``yonder serve``.

Thin wrapper around :func:`yonder.server.create_app` and ``uvicorn.run``;
all the interesting work happens in :mod:`yonder.server.app`.
"""
from __future__ import annotations

import argparse
import os
import sys
from typing import Optional


def _read_token(token: Optional[str], token_file: Optional[str]) -> Optional[str]:
    if token and token_file:
        raise SystemExit("yonder serve: pass --token or --token-file, not both")
    if token:
        return token
    if token_file:
        try:
            with open(token_file, "r") as f:
                return f.read().strip()
        except OSError as exc:
            raise SystemExit(f"yonder serve: --token-file {token_file!r}: {exc}")
    return None


def main(argv: Optional[list] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="yonder serve",
        description="Run the yonder-server HTTP service for ApiRunner clients.",
    )
    parser.add_argument("--host", default="0.0.0.0", help="bind address (default 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8765, help="bind port (default 8765)")
    parser.add_argument("--token", default=None, help="bearer token (clients pass Authorization: Bearer ...)")
    parser.add_argument(
        "--token-file",
        default=None,
        help="path to a file containing the bearer token (preferred over --token)",
    )
    parser.add_argument(
        "--workdir",
        default=None,
        help="where uploaded source tarballs are extracted (default: <tmpdir>/yonder-server)",
    )
    parser.add_argument(
        "--max-upload-bytes",
        type=int,
        default=256 * 1024 * 1024,
        help="hard cap on a single source-tarball upload",
    )
    parser.add_argument(
        "--cert", default=None, help="TLS certificate path (PEM); enables HTTPS when set with --key"
    )
    parser.add_argument("--key", default=None, help="TLS private key path (PEM)")
    parser.add_argument(
        "--log-level", default="info", help="uvicorn log level (debug/info/warning/error)"
    )
    args = parser.parse_args(argv)

    try:
        import uvicorn
    except ImportError:
        raise SystemExit(
            "yonder serve requires uvicorn. Install with: pip install 'yonder[server]'"
        )

    from .app import create_app

    token = _read_token(args.token, args.token_file) or os.environ.get("YONDER_TOKEN")
    app = create_app(
        token=token,
        workdir=args.workdir,
        max_upload_bytes=args.max_upload_bytes,
    )

    if bool(args.cert) != bool(args.key):
        raise SystemExit("--cert and --key must be set together (or neither, for plain HTTP)")

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level=args.log_level,
        ssl_certfile=args.cert,
        ssl_keyfile=args.key,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
