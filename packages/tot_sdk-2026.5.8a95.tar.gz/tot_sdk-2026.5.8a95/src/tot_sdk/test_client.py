import base64
import inspect
import json
import os
from typing import Any

import grpc
from sapiopylib.rest.pojo.DataRecord import DataRecord

from tot_sdk.agent_service_base import ContainerType
from sapiopycommons.files.file_util import FileUtil
from sapiopylib.rest.User import SapioUser

from tot_sdk.external_credentials import ExternalCredentials
from tot_sdk.protoapi.externalcredentials.external_credentials_pb2 import ExternalCredentialsPbo
from tot_sdk.protoapi.fielddefinitions.fields_pb2 import FieldValuePbo, DataRecordPbo
from tot_sdk.protoapi.pipeline.converter.converter_pb2 import ConverterDetailsRequestPbo, \
    ConverterDetailsResponsePbo, ConvertResponsePbo, ConvertRequestPbo
from tot_sdk.protoapi.pipeline.converter.converter_pb2_grpc import ConverterServiceStub
from tot_sdk.protoapi.agent.item.item_container_pb2 import ContentTypePbo, StepDataRecordContainerPbo
from tot_sdk.protoapi.agent.entry_pb2 import StepBinaryContainerPbo, StepCsvRowPbo, \
    StepCsvHeaderRowPbo, StepCsvContainerPbo, StepJsonContainerPbo, StepTextContainerPbo, \
    StepItemContainerPbo, StepInputBatchPbo
from tot_sdk.protoapi.agent.agent_pb2 import ProcessStepResponsePbo, ProcessStepRequestPbo, \
    AgentDetailsRequestPbo, AgentDetailsResponsePbo, ProcessStepResponseStatusPbo, AgentDetailsPbo, \
    AgentInputDetailsPbo, CalculateCostRequestPbo, CalculateCostResponsePbo
from tot_sdk.protoapi.agent.agent_pb2_grpc import AgentServiceStub
from tot_sdk.protoapi.session.sapio_conn_info_pb2 import SapioConnectionInfoPbo, SapioUserSecretTypePbo
from tot_sdk.protobuf_utils import ProtobufUtils
from sapiopycommons.general.aliases import FieldValue
from sapiopycommons.general.time_util import TimeUtil


# FR-47422: Created class.
class AgentOutput:
    """
    A class for holding the output of a TestClient that calls an AgentService. AgentOutput objects an be
    printed to show the output of the agent in a human-readable format.
    """
    agent_name: str

    status: str
    message: str

    # Outputs are lists of lists, where the outer lists are the different outputs of the tool, and the inner lists
    # are the entries for that output.
    binary_output: list[list[bytes]]
    csv_output: list[list[dict[str, Any]]]
    json_output: list[list[dict[str, Any]]]
    text_output: list[list[str]]
    record_output: list[list[dict[str, Any]]]
    # A mapping of index from the raw output to the container type and index from the lists above.
    index_map: dict[int, tuple[ContainerType, int]]

    structured_output_records: list[dict[str, FieldValue]]

    logs: list[str]
    execution_profiles: list[dict[str, Any]]
    cost_calculation_responses: list[dict[str, Any]]

    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.status = "Unknown"
        self.message = ""
        self.binary_output = []
        self.csv_output = []
        self.json_output = []
        self.text_output = []
        self.record_output = []
        self.index_map = {}
        self.structured_output_records = []
        self.logs = []
        self.execution_profiles = []
        self.cost_calculation_responses = []

    def save_outputs(self, path: str = "test_outputs", subfolder: str | None = None,
                     file_extensions: list[str] | None = None) -> None:
        """
        Save all outputs to files in the specified output directory.

        :param path: The directory to save the output files to. Relative paths are resolved from the calling script's
            directory.
        :param subfolder: An optional subfolder within the path to save the output files to. Useful for when you are
            calling the same agent multiple times for separate test cases.
        :param file_extensions: A list of file extensions to use for binary output files. The length of this list
            should match the number of binary outputs.
        """
        if not os.path.isabs(path):
            path = os.path.join(self._get_calling_script_directory(), path)
        output_path: str = os.path.join(path, self.agent_name)
        if subfolder:
            output_path = os.path.join(output_path, subfolder)
        if self.logs:
            os.makedirs(output_path, exist_ok=True)
            with open(os.path.join(output_path, "logs.txt"), "w") as f:
                f.write("\n".join(self.logs))
        if self.execution_profiles:
            os.makedirs(output_path, exist_ok=True)
            with open(os.path.join(output_path, "execution_profiles.json"), "w", encoding="utf-8") as f:
                f.write(json.dumps(self.execution_profiles, indent=2))
        if self.cost_calculation_responses:
            os.makedirs(output_path, exist_ok=True)
            with open(os.path.join(output_path, "cost_calculation_responses.json"), "w", encoding="utf-8") as f:
                f.write(json.dumps(self.cost_calculation_responses, indent=2))

        if not self:
            return
        os.makedirs(output_path, exist_ok=True)
        if self.binary_output and (file_extensions is None or len(file_extensions) != len(self.binary_output)):
            raise ValueError("File extensions must be provided for each binary output.")

        for i, mapping in self.index_map.items():
            output_type: ContainerType = mapping[0]
            output_index: int = mapping[1]

            match output_type:
                case ContainerType.BINARY:
                    output: list[bytes] = self.binary_output[output_index]
                    binary_zip: dict[str, bytes] = {}
                    ext: str = "." + file_extensions[output_index].lstrip(".")
                    total_output: int = len(output)
                    for j, entry in enumerate(output):
                        file_name: str = f"output_{i}_binary_{j}{ext}"
                        if j >= 5 and total_output > 6:
                            binary_zip[file_name] = entry
                        else:
                            with open(os.path.join(output_path, file_name), "wb") as f:
                                f.write(entry)
                    if binary_zip:
                        zip_file: bytes = FileUtil.tar_gzip_files(binary_zip)
                        zip_name: str = f"output_{i}_binary - {total_output - 5}_remaining_results.tar.gz"
                        with open(os.path.join(output_path, zip_name), "wb") as f:
                            f.write(zip_file)
                case ContainerType.CSV:
                    output: list[dict[str, Any]] = self.csv_output[output_index]
                    with open(os.path.join(output_path, f"output_{i}_csv.csv"), "w", encoding="utf-8") as f:
                        headers = output[0].keys()
                        f.write(",".join(headers) + "\n")
                        for row in output:
                            f.write(",".join(f'"{str(row[h])}"' for h in headers) + "\n")
                case ContainerType.DATA_RECORDS:
                    output: list[dict[str, Any]] = self.record_output[output_index]
                    file_name: str = f"output_{i}_records - {len(output)} results.json"
                    file_data: str = ""
                    for j, entry in enumerate(output):
                        file_data += json.dumps(entry, indent=2) + "\n"
                    with open(os.path.join(output_path, file_name), "w", encoding="utf-8") as f:
                        f.write(file_data)
                case ContainerType.JSON:
                    output: list[dict[str, Any]] = self.json_output[output_index]
                    file_name: str = f"output_{i}_json - {len(output)} results.json"
                    file_data: str = ""
                    for j, entry in enumerate(output):
                        file_data += json.dumps(entry, indent=2) + "\n"
                    with open(os.path.join(output_path, file_name), "w", encoding="utf-8") as f:
                        f.write(file_data)
                case ContainerType.TEXT:
                    output: list[str] = self.text_output[output_index]
                    text_zip: dict[str, str] = {}
                    total_output: int = len(output)
                    for j, entry in enumerate(output):
                        file_name: str = f"output_{i}_text_{j}.txt"
                        if j >= 5 and total_output > 6:
                            text_zip[file_name] = entry
                        else:
                            with open(os.path.join(output_path, file_name), "w", encoding="utf-8") as f:
                                f.write(entry)
                    if text_zip:
                        zip_file: bytes = FileUtil.tar_gzip_files(text_zip)
                        zip_name: str = f"output_{i}_text - {total_output - 5}_remaining_results.tar.gz"
                        with open(os.path.join(output_path, zip_name), "wb") as f:
                            f.write(zip_file)

    @staticmethod
    def _get_calling_script_directory() -> str:
        """
        Resolve paths from the script that called save_outputs(), not from the process working directory.
        """
        frame = inspect.currentframe()
        try:
            caller_frame = frame.f_back.f_back if frame and frame.f_back else None
            caller_file = caller_frame.f_globals.get("__file__") if caller_frame else None
            if caller_file:
                return os.path.dirname(os.path.abspath(caller_file))
            return os.getcwd()
        finally:
            del frame

    def __bool__(self):
        """
        Return True if the agent call was successful, False otherwise.
        """
        return self.status == "Success"

    def __str__(self):
        """
        Return a string representing a summary of the agent output.
        """
        ret_val: str = f"{self.agent_name} Output:\n"
        ret_val += f"\tStatus: {self.status}\n"
        ret_val += f"\tMessage: {self.message}\n"
        ret_val += "-" * 25 + "\n"

        if self and self.index_map:
            ret_val += f"Total Binary Output:\n"
            ret_val += f"\t{len(self.binary_output)} BINARY output(s)\n"
            ret_val += f"\t{sum(len(x) for x in self.binary_output):,} file(s)\n"
            ret_val += f"\t{sum(sum(len(y) for y in x) for x in self.binary_output):,} byte(s)\n"
            ret_val += f"Total CSV Output:\n"
            ret_val += f"\t{len(self.csv_output)} CSV output(s)\n"
            ret_val += f"\t{sum(len(x) for x in self.csv_output):,} rows(s)\n"
            ret_val += f"Total DATA_RECORDS Output:\n"
            ret_val += f"\t{len(self.record_output)} DATA_RECORDS output(s)\n"
            ret_val += f"\t{sum(len(x) for x in self.record_output):,} records(s)\n"
            ret_val += f"Total JSON Output:\n"
            ret_val += f"\t{len(self.json_output)} JSON output(s)\n"
            ret_val += f"\t{sum(len(x) for x in self.json_output):,} item(s)\n"
            ret_val += f"Total Text Output:\n"
            ret_val += f"\t{len(self.text_output)} TEXT output(s)\n"
            ret_val += f"\t{sum(len(x) for x in self.text_output):,} item(s)\n"
            ret_val += f"\t{sum(sum(len(y) for y in x) for x in self.text_output):,} characters(s)\n\n"

            for i, mapping in self.index_map.items():
                output_type: ContainerType = mapping[0]
                output_index: int = mapping[1]

                match output_type:
                    case ContainerType.BINARY:
                        output: list[bytes] = self.binary_output[output_index]
                        ret_val += f"Output Index {i}: BINARY with {len(output)} file(s)\n"
                        for j, binary in enumerate(output):
                            ret_val += f"\t{len(binary)} byte(s): {binary[:50]}...\n"
                            if j == 5:
                                ret_val += f"\tAnd {len(output) - j} more binary file(s)...\n"
                                break
                    case ContainerType.CSV:
                        output: list[dict[str, Any]] = self.csv_output[output_index]
                        ret_val += f"Output Index {i}: CSV with {len(output)} row(s)\n"
                        ret_val += f"\tHeaders: {', '.join(output[0].keys())}\n"
                        for j, csv_row in enumerate(output, start=1):
                            ret_val += f"\t{j}: {', '.join(f'{v}' for k, v in csv_row.items())}\n"
                            if j == 5:
                                ret_val += f"\tAnd {len(output) - j} more CSV row(s)...\n"
                                break
                    case ContainerType.DATA_RECORDS:
                        lines: int = 0
                        output: list[dict[str, Any]] = self.record_output[output_index]
                        ret_val += f"Output Index {i}: DATA_RECORDS with {len(output)} record(s)\n"
                        for j, json_obj in enumerate(output, start=1):
                            ret_val += f"\t"
                            dump = json.dumps(json_obj, indent=2).replace("\n", "\n\t") + "\n"
                            dump_size = dump.count("\n")
                            if dump_size > 200:
                                dump = "\n".join(dump.splitlines()[:200]) + f"\n\t\t... (truncated {dump_size - 200})\n"
                                dump_size = dump.count("\n")
                            lines += dump_size
                            ret_val += dump
                            if j == 5 or lines > 100:
                                ret_val += f"\tAnd {len(output) - j} more record(s)...\n"
                                break
                    case ContainerType.JSON:
                        lines: int = 0
                        output: list[dict[str, Any]] = self.json_output[output_index]
                        ret_val += f"Output Index {i}: JSON with {len(output)} item(s)\n"
                        for j, json_obj in enumerate(output, start=1):
                            ret_val += f"\t"
                            dump = json.dumps(json_obj, indent=2).replace("\n", "\n\t") + "\n"
                            dump_size = dump.count("\n")
                            if dump_size > 200:
                                dump = "\n".join(dump.splitlines()[:200]) + f"\n\t\t... (truncated {dump_size - 200})\n"
                                dump_size = dump.count("\n")
                            lines += dump_size
                            ret_val += dump
                            if j == 5 or lines > 100:
                                ret_val += f"\tAnd {len(output) - j} more JSON item(s)...\n"
                                break
                    case ContainerType.TEXT:
                        lines: int = 0
                        output: list[str] = self.text_output[output_index]
                        ret_val += f"Output Index {i}: TEXT with {len(output)} item(s)\n"
                        for j, text in enumerate(output, start=1):
                            lines += text.count("\n")
                            ret_val += f"\t{text}\n"
                            if j == 5 or lines > 100:
                                ret_val += f"\tAnd {len(output) - j} more text item(s)...\n"
                                break

            ret_val += f"Structured Output Records: {len(self.structured_output_records)} record(s)\n"
            lines: int = 0
            for i, record in enumerate(self.structured_output_records, start=1):
                ret_val += f"\t"
                dump = json.dumps(record, indent=2).replace("\n", "\n\t") + "\n"
                dump_size = dump.count("\n")
                if dump_size > 200:
                    dump = "\n".join(dump.splitlines()[:200]) + f"\n\t\t... (truncated {dump_size - 200})\n"
                    dump_size = dump.count("\n")
                lines += dump_size
                ret_val += dump
                if i == 5 or lines > 100:
                    ret_val += f"\tAnd {len(self.structured_output_records) - i} more new records...\n"
                    break

        ret_val += f"Logs: {len(self.logs)} item(s)\n"
        for log in self.logs:
            ret_val += f"\t{log}\n"
        if self.execution_profiles:
            ret_val += f"Execution Profiles: {len(self.execution_profiles)} item(s)\n"
            ret_val += json.dumps(self.execution_profiles, indent=2)
            ret_val += "\n"
        if self.cost_calculation_responses:
            ret_val += f"Cost Calculations: {len(self.cost_calculation_responses)} item(s)\n"
            ret_val += json.dumps(self.cost_calculation_responses, indent=2)
            ret_val += "\n"
        return ret_val


class TestClient:
    """
    A client for testing an AgentService.
    """
    grpc_server_url: str
    options: list[tuple[str, Any]] | None
    connection: SapioConnectionInfoPbo
    _request_inputs: list[StepItemContainerPbo]
    _config_fields: dict[str, FieldValuePbo]
    _credentials: list[ExternalCredentialsPbo]
    _agent_details_by_import_id: dict[str, AgentDetailsPbo]
    _agent_details_by_name: dict[str, AgentDetailsPbo]

    def __init__(self, grpc_server_url: str, message_mb_size: int = 1024, user: SapioUser | None = None,
                 options: list[tuple[str, Any]] | None = None):
        """
        :param grpc_server_url: The URL of the gRPC server to connect to.
        :param message_mb_size: The maximum size of a sent or received message in megabytes.
        :param user: Optional SapioUser object to use for the connection. If not provided, a default connection
            will be created with test credentials.
        :param options: Optional list of gRPC channel options.
        """
        self.grpc_server_url = grpc_server_url
        self.options = [
            ('grpc.max_send_message_length', message_mb_size * 1024 * 1024),
            ('grpc.max_receive_message_length', message_mb_size * 1024 * 1024)
        ]
        if options:
            self.options.extend(options)
        self._create_connection(user)
        self._request_inputs = []
        self._config_fields = {}
        self._credentials = []
        self._agent_details_by_import_id = {}
        self._agent_details_by_name = {}
        self._cache_agent_details()

    def _create_connection(self, user: SapioUser | None = None):
        """
        Create a SapioConnectionInfoPbo object from the given user. If no user was given, use dummy credentials.
        """
        self.connection = SapioConnectionInfoPbo()
        self.connection.username = user.username if user and user.username else "Testing"
        self.connection.webservice_url = user.url if user and user.url else "https://localhost:8080/webservice/api"
        if user and user.guid:
            self.connection.app_guid = user.guid
        self.connection.rmi_host.append("Testing")
        self.connection.rmi_port = 9001
        if user and user.password:
            self.connection.secret_type = SapioUserSecretTypePbo.PASSWORD
            self.connection.secret = "Basic " + base64.b64encode(f'{user.username}:{user.password}'.encode()).decode()
        else:
            self.connection.secret_type = SapioUserSecretTypePbo.SESSION_TOKEN
            self.connection.secret = user.api_token if user and user.api_token else "test_api_token"

    def add_binary_input(self, input_data: list[bytes]) -> None:
        """
        Add a binary input to the the next request.
        """
        self._add_input(ContainerType.BINARY, StepBinaryContainerPbo(items=input_data))

    def add_csv_input(self, input_data: list[dict[str, Any]]) -> None:
        """
        Add a CSV input to the next request.
        """
        csv_items = []
        for row in input_data:
            csv_items.append(StepCsvRowPbo(cells=[str(value) for value in row.values()]))
        header = StepCsvHeaderRowPbo(cells=list(input_data[0].keys()))
        self._add_input(ContainerType.CSV, StepCsvContainerPbo(header=header, items=csv_items))

    def add_record_input(self, input_data: list[DataRecord]) -> None:
        """
        Add a data record input to the next request.
        """
        records: list[DataRecordPbo] = [ProtobufUtils.data_record_to_pbo(x) for x in input_data]
        self._add_input(ContainerType.DATA_RECORDS, StepDataRecordContainerPbo(items=records))

    def add_json_input(self, input_data: list[dict[str, Any]]) -> None:
        """
        Add a JSON input to the next request.
        """
        self._add_input(ContainerType.JSON, StepJsonContainerPbo(items=[json.dumps(x) for x in input_data]))

    def add_text_input(self, input_data: list[str]) -> None:
        """
        Add a text input to the next request.
        """
        self._add_input(ContainerType.TEXT, StepTextContainerPbo(items=input_data))

    def clear_inputs(self) -> None:
        """
        Clear all inputs that have been added to the next request.
        This is useful if you want to start a new request without the previous inputs.
        """
        self._request_inputs.clear()

    def add_config_field(self, field_name: str, value: FieldValue | list[str]) -> None:
        """
        Add a configuration field value to the next request.

        :param field_name: The name of the configuration field.
        :param value: The value to set for the configuration field. If a list is provided, it will be
            converted to a comma-separated string.
        """
        if isinstance(value, list):
            value = ",".join(str(x) for x in value)
        if not isinstance(value, FieldValuePbo):
            value = ProtobufUtils.value_to_field_pbo(value)
        self._config_fields[field_name] = value

    def add_config_fields(self, config_fields: dict[str, FieldValue | list[str]]) -> None:
        """
        Add multiple configuration field values to the next request.

        :param config_fields: A dictionary of configuration field names and their corresponding values.
        """
        for x, y in config_fields.items():
            self.add_config_field(x, y)

    def clear_configs(self) -> None:
        """
        Clear all configuration field values that have been added to the next request.
        This is useful if you want to start a new request without the previous configurations.
        """
        self._config_fields.clear()

    def add_credentials(self, credentials: list[ExternalCredentials]) -> None:
        """
        Add external credentials to the connection info for the next request.

        :param credentials: A list of ExternalCredentialsPbo objects to add to the connection info.
        """
        for cred in credentials:
            self._credentials.append(cred.to_pbo())

    def clear_credentials(self) -> None:
        """
        Clear all external credentials that have been added to the next request.
        This is useful if you want to start a new request without the previous credentials.
        """
        self._credentials.clear()

    def clear_request(self) -> None:
        """
        Clear all inputs and configuration fields that have been added to the next request.
        This is useful if you want to start a new request without the previous inputs and configurations.

        Credentials are not cleared, as they may be reused across multiple requests.
        """
        self.clear_inputs()
        self.clear_configs()

    def _add_input(self, container_type: ContainerType, items: Any) -> None:
        """
        Helper method for adding inputs to the next request.
        """
        container: StepItemContainerPbo | None = None
        match container_type:
            # The content type doesn't matter when we're just testing.
            case ContainerType.BINARY:
                container = StepItemContainerPbo(content_type=ContentTypePbo(), binary_container=items)
            case ContainerType.CSV:
                container = StepItemContainerPbo(content_type=ContentTypePbo(), csv_container=items)
            case ContainerType.DATA_RECORDS:
                container = StepItemContainerPbo(content_type=ContentTypePbo(), data_record_container=items)
            case ContainerType.JSON:
                container = StepItemContainerPbo(content_type=ContentTypePbo(), json_container=items)
            case ContainerType.TEXT:
                container = StepItemContainerPbo(content_type=ContentTypePbo(), text_container=items)
            case _:
                raise ValueError(f"Unsupported container type: {container_type}")
        self._request_inputs.append(container)

    def get_service_details(self) -> AgentDetailsResponsePbo:
        """
        Get the details of the agents from the server.

        :return: A ToolDetailsResponsePbo object containing the details of the agent service.
        """
        with grpc.insecure_channel(self.grpc_server_url, options=self.options) as channel:
            stub = AgentServiceStub(channel)
            return stub.GetAgentDetails(AgentDetailsRequestPbo(sapio_conn_info=self.connection))

    def _cache_agent_details(self) -> None:
        """
        Cache agent details so paging configuration can be checked before each request.
        """
        details: AgentDetailsResponsePbo = self.get_service_details()
        for agent_details in details.agent_details:
            if agent_details.import_id:
                self._agent_details_by_import_id[agent_details.import_id] = agent_details
            if agent_details.name:
                self._agent_details_by_name[agent_details.name] = agent_details

    def _get_agent_details(self, agent_name: str) -> AgentDetailsPbo | None:
        """
        Look up agent details using the same identifier the caller will send to the service.
        """
        return self._agent_details_by_import_id.get(agent_name) or self._agent_details_by_name.get(agent_name)

    @staticmethod
    def _get_paged_input(agent_details: AgentDetailsPbo | None) -> tuple[int, AgentInputDetailsPbo] | None:
        """
        Return the first paged input config for an agent, if one exists.
        """
        if agent_details is None:
            return None
        for i, input_config in enumerate(agent_details.input_configs):
            if input_config.paged:
                return i, input_config
        return None

    @staticmethod
    def _get_container_items(container: StepItemContainerPbo) -> list[Any]:
        if container.HasField("binary_container"):
            return list(container.binary_container.items)
        if container.HasField("csv_container"):
            return list(container.csv_container.items)
        if container.HasField("data_record_container"):
            return list(container.data_record_container.items)
        if container.HasField("json_container"):
            return list(container.json_container.items)
        if container.HasField("text_container"):
            return list(container.text_container.items)
        raise ValueError("Paged input does not contain a supported item container.")

    @staticmethod
    def _copy_container_with_items(container: StepItemContainerPbo, items: list[Any]) -> StepItemContainerPbo:
        if container.HasField("binary_container"):
            return StepItemContainerPbo(
                content_type=container.content_type,
                container_name=container.container_name,
                binary_container=StepBinaryContainerPbo(items=items)
            )
        if container.HasField("csv_container"):
            return StepItemContainerPbo(
                content_type=container.content_type,
                container_name=container.container_name,
                csv_container=StepCsvContainerPbo(header=container.csv_container.header, items=items)
            )
        if container.HasField("data_record_container"):
            return StepItemContainerPbo(
                content_type=container.content_type,
                container_name=container.container_name,
                data_record_container=StepDataRecordContainerPbo(items=items)
            )
        if container.HasField("json_container"):
            return StepItemContainerPbo(
                content_type=container.content_type,
                container_name=container.container_name,
                json_container=StepJsonContainerPbo(items=items)
            )
        if container.HasField("text_container"):
            return StepItemContainerPbo(
                content_type=container.content_type,
                container_name=container.container_name,
                text_container=StepTextContainerPbo(items=items)
            )
        raise ValueError("Paged input does not contain a supported item container.")

    @staticmethod
    def _get_page_sizes(item_count: int, min_page_size: int, max_page_size: int | None) -> list[int]:
        """
        Create page sizes that satisfy the configured min and max page sizes.
        """
        if min_page_size > 1 and item_count < min_page_size:
            raise ValueError(
                f"Paged input has {item_count} item(s), which is less than the minimum page size of {min_page_size}."
            )
        if item_count == 0:
            return [0]
        if max_page_size is None or max_page_size <= 0:
            max_page_size = item_count
        if max_page_size < min_page_size:
            raise ValueError(
                f"Paged input maximum page size ({max_page_size}) is less than minimum page size ({min_page_size})."
            )

        page_sizes: list[int] = []
        remaining = item_count
        while remaining > 0:
            page_size = min(max_page_size, remaining)
            next_remaining = remaining - page_size
            if 0 < next_remaining < min_page_size:
                page_size -= min_page_size - next_remaining
                if page_size < min_page_size:
                    raise ValueError(
                        f"Paged input would leave {next_remaining} item(s), which is less than the minimum page "
                        f"size of {min_page_size}."
                    )
            page_sizes.append(page_size)
            remaining -= page_size
        return page_sizes

    def _build_input_batches(self, paged_input: tuple[int, AgentInputDetailsPbo] | None = None,
                             page_items: list[Any] | None = None, is_partial: bool = False) -> list[StepInputBatchPbo]:
        """
        Build request inputs, replacing the paged input with the current page when needed.
        """
        input_batches: list[StepInputBatchPbo] = []
        paged_input_index = paged_input[0] if paged_input else None
        for i, item in enumerate(self._request_inputs):
            if i == paged_input_index:
                item = self._copy_container_with_items(item, page_items or [])
                input_batches.append(StepInputBatchPbo(is_partial=is_partial, item_container=item))
            else:
                input_batches.append(StepInputBatchPbo(is_partial=False, item_container=item))
        return input_batches

    def _build_paged_input_batches(self, paged_input: tuple[int, AgentInputDetailsPbo]) -> list[list[StepInputBatchPbo]]:
        """
        Build all page requests for a paged input.
        """
        paged_input_index, input_config = paged_input
        if paged_input_index >= len(self._request_inputs):
            raise ValueError(f"Agent has a paged input at index {paged_input_index}, but no input was provided.")

        container = self._request_inputs[paged_input_index]
        items = self._get_container_items(container)
        min_page_size = input_config.min_page_size if input_config.min_page_size > 0 else 1
        max_page_size = input_config.max_page_size if input_config.max_page_size > 0 else None
        page_sizes = self._get_page_sizes(len(items), min_page_size, max_page_size)

        input_batches: list[list[StepInputBatchPbo]] = []
        offset = 0
        for i, page_size in enumerate(page_sizes):
            next_offset = offset + page_size
            page_items = items[offset:next_offset]
            input_batches.append(self._build_input_batches(
                paged_input=paged_input,
                page_items=page_items,
                is_partial=i < len(page_sizes) - 1
            ))
            offset = next_offset
        return input_batches

    def _process_data(self, stub: AgentServiceStub, agent_name: str, is_verbose: bool, is_dry_run: bool,
                      input_batches: list[StepInputBatchPbo]) -> ProcessStepResponsePbo:
        return stub.ProcessData(
            ProcessStepRequestPbo(
                sapio_user=self.connection,
                agent_name=agent_name,
                config_field_values=self._config_fields,
                dry_run=is_dry_run,
                verbose_logging=is_verbose,
                external_credential=self._credentials,
                input=input_batches
            )
        )

    @classmethod
    def _input_count(cls, input_batch: StepInputBatchPbo) -> int:
        return len(cls._get_container_items(input_batch.item_container))

    def _calculate_cost(self, stub: AgentServiceStub, agent_name: str, is_verbose: bool,
                        input_batches: list[StepInputBatchPbo], include_inputs: bool) -> CalculateCostResponsePbo:
        return stub.CalculateCost(
            CalculateCostRequestPbo(
                agent_name=agent_name,
                config_field_values=self._config_fields,
                verbose_logging=is_verbose,
                input=input_batches if include_inputs else [],
                input_count=[self._input_count(input_batch) for input_batch in input_batches]
            )
        )

    @staticmethod
    def _store_cost_response(results: AgentOutput, response: CalculateCostResponsePbo,
                             page_number: int | None = None) -> None:
        response_json: dict[str, Any] = {
            "cost_tokens": response.cost_tokens,
            "cost_calculation_message": response.cost_calculation_message,
        }
        if page_number is not None:
            response_json["page_number"] = page_number
        results.cost_calculation_responses.append(response_json)

    @staticmethod
    def _response_status_to_str(status: ProcessStepResponseStatusPbo) -> str:
        match status:
            case ProcessStepResponseStatusPbo.SUCCESS:
                return "Success"
            case ProcessStepResponseStatusPbo.FAILURE:
                return "Failure"
            case _:
                return "Unknown"

    @staticmethod
    def _append_output_items(results: AgentOutput, output_index: int, output_type: ContainerType,
                             items: list[Any]) -> None:
        if output_index not in results.index_map:
            match output_type:
                case ContainerType.BINARY:
                    results.index_map[output_index] = (output_type, len(results.binary_output))
                    results.binary_output.append([])
                case ContainerType.CSV:
                    results.index_map[output_index] = (output_type, len(results.csv_output))
                    results.csv_output.append([])
                case ContainerType.DATA_RECORDS:
                    results.index_map[output_index] = (output_type, len(results.record_output))
                    results.record_output.append([])
                case ContainerType.JSON:
                    results.index_map[output_index] = (output_type, len(results.json_output))
                    results.json_output.append([])
                case ContainerType.TEXT:
                    results.index_map[output_index] = (output_type, len(results.text_output))
                    results.text_output.append([])
                case _:
                    raise ValueError(f"Unsupported output type: {output_type}")

        existing_type, existing_index = results.index_map[output_index]
        if existing_type != output_type:
            raise ValueError(f"Output {output_index} changed type between paged responses.")

        match output_type:
            case ContainerType.BINARY:
                results.binary_output[existing_index].extend(items)
            case ContainerType.CSV:
                results.csv_output[existing_index].extend(items)
            case ContainerType.DATA_RECORDS:
                results.record_output[existing_index].extend(items)
            case ContainerType.JSON:
                results.json_output[existing_index].extend(items)
            case ContainerType.TEXT:
                results.text_output[existing_index].extend(items)

    def _merge_response(self, results: AgentOutput, response: ProcessStepResponsePbo,
                        page_number: int | None = None) -> None:
        response_status = self._response_status_to_str(response.status)
        if response_status == "Failure" or results.status == "Unknown":
            results.status = response_status

        if response.status_message:
            message = response.status_message
            if page_number is not None:
                message = f"Page {page_number}: {message}"
            results.message = f"{results.message}\n{message}" if results.message else message

        for i, output in enumerate(response.output):
            container = output.item_container

            if container.HasField("binary_container"):
                self._append_output_items(results, i, ContainerType.BINARY, list(container.binary_container.items))
            elif container.HasField("csv_container"):
                csv_output: list[dict[str, Any]] = []
                for row in container.csv_container.items:
                    output_row: dict[str, Any] = {}
                    for j, header in enumerate(container.csv_container.header.cells):
                        output_row[header] = row.cells[j]
                    csv_output.append(output_row)
                self._append_output_items(results, i, ContainerType.CSV, csv_output)
            elif container.HasField("data_record_container"):
                record_output: list[dict[str, Any]] = []
                for record in container.data_record_container.items:
                    record_output.append(ProtobufUtils.pbo_to_data_record(record).to_json())
                self._append_output_items(results, i, ContainerType.DATA_RECORDS, record_output)
            elif container.HasField("json_container"):
                self._append_output_items(results, i, ContainerType.JSON,
                                          [json.loads(x) for x in container.json_container.items])
            elif container.HasField("text_container"):
                self._append_output_items(results, i, ContainerType.TEXT, list(container.text_container.items))

        for record in response.new_records:
            field_map: dict[str, Any] = {x: ProtobufUtils.field_pbo_to_value(y) for x, y in record.fields.items()}
            results.structured_output_records.append(field_map)

        results.logs.extend(response.log)
        if response.execution_profile:
            results.execution_profiles.append(json.loads(response.execution_profile))

    def call_agent(self, agent_name: str, is_verbose: bool = True, is_dry_run: bool = False) -> AgentOutput:
        """
        Send the request to the agent service for a particular agent name. This will send all the inputs that have been
        added using the add_X_input functions.

        :param agent_name: The name of the agent to call on the server.
        :param is_verbose: If True, the agent will log verbosely.
        :param is_dry_run: If True, the agent will not be executed, but the request will be validated.
        :return: An AgentOutput object containing the results of the agent service call.
        """
        print(f"Calling agent \"{agent_name}\"...")
        with grpc.insecure_channel(self.grpc_server_url, options=self.options) as channel:
            stub = AgentServiceStub(channel)
            start = TimeUtil.now_in_millis()
            results = AgentOutput(agent_name)
            agent_details = self._get_agent_details(agent_name)
            paged_input = self._get_paged_input(agent_details)
            include_cost_inputs = bool(
                agent_details and agent_details.send_full_inputs_for_cost_calculation
            )

            if paged_input is None:
                input_batches = self._build_input_batches()
                cost_response = self._calculate_cost(stub, agent_name, is_verbose, input_batches, include_cost_inputs)
                self._store_cost_response(results, cost_response)
                response = self._process_data(
                    stub, agent_name, is_verbose, is_dry_run, input_batches
                )
                self._merge_response(results, response)
            else:
                input_batches = self._build_paged_input_batches(paged_input)
                print(f"Agent input will be sent in {len(input_batches)} page(s).")
                for i, page_input_batches in enumerate(input_batches, start=1):
                    print(f"Calling page {i} of {len(input_batches)}...")
                    cost_response = self._calculate_cost(
                        stub, agent_name, is_verbose, page_input_batches, include_cost_inputs
                    )
                    self._store_cost_response(results, cost_response, page_number=i)
                    response = self._process_data(stub, agent_name, is_verbose, is_dry_run, page_input_batches)
                    self._merge_response(results, response, page_number=i)

            end = TimeUtil.now_in_millis()
            print(f"Agent call completed in {(end - start) / 1000.:.3f} seconds")
            return results


class TestConverterClient:
    """
    A client for testing a ConverterService.
    """
    grpc_server_url: str
    options: list[tuple[str, Any]] | None

    def __init__(self, grpc_server_url: str, options: list[tuple[str, Any]] | None = None):
        """
        :param grpc_server_url: The URL of the gRPC server to connect to.
        :param options: Optional list of gRPC channel options.
        """
        self.grpc_server_url = grpc_server_url
        self.options = options

    def get_converter_details(self) -> ConverterDetailsResponsePbo:
        """
        Get the details of the converters from the server.

        :return: A ToolDetailsResponsePbo object containing the details of the converter service.
        """
        with grpc.insecure_channel(self.grpc_server_url, options=self.options) as channel:
            stub = ConverterServiceStub(channel)
            return stub.GetConverterDetails(ConverterDetailsRequestPbo())

    def convert_content(self, input_container: StepItemContainerPbo, target_type: ContentTypePbo) \
            -> StepItemContainerPbo:
        """
        Convert the content of the input container to the target content type.

        :param input_container: The input container to convert. This container must have a ContentTypePbo set that
            matches one of the input types that the converter service supports.
        :param target_type: The target content type to convert to. This must match one of the target types that the
            converter service supports.
        :return: A StepItemContainerPbo object containing the converted content.
        """
        with grpc.insecure_channel(self.grpc_server_url, options=self.options) as channel:
            stub = ConverterServiceStub(channel)
            response: ConvertResponsePbo = stub.ConvertContent(
                ConvertRequestPbo(item_container=input_container, target_content_type=target_type)
            )
            return response.item_container
