from __future__ import annotations

from typing import Any

from sapiopylib.rest.User import SapioUser
from sapiopylib.rest.pojo.DataRecord import DataRecord
from sapiopylib.rest.utils.singletons import SapioContextManager

from tot_sdk.webservice.pojos.foundations_pipeline import (
    FoundationsPipelineTemplateResult,
    PipelineResult,
    PipelineStepOutputResult,
    PipelineStepResult,
    PipelineTemplateBlueprintResult,
    ScoutResult,
    StartPipelineRequest,
    StartPipelineResponse,
    StepInput,
)
from tot_sdk.webservice.pojos.pipeline import VersionId


class FoundationsPipelineManager(SapioContextManager):
    """
    REST API service for Foundations Pipeline endpoints.
    """

    def __init__(self, user: SapioUser):
        super().__init__(user)

    @staticmethod
    def _version_id_payload(version_id: VersionId | str) -> str:
        if isinstance(version_id, VersionId):
            return version_id.to_json()
        return version_id

    def get_scouts(self, limit: int | None = None) -> list[ScoutResult]:
        """
        Retrieve Scout records created by the current user, sorted descending by last modified date.

        :param limit: Optional maximum number of scouts to return.
        :return: Matching scout records.
        """
        params = {}
        if limit is not None:
            params["limit"] = str(limit)
        response = self.user.get("/ext/helix/scout/get", params=params or None)
        self.user.raise_for_status(response)
        return [ScoutResult.from_json(item) for item in response.json()]

    def get_scout_pipelines(self, scout_record_ids: list[int], limit: int | None = None) -> list[PipelineResult]:
        """
        Retrieve pipeline records linked to the given scout record IDs.

        :param scout_record_ids: Scout record IDs to query for linked pipelines.
        :param limit: Optional maximum number of pipelines to return. Defaults server-side when omitted.
        :return: Matching pipeline records.
        """
        params = {
            "scoutRecordIds": ",".join(str(record_id) for record_id in scout_record_ids)
        }
        if limit is not None:
            params["limit"] = str(limit)
        response = self.user.get("/ext/helix/scout/pipelines/get", params=params)
        self.user.raise_for_status(response)
        return [PipelineResult.from_json(item) for item in response.json()]

    def get_scout_results(self, scout_record_ids: list[int]) -> dict[int, DataRecord | None]:
        """
        Retrieve final report records for scout runs when they are available.

        :param scout_record_ids: VeloxPipelineGroup record IDs for the scout runs.
        :return: A map of scout record ID to its raw H_ScoutFinalReport DataRecord payload, or None if unfinished.
        """
        response = self.user.post("/ext/helix/scout/results", payload=scout_record_ids)
        self.user.raise_for_status(response)
        return {int(record_id): DataRecord.from_json(result) if result else None for record_id, result in response.json().items()}

    def get_pipelines(self, limit: int | None = None) -> list[PipelineResult]:
        """
        Retrieve pipeline records created by the current user, sorted descending by last modified date.

        :param limit: Optional maximum number of pipelines to return.
        :return: Matching pipeline records.
        """
        params = {}
        if limit is not None:
            params["limit"] = str(limit)
        response = self.user.get("/ext/helix/pipeline/get", params=params or None)
        self.user.raise_for_status(response)
        return [PipelineResult.from_json(item) for item in response.json()]

    def get_pipeline_steps(self, pipeline_id: int) -> list[PipelineStepResult]:
        """
        Retrieve pipeline step records for the given pipeline.

        :param pipeline_id: Pipeline record ID.
        :return: Pipeline step records belonging to the pipeline.
        """
        response = self.user.get("/ext/helix/pipelineStep/get", params={"pipelineId": str(pipeline_id)})
        self.user.raise_for_status(response)
        return [PipelineStepResult.from_json(item) for item in response.json()]

    def get_pipeline_step_outputs(self, pipeline_id: int, step_id: str | int) -> list[PipelineStepOutputResult]:
        """
        Retrieve outputs for a pipeline step.

        :param pipeline_id: Pipeline record ID.
        :param step_id: Step template ID for the pipeline step.
        :return: Outputs available on the pipeline step.
        """
        params = {
            "pipelineId": str(pipeline_id),
            "stepId": str(step_id),
        }
        response = self.user.get("/ext/helix/pipelineStepOutput/get", params=params)
        self.user.raise_for_status(response)
        return [PipelineStepOutputResult.from_json(item) for item in response.json()]

    def get_pipeline_templates(self) -> list[FoundationsPipelineTemplateResult]:
        """
        Retrieve the latest visible pipeline templates in the system.

        :return: Pipeline template summary records.
        """
        response = self.user.get("/ext/helix/pipelineTemplate/get")
        self.user.raise_for_status(response)
        return [FoundationsPipelineTemplateResult.from_json(item) for item in response.json()]

    def get_pipeline_template_steps(self, pipeline_template_id: VersionId | str) -> PipelineTemplateBlueprintResult:
        """
        Retrieve the blueprint and step metadata for a pipeline template.

        :param pipeline_template_id: Pipeline template identifier in versioned string form, or a VersionId.
        :return: Pipeline template blueprint and step metadata.
        """
        params = {
            "pipelineTemplateId": self._version_id_payload(pipeline_template_id)
        }
        response = self.user.get("/ext/helix/pipelineTemplateStep/get", params=params)
        self.user.raise_for_status(response)
        return PipelineTemplateBlueprintResult.from_json(response.json())

    def start_new_pipeline_from_template(self, request: StartPipelineRequest | VersionId | str,
                                         step_inputs: dict[str | int, StepInput | dict[str, Any]] | None = None,
                                         step_runtime_parameters: dict[str | int, dict[str, Any]] | None = None) \
            -> StartPipelineResponse:
        """
        Start a new pipeline from a pipeline template.

        :param request: A StartPipelineRequest, or the pipeline template ID for the convenience form.
        :param step_inputs: Optional per-step inputs, used only when request is a template ID.
        :param step_runtime_parameters: Optional per-step runtime parameters, used only when request is a template ID.
        :return: Pipeline creation response.
        """
        if isinstance(request, StartPipelineRequest):
            payload = request.to_json()
        else:
            payload = StartPipelineRequest(request, step_inputs, step_runtime_parameters).to_json()

        response = self.user.post("/ext/helix/startNewPipelineFromTemplate", payload=payload)
        self.user.raise_for_status(response)
        return StartPipelineResponse.from_json(response.json())
