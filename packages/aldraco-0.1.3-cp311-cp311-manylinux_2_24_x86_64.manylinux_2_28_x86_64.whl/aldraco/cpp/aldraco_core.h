#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace AldracoCore {

enum decoding_status {
  successful,
  not_draco_encoded,
  no_position_attribute,
  failed_during_decoding
};

enum encoding_status {
  successful_encoding,
  failed_during_encoding
};

struct AttributeObject {
  int unique_id = -1;         // Draco attribute unique id
  int num_components = 0;
  int data_type = 0;          // draco::DataType numeric value
  int attribute_type = -1;    // draco::GeometryAttribute::Type numeric value
  std::string name;           // attribute name if present (metadata)

  std::vector<float> float_data;
  std::vector<std::uint32_t> uint_data;
  std::vector<std::uint16_t> uint16_data;
  std::vector<std::uint8_t> byte_data;
};

struct MeshObject {
  std::vector<float> points;
  std::vector<std::uint32_t> faces;
  std::vector<float> normals;
  std::vector<float> tex_coord;

  std::vector<std::uint8_t> colors;
  int colors_channel = 0;

  // ====== 新增：存储唯一颜色的数量 (由底层并发计算) ======
  int unique_color_count = 0;

  // I3S attributes (optional)
  std::vector<std::uint16_t> uvr;
  int uvr_components = 0;
  std::vector<std::uint32_t> feature_index;
  int feature_index_components = 0;
  // I3S feature ids stored in metadata of feature-index attribute (optional)
  std::vector<std::int32_t> feature_ids;

  std::vector<AttributeObject> attributes;

  // Encoding options stored in metadata
  bool encoding_options_set = false;
  int quantization_bits = 0;
  double quantization_range = 0;
  std::vector<double> quantization_origin;

  decoding_status decode_status = successful;
};

struct EncodedObject {
  std::vector<std::uint8_t> buffer;
  encoding_status encode_status = successful_encoding;
};

struct GenericAttributeInput {
  bool has_unique_id = false;
  std::uint32_t unique_id = 0;
  std::string name;

  int num_components = 0;
  int data_type = 0;  // draco::DataType numeric value
  bool normalized = false;

  std::vector<float> float_data;
  std::vector<std::uint32_t> uint_data;
  std::vector<std::uint16_t> uint16_data;
  std::vector<std::uint8_t> uint8_data;
};

MeshObject decode_buffer(const char *buffer, std::size_t buffer_len);

// Decode with options for memory control.
// - collect_attributes: when false, skips collecting the full attribute list
//   (including GENERIC). Standard fields (points/faces/normals/tex_coord/colors)
//   and I3S convenience fields may still be populated.
MeshObject decode_buffer_ex(const char *buffer, std::size_t buffer_len, bool collect_attributes);

EncodedObject encode_mesh(
    const std::vector<float> &points,
    const std::vector<std::uint32_t> &faces,
    int quantization_bits,
    int compression_level,
    float quantization_range,
    const float *quantization_origin,
    bool preserve_order,
    bool create_metadata,
    const std::vector<std::uint8_t> &colors,
    std::uint8_t colors_channel,
    const std::vector<float> &tex_coord,
    std::uint8_t tex_coord_channel,
    const std::vector<float> &normals,
    // I3S optional generics
    const std::vector<std::uint16_t> &uvr,
    int uvr_components,
    const std::vector<std::uint32_t> &feature_index,
    int feature_index_components,
    const std::vector<std::int32_t> &feature_ids,
    const std::vector<GenericAttributeInput> &generic_attributes,
    bool write_i3s_scale_xy,
    double i3s_scale_x,
    double i3s_scale_y);

EncodedObject encode_point_cloud(
    const std::vector<float> &points,
    int quantization_bits,
    int compression_level,
    float quantization_range,
    const float *quantization_origin,
    bool preserve_order,
    bool create_metadata,
    const std::vector<std::uint8_t> &colors,
    std::uint8_t colors_channel,
    const std::vector<GenericAttributeInput> &generic_attributes,
    bool write_i3s_scale_xy,
    double i3s_scale_x,
    double i3s_scale_y);

EncodedObject gzip_compress(const std::vector<std::uint8_t> &data, int level);
EncodedObject gzip_decompress(const std::vector<std::uint8_t> &data);

}  // namespace AldracoCore