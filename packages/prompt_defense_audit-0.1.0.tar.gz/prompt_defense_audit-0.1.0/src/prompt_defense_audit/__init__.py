"""prompt-defense-audit — output scanner for LLM responses.

Pure-regex scanner that detects dangerous payloads in AI-generated text
before it reaches downstream systems (HTML rendering, databases, shells,
APIs). Maps to OWASP LLM02 (Insecure Output Handling).

This is the Python port of the npm package of the same name, with byte-
for-byte parity on the output scanner rules.

Public API
----------
- ``scan_output(text)`` — main entry point, returns ``OutputScanResult``.
- ``OutputScanResult`` — dataclass with ``safe``, ``threats``,
  ``risk_level``, ``summary``.
- ``OutputThreat`` — dataclass per individual finding.
"""

from __future__ import annotations

from .output_scanner import (
    OutputScanResult,
    OutputThreat,
    RiskLevel,
    Severity,
    scan_output,
)

__all__ = [
    "OutputScanResult",
    "OutputThreat",
    "RiskLevel",
    "Severity",
    "scan_output",
]

__version__ = "0.1.0"
