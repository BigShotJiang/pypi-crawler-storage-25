"""Parity harness — Python side.

Loads the same ``fixtures.json`` used by the JS runner, runs each input
through ``scan_output``, prints normalized JSON. The output must match
the JS runner byte-for-byte.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from prompt_defense_audit import scan_output  # noqa: E402

fixtures_path = Path(__file__).resolve().parent / "fixtures.json"
fixtures = json.loads(fixtures_path.read_text(encoding="utf-8"))

out = []
for fx in fixtures:
    result = scan_output(fx["input"])
    out.append(
        {
            "name": fx["name"],
            "safe": result.safe,
            "riskLevel": result.risk_level,
            "summary": result.summary,
            "threats": [
                {
                    "id": t.id,
                    "name": t.name,
                    "severity": t.severity,
                    "match": t.match,
                    "position": t.position,
                    "context": t.context,
                }
                for t in result.threats
            ],
        }
    )

# Mirror Node's JSON.stringify(o, null, 2) formatting.
sys.stdout.write(json.dumps(out, indent=2, ensure_ascii=False))
