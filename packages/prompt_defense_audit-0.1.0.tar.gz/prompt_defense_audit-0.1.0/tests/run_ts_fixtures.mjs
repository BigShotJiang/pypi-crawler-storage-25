// Parity harness — TypeScript/JS side.
// Loads fixtures.json, runs each input through scanOutput from the npm
// package's local build, prints normalized JSON for byte-for-byte
// comparison against the Python port.
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fixturesPath = path.join(__dirname, "fixtures.json");

// Import compiled output-scanner.js from the local TypeScript build.
const scannerPath = path.resolve(
  __dirname,
  "../../prompt-defense-audit/dist/output-scanner.js"
);
const { scanOutput } = await import("file://" + scannerPath.replaceAll("\\", "/"));

const fixtures = JSON.parse(readFileSync(fixturesPath, "utf-8"));

const out = fixtures.map((fx) => {
  const result = scanOutput(fx.input);
  return {
    name: fx.name,
    safe: result.safe,
    riskLevel: result.riskLevel,
    summary: result.summary,
    threats: result.threats.map((t) => ({
      id: t.id,
      name: t.name,
      severity: t.severity,
      match: t.match,
      position: t.position,
      context: t.context,
    })),
  };
});

process.stdout.write(JSON.stringify(out, null, 2));
