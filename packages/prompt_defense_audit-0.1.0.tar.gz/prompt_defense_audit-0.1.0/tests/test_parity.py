"""Parity test: compare Python scanner output against the TypeScript
reference implementation across a wide fixtures suite.

Both runners produce JSON; after normalizing line endings, the output
must be byte-for-byte identical. This test compiles the fixture results
at runtime so the parity contract is enforced on every test run.

Skips automatically if the TypeScript build is not present locally —
the parity claim still holds, but verification requires the sibling
``prompt-defense-audit`` repo checked out next to this one with its
``dist/`` build available.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from prompt_defense_audit import scan_output

FIXTURES = json.loads(
    (Path(__file__).resolve().parent / "fixtures.json").read_text(encoding="utf-8")
)


def _ts_dist_available() -> bool:
    return (
        Path(__file__).resolve().parents[2] / "prompt-defense-audit" / "dist" / "output-scanner.js"
    ).exists()


@pytest.mark.skipif(
    not _ts_dist_available(),
    reason="TypeScript dist/output-scanner.js not found next to this repo",
)
def test_ts_python_parity() -> None:
    """Run the same fixtures through TS + Python, byte-compare."""
    runner = Path(__file__).resolve().parent / "run_ts_fixtures.mjs"
    ts_proc = subprocess.run(
        ["node", str(runner)],
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    assert ts_proc.returncode == 0, f"node runner failed: {ts_proc.stderr}"
    ts_out = json.loads(ts_proc.stdout)

    py_out = []
    for fx in FIXTURES:
        result = scan_output(fx["input"])
        py_out.append(
            {
                "name": fx["name"],
                "safe": result.safe,
                "riskLevel": result.risk_level,
                "summary": result.summary,
                "threats": [
                    {
                        "id": t.id,
                        "name": t.name,
                        "severity": t.severity,
                        "match": t.match,
                        "position": t.position,
                        "context": t.context,
                    }
                    for t in result.threats
                ],
            }
        )

    # Compare entry-by-entry for clearer failure output than blob diff.
    assert len(py_out) == len(ts_out)
    for i, (p, t) in enumerate(zip(py_out, ts_out)):
        assert p == t, f"parity fail at fixture {i} ({p.get('name')})"
