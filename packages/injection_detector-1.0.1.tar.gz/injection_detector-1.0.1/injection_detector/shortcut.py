"""
Convenience functions for one-shot scanning without creating a detector instance.
Uses environment variables for config.
"""

import os
from .detector import InjectionDetector
from .models   import ScanResult

_default_detector: InjectionDetector | None = None


def _get_default_detector() -> InjectionDetector:
    """Lazily create a shared detector using env vars."""
    global _default_detector
    if _default_detector is None:
        _default_detector = InjectionDetector(
            openai_api_key  = os.getenv("OPENAI_API_KEY"),
            warn_threshold  = float(os.getenv("PID_WARN_THRESHOLD",  "0.40")),
            block_threshold = float(os.getenv("PID_BLOCK_THRESHOLD", "0.70")),
        )
    return _default_detector


def scan(text: str) -> ScanResult:
    """
    One-shot synchronous scan using OPENAI_API_KEY from environment.

    Parameters
    ----------
    text : str
        The user prompt to scan.

    Returns
    -------
    ScanResult

    Example
    -------
        from injection_detector import scan

        result = scan(user_input)
        if result.blocked:
            return "Input rejected."
    """
    return _get_default_detector().scan(text)


async def scan_async(text: str) -> ScanResult:
    """
    One-shot async scan using OPENAI_API_KEY from environment.

    Example
    -------
        from injection_detector import scan_async

        result = await scan_async(user_input)
        if result.blocked:
            raise HTTPException(400, "Input rejected.")
    """
    return await _get_default_detector().scan_async(text)
