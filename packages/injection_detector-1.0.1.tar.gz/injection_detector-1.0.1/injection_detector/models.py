"""
Data models returned by the detector.
These are plain Python dataclasses — no external dependencies.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Verdict(str, Enum):
    PASS  = "PASS"   # safe — forward to LLM
    WARN  = "WARN"   # suspicious — sanitise before forwarding
    BLOCK = "BLOCK"  # dangerous — do not forward


@dataclass
class LayerResult:
    """Result from a single detection layer."""
    ran:     bool = False
    score:   float = 0.0
    flagged: bool  = False
    details: dict  = field(default_factory=dict)


@dataclass
class ScanResult:
    """
    Full result returned by InjectionDetector.scan().

    Attributes
    ----------
    verdict : Verdict
        PASS, WARN, or BLOCK.
    score : float
        Composite risk score 0.0 – 1.0.
    blocked : bool
        True if verdict is BLOCK. Shortcut for `result.verdict == Verdict.BLOCK`.
    warned : bool
        True if verdict is WARN.
    block_reason : str or None
        Human-readable reason for a BLOCK verdict.
    sanitized_input : str or None
        The cleaned version of the prompt (only set when verdict is WARN).
        Forward this to your LLM instead of the original prompt.
    layers : dict
        Raw per-layer results for debugging.
    """
    verdict:         Verdict
    score:           float
    blocked:         bool
    warned:          bool
    block_reason:    Optional[str]       = None
    sanitized_input: Optional[str]       = None
    layers:          dict                = field(default_factory=dict)
    error:           Optional[str]       = None

    def raise_if_blocked(self, message: str = "Prompt blocked by injection detector."):
        """
        Raise a ValueError if the prompt was blocked.
        Convenient for apps that want exception-based control flow.

            result = scan(prompt)
            result.raise_if_blocked()
            # safe to use prompt below
        """
        if self.blocked:
            raise ValueError(message)

    def safe_prompt(self, original: str) -> str:
        """
        Return the sanitised prompt if WARN, or the original if PASS.
        Always use this when forwarding to your LLM.

            result = scan(prompt)
            if not result.blocked:
                response = llm.chat(result.safe_prompt(prompt))
        """
        return self.sanitized_input if self.sanitized_input else original
