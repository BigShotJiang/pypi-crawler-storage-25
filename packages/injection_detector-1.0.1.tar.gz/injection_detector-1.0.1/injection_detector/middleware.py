"""
Ready-made middleware for FastAPI and Django.
AI engineers drop these in with zero manual scanning code.
"""

import json
from typing import Optional


# ── FastAPI middleware ─────────────────────────────────────────────────────────

class FastAPIInjectionMiddleware:
    """
    FastAPI middleware that auto-scans every request body field
    named 'message', 'prompt', 'input', or 'query'.

    Usage
    -----
        from fastapi import FastAPI
        from injection_detector.middleware import FastAPIInjectionMiddleware

        app = FastAPI()
        app.add_middleware(
            FastAPIInjectionMiddleware,
            openai_api_key="sk-...",   # or set OPENAI_API_KEY env var
            block_threshold=0.70,
        )

        # That's it — every endpoint is now protected automatically.
        # No changes needed to individual route handlers.

        @app.post("/chat")
        def chat(body: ChatRequest):
            # By the time this runs, the prompt is already scanned.
            # If it was blocked, middleware returned 400 before reaching here.
            return openai_call(body.message)
    """

    # Fields to scan in JSON request bodies
    SCAN_FIELDS = {"message", "prompt", "input", "query", "text", "content"}

    def __init__(
        self,
        app,
        openai_api_key:  Optional[str] = None,
        warn_threshold:  float = 0.40,
        block_threshold: float = 0.70,
        block_status_code: int = 400,
        scan_fields: Optional[set] = None,
    ):
        from starlette.middleware.base import BaseHTTPMiddleware
        from .detector import InjectionDetector

        self.app      = app
        self.detector = InjectionDetector(
            openai_api_key  = openai_api_key,
            warn_threshold  = warn_threshold,
            block_threshold = block_threshold,
        )
        self.block_status_code = block_status_code
        self.scan_fields       = scan_fields or self.SCAN_FIELDS

        # Wrap self in Starlette middleware
        self._middleware = BaseHTTPMiddleware(app, dispatch=self._dispatch)

    async def _dispatch(self, request, call_next):
        from starlette.responses import JSONResponse

        content_type = request.headers.get("content-type", "")
        if "application/json" in content_type:
            try:
                raw  = await request.body()
                body = json.loads(raw)

                for field in self.scan_fields:
                    value = body.get(field, "")
                    if isinstance(value, str) and value.strip():
                        result = await self.detector.scan_async(value)
                        if result.blocked:
                            return JSONResponse(
                                status_code=self.block_status_code,
                                content={
                                    "error":  "Input blocked by injection detector.",
                                    "reason": result.block_reason,
                                    "score":  result.score,
                                }
                            )
                        # If WARN — replace field value with sanitised version
                        if result.warned and result.sanitized_input:
                            body[field] = result.sanitized_input

                # Re-inject (possibly sanitised) body into request
                from starlette.datastructures import Headers
                import io
                cleaned_body = json.dumps(body).encode()
                request._body = cleaned_body

            except Exception:
                pass  # Never crash the app if detector fails

        return await call_next(request)

    def __call__(self, scope, receive, send):
        return self._middleware(scope, receive, send)


# ── Django middleware ──────────────────────────────────────────────────────────

class DjangoInjectionMiddleware:
    """
    Django middleware that auto-scans POST body fields.

    Usage
    -----
    In settings.py, add to MIDDLEWARE (before your views):

        MIDDLEWARE = [
            ...
            "injection_detector.middleware.DjangoInjectionMiddleware",
        ]

    Set these in settings.py:

        INJECTION_DETECTOR_API_KEY      = "sk-..."  # or use OPENAI_API_KEY env var
        INJECTION_DETECTOR_BLOCK_THRESH = 0.70
        INJECTION_DETECTOR_WARN_THRESH  = 0.40

    That's it. Every POST request is now scanned automatically.
    Blocked requests receive a 400 JSON response before reaching any view.
    """

    SCAN_FIELDS = {"message", "prompt", "input", "query", "text", "content"}

    def __init__(self, get_response):
        import django.conf as conf
        from .detector import InjectionDetector

        self.get_response = get_response
        settings = conf.settings

        self.detector = InjectionDetector(
            openai_api_key  = getattr(settings, "INJECTION_DETECTOR_API_KEY", None),
            warn_threshold  = getattr(settings, "INJECTION_DETECTOR_WARN_THRESH",  0.40),
            block_threshold = getattr(settings, "INJECTION_DETECTOR_BLOCK_THRESH", 0.70),
        )
        self.scan_fields = getattr(settings, "INJECTION_DETECTOR_SCAN_FIELDS", self.SCAN_FIELDS)

    def __call__(self, request):
        import json as _json
        from django.http import JsonResponse

        if request.method == "POST":
            # Try JSON body first, then form data
            try:
                body = _json.loads(request.body)
            except Exception:
                body = request.POST.dict()

            for field in self.scan_fields:
                value = body.get(field, "")
                if isinstance(value, str) and value.strip():
                    result = self.detector.scan(value)
                    if result.blocked:
                        return JsonResponse(
                            {
                                "error":  "Input blocked by injection detector.",
                                "reason": result.block_reason,
                                "score":  result.score,
                            },
                            status=400
                        )

        return self.get_response(request)
