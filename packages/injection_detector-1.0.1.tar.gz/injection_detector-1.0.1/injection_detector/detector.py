"""
InjectionDetector — the main class AI engineers use in their applications.
"""

import os
from typing import Optional
from openai import OpenAI
from dotenv import load_dotenv

from .models import ScanResult, Verdict
from .layers import (
    layer1_pattern_match,
    layer2_semantic,
    layer3_llm_judge,
    layer4_context_validator,
    scan_response,
    sanitize,
)

load_dotenv()


class InjectionDetector:
    """
    Server-side prompt injection detector.

    Parameters
    ----------
    openai_api_key : str, optional
        Your OpenAI API key. Falls back to OPENAI_API_KEY env variable.
    warn_threshold : float
        Risk score at which a prompt is flagged as WARN. Default 0.40.
    block_threshold : float
        Risk score at which a prompt is blocked. Default 0.70.
    layers : dict, optional
        Which layers to run. Default: all enabled.
        Example: {"l1": True, "l2": True, "l3": False, "l4": True}

    Examples
    --------
    Basic usage::

        from injection_detector import InjectionDetector

        detector = InjectionDetector(openai_api_key="sk-...")
        result = detector.scan(user_prompt)

        if result.blocked:
            return {"error": "Invalid input detected."}

        # Safe to forward to your LLM
        response = openai_client.chat(result.safe_prompt(user_prompt))

    With FastAPI::

        @app.post("/chat")
        def chat(request: ChatRequest):
            result = detector.scan(request.message)
            if result.blocked:
                raise HTTPException(status_code=400, detail="Input blocked.")
            # ... call your LLM

    With Django::

        def chat_view(request):
            result = detector.scan(request.POST["message"])
            result.raise_if_blocked("Your input was flagged as malicious.")
            # ... call your LLM
    """

    def __init__(
        self,
        openai_api_key: Optional[str] = None,
        warn_threshold:  float = 0.40,
        block_threshold: float = 0.70,
        layers: Optional[dict] = None,
    ):
        api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError(
                "OpenAI API key required. Pass openai_api_key= or set OPENAI_API_KEY env variable."
            )

        self._client         = OpenAI(api_key=api_key)
        self.warn_threshold  = warn_threshold
        self.block_threshold = block_threshold
        self.layers          = layers or {"l1": True, "l2": True, "l3": True, "l4": True}

    # ── Public API ─────────────────────────────────────────────────────────────

    def scan(self, text: str) -> ScanResult:
        """
        Scan a prompt synchronously.

        Parameters
        ----------
        text : str
            The user prompt to scan.

        Returns
        -------
        ScanResult
            Contains verdict, score, blocked flag, and per-layer details.
        """
        if not text or not text.strip():
            return ScanResult(
                verdict=Verdict.PASS, score=0.0, blocked=False, warned=False
            )

        try:
            return self._run_pipeline(text.strip())
        except Exception as e:
            # Never crash the calling app — return a safe fallback
            return ScanResult(
                verdict=Verdict.PASS,
                score=0.0,
                blocked=False,
                warned=False,
                error=f"Detector error (failing open): {e}"
            )

    async def scan_async(self, text: str) -> ScanResult:
        """
        Async version of scan() for use with async frameworks (FastAPI, etc.).
        Runs the pipeline in a thread pool so it doesn't block the event loop.
        """
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.scan, text)

    def scan_response(self, response_text: str) -> dict:
        """
        Scan an LLM response for data leakage or manipulation signs.

        Parameters
        ----------
        response_text : str
            The LLM's reply text.

        Returns
        -------
        dict with keys: clean (bool), issues (list), severity (str)
        """
        try:
            return scan_response(response_text, self._client)
        except Exception as e:
            return {"clean": True, "issues": [], "severity": "none", "error": str(e)}

    # ── Internal pipeline ──────────────────────────────────────────────────────

    def _run_pipeline(self, text: str) -> ScanResult:
        risk_score   = 0.0
        blocked      = False
        block_reason = ""
        layers_out   = {}

        # ── Layer 1: pattern matching (no API call, instant) ──────────────────
        if self.layers.get("l1", True):
            l1 = layer1_pattern_match(text)
            layers_out["l1"] = l1
            risk_score = max(risk_score, l1["score"])
            if l1["score"] >= self.block_threshold:
                blocked      = True
                block_reason = f"L1: {l1['total_hits']} pattern(s) matched — score {l1['score']}"

        if blocked:
            return self._make_result(text, Verdict.BLOCK, risk_score, block_reason, layers_out)

        # ── Layer 2: semantic classifier ──────────────────────────────────────
        if self.layers.get("l2", True):
            try:
                l2 = layer2_semantic(text, self._client)
                layers_out["l2"] = l2
                risk_score = max(risk_score, l2["score"])
                if l2["score"] >= self.block_threshold:
                    blocked      = True
                    block_reason = f"L2: {l2['category']} — score {l2['score']}"
            except Exception as e:
                layers_out["l2"] = {"error": str(e)}

        if blocked:
            return self._make_result(text, Verdict.BLOCK, risk_score, block_reason, layers_out)

        # ── Layer 3: LLM judge ────────────────────────────────────────────────
        if self.layers.get("l3", True):
            try:
                l3 = layer3_llm_judge(text, self._client)
                layers_out["l3"] = l3
                delta = (0.6 if l3["verdict"] == "adversarial"
                         else 0.3 if l3["verdict"] == "suspicious"
                         else 0)
                risk_score = min(1.0, risk_score + delta)
                if l3["verdict"] == "adversarial" and l3["confidence"] >= 0.7:
                    blocked      = True
                    block_reason = f"L3: {l3['attack_type']} — {l3['confidence']*100:.0f}% confidence"
            except Exception as e:
                layers_out["l3"] = {"error": str(e)}

        if blocked:
            return self._make_result(text, Verdict.BLOCK, risk_score, block_reason, layers_out)

        # ── Layer 4: context validator ────────────────────────────────────────
        if self.layers.get("l4", True):
            try:
                l4 = layer4_context_validator(text, self._client)
                layers_out["l4"] = l4
                risk_score = min(1.0, risk_score + l4["risk_delta"])
                flag_count = sum([
                    l4["role_drift"], l4["instruction_override"],
                    l4["data_extraction"], l4["filter_bypass"]
                ])
                if flag_count >= 2:
                    blocked      = True
                    block_reason = f"L4: {flag_count} structural flags detected"
            except Exception as e:
                layers_out["l4"] = {"error": str(e)}

        # ── Final verdict ─────────────────────────────────────────────────────
        risk_score = round(risk_score, 3)

        if blocked or risk_score >= self.block_threshold:
            return self._make_result(
                text, Verdict.BLOCK, risk_score,
                block_reason or f"Composite score {risk_score} exceeds threshold",
                layers_out
            )
        elif risk_score >= self.warn_threshold:
            return self._make_result(text, Verdict.WARN, risk_score, None, layers_out)
        else:
            return self._make_result(text, Verdict.PASS, risk_score, None, layers_out)

    def _make_result(
        self, text: str, verdict: Verdict,
        score: float, block_reason: Optional[str], layers: dict
    ) -> ScanResult:
        sanitized = sanitize(text) if verdict == Verdict.WARN else None
        return ScanResult(
            verdict=verdict,
            score=score,
            blocked=(verdict == Verdict.BLOCK),
            warned=(verdict == Verdict.WARN),
            block_reason=block_reason,
            sanitized_input=sanitized,
            layers=layers,
        )
