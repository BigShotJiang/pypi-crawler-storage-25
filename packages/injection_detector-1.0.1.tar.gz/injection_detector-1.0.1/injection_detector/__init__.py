"""
injection-detector
==================
Server-side prompt injection detection for AI applications.

Quick start
-----------
    from injection_detector import scan, InjectionDetector

    # One-shot scan (simplest)
    result = scan("user prompt here")
    if result.blocked:
        return "Invalid input."

    # Configured detector (reuse across requests)
    detector = InjectionDetector(
        openai_api_key="sk-...",
        block_threshold=0.70,
        warn_threshold=0.40,
    )
    result = detector.scan("user prompt here")
    print(result.verdict)   # "PASS", "WARN", or "BLOCK"
    print(result.score)     # 0.0 – 1.0
    print(result.blocked)   # True / False
"""

from .detector   import InjectionDetector
from .models     import ScanResult, Verdict
from .shortcut   import scan, scan_async

__version__ = "1.0.0"
__all__     = ["InjectionDetector", "ScanResult", "Verdict", "scan", "scan_async"]
