"""
Core helper for the Anthropic wrapper.

Anthropic's API differs from OpenAI:
- system prompt lives on a top-level `system` field, not a message role
- response.content is a list of blocks (text / tool_use / etc.)
- text extraction requires filter+map

AgentLoop semantics are identical.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Union

from agentloop import AgentLoop, Memory

if TYPE_CHECKING:
    from anthropic import Anthropic


SystemPrompt = Union[str, list[dict[str, Any]], None]


# ---------------------------------------------------------------------------
# Configuration dataclasses
# ---------------------------------------------------------------------------


@dataclass
class PerCallOptions:
    """Per-call overrides passed via the `agentloop` kwarg."""

    #: Tag the logged turn with this end-user id. Used for per-user
    #: filtering and analytics in the dashboard. Does NOT filter memory
    #: retrieval — by default, search returns the full org-wide memory
    #: corpus regardless of which user this call is for. To scope
    #: retrieval to memories tagged with a specific user, set
    #: `search_user_id` explicitly. (Prior to 0.2.2, `user_id` was
    #: silently forwarded to search as well, which suppressed retrieval
    #: of any org-wide correction.)
    user_id: str | None = None
    #: Optional: scope memory retrieval to memories tagged with this
    #: user_id. Leave None (default) to search the full org corpus.
    #: Only set this when you have a reason to want per-user retrieval.
    search_user_id: str | None = None
    session_id: str | None = None
    signals: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None
    #: Per-call tags. Folded into the logged turn's metadata under "tags",
    #: so reviewers can filter by tag in the dashboard. Distinct from
    #: WrapOptions.search_tags which filters memory retrieval.
    tags: list[str] | None = None
    skip: bool = False
    search: bool | dict[str, Any] = True


@dataclass
class WrapOptions:
    loop: AgentLoop
    inject_memories: (
        Callable[[list[Memory], SystemPrompt], SystemPrompt] | None
    ) = None
    detect_signals: (
        Callable[[str, str, list[Memory]], dict[str, Any] | None] | None
    ) = None
    search_limit: int = 3
    search_tags: list[str] = field(default_factory=list)
    only_log_when_signaled: bool = False


# ---------------------------------------------------------------------------
# Default memory injector
# ---------------------------------------------------------------------------


def default_inject_memories(
    memories: list[Memory], existing_system: SystemPrompt
) -> SystemPrompt:
    """Append a 'Trusted facts' block to the existing system prompt.

    Handles string form (simple concat) and array-of-text-blocks form
    (append to the last text block, or add a new one).
    """
    if not memories:
        return existing_system

    facts_block = "\n\nTrusted facts from past corrections:\n" + "\n".join(
        f"- {m.fact}" for m in memories
    )

    if existing_system is None:
        return "You are a helpful assistant." + facts_block

    if isinstance(existing_system, str):
        return existing_system + facts_block

    # Array form — append to last text block or add one
    updated = list(existing_system)
    for i in range(len(updated) - 1, -1, -1):
        block = updated[i]
        if isinstance(block, dict) and block.get("type") == "text":
            updated[i] = {**block, "text": block.get("text", "") + facts_block}
            return updated
    updated.append({"type": "text", "text": facts_block})
    return updated


# ---------------------------------------------------------------------------
# Extract question / answer
# ---------------------------------------------------------------------------


def extract_question(messages: list[dict[str, Any]]) -> str:
    """Last user message, text content only."""
    for msg in reversed(messages):
        if msg.get("role") != "user":
            continue
        content = msg.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = [
                p["text"]
                for p in content
                if isinstance(p, dict) and p.get("type") == "text"
            ]
            return "\n".join(parts)
    return ""


def extract_answer(message: Any) -> str:
    """Concatenate text blocks from an Anthropic Message response."""
    try:
        content = getattr(message, "content", None)
        if content is None:
            return ""
        parts: list[str] = []
        for block in content:
            block_type = (
                getattr(block, "type", None)
                if hasattr(block, "type")
                else block.get("type") if isinstance(block, dict) else None
            )
            if block_type == "text":
                text = (
                    getattr(block, "text", "")
                    if hasattr(block, "text")
                    else block.get("text", "") if isinstance(block, dict) else ""
                )
                if text:
                    parts.append(text)
        return "".join(parts)
    except (AttributeError, KeyError, TypeError):
        return ""


# ---------------------------------------------------------------------------
# Main entry point (non-streaming)
# ---------------------------------------------------------------------------


def _detect_and_log(
    *,
    question: str,
    answer: str,
    memories: list[Memory],
    config: WrapOptions,
    per_call: PerCallOptions,
    partial: bool = False,
) -> None:
    """Run detect_signals + log_turn — shared by streaming and non-streaming."""
    if not question or not answer:
        return

    auto_signals = (
        config.detect_signals(question, answer, memories)
        if config.detect_signals
        else None
    ) or {}
    merged_signals: dict[str, Any] = {**auto_signals, **(per_call.signals or {})}

    should_log = not config.only_log_when_signaled or len(merged_signals) > 0
    if not should_log:
        return

    metadata = dict(per_call.metadata or {})
    if partial:
        metadata["partial"] = True
    if per_call.tags:
        existing = metadata.get("tags")
        if isinstance(existing, list):
            seen = set(existing)
            merged = list(existing) + [t for t in per_call.tags if t not in seen]
            metadata["tags"] = merged
        else:
            metadata["tags"] = list(per_call.tags)

    try:
        config.loop.log_turn(
            question=question,
            agent_response=answer,
            user_id=per_call.user_id,
            session_id=per_call.session_id,
            signals=merged_signals or None,
            metadata=metadata or None,
        )
    except Exception as e:  # noqa: BLE001
        import logging
        logging.getLogger("agentloop.anthropic").warning(
            "agentloop log_turn failed: %s", e
        )


async def _detect_and_log_async(
    *,
    question: str,
    answer: str,
    memories: list[Memory],
    config: WrapOptions,
    per_call: PerCallOptions,
    partial: bool = False,
) -> None:
    """Async equivalent — detects sync vs async loop and routes."""
    if not question or not answer:
        return

    auto_signals = (
        config.detect_signals(question, answer, memories)
        if config.detect_signals
        else None
    ) or {}
    merged_signals: dict[str, Any] = {**auto_signals, **(per_call.signals or {})}

    should_log = not config.only_log_when_signaled or len(merged_signals) > 0
    if not should_log:
        return

    metadata = dict(per_call.metadata or {})
    if partial:
        metadata["partial"] = True
    if per_call.tags:
        existing = metadata.get("tags")
        if isinstance(existing, list):
            seen = set(existing)
            merged = list(existing) + [t for t in per_call.tags if t not in seen]
            metadata["tags"] = merged
        else:
            metadata["tags"] = list(per_call.tags)

    import inspect
    log_turn = config.loop.log_turn
    is_async = inspect.iscoroutinefunction(log_turn)

    try:
        if is_async:
            await log_turn(
                question=question,
                agent_response=answer,
                user_id=per_call.user_id,
                session_id=per_call.session_id,
                signals=merged_signals or None,
                metadata=metadata or None,
            )
        else:
            import asyncio
            await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: log_turn(
                    question=question,
                    agent_response=answer,
                    user_id=per_call.user_id,
                    session_id=per_call.session_id,
                    signals=merged_signals or None,
                    metadata=metadata or None,
                ),
            )
    except Exception as e:  # noqa: BLE001
        import logging
        logging.getLogger("agentloop.anthropic").warning(
            "agentloop log_turn failed (async): %s", e
        )


def ask_with_agentloop(
    client: Anthropic,
    *,
    messages: list[dict[str, Any]],
    per_call: PerCallOptions | None = None,
    config: WrapOptions,
    **create_kwargs: Any,
) -> Any:
    """Run one Anthropic messages.create call through the AgentLoop cycle.

    When `stream=True` is passed, returns a streaming wrapper. Same
    semantics as the non-streaming path: search → inject → call → log.
    Logging happens at end-of-stream.
    """
    per_call = per_call or PerCallOptions()

    if per_call.skip:
        return client.messages.create(messages=messages, **create_kwargs)

    streaming = bool(create_kwargs.get("stream"))

    question = extract_question(messages)

    # ---- 1. Retrieve memories ----
    memories: list[Memory] = []
    if per_call.search is not False and question:
        search_config = per_call.search if isinstance(per_call.search, dict) else {}
        memories = config.loop.search(
            question,
            limit=search_config.get("limit", config.search_limit),
            user_id=per_call.search_user_id,
            tags=search_config.get("tags") or (config.search_tags or None),
        )

    # ---- 2. Inject memories into system prompt ----
    injector = config.inject_memories or default_inject_memories
    existing_system = create_kwargs.pop("system", None)
    new_system = injector(memories, existing_system)

    kwargs: dict[str, Any] = dict(create_kwargs)
    if new_system is not None:
        kwargs["system"] = new_system

    # ---- 3. Call Anthropic ----
    if streaming:
        from ._streaming import AgentLoopStream
        stream = client.messages.create(messages=messages, **kwargs)
        return AgentLoopStream(
            stream,
            question=question,
            memories=memories,
            config=config,
            per_call=per_call,
        )

    message = client.messages.create(messages=messages, **kwargs)
    answer = extract_answer(message)

    # ---- 4. Detect signals + log_turn ----
    _detect_and_log(
        question=question,
        answer=answer,
        memories=memories,
        config=config,
        per_call=per_call,
    )

    return message


async def ask_with_agentloop_async(
    client: Any,
    *,
    messages: list[dict[str, Any]],
    per_call: PerCallOptions | None = None,
    config: WrapOptions,
    **create_kwargs: Any,
) -> Any:
    """Async equivalent of ask_with_agentloop. `client` is an AsyncAnthropic."""
    per_call = per_call or PerCallOptions()

    if per_call.skip:
        return await client.messages.create(messages=messages, **create_kwargs)

    streaming = bool(create_kwargs.get("stream"))

    question = extract_question(messages)

    # ---- 1. Retrieve memories ----
    import inspect
    memories: list[Memory] = []
    if per_call.search is not False and question:
        search_config = per_call.search if isinstance(per_call.search, dict) else {}
        search_fn = config.loop.search
        search_kwargs = dict(
            limit=search_config.get("limit", config.search_limit),
            user_id=per_call.search_user_id,
            tags=search_config.get("tags") or (config.search_tags or None),
        )
        if inspect.iscoroutinefunction(search_fn):
            memories = await search_fn(question, **search_kwargs)
        else:
            import asyncio
            memories = await asyncio.get_event_loop().run_in_executor(
                None, lambda: search_fn(question, **search_kwargs)
            )

    # ---- 2. Inject memories into system prompt ----
    injector = config.inject_memories or default_inject_memories
    existing_system = create_kwargs.pop("system", None)
    new_system = injector(memories, existing_system)

    kwargs: dict[str, Any] = dict(create_kwargs)
    if new_system is not None:
        kwargs["system"] = new_system

    # ---- 3. Call Anthropic ----
    if streaming:
        from ._streaming import AgentLoopAsyncStream
        stream = await client.messages.create(messages=messages, **kwargs)
        return AgentLoopAsyncStream(
            stream,
            question=question,
            memories=memories,
            config=config,
            per_call=per_call,
        )

    message = await client.messages.create(messages=messages, **kwargs)
    answer = extract_answer(message)

    # ---- 4. Detect signals + log_turn ----
    await _detect_and_log_async(
        question=question,
        answer=answer,
        memories=memories,
        config=config,
        per_call=per_call,
    )

    return message
