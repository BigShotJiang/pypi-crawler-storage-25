"""WebPrinter MCP server package."""
