"""TDD (Test-Driven Development) enforcement for SAGE.

This module enforces TDD practices automatically during code execution:
- Runs tests after every code write
- Requires 100% coverage on modified files
- Blocks code changes that break tests or miss coverage

This is NOT a command - it's integrated into the execution cycle.
"""

from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class TDDResult:
    """Result of TDD validation."""

    passed: bool
    tests_run: int = 0
    tests_passed: int = 0
    tests_failed: int = 0
    coverage_percent: float = 0.0
    coverage_required: float = 100.0
    missing_test_file: bool = False
    error: str | None = None
    output: str = ""
    files_tested: list[str] = field(default_factory=list)

    @property
    def coverage_met(self) -> bool:
        """Check if coverage requirement is met."""
        return self.coverage_percent >= self.coverage_required

    @property
    def all_tests_pass(self) -> bool:
        """Check if all tests pass."""
        return self.tests_failed == 0 and self.tests_run > 0

    def summary(self) -> str:
        """Generate a summary string."""
        if self.missing_test_file:
            return "TDD BLOCKED: No test file found for modified code"
        if self.error:
            return f"TDD ERROR: {self.error}"
        if not self.all_tests_pass:
            return f"TDD FAILED: {self.tests_failed}/{self.tests_run} tests failed"
        if not self.coverage_met:
            return (
                f"TDD BLOCKED: Coverage {self.coverage_percent:.1f}% "
                f"< required {self.coverage_required:.1f}%"
            )
        return f"TDD PASSED: {self.tests_passed} tests, {self.coverage_percent:.1f}% coverage"


class TDDEnforcer:
    """Enforces TDD practices on code writes.

    Automatically validates that:
    1. Test files exist for modified code
    2. All tests pass after modification
    3. Code coverage meets threshold (default 100%)
    """

    # File extensions that require TDD enforcement
    CODE_EXTENSIONS = {".py"}

    # Directories to skip TDD enforcement
    SKIP_DIRS = {"tests", "test", "__pycache__", ".git", "node_modules", "venv", ".venv"}

    # Test file patterns
    TEST_PATTERNS = [
        "test_{name}.py",  # test_module.py
        "{name}_test.py",  # module_test.py
        "tests/test_{name}.py",  # tests/test_module.py
        "tests/{name}_test.py",  # tests/module_test.py
    ]

    def __init__(
        self,
        project_root: Path | None = None,
        coverage_threshold: float = 100.0,
        enabled: bool = True,
        strict: bool = True,
    ):
        """Initialize TDD enforcer.

        Args:
            project_root: Project root directory (auto-detected if None)
            coverage_threshold: Required coverage percentage (default 100%)
            enabled: Whether TDD enforcement is enabled
            strict: If True, block writes that fail TDD
        """
        self.project_root = project_root or self._find_project_root()
        self.coverage_threshold = coverage_threshold
        self.enabled = enabled
        self.strict = strict

    def _find_project_root(self) -> Path:
        """Find project root by looking for pyproject.toml or .git."""
        cwd = Path.cwd()
        for parent in [cwd, *cwd.parents]:
            if (parent / "pyproject.toml").exists() or (parent / ".git").exists():
                return parent
        return cwd

    def should_enforce(self, filepath: Path) -> bool:
        """Check if TDD should be enforced for this file.

        Args:
            filepath: Path to the file being written

        Returns:
            True if TDD enforcement applies
        """
        if not self.enabled:
            return False

        # Only enforce for code files
        if filepath.suffix not in self.CODE_EXTENSIONS:
            return False

        # Skip test files themselves
        if filepath.name.startswith("test_") or filepath.name.endswith("_test.py"):
            return False

        # Skip files in excluded directories
        parts = filepath.parts
        for skip_dir in self.SKIP_DIRS:
            if skip_dir in parts:
                return False

        # Skip __init__.py files (usually empty or imports only)
        if filepath.name == "__init__.py":
            return False

        # Skip conftest.py files
        if filepath.name == "conftest.py":
            return False

        return True

    def find_test_file(self, source_file: Path) -> Path | None:
        """Find the corresponding test file for a source file.

        Args:
            source_file: Path to the source file

        Returns:
            Path to test file if found, None otherwise
        """
        name = source_file.stem
        parent = source_file.parent

        # Try patterns relative to source file
        for pattern in self.TEST_PATTERNS:
            test_name = pattern.format(name=name)
            test_path = parent / test_name
            if test_path.exists():
                return test_path

        # Try patterns relative to project root
        if self.project_root:
            for pattern in self.TEST_PATTERNS:
                test_name = pattern.format(name=name)
                test_path = self.project_root / test_name
                if test_path.exists():
                    return test_path

            # Try sage/tests/ directory
            test_path = self.project_root / "sage" / "tests" / f"test_{name}.py"
            if test_path.exists():
                return test_path

            # Try tests/sage/ directory
            test_path = self.project_root / "tests" / "sage" / f"test_{name}.py"
            if test_path.exists():
                return test_path

            # Try tests/ directory
            test_path = self.project_root / "tests" / f"test_{name}.py"
            if test_path.exists():
                return test_path

        return None

    def run_tests(self, source_file: Path, test_file: Path) -> TDDResult:
        """Run tests for a source file with coverage.

        Args:
            source_file: Path to the source file
            test_file: Path to the test file

        Returns:
            TDDResult with test and coverage information
        """
        # Get the module path for coverage
        try:
            relative_source = source_file.relative_to(self.project_root)
            cov_source = str(relative_source.parent)
        except ValueError:
            cov_source = str(source_file.parent)

        # Build pytest command with coverage
        cmd = [
            sys.executable,
            "-m",
            "pytest",
            str(test_file),
            f"--cov={cov_source}",
            "--cov-report=term-missing",
            "--cov-report=",  # Suppress HTML
            "-v",
            "--tb=short",
            "-x",  # Stop on first failure
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=self.project_root,
                timeout=120,  # 2 minute timeout
            )

            # Parse results
            output = result.stdout + result.stderr
            tests_run, tests_passed, tests_failed = self._parse_test_results(output)
            coverage = self._parse_coverage(output, source_file.name)

            return TDDResult(
                passed=result.returncode == 0 and coverage >= self.coverage_threshold,
                tests_run=tests_run,
                tests_passed=tests_passed,
                tests_failed=tests_failed,
                coverage_percent=coverage,
                coverage_required=self.coverage_threshold,
                output=output,
                files_tested=[str(source_file)],
            )

        except subprocess.TimeoutExpired:
            return TDDResult(
                passed=False,
                error="Tests timed out (120s limit)",
                files_tested=[str(source_file)],
            )
        except Exception as e:
            return TDDResult(
                passed=False,
                error=str(e),
                files_tested=[str(source_file)],
            )

    def _parse_test_results(self, output: str) -> tuple[int, int, int]:
        """Parse test counts from pytest output."""
        import re

        # Look for "X passed, Y failed" pattern
        passed = 0
        failed = 0

        # Match "N passed"
        passed_match = re.search(r"(\d+) passed", output)
        if passed_match:
            passed = int(passed_match.group(1))

        # Match "N failed"
        failed_match = re.search(r"(\d+) failed", output)
        if failed_match:
            failed = int(failed_match.group(1))

        # Match "N error"
        error_match = re.search(r"(\d+) error", output)
        if error_match:
            failed += int(error_match.group(1))

        total = passed + failed
        return total, passed, failed

    def _parse_coverage(self, output: str, filename: str) -> float:
        """Parse coverage percentage from pytest-cov output."""
        for line in output.split("\n"):
            if filename in line:
                # Look for percentage in the line
                import re

                match = re.search(r"(\d+(?:\.\d+)?)\s*%", line)
                if match:
                    return float(match.group(1))
        return 0.0

    def validate_write(self, filepath: Path, content: str) -> TDDResult:
        """Validate a file write against TDD requirements.

        This is the main entry point called after writing a file.

        Args:
            filepath: Path to the file that was written
            content: Content that was written

        Returns:
            TDDResult indicating whether the write passes TDD requirements
        """
        # Check if TDD applies
        if not self.should_enforce(filepath):
            return TDDResult(
                passed=True,
                output="TDD enforcement not required for this file",
            )

        # Find test file
        test_file = self.find_test_file(filepath)
        if test_file is None:
            result = TDDResult(
                passed=not self.strict,
                missing_test_file=True,
                error=f"No test file found for {filepath.name}. Expected: test_{filepath.stem}.py",
            )
            return result

        # Run tests with coverage
        return self.run_tests(filepath, test_file)


# Global TDD enforcer instance
_tdd_enforcer: TDDEnforcer | None = None


def get_tdd_enforcer() -> TDDEnforcer:
    """Get or create the global TDD enforcer."""
    global _tdd_enforcer
    if _tdd_enforcer is None:
        _tdd_enforcer = TDDEnforcer()
    return _tdd_enforcer


def validate_code_write(filepath: str | Path, content: str) -> TDDResult:
    """Validate a code write against TDD requirements.

    This function is called automatically after writing code files.

    Args:
        filepath: Path to the file that was written
        content: Content that was written

    Returns:
        TDDResult with validation status
    """
    enforcer = get_tdd_enforcer()
    return enforcer.validate_write(Path(filepath), content)


def configure_tdd(
    enabled: bool = True,
    coverage_threshold: float = 100.0,
    strict: bool = True,
    project_root: Path | None = None,
) -> None:
    """Configure TDD enforcement settings.

    Args:
        enabled: Whether TDD enforcement is enabled
        coverage_threshold: Required coverage percentage
        strict: If True, block writes that fail TDD
        project_root: Project root directory
    """
    global _tdd_enforcer
    _tdd_enforcer = TDDEnforcer(
        project_root=project_root,
        coverage_threshold=coverage_threshold,
        enabled=enabled,
        strict=strict,
    )
