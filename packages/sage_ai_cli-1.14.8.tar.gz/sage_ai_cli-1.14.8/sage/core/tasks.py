"""
Task state machine and progress tracking for SAGE.

P1-24: Create explicit task state machine
P1-25: Implement inter-task communication
P1-26: Add progress tracking/reporting
P1-27: Implement task retry with exponential backoff
"""

from __future__ import annotations

import asyncio
import random
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any

from rich.console import Console
from rich.live import Live
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskID, TextColumn, TimeElapsedColumn
from rich.table import Table

# =============================================================================
# Task State Machine (P1-24)
# =============================================================================


class TaskState(Enum):
    """States in the task state machine."""

    PENDING = auto()  # Task created, not yet started
    QUEUED = auto()  # Task queued for execution
    RUNNING = auto()  # Task currently executing
    PAUSED = auto()  # Task paused (can be resumed)
    WAITING = auto()  # Task waiting for dependencies
    COMPLETED = auto()  # Task finished successfully
    FAILED = auto()  # Task failed with error
    CANCELLED = auto()  # Task was cancelled
    RETRYING = auto()  # Task is being retried


class TaskPriority(Enum):
    """Task priority levels."""

    CRITICAL = 0
    HIGH = 1
    MEDIUM = 2
    LOW = 3
    BACKGROUND = 4


class TaskTransition(Enum):
    """Valid state transitions."""

    START = auto()  # PENDING/QUEUED -> RUNNING
    COMPLETE = auto()  # RUNNING -> COMPLETED
    FAIL = auto()  # RUNNING -> FAILED
    CANCEL = auto()  # Any -> CANCELLED
    PAUSE = auto()  # RUNNING -> PAUSED
    RESUME = auto()  # PAUSED -> RUNNING
    RETRY = auto()  # FAILED -> RETRYING -> RUNNING
    WAIT = auto()  # RUNNING -> WAITING
    QUEUE = auto()  # PENDING -> QUEUED


# Valid transitions for state machine
VALID_TRANSITIONS: dict[TaskState, set[TaskState]] = {
    TaskState.PENDING: {TaskState.QUEUED, TaskState.CANCELLED},
    TaskState.QUEUED: {TaskState.RUNNING, TaskState.CANCELLED},
    TaskState.RUNNING: {
        TaskState.COMPLETED,
        TaskState.FAILED,
        TaskState.PAUSED,
        TaskState.WAITING,
        TaskState.CANCELLED,
    },
    TaskState.PAUSED: {TaskState.RUNNING, TaskState.CANCELLED},
    TaskState.WAITING: {TaskState.RUNNING, TaskState.FAILED, TaskState.CANCELLED},
    TaskState.COMPLETED: set(),  # Terminal state
    TaskState.FAILED: {TaskState.RETRYING, TaskState.CANCELLED},
    TaskState.CANCELLED: set(),  # Terminal state
    TaskState.RETRYING: {TaskState.RUNNING, TaskState.FAILED, TaskState.CANCELLED},
}


@dataclass
class TaskResult:
    """Result of a task execution."""

    success: bool
    output: Any = None
    error: str | None = None
    duration: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Task:
    """
    A task with full state machine support.

    P1-24: Explicit state machine with valid transitions
    """

    id: str
    name: str
    description: str = ""
    priority: TaskPriority = TaskPriority.MEDIUM
    state: TaskState = TaskState.PENDING

    # Execution
    handler: Callable[..., Any] | None = None
    args: tuple = ()
    kwargs: dict = field(default_factory=dict)

    # Dependencies (P1-25)
    dependencies: list[str] = field(default_factory=list)
    dependents: list[str] = field(default_factory=list)

    # Retry configuration (P1-27)
    max_retries: int = 3
    retry_count: int = 0
    retry_delay: float = 1.0  # Base delay in seconds
    retry_backoff: float = 2.0  # Exponential backoff multiplier

    # Timing
    created_at: float = field(default_factory=time.time)
    started_at: float | None = None
    completed_at: float | None = None

    # Results
    result: TaskResult | None = None
    error_history: list[str] = field(default_factory=list)

    # Progress (P1-26)
    progress: float = 0.0  # 0.0 to 1.0
    progress_message: str = ""

    # Inter-task communication (P1-25)
    shared_data: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid.uuid4())[:8]

    def can_transition_to(self, new_state: TaskState) -> bool:
        """Check if transition to new state is valid."""
        return new_state in VALID_TRANSITIONS.get(self.state, set())

    def transition_to(self, new_state: TaskState) -> bool:
        """Transition to new state if valid."""
        if not self.can_transition_to(new_state):
            return False

        old_state = self.state
        self.state = new_state

        # Update timing
        if new_state == TaskState.RUNNING and self.started_at is None:
            self.started_at = time.time()
        elif new_state in (TaskState.COMPLETED, TaskState.FAILED, TaskState.CANCELLED):
            self.completed_at = time.time()

        return True

    @property
    def duration(self) -> float | None:
        """Get task duration in seconds."""
        if self.started_at is None:
            return None
        end_time = self.completed_at or time.time()
        return end_time - self.started_at

    @property
    def is_terminal(self) -> bool:
        """Check if task is in terminal state."""
        return self.state in (TaskState.COMPLETED, TaskState.FAILED, TaskState.CANCELLED)

    @property
    def is_runnable(self) -> bool:
        """Check if task can be run."""
        return self.state in (TaskState.PENDING, TaskState.QUEUED)

    def get_retry_delay(self) -> float:
        """Calculate retry delay with exponential backoff and jitter."""
        base_delay = self.retry_delay * (self.retry_backoff**self.retry_count)
        # Add jitter (±20%)
        jitter = base_delay * 0.2 * (random.random() * 2 - 1)
        return max(0.1, base_delay + jitter)

    def should_retry(self) -> bool:
        """Check if task should be retried."""
        return self.state == TaskState.FAILED and self.retry_count < self.max_retries


# =============================================================================
# Task Manager (P1-24, P1-25, P1-26)
# =============================================================================


class TaskManager:
    """
    Manages task lifecycle, dependencies, and execution.

    P1-24: State machine management
    P1-25: Inter-task communication
    P1-26: Progress tracking
    """

    def __init__(self):
        self.tasks: dict[str, Task] = {}
        self.task_order: list[str] = []
        self._listeners: list[Callable[[Task, TaskState, TaskState], None]] = []
        self._shared_context: dict[str, Any] = {}

    # ── Task Creation and Management ──────────────────────────

    def create_task(
        self,
        name: str,
        handler: Callable | None = None,
        description: str = "",
        priority: TaskPriority = TaskPriority.MEDIUM,
        dependencies: list[str] | None = None,
        **kwargs,
    ) -> Task:
        """Create and register a new task."""
        task = Task(
            id=str(uuid.uuid4())[:8],
            name=name,
            description=description,
            priority=priority,
            handler=handler,
            dependencies=dependencies or [],
            kwargs=kwargs,
        )
        self.tasks[task.id] = task
        self.task_order.append(task.id)

        # Update dependents for dependency tasks
        for dep_id in task.dependencies:
            if dep_id in self.tasks:
                self.tasks[dep_id].dependents.append(task.id)

        return task

    def get_task(self, task_id: str) -> Task | None:
        """Get task by ID."""
        return self.tasks.get(task_id)

    def get_tasks_by_state(self, state: TaskState) -> list[Task]:
        """Get all tasks in a specific state."""
        return [t for t in self.tasks.values() if t.state == state]

    def get_runnable_tasks(self) -> list[Task]:
        """Get tasks that are ready to run (dependencies satisfied)."""
        runnable = []
        for task in self.tasks.values():
            if task.is_runnable and self._dependencies_satisfied(task):
                runnable.append(task)

        # Sort by priority
        runnable.sort(key=lambda t: t.priority.value)
        return runnable

    def _dependencies_satisfied(self, task: Task) -> bool:
        """Check if all task dependencies are completed."""
        for dep_id in task.dependencies:
            dep = self.tasks.get(dep_id)
            if dep is None or dep.state != TaskState.COMPLETED:
                return False
        return True

    # ── State Transitions ─────────────────────────────────────

    def transition_task(self, task_id: str, new_state: TaskState) -> bool:
        """Transition task to new state."""
        task = self.tasks.get(task_id)
        if task is None:
            return False

        old_state = task.state
        if task.transition_to(new_state):
            self._notify_listeners(task, old_state, new_state)
            return True
        return False

    def start_task(self, task_id: str) -> bool:
        """Start a task (PENDING/QUEUED -> RUNNING)."""
        task = self.tasks.get(task_id)
        if task is None:
            return False

        if task.state == TaskState.PENDING:
            task.transition_to(TaskState.QUEUED)

        return self.transition_task(task_id, TaskState.RUNNING)

    def complete_task(self, task_id: str, result: Any = None) -> bool:
        """Mark task as completed."""
        task = self.tasks.get(task_id)
        if task is None:
            return False

        task.result = TaskResult(
            success=True,
            output=result,
            duration=task.duration or 0,
        )
        return self.transition_task(task_id, TaskState.COMPLETED)

    def fail_task(self, task_id: str, error: str) -> bool:
        """Mark task as failed."""
        task = self.tasks.get(task_id)
        if task is None:
            return False

        task.error_history.append(error)
        task.result = TaskResult(
            success=False,
            error=error,
            duration=task.duration or 0,
        )
        return self.transition_task(task_id, TaskState.FAILED)

    def retry_task(self, task_id: str) -> bool:
        """Retry a failed task."""
        task = self.tasks.get(task_id)
        if task is None or not task.should_retry():
            return False

        task.retry_count += 1
        task.transition_to(TaskState.RETRYING)
        task.started_at = None  # Reset timing
        task.completed_at = None
        return self.transition_task(task_id, TaskState.RUNNING)

    # ── Inter-task Communication (P1-25) ──────────────────────

    def share_data(self, key: str, value: Any) -> None:
        """Share data between tasks."""
        self._shared_context[key] = value

    def get_shared_data(self, key: str, default: Any = None) -> Any:
        """Get shared data."""
        return self._shared_context.get(key, default)

    def pass_result_to_dependents(self, task_id: str) -> None:
        """Pass task result to dependent tasks."""
        task = self.tasks.get(task_id)
        if task is None or task.result is None:
            return

        for dep_id in task.dependents:
            dep_task = self.tasks.get(dep_id)
            if dep_task:
                dep_task.shared_data[f"result_from_{task_id}"] = task.result.output

    # ── Progress Tracking (P1-26) ─────────────────────────────

    def update_progress(self, task_id: str, progress: float, message: str = "") -> None:
        """Update task progress."""
        task = self.tasks.get(task_id)
        if task:
            task.progress = max(0.0, min(1.0, progress))
            task.progress_message = message

    def get_overall_progress(self) -> float:
        """Get overall progress across all tasks."""
        if not self.tasks:
            return 0.0

        total_progress = sum(
            t.progress
            if t.state == TaskState.RUNNING
            else (1.0 if t.state == TaskState.COMPLETED else 0.0)
            for t in self.tasks.values()
        )
        return total_progress / len(self.tasks)

    # ── Event Listeners ───────────────────────────────────────

    def add_listener(self, callback: Callable[[Task, TaskState, TaskState], None]) -> None:
        """Add state change listener."""
        self._listeners.append(callback)

    def _notify_listeners(self, task: Task, old_state: TaskState, new_state: TaskState) -> None:
        """Notify all listeners of state change."""
        for listener in self._listeners:
            try:
                listener(task, old_state, new_state)
            except Exception:
                pass  # Don't let listener errors affect task management

    # ── Execution ─────────────────────────────────────────────

    async def execute_task(self, task_id: str) -> TaskResult:
        """Execute a single task."""
        task = self.tasks.get(task_id)
        if task is None:
            return TaskResult(success=False, error="Task not found")

        if not self.start_task(task_id):
            return TaskResult(success=False, error="Cannot start task")

        try:
            if task.handler:
                # Pass shared data to handler
                result = await self._run_handler(task)
                self.complete_task(task_id, result)
                self.pass_result_to_dependents(task_id)
                return task.result
            else:
                self.complete_task(task_id)
                return task.result

        except Exception as e:
            error_msg = str(e)
            self.fail_task(task_id, error_msg)

            # Auto-retry if applicable
            if task.should_retry():
                delay = task.get_retry_delay()
                await asyncio.sleep(delay)
                return await self.execute_task(task_id)

            return task.result

    async def _run_handler(self, task: Task) -> Any:
        """Run task handler with proper async support."""
        # Inject shared context into kwargs
        kwargs = {**task.kwargs, "_shared": self._shared_context}

        if asyncio.iscoroutinefunction(task.handler):
            return await task.handler(*task.args, **kwargs)
        else:
            return task.handler(*task.args, **kwargs)

    async def execute_all(self, parallel: bool = False) -> dict[str, TaskResult]:
        """Execute all tasks respecting dependencies."""
        results: dict[str, TaskResult] = {}

        if parallel:
            # Execute tasks in parallel where possible
            while True:
                runnable = self.get_runnable_tasks()
                if not runnable:
                    break

                tasks_to_run = [self.execute_task(t.id) for t in runnable]
                await asyncio.gather(*tasks_to_run)

                for task in runnable:
                    if task.result:
                        results[task.id] = task.result
        else:
            # Execute tasks sequentially
            for task_id in self.task_order:
                task = self.tasks[task_id]
                if not task.is_terminal:
                    result = await self.execute_task(task_id)
                    results[task_id] = result

        return results


# =============================================================================
# Progress Display (P1-26)
# =============================================================================


class TaskProgressDisplay:
    """
    Rich progress display for task execution.

    Shows real-time progress, timing, and status.
    """

    def __init__(self, console: Console | None = None):
        self.console = console or Console()
        self._progress: Progress | None = None
        self._task_ids: dict[str, TaskID] = {}

    def create_progress(self) -> Progress:
        """Create a progress display."""
        return Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.fields[name]}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("•"),
            TextColumn("{task.fields[status]}"),
            TimeElapsedColumn(),
            console=self.console,
        )

    def start(self, tasks: list[Task]) -> Live:
        """Start progress display with tasks."""
        self._progress = self.create_progress()

        for task in tasks:
            task_id = self._progress.add_task(
                task.name,
                total=100,
                name=task.name,
                status=task.state.name,
            )
            self._task_ids[task.id] = task_id

        return Live(self._progress, console=self.console, refresh_per_second=4)

    def update(self, task: Task) -> None:
        """Update progress display for a task."""
        if self._progress is None:
            return

        rich_task_id = self._task_ids.get(task.id)
        if rich_task_id is not None:
            status = task.progress_message or task.state.name
            self._progress.update(
                rich_task_id,
                completed=task.progress * 100,
                status=status,
            )

    def render_summary(self, manager: TaskManager) -> None:
        """Render task execution summary."""
        table = Table(title="Task Summary")
        table.add_column("Task", style="cyan")
        table.add_column("Status")
        table.add_column("Duration", justify="right")
        table.add_column("Retries", justify="right")

        for task_id in manager.task_order:
            task = manager.tasks[task_id]

            # Status with color
            if task.state == TaskState.COMPLETED:
                status = "[green]Completed[/green]"
            elif task.state == TaskState.FAILED:
                status = "[red]Failed[/red]"
            elif task.state == TaskState.CANCELLED:
                status = "[yellow]Cancelled[/yellow]"
            else:
                status = task.state.name

            # Duration
            duration = f"{task.duration:.2f}s" if task.duration else "-"

            table.add_row(
                task.name,
                status,
                duration,
                str(task.retry_count) if task.retry_count > 0 else "-",
            )

        self.console.print(table)

        # Summary stats
        completed = len(manager.get_tasks_by_state(TaskState.COMPLETED))
        failed = len(manager.get_tasks_by_state(TaskState.FAILED))
        total = len(manager.tasks)

        self.console.print(f"\n[bold]Total:[/bold] {completed}/{total} completed, {failed} failed")


# =============================================================================
# Retry Handler (P1-27)
# =============================================================================


class RetryHandler:
    """
    Handles task retry logic with exponential backoff.

    P1-27: Implement task retry with exponential backoff
    """

    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        backoff_factor: float = 2.0,
        jitter: float = 0.2,
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.jitter = jitter

    def calculate_delay(self, attempt: int) -> float:
        """Calculate delay for retry attempt."""
        # Exponential backoff
        delay = self.base_delay * (self.backoff_factor**attempt)

        # Apply max delay cap
        delay = min(delay, self.max_delay)

        # Add jitter
        jitter_amount = delay * self.jitter * (random.random() * 2 - 1)
        delay = max(0.1, delay + jitter_amount)

        return delay

    def should_retry(self, attempt: int, error: Exception) -> bool:
        """Determine if error should be retried."""
        if attempt >= self.max_retries:
            return False

        # Check for non-retryable errors
        error_str = str(error).lower()
        non_retryable = [
            "authentication",
            "authorization",
            "permission denied",
            "invalid api key",
            "not found",
        ]

        return not any(msg in error_str for msg in non_retryable)

    async def execute_with_retry(
        self,
        func: Callable,
        *args,
        on_retry: Callable[[int, Exception, float], None] | None = None,
        **kwargs,
    ) -> Any:
        """Execute function with automatic retry."""
        last_error: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                if asyncio.iscoroutinefunction(func):
                    return await func(*args, **kwargs)
                else:
                    return func(*args, **kwargs)

            except Exception as e:
                last_error = e

                if not self.should_retry(attempt, e):
                    raise

                if attempt < self.max_retries:
                    delay = self.calculate_delay(attempt)

                    if on_retry:
                        on_retry(attempt + 1, e, delay)

                    await asyncio.sleep(delay)

        if last_error:
            raise last_error


# =============================================================================
# Convenience Functions
# =============================================================================


def create_task_manager() -> TaskManager:
    """Create a new task manager."""
    return TaskManager()


def create_progress_display(console: Console | None = None) -> TaskProgressDisplay:
    """Create a new progress display."""
    return TaskProgressDisplay(console)
