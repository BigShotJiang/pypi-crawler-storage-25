"""
15-Step Procedural Workflow Orchestrator for SAGE AI Coding Agent.

This module implements a comprehensive workflow for AI-driven coding tasks:
1. Input Normalization & Prompt Autocorrection
2. Intent Decomposition
3. Brainstorming & Solution Search
4. Planning
5. Spec-to-Test Conversion (TDD)
6. Code Generation
7. Execution Loop
8. Self-Review & Static Analysis
9. Refactor Loop
10. Integration Validation
11. Git Workflow Automation
12. CI/CD Pipeline Execution
13. Post-Execution Evaluation
14. Memory & Retrieval Update
15. Human-in-the-Loop

Design Goals:
- Less noisy output for users
- Shows AI's plans during execution
- Shows all code changes
- Follows TDD principles
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol

logger = logging.getLogger(__name__)


# =============================================================================
# Core Types and Protocols
# =============================================================================


class WorkflowSender(Protocol):
    """Protocol for AI model send functions."""

    def __call__(self, prompt: str) -> dict[str, Any]:
        """Send a prompt to the AI model and return structured response."""
        ...


class WorkflowStep(Enum):
    """Enumeration of all 15 workflow steps."""

    INPUT_NORMALIZATION = 1
    INTENT_DECOMPOSITION = 2
    BRAINSTORMING = 3
    PLANNING = 4
    SPEC_TO_TEST = 5
    CODE_GENERATION = 6
    EXECUTION_LOOP = 7
    SELF_REVIEW = 8
    REFACTOR_LOOP = 9
    INTEGRATION_VALIDATION = 10
    GIT_WORKFLOW = 11
    CICD_PIPELINE = 12
    POST_EVALUATION = 13
    MEMORY_UPDATE = 14
    HUMAN_IN_LOOP = 15


# =============================================================================
# Result Dataclasses
# =============================================================================


@dataclass
class NormalizationResult:
    """Result of Step 1: Input Normalization."""

    normalized_prompt: str
    corrections: list[str] = field(default_factory=list)
    confidence: float = 1.0
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class IntentResult:
    """Result of Step 2: Intent Decomposition."""

    primary_intent: str
    sub_intents: list[str] = field(default_factory=list)
    entities: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    implicit_requirements: list[str] = field(default_factory=list)
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class Solution:
    """A potential solution from brainstorming."""

    approach: str
    pros: list[str] = field(default_factory=list)
    cons: list[str] = field(default_factory=list)


@dataclass
class BrainstormResult:
    """Result of Step 3: Brainstorming."""

    solutions: list[Solution] = field(default_factory=list)
    recommended_solution: str | None = None
    reasoning: str | None = None
    codebase_patterns: list[str] = field(default_factory=list)
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class PlanStep:
    """A single step in the execution plan."""

    step_number: int
    action: str
    file: str | None = None
    rollback: str | None = None


@dataclass
class PlanResult:
    """Result of Step 4: Planning."""

    steps: list[PlanStep] = field(default_factory=list)
    dependencies: dict[str, list[str]] = field(default_factory=dict)
    rollback_points: list[dict[str, Any]] = field(default_factory=list)
    estimated_changes: int = 0
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class TestSpec:
    """A test specification."""

    name: str
    code: str


@dataclass
class TestGenerationResult:
    """Result of Step 5: Spec-to-Test Conversion."""

    tests: list[TestSpec] = field(default_factory=list)
    coverage_areas: list[str] = field(default_factory=list)
    tdd_phase: str = "red"
    expected_to_fail: bool = True
    raw_response: dict[str, Any] = field(default_factory=dict)
    assertion_count: int = 0

    def validate_tests(self) -> tuple[bool, list[str]]:
        """Validate that tests meet TDD quality requirements.

        Returns (is_valid, list_of_issues).
        """
        issues = []

        if not self.tests:
            issues.append("No tests were generated - TDD requires tests first")
            return False, issues

        for test in self.tests:
            # Check for empty test functions
            if "pass" in test.code and test.code.strip().endswith("pass"):
                issues.append(
                    f"Test '{test.name}' is empty (just 'pass') - tests must have assertions"
                )

            # Check for assertions
            assertion_patterns = [
                "assert ",
                "assertEqual",
                "assertTrue",
                "assertFalse",
                "assertRaises",
                "assertIn",
                "assertIsNone",
                "expect(",
                "should.",
                "pytest.raises",
            ]
            has_assertion = any(pattern in test.code for pattern in assertion_patterns)
            if not has_assertion:
                issues.append(f"Test '{test.name}' has no assertions - tests must verify behavior")

            # Check for placeholder comments
            placeholder_patterns = ["# TODO", "# FIXME", "# implement", "# placeholder"]
            for pattern in placeholder_patterns:
                if pattern.lower() in test.code.lower():
                    issues.append(f"Test '{test.name}' contains placeholder '{pattern}'")

        return len(issues) == 0, issues


@dataclass
class CodeChange:
    """A code change."""

    file: str
    action: str = "modify"
    content: str = ""
    diff: str = ""


@dataclass
class StyleAdherence:
    """Style adherence information."""

    naming_convention: str = "snake_case"
    docstrings: bool = True
    type_hints: bool = True


@dataclass
class CodeGenerationResult:
    """Result of Step 6: Code Generation."""

    code_changes: list[CodeChange] = field(default_factory=list)
    tests_targeted: list[str] = field(default_factory=list)
    style_adherence: StyleAdherence | None = None
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionResult:
    """Result of Step 7: Execution Loop."""

    passed: int = 0
    failed: int = 0
    errors: int = 0
    failed_tests: list[str] = field(default_factory=list)
    execution_time: float = 0.0
    all_passed: bool = False
    iterations: int = 0
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class ReviewFinding:
    """A finding from code review."""

    severity: str
    message: str


@dataclass
class StaticAnalysis:
    """Static analysis results."""

    linting: dict[str, int] = field(default_factory=dict)
    type_checking: dict[str, int] = field(default_factory=dict)
    security: dict[str, int] = field(default_factory=dict)


@dataclass
class ReviewResult:
    """Result of Step 8: Self-Review."""

    quality_score: float = 0.0
    review_findings: list[ReviewFinding] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    static_analysis: StaticAnalysis | None = None
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class RefactorSuggestion:
    """A refactoring suggestion."""

    type: str
    location: str


@dataclass
class RefactorResult:
    """Result of Step 9: Refactor Loop."""

    suggestions: list[RefactorSuggestion] = field(default_factory=list)
    applied: bool = False
    tests_preserved: bool = True
    coverage_before: float = 0.0
    coverage_after: float = 0.0
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class IntegrationResult:
    """Result of Step 10: Integration Validation."""

    integration_valid: bool = False
    api_contracts_valid: bool = True
    database_migrations_valid: bool = True
    backward_compatible: bool = True
    breaking_changes: list[str] = field(default_factory=list)
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class GitResult:
    """Result of Step 11: Git Workflow."""

    commit_message: str | None = None
    files_staged: list[str] = field(default_factory=list)
    branch_name: str | None = None
    conventional_commit: bool = True
    ready_for_pr: bool = False
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class CICDStage:
    """A CI/CD pipeline stage."""

    name: str
    status: str


@dataclass
class CICDResult:
    """Result of Step 12: CI/CD Pipeline."""

    pipeline_triggered: bool = False
    pipeline_id: str | None = None
    status: str = "pending"
    stages: list[CICDStage] = field(default_factory=list)
    estimated_duration: int = 0
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class EvaluationResult:
    """Result of Step 13: Post-Execution Evaluation."""

    task_completed: bool = False
    requirements_met: list[str] = field(default_factory=list)
    requirements_missing: list[str] = field(default_factory=list)
    confidence: float = 0.0
    follow_up_tasks: list[str] = field(default_factory=list)
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class MemoryResult:
    """Result of Step 14: Memory Update."""

    learnings_stored: bool = False
    patterns_learned: list[str] = field(default_factory=list)
    knowledge_updated: bool = False
    context_updated: bool = False
    codebase_knowledge: dict[str, Any] = field(default_factory=dict)
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class HumanReviewResult:
    """Result of Step 15: Human-in-the-Loop."""

    requires_approval: bool = False
    approval_points: list[str] = field(default_factory=list)
    summary: dict[str, Any] | None = None
    review_checklist: list[str] = field(default_factory=list)
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowResult:
    """Complete workflow execution result."""

    completed: bool = False
    current_step: int = 0
    steps_executed: list[int] = field(default_factory=list)
    error: str | None = None
    recovery_attempted: bool = False
    displayed_plan: dict[str, Any] | None = None
    code_changes_displayed: bool = False

    # Results from each step
    normalization: NormalizationResult | None = None
    intent: IntentResult | None = None
    brainstorm: BrainstormResult | None = None
    plan: PlanResult | None = None
    tests: TestGenerationResult | None = None
    code: CodeGenerationResult | None = None
    execution: ExecutionResult | None = None
    review: ReviewResult | None = None
    refactor: RefactorResult | None = None
    integration: IntegrationResult | None = None
    git: GitResult | None = None
    cicd: CICDResult | None = None
    evaluation: EvaluationResult | None = None
    memory: MemoryResult | None = None
    human_review: HumanReviewResult | None = None


# =============================================================================
# Procedural Workflow Orchestrator
# =============================================================================


class ProceduralWorkflowOrchestrator:
    """
    15-Step Procedural Workflow Orchestrator.

    Implements a comprehensive AI-driven coding workflow with:
    - Minimal noise output for users
    - Visible AI plans during execution
    - Full code change display
    - TDD principles throughout
    """

    STEP_NAMES = {
        1: "Input Normalization",
        2: "Intent Decomposition",
        3: "Brainstorming",
        4: "Planning",
        5: "Spec-to-Test (TDD)",
        6: "Code Generation",
        7: "Execution Loop",
        8: "Self-Review",
        9: "Refactor Loop",
        10: "Integration Validation",
        11: "Git Workflow",
        12: "CI/CD Pipeline",
        13: "Post-Evaluation",
        14: "Memory Update",
        15: "Human-in-the-Loop",
    }

    def __init__(self, send: WorkflowSender):
        """Initialize with AI model send function."""
        self._send = send
        self._current_context: dict[str, Any] = {}

    def _safe_send(self, prompt: str) -> dict[str, Any]:
        """Send prompt safely with error handling."""
        try:
            response = self._send(prompt)
            if isinstance(response, str):
                try:
                    return json.loads(response)
                except json.JSONDecodeError:
                    return {"raw": response}
            return response or {}
        except Exception as e:
            logger.error(f"AI send error: {e}")
            return {"error": str(e)}

    # =========================================================================
    # Step 1: Input Normalization & Prompt Autocorrection
    # =========================================================================

    def step_1_normalize_input(self, raw_input: str) -> NormalizationResult:
        """
        Step 1: Normalize and autocorrect user input.

        - Fixes typos and abbreviations
        - Expands shorthand
        - Preserves technical terms
        """
        prompt = f"""Normalize and autocorrect this user input for a coding task.
Fix typos, expand abbreviations, but preserve technical terms.

Input: {raw_input}

Return JSON:
{{
    "normalized": "corrected and expanded prompt",
    "corrections": ["list of corrections made"],
    "confidence": 0.0 to 1.0
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        return NormalizationResult(
            normalized_prompt=response.get("normalized", raw_input),
            corrections=response.get("corrections", []),
            confidence=response.get("confidence", 1.0),
            raw_response=response,
        )

    # =========================================================================
    # Step 2: Intent Decomposition
    # =========================================================================

    def step_2_decompose_intent(self, task: str) -> IntentResult:
        """
        Step 2: Decompose user intent into structured components.

        - Identifies primary intent
        - Extracts sub-intents
        - Finds entities and constraints
        - Discovers implicit requirements
        """
        prompt = f"""Decompose the intent of this coding task.

Task: {task}

Return JSON:
{{
    "primary_intent": "main action type",
    "sub_intents": ["list of sub-tasks"],
    "entities": ["key entities mentioned"],
    "constraints": ["explicit constraints"],
    "implicit_requirements": ["implied requirements not stated"]
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        return IntentResult(
            primary_intent=response.get("primary_intent", "unknown"),
            sub_intents=response.get("sub_intents", []),
            entities=response.get("entities", []),
            constraints=response.get("constraints", []),
            implicit_requirements=response.get("implicit_requirements", []),
            raw_response=response,
        )

    # =========================================================================
    # Step 3: Brainstorming & Solution Search
    # =========================================================================

    def step_3_brainstorm_solutions(
        self, task: str, codebase_context: str | None = None
    ) -> BrainstormResult:
        """
        Step 3: Brainstorm multiple solution approaches.

        - Generates multiple solutions
        - Considers codebase patterns
        - Recommends best approach
        """
        context_info = f"\nCodebase Context: {codebase_context}" if codebase_context else ""

        prompt = f"""Brainstorm solutions for this coding task.
Generate multiple approaches with pros/cons.{context_info}

Task: {task}

Return JSON:
{{
    "solutions": [
        {{"approach": "solution 1", "pros": ["pro1"], "cons": ["con1"]}},
        {{"approach": "solution 2", "pros": ["pro2"], "cons": ["con2"]}}
    ],
    "recommended": "best solution name",
    "reasoning": "why this is recommended",
    "codebase_patterns": ["existing patterns to consider"]
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        solutions = []
        for sol in response.get("solutions", []):
            solutions.append(
                Solution(
                    approach=sol.get("approach", ""),
                    pros=sol.get("pros", []),
                    cons=sol.get("cons", []),
                )
            )

        return BrainstormResult(
            solutions=solutions,
            recommended_solution=response.get("recommended"),
            reasoning=response.get("reasoning"),
            codebase_patterns=response.get("codebase_patterns", []),
            raw_response=response,
        )

    # =========================================================================
    # Step 4: Planning
    # =========================================================================

    def step_4_create_plan(self, task: str) -> PlanResult:
        """
        Step 4: Create a detailed execution plan.

        - Defines ordered steps
        - Maps dependencies
        - Identifies rollback points
        """
        prompt = f"""Create an execution plan for this coding task.

Task: {task}

Return JSON:
{{
    "plan": [
        {{"step": 1, "action": "description", "file": "path/to/file.py", "rollback": "undo action"}}
    ],
    "dependencies": {{"step_2": ["step_1"]}},
    "rollback_points": [{{"step": 1, "action": "rollback description"}}],
    "estimated_changes": 3
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        steps = []
        for step in response.get("plan", []):
            steps.append(
                PlanStep(
                    step_number=step.get("step", 0),
                    action=step.get("action", ""),
                    file=step.get("file"),
                    rollback=step.get("rollback"),
                )
            )

        return PlanResult(
            steps=steps,
            dependencies=response.get("dependencies", {}),
            rollback_points=response.get("rollback_points", []),
            estimated_changes=response.get("estimated_changes", 0),
            raw_response=response,
        )

    # =========================================================================
    # Step 5: Spec-to-Test Conversion (TDD)
    # =========================================================================

    def step_5_generate_tests(self, spec: str) -> TestGenerationResult:
        """
        Step 5: Generate tests from specification (TDD Red phase).

        - Creates failing tests first
        - Covers happy path and edge cases
        - CRITICAL: Tests must have real assertions, not just 'pass'
        """
        prompt = f"""Generate tests for this specification using TDD (Test-Driven Development).
These tests are for the RED phase - they MUST fail initially because no implementation exists yet.

CRITICAL TDD REQUIREMENTS:
1. Each test MUST have real assertions (assert, assertEqual, assertTrue, etc.)
2. NEVER write empty test functions with just 'pass'
3. NEVER use placeholder comments like '# TODO' or '# implement this'
4. Tests should test ACTUAL expected behavior, not just "it works"
5. Include edge cases and error handling tests

Specification: {spec}

Return JSON:
{{
    "tests": [
        {{"name": "test_function_name_describes_behavior", "code": "def test_function_name_describes_behavior():\\n    # Test setup\\n    input_data = ...\\n    expected = ...\\n    # Act\\n    result = function_under_test(input_data)\\n    # Assert - REAL assertion\\n    assert result == expected"}}
    ],
    "coverage_areas": ["happy path", "error handling", "edge cases", "boundary conditions"],
    "tdd_phase": "red",
    "expected_to_fail": true,
    "assertion_count": 5
}}

VALIDATION: Each test function MUST contain at least one assertion keyword (assert, assertEqual, etc.).
Tests without assertions will be REJECTED.

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        tests = []
        for test in response.get("tests", []):
            tests.append(
                TestSpec(
                    name=test.get("name", ""),
                    code=test.get("code", ""),
                )
            )

        return TestGenerationResult(
            tests=tests,
            coverage_areas=response.get("coverage_areas", []),
            tdd_phase=response.get("tdd_phase", "red"),
            expected_to_fail=response.get("expected_to_fail", True),
            raw_response=response,
        )

    # =========================================================================
    # Step 6: Code Generation
    # =========================================================================

    def step_6_generate_code(
        self, tests: list[str], style_guide: str | None = None
    ) -> CodeGenerationResult:
        """
        Step 6: Generate code to pass tests (TDD Green phase).

        - Writes minimal code to pass tests
        - Follows style guide
        - CRITICAL: Code must be complete, no placeholders
        """
        style_info = f"\nStyle Guide: {style_guide}" if style_guide else ""

        prompt = f"""Generate COMPLETE, WORKING implementation code to pass these tests (TDD GREEN phase).
The tests are already written and failing. Your implementation must make them pass.{style_info}

CRITICAL IMPLEMENTATION REQUIREMENTS:
1. Write COMPLETE, FUNCTIONAL code - no placeholders, no TODOs, no 'pass' statements
2. Every function MUST have actual implementation logic
3. NEVER use comments like '# implement this' or '# placeholder'
4. Code must be ready to run without modification
5. Include proper error handling where appropriate
6. Use type hints for function signatures

Tests to make pass: {json.dumps(tests)}

Return JSON:
{{
    "code_changes": [
        {{"file": "path/to/file.py", "action": "create", "content": "# Complete implementation\\nimport ...\\n\\ndef function_name(param: Type) -> ReturnType:\\n    '''Docstring explaining behavior.'''\\n    # Actual implementation logic\\n    result = compute_something(param)\\n    return result"}}
    ],
    "tests_targeted": ["test_name1", "test_name2"],
    "style_adherence": {{
        "naming_convention": "snake_case",
        "docstrings": true,
        "type_hints": true
    }},
    "implementation_complete": true
}}

VALIDATION:
- Code with 'pass' as the only statement in a function will be REJECTED
- Code with TODO/FIXME comments will be REJECTED
- Code that cannot make tests pass will be REJECTED

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        changes = []
        for change in response.get("code_changes", []):
            changes.append(
                CodeChange(
                    file=change.get("file", ""),
                    action=change.get("action", "modify"),
                    content=change.get("content", ""),
                )
            )

        style = None
        if "style_adherence" in response:
            sa = response["style_adherence"]
            style = StyleAdherence(
                naming_convention=sa.get("naming_convention", "snake_case"),
                docstrings=sa.get("docstrings", True),
                type_hints=sa.get("type_hints", True),
            )

        return CodeGenerationResult(
            code_changes=changes,
            tests_targeted=response.get("tests_targeted", []),
            style_adherence=style,
            raw_response=response,
        )

    # =========================================================================
    # Step 7: Execution Loop
    # =========================================================================

    def step_7_execute_tests(self, max_iterations: int = 5) -> ExecutionResult:
        """
        Step 7: Execute tests and iterate until passing.

        - Runs test suite
        - Reports results
        - Iterates on failures
        """
        prompt = """Execute tests and report results.

Return JSON:
{{
    "test_results": {{"passed": 5, "failed": 1, "errors": 0}},
    "failed_tests": ["test_name"],
    "execution_time": 2.5,
    "all_passed": false
}}

Respond ONLY with valid JSON."""

        iterations = 0
        all_passed = False

        while iterations < max_iterations and not all_passed:
            response = self._safe_send(prompt)
            iterations += 1

            results = response.get("test_results", {})
            all_passed = response.get("all_passed", results.get("failed", 1) == 0)

            if all_passed:
                break

        results = response.get("test_results", {})

        return ExecutionResult(
            passed=results.get("passed", 0),
            failed=results.get("failed", 0),
            errors=results.get("errors", 0),
            failed_tests=response.get("failed_tests", []),
            execution_time=response.get("execution_time", 0.0),
            all_passed=all_passed,
            iterations=iterations,
            raw_response=response,
        )

    # =========================================================================
    # Step 8: Self-Review & Static Analysis
    # =========================================================================

    def step_8_self_review(self) -> ReviewResult:
        """
        Step 8: Perform code review and static analysis.

        - Reviews code quality
        - Runs linting and type checking
        - Checks for security issues
        """
        prompt = """Review the generated code for quality issues.

Return JSON:
{{
    "review_findings": [
        {{"severity": "warning", "message": "description"}}
    ],
    "quality_score": 8.5,
    "suggestions": ["suggestion 1"],
    "static_analysis": {{
        "linting": {{"errors": 0, "warnings": 2}},
        "type_checking": {{"errors": 0}},
        "security": {{"vulnerabilities": 0}}
    }}
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        findings = []
        for finding in response.get("review_findings", []):
            findings.append(
                ReviewFinding(
                    severity=finding.get("severity", "info"),
                    message=finding.get("message", ""),
                )
            )

        static = None
        if "static_analysis" in response:
            sa = response["static_analysis"]
            static = StaticAnalysis(
                linting=sa.get("linting", {}),
                type_checking=sa.get("type_checking", {}),
                security=sa.get("security", {}),
            )

        return ReviewResult(
            quality_score=response.get("quality_score", 0.0),
            review_findings=findings,
            suggestions=response.get("suggestions", []),
            static_analysis=static,
            raw_response=response,
        )

    # =========================================================================
    # Step 9: Refactor Loop
    # =========================================================================

    def step_9_refactor(self) -> RefactorResult:
        """
        Step 9: Refactor code while preserving tests.

        - Identifies refactoring opportunities
        - Applies safe refactorings
        - Ensures tests still pass
        """
        prompt = """Identify refactoring opportunities and apply them.

Return JSON:
{{
    "refactoring_suggestions": [
        {{"type": "extract_method", "location": "file.py:50-60"}}
    ],
    "applied": true,
    "tests_still_passing": true,
    "coverage_before": 85.0,
    "coverage_after": 87.0
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        suggestions = []
        for sug in response.get("refactoring_suggestions", []):
            suggestions.append(
                RefactorSuggestion(
                    type=sug.get("type", ""),
                    location=sug.get("location", ""),
                )
            )

        return RefactorResult(
            suggestions=suggestions,
            applied=response.get("applied", False),
            tests_preserved=response.get("tests_still_passing", True),
            coverage_before=response.get("coverage_before", 0.0),
            coverage_after=response.get("coverage_after", 0.0),
            raw_response=response,
        )

    # =========================================================================
    # Step 10: Integration Validation
    # =========================================================================

    def step_10_validate_integration(self) -> IntegrationResult:
        """
        Step 10: Validate integration with existing code.

        - Checks integration points
        - Validates API contracts
        - Verifies backward compatibility
        """
        prompt = """Validate integration with the existing codebase.

Return JSON:
{{
    "integration_tests_passed": true,
    "api_contracts_valid": true,
    "database_migrations_valid": true,
    "backward_compatible": true,
    "breaking_changes": []
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        return IntegrationResult(
            integration_valid=response.get("integration_tests_passed", False),
            api_contracts_valid=response.get("api_contracts_valid", True),
            database_migrations_valid=response.get("database_migrations_valid", True),
            backward_compatible=response.get("backward_compatible", True),
            breaking_changes=response.get("breaking_changes", []),
            raw_response=response,
        )

    # =========================================================================
    # Step 11: Git Workflow Automation
    # =========================================================================

    def step_11_git_workflow(self) -> GitResult:
        """
        Step 11: Automate git workflow.

        - Creates meaningful commits
        - Manages branches
        - Prepares for PR
        """
        prompt = """Create git commits and manage branches for the changes.

Return JSON:
{{
    "commit_message": "feat(scope): description",
    "files_staged": ["file1.py", "file2.py"],
    "conventional_commit": true,
    "branch_created": "feature/name",
    "base_branch": "main",
    "ready_for_pr": true
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        return GitResult(
            commit_message=response.get("commit_message"),
            files_staged=response.get("files_staged", []),
            branch_name=response.get("branch_created"),
            conventional_commit=response.get("conventional_commit", True),
            ready_for_pr=response.get("ready_for_pr", False),
            raw_response=response,
        )

    # =========================================================================
    # Step 12: CI/CD Pipeline Execution
    # =========================================================================

    def step_12_run_cicd(self) -> CICDResult:
        """
        Step 12: Trigger and monitor CI/CD pipeline.

        - Triggers pipeline
        - Reports status
        - Handles failures
        """
        prompt = """Trigger CI/CD pipeline and report status.

Return JSON:
{{
    "pipeline_triggered": true,
    "pipeline_id": "ci-12345",
    "status": "passed",
    "stages": [
        {{"name": "build", "status": "passed"}},
        {{"name": "test", "status": "passed"}}
    ],
    "estimated_duration": 300
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        stages = []
        for stage in response.get("stages", []):
            stages.append(
                CICDStage(
                    name=stage.get("name", ""),
                    status=stage.get("status", "pending"),
                )
            )

        return CICDResult(
            pipeline_triggered=response.get("pipeline_triggered", False),
            pipeline_id=response.get("pipeline_id"),
            status=response.get("status", "pending"),
            stages=stages,
            estimated_duration=response.get("estimated_duration", 0),
            raw_response=response,
        )

    # =========================================================================
    # Step 13: Post-Execution Evaluation
    # =========================================================================

    def step_13_evaluate(self) -> EvaluationResult:
        """
        Step 13: Evaluate task completion.

        - Checks requirements met
        - Measures confidence
        - Identifies follow-up tasks
        """
        prompt = """Evaluate if the task was completed successfully.

Return JSON:
{{
    "task_completed": true,
    "requirements_met": ["requirement 1", "requirement 2"],
    "requirements_missing": [],
    "confidence": 0.95,
    "follow_up_tasks": ["optional future improvement"]
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        return EvaluationResult(
            task_completed=response.get("task_completed", False),
            requirements_met=response.get("requirements_met", []),
            requirements_missing=response.get("requirements_missing", []),
            confidence=response.get("confidence", 0.0),
            follow_up_tasks=response.get("follow_up_tasks", []),
            raw_response=response,
        )

    # =========================================================================
    # Step 14: Memory & Retrieval Update
    # =========================================================================

    def step_14_update_memory(self) -> MemoryResult:
        """
        Step 14: Update memory and context for future tasks.

        - Stores learnings
        - Updates codebase knowledge
        - Prepares context for future
        """
        prompt = """Update memory with learnings from this task.

Return JSON:
{{
    "learnings_stored": true,
    "patterns_learned": ["pattern description"],
    "knowledge_updated": true,
    "context_updated": true,
    "codebase_knowledge": {{"key": "value"}}
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        return MemoryResult(
            learnings_stored=response.get("learnings_stored", False),
            patterns_learned=response.get("patterns_learned", []),
            knowledge_updated=response.get("knowledge_updated", False),
            context_updated=response.get("context_updated", False),
            codebase_knowledge=response.get("codebase_knowledge", {}),
            raw_response=response,
        )

    # =========================================================================
    # Step 15: Human-in-the-Loop
    # =========================================================================

    def step_15_human_review(self) -> HumanReviewResult:
        """
        Step 15: Request human review when needed.

        - Identifies approval points
        - Provides summary
        - Creates review checklist
        """
        prompt = """Determine if human review is needed and prepare summary.

Return JSON:
{{
    "requires_approval": true,
    "approval_points": ["point needing review"],
    "summary": {{
        "changes_made": 5,
        "tests_added": 3,
        "files_modified": ["file1.py"]
    }},
    "review_checklist": ["Security", "Performance"]
}}

Respond ONLY with valid JSON."""

        response = self._safe_send(prompt)

        return HumanReviewResult(
            requires_approval=response.get("requires_approval", False),
            approval_points=response.get("approval_points", []),
            summary=response.get("summary"),
            review_checklist=response.get("review_checklist", []),
            raw_response=response,
        )

    # =========================================================================
    # Full Workflow Execution
    # =========================================================================

    def execute(
        self,
        task: str,
        stop_after_step: int | None = None,
        on_progress: Callable[[int, str], None] | None = None,
        verbosity: str = "normal",
        show_code_changes: bool = True,
    ) -> WorkflowResult:
        """
        Execute the complete 15-step workflow.

        Args:
            task: The coding task to execute
            stop_after_step: Stop after this step (for resumable workflows)
            on_progress: Callback for progress updates (step, status)
            verbosity: Output level ("minimal", "normal", "plan", "verbose")
            show_code_changes: Whether to display code changes

        Returns:
            WorkflowResult with all step results
        """
        result = WorkflowResult()
        total_steps = stop_after_step or 15

        def report_progress(step: int, status: str):
            if on_progress:
                on_progress(step, status)
            if verbosity != "minimal":
                logger.info(f"Step {step}: {self.STEP_NAMES.get(step, 'Unknown')} - {status}")

        try:
            # Step 1: Input Normalization
            report_progress(1, "started")
            result.normalization = self.step_1_normalize_input(task)
            result.steps_executed.append(1)
            result.current_step = 1
            report_progress(1, "completed")
            if total_steps == 1:
                return result

            normalized_task = result.normalization.normalized_prompt

            # Step 2: Intent Decomposition
            report_progress(2, "started")
            result.intent = self.step_2_decompose_intent(normalized_task)
            result.steps_executed.append(2)
            result.current_step = 2
            report_progress(2, "completed")
            if total_steps == 2:
                return result

            # Step 3: Brainstorming
            report_progress(3, "started")
            result.brainstorm = self.step_3_brainstorm_solutions(normalized_task)
            result.steps_executed.append(3)
            result.current_step = 3
            report_progress(3, "completed")
            if total_steps == 3:
                return result

            # Step 4: Planning
            report_progress(4, "started")
            result.plan = self.step_4_create_plan(normalized_task)
            result.steps_executed.append(4)
            result.current_step = 4
            if verbosity in ("plan", "verbose"):
                result.displayed_plan = {
                    "steps": [
                        {"step": s.step_number, "action": s.action} for s in result.plan.steps
                    ],
                    "estimated_changes": result.plan.estimated_changes,
                }
            report_progress(4, "completed")
            if total_steps == 4:
                return result

            # Step 5: Spec-to-Test (TDD)
            report_progress(5, "started")
            result.tests = self.step_5_generate_tests(normalized_task)
            result.steps_executed.append(5)
            result.current_step = 5

            # TDD GATE: Validate tests before proceeding to implementation
            max_test_retries = 3
            test_retry = 0
            tests_valid, test_issues = result.tests.validate_tests()

            while not tests_valid and test_retry < max_test_retries:
                test_retry += 1
                logger.warning(
                    f"TDD Gate: Test validation failed (attempt {test_retry}/{max_test_retries})"
                )
                for issue in test_issues:
                    logger.warning(f"  - {issue}")

                # Regenerate tests with explicit feedback about failures
                regenerate_prompt = f"""Your previous tests were REJECTED for the following reasons:
{chr(10).join(f"- {issue}" for issue in test_issues)}

You MUST fix these issues. Requirements:
1. Every test function MUST have at least one assertion (assert, assertEqual, etc.)
2. NO empty functions with just 'pass'
3. NO placeholder comments (TODO, FIXME, etc.)
4. Tests must verify actual expected behavior

Specification: {normalized_task}

Regenerate the tests with REAL assertions."""

                result.tests = self.step_5_generate_tests(regenerate_prompt)
                tests_valid, test_issues = result.tests.validate_tests()

            if not tests_valid:
                result.error = f"TDD Gate Failed: Tests do not meet quality requirements after {max_test_retries} attempts: {'; '.join(test_issues)}"
                logger.error(result.error)
                return result

            report_progress(5, "completed")
            if total_steps == 5:
                return result

            # Step 6: Code Generation (only proceeds if tests are valid)
            report_progress(6, "started")
            test_names = [t.name for t in result.tests.tests]
            result.code = self.step_6_generate_code(test_names)
            result.steps_executed.append(6)
            result.current_step = 6
            if show_code_changes:
                result.code_changes_displayed = True
            report_progress(6, "completed")
            if total_steps == 6:
                return result

            # Step 7: Execution Loop
            report_progress(7, "started")
            result.execution = self.step_7_execute_tests()
            result.steps_executed.append(7)
            result.current_step = 7
            report_progress(7, "completed")
            if total_steps == 7:
                return result

            # Step 8: Self-Review
            report_progress(8, "started")
            result.review = self.step_8_self_review()
            result.steps_executed.append(8)
            result.current_step = 8
            report_progress(8, "completed")
            if total_steps == 8:
                return result

            # Step 9: Refactor Loop
            report_progress(9, "started")
            result.refactor = self.step_9_refactor()
            result.steps_executed.append(9)
            result.current_step = 9
            report_progress(9, "completed")
            if total_steps == 9:
                return result

            # Step 10: Integration Validation
            report_progress(10, "started")
            result.integration = self.step_10_validate_integration()
            result.steps_executed.append(10)
            result.current_step = 10
            report_progress(10, "completed")
            if total_steps == 10:
                return result

            # Step 11: Git Workflow
            report_progress(11, "started")
            result.git = self.step_11_git_workflow()
            result.steps_executed.append(11)
            result.current_step = 11
            report_progress(11, "completed")
            if total_steps == 11:
                return result

            # Step 12: CI/CD Pipeline
            report_progress(12, "started")
            result.cicd = self.step_12_run_cicd()
            result.steps_executed.append(12)
            result.current_step = 12
            report_progress(12, "completed")
            if total_steps == 12:
                return result

            # Step 13: Post-Evaluation
            report_progress(13, "started")
            result.evaluation = self.step_13_evaluate()
            result.steps_executed.append(13)
            result.current_step = 13
            report_progress(13, "completed")
            if total_steps == 13:
                return result

            # Step 14: Memory Update
            report_progress(14, "started")
            result.memory = self.step_14_update_memory()
            result.steps_executed.append(14)
            result.current_step = 14
            report_progress(14, "completed")
            if total_steps == 14:
                return result

            # Step 15: Human-in-the-Loop
            report_progress(15, "started")
            result.human_review = self.step_15_human_review()
            result.steps_executed.append(15)
            result.current_step = 15
            report_progress(15, "completed")

            result.completed = True

        except Exception as e:
            result.error = str(e)
            result.recovery_attempted = True
            logger.error(f"Workflow error at step {result.current_step}: {e}")

        return result
