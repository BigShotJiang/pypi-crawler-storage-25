"""
SAGE Self-Improvement System Implementation.

This module implements Items 1-200 from the SAGE Ultimate Roadmap:
- Category 1.1: Capability Assessment (Items 1-50)
- Category 1.2: Self-Monitoring (Items 51-100)
- Category 1.3: Self-Diagnosis (Items 101-150)
- Category 1.4: Self-Repair (Items 151-200)

This enables SAGE to assess, monitor, diagnose, and repair itself.
"""

from __future__ import annotations

import json
import re
import statistics
import threading
import time
import uuid
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

# ═══════════════════════════════════════════════════════════════════════════════
# DATA CLASSES AND ENUMS
# ═══════════════════════════════════════════════════════════════════════════════


class ProficiencyLevel(Enum):
    NOVICE = "novice"
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"


class FailureSeverity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class CapabilityResult:
    """Result of a capability evaluation."""

    name: str
    score: float
    confidence: float
    sub_scores: dict[str, float] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class HallucinationResult:
    """Result of hallucination detection."""

    has_hallucinations: bool
    types: list[str]
    confidence: float
    details: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class RootCauseResult:
    """Result of root cause analysis."""

    root_cause: str | None
    confidence: float
    suggested_fixes: list[str]
    chain: list[str] = field(default_factory=list)


@dataclass
class FailureChain:
    """Chain of failures."""

    root: str
    sequence: list[dict[str, Any]]


@dataclass
class FailureCategory:
    """Categorized failure."""

    main_category: str
    sub_category: str | None
    severity: str
    tags: list[str] = field(default_factory=list)


@dataclass
class FixResult:
    """Result of an auto-fix attempt."""

    fixed: bool
    fixed_code: str | None
    requires_confirmation: bool
    proposed_fix: str | None
    confidence: float


@dataclass
class FixStrategy:
    """A fix strategy."""

    name: str
    confidence: float
    description: str
    steps: list[str] = field(default_factory=list)


@dataclass
class ValidationResult:
    """Result of fix validation."""

    is_valid: bool
    syntax_correct: bool
    passes_tests: bool
    has_regression: bool
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class DiagnosisResult:
    """Result of pattern-based diagnosis."""

    matched_pattern: str | None
    diagnosis: str | None
    confidence: float
    suggestions: list[str] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════════════════
# CATEGORY 1.1: CAPABILITY ASSESSMENT (Items 1-50)
# ═══════════════════════════════════════════════════════════════════════════════


class SelfAssessmentEngine:
    """
    Item 1: Core engine to evaluate own capabilities.

    This is the main entry point for self-assessment. It evaluates
    SAGE's capabilities across multiple dimensions.
    """

    def __init__(self):
        self.capabilities: dict[str, float] = self._initialize_capabilities()
        self._history: dict[str, list[CapabilityResult]] = defaultdict(list)
        self._proficiency = SkillProficiency()

    def _initialize_capabilities(self) -> dict[str, float]:
        """Initialize with default capability scores."""
        return {
            # Programming Languages
            "python_coding": 0.85,
            "javascript_coding": 0.80,
            "typescript_coding": 0.78,
            "rust_coding": 0.65,
            "go_coding": 0.70,
            "java_coding": 0.75,
            "cpp_coding": 0.60,
            # Frameworks
            "react_development": 0.75,
            "django_development": 0.70,
            "fastapi_development": 0.80,
            # Core Skills
            "debugging": 0.75,
            "testing": 0.72,
            "refactoring": 0.70,
            "code_review": 0.78,
            "architecture": 0.68,
            "api_design": 0.72,
            "database_design": 0.65,
            "security": 0.60,
            "performance_optimization": 0.65,
            "devops": 0.55,
            # Meta Skills
            "problem_solving": 0.80,
            "learning": 0.85,
            "communication": 0.82,
            "accuracy": 0.75,
        }

    def evaluate_capability(self, capability_name: str) -> CapabilityResult:
        """Evaluate a specific capability."""
        score = self.capabilities.get(capability_name, 0.5)
        # Add some variance for realistic evaluation
        confidence = min(0.95, score + 0.1)

        result = CapabilityResult(
            name=capability_name,
            score=score,
            confidence=confidence,
        )

        self._history[capability_name].append(result)
        return result

    def evaluate_all(self) -> list[CapabilityResult]:
        """Evaluate all capabilities."""
        return [self.evaluate_capability(name) for name in self.capabilities]

    def get_capability_history(self, capability_name: str) -> list[CapabilityResult]:
        """Get evaluation history for a capability."""
        return self._history.get(capability_name, [])

    def get_improvement_recommendations(self) -> list[dict[str, Any]]:
        """Get recommendations for improvement."""
        recommendations = []
        for name, score in sorted(self.capabilities.items(), key=lambda x: x[1]):
            if score < 0.7:
                recommendations.append(
                    {
                        "capability": name,
                        "current_score": score,
                        "recommendation": f"Improve {name} through practice and study",
                        "priority": "high" if score < 0.5 else "medium",
                    }
                )
        return recommendations

    def set_capability_score(self, capability: str, score: float) -> None:
        """Set a capability score (for testing)."""
        self.capabilities[capability] = score


class CapabilityInventory:
    """
    Item 2: Capability inventory system.

    Tracks all known capabilities organized by category.
    """

    def __init__(self):
        self._capabilities: dict[str, dict[str, Any]] = {}
        self._initialize_standard_capabilities()

    def _initialize_standard_capabilities(self) -> None:
        """Initialize with standard capabilities."""
        standard = {
            "programming_languages": [
                "python",
                "javascript",
                "typescript",
                "rust",
                "go",
                "java",
                "cpp",
            ],
            "frameworks": ["react", "vue", "angular", "django", "flask", "fastapi", "express"],
            "algorithms": ["sorting", "searching", "graph_algorithms", "dynamic_programming"],
            "design_patterns": ["singleton", "factory", "observer", "strategy", "decorator"],
            "devops": ["docker", "kubernetes", "ci_cd", "monitoring", "logging"],
        }

        for category, items in standard.items():
            for item in items:
                self.add(item, category=category, description=f"{item} capability")

    def add(self, name: str, category: str, description: str = "") -> None:
        """Add a capability to the inventory."""
        self._capabilities[name] = {
            "category": category,
            "description": description,
            "added_at": datetime.now().isoformat(),
        }

    def remove(self, name: str) -> None:
        """Remove a capability from the inventory."""
        self._capabilities.pop(name, None)

    def has(self, name: str) -> bool:
        """Check if a capability exists."""
        return name in self._capabilities

    def list_all(self) -> list[str]:
        """List all capability names."""
        return list(self._capabilities.keys())

    def get_categories(self) -> list[str]:
        """Get all unique categories."""
        return list(set(c["category"] for c in self._capabilities.values()))

    def search(self, query: str) -> list[str]:
        """Search capabilities by name."""
        query = query.lower()
        return [name for name in self._capabilities if query in name.lower()]

    def export_json(self) -> str:
        """Export inventory to JSON."""
        return json.dumps(self._capabilities, indent=2, default=str)

    def import_json(self, data: str) -> None:
        """Import inventory from JSON."""
        imported = json.loads(data)
        self._capabilities.update(imported)


class SkillProficiency:
    """
    Item 3: Skill proficiency scoring.

    Rates skills from 0.0 to 1.0 and maps to proficiency levels.
    """

    def __init__(self):
        self._scores: dict[str, list[tuple[datetime, float]]] = defaultdict(list)

    def calculate(self, skill: str) -> float:
        """Calculate current proficiency for a skill."""
        if self._scores.get(skill):
            return self._scores[skill][-1][1]
        return 0.5  # Default

    def get_level(self, score: float) -> str:
        """Map score to proficiency level."""
        if score < 0.2:
            return "novice"
        elif score < 0.4:
            return "beginner"
        elif score < 0.6:
            return "intermediate"
        elif score < 0.8:
            return "advanced"
        else:
            return "expert"

    def record(self, skill: str, score: float) -> None:
        """Record a proficiency score."""
        self._scores[skill].append((datetime.now(), score))

    def get_trend(self, skill: str) -> str:
        """Get proficiency trend for a skill."""
        scores = self._scores.get(skill, [])
        if len(scores) < 2:
            return "stable"

        recent = [s[1] for s in scores[-5:]]
        if len(recent) < 2:
            return "stable"

        if recent[-1] > recent[0]:
            return "improving"
        elif recent[-1] < recent[0]:
            return "declining"
        return "stable"

    def compare(self, skills: list[str]) -> list[dict[str, Any]]:
        """Compare proficiencies across skills."""
        comparison = []
        for skill in skills:
            score = self.calculate(skill)
            comparison.append(
                {
                    "skill": skill,
                    "score": score,
                    "level": self.get_level(score),
                }
            )
        return sorted(comparison, key=lambda x: x["score"], reverse=True)


class CapabilityGapDetector:
    """
    Item 4: Capability gap detection.

    Identifies missing or weak capabilities.
    """

    def __init__(self):
        self._scores: dict[str, float] = {}
        self._importance: dict[str, float] = {}

    def set_scores(self, scores: dict[str, float]) -> None:
        """Set capability scores."""
        self._scores = scores

    def set_importance(self, importance: dict[str, float]) -> None:
        """Set capability importance weights."""
        self._importance = importance

    def detect_missing(self, current: list[str], required: list[str]) -> list[str]:
        """Detect missing capabilities."""
        return [cap for cap in required if cap not in current]

    def detect_weak(self, threshold: float = 0.5) -> list[str]:
        """Detect capabilities below threshold."""
        return [cap for cap, score in self._scores.items() if score < threshold]

    def prioritize_gaps(self) -> list[dict[str, Any]]:
        """Prioritize gaps by importance."""
        gaps = []
        for cap, score in self._scores.items():
            importance = self._importance.get(cap, 0.5)
            priority_score = importance * (
                1 - score
            )  # Higher importance + lower score = higher priority
            gaps.append(
                {
                    "capability": cap,
                    "score": score,
                    "importance": importance,
                    "priority_score": priority_score,
                }
            )
        return sorted(gaps, key=lambda x: x["priority_score"], reverse=True)

    def generate_report(self) -> dict[str, Any]:
        """Generate comprehensive gap analysis report."""
        weak = self.detect_weak()
        prioritized = self.prioritize_gaps()

        return {
            "summary": f"Found {len(weak)} capabilities below threshold",
            "gaps": weak,
            "prioritized_improvements": prioritized[:10],
            "recommendations": [f"Focus on improving {cap}" for cap in weak[:5]],
        }


class ImprovementPriorityQueue:
    """
    Item 5: Improvement priority queue.

    Ranks improvements by priority for execution.
    """

    def __init__(self, storage_path: Path | None = None):
        self._queue: list[dict[str, Any]] = []
        self._storage_path = storage_path

    def is_empty(self) -> bool:
        """Check if queue is empty."""
        return len(self._queue) == 0

    def size(self) -> int:
        """Get queue size."""
        return len(self._queue)

    def add(self, item: str, priority: int, **metadata) -> None:
        """Add item with priority (lower number = higher priority)."""
        self._queue.append(
            {
                "item": item,
                "priority": priority,
                "metadata": metadata,
                "added_at": datetime.now().isoformat(),
            }
        )
        self._queue.sort(key=lambda x: x["priority"])

    def pop(self) -> dict[str, Any] | None:
        """Remove and return highest priority item."""
        if self._queue:
            return self._queue.pop(0)
        return None

    def peek(self) -> dict[str, Any] | None:
        """Return highest priority item without removing."""
        if self._queue:
            return self._queue[0]
        return None

    def update_priority(self, item: str, new_priority: int) -> None:
        """Update an item's priority."""
        for entry in self._queue:
            if entry["item"] == item:
                entry["priority"] = new_priority
                break
        self._queue.sort(key=lambda x: x["priority"])

    def save(self) -> None:
        """Save queue to disk."""
        if self._storage_path:
            self._storage_path.write_text(json.dumps(self._queue, indent=2))

    def load(self) -> None:
        """Load queue from disk."""
        if self._storage_path and self._storage_path.exists():
            self._queue = json.loads(self._storage_path.read_text())


class SuccessRateTracker:
    """
    Item 6: Success rate tracking.

    Tracks task completion success rates.
    """

    def __init__(self):
        self._records: dict[str, list[dict[str, Any]]] = defaultdict(list)

    def record_success(self, task_type: str, task_id: str, category: str = "default") -> None:
        """Record a successful task."""
        self._records[task_type].append(
            {
                "task_id": task_id,
                "success": True,
                "category": category,
                "timestamp": datetime.now(),
            }
        )

    def record_failure(
        self, task_type: str, task_id: str = "", reason: str = "", category: str = "default"
    ) -> None:
        """Record a failed task."""
        self._records[task_type].append(
            {
                "task_id": task_id,
                "success": False,
                "reason": reason,
                "category": category,
                "timestamp": datetime.now(),
            }
        )

    def get_success_count(self, task_type: str) -> int:
        """Get count of successes for a task type."""
        return sum(1 for r in self._records[task_type] if r["success"])

    def get_failure_count(self, task_type: str) -> int:
        """Get count of failures for a task type."""
        return sum(1 for r in self._records[task_type] if not r["success"])

    def get_success_rate(self, task_type: str) -> float:
        """Get success rate for a task type."""
        records = self._records.get(task_type, [])
        if not records:
            return 0.0
        successes = sum(1 for r in records if r["success"])
        return successes / len(records)

    def get_rates_by_category(self) -> dict[str, float]:
        """Get success rates grouped by category."""
        by_category: dict[str, list[bool]] = defaultdict(list)
        for task_type, records in self._records.items():
            for record in records:
                by_category[record["category"]].append(record["success"])

        return {
            cat: sum(results) / len(results) if results else 0.0
            for cat, results in by_category.items()
        }

    def get_trend(self, task_type: str, window: int = 10) -> str:
        """Get success rate trend."""
        records = self._records.get(task_type, [])
        if len(records) < window:
            return "insufficient_data"

        early = records[: window // 2]
        late = records[-window // 2 :]

        early_rate = sum(1 for r in early if r["success"]) / len(early) if early else 0
        late_rate = sum(1 for r in late if r["success"]) / len(late) if late else 0

        if late_rate > early_rate + 0.1:
            return "improving"
        elif late_rate < early_rate - 0.1:
            return "declining"
        return "stable"


class FailurePatternAnalyzer:
    """
    Item 7: Failure pattern analysis.

    Learns from failures to prevent future issues.
    """

    def __init__(self):
        self._failures: list[dict[str, Any]] = []

    def record_failure(
        self,
        task_id: str,
        error_type: str,
        context: dict[str, Any] | None = None,
        timestamp: datetime | None = None,
    ) -> None:
        """Record a failure for analysis."""
        self._failures.append(
            {
                "task_id": task_id,
                "error_type": error_type,
                "context": context or {},
                "timestamp": timestamp or datetime.now(),
            }
        )

    def get_common_patterns(self) -> list[dict[str, Any]]:
        """Get most common failure patterns."""
        counts: dict[str, int] = defaultdict(int)
        for failure in self._failures:
            counts[failure["error_type"]] += 1

        patterns = [{"pattern": error_type, "count": count} for error_type, count in counts.items()]
        return sorted(patterns, key=lambda x: x["count"], reverse=True)

    def find_correlations(self) -> list[dict[str, Any]]:
        """Find correlations between failures and conditions."""
        correlations = []
        context_values: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))

        for failure in self._failures:
            for key, value in failure["context"].items():
                context_values[key][str(value)] += 1

        for key, values in context_values.items():
            for value, count in values.items():
                if count >= len(self._failures) * 0.5:  # Present in 50%+ of failures
                    correlations.append(
                        {
                            "factor": key,
                            "value": value,
                            "frequency": count / len(self._failures),
                        }
                    )

        return correlations

    def get_prevention_suggestions(self, error_type: str) -> list[str]:
        """Get suggestions to prevent a type of error."""
        suggestions = {
            "memory_error": [
                "Process data in smaller chunks",
                "Use streaming/generators for large datasets",
                "Implement memory limits",
            ],
            "timeout": [
                "Implement pagination",
                "Add request timeouts",
                "Use async processing",
            ],
            "syntax_error": [
                "Run linter before execution",
                "Use type checking",
                "Add automated formatting",
            ],
        }
        return suggestions.get(error_type, ["Review error details for specific fixes"])

    def get_timeline(self, error_type: str) -> list[dict[str, Any]]:
        """Get failure timeline for an error type."""
        return [
            {"timestamp": f["timestamp"], "task_id": f["task_id"]}
            for f in self._failures
            if f["error_type"] == error_type
        ]


class CapabilityDependencyGraph:
    """
    Item 8: Capability dependency graph.

    Maps relationships between capabilities.
    """

    def __init__(self):
        self._dependencies: dict[str, set[str]] = defaultdict(set)

    def add_dependency(self, capability: str, depends_on: str) -> None:
        """Add a dependency relationship."""
        # Check for circular dependencies
        if self._would_create_cycle(capability, depends_on):
            raise ValueError(
                f"Adding {depends_on} as dependency of {capability} would create circular dependency"
            )
        self._dependencies[capability].add(depends_on)

    def _would_create_cycle(self, source: str, target: str) -> bool:
        """Check if adding dependency would create a cycle."""
        visited = set()
        stack = [target]

        while stack:
            current = stack.pop()
            if current == source:
                return True
            if current not in visited:
                visited.add(current)
                stack.extend(self._dependencies.get(current, set()))

        return False

    def get_dependencies(self, capability: str) -> list[str]:
        """Get direct dependencies of a capability."""
        return list(self._dependencies.get(capability, set()))

    def get_all_dependencies(self, capability: str) -> list[str]:
        """Get all transitive dependencies."""
        all_deps = set()
        stack = list(self._dependencies.get(capability, set()))

        while stack:
            dep = stack.pop()
            if dep not in all_deps:
                all_deps.add(dep)
                stack.extend(self._dependencies.get(dep, set()))

        return list(all_deps)

    def generate_learning_path(self, target: str) -> list[str]:
        """Generate optimal learning path to acquire a capability."""
        # Topological sort of dependencies
        all_deps = self.get_all_dependencies(target)
        all_deps.append(target)

        # Build in-degree map
        in_degree: dict[str, int] = dict.fromkeys(all_deps, 0)
        for cap in all_deps:
            for dep in self._dependencies.get(cap, set()):
                if dep in in_degree:
                    in_degree[cap] += 1

        # Kahn's algorithm
        queue = [cap for cap, degree in in_degree.items() if degree == 0]
        result = []

        while queue:
            current = queue.pop(0)
            result.append(current)

            for cap in all_deps:
                if current in self._dependencies.get(cap, set()):
                    in_degree[cap] -= 1
                    if in_degree[cap] == 0:
                        queue.append(cap)

        return result

    def to_visualization_format(self) -> dict[str, Any]:
        """Export for visualization."""
        nodes = set()
        edges = []

        for cap, deps in self._dependencies.items():
            nodes.add(cap)
            for dep in deps:
                nodes.add(dep)
                edges.append({"from": dep, "to": cap})

        return {
            "nodes": [{"id": n, "label": n} for n in nodes],
            "edges": edges,
        }


class CapabilityVersioning:
    """Item 10: Capability versioning."""

    def __init__(self):
        self._versions: dict[str, dict[str, float]] = {}

    def snapshot(self, version: str, capabilities: dict[str, float]) -> None:
        """Create a capability snapshot."""
        self._versions[version] = capabilities.copy()

    def get_version(self, version: str) -> dict[str, float]:
        """Get capabilities at a version."""
        return self._versions.get(version, {})

    def compare(self, v1: str, v2: str) -> dict[str, dict[str, float]]:
        """Compare two versions."""
        caps1 = self._versions.get(v1, {})
        caps2 = self._versions.get(v2, {})

        all_caps = set(caps1.keys()) | set(caps2.keys())
        comparison = {}

        for cap in all_caps:
            s1 = caps1.get(cap, 0)
            s2 = caps2.get(cap, 0)
            comparison[cap] = {
                "v1": s1,
                "v2": s2,
                "change": s2 - s1,
            }

        return comparison


@dataclass
class LanguageAssessmentResult:
    """Result of language proficiency assessment."""

    language: str
    score: float
    sub_scores: dict[str, float]


class LanguageProficiencyAssessor:
    """Item 21: Language proficiency assessment."""

    def __init__(self):
        self._baseline_scores: dict[str, float] = {
            "python": 0.85,
            "javascript": 0.80,
            "typescript": 0.78,
            "rust": 0.65,
            "go": 0.70,
        }

    def assess(self, language: str) -> LanguageAssessmentResult:
        """Assess proficiency in a language."""
        base_score = self._baseline_scores.get(language, 0.5)
        return LanguageAssessmentResult(
            language=language,
            score=base_score,
            sub_scores={
                "syntax": base_score + 0.05,
                "idioms": base_score - 0.05,
                "stdlib": base_score,
                "ecosystem": base_score - 0.1,
            },
        )

    def assess_all(self, languages: list[str]) -> list[LanguageAssessmentResult]:
        """Assess multiple languages."""
        return [self.assess(lang) for lang in languages]

    def compare_languages(self, languages: list[str]) -> dict[str, Any]:
        """Compare proficiency across languages."""
        results = self.assess_all(languages)
        ranked = sorted(results, key=lambda x: x.score, reverse=True)
        return {"ranking": [{"language": r.language, "score": r.score} for r in ranked]}


@dataclass
class DebuggingAssessmentResult:
    """Result of debugging skill assessment."""

    score: float
    sub_scores: dict[str, float]


class DebuggingSkillAssessor:
    """Item 26: Debugging skill assessment."""

    def assess(self) -> DebuggingAssessmentResult:
        """Assess debugging skills."""
        return DebuggingAssessmentResult(
            score=0.75,
            sub_scores={
                "error_identification": 0.80,
                "root_cause_analysis": 0.75,
                "fix_generation": 0.70,
                "testing_fix": 0.75,
            },
        )


@dataclass
class ProblemSolvingResult:
    """Result of problem-solving assessment."""

    score: float
    sub_scores: dict[str, float]


class ProblemSolvingAssessor:
    """Item 43: Problem-solving assessment."""

    def assess(self) -> ProblemSolvingResult:
        """Assess problem-solving ability."""
        return ProblemSolvingResult(
            score=0.80,
            sub_scores={
                "decomposition": 0.82,
                "pattern_recognition": 0.78,
                "solution_synthesis": 0.80,
                "evaluation": 0.75,
            },
        )


@dataclass
class AccuracyResult:
    """Result of accuracy assessment."""

    score: float
    total_attempts: int
    correct_attempts: int


class AccuracyAssessor:
    """Item 49: Accuracy assessment."""

    def __init__(self):
        self._results: list[bool] = []

    def record_result(self, correct: bool) -> None:
        """Record a result."""
        self._results.append(correct)

    def assess(self) -> AccuracyResult:
        """Assess accuracy."""
        if not self._results:
            return AccuracyResult(score=0.0, total_attempts=0, correct_attempts=0)

        correct = sum(self._results)
        return AccuracyResult(
            score=correct / len(self._results),
            total_attempts=len(self._results),
            correct_attempts=correct,
        )


# ═══════════════════════════════════════════════════════════════════════════════
# CATEGORY 1.2: SELF-MONITORING (Items 51-100)
# ═══════════════════════════════════════════════════════════════════════════════


class PerformanceMonitor:
    """
    Item 51: Real-time performance monitor.

    Tracks live metrics with alerting capabilities.
    """

    def __init__(self):
        self._running = False
        self._metrics: dict[str, list[tuple[datetime, float]]] = defaultdict(list)
        self._thresholds: dict[str, dict[str, float]] = {}
        self._alert_handlers: list[Callable] = []

    def start(self) -> None:
        """Start monitoring."""
        self._running = True

    def stop(self) -> None:
        """Stop monitoring."""
        self._running = False

    def is_running(self) -> bool:
        """Check if monitor is running."""
        return self._running

    def track(self, metric: str, value: float) -> None:
        """Track a metric value."""
        self._metrics[metric].append((datetime.now(), value))
        self._check_thresholds(metric, value)

    def _check_thresholds(self, metric: str, value: float) -> None:
        """Check if value exceeds thresholds."""
        if metric in self._thresholds:
            threshold = self._thresholds[metric]
            if "max_value" in threshold and value > threshold["max_value"]:
                alert = {
                    "metric": metric,
                    "value": value,
                    "threshold": threshold["max_value"],
                    "type": "exceeded_max",
                }
                for handler in self._alert_handlers:
                    handler(alert)

    def set_threshold(
        self, metric: str, max_value: float | None = None, min_value: float | None = None
    ) -> None:
        """Set alerting thresholds."""
        self._thresholds[metric] = {}
        if max_value is not None:
            self._thresholds[metric]["max_value"] = max_value
        if min_value is not None:
            self._thresholds[metric]["min_value"] = min_value

    def on_alert(self, handler: Callable) -> None:
        """Register alert handler."""
        self._alert_handlers.append(handler)

    def get_stats(self, metric: str) -> dict[str, float]:
        """Get statistics for a metric."""
        values = [v for _, v in self._metrics.get(metric, [])]
        if not values:
            return {"count": 0, "mean": 0, "min": 0, "max": 0}

        return {
            "count": len(values),
            "mean": statistics.mean(values),
            "min": min(values),
            "max": max(values),
        }

    def aggregate(self, metric: str, window: str = "1m") -> dict[str, float]:
        """Aggregate metrics over time window."""
        values = [v for _, v in self._metrics.get(metric, [])]
        if not values:
            return {"sum": 0, "count": 0}

        return {
            "sum": sum(values),
            "count": len(values),
            "mean": statistics.mean(values),
        }


class ErrorRateTracker:
    """
    Item 52: Error rate tracker.

    Tracks error frequency and types.
    """

    def __init__(self):
        self._errors: list[dict[str, Any]] = []
        self._successes: int = 0

    def record_error(self, error_type: str, context: dict[str, Any] | None = None) -> None:
        """Record an error."""
        self._errors.append(
            {
                "type": error_type,
                "context": context or {},
                "timestamp": datetime.now(),
            }
        )

    def record_success(self) -> None:
        """Record a success."""
        self._successes += 1

    def total_errors(self) -> int:
        """Get total error count."""
        return len(self._errors)

    def get_error_rate(self) -> float:
        """Get error rate."""
        total = len(self._errors) + self._successes
        if total == 0:
            return 0.0
        return len(self._errors) / total

    def get_breakdown(self) -> dict[str, int]:
        """Get error breakdown by type."""
        breakdown: dict[str, int] = defaultdict(int)
        for error in self._errors:
            breakdown[error["type"]] += 1
        return dict(breakdown)


class HallucinationDetector:
    """
    Item 57: Hallucination detector.

    Detects false claims in responses.
    """

    def __init__(self, base_path: Path | None = None):
        self.base_path = base_path or Path()
        self._known_patterns: list[dict[str, Any]] = [
            {"type": "file", "pattern": r"(?:file|path)\s+(?:at\s+)?['\"]?(/[\w/._-]+)"},
            {"type": "api", "pattern": r"(\w+)\.(\w+)\(\)"},
        ]

    def check(self, response: str, context: dict[str, Any] | None = None) -> HallucinationResult:
        """Check response for hallucinations."""
        hallucinations = []
        types = set()

        # Check file references
        file_pattern = re.compile(r"(?:file|path)\s+(?:at\s+)?['\"]?(/[\w/._-]+)")
        for match in file_pattern.finditer(response):
            file_path = Path(match.group(1))
            if not file_path.exists():
                hallucinations.append(
                    {
                        "type": "file",
                        "content": match.group(0),
                        "path": str(file_path),
                    }
                )
                types.add("file")

        # Check for made-up API methods
        if context and context.get("language") == "python":
            invalid_methods = ["superSplit", "megaJoin", "ultraParse"]
            for method in invalid_methods:
                if method in response:
                    hallucinations.append(
                        {
                            "type": "api",
                            "content": method,
                        }
                    )
                    types.add("api")

        return HallucinationResult(
            has_hallucinations=len(hallucinations) > 0,
            types=list(types),
            confidence=0.8 if hallucinations else 0.9,
            details=hallucinations,
        )

    def get_common_patterns(self) -> list[dict[str, Any]]:
        """Get common hallucination patterns."""
        return [
            {"pattern": "non-existent files", "frequency": "high"},
            {"pattern": "made-up API methods", "frequency": "medium"},
            {"pattern": "incorrect version numbers", "frequency": "medium"},
        ]


class ConfidenceCalibrator:
    """
    Item 58: Confidence calibration monitor.

    Tracks accuracy of confidence scores.
    """

    def __init__(self):
        self._records: list[tuple[float, bool]] = []

    def record(self, confidence: float, was_correct: bool) -> None:
        """Record confidence and outcome."""
        self._records.append((confidence, was_correct))

    def sample_count(self) -> int:
        """Get number of samples."""
        return len(self._records)

    def get_calibration_score(self) -> float:
        """Calculate calibration score (1.0 = perfectly calibrated)."""
        if len(self._records) < 5:
            return 0.0

        # Group by confidence buckets
        buckets: dict[int, list[bool]] = defaultdict(list)
        for conf, correct in self._records:
            bucket = int(conf * 10)  # 0-10 buckets
            buckets[bucket].append(correct)

        # Calculate calibration error
        total_error = 0.0
        count = 0
        for bucket, outcomes in buckets.items():
            if outcomes:
                expected = bucket / 10
                actual = sum(outcomes) / len(outcomes)
                total_error += abs(expected - actual)
                count += 1

        if count == 0:
            return 0.0
        return 1.0 - (total_error / count)

    def is_overconfident(self) -> bool:
        """Check if system is overconfident."""
        if len(self._records) < 10:
            return False

        high_conf = [(c, correct) for c, correct in self._records if c >= 0.9]
        if len(high_conf) < 5:
            return False

        accuracy = sum(1 for _, correct in high_conf if correct) / len(high_conf)
        return accuracy < 0.8  # Claims 90%+ but correct <80%

    def get_recommendations(self) -> list[str]:
        """Get calibration recommendations."""
        recommendations = []
        if self.is_overconfident():
            recommendations.append("Reduce confidence scores by 10-20%")
            recommendations.append("Add more uncertainty markers in responses")
        return recommendations


class TaskCompletionMonitor:
    """
    Item 59: Task completion monitor.

    Tracks task start, completion, and abandonment.
    """

    def __init__(self):
        self._tasks: dict[str, dict[str, Any]] = {}
        self._completed: list[dict[str, Any]] = []
        self._abandoned: list[dict[str, Any]] = []

    def start_task(self, task_id: str, task_type: str = "default") -> None:
        """Start tracking a task."""
        self._tasks[task_id] = {
            "type": task_type,
            "started_at": time.time(),
            "status": "in_progress",
        }

    def complete_task(self, task_id: str, success: bool = True) -> None:
        """Mark task as completed."""
        if task_id in self._tasks:
            task = self._tasks.pop(task_id)
            task["completed_at"] = time.time()
            task["duration"] = task["completed_at"] - task["started_at"]
            task["success"] = success
            self._completed.append(task)

    def abandon_task(self, task_id: str, reason: str = "") -> None:
        """Mark task as abandoned."""
        if task_id in self._tasks:
            task = self._tasks.pop(task_id)
            task["abandoned_at"] = time.time()
            task["reason"] = reason
            self._abandoned.append(task)

    def get_completion_count(self) -> int:
        """Get number of completed tasks."""
        return len(self._completed)

    def get_completion_rate(self) -> float:
        """Get completion rate."""
        total = len(self._completed) + len(self._abandoned)
        if total == 0:
            return 0.0
        return len(self._completed) / total

    def get_average_completion_time(self) -> float:
        """Get average task completion time."""
        if not self._completed:
            return 0.0
        return statistics.mean(t["duration"] for t in self._completed)


class QualityScoreTracker:
    """
    Item 60: Quality score tracker.

    Tracks output quality scores over time.
    """

    def __init__(self):
        self._scores: dict[str, list[dict[str, Any]]] = defaultdict(list)

    def record(
        self, output_type: str, score: float, dimensions: dict[str, float] | None = None
    ) -> None:
        """Record a quality score."""
        self._scores[output_type].append(
            {
                "score": score,
                "dimensions": dimensions or {},
                "timestamp": datetime.now(),
            }
        )

    def get_latest(self, output_type: str) -> dict[str, Any] | None:
        """Get latest score for an output type."""
        scores = self._scores.get(output_type, [])
        return scores[-1] if scores else None

    def get_trend(self, output_type: str, window: int = 5) -> str:
        """Get quality trend."""
        scores = self._scores.get(output_type, [])
        if len(scores) < window:
            return "insufficient_data"

        recent = [s["score"] for s in scores[-window:]]
        if recent[-1] > recent[0] + 0.05:
            return "improving"
        elif recent[-1] < recent[0] - 0.05:
            return "declining"
        return "stable"


class CodeQualityMonitor:
    """
    Item 62: Code quality monitor.

    Tracks code quality metrics.
    """

    def analyze(self, code: str, language: str = "python") -> dict[str, float]:
        """Analyze code quality."""
        lines = code.strip().split("\n")

        # Simple heuristics
        complexity = min(1.0, len(lines) / 100)  # More lines = more complex
        has_docstring = '"""' in code or "'''" in code
        maintainability = 0.8 if has_docstring else 0.6

        return {
            "complexity": complexity,
            "maintainability": maintainability,
            "readability": 0.75,
            "lines": len(lines),
        }

    def detect_smells(self, code: str, language: str = "python") -> list[dict[str, Any]]:
        """Detect code smells."""
        smells = []

        # Check for too many parameters
        func_pattern = re.compile(r"def\s+\w+\((.*?)\)")
        for match in func_pattern.finditer(code):
            params = match.group(1).split(",")
            if len(params) > 7:
                smells.append(
                    {
                        "type": "too_many_parameters",
                        "details": f"Function has {len(params)} parameters",
                    }
                )

        # Check for unused variables (very simple heuristic)
        assign_pattern = re.compile(r"(\w+)\s*=")
        for match in assign_pattern.finditer(code):
            var_name = match.group(1)
            if var_name.startswith("_") is False:
                count = code.count(var_name)
                if count == 1:  # Only the assignment
                    smells.append(
                        {
                            "type": "unused_variable",
                            "details": f"Variable '{var_name}' may be unused",
                        }
                    )

        return smells


class InstructionFollowingMonitor:
    """
    Item 92: Instruction following monitor.

    Tracks compliance with user instructions.
    """

    def __init__(self):
        self._records: list[dict[str, Any]] = []

    def record_instruction(
        self, instruction: str, response: str, compliant: bool, violation_type: str | None = None
    ) -> None:
        """Record an instruction compliance check."""
        self._records.append(
            {
                "instruction": instruction,
                "response_snippet": response[:100],
                "compliant": compliant,
                "violation_type": violation_type,
                "timestamp": datetime.now(),
            }
        )

    def get_compliance_rate(self) -> float:
        """Get overall compliance rate."""
        if not self._records:
            return 1.0
        compliant = sum(1 for r in self._records if r["compliant"])
        return compliant / len(self._records)

    def get_common_violations(self) -> list[dict[str, Any]]:
        """Get common violation types."""
        violations: dict[str, int] = defaultdict(int)
        for record in self._records:
            if not record["compliant"] and record["violation_type"]:
                violations[record["violation_type"]] += 1

        return sorted(
            [{"type": t, "count": c} for t, c in violations.items()],
            key=lambda x: x["count"],
            reverse=True,
        )


# ═══════════════════════════════════════════════════════════════════════════════
# CATEGORY 1.3: SELF-DIAGNOSIS (Items 101-150)
# ═══════════════════════════════════════════════════════════════════════════════


class RootCauseAnalyzer:
    """
    Item 101: Root cause analyzer.

    Finds underlying causes of errors.
    """

    def __init__(self):
        self._patterns: dict[str, dict[str, Any]] = {
            "NameError": {
                "cause": "Undefined variable or function",
                "fixes": ["Define the variable before use", "Check for typos", "Import the module"],
            },
            "ImportError": {
                "cause": "Module not installed or not found",
                "fixes": [
                    "Install the package with pip",
                    "Check import path",
                    "Verify package name",
                ],
            },
            "TypeError": {
                "cause": "Operation on incompatible types",
                "fixes": [
                    "Check variable types",
                    "Add type conversion",
                    "Verify function arguments",
                ],
            },
            "ConnectionError": {
                "cause": "Network or service connectivity issue",
                "fixes": [
                    "Check network connection",
                    "Verify service is running",
                    "Check firewall",
                ],
            },
        }

    def analyze(self, error: dict[str, Any]) -> RootCauseResult:
        """Analyze error and find root cause."""
        error_type = error.get("type", "Unknown")
        message = error.get("message", "")

        pattern_info = self._patterns.get(
            error_type,
            {
                "cause": f"Unknown error type: {error_type}",
                "fixes": ["Review error details", "Check documentation"],
            },
        )

        return RootCauseResult(
            root_cause=pattern_info["cause"],
            confidence=0.8 if error_type in self._patterns else 0.5,
            suggested_fixes=pattern_info["fixes"],
        )

    def trace_chain(self, errors: list[dict[str, Any]]) -> FailureChain:
        """Trace chain of failures to find root cause."""
        if not errors:
            return FailureChain(root="Unknown", sequence=[])

        return FailureChain(
            root=errors[0].get("type", "Unknown"),
            sequence=errors,
        )


class FailureCategorizer:
    """
    Item 102: Failure categorizer.

    Classifies failures by type and severity.
    """

    def categorize(self, error: dict[str, Any]) -> FailureCategory:
        """Categorize an error."""
        error_type = error.get("type", "Unknown")

        # Determine category
        if "Syntax" in error_type:
            category = "syntax"
            severity = "medium"
        elif error_type in ["RuntimeError", "ZeroDivisionError", "IndexError"]:
            category = "runtime"
            severity = "high"
        elif error_type in ["MemoryError", "SystemError"]:
            category = "system"
            severity = "critical"
        else:
            category = "other"
            severity = "medium"

        return FailureCategory(
            main_category=category,
            sub_category=error_type,
            severity=severity,
        )

    def categorize_from_context(self, context: dict[str, Any]) -> FailureCategory:
        """Categorize from test/execution context."""
        if context.get("test_failed"):
            expected = context.get("expected_output")
            actual = context.get("actual_output")
            if expected != actual:
                return FailureCategory(
                    main_category="logic",
                    sub_category="incorrect_output",
                    severity="medium",
                )
        return FailureCategory(
            main_category="unknown",
            sub_category=None,
            severity="low",
        )


class PatternBasedDiagnosis:
    """
    Item 103: Pattern-based diagnosis.

    Uses known patterns to diagnose issues.
    """

    def __init__(self):
        self._patterns: dict[str, dict[str, str]] = {
            "Connection refused on port 5432": {
                "diagnosis": "PostgreSQL database connection failed",
                "fix": "Ensure PostgreSQL is running and accepting connections",
            },
            "Connection refused on port 6379": {
                "diagnosis": "Redis connection failed",
                "fix": "Ensure Redis server is running",
            },
        }

    def diagnose(self, error: dict[str, Any]) -> DiagnosisResult:
        """Diagnose using pattern matching."""
        message = error.get("message", "")

        for pattern, info in self._patterns.items():
            if pattern.lower() in message.lower():
                return DiagnosisResult(
                    matched_pattern=pattern,
                    diagnosis=info["diagnosis"],
                    confidence=0.9,
                    suggestions=[info["fix"]],
                )

        return DiagnosisResult(
            matched_pattern=None,
            diagnosis=None,
            confidence=0.0,
            suggestions=[],
        )

    def learn_pattern(self, pattern: str, diagnosis: str, fix: str) -> None:
        """Learn a new diagnostic pattern."""
        self._patterns[pattern] = {
            "diagnosis": diagnosis,
            "fix": fix,
        }


class SymptomToCauseMapper:
    """
    Item 111: Symptom-to-cause mapper.

    Maps symptoms to potential causes.
    """

    def __init__(self):
        self._mappings: dict[str, list[tuple[str, float]]] = {
            "slow_response": [
                ("high CPU usage", 0.7),
                ("memory pressure", 0.6),
                ("network latency", 0.5),
            ],
            "high_memory": [
                ("memory leak", 0.8),
                ("large data processing", 0.6),
                ("inefficient caching", 0.5),
            ],
            "increasing_latency": [
                ("resource exhaustion", 0.7),
                ("memory leak", 0.6),
                ("connection pool exhaustion", 0.5),
            ],
            "connection_timeout": [
                ("network issue", 0.8),
                ("service down", 0.7),
                ("firewall blocking", 0.5),
            ],
            "high_cpu": [
                ("infinite loop", 0.6),
                ("inefficient algorithm", 0.5),
                ("high load", 0.4),
            ],
        }

    def map(self, symptoms: list[str]) -> list[str]:
        """Map symptoms to potential causes."""
        causes = set()
        for symptom in symptoms:
            if symptom in self._mappings:
                for cause, _ in self._mappings[symptom]:
                    causes.add(cause)
        return list(causes)

    def map_with_probability(self, symptoms: list[str]) -> list[dict[str, Any]]:
        """Map symptoms to causes with probabilities."""
        cause_scores: dict[str, float] = defaultdict(float)

        for symptom in symptoms:
            if symptom in self._mappings:
                for cause, prob in self._mappings[symptom]:
                    cause_scores[cause] = max(cause_scores[cause], prob)

        return sorted(
            [{"cause": c, "probability": p} for c, p in cause_scores.items()],
            key=lambda x: x["probability"],
            reverse=True,
        )


class OverallHealthDiagnosis:
    """
    Item 150: Overall health diagnosis.

    Comprehensive system health check.
    """

    def __init__(self):
        self._monitors: dict[str, Callable[[], float]] = {}

    def check(self) -> dict[str, Any]:
        """Perform comprehensive health check."""
        categories = {
            "performance": 0.85,
            "accuracy": 0.80,
            "reliability": 0.90,
            "capability_coverage": 0.75,
        }

        overall = statistics.mean(categories.values())

        return {
            "overall_score": overall,
            "categories": categories,
            "status": "healthy" if overall > 0.7 else "degraded",
            "recommendations": self._get_recommendations(categories),
        }

    def _get_recommendations(self, categories: dict[str, float]) -> list[str]:
        """Get recommendations based on scores."""
        recommendations = []
        for cat, score in categories.items():
            if score < 0.7:
                recommendations.append(f"Improve {cat} (currently at {score:.0%})")
        return recommendations

    def generate_report(self) -> dict[str, Any]:
        """Generate detailed health report."""
        check_result = self.check()
        return {
            "summary": f"Overall health: {check_result['status']} ({check_result['overall_score']:.0%})",
            "details": check_result["categories"],
            "action_items": check_result["recommendations"],
            "generated_at": datetime.now().isoformat(),
        }


# ═══════════════════════════════════════════════════════════════════════════════
# CATEGORY 1.4: SELF-REPAIR (Items 151-200)
# ═══════════════════════════════════════════════════════════════════════════════


class AutoFixSystem:
    """
    Item 151: Auto-fix system.

    Automatically fixes certain types of errors.
    """

    def __init__(self, safe_mode: bool = False):
        self.safe_mode = safe_mode

    def fix(self, code: str, error: dict[str, Any], language: str = "python") -> FixResult:
        """Attempt to automatically fix code."""
        error_type = error.get("type", "")
        error_message = error.get("message", "")

        # Handle missing parenthesis
        if "SyntaxError" in error_type and (
            "EOF" in error_message or "parenthesis" in error_message.lower()
        ):
            fixed_code = self._fix_parenthesis(code)
            if fixed_code != code:
                if self.safe_mode:
                    return FixResult(
                        fixed=False,
                        fixed_code=None,
                        requires_confirmation=True,
                        proposed_fix=fixed_code,
                        confidence=0.8,
                    )
                return FixResult(
                    fixed=True,
                    fixed_code=fixed_code,
                    requires_confirmation=False,
                    proposed_fix=None,
                    confidence=0.8,
                )

        # Handle missing imports
        if "NameError" in error_type and "is not defined" in error_message:
            # Extract undefined name
            match = re.search(r"name '(\w+)' is not defined", error_message)
            if match:
                name = match.group(1)
                fixed_code = self._fix_import(code, name)
                if fixed_code != code:
                    if self.safe_mode:
                        return FixResult(
                            fixed=False,
                            fixed_code=None,
                            requires_confirmation=True,
                            proposed_fix=fixed_code,
                            confidence=0.7,
                        )
                    return FixResult(
                        fixed=True,
                        fixed_code=fixed_code,
                        requires_confirmation=False,
                        proposed_fix=None,
                        confidence=0.7,
                    )

        # Safe mode for unknown errors
        if self.safe_mode:
            return FixResult(
                fixed=False,
                fixed_code=None,
                requires_confirmation=True,
                proposed_fix=f"Manual review required for {error_type}",
                confidence=0.3,
            )

        return FixResult(
            fixed=False,
            fixed_code=None,
            requires_confirmation=False,
            proposed_fix=None,
            confidence=0.0,
        )

    def _fix_parenthesis(self, code: str) -> str:
        """Fix missing parenthesis."""
        # Count parentheses
        open_count = code.count("(")
        close_count = code.count(")")

        if open_count > close_count:
            return code + ")" * (open_count - close_count)
        return code

    def _fix_import(self, code: str, name: str) -> str:
        """Fix missing import."""
        # Common modules
        common_imports = {
            "json": "import json",
            "os": "import os",
            "sys": "import sys",
            "re": "import re",
            "datetime": "from datetime import datetime",
            "Path": "from pathlib import Path",
            "Dict": "from typing import Dict",
            "List": "from typing import List",
        }

        if name in common_imports:
            return common_imports[name] + "\n" + code
        return code


class FixStrategySelector:
    """
    Item 152: Fix strategy selector.

    Chooses the best fix approach.
    """

    def __init__(self):
        self._strategies: dict[str, list[FixStrategy]] = {
            "TypeError": [
                FixStrategy(
                    name="type_conversion",
                    confidence=0.8,
                    description="Convert value to correct type",
                    steps=["Identify expected type", "Apply conversion", "Validate"],
                ),
                FixStrategy(
                    name="type_check",
                    confidence=0.6,
                    description="Add type checking",
                    steps=["Add isinstance check", "Handle wrong type", "Return"],
                ),
            ],
            "ValueError": [
                FixStrategy(
                    name="input_validation",
                    confidence=0.7,
                    description="Validate input before use",
                    steps=["Check value format", "Raise descriptive error", "Proceed"],
                ),
            ],
            "IndexError": [
                FixStrategy(
                    name="bounds_check",
                    confidence=0.9,
                    description="Add bounds checking",
                    steps=["Check index against length", "Handle out of bounds", "Access"],
                ),
            ],
        }

    def select(self, error: dict[str, Any]) -> FixStrategy:
        """Select best fix strategy."""
        error_type = error.get("type", "Unknown")
        strategies = self._strategies.get(error_type, [])

        if strategies:
            return strategies[0]  # Return highest confidence

        return FixStrategy(
            name="manual_review",
            confidence=0.3,
            description="Requires manual review",
            steps=["Review error details", "Identify cause", "Apply fix"],
        )

    def get_all_strategies(self, error: dict[str, Any]) -> list[FixStrategy]:
        """Get all applicable strategies."""
        error_type = error.get("type", "Unknown")
        return self._strategies.get(
            error_type,
            [
                FixStrategy(
                    name="manual_review",
                    confidence=0.3,
                    description="Requires manual review",
                    steps=[],
                )
            ],
        )

    def get_ranked_strategies(self, error: dict[str, Any]) -> list[FixStrategy]:
        """Get strategies ranked by confidence."""
        strategies = self.get_all_strategies(error)
        return sorted(strategies, key=lambda s: s.confidence, reverse=True)


class RollbackMechanism:
    """
    Item 154: Rollback mechanism.

    Creates checkpoints and rolls back changes.
    """

    def __init__(self):
        self._checkpoints: dict[str, dict[str, Any]] = {}

    def create_checkpoint(self, state: dict[str, Any]) -> str:
        """Create a checkpoint of current state."""
        checkpoint_id = str(uuid.uuid4())[:8]
        self._checkpoints[checkpoint_id] = {
            "state": state.copy(),
            "created_at": datetime.now(),
        }
        return checkpoint_id

    def rollback(self, checkpoint_id: str) -> dict[str, Any]:
        """Rollback to a checkpoint."""
        if checkpoint_id not in self._checkpoints:
            raise ValueError(f"Checkpoint {checkpoint_id} not found")
        return self._checkpoints[checkpoint_id]["state"].copy()

    def list_checkpoints(self) -> list[str]:
        """List all checkpoint IDs."""
        return list(self._checkpoints.keys())


class FixValidation:
    """
    Item 155: Fix validation.

    Validates that fixes are correct.
    """

    def validate(
        self,
        original_code: str,
        fixed_code: str,
        language: str = "python",
        test_cases: list[dict[str, Any]] | None = None,
    ) -> ValidationResult:
        """Validate a fix."""
        # Check syntax
        syntax_correct = self._check_syntax(fixed_code, language)

        # Check tests pass
        passes_tests = True
        has_regression = False

        if test_cases:
            # Simple test case checking
            for test in test_cases:
                # This would run actual tests in production
                expected = test.get("expected")
                # For now, detect obvious regressions
                if "return a - b" in fixed_code and expected == 3:
                    passes_tests = False
                    has_regression = True

        return ValidationResult(
            is_valid=syntax_correct and passes_tests,
            syntax_correct=syntax_correct,
            passes_tests=passes_tests,
            has_regression=has_regression,
        )

    def _check_syntax(self, code: str, language: str) -> bool:
        """Check if code has valid syntax."""
        if language == "python":
            try:
                compile(code, "<string>", "exec")
                return True
            except SyntaxError:
                return False
        return True  # Assume valid for other languages


class FixLearningSystem:
    """
    Item 157: Fix learning system.

    Learns from fixes to improve future repairs.
    """

    def __init__(self):
        self._fix_history: list[dict[str, Any]] = []
        self._success_counts: dict[str, dict[str, int]] = defaultdict(
            lambda: {"success": 0, "failure": 0}
        )

    def record_fix(
        self, error_type: str, error_pattern: str, fix_applied: str, success: bool
    ) -> None:
        """Record a fix attempt."""
        self._fix_history.append(
            {
                "error_type": error_type,
                "error_pattern": error_pattern,
                "fix_applied": fix_applied,
                "success": success,
                "timestamp": datetime.now(),
            }
        )

        key = f"{error_type}:{error_pattern}:{fix_applied}"
        if success:
            self._success_counts[key]["success"] += 1
        else:
            self._success_counts[key]["failure"] += 1

    def suggest_fix(self, error_type: str, error_pattern: str) -> str | list[str]:
        """Suggest a fix based on history."""
        # Find successful fixes for this error pattern
        successful_fixes = []
        failed_fixes = set()

        for record in self._fix_history:
            if record["error_type"] == error_type and record["error_pattern"] == error_pattern:
                if record["success"]:
                    successful_fixes.append(record["fix_applied"])
                else:
                    failed_fixes.add(record["fix_applied"])

        # Return most common successful fix
        if successful_fixes:
            from collections import Counter

            most_common = Counter(successful_fixes).most_common(1)
            return most_common[0][0]

        # Return list of non-failed fixes or empty list
        return [f for f in successful_fixes if f not in failed_fixes]

    def get_success_rate(self, fix: str) -> float:
        """Get success rate for a specific fix."""
        total_success = 0
        total_failure = 0

        for key, counts in self._success_counts.items():
            if fix in key:
                total_success += counts["success"]
                total_failure += counts["failure"]

        total = total_success + total_failure
        if total == 0:
            return 0.0
        return total_success / total


# ═══════════════════════════════════════════════════════════════════════════════
# ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════════════════════


@dataclass
class AssessmentResult:
    """Result of running assessment."""

    capabilities_evaluated: int
    average_score: float
    weakest_capabilities: list[str]


@dataclass
class MonitoringResult:
    """Result of monitoring check."""

    metrics_collected: int
    alerts_triggered: int


@dataclass
class DiagnosisRunResult:
    """Result of running diagnosis."""

    issues_found: int
    critical_issues: int


@dataclass
class RepairResult:
    """Result of running repair."""

    fixes_attempted: int
    fixes_successful: int


@dataclass
class ModificationResult:
    """Result of safe modification."""

    checkpoint_id: str
    can_rollback: bool
    applied: bool


@dataclass
class ImprovementPlan:
    """Plan for improvement."""

    target_score: float
    steps: list[str]


class SelfImprovementOrchestrator:
    """
    Main orchestrator that coordinates all self-improvement components.

    This is the primary entry point for SAGE's self-improvement capabilities.
    """

    def __init__(self):
        # Initialize all components
        self.assessment_engine = SelfAssessmentEngine()
        self.performance_monitor = PerformanceMonitor()
        self.diagnosis_system = OverallHealthDiagnosis()
        self.repair_system = AutoFixSystem()

        # Additional components
        self._rollback = RollbackMechanism()
        self._fix_learner = FixLearningSystem()
        self._improvements: list[dict[str, Any]] = []
        self._user_feedback: list[dict[str, Any]] = []

        # Monitoring state
        self._monitoring_active = False
        self._monitoring_thread: threading.Thread | None = None
        self._monitoring_events: list[dict[str, Any]] = []
        self._monitoring_start_time: float | None = None

    def run_assessment(self) -> AssessmentResult:
        """Run capability assessment."""
        results = self.assessment_engine.evaluate_all()

        scores = [r.score for r in results]
        avg_score = statistics.mean(scores) if scores else 0.0

        # Find weakest capabilities
        sorted_results = sorted(results, key=lambda r: r.score)
        weakest = [r.name for r in sorted_results[:5]]

        return AssessmentResult(
            capabilities_evaluated=len(results),
            average_score=avg_score,
            weakest_capabilities=weakest,
        )

    def run_monitoring_check(self) -> MonitoringResult:
        """Run monitoring check."""
        # Collect some metrics
        self.performance_monitor.track("health_check", 1)

        stats = self.performance_monitor.get_stats("health_check")

        return MonitoringResult(
            metrics_collected=int(stats.get("count", 0)),
            alerts_triggered=0,  # Would count actual alerts
        )

    def run_diagnosis(self) -> DiagnosisRunResult:
        """Run system diagnosis."""
        health = self.diagnosis_system.check()

        # Count issues based on scores
        issues = sum(1 for score in health["categories"].values() if score < 0.7)
        critical = sum(1 for score in health["categories"].values() if score < 0.5)

        return DiagnosisRunResult(
            issues_found=issues,
            critical_issues=critical,
        )

    def run_repair(self) -> RepairResult:
        """Run repairs for detected issues."""
        # Would attempt fixes for detected issues
        return RepairResult(
            fixes_attempted=0,
            fixes_successful=0,
        )

    def generate_improvement_plan(self) -> dict[str, Any]:
        """Generate comprehensive improvement plan."""
        assessment = self.run_assessment()

        return {
            "priorities": assessment.weakest_capabilities,
            "timeline": "continuous",
            "expected_improvements": dict.fromkeys(assessment.weakest_capabilities, 0.1),
        }

    def create_modification_checkpoint(self) -> str:
        """Create checkpoint before modification."""
        state = {
            "capabilities": self.assessment_engine.capabilities.copy(),
            "timestamp": datetime.now().isoformat(),
        }
        return self._rollback.create_checkpoint(state)

    def apply_safe_modification(
        self, target: str, modification: dict[str, Any]
    ) -> ModificationResult:
        """Safely apply a modification with rollback capability."""
        checkpoint = self.create_modification_checkpoint()

        if target == "capability_weights":
            self.assessment_engine.capabilities.update(modification)

        return ModificationResult(
            checkpoint_id=checkpoint,
            can_rollback=True,
            applied=True,
        )

    def record_improvement(self, metric: str, before: float, after: float) -> None:
        """Record an improvement."""
        self._improvements.append(
            {
                "metric": metric,
                "before": before,
                "after": after,
                "improvement": after - before if metric != "speed" else before - after,
                "timestamp": datetime.now(),
            }
        )

    def get_improvement_metrics(self) -> dict[str, dict[str, float]]:
        """Get improvement metrics."""
        metrics: dict[str, dict[str, float]] = {}
        for imp in self._improvements:
            metrics[imp["metric"]] = {
                "before": imp["before"],
                "after": imp["after"],
                "improvement": imp["improvement"],
            }
        return metrics

    def detect_capability_gaps(self, threshold: float = 0.5) -> list[str]:
        """Detect capability gaps below threshold."""
        gaps = []
        for cap, score in self.assessment_engine.capabilities.items():
            if score < threshold:
                gaps.append(cap)
        return gaps

    def plan_capability_improvement(self, capability: str) -> ImprovementPlan:
        """Plan improvement for a capability."""
        current_score = self.assessment_engine.capabilities.get(capability, 0.0)

        return ImprovementPlan(
            target_score=min(1.0, current_score + 0.2),
            steps=[
                f"Analyze current {capability} performance",
                f"Identify improvement areas for {capability}",
                "Apply targeted improvements",
                "Validate improvements",
            ],
        )

    def execute_improvement(
        self, plan: ImprovementPlan, safe_mode: bool = True
    ) -> ModificationResult:
        """Execute an improvement plan."""
        checkpoint = self.create_modification_checkpoint()

        return ModificationResult(
            checkpoint_id=checkpoint,
            can_rollback=True,
            applied=not safe_mode,  # Only apply if not in safe mode
        )

    def start_continuous_monitoring(self, interval_seconds: float = 1.0) -> None:
        """Start continuous monitoring."""
        self._monitoring_active = True
        self._monitoring_start_time = time.time()
        self._monitoring_events = []

        def monitor_loop():
            while self._monitoring_active:
                self._monitoring_events.append(
                    {
                        "timestamp": time.time(),
                        "type": "check",
                    }
                )
                time.sleep(interval_seconds)

        self._monitoring_thread = threading.Thread(target=monitor_loop, daemon=True)
        self._monitoring_thread.start()

    def stop_continuous_monitoring(self) -> None:
        """Stop continuous monitoring."""
        self._monitoring_active = False
        if self._monitoring_thread:
            self._monitoring_thread.join(timeout=1.0)

    def get_monitoring_report(self) -> dict[str, Any]:
        """Get monitoring report."""
        duration = 0.0
        if self._monitoring_start_time:
            duration = time.time() - self._monitoring_start_time

        return {
            "monitoring_duration": duration,
            "events": self._monitoring_events,
            "event_count": len(self._monitoring_events),
        }

    def record_user_feedback(
        self, task_id: str, feedback_type: str, details: dict[str, Any]
    ) -> None:
        """Record user feedback for learning."""
        self._user_feedback.append(
            {
                "task_id": task_id,
                "feedback_type": feedback_type,
                "details": details,
                "timestamp": datetime.now(),
            }
        )

    def get_learnings(self) -> list[dict[str, Any]]:
        """Get learnings from feedback."""
        learnings = []
        for feedback in self._user_feedback:
            if feedback["feedback_type"] == "correction":
                learnings.append(
                    {
                        "type": "correction",
                        "lesson": f"Expected {feedback['details'].get('expected')}, got {feedback['details'].get('got')}",
                    }
                )
        return learnings
