"""CI/CD monitoring module for SAGE DevOps.

This module provides CI/CD operations including:
- Pipeline status monitoring
- Build triggering
- Test result parsing
- Deployment status

NOTE: This is a stub implementation. Full functionality coming soon.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path


class PipelineStatus(Enum):
    """Status of a CI/CD pipeline."""

    PENDING = auto()
    RUNNING = auto()
    SUCCESS = auto()
    FAILED = auto()
    CANCELLED = auto()
    UNKNOWN = auto()


class JobStatus(Enum):
    """Status of a CI/CD job."""

    PENDING = auto()
    RUNNING = auto()
    SUCCESS = auto()
    FAILED = auto()
    SKIPPED = auto()
    CANCELLED = auto()


@dataclass
class CIJob:
    """A CI/CD job."""

    name: str
    status: JobStatus
    duration_seconds: float | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    logs_url: str | None = None
    error_message: str | None = None


@dataclass
class CIPipeline:
    """A CI/CD pipeline run."""

    id: str
    status: PipelineStatus
    branch: str
    commit_sha: str
    jobs: list[CIJob] = field(default_factory=list)
    started_at: datetime | None = None
    finished_at: datetime | None = None
    url: str | None = None

    @property
    def is_complete(self) -> bool:
        """Check if pipeline is complete."""
        return self.status in (
            PipelineStatus.SUCCESS,
            PipelineStatus.FAILED,
            PipelineStatus.CANCELLED,
        )

    @property
    def failed_jobs(self) -> list[CIJob]:
        """Get list of failed jobs."""
        return [j for j in self.jobs if j.status == JobStatus.FAILED]


@dataclass
class TestResult:
    """A test result."""

    name: str
    passed: bool
    duration_seconds: float | None = None
    error_message: str | None = None
    file_path: str | None = None
    line_number: int | None = None


@dataclass
class TestSummary:
    """Summary of test results."""

    total: int
    passed: int
    failed: int
    skipped: int
    duration_seconds: float | None = None
    results: list[TestResult] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        """Get test success rate as percentage."""
        if self.total == 0:
            return 100.0
        return (self.passed / self.total) * 100


class CICDMonitor:
    """CI/CD monitoring and interaction.

    Provides monitoring and control of CI/CD pipelines.
    Currently supports:
    - GitHub Actions
    - (Future) GitLab CI
    - (Future) CircleCI
    - (Future) Jenkins
    """

    def __init__(
        self,
        repo_path: Path | str | None = None,
        provider: str = "github",
    ):
        """Initialize CI/CD monitor.

        Args:
            repo_path: Path to the repository.
            provider: CI provider ('github', 'gitlab', 'circleci', 'jenkins').
        """
        self.repo_path = Path(repo_path) if repo_path else Path.cwd()
        self.provider = provider
        self._validate_setup()

    def _validate_setup(self) -> None:
        """Validate CI/CD setup."""
        # Check for workflow files
        github_workflows = self.repo_path / ".github" / "workflows"
        gitlab_ci = self.repo_path / ".gitlab-ci.yml"
        circleci = self.repo_path / ".circleci" / "config.yml"

        self.has_github_actions = github_workflows.exists()
        self.has_gitlab_ci = gitlab_ci.exists()
        self.has_circleci = circleci.exists()

    def get_pipelines(self, limit: int = 10) -> list[CIPipeline]:
        """Get recent pipeline runs.

        Args:
            limit: Maximum number of pipelines to return.

        Returns:
            List of recent pipeline runs.
        """
        if self.provider == "github" and self.has_github_actions:
            return self._get_github_pipelines(limit)
        return []

    def _get_github_pipelines(self, limit: int) -> list[CIPipeline]:
        """Get GitHub Actions workflow runs."""
        import json
        import subprocess

        try:
            result = subprocess.run(
                [
                    "gh",
                    "run",
                    "list",
                    "--limit",
                    str(limit),
                    "--json",
                    "databaseId,displayTitle,status,conclusion,headBranch,headSha,createdAt,url",
                ],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True,
            )
            data = json.loads(result.stdout)

            pipelines = []
            for run in data:
                status_map = {
                    "queued": PipelineStatus.PENDING,
                    "in_progress": PipelineStatus.RUNNING,
                    "completed": PipelineStatus.SUCCESS,
                }
                if run.get("conclusion") == "failure":
                    status = PipelineStatus.FAILED
                elif run.get("conclusion") == "cancelled":
                    status = PipelineStatus.CANCELLED
                else:
                    status = status_map.get(run.get("status", ""), PipelineStatus.UNKNOWN)

                pipelines.append(
                    CIPipeline(
                        id=str(run["databaseId"]),
                        status=status,
                        branch=run.get("headBranch", ""),
                        commit_sha=run.get("headSha", "")[:7],
                        url=run.get("url"),
                    )
                )
            return pipelines
        except Exception:
            return []

    def get_pipeline(self, pipeline_id: str) -> CIPipeline | None:
        """Get a specific pipeline by ID.

        Args:
            pipeline_id: The pipeline ID.

        Returns:
            The pipeline, or None if not found.
        """
        if self.provider == "github":
            return self._get_github_pipeline(pipeline_id)
        return None

    def _get_github_pipeline(self, run_id: str) -> CIPipeline | None:
        """Get a specific GitHub Actions workflow run."""
        import json
        import subprocess

        try:
            result = subprocess.run(
                [
                    "gh",
                    "run",
                    "view",
                    run_id,
                    "--json",
                    "databaseId,displayTitle,status,conclusion,headBranch,headSha,createdAt,url,jobs",
                ],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True,
            )
            run = json.loads(result.stdout)

            status_map = {
                "queued": PipelineStatus.PENDING,
                "in_progress": PipelineStatus.RUNNING,
                "completed": PipelineStatus.SUCCESS,
            }
            if run.get("conclusion") == "failure":
                status = PipelineStatus.FAILED
            elif run.get("conclusion") == "cancelled":
                status = PipelineStatus.CANCELLED
            else:
                status = status_map.get(run.get("status", ""), PipelineStatus.UNKNOWN)

            jobs = []
            for job in run.get("jobs", []):
                job_status_map = {
                    "queued": JobStatus.PENDING,
                    "in_progress": JobStatus.RUNNING,
                    "completed": JobStatus.SUCCESS,
                }
                if job.get("conclusion") == "failure":
                    job_status = JobStatus.FAILED
                elif job.get("conclusion") == "skipped":
                    job_status = JobStatus.SKIPPED
                else:
                    job_status = job_status_map.get(job.get("status", ""), JobStatus.PENDING)

                jobs.append(
                    CIJob(
                        name=job.get("name", ""),
                        status=job_status,
                    )
                )

            return CIPipeline(
                id=str(run["databaseId"]),
                status=status,
                branch=run.get("headBranch", ""),
                commit_sha=run.get("headSha", "")[:7],
                jobs=jobs,
                url=run.get("url"),
            )
        except Exception:
            return None

    def get_latest_pipeline(self, branch: str | None = None) -> CIPipeline | None:
        """Get the latest pipeline for a branch.

        Args:
            branch: Branch name. If None, uses current branch.

        Returns:
            The latest pipeline, or None if none found.
        """
        import subprocess

        if branch is None:
            try:
                result = subprocess.run(
                    ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                    cwd=self.repo_path,
                    capture_output=True,
                    text=True,
                    check=True,
                )
                branch = result.stdout.strip()
            except Exception:
                return None

        pipelines = self.get_pipelines(limit=20)
        for p in pipelines:
            if p.branch == branch:
                return p
        return None

    def trigger_pipeline(self, branch: str | None = None) -> CIPipeline | None:
        """Trigger a new pipeline run.

        Args:
            branch: Branch to run on. If None, uses current branch.

        Returns:
            The triggered pipeline, or None if failed.
        """
        import subprocess

        if not self.has_github_actions:
            return None

        try:
            # Get workflow files
            workflows = list((self.repo_path / ".github" / "workflows").glob("*.yml"))
            if not workflows:
                return None

            # Trigger the first workflow (usually CI)
            workflow_file = workflows[0].name
            args = ["gh", "workflow", "run", workflow_file]
            if branch:
                args.extend(["--ref", branch])

            subprocess.run(args, cwd=self.repo_path, check=True, capture_output=True)

            # Return the latest pipeline after a brief delay
            import time

            time.sleep(2)
            return self.get_latest_pipeline(branch)
        except Exception:
            return None

    def cancel_pipeline(self, pipeline_id: str) -> bool:
        """Cancel a running pipeline.

        Args:
            pipeline_id: The pipeline ID.

        Returns:
            True if cancelled successfully.
        """
        import subprocess

        try:
            subprocess.run(
                ["gh", "run", "cancel", pipeline_id],
                cwd=self.repo_path,
                check=True,
                capture_output=True,
            )
            return True
        except Exception:
            return False

    def get_job_logs(self, pipeline_id: str, job_name: str) -> str | None:
        """Get logs for a specific job.

        Args:
            pipeline_id: The pipeline ID.
            job_name: The job name.

        Returns:
            Job logs as string, or None if not found.
        """
        import subprocess

        try:
            result = subprocess.run(
                ["gh", "run", "view", pipeline_id, "--log"],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True,
            )
            # Filter logs for the specific job
            logs = result.stdout
            if job_name:
                lines = []
                in_job = False
                for line in logs.split("\n"):
                    if job_name in line:
                        in_job = True
                    if in_job:
                        lines.append(line)
                        if line.strip() == "" and len(lines) > 1:
                            break
                return "\n".join(lines) if lines else logs
            return logs
        except Exception:
            return None

    def parse_test_results(self, pipeline_id: str) -> TestSummary | None:
        """Parse test results from a pipeline.

        Args:
            pipeline_id: The pipeline ID.

        Returns:
            Test summary, or None if not available.
        """
        logs = self.get_job_logs(pipeline_id, "test")
        if not logs:
            return None

        # Parse pytest-style output
        import re

        results: list[TestResult] = []
        total = passed = failed = skipped = 0

        # Look for pytest summary line: "X passed, Y failed, Z skipped"
        summary_match = re.search(r"(\d+) passed", logs)
        if summary_match:
            passed = int(summary_match.group(1))

        summary_match = re.search(r"(\d+) failed", logs)
        if summary_match:
            failed = int(summary_match.group(1))

        summary_match = re.search(r"(\d+) skipped", logs)
        if summary_match:
            skipped = int(summary_match.group(1))

        total = passed + failed + skipped

        # Parse individual test failures
        failure_pattern = re.compile(r"FAILED (.+?)(?:\s|$)")
        for match in failure_pattern.finditer(logs):
            results.append(
                TestResult(
                    name=match.group(1),
                    passed=False,
                )
            )

        return TestSummary(
            total=total,
            passed=passed,
            failed=failed,
            skipped=skipped,
            results=results,
        )

    def get_workflow_files(self) -> list[Path]:
        """Get list of CI workflow files."""
        files: list[Path] = []

        if self.has_github_actions:
            workflows_dir = self.repo_path / ".github" / "workflows"
            files.extend(workflows_dir.glob("*.yml"))
            files.extend(workflows_dir.glob("*.yaml"))

        if self.has_gitlab_ci:
            files.append(self.repo_path / ".gitlab-ci.yml")

        if self.has_circleci:
            files.append(self.repo_path / ".circleci" / "config.yml")

        return files

    def validate_workflow(self, workflow_path: Path) -> list[str]:
        """Validate a workflow file.

        Args:
            workflow_path: Path to the workflow file.

        Returns:
            List of validation errors (empty if valid).
        """
        # Stub implementation - basic YAML validation
        errors = []

        if not workflow_path.exists():
            errors.append(f"Workflow file not found: {workflow_path}")
            return errors

        try:
            import yaml

            with open(workflow_path) as f:
                yaml.safe_load(f)
        except ImportError:
            pass  # YAML module not available
        except Exception as e:
            errors.append(f"Invalid YAML: {e}")

        return errors
