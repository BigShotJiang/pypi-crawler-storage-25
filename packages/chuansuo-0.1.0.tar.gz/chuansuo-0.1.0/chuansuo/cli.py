"""Command-line interface for chuansuo video loop tool."""

import argparse
import json
import logging
import sys

from .__version__ import __version__
from .api import chuansuo_make_loop

logger = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser."""
    parser = argparse.ArgumentParser(
        prog="chuansuo",
        description="Make videos seamlessly loopable or sort frames by similarity",
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose output",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default=None,
        help="Output video path (default: input_loop.mp4 or input_sorted.mp4)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output result as JSON",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Suppress non-essential output",
    )
    parser.add_argument(
        "-m",
        "--mode",
        type=str,
        default="loop",
        choices=["loop", "similarity", "compress"],
        help="Processing mode: loop (seamless loop), similarity (sort by similarity), "
        "or compress (lossless delta compression)",
    )
    parser.add_argument(
        "--smooth-audio",
        action="store_true",
        help="Apply crossfade between audio segments to avoid tearing",
    )
    parser.add_argument(
        "--audio-fade-ms",
        type=float,
        default=50.0,
        help="Crossfade duration in milliseconds (default: 50ms)",
    )
    parser.add_argument(
        "--keep-audio",
        action="store_true",
        help="Keep original audio track unchanged (do not reorder)",
    )
    parser.add_argument(
        "input",
        type=str,
        help="Input video file path",
    )
    return parser


def run_cli(argv: list[str] | None = None) -> int:
    """Run the CLI entry point.

    Args:
        argv: Command line arguments (defaults to sys.argv[1:]).

    Returns:
        Exit code (0 for success, 1 for error, 2 for invalid args).
    """
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.quiet:
        logging.getLogger().setLevel(logging.WARNING)
    elif args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    result = chuansuo_make_loop(
        input_path=args.input,
        output_path=args.output,
        verbose=args.verbose and not args.quiet,
        mode=args.mode,
        smooth_audio=args.smooth_audio,
        audio_fade_ms=args.audio_fade_ms,
        keep_audio=args.keep_audio,
    )

    if args.json_output:
        print(json.dumps(result.to_dict(), indent=2, ensure_ascii=False))
    elif not args.quiet:
        if result.success:
            print(f"Success! Output: {result.data['output_path']}")
            print(f"  Input frames: {result.data['input_frames']}")
            print(f"  Output frames: {result.data['output_frames']}")
        else:
            print(f"Error: {result.error}", file=sys.stderr)

    return 0 if result.success else 1


if __name__ == "__main__":
    sys.exit(run_cli())
