"""OpenAI function-calling tools for chuansuo."""

import json
from typing import Any

TOOLS: list[dict] = [
    {
        "type": "function",
        "function": {
            "name": "chuansuo_make_loop",
            "description": "Make a video seamlessly loopable or sort frames by similarity. "
            "Loop mode: reorders frames so video ends at frame 0 for seamless looping. "
            "Similarity mode: sorts frames from first frame by decreasing similarity.",
            "parameters": {
                "type": "object",
                "properties": {
                    "input_path": {
                        "type": "string",
                        "description": "Path to the input video file",
                    },
                    "output_path": {
                        "type": "string",
                        "description": "Path to the output video file. "
                        "Defaults to input_loop.mp4 or input_sorted.mp4",
                    },
                    "verbose": {
                        "type": "boolean",
                        "description": "Whether to print progress information",
                        "default": False,
                    },
                    "mode": {
                        "type": "string",
                        "description": "Processing mode: 'loop' for seamless loop, "
                        "'similarity' for similarity-based ordering, "
                        "'compress' for lossless delta compression",
                        "default": "loop",
                        "enum": ["loop", "similarity", "compress"],
                    },
                    "smooth_audio": {
                        "type": "boolean",
                        "description": "Apply crossfade between audio segments "
                        "to avoid tearing/clicking sounds",
                        "default": False,
                    },
                    "audio_fade_ms": {
                        "type": "number",
                        "description": "Crossfade duration in milliseconds",
                        "default": 50.0,
                    },
                    "keep_audio": {
                        "type": "boolean",
                        "description": "Keep original audio track unchanged "
                        "(do not reorder audio segments)",
                        "default": False,
                    },
                },
                "required": ["input_path"],
            },
        },
    },
]


def dispatch(name: str, arguments: dict[str, Any] | str) -> dict:
    """Dispatch tool call to the appropriate API function.

    Args:
        name: The function name to dispatch.
        arguments: Function arguments as dict or JSON string.

    Returns:
        Result dictionary from the API function.
    """
    if isinstance(arguments, str):
        arguments = json.loads(arguments)

    if name == "chuansuo_make_loop":
        from .api import chuansuo_make_loop

        result = chuansuo_make_loop(**arguments)
        return result.to_dict()

    raise ValueError(f"Unknown tool: {name}")
