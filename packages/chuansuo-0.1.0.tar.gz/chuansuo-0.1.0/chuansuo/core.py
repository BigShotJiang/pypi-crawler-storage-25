"""Core video processing logic for creating loopable videos."""

import json
import subprocess
import zlib
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np


@dataclass
class VideoInfo:
    """Metadata about a video file."""

    width: int
    height: int
    fps: float
    total_frames: int
    codec: str = "mp4v"
    has_audio: bool = False


def extract_frames(input_path: Path) -> tuple[list[np.ndarray], VideoInfo]:
    """Extract all frames from a video file.

    Args:
        input_path: Path to the input video file.

    Returns:
        Tuple of (list of frames as numpy arrays, VideoInfo metadata).
    """
    cap = cv2.VideoCapture(str(input_path))
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {input_path}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    frames: list[np.ndarray] = []
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)

    cap.release()

    info = VideoInfo(
        width=width,
        height=height,
        fps=fps,
        total_frames=len(frames),
    )
    return frames, info


def reorder_frames_for_loop(frames: list[np.ndarray]) -> list[np.ndarray]:
    """Reorder frames to create a seamless loop without changing duration.

    Algorithm:
    1. Split frames into odd-indexed and even-indexed groups
    2. Output: odd frames first, then reversed even frames

    Example for 10 frames [0,1,2,3,4,5,6,7,8,9]:
    - Odd: [1, 3, 5, 7, 9]
    - Even reversed: [8, 6, 4, 2, 0]
    - Result: [1, 3, 5, 7, 9, 8, 6, 4, 2, 0]

    The video ends at frame 0, enabling seamless looping back to 1.
    Total frame count is unchanged - same duration as original.

    Args:
        frames: List of original frames in order.

    Returns:
        Reordered frames for seamless looping (same count as input).
    """
    odd_frames = [frames[i] for i in range(1, len(frames), 2)]
    even_frames = [frames[i] for i in range(0, len(frames), 2)]
    return odd_frames + even_frames[::-1]


def compute_frame_similarity(frame1: np.ndarray, frame2: np.ndarray) -> float:
    """Compute similarity between two frames using histogram comparison.

    Args:
        frame1: First frame as numpy array.
        frame2: Second frame as numpy array.

    Returns:
        Similarity score between 0 and 1 (1 = identical).
    """
    hist1 = cv2.calcHist([frame1], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    hist2 = cv2.calcHist([frame2], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    cv2.normalize(hist1, hist1, 0, 1, cv2.NORM_MINMAX)
    cv2.normalize(hist2, hist2, 0, 1, cv2.NORM_MINMAX)
    return float(cv2.compareHist(hist1, hist2, cv2.HISTCMP_CORREL))


def compute_frame_histogram(frame: np.ndarray) -> np.ndarray:
    """Compute normalized histogram for a frame.

    Args:
        frame: Frame as numpy array.

    Returns:
        Normalized histogram array.
    """
    hist = cv2.calcHist([frame], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    cv2.normalize(hist, hist, 0, 1, cv2.NORM_MINMAX)
    return hist


def similarity_from_histograms(hist1: np.ndarray, hist2: np.ndarray) -> float:
    """Compute similarity from precomputed histograms.

    Args:
        hist1: First normalized histogram.
        hist2: Second normalized histogram.

    Returns:
        Similarity score between 0 and 1.
    """
    return float(cv2.compareHist(hist1, hist2, cv2.HISTCMP_CORREL))


def compute_frame_entropy(frame: np.ndarray) -> float:
    """Compute Shannon entropy of a grayscale frame.

    Higher entropy = more information/complexity.

    Args:
        frame: Frame as numpy array.

    Returns:
        Shannon entropy value in bits.
    """
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if len(frame.shape) == 3 else frame
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
    hist = hist.flatten()
    hist = hist / hist.sum()
    hist = hist[hist > 0]
    return float(-np.sum(hist * np.log2(hist)))


def compute_frame_diff(frame1: np.ndarray, frame2: np.ndarray) -> float:
    """Compute mean absolute difference between two frames.

    Args:
        frame1: First frame.
        frame2: Second frame.

    Returns:
        Mean absolute pixel difference.
    """
    return float(np.mean(np.abs(frame1.astype(np.int16) - frame2.astype(np.int16))))


def reorder_frames_by_entropy(
    frames: list[np.ndarray],
    verbose: bool = False,
) -> tuple[list[np.ndarray], list[int]]:
    """Reorder frames using greedy TSP to minimize entropy increase.

    Algorithm:
    1. Start with first frame
    2. Find the unused frame with minimum pixel difference
    3. Add it and repeat until all frames are used

    This minimizes inter-frame changes, maximizing compression.

    Args:
        frames: List of original frames.
        verbose: Whether to print progress.

    Returns:
        Tuple of (reordered frames, index mapping).
    """
    if len(frames) <= 2:
        return frames, list(range(len(frames)))

    n = len(frames)
    used = [False] * n
    order = [0]
    used[0] = True
    current_frame = frames[0]
    total_diff = 0.0

    if verbose:
        print("  Reordering by minimum entropy increase (greedy TSP)...")

    for step in range(1, n):
        best_idx = -1
        best_diff = float("inf")

        for j in range(n):
            if not used[j]:
                diff = compute_frame_diff(current_frame, frames[j])
                if diff < best_diff:
                    best_diff = diff
                    best_idx = j

        order.append(best_idx)
        used[best_idx] = True
        current_frame = frames[best_idx]
        total_diff += best_diff

        if verbose and step % 50 == 0:
            avg_diff = total_diff / step
            print(f"    Progress: {step}/{n}, avg diff: {avg_diff:.2f}")

    if verbose:
        print(f"  Total diff: {total_diff:.2f} (avg: {total_diff/(n-1):.2f})")

    return [frames[i] for i in order], order


@dataclass
class DeltaFrame:
    """Represents a delta-encoded frame."""

    key_frame: bool
    data: bytes = b""
    width: int = 0
    height: int = 0

    def to_dict(self) -> dict:
        return {
            "key_frame": self.key_frame,
            "data_size": len(self.data),
            "width": self.width,
            "height": self.height,
        }


def encode_delta_frames(
    frames: list[np.ndarray],
    verbose: bool = False,
) -> tuple[np.ndarray, list[DeltaFrame]]:
    """Encode frames using delta compression.

    First frame is key frame (PNG lossless).
    Subsequent frames store only changed pixels.

    Args:
        frames: List of frames in order.
        verbose: Whether to print progress.

    Returns:
        Tuple of (key_frame_bytes, list of DeltaFrame).
    """
    if not frames:
        raise ValueError("No frames to encode")

    n = len(frames)
    height, width = frames[0].shape[:2]

    _, key_frame_bytes = cv2.imencode(".png", frames[0])
    key_frame = np.frombuffer(key_frame_bytes, dtype=np.uint8)

    deltas: list[DeltaFrame] = []
    total_original = 0
    total_compressed = 0

    if verbose:
        print("  Encoding delta frames...")

    for i in range(1, n):
        prev = frames[i - 1]
        curr = frames[i]

        diff = np.abs(curr.astype(np.int16) - prev.astype(np.int16))
        changed_mask = np.any(diff > 0, axis=2)

        if not np.any(changed_mask):
            delta = DeltaFrame(
                key_frame=False,
                data=b"",
                width=width,
                height=height,
            )
        else:
            changed_indices = np.argwhere(changed_mask)
            rows = changed_indices[:, 0].astype(np.uint16)
            cols = changed_indices[:, 1].astype(np.uint16)
            values = curr[changed_mask]

            packed = np.concatenate([
                rows.tobytes(),
                cols.tobytes(),
                values.tobytes(),
            ])
            compressed = zlib.compress(packed, level=9)

            delta = DeltaFrame(
                key_frame=False,
                data=bytes(compressed),
                width=width,
                height=height,
            )

        deltas.append(delta)
        total_original += curr.nbytes
        total_compressed += len(delta.data)

        if verbose and i % 50 == 0:
            ratio = total_compressed / max(total_original, 1) * 100
            print(f"    Frame {i}/{n}: ratio {ratio:.1f}%")

    if verbose:
        key_size = len(key_frame)
        delta_size = sum(len(d.data) for d in deltas)
        original_total = n * frames[0].nbytes
        compressed_total = key_size + delta_size
        ratio = compressed_total / max(original_total, 1) * 100
        print(f"  Key frame: {key_size / 1024:.1f} KB")
        print(f"  Delta data: {delta_size / 1024:.1f} KB")
        print(f"  Compression: {ratio:.1f}% of original")

    return key_frame, deltas


def decode_delta_frames(
    key_frame: np.ndarray,
    deltas: list[DeltaFrame],
) -> list[np.ndarray]:
    """Reconstruct frames from key frame and deltas (lossless).

    Args:
        key_frame: First frame as PNG-encoded bytes.
        deltas: List of DeltaFrame objects.

    Returns:
        Reconstructed list of frames.
    """
    reconstructed = cv2.imdecode(key_frame, cv2.IMREAD_COLOR)
    frames = [reconstructed.copy()]

    for delta in deltas:
        if delta.data == b"":
            frames.append(frames[-1].copy())
        else:
            packed = zlib.decompress(delta.data)
            n_pixels = len(packed) // 7  # 2 + 2 + 3 bytes per pixel
            row_size = n_pixels * 2
            col_size = n_pixels * 2

            rows = np.frombuffer(packed[:row_size], dtype=np.uint16)
            cols = np.frombuffer(packed[row_size:row_size + col_size], dtype=np.uint16)
            pixels = np.frombuffer(
                packed[row_size + col_size:],
                dtype=np.uint8,
            ).reshape(n_pixels, 3)

            prev = frames[-1].copy()
            prev[rows, cols] = pixels
            frames.append(prev)

    return frames


def reorder_frames_by_similarity(
    frames: list[np.ndarray],
    verbose: bool = False,
) -> list[np.ndarray]:
    """Reorder frames by similarity using greedy nearest-neighbor algorithm.

    Algorithm:
    1. Keep first frame as starting point
    2. Find the most similar unused frame to the current frame
    3. Add it to the result and repeat until all frames are used

    This creates a smooth visual transition from frame to frame,
    ending at the most dissimilar frame.

    Args:
        frames: List of original frames in order.
        verbose: Whether to print progress information.

    Returns:
        Reordered frames sorted by similarity (same count as input).
    """
    if len(frames) <= 2:
        return frames

    n = len(frames)

    if verbose:
        print("  Computing frame histograms...")

    histograms = [compute_frame_histogram(frame) for frame in frames]

    if verbose:
        print("  Sorting frames by similarity (greedy nearest-neighbor)...")

    used = [False] * n
    order = [0]
    used[0] = True
    current_hist = histograms[0]

    for step in range(1, n):
        best_idx = -1
        best_score = -2

        for j in range(n):
            if not used[j]:
                score = similarity_from_histograms(current_hist, histograms[j])
                if score > best_score:
                    best_score = score
                    best_idx = j

        order.append(best_idx)
        used[best_idx] = True
        current_hist = histograms[best_idx]

        if verbose and step % 50 == 0:
            print(f"    Progress: {step}/{n} frames sorted")

    return [frames[i] for i in order]


def write_video(
    output_path: Path,
    frames: list[np.ndarray],
    video_info: VideoInfo,
) -> None:
    """Write frames to a video file without audio.

    Args:
        output_path: Path to the output video file.
        frames: List of frames to write.
        video_info: Video metadata (fps, dimensions, codec).
    """
    if not frames:
        raise ValueError("No frames to write")

    fourcc = cv2.VideoWriter_fourcc(*video_info.codec)
    out = cv2.VideoWriter(
        str(output_path),
        fourcc,
        video_info.fps,
        (video_info.width, video_info.height),
    )

    for frame in frames:
        out.write(frame)

    out.release()


def extract_audio(input_path: Path, tmp_dir: Path) -> Path | None:
    """Extract audio from video file.

    Args:
        input_path: Path to the input video file.
        tmp_dir: Temporary directory for intermediate files.

    Returns:
        Path to extracted audio file, or None if no audio.
    """

    audio_path = tmp_dir / "audio.wav"
    cmd = [
        "ffmpeg",
        "-i",
        str(input_path),
        "-vn",
        "-acodec",
        "pcm_s16le",
        "-y",
        str(audio_path),
    ]
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=300,
    )
    if result.returncode != 0:
        return None

    if not audio_path.exists() or audio_path.stat().st_size < 1000:
        return None

    return audio_path


def split_audio_by_frames(
    audio_path: Path,
    fps: float,
    num_frames: int,
) -> list:
    """Split audio into segments aligned with video frames.

    Each segment duration = 1000/fps milliseconds.
    Uses exact sample-level precision to avoid drift.

    Args:
        audio_path: Path to the audio file.
        fps: Video frames per second.
        num_frames: Number of video frames.

    Returns:
        List of AudioSegment objects, one per frame.
    """
    from pydub import AudioSegment

    audio = AudioSegment.from_wav(str(audio_path))
    frame_duration_ms = 1000.0 / fps
    sample_rate = audio.frame_rate

    segments = []
    for i in range(num_frames):
        start_ms = i * frame_duration_ms
        end_ms = (i + 1) * frame_duration_ms

        start_sample = int(start_ms * sample_rate / 1000)
        end_sample = int(end_ms * sample_rate / 1000)

        segment = audio[start_sample:end_sample]
        segments.append(segment)

    return segments


def reorder_audio_for_loop(
    segments: list,
) -> list:
    """Reorder audio segments to match video frame reordering.

    Algorithm mirrors video: odd segments + reversed even segments.
    Total segment count is unchanged.

    Args:
        segments: List of audio segments aligned with frames.

    Returns:
        Reordered audio segments (same count as input).
    """
    odd_segments = [segments[i] for i in range(1, len(segments), 2)]
    even_segments = [segments[i] for i in range(0, len(segments), 2)]
    return odd_segments + even_segments[::-1]


def reorder_audio_by_similarity(
    segments: list,
    frame_order: list[int],
) -> list:
    """Reorder audio segments to match similarity-based frame ordering.

    Args:
        segments: List of audio segments aligned with frames.
        frame_order: List of indices representing the new frame order.

    Returns:
        Reordered audio segments matching the frame order.
    """
    return [segments[i] for i in frame_order]


def concatenate_audio(
    segments: list,
    output_path: Path,
    smooth: bool = False,
    fade_ms: float = 50.0,
) -> None:
    """Concatenate audio segments into a single file.

    Args:
        segments: List of AudioSegment objects.
        output_path: Path for the output audio file.
        smooth: Whether to apply crossfade between segments
            to avoid audio tearing/clicking.
        fade_ms: Duration of crossfade in milliseconds (default 50ms).
    """
    from pydub import AudioSegment

    if not smooth or len(segments) <= 1:
        combined = segments[0]
        for seg in segments[1:]:
            combined += seg
    else:
        fade_ms = min(fade_ms, len(segments[0]) / 2)
        combined = segments[0]
        for seg in segments[1:]:
            combined = combined.append(
                seg,
                crossfade=int(fade_ms),
            )

    combined.export(str(output_path), format="wav")


def merge_audio_video(
    video_path: Path,
    audio_path: Path,
    output_path: Path,
) -> None:
    """Merge audio and video into a single file.

    Args:
        video_path: Path to video file (no audio).
        audio_path: Path to audio file.
        output_path: Path for the merged output.
    """
    cmd = [
        "ffmpeg",
        "-i",
        str(video_path),
        "-i",
        str(audio_path),
        "-c:v",
        "libx264",
        "-preset",
        "fast",
        "-crf",
        "23",
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        "-map",
        "0:v:0",
        "-map",
        "1:a:0",
        "-y",
        str(output_path),
    ]
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=300,
    )
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg merge failed: {result.stderr}")


def process_video(
    input_path: Path,
    output_path: Path,
    verbose: bool = False,
    mode: str = "loop",
    smooth_audio: bool = False,
    audio_fade_ms: float = 50.0,
    keep_audio: bool = False,
) -> dict:
    """Process a video to make it seamlessly loopable or sort by similarity.

    Both video frames and audio are reordered using the same
    algorithm so they stay in sync.

    Args:
        input_path: Path to the input video.
        output_path: Path to the output video.
        verbose: Whether to print progress information.
        mode: Processing mode - "loop" for seamless loop,
              "similarity" for similarity-based ordering,
              "compress" for lossless delta compression.
        smooth_audio: Whether to apply crossfade between audio segments
            to avoid tearing/clicking sounds.
        audio_fade_ms: Crossfade duration in milliseconds (default 50ms).
        keep_audio: If True, keep the original audio track unchanged
            (do not reorder audio segments).

    Returns:
        Dictionary with processing metadata.
    """
    import tempfile as _tempfile

    if verbose:
        print(f"Reading video: {input_path}")

    frames, info = extract_frames(input_path)

    if verbose:
        print(f"  Frames: {info.total_frames}")
        print(f"  Resolution: {info.width}x{info.height}")
        print(f"  FPS: {info.fps}")

    with _tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)

        # Process audio if present
        audio_path = extract_audio(input_path, tmp)
        has_audio = audio_path is not None
        info.has_audio = has_audio

        if has_audio and not keep_audio:
            if verbose:
                print("  Extracting audio...")

            audio_segments = split_audio_by_frames(
                audio_path,
                info.fps,
                info.total_frames,
            )

        # Process video frames based on mode
        if mode == "compress":
            if verbose:
                print("  Compressing with delta encoding...")

            reordered_frames, frame_order = reorder_frames_by_entropy(
                frames, verbose=verbose,
            )
            key_frame, deltas = encode_delta_frames(
                reordered_frames, verbose=verbose,
            )

            # Verify lossless reconstruction
            reconstructed = decode_delta_frames(key_frame, deltas)
            assert len(reconstructed) == len(frames)
            for i, (orig, recon) in enumerate(zip(reordered_frames, reconstructed)):
                assert np.array_equal(orig, recon), f"Frame {i} mismatch!"

            if has_audio and not keep_audio:
                reordered_audio = reorder_audio_by_similarity(audio_segments, frame_order)

            output_frames = reconstructed

        elif mode == "similarity":
            if verbose:
                print("  Reordering frames by similarity...")

            reordered_frames = reorder_frames_by_similarity(frames, verbose=verbose)
            frame_order = list(range(info.total_frames))
            n = len(frames)
            used = [False] * n
            frame_order = [0]
            used[0] = True
            for step in range(1, n):
                current_idx = frame_order[-1]
                current_frame = frames[current_idx]
                best_idx = -1
                best_score = -2
                for j in range(n):
                    if not used[j]:
                        score = compute_frame_similarity(current_frame, frames[j])
                        if score > best_score:
                            best_score = score
                            best_idx = j
                frame_order.append(best_idx)
                used[best_idx] = True

            if has_audio and not keep_audio:
                reordered_audio = reorder_audio_by_similarity(audio_segments, frame_order)

            output_frames = reordered_frames

        else:
            if verbose:
                print("  Reordering frames for loop...")

            reordered_frames = reorder_frames_for_loop(frames)
            if has_audio and not keep_audio:
                reordered_audio = reorder_audio_for_loop(audio_segments)

            output_frames = reordered_frames

        if verbose:
            print(f"  Output frames: {len(output_frames)} (same as input)")
            if keep_audio and has_audio:
                print("  Audio: keeping original track (not reordered)")
            elif smooth_audio and has_audio:
                print(f"  Audio smoothing: enabled (fade={audio_fade_ms}ms)")
            print(f"Writing output: {output_path}")

        # Write video without audio first
        video_only_path = tmp / "video_only.mp4"
        write_video(video_only_path, output_frames, info)

        # Merge with audio if available
        if has_audio:
            looped_audio_path = tmp / "looped_audio.wav"
            if keep_audio:
                import shutil
                shutil.copy2(audio_path, looped_audio_path)
            else:
                concatenate_audio(
                    reordered_audio,
                    looped_audio_path,
                    smooth=smooth_audio,
                    fade_ms=audio_fade_ms,
                )
            merge_audio_video(video_only_path, looped_audio_path, output_path)
        else:
            import shutil
            shutil.copy2(video_only_path, output_path)

    if verbose:
        print("  Done!")

    return {
        "input_frames": info.total_frames,
        "output_frames": len(output_frames),
        "resolution": f"{info.width}x{info.height}",
        "fps": info.fps,
        "has_audio": has_audio,
        "mode": mode,
        "smooth_audio": smooth_audio,
        "keep_audio": keep_audio,
        "output_path": str(output_path),
    }
