"""Python API for chuansuo video loop tool."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class ToolResult:
    """Standard result wrapper for API functions."""

    success: bool
    data: Any = None
    error: Optional[str] = None
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "metadata": self.metadata,
        }


def chuansuo_make_loop(
    *,
    input_path: str | Path,
    output_path: str | Path | None = None,
    verbose: bool = False,
    mode: str = "loop",
    smooth_audio: bool = False,
    audio_fade_ms: float = 50.0,
    keep_audio: bool = False,
) -> ToolResult:
    """Make a video seamlessly loopable or sort frames by similarity.

    Args:
        input_path: Path to the input video file.
        output_path: Path to the output video file. Defaults to
            input_path with '_loop' suffix.
        verbose: Whether to print progress information.
        mode: Processing mode - "loop" for seamless loop,
              "similarity" for similarity-based ordering.
        smooth_audio: Whether to apply crossfade between audio segments
            to avoid tearing/clicking sounds.
        audio_fade_ms: Crossfade duration in milliseconds (default 50ms).
        keep_audio: If True, keep the original audio track unchanged
            (do not reorder audio segments).

    Returns:
        ToolResult with success status and processing metadata.
    """
    from .__version__ import __version__
    from .core import process_video

    input_path = Path(input_path)

    if output_path is None:
        suffix = "_sorted" if mode == "similarity" else "_loop"
        output_path = input_path.parent / f"{input_path.stem}{suffix}{input_path.suffix}"
    else:
        output_path = Path(output_path)

    try:
        result = process_video(
            input_path,
            output_path,
            verbose=verbose,
            mode=mode,
            smooth_audio=smooth_audio,
            audio_fade_ms=audio_fade_ms,
            keep_audio=keep_audio,
        )
        return ToolResult(
            success=True,
            data=result,
            metadata={"version": __version__},
        )
    except Exception as e:
        return ToolResult(success=False, error=str(e))
