from blends.ctx import ctx
from blends.models import NId
from blends.stack.scope_types import ScopeType
from blends.syntax.builders.utils import (
    enter_scope_stack,
    exit_scope_stack_if_current,
    setup_stack_graph_definition,
)
from blends.syntax.models import SyntaxGraphArgs


def build_declaration_node(
    args: SyntaxGraphArgs,
    name: str,
    block_id: NId | None,
    access_modifiers: str | None = None,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        name=name,
        block_id=block_id,
        label_type="Declaration",
        **({"access_modifiers": access_modifiers} if access_modifiers else {}),
    )

    if ctx.has_feature_flag("StackGraph"):
        setup_stack_graph_definition(args, name)

    enter_scope_stack(args, name, ScopeType.DECLARATION)

    if block_id:
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(block_id)),
            label_ast="AST",
        )

    if args.metadata["class_path"]:
        args.metadata["class_path"].pop()

    exit_scope_stack_if_current(args)

    return args.n_id
