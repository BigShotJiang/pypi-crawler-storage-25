from blends.syntax.models import (
    Dispatcher,
)
from blends.syntax.readers.rust import (
    argument_list as rust_argument_list,
)
from blends.syntax.readers.rust import (
    assignment_expression as rust_assignment_expression,
)
from blends.syntax.readers.rust import (
    await_expression as rust_await_expression,
)
from blends.syntax.readers.rust import (
    binary_expression as rust_binary_expression,
)
from blends.syntax.readers.rust import (
    block as rust_block,
)
from blends.syntax.readers.rust import (
    boolean_literal as rust_boolean_literal,
)
from blends.syntax.readers.rust import (
    break_expression as rust_break_expression,
)
from blends.syntax.readers.rust import (
    call_expression as rust_call_expression,
)
from blends.syntax.readers.rust import (
    closure_expression as rust_closure_expression,
)
from blends.syntax.readers.rust import (
    comment as rust_comment,
)
from blends.syntax.readers.rust import (
    const_item as rust_const_item,
)
from blends.syntax.readers.rust import (
    declaration_list as rust_declaration_list,
)
from blends.syntax.readers.rust import (
    enum_item as rust_enum_item,
)
from blends.syntax.readers.rust import (
    expression_statement as rust_expression_statement,
)
from blends.syntax.readers.rust import (
    field_declaration as rust_field_declaration,
)
from blends.syntax.readers.rust import (
    field_expression as rust_field_expression,
)
from blends.syntax.readers.rust import (
    field_initializer as rust_field_initializer,
)
from blends.syntax.readers.rust import (
    for_expression as rust_for_expression,
)
from blends.syntax.readers.rust import (
    function_item as rust_function_item,
)
from blends.syntax.readers.rust import (
    generic_function as rust_generic_function,
)
from blends.syntax.readers.rust import (
    identifier as rust_identifier,
)
from blends.syntax.readers.rust import (
    if_expression as rust_if_expression,
)
from blends.syntax.readers.rust import (
    impl_item as rust_impl_item,
)
from blends.syntax.readers.rust import (
    index_expression as rust_index_expression,
)
from blends.syntax.readers.rust import (
    integer_literal as rust_integer_literal,
)
from blends.syntax.readers.rust import (
    let_declaration as rust_let_declaration,
)
from blends.syntax.readers.rust import (
    loop_expression as rust_loop_expression,
)
from blends.syntax.readers.rust import (
    macro_invocation as rust_macro_invocation,
)
from blends.syntax.readers.rust import (
    match_arm as rust_match_arm,
)
from blends.syntax.readers.rust import (
    match_block as rust_match_block,
)
from blends.syntax.readers.rust import (
    match_expression as rust_match_expression,
)
from blends.syntax.readers.rust import (
    parameter as rust_parameter,
)
from blends.syntax.readers.rust import (
    parameter_list as rust_parameter_list,
)
from blends.syntax.readers.rust import (
    parenthesized_expression as rust_parenthesized_expression,
)
from blends.syntax.readers.rust import (
    range_expression as rust_range_expression,
)
from blends.syntax.readers.rust import (
    reference_expression as rust_reference_expression,
)
from blends.syntax.readers.rust import (
    return_expression as rust_return_expression,
)
from blends.syntax.readers.rust import (
    scoped_identifier as rust_scoped_identifier,
)
from blends.syntax.readers.rust import (
    self_parameter as rust_self_parameter,
)
from blends.syntax.readers.rust import (
    source_file as rust_source_file,
)
from blends.syntax.readers.rust import (
    string_literal as rust_string_literal,
)
from blends.syntax.readers.rust import (
    struct_expression as rust_struct_expression,
)
from blends.syntax.readers.rust import (
    struct_item as rust_struct_item,
)
from blends.syntax.readers.rust import (
    token_tree as rust_token_tree,
)
from blends.syntax.readers.rust import (
    try_expression as rust_try_expression,
)
from blends.syntax.readers.rust import (
    tuple_expression as rust_tuple_expression,
)
from blends.syntax.readers.rust import (
    type_cast_expression as rust_type_cast_expression,
)
from blends.syntax.readers.rust import (
    type_item as rust_type_item,
)
from blends.syntax.readers.rust import (
    unary_expression as rust_unary_expression,
)
from blends.syntax.readers.rust import (
    unsafe_block as rust_unsafe_block,
)
from blends.syntax.readers.rust import (
    use_declaration as rust_use_declaration,
)
from blends.syntax.readers.rust import (
    while_expression as rust_while_expression,
)

RUST_DISPATCHERS: Dispatcher = {
    "arguments": rust_argument_list.reader,
    "assignment_expression": rust_assignment_expression.reader,
    "async_block": rust_unsafe_block.reader,
    "attribute_item": rust_comment.reader,
    "await_expression": rust_await_expression.reader,
    "binary_expression": rust_binary_expression.reader,
    "block": rust_block.reader,
    "block_comment": rust_comment.reader,
    "boolean_literal": rust_boolean_literal.reader,
    "break_expression": rust_break_expression.reader,
    "call_expression": rust_call_expression.reader,
    "char_literal": rust_string_literal.reader,
    "closure_expression": rust_closure_expression.reader,
    "closure_parameters": rust_parameter_list.reader,
    "compound_assignment_expr": rust_assignment_expression.reader,
    "const_block": rust_unsafe_block.reader,
    "const_item": rust_const_item.reader,
    "continue_expression": rust_break_expression.reader,
    "declaration_list": rust_declaration_list.reader,
    "doc_comment": rust_comment.reader,
    "empty_statement": rust_comment.reader,
    "enum_item": rust_enum_item.reader,
    "extern_crate_declaration": rust_comment.reader,
    "expression_statement": rust_expression_statement.reader,
    "field_declaration": rust_field_declaration.reader,
    "field_expression": rust_field_expression.reader,
    "field_initializer": rust_field_initializer.reader,
    "field_initializer_list": rust_argument_list.reader,
    "float_literal": rust_integer_literal.reader,
    "for_expression": rust_for_expression.reader,
    "function_item": rust_function_item.reader,
    "generic_function": rust_generic_function.reader,
    "identifier": rust_identifier.reader,
    "if_expression": rust_if_expression.reader,
    "impl_item": rust_impl_item.reader,
    "index_expression": rust_index_expression.reader,
    "inner_attribute_item": rust_comment.reader,
    "integer_literal": rust_integer_literal.reader,
    "let_declaration": rust_let_declaration.reader,
    "line_comment": rust_comment.reader,
    "loop_expression": rust_loop_expression.reader,
    "macro_invocation": rust_macro_invocation.reader,
    "match_arm": rust_match_arm.reader,
    "mod_item": rust_struct_item.reader,
    "match_block": rust_match_block.reader,
    "match_expression": rust_match_expression.reader,
    "parameter": rust_parameter.reader,
    "parameters": rust_parameter_list.reader,
    "parenthesized_expression": rust_parenthesized_expression.reader,
    "range_expression": rust_range_expression.reader,
    "raw_string_literal": rust_string_literal.reader,
    "reference_expression": rust_reference_expression.reader,
    "return_expression": rust_return_expression.reader,
    "scoped_identifier": rust_scoped_identifier.reader,
    "scoped_type_identifier": rust_scoped_identifier.reader,
    "self": rust_identifier.reader,
    "self_parameter": rust_self_parameter.reader,
    "shorthand_field_initializer": rust_expression_statement.reader,
    "source_file": rust_source_file.reader,
    "string_literal": rust_string_literal.reader,
    "static_item": rust_const_item.reader,
    "struct_expression": rust_struct_expression.reader,
    "struct_item": rust_struct_item.reader,
    "token_tree": rust_token_tree.reader,
    "trait_item": rust_struct_item.reader,
    "try_expression": rust_try_expression.reader,
    "tuple_expression": rust_tuple_expression.reader,
    "type_arguments": rust_argument_list.reader,
    "type_cast_expression": rust_type_cast_expression.reader,
    "type_identifier": rust_identifier.reader,
    "type_item": rust_type_item.reader,
    "unary_expression": rust_unary_expression.reader,
    "union_item": rust_struct_item.reader,
    "unsafe_block": rust_unsafe_block.reader,
    "use_declaration": rust_use_declaration.reader,
    "while_expression": rust_while_expression.reader,
}
