from blends.models import (
    NId,
)
from blends.query import (
    match_ast_d,
)
from blends.syntax.builders.declaration import (
    build_declaration_node,
)
from blends.syntax.builders.variable_declaration import (
    build_variable_declaration_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)

_SCOPED_TYPES = {"struct_type", "interface_type"}


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    var_name = None

    if spec_id := match_ast_d(graph, args.n_id, "type_spec"):
        id_name = graph.nodes[spec_id]["label_field_name"]
        var_name = node_to_str(graph, id_name)
        type_id = graph.nodes[spec_id].get("label_field_type")
        if type_id is not None:
            inner_label = graph.nodes[type_id]["label_type"]
            if inner_label in _SCOPED_TYPES:
                return build_declaration_node(args, var_name, type_id)
            var_type = node_to_str(graph, type_id)
            return build_variable_declaration_node(args, var_name, var_type, None)

    if not var_name:
        var_name = node_to_str(graph, args.n_id)

    return build_variable_declaration_node(args, var_name, None, None)
