from blends.models import (
    Graph,
    NId,
)
from blends.query import (
    adj_ast,
    match_ast_d,
)
from blends.syntax.builders.element_access import (
    build_element_access_node,
)
from blends.syntax.builders.member_access import (
    build_member_access_node,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren,
    build_method_invocation_node,
)
from blends.syntax.builders.symbol_lookup import (
    build_symbol_lookup_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def _extract_member_name(graph: Graph, assignable_selector_id: NId) -> str | None:
    children = adj_ast(graph, assignable_selector_id)
    if not children:
        return None
    member_node = children[1] if len(children) > 1 else children[0]
    text = node_to_str(graph, member_node)
    return text or None


_ASSIGNABLE_SELECTOR_LABELS = {
    "unconditional_assignable_selector",
    "conditional_assignable_selector",
}


def _get_selector_parts(
    graph: Graph,
    selectors: list[NId],
) -> list[tuple[NId | None, NId | None]] | None:
    selector_parts: list[tuple[NId | None, NId | None]] = []
    for sel_id in selectors:
        if graph.nodes[sel_id]["label_type"] in _ASSIGNABLE_SELECTOR_LABELS:
            assignable: NId | None = sel_id
            arg_part: NId | None = None
        else:
            assignable = match_ast_d(
                graph, sel_id, "unconditional_assignable_selector"
            ) or match_ast_d(graph, sel_id, "conditional_assignable_selector")
            arg_part = match_ast_d(graph, sel_id, "argument_part") if assignable is None else None
        if assignable is None and arg_part is None:
            return None
        selector_parts.append((assignable, arg_part))
    return selector_parts


def _try_build_selector_node(
    args: SyntaxGraphArgs,
    assignable: NId | None,
    arg_part: NId | None,
    current_id: NId,
    current_expr: str,
) -> tuple[NId, str] | None:
    graph = args.ast_graph
    if assignable is not None:
        if (idx := match_ast_d(graph, assignable, "index_selector")) is not None:
            idx_children = adj_ast(graph, idx)
            node_id = build_element_access_node(
                args,
                current_id,
                idx_children[1] if len(idx_children) > 1 else None,
            )
            return node_id, current_expr
        if (member := _extract_member_name(graph, assignable)) is None:
            return None
        node_id = build_member_access_node(args, member, current_expr, current_id)
        return node_id, f"{current_expr}.{member}"

    if arg_part is not None:
        arg_list_id = match_ast_d(graph, arg_part, "arguments")
        children: DirectChildren = {"object_id": current_id}
        if arg_list_id is not None:
            children["arguments_id"] = arg_list_id
        node_id = build_method_invocation_node(args, current_expr, children)
        return node_id, current_expr

    return None


def try_build_accessor_chain(
    args: SyntaxGraphArgs,
    graph: Graph,
    symbol: str,
    identifier_id: NId,
    selectors: list[NId],
) -> NId | None:
    if not selectors or (selector_parts := _get_selector_parts(graph, selectors)) is None:
        return None

    current_id = build_symbol_lookup_node(args.fork_n_id(identifier_id), symbol)
    current_expr = symbol

    for i, selector in enumerate(selectors):
        assignable, arg_part = selector_parts[i]
        sel_args = args if i == len(selectors) - 1 else args.fork_n_id(selector)
        result = _try_build_selector_node(sel_args, assignable, arg_part, current_id, current_expr)
        if result is None:
            return None
        current_id, current_expr = result
        graph.nodes[selector]["_chain_built_id"] = current_id

    return current_id
