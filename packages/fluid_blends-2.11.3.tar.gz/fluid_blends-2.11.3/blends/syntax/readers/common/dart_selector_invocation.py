from blends.models import (
    Graph,
    NId,
)
from blends.query import (
    adj_ast,
    match_ast_d,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren,
    build_method_invocation_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_accessor_chain import (
    try_build_accessor_chain,
)
from blends.utilities.text_nodes import (
    node_to_str,
)

SELECTORS_ONE_PART = 1
SELECTORS_TWO_PART = 2


def try_build_chained_invocation(
    args: SyntaxGraphArgs,
    graph: Graph,
    symbol: str,
    identifier_id: NId,
    selectors: list[NId],
) -> NId | None:
    if len(selectors) != SELECTORS_TWO_PART:
        return None
    uas = match_ast_d(graph, selectors[0], "unconditional_assignable_selector")
    arg_part = match_ast_d(graph, selectors[1], "argument_part")
    if uas and arg_part:
        expr_children = adj_ast(graph, uas)
        if expr_children:
            method_node = expr_children[1] if len(expr_children) > 1 else expr_children[0]
            expr = symbol + "." + node_to_str(graph, method_node)
            args_id = match_ast_d(graph, arg_part, "arguments")
            children: DirectChildren = {
                "object_id": identifier_id,
                "expression_id": method_node,
            }
            if args_id:
                children["arguments_id"] = args_id
            return build_method_invocation_node(args, expr, children)
    return None


def try_build_simple_invocation(
    args: SyntaxGraphArgs,
    graph: Graph,
    symbol: str,
    selectors: list[NId],
) -> NId | None:
    if len(selectors) != SELECTORS_ONE_PART:
        return None
    arg_part = match_ast_d(graph, selectors[0], "argument_part")
    if arg_part:
        args_id = match_ast_d(graph, arg_part, "arguments")
        children: DirectChildren = {}
        if args_id:
            children["arguments_id"] = args_id
        return build_method_invocation_node(args, symbol, children)
    return None


def try_build_invocation_chain(
    args: SyntaxGraphArgs,
    graph: Graph,
    fork_target_id: NId,
    identifier_id: NId,
    selectors: list[NId],
) -> NId | None:
    if not selectors:
        return None
    fork_args = args.fork_n_id(fork_target_id)
    symbol = graph.nodes[identifier_id]["label_text"]
    if result := try_build_simple_invocation(fork_args, graph, symbol, selectors):
        graph.nodes[fork_target_id]["_method_invocation_id"] = result
        return result
    if result := try_build_chained_invocation(fork_args, graph, symbol, identifier_id, selectors):
        graph.nodes[fork_target_id]["_method_invocation_id"] = result
        return result
    return try_build_accessor_chain(fork_args, graph, symbol, identifier_id, selectors)


def try_compose_rhs_chain(
    args: SyntaxGraphArgs,
    graph: Graph,
    assign_id: NId,
    val_id: NId,
) -> NId | None:
    if graph.nodes[val_id]["label_type"] != "identifier":
        return None
    siblings = adj_ast(graph, assign_id)
    if val_id not in siblings:
        return None
    selectors = [
        sel_id
        for sel_id in siblings[siblings.index(val_id) + 1 :]
        if graph.nodes[sel_id]["label_type"] == "selector"
    ]
    if not selectors:
        return None
    return try_build_invocation_chain(args, graph, selectors[-1], val_id, selectors)
