from blends.models import (
    Graph,
    NId,
)
from blends.query import (
    adj_ast,
    pred_ast,
)

_RECEIVER_RESET_TYPES = {"=", ";", ",", "(", "{", ":", "=>", "return", "yield"}


def find_cascade_receiver(graph: Graph, cascade_section_id: NId) -> NId | None:
    parents = pred_ast(graph, cascade_section_id)
    if not parents:
        return None
    siblings = adj_ast(graph, parents[0])
    if cascade_section_id not in siblings:
        return None
    self_pos = siblings.index(cascade_section_id)
    receiver_id: NId | None = None
    for sibling in siblings[:self_pos]:
        sibling_label = graph.nodes[sibling]["label_type"]
        if sibling_label == "identifier":
            receiver_id = sibling
        elif sibling_label in _RECEIVER_RESET_TYPES:
            receiver_id = None
    return receiver_id
