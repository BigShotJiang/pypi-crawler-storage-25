from blends.models import (
    NId,
)
from blends.query import (
    match_ast_group_d,
    pred,
)
from blends.syntax.builders.symbol_lookup import (
    build_symbol_lookup_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_selector_invocation import (
    try_build_simple_invocation,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    symbol = graph.nodes[args.n_id]["label_text"]
    pred_nid = pred(graph, args.n_id)[0]
    label_type = graph.nodes[pred_nid]["label_type"]

    selectors_ids = match_ast_group_d(graph, pred_nid, "selector")
    if not selectors_ids:
        return build_symbol_lookup_node(args, symbol)

    if label_type == "static_final_declaration" and (
        result := try_build_simple_invocation(args, graph, symbol, selectors_ids)
    ):
        return result

    return build_symbol_lookup_node(args, symbol)
