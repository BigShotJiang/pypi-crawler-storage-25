from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    match_ast,
)
from blends.syntax.builders.assignment import (
    build_assignment_node,
)
from blends.syntax.builders.expression_statement import (
    build_expression_statement_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_accessor_chain import (
    try_build_accessor_chain,
)
from blends.syntax.readers.common.dart_selector_invocation import (
    try_build_chained_invocation,
    try_build_simple_invocation,
    try_compose_rhs_chain,
)


def _try_build_assignment(
    args: SyntaxGraphArgs,
    filtered_ids: list[NId],
) -> NId | None:
    graph = args.ast_graph
    if not (
        len(filtered_ids) == 1
        and graph.nodes[filtered_ids[0]]["label_type"] == "assignment_expression"
    ):
        return None
    assign_id = filtered_ids[0]
    n_attr = graph.nodes[assign_id]
    var_id = n_attr["label_field_left"]
    op_id = n_attr.get("label_field_operator")
    val_id = n_attr["label_field_right"]
    if (
        graph.nodes[var_id]["label_type"] == "assignable_expression"
        and len(adj_ast(graph, var_id)) == 1
        and (var_n_id := match_ast(graph, var_id).get("__0__"))
    ):
        var_id = var_n_id
    if op_id:
        if composed := try_compose_rhs_chain(args, graph, assign_id, val_id):
            val_id = composed
        return build_assignment_node(
            args,
            var_id,
            val_id,
            graph.nodes[op_id]["label_text"],
        )
    return None


def _try_build_from_selectors(
    args: SyntaxGraphArgs,
    identifier_id: NId,
    selectors: list[NId],
) -> NId | None:
    graph = args.ast_graph
    symbol = graph.nodes[identifier_id]["label_text"]
    if result := try_build_simple_invocation(args, graph, symbol, selectors):
        return result
    if result := try_build_chained_invocation(args, graph, symbol, identifier_id, selectors):
        return result
    return try_build_accessor_chain(args, graph, symbol, identifier_id, selectors)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    c_ids = adj_ast(args.ast_graph, args.n_id)
    ignored_types = {";", "(", ")", "super", "comment"}
    filtered_ids = [
        c_id for c_id in c_ids if args.ast_graph.nodes[c_id]["label_type"] not in ignored_types
    ]

    identifier_id: NId | None = None
    selectors: list[NId] = []
    for c_id in filtered_ids:
        label = graph.nodes[c_id]["label_type"]
        if label == "identifier" and identifier_id is None:
            identifier_id = c_id
        elif label == "selector":
            selectors.append(c_id)

    if (
        identifier_id is not None
        and len(filtered_ids) == len(selectors) + 1
        and (result := _try_build_from_selectors(args, identifier_id, selectors))
    ):
        return result

    if assignment := _try_build_assignment(args, filtered_ids):
        return assignment

    return build_expression_statement_node(args, iter(filtered_ids))
