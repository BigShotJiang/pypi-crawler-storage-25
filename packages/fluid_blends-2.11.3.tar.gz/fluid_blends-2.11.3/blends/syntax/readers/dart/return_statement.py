from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.return_statement import (
    build_return_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_operand_compose import (
    try_build_operand_chain,
)

_RETURN_IGNORED_CHILDS = {"return", "yield", ";"}
_MIN_FOR_SELECTOR_RETURN = 3


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    c_ids = adj_ast(graph, args.n_id)
    filtered = [
        c_id
        for c_id in c_ids
        if graph.nodes[c_id]["label_type"] not in _RETURN_IGNORED_CHILDS
        and graph.nodes[c_id]["label_type"] != "cascade_section"
    ]
    cascade_ids: list[NId] = [
        c_id for c_id in c_ids if graph.nodes[c_id]["label_type"] == "cascade_section"
    ]

    if not filtered:
        result = build_return_node(args, None)
    elif composed := try_build_operand_chain(args, graph, filtered):
        result = build_return_node(args, value_id=composed)
    elif (
        len(filtered) >= _MIN_FOR_SELECTOR_RETURN
        and graph.nodes[filtered[1]]["label_type"] == "selector"
    ):
        result = build_return_node(args, value_id=filtered[1])
    else:
        result = build_return_node(args, value_id=filtered[0])

    for cascade_id in cascade_ids:
        args.syntax_graph.add_edge(
            result,
            args.generic(args.fork_n_id(cascade_id)),
            label_ast="AST",
        )
    return result
