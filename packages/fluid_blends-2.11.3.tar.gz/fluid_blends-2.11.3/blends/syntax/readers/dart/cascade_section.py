from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    match_ast_d,
)
from blends.syntax.builders.assignment import (
    build_assignment_node,
)
from blends.syntax.builders.member_access import (
    build_member_access_node,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren,
    build_method_invocation_node,
)
from blends.syntax.builders.symbol_lookup import (
    build_symbol_lookup_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_cascade import (
    find_cascade_receiver,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    children = list(adj_ast(graph, args.n_id))

    cascade_selector_id = next(
        (c_id for c_id in children if graph.nodes[c_id]["label_type"] == "cascade_selector"),
        None,
    )

    eq_idx = next(
        (idx for idx, c_id in enumerate(children) if graph.nodes[c_id]["label_type"] == "="),
        None,
    )
    if cascade_selector_id is not None and eq_idx is not None and eq_idx + 1 < len(children):
        return build_assignment_node(
            args,
            var_id=cascade_selector_id,
            val_id=children[eq_idx + 1],
            operator="=",
        )

    receiver_id = find_cascade_receiver(graph, args.n_id)
    selector_children = (
        adj_ast(graph, cascade_selector_id) if cascade_selector_id is not None else ()
    )
    member = node_to_str(graph, selector_children[-1]) if selector_children else ""
    receiver_symbol = node_to_str(graph, receiver_id) if receiver_id is not None else ""
    selector_name = f"{receiver_symbol}.{member}" if receiver_symbol else member

    arg_part = next(
        (c_id for c_id in children if graph.nodes[c_id]["label_type"] == "argument_part"),
        None,
    )
    if arg_part is not None and receiver_id is not None and member:
        arg_list = match_ast_d(graph, arg_part, "arguments")
        direct_children: DirectChildren = {"object_id": receiver_id}
        if arg_list is not None:
            direct_children["arguments_id"] = arg_list
        return build_method_invocation_node(args, selector_name, direct_children)

    if receiver_id is not None and member:
        return build_member_access_node(args, member, receiver_symbol, receiver_id)

    return build_symbol_lookup_node(args, member or "")
