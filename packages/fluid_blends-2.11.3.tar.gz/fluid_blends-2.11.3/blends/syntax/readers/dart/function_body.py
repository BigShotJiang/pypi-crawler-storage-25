from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.execution_block import (
    build_execution_block_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_selector_invocation import (
    try_build_invocation_chain,
)


def _try_compose_arrow_body(
    args: SyntaxGraphArgs,
    filtered: list[NId],
) -> NId | None:
    graph = args.ast_graph
    identifier_id: NId | None = None
    selectors: list[NId] = []
    for c_id in filtered:
        label = graph.nodes[c_id]["label_type"]
        if label == "identifier" and identifier_id is None:
            identifier_id = c_id
        elif label == "selector":
            selectors.append(c_id)
        else:
            return None
    if identifier_id is None or not selectors:
        return None
    return try_build_invocation_chain(args, graph, selectors[-1], identifier_id, selectors)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    c_ids = adj_ast(graph, args.n_id)
    invalid_childs = {"=>", ";", "async"}
    filtered = [c_id for c_id in c_ids if graph.nodes[c_id]["label_type"] not in invalid_childs]

    if composed := _try_compose_arrow_body(args, filtered):
        return build_execution_block_node(args, iter([composed]))

    return build_execution_block_node(args, iter(filtered))
