from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    pred_ast,
)
from blends.syntax.builders.member_access import (
    build_member_access_node,
)
from blends.syntax.builders.symbol_lookup import (
    build_symbol_lookup_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_cascade import (
    find_cascade_receiver,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    children = adj_ast(graph, args.n_id)
    member = node_to_str(graph, children[-1]) if children else ""
    parents = pred_ast(graph, args.n_id)
    if not member or not parents:
        return build_symbol_lookup_node(args, member or "")
    receiver_id = find_cascade_receiver(graph, parents[0])
    if receiver_id is None:
        return build_symbol_lookup_node(args, member)
    receiver_symbol = node_to_str(graph, receiver_id)
    if not receiver_symbol:
        return build_symbol_lookup_node(args, member)
    return build_member_access_node(args, member, receiver_symbol, receiver_id)
