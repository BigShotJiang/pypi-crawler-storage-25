from blends.models import (
    NId,
    SyntaxGraph,
)
from blends.models.syntax_attrs import SyntaxNodeAttrs
from blends.query import (
    match_ast,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren,
    build_method_invocation_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.receiver_fqn import (
    fqn_from_graph_imports,
    receiver_fqn_from_graph_symbol,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def _receiver_fqn_from_object_creation(node: SyntaxNodeAttrs, sg: SyntaxGraph) -> str | None:
    name = str(node.get("name") or "").lstrip(":")
    if not name:
        return None
    if "." in name:
        return name
    return fqn_from_graph_imports(sg, name)


def _receiver_fqn_from_member_access(node: SyntaxNodeAttrs, sg: SyntaxGraph) -> str | None:
    member = str(node.get("member") or "").lstrip(":")
    inner_fqn = _receiver_fqn_from_node(sg, node.get("expression_id"))
    return f"{inner_fqn}.{member}" if inner_fqn and member else None


def _receiver_fqn_from_node(sg: SyntaxGraph, nid: object) -> str | None:
    if not isinstance(nid, int) or nid not in sg.nodes:
        return None
    node = sg.nodes[nid]
    label = node.get("label_type")
    if label == "MemberAccess":
        return _receiver_fqn_from_member_access(node, sg)
    if label == "SymbolLookup":
        symbol = str(node.get("symbol") or node.get("value") or "").lstrip(":")
        return receiver_fqn_from_graph_symbol(sg, symbol) if symbol else None
    if label == "ObjectCreation":
        return _receiver_fqn_from_object_creation(node, sg)
    if label == "MethodInvocation":
        inner = node.get("receiver_type_fqn")
        return str(inner) if inner else None
    return None


def reader(args: SyntaxGraphArgs) -> NId:
    arguments_id = args.ast_graph.nodes[args.n_id]["label_field_arguments"]
    expr_id = args.ast_graph.nodes[args.n_id]["label_field_function"]
    expr = node_to_str(args.ast_graph, expr_id)

    include_args = "__0__" in match_ast(args.ast_graph, arguments_id, "(", ")")

    children: DirectChildren = {"expression_id": expr_id}
    if include_args:
        children["arguments_id"] = arguments_id

    nid = build_method_invocation_node(args, expr, children)

    sg = args.syntax_graph
    expr_nid = sg.nodes.get(nid, {}).get("expression_id")
    if isinstance(expr_nid, int) and expr_nid in sg.nodes:
        member = sg.nodes[expr_nid]
        if member.get("label_type") == "MemberAccess" and (
            receiver_fqn := _receiver_fqn_from_node(sg, member.get("expression_id"))
        ):
            sg.update_node_attribute(nid, "receiver_type_fqn", receiver_fqn)

    return nid
