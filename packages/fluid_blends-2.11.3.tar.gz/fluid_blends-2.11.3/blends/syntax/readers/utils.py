from blends.models import NId
from blends.syntax.models import ReaderLogicError, SyntaxGraphArgs

_CLASS_LABEL_TYPES = frozenset({"Declaration", "Class"})


def check_reader_element_consistency(*args: NId | None) -> None:
    if any(arg is None for arg in args):
        msg = "Inconsistent reader element"
        raise ReaderLogicError(msg)


def ensure_nid(value: NId | None) -> NId:
    if value is None:
        msg = "Inconsistent reader element, expected NId but got None"
        raise ReaderLogicError(msg)
    return value


def find_class_parent_scope(args: SyntaxGraphArgs, class_name: str) -> NId | None:
    for nid in args.syntax_graph.nodes:
        attrs = args.syntax_graph.nodes[nid]
        if attrs.get("name") == class_name and attrs.get("label_type") in _CLASS_LABEL_TYPES:
            return args.syntax_graph.scope_parent.get(nid)
    return None
