from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, cast

from blends.ctx import ctx
from blends.models import EXTENSION_TO_LANGUAGE, NId
from blends.stack.forward_stitcher import (
    ForwardStitcherConfig,
    ForwardStitcherStatsSnapshot,
)
from blends.stack.multi_file_resolver import (
    MultiFileResolutionRequest,
    MultiFileResolutionStats,
    resolve_definitions_multi_file,
)
from blends.stack.partial_path import (
    PartialPathDatabase,
    PartialPathFileRecord,
    PartialPathIndexRequest,
    index_partial_paths_for_file,
)
from blends.stack.receiver_inference import resolve_receiver_member
from blends.stack.single_file_resolver import (
    SingleFileResolutionRequest,
    SingleFileResolutionStats,
    resolve_definitions_single_file,
)
from blends.stack.view import StackGraphView

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from blends.models import StackGraph, SyntaxGraph


@dataclass(frozen=True, slots=True)
class DefinitionLocation:
    file_path: str
    nid: NId


def _to_syntax_nid(
    view: StackGraphView,
    syntax_graph: SyntaxGraph,
    idx: int,
) -> NId | None:
    nid = view.index_to_nid[idx]
    if nid is None:
        return None
    if nid in syntax_graph.nodes:
        return nid
    for next_idx, _ in view.outgoing[idx]:
        next_nid = view.index_to_nid[next_idx]
        if next_nid is not None and next_nid in syntax_graph.nodes:
            return next_nid
    return None


RECOMMENDED_RESOLUTION_CONFIG: ForwardStitcherConfig = ForwardStitcherConfig(
    max_phases=100,
    max_total_work=10_000,
)

_KNOWN_SUFFIXES: frozenset[str] = frozenset(EXTENSION_TO_LANGUAGE)


def _expand_paths(paths: Sequence[Path | str]) -> list[Path]:
    result: list[Path] = []
    for raw in paths:
        path = Path(raw)
        if path.is_dir():
            result.extend(entry for entry in path.rglob("*") if entry.suffix in _KNOWN_SUFFIXES)
        elif path.exists() and path.suffix in _KNOWN_SUFFIXES:
            result.append(path)
    return result


def _build_graphs_view_and_record(
    source: Path,
) -> tuple[SyntaxGraph, StackGraphView, PartialPathFileRecord] | None:
    from blends import get_graphs_from_path  # noqa: PLC0415

    graphs = get_graphs_from_path(source)
    if graphs.stack_graph is None or graphs.syntax_graph is None:
        return None
    database = PartialPathDatabase()
    path_str = str(source)
    view = StackGraphView.from_stack_graph(graphs.stack_graph, path=path_str)
    index_partial_paths_for_file(
        graphs.stack_graph,
        request=PartialPathIndexRequest(file_path=path_str, file_handle=0),
        database=database,
        view=view,
    )
    record = database.get_file(0)
    if record is None:
        return None
    return graphs.syntax_graph, view, record


def _build_view_and_record(
    source: Path,
) -> tuple[StackGraphView, PartialPathFileRecord] | None:
    built = _build_graphs_view_and_record(source)
    if built is None:
        return None
    _, view, record = built
    return view, record


def resolve_member_access(
    file_path: Path | str,
    receiver_ref_nid: NId,
    member_name: str,
) -> list[DefinitionLocation]:
    if not ctx.has_feature_flag("StackGraph"):
        return []
    source = Path(file_path)
    built = _build_graphs_view_and_record(source)
    if built is None:
        return []
    syntax_graph, view, record = built
    ref_index = view.nid_to_index.get(receiver_ref_nid)
    if ref_index is None:
        return []
    nids = resolve_receiver_member(syntax_graph, view, record, ref_index, member_name)
    return [DefinitionLocation(file_path=str(source), nid=nid) for nid in nids]


def resolve_definitions(
    file_path: Path | str,
    ref_nid: NId,
    *,
    sibling_paths: Sequence[Path | str] = (),
    config: ForwardStitcherConfig | None = None,
) -> list[DefinitionLocation]:
    if not ctx.has_feature_flag("StackGraph"):
        return []
    source = Path(file_path)
    siblings = _expand_paths(sibling_paths)
    if not siblings:
        return _resolve_single(source, ref_nid, config=config)
    return _resolve_multi(source, siblings, ref_nid, config=config)


def _resolve_single(
    source: Path,
    ref_nid: NId,
    *,
    config: ForwardStitcherConfig | None,
) -> list[DefinitionLocation]:
    built = _build_graphs_view_and_record(source)
    if built is None:
        return []
    syntax_graph, view, record = built
    ref_index = view.nid_to_index.get(ref_nid)
    if ref_index is None:
        return []
    raw = resolve_definitions_single_file(
        view,
        request=SingleFileResolutionRequest(
            file_handle=0,
            record=record,
            ref_node_index=ref_index,
            config=config,
        ),
    )
    indices = cast("list[int]", raw)
    return [
        DefinitionLocation(file_path=str(source), nid=nid)
        for idx in indices
        if (nid := _to_syntax_nid(view, syntax_graph, idx)) is not None
    ]


def _resolve_multi(
    source: Path,
    siblings: list[Path],
    ref_nid: NId,
    *,
    config: ForwardStitcherConfig | None,
) -> list[DefinitionLocation]:
    idx = build_resolution_index(source, siblings)
    locations, _ = resolve_with_index(idx, ref_nid, config=config)
    return locations


@dataclass(slots=True)
class ResolutionIndex:
    database: PartialPathDatabase
    views: dict[int, StackGraphView]
    syntax_graphs: dict[int, SyntaxGraph]
    path_to_handle: dict[Path, int]
    source_handle: int = 0
    config: ForwardStitcherConfig | None = None


def _index_all_paths(
    all_paths: list[Path],
    database: PartialPathDatabase,
) -> tuple[dict[int, StackGraphView], dict[int, SyntaxGraph], dict[Path, int]]:
    from blends import get_graphs_from_path  # noqa: PLC0415

    views: dict[int, StackGraphView] = {}
    syntax_graphs: dict[int, SyntaxGraph] = {}
    path_to_handle: dict[Path, int] = {}
    for fh, path in enumerate(all_paths):
        path_to_handle[path] = fh
        graphs = get_graphs_from_path(path)
        if graphs.stack_graph is None:
            continue
        path_str = str(path)
        view = StackGraphView.from_stack_graph(
            graphs.stack_graph, path=path_str, symbols=database.symbols
        )
        index_partial_paths_for_file(
            graphs.stack_graph,
            request=PartialPathIndexRequest(file_path=path_str, file_handle=fh),
            database=database,
            view=view,
        )
        views[fh] = view
        if graphs.syntax_graph is not None:
            syntax_graphs[fh] = graphs.syntax_graph
    return views, syntax_graphs, path_to_handle


def build_resolution_index_from_graphs(
    stack_graphs: Mapping[Path, StackGraph],
    syntax_graphs: Mapping[Path, SyntaxGraph],
    *,
    config: ForwardStitcherConfig | None = None,
) -> ResolutionIndex:
    database = PartialPathDatabase()
    views: dict[int, StackGraphView] = {}
    out_syntax_graphs: dict[int, SyntaxGraph] = {}
    path_to_handle: dict[Path, int] = {}
    for fh, path in enumerate(sorted(stack_graphs)):
        path_to_handle[path] = fh
        path_str = str(path)
        view = StackGraphView.from_stack_graph(
            stack_graphs[path],
            path=path_str,
            symbols=database.symbols,
        )
        _ = index_partial_paths_for_file(
            stack_graphs[path],
            request=PartialPathIndexRequest(file_path=path_str, file_handle=fh),
            database=database,
            view=view,
        )
        views[fh] = view
        if (syntax_graph := syntax_graphs.get(path)) is not None:
            out_syntax_graphs[fh] = syntax_graph
    return ResolutionIndex(
        database=database,
        views=views,
        syntax_graphs=out_syntax_graphs,
        path_to_handle=path_to_handle,
        config=config,
    )


def build_resolution_index(
    file_path: Path | str,
    sibling_paths: Sequence[Path | str] = (),
    *,
    working_dir: Path | str | None = None,
    config: ForwardStitcherConfig | None = None,
) -> ResolutionIndex:
    source = Path(file_path)
    siblings = _expand_paths(sibling_paths)
    seen: set[Path] = set()
    all_paths: list[Path] = []
    for candidate in [source, *siblings]:
        if candidate not in seen:
            seen.add(candidate)
            all_paths.append(candidate)
    database = PartialPathDatabase()
    prev_working_dir = ctx.working_dir
    if working_dir is not None:
        ctx.working_dir = Path(working_dir)
    try:
        views, syntax_graphs, path_to_handle = _index_all_paths(all_paths, database)
    finally:
        ctx.working_dir = prev_working_dir
    return ResolutionIndex(
        database=database,
        views=views,
        syntax_graphs=syntax_graphs,
        path_to_handle=path_to_handle,
        config=config,
    )


def update_file_in_index(context: ResolutionIndex, file_path: Path | str) -> None:
    from blends import get_graphs_from_path  # noqa: PLC0415

    path = Path(file_path)
    handle = context.path_to_handle[path]
    context.database.drop_file(handle)
    graphs = get_graphs_from_path(path)
    if graphs.stack_graph is None:
        context.views.pop(handle, None)
        context.syntax_graphs.pop(handle, None)
        return
    path_str = str(path)
    view = StackGraphView.from_stack_graph(
        graphs.stack_graph, path=path_str, symbols=context.database.symbols
    )
    index_partial_paths_for_file(
        graphs.stack_graph,
        request=PartialPathIndexRequest(file_path=path_str, file_handle=handle),
        database=context.database,
        view=view,
    )
    context.views[handle] = view
    if graphs.syntax_graph is not None:
        context.syntax_graphs[handle] = graphs.syntax_graph


def add_file_to_index(context: ResolutionIndex, file_path: Path | str) -> None:
    from blends import get_graphs_from_path  # noqa: PLC0415

    path = Path(file_path)
    if path in context.path_to_handle:
        msg = f"{path} is already in context; use update_file_in_index instead"
        raise ValueError(msg)
    handle = max(context.path_to_handle.values(), default=-1) + 1
    context.path_to_handle[path] = handle
    graphs = get_graphs_from_path(path)
    if graphs.stack_graph is None:
        return
    path_str = str(path)
    view = StackGraphView.from_stack_graph(
        graphs.stack_graph, path=path_str, symbols=context.database.symbols
    )
    index_partial_paths_for_file(
        graphs.stack_graph,
        request=PartialPathIndexRequest(file_path=path_str, file_handle=handle),
        database=context.database,
        view=view,
    )
    context.views[handle] = view
    if graphs.syntax_graph is not None:
        context.syntax_graphs[handle] = graphs.syntax_graph


def _zero_stats_snapshot() -> ForwardStitcherStatsSnapshot:
    return ForwardStitcherStatsSnapshot(
        phases_executed=0,
        candidates_considered=0,
        concatenations_succeeded=0,
        complete_paths_found=0,
        cancelled=False,
        cycle_guard_hits=0,
        queue_pruned_count=0,
    )


def _to_stats_snapshot(
    stats: SingleFileResolutionStats | MultiFileResolutionStats,
) -> ForwardStitcherStatsSnapshot:
    return ForwardStitcherStatsSnapshot(
        phases_executed=stats.phases_executed,
        candidates_considered=stats.candidates_considered,
        concatenations_succeeded=stats.concatenations_succeeded,
        complete_paths_found=stats.complete_paths_found,
        cancelled=stats.cancelled,
        cycle_guard_hits=stats.cycle_guard_hits,
        queue_pruned_count=stats.queue_pruned_count,
    )


def resolve_with_index(
    context: ResolutionIndex,
    ref_nid: NId,
    *,
    config: ForwardStitcherConfig | None = None,
) -> tuple[list[DefinitionLocation], ForwardStitcherStatsSnapshot]:
    effective_config = config if config is not None else context.config
    source_view = context.views.get(context.source_handle)
    if source_view is None:
        return [], _zero_stats_snapshot()
    ref_index = source_view.nid_to_index.get(ref_nid)
    if ref_index is None:
        return [], _zero_stats_snapshot()
    if len(context.views) == 1:
        return _resolve_with_index_single(context, source_view, ref_index, config=effective_config)
    return _resolve_with_index_multi(context, source_view, ref_index, config=effective_config)


def _resolve_with_index_single(
    context: ResolutionIndex,
    source_view: StackGraphView,
    ref_index: int,
    *,
    config: ForwardStitcherConfig | None,
) -> tuple[list[DefinitionLocation], ForwardStitcherStatsSnapshot]:
    record = context.database.get_file(context.source_handle)
    if record is None:
        return [], _zero_stats_snapshot()
    raw = resolve_definitions_single_file(
        source_view,
        request=SingleFileResolutionRequest(
            file_handle=context.source_handle,
            record=record,
            ref_node_index=ref_index,
            config=config,
            include_stats=True,
        ),
    )
    indices, raw_stats = cast("tuple[list[int], SingleFileResolutionStats]", raw)
    stats = _to_stats_snapshot(raw_stats)
    syntax_graph = context.syntax_graphs.get(context.source_handle)
    if syntax_graph is None:
        return [], stats
    locations = [
        DefinitionLocation(file_path=source_view.file_path, nid=nid)
        for idx in indices
        if (nid := _to_syntax_nid(source_view, syntax_graph, idx)) is not None
    ]
    return locations, stats


def _resolve_with_index_multi(
    context: ResolutionIndex,
    source_view: StackGraphView,
    ref_index: int,
    *,
    config: ForwardStitcherConfig | None,
) -> tuple[list[DefinitionLocation], ForwardStitcherStatsSnapshot]:
    raw = resolve_definitions_multi_file(
        source_view,
        context.database,
        request=MultiFileResolutionRequest(
            file_handle=context.source_handle,
            ref_node_index=ref_index,
            config=config,
            include_stats=True,
        ),
        views=context.views,
    )
    pairs, raw_stats = cast("tuple[list[tuple[int, int]], MultiFileResolutionStats]", raw)
    stats = _to_stats_snapshot(raw_stats)
    locations: list[DefinitionLocation] = []
    for fh, node_idx in pairs:
        view = context.views.get(fh)
        if view is None:
            continue
        syntax_graph = context.syntax_graphs.get(fh)
        if syntax_graph is None:
            continue
        nid = _to_syntax_nid(view, syntax_graph, node_idx)
        if nid is None:
            continue
        locations.append(DefinitionLocation(file_path=view.file_path, nid=nid))
    return locations, stats
