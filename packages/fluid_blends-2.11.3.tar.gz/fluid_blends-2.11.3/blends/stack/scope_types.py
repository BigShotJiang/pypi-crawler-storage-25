from enum import StrEnum


class ScopeType(StrEnum):
    FILE = "file"
    CLASS = "class"
    DECLARATION = "declaration"
    FUNCTION = "function"
    BLOCK = "block"
    NAMESPACE = "namespace"
