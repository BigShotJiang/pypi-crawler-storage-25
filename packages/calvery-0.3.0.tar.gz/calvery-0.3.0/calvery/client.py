"""Calvery SDK client — baca secret dari Calvery Vault API."""

from __future__ import annotations

import os
import re
import time
import random
from typing import Dict, Optional, List

import requests

from .errors import (
    CalveryError,
    CalveryAuthError,
    CalveryNetworkError,
    CalveryServerError,
    CalverySecretNotFoundError,
)

__version__ = "0.1.0"

_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


class Calvery:
    """Calvery Vault client.

    Example:
        >>> from calvery import Calvery
        >>> c = Calvery(token=os.environ["CVSM_TOKEN"], team="acme-corp")
        >>> db = c.get("DATABASE_URL")
        >>> c.inject()  # os.environ["DATABASE_URL"] sekarang terisi
    """

    def __init__(
        self,
        token: str,
        team: str,
        *,
        base_url: str = "https://api.calvery.xyz",
        environment: str = "production",
        cache_ttl: float = 30.0,
        max_retries: int = 3,
        timeout: float = 10.0,
    ) -> None:
        """
        Args:
            token: Personal Access Token (`cvsm_...`). Buat di dash → Access Tokens.
            team: Team slug atau UUID.
            base_url: Override untuk self-host. Default ``https://api.calvery.xyz``.
            environment: Default env kalau tidak di-override per call.
            cache_ttl: In-memory cache TTL dalam detik. Set 0 untuk disable.
            max_retries: Jumlah retry untuk 5xx + network error.
            timeout: HTTP request timeout (detik) per attempt.
        """
        if not token:
            raise CalveryError("token wajib diisi")
        if not team:
            raise CalveryError("team wajib diisi (UUID atau slug)")

        self._token = token
        self._team_input = team
        self._base_url = base_url.rstrip("/")
        self._default_env = environment
        self._cache_ttl = cache_ttl
        self._max_retries = max_retries
        self._timeout = timeout

        self._resolved_team_id: Optional[str] = None
        # {env: (data_dict, expires_at)}
        self._cache: Dict[str, tuple] = {}

        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self._token}",
                "User-Agent": f"calvery-python/{__version__}",
            }
        )

    def get(self, name: str, *, environment: Optional[str] = None) -> str:
        """Ambil satu secret by name.

        Raises:
            CalverySecretNotFoundError: kalau secret tidak ada.
        """
        env = environment or self._default_env
        all_secrets = self.get_all(environment=env)
        if name not in all_secrets:
            raise CalverySecretNotFoundError(name, env)
        return all_secrets[name]

    def get_all(self, *, environment: Optional[str] = None) -> Dict[str, str]:
        """Ambil semua secret untuk environment tertentu sebagai dict."""
        env = environment or self._default_env
        cached = self._cache.get(env)
        if cached and cached[1] > time.time():
            return dict(cached[0])

        team_id = self._resolve_team_id()
        url = f"{self._base_url}/api/v1/teams/{team_id}/secrets/export"
        res = self._request("GET", url, params={"format": "json", "environment": env})
        data: Dict[str, str] = res.json()

        if self._cache_ttl > 0:
            self._cache[env] = (data, time.time() + self._cache_ttl)
        return dict(data)

    def inject(
        self,
        *,
        environment: Optional[str] = None,
        overwrite: bool = False,
    ) -> List[str]:
        """Inject semua secret ke ``os.environ``.

        Return:
            list nama secret yang di-inject.
        """
        secrets = self.get_all(environment=environment)
        injected: List[str] = []
        for name, value in secrets.items():
            if overwrite or name not in os.environ:
                os.environ[name] = value
                injected.append(name)
        return injected

    def clear_cache(self) -> None:
        """Clear local cache. Berguna kalau kamu tahu ada secret baru di push."""
        self._cache.clear()

    # ─── Internal ──────────────────────────────────────────

    def _resolve_team_id(self) -> str:
        if self._resolved_team_id:
            return self._resolved_team_id

        if _UUID_RE.match(self._team_input):
            self._resolved_team_id = self._team_input
            return self._resolved_team_id

        url = f"{self._base_url}/api/v1/teams"
        res = self._request("GET", url)
        data = res.json()
        for t in data.get("teams", []):
            if t.get("slug") == self._team_input:
                self._resolved_team_id = t["id"]
                return self._resolved_team_id

        raise CalveryError(
            f'Team dengan slug "{self._team_input}" tidak ditemukan di akun ini'
        )

    def _request(self, method: str, url: str, **kwargs) -> requests.Response:
        last_exc: Optional[Exception] = None
        for attempt in range(self._max_retries + 1):
            try:
                res = self._session.request(
                    method,
                    url,
                    timeout=self._timeout,
                    **kwargs,
                )

                if res.status_code in (401, 403):
                    msg = _safe_error(res) or "Tidak berwenang"
                    raise CalveryAuthError(msg)

                if res.status_code >= 500 and attempt < self._max_retries:
                    time.sleep(_backoff(attempt))
                    continue

                if not res.ok:
                    msg = _safe_error(res) or f"HTTP {res.status_code}"
                    raise CalveryServerError(res.status_code, msg)

                return res

            except CalveryAuthError:
                raise
            except CalveryServerError:
                if attempt >= self._max_retries:
                    raise
                time.sleep(_backoff(attempt))
            except requests.RequestException as e:
                last_exc = e
                if attempt < self._max_retries:
                    time.sleep(_backoff(attempt))
                    continue
                raise CalveryNetworkError(
                    f"Gagal konek ke {self._base_url} setelah "
                    f"{self._max_retries + 1} percobaan: {e}"
                ) from e

        # Seharusnya tidak sampai sini
        raise CalveryNetworkError(f"Unreachable: {last_exc}")


def _backoff(attempt: int) -> float:
    """Exponential backoff dengan jitter: 0.1s, 0.25s, 0.5s + jitter."""
    base = min(0.1 * (2 ** attempt), 2.0)
    return base + random.random() * 0.1


def _safe_error(res: requests.Response) -> Optional[str]:
    try:
        return res.json().get("error")
    except Exception:
        return None
