"""Exception types yang di-raise SDK."""


class CalveryError(Exception):
    """Base error untuk semua SDK exception. Catch ini untuk handle generic."""


class CalveryAuthError(CalveryError):
    """Token invalid / expired (401) atau akses team ditolak (403)."""


class CalverySecretNotFoundError(CalveryError):
    """Secret yang diminta tidak ada di team + environment tersebut."""

    def __init__(self, name: str, environment: str):
        super().__init__(
            f'Secret "{name}" tidak ditemukan di environment "{environment}"'
        )
        self.name = name
        self.environment = environment


class CalveryNetworkError(CalveryError):
    """Network / connection error — sudah retry habis."""


class CalveryServerError(CalveryError):
    """Server 5xx setelah semua retry gagal."""

    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
