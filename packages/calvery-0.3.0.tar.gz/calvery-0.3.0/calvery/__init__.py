"""Official Python SDK for Calvery Vault — https://calvery.xyz"""

from .client import Calvery
from .errors import (
    CalveryError,
    CalveryAuthError,
    CalveryNetworkError,
    CalveryServerError,
    CalverySecretNotFoundError,
)

__version__ = "0.1.0"
__all__ = [
    "Calvery",
    "CalveryError",
    "CalveryAuthError",
    "CalveryNetworkError",
    "CalveryServerError",
    "CalverySecretNotFoundError",
]
