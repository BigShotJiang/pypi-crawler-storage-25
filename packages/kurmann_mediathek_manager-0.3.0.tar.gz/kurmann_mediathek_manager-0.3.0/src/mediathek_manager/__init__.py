"""Mediathek Manager – Generiert statische HTML-Bibliotheken aus Videodateien."""
