"""Request/Result-Modelle und Datenstrukturen für die Public API."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from pathlib import Path, PurePosixPath


@dataclass
class Chapter:
    """Ein Kapitel innerhalb eines Videos."""

    title: str
    start_seconds: float


@dataclass
class VideoMetadata:
    """Gesammelte Metadaten eines Videos aus eingebetteten Daten und optionalem YAML-Sidecar."""

    relative_path: str
    title: str
    artist: str | None = None
    album: str | None = None
    genre: str | None = None
    tags: list[str] = field(default_factory=list)
    description: str | None = None
    long_description: str | None = None
    chapters: list[Chapter] = field(default_factory=list)
    content_create_date: datetime | None = None
    duration_seconds: float | None = None
    resolution: str | None = None
    bitrate: str | None = None
    comment: str | None = None
    poster_sidecar: str | None = None
    """Relativer Pfad einer Poster-Sidecar-Datei (z. B. ``ferien/urlaub-poster.jpg``),
    falls vorhanden — sonst ``None``. Der Mediathek Manager extrahiert selbst keine
    Vorschaubilder; er konsumiert nur existierende Sidecars."""
    fanart_sidecar: str | None = None
    """Relativer Pfad einer Fanart-Sidecar-Datei (z. B. ``ferien/urlaub-fanart.jpg``),
    falls vorhanden. Wird auf Detailseiten als Hero-Bild im ``<video poster="…">``
    verwendet; Card-Thumbnails nutzen weiterhin das Poster-Sidecar."""
    display_path: str | None = None
    """Optionaler Layout-Pfad: wenn gesetzt, nutzt der Generator diesen Pfad für
    Index-Filter, Detail-URL und Breadcrumb — als läge das Video direkt dort.
    Der echte Pfad (``relative_path``) wird weiterhin für die Video-Source-Referenz
    verwendet. Wird gesetzt, wenn das umgebende Verzeichnis als Medienset erkannt
    wurde (Infuse-Konvention)."""
    embedded_cover_stream_index: int | None = None
    """Index des ``attached_pic``-Streams im Video, falls das Video im Header ein
    eingebettetes Coverbild trägt (``disposition.attached_pic == 1``). Wird aus
    ``ffprobe -show_streams`` gelesen und später — wenn kein ``{stem}-poster.jpg``
    neben dem Video liegt — via ffmpeg verlustfrei (``-c copy``) nach
    ``mediathek/embedded-poster/…`` extrahiert und als Poster-Fallback für
    Grid-Cards verwendet. Beim Mediathek Manager werden keine neuen Bilder
    erzeugt — das Atom existiert bereits im Datei-Header."""

    @property
    def file_name(self) -> str:
        return PurePosixPath(self.relative_path).name

    @property
    def file_stem(self) -> str:
        return PurePosixPath(self.relative_path).stem

    @property
    def file_suffix(self) -> str:
        return PurePosixPath(self.relative_path).suffix

    @property
    def layout_path(self) -> str:
        """Pfad für Layout-Zwecke (Index-Filter, Detail-URL, Breadcrumb).

        Default: ``relative_path``. Bei Medienset-Videos wird ``display_path``
        gesetzt und überschreibt den Pfad hier — die tatsächliche Videodatei
        bleibt aber unter ``relative_path`` erreichbar.
        """
        return self.display_path or self.relative_path


@dataclass
class GenerateLibraryRequest:
    """Fachlicher Request: Bibliothek generieren."""

    source_path: str
    recursive: bool = True
    title: str | None = None
    show_card_titles: bool = False
    """Wenn ``True``, wird der Video-Titel zusätzlich als Textzeile unter jeder
    Grid-Card gerendert. Default (``False``) setzt darauf, dass das Poster
    den Titel bereits zeigt (typische YouTube-Thumbnails, gestaltete
    Mediaset-Poster); der Card-Footer enthält dann nur Jahr (links) und
    Laufzeit (rechts). Platzhalter-Cards ohne Poster zeigen den Titel
    unabhängig davon weiterhin zentriert in der Platzhalter-Box."""


@dataclass
class GenerateLibraryResult:
    """Ergebnis der Bibliotheks-Generierung."""

    success: bool
    videos_processed: int = 0
    pages_generated: int = 0
    output_dir: Path | None = None
    error_message: str | None = None


@dataclass
class ScanLibraryRequest:
    """Fachlicher Request: Verzeichnis scannen."""

    source_path: str
    recursive: bool = True


@dataclass
class ScanLibraryResult:
    """Ergebnis des Scans."""

    success: bool
    videos: list[VideoMetadata] = field(default_factory=list)
    error_message: str | None = None


@dataclass
class NameCheckIssue:
    """Eine am Quellpfad gefundene Dateinamens-Auffälligkeit.

    Gespiegelt aus ``core.name_checker.NameIssue`` für die öffentliche API —
    Aufrufer sollen nicht direkt gegen das interne Core-Modul programmieren.
    """

    path: str
    tags: list[str] = field(default_factory=list)
    details: list[str] = field(default_factory=list)


@dataclass
class CheckNamesRequest:
    """Fachlicher Request: Dateinamen auf SMB/URL/APFS-Probleme prüfen."""

    source_path: str
    recursive: bool = True


@dataclass
class CheckNamesResult:
    """Ergebnis der Dateinamens-Prüfung.

    Der Mediathek Manager ist ein Read-only-Werkzeug — ``check-names`` meldet
    nur, was auffällig ist, und verändert nichts an der Quelle. Der Nutzer
    entscheidet selbst, ob und wie umbenannt wird.
    """

    success: bool
    total_checked: int = 0
    issues: list[NameCheckIssue] = field(default_factory=list)
    error_message: str | None = None


@dataclass
class RuntimeOptions:
    """Technische Laufzeitoptionen, getrennt vom fachlichen Request."""

    ffprobe_path: str = "ffprobe"
    ffmpeg_path: str = "ffmpeg"
    """Pfad zu ffmpeg. Wird **ausschließlich** genutzt, um ein bereits im Video-
    Header vorhandenes ``attached_pic``-Atom verlustfrei (``-c copy``) als
    Poster-Fallback zu extrahieren — der Mediathek Manager erzeugt weiterhin
    keine Vorschaubilder aus dem Videoinhalt selbst. Fehlt ffmpeg, bleibt die
    Extraktion aus: Videos ohne ``-poster.jpg``-Sidecar behalten die
    Platzhalter-Card."""
    rclone_path: str = "rclone"


class MediathekStage(StrEnum):
    """Stabile Bezeichner für Event-Stufen."""

    SCAN_STARTED = "scan_started"
    SCAN_COMPLETED = "scan_completed"
    METADATA_READING = "metadata_reading"
    COVER_EXTRACTING = "cover_extracting"
    HTML_GENERATING = "html_generating"
    RCLONE_SYNCING = "rclone_syncing"
    LIBRARY_COMPLETED = "library_completed"


@dataclass
class MediathekEvent:
    """Strukturiertes Event für Fortschrittsanzeige."""

    stage_id: MediathekStage
    message: str
    current: int | None = None
    total: int | None = None
