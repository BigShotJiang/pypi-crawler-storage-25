"""API-Fassade – öffentliche Einstiegspunkte für den Mediathek Manager."""

from __future__ import annotations

import shutil
import tempfile
from collections.abc import Callable
from pathlib import Path, PurePosixPath

from .models import (
    CheckNamesRequest,
    CheckNamesResult,
    GenerateLibraryRequest,
    GenerateLibraryResult,
    MediathekEvent,
    MediathekStage,
    NameCheckIssue,
    RuntimeOptions,
    ScanLibraryRequest,
    ScanLibraryResult,
    VideoMetadata,
)


def scan_library(
    request: ScanLibraryRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediathekEvent], None] | None = None,
) -> ScanLibraryResult:
    """Scannt ein Verzeichnis und gibt Metadaten aller gefundenen Videos zurück."""
    runtime = runtime or RuntimeOptions()
    try:
        from ..services.storage import create_backend
        from ..core.scanner import scan_videos
        from ..core.metadata import extract_metadata

        backend = create_backend(request.source_path, runtime)
        video_paths = scan_videos(backend, recursive=request.recursive)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_COMPLETED,
                message=f"{len(video_paths)} Videodateien gefunden",
            ))

        videos: list[VideoMetadata] = []
        for i, rp in enumerate(video_paths):
            if on_event:
                on_event(MediathekEvent(
                    stage_id=MediathekStage.METADATA_READING,
                    message=f"Lese Metadaten: {PurePosixPath(rp).name}",
                    current=i + 1,
                    total=len(video_paths),
                ))
            metadata = extract_metadata(backend, rp, runtime)
            videos.append(metadata)

        return ScanLibraryResult(success=True, videos=videos)

    except Exception as e:
        return ScanLibraryResult(success=False, error_message=str(e))


def generate_library(
    request: GenerateLibraryRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediathekEvent], None] | None = None,
) -> GenerateLibraryResult:
    """Generiert eine statische HTML-Bibliothek aus einem Videoverzeichnis.

    Erzeugt eine einzelne Bibliothek mit Root = ``source_path``. Im Root-Verzeichnis
    liegt nur ``index.html`` (neben den Videos); alle weiteren HTML-Dateien, Poster
    und CSS liegen unter ``mediathek/``. Die Hierarchie wird gespiegelt.
    """
    runtime = runtime or RuntimeOptions()
    try:
        from ..services.storage import create_backend, RcloneBackend
        from ..core.scanner import scan_videos, find_all_subdirectories, detect_media_sets
        from ..core.metadata import extract_metadata
        from ..core.generator import generate_html

        backend = create_backend(request.source_path, runtime)
        is_remote = isinstance(backend, RcloneBackend)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_STARTED,
                message=f"Scanne {request.source_path}",
            ))

        # Alle Videos rekursiv sammeln (oder nur Root bei --no-recursive)
        video_paths = scan_videos(backend, recursive=request.recursive)
        subdirectories = find_all_subdirectories(backend) if request.recursive else []

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_COMPLETED,
                message=f"{len(video_paths)} Videos, {len(subdirectories)} Unterverzeichnisse",
            ))

        # Metadaten extrahieren
        videos: list[VideoMetadata] = []
        for i, rp in enumerate(video_paths):
            if on_event:
                on_event(MediathekEvent(
                    stage_id=MediathekStage.METADATA_READING,
                    message=f"Lese Metadaten: {PurePosixPath(rp).name}",
                    current=i + 1,
                    total=len(video_paths),
                ))
            metadata = extract_metadata(backend, rp, runtime)
            videos.append(metadata)

        # Medienset-Verzeichnisse erkennen (Infuse-Konvention): Ordner mit genau
        # einem Video, dessen Stem dem Ordnernamen entspricht, werden nicht als
        # Zwischen-Ordner gerendert — das Video erscheint direkt im Parent.
        media_sets = detect_media_sets(videos, subdirectories)
        if media_sets:
            subdirectories = [s for s in subdirectories if s not in media_sets]
            for sub_path, video in media_sets.items():
                parent = str(PurePosixPath(sub_path).parent)
                prefix = f"{parent}/" if parent != "." else ""
                video.display_path = f"{prefix}{video.file_name}"

        # Output-Root bestimmen
        if is_remote:
            output_root = Path(tempfile.mkdtemp(prefix="mediathek-"))
        else:
            output_root = Path(request.source_path)

        # Eingebettete Cover-Atome als Poster-Fallback extrahieren.
        # Der Mediathek Manager generiert keine neuen Vorschaubilder, kopiert
        # aber verlustfrei (``ffmpeg -c copy``) ein bereits im Datei-Header
        # vorhandenes ``attached_pic``-Atom in die Mediathek, wenn kein
        # ``{stem}-poster.jpg`` neben dem Video liegt. Das schließt die Lücke
        # für Bibliotheken mit eingebetteten iTunes-``covr``-Atomen (typisch
        # bei M4V aus Video-Workflows), ohne auf Frame-Extraktion oder
        # ffmpeg-als-Bildgenerator zurückzugreifen.
        _extract_embedded_covers(backend, videos, output_root, runtime, on_event)

        # HTML generieren
        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.HTML_GENERATING,
                message="Generiere HTML-Seiten",
            ))
        library_title = request.title or backend.root_name
        pages_generated = generate_html(
            library_title=library_title,
            videos=videos,
            subdirectories=subdirectories,
            output_root=output_root,
            show_card_titles=request.show_card_titles,
        )

        # Für rclone: Output (index.html + mediathek/) zurück zum Remote synchronisieren
        if is_remote:
            if on_event:
                on_event(MediathekEvent(
                    stage_id=MediathekStage.RCLONE_SYNCING,
                    message=f"Synchronisiere Mediathek zu {request.source_path}",
                ))
            _sync_generated_files_to_remote(backend, output_root)
            shutil.rmtree(output_root, ignore_errors=True)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.LIBRARY_COMPLETED,
                message=f"Bibliothek generiert: {request.source_path}",
            ))

        return GenerateLibraryResult(
            success=True,
            videos_processed=len(videos),
            pages_generated=pages_generated,
            output_dir=output_root if not is_remote else None,
        )

    except Exception as e:
        return GenerateLibraryResult(success=False, error_message=str(e))


def check_names(
    request: CheckNamesRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediathekEvent], None] | None = None,
) -> CheckNamesResult:
    """Prüft Dateinamen in einer Quelle auf SMB/URL/APFS-Kompatibilität.

    Read-only-Diagnose: der Mediathek Manager benennt niemals um. Gemeldet
    werden NFD-Unicode, URL-reservierte Zeichen (``#?&+%``), Windows-
    verbotene Zeichen, Überlängen, führende/abschließende Whitespaces,
    reservierte Windows-Basenamen und Groß-/Kleinschreibungs-Kollisionen.

    Der Aufrufer entscheidet aus dem Resultat, ob und wie umbenannt wird —
    typisch über ``convmv -f utf-8 -t utf-8 --nfc`` (NFD→NFC) oder eine
    manuelle Korrektur im Finder/Terminal.
    """
    runtime = runtime or RuntimeOptions()
    try:
        from ..services.storage import create_backend
        from ..core.scanner import scan_videos, find_all_subdirectories
        from ..core.name_checker import check_paths, NameIssue

        backend = create_backend(request.source_path, runtime)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_STARTED,
                message=f"Scanne {request.source_path}",
            ))

        video_paths = scan_videos(backend, recursive=request.recursive)
        subdirs = find_all_subdirectories(backend) if request.recursive else []

        # Dedupliziert: Videos + Verzeichnisse gemeinsam prüfen, damit
        # Auffälligkeiten in reinen Ordnernamen (z. B. ``Bäbibett & Co``)
        # nicht übersehen werden.
        all_paths: list[str] = []
        seen: set[str] = set()
        for p in list(video_paths) + list(subdirs):
            if p not in seen:
                seen.add(p)
                all_paths.append(p)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_COMPLETED,
                message=f"{len(all_paths)} Pfade prüfen",
            ))

        raw_issues: list[NameIssue] = check_paths(all_paths)
        issues = [
            NameCheckIssue(path=i.path, tags=list(i.tags), details=list(i.details))
            for i in raw_issues
        ]

        return CheckNamesResult(
            success=True,
            total_checked=len(all_paths),
            issues=issues,
        )

    except Exception as e:
        return CheckNamesResult(success=False, error_message=str(e))


def _extract_embedded_covers(
    backend,
    videos: list[VideoMetadata],
    output_root: Path,
    runtime: RuntimeOptions,
    on_event: Callable[[MediathekEvent], None] | None,
) -> None:
    """Extrahiert eingebettete ``attached_pic``-Atome als Poster-Fallback.

    Läuft **nur** für Videos, die:
    1. einen ``attached_pic``-Stream im Header tragen (aus ffprobe bekannt), und
    2. noch kein ``{stem}-poster.jpg``-Sidecar haben.

    Die extrahierten Bilder landen unter
    ``<output_root>/mediathek/embedded-poster/<layout_stem>.jpg`` — also
    hierarchie-gespiegelt wie die Detail-Seiten. Nach erfolgreicher Extraktion
    wird ``metadata.poster_sidecar`` auf diesen Pfad gesetzt, sodass die
    bestehenden Template-Pfade (``_poster_url``) unverändert funktionieren.

    **Idempotenz** (nur LocalBackend): Wenn die Ziel-JPG-Datei bereits
    existiert und mindestens so jung ist wie das Quellvideo, wird die
    Extraktion übersprungen. Das spart bei unveränderten Bibliotheken auf
    SMB-Mounts den teuren Re-Read des Video-Streams (ffmpeg muss das
    moov-Atom finden, was bei MP4-am-Ende-Layout die ganze Datei liest).
    Für RcloneBackend greift der Skip nicht, weil ``output_root`` bei
    rclone ein frisches Temp-Verzeichnis ist — dort gibt es keine
    Voraus-Version der Datei zum Vergleich. Wer rclone-Idempotenz braucht,
    mountet die Freigabe als SMB und nutzt die LocalBackend-Route.

    Schlägt die Extraktion fehl (fehlender ffmpeg, Timeout, Pipe-Fehler), wird
    das Video weiterhin mit einer Platzhalter-Card gerendert — kein Abbruch.
    """
    candidates = [
        v for v in videos
        if v.embedded_cover_stream_index is not None and v.poster_sidecar is None
    ]
    if not candidates:
        return

    # LocalBackend stellt ``root_path`` bereit — daraus leiten wir den
    # echten Dateipfad des Quellvideos ab, um dessen mtime mit dem
    # bereits extrahierten Cover zu vergleichen. RcloneBackend hat kein
    # ``root_path``; dann bleibt ``source_root = None`` und die Idempotenz
    # ist per Konstruktion deaktiviert.
    source_root: Path | None = getattr(backend, "root_path", None)
    if not isinstance(source_root, Path):
        source_root = None

    embedded_dir_rel = PurePosixPath("mediathek/embedded-poster")
    total = len(candidates)
    for i, video in enumerate(candidates, start=1):
        layout_posix = PurePosixPath(video.layout_path)
        rel_poster = embedded_dir_rel / layout_posix.with_suffix(".jpg")
        out_local = output_root / rel_poster

        # Idempotenz-Check: bereits extrahiertes Cover ist aktuell genug.
        if source_root is not None and _cached_cover_is_fresh(
            source_root / video.relative_path, out_local
        ):
            video.poster_sidecar = str(rel_poster)
            continue

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.COVER_EXTRACTING,
                message=f"Extrahiere Cover: {layout_posix.name}",
                current=i,
                total=total,
            ))

        try:
            ok = backend.extract_attached_pic(
                video.relative_path,
                int(video.embedded_cover_stream_index),
                out_local,
                runtime,
            )
        except Exception:  # noqa: BLE001 — Cover-Extraktion darf Lauf nicht killen
            ok = False

        if ok:
            # ``poster_sidecar`` ist ein Pfad relativ zu ``output_root`` — das
            # matcht sowohl echte Sidecars neben dem Video als auch unsere
            # neu erzeugten embedded-Poster unter ``mediathek/…``. Der
            # Generator resolved beide über dieselbe ``_poster_url``-Logik.
            video.poster_sidecar = str(rel_poster)


def _cached_cover_is_fresh(source_video: Path, cached_cover: Path) -> bool:
    """Prüft, ob ein bereits extrahiertes Cover noch gültig ist.

    Gültig heißt: das Cover-JPG existiert und seine ``mtime`` ist mindestens
    so jung wie die des Quellvideos. Wenn das Video seit der letzten
    Extraktion neu kodiert oder ersetzt wurde, ist das Cover veraltet und
    wird neu gezogen. Jeder OS-Fehler beim Stat (z. B. Rechteproblem auf
    SMB-Share) führt zu ``False`` — sicherer Fallback auf Re-Extraktion.
    """
    try:
        if not cached_cover.exists():
            return False
        return cached_cover.stat().st_mtime >= source_video.stat().st_mtime
    except OSError:
        return False


def _sync_generated_files_to_remote(backend, output_root: Path) -> None:
    """Synchronisiert generierte Dateien (index.html + mediathek/) auf das Remote.

    Kopiert ``index.html`` direkt und synct ``mediathek/`` rekursiv. Videos im Temp
    sind nicht vorhanden — es werden nur die neu erzeugten Artefakte übertragen.
    """
    index_file = output_root / "index.html"
    mediathek_dir = output_root / "mediathek"

    if index_file.exists():
        backend.copy_local_to_remote(index_file, "index.html")
    if mediathek_dir.exists():
        backend.sync_to_remote(mediathek_dir, "mediathek")
