"""Diagnose-Modul: prüft Dateinamen auf SMB/URL/APFS-Kompatibilität.

Der Mediathek Manager verändert niemals Quelldateien — dieses Modul ist ein
reines Read-only-Diagnosewerkzeug. Es hilft, Bibliotheken so zu benennen,
dass ``index.html`` per Doppelklick im SMB-gemounteten Finder öffnet und
die Video-Links über das ``file://``-Schema funktionieren.

Geprüfte Klassen:

``NFD``
    macOS APFS und SMB-Mounts speichern Umlaute dekomponiert (``a`` + ``¨``).
    Bei URL-Encoding baut der Browser daraus ``%CC%88``-Kaskaden, die manche
    Player / Downloader nicht auflösen. NFC ist das Zielformat — die
    gleiche Umlaut-Form, die z. B. git, Python, Linux-ext4 und Windows-NTFS
    nativ nutzen.

``URL``
    ``#`` ``?`` ``&`` ``+`` ``%`` werden vom Browser beim Auflösen von
    ``file://``-Links besonders interpretiert. Ein ``#`` terminiert die URL
    als Fragment-Anker, ``?`` startet den Query-String, ``&`` trennt
    Parameter. Das Ergebnis ist ein stumm kaputter Link — der Player lädt
    nichts und der Browser meldet keinen Fehler.

``WIN``
    ``< > : " | ? *`` sind unter Windows/SMB in Dateinamen verboten. Wer
    die Bibliothek später auf eine Windows-Freigabe oder OneDrive legt,
    verliert diese Dateien still (``Invalid name`` beim Kopieren).

``LEN``
    Über 240 Zeichen Gesamtpfad wird unter Windows (klassischer
    MAX_PATH=260) gefährlich, weil der Mount-Point zusätzlich Platz braucht.

``TRIM``
    Führende oder abschließende Leerzeichen und trailing dots sind im
    Finder unsichtbar, aber brechen viele Tools und sind unter Windows
    gar nicht erlaubt.

``RSVD``
    ``CON``, ``PRN``, ``AUX``, ``NUL``, ``COM1``…``COM9``, ``LPT1``…``LPT9``
    sind Windows-Device-Namen und können auf NTFS nicht als Datei existieren
    (auch nicht mit Extension).

``CASE``
    Zwei Pfade, die sich nur in Groß-/Kleinschreibung unterscheiden. Auf
    APFS (case-insensitive) sind sie nicht unterscheidbar; beim
    Synchronisieren auf Linux/Windows überschreibt die eine Datei die andere.
"""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass, field
from pathlib import PurePosixPath

# Zeichen, die in ``file://``-URLs vom Browser besonders interpretiert werden
# (unabhängig vom Encoding) und deshalb zu stumm kaputten Links führen.
_URL_RESERVED: frozenset[str] = frozenset("#?&+%")

# Zeichen, die Windows/SMB in Dateinamen komplett verbietet.
# ``/`` fehlt absichtlich: das ist der Pfadtrenner und wird separat behandelt.
_WIN_FORBIDDEN: frozenset[str] = frozenset('<>:"|?*')

# Konservatives Limit für den gesamten Pfadstring. Der klassische Windows-
# MAX_PATH liegt bei 260, wir warnen etwas früher, weil SMB-Shares vorn
# Mount-Point und Share-Name anhängen.
_MAX_PATH_WARN: int = 240

# Windows-Device-Namen. Gilt für den Stem der Komponente (mit und ohne
# Extension).
_WIN_RESERVED_BASENAMES: frozenset[str] = frozenset({
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
})


@dataclass
class NameIssue:
    """Eine gefundene Auffälligkeit an einem Pfad."""

    path: str
    """Relativer Pfad (POSIX-Slashes), an dem die Auffälligkeit liegt."""

    tags: list[str] = field(default_factory=list)
    """Kurzlabels der Probleme in stabiler Reihenfolge: ``NFD``, ``URL``,
    ``WIN``, ``LEN``, ``TRIM``, ``RSVD``, ``CASE``."""

    details: list[str] = field(default_factory=list)
    """Menschlich lesbare Erläuterungen, parallel indiziert zu ``tags``."""


def check_paths(paths: list[str]) -> list[NameIssue]:
    """Prüft eine Liste relativer Pfade auf SMB/URL/APFS-Auffälligkeiten.

    Rein funktional, ohne I/O: der Aufrufer (Facade) sammelt die Pfade
    vorher über das passende Backend. Das macht dieses Modul trivial
    testbar und unabhängig vom Speicherort der Bibliothek.

    Args:
        paths: Relative Pfade, POSIX-Form (``ferien/urlaub.m4v``). Darf
            Dateinamen und Verzeichnisnamen mischen.

    Returns:
        Liste der auffälligen Pfade (keine Duplikate, keine Sortierung —
        die Reihenfolge entspricht der Input-Liste). Pfade ohne
        Auffälligkeiten tauchen nicht auf.
    """
    issues: list[NameIssue] = []

    # Case-Kollisionen: gleiche ``casefold``-Form, unterschiedliche
    # Original-Form. Wir gruppieren auf dem gesamten Pfad, weil zwei
    # Videos in verschiedenen Unterordnern nicht kollidieren, aber in
    # der gleichen Hierarchie sehr wohl.
    case_buckets: dict[str, list[str]] = {}
    for path in paths:
        case_buckets.setdefault(path.casefold(), []).append(path)
    collisions: set[str] = {
        variant
        for variants in case_buckets.values()
        if len(variants) > 1
        for variant in variants
    }

    for path in paths:
        issue = _check_single(path, collisions)
        if issue is not None:
            issues.append(issue)
    return issues


def _check_single(path: str, collisions: set[str]) -> NameIssue | None:
    tags: list[str] = []
    details: list[str] = []
    parts = PurePosixPath(path).parts

    # 1. NFD-Unicode-Check auf dem gesamten Pfad.
    if unicodedata.normalize("NFC", path) != path:
        tags.append("NFD")
        details.append("dekomponierte Unicode-Form (NFC erwartet)")

    # 2. URL-reservierte Zeichen.
    url_hits = sorted({c for c in path if c in _URL_RESERVED})
    if url_hits:
        tags.append("URL")
        details.append(f"URL-reservierte Zeichen: {' '.join(url_hits)}")

    # 3. Windows/SMB-verbotene Zeichen.
    win_hits = sorted({c for c in path if c in _WIN_FORBIDDEN})
    if win_hits:
        tags.append("WIN")
        details.append(f"unter Windows verboten: {' '.join(win_hits)}")

    # 4. Pfadlänge (gesamt).
    if len(path) > _MAX_PATH_WARN:
        tags.append("LEN")
        details.append(f"Pfadlänge {len(path)} > {_MAX_PATH_WARN} (Windows-MAX_PATH)")

    # 5. Führende/abschließende Leerzeichen oder trailing Punkte.
    # Hinweis: Ein führender ``.`` ist ok (versteckte Datei) — wir melden
    # nur trailing dots und führende/trailing Whitespaces. Zusätzlich
    # prüfen wir den Stem (Dateiname ohne Extension) auf trailing Space/
    # Punkt: Windows schneidet dort stumm ab, bevor die Extension-Logik
    # greift, sodass ``film .m4v`` zu ``film.m4v`` wird und Duplikate
    # überschreibt.
    trim_hits: list[str] = []
    for part in parts:
        if not part or part in (".", ".."):
            continue
        stem = PurePosixPath(part).stem
        if (
            part != part.strip()
            or part.endswith(".")
            or stem.endswith(" ")
            or stem.endswith(".")
        ):
            trim_hits.append(part)
    if trim_hits:
        tags.append("TRIM")
        details.append(
            "führende/abschließende Leerzeichen oder trailing Punkte: "
            + ", ".join(f"'{p}'" for p in trim_hits)
        )

    # 6. Windows-reservierte Basisnamen (CON, PRN, AUX, NUL, COM1…9, LPT1…9).
    reserved_hits = [
        part for part in parts
        if PurePosixPath(part).stem.upper() in _WIN_RESERVED_BASENAMES
    ]
    if reserved_hits:
        tags.append("RSVD")
        details.append(
            f"Windows-reservierter Basename: {', '.join(reserved_hits)}"
        )

    # 7. Groß-/Kleinschreibungs-Kollision (vorher berechnet).
    if path in collisions:
        tags.append("CASE")
        details.append("Groß-/Kleinschreibungs-Kollision mit anderem Pfad")

    if not tags:
        return None
    return NameIssue(path=path, tags=tags, details=details)
