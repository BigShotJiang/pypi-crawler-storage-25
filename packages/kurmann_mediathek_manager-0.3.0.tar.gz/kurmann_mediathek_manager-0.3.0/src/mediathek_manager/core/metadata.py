"""Extrahiert Metadaten aus Videodateien via StorageBackend."""

from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import PurePosixPath
from typing import TYPE_CHECKING

import yaml

from ..api.models import Chapter, RuntimeOptions, VideoMetadata

# Matcht einen ISO-Datum-Präfix am Anfang eines Datei-Stems, gefolgt von einem
# Separator (Leerzeichen, Unterstrich, Bindestrich) und mindestens einem
# weiteren Zeichen. Beispiele:
#   "2026-04-05 Tubelochschlucht Biel"   → ("2026","04","05","Tubelochschlucht Biel")
#   "2024-01-30_youtube_MJfn4g64bnA"     → ("2024","01","30","youtube_MJfn4g64bnA")
_ISO_PREFIX_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})[ _-](.+)$")

if TYPE_CHECKING:
    from ..services.storage import StorageBackend


def extract_metadata(
    backend: StorageBackend,
    relative_path: str,
    runtime: RuntimeOptions | None = None,
) -> VideoMetadata:
    """Extrahiert Metadaten aus einer Videodatei.

    Liest eingebettete Metadaten via ffprobe (über das Backend) und
    ergänzt/überschreibt sie mit Werten aus einer optionalen YAML-Sidecar-Datei.
    """
    runtime = runtime or RuntimeOptions()
    metadata = _read_ffprobe(backend, relative_path, runtime)

    # Filename-Anreicherung: Datum aus ISO-Präfix, Titel-Bereinigung.
    # Läuft nach ffprobe, damit ein echter ffprobe-Titel den Stem-Fallback
    # ersetzt, bevor die Heuristik den Präfix strippt.
    _enrich_from_filename(metadata)

    stem = PurePosixPath(relative_path).stem
    parent = str(PurePosixPath(relative_path).parent)
    prefix = f"{parent}/" if parent != "." else ""

    # YAML-Sidecar einlesen und mergen (legacy).
    # Breiter Fehlerfang: ein einzelner fehlgeschlagener Sidecar-Read darf
    # niemals den Gesamtlauf killen — bei rclone-Backends kann z. B. ein
    # paralleler ``rclone serve`` einen transienten Pipe-Fehler auslösen,
    # der als ``ValueError: read of closed file`` durchschlägt.
    yaml_path = f"{prefix}{stem}.yaml"
    if backend.file_exists(yaml_path):
        try:
            yaml_text = backend.read_text(yaml_path)
            _merge_sidecar(metadata, yaml_text)
        except Exception:  # noqa: BLE001 — Sidecar-Ausfall darf Lauf nicht killen
            pass

    # NFO-Sidecar (Infuse-Konvention) — überschreibt YAML wie ffprobe,
    # weil NFO die externe "offizielle" Wahrheit ist.
    nfo_path = f"{prefix}{stem}.nfo"
    if backend.file_exists(nfo_path):
        try:
            nfo_text = backend.read_text(nfo_path)
            _merge_nfo_sidecar(metadata, nfo_text)
        except Exception:  # noqa: BLE001 — Sidecar-Ausfall darf Lauf nicht killen
            pass

    # Poster Sidecar erkennen (Mediathek Manager extrahiert selbst keine Vorschaubilder)
    poster_candidate = f"{prefix}{stem}-poster.jpg"
    if backend.file_exists(poster_candidate):
        metadata.poster_sidecar = poster_candidate

    # Fanart Sidecar erkennen — wird auf Detailseiten als Hero-Bild verwendet
    fanart_candidate = f"{prefix}{stem}-fanart.jpg"
    if backend.file_exists(fanart_candidate):
        metadata.fanart_sidecar = fanart_candidate

    return metadata


def _read_ffprobe(backend: StorageBackend, relative_path: str, runtime: RuntimeOptions) -> VideoMetadata:
    """Liest Metadaten via ffprobe über das Backend."""
    try:
        stdout = backend.run_ffprobe(relative_path, runtime)
        data = json.loads(stdout)
    except (json.JSONDecodeError, RuntimeError, FileNotFoundError):
        return VideoMetadata(
            relative_path=relative_path,
            title=PurePosixPath(relative_path).stem,
        )

    fmt = data.get("format", {})
    tags = fmt.get("tags", {})

    # Video-Stream für Auflösung finden — erster "normaler" Video-Stream
    # (nicht ``attached_pic``, denn das Cover-Atom hat eigene Dimensionen).
    # Gleichzeitig nach einem ``attached_pic``-Stream suchen, der später als
    # Poster-Fallback extrahiert werden kann, wenn kein Sidecar existiert.
    resolution = None
    embedded_cover_stream_index: int | None = None
    for stream in data.get("streams", []):
        if stream.get("codec_type") != "video":
            continue
        disposition = stream.get("disposition", {}) or {}
        if disposition.get("attached_pic") == 1:
            if embedded_cover_stream_index is None:
                embedded_cover_stream_index = stream.get("index")
            continue
        if resolution is None:
            w = stream.get("width")
            h = stream.get("height")
            if w and h:
                resolution = f"{w}x{h}"

    # Kapitel parsen
    chapters = _parse_chapters(data.get("chapters", []))

    # Tags extrahieren (Grouping-Feld, getrennt durch " / ")
    grouping = tags.get("grouping", "") or tags.get("Grouping", "")
    tag_list = [t.strip() for t in grouping.split(" / ") if t.strip()] if grouping else []

    # Dauer
    duration = None
    duration_str = fmt.get("duration")
    if duration_str:
        try:
            duration = float(duration_str)
        except ValueError:
            pass

    # Bitrate
    bitrate = None
    bitrate_str = fmt.get("bit_rate")
    if bitrate_str:
        try:
            bitrate_mbps = int(bitrate_str) / 1_000_000
            bitrate = f"{bitrate_mbps:.1f} Mbps"
        except (ValueError, TypeError):
            pass

    # Erstelldatum: nur verlässliche Quellen — niemals ``creation_time``
    # (QuickTime/MP4 mvhd-Header-Timestamp) verwenden, weil das in der Praxis
    # fast immer das Encoding-/Kopierdatum ist und nicht das Aufnahmedatum.
    # Siehe z. B. Apple-Memories-MOV-Renderings, bei denen ``creation_time``
    # auf den Render-Zeitpunkt zeigt. Verlässlich ist hingegen das vom User
    # explizit gesetzte ``date``-Atom (M4V ``©day``, exiftool "Content Create
    # Date") sowie ``content_create_date``.
    content_date = _parse_date(
        tags.get("date")
        or tags.get("content_create_date")
    )

    return VideoMetadata(
        relative_path=relative_path,
        title=tags.get("title") or PurePosixPath(relative_path).stem,
        artist=tags.get("artist") or tags.get("album_artist"),
        album=tags.get("album"),
        genre=tags.get("genre"),
        tags=tag_list,
        description=tags.get("description"),
        long_description=tags.get("synopsis") or tags.get("long_description"),
        chapters=chapters,
        content_create_date=content_date,
        duration_seconds=duration,
        resolution=resolution,
        bitrate=bitrate,
        comment=tags.get("comment"),
        embedded_cover_stream_index=embedded_cover_stream_index,
    )


def _parse_chapters(chapters_data: list[dict]) -> list[Chapter]:
    """Parst ffprobe Chapter-Daten in Chapter-Objekte."""
    chapters = []
    for ch in chapters_data:
        title = ch.get("tags", {}).get("title", "")
        start = float(ch.get("start_time", 0))
        if title:
            chapters.append(Chapter(title=title, start_seconds=start))
    return chapters


def _parse_date(date_str: str | None) -> datetime | None:
    """Versucht verschiedene Datumsformate zu parsen."""
    if not date_str:
        return None

    formats = [
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
        "%Y:%m:%d %H:%M:%S",
        "%Y",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None


def _merge_sidecar(metadata: VideoMetadata, yaml_text: str) -> None:
    """Ergänzt/überschreibt Metadaten mit Werten aus YAML-Text."""
    try:
        data = yaml.safe_load(yaml_text)
    except yaml.YAMLError:
        return

    if not isinstance(data, dict):
        return

    field_mapping = {
        "title": "title",
        "artist": "artist",
        "album": "album",
        "genre": "genre",
        "description": "description",
        "long_description": "long_description",
        "comment": "comment",
    }
    for yaml_key, attr_name in field_mapping.items():
        if yaml_key in data and data[yaml_key] is not None:
            setattr(metadata, attr_name, data[yaml_key])

    if "tags" in data and isinstance(data["tags"], list):
        existing = set(metadata.tags)
        for tag in data["tags"]:
            if isinstance(tag, str) and tag not in existing:
                metadata.tags.append(tag)

    if "content_create_date" in data:
        parsed = _parse_date(str(data["content_create_date"]))
        if parsed:
            metadata.content_create_date = parsed


def _enrich_from_filename(metadata: VideoMetadata) -> None:
    """Ergänzt Datum und Titel aus dem Dateinamen — füllt nur Lücken.

    - Wenn der Stem mit ``YYYY-MM-DD<sep>...`` beginnt (sep ∈ Leerzeichen,
      Unterstrich, Bindestrich), wird ein fehlendes
      ``content_create_date`` aus dem Präfix gesetzt.
    - Wenn der aktuelle Titel identisch zum vollen Stem ist (d. h. ffprobe
      hat keinen ``title``-Tag geliefert) und ein ISO-Präfix existiert,
      wird der ISO-Präfix-Anteil aus dem Titel entfernt.
    - Wenn ffprobe bereits einen echten Titel geliefert hat (Stem != Titel),
      bleibt dieser unverändert — auch wenn der Dateiname einen ISO-Präfix
      trägt. (Beispiel: ``2024-01-30_youtube_xyz`` mit ffprobe-Titel
      "Anleitung: 3 Dioptrien …" behält den ffprobe-Titel.)
    """
    stem = PurePosixPath(metadata.relative_path).stem
    match = _ISO_PREFIX_RE.match(stem)
    if not match:
        return
    year, month, day, remainder = match.groups()
    if metadata.content_create_date is None:
        try:
            metadata.content_create_date = datetime(int(year), int(month), int(day))
        except ValueError:
            # Ungültiges Datum (z. B. 2026-13-40) — still ignorieren
            pass
    remainder = remainder.strip()
    if metadata.title == stem and remainder:
        metadata.title = remainder


def _merge_nfo_sidecar(metadata: VideoMetadata, nfo_text: str) -> None:
    """Übernimmt Felder aus einer Infuse-NFO-Datei (XML) als Override.

    Unterstützte Tags (Infuse-``<media type="…">``-Schema)::

        <title>             → metadata.title
        <published>         → metadata.content_create_date
        <genres>/<genre>    → metadata.genre (erster Eintrag)
        <authors>/<author>  → metadata.artist (erster Eintrag)
        <plot>              → metadata.long_description

    NFO-Werte überschreiben alles, was zuvor von ffprobe, Filename-Heuristik
    oder YAML-Sidecar gesetzt wurde — die NFO ist die externe Wahrheit.
    Parse-Fehler werden geschluckt (kein NFO-Merge, sonst unverändert).
    """
    try:
        root = ET.fromstring(nfo_text)
    except ET.ParseError:
        return

    title = root.findtext("title")
    if title and title.strip():
        metadata.title = title.strip()

    published = root.findtext("published")
    if published and published.strip():
        parsed = _parse_date(published.strip())
        if parsed:
            metadata.content_create_date = parsed

    # Erstes <genre> innerhalb von <genres> oder direkt
    genre = root.findtext("genres/genre") or root.findtext("genre")
    if genre and genre.strip():
        metadata.genre = genre.strip()

    # Erstes <author> innerhalb von <authors> oder direkt
    author = root.findtext("authors/author") or root.findtext("author")
    if author and author.strip():
        metadata.artist = author.strip()

    plot = root.findtext("plot")
    if plot and plot.strip():
        metadata.long_description = plot.strip()
