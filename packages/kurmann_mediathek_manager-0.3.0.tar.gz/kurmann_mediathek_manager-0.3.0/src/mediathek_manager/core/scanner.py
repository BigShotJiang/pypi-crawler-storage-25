"""Scannt Verzeichnisse nach Videodateien über das StorageBackend."""

from __future__ import annotations

import unicodedata
from pathlib import PurePosixPath
from typing import TYPE_CHECKING

from ..api.models import VideoMetadata

if TYPE_CHECKING:
    from ..services.storage import StorageBackend


def scan_videos(backend: StorageBackend, recursive: bool = False) -> list[str]:
    """Findet alle Videodateien über das Backend.

    Returns:
        Sortierte Liste relativer Pfade.
    """
    return backend.list_videos(recursive=recursive)


def find_subdirectories(backend: StorageBackend) -> list[str]:
    """Findet direkte Unterverzeichnisse (ohne versteckte)."""
    return backend.list_subdirectories()


def find_all_subdirectories(backend: StorageBackend) -> list[str]:
    """Findet alle Unterverzeichnisse rekursiv, die Videos enthalten (direkt oder transitiv).

    Leitet die Verzeichnisstruktur aus der rekursiven Videoliste ab. Enthält auch
    Zwischenverzeichnisse (z. B. ``"Familie"``, wenn nur ``"Familie/2024/video.m4v"``
    existiert).

    Returns:
        Sortierte Liste relativer Verzeichnispfade, z. B. ``["Familie", "Familie/2024", "Ferien"]``.
    """
    video_paths = backend.list_videos(recursive=True)
    subdirs: set[str] = set()
    for path in video_paths:
        parent = PurePosixPath(path).parent
        while str(parent) not in (".", ""):
            subdirs.add(str(parent))
            parent = parent.parent
    return sorted(subdirs, key=str.lower)


def detect_media_sets(
    videos: list[VideoMetadata],
    subdirectories: list[str],
) -> dict[str, VideoMetadata]:
    """Erkennt Medienset-Verzeichnisse (Infuse-Konvention).

    Ein Verzeichnis gilt als Medienset, wenn es **genau ein** Video direkt
    enthält UND dessen Dateiname ohne Erweiterung nach Normalisierung dem
    Verzeichnisnamen entspricht. Normalisierung: NFC + casefold + Leerzeichen
    werden Bindestrichen gleichgesetzt. Beispiel: Verzeichnis
    ``2026-03-22-Geburtstag-Dennis-2026`` matcht Video
    ``2026-03-22 Geburtstag Dennis 2026.mov``.

    Returns:
        Dict ``{subdir_path: medienset_video}`` — leere Map wenn keine
        Mediensets erkannt wurden.
    """
    # Gruppiere Videos nach direktem Elternverzeichnis für O(N) statt O(N*M)
    by_parent: dict[str, list[VideoMetadata]] = {}
    for video in videos:
        parent = str(PurePosixPath(video.relative_path).parent)
        by_parent.setdefault(parent, []).append(video)

    result: dict[str, VideoMetadata] = {}
    for sub in subdirectories:
        direct_videos = by_parent.get(sub, [])
        if len(direct_videos) != 1:
            continue
        video = direct_videos[0]
        sub_name = PurePosixPath(sub).name
        if _normalize_for_match(video.file_stem) == _normalize_for_match(sub_name):
            result[sub] = video
    return result


def _normalize_for_match(text: str) -> str:
    """Normalisiert Strings für den Medienset-Namensvergleich.

    Unicode NFC (damit NFD-kodierte SMB-Dateinamen mit NFC-Dir-Namen matchen),
    casefold (aggressiveres lowercasing als ``.lower()``) und Leerzeichen →
    Bindestrich (Infuse-Konvention: der Ordner nutzt oft Bindestriche statt
    Leerzeichen).
    """
    normalized = unicodedata.normalize("NFC", text)
    return normalized.casefold().replace(" ", "-")
