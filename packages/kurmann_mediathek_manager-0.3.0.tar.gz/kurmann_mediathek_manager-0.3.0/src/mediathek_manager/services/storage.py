"""Abstraktion für Dateizugriff — lokal (pathlib) oder remote (rclone).

Der Mediathek Manager extrahiert selbst keine Vorschaubilder. Die Backends
liefern deshalb ausschließlich Listing-, Lese- und (bei rclone) Sync-Fähigkeiten
sowie ``run_ffprobe`` für Metadaten-Extraktion.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path, PurePosixPath
from typing import Protocol, runtime_checkable

from ..api.models import RuntimeOptions


VIDEO_EXTENSIONS = {".m4v", ".mp4", ".mkv", ".mov", ".avi", ".webm"}


@runtime_checkable
class StorageBackend(Protocol):
    """Einheitliches Interface für lokalen und rclone-basierten Dateizugriff."""

    @property
    def root_name(self) -> str:
        """Name des Wurzelverzeichnisses (für Bibliothekstitel)."""
        ...

    def list_videos(self, recursive: bool = False) -> list[str]:
        """Gibt relative Pfade aller Videodateien zurück."""
        ...

    def list_subdirectories(self) -> list[str]:
        """Gibt Namen der direkten, nicht-versteckten Unterverzeichnisse zurück."""
        ...

    def file_exists(self, relative_path: str) -> bool:
        ...

    def read_text(self, relative_path: str, encoding: str = "utf-8") -> str:
        ...

    def run_ffprobe(self, relative_path: str, runtime: RuntimeOptions) -> str:
        """Führt ffprobe auf einer Datei aus und gibt stdout (JSON) zurück.

        Bei Timeout oder Fehler: leerer String — Aufrufer soll daraus einen
        Fallback ableiten statt abzubrechen.
        """
        ...

    def extract_attached_pic(
        self,
        relative_path: str,
        stream_index: int,
        output_local: Path,
        runtime: RuntimeOptions,
    ) -> bool:
        """Extrahiert einen bereits im Header vorhandenen ``attached_pic``-Stream
        verlustfrei (``ffmpeg -c copy``) nach ``output_local``.

        Rückgabewert: ``True`` bei Erfolg, ``False`` bei jedem Fehler (fehlender
        ffmpeg, Timeout, Pipe-Fehler, ffmpeg-Non-Zero). Die Extraktion ist ein
        reiner Komfort-Fallback — schlägt sie fehl, bleibt das Video ohne
        Poster und es wird eine Platzhalter-Card gerendert.

        Der Mediathek Manager generiert keine Vorschaubilder aus dem Videoinhalt.
        Diese Methode liest ausschließlich ein bereits eingebettetes Cover-Atom
        (z. B. iTunes ``covr`` in M4V/MP4).
        """
        ...


class LocalBackend:
    """Dateizugriff über das lokale Dateisystem (pathlib)."""

    def __init__(self, root: Path) -> None:
        self._root = Path(root)

    @property
    def root_name(self) -> str:
        return self._root.name

    @property
    def root_path(self) -> Path:
        return self._root

    def list_videos(self, recursive: bool = False) -> list[str]:
        videos: list[str] = []
        if recursive:
            # Hinweis: Kein zusätzlicher ``path.exists()``-Check nach rglob. Auf
            # SMB-Mounts mit NFD-kodierten Dateinamen (z. B. ``Bäbibett``)
            # schlägt der Check fälschlich fehl, obwohl rglob die Datei findet.
            for ext in VIDEO_EXTENSIONS:
                for path in self._root.rglob(f"*{ext}"):
                    try:
                        videos.append(str(path.relative_to(self._root)))
                    except (OSError, ValueError):
                        pass
        else:
            try:
                for item in self._root.iterdir():
                    try:
                        if item.is_file() and item.suffix.lower() in VIDEO_EXTENSIONS:
                            videos.append(item.name)
                    except OSError:
                        pass
            except OSError:
                pass
        return sorted(videos, key=str.lower)

    def list_subdirectories(self) -> list[str]:
        try:
            return sorted(
                [d.name for d in self._root.iterdir()
                 if d.is_dir() and not d.name.startswith(".")],
                key=str.lower,
            )
        except OSError:
            return []

    def file_exists(self, relative_path: str) -> bool:
        try:
            return (self._root / relative_path).exists()
        except OSError:
            return False

    def read_text(self, relative_path: str, encoding: str = "utf-8") -> str:
        return (self._root / relative_path).read_text(encoding=encoding)

    def run_ffprobe(self, relative_path: str, runtime: RuntimeOptions) -> str:
        file_path = self._root / relative_path
        try:
            result = subprocess.run(
                [
                    runtime.ffprobe_path,
                    "-v", "quiet",
                    "-print_format", "json",
                    "-show_format",
                    "-show_streams",
                    "-show_chapters",
                    str(file_path),
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return ""

    def extract_attached_pic(
        self,
        relative_path: str,
        stream_index: int,
        output_local: Path,
        runtime: RuntimeOptions,
    ) -> bool:
        file_path = self._root / relative_path
        output_local.parent.mkdir(parents=True, exist_ok=True)
        try:
            result = subprocess.run(
                [
                    runtime.ffmpeg_path,
                    "-nostdin",
                    "-loglevel", "error",
                    "-y",
                    "-i", str(file_path),
                    "-map", f"0:{stream_index}",
                    "-frames:v", "1",
                    "-c", "copy",
                    str(output_local),
                ],
                capture_output=True,
                timeout=30,
            )
            return result.returncode == 0 and output_local.exists()
        except (subprocess.SubprocessError, FileNotFoundError, OSError):
            return False


class RcloneBackend:
    """Dateizugriff über rclone (SFTP, S3, etc.)."""

    def __init__(self, remote_path: str, runtime: RuntimeOptions) -> None:
        self._remote = remote_path.rstrip("/")
        self._rclone = runtime.rclone_path
        self._runtime = runtime

        # rclone-Verfügbarkeit prüfen
        try:
            subprocess.run([self._rclone, "version"], capture_output=True, timeout=5)
        except FileNotFoundError:
            raise RuntimeError(
                f"rclone nicht gefunden unter '{self._rclone}'. "
                "Bitte installieren: https://rclone.org/install/"
            )

        # Verzeichnislisting einmalig cachen
        self._listing: list[dict] = self._fetch_listing()

    @property
    def root_name(self) -> str:
        # "lyssach-nas:/Familienfilme/Final" → "Final"
        path_part = self._remote.split(":", 1)[1] if ":" in self._remote else self._remote
        return PurePosixPath(path_part).name or path_part

    def _fetch_listing(self) -> list[dict]:
        """Holt die vollständige Verzeichnisstruktur via rclone lsjson."""
        try:
            result = subprocess.run(
                [self._rclone, "lsjson", "--recursive", self._remote],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                raise RuntimeError(f"rclone lsjson fehlgeschlagen: {result.stderr.strip()}")
            return json.loads(result.stdout)
        except (subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            raise RuntimeError(f"rclone Listing fehlgeschlagen: {e}")

    def list_videos(self, recursive: bool = False) -> list[str]:
        videos: list[str] = []
        for entry in self._listing:
            if entry.get("IsDir", False):
                continue
            path = entry["Path"]
            suffix = PurePosixPath(path).suffix.lower()
            if suffix not in VIDEO_EXTENSIONS:
                continue
            if not recursive and "/" in path:
                continue
            videos.append(path)
        return sorted(videos, key=str.lower)

    def list_subdirectories(self) -> list[str]:
        dirs: set[str] = set()
        for entry in self._listing:
            path = entry["Path"]
            # Direkte Unterverzeichnisse: erster Pfadteil ohne /
            if entry.get("IsDir", False) and "/" not in path.rstrip("/"):
                name = path.rstrip("/")
                if not name.startswith("."):
                    dirs.add(name)
            # Oder implizite Verzeichnisse aus Dateipfaden
            elif "/" in path:
                first_part = path.split("/")[0]
                if not first_part.startswith("."):
                    dirs.add(first_part)
        return sorted(dirs, key=str.lower)

    def file_exists(self, relative_path: str) -> bool:
        for entry in self._listing:
            if entry["Path"] == relative_path and not entry.get("IsDir", False):
                return True
        return False

    def read_text(self, relative_path: str, encoding: str = "utf-8") -> str:
        """Liest eine Textdatei via ``rclone cat``.

        Normalisiert alle Fehlerklassen (Subprocess-Fehler, Pipe-Probleme
        wie ``ValueError: read of closed file`` bei FD-Race mit parallelen
        rclone-Prozessen, Timeouts) auf ``FileNotFoundError`` — Aufrufer wie
        ``extract_metadata`` behandeln fehlgeschlagene Sidecar-Reads dann
        einheitlich und killen den Gesamtlauf nicht.
        """
        try:
            result = subprocess.run(
                [self._rclone, "cat", f"{self._remote}/{relative_path}"],
                capture_output=True,
                text=True,
                timeout=30,
            )
        except (subprocess.SubprocessError, ValueError, OSError) as e:
            raise FileNotFoundError(
                f"rclone cat abgebrochen: {relative_path} ({e})"
            ) from e
        if result.returncode != 0:
            raise FileNotFoundError(f"rclone cat fehlgeschlagen: {relative_path}")
        return result.stdout

    def run_ffprobe(self, relative_path: str, runtime: RuntimeOptions) -> str:
        """Piped rclone cat → ffprobe für Metadaten-Extraktion.

        Achtung: Da ffprobe in der Pipe nicht seeken kann, muss bei MP4-Dateien
        mit moov-Atom am Ende die gesamte Datei gelesen werden. Bei großen
        Videos auf langsamen Verbindungen läuft das leicht in den Timeout.
        Für verlässliche rclone-Workflows empfiehlt sich stattdessen ein lokal
        gemountetes Volume (SMB/FUSE) mit ``LocalBackend``. Bei Timeout liefern
        wir leeren stdout zurück — der Aufrufer fällt dann auf Dateinamen als
        Titel zurück, ein einzelnes Video killt nicht den Gesamtlauf.
        """
        try:
            rclone_proc = subprocess.Popen(
                [self._rclone, "cat", f"{self._remote}/{relative_path}"],
                stdout=subprocess.PIPE,
            )
            ffprobe_proc = subprocess.Popen(
                [
                    runtime.ffprobe_path,
                    "-v", "quiet",
                    "-print_format", "json",
                    "-show_format",
                    "-show_streams",
                    "-show_chapters",
                    "-i", "pipe:0",
                ],
                stdin=rclone_proc.stdout,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            rclone_proc.stdout.close()
            try:
                stdout, _ = ffprobe_proc.communicate(timeout=180)
            except subprocess.TimeoutExpired:
                ffprobe_proc.kill()
                rclone_proc.kill()
                ffprobe_proc.communicate()
                rclone_proc.communicate()
                return ""
            rclone_proc.wait()
            return stdout
        except (ValueError, OSError, subprocess.SubprocessError):
            # ``ValueError: read of closed file`` kann auftreten, wenn
            # parallel ein weiterer rclone-Prozess (z. B. ``rclone serve``)
            # den SFTP-Connection-Pool beansprucht und der Pipe vor dem
            # communicate() geschlossen wird. Wir behandeln das wie einen
            # Timeout: leerer stdout, Aufrufer fällt auf Dateinamen zurück.
            return ""

    def extract_attached_pic(
        self,
        relative_path: str,
        stream_index: int,
        output_local: Path,
        runtime: RuntimeOptions,
    ) -> bool:
        """Pipet ``rclone cat`` → ``ffmpeg`` und kopiert das attached_pic-Atom
        verlustfrei in ``output_local``.

        Achtung: Wie bei ``run_ffprobe`` muss der gesamte Videodatenstrom durch
        die Pipe gelesen werden, bis ffmpeg das Cover-Atom (moov → meta → ilst
        → covr) gefunden hat. Bei moov-am-Ende-Dateien = volle Datei. Bandbreite
        ist deshalb teuer — wer das vermeiden will, legt ein ``{stem}-poster.jpg``
        neben das Video. Bei Timeout oder Fehler: ``False``, Video bleibt ohne
        Poster.
        """
        output_local.parent.mkdir(parents=True, exist_ok=True)
        rclone_proc: subprocess.Popen | None = None
        ffmpeg_proc: subprocess.Popen | None = None
        try:
            rclone_proc = subprocess.Popen(
                [self._rclone, "cat", f"{self._remote}/{relative_path}"],
                stdout=subprocess.PIPE,
            )
            ffmpeg_proc = subprocess.Popen(
                [
                    runtime.ffmpeg_path,
                    "-nostdin",
                    "-loglevel", "error",
                    "-y",
                    "-i", "pipe:0",
                    "-map", f"0:{stream_index}",
                    "-frames:v", "1",
                    "-c", "copy",
                    str(output_local),
                ],
                stdin=rclone_proc.stdout,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            rclone_proc.stdout.close()
            try:
                ffmpeg_proc.communicate(timeout=300)
            except subprocess.TimeoutExpired:
                ffmpeg_proc.kill()
                rclone_proc.kill()
                ffmpeg_proc.communicate()
                rclone_proc.communicate()
                return False
            rclone_proc.wait()
            return ffmpeg_proc.returncode == 0 and output_local.exists()
        except (ValueError, OSError, subprocess.SubprocessError):
            # Analog zu ``run_ffprobe``: ``ValueError: read of closed file``
            # und verwandte Pipe-Races dürfen die Bibliotheks-Generierung
            # nicht killen. Fallback → Platzhalter-Card.
            try:
                if ffmpeg_proc is not None:
                    ffmpeg_proc.kill()
                if rclone_proc is not None:
                    rclone_proc.kill()
            except OSError:
                pass
            return False

    def sync_to_remote(self, local_dir: Path, remote_subdir: str) -> None:
        """Synchronisiert ein lokales Verzeichnis zum Remote."""
        result = subprocess.run(
            [self._rclone, "sync", str(local_dir), f"{self._remote}/{remote_subdir}"],
            capture_output=True,
            text=True,
            timeout=600,
        )
        if result.returncode != 0:
            raise RuntimeError(f"rclone sync fehlgeschlagen: {result.stderr.strip()}")

    def copy_local_to_remote(self, local_file: Path, remote_relative_path: str) -> None:
        """Kopiert eine einzelne lokale Datei zum Remote unter einem relativen Pfad."""
        result = subprocess.run(
            [self._rclone, "copyto", str(local_file), f"{self._remote}/{remote_relative_path}"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            raise RuntimeError(f"rclone copyto fehlgeschlagen: {result.stderr.strip()}")


def create_backend(path_str: str, runtime: RuntimeOptions) -> StorageBackend:
    """Erstellt das passende Backend basierend auf dem Pfad.

    Erkennung: Enthält der Pfad ':' und ist kein existierender lokaler Pfad → rclone.
    """
    if ":" in path_str and not Path(path_str).exists():
        return RcloneBackend(path_str, runtime)
    return LocalBackend(Path(path_str))
