"""Persistente Konfiguration unter ~/.config/mediathek-manager/config.toml."""

from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "mediathek-manager"
CONFIG_FILE = CONFIG_DIR / "config.toml"

# Erlaubte Konfigurationsschlüssel mit Defaults
DEFAULTS: dict[str, str] = {
    "tools.ffprobe_path": "ffprobe",
    "tools.rclone_path": "rclone",
}


def load_config() -> dict[str, str]:
    """Lädt die Konfiguration aus der TOML-Datei.

    Gibt ein flaches Dictionary mit Punkt-getrennten Schlüsseln zurück.
    Fehlende Werte werden mit Defaults gefüllt.
    """
    config = dict(DEFAULTS)

    if CONFIG_FILE.exists():
        try:
            import tomllib
            with open(CONFIG_FILE, "rb") as f:
                data = tomllib.load(f)
            # Flache Schlüssel aus verschachtelter Struktur
            for section, values in data.items():
                if isinstance(values, dict):
                    for key, value in values.items():
                        config[f"{section}.{key}"] = str(value)
                else:
                    config[section] = str(values)
        except Exception:
            pass

    return config


def set_config(key: str, value: str) -> None:
    """Setzt einen Konfigurationswert in der TOML-Datei."""
    config = {}

    if CONFIG_FILE.exists():
        try:
            import tomllib
            with open(CONFIG_FILE, "rb") as f:
                config = tomllib.load(f)
        except Exception:
            pass

    # Punkt-getrennten Schlüssel in verschachtelte Struktur
    parts = key.split(".", 1)
    if len(parts) == 2:
        section, subkey = parts
        if section not in config:
            config[section] = {}
        config[section][subkey] = value
    else:
        config[key] = value

    # Schreiben
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        import tomli_w
        with open(CONFIG_FILE, "wb") as f:
            tomli_w.dump(config, f)
    except ImportError:
        # Fallback: manuelles TOML-Schreiben
        _write_toml_simple(config)


def _write_toml_simple(config: dict) -> None:
    """Einfacher TOML-Writer ohne externe Abhängigkeit."""
    lines: list[str] = []
    for key, value in config.items():
        if isinstance(value, dict):
            lines.append(f"[{key}]")
            for subkey, subvalue in value.items():
                lines.append(f'{subkey} = "{subvalue}"')
            lines.append("")
        else:
            lines.append(f'{key} = "{value}"')
    CONFIG_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
