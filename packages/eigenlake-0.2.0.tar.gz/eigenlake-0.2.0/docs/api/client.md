# Client API Reference

## Surface Map

- `eigenlake.connect(...)`
- `client.indexes.create_or_get(...)`
- `client.indexes.open(...)`
- `client.indexes.ref(...)`
- `index.records.*`
- `index.search.*`
- `index.search.cluster(...)`
- `index.agent.query(...)`
- `index.settings.*`
- `index.manage.*`
- `index.batch.with_size(...)`

## Top-level Module

::: eigenlake

## Client and Namespaces

::: eigenlake.client

## Schema Builder

::: eigenlake.schema

## Errors

::: eigenlake.errors
