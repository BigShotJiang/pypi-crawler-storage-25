"""Per-agent workspace creator for `meshcode setup`.

NEW MODEL (1.3.0): instead of polluting the user's global MCP config
(~/.claude.json, ~/.cursor/mcp.json, ...), each `meshcode setup <project>
<agent>` creates an isolated workspace directory at:

    ~/meshcode/<project>-<agent>/

containing a single .mcp.json with ONLY that agent's MCP server entry.
The user then runs `meshcode run <agent>` to launch their editor with
that workspace, and ONLY that one agent goes online. Closing the editor
window flips the agent offline. No cross-window status pollution.

Backward compatibility: the old `meshcode setup <client> <project>
<agent>` form still works for the global-config flow (kept for users
on Claude Desktop, which doesn't support per-instance MCP configs).
"""
import json
import os
import platform
import sys
from pathlib import Path
from typing import Dict, Any, Optional


def _load_credentials(profile: str = "default") -> Dict[str, str]:
    """Load the api key + non-secret metadata for the given keychain profile.

    1.4.1+ stores api keys in the OS keychain. The api key is read from there
    via the secrets module. Non-secret metadata (user_id / email / display_name)
    lives in ~/.meshcode/profile_meta.json. Falls back to the legacy
    credentials.json file if the migration hasn't run yet (e.g. first run after
    upgrade).
    """
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception as e:
        print(f"[meshcode] ERROR: cannot load secrets module: {e}", file=sys.stderr)
        sys.exit(2)

    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        print("[meshcode] ERROR: No credentials found. Run `meshcode login <api_key>` first.", file=sys.stderr)
        sys.exit(2)

    meta_path = Path.home() / ".meshcode" / "profile_meta.json"
    meta: Dict[str, Any] = {"api_key": api_key}
    if meta_path.exists():
        try:
            extra = json.loads(meta_path.read_text())
            if isinstance(extra, dict):
                meta.update({k: v for k, v in extra.items() if v is not None})
        except Exception:
            pass
    # Legacy fallback (pre-1.4.1): if profile_meta.json doesn't exist, try the
    # old credentials.json for non-secret fields. The api key itself is already
    # in keychain by now (via migrate_legacy_credentials).
    legacy_path = Path.home() / ".meshcode" / "credentials.json"
    if legacy_path.exists() and not meta_path.exists():
        try:
            legacy = json.loads(legacy_path.read_text())
            if isinstance(legacy, dict):
                for k in ("user_id", "email", "display_name"):
                    if legacy.get(k) and not meta.get(k):
                        meta[k] = legacy[k]
        except Exception:
            pass
    return meta


def _load_supabase_env() -> Dict[str, str]:
    """Read SUPABASE_URL/SUPABASE_KEY from env or ~/.meshcode/env, fall back to publishable defaults."""
    url = os.environ.get("SUPABASE_URL", "")
    key = os.environ.get("SUPABASE_KEY", "")
    if not url or not key:
        env_file = Path.home() / ".meshcode" / "env"
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                line = line.strip()
                if line.startswith("export "):
                    line = line[7:]
                if "=" in line:
                    k, v = line.split("=", 1)
                    v = v.strip().strip('"').strip("'")
                    if k == "SUPABASE_URL" and not url:
                        url = v
                    elif k == "SUPABASE_KEY" and not key:
                        key = v
    if not url:
        url = "https://wwgzzmydrwrjgaebspdo.supabase.co"
    if not key:
        key = "sb_publishable_0qf0U1GURopPIxLR8Vu7eQ_5grflPP4"
    return {"SUPABASE_URL": url, "SUPABASE_KEY": key}


def _resolve_project_id(api_key: str, project: str, sb: Dict[str, str]) -> str:
    """Call mc_resolve_project SECURITY DEFINER RPC to get the project_id."""
    try:
        from urllib.request import Request as _Req, urlopen as _urlopen
        body = json.dumps({"p_api_key": api_key, "p_project_name": project}).encode()
        req = _Req(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_resolve_project",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with _urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            if isinstance(data, dict) and data.get("project_id"):
                return data["project_id"]
            if isinstance(data, dict) and data.get("error"):
                print(f"[meshcode] ERROR: could not resolve project '{project}': {data['error']}", file=sys.stderr)
                sys.exit(2)
    except Exception as e:
        print(f"[meshcode] WARNING: project_id resolution failed ({e}); MCP server will retry at boot", file=sys.stderr)
    return ""


def _build_server_block(project: str, project_id: str, agent: str, role: str,
                         api_key: str, sb: Dict[str, str],
                         keychain_profile: str = "default") -> Dict[str, Any]:
    """Build the MCP server config block for an agent.

    1.4.1+ does NOT bake the api key into the env. Instead it bakes a
    `MESHCODE_KEYCHAIN_PROFILE` env var that names the keychain entry the
    MCP server should look up at boot. The api key never appears in any
    file on disk and never in process env / `ps eauxww`.

    For backwards compatibility, if the keychain isn't available on this
    OS, the api key falls back to the env var (legacy path).
    """
    env: Dict[str, str] = {
        "MESHCODE_PROJECT": project,
        "MESHCODE_PROJECT_ID": project_id,
        "MESHCODE_AGENT": agent,
        "MESHCODE_ROLE": role or "MCP-connected agent",
        "MESHCODE_KEYCHAIN_PROFILE": keychain_profile,
        "SUPABASE_URL": sb["SUPABASE_URL"],
        "SUPABASE_KEY": sb["SUPABASE_KEY"],
    }
    # Belt-and-suspenders fallback: if the OS doesn't have a keychain backend
    # the MCP server can't read the key from there, so we still need to pass
    # it via env. Probe and only include it as a fallback path.
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
        if not secrets_mod.keyring_status().get("available", False):
            env["MESHCODE_API_KEY"] = api_key
    except Exception:
        env["MESHCODE_API_KEY"] = api_key
    return {
        "command": sys.executable or "python3",
        "args": ["-m", "meshcode.meshcode_mcp", "serve"],
        "env": env,
    }


def _atomic_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(path)


# ============================================================
# WORKSPACE MODEL (1.3.0+) — one isolated dir per agent
# ============================================================

WORKSPACES_ROOT = Path.home() / "meshcode"


def _workspace_dir(project: str, agent: str) -> Path:
    return WORKSPACES_ROOT / f"{project}-{agent}"


def setup_workspace(project: str, agent: str, role: str = "",
                     keychain_profile: str = "default") -> int:
    """Create an isolated workspace dir at ~/meshcode/<project>-<agent>/ with
    .mcp.json containing ONLY this agent's server entry. Universal for any
    MCP-compatible editor that supports per-directory configs (Claude Code via
    --mcp-config flag, Cursor + Cline via .cursor/mcp.json + .vscode/mcp.json).

    keychain_profile: which entry in the OS keychain holds the api key for
    this agent. Defaults to "default" (the user's main login). For a
    friend who joined via `meshcode join <token>`, this is set to
    "mesh:<project>:<agent>" so the workspace uses the scoped guest key
    instead of the inviter's main key.
    """
    sb = _load_supabase_env()

    # Resolve api_key from the named keychain profile (NOT always 'default')
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
        api_key = secrets_mod.get_api_key(profile=keychain_profile) or ""
    except Exception as e:
        print(f"[meshcode] ERROR: cannot load secrets module: {e}", file=sys.stderr)
        return 2

    if not api_key:
        print(f"[meshcode] ERROR: no api key found in keychain profile '{keychain_profile}'", file=sys.stderr)
        if keychain_profile == "default":
            print("[meshcode]   Run `meshcode login <api_key>` first.", file=sys.stderr)
        else:
            print(f"[meshcode]   This profile is created by `meshcode join <token>`.", file=sys.stderr)
        return 2

    project_id = _resolve_project_id(api_key, project, sb)

    server_id = f"meshcode-{project}-{agent}"
    server_block = _build_server_block(project, project_id, agent, role, api_key, sb,
                                         keychain_profile=keychain_profile)

    ws = _workspace_dir(project, agent)
    ws.mkdir(parents=True, exist_ok=True)

    # Write 3 config files inside the workspace so any MCP-aware editor
    # opened in this dir picks up the meshcode server.
    #
    #   .mcp.json              — Claude Code project-scoped MCP config
    #   .cursor/mcp.json       — Cursor workspace-scoped MCP config
    #   .vscode/mcp.json       — Cline / VS Code workspace-scoped MCP config
    #
    # All three contain the SAME single server entry. Whichever editor the
    # user opens here will see exactly one agent: this one.
    server_doc = {"mcpServers": {server_id: server_block}}
    _atomic_write_json(ws / ".mcp.json", server_doc)
    _atomic_write_json(ws / ".cursor" / "mcp.json", server_doc)
    _atomic_write_json(ws / ".vscode" / "mcp.json", server_doc)

    # A tiny manifest the `meshcode run` command reads to know where this
    # workspace lives. Stored at the root so `meshcode run <agent>` can find
    # it without scanning every dir.
    registry_path = WORKSPACES_ROOT / ".registry.json"
    registry: Dict[str, Any] = {}
    if registry_path.exists():
        try:
            registry = json.loads(registry_path.read_text())
        except Exception:
            registry = {}
    registry.setdefault("agents", {})[agent] = {
        "project": project,
        "workspace": str(ws),
        "server_id": server_id,
        "role": role,
    }
    _atomic_write_json(registry_path, registry)

    # Drop a README.md so the agent's working directory isn't empty on boot.
    readme_body = f"""# {project} — {agent}

This is the MeshCode workspace for the **{agent}** agent in the **{project}** meshwork.

You are connected to the rest of your team via the meshcode MCP server, which is loaded
automatically when you open this directory in Claude Code, Cursor, or Cline.

## Your identity
- Project: {project}
- Agent name: {agent}
- Role: {role or "(set in dashboard)"}

## How this works
- Use the meshcode_* tools to communicate with other agents in the mesh.
- Use meshcode_status to see who else is in the meshwork.
- Use meshcode_send(to, message) to send messages.
- Use meshcode_wait to listen for incoming messages (your default idle state).
- Use meshcode_done(reason) when the team's task is complete.

## To launch this agent again
```bash
meshcode run {agent}
```

This is your workspace dir — feel free to scaffold any files your task needs here, or
work in a different repo by `cd`ing elsewhere after launch.
"""
    try:
        (ws / "README.md").write_text(readme_body)
    except Exception as _e:
        print(f"[meshcode] WARNING: could not write README.md: {_e}", file=sys.stderr)

    print(f"[meshcode] ✓ Workspace created for agent '{agent}' (project: {project})")
    print(f"[meshcode]   Path: {ws}")
    print(f"[meshcode]")
    print(f"[meshcode]   To launch this agent in your editor:")
    print(f"[meshcode]     meshcode run {agent}")
    print(f"[meshcode]")
    print(f"[meshcode]   Closing the editor window flips this agent offline.")
    print(f"[meshcode]   Other agents stay independent — no cross-window pollution.")
    return 0


# ============================================================
# LEGACY GLOBAL-CONFIG MODEL (kept for Claude Desktop)
# ============================================================

CLIENT_CONFIG_PATHS = {
    "claude-code": {
        "Darwin":  Path.home() / ".claude.json",
        "Linux":   Path.home() / ".claude.json",
        "Windows": Path.home() / ".claude.json",
    },
    "cursor": {
        "Darwin":  Path.home() / ".cursor" / "mcp.json",
        "Linux":   Path.home() / ".cursor" / "mcp.json",
        "Windows": Path.home() / ".cursor" / "mcp.json",
    },
    "cline": {
        "Darwin":  Path.home() / "Library" / "Application Support" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        "Linux":   Path.home() / ".config" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        "Windows": Path.home() / "AppData" / "Roaming" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
    },
    "claude-desktop": {
        "Darwin":  Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json",
        "Linux":   Path.home() / ".config" / "Claude" / "claude_desktop_config.json",
        "Windows": Path.home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json",
    },
}

CLIENT_DISPLAY_NAMES = {
    "claude-code":    "Claude Code",
    "cursor":         "Cursor",
    "cline":          "Cline (VS Code)",
    "claude-desktop": "Claude Desktop",
}


def setup_global(client: str, project: str, agent: str, role: str = "") -> int:
    """LEGACY: write to the user's GLOBAL MCP config file. All agents that
    setup this way will load in EVERY window of the editor — they all show
    online whenever any window is open. Kept for Claude Desktop and other
    clients that don't support per-instance configs."""
    if client not in CLIENT_CONFIG_PATHS:
        print(f"[meshcode] ERROR: Unknown client '{client}'. Supported: {', '.join(CLIENT_CONFIG_PATHS)}", file=sys.stderr)
        return 2

    creds = _load_credentials()
    sb = _load_supabase_env()
    api_key = creds.get("api_key", "")
    project_id = _resolve_project_id(api_key, project, sb)

    os_name = platform.system()
    config_path = CLIENT_CONFIG_PATHS[client].get(os_name)
    if config_path is None:
        print(f"[meshcode] ERROR: '{client}' is not supported on {os_name}", file=sys.stderr)
        return 2

    existing: Dict[str, Any] = {}
    if config_path.exists():
        try:
            existing = json.loads(config_path.read_text())
        except json.JSONDecodeError:
            print(f"[meshcode] WARNING: {config_path} exists but is not valid JSON.", file=sys.stderr)
            return 2

    if not isinstance(existing, dict):
        existing = {}

    servers = existing.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        print(f"[meshcode] ERROR: 'mcpServers' in {config_path} is not an object", file=sys.stderr)
        return 2

    server_id = f"meshcode-{project}-{agent}"
    servers[server_id] = _build_server_block(project, project_id, agent, role, api_key, sb)
    _atomic_write_json(config_path, existing)

    display = CLIENT_DISPLAY_NAMES[client]
    print(f"[meshcode] MCP server '{server_id}' added to {display} GLOBAL config")
    print(f"[meshcode]   Path: {config_path}")
    print(f"[meshcode]   ⚠️  Global mode: this agent will appear in EVERY window of {display}.")
    print(f"[meshcode]   For per-window agent isolation, use the workspace flow instead:")
    print(f"[meshcode]     meshcode setup {project} {agent}")
    print(f"[meshcode]     meshcode run {agent}")
    return 0


# ============================================================
# DISPATCHER (called from comms_v4.py CLI)
# ============================================================

def setup(*args) -> int:
    """Smart dispatcher.

    Forms supported:
        meshcode setup <project> <agent> [role]            → workspace flow (NEW)
        meshcode setup <client> <project> <agent> [role]   → legacy global flow

    Detection: if the first arg is one of the known client slugs, fall back
    to the legacy global flow. Otherwise treat the first arg as a project
    name and create a workspace.
    """
    if not args:
        print("Usage:", file=sys.stderr)
        print("  meshcode setup <project> <agent> [role]           # workspace flow (recommended)", file=sys.stderr)
        print("  meshcode setup <client> <project> <agent> [role]  # legacy global flow", file=sys.stderr)
        print("  Clients: claude-code, cursor, cline, claude-desktop", file=sys.stderr)
        return 1

    if args[0] in CLIENT_CONFIG_PATHS:
        if len(args) < 3:
            print("Usage: meshcode setup <client> <project> <agent> [role]", file=sys.stderr)
            return 1
        return setup_global(args[0], args[1], args[2], args[3] if len(args) > 3 else "")

    if len(args) < 2:
        print("Usage: meshcode setup <project> <agent> [role]", file=sys.stderr)
        return 1
    return setup_workspace(args[0], args[1], args[2] if len(args) > 2 else "")
