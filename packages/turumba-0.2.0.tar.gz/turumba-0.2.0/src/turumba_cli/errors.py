"""Error types for Turumba CLI."""

from __future__ import annotations


class TurumbaError(Exception):
    """Base error for all Turumba CLI errors."""


class TurumbaAuthError(TurumbaError):
    """Authentication failed — invalid credentials or expired token."""

    def __init__(self, message: str = "Authentication required. Run: turumba auth login"):
        super().__init__(message)


class TurumbaAPIError(TurumbaError):
    """API returned an error response."""

    def __init__(
        self,
        status_code: int,
        error: str,
        message: str,
        details: dict | None = None,
    ):
        self.status_code = status_code
        self.error = error
        self.details = details or {}
        super().__init__(f"[{status_code}] {error}: {message}")


class TurumbaNotFoundError(TurumbaAPIError):
    """Resource not found (404)."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(404, "not_found", message)


class TurumbaConfigError(TurumbaError):
    """Configuration is missing or invalid."""
