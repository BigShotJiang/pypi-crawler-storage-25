"""Skill topic: automation-definitions — the complete graph-authoring reference.

The single source agents query to learn how to build a valid `definition_json`:
every trigger kind, every node kind and its config, edge/port routing rules,
templating, and the per-type allow-lists the backend enforces at save/publish.
"""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="automation-definitions",
    summary="Author a valid automation definition graph: every node kind, trigger kind, and rule",
    commands=[
        "turumba automations save-definition <id> --definition-file graph.json",
        "turumba automations save-definition <id> --definition '<json>'",
        "turumba automations test <id> --event '<json>' -o json   # validate before publish",
        "turumba automations publish <id>",
    ],
    notes=[
        "=== DEFINITION SHAPE ===",
        "A definition_json is a directed graph:",
        '  {"type": "<automation type>",        # must equal the automation\'s type',
        '   "triggers": [ {"kind": ..., ...} ], # what enrolls a contact / fires a run',
        '   "nodes":    [ {"id": ..., "kind": ..., ...} ],  # the steps',
        '   "edges":    [ {"from": ..., "to": ..., "port": ...} ],  # wiring',
        '   "settings": { ... },                # type-specific (optional)',
        '   "audience": { ... } }               # broadcast only',
        "Every graph has EXACTLY ONE node of kind 'trigger' (the entry node). Every",
        "action node must be reachable from it via edges, or save/publish fails (422).",
        "",
        "=== EDGES & PORTS ===",
        'Edge: {"from": <node id>, "to": <node id>, "port": <optional>}.',
        "A node advances along its first matching outgoing edge.",
        "  - default edge: omit 'port' (or use 'default').",
        "  - condition node: TWO edges, port 'yes' and port 'no'.",
        "  - menuChoices node: one edge per choice, port == that choice's 'key'.",
        "",
        "=== TRIGGER KINDS (the triggers[] array) ===",
        "welcomeMessage  -> fires on first contact (conversation.created). "
        'config: channels (list of channel UUIDs or ["all"], default all).',
        "keyword         -> inbound message matches. config: value (str, required); "
        "match (eq|contains|icontains[default]|startswith|endswith|regex); channels.",
        "defaultReply    -> inbound fallback when NO other trigger matched. config: channels.",
        "event           -> a named domain event. config: event (str, e.g. "
        "'intake_complete', 'message.status.failed'); filter (dict, shallow equality).",
        "inactivity      -> contact silent for a window (drip; scanned by scheduler). "
        "config: window (ISO-8601 duration).",
        "schedule        -> broadcast firing. config: cron (cron expr, recurring) OR "
        "at (ISO-8601 datetime, one-shot). Exactly one of the two.",
        "dateProperty    -> a contact date property reaches an offset (daily scan). "
        "config: property, offset.",
        "contact.tagged  -> a watched tag was added (tag rules). config: tag (str, required).",
        "",
        "=== NODE KINDS (the nodes[] array) — config fields ===",
        "trigger      | (no config) the single entry node.",
        "sendMessage  | REQUIRED channel + body. optional quickReplies (list). "
        "channel = a channel UUID, a template, or '{{trigger.channel.id}}' to reply "
        "on the channel that fired the run.",
        "content      | REQUIRED content_item_id (a content-items id) + channel. "
        "Body/attachments come from the content item.",
        "waitDelay    | REQUIRED duration (ISO-8601, > 0, <= 90 days, e.g. PT2H, P1D, P3DT12H). "
        "Cannot be the last node in drip.",
        "aiPersonalize| optional intent. No-op pass-through today (turumba_ai not wired); "
        "reserved so flows can lay out where AI personalization will go.",
        "condition    | REQUIRED expr (JsonLogic tree). Routes port 'yes'/'no'. "
        'e.g. {"==": [{"var": "contact.properties.tier"}, "gold"]}.',
        "menuChoices  | REQUIRED body + choices ([{key,label}], non-empty). optional "
        "timeout (ISO-8601, default P1D), channel. Sends quick replies, parks for a "
        "reply, routes on the matched choice key.",
        "askQuestion  | REQUIRED prompt (or body) + bindTo (str — stores the answer at "
        "answers.<bindTo>). optional answerType (text[default]|choices|number|date|yesNo), "
        "choices (>=2 when answerType=choices), timeout (default P7D), strictChannel "
        "(bool — lock answer to the asking channel), channel.",
        "mutateContact| REQUIRED at least one operation. operations: [{op, ...}] and/or "
        "the properties:{key:value} shorthand. ops: addTag{tag}, removeTag{tag}, "
        "addToGroup{group_id}, removeFromGroup{group_id}, setProperty{key,value}, "
        "incrementProperty{key,by?(=1)}, unsetProperty{key}.",
        "webhook      | REQUIRED url (literal or template; must pass the account "
        "allow-list + SSRF guard). optional body (JSON tree; values are templated, "
        "keys are not). HMAC-signed automatically.",
        "actionNotify | REQUIRED title + body. optional metadata. Emits an in-app "
        "notification event (no outbound message).",
        "milestone / keyMilestone | REQUIRED milestoneKind (the user-facing label, "
        "e.g. 'intake_complete'). optional isKey (bool), metadata. Records a contact "
        "milestone. keyMilestone == milestone with isKey=true.",
        "sequence     | REQUIRED target_automation_id (an ACTIVE automation in the same "
        "account). optional context_overrides. Enrolls the contact in another "
        "automation as a sub-run; the parent advances immediately.",
        "",
        "=== WHICH NODES/TRIGGERS EACH TYPE ALLOWS (enforced at save/publish) ===",
        "autoReply  triggers: welcomeMessage|keyword|defaultReply|event (>=1). "
        "nodes: trigger, sendMessage. (1 trigger, >=1 sendMessage).",
        "drip       triggers: + inactivity. nodes: trigger, sendMessage, content, "
        "waitDelay, aiPersonalize. No cycles; the last node must be a send (no trailing "
        "waitDelay). settings.reEnrollment in {skip[default],restart,concurrent}; "
        "stopOnReply (bool); stopOnTag (str).",
        "broadcast  trigger: exactly one schedule (cron or at). nodes: trigger, "
        "sendMessage (exactly one), content, aiPersonalize. Top-level audience REQUIRED "
        "with groupIds and/or contactIds; optional excludeGroupIds, excludeContactIds, "
        "filter (JsonLogic, applied to group-resolved contacts only).",
        "survey     triggers: any (>=1). nodes: trigger, askQuestion (>=1, <=25, unique "
        "bindTo), condition, mutateContact, sendMessage.",
        "sync       triggers: any (>=1). nodes: trigger, webhook (exactly one).",
        "tagRule    triggers: any (contact.tagged needs 'tag'). nodes: trigger, "
        "condition, mutateContact (>=1). No outbound messaging nodes.",
        "flow       triggers: welcomeMessage|keyword|defaultReply|event|inactivity. "
        "nodes: ALL of the above. Conditions route yes/no; menuChoices route on choice "
        "keys; a cycle through a waitDelay is allowed (a deliberate loop).",
        "",
        "=== TEMPLATING (Handlebars subset) in body / prompt / url / webhook values ===",
        "Variables: {{contact.properties.name}}, {{contact.name}}, {{trigger.body}}, "
        "{{answers.<bindTo>}}. Missing vars render to empty string.",
        "Conditionals: {{#if x}}..{{else}}..{{/if}}, {{#unless x}}..{{/unless}}. "
        "Loops: {{#each list}}{{this}} {{@index}}{{/each}}. "
        "Helpers: upper, lower, default, formatDate.",
        "",
        "ALWAYS run `turumba automations test <id> --event '{...}' -o json` after "
        "save-definition and before publish — it walks the graph with no side effects "
        "and returns a per-node audit.",
    ],
    examples=[
        # autoReply — keyword
        "# autoReply: reply to a keyword\n"
        "turumba automations save-definition <id> --definition '"
        '{"type":"autoReply","triggers":[{"kind":"keyword","value":"hours","match":"icontains"}],'
        '"nodes":[{"id":"t","kind":"trigger"},'
        '{"id":"reply","kind":"sendMessage","channel":"{{trigger.channel.id}}",'
        '"body":"We are open 9-5, Mon-Fri."}],'
        '"edges":[{"from":"t","to":"reply"}]}\'',
        # drip — welcome series with a wait
        "# drip: 2-step welcome series, stop if they reply\n"
        "turumba automations save-definition <id> --definition '"
        '{"type":"drip","triggers":[{"kind":"welcomeMessage"}],'
        '"settings":{"reEnrollment":"skip","stopOnReply":true},'
        '"nodes":[{"id":"t","kind":"trigger"},'
        '{"id":"m1","kind":"sendMessage","channel":"<cid>","body":"Welcome {{contact.properties.name}}!"},'
        '{"id":"w","kind":"waitDelay","duration":"P1D"},'
        '{"id":"m2","kind":"sendMessage","channel":"<cid>","body":"Here is how to get started..."}],'
        '"edges":[{"from":"t","to":"m1"},{"from":"m1","to":"w"},{"from":"w","to":"m2"}]}\'',
        # broadcast — scheduled fan-out to a group
        "# broadcast: weekly Monday 9am digest to a group\n"
        "turumba automations save-definition <id> --definition '"
        '{"type":"broadcast","triggers":[{"kind":"schedule","cron":"0 9 * * MON"}],'
        '"audience":{"groupIds":["<gid>"]},'
        '"nodes":[{"id":"t","kind":"trigger"},'
        '{"id":"s","kind":"sendMessage","channel":"<cid>","body":"Weekly digest is out!"}],'
        '"edges":[{"from":"t","to":"s"}]}\'   '
        '# one-shot instead: {"kind":"schedule","at":"2026-06-01T09:00:00Z"}',
        # survey — question chain binding answers
        "# survey: rating + comment, then a thank-you using the answers\n"
        "turumba automations save-definition <id> --definition '"
        '{"type":"survey","triggers":[{"kind":"keyword","value":"survey"}],'
        '"nodes":[{"id":"t","kind":"trigger"},'
        '{"id":"q1","kind":"askQuestion","channel":"<cid>","prompt":"Rate us 1-5?","bindTo":"rating","answerType":"number"},'
        '{"id":"q2","kind":"askQuestion","prompt":"Any comments?","bindTo":"comments"},'
        '{"id":"thanks","kind":"sendMessage","channel":"<cid>","body":"Thanks! You rated us {{answers.rating}}."}],'
        '"edges":[{"from":"t","to":"q1"},{"from":"q1","to":"q2"},{"from":"q2","to":"thanks"}]}\'',
        # sync — outbound webhook on an event
        "# sync: POST contact data to an external CRM when intake completes\n"
        "turumba automations save-definition <id> --definition '"
        '{"type":"sync","triggers":[{"kind":"event","event":"intake_complete"}],'
        '"nodes":[{"id":"t","kind":"trigger"},'
        '{"id":"hook","kind":"webhook","url":"https://crm.example.com/hooks/turumba",'
        '"body":{"contact":"{{contact.id}}","name":"{{contact.properties.name}}"}}],'
        '"edges":[{"from":"t","to":"hook"}]}\'',
        # tagRule — react to a tag with mutations
        "# tagRule: when 'vip' is added, add to a group and set a property\n"
        "turumba automations save-definition <id> --definition '"
        '{"type":"tagRule","triggers":[{"kind":"contact.tagged","tag":"vip"}],'
        '"nodes":[{"id":"t","kind":"trigger"},'
        '{"id":"mut","kind":"mutateContact","operations":['
        '{"op":"addToGroup","group_id":"<gid>"},{"op":"setProperty","key":"tier","value":"gold"}]}],'
        '"edges":[{"from":"t","to":"mut"}]}\'',
        # flow — menu routing with ports
        "# flow: a menu that routes to different replies by choice key\n"
        "turumba automations save-definition <id> --definition '"
        '{"type":"flow","triggers":[{"kind":"keyword","value":"menu"}],'
        '"nodes":[{"id":"t","kind":"trigger"},'
        '{"id":"menu","kind":"menuChoices","channel":"<cid>","body":"Pick one:",'
        '"choices":[{"key":"sales","label":"Sales"},{"key":"support","label":"Support"}]},'
        '{"id":"s_sales","kind":"sendMessage","channel":"<cid>","body":"Connecting you to sales."},'
        '{"id":"s_support","kind":"sendMessage","channel":"<cid>","body":"Connecting you to support."}],'
        '"edges":[{"from":"t","to":"menu"},'
        '{"from":"menu","to":"s_sales","port":"sales"},'
        '{"from":"menu","to":"s_support","port":"support"}]}\'',
        # flow — condition branch (yes/no ports)
        "# flow: condition node branches on a contact property (ports yes/no)\n"
        '{"id":"cond","kind":"condition","expr":{"==":[{"var":"contact.properties.tier"},"gold"]}}  '
        '+ edges: {"from":"cond","to":"vip_msg","port":"yes"}, '
        '{"from":"cond","to":"std_msg","port":"no"}',
    ],
    workflows=[
        {
            "name": "Author, validate, and publish any automation",
            "steps": [
                "turumba skills show automation-definitions -o json  # this reference",
                'turumba automations create --name "..." --type <type>  # get the id',
                "# write graph.json matching the type's allow-list above",
                "turumba automations save-definition <id> --definition-file graph.json",
                "turumba automations test <id> --event '"
                '{"kind":"message.created","body":"hi","channel_id":"<cid>"}\' -o json',
                "turumba automations publish <id>",
            ],
        },
    ],
    related=["automations", "content-items", "channels", "templates", "groups"],
)

register_topics(topic)
