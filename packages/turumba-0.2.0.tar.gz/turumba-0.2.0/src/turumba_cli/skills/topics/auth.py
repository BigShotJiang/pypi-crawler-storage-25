"""Skill topic: auth."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="auth",
    summary="Authentication: login, logout, register, verify email",
    commands=[
        "turumba auth login",
        "turumba auth logout",
        "turumba auth register",
        "turumba auth verify-email",
        "turumba auth status",
    ],
    examples=[
        "turumba auth login --email user@example.com --password secret",
        "turumba auth register --email new@example.com --password secret",
        "turumba auth verify-email --email new@example.com --code 123456",
        "turumba auth status",
        "turumba auth logout",
    ],
    related=["overview"],
)

register_topics(topic)
