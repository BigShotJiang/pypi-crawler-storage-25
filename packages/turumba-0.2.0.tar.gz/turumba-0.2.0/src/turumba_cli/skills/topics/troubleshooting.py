"""Skill topic: troubleshooting."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="troubleshooting",
    summary="Common issues and debugging tips",
    commands=["turumba auth status", "turumba config list"],
    examples=[
        "turumba auth status",
        "turumba config list",
        "turumba channels test-connection --id <channel-id>",
    ],
    related=["auth", "channels"],
)

register_topics(topic)
