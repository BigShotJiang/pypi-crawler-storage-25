"""Skill topic: automations — lifecycle commands for the automation engine."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="automations",
    summary="Build, version, publish, and run message automations (the workflow engine)",
    commands=[
        "turumba automations list",
        "turumba automations get <id>",
        "turumba automations create",
        "turumba automations update <id>",
        "turumba automations delete <id>",
        "turumba automations save-definition <id> --definition-file graph.json",
        "turumba automations publish <id>",
        "turumba automations pause <id>",
        "turumba automations resume <id>",
        "turumba automations test <id> --event '{...}'",
        "turumba automations versions <id>",
        "turumba automations version <id> <ver>",
        "turumba automations runs <id>",
    ],
    create_params=[
        ParamSpec(
            name="--name / -n",
            type="string",
            required=True,
            description="Automation name",
        ),
        ParamSpec(
            name="--type / -t",
            type="enum",
            required=True,
            description="Automation type (immutable after creation)",
            enum_values=[
                "autoReply",
                "drip",
                "broadcast",
                "survey",
                "sync",
                "tagRule",
                "flow",
            ],
        ),
        ParamSpec(
            name="--description / -d",
            type="string",
            required=False,
            description="Human-readable description",
        ),
        ParamSpec(
            name="--folder-id",
            type="UUID",
            required=False,
            description="Folder to place the automation in",
        ),
        ParamSpec(
            name="--metadata",
            type="JSON string",
            required=False,
            description="Arbitrary metadata object",
        ),
    ],
    notes=[
        "LIFECYCLE: create (draft) -> save-definition (the graph) -> test (dry-run) "
        "-> publish (active) -> pause/resume. Status transitions ONLY via "
        "publish/pause/resume — never via update.",
        "`create` only sets metadata (name/type/description/folder). The actual "
        "workflow graph is a SEPARATE step: save-definition.",
        "Account is auto-injected by the gateway (x-account-ids) — no --account-id needed.",
        "TYPES: autoReply (instant reply), drip (timed sequence), broadcast "
        "(scheduled fan-out to an audience), survey (askQuestion chain), sync "
        "(outbound webhook), tagRule (tag/property mutations), flow (everything: "
        "conditions, menus, webhooks, sub-sequences).",
        "save-definition accepts the bare definition JSON (type/triggers/nodes/"
        'edges/settings) OR a full {"definition_json": {...}} body. Use '
        "--definition-file for large graphs, --definition for inline.",
        "Optimistic concurrency: pass --if-match <version> to save-definition; a "
        "stale version returns 409.",
        "ALWAYS dry-run with `test` before publish. Publish runs structural + "
        "publish-time validation (cycles, webhook allow-list) and returns 422 "
        "with structured details on failure.",
        "Definition graph schema for every type + ALL node/trigger kinds: "
        "run `turumba skills show automation-definitions`.",
        "Manual enrollment (POST /enroll) is NOT yet exposed on the gateway, so "
        "there is no `enroll` command. Contacts enter automations via their "
        "triggers (keyword, welcomeMessage, schedule, etc.).",
    ],
    examples=[
        # Create a draft
        'turumba automations create --name "Welcome reply" --type autoReply '
        '--description "Greets new inbound contacts"',
        # Save the graph from a file (see automation-definitions for the JSON)
        "turumba automations save-definition <id> --definition-file welcome.json",
        # Save inline
        "turumba automations save-definition <id> --definition '"
        '{"type":"autoReply","triggers":[{"kind":"welcomeMessage"}],'
        '"nodes":[{"id":"t","kind":"trigger"},{"id":"s","kind":"sendMessage",'
        '"channel":"<channel-uuid>","body":"Hi! Thanks for reaching out."}],'
        '"edges":[{"from":"t","to":"s"}]}\'',
        # Dry-run against a synthetic inbound message
        "turumba automations test <id> --event '"
        '{"kind":"message.created","body":"hello","channel_id":"<channel-uuid>"}\' -o json',
        # Publish / pause / resume
        "turumba automations publish <id>",
        "turumba automations pause <id>",
        "turumba automations resume <id>",
        # Inspect
        "turumba automations list -f type:eq:drip -f status:eq:active -o json",
        "turumba automations versions <id>",
        "turumba automations version <id> 2 -o json",
        "turumba automations runs <id> --state running -o json",
    ],
    workflows=[
        {
            "name": "Ship an auto-reply end to end",
            "steps": [
                "turumba channels list -o json  # get a channel UUID",
                'turumba automations create --name "Welcome reply" --type autoReply',
                "# author the graph (see: turumba skills show automation-definitions)",
                "turumba automations save-definition <id> --definition-file welcome.json",
                "turumba automations test <id> --event '"
                '{"kind":"message.created","body":"hi","channel_id":"<cid>"}\' -o json',
                "turumba automations publish <id>",
            ],
        },
        {
            "name": "Iterate on a published automation safely",
            "steps": [
                "turumba automations get <id> -o json  # note current_version",
                "turumba automations save-definition <id> --definition-file v2.json "
                "--if-match <current_version>  # 409 if someone else changed it",
                "turumba automations test <id> --event '{...}' -o json",
                "turumba automations publish <id>  # promotes the new draft",
            ],
        },
    ],
    related=["automation-definitions", "automation-folders", "automation-runs", "content-items"],
)

register_topics(topic)
