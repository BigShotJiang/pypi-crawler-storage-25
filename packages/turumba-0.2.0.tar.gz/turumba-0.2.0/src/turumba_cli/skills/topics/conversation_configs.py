"""Skill topic: conversation-configs."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="conversation-configs",
    summary="Conversation routing rules: audience targeting, creation modes, reopen policies.",
    commands=[
        "turumba conversation-configs list",
        "turumba conversation-configs get",
        "turumba conversation-configs create",
        "turumba conversation-configs update",
        "turumba conversation-configs delete",
        "turumba conversation-configs evaluate",
    ],
    examples=[
        "turumba conversation-configs list",
        "turumba conversation-configs list -f is_active:eq:true -o json",
        "turumba conversation-configs list -f audience_mode:eq:groups -s priority:desc",
        "turumba conversation-configs get <config-id>",
        'turumba conversation-configs create --name "Default Config" --priority 0',
        'turumba conversation-configs create --name "VIP Support" '
        "--priority 10 --audience-mode groups "
        '\'--audience-group-ids \'["group-uuid-1", "group-uuid-2"]\'',
        'turumba conversation-configs create --name "First Contact Only" '
        "--creation-mode first_only --reopen-policy reopen --reopen-window 60",
        "turumba conversation-configs update <config-id> --inactive",
        "turumba conversation-configs update <config-id> --priority 5 --auto-resolve-hours 24",
        "turumba conversation-configs delete <config-id> --force",
        "turumba conversation-configs evaluate "
        "--channel-type telegram --channel-id <channel-id> --known",
    ],
    workflows=[
        {
            "name": "Set up conversation routing for a new channel",
            "steps": [
                "turumba channels list  # find or create a channel",
                'turumba conversation-configs create --name "Telegram Support" '
                "--priority 10 "
                "--source-channel-ids '[\"<channel-id>\"]'",
                "turumba conversation-configs list -s priority:desc  # verify priority order",
            ],
        },
        {
            "name": "Configure VIP group routing",
            "steps": [
                "turumba conversation-configs create "
                '--name "VIP Routing" '
                "--audience-mode groups "
                "--audience-group-ids '[\"<vip-group-id>\"]' "
                "--priority 100 "
                "--default-team-id <team-id>",
            ],
        },
        {
            "name": "Test which config matches for an inbound message",
            "steps": [
                "turumba conversation-configs evaluate "
                "--channel-type telegram --channel-id <channel-id> --known",
            ],
        },
    ],
    related=["channels", "contacts", "sending"],
)

register_topics(topic)
