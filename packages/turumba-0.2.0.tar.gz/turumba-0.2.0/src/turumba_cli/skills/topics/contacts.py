"""Skill topic: contacts — complete parameter specs for one-shot agent execution."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="contacts",
    summary="Manage contacts (dynamic-property contact records)",
    commands=[
        "turumba contacts list",
        "turumba contacts get <contact-id>",
        "turumba contacts create",
        "turumba contacts update <contact-id>",
        "turumba contacts delete <contact-id>",
    ],
    create_params=[
        ParamSpec(
            name="--account-id / -a",
            type="UUID",
            required=True,
            description="Account ID. Falls back to config default_account_id",
        ),
        ParamSpec(
            name="--properties / -p",
            type="JSON string",
            required=False,
            description="Dynamic key-value properties (e.g. phone, email, name, address)",
            default="{}",
        ),
    ],
    notes=[
        "account_id is REQUIRED by the API. Use --account-id or set default: "
        "turumba config set default_account_id <uuid>",
        "Contacts are stored in MongoDB with dynamic properties.",
        "Properties are free-form key-value pairs. Common fields: name, phone, "
        "email, address, company, notes.",
        "Contacts differ from Persons: contacts are simple records; "
        "persons support group membership.",
    ],
    examples=[
        # One-shot with account_id
        "turumba contacts create --account-id 66a08c9b-... "
        '--properties \'{"phone": "+251911123456", "name": "Abebe Kebede"}\'',
        # Using default account_id
        'turumba contacts create --properties \'{"phone": "+251911123456", '
        '"name": "Abebe", "email": "abebe@example.com"}\'',
        # List
        "turumba contacts list -o json",
        "turumba contacts get <contact-id> -o json",
        'turumba contacts update <contact-id> --properties \'{"email": "new@example.com"}\'',
        'turumba contacts update <contact-id> --properties \'{"phone": "+251911..."}\' --replace',
    ],
    workflows=[
        {
            "name": "Create a contact and send a message",
            "steps": [
                'turumba contacts create --properties \'{"phone": "+251911...", '
                '"name": "Abebe"}\' -o json',
                "turumba channels list -f channel_type:eq:sms -o json",
                "turumba group-messages create --contact-id <contact-id> "
                '--channel-id <cid> --body "Hello Abebe!"',
            ],
        },
    ],
    related=["persons", "sending", "group-messages"],
)

register_topics(topic)
