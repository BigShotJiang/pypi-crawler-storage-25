"""Skill topic: scheduled-messages — complete parameter specs for one-shot agent execution."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="scheduled-messages",
    summary="Schedule one-time or recurring messages to individuals or groups",
    commands=[
        "turumba scheduled-messages list",
        "turumba scheduled-messages get <id>",
        "turumba scheduled-messages create",
        "turumba scheduled-messages update <id>",
        "turumba scheduled-messages delete <id>",
    ],
    create_params=[
        ParamSpec(
            name="--send-type",
            type="enum",
            required=True,
            description="Send type",
            enum_values=["single", "group"],
        ),
        ParamSpec(
            name="--scheduled-at",
            type="ISO 8601 datetime",
            required=True,
            description="When to send (e.g. 2026-04-01T09:00:00Z)",
        ),
        ParamSpec(
            name="--body / -b",
            type="string",
            required=True,
            description="Message body text",
            condition="required if no --template-id",
        ),
        ParamSpec(
            name="--template-id / -t",
            type="UUID",
            required=True,
            description="Template ID to use instead of --body",
            condition="required if no --body",
        ),
        ParamSpec(
            name="--delivery-address / -d",
            type="string",
            required=True,
            description="Recipient phone/address",
            condition="required when --send-type single",
        ),
        ParamSpec(
            name="--group-id",
            type="string (repeatable)",
            required=True,
            description="Group ID(s) to send to",
            condition="required when --send-type group",
        ),
        ParamSpec(
            name="--account-id / -a",
            type="UUID",
            required=False,
            description="Account ID. Falls back to config default_account_id",
        ),
        ParamSpec(
            name="--channel-id / -c",
            type="UUID",
            required=False,
            description="Channel ID to send through",
        ),
        ParamSpec(
            name="--name / -n",
            type="string",
            required=False,
            description="Message name for tracking",
        ),
        ParamSpec(
            name="--contact-id",
            type="string",
            required=False,
            description="Contact ID (for single send, links message to contact)",
        ),
        ParamSpec(
            name="--exclude-person-id",
            type="string (repeatable)",
            required=False,
            description="Person ID(s) to exclude (group send only)",
        ),
        ParamSpec(
            name="--timezone",
            type="string",
            required=False,
            description="Timezone (e.g. Africa/Addis_Ababa, UTC)",
        ),
        ParamSpec(
            name="--recurring",
            type="boolean flag",
            required=False,
            description="Enable recurring schedule",
            default="false",
        ),
        ParamSpec(
            name="--recurrence-rule",
            type="string",
            required=True,
            description="iCal RRULE (e.g. RRULE:FREQ=DAILY, RRULE:FREQ=WEEKLY)",
            condition="required when --recurring is set",
        ),
        ParamSpec(
            name="--recurrence-end-at",
            type="ISO 8601 datetime",
            required=False,
            description="When to stop recurring (omit for indefinite)",
        ),
        ParamSpec(
            name="--custom-values",
            type="JSON string",
            required=False,
            description="Custom variable values for template substitution",
        ),
        ParamSpec(
            name="--metadata",
            type="JSON string",
            required=False,
            description="Arbitrary metadata to attach",
        ),
    ],
    notes=[
        "Must provide either --body or --template-id (not both).",
        "send-type single requires --delivery-address.",
        "send-type group requires at least one --group-id.",
        "--recurring requires --recurrence-rule (iCal RRULE format).",
        "Common RRULE patterns: RRULE:FREQ=DAILY, RRULE:FREQ=WEEKLY, "
        "RRULE:FREQ=MONTHLY, RRULE:FREQ=WEEKLY;BYDAY=MO,WE,FR",
    ],
    examples=[
        # One-shot: single one-time
        "turumba scheduled-messages create --send-type single "
        '--delivery-address "+251911123456" --channel-id <cid> '
        '--body "Appointment reminder" --scheduled-at 2026-04-01T09:00:00Z',
        # One-shot: group one-time
        "turumba scheduled-messages create --send-type group "
        "--group-id <gid> --channel-id <cid> "
        '--body "Weekly update" --scheduled-at 2026-04-01T09:00:00Z',
        # One-shot: recurring weekly
        "turumba scheduled-messages create --send-type group "
        "--group-id <gid> --channel-id <cid> "
        '--body "Weekly digest" --scheduled-at 2026-04-07T09:00:00Z '
        "--recurring --recurrence-rule RRULE:FREQ=WEEKLY",
        # With timezone and end date
        "turumba scheduled-messages create --send-type single "
        '--delivery-address "+251911..." --channel-id <cid> '
        '--body "Daily reminder" --scheduled-at 2026-04-01T08:00:00Z '
        "--timezone Africa/Addis_Ababa --recurring "
        "--recurrence-rule RRULE:FREQ=DAILY "
        "--recurrence-end-at 2026-06-01T00:00:00Z",
        # Template-based
        "turumba scheduled-messages create --send-type group "
        "--group-id <gid> --template-id <tid> --channel-id <cid> "
        "--scheduled-at 2026-04-01T09:00:00Z "
        '--custom-values \'{"promo_code": "SPRING26"}\'',
        # Manage
        "turumba scheduled-messages list -f status:eq:pending -o json",
        "turumba scheduled-messages update <id> --scheduled-at 2026-04-05T14:00:00Z",
        "turumba scheduled-messages delete <id> --force",
    ],
    workflows=[
        {
            "name": "Schedule a one-time reminder (one-shot)",
            "steps": [
                "turumba channels list -o json  # pick a channel",
                "turumba scheduled-messages create --send-type single "
                '--delivery-address "+251911..." --channel-id <cid> '
                '--body "Appointment tomorrow at 10am" '
                "--scheduled-at 2026-04-01T09:00:00Z --timezone Africa/Addis_Ababa",
            ],
        },
        {
            "name": "Set up a recurring weekly group broadcast",
            "steps": [
                "turumba channels list -o json",
                "turumba groups list -o json",
                "turumba scheduled-messages create --send-type group "
                "--group-id <gid> --channel-id <cid> "
                '--body "Weekly status update" '
                "--scheduled-at 2026-04-07T09:00:00Z "
                "--recurring --recurrence-rule RRULE:FREQ=WEEKLY",
            ],
        },
    ],
    related=["sending", "channels", "templates", "group-messages"],
)

register_topics(topic)
