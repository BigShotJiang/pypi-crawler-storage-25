"""Skill topic: content-items — reusable content library for automations."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="content-items",
    summary="Reusable message bodies + attachments referenced by automation 'content' nodes",
    commands=[
        "turumba content-items list",
        "turumba content-items get <id>",
        "turumba content-items create --name <name> --body <text>",
        "turumba content-items update <id>",
        "turumba content-items delete <id>",
    ],
    create_params=[
        ParamSpec(
            name="--name / -n",
            type="string",
            required=True,
            description="Content item name",
        ),
        ParamSpec(
            name="--body / -b",
            type="string",
            required=True,
            description="Body text. Supports {{template}} variables (rendered per contact).",
        ),
        ParamSpec(
            name="--channel-type",
            type="string",
            required=False,
            description="Channel type hint (sms, telegram, whatsapp, email, ...)",
        ),
        ParamSpec(
            name="--attachments",
            type="JSON string",
            required=False,
            description='List of {"url","type"} objects; type in image|video|audio|document',
        ),
        ParamSpec(
            name="--metadata",
            type="JSON string",
            required=False,
            description="Arbitrary metadata object",
        ),
    ],
    notes=[
        "Account is auto-injected by the gateway — no --account-id needed.",
        "A `content` node in a drip/flow automation references a content item by id "
        "(content_item_id) and dispatches its body + attachments via the active channel.",
        "The FIRST attachment becomes the primary media (media_url + media_type); the "
        "rest ride along in metadata for adapter-specific handling.",
        "Body templating uses the same Handlebars subset as sendMessage "
        "(see automation-definitions).",
        "Get the item's id, then reference it: a content node looks like "
        '{"id":"c","kind":"content","content_item_id":"<id>","channel":"<cid>"}.',
    ],
    examples=[
        'turumba content-items create --name "promo-banner" '
        '--body "Big sale, {{contact.properties.name}}!" '
        '--attachments \'[{"url":"https://cdn.example.com/sale.jpg","type":"image"}]\'',
        "turumba content-items list -o json",
        "turumba content-items get <id> -o json",
        'turumba content-items update <id> --body "Updated copy"',
        "turumba content-items delete <id> --force",
    ],
    related=["automations", "automation-definitions"],
)

register_topics(topic)
