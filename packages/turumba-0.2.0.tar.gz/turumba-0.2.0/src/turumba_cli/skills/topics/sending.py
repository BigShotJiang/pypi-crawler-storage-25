"""Skill topic: sending — overview of all message sending methods."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="sending",
    summary="Send messages: single, group, and scheduled — overview and quick reference",
    commands=[
        "turumba group-messages create",
        "turumba scheduled-messages create",
        "turumba group-messages list",
        "turumba group-messages get <id>",
        "turumba scheduled-messages list",
        "turumba scheduled-messages get <id>",
    ],
    notes=[
        "Three ways to send messages in Turumba:",
        "  1. Group messages — send to groups/persons/contacts immediately",
        "  2. Scheduled messages (single) — send to one recipient at a future time",
        "  3. Scheduled messages (group) — send to groups at a future time, optionally recurring",
        "",
        "Prerequisites for sending:",
        "  - A channel must exist and be enabled (turumba channels list)",
        "  - Recipients must exist as persons, contacts, or in groups",
        "  - Either a message body or template is required",
        "",
        "For detailed parameter specs, use: turumba skills show group-messages",
        "or: turumba skills show scheduled-messages",
    ],
    examples=[
        # Group message — immediate
        "turumba group-messages create --group-id <gid> --channel-id <cid> "
        '--body "Hello everyone!"',
        # Group message — to specific persons
        "turumba group-messages create --person-id <pid1> --person-id <pid2> "
        '--channel-id <cid> --body "Direct message"',
        # Scheduled — single one-time
        "turumba scheduled-messages create --send-type single "
        '--delivery-address "+251911..." --channel-id <cid> '
        '--body "Reminder" --scheduled-at 2026-04-01T09:00:00Z',
        # Scheduled — group recurring
        "turumba scheduled-messages create --send-type group "
        "--group-id <gid> --channel-id <cid> "
        '--body "Weekly update" --scheduled-at 2026-04-07T09:00:00Z '
        "--recurring --recurrence-rule RRULE:FREQ=WEEKLY",
    ],
    workflows=[
        {
            "name": "Send a message to a group via Telegram",
            "steps": [
                "turumba channels list -f channel_type:eq:telegram -o json  # find channel ID",
                "turumba groups list -o json  # find group ID",
                "turumba group-messages create --group-id <gid> "
                '--channel-id <cid> --body "Hello group!"',
                "turumba group-messages get <id> -o json  # check delivery status",
            ],
        },
        {
            "name": "Full setup: channel + persons + group + send",
            "steps": [
                "turumba config set default_account_id <your-account-id>  # one-time setup",
                'turumba channels create --name "Bot" --type telegram '
                '--credentials \'{"bot_token": "..."}\'  # create channel',
                "turumba channels test-connection --id <cid>  # verify",
                'turumba persons create --properties \'{"name": "Abebe", '
                '"phone": "+251911..."}\' --group-id <gid>  # add recipient',
                "turumba group-messages create --group-id <gid> "
                '--channel-id <cid> --body "Hello!"  # send',
            ],
        },
    ],
    related=[
        "channels",
        "contacts",
        "persons",
        "templates",
        "group-messages",
        "scheduled-messages",
    ],
)

register_topics(topic)
