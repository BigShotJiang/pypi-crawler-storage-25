"""Skill topic: chat-endpoints."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="chat-endpoints",
    summary="Embeddable chat endpoints with widget config, pre-chat forms, and visitor sessions.",
    commands=[
        "turumba chat-endpoints list",
        "turumba chat-endpoints get",
        "turumba chat-endpoints create",
        "turumba chat-endpoints update",
        "turumba chat-endpoints delete",
    ],
    examples=[
        "turumba chat-endpoints list",
        "turumba chat-endpoints list -f is_active:eq:true -o json",
        "turumba chat-endpoints list -f name:contains:support",
        "turumba chat-endpoints get <endpoint-id>",
        'turumba chat-endpoints create --name "Support Chat" '
        '--welcome-message "Hello! How can we help?" '
        "--origin https://example.com",
        'turumba chat-endpoints create --name "Sales Widget" '
        "--channel-id <channel-id> "
        '--widget-config \'{"theme": "dark", "position": "bottom-right"}\'',
        "turumba chat-endpoints update <endpoint-id> --inactive",
        "turumba chat-endpoints update <endpoint-id> "
        '--allowed-origins \'["https://example.com", "https://app.example.com"]\'',
        "turumba chat-endpoints delete <endpoint-id> --force",
    ],
    workflows=[
        {
            "name": "Set up a new chat widget",
            "steps": [
                "turumba channels list  # find or create a channel to associate",
                'turumba chat-endpoints create --name "Website Chat" '
                "--channel-id <channel-id> "
                '--welcome-message "Hi there!" '
                "--origin https://yoursite.com",
                "turumba chat-endpoints get <endpoint-id>  # note the public_key",
                "# Embed widget using the public_key in your website",
            ],
        },
        {
            "name": "Disable a chat endpoint",
            "steps": [
                "turumba chat-endpoints list -f is_active:eq:true",
                "turumba chat-endpoints update <endpoint-id> --inactive",
            ],
        },
    ],
    related=["channels", "sending"],
)

register_topics(topic)
