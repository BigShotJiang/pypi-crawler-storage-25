"""Skill topic: automation-runs — inspect and control individual enrollments."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="automation-runs",
    summary="Inspect a contact's journey through an automation and cancel it",
    commands=[
        "turumba automations runs <automation-id>   # list runs for an automation",
        "turumba automation-runs get <run-id>",
        "turumba automation-runs steps <run-id>",
        "turumba automation-runs cancel <run-id>",
    ],
    notes=[
        "A run is ONE contact's execution of an automation. List runs by automation "
        "with `turumba automations runs <automation-id>` (optionally --state).",
        "Run states: running (advancing), waiting (parked on a delay/reply), paused "
        "(drip lifecycle), completed, failed, cancelled. The last three are terminal.",
        "`steps` is the per-node audit trail: each node's kind, status (ok/failed/"
        "skipped), output_json, error, and timings — the first place to look when a "
        "run misbehaves.",
        "`get` includes context_json (contact block, trigger, bound answers) and the "
        "resume_at / resume_on_event fields for parked runs.",
        "`cancel` only works on non-terminal runs; a terminal run returns 409.",
    ],
    examples=[
        "turumba automations runs <automation-id> --state failed -o json",
        "turumba automation-runs get <run-id> -o json",
        "turumba automation-runs steps <run-id> -o json",
        "turumba automation-runs cancel <run-id> --force",
    ],
    workflows=[
        {
            "name": "Debug why a run failed",
            "steps": [
                "turumba automations runs <automation-id> --state failed -o json",
                "turumba automation-runs steps <run-id> -o json  # find the failed step",
                "turumba automation-runs get <run-id> -o json     # inspect context_json",
            ],
        },
    ],
    related=["automations", "automation-definitions"],
)

register_topics(topic)
