"""Skill topic: overview."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="overview",
    summary="Platform overview and getting started",
    commands=["turumba --help", "turumba auth login"],
    examples=[
        "turumba auth login --email user@example.com",
        "turumba config list",
    ],
    related=["auth", "channels"],
)

register_topics(topic)
