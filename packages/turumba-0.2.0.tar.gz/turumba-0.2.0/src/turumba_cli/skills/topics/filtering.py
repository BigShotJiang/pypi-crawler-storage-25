"""Skill topic: filtering."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="filtering",
    summary="Filter and sort query syntax for list commands",
    commands=[],
    examples=[
        "turumba channels list -f channel_type:eq:telegram",
        "turumba channels list -f status:eq:active -s created_at:desc",
        "turumba channels list -f name:contains:bot -l 10",
        "turumba messages list -f channel_type:eq:sms -f status:eq:sent",
        "turumba persons list -f properties.name:contains:Abebe",
        "turumba contacts list -s created_at:desc -l 20",
        "turumba group-messages list -f status:eq:completed",
        "turumba scheduled-messages list -f status:eq:pending -f send_type:eq:group",
    ],
    related=["channels", "sending", "persons", "contacts"],
)

register_topics(topic)
