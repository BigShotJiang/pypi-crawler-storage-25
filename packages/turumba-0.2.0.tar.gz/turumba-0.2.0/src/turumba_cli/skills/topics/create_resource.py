"""Skill topic: create-resource — unified quick-reference for all resource creation."""

from turumba_cli.skills.registry import SkillTopic, register_topics

topic = SkillTopic(
    name="create-resource",
    summary="Quick-reference: required params and one-shot examples for creating ANY resource",
    commands=[
        "turumba channels create",
        "turumba users create",
        "turumba teams create",
        "turumba persons create",
        "turumba contacts create",
        "turumba templates create",
        "turumba group-messages create",
        "turumba scheduled-messages create",
        "turumba messages create",
        "turumba conversations create",
        "turumba chat-endpoints create",
        "turumba conversation-configs create",
        "turumba automations create",
        "turumba automation-folders create",
        "turumba content-items create",
    ],
    notes=[
        "SETUP: Set default account_id once to avoid passing it every time:",
        "  turumba config set default_account_id <your-uuid>",
        "",
        "=== CHANNEL (no account_id needed — auto-injected by gateway) ===",
        "Required: --name, --type, --credentials",
        "Credential schemas by type:",
        '  telegram:  {"bot_token": "..."}',
        '  sms:       {"api_key": "...", "api_secret": "...", "sender_id": "..."}',
        '  whatsapp:  {"phone_number_id": "...", "access_token": "...", "business_account_id": "..."}',
        '  email:     {"smtp_host": "...", "smtp_port": 587, "username": "...", "password": "...", "from_address": "..."}',
        '  smpp:      {"host": "...", "port": 2775, "system_id": "...", "password": "..."}',
        '  messenger: {"page_access_token": "...", "page_id": "..."}',
        "",
        "=== USER (account_id REQUIRED) ===",
        "Required: --email, --given-name, --family-name, --role-id, --account-id (or config default)",
        "Optional: --phone",
        "",
        "=== TEAM (account_id REQUIRED) ===",
        "Required: --name, --account-id (or config default)",
        "Optional: --description, --lead-id, --active/--inactive, --metadata (JSON)",
        "Members: turumba teams add-members <team-id> --user-id <uid> --role member|lead",
        "",
        "=== PERSON (account_id REQUIRED) ===",
        "Required: --account-id (or config default)",
        "Optional: --properties (JSON), --group-id (repeatable)",
        "",
        "=== CONTACT (account_id REQUIRED) ===",
        "Required: --account-id (or config default)",
        "Optional: --properties (JSON)",
        "",
        "=== TEMPLATE (no account_id needed) ===",
        "Required: --name, --body",
        "Optional: --category, --channel-type, --language, --default-values, --fallback-strategy",
        "",
        "=== GROUP MESSAGE ===",
        "Required: (--body OR --template-id) + (--group-id OR --person-id OR --contact-id)",
        "Optional: --channel-id, --name, --exclude-person-id, --scheduled-at, --custom-values",
        "",
        "=== SCHEDULED MESSAGE ===",
        "Required: --send-type (single|group), --scheduled-at, (--body OR --template-id)",
        "  If single: --delivery-address required",
        "  If group: --group-id required",
        "  If --recurring: --recurrence-rule required",
        "Optional: --channel-id, --name, --timezone, --recurrence-end-at, --custom-values",
        "",
        "=== MESSAGE (account_id REQUIRED) ===",
        "Required: --body, --account-id (or config default)",
        "Optional: --direction (outbound|inbound|system), --channel-id, --delivery-address, "
        "--contact-id, --template-id, --scheduled-at, --metadata (JSON)",
        "For outbound dispatch: provide --channel-id + --delivery-address",
        "",
        "=== CONVERSATION (account_id REQUIRED) ===",
        "Required: --account-id (or config default), ONE of --channel-id or --chat-endpoint-id",
        "Optional: --contact-id, --assignee-id, --team-id, --status, --priority, "
        "--subject, --source, --metadata (JSON)",
        "Messages: turumba conversations send-message <id> --body 'text' [--private]",
        "",
        "=== CHAT ENDPOINT (no account_id needed) ===",
        "Required: --name",
        "Optional: --channel-id, --welcome-message, --offline-message, --origin, "
        "--widget-config, --pre-chat-form, --description, --metadata",
        "",
        "=== CONVERSATION CONFIG (no account_id needed) ===",
        "Required: --name",
        "Optional: --priority, --audience-mode, --audience-group-ids, --source-channels, "
        "--creation-mode, --reopen-policy, --auto-resolve-hours, --default-team-id",
        "",
        "=== AUTOMATION (no account_id needed) ===",
        "Required: --name, --type (autoReply|drip|broadcast|survey|sync|tagRule|flow)",
        "Optional: --description, --folder-id, --metadata (JSON)",
        "Two-step: create sets metadata; the workflow GRAPH is a separate call:",
        "  turumba automations save-definition <id> --definition-file graph.json",
        "  then: turumba automations test <id> --event '{...}' && publish <id>",
        "Graph schema + ALL node/trigger kinds: turumba skills show automation-definitions",
        "",
        "=== AUTOMATION FOLDER (no account_id needed) ===",
        "Required: --name",
        "Optional: --parent-folder-id (omit for a root folder)",
        "",
        "=== CONTENT ITEM (no account_id needed) ===",
        "Required: --name, --body",
        "Optional: --channel-type, --attachments (JSON), --metadata (JSON)",
        "Referenced by automation 'content' nodes via content_item_id.",
        "",
        "For detailed params, run: turumba skills show <resource-name>",
    ],
    examples=[
        # Channel
        'turumba channels create --name "My Bot" --type telegram '
        '--credentials \'{"bot_token": "123:ABC"}\'',
        # User
        "turumba users create --email user@example.com --given-name Abebe "
        "--family-name Kebede --role-id <role-uuid>",
        # Team
        'turumba teams create --name "Engineering" --description "Backend team" '
        "--lead-id <user-uuid>",
        # Person
        'turumba persons create --properties \'{"name": "Abebe", '
        '"phone": "+251911123456", "telegram_chat_id": "123456"}\'',
        # Contact
        'turumba contacts create --properties \'{"phone": "+251911...", '
        '"name": "Abebe", "email": "a@b.com"}\'',
        # Template
        'turumba templates create --name "welcome" '
        '--body "Hello {{name}}! Welcome to {{company}}."',
        # Group message
        "turumba group-messages create --group-id <gid> --channel-id <cid> "
        '--body "Hello everyone!"',
        # Scheduled single
        "turumba scheduled-messages create --send-type single "
        '--delivery-address "+251911..." --channel-id <cid> '
        '--body "Reminder" --scheduled-at 2026-04-01T09:00:00Z',
        # Scheduled group recurring
        "turumba scheduled-messages create --send-type group "
        "--group-id <gid> --channel-id <cid> "
        '--body "Weekly update" --scheduled-at 2026-04-07T09:00:00Z '
        "--recurring --recurrence-rule RRULE:FREQ=WEEKLY",
        # Message
        "turumba messages create --body 'Hello!' --channel-id <cid> "
        "--delivery-address '+251911123456'",
        # Conversation
        "turumba conversations create --channel-id <cid> --contact-id <contact-id> "
        '--subject "Support request"',
        # Chat endpoint
        'turumba chat-endpoints create --name "Support Chat" '
        '--welcome-message "How can we help?" --origin https://example.com',
        # Conversation config
        'turumba conversation-configs create --name "Default" --priority 0',
        # Automation (metadata only; graph is a separate save-definition call)
        'turumba automations create --name "Welcome reply" --type autoReply',
        # Content item (referenced by automation content nodes)
        'turumba content-items create --name "promo" --body "Hi {{contact.properties.name}}!"',
    ],
    workflows=[
        {
            "name": "Complete setup: channel + person + group message",
            "steps": [
                "turumba config set default_account_id <your-account-uuid>  # one-time setup",
                'turumba channels create --name "Telegram Bot" --type telegram '
                '--credentials \'{"bot_token": "..."}\'  # create channel',
                "turumba channels test-connection --id <channel-id>  # verify",
                'turumba persons create --properties \'{"name": "Abebe", '
                '"phone": "+251911..."}\' --group-id <gid>  # add recipient',
                "turumba group-messages create --group-id <gid> "
                '--channel-id <cid> --body "Hello!"  # send',
            ],
        },
        {
            "name": "Complete setup: template + scheduled recurring message",
            "steps": [
                'turumba templates create --name "weekly-report" '
                '--body "Hi {{name}}, here is your weekly report: {{content}}" -o json',
                "turumba scheduled-messages create --send-type group "
                "--group-id <gid> --template-id <tid> --channel-id <cid> "
                "--scheduled-at 2026-04-07T09:00:00Z "
                "--recurring --recurrence-rule RRULE:FREQ=WEEKLY "
                '--custom-values \'{"content": "This week summary..."}\'',
            ],
        },
    ],
    related=[
        "channels",
        "users",
        "teams",
        "persons",
        "contacts",
        "templates",
        "messages",
        "group-messages",
        "scheduled-messages",
        "conversations",
        "chat-endpoints",
        "conversation-configs",
        "automations",
        "automation-definitions",
        "content-items",
    ],
)

register_topics(topic)
