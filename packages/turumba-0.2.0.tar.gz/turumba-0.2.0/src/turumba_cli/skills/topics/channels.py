"""Skill topic: channels — complete parameter specs for one-shot agent execution."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="channels",
    summary="Delivery channels: SMS, Telegram, WhatsApp, Email, etc.",
    commands=[
        "turumba channels list",
        "turumba channels get <channel-id>",
        "turumba channels create",
        "turumba channels update <channel-id>",
        "turumba channels delete <channel-id>",
        "turumba channels test-connection",
    ],
    create_params=[
        ParamSpec(
            name="--name / -n",
            type="string",
            required=True,
            description="Channel display name",
        ),
        ParamSpec(
            name="--type / -t",
            type="enum",
            required=True,
            description="Channel type",
            enum_values=["sms", "smpp", "telegram", "whatsapp", "messenger", "email"],
        ),
        ParamSpec(
            name="--credentials",
            type="JSON string",
            required=True,
            description="Provider credentials (schema depends on --type, see notes)",
        ),
        ParamSpec(
            name="--sender-name",
            type="string",
            required=False,
            description="Sender display name",
        ),
        ParamSpec(
            name="--country-code",
            type="string",
            required=False,
            description="Default country code (e.g. +251)",
        ),
        ParamSpec(
            name="--rate-limit",
            type="integer",
            required=False,
            description="Messages per second limit",
        ),
        ParamSpec(
            name="--priority",
            type="integer",
            required=False,
            description="Channel priority (higher = preferred)",
            default="0",
        ),
    ],
    notes=[
        "account_id is auto-injected by the gateway from your auth token.",
        "Credential schemas per channel type:",
        '  telegram:  {"bot_token": "123456:ABC-DEF..."}',
        '  sms:       {"api_key": "...", "api_secret": "...", "sender_id": "..."}',
        '  smpp:      {"host": "...", "port": 2775, "system_id": "...", "password": "..."}',
        '  whatsapp:  {"phone_number_id": "...", "access_token": "...", "business_account_id": "..."}',
        '  messenger: {"page_access_token": "...", "page_id": "..."}',
        '  email:     {"smtp_host": "...", "smtp_port": 587, "username": "...", "password": "...", "from_address": "..."}',
        "After creating, run test-connection to verify credentials work.",
    ],
    examples=[
        # Telegram — one-shot
        'turumba channels create --name "My Telegram Bot" --type telegram '
        '--credentials \'{"bot_token": "123456:ABC-DEF..."}\'',
        # SMS — one-shot
        'turumba channels create --name "SMS Gateway" --type sms '
        '--credentials \'{"api_key": "key", "api_secret": "secret", "sender_id": "MyApp"}\' '
        "--sender-name MyApp --country-code +251",
        # WhatsApp — one-shot
        'turumba channels create --name "WhatsApp Business" --type whatsapp '
        '--credentials \'{"phone_number_id": "...", "access_token": "...", '
        '"business_account_id": "..."}\'',
        # Email — one-shot
        'turumba channels create --name "Email Notifications" --type email '
        '--credentials \'{"smtp_host": "smtp.gmail.com", "smtp_port": 587, '
        '"username": "...", "password": "...", "from_address": "noreply@example.com"}\'',
        # Test & enable
        "turumba channels test-connection --id <channel-id>",
        "turumba channels update <channel-id> --enabled",
        # List & filter
        "turumba channels list -f channel_type:eq:telegram -o json",
    ],
    workflows=[
        {
            "name": "Set up a new Telegram channel (one-shot)",
            "steps": [
                'turumba channels create --name "My Bot" --type telegram '
                '--credentials \'{"bot_token": "BOT_TOKEN"}\' -o json',
                "turumba channels test-connection --id <channel-id from step 1>",
                "turumba channels update <channel-id> --enabled",
            ],
        },
    ],
    related=["sending", "templates", "group-messages"],
)

register_topics(topic)
