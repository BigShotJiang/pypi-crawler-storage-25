"""Skill topic: teams — complete parameter specs for one-shot agent execution."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="teams",
    summary="Manage teams and team membership within accounts",
    commands=[
        "turumba teams list",
        "turumba teams get <team-id>",
        "turumba teams create",
        "turumba teams update <team-id>",
        "turumba teams delete <team-id>",
        "turumba teams list-members <team-id>",
        "turumba teams add-members <team-id>",
        "turumba teams remove-members <team-id>",
    ],
    create_params=[
        ParamSpec(
            name="--name / -n",
            type="string",
            required=True,
            description="Team name (max 255 chars). Must be unique within the account",
        ),
        ParamSpec(
            name="--account-id / -a",
            type="UUID",
            required=True,
            description="Account ID. Falls back to config default_account_id",
        ),
        ParamSpec(
            name="--description / -d",
            type="string",
            required=False,
            description="Team description",
        ),
        ParamSpec(
            name="--lead-id",
            type="UUID",
            required=False,
            description="User ID of the team lead",
        ),
        ParamSpec(
            name="--active / --inactive",
            type="boolean",
            required=False,
            description="Team active status",
            default="active (True)",
        ),
        ParamSpec(
            name="--metadata / -m",
            type="JSON string",
            required=False,
            description="Custom metadata key-value pairs",
            default="{}",
        ),
    ],
    notes=[
        "account_id is REQUIRED for create. Use --account-id or set default: "
        "turumba config set default_account_id <uuid>",
        "Team name must be unique within an account.",
        "Team members are managed via add-members / remove-members sub-commands.",
        "add-members accepts --user-id (repeatable) and --role (member or lead).",
        "remove-members accepts --user-id (repeatable).",
        "Filterable fields: id, name, account_id, is_active, lead_id, created_at.",
        "Sortable fields: name, created_at, updated_at.",
    ],
    examples=[
        # Create
        'turumba teams create --name "Engineering" --description "Backend team" '
        "--account-id <account-uuid>",
        # Create with lead
        'turumba teams create --name "Support" --lead-id <user-uuid>',
        # List
        "turumba teams list -f account_id:eq:<account-uuid> -o json",
        "turumba teams list -f is_active:eq:true -s name:asc",
        "turumba teams list -f name:icontains:eng",
        # Get
        "turumba teams get <team-id> -o json",
        # Update
        'turumba teams update <team-id> --name "New Name" --lead-id <user-uuid>',
        "turumba teams update <team-id> --inactive",
        # Delete
        "turumba teams delete <team-id> --force",
        # Members
        "turumba teams list-members <team-id> -o json",
        "turumba teams add-members <team-id> --user-id <uid1> --user-id <uid2> --role member",
        "turumba teams add-members <team-id> --user-id <uid> --role lead",
        "turumba teams remove-members <team-id> --user-id <uid1> --user-id <uid2>",
    ],
    workflows=[
        {
            "name": "Create a team and add members",
            "steps": [
                "turumba config set default_account_id <your-account-id>  # one-time setup",
                "turumba users list -o json  # find user IDs",
                'turumba teams create --name "Engineering" --lead-id <lead-user-id> -o json',
                "turumba teams add-members <team-id> "
                "--user-id <uid1> --user-id <uid2> --role member",
            ],
        },
        {
            "name": "Transfer team leadership",
            "steps": [
                "turumba teams list-members <team-id> -o json  # find current members",
                "turumba teams update <team-id> --lead-id <new-lead-user-id>",
                "turumba teams add-members <team-id> --user-id <new-lead-user-id> --role lead",
            ],
        },
    ],
    related=["users", "overview"],
)

register_topics(topic)
