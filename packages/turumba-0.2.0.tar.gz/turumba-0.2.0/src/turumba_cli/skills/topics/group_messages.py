"""Skill topic: group-messages — complete parameter specs for one-shot agent execution."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="group-messages",
    summary="Broadcast messages to groups, persons, or contacts in bulk",
    commands=[
        "turumba group-messages list",
        "turumba group-messages get <id>",
        "turumba group-messages create",
        "turumba group-messages update <id>",
        "turumba group-messages delete <id>",
    ],
    create_params=[
        ParamSpec(
            name="--account-id / -a",
            type="UUID",
            required=False,
            description="Account ID. Falls back to config default_account_id",
        ),
        ParamSpec(
            name="--body / -b",
            type="string",
            required=True,
            description="Message body text",
            condition="required if no --template-id",
        ),
        ParamSpec(
            name="--template-id / -t",
            type="UUID",
            required=True,
            description="Template ID to use instead of --body",
            condition="required if no --body",
        ),
        ParamSpec(
            name="--group-id",
            type="string (repeatable)",
            required=True,
            description="Group ID(s) to send to",
            condition="at least one of --group-id, --person-id, or --contact-id required",
        ),
        ParamSpec(
            name="--person-id",
            type="string (repeatable)",
            required=False,
            description="Person ID(s) to send to directly",
            condition="at least one of --group-id, --person-id, or --contact-id required",
        ),
        ParamSpec(
            name="--contact-id",
            type="string (repeatable)",
            required=False,
            description="Contact ID(s) to send to directly",
            condition="at least one of --group-id, --person-id, or --contact-id required",
        ),
        ParamSpec(
            name="--channel-id / -c",
            type="UUID",
            required=False,
            description="Channel ID to send through (picks default if omitted)",
        ),
        ParamSpec(
            name="--name / -n",
            type="string",
            required=False,
            description="Group message name (for tracking/display)",
        ),
        ParamSpec(
            name="--exclude-person-id",
            type="string (repeatable)",
            required=False,
            description="Person ID(s) to exclude from the broadcast",
        ),
        ParamSpec(
            name="--scheduled-at",
            type="ISO 8601 datetime",
            required=False,
            description="Schedule for later instead of sending immediately",
        ),
        ParamSpec(
            name="--custom-values",
            type="JSON string",
            required=False,
            description="Custom variable values for template substitution",
        ),
        ParamSpec(
            name="--metadata",
            type="JSON string",
            required=False,
            description="Arbitrary metadata to attach",
        ),
    ],
    notes=[
        "Must provide either --body or --template-id (not both).",
        "Must provide at least one recipient: --group-id, --person-id, or --contact-id.",
        "Use --group-id multiple times to send to multiple groups.",
        "Use --exclude-person-id to exclude specific persons from a group.",
        "--custom-values are merged with recipient properties for template variable resolution.",
    ],
    examples=[
        # One-shot: body + group
        "turumba group-messages create --group-id <gid> --channel-id <cid> "
        '--body "Hello everyone!"',
        # One-shot: template + campaign
        'turumba group-messages create --name "March Campaign" '
        "--group-id <gid> --template-id <tid> --channel-id <cid> "
        '--custom-values \'{"promo_code": "MARCH25"}\'',
        # Multiple groups
        "turumba group-messages create --group-id <gid1> --group-id <gid2> "
        '--channel-id <cid> --body "Multi-group broadcast"',
        # Direct to persons
        "turumba group-messages create --person-id <pid1> --person-id <pid2> "
        '--channel-id <cid> --body "Direct to persons"',
        # With exclusions
        "turumba group-messages create --group-id <gid> "
        '--exclude-person-id <pid> --channel-id <cid> --body "All except one"',
        # Scheduled
        "turumba group-messages create --group-id <gid> --channel-id <cid> "
        '--body "Scheduled broadcast" --scheduled-at 2026-04-01T09:00:00Z',
        # Monitor
        "turumba group-messages list -f status:eq:processing -o json",
        "turumba group-messages get <id> -o json",
    ],
    workflows=[
        {
            "name": "Send a broadcast to a group (one-shot)",
            "steps": [
                "turumba channels list -o json  # pick a channel",
                "turumba groups list -o json  # pick a group",
                "turumba group-messages create --group-id <gid> "
                '--channel-id <cid> --body "Broadcast message"',
                "turumba group-messages get <id>  # monitor delivery status",
            ],
        },
        {
            "name": "Template-based campaign to multiple groups",
            "steps": [
                "turumba templates list -o json  # pick a template",
                "turumba channels list -o json  # pick a channel",
                "turumba groups list -o json  # pick groups",
                'turumba group-messages create --name "Campaign" '
                "--group-id <gid1> --group-id <gid2> "
                "--template-id <tid> --channel-id <cid> "
                '--custom-values \'{"discount": "20%"}\'',
            ],
        },
    ],
    related=["sending", "channels", "persons", "contacts", "templates"],
)

register_topics(topic)
