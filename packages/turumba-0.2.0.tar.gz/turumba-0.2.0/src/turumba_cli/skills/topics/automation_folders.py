"""Skill topic: automation-folders — organize automations into a tree."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="automation-folders",
    summary="Group automations into a (nestable) folder tree",
    commands=[
        "turumba automation-folders list",
        "turumba automation-folders list --tree",
        "turumba automation-folders create --name <name>",
        "turumba automation-folders update <id>",
        "turumba automation-folders delete <id>",
    ],
    create_params=[
        ParamSpec(
            name="--name / -n",
            type="string",
            required=True,
            description="Folder name",
        ),
        ParamSpec(
            name="--parent-folder-id",
            type="UUID",
            required=False,
            description="Parent folder ID. Omit for a root-level folder.",
        ),
    ],
    notes=[
        "Account is auto-injected by the gateway — no --account-id needed.",
        "Flat list returns computed children_count and automation_count per folder.",
        "--tree returns the full recursive hierarchy (children[] on each node) as JSON.",
        "Place an automation in a folder via `turumba automations create --folder-id <id>` "
        "or `turumba automations update <id> --folder-id <id>`.",
        "On update: --root moves the folder to the top level; --parent-folder-id "
        "re-parents it; omitting both leaves the parent unchanged.",
    ],
    examples=[
        'turumba automation-folders create --name "Campaigns"',
        'turumba automation-folders create --name "Q3 2026" --parent-folder-id <parent-id>',
        "turumba automation-folders list -o json",
        "turumba automation-folders list --tree",
        'turumba automation-folders update <id> --name "Campaigns 2026"',
        "turumba automation-folders update <id> --root  # move to top level",
        "turumba automation-folders delete <id> --force",
    ],
    related=["automations"],
)

register_topics(topic)
