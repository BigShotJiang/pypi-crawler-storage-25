"""Skill topic: templates — complete parameter specs for one-shot agent execution."""

from turumba_cli.skills.registry import ParamSpec, SkillTopic, register_topics

topic = SkillTopic(
    name="templates",
    summary="Message templates with variable substitution ({{variable}} syntax)",
    commands=[
        "turumba templates list",
        "turumba templates get <template-id>",
        "turumba templates create",
        "turumba templates update <template-id>",
        "turumba templates delete <template-id>",
    ],
    create_params=[
        ParamSpec(
            name="--name / -n",
            type="string",
            required=True,
            description="Template name (unique identifier)",
        ),
        ParamSpec(
            name="--body / -b",
            type="string",
            required=True,
            description="Template body with {{variable}} placeholders",
        ),
        ParamSpec(
            name="--category",
            type="string",
            required=False,
            description="Template category for organization (e.g. marketing, transactional)",
        ),
        ParamSpec(
            name="--channel-type",
            type="enum",
            required=False,
            description="Restrict template to a specific channel type",
            enum_values=["sms", "smpp", "telegram", "whatsapp", "messenger", "email"],
        ),
        ParamSpec(
            name="--language",
            type="string",
            required=False,
            description="Template language code (e.g. en, am, or)",
        ),
        ParamSpec(
            name="--default-values",
            type="JSON string",
            required=False,
            description="Default values for variables when not provided at send time",
        ),
        ParamSpec(
            name="--fallback-strategy",
            type="enum",
            required=False,
            description="What to do when a variable has no value",
            enum_values=["keep_placeholder", "use_default", "skip_contact"],
            default="keep_placeholder",
        ),
    ],
    notes=[
        "Variables use double curly braces: {{name}}, {{phone}}, {{promo_code}}.",
        "Default values are used when a recipient doesn't have a matching property.",
        "Fallback strategies: keep_placeholder (leave {{var}} in text), "
        "use_default (use default_values), skip_contact (don't send to that recipient).",
        "Templates are reusable across group-messages and scheduled-messages.",
    ],
    examples=[
        # One-shot create
        'turumba templates create --name "welcome" '
        '--body "Hello {{name}}! Welcome to {{company}}."',
        # With defaults and category
        'turumba templates create --name "promo" --category marketing '
        '--body "Hi {{name}}, use code {{promo_code}} for {{discount}} off!" '
        '--default-values \'{"discount": "10%"}\' '
        "--fallback-strategy use_default",
        # Channel-specific template
        'turumba templates create --name "telegram-alert" --channel-type telegram '
        '--body "Alert: {{message}}"',
        # List & filter
        "turumba templates list -o json",
        "turumba templates list -f category:eq:marketing",
    ],
    workflows=[
        {
            "name": "Create template and use in group message",
            "steps": [
                'turumba templates create --name "campaign" '
                '--body "Hi {{name}}, {{message}}" -o json',
                "turumba group-messages create --template-id <tid> "
                "--group-id <gid> --channel-id <cid> "
                '--custom-values \'{"message": "Check our new offer!"}\'',
            ],
        },
    ],
    related=["sending", "group-messages", "scheduled-messages", "channels"],
)

register_topics(topic)
