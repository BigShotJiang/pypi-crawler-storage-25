"""Turumba CLI — Command-line interface for the Turumba message automation platform."""

__version__ = "0.2.0"
