"""Turumba CLI — main entry point."""

from __future__ import annotations

import typer

from turumba_cli import __version__
from turumba_cli.commands import (
    auth,
    automation_folders,
    automation_runs,
    automations,
    channels,
    chat_endpoints,
    config_cmd,
    contacts,
    content_items,
    conversation_configs,
    conversations,
    group_messages,
    groups,
    messages,
    persons,
    scheduled_messages,
    skills,
    teams,
    users,
)

app = typer.Typer(
    name="turumba",
    help="CLI for the Turumba message automation platform.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# Register command groups
app.add_typer(auth.app)
app.add_typer(config_cmd.app)
app.add_typer(automations.app)
app.add_typer(automation_folders.app)
app.add_typer(automation_runs.app)
app.add_typer(channels.app)
app.add_typer(chat_endpoints.app)
app.add_typer(content_items.app)
app.add_typer(conversation_configs.app)
app.add_typer(conversations.app)
app.add_typer(contacts.app)
app.add_typer(group_messages.app)
app.add_typer(messages.app)
app.add_typer(groups.app)
app.add_typer(persons.app)
app.add_typer(scheduled_messages.app)
app.add_typer(skills.app)
app.add_typer(teams.app)
app.add_typer(users.app)


def version_callback(value: bool) -> None:
    if value:
        typer.echo(f"turumba {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool | None = typer.Option(
        None,
        "--version",
        "-V",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """Turumba CLI — manage accounts, channels, messages, and more."""
