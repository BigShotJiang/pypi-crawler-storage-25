"""Automation folder commands — organize automations into a folder tree."""

from __future__ import annotations

import typer

from turumba_cli.client import TurumbaClient
from turumba_cli.errors import TurumbaAPIError, TurumbaAuthError
from turumba_cli.output import error, render, render_meta, success

app = typer.Typer(name="automation-folders", help="Organize automations into folders.")

API_PATH = "/v1/automation-folders"

LIST_COLUMNS = {
    "ID": "id",
    "Name": "name",
    "Parent": "parent_folder_id",
    "Children": "children_count",
    "Automations": "automation_count",
    "Created At": "created_at",
}


def _handle_error(e: Exception) -> None:
    if isinstance(e, TurumbaAuthError | TurumbaAPIError):
        error(str(e))
    else:
        error(f"Unexpected error: {e}")
    raise typer.Exit(1)


@app.command("list")
def list_folders(
    tree: bool = typer.Option(False, "--tree", help="Return the full hierarchy as a nested tree"),
    filter_: list[str] | None = typer.Option(None, "--filter", "-f", help="Filter: field:op:value"),
    sort: list[str] | None = typer.Option(None, "--sort", "-s", help="Sort: field:asc|desc"),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    skip: int = typer.Option(0, "--skip", help="Offset"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """List folders (flat) or the full nested tree with --tree."""
    client = TurumbaClient(gateway_url=gateway_url)

    if tree:
        try:
            body = client.request("GET", API_PATH, params={"tree": "true"})
        except Exception as e:
            _handle_error(e)
        data = body["data"] if isinstance(body, dict) and "data" in body else body
        # The tree is recursive (children[]) — render as JSON regardless of mode.
        render(data, output_format="json")
        return

    try:
        data, meta = client.list(API_PATH, filter_=filter_, sort=sort, limit=limit, skip=skip)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, columns=LIST_COLUMNS, title="Automation Folders")
    render_meta(meta, output_format=output)


@app.command("create")
def create_folder(
    name: str = typer.Option(..., "--name", "-n", help="Folder name"),
    parent_folder_id: str = typer.Option(
        None, "--parent-folder-id", help="Parent folder ID (omit for a root folder)"
    ),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Create a folder. Omit --parent-folder-id for a root-level folder."""
    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {"name": name}
    if parent_folder_id is not None:
        data["parent_folder_id"] = parent_folder_id

    try:
        result = client.create(API_PATH, data)
    except Exception as e:
        _handle_error(e)

    success(f"Folder created: {result.get('id', '')}")
    render(result, output_format=output, is_list=False, title="Created Folder")


@app.command("update")
def update_folder(
    folder_id: str = typer.Argument(help="Folder ID"),
    name: str = typer.Option(None, "--name", "-n", help="New folder name"),
    parent_folder_id: str = typer.Option(
        None, "--parent-folder-id", help="New parent folder ID (re-parent)"
    ),
    root: bool = typer.Option(False, "--root", help="Move the folder to the root level"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Rename or re-parent a folder. Use --root to move it to the top level."""
    if parent_folder_id is not None and root:
        error("Provide either --parent-folder-id or --root, not both.")
        raise typer.Exit(1)

    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {}
    if name is not None:
        data["name"] = name
    if root:
        data["parent_folder_id"] = None
    elif parent_folder_id is not None:
        data["parent_folder_id"] = parent_folder_id

    if not data:
        error("No fields to update. Provide --name, --parent-folder-id, or --root.")
        raise typer.Exit(1)

    try:
        result = client.update(API_PATH, folder_id, data)
    except Exception as e:
        _handle_error(e)

    success(f"Folder updated: {folder_id}")
    render(result, output_format=output, is_list=False, title="Updated Folder")


@app.command("delete")
def delete_folder(
    folder_id: str = typer.Argument(help="Folder ID"),
    force: bool = typer.Option(False, "--force", "-y", help="Skip confirmation"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Delete a folder."""
    if not force:
        typer.confirm(f"Delete folder {folder_id}?", abort=True)

    client = TurumbaClient(gateway_url=gateway_url)
    try:
        client.delete(API_PATH, folder_id)
    except Exception as e:
        _handle_error(e)

    success(f"Folder deleted: {folder_id}")
