"""Content item commands — reusable content library entries for automations.

`content` nodes in drip/flow automations reference a content item by id and
dispatch its body + attachments through the active channel.
"""

from __future__ import annotations

import json

import typer

from turumba_cli.client import TurumbaClient
from turumba_cli.errors import TurumbaAPIError, TurumbaAuthError
from turumba_cli.output import error, render, render_meta, success

app = typer.Typer(name="content-items", help="Manage reusable content library items.")

API_PATH = "/v1/content-items"

LIST_COLUMNS = {
    "ID": "id",
    "Name": "name",
    "Channel Type": "channel_type",
    "Created At": "created_at",
}


def _handle_error(e: Exception) -> None:
    if isinstance(e, TurumbaAuthError | TurumbaAPIError):
        error(str(e))
    else:
        error(f"Unexpected error: {e}")
    raise typer.Exit(1)


def _parse_json(raw: str, label: str) -> object:
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        error(f"Invalid JSON for {label}: {e}")
        raise typer.Exit(1) from None


@app.command("list")
def list_content_items(
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    skip: int = typer.Option(0, "--skip", help="Offset"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """List content library items for the tenant."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data, meta = client.list(API_PATH, limit=limit, skip=skip)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, columns=LIST_COLUMNS, title="Content Items")
    render_meta(meta, output_format=output)


@app.command("get")
def get_content_item(
    content_item_id: str = typer.Argument(help="Content item ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Get a content item including its body and attachments."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data = client.get(API_PATH, content_item_id)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, is_list=False, title="Content Item")


@app.command("create")
def create_content_item(
    name: str = typer.Option(..., "--name", "-n", help="Content item name"),
    body: str = typer.Option(..., "--body", "-b", help="Body text (supports {{template}} vars)"),
    channel_type: str = typer.Option(
        None, "--channel-type", help="Channel type hint (sms, telegram, whatsapp, ...)"
    ),
    attachments: str = typer.Option(
        None,
        "--attachments",
        help='Attachments as JSON, e.g. \'[{"url": "...", "type": "image"}]\'',
    ),
    metadata: str = typer.Option(None, "--metadata", help="Metadata as JSON string"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Create a content library item."""
    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {"name": name, "body": body}
    if channel_type is not None:
        data["channel_type"] = channel_type
    if attachments is not None:
        data["attachments"] = _parse_json(attachments, "attachments")
    if metadata is not None:
        data["metadata"] = _parse_json(metadata, "metadata")

    try:
        result = client.create(API_PATH, data)
    except Exception as e:
        _handle_error(e)

    success(f"Content item created: {result.get('id', '')}")
    render(result, output_format=output, is_list=False, title="Created Content Item")


@app.command("update")
def update_content_item(
    content_item_id: str = typer.Argument(help="Content item ID"),
    name: str = typer.Option(None, "--name", "-n", help="Content item name"),
    body: str = typer.Option(None, "--body", "-b", help="Body text"),
    channel_type: str = typer.Option(None, "--channel-type", help="Channel type hint"),
    attachments: str = typer.Option(None, "--attachments", help="Attachments as JSON"),
    metadata: str = typer.Option(None, "--metadata", help="Metadata as JSON string"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Update a content library item."""
    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {}
    if name is not None:
        data["name"] = name
    if body is not None:
        data["body"] = body
    if channel_type is not None:
        data["channel_type"] = channel_type
    if attachments is not None:
        data["attachments"] = _parse_json(attachments, "attachments")
    if metadata is not None:
        data["metadata"] = _parse_json(metadata, "metadata")

    if not data:
        error("No fields to update. Provide at least one option.")
        raise typer.Exit(1)

    try:
        result = client.update(API_PATH, content_item_id, data)
    except Exception as e:
        _handle_error(e)

    success(f"Content item updated: {content_item_id}")
    render(result, output_format=output, is_list=False, title="Updated Content Item")


@app.command("delete")
def delete_content_item(
    content_item_id: str = typer.Argument(help="Content item ID"),
    force: bool = typer.Option(False, "--force", "-y", help="Skip confirmation"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Delete a content library item."""
    if not force:
        typer.confirm(f"Delete content item {content_item_id}?", abort=True)

    client = TurumbaClient(gateway_url=gateway_url)
    try:
        client.delete(API_PATH, content_item_id)
    except Exception as e:
        _handle_error(e)

    success(f"Content item deleted: {content_item_id}")
