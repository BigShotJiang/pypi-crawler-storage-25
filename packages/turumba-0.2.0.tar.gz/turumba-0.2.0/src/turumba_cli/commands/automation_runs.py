"""Automation run commands — inspect and control individual enrollments.

A run is one contact's journey through an automation. List runs for an
automation with `turumba automations runs <automation-id>`; these commands
operate on a single run by its ID.
"""

from __future__ import annotations

import typer

from turumba_cli.client import TurumbaClient
from turumba_cli.errors import TurumbaAPIError, TurumbaAuthError
from turumba_cli.output import error, render, render_meta, success

app = typer.Typer(name="automation-runs", help="Inspect and control automation runs.")

API_PATH = "/v1/automation-runs"

STEP_COLUMNS = {
    "Node": "node_id",
    "Kind": "kind",
    "Status": "status",
    "Error": "error",
    "Started At": "started_at",
    "Finished At": "finished_at",
}


def _handle_error(e: Exception) -> None:
    if isinstance(e, TurumbaAuthError | TurumbaAPIError):
        error(str(e))
    else:
        error(f"Unexpected error: {e}")
    raise typer.Exit(1)


@app.command("get")
def get_run(
    run_id: str = typer.Argument(help="Automation run ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Get a run, including its context_json and resume state."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data = client.get(API_PATH, run_id)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, is_list=False, title="Automation Run")


@app.command("steps")
def list_steps(
    run_id: str = typer.Argument(help="Automation run ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """List the per-node audit trail for a run (each step's status, output, timings)."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data, meta = client.list(f"{API_PATH}/{run_id}/steps")
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, columns=STEP_COLUMNS, title="Run Steps")
    render_meta(meta, output_format=output)


@app.command("cancel")
def cancel_run(
    run_id: str = typer.Argument(help="Automation run ID"),
    force: bool = typer.Option(False, "--force", "-y", help="Skip confirmation"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Cancel a non-terminal run (terminal runs return 409)."""
    if not force:
        typer.confirm(f"Cancel run {run_id}?", abort=True)

    client = TurumbaClient(gateway_url=gateway_url)
    try:
        body = client.post(f"{API_PATH}/{run_id}/cancel")
    except Exception as e:
        _handle_error(e)

    result = body["data"] if isinstance(body, dict) and "data" in body else body
    success(f"Run cancelled: {run_id}")
    render(result, output_format=output, is_list=False, title="Cancelled Run")
