"""Users commands — CRUD for user management."""

from __future__ import annotations

import typer

from turumba_cli.client import TurumbaClient
from turumba_cli.config import get_value
from turumba_cli.errors import TurumbaAPIError, TurumbaAuthError
from turumba_cli.output import error, render, render_meta, success

app = typer.Typer(name="users", help="Manage users (team members within accounts).")

API_PATH = "/v1/users"

LIST_COLUMNS = {
    "ID": "id",
    "Email": "email",
    "Given Name": "given_name",
    "Family Name": "family_name",
    "Phone": "phone",
    "Created At": "created_at",
}


def _handle_error(e: Exception) -> None:
    if isinstance(e, TurumbaAuthError | TurumbaAPIError):
        error(str(e))
    else:
        error(f"Unexpected error: {e}")
    raise typer.Exit(1)


@app.command("list")
def list_users(
    filter_: list[str] | None = typer.Option(None, "--filter", "-f", help="Filter: field:op:value"),
    sort: list[str] | None = typer.Option(None, "--sort", "-s", help="Sort: field:asc|desc"),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    skip: int = typer.Option(0, "--skip", help="Offset"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """List users."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data, meta = client.list(API_PATH, filter_=filter_, sort=sort, limit=limit, skip=skip)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, columns=LIST_COLUMNS, title="Users")
    render_meta(meta, output_format=output)


@app.command("get")
def get_user(
    user_id: str = typer.Argument(help="User ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Get details of a specific user."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data = client.get(API_PATH, user_id)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, is_list=False, title="User Details")


@app.command("create")
def create_user(
    email: str = typer.Option(..., "--email", "-e", help="User email address"),
    given_name: str = typer.Option(..., "--given-name", help="Given (first) name"),
    family_name: str = typer.Option(..., "--family-name", help="Family (last) name"),
    account_id: str = typer.Option(
        None, "--account-id", "-a", help="Account ID (defaults to config default_account_id)"
    ),
    role_id: str = typer.Option(..., "--role-id", "-r", help="Role ID to assign"),
    phone: str = typer.Option(None, "--phone", help="Phone number"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Create a new user."""
    resolved_account_id = account_id or get_value("default_account_id")
    if not resolved_account_id:
        error(
            "account_id is required. Use --account-id or set: turumba config set default_account_id <id>"
        )
        raise typer.Exit(1)

    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {
        "account_id": resolved_account_id,
        "role_id": role_id,
        "email": email,
        "given_name": given_name,
        "family_name": family_name,
    }
    if phone:
        data["phone"] = phone

    try:
        result = client.create(API_PATH, data)
    except Exception as e:
        _handle_error(e)

    success(f"User created: {result.get('id', '')} ({email})")
    render(result, output_format=output, is_list=False, title="Created User")


@app.command("update")
def update_user(
    user_id: str = typer.Argument(help="User ID"),
    given_name: str = typer.Option(None, "--given-name", help="Given (first) name"),
    family_name: str = typer.Option(None, "--family-name", help="Family (last) name"),
    phone: str = typer.Option(None, "--phone", help="Phone number"),
    role_id: str = typer.Option(None, "--role-id", "-r", help="Role ID to assign"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Update an existing user."""
    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {}
    if given_name is not None:
        data["given_name"] = given_name
    if family_name is not None:
        data["family_name"] = family_name
    if phone is not None:
        data["phone"] = phone
    if role_id is not None:
        data["role_id"] = role_id

    if not data:
        error("No fields to update. Provide at least one option.")
        raise typer.Exit(1)

    try:
        result = client.update(API_PATH, user_id, data, method="PUT")
    except Exception as e:
        _handle_error(e)

    success(f"User updated: {user_id}")
    render(result, output_format=output, is_list=False, title="Updated User")


@app.command("delete")
def delete_user(
    user_id: str = typer.Argument(help="User ID"),
    force: bool = typer.Option(False, "--force", "-y", help="Skip confirmation"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Delete a user."""
    if not force:
        typer.confirm(f"Delete user {user_id}?", abort=True)

    client = TurumbaClient(gateway_url=gateway_url)
    try:
        client.delete(API_PATH, user_id)
    except Exception as e:
        _handle_error(e)

    success(f"User deleted: {user_id}")
