"""Automation commands — full lifecycle for the Turumba automation engine.

Covers CRUD, versioned definitions (PUT with optimistic concurrency), the
publish/pause/resume state machine, dry-run testing, version history, and runs.
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from turumba_cli.client import TurumbaClient
from turumba_cli.errors import TurumbaAPIError, TurumbaAuthError
from turumba_cli.output import error, render, render_meta, success

app = typer.Typer(
    name="automations",
    help="Manage automations (auto-reply, drip, broadcast, survey, sync, tag-rule, flow).",
)

API_PATH = "/v1/automations"

AUTOMATION_TYPES = ["autoReply", "drip", "broadcast", "survey", "sync", "tagRule", "flow"]

LIST_COLUMNS = {
    "ID": "id",
    "Name": "name",
    "Type": "type",
    "Status": "status",
    "Version": "current_version",
    "Folder": "folder_id",
    "Created At": "created_at",
}

VERSION_COLUMNS = {
    "Version": "version",
    "Published": "is_published",
    "Created At": "created_at",
    "Created By": "created_by",
}

RUN_COLUMNS = {
    "ID": "id",
    "Contact": "contact_id",
    "State": "state",
    "Current Node": "current_node_id",
    "Version": "automation_version",
    "Started At": "started_at",
}


def _handle_error(e: Exception) -> None:
    if isinstance(e, TurumbaAuthError | TurumbaAPIError):
        error(str(e))
    else:
        error(f"Unexpected error: {e}")
    raise typer.Exit(1)


def _parse_json(raw: str, label: str) -> dict:
    """Parse an inline JSON string, exiting cleanly on malformed input."""
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        error(f"Invalid JSON for {label}: {e}")
        raise typer.Exit(1) from None


def _resolve_json_arg(inline: str | None, file_path: str | None, label: str) -> dict:
    """Resolve a JSON object from an inline string or a file path (exactly one)."""
    if inline and file_path:
        error(f"Provide either --{label} or --{label}-file, not both.")
        raise typer.Exit(1)
    raw = inline
    if file_path:
        try:
            raw = Path(file_path).read_text()
        except OSError as e:
            error(f"Could not read {label} file: {e}")
            raise typer.Exit(1) from None
    if not raw:
        error(f"Provide --{label} (JSON string) or --{label}-file (path to JSON).")
        raise typer.Exit(1)
    return _parse_json(raw, label)


def _unwrap(body: object) -> object:
    """Pull `data` out of a success envelope when present."""
    if isinstance(body, dict) and "data" in body:
        return body["data"]
    return body


@app.command("list")
def list_automations(
    include_archived: bool = typer.Option(
        False, "--include-archived", help="Include archived automations"
    ),
    filter_: list[str] | None = typer.Option(None, "--filter", "-f", help="Filter: field:op:value"),
    sort: list[str] | None = typer.Option(None, "--sort", "-s", help="Sort: field:asc|desc"),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    skip: int = typer.Option(0, "--skip", help="Offset"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """List automations. Use -f type:eq:drip or -f status:eq:active to narrow."""
    client = TurumbaClient(gateway_url=gateway_url)
    extra = {"include_archived": str(include_archived).lower()} if include_archived else None
    try:
        data, meta = client.list(
            API_PATH, filter_=filter_, sort=sort, limit=limit, skip=skip, extra_params=extra
        )
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, columns=LIST_COLUMNS, title="Automations")
    render_meta(meta, output_format=output)


@app.command("get")
def get_automation(
    automation_id: str = typer.Argument(help="Automation ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Get an automation including its draft and published definition blocks."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data = client.get(API_PATH, automation_id)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, is_list=False, title="Automation Details")


@app.command("create")
def create_automation(
    name: str = typer.Option(..., "--name", "-n", help="Automation name"),
    type_: str = typer.Option(
        ..., "--type", "-t", help=f"Automation type: {', '.join(AUTOMATION_TYPES)}"
    ),
    description: str = typer.Option(None, "--description", "-d", help="Description"),
    folder_id: str = typer.Option(None, "--folder-id", help="Folder ID to place it in"),
    metadata: str = typer.Option(None, "--metadata", help="Metadata as JSON string"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Create an automation in draft status. Type is immutable after creation."""
    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {"name": name, "type": type_}
    if description is not None:
        data["description"] = description
    if folder_id is not None:
        data["folder_id"] = folder_id
    if metadata is not None:
        data["metadata"] = _parse_json(metadata, "metadata")

    try:
        result = client.create(API_PATH, data)
    except Exception as e:
        _handle_error(e)

    success(f"Automation created: {result.get('id', '')}")
    render(result, output_format=output, is_list=False, title="Created Automation")


@app.command("update")
def update_automation(
    automation_id: str = typer.Argument(help="Automation ID"),
    name: str = typer.Option(None, "--name", "-n", help="Automation name"),
    description: str = typer.Option(None, "--description", "-d", help="Description"),
    folder_id: str = typer.Option(None, "--folder-id", help="Folder ID"),
    metadata: str = typer.Option(None, "--metadata", help="Metadata as JSON string"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Update automation metadata. Type and status cannot change here."""
    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {}
    if name is not None:
        data["name"] = name
    if description is not None:
        data["description"] = description
    if folder_id is not None:
        data["folder_id"] = folder_id
    if metadata is not None:
        data["metadata"] = _parse_json(metadata, "metadata")

    if not data:
        error("No fields to update. Provide at least one option.")
        raise typer.Exit(1)

    try:
        result = client.update(API_PATH, automation_id, data)
    except Exception as e:
        _handle_error(e)

    success(f"Automation updated: {automation_id}")
    render(result, output_format=output, is_list=False, title="Updated Automation")


@app.command("delete")
def delete_automation(
    automation_id: str = typer.Argument(help="Automation ID"),
    force: bool = typer.Option(False, "--force", "-y", help="Skip confirmation"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Delete an automation."""
    if not force:
        typer.confirm(f"Delete automation {automation_id}?", abort=True)

    client = TurumbaClient(gateway_url=gateway_url)
    try:
        client.delete(API_PATH, automation_id)
    except Exception as e:
        _handle_error(e)

    success(f"Automation deleted: {automation_id}")


@app.command("save-definition")
def save_definition(
    automation_id: str = typer.Argument(help="Automation ID"),
    definition: str = typer.Option(None, "--definition", help="Definition JSON string"),
    definition_file: str = typer.Option(
        None, "--definition-file", help="Path to a JSON file with the definition"
    ),
    if_match: int = typer.Option(
        None, "--if-match", help="Expected current version (optimistic concurrency guard)"
    ),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Save a new draft definition version (the graph: triggers, nodes, edges).

    The JSON may be the bare definition (type/triggers/nodes/edges/settings) or a
    full PUT body ({"definition_json": {...}}); both are accepted. See
    `turumba skills show automation-definitions` for the graph schema per type.
    """
    loaded = _resolve_json_arg(definition, definition_file, "definition")
    body = loaded if "definition_json" in loaded else {"definition_json": loaded}
    if if_match is not None:
        body["if_match_version"] = if_match

    extra_headers = {"If-Match": str(if_match)} if if_match is not None else None
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        result = _unwrap(
            client.request(
                "PUT",
                f"{API_PATH}/{automation_id}/definition",
                json_data=body,
                extra_headers=extra_headers,
            )
        )
    except Exception as e:
        _handle_error(e)

    version = result.get("version") if isinstance(result, dict) else None
    success(f"Definition saved: v{version}" if version else "Definition saved")
    render(result, output_format=output, is_list=False, title="Saved Definition")


def _lifecycle(automation_id: str, action: str, gateway_url: str, output: str) -> None:
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        result = _unwrap(client.post(f"{API_PATH}/{automation_id}/{action}"))
    except Exception as e:
        _handle_error(e)

    success(f"Automation {action}: {automation_id}")
    render(result, output_format=output, is_list=False, title=f"Automation ({action})")


@app.command("publish")
def publish_automation(
    automation_id: str = typer.Argument(help="Automation ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Publish the draft definition and move the automation to active."""
    _lifecycle(automation_id, "publish", gateway_url, output)


@app.command("pause")
def pause_automation(
    automation_id: str = typer.Argument(help="Automation ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Pause an active automation (stops new enrollments and firing)."""
    _lifecycle(automation_id, "pause", gateway_url, output)


@app.command("resume")
def resume_automation(
    automation_id: str = typer.Argument(help="Automation ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Resume a paused automation back to active."""
    _lifecycle(automation_id, "resume", gateway_url, output)


@app.command("test")
def test_automation(
    automation_id: str = typer.Argument(help="Automation ID"),
    event: str = typer.Option(None, "--event", help="Synthetic trigger event as JSON string"),
    event_file: str = typer.Option(None, "--event-file", help="Path to a JSON file with the event"),
    contact_id: str = typer.Option(None, "--contact-id", help="Contact ID (defaults to synthetic)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Dry-run the definition against a synthetic event (no real side effects).

    Returns a step-by-step audit. Example event:
    '{"kind": "message.created", "body": "hello", "channel_id": "<uuid>"}'
    """
    event_json = _resolve_json_arg(event, event_file, "event")
    body: dict = {"event": event_json}
    if contact_id is not None:
        body["contact_id"] = contact_id

    client = TurumbaClient(gateway_url=gateway_url)
    try:
        result = _unwrap(client.post(f"{API_PATH}/{automation_id}/test", data=body))
    except Exception as e:
        _handle_error(e)

    render(result, output_format=output, is_list=False, title="Dry-Run Report")


@app.command("versions")
def list_versions(
    automation_id: str = typer.Argument(help="Automation ID"),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    skip: int = typer.Option(0, "--skip", help="Offset"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """List a definition's version history (newest first). Versions are immutable."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data, meta = client.list(f"{API_PATH}/{automation_id}/versions", limit=limit, skip=skip)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, columns=VERSION_COLUMNS, title="Definition Versions")
    render_meta(meta, output_format=output)


@app.command("version")
def get_version(
    automation_id: str = typer.Argument(help="Automation ID"),
    version: int = typer.Argument(help="Version number"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Get a single definition version (full definition_json). Use -o json."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        result = _unwrap(client.request("GET", f"{API_PATH}/{automation_id}/versions/{version}"))
    except Exception as e:
        _handle_error(e)

    render(result, output_format=output, is_list=False, title=f"Definition v{version}")


@app.command("runs")
def list_runs(
    automation_id: str = typer.Argument(help="Automation ID"),
    state: str = typer.Option(
        None, "--state", help="State filter: running, waiting, paused, completed, failed, cancelled"
    ),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    skip: int = typer.Option(0, "--skip", help="Offset"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """List runs (enrollments) for an automation."""
    client = TurumbaClient(gateway_url=gateway_url)
    extra = {"state": state} if state else None
    try:
        data, meta = client.list(
            f"{API_PATH}/{automation_id}/runs", limit=limit, skip=skip, extra_params=extra
        )
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, columns=RUN_COLUMNS, title="Automation Runs")
    render_meta(meta, output_format=output)
