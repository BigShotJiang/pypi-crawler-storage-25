"""Group messages commands — CRUD for group message broadcasts."""

from __future__ import annotations

import json

import typer

from turumba_cli.client import TurumbaClient
from turumba_cli.config import get_value
from turumba_cli.errors import TurumbaAPIError, TurumbaAuthError
from turumba_cli.output import error, render, render_meta, success

app = typer.Typer(name="group-messages", help="Manage group message broadcasts.")

API_PATH = "/v1/group-messages"

LIST_COLUMNS = {
    "ID": "id",
    "Name": "name",
    "Status": "status",
    "Total": "total_recipients",
    "Sent": "sent_count",
    "Delivered": "delivered_count",
    "Failed": "failed_count",
    "Scheduled At": "scheduled_at",
    "Created At": "created_at",
}


def _handle_error(e: Exception) -> None:
    if isinstance(e, TurumbaAuthError | TurumbaAPIError):
        error(str(e))
    else:
        error(f"Unexpected error: {e}")
    raise typer.Exit(1)


@app.command("list")
def list_group_messages(
    filter_: list[str] | None = typer.Option(None, "--filter", "-f", help="Filter: field:op:value"),
    sort: list[str] | None = typer.Option(None, "--sort", "-s", help="Sort: field:asc|desc"),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    skip: int = typer.Option(0, "--skip", help="Offset"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """List group messages."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data, meta = client.list(API_PATH, filter_=filter_, sort=sort, limit=limit, skip=skip)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, columns=LIST_COLUMNS, title="Group Messages")
    render_meta(meta, output_format=output)


@app.command("get")
def get_group_message(
    group_message_id: str = typer.Argument(help="Group message ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Get details of a specific group message."""
    client = TurumbaClient(gateway_url=gateway_url)
    try:
        data = client.get(API_PATH, group_message_id)
    except Exception as e:
        _handle_error(e)

    render(data, output_format=output, is_list=False, title="Group Message Details")


@app.command("create")
def create_group_message(
    account_id: str = typer.Option(
        None, "--account-id", "-a", help="Account ID (defaults to config default_account_id)"
    ),
    name: str = typer.Option(None, "--name", "-n", help="Group message name"),
    channel_id: str = typer.Option(None, "--channel-id", "-c", help="Channel ID to send through"),
    template_id: str = typer.Option(None, "--template-id", "-t", help="Template ID"),
    message_body: str = typer.Option(None, "--body", "-b", help="Message body (if no template)"),
    group_ids: list[str] | None = typer.Option(None, "--group-id", help="Group ID(s) to send to"),
    person_ids: list[str] | None = typer.Option(
        None, "--person-id", help="Person ID(s) to send to"
    ),
    contact_ids: list[str] | None = typer.Option(
        None, "--contact-id", help="Contact ID(s) to send to"
    ),
    exclude_person_ids: list[str] | None = typer.Option(
        None, "--exclude-person-id", help="Person ID(s) to exclude"
    ),
    scheduled_at: str = typer.Option(None, "--scheduled-at", help="Schedule time (ISO 8601)"),
    custom_values: str = typer.Option(
        None, "--custom-values", help="Custom template values as JSON"
    ),
    metadata: str = typer.Option(None, "--metadata", help="Metadata as JSON string"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Create a new group message broadcast."""
    if not template_id and not message_body:
        error("Provide either --template-id or --body.")
        raise typer.Exit(1)
    if not group_ids and not person_ids and not contact_ids:
        error("Provide at least one of --group-id, --person-id, or --contact-id.")
        raise typer.Exit(1)

    resolved_account_id = account_id or get_value("default_account_id")

    client = TurumbaClient(gateway_url=gateway_url)

    fields: dict = {
        "account_id": resolved_account_id,
        "name": name,
        "channel_id": channel_id,
        "template_id": template_id,
        "message_body": message_body,
        "group_ids": group_ids,
        "person_ids": person_ids,
        "contact_ids": contact_ids,
        "exclude_person_ids": exclude_person_ids,
        "scheduled_at": scheduled_at,
    }
    data = {k: v for k, v in fields.items() if v}
    if custom_values:
        data["custom_values"] = json.loads(custom_values)
    if metadata:
        data["metadata"] = json.loads(metadata)

    try:
        result = client.create(API_PATH, data)
    except Exception as e:
        _handle_error(e)

    success(f"Group message created: {result.get('id', '')}")
    render(result, output_format=output, is_list=False, title="Created Group Message")


@app.command("update")
def update_group_message(
    group_message_id: str = typer.Argument(help="Group message ID"),
    name: str = typer.Option(None, "--name", "-n", help="Group message name"),
    channel_id: str = typer.Option(None, "--channel-id", "-c", help="Channel ID"),
    template_id: str = typer.Option(None, "--template-id", "-t", help="Template ID"),
    message_body: str = typer.Option(None, "--body", "-b", help="Message body"),
    scheduled_at: str = typer.Option(None, "--scheduled-at", help="Schedule time (ISO 8601)"),
    custom_values: str = typer.Option(
        None, "--custom-values", help="Custom template values as JSON"
    ),
    metadata: str = typer.Option(None, "--metadata", help="Metadata as JSON string"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Update an existing group message."""
    client = TurumbaClient(gateway_url=gateway_url)

    data: dict = {}
    if name is not None:
        data["name"] = name
    if channel_id is not None:
        data["channel_id"] = channel_id
    if template_id is not None:
        data["template_id"] = template_id
    if message_body is not None:
        data["message_body"] = message_body
    if scheduled_at is not None:
        data["scheduled_at"] = scheduled_at
    if custom_values is not None:
        data["custom_values"] = json.loads(custom_values)
    if metadata is not None:
        data["metadata"] = json.loads(metadata)

    if not data:
        error("No fields to update. Provide at least one option.")
        raise typer.Exit(1)

    try:
        result = client.update(API_PATH, group_message_id, data)
    except Exception as e:
        _handle_error(e)

    success(f"Group message updated: {group_message_id}")
    render(result, output_format=output, is_list=False, title="Updated Group Message")


@app.command("delete")
def delete_group_message(
    group_message_id: str = typer.Argument(help="Group message ID"),
    force: bool = typer.Option(False, "--force", "-y", help="Skip confirmation"),
    gateway_url: str = typer.Option(None, "--gateway-url", "-g", help="Gateway URL override"),
) -> None:
    """Delete a group message."""
    if not force:
        typer.confirm(f"Delete group message {group_message_id}?", abort=True)

    client = TurumbaClient(gateway_url=gateway_url)
    try:
        client.delete(API_PATH, group_message_id)
    except Exception as e:
        _handle_error(e)

    success(f"Group message deleted: {group_message_id}")
