"""Write pipeline — extract → resolve → reconcile → upsert + helpers."""

from arandu.write.canonicalization import (
    canonicalize_attribute_key,
    normalize_key,
    validate_proposed_key,
)
from arandu.write.correction import (
    CorrectionResult,
    detect_and_record_corrections,
    is_user_correction,
)
from arandu.write.entity_helpers import (
    create_or_update_entity,
    get_entities_for_user,
    get_entity_by_key,
)
from arandu.write.extraction_strategy import (
    ExtractionMode,
    ExtractionStrategy,
    InputClassification,
    InputType,
    classify_input,
    select_strategy,
)
from arandu.write.pending_ops import (
    clear_pending,
    get_pending,
    save_pending_execution,
    save_pending_selection,
)
from arandu.write.pipeline import run_write_pipeline

__all__ = [
    "CorrectionResult",
    "ExtractionMode",
    "ExtractionStrategy",
    "InputClassification",
    "InputType",
    "canonicalize_attribute_key",
    "classify_input",
    "clear_pending",
    "create_or_update_entity",
    "detect_and_record_corrections",
    "get_entities_for_user",
    "get_entity_by_key",
    "get_pending",
    "is_user_correction",
    "normalize_key",
    "run_write_pipeline",
    "save_pending_execution",
    "save_pending_selection",
    "select_strategy",
    "validate_proposed_key",
]
