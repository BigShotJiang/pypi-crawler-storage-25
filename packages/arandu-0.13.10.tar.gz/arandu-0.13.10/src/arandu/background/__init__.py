"""Background jobs — clustering, consolidation, sleep-time compute, memify."""

from arandu.background.clustering import (
    ClusteringResult,
    CommunityDetectionResult,
    cluster_user_facts,
    detect_communities,
)
from arandu.background.consolidation import (
    ConsolidationResult,
    run_consolidation,
    run_profile_consolidation,
    tag_event_emotion,
)
from arandu.background.memify import (
    MemifyResult,
    compute_vitality,
    run_memify,
)
from arandu.background.sleep_time import (
    EntityImportanceResult,
    ProfileConsolidationResult,
    SummaryRefreshResult,
    compute_entity_importance,
    consolidate_entity_profiles,
    detect_entity_communities,
    refresh_entity_summaries,
)

__all__ = [
    "ClusteringResult",
    "CommunityDetectionResult",
    "ConsolidationResult",
    "EntityImportanceResult",
    "MemifyResult",
    "ProfileConsolidationResult",
    "SummaryRefreshResult",
    "cluster_user_facts",
    "compute_entity_importance",
    "compute_vitality",
    "consolidate_entity_profiles",
    "detect_communities",
    "detect_entity_communities",
    "refresh_entity_summaries",
    "run_consolidation",
    "run_memify",
    "run_profile_consolidation",
    "tag_event_emotion",
]
