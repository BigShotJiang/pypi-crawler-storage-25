"""Context compression — tiered hot/warm/cold within a token budget.

Builds a prompt-ready context string from scored facts, events, clusters,
and meta-observations. Three tiers with configurable budget ratios:

- **Hot (Tier 1)**: Top facts in full format (core memory).
- **Warm (Tier 2)**: Remaining facts grouped by entity, compact format.
- **Cold (Tier 3)**: Cluster summaries, meta-observations, events.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from arandu.config import MemoryConfig

logger = logging.getLogger(__name__)

__all__ = ["CompressedContext", "compress_broad_context", "compress_context"]


# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------


_AVG_CHARS_PER_TOKEN = 4


def _est_tokens(text: str) -> int:
    """Heuristic: ~4 chars per token."""
    return max(0, len(text) // _AVG_CHARS_PER_TOKEN)


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class CompressedContext:
    """Result of context compression.

    Attributes:
        context_text: Final prompt-ready context string.
        hot_count: Number of facts in hot tier (Tier 1).
        warm_count: Number of facts in warm tier (Tier 2).
        cold_count: Number of items in cold tier (Tier 3).
        total_tokens: Estimated token count of context_text.
    """

    context_text: str = ""
    hot_count: int = 0
    warm_count: int = 0
    cold_count: int = 0
    total_tokens: int = 0


# ---------------------------------------------------------------------------
# Fact formatting helpers
# ---------------------------------------------------------------------------


def _fact_line(entry: dict[str, Any]) -> str:
    """Format a fact as a clean line for LLM consumption. No timestamps, no noise."""
    value = entry.get("value", "")
    return f"- {value}" if value else ""


# ---------------------------------------------------------------------------
# Main compression
# ---------------------------------------------------------------------------


async def compress_context(
    facts: list[dict[str, Any]],
    events: list[dict[str, Any]],
    config: MemoryConfig,
    *,
    clusters: list[Any] | None = None,
    meta_observations: list[Any] | None = None,
    stale_keys: set[str] | None = None,
    stale_threshold_days: int = 90,
    now: datetime | None = None,
    entity_profiles: dict[str, str] | None = None,
) -> CompressedContext:
    """Build tiered context text within token budget.

    Tier 1 (hot): Top 5 facts in full format.
    Tier 2 (warm): Remaining facts grouped by entity, compact.
    Tier 3 (cold): Cluster summaries, meta-observations, events.

    Args:
        facts: Scored fact dicts (must have ``score``, ``fact``, ``entity``,
            ``attribute``, ``value``, ``date`` keys).
        events: Event dicts with ``date`` and ``text`` keys.
        config: Memory configuration with token budget and tier ratios.
        clusters: Optional cluster objects with ``label`` and ``summary_text``.
        meta_observations: Optional meta-observation objects.
        stale_keys: Attribute keys that are considered always-stale.
        stale_threshold_days: Days after which a fact is stale.
        now: Current timestamp (defaults to UTC now).

    Returns:
        CompressedContext with tiered context text.
    """
    if now is None:
        now = datetime.now(UTC)

    token_budget = config.context_max_tokens
    budget_hot = int(token_budget * config.hot_tier_ratio)
    budget_warm = int(token_budget * config.warm_tier_ratio)
    budget_cold = token_budget - budget_hot - budget_warm

    # Sort by score descending
    all_facts = sorted(facts, key=lambda x: x.get("score", 0.0), reverse=True)

    lines: list[str] = []
    tokens_used = 0
    hot_count = 0
    warm_count = 0
    cold_count = 0

    # -- Facts: clean list, no timestamps, no entity prefixes --
    fact_lines: list[str] = []
    fact_budget = budget_hot + budget_warm
    for entry in all_facts:
        line = _fact_line(entry)
        if not line:
            continue
        cost = _est_tokens(line)
        if tokens_used + cost > fact_budget and fact_lines:
            break
        fact_lines.append(line)
        tokens_used += cost
        if len(fact_lines) <= 5:
            hot_count += 1
        else:
            warm_count += 1

    if fact_lines:
        lines.append("Known facts:")
        lines.extend(fact_lines)
        lines.append("")

    # -- Patterns & clusters (compact) --
    total_budget = budget_hot + budget_warm + budget_cold
    pattern_lines: list[str] = []

    for o in (meta_observations or [])[:3]:
        title = getattr(o, "title", "")
        if title:
            line = f"- {title}"
            cost = _est_tokens(line)
            if tokens_used + cost > total_budget:
                break
            pattern_lines.append(line)
            tokens_used += cost
            cold_count += 1

    if pattern_lines:
        lines.append("Observed patterns:")
        lines.extend(pattern_lines)
        lines.append("")

    # -- Events: original conversation messages as episodic fallback --
    event_lines: list[str] = []
    for e in (events or [])[:8]:
        date = e.get("date", "")
        text = e.get("text", "")
        if not text and e.get("event"):
            ev = e["event"]
            text = getattr(ev, "text", "") or ""
            if not date and getattr(ev, "occurred_at", None):
                occ = ev.occurred_at
                date = occ.strftime("%Y-%m-%d") if hasattr(occ, "strftime") else str(occ)[:10]
        if not text or len(text.strip()) < 15:
            continue
        text = (text or "")[:300]
        ellipsis = "..." if len(text) >= 300 else ""
        line = f"- ({date}) {text}{ellipsis}"
        cost = _est_tokens(line)
        if tokens_used + cost > total_budget + 400:
            break
        event_lines.append(line)
        tokens_used += cost
        cold_count += 1

    if event_lines:
        lines.append("Relevant conversations:")
        lines.extend(event_lines)

    context_text = "\n".join(lines)
    total_tokens = _est_tokens(context_text)

    return CompressedContext(
        context_text=context_text,
        hot_count=hot_count,
        warm_count=warm_count,
        cold_count=cold_count,
        total_tokens=total_tokens,
    )


# ---------------------------------------------------------------------------
# Broad cluster-first compression
# ---------------------------------------------------------------------------


async def compress_broad_context(
    cluster_facts: dict[str, list[dict[str, Any]]],
    clusters: list[Any],
    config: MemoryConfig,
    *,
    meta_observations: list[Any] | None = None,
    events: list[dict[str, Any]] | None = None,
) -> CompressedContext:
    """Build context for broad queries using clusters as primary unit.

    Tier 1 (50%): Cluster summaries + representative facts inline.
    Tier 2 (25%): Meta-observations (top 5).
    Tier 3 (25%): Recent events (top 5).

    Args:
        cluster_facts: Mapping of cluster_label → fact dicts.
        clusters: Cluster objects with ``label``, ``summary_text``, ``fact_count``.
        config: Memory configuration.
        meta_observations: Optional meta-observation objects.
        events: Optional event dicts.

    Returns:
        CompressedContext with cluster-first context text.
    """
    token_budget = config.context_max_tokens
    budget_t1 = int(token_budget * 0.50)
    budget_t2 = int(token_budget * 0.25)
    budget_t3 = int(token_budget * 0.25)

    lines: list[str] = []
    tokens_used = 0
    hot_count = 0
    warm_count = 0
    cold_count = 0

    # -- Tier 1: Cluster summaries + inline facts --
    section1: list[str] = []
    sorted_clusters = sorted(
        clusters,
        key=lambda c: getattr(c, "fact_count", 0) or 0,
        reverse=True,
    )

    for cluster in sorted_clusters:
        label = getattr(cluster, "label", "?")
        summary = getattr(cluster, "summary_text", "") or ""
        summary_short = summary[:200] + ("..." if len(summary) > 200 else "")

        facts_for_cluster = cluster_facts.get(label, [])
        fact_parts: list[str] = []
        for fe in facts_for_cluster:
            attr = fe.get("attribute", "")
            val = fe.get("value", "")
            if attr and val:
                fact_parts.append(f"{attr}: {val}")

        inline = " | ".join(fact_parts) if fact_parts else ""
        line = f"  • [{label}] {summary_short}" + (f" ({inline})" if inline else "")
        cost = _est_tokens(line)
        if tokens_used + cost > budget_t1 and section1:
            break
        section1.append(line)
        tokens_used += cost
        hot_count += 1

    if section1:
        lines.append("═══ BRAIN OVERVIEW ═══")
        lines.extend(section1)
        lines.append("")

    # -- Tier 2: Meta-observations --
    section2: list[str] = []
    for o in (meta_observations or [])[:5]:
        otype = getattr(o, "observation_type", "pattern")
        title = getattr(o, "title", "")
        conf = getattr(o, "confidence", 0.7) or 0.7
        times = getattr(o, "times_reinforced", 1) or 1
        line = f"  • [{otype}] {title} — detected {times}x (confidence: {conf:.2f})"
        cost = _est_tokens(line)
        if tokens_used + cost > budget_t1 + budget_t2:
            break
        section2.append(line)
        tokens_used += cost
        warm_count += 1

    if section2:
        lines.append("═══ PATTERNS & INSIGHTS ═══")
        lines.extend(section2)
        lines.append("")

    # -- Tier 3: Events --
    event_lines: list[str] = []
    for e in (events or [])[:5]:
        date = e.get("date", "")
        text = e.get("text", "")
        if not text and e.get("event"):
            ev = e["event"]
            text = getattr(ev, "text", "") or ""
            if not date and getattr(ev, "occurred_at", None):
                occ = ev.occurred_at
                date = occ.strftime("%Y-%m-%d") if hasattr(occ, "strftime") else str(occ)[:10]
        text = (text or "")[:80]
        ellipsis = "..." if len(text) >= 80 else ""
        line = f"  • ({date}) {text}{ellipsis}"
        cost = _est_tokens(line)
        if tokens_used + cost > budget_t1 + budget_t2 + budget_t3:
            break
        event_lines.append(line)
        tokens_used += cost
        cold_count += 1

    if event_lines:
        lines.append("═══ RELEVANT_EVENTS (history — do NOT assert as current truth) ═══")
        lines.extend(event_lines)

    context_text = "\n".join(lines)
    total_tokens = _est_tokens(context_text)

    return CompressedContext(
        context_text=context_text,
        hot_count=hot_count,
        warm_count=warm_count,
        cold_count=cold_count,
        total_tokens=total_tokens,
    )
