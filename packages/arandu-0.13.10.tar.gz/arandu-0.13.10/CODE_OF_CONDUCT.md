# Code of Conduct

This project follows the [Contributor Covenant v2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).

By participating in this project, you agree to abide by its terms.

## Reporting

If you experience or witness unacceptable behavior, please report it by emailing **pedromenezesrs@gmail.com**. All reports will be handled with discretion.
