# Contributing to arandu

Thank you for your interest in contributing to arandu! This guide will help you get started.

## Prerequisites

- Python 3.11 or later
- Git

## Development Setup

1. **Fork and clone the repository:**

   ```bash
   git clone https://github.com/<your-username>/arandu.git
   cd arandu
   ```

2. **Create a virtual environment:**

   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Linux/macOS
   # or
   .venv\Scripts\activate     # Windows
   ```

3. **Install in development mode:**

   ```bash
   pip install -e ".[dev]"
   ```

## Running Tests

All tests use mock providers (no database required):

```bash
pytest
```

To run a specific test file:

```bash
pytest tests/test_extraction.py
```

## Code Style

This project uses [ruff](https://docs.astral.sh/ruff/) for linting and formatting, and [mypy](https://mypy-lang.org/) for type checking.

**Check linting and formatting:**

```bash
ruff check .
ruff format --check .
```

**Auto-fix lint issues and format code:**

```bash
ruff check --fix .
ruff format .
```

**Run type checking:**

```bash
mypy src/
```

Please ensure all three checks pass before submitting a pull request.

## Pull Request Guidelines

1. **Create a feature branch** from `main`:

   ```bash
   git checkout -b feature/my-feature
   ```

2. **Keep changes focused.** One pull request per feature or bug fix.

3. **Write tests** for new functionality.

4. **Ensure all checks pass:**

   ```bash
   pytest
   ruff check .
   ruff format --check .
   mypy src/
   ```

5. **Write a clear PR description** explaining what changed and why.

6. **Link related issues** in the PR description (e.g., "Closes #42").

## Reporting Bugs

Please use the [GitHub Issues](https://github.com/pe-menezes/arandu/issues) page to report bugs. Include:

- A clear description of the problem
- Steps to reproduce
- Expected vs. actual behavior
- Python version and OS

## Questions?

Feel free to open an issue for questions or discussions about the project.
