## Audit Report: Unificar reconciliação

**Verdict: PASS**

### DoD Checklist

- [x] **1. `reconcile_facts()` chamado em ambos os modos** — `pipeline.py:370` chama `reconcile_facts()` incondicionalmente. O branch `if extraction_meta.get("mode") == "informed"` foi removido. Grep confirma: zero ocorrências de `build_informed` em `pipeline.py`.

- [x] **2. `build_informed_decisions()` e `_find_update_target()` removidos** — grep por `build_informed_decisions|_find_update_target` em todo o codebase retorna zero matches. Funções removidas de `informed_extract.py`. Import de `ReconciliationDecision` removido do módulo.

- [x] **3. Prompt sem action/updates** — grep por `RULES FOR ACTION|"action".*NEW.*UPDATE|"updates"` em `informed_extract.py` retorna zero matches. JSON schema no prompt não contém `action` nem `updates`. `importance_category` preservado. Bloco substituído por "RULES FOR DEDUPLICATION" que orienta o LLM a não re-extrair informação existente (responsabilidade de filtragem, não de decisão).

- [x] **4. Testes passam** — `python -m pytest tests/ -q`: 475 passed, 0 failures. `TestBuildInformedDecisions` removido de `test_informed_extract.py`. Import de `build_informed_decisions` removido. `TestPipelineFallback` adaptado pro caminho único.

- [x] **5. Sem violações de conventions** — ruff check: all passed. ruff format: 84 files formatted. mypy: no issues in 44 files. Fail-safe pattern preservado: `reconcile_facts` fallback (all ADD) inalterado em `reconcile.py`.

### Pattern Compliance

- [x] **Pipeline Orchestration** — `reconcile_facts()` é agora stage incondicional entre extração e upsert. Padrão de stage sequencial com timing (`_t_rec`) preservado. Evidence: `pipeline.py:366-377`.

- [x] **Fail-Safe Error Handling** — reconcile fallback (all ADD on LLM failure) preservado sem alteração. Importância propagada via `_fact_importance()` helper com fallback default (`IMPORTANCE_CATEGORY_DEFAULT = 0.5`). Evidence: `reconcile.py:33-37`.

- [x] **LLM Interaction** — prompt de extração informada modificado: removeu campos `action`/`updates` do JSON schema. Parse continua aceitando campos extras do JSON sem quebrar (Pydantic `model_validate` ignora extras por default). Evidence: `informed_extract.py:112-115`.

### Convention Violations

Nenhuma.

### Gaps

Nenhum.
