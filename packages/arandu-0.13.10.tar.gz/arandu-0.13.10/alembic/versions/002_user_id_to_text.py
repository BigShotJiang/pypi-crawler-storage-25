"""Convert user_id columns from INTEGER to TEXT.

Revision ID: 002
Depends on: 001
Create Date: 2026-03-19

Fixes a type mismatch: the SDK internally passes user_id as a string,
but initialize() (via create_all) created columns as INTEGER when the
model used Integer. The migration already used VARCHAR, but databases
created via initialize() have INTEGER columns.

This migration converts all user_id columns to TEXT, which accepts any
string format (UUID, email, numeric, etc.).
"""

from alembic import op

revision = "002"
down_revision = "001"
branch_labels = None
depends_on = None

# All tables that have a user_id column.
_TABLES = [
    "memory_events",
    "memory_clusters",
    "memory_facts",
    "memory_meta_observations",
    "memory_entities",
    "memory_entity_aliases",
    "memory_entity_relationships",
    "memory_intentions",
    "session_observations",
]


def upgrade() -> None:
    for table in _TABLES:
        op.execute(f"ALTER TABLE {table} ALTER COLUMN user_id TYPE TEXT USING user_id::TEXT")


def downgrade() -> None:
    for table in _TABLES:
        op.execute(f"ALTER TABLE {table} ALTER COLUMN user_id TYPE INTEGER USING user_id::INTEGER")
