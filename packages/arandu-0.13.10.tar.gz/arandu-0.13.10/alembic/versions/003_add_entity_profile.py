"""Add profile_text and profile_refreshed_at to memory_entities.

Revision ID: 003
Revises: 002
Create Date: 2026-03-30
"""

from alembic import op

revision = "003"
down_revision = "002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("memory_entities", op.Column("profile_text", op.Text(), nullable=True))
    op.add_column(
        "memory_entities",
        op.Column("profile_refreshed_at", op.DateTime(timezone=True), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("memory_entities", "profile_refreshed_at")
    op.drop_column("memory_entities", "profile_text")
