## Description

<!-- What does this PR do? Why is this change needed? -->

## Checklist

- [ ] Tests pass (`pytest`)
- [ ] Lint passes (`ruff check .` and `ruff format --check .`)
- [ ] Type check passes (`mypy src/`)
- [ ] No breaking changes (or documented below)

## Breaking Changes

<!-- If this PR introduces breaking changes, describe them here. Otherwise, delete this section. -->
