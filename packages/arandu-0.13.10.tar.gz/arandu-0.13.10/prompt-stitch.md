# Prompt para Google Stitch — Landing Page Arandu

---

Create a single-page landing site for **Arandu**, an open-source Python SDK that gives AI agents long-term memory. The name comes from the Guarani word meaning "wisdom acquired through experience" — literally "listening to time."

## Visual Theme & Atmosphere

The entire site should feel like **entering the Amazon rainforest at dawn** — lush, alive, breathing. The design language is: **Brazilian nature meets modern developer tooling**.

**Color palette:**
- Primary: deep forest greens (#0B3D2E, #1A5C3A, #2D8B5E)
- Accent: golden amber (#D4A017, #F2C94C) — like sunlight filtering through the canopy
- Dark background: deep jungle night (#0A1F14, #0D2818)
- Text: warm white (#F5F0E8) on dark, dark green on light sections
- Subtle touches of tropical blue (#1B6B93) for links/interactive elements

**Visual elements & illustrations:**
- Hero section: a lush canopy with light rays breaking through. Subtle animated particles floating like fireflies or pollen in the air. A tucano (toucan) perched somewhere, maybe animated with a subtle head tilt or blink.
- Araras (macaws) flying gracefully across section transitions — not cartoonish, more like elegant silhouettes or semi-realistic illustrations with a slight parallax effect as you scroll.
- Vines and leaves as subtle decorative borders between sections, gently swaying with a CSS animation.
- The background should have depth — layered forest elements (foreground leaves, mid-ground trees, background mist) creating a parallax scrolling effect.
- Subtle ambient animations: leaves drifting, light rays shifting, birds in the distance.

**Typography:**
- Headings: a bold, modern sans-serif with character (e.g., Inter, Plus Jakarta Sans, or similar)
- Body: clean and readable (Inter, Source Sans)
- Code snippets: JetBrains Mono or Fira Code with a dark terminal-style background that looks like a gap in the canopy

## Page Structure & Content

### 1. Hero Section
- Big headline: **"Arandu"** with a subtle golden glow animation
- Subtitle: "Long-term memory for AI agents — wisdom acquired through experience"
- Brief poetic line: *"From the Guarani: to listen to time. Give your AI the gift of remembering."*
- Two CTA buttons: "Get Started" (links to https://pe-menezes.github.io/arandu/getting-started/) and "View on GitHub" (links to https://github.com/pe-menezes/arandu)
- A small animated badge: "pip install arandu" with a copy button
- Background: the deep forest canopy with animated light rays and floating particles

### 2. What is Arandu? (brief intro)
- 2-3 short paragraphs explaining the problem (AI agents forget everything) and the solution (persistent, structured memory that grows smarter over time)
- A simple animated diagram showing: Message → Extract → Resolve → Reconcile → Remember
- Keep it non-technical, inviting

### 3. How It Works (3 cards or columns)
Three visual cards with icons inspired by nature:

- **Write Pipeline** 🌱 (seed/growth metaphor): "Send a message, get structured knowledge. Arandu extracts facts, resolves entities, and reconciles with what it already knows — automatically."
- **Read Pipeline** 🦜 (bird finding its way): "Ask a question, get relevant context. Semantic search, keyword matching, graph traversal, and recency scoring work together to find what matters."
- **Background Jobs** 🌙 (moon/night/sleep): "Like a brain consolidating memories during sleep. Clustering, consolidation, and importance scoring keep memory fresh and organized."

### 4. Code Example
A beautiful, syntax-highlighted code block showing a minimal working example:

```python
from arandu import MemoryClient
from arandu.providers.openai import OpenAIProvider

provider = OpenAIProvider(api_key="sk-...")
memory = MemoryClient(
    database_url="postgresql+psycopg://user:pass@localhost/mydb",
    llm=provider,
    embeddings=provider,
)

# Write — extracts facts automatically
await memory.write(user_id="u1", message="I live in São Paulo with my wife Ana")

# Retrieve — finds relevant context
result = await memory.retrieve(user_id="u1", query="where does the user live?")
print(result.context)
# "Lives in São Paulo, Married to Ana..."
```

Style this code block to look like a terminal window floating in the forest, maybe with a slight glow effect.

### 5. Key Features (grid or list)
- **Automatic fact extraction** — LLM-powered, zero manual tagging
- **3-phase entity resolution** — exact → fuzzy → LLM. "my wife Ana" and "Ana" resolve to the same entity
- **Knowledge reconciliation** — ADD, UPDATE, DELETE decisions. No duplicates, no stale data
- **Multi-signal retrieval** — semantic + keyword + graph + recency
- **Provider-agnostic** — bring your own LLM via Python protocols. OpenAI included
- **Built on PostgreSQL + pgvector** — battle-tested infrastructure, no exotic dependencies

### 6. Architecture Overview
A visual/animated diagram showing the full pipeline. Could be a flowing river metaphor — data flows like water through the forest:
- Write side: Message → Extract → Resolve → Reconcile → Upsert (into the "lake" of knowledge)
- Read side: Query → Plan → Retrieve → Rerank → Context (drawing from the "lake")

### 7. Open Source & Community
- "Arandu is MIT licensed and open source. Built in Brazil 🇧🇷"
- Links: GitHub, PyPI, Documentation
- GitHub stars badge, PyPI version badge

### 8. Footer
- "Made with 💚 in Brazil"
- Links: Documentation (https://pe-menezes.github.io/arandu/), GitHub (https://github.com/pe-menezes/arandu), PyPI (https://pypi.org/project/arandu/)
- Small Arandu logo/wordmark

## Animation Guidelines
- All animations should be **smooth, organic, and subtle** — like nature, not like a tech demo
- Use easing curves that feel natural (ease-in-out, not linear)
- Scroll-triggered animations for section reveals (fade up + slight slide)
- Parallax depth on the forest layers
- Birds flying across transitions should be triggered by scroll position
- The hero particles/fireflies should be continuous but very gentle
- Code block could have a typing animation on first view
- Keep performance in mind — prefer CSS animations over heavy JS where possible

## Tone of Voice
- Confident but not arrogant
- Technical but accessible
- Poetic touches are welcome (it's a product inspired by indigenous wisdom)
- Brazilian warmth — welcoming, not corporate

## Technical Notes
- Single page, responsive (mobile-first)
- Dark mode as the default (it's a forest at dawn/dusk)
- Smooth scroll between sections
- The site is a marketing/landing page — the actual documentation lives at https://pe-menezes.github.io/arandu/
