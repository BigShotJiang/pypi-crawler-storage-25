"""iFlytek (讯飞) TTS provider adapter — WebSocket-based."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
from openspeechapi.logging_config import logger
import urllib.parse
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import formatdate
from typing import Any

import httpx
import websockets

from openspeechapi.core.base import TTSProvider
from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class IflytekTTSSettings(BaseSettings):
    app_id: str = ""
    api_key: str = ""
    api_secret: str = ""
    voice: str = "xiaoyan"
    speed: int = 50

class IflytekTTS(TTSProvider):
    name = "iflytek-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = IflytekTTSSettings
    capabilities = {Capability.BATCH, Capability.STREAMING, Capability.MULTILINGUAL}
    field_options = {"voice": [
        "xiaoyan", "aisjiuxu", "aisxping", "aisjinger", "aisbabyxu",
        "x4_lingxiaolu_em", "x4_lingfeizhe_em", "xiaoyu", "xiaoqi",
        "xiaofeng", "xiaomei", "xiaolin", "xiaorong", "xiaoqian",
        "catherine", "john", "laura", "yuka", "xiaoqiukor",
    ]}

    _WS_HOST = "tts-api.xfyun.cn"
    _WS_PATH = "/v2/tts"

    def __init__(self, settings: IflytekTTSSettings | None = None) -> None:
        self.settings = settings or IflytekTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._owns_client = True

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None

    async def health_check(self) -> bool:
        return bool(self.settings.app_id) and bool(self.settings.api_key) and bool(self.settings.api_secret)

    def _build_auth_url(self) -> str:
        """Build HMAC-SHA256 signed WebSocket URL."""
        now = datetime.now(tz=timezone.utc)
        date = formatdate(timeval=now.timestamp(), localtime=False, usegmt=True)

        signature_origin = (
            f"host: {self._WS_HOST}\n"
            f"date: {date}\n"
            f"GET {self._WS_PATH} HTTP/1.1"
        )
        signature_sha = hmac.new(
            self.settings.api_secret.encode("utf-8"),
            signature_origin.encode("utf-8"),
            hashlib.sha256,
        ).digest()
        signature = base64.b64encode(signature_sha).decode("utf-8")

        authorization_origin = (
            f'api_key="{self.settings.api_key}", '
            f'algorithm="hmac-sha256", '
            f'headers="host date request-line", '
            f'signature="{signature}"'
        )
        authorization = base64.b64encode(
            authorization_origin.encode("utf-8")
        ).decode("utf-8")

        params = urllib.parse.urlencode(
            {"authorization": authorization, "date": date, "host": self._WS_HOST}
        )
        return f"wss://{self._WS_HOST}{self._WS_PATH}?{params}"

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        """Batch synthesize by collecting all stream chunks."""
        parts: list[bytes] = []
        async for chunk in self.synthesize_stream(text, opts):
            parts.append(chunk.data)
        audio_bytes = b"".join(parts)
        logger.info("iFlytek TTS: {} chunks, {} MP3 bytes total", len(parts), len(audio_bytes))
        return AudioData(
            data=audio_bytes,
            sample_rate=16000,
            channels=1,
            format="mp3",
        )

    # iFlytek voice catalog — vcn → (display name, language, group)
    _VOICES = [
        # 中文
        ("xiaoyan",           "小燕 — 中文女声",         "zh_cn", "中文"),
        ("aisjiuxu",          "许久 — 中文男声",         "zh_cn", "中文"),
        ("aisxping",          "小萍 — 中文女声",         "zh_cn", "中文"),
        ("aisjinger",         "小婧 — 中文女声",         "zh_cn", "中文"),
        ("aisbabyxu",         "许小宝 — 童声",           "zh_cn", "中文"),
        ("x4_lingxiaolu_em",  "凌小路 — 情感男声",       "zh_cn", "中文"),
        ("x4_lingfeizhe_em",  "凌飞哲 — 情感男声",       "zh_cn", "中文"),
        ("xiaoyu",            "小宇 — 中文男声",         "zh_cn", "中文"),
        ("xiaoqi",            "小琪 — 中文女声",         "zh_cn", "中文"),
        ("xiaofeng",          "小峰 — 中文男声",         "zh_cn", "中文"),
        ("xiaomei",           "小梅 — 粤语女声",         "zh_cn", "粤语"),
        ("xiaolin",           "小林 — 台湾女声",         "zh_cn", "中文"),
        ("xiaorong",          "小蓉 — 四川女声",         "zh_cn", "方言"),
        ("xiaoqian",          "小芊 — 东北女声",         "zh_cn", "方言"),
        # English
        ("catherine",         "Catherine — English Female", "en_us", "English"),
        ("john",              "John — English Male",        "en_us", "English"),
        ("laura",             "Laura — English Female",     "en_us", "English"),
        # Japanese
        ("yuka",              "Yuka — Japanese Female",     "ja_jp", "日本語"),
        # Korean
        ("xiaoqiukor",        "小秋 — Korean Female",       "ko_kr", "한국어"),
    ]

    def _build_ws_message(self, text: str, voice: str | None = None, speed: float | None = None) -> dict:
        """Build the WebSocket request message."""
        vcn = voice or self.settings.voice
        spd = int(speed * 50) if speed and speed != 1.0 else self.settings.speed
        text_b64 = base64.b64encode(text.encode("utf-8")).decode("utf-8")
        return {
            "common": {"app_id": self.settings.app_id},
            "business": {
                "aue": "lame",
                "sfl": 1,
                "vcn": vcn,
                "speed": spd,
                "tte": "UTF8",
            },
            "data": {
                "status": 2,
                "text": text_b64,
            },
        }

    async def list_voices(self) -> list[dict]:
        """Return available iFlytek voices."""
        return [
            {"name": vcn, "description": desc, "language": lang, "group": group}
            for vcn, desc, lang, group in self._VOICES
        ]

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        """Stream MP3 audio chunks as they arrive from iFlytek WebSocket."""
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        opts = opts or TTSOptions()

        voice = opts.voice or self.settings.voice
        speed = opts.speed if opts.speed != 1.0 else None
        logger.info("iFlytek stream: voice={}, speed={}, text={} chars", voice, speed, len(text))

        url = self._build_auth_url()
        msg = self._build_ws_message(text, voice=voice, speed=speed)
        seq = 0

        async with websockets.connect(url) as ws:
            await ws.send(json.dumps(msg))

            async for message in ws:
                resp = json.loads(message)
                code = resp.get("code", -1)
                if code != 0:
                    raise RuntimeError(
                        f"iFlytek TTS error [{code}]: {resp.get('message', 'unknown')}"
                    )

                data = resp.get("data", {})
                audio_b64 = data.get("audio", "")
                is_final = data.get("status") == 2

                if audio_b64:
                    chunk_bytes = base64.b64decode(audio_b64)
                    yield AudioChunk(data=chunk_bytes, sequence=seq, is_final=is_final)
                    seq += 1

                if is_final:
                    break
