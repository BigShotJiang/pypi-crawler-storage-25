"""Core data models — plain dataclasses for data transfer."""
from __future__ import annotations

from dataclasses import dataclass

from openspeechapi.core.enums import AudioFormat


@dataclass
class AudioData:
    data: bytes
    sample_rate: int
    channels: int
    format: AudioFormat
    duration_ms: int | None = None


@dataclass
class Word:
    text: str
    start_ms: int
    end_ms: int
    confidence: float | None = None


@dataclass
class Transcription:
    text: str
    language: str | None = None
    confidence: float | None = None
    words: list[Word] | None = None
    duration_ms: int | None = None
    is_partial: bool = False  # True for intermediate results from streaming STT


@dataclass
class AudioChunk:
    data: bytes
    sequence: int
    is_final: bool = False


@dataclass
class STTOptions:
    language: str | None = None
    prompt: str | None = None
    temperature: float | None = None
    model: str | None = None
    device: str | None = None
    beam_size: int | None = None
    compute_type: str | None = None
    fp16: bool | None = None


@dataclass
class TTSOptions:
    voice: str | None = None
    speed: float = 1.0
    output_format: AudioFormat = AudioFormat.PCM_16K
    model: str | None = None
    stream_transport: str | None = None
