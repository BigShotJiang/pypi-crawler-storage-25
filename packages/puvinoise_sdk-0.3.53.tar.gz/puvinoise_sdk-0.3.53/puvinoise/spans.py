"""
PUVINoise Custom Span System
============================
Provides @puvinoise.span() decorator and ``with puvinoise.span():`` context manager
for full and custom span observability.

Usage
-----
Decorator::

    @puvinoise.span("retrieval", kind=SpanKind.RETRIEVAL)
    def fetch_docs(query):
        ...

Context manager::

    with puvinoise.span("planning", attributes={"plan.step": 1}):
        ...

Both forms:
- Auto-generate span_id / parent_span_id via a thread-local stack
- Emit child OTel spans underneath the active agent.run root span
- Record attributes, status, errors
- Emit a ``puvinoise.span`` OTel event so the backend can reconstruct a span tree
"""

from __future__ import annotations

import contextlib
import enum
import functools
import inspect
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Generator, Optional

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

# ---------------------------------------------------------------------------
# SpanKind
# ---------------------------------------------------------------------------

class SpanKind(str, enum.Enum):
    """High-level semantic category for a PUVINoise span."""
    AGENT = "agent"
    LLM = "llm"
    TOOL = "tool"
    RETRIEVAL = "retrieval"
    CUSTOM = "custom"
    PLANNING = "planning"
    MEMORY = "memory"
    GUARDRAIL = "guardrail"


# ---------------------------------------------------------------------------
# SpanRecord — in-memory representation emitted before the OTel span ends
# ---------------------------------------------------------------------------

@dataclass
class SpanRecord:
    """Lightweight in-memory record of a single span, for logging / debugging."""
    span_id: str
    trace_id: str
    parent_span_id: Optional[str]
    name: str
    kind: SpanKind
    start_time: float  # epoch seconds
    end_time: Optional[float]
    attributes: dict[str, Any] = field(default_factory=dict)
    status: str = "ok"  # ok | error
    error_message: Optional[str] = None

    @property
    def duration_ms(self) -> Optional[float]:
        if self.end_time is not None:
            return round((self.end_time - self.start_time) * 1000, 2)
        return None

    def to_dict(self) -> dict:
        return {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "parent_span_id": self.parent_span_id,
            "name": self.name,
            "kind": self.kind.value if isinstance(self.kind, SpanKind) else str(self.kind),
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "attributes": self.attributes,
            "status": self.status,
            "error_message": self.error_message,
        }


# ---------------------------------------------------------------------------
# Thread-local span stack for parent-child correlation
# ---------------------------------------------------------------------------

_local = threading.local()


def _get_stack() -> list[str]:
    if not hasattr(_local, "span_stack"):
        _local.span_stack = []
    return _local.span_stack


def _current_parent_span_id() -> Optional[str]:
    stack = _get_stack()
    return stack[-1] if stack else None


def _push_span_id(span_id: str) -> None:
    _get_stack().append(span_id)


def _pop_span_id() -> Optional[str]:
    stack = _get_stack()
    return stack.pop() if stack else None


# ---------------------------------------------------------------------------
# OTel tracer
# ---------------------------------------------------------------------------

_tracer = trace.get_tracer("puvinoise.spans")

_MAX_ATTR_LEN = 2000


def _safe_str(v: Any, max_len: int = _MAX_ATTR_LEN) -> str:
    try:
        s = str(v)
    except Exception:
        s = "<unrepresentable>"
    return s[:max_len]


# ---------------------------------------------------------------------------
# Core span context manager
# ---------------------------------------------------------------------------

@contextlib.contextmanager
def _span_ctx(
    name: str,
    kind: SpanKind = SpanKind.CUSTOM,
    attributes: Optional[dict[str, Any]] = None,
) -> Generator[SpanRecord, None, None]:
    """
    Internal context manager that creates a child OTel span and a SpanRecord.

    Yields the SpanRecord so callers can attach attributes dynamically.
    """
    span_id = uuid.uuid4().hex[:16]
    parent_span_id = _current_parent_span_id()

    # Derive trace_id from active OTel context, fall back to a generated one
    active_otel = trace.get_current_span()
    try:
        sc = active_otel.get_span_context()
        trace_id = f"{sc.trace_id:032x}" if sc and sc.trace_id else f"trace-{uuid.uuid4().hex}"
    except Exception:
        trace_id = f"trace-{uuid.uuid4().hex}"

    record = SpanRecord(
        span_id=span_id,
        trace_id=trace_id,
        parent_span_id=parent_span_id,
        name=name,
        kind=kind,
        start_time=time.time(),
        end_time=None,
        attributes=dict(attributes or {}),
    )

    _push_span_id(span_id)

    # Build OTel child span
    otel_span_name = f"custom.{name}" if kind == SpanKind.CUSTOM else f"{kind.value}.{name}"
    with _tracer.start_as_current_span(otel_span_name) as otel_span:
        # Attach standard attributes
        otel_span.set_attribute("puvinoise.span.id", span_id)
        otel_span.set_attribute("puvinoise.span.kind", kind.value if isinstance(kind, SpanKind) else str(kind))
        otel_span.set_attribute("puvinoise.span.name", name)
        if parent_span_id:
            otel_span.set_attribute("puvinoise.span.parent_id", parent_span_id)
        otel_span.set_attribute("puvinoise.trace.id", trace_id)

        # Attach caller-provided attributes
        if attributes:
            for k, v in attributes.items():
                try:
                    if isinstance(v, bool):
                        otel_span.set_attribute(k, v)
                    elif isinstance(v, (int, float)):
                        otel_span.set_attribute(k, v)
                    else:
                        otel_span.set_attribute(k, _safe_str(v))
                except Exception:
                    pass

        error_occurred = False
        try:
            yield record

            # Update attributes set during execution back onto OTel span
            for k, v in record.attributes.items():
                try:
                    if isinstance(v, bool):
                        otel_span.set_attribute(k, v)
                    elif isinstance(v, (int, float)):
                        otel_span.set_attribute(k, v)
                    else:
                        otel_span.set_attribute(k, _safe_str(v))
                except Exception:
                    pass

            record.end_time = time.time()
            record.status = "ok"
            otel_span.set_status(Status(StatusCode.OK))
            otel_span.set_attribute("puvinoise.span.duration_ms", record.duration_ms or 0)

        except Exception as exc:
            error_occurred = True
            record.end_time = time.time()
            record.status = "error"
            record.error_message = str(exc)[:500]
            otel_span.set_status(Status(StatusCode.ERROR, str(exc)))
            otel_span.record_exception(exc)
            otel_span.set_attribute("puvinoise.span.error", str(exc)[:500])
            otel_span.set_attribute("puvinoise.span.duration_ms", record.duration_ms or 0)
            raise

        finally:
            _pop_span_id()

            # Emit structured span event so backend can reconstruct tree without OTel collector
            try:
                otel_span.add_event(
                    "puvinoise.span.record",
                    {
                        "span.id": span_id,
                        "span.parent_id": parent_span_id or "",
                        "span.name": name,
                        "span.kind": kind.value if isinstance(kind, SpanKind) else str(kind),
                        "span.status": "error" if error_occurred else "ok",
                        "span.duration_ms": str(record.duration_ms or 0),
                        "span.trace_id": trace_id,
                    },
                )
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Public span() — decorator OR context manager
# ---------------------------------------------------------------------------

class _SpanFactory:
    """
    Returned by ``puvinoise.span(name)``.

    Works as both a context manager::

        with puvinoise.span("planning", kind=SpanKind.PLANNING) as s:
            s.attributes["plan.steps"] = 3

    And as a decorator::

        @puvinoise.span("retrieval")
        def fetch(query):
            ...

    Async functions and generators are also supported.
    """

    def __init__(
        self,
        name: str,
        kind: SpanKind = SpanKind.CUSTOM,
        attributes: Optional[dict[str, Any]] = None,
    ):
        self._name = name
        self._kind = kind
        self._attributes = attributes or {}
        self._ctx: Optional[contextlib.AbstractContextManager] = None
        self._record: Optional[SpanRecord] = None

    # ------------------------------------------------------------------
    # Context manager protocol
    # ------------------------------------------------------------------

    def __enter__(self) -> SpanRecord:
        self._ctx = _span_ctx(self._name, self._kind, self._attributes)
        self._record = self._ctx.__enter__()
        return self._record

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._ctx is not None:
            return self._ctx.__exit__(exc_type, exc_val, exc_tb)

    # ------------------------------------------------------------------
    # Decorator protocol
    # ------------------------------------------------------------------

    def __call__(self, func: Callable) -> Callable:
        """Use as @puvinoise.span("name") decorator."""
        if inspect.iscoroutinefunction(func):
            return self._wrap_async(func)
        if inspect.isgeneratorfunction(func):
            return self._wrap_gen(func)
        return self._wrap_sync(func)

    def _wrap_sync(self, func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with _span_ctx(self._name, self._kind, dict(self._attributes)) as record:
                record.attributes.setdefault("function", func.__qualname__)
                return func(*args, **kwargs)
        return wrapper

    def _wrap_async(self, func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            with _span_ctx(self._name, self._kind, dict(self._attributes)) as record:
                record.attributes.setdefault("function", func.__qualname__)
                return await func(*args, **kwargs)
        return wrapper

    def _wrap_gen(self, func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with _span_ctx(self._name, self._kind, dict(self._attributes)) as record:
                record.attributes.setdefault("function", func.__qualname__)
                yield from func(*args, **kwargs)
        return wrapper


def span(
    name: str,
    kind: SpanKind = SpanKind.CUSTOM,
    attributes: Optional[dict[str, Any]] = None,
) -> _SpanFactory:
    """
    Create a PUVINoise custom span.

    As a context manager::

        with puvinoise.span("retrieval", kind=puvinoise.SpanKind.RETRIEVAL) as s:
            docs = vector_search(query)
            s.attributes["retrieval.count"] = len(docs)

    As a decorator::

        @puvinoise.span("call_llm", kind=puvinoise.SpanKind.LLM)
        def call_llm(prompt):
            return client.chat(prompt)

    Args:
        name: Human-readable span name (shown in Session Replay waterfall, Flight Recorder).
        kind: Semantic kind — SpanKind.CUSTOM (default), LLM, TOOL, RETRIEVAL, PLANNING, etc.
        attributes: Optional dict of initial span attributes.

    Returns:
        _SpanFactory — usable as a context manager or decorator.
    """
    return _SpanFactory(name, kind, attributes)


# ---------------------------------------------------------------------------
# Tool-call child span helpers (used by hooks.py)
# ---------------------------------------------------------------------------

def emit_tool_call_spans(tool_calls: list[dict], parent_run_span=None) -> None:
    """
    Emit child OTel spans for each tool call block extracted from an LLM response.

    Called automatically by instrument_openai_call / instrument_anthropic_call
    when the response contains tool_calls or tool_use blocks.

    Args:
        tool_calls: List of normalised dicts with keys:
            - name (str): tool function name
            - input (dict | str): arguments
            - call_id (str | None): provider-assigned ID
        parent_run_span: Optional OTel span to use as parent (defaults to current active span).
    """
    if not tool_calls:
        return

    active = parent_run_span or trace.get_current_span()
    tracer = trace.get_tracer("puvinoise.tool_calls")

    for tc in tool_calls:
        tool_name = tc.get("name") or "unknown_tool"
        call_id = tc.get("call_id") or uuid.uuid4().hex[:8]
        args = tc.get("input") or tc.get("arguments") or {}

        span_name = f"tool.{tool_name}"
        try:
            child_span = tracer.start_span(
                span_name,
                context=trace.set_span_in_context(active),
            )
            child_span.set_attribute("tool.name", tool_name)
            child_span.set_attribute("tool.call_id", str(call_id))
            child_span.set_attribute("tool.kind", "llm_requested")
            child_span.set_attribute("puvinoise.span.kind", SpanKind.TOOL.value)
            if isinstance(args, dict):
                import json as _json
                try:
                    child_span.set_attribute("tool.input", _json.dumps(args, default=str)[:1000])
                except Exception:
                    child_span.set_attribute("tool.input", str(args)[:1000])
            else:
                child_span.set_attribute("tool.input", str(args)[:1000])

            # Mark as instantaneous (the actual execution may happen later in the agent loop)
            child_span.set_status(Status(StatusCode.OK))
            child_span.add_event(
                "puvinoise.span.record",
                {
                    "span.name": tool_name,
                    "span.kind": SpanKind.TOOL.value,
                    "span.status": "ok",
                    "tool.call_id": str(call_id),
                },
            )
        except Exception:
            continue
        finally:
            try:
                child_span.end()
            except Exception:
                pass
