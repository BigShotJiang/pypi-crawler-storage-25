"""
HTTP helpers for tenant-scoped CLI commands (create, attach, list).

Uses JWT from PUVINOISE_BEARER_TOKEN or --bearer. These endpoints mirror the
product UI; they are separate from agent runtime auth (API keys).
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import quote
from typing import Any, Dict, List, Optional, Tuple

from puvinoise.agent_state import load_agent_state, load_env_state


class TenantApiError(RuntimeError):
    """HTTP error from tenant API with parsed JSON body when available."""

    def __init__(self, message: str, *, status: int, payload: Any = None):
        super().__init__(message)
        self.status = status
        self.payload = payload if isinstance(payload, dict) else None


def load_binding(workdir: Path) -> Tuple[str, str, str, str]:
    """
    Return (base_url, env_id, env_name, tenant_id) from ``.puvinoise/`` JSON files.

    Resolution order (mirrors SDK identity model):
      1. ``.puvinoise/agent_*.json`` — full identity (wins if present)
      2. ``.puvinoise/env.json``     — bootstrap-only fallback

    Raises ``ValueError`` with an actionable message if binding is missing or
    required fields are absent.
    """
    resolved = workdir.resolve()

    # Try agent_*.json first — has api_key + tenant_id already set.
    agent_data, agent_path = load_agent_state(resolved)
    if agent_data:
        base = str(agent_data.get("base_url") or "").strip().rstrip("/")
        eid = str(agent_data.get("env_id") or "").strip()
        ename = str(agent_data.get("agent_name") or "").strip()
        tid = str(agent_data.get("tenant_id") or "").strip()
        if base and eid:
            return base, eid, ename, tid

    # Fall back to env.json (written immediately after bindcar, before registration).
    env_data, env_path = load_env_state(resolved)
    if env_data:
        base = str(env_data.get("base_url") or "").strip().rstrip("/")
        eid = str(env_data.get("env_id") or "").strip()
        ename = (
            str(env_data.get("env_name") or "").strip()
            or str(env_data.get("environment") or "").strip()
        )
        tid = str(env_data.get("tenant_id") or "").strip()
        if base and eid:
            return base, eid, ename, tid
        raise ValueError(
            f"{env_path} is missing base_url or env_id.\n"
            "  Re-run: puvinoise bindcar --token <prt_...>"
        )

    raise ValueError(
        "No environment binding for this folder.\n"
        "  Expected: .puvinoise/env.json (written by `puvinoise bindcar --token <prt_...>`)\n"
        "  Run: puvinoise bindcar --token <prt_...>\n"
        "  (set PUVINOISE_BASE_URL or use bindcar --base-url if needed)"
    )


def resolve_bearer(explicit: Optional[str] = None) -> str:
    """Bearer JWT from argument or PUVINOISE_BEARER_TOKEN."""
    t = (explicit or os.environ.get("PUVINOISE_BEARER_TOKEN", "") or "").strip()
    if not t:
        raise ValueError(
            "Tenant JWT is required for this command.\n"
            "  Export PUVINOISE_BEARER_TOKEN from your browser session (same token as the UI),\n"
            "  or pass --bearer <jwt>."
        )
    return t


def _request_json(
    method: str,
    url: str,
    *,
    bearer: Optional[str] = None,
    body: Optional[Dict[str, Any]] = None,
    timeout: float = 60.0,
) -> Tuple[int, Any]:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            status = int(getattr(resp, "status", 200) or 200)
            if not raw:
                return status, {}
            return status, json.loads(raw)
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8")
            payload = json.loads(detail) if detail else {}
        except Exception:
            payload = {"error": str(e)}
        err = (payload.get("error") if isinstance(payload, dict) else None) or str(e)
        raise TenantApiError(
            f"HTTP {e.code}: {err}",
            status=int(e.code),
            payload=payload if isinstance(payload, dict) else None,
        ) from e


def api_list_agents(
    base_url: str,
    bearer: str,
    *,
    tag_filters: Optional[List[Tuple[str, str]]] = None,
    search: Optional[str] = None,
) -> List[Dict[str, Any]]:
    qs: List[str] = []
    if search and str(search).strip():
        qs.append(f"search={quote(str(search).strip())}")
    if tag_filters:
        for k, v in tag_filters:
            k0, v0 = str(k).strip(), str(v).strip()
            if k0 and v0:
                qs.append(f"tag={quote(f'{k0}={v0}')}")
    suffix = ("?" + "&".join(qs)) if qs else ""
    status, data = _request_json("GET", f"{base_url}/api/agents{suffix}", bearer=bearer)
    if status >= 400:
        raise RuntimeError(f"List agents failed: {data}")
    agents = data.get("agents") if isinstance(data, dict) else None
    if not isinstance(agents, list):
        return []
    return agents


def api_get_agent(base_url: str, bearer: str, agent_id: str) -> Dict[str, Any]:
    aid = quote(agent_id.strip(), safe="")
    status, data = _request_json("GET", f"{base_url}/api/agents/{aid}", bearer=bearer)
    if status >= 400 or not isinstance(data, dict):
        raise RuntimeError(f"Get agent failed: {data}")
    agent = data.get("agent")
    if not isinstance(agent, dict):
        raise RuntimeError("Get agent: missing agent object")
    return agent


def api_create_agent(
    base_url: str,
    bearer: str,
    name: str,
    *,
    tags: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"name": name.strip()}
    if tags:
        body["tags"] = tags
    try:
        status, data = _request_json(
            "POST",
            f"{base_url}/api/agents",
            bearer=bearer,
            body=body,
        )
    except TenantApiError:
        raise
    if status >= 400 or not isinstance(data, dict):
        raise RuntimeError(f"Create agent failed: {data}")
    agent = data.get("agent")
    if not isinstance(agent, dict) or not agent.get("agent_id"):
        raise RuntimeError("Create agent: invalid response")
    return agent


def api_patch_agent(
    base_url: str,
    bearer: str,
    agent_key: str,
    *,
    environment_id: Optional[str] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {}
    if environment_id is not None:
        body["environmentId"] = environment_id
    key = quote(agent_key.strip(), safe="")
    status, data = _request_json(
        "PATCH",
        f"{base_url}/api/agents/{key}",
        bearer=bearer,
        body=body,
    )
    if status >= 400 or not isinstance(data, dict):
        raise RuntimeError(f"Update agent failed: {data}")
    agent = data.get("agent")
    if not isinstance(agent, dict):
        raise RuntimeError("Update agent: invalid response")
    return agent


def api_auto_register(base_url: str, env_id: str, agent_name: str) -> Dict[str, Any]:
    """Open registration (bootstrapped env gate on server). No JWT."""
    status, data = _request_json(
        "POST",
        f"{base_url.rstrip('/')}/api/auto-register",
        bearer=None,
        body={"env_id": env_id.strip(), "agent_name": agent_name.strip()},
    )
    if status >= 400 or not isinstance(data, dict):
        raise RuntimeError(f"Auto-register failed: {data}")
    if not data.get("api_key") or not data.get("agent_id"):
        raise RuntimeError("Auto-register: incomplete response (api_key / agent_id)")
    return data
