"""
SDK-native control plane loop (no sidecar): polls GET /api/agents/{agent_id}/control-queue
and executes commands via AgentControlWorker (PATCH /api/agent-control/:id/complete).

POST /api/agents/{agent_id}/control-ack is used only when a command cannot be dispatched
(e.g. missing command_id or unsupported type) so the queue can advance.

Runs in a daemon thread; failures are logged and never crash the agent process.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from puvinoise.env_keys import get_agent_id, get_api_key, get_base_url

logger = logging.getLogger(__name__)

# ─── Delegation to AgentControlWorker (full handlers + PATCH /complete) ───────

_delegating_worker: Optional["AgentControlWorker"] = None


def _ensure_dispatch_worker(base_url: str, agent_id: str, api_key: str) -> "AgentControlWorker":
    """
    Single worker instance used only for dispatch_agent_command (no poll thread).
    Mirrors GET /api/agents/:id/control-queue execution with AgentControlWorker semantics.
    """
    global _delegating_worker
    if _delegating_worker is not None:
        return _delegating_worker
    from puvinoise.agent_runtime.agent_control_worker import AgentControlWorker

    _delegating_worker = AgentControlWorker(
        agent_id=agent_id.strip(),
        base_url=base_url.rstrip("/"),
        poll_interval_seconds=10.0,
        api_key=api_key or None,
    )
    return _delegating_worker


# ─── Lifecycle (STEP 7) ───────────────────────────────────────────────────────


class ControlLifecycleState(str, Enum):
    ACTIVE = "ACTIVE"
    DEGRADED = "DEGRADED"
    STOPPED = "STOPPED"


@dataclass
class ControlLoopRuntime:
    """In-process control state (thread-safe)."""

    agent_paused: bool = False
    lifecycle: ControlLifecycleState = ControlLifecycleState.ACTIVE
    config: Dict[str, Any] = field(default_factory=dict)
    _pause_event: threading.Event = field(default_factory=threading.Event)
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def __post_init__(self) -> None:
        self._pause_event.set()  # not paused → event set means "may proceed"

    def set_paused(self, paused: bool) -> None:
        with self._lock:
            self.agent_paused = paused
            if paused:
                self.lifecycle = ControlLifecycleState.DEGRADED
                self._pause_event.clear()
            else:
                self.lifecycle = ControlLifecycleState.ACTIVE
                self._pause_event.set()

    def set_stopped(self) -> None:
        with self._lock:
            self.lifecycle = ControlLifecycleState.STOPPED

    def wait_if_paused(self, timeout: Optional[float] = None) -> bool:
        """Block while paused. Returns True if unpaused, False on timeout."""
        return self._pause_event.wait(timeout=timeout)

    def merge_config(self, payload: Optional[Dict[str, Any]]) -> None:
        if not payload or not isinstance(payload, dict):
            return
        with self._lock:
            self.config.update(payload)


_runtime = ControlLoopRuntime()

_control_thread: Optional[threading.Thread] = None
_control_stop = threading.Event()
_started_lock = threading.Lock()


def _sync_runtime_from_worker() -> None:
    """Keep ControlLoopRuntime in sync for is_agent_paused / get_control_lifecycle_state."""
    w = _delegating_worker
    if w is None:
        return
    try:
        with _runtime._lock:
            _runtime.agent_paused = w.is_paused()
            if w.is_stopped():
                _runtime.lifecycle = ControlLifecycleState.STOPPED
            elif w.is_paused():
                _runtime.lifecycle = ControlLifecycleState.DEGRADED
            else:
                _runtime.lifecycle = ControlLifecycleState.ACTIVE
            if w.is_paused():
                _runtime._pause_event.clear()
            else:
                _runtime._pause_event.set()
    except Exception:
        pass


def _supported_control_types() -> frozenset:
    from puvinoise.agent_runtime.agent_control_worker import VALID_COMMANDS

    return frozenset(str(x).strip().lower() for x in VALID_COMMANDS)


def get_control_lifecycle_state() -> str:
    w = _delegating_worker
    if w is not None:
        if w.is_stopped():
            return ControlLifecycleState.STOPPED.value
        if w.is_paused():
            return ControlLifecycleState.DEGRADED.value
        return ControlLifecycleState.ACTIVE.value
    return _runtime.lifecycle.value


def is_agent_paused() -> bool:
    w = _delegating_worker
    if w is not None:
        return w.is_paused()
    return _runtime.agent_paused


def get_runtime_config_snapshot() -> Dict[str, Any]:
    with _runtime._lock:
        return dict(_runtime.config)


def wait_if_control_paused(timeout: Optional[float] = None) -> bool:
    """Block while the control plane has paused the agent (STEP 3)."""
    return _runtime.wait_if_paused(timeout=timeout)


def check_allowed_to_run() -> bool:
    """Returns False when paused (caller should skip new work)."""
    w = _delegating_worker
    if w is not None:
        return not w.is_stopped() and not w.is_paused()
    if _runtime.lifecycle == ControlLifecycleState.STOPPED:
        return False
    return not _runtime.agent_paused


# ─── HTTP ─────────────────────────────────────────────────────────────────────


def _normalize_base(url: str) -> str:
    u = (url or "").strip().rstrip("/")
    if u.lower().endswith("/api"):
        u = u[: -len("/api")].rstrip("/")
    return u


def _fetch_queue(base: str, agent_id: str, api_key: str) -> List[Dict[str, Any]]:
    url = f"{_normalize_base(base)}/api/agents/{urllib.parse.quote(agent_id, safe='')}/control-queue"
    req = urllib.request.Request(url, method="GET")
    req.add_header("Accept", "application/json")
    if api_key:
        req.add_header("Authorization", f"Bearer {api_key}")
        req.add_header("x-api-key", api_key)
    with urllib.request.urlopen(req, timeout=15) as resp:
        body = resp.read().decode("utf-8", errors="replace")
    data = json.loads(body) if body.strip() else {}
    cmds = data.get("commands")
    if not isinstance(cmds, list):
        return []
    return [c for c in cmds if isinstance(c, dict)]


def _post_ack(
    base: str,
    agent_id: str,
    api_key: str,
    command_id: str,
    status: str,
    error: Optional[str],
) -> None:
    url = f"{_normalize_base(base)}/api/agents/{urllib.parse.quote(agent_id, safe='')}/control-ack"
    payload = {
        "command_id": command_id,
        "status": status,
        **({"error": error} if error else {}),
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if api_key:
        req.add_header("Authorization", f"Bearer {api_key}")
        req.add_header("x-api-key", api_key)
    with urllib.request.urlopen(req, timeout=15) as resp:
        if resp.status >= 400:
            raise urllib.error.HTTPError(url, resp.status, resp.reason, resp.headers, None)


def _execute_command(
    cmd: Dict[str, Any],
    *,
    base_url: str,
    agent_id: str,
    api_key: str,
) -> tuple[str, Optional[str]]:
    """
    Dispatch one queue item through AgentControlWorker (telemetry + PATCH /complete).
    Returns (completed, None) on success; (failed, err) only when dispatch cannot run
    (missing id / unsupported) — caller may POST control-ack for failed.
    """
    cmd_id = str(cmd.get("command_id") or "").strip()
    typ = str(cmd.get("type") or cmd.get("command") or "").strip().lower()
    payload = cmd.get("payload") if isinstance(cmd.get("payload"), dict) else {}
    ts = cmd.get("timestamp")
    ver = cmd.get("version")
    if not cmd_id:
        return "failed", "missing command_id"
    supported = _supported_control_types()
    if typ not in supported:
        return "failed", f"unsupported type: {typ}"

    from puvinoise.agent_runtime.agent_control_worker import ControlCommand

    cc = ControlCommand(
        command=typ,
        command_id=cmd_id,
        timestamp=str(ts) if ts is not None else None,
        version=str(ver).strip() if ver is not None and str(ver).strip() else None,
        payload=payload if payload else None,
    )
    logger.info("control_loop: received queue item type=%s command_id=%s", typ, cmd_id)
    try:
        w = _ensure_dispatch_worker(base_url, agent_id, api_key)
        w.dispatch_agent_command(cc)
    except Exception as exc:
        logger.exception("control_loop: dispatch failed for %s: %s", typ, exc)
        return "failed", str(exc)[:2000]
    _sync_runtime_from_worker()
    logger.info(
        "control_loop: executed command type=%s command_id=%s (completion via PATCH /api/agent-control/.../complete)",
        typ,
        cmd_id,
    )
    return "completed", None


def _loop_body(
    base_url: str,
    agent_id: str,
    api_key: str,
) -> None:
    try:
        raw_cmds = _fetch_queue(base_url, agent_id, api_key)
    except Exception as exc:
        logger.debug("control_loop: fetch queue failed (non-fatal): %s", exc)
        return

    for cmd in raw_cmds:
        if _control_stop.is_set():
            break
        status, err = _execute_command(cmd, base_url=base_url, agent_id=agent_id, api_key=api_key)
        cid = str(cmd.get("command_id") or "").strip()
        if status != "failed" or not cid:
            continue
        try:
            _post_ack(base_url, agent_id, api_key, cid, status, err)
        except Exception as exc:
            logger.warning("control_loop: ack failed for %s: %s", cid, exc)


def _run_loop(base_url: str, agent_id: str, env_id: str, interval_sec: float) -> None:
    api_key = (get_api_key() or "").strip()
    if env_id and not os.environ.get("PUVINOISE_ENV_ID"):
        os.environ["PUVINOISE_ENV_ID"] = env_id
    while not _control_stop.wait(timeout=max(0.5, interval_sec)):
        try:
            _loop_body(base_url, agent_id, api_key)
        except Exception as exc:
            logger.exception("control_loop: tick failed (continuing): %s", exc)


def start_control_loop(
    agent_id: Optional[str] = None,
    env_id: Optional[str] = None,
    *,
    interval_seconds: float = 10.0,
    platform_url: Optional[str] = None,
) -> bool:
    """
    Start a daemon thread that polls the control queue and executes commands.

    Idempotent: a second call while the loop is running returns True without starting another thread.

    Args:
        agent_id: Defaults to PUVINOISE_AGENT_ID.
        env_id: Optional PUVINOISE_ENV_ID (stored in env if missing).
        interval_seconds: Poll interval (default 10s).
        platform_url: Defaults to PUVINOISE_BASE_URL.
    """
    global _control_thread

    with _started_lock:
        if _control_thread is not None and _control_thread.is_alive():
            logger.debug("control_loop: already running")
            return True

    base = (platform_url or get_base_url() or "").strip()
    aid = (agent_id or get_agent_id() or "").strip()
    eid = (env_id or os.environ.get("PUVINOISE_ENV_ID") or "").strip()
    key = (get_api_key() or "").strip()

    if not base or not aid or not key:
        logger.info(
            "control_loop: not started — missing platform_url, agent_id, or api key",
        )
        return False

    _control_stop.clear()
    interval = max(2.0, float(interval_seconds))

    _ensure_dispatch_worker(base, aid, key)

    def _target() -> None:
        try:
            _run_loop(base, aid, eid, interval)
        except Exception as exc:
            logger.exception("control_loop: thread died: %s", exc)

    t = threading.Thread(
        target=_target,
        name="puvinoise-control-loop",
        daemon=True,
    )
    with _started_lock:
        t.start()
        _control_thread = t

    logger.info(
        "control_loop: started (interval=%.1fs, agent_id=%s)",
        interval,
        aid,
    )
    return True


def stop_control_loop() -> None:
    """Signal the control loop thread to exit (used by shutdown)."""
    global _delegating_worker
    _control_stop.set()
    _delegating_worker = None


def control_loop_started() -> bool:
    return _control_thread is not None and _control_thread.is_alive()


def sdk_control_loop_enabled() -> bool:
    """Default ON; set PUVINOISE_SDK_CONTROL_LOOP=0 to disable and use legacy AgentControlWorker."""
    v = os.environ.get("PUVINOISE_SDK_CONTROL_LOOP", "1").strip().lower()
    return v not in ("0", "false", "no", "off")


__all__ = [
    "ControlLifecycleState",
    "start_control_loop",
    "stop_control_loop",
    "control_loop_started",
    "sdk_control_loop_enabled",
    "get_control_lifecycle_state",
    "is_agent_paused",
    "get_runtime_config_snapshot",
    "wait_if_control_paused",
    "check_allowed_to_run",
]
