"""
High-level agent observability decorator.

@observe_agent wraps a customer function so it is observable without changing
business logic. It creates/uses TraceContext, runs inside run_with_trace, and
injects ctx only when the function supports it.
"""

from __future__ import annotations

import functools
import inspect
import os
from typing import Any, Callable, Optional

from opentelemetry import trace

from puvinoise.tracer import run_with_trace, start_trace
from puvinoise.trace_context import TraceContext


_MAX_ATTR_LEN = 4000


def _safe_repr(value: Any, max_len: int = _MAX_ATTR_LEN) -> str:
    try:
        text = repr(value)
    except Exception:
        text = f"<unreprable:{type(value).__name__}>"
    return text[:max_len]


def _extract_session_id(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str:
    # Prefer explicit caller-provided session id.
    if "session_id" in kwargs and kwargs["session_id"] is not None:
        return str(kwargs["session_id"])
    # Reuse explicit ctx when provided.
    maybe_ctx = kwargs.get("ctx")
    if isinstance(maybe_ctx, TraceContext):
        return str(maybe_ctx.session_id)
    # Optional environment default.
    env_sid = (os.getenv("PUVINOISE_SESSION_ID") or "").strip()
    if env_sid:
        return env_sid
    # Deterministic fallback.
    return "default-session"


def observe_agent(func: Optional[Callable[..., Any]] = None, *, session_id: Optional[str] = None):
    """
    Decorator for observable customer agent entrypoints.

    Behavior:
    - creates ctx via start_trace() unless caller already provides ctx
    - wraps execution with run_with_trace(ctx=ctx, session_id=ctx.session_id)
    - injects ctx only if wrapped function accepts `ctx`
    - records function args, output, and errors on active span
    """

    def _decorate(inner: Callable[..., Any]) -> Callable[..., Any]:
        sig = inspect.signature(inner)
        accepts_ctx = "ctx" in sig.parameters

        @functools.wraps(inner)
        def _wrapped(*args, **kwargs):
            explicit_ctx = kwargs.get("ctx")
            if isinstance(explicit_ctx, TraceContext):
                ctx = explicit_ctx
            else:
                sid = session_id or _extract_session_id(args, kwargs)
                ctx = start_trace(session_id=sid)

            # Keep kwargs for inner function behavior; only add ctx when accepted.
            kwargs_for_inner = dict(kwargs)
            if accepts_ctx:
                kwargs_for_inner["ctx"] = ctx
            else:
                kwargs_for_inner.pop("ctx", None)

            def _invoke():
                span = trace.get_current_span()
                if span and span.is_recording():
                    span.set_attribute("trace.id", str(ctx.trace_id))
                    span.set_attribute("session.id", str(ctx.session_id))
                    span.set_attribute("agent.observe.args", _safe_repr(args))
                    span.set_attribute("agent.observe.kwargs", _safe_repr(kwargs_for_inner))
                try:
                    result = inner(*args, **kwargs_for_inner)
                    if span and span.is_recording():
                        span.set_attribute("agent.observe.output", _safe_repr(result))
                    return result
                except Exception as exc:
                    if span and span.is_recording():
                        span.set_attribute("agent.observe.error", _safe_repr(exc))
                    raise

            return run_with_trace(
                _invoke,
                ctx=ctx,
                session_id=ctx.session_id,
            )

        return _wrapped

    if func is None:
        return _decorate
    return _decorate(func)

