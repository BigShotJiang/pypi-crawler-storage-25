"""
Multi-provider instrumentation hooks for puvinoise SDK.
Supports Anthropic, OpenAI, Ollama, and generic LLM providers.
"""

import os
import re as _re
import os as _os
import json
import time

from opentelemetry import trace
from puvinoise.env_keys import get_agent_id

_SCRUB_ENABLED = _os.environ.get('PUVINOISE_SCRUB_LLM_CONTENT', 'true').lower() != 'false'
_LLM_PII_PATS = [
    _re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'),
    _re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
    _re.compile(r'\b(?:\d{4}[\s-]?){3}\d{4}\b'),
    _re.compile(r'\b(Mr|Mrs|Ms|Dr)\s+[A-Z][a-z]+\b'),
    _re.compile(r'\bBearer\s+[A-Za-z0-9\-._~+\/]{20,}'),
]


def _scrub(text, max_len=500):
    if not _SCRUB_ENABLED or not isinstance(text, str):
        return text[:max_len] if isinstance(text, str) else text
    for p in _LLM_PII_PATS:
        text = p.sub('[REDACTED]', text)
    return text[:max_len]
from opentelemetry.trace import Status, StatusCode
from puvinoise.context import AgentContext
import functools
from puvinoise.trace_context import TraceContext
from puvinoise.tracer import record_context

_tracer = trace.get_tracer("agent.hooks")
_AUTO_INSTRUMENT_DONE = False


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _infer_logical_agent_name(span) -> str:
    """
    Heuristically derive a ``logical.agent.name`` from the span's own name when
    no explicit value is set via ``AgentContext.logical_agent()``.

    Priority:
      1. ``tool.<name>``           → ``"tool:<name>"``
      2. ``llm.<provider>[.stream]`` → ``"llm:<provider>"``
      3. ``memory.<op>``           → ``"fn:memory_<op>"``
      4. ``workflow.<step>`` / ``chain.<step>`` / ``step.<step>``
                                   → ``"workflow:<step>"``
      5. Any other named span      → ``"fn:<span_name>"``
      6. Unnamed / empty           → ``"default"``

    The result is normalised to lower-case with no spaces so it is safe to use
    as a grouping key in the UI.
    """
    try:
        raw_name: str = (getattr(span, "name", "") or "").strip().lower()
    except Exception:
        raw_name = ""

    if not raw_name:
        return "default"

    # Priority 1 — tool call
    if raw_name.startswith("tool."):
        tool = raw_name[5:].strip() or "unknown"
        return f"tool:{tool}"

    # Priority 2 — LLM / model call
    if raw_name.startswith("llm."):
        parts = raw_name.split(".")
        provider = parts[1] if len(parts) > 1 else "unknown"
        # Collapse "llm.anthropic.stream" → provider = "anthropic"
        return f"llm:{provider}"

    # Priority 3 — memory operation
    if raw_name.startswith("memory."):
        op = raw_name[7:].strip() or "unknown"
        return f"fn:memory_{op}"

    # Priority 4 — explicit workflow / chain / step prefix
    for prefix in ("workflow.", "chain.", "step."):
        if raw_name.startswith(prefix):
            step = raw_name[len(prefix):].strip() or "unknown"
            return f"workflow:{step}"

    # Priority 5 — any other named span (agent.run, custom spans, etc.)
    safe = raw_name.replace(" ", "_")[:64]
    return f"fn:{safe}"


def _attach_agent_context(span):
    """
    Attach process-level agent identity, run/session IDs, and logical agent name
    to the given OTel span.

    Attributes written:
      agent.run_id           — current run UUID
      agent.name             — process-level PUVINOISE_AGENT_NAME (if set)
      agent.id               — resolved PUVINOISE_AGENT_ID
      agent.goal             — goal string (if set via AgentContext)
      agent.task_type / .task — task classification (if set)
      agent.intent           — intent classification (if set)
      logical.agent.name     — logical agent identity for this execution step:
                               * explicit value from AgentContext.logical_agent() / set_logical_agent_name()
                               * auto-inferred from span name when no explicit value is set
                               * always present — falls back to "default"
    """
    run_id = AgentContext.get_run_id()
    agent_name = AgentContext.get_agent_name()
    raw_id = (get_agent_id() or "").strip()
    agent_id = raw_id if raw_id else "unresolved"

    if run_id:
        span.set_attribute("agent.run_id", run_id)
    if agent_name:
        span.set_attribute("agent.name", agent_name)
    span.set_attribute("agent.id", agent_id)

    goal = AgentContext.get_goal()
    if goal:
        span.set_attribute("agent.goal", str(goal)[:500])
    task_type = AgentContext.get_task_type()
    if task_type:
        span.set_attribute("agent.task_type", str(task_type)[:200])
        span.set_attribute("agent.task", str(task_type)[:200])
    intent = AgentContext.get_intent()
    if intent:
        span.set_attribute("agent.intent", str(intent)[:200])

    # ── Logical agent name ────────────────────────────────────────────────────
    # Explicit value (set via AgentContext.logical_agent() or set_logical_agent_name())
    # takes absolute priority. Auto-detection fills in when none is set so the
    # attribute is *always* present on every span — enabling unconditional
    # grouping and filtering in the UI without schema changes.
    explicit = AgentContext.get_logical_agent_name()
    logical_name: str = explicit if explicit else _infer_logical_agent_name(span)
    span.set_attribute("logical.agent.name", logical_name)


def _attach_trace_context(span, args, kwargs):
    """
    Attach explicit trace context attributes if ctx is provided by caller.
    Falls back to current AgentContext session_id and active span trace_id.
    """
    explicit_ctx = kwargs.get("ctx")
    if explicit_ctx is None and args:
        first = args[0]
        if isinstance(first, TraceContext):
            explicit_ctx = first

    trace_id = None
    session_id = None
    if isinstance(explicit_ctx, TraceContext):
        trace_id = explicit_ctx.trace_id
        session_id = explicit_ctx.session_id

    if not trace_id:
        try:
            sc = span.get_span_context()
            trace_id = f"{getattr(sc, 'trace_id', 0):032x}" if sc else None
        except Exception:
            trace_id = None
    if not session_id:
        session_id = AgentContext.get_session_id()

    if trace_id:
        span.set_attribute("trace.id", str(trace_id)[:200])
    if session_id:
        span.set_attribute("session.id", str(session_id)[:200])


def _context_text(value):
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str)
    except Exception:
        return str(value)


def _normalise_openai_tool_calls(choices) -> list[dict]:
    """
    Extract tool_calls from OpenAI ChatCompletion choices into a normalised list.
    Returns [] if none found.
    """
    calls = []
    try:
        if not choices:
            return calls
        for choice in choices:
            message = getattr(choice, "message", None)
            if not message:
                continue
            tool_calls = getattr(message, "tool_calls", None)
            if not tool_calls:
                continue
            for tc in tool_calls:
                fn = getattr(tc, "function", None)
                if not fn:
                    continue
                import json as _j
                try:
                    args = _j.loads(getattr(fn, "arguments", "{}") or "{}")
                except Exception:
                    args = str(getattr(fn, "arguments", ""))
                calls.append({
                    "name": getattr(fn, "name", "unknown_tool"),
                    "input": args,
                    "call_id": getattr(tc, "id", None),
                })
    except Exception:
        pass
    return calls


def _normalise_anthropic_tool_use(content_blocks) -> list[dict]:
    """
    Extract tool_use blocks from Anthropic content into a normalised list.
    Returns [] if none found.
    """
    calls = []
    try:
        if not content_blocks:
            return calls
        for block in content_blocks:
            block_type = getattr(block, "type", None)
            if block_type != "tool_use":
                continue
            calls.append({
                "name": getattr(block, "name", "unknown_tool"),
                "input": getattr(block, "input", {}),
                "call_id": getattr(block, "id", None),
            })
    except Exception:
        pass
    return calls


def _emit_tool_call_child_spans(tool_calls: list[dict]) -> None:
    """Emit child OTel spans for extracted tool calls. Silently no-ops on any error."""
    if not tool_calls:
        return
    try:
        from puvinoise.spans import emit_tool_call_spans
        emit_tool_call_spans(tool_calls)
    except Exception:
        pass


def _extract_openai_response(result, span):
    """
    Parse an OpenAI ChatCompletion response object and record span attributes.
    Works for openai>=1.0 (the openai.types.chat.ChatCompletion object).
    Also auto-emits child tool-call spans for any tool_calls in the response.
    """
    try:
        # Model actually used (may differ from requested)
        if hasattr(result, "model"):
            span.set_attribute("llm.response_model", result.model)

        choices = getattr(result, "choices", None)
        if choices:
            first = choices[0]
            # finish_reason
            finish_reason = getattr(first, "finish_reason", None)
            if finish_reason:
                span.set_attribute("llm.stop_reason", finish_reason)
            # message content
            message = getattr(first, "message", None)
            if message:
                content = getattr(message, "content", None) or ""
                span.set_attribute("llm.response", _scrub(content))
                span.set_attribute("llm.response_length", len(content))

            # Auto-extract tool_calls → child spans
            tool_calls = _normalise_openai_tool_calls(choices)
            if tool_calls:
                span.set_attribute("llm.tool_call_count", len(tool_calls))
                span.set_attribute(
                    "llm.tool_calls",
                    json.dumps([{"name": tc["name"], "call_id": tc.get("call_id")} for tc in tool_calls])[:1000],
                )
                _emit_tool_call_child_spans(tool_calls)

        # Token usage (OpenAI ChatCompletion uses prompt_tokens/completion_tokens)
        usage = getattr(result, "usage", None)
        if usage:
            in_tok = getattr(usage, "prompt_tokens", None) or getattr(usage, "input_tokens", None)
            out_tok = getattr(usage, "completion_tokens", None) or getattr(usage, "output_tokens", None)
            if in_tok is not None:
                span.set_attribute("llm.input_tokens", int(in_tok))
            if out_tok is not None:
                span.set_attribute("llm.output_tokens", int(out_tok))
    except Exception:
        pass  # Never let telemetry crash the caller


def _extract_anthropic_response(result, span):
    """
    Parse an Anthropic MessageResponse and record span attributes.
    Also auto-emits child tool-call spans for any tool_use blocks.
    """
    try:
        if hasattr(result, "model"):
            span.set_attribute("llm.response_model", result.model)

        if hasattr(result, "content") and result.content:
            if isinstance(result.content, list):
                text_blocks = [b.text for b in result.content if hasattr(b, "text")]
                response_text = " ".join(text_blocks)

                # Auto-extract tool_use blocks → child spans
                tool_calls = _normalise_anthropic_tool_use(result.content)
                if tool_calls:
                    span.set_attribute("llm.tool_call_count", len(tool_calls))
                    span.set_attribute(
                        "llm.tool_calls",
                        json.dumps([{"name": tc["name"], "call_id": tc.get("call_id")} for tc in tool_calls])[:1000],
                    )
                    _emit_tool_call_child_spans(tool_calls)
            else:
                response_text = str(result.content)
            span.set_attribute("llm.response", _scrub(response_text))
            span.set_attribute("llm.response_length", len(response_text))

        if hasattr(result, "stop_reason"):
            span.set_attribute("llm.stop_reason", result.stop_reason)

        usage = getattr(result, "usage", None)
        if usage:
            if hasattr(usage, "input_tokens"):
                span.set_attribute("llm.input_tokens", usage.input_tokens)
            if hasattr(usage, "output_tokens"):
                span.set_attribute("llm.output_tokens", usage.output_tokens)
    except Exception:
        pass


def _extract_openai_messages(kwargs, span):
    """Extract prompt info from OpenAI-style messages kwarg."""
    messages = kwargs.get("messages")
    if not messages:
        return
    span.set_attribute("llm.message_count", len(messages))
    user_msgs = [m for m in messages if m.get("role") == "user"]
    if user_msgs:
        content = user_msgs[0].get("content", "")
        if isinstance(content, str):
            span.set_attribute("llm.prompt", _scrub(content))
        elif isinstance(content, list):
            texts = [b.get("text", "") for b in content if b.get("type") == "text"]
            if texts:
                span.set_attribute("llm.prompt", _scrub(texts[0]))


# ---------------------------------------------------------------------------
# Anthropic hooks
# ---------------------------------------------------------------------------

def instrument_anthropic_call(func):
    """
    Decorator to automatically trace synchronous Anthropic API calls.

    Usage::

        @instrument_anthropic_call
        def call_claude(prompt, model="claude-sonnet-4-5-20250929"):
            response = client.messages.create(...)
            return response
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        with _tracer.start_as_current_span("llm.anthropic") as span:
            _attach_agent_context(span)
            span.set_attribute("llm.provider", "anthropic")

            model = kwargs.get("model")
            if model:
                span.set_attribute("llm.model", model)

            _extract_openai_messages(kwargs, span)  # same shape for Anthropic

            if "temperature" in kwargs:
                span.set_attribute("llm.temperature", float(kwargs["temperature"]))
            if "max_tokens" in kwargs:
                span.set_attribute("llm.max_tokens", int(kwargs["max_tokens"]))

            _start_ns = time.perf_counter_ns()
            try:
                result = func(*args, **kwargs)
                _elapsed_ms = (time.perf_counter_ns() - _start_ns) / 1e6
                span.set_attribute("llm.elapsed_ms", _elapsed_ms)
                _extract_anthropic_response(result, span)
                _check_response_anomalies(result, span, _elapsed_ms, "anthropic")
                span.set_status(Status(StatusCode.OK))
                return result
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                span.set_attribute("error.type", type(e).__name__)
                _auto_emit_failure(e, span)
                raise

    return wrapper


def instrument_anthropic_stream(func):
    """
    Decorator for *generator* streaming Anthropic API calls.

    The span stays open for the entire stream duration (bug fix: previously
    the span closed before iteration completed).

    Usage::

        @instrument_anthropic_stream
        def stream_claude(prompt):
            with client.messages.stream(...) as stream:
                for text in stream.text_stream:
                    yield text
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        span = _tracer.start_span("llm.anthropic.stream")
        ctx = trace.use_span(span, end_on_exit=False)
        ctx.__enter__()

        _attach_agent_context(span)
        span.set_attribute("llm.provider", "anthropic")
        span.set_attribute("llm.streaming", True)

        model = kwargs.get("model")
        if model:
            span.set_attribute("llm.model", model)

        chunk_count = 0
        total_length = 0
        _stream_start_ns = time.perf_counter_ns()

        try:
            for chunk in func(*args, **kwargs):
                chunk_count += 1
                if isinstance(chunk, str):
                    total_length += len(chunk)
                yield chunk

            _stream_elapsed_ms = (time.perf_counter_ns() - _stream_start_ns) / 1e6
            span.set_attribute("llm.chunks_received", chunk_count)
            span.set_attribute("llm.total_length", total_length)
            span.set_attribute("llm.elapsed_ms", _stream_elapsed_ms)
            # Flag suspiciously slow or empty streams
            if _stream_elapsed_ms > _get_llm_latency_threshold_ms():
                span.set_attribute("llm.latency_exceeded", True)
                try:
                    from puvinoise.decision_telemetry import record_failure as _record_failure
                    _record_failure(
                        category="timeout",
                        error_type="SlowLLMStream",
                        message=f"Anthropic stream took {_stream_elapsed_ms:.0f}ms",
                    )
                except Exception:
                    pass
            if chunk_count == 0:
                try:
                    from puvinoise.decision_telemetry import record_failure as _record_failure
                    _record_failure(
                        category="unknown",
                        error_type="EmptyLLMResponse",
                        message="Anthropic stream produced zero chunks",
                    )
                except Exception:
                    pass
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            _auto_emit_failure(e, span)
            raise
        finally:
            ctx.__exit__(None, None, None)
            span.end()

    return wrapper


# ---------------------------------------------------------------------------
# OpenAI hook
# ---------------------------------------------------------------------------

def instrument_openai_call(func):
    """
    Decorator to automatically trace OpenAI API calls (openai>=1.0).

    API keys are read by the openai library itself (``OPENAI_API_KEY`` env var
    or ``openai.api_key``).  The SDK never touches credentials.

    Usage::

        @instrument_openai_call
        def call_gpt(prompt, model="gpt-4o"):
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
            )
            return response
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        import logging as _log
        _log.getLogger("puvinoise.hooks").debug(
            "puvinoise.hooks: llm.openai span starting (model=%s)", kwargs.get("model")
        )
        with _tracer.start_as_current_span("llm.openai") as span:
            _attach_agent_context(span)
            _attach_trace_context(span, args, kwargs)
            span.set_attribute("llm.provider", "openai")

            model = kwargs.get("model")
            if model:
                span.set_attribute("llm.model", model)

            _extract_openai_messages(kwargs, span)

            if "temperature" in kwargs:
                span.set_attribute("llm.temperature", float(kwargs["temperature"]))
            if "max_tokens" in kwargs:
                span.set_attribute("llm.max_tokens", int(kwargs["max_tokens"]))

            _start_ns = time.perf_counter_ns()
            try:
                result = func(*args, **kwargs)
                _elapsed_ms = (time.perf_counter_ns() - _start_ns) / 1e6
                span.set_attribute("llm.elapsed_ms", _elapsed_ms)
                _extract_openai_response(result, span)
                _check_response_anomalies(result, span, _elapsed_ms, "openai")
                span.set_status(Status(StatusCode.OK))
                return result
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                span.set_attribute("error.type", type(e).__name__)
                _auto_emit_failure(e, span)
                raise

    return wrapper


def instrument_openai_async_call(func):
    """
    Async counterpart of instrument_openai_call — traces AsyncOpenAI completions.

    Patches AsyncCompletions.create so that agents using AsyncOpenAI / await
    client.chat.completions.create(...) emit LLM spans identically to the sync
    path.  Without this, llmCount remains 0 for all async agents.
    """
    import asyncio

    @functools.wraps(func)
    async def async_wrapper(*args, **kwargs):
        import logging as _log
        _log.getLogger("puvinoise.hooks").debug(
            "puvinoise.hooks: async llm.openai span starting (model=%s)", kwargs.get("model")
        )
        with _tracer.start_as_current_span("llm.openai") as span:
            _attach_agent_context(span)
            _attach_trace_context(span, args, kwargs)
            span.set_attribute("llm.provider", "openai")

            model = kwargs.get("model")
            if model:
                span.set_attribute("llm.model", model)

            _extract_openai_messages(kwargs, span)

            if "temperature" in kwargs:
                span.set_attribute("llm.temperature", float(kwargs["temperature"]))
            if "max_tokens" in kwargs:
                span.set_attribute("llm.max_tokens", int(kwargs["max_tokens"]))

            _start_ns = time.perf_counter_ns()
            try:
                result = await func(*args, **kwargs)
                _elapsed_ms = (time.perf_counter_ns() - _start_ns) / 1e6
                span.set_attribute("llm.elapsed_ms", _elapsed_ms)
                _extract_openai_response(result, span)
                _check_response_anomalies(result, span, _elapsed_ms, "openai")
                span.set_status(Status(StatusCode.OK))
                _log.getLogger("puvinoise.hooks").debug(
                    "puvinoise.hooks: async llm.openai span completed"
                )
                return result
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                span.set_attribute("error.type", type(e).__name__)
                _auto_emit_failure(e, span)
                raise

    return async_wrapper


def instrument_openai_stream(func):
    """
    Decorator for streaming OpenAI calls using ``stream=True``.

    Usage::

        @instrument_openai_stream
        def stream_gpt(prompt, model="gpt-4o"):
            for chunk in client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                stream=True,
            ):
                delta = chunk.choices[0].delta.content or ""
                yield delta
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        span = _tracer.start_span("llm.openai.stream")
        ctx = trace.use_span(span, end_on_exit=False)
        ctx.__enter__()

        _attach_agent_context(span)
        span.set_attribute("llm.provider", "openai")
        span.set_attribute("llm.streaming", True)

        model = kwargs.get("model")
        if model:
            span.set_attribute("llm.model", model)

        chunk_count = 0
        total_length = 0
        _stream_start_ns = time.perf_counter_ns()

        try:
            for chunk in func(*args, **kwargs):
                chunk_count += 1
                if isinstance(chunk, str):
                    total_length += len(chunk)
                yield chunk

            _stream_elapsed_ms = (time.perf_counter_ns() - _stream_start_ns) / 1e6
            span.set_attribute("llm.chunks_received", chunk_count)
            span.set_attribute("llm.total_length", total_length)
            span.set_attribute("llm.elapsed_ms", _stream_elapsed_ms)
            if _stream_elapsed_ms > _get_llm_latency_threshold_ms():
                span.set_attribute("llm.latency_exceeded", True)
                try:
                    from puvinoise.decision_telemetry import record_failure as _record_failure
                    _record_failure(
                        category="timeout",
                        error_type="SlowLLMStream",
                        message=f"OpenAI stream took {_stream_elapsed_ms:.0f}ms",
                    )
                except Exception:
                    pass
            if chunk_count == 0:
                try:
                    from puvinoise.decision_telemetry import record_failure as _record_failure
                    _record_failure(
                        category="unknown",
                        error_type="EmptyLLMResponse",
                        message="OpenAI stream produced zero chunks",
                    )
                except Exception:
                    pass
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            _auto_emit_failure(e, span)
            raise
        finally:
            ctx.__exit__(None, None, None)
            span.end()

    return wrapper


# ---------------------------------------------------------------------------
# Generic / Ollama hook
# ---------------------------------------------------------------------------

def instrument_llm_call(provider="unknown"):
    """
    Generic LLM call instrumentation (works with any provider: Ollama, Cohere, etc.).

    Unlike the old version this is now a *parameterised* decorator so you can
    tag the provider name cleanly::

        @instrument_llm_call(provider="ollama")
        def call_ollama(prompt, model="llama3"):
            ...

    For backward-compat, calling without parentheses still works (provider="unknown").
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with _tracer.start_as_current_span("llm.call") as span:
                _attach_agent_context(span)
                span.set_attribute("llm.provider", provider)

                model = kwargs.get("model", "unknown")
                span.set_attribute("llm.model", model)

                # Accept a plain prompt string as first positional arg or kwarg
                prompt = kwargs.get("prompt") or (
                    args[0] if args and isinstance(args[0], str) else None
                )
                if prompt:
                    span.set_attribute("llm.prompt", _scrub(prompt))

                if "temperature" in kwargs:
                    span.set_attribute("llm.temperature", float(kwargs["temperature"]))

                _start_ns = time.perf_counter_ns()
                try:
                    result = func(*args, **kwargs)
                    _elapsed_ms = (time.perf_counter_ns() - _start_ns) / 1e6
                    span.set_attribute("llm.elapsed_ms", _elapsed_ms)

                    if isinstance(result, str):
                        span.set_attribute("llm.response", result[:500])
                        span.set_attribute("llm.response_length", len(result))
                    elif isinstance(result, dict):
                        # Ollama /api/chat returns a dict
                        msg = (
                            result.get("message", {}).get("content")
                            or result.get("response", "")
                        )
                        if msg:
                            span.set_attribute("llm.response", msg[:500])
                            span.set_attribute("llm.response_length", len(msg))
                        # Ollama model from response (actual model used)
                        resp_model = result.get("model")
                        if resp_model:
                            span.set_attribute("llm.response_model", str(resp_model))
                        # Ollama token counts
                        if "prompt_eval_count" in result:
                            span.set_attribute("llm.input_tokens", result["prompt_eval_count"])
                        if "eval_count" in result:
                            span.set_attribute("llm.output_tokens", result["eval_count"])

                    _check_response_anomalies(result, span, _elapsed_ms, provider)
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    span.set_attribute("error.type", type(e).__name__)
                    _auto_emit_failure(e, span)
                    raise

        return wrapper

    # Allow @instrument_llm_call (no parens) for backward compat
    if callable(provider):
        func, provider = provider, "unknown"
        return decorator(func)

    return decorator


# ---------------------------------------------------------------------------
# Memory & tool hooks (unchanged API, small robustness improvements)
# ---------------------------------------------------------------------------

def instrument_memory_operation(operation_type="query"):
    """
    Decorator to trace memory operations (retrieval, storage, delete, etc.).

    Usage::

        @instrument_memory_operation("retrieve")
        def retrieve_memory(query):
            ...
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with _tracer.start_as_current_span(f"memory.{operation_type}") as span:
                _attach_agent_context(span)
                span.set_attribute("memory.operation", operation_type)

                try:
                    result = func(*args, **kwargs)
                    if isinstance(result, (list, tuple)):
                        span.set_attribute("memory.result_count", len(result))
                    record_context("memory", _context_text(result))
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    raise

        return wrapper
    return decorator


def instrument_tool_call(tool_name=None, tool_candidates=None, selection_reasoning=None, selection_confidence=None):
    """
    Decorator to trace agent tool usage.
    Optionally records decision telemetry: tool candidates considered and selection reasoning.

    Usage::

        @instrument_tool_call("web_search")
        def search_web(query):
            ...

        @instrument_tool_call("web_search", tool_candidates=["web_search", "calculator"],
                             selection_reasoning="need current info", selection_confidence=0.9)
        def search_web(query):
            ...
    """
    # Backward compat: @instrument_tool_call without parens
    if callable(tool_name):
        func, tool_name = tool_name, None
        return instrument_tool_call(None, None, None, None)(func)

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            name = tool_name or func.__name__
            with _tracer.start_as_current_span(f"tool.{name}") as span:
                _attach_agent_context(span)
                _attach_trace_context(span, args, kwargs)
                span.set_attribute("tool.name", name)
                if tool_candidates is not None:
                    from puvinoise.decision_telemetry import record_tool_candidates, record_tool_selection_reasoning
                    record_tool_candidates(
                        candidates=tool_candidates,
                        selected_name=name,
                        reasoning=selection_reasoning,
                        confidence=selection_confidence,
                    )
                    if selection_reasoning is not None:
                        record_tool_selection_reasoning(
                            tool_name=name,
                            reasoning=selection_reasoning,
                            confidence=selection_confidence,
                        )
                try:
                    result = func(*args, **kwargs)
                    context_type = "tool_output"
                    lname = str(name or "").lower()
                    if "mcp" in lname:
                        context_type = "mcp"
                    elif any(tok in lname for tok in ("rag", "retriev", "vector")):
                        context_type = "rag"
                    record_context(context_type, _context_text(result))
                    span.set_status(Status(StatusCode.OK))
                    # Behaviour signals: count successful tool call
                    AgentContext.increment_tool_call(name, success=True)
                    try:
                        from puvinoise.framework_instrumentation import record_behavior_event

                        record_behavior_event("tool_call", {"tool": str(name)})
                    except Exception:  # noqa: BLE001
                        pass
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    _auto_emit_failure(e, span)
                    # Behaviour signals: count failed tool call
                    AgentContext.increment_tool_call(name, success=False)
                    raise

        return wrapper
    return decorator


def _patch_method(target, method_name: str, decorator) -> bool:
    fn = getattr(target, method_name, None)
    if not callable(fn):
        return False
    if getattr(fn, "_puvinoise_instrumented", False):
        return False
    wrapped = decorator(fn)
    try:
        wrapped._puvinoise_instrumented = True
    except Exception:
        pass
    setattr(target, method_name, wrapped)
    return True


# ---------------------------------------------------------------------------
# Zero-touch failure detection helpers
# ---------------------------------------------------------------------------

def _get_llm_latency_threshold_ms() -> float:
    """Return the configured LLM latency threshold in milliseconds (default 30 000 ms)."""
    try:
        return float(os.environ.get("PUVINOISE_LLM_TIMEOUT_MS", "30000"))
    except (ValueError, TypeError):
        return 30000.0


def _auto_emit_failure(exc: BaseException, span) -> None:
    """
    Infer the failure category from *exc* and emit a ``decision.failure`` span
    event unconditionally.  Designed to be called from every LLM / tool
    exception handler so failures are always visible to the trace-normalizer
    even when agent code swallows the exception upstream.
    """
    try:
        from puvinoise.tracer import _infer_failure_category
        from puvinoise.decision_telemetry import record_failure as _record_failure
        cat = _infer_failure_category(exc)
        etype = type(exc).__name__
        _record_failure(category=cat, error_type=etype, message=str(exc)[:500])
    except Exception:
        pass


def _check_response_anomalies(result, span, elapsed_ms: float, provider: str = "unknown") -> None:
    """
    Inspect a successful LLM response for anomalies and emit ``decision.failure``
    events when detected.  Checks:

    * **Latency exceeded** – ``elapsed_ms > PUVINOISE_LLM_TIMEOUT_MS``
    * **Content filter** – OpenAI ``finish_reason == "content_filter"``
    * **Token limit**    – OpenAI ``finish_reason == "length"``  /
                           Anthropic ``stop_reason == "max_tokens"``
    * **Empty response** – no content in the response body
    * **Anthropic error** – ``stop_reason == "error"``

    All failures are emitted via ``record_failure()`` which unconditionally
    calls ``span.add_event("decision.failure", ...)``.
    """
    try:
        # ── Latency guard ────────────────────────────────────────────────────
        threshold_ms = _get_llm_latency_threshold_ms()
        if elapsed_ms > threshold_ms:
            span.set_attribute("llm.latency_exceeded", True)
            span.set_attribute("llm.elapsed_ms", elapsed_ms)
            from puvinoise.decision_telemetry import record_failure as _record_failure
            _record_failure(
                category="timeout",
                error_type="SlowLLMResponse",
                message=f"LLM call took {elapsed_ms:.0f}ms (threshold: {threshold_ms:.0f}ms)",
            )

        # ── Provider-specific anomalies ───────────────────────────────────────
        if provider == "openai":
            choices = getattr(result, "choices", None)
            if not choices:
                from puvinoise.decision_telemetry import record_failure as _record_failure
                _record_failure(
                    category="unknown",
                    error_type="EmptyLLMResponse",
                    message="OpenAI response has no choices",
                )
                return
            first = choices[0]
            finish_reason = getattr(first, "finish_reason", None)
            if finish_reason == "content_filter":
                from puvinoise.decision_telemetry import record_failure as _record_failure
                _record_failure(
                    category="content_filter",
                    error_type="ContentFilterTriggered",
                    message="OpenAI content filter triggered (finish_reason=content_filter)",
                )
            elif finish_reason == "length":
                from puvinoise.decision_telemetry import record_failure as _record_failure
                _record_failure(
                    category="token_limit",
                    error_type="MaxTokensReached",
                    message="OpenAI response truncated at max_tokens (finish_reason=length)",
                )
            # Empty content check
            message = getattr(first, "message", None)
            if message:
                content = getattr(message, "content", None) or ""
                if not content.strip():
                    from puvinoise.decision_telemetry import record_failure as _record_failure
                    _record_failure(
                        category="unknown",
                        error_type="EmptyLLMResponse",
                        message="OpenAI response message content is empty",
                    )

        elif provider == "anthropic":
            stop_reason = getattr(result, "stop_reason", None)
            if stop_reason == "error":
                from puvinoise.decision_telemetry import record_failure as _record_failure
                _record_failure(
                    category="unknown",
                    error_type="AnthropicResponseError",
                    message="Anthropic response stop_reason=error",
                )
            elif stop_reason == "max_tokens":
                from puvinoise.decision_telemetry import record_failure as _record_failure
                _record_failure(
                    category="token_limit",
                    error_type="MaxTokensReached",
                    message="Anthropic response truncated at max_tokens",
                )
            # Empty content check
            content = getattr(result, "content", None)
            if not content:
                from puvinoise.decision_telemetry import record_failure as _record_failure
                _record_failure(
                    category="unknown",
                    error_type="EmptyLLMResponse",
                    message="Anthropic response content is empty",
                )

        else:
            # Generic provider: flag None or empty-string responses
            if result is None:
                from puvinoise.decision_telemetry import record_failure as _record_failure
                _record_failure(
                    category="unknown",
                    error_type="EmptyLLMResponse",
                    message="LLM response is None",
                )
            elif isinstance(result, str) and not result.strip():
                from puvinoise.decision_telemetry import record_failure as _record_failure
                _record_failure(
                    category="unknown",
                    error_type="EmptyLLMResponse",
                    message="LLM response string is empty",
                )
    except Exception:
        pass  # Never let anomaly detection crash the caller


def enable_auto_instrumentation() -> dict:
    """
    SDK-level best-effort instrumentation for common provider SDKs.
    This keeps telemetry capture in SDK/wrapper layer without requiring
    customer agent code to manually apply decorators.
    """
    global _AUTO_INSTRUMENT_DONE
    if _AUTO_INSTRUMENT_DONE:
        return {"enabled": True, "patched": []}
    patched = []

    # OpenAI chat completions — sync client (OpenAI)
    try:
        from openai.resources.chat.completions import Completions  # type: ignore

        if _patch_method(Completions, "create", instrument_openai_call):
            patched.append("openai.chat.completions.create")
    except Exception:
        pass

    # OpenAI chat completions — async client (AsyncOpenAI).
    # This is the critical missing path: agents using `await client.chat.completions.create(...)`
    # would never emit LLM spans without patching AsyncCompletions independently.
    try:
        from openai.resources.chat.completions import AsyncCompletions  # type: ignore

        if _patch_method(AsyncCompletions, "create", instrument_openai_async_call):
            patched.append("openai.chat.completions.async_create")
    except Exception:
        pass

    # Anthropic messages
    try:
        from anthropic.resources.messages import Messages  # type: ignore

        if _patch_method(Messages, "create", instrument_anthropic_call):
            patched.append("anthropic.messages.create")
        if _patch_method(Messages, "stream", instrument_anthropic_stream):
            patched.append("anthropic.messages.stream")
    except Exception:
        pass

    _AUTO_INSTRUMENT_DONE = True
    return {"enabled": True, "patched": patched}


# ---------------------------------------------------------------------------
# Span utilities
# ---------------------------------------------------------------------------

def add_span_attribute(key: str, value):
    """Add a custom attribute to the current active span."""
    span = trace.get_current_span()
    if span and span.is_recording():
        span.set_attribute(key, value)


def add_span_event(name: str, attributes: dict = None):
    """Add an event to the current active span."""
    span = trace.get_current_span()
    if span and span.is_recording():
        span.add_event(name, attributes or {})