"""Allow: python -m puvinoise run ..."""

from puvinoise.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
