"""
agent-sdk/puvinoise/framework_instrumentation.py
─────────────────────────────────────────────────
Runtime interception layer — framework-agnostic behavior intelligence.

This module dynamically instruments agent frameworks at runtime via
monkey-patching.  It is the CORE instrumentation layer, NOT a plugin system.

Design principles
─────────────────
1. **Behavior-aware, not framework-coupled** — instrumentation hooks capture
   inputs, outputs, latency, and step sequences regardless of framework.
2. **Safe under API drift** — every hook is wrapped in try/except so that if
   a framework changes its internal API the worst case is a logged warning,
   never a crash.
3. **Idempotent** — calling ``apply_instrumentation()`` multiple times does
   not double-patch; the ``_puvinoise_instrumented`` sentinel prevents this.
4. **Framework-agnostic fallback** — when no known framework is present the
   behavior-based tracer still captures LLM calls, tool calls, and multi-step
   patterns, classifying them as ``agent_workflow_detected``.
5. **No hard dependencies** — this module imports frameworks lazily inside
   hook application functions; it runs fine even when none are installed.

Flow
────
    puvinoise.init()
        → framework_detection.detect_all()
        → framework_instrumentation.apply_instrumentation(detection_result)
            → _apply_langchain_hooks()     (if langchain detected)
            → _apply_langgraph_hooks()     (if langgraph detected)
            → _apply_crewai_hooks()        (if crewai detected)
            → _apply_autogen_hooks()       (if autogen detected)
            → _apply_llama_index_hooks()   (if llama_index detected)
            → _apply_behavior_fallback()   (always, for unknown workflows)
"""

from __future__ import annotations

import functools
import inspect
import logging
import os
import sys
import threading
import time
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("puvinoise.framework_instrumentation")


def _record_framework_usage_label(label: str) -> None:
    """Increment runtime usage counter for a known framework label (best-effort)."""
    if not label:
        return
    try:
        from puvinoise.framework_usage import record_framework_usage

        record_framework_usage(label)
    except Exception:  # noqa: BLE001
        pass


def _record_framework_usage_from_attrs(attributes: Dict[str, str]) -> None:
    _record_framework_usage_label((attributes.get("framework") or "").strip())


# ─── Module-level state ─────────────────────────────────────────────────────

_INSTRUMENTATION_DONE: bool = False
_PATCHED_TARGETS: List[str] = []


# ─── Shared helpers ──────────────────────────────────────────────────────────

def _get_tracer():
    """Late-bind the OpenTelemetry tracer so we don't force an OTel dependency
    at import time."""
    try:
        from opentelemetry import trace
        return trace.get_tracer("puvinoise.framework")
    except Exception:  # noqa: BLE001
        return None


def _safe_patch(target: Any, method_name: str, wrapper_factory: Callable,
                label: str) -> bool:
    """
    Monkey-patch ``target.method_name`` with the wrapper returned by
    ``wrapper_factory(original_method)``.

    Returns True if the patch was applied, False if skipped (already patched,
    method missing, or error).

    Uses the ``_puvinoise_instrumented`` sentinel from hooks.py to prevent
    double-patching.
    """
    try:
        original = getattr(target, method_name, None)
        if original is None:
            logger.debug("framework_instrumentation: %s.%s not found — skipping",
                         label, method_name)
            return False

        if not callable(original):
            return False

        if getattr(original, "_puvinoise_instrumented", False):
            logger.debug("framework_instrumentation: %s.%s already patched — skipping",
                         label, method_name)
            return False

        wrapped = wrapper_factory(original)
        try:
            wrapped._puvinoise_instrumented = True
        except (AttributeError, TypeError):
            pass  # builtin methods may not allow attribute setting

        setattr(target, method_name, wrapped)
        _PATCHED_TARGETS.append(f"{label}.{method_name}")
        logger.debug("framework_instrumentation: patched %s.%s", label, method_name)
        return True
    except Exception as exc:  # noqa: BLE001
        logger.warning("framework_instrumentation: failed to patch %s.%s: %s",
                        label, method_name, exc)
        return False


def _make_span_wrapper(span_name: str, attributes: Dict[str, str]):
    """
    Factory: returns a wrapper_factory suitable for _safe_patch() that creates
    an OTel span around the original method, recording input/output/latency.
    """
    def wrapper_factory(original):
        @functools.wraps(original)
        def wrapper(*args, **kwargs):
            _record_framework_usage_from_attrs(attributes)
            tracer = _get_tracer()
            if tracer is None:
                return original(*args, **kwargs)

            with tracer.start_as_current_span(span_name) as span:
                for k, v in attributes.items():
                    span.set_attribute(k, v)

                # Capture input summary (first positional arg or named 'input')
                input_val = kwargs.get("input") or kwargs.get("inputs") or (
                    args[0] if args else None
                )
                if input_val is not None:
                    span.set_attribute("input.summary", _safe_str(input_val, 500))

                t0 = time.monotonic()
                try:
                    result = original(*args, **kwargs)
                    elapsed_ms = (time.monotonic() - t0) * 1000
                    span.set_attribute("duration_ms", round(elapsed_ms, 2))

                    if result is not None:
                        span.set_attribute("output.summary", _safe_str(result, 500))

                    from opentelemetry.trace import Status, StatusCode
                    span.set_status(Status(StatusCode.OK))
                    fw = (attributes.get("framework") or "").strip()
                    comp = (attributes.get("component") or "").strip()
                    if fw in (
                        "langchain",
                        "langgraph",
                        "crewai",
                        "autogen",
                        "llama_index",
                    ) and comp == "llm":
                        try:
                            record_behavior_event(
                                "llm_call",
                                {"framework": fw, "span": span_name},
                            )
                        except Exception:  # noqa: BLE001
                            pass
                    return result
                except Exception as exc:
                    elapsed_ms = (time.monotonic() - t0) * 1000
                    span.set_attribute("duration_ms", round(elapsed_ms, 2))
                    from opentelemetry.trace import Status, StatusCode
                    span.set_status(Status(StatusCode.ERROR, str(exc)))
                    span.record_exception(exc)
                    try:
                        from puvinoise.hooks import _auto_emit_failure
                        _auto_emit_failure(exc, span)
                    except Exception:  # noqa: BLE001
                        pass
                    raise
        return wrapper
    return wrapper_factory


def _safe_str(obj: Any, max_len: int = 500) -> str:
    """Best-effort string representation, capped to max_len."""
    try:
        s = str(obj)
    except Exception:  # noqa: BLE001
        s = repr(type(obj))
    return s[:max_len]


# ─── LangChain hooks ────────────────────────────────────────────────────────

def _apply_langchain_hooks() -> List[str]:
    """
    Dynamically patch LangChain's Chain and Runnable classes.

    Hooks:
      - Chain.run()    / Chain.__call__()    → span: langchain.chain.run
      - Chain.invoke()                        → span: langchain.chain.invoke
      - BaseChatModel.invoke()                → span: langchain.llm.invoke
      - BaseChatModel.generate()              → span: langchain.llm.generate
    """
    patched: List[str] = []

    # ── Chain.invoke / Chain.run (langchain.chains.base) ─────────────────
    try:
        from langchain.chains.base import Chain  # type: ignore[import-untyped]
        if _safe_patch(Chain, "invoke", _make_span_wrapper(
                "langchain.chain.invoke",
                {"framework": "langchain", "component": "chain", "operation": "invoke"}),
                "langchain.Chain"):
            patched.append("langchain.Chain.invoke")

        if _safe_patch(Chain, "run", _make_span_wrapper(
                "langchain.chain.run",
                {"framework": "langchain", "component": "chain", "operation": "run"}),
                "langchain.Chain"):
            patched.append("langchain.Chain.run")

        if _safe_patch(Chain, "__call__", _make_span_wrapper(
                "langchain.chain.call",
                {"framework": "langchain", "component": "chain", "operation": "__call__"}),
                "langchain.Chain"):
            patched.append("langchain.Chain.__call__")
    except Exception as exc:  # noqa: BLE001
        logger.debug("langchain Chain hooks skipped: %s", exc)

    # ── Runnable.invoke (langchain_core) ─────────────────────────────────
    try:
        from langchain_core.runnables.base import RunnableSerializable  # type: ignore[import-untyped]
        if _safe_patch(RunnableSerializable, "invoke", _make_span_wrapper(
                "langchain.runnable.invoke",
                {"framework": "langchain", "component": "runnable", "operation": "invoke"}),
                "langchain_core.RunnableSerializable"):
            patched.append("langchain_core.RunnableSerializable.invoke")
    except Exception as exc:  # noqa: BLE001
        logger.debug("langchain_core Runnable hooks skipped: %s", exc)

    # ── BaseChatModel (LLM calls) ────────────────────────────────────────
    try:
        from langchain_core.language_models.chat_models import BaseChatModel  # type: ignore[import-untyped]
        if _safe_patch(BaseChatModel, "invoke", _make_span_wrapper(
                "langchain.llm.invoke",
                {"framework": "langchain", "component": "llm", "operation": "invoke"}),
                "langchain.BaseChatModel"):
            patched.append("langchain.BaseChatModel.invoke")

        if _safe_patch(BaseChatModel, "generate", _make_span_wrapper(
                "langchain.llm.generate",
                {"framework": "langchain", "component": "llm", "operation": "generate"}),
                "langchain.BaseChatModel"):
            patched.append("langchain.BaseChatModel.generate")
    except Exception as exc:  # noqa: BLE001
        logger.debug("langchain BaseChatModel hooks skipped: %s", exc)

    return patched


# ─── LangGraph hooks ────────────────────────────────────────────────────────

def _apply_langgraph_hooks() -> List[str]:
    """
    Dynamically patch LangGraph's StateGraph and CompiledGraph.

    Hooks:
      - StateGraph.compile()     → span: langgraph.graph.compile
      - CompiledGraph.invoke()   → span: langgraph.graph.invoke
      - CompiledGraph.stream()   → span: langgraph.graph.stream

    These capture graph transitions, node execution order, and state
    snapshots at each step.
    """
    patched: List[str] = []

    # ── StateGraph.compile ───────────────────────────────────────────────
    try:
        from langgraph.graph.state import StateGraph  # type: ignore[import-untyped]
        if _safe_patch(StateGraph, "compile", _make_span_wrapper(
                "langgraph.graph.compile",
                {"framework": "langgraph", "component": "graph", "operation": "compile"}),
                "langgraph.StateGraph"):
            patched.append("langgraph.StateGraph.compile")
    except Exception as exc:  # noqa: BLE001
        logger.debug("langgraph StateGraph hooks skipped: %s", exc)

    # ── CompiledGraph.invoke / .stream ───────────────────────────────────
    try:
        from langgraph.graph.graph import CompiledGraph  # type: ignore[import-untyped]
        if _safe_patch(CompiledGraph, "invoke", _make_span_wrapper(
                "langgraph.graph.invoke",
                {"framework": "langgraph", "component": "compiled_graph", "operation": "invoke"}),
                "langgraph.CompiledGraph"):
            patched.append("langgraph.CompiledGraph.invoke")

        # stream() is a generator — wrap it with a span that stays open.
        def _stream_wrapper_factory(original):
            @functools.wraps(original)
            def wrapper(*args, **kwargs):
                _record_framework_usage_label("langgraph")
                tracer = _get_tracer()
                if tracer is None:
                    yield from original(*args, **kwargs)
                    return

                span = tracer.start_span("langgraph.graph.stream")
                span.set_attribute("framework", "langgraph")
                span.set_attribute("component", "compiled_graph")
                span.set_attribute("operation", "stream")

                step_count = 0
                try:
                    for chunk in original(*args, **kwargs):
                        step_count += 1
                        span.add_event("graph_step", {"step": step_count})
                        yield chunk
                    span.set_attribute("graph.step_count", step_count)
                    from opentelemetry.trace import Status, StatusCode
                    span.set_status(Status(StatusCode.OK))
                except Exception as exc:
                    from opentelemetry.trace import Status, StatusCode
                    span.set_status(Status(StatusCode.ERROR, str(exc)))
                    span.record_exception(exc)
                    try:
                        from puvinoise.hooks import _auto_emit_failure
                        _auto_emit_failure(exc, span)
                    except Exception:  # noqa: BLE001
                        pass
                    raise
                finally:
                    span.end()
            return wrapper

        if _safe_patch(CompiledGraph, "stream", _stream_wrapper_factory,
                       "langgraph.CompiledGraph"):
            patched.append("langgraph.CompiledGraph.stream")
    except Exception as exc:  # noqa: BLE001
        logger.debug("langgraph CompiledGraph hooks skipped: %s", exc)

    return patched


# ─── CrewAI hooks ────────────────────────────────────────────────────────────

def _apply_crewai_hooks() -> List[str]:
    """
    Dynamically patch CrewAI's Agent, Task, and Crew classes.

    Hooks:
      - Agent.execute_task()   → span: crewai.agent.execute_task
      - Task.execute()         → span: crewai.task.execute
      - Crew.kickoff()         → span: crewai.crew.kickoff
    """
    patched: List[str] = []

    # ── CrewAI Agent ─────────────────────────────────────────────────────
    try:
        from crewai import Agent as CrewAgent  # type: ignore[import-untyped]

        def _agent_execute_factory(original):
            @functools.wraps(original)
            def wrapper(self, *args, **kwargs):
                _record_framework_usage_label("crewai")
                tracer = _get_tracer()
                if tracer is None:
                    return original(self, *args, **kwargs)
                span_name = "crewai.agent.execute_task"
                with tracer.start_as_current_span(span_name) as span:
                    span.set_attribute("framework", "crewai")
                    span.set_attribute("component", "agent")
                    span.set_attribute("agent.role", _safe_str(getattr(self, "role", ""), 200))
                    span.set_attribute("agent.goal", _safe_str(getattr(self, "goal", ""), 200))

                    # Capture task description from first arg if present
                    if args:
                        span.set_attribute("task.description", _safe_str(args[0], 300))

                    t0 = time.monotonic()
                    try:
                        result = original(self, *args, **kwargs)
                        span.set_attribute("duration_ms", round((time.monotonic() - t0) * 1000, 2))
                        span.set_attribute("output.summary", _safe_str(result, 500))
                        from opentelemetry.trace import Status, StatusCode
                        span.set_status(Status(StatusCode.OK))
                        return result
                    except Exception as exc:
                        span.set_attribute("duration_ms", round((time.monotonic() - t0) * 1000, 2))
                        from opentelemetry.trace import Status, StatusCode
                        span.set_status(Status(StatusCode.ERROR, str(exc)))
                        span.record_exception(exc)
                        try:
                            from puvinoise.hooks import _auto_emit_failure
                            _auto_emit_failure(exc, span)
                        except Exception:  # noqa: BLE001
                            pass
                        raise
            return wrapper

        if _safe_patch(CrewAgent, "execute_task", _agent_execute_factory,
                       "crewai.Agent"):
            patched.append("crewai.Agent.execute_task")
    except Exception as exc:  # noqa: BLE001
        logger.debug("crewai Agent hooks skipped: %s", exc)

    # ── CrewAI Task ──────────────────────────────────────────────────────
    try:
        from crewai import Task as CrewTask  # type: ignore[import-untyped]

        def _task_execute_factory(original):
            @functools.wraps(original)
            def wrapper(self, *args, **kwargs):
                _record_framework_usage_label("crewai")
                tracer = _get_tracer()
                if tracer is None:
                    return original(self, *args, **kwargs)
                with tracer.start_as_current_span("crewai.task.execute") as span:
                    span.set_attribute("framework", "crewai")
                    span.set_attribute("component", "task")
                    span.set_attribute("task.description",
                                       _safe_str(getattr(self, "description", ""), 300))
                    span.set_attribute("task.expected_output",
                                       _safe_str(getattr(self, "expected_output", ""), 200))

                    t0 = time.monotonic()
                    try:
                        result = original(self, *args, **kwargs)
                        span.set_attribute("duration_ms",
                                           round((time.monotonic() - t0) * 1000, 2))
                        span.set_attribute("output.summary", _safe_str(result, 500))
                        from opentelemetry.trace import Status, StatusCode
                        span.set_status(Status(StatusCode.OK))
                        return result
                    except Exception as exc:
                        span.set_attribute("duration_ms",
                                           round((time.monotonic() - t0) * 1000, 2))
                        from opentelemetry.trace import Status, StatusCode
                        span.set_status(Status(StatusCode.ERROR, str(exc)))
                        span.record_exception(exc)
                        try:
                            from puvinoise.hooks import _auto_emit_failure
                            _auto_emit_failure(exc, span)
                        except Exception:  # noqa: BLE001
                            pass
                        raise
            return wrapper

        if _safe_patch(CrewTask, "execute", _task_execute_factory, "crewai.Task"):
            patched.append("crewai.Task.execute")
    except Exception as exc:  # noqa: BLE001
        logger.debug("crewai Task hooks skipped: %s", exc)

    # ── CrewAI Crew.kickoff ──────────────────────────────────────────────
    try:
        from crewai import Crew  # type: ignore[import-untyped]
        if _safe_patch(Crew, "kickoff", _make_span_wrapper(
                "crewai.crew.kickoff",
                {"framework": "crewai", "component": "crew", "operation": "kickoff"}),
                "crewai.Crew"):
            patched.append("crewai.Crew.kickoff")
    except Exception as exc:  # noqa: BLE001
        logger.debug("crewai Crew hooks skipped: %s", exc)

    return patched


# ─── AutoGen hooks ───────────────────────────────────────────────────────────

def _apply_autogen_hooks() -> List[str]:
    """
    Patch ``ConversableAgent.generate_reply`` / ``initiate_chat`` (agentchat).

    Import paths vary by release; we try the most common stable locations.
    """
    patched: List[str] = []

    def _conversable_agent_class():
        try:
            from autogen.agentchat.conversable_agent import (  # type: ignore[import-untyped]
                ConversableAgent,
            )

            return ConversableAgent
        except Exception:  # noqa: BLE001
            pass
        try:
            from autogen import ConversableAgent  # type: ignore[import-untyped]

            return ConversableAgent
        except Exception:  # noqa: BLE001
            return None

    try:
        CA = _conversable_agent_class()
        if CA is None:
            raise ImportError("ConversableAgent not found")
        if _safe_patch(
            CA,
            "generate_reply",
            _make_span_wrapper(
                "autogen.agent.generate_reply",
                {
                    "framework": "autogen",
                    "component": "llm",
                    "operation": "generate_reply",
                },
            ),
            "autogen.ConversableAgent",
        ):
            patched.append("autogen.ConversableAgent.generate_reply")
    except Exception as exc:  # noqa: BLE001
        logger.debug("autogen generate_reply hook skipped: %s", exc)

    try:
        CA = _conversable_agent_class()
        if CA is None:
            raise ImportError("ConversableAgent not found")
        if _safe_patch(
            CA,
            "initiate_chat",
            _make_span_wrapper(
                "autogen.agent.initiate_chat",
                {
                    "framework": "autogen",
                    "component": "agent",
                    "operation": "initiate_chat",
                },
            ),
            "autogen.ConversableAgent",
        ):
            patched.append("autogen.ConversableAgent.initiate_chat")
    except Exception as exc:  # noqa: BLE001
        logger.debug("autogen initiate_chat hook skipped: %s", exc)

    return patched


# ─── LlamaIndex hooks ────────────────────────────────────────────────────────

def _apply_llama_index_hooks() -> List[str]:
    """
    Patch ``BaseQueryEngine.query`` / ``aquery`` and ``BaseChatEngine.chat`` / ``achat``.

    ``llama_index`` layout changed across releases; imports are best-effort.
    """
    patched: List[str] = []

    BaseQE: Any = None
    try:
        from llama_index.core.query_engine.base import (  # type: ignore[import-untyped]
            BaseQueryEngine as _BQE,
        )

        BaseQE = _BQE
    except Exception:  # noqa: BLE001
        try:
            from llama_index.query_engine.base import (  # type: ignore[import-untyped]
                BaseQueryEngine as _BQE,
            )

            BaseQE = _BQE
        except Exception:  # noqa: BLE001
            BaseQE = None

    if BaseQE is not None:
        try:
            if _safe_patch(
                BaseQE,
                "query",
                _make_span_wrapper(
                    "llama_index.query_engine.query",
                    {
                        "framework": "llama_index",
                        "component": "llm",
                        "operation": "query",
                    },
                ),
                "llama_index.BaseQueryEngine",
            ):
                patched.append("llama_index.BaseQueryEngine.query")
        except Exception as exc:  # noqa: BLE001
            logger.debug("llama_index query hook skipped: %s", exc)

        try:
            orig_aq = getattr(BaseQE, "aquery", None)
            if orig_aq is not None and inspect.iscoroutinefunction(orig_aq):

                def _aquery_factory(original):
                    @functools.wraps(original)
                    async def awrapper(*args, **kwargs):
                        attrs = {
                            "framework": "llama_index",
                            "component": "llm",
                            "operation": "aquery",
                        }
                        _record_framework_usage_from_attrs(attrs)
                        tracer = _get_tracer()
                        if tracer is None:
                            return await original(*args, **kwargs)
                        with tracer.start_as_current_span(
                            "llama_index.query_engine.aquery"
                        ) as span:
                            for k, v in attrs.items():
                                span.set_attribute(k, v)
                            input_val = kwargs.get("str_or_query_bundle")
                            if input_val is None and len(args) > 1:
                                input_val = args[1]
                            elif input_val is None and args:
                                input_val = args[0]
                            if input_val is not None:
                                span.set_attribute(
                                    "input.summary", _safe_str(input_val, 500)
                                )
                            t0 = time.monotonic()
                            try:
                                result = await original(*args, **kwargs)
                                span.set_attribute(
                                    "duration_ms",
                                    round((time.monotonic() - t0) * 1000, 2),
                                )
                                if result is not None:
                                    span.set_attribute(
                                        "output.summary", _safe_str(result, 500)
                                    )
                                from opentelemetry.trace import Status, StatusCode

                                span.set_status(Status(StatusCode.OK))
                                try:
                                    record_behavior_event(
                                        "llm_call",
                                        {
                                            "framework": "llama_index",
                                            "span": "llama_index.query_engine.aquery",
                                        },
                                    )
                                except Exception:  # noqa: BLE001
                                    pass
                                return result
                            except Exception as exc:
                                span.set_attribute(
                                    "duration_ms",
                                    round((time.monotonic() - t0) * 1000, 2),
                                )
                                from opentelemetry.trace import Status, StatusCode

                                span.set_status(Status(StatusCode.ERROR, str(exc)))
                                span.record_exception(exc)
                                try:
                                    from puvinoise.hooks import _auto_emit_failure
                                    _auto_emit_failure(exc, span)
                                except Exception:  # noqa: BLE001
                                    pass
                                raise

                    return awrapper

                if _safe_patch(
                    BaseQE, "aquery", _aquery_factory, "llama_index.BaseQueryEngine"
                ):
                    patched.append("llama_index.BaseQueryEngine.aquery")
        except Exception as exc:  # noqa: BLE001
            logger.debug("llama_index aquery hook skipped: %s", exc)

    BaseCE: Any = None
    try:
        from llama_index.core.chat_engine.types import (  # type: ignore[import-untyped]
            BaseChatEngine as _BCE,
        )

        BaseCE = _BCE
    except Exception:  # noqa: BLE001
        try:
            from llama_index.core.base.base_chat_engine import (  # type: ignore[import-untyped]
                BaseChatEngine as _BCE,
            )

            BaseCE = _BCE
        except Exception:  # noqa: BLE001
            BaseCE = None

    if BaseCE is not None:
        try:
            if _safe_patch(
                BaseCE,
                "chat",
                _make_span_wrapper(
                    "llama_index.chat_engine.chat",
                    {
                        "framework": "llama_index",
                        "component": "llm",
                        "operation": "chat",
                    },
                ),
                "llama_index.BaseChatEngine",
            ):
                patched.append("llama_index.BaseChatEngine.chat")
        except Exception as exc:  # noqa: BLE001
            logger.debug("llama_index chat hook skipped: %s", exc)

    return patched


def _warn_if_detected_without_instrumentation(
    frameworks: Dict[str, bool],
    all_patched: List[str],
) -> None:
    """Log when ``detect_frameworks`` reports a package present but no hook patched."""
    for label, present in frameworks.items():
        if not present:
            continue
        if any(p.startswith(f"{label}.") for p in all_patched):
            continue
        logger.warning(
            "Framework detected but no instrumentation available: %s",
            label,
        )


# ─── Behavior-based fallback (CRITICAL) ─────────────────────────────────────

# Rolling in-process buffer (per OS process ≈ one agent worker). Thread-safe.
# Detects LLM→tool→LLM patterns even when no known framework is present.

_BEHAVIOR_LOCK = threading.Lock()
_BEHAVIOR_BUFFER: List[Dict[str, Any]] = []
_BEHAVIOR_BUFFER_MAX = 100
_BEHAVIOR_EVENT_COUNT: int = 0
_BEHAVIOR_CLASSIFICATION: Optional[str] = None
_BEHAVIOR_CONFIDENCE: Optional[str] = None
# True after classify_behavior_pattern() or an automatic _run_classification_locked().
_BEHAVIOR_CLASSIFIER_HAS_RUN: bool = False


def _behavior_classify_interval() -> int:
    """Events between automatic classifications (env: PUVINOISE_BEHAVIOR_CLASSIFY_INTERVAL, default 8)."""
    try:
        v = int(
            os.environ.get("PUVINOISE_BEHAVIOR_CLASSIFY_INTERVAL")
            or os.environ.get("PUVINOISE_BEHAVIOR_CLASSIFY_INTERVAL", "8")
        )
    except ValueError:
        v = 8
    return max(3, min(100, v))


def _confidence_for(classification: str) -> str:
    if classification == "agent_workflow_detected":
        return "high"
    if classification == "single_llm_call":
        return "medium"
    if classification == "tool_only":
        return "low"
    return "low"


def _classify_from_buffer(buf: List[Dict[str, Any]]) -> str:
    """
    Core classifier over a snapshot of the buffer (caller holds lock or uses a copy).
    """
    if not buf:
        return "unknown"

    types_seen = {e["type"] for e in buf}
    type_sequence = [e["type"] for e in buf]

    has_llm = "llm_call" in types_seen
    has_tool = "tool_call" in types_seen
    has_memory = "memory_op" in types_seen

    if has_llm and (has_tool or has_memory):
        for i in range(len(type_sequence) - 2):
            if type_sequence[i] == "llm_call" and type_sequence[i + 2] == "llm_call":
                if type_sequence[i + 1] in ("tool_call", "memory_op"):
                    return "agent_workflow_detected"
        if len(buf) >= 3:
            return "agent_workflow_detected"

    if has_llm and not has_tool:
        llm_count = sum(1 for e in buf if e["type"] == "llm_call")
        return "single_llm_call" if llm_count == 1 else "agent_workflow_detected"

    if has_tool and not has_llm:
        return "tool_only"

    return "unknown"


def _attach_behavior_to_span(classification: str, confidence: str) -> None:
    try:
        from opentelemetry import trace

        span = trace.get_current_span()
        if span is not None and span.is_recording():
            span.set_attribute("puvi.behavior", classification)
            span.set_attribute("puvi.confidence", confidence)
    except Exception:  # noqa: BLE001
        pass


def _run_classification_locked() -> None:
    """Update last classification/confidence and attach to the active span. Lock held."""
    global _BEHAVIOR_CLASSIFICATION, _BEHAVIOR_CONFIDENCE, _BEHAVIOR_CLASSIFIER_HAS_RUN

    _BEHAVIOR_CLASSIFIER_HAS_RUN = True
    cls = _classify_from_buffer(_BEHAVIOR_BUFFER)
    conf = _confidence_for(cls)
    _BEHAVIOR_CLASSIFICATION = cls
    _BEHAVIOR_CONFIDENCE = conf
    _attach_behavior_to_span(cls, conf)


def record_behavior_event(event_type: str, meta: Optional[Dict[str, Any]] = None) -> None:
    """
    Record a raw behavior event into the rolling buffer.

    event_type is one of: "llm_call", "tool_call", "memory_op", "step".
    Periodically runs classification and sets ``puvi.behavior`` / ``puvi.confidence``
    on the current OTEL span when applicable.
    """
    global _BEHAVIOR_EVENT_COUNT

    entry = {"type": event_type, "ts": time.monotonic()}
    if meta:
        entry.update(meta)

    with _BEHAVIOR_LOCK:
        _BEHAVIOR_BUFFER.append(entry)
        if len(_BEHAVIOR_BUFFER) > _BEHAVIOR_BUFFER_MAX:
            _BEHAVIOR_BUFFER.pop(0)
        _BEHAVIOR_EVENT_COUNT += 1

        n = len(_BEHAVIOR_BUFFER)
        interval = _behavior_classify_interval()
        cnt = _BEHAVIOR_EVENT_COUNT
        should_classify = n >= 3 and (cnt == 3 or (cnt % interval == 0))

        if should_classify:
            _run_classification_locked()


def classify_behavior_pattern() -> str:
    """
    Analyse the behavior buffer and return a classification:
      - "agent_workflow_detected"  — LLM→tool→LLM or multi-step pattern found
      - "single_llm_call"         — one LLM call, no agent loop
      - "tool_only"               — tool calls but no LLM calls
      - "unknown"                 — insufficient data

    Thread-safe. Does not set span attributes; use the automatic path via
    ``record_behavior_event`` or ``signal_behavior_workflow_complete`` for that.
    Marks the classifier as run for :func:`puvinoise.framework_detection.effective_detection_mode`.
    """
    global _BEHAVIOR_CLASSIFIER_HAS_RUN

    with _BEHAVIOR_LOCK:
        _BEHAVIOR_CLASSIFIER_HAS_RUN = True
        return _classify_from_buffer(list(_BEHAVIOR_BUFFER))


def behavior_classifier_has_run() -> bool:
    """True once :func:`classify_behavior_pattern` or automatic classification has executed."""
    with _BEHAVIOR_LOCK:
        return _BEHAVIOR_CLASSIFIER_HAS_RUN


def signal_behavior_workflow_complete() -> None:
    """
    Run classification once after a logical workflow ends (e.g. graph run finished).
    Optional; automatic classification also runs on a fixed event interval.
    """
    with _BEHAVIOR_LOCK:
        if len(_BEHAVIOR_BUFFER) < 2:
            return
        _run_classification_locked()


def get_behavior_snapshot() -> Dict[str, str]:
    """Last classification and confidence (thread-safe). Unknown/low before first classify."""
    with _BEHAVIOR_LOCK:
        cls = _BEHAVIOR_CLASSIFICATION
        conf = _BEHAVIOR_CONFIDENCE
    return {
        "classification": cls if cls else "unknown",
        "confidence": conf if conf else "low",
    }


def sync_behavior_env_from_runtime() -> None:
    """Mirror behavior snapshot into ``PUVINOISE_BEHAVIOR_*`` for registration / heartbeat."""
    snap = get_behavior_snapshot()
    os.environ["PUVINOISE_BEHAVIOR_CLASSIFICATION"] = snap["classification"]
    os.environ["PUVINOISE_BEHAVIOR_CONFIDENCE"] = snap["confidence"]


def _apply_behavior_fallback() -> List[str]:
    """
    Wire the behavior-event recording into the existing LLM/tool hook system
    from hooks.py.  This ensures that EVEN WITHOUT a known framework, every
    LLM call and tool call is captured for pattern classification.

    We do this by patching the existing enable_auto_instrumentation() result
    path — after the LLM hooks fire, they also record a behavior event.
    """
    patched: List[str] = []

    # Patch the OpenAI/Anthropic hooks (if they exist) to also emit behavior events.
    # This extends the existing hooks.py auto-instrumentation with behavior tracking.
    try:
        # OpenAI chat completions — sync client
        from openai.resources.chat.completions import Completions  # type: ignore[import-untyped]
        _original_create = getattr(Completions, "create", None)
        if _original_create and not getattr(_original_create, "_puvinoise_behavior_tracked", False):
            @functools.wraps(_original_create)
            def _openai_with_behavior(*args, **kwargs):
                record_behavior_event("llm_call", {"provider": "openai"})
                return _original_create(*args, **kwargs)
            try:
                _openai_with_behavior._puvinoise_behavior_tracked = True
                # Preserve existing instrumentation sentinel
                if getattr(_original_create, "_puvinoise_instrumented", False):
                    _openai_with_behavior._puvinoise_instrumented = True
            except (AttributeError, TypeError):
                pass
            Completions.create = _openai_with_behavior
            patched.append("openai.behavior_tracker")
    except Exception:  # noqa: BLE001
        pass

    try:
        # OpenAI chat completions — async client (AsyncOpenAI).
        # Agents using `await client.chat.completions.create(...)` go through
        # AsyncCompletions, not Completions.  Without this patch, behavior events
        # are never recorded and LLM spans are never counted for async agents.
        from openai.resources.chat.completions import AsyncCompletions  # type: ignore[import-untyped]
        _original_async_create = getattr(AsyncCompletions, "create", None)
        if _original_async_create and not getattr(_original_async_create, "_puvinoise_behavior_tracked", False):
            @functools.wraps(_original_async_create)
            async def _openai_async_with_behavior(*args, **kwargs):
                record_behavior_event("llm_call", {"provider": "openai"})
                return await _original_async_create(*args, **kwargs)
            try:
                _openai_async_with_behavior._puvinoise_behavior_tracked = True
                if getattr(_original_async_create, "_puvinoise_instrumented", False):
                    _openai_async_with_behavior._puvinoise_instrumented = True
            except (AttributeError, TypeError):
                pass
            AsyncCompletions.create = _openai_async_with_behavior
            patched.append("openai.async_behavior_tracker")
    except Exception:  # noqa: BLE001
        pass

    # Anthropic
    try:
        from anthropic.resources.messages import Messages  # type: ignore[import-untyped]
        _original_anthro_create = getattr(Messages, "create", None)
        if _original_anthro_create and not getattr(_original_anthro_create, "_puvinoise_behavior_tracked", False):
            @functools.wraps(_original_anthro_create)
            def _anthropic_with_behavior(*args, **kwargs):
                record_behavior_event("llm_call", {"provider": "anthropic"})
                return _original_anthro_create(*args, **kwargs)
            try:
                _anthropic_with_behavior._puvinoise_behavior_tracked = True
                if getattr(_original_anthro_create, "_puvinoise_instrumented", False):
                    _anthropic_with_behavior._puvinoise_instrumented = True
            except (AttributeError, TypeError):
                pass
            Messages.create = _anthropic_with_behavior
            patched.append("anthropic.behavior_tracker")
    except Exception:  # noqa: BLE001
        pass

    return patched


# ─── Main entry point ────────────────────────────────────────────────────────

def apply_instrumentation(detection_result: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Apply all applicable instrumentation hooks.

    Called by ``puvinoise.init()`` after framework detection.

    Args:
        detection_result: output of ``framework_detection.detect_all()``.
                          If None, detection is run inline.

    Returns::

        {
            "patched": ["langchain.Chain.invoke", ...],
            "framework": "langchain",
            "detection_mode": "library",
            "behavior_fallback": True,
        }
    """
    global _INSTRUMENTATION_DONE

    if _INSTRUMENTATION_DONE:
        logger.debug("framework_instrumentation: already applied — skipping")
        from puvinoise.framework_detection import effective_detection_mode
        from puvinoise.framework_usage import get_runtime_primary_framework

        fw_label, _ = get_runtime_primary_framework()
        return {
            "patched": list(_PATCHED_TARGETS),
            "framework": fw_label,
            "detection_mode": effective_detection_mode(),
            "behavior_fallback": True,
        }

    if detection_result is None:
        from puvinoise.framework_detection import detect_all
        detection_result = detect_all()

    frameworks = detection_result.get("frameworks", {})
    all_patched: List[str] = []

    # Apply framework-specific hooks for each detected framework.
    if frameworks.get("langchain"):
        all_patched.extend(_apply_langchain_hooks())

    if frameworks.get("langgraph"):
        all_patched.extend(_apply_langgraph_hooks())

    if frameworks.get("crewai"):
        all_patched.extend(_apply_crewai_hooks())

    if frameworks.get("autogen"):
        all_patched.extend(_apply_autogen_hooks())

    if frameworks.get("llama_index"):
        all_patched.extend(_apply_llama_index_hooks())

    # ALWAYS apply behavior fallback — this is the critical path for unknown
    # frameworks and for enriching known framework telemetry.
    behavior_patched = _apply_behavior_fallback()
    all_patched.extend(behavior_patched)

    _warn_if_detected_without_instrumentation(frameworks, all_patched)

    _INSTRUMENTATION_DONE = True

    from puvinoise.framework_detection import effective_detection_mode
    from puvinoise.framework_usage import get_runtime_primary_framework

    fw_label, _ = get_runtime_primary_framework()
    result = {
        "patched": all_patched,
        "framework": fw_label,
        "detection_mode": effective_detection_mode(),
        "behavior_fallback": True,
    }

    logger.info(
        "framework_instrumentation: applied %d hooks (framework=%s, mode=%s)",
        len(all_patched), result["framework"], result["detection_mode"],
    )
    return result


def reset_instrumentation() -> None:
    """Reset instrumentation state (for tests only)."""
    global _INSTRUMENTATION_DONE, _PATCHED_TARGETS, _BEHAVIOR_BUFFER, _BEHAVIOR_CLASSIFICATION
    global _BEHAVIOR_CONFIDENCE, _BEHAVIOR_EVENT_COUNT, _BEHAVIOR_CLASSIFIER_HAS_RUN
    _INSTRUMENTATION_DONE = False
    _PATCHED_TARGETS = []
    with _BEHAVIOR_LOCK:
        _BEHAVIOR_BUFFER = []
        _BEHAVIOR_EVENT_COUNT = 0
        _BEHAVIOR_CLASSIFICATION = None
        _BEHAVIOR_CONFIDENCE = None
        _BEHAVIOR_CLASSIFIER_HAS_RUN = False


def get_patched_targets() -> List[str]:
    """Return the list of methods that were patched by apply_instrumentation()."""
    return list(_PATCHED_TARGETS)


def get_behavior_buffer() -> List[Dict[str, Any]]:
    """Return a copy of the behavior event buffer (for testing/debugging)."""
    with _BEHAVIOR_LOCK:
        return list(_BEHAVIOR_BUFFER)
