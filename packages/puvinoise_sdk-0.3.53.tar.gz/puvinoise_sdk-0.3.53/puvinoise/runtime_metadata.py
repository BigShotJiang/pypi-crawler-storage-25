"""
Runtime metadata collection for PUVINoise Agent Admin UI.
Collected at SDK init and attached to all telemetry events.
"""

import os
import sys
import socket
from typing import Any, Dict, Optional

from puvinoise.env_keys import get_agent_id
from puvinoise.env_resolve import env_var

_RUNTIME_METADATA: Optional[Dict[str, Any]] = None


def _detect_sdk_language() -> str:
    """Detect SDK language (python/node/java). This SDK is Python."""
    return "python"


def _detect_sdk_version() -> str:
    """SDK package version."""
    try:
        from importlib.metadata import version as _version
        return str(_version("puvinoise-sdk")).strip()
    except Exception:
        try:
            from puvinoise import __version__
            return str(__version__).strip()
        except Exception:
            return "0.0.0"


def _detect_runtime() -> str:
    """Runtime version (e.g. Python 3.12.0)."""
    return f"{sys.implementation.name} {sys.version.split()[0]}".strip()


def _detect_host() -> str:
    """Host name."""
    try:
        return socket.gethostname() or ""
    except Exception:
        return ""


def _detect_instance_id() -> str:
    """
    Container / process identity (pod name, task id, etc.).
    Prefer explicit PUVINOISE_INSTANCE_ID; then common orchestration env vars; else empty.
    """
    for key in ("PUVINOISE_INSTANCE_ID", "KUBERNETES_POD_UID", "ECS_TASK_ARN"):
        v = (os.getenv(key) or "").strip()
        if v:
            return v[:256]
    hn = (os.getenv("HOSTNAME") or "").strip()
    if hn:
        return hn[:256]
    return ""


def collect_runtime_metadata(agent_id: Optional[str] = None, agent_name: Optional[str] = None) -> Dict[str, Any]:
    """
    Build runtime metadata from env and auto-detection.
    Called during SDK bootstrap.
    """
    global _RUNTIME_METADATA
    agent_id = (agent_id or get_agent_id() or "").strip()
    agent_name = (agent_name or env_var("PUVINOISE_AGENT_NAME")).strip()
    # Canonical source is PUVINOISE_DEPLOY_ENV.
    # DEPLOYMENT_ENV is backward-compat fallback only.
    deploy_env = env_var("PUVINOISE_DEPLOY_ENV")
    if not deploy_env:
        deploy_env = (os.getenv("DEPLOYMENT_ENV") or "").strip()
    deploy_version = env_var("PUVINOISE_DEPLOY_VERSION")
    region = env_var("PUVINOISE_REGION")
    instance_id = env_var("PUVINOISE_INSTANCE_ID").strip() or _detect_instance_id()
    sdk_language = env_var("PUVINOISE_SDK_LANGUAGE") or _detect_sdk_language()
    sdk_version = env_var("PUVINOISE_SDK_VERSION") or _detect_sdk_version()

    _RUNTIME_METADATA = {
        "agent_id": agent_id or "",
        "agent_name": agent_name or "",
        "sdk_language": sdk_language,
        "sdk_version": sdk_version,
        "deploy_env": deploy_env or "",
        "deploy_version": deploy_version or "",
        "environment": deploy_env or "",
        "runtime": _detect_runtime(),
        "host": _detect_host(),
        "region": region or None,
        "instance_id": instance_id or "",
    }
    return _RUNTIME_METADATA


def get_runtime_metadata() -> Dict[str, Any]:
    """Return the current runtime metadata (from last collect). If never collected, collect now."""
    global _RUNTIME_METADATA
    if _RUNTIME_METADATA is None:
        collect_runtime_metadata()
    return dict(_RUNTIME_METADATA or {})


def set_runtime_metadata(metadata: Dict[str, Any]) -> None:
    """Override stored runtime metadata (e.g. for tests)."""
    global _RUNTIME_METADATA
    _RUNTIME_METADATA = dict(metadata) if metadata else None


def ensure_runtime_metadata_env(
    agent_name_default: str = "",
    deploy_env_default: str = "development",
    deploy_version_default: str = "",
) -> None:
    """
    Set PUVINOISE_* environment variables with setdefault so .env can override.
    Call this before bootstrap() in production, test, and demo agents so runtime
    metadata is collected and attached to all telemetry events.
    """
    name = env_var("PUVINOISE_AGENT_NAME").strip()
    if name:
        os.environ.setdefault("PUVINOISE_AGENT_NAME", name)
    # Do not set PUVINOISE_AGENT_ID to the display name — canonical agt_* id comes from
    # POST /api/agent-register (persisted to .puvinoise/agent_<id>.json by agent_autoregister).
    if deploy_env_default:
        os.environ.setdefault("PUVINOISE_DEPLOY_ENV", deploy_env_default)
    if deploy_version_default:
        os.environ.setdefault("PUVINOISE_DEPLOY_VERSION", deploy_version_default)
    os.environ.setdefault("PUVINOISE_INSTANCE_ID", "")
