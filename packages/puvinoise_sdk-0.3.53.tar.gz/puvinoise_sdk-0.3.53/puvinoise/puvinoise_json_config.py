"""
Centralized resolution and logging for PUVINoise JSON identity files.

All agent/environment JSON is read ONLY from::

    <project_root>/.puvinoise/

Optional per-environment files (when ``env_name`` is set on agent state)::

    <project_root>/.puvinoise/environments/<env_name>.json

where *project_root* is the supplied working directory, defaulting to
``os.getcwd()`` — **no parent-directory walk**, no environment-variable
overrides for JSON paths, no reads from the repository root outside
``.puvinoise/``.

``.env.puvinoise`` (dotenv) is handled elsewhere; this module is **JSON only**.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("puvinoise.json_config")

LOG_PREFIX = "[puvinoise]"

# Directory name under project root (single source for all JSON state).
PUVINOISE_SUBDIR = ".puvinoise"
ENVIRONMENTS_SUBDIR = "environments"
ENV_JSON_FILENAME = "env.json"
AGENT_JSON_GLOB = "agent_*.json"

_probe_logged = False
_env_missing_logged = False
_agent_missing_logged = False


def resolve_project_root(cwd: Optional[Path] = None) -> Path:
    """Absolute project root (directory that contains ``.puvinoise/``)."""
    base = Path.cwd() if cwd is None else Path(cwd)
    return base.resolve()


def resolve_puvinoise_dir(cwd: Optional[Path] = None) -> Path:
    """``<project_root>/.puvinoise`` — may or may not exist."""
    return resolve_project_root(cwd) / PUVINOISE_SUBDIR


def log_loading_config_from_puvinoise(cwd: Optional[Path] = None) -> None:
    """
    One-time informational log when the SDK first probes JSON config location.

    Does not create the directory. Safe when absent (degraded mode).
    """
    global _probe_logged
    if _probe_logged:
        return
    _probe_logged = True
    d = resolve_puvinoise_dir(cwd)
    print(f"{LOG_PREFIX} Loading config from {d}/")
    if d.is_dir():
        print(f"{LOG_PREFIX} Found .puvinoise directory")
    else:
        print(f"{LOG_PREFIX} .puvinoise/ not found (continuing without local JSON config)")


def list_agent_json_paths(cwd: Optional[Path] = None) -> List[Path]:
    """Sorted ``agent_*.json`` paths under ``.puvinoise/``; empty if missing."""
    state_dir = resolve_puvinoise_dir(cwd)
    if not state_dir.is_dir():
        return []
    return sorted(state_dir.glob(AGENT_JSON_GLOB))


def env_json_path(cwd: Optional[Path] = None) -> Path:
    """Path to ``.puvinoise/env.json`` (may not exist)."""
    return resolve_puvinoise_dir(cwd) / ENV_JSON_FILENAME


def _sanitize_env_name_segment(env_name: str) -> str:
    """Strip and make *env_name* safe as a single path segment (no dirs)."""
    s = (env_name or "").strip().replace("/", "_").replace("\\", "_")
    return s


def environment_json_path(env_name: str, cwd: Optional[Path] = None) -> Path:
    """Path to ``.puvinoise/environments/<env_name>.json`` (may not exist)."""
    safe = _sanitize_env_name_segment(env_name)
    return resolve_puvinoise_dir(cwd) / ENVIRONMENTS_SUBDIR / f"{safe}.json"


def read_json_dict(path: Path) -> Dict[str, Any]:
    """Parse JSON object from *path*; empty dict on missing/malformed (no throw)."""
    try:
        if not path.is_file():
            return {}
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except Exception as exc:  # noqa: BLE001
        logger.debug("json_config: failed to read %s: %s", path, exc)
    return {}


def load_env_json_if_present(cwd: Optional[Path] = None) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load ``.puvinoise/env.json`` if it exists.

    Returns ``({}, None)`` when absent or unreadable — no exception.
    """
    log_loading_config_from_puvinoise(cwd)
    path = env_json_path(cwd)
    global _env_missing_logged
    if not path.is_file():
        if not _env_missing_logged:
            _env_missing_logged = True
            print(f"{LOG_PREFIX} Env config not found (continuing)")
        return {}, None
    data = read_json_dict(path)
    if data:
        print(f"{LOG_PREFIX} Env config loaded from {path.name}")
        logger.info("json_config: loaded env.json from %s", path)
        return data, path
    print(f"{LOG_PREFIX} Env config present but empty or invalid (continuing)")
    return {}, None


def load_environment_json(env_name: str, cwd: Optional[Path] = None) -> Dict[str, Any]:
    """
    Load ``.puvinoise/environments/<env_name>.json`` when present.

    Returns ``{}`` if *env_name* is empty, the file is missing, or JSON is not a
    usable object — never raises.
    """
    label = (env_name or "").strip()
    if not label:
        return {}

    safe = _sanitize_env_name_segment(label)
    if not safe:
        return {}

    path = environment_json_path(label, cwd)
    if not path.is_file():
        print(
            f"{LOG_PREFIX} environment '{label}' not found under .puvinoise/environments/"
        )
        print(f"{LOG_PREFIX} environment config not found (continuing)")
        return {}

    data = read_json_dict(path)
    if data:
        print(f"{LOG_PREFIX} environment config loaded")
        logger.info("json_config: loaded environments/%s.json", safe)
        return data

    print(f"{LOG_PREFIX} environment config not found (continuing)")
    return {}


def _maybe_load_environment_for_agent(agent_data: Dict[str, Any], cwd: Optional[Path]) -> None:
    """If agent JSON includes ``env_name``, load matching file under ``environments/``."""
    envn = str(agent_data.get("env_name") or "").strip()
    if not envn:
        return
    print(f"{LOG_PREFIX} env_name={envn}")
    load_environment_json(envn, cwd)


def load_agent_json_first(
    cwd: Optional[Path] = None,
    *,
    exact_agent_id: Optional[str] = None,
) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load the first matching ``agent_*.json`` under ``.puvinoise/``.

    If *exact_agent_id* is set, tries ``agent_<id>.json`` first.
    If several ``agent_*.json`` exist, logs a warning and uses the first in sorted order.
    """
    log_loading_config_from_puvinoise(cwd)
    state_dir = resolve_puvinoise_dir(cwd)
    global _agent_missing_logged
    if not state_dir.is_dir():
        if not _agent_missing_logged:
            _agent_missing_logged = True
            print(f"{LOG_PREFIX} Agent config: .puvinoise/ missing (continuing)")
        return {}, None

    if exact_agent_id:
        safe_id = (exact_agent_id or "").strip().replace("/", "_").replace("\\", "_")
        exact = state_dir / f"agent_{safe_id}.json"
        if exact.is_file():
            data = read_json_dict(exact)
            if data:
                print(f"{LOG_PREFIX} Agent config loaded from {exact.name}")
                logger.info("json_config: loaded agent state from %s", exact)
                _maybe_load_environment_for_agent(data, cwd)
                return data, exact

    files = sorted(state_dir.glob(AGENT_JSON_GLOB))
    if not files:
        if not _agent_missing_logged:
            _agent_missing_logged = True
            print(f"{LOG_PREFIX} Agent config not found (no agent_*.json in .puvinoise/)")
        return {}, None
    if len(files) > 1:
        names = ", ".join(f.name for f in files)
        msg = (
            f"{LOG_PREFIX} WARNING: multiple agent JSON files in {state_dir}: {names} — "
            f"using {files[0].name}"
        )
        print(msg)
        logger.warning("json_config: multiple agent_*.json; picking first: %s", files[0])

    path = files[0]
    data = read_json_dict(path)
    if data:
        print(f"{LOG_PREFIX} Agent config loaded from {path.name}")
        logger.info("json_config: loaded agent state from %s", path)
        _maybe_load_environment_for_agent(data, cwd)
        return data, path
    print(f"{LOG_PREFIX} Agent config file unreadable (continuing)")
    return {}, None


__all__ = [
    "LOG_PREFIX",
    "PUVINOISE_SUBDIR",
    "ENVIRONMENTS_SUBDIR",
    "ENV_JSON_FILENAME",
    "AGENT_JSON_GLOB",
    "resolve_project_root",
    "resolve_puvinoise_dir",
    "log_loading_config_from_puvinoise",
    "list_agent_json_paths",
    "env_json_path",
    "environment_json_path",
    "read_json_dict",
    "load_env_json_if_present",
    "load_environment_json",
    "load_agent_json_first",
]
