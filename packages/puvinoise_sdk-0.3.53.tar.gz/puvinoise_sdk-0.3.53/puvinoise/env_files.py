"""
PUVINoise agent env-file resolution (branded naming + backward compat).

Canonical filename: ``.env.puvinoise`` (lives in the agent working directory).

Historical filename: ``.env`` — still accepted as a read-time fallback and
still written-to if it exists when the sidecar refreshes bootstrap config,
so in-place EC2 / VM deployments keep working across the rename.

Override with ``PUVINOISE_ENV_FILE=/abs/or/rel/path`` when you need to force
a specific file (useful for CI, tests, or containerized agents that mount the
env from outside the workdir).

Public API:

    resolve_read_env_path(workdir)   → existing file (branded preferred, legacy fallback) or None
    canonical_env_path(workdir)      → branded write target (``.env.puvinoise`` by default)
    legacy_env_path(workdir)         → legacy write mirror (``.env``) — used when it already exists

Keep this file dependency-free — it is imported from bootstrap, runtime, CLI,
and the server-side sidecar mirror. Adding third-party imports here will
break environments where the SDK was extracted without its deps.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

BRANDED_NAME = ".env.puvinoise"
LEGACY_NAME = ".env"
ENV_FILE_OVERRIDE = "PUVINOISE_ENV_FILE"


def _override_path(workdir: Path) -> Optional[Path]:
    raw = os.environ.get(ENV_FILE_OVERRIDE, "").strip()
    if not raw:
        return None
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = (workdir / p).resolve()
    return p


def canonical_env_path(workdir: Path) -> Path:
    """
    Return the *branded* env-file path for this workdir.

    Honors ``PUVINOISE_ENV_FILE`` if set — otherwise returns
    ``<workdir>/.env.puvinoise``. Does NOT check existence; callers that need
    an existence check should use ``resolve_read_env_path`` instead.
    """
    override = _override_path(workdir)
    if override is not None:
        return override
    return Path(workdir) / BRANDED_NAME


def legacy_env_path(workdir: Path) -> Path:
    """Return the legacy ``<workdir>/.env`` path (unconditional, no existence check)."""
    return Path(workdir) / LEGACY_NAME


def resolve_read_env_path(workdir: Path) -> Optional[Path]:
    """
    Return the first existing env file for this workdir, preferring the
    branded name. Returns ``None`` if neither file exists and no override
    points to an existing file.
    """
    override = _override_path(workdir)
    if override is not None and override.exists():
        return override
    branded = Path(workdir) / BRANDED_NAME
    if branded.exists():
        return branded
    legacy = Path(workdir) / LEGACY_NAME
    if legacy.exists():
        return legacy
    return None


def resolve_env_path_for_tools(workdir: Path) -> Path:
    """
    Best-effort env-file path for diagnostic/CLI callers that want to show
    "where the SDK would look". Falls back to the canonical branded path
    when neither file exists yet.
    """
    return resolve_read_env_path(workdir) or canonical_env_path(workdir)


__all__ = [
    "BRANDED_NAME",
    "LEGACY_NAME",
    "ENV_FILE_OVERRIDE",
    "canonical_env_path",
    "legacy_env_path",
    "resolve_read_env_path",
    "resolve_env_path_for_tools",
]
