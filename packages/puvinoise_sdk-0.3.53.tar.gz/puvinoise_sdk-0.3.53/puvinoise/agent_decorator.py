"""
agent_decorator.py — @puvinoise.agent decorator

Provides the @puvinoise.agent decorator that the GitHub integration scanner
looks for as a first-class signal of agent entrypoints.

Usage
-----
Function-based agent::

    import puvinoise

    @puvinoise.agent(name="my-agent", model_provider="openai")
    def run_agent(user_input: str) -> str:
        ...
        return response

Class-based agent (wraps .run / .invoke)::

    @puvinoise.agent(name="my-agent", model_provider="anthropic", environment="production")
    class MyAgent:
        def run(self, input: str) -> str:
            ...

Bare usage without parentheses (uses class/function name)::

    @puvinoise.agent
    def my_agent(input):
        ...

All forms are equivalent to calling ``puvinoise.wrapAgent()`` with the same
kwargs.  The decorator also records three span attributes so the platform can
read the agent name and provider during trace normalisation without requiring
a full OTLP import:

    puvinoise.agent_name   ← name kwarg (or class/function __name__)
    puvinoise.model_provider ← model_provider kwarg (or None)
    puvinoise.environment    ← environment kwarg (or PUVINOISE_DEPLOY_ENV env var)

The ``@puvinoise.agent`` string is also what the GitHub codebase scanner
(server/lib/github-integration.js) uses as its primary agent-discovery marker.
"""

from __future__ import annotations

import functools
import os
from typing import Any, Callable, Optional, TypeVar, Union, overload

F = TypeVar("F", bound=Callable[..., Any])


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def _infer_name(obj: Any, override: Optional[str] = None) -> str:
    if override:
        return str(override).strip()
    if hasattr(obj, "__name__") and obj.__name__:
        return str(obj.__name__).strip()
    if hasattr(obj, "__class__") and obj.__class__.__name__:
        return obj.__class__.__name__.strip()
    return "agent"


def _apply_wrap(
    target: Any,
    *,
    name: Optional[str],
    model_provider: Optional[str],
    environment: Optional[str],
    session_id: Optional[str],
    goal: Optional[str],
    intent: Optional[str],
    wrap_tools: bool,
) -> Any:
    """Apply wrapAgent with the resolved attributes and embed span tags."""
    from puvinoise.agent_wrapper import wrapAgent  # local import avoids circular dep

    resolved_name = _infer_name(target, name)
    resolved_env = environment or os.environ.get("PUVINOISE_DEPLOY_ENV") or os.environ.get("PUVINOISE_DEPLOY_ENV")

    # Record decorator metadata into OpenTelemetry span attributes.
    # This is best-effort; if tracer is not started yet it is a no-op.
    try:
        from puvinoise.hooks import add_span_attribute
        if resolved_name:
            add_span_attribute("puvinoise.agent_name", resolved_name)
        if model_provider:
            add_span_attribute("puvinoise.model_provider", str(model_provider))
        if resolved_env:
            add_span_attribute("puvinoise.environment", str(resolved_env))
    except Exception:
        pass

    return wrapAgent(
        target,
        agent_name=resolved_name,
        goal=goal,
        intent=intent,
        session_id=session_id,
        wrap_tools=wrap_tools,
    )


# --------------------------------------------------------------------------
# Decorator factory
# --------------------------------------------------------------------------

@overload
def agent(func: F) -> F: ...  # bare: @puvinoise.agent

@overload
def agent(
    *,
    name: Optional[str] = None,
    model_provider: Optional[str] = None,
    environment: Optional[str] = None,
    session_id: Optional[str] = None,
    goal: Optional[str] = None,
    intent: Optional[str] = None,
    wrap_tools: bool = True,
) -> Callable[[F], F]: ...  # with kwargs: @puvinoise.agent(name="x")


def agent(
    _target: Optional[Any] = None,
    *,
    name: Optional[str] = None,
    model_provider: Optional[str] = None,
    environment: Optional[str] = None,
    session_id: Optional[str] = None,
    goal: Optional[str] = None,
    intent: Optional[str] = None,
    wrap_tools: bool = True,
) -> Any:
    """
    Decorator that marks a function or class as a PUVINoise-instrumented agent
    and wraps it with automatic telemetry via ``wrapAgent()``.

    Supports both bare usage ``@puvinoise.agent`` and parametrised usage
    ``@puvinoise.agent(name="x", model_provider="openai")``.
    """
    wrap_kwargs = dict(
        name=name,
        model_provider=model_provider,
        environment=environment,
        session_id=session_id,
        goal=goal,
        intent=intent,
        wrap_tools=wrap_tools,
    )

    if _target is not None:
        # Bare usage: @puvinoise.agent  (no parentheses)
        return _apply_wrap(_target, **wrap_kwargs)  # type: ignore[arg-type]

    # Parametrised: @puvinoise.agent(name=...) — return the actual decorator
    def _decorator(target: F) -> F:
        return _apply_wrap(target, **wrap_kwargs)  # type: ignore[return-value]

    return _decorator


__all__ = ["agent"]
