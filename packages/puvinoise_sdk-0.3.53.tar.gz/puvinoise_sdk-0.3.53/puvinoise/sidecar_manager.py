"""
PUVINoise Sidecar Manager  — Production-Grade v2
=================================================

Cross-platform lifecycle manager for the PUVINoise sidecar binary.

Design pillars
--------------
1. PATH-free binary resolution  — bundled bin/ dir, env override, user cache.
2. Cross-process race safety    — advisory file lock prevents duplicate spawns
   from concurrent threads OR processes (e.g. gunicorn workers).
3. Attach-before-spawn          — if a sidecar already owns the port, connect
   to it instead of starting a second one (EXTERNAL / re-attach mode).
4. Binary compatibility guard   — version probe before every start attempt.
5. Structured log streaming     — stdout/stderr of the child process are drained
   by daemon threads and forwarded to a Python logger at configurable levels.
6. Diagnostics                  — `puvinoise_doctor()` surfaces actionable
   checks without requiring a running sidecar.
7. Offline/enterprise support   — auto-download checks network reachability;
   fails with an actionable message, not a timeout stack trace.

Public API (zero-config)
------------------------
    from puvinoise import start_sidecar, stop_sidecar, get_sidecar_status
    from puvinoise import puvinoise_doctor

    start_sidecar()              # idempotent; resolves binary, validates, starts
    get_sidecar_status()         # dict suitable for /health endpoints
    puvinoise_doctor()           # prints + returns diagnostic report
    stop_sidecar()               # graceful shutdown (registered with atexit)

FastAPI integration
-------------------
    from contextlib import asynccontextmanager
    from fastapi import FastAPI
    from puvinoise import start_sidecar, stop_sidecar

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        start_sidecar()         # managed mode: SDK owns lifecycle
        yield
        stop_sidecar()

    app = FastAPI(lifespan=lifespan)

Wheel packaging for multi-OS binaries
--------------------------------------
In pyproject.toml:
    [tool.hatch.build.targets.wheel]
    packages = ["puvinoise"]
    # Include pre-compiled sidecar binaries for all platforms
    include = [
        "puvinoise/bin/linux/amd64/puvinoise-sidecar",
        "puvinoise/bin/linux/arm64/puvinoise-sidecar",
        "puvinoise/bin/macos/amd64/puvinoise-sidecar",
        "puvinoise/bin/macos/arm64/puvinoise-sidecar",
        "puvinoise/bin/windows/amd64/puvinoise-sidecar.exe",
    ]

For CI/Docker multi-arch builds use cibuildwheel with a matrix per
{os, arch} so each platform wheel ships only its own binary (keeps
the download small). The pure-Python sdist triggers auto-download.
"""
from __future__ import annotations

import atexit
import logging
import os
import platform
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import threading
import time
import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

log = logging.getLogger("puvinoise.sidecar")

# ---------------------------------------------------------------------------
# Constants  (all overridable via environment variables)
# ---------------------------------------------------------------------------

SIDECAR_BINARY_NAME = "puvinoise-sidecar"

# Default gRPC / HTTP port the sidecar listens on.  Override with
# PUVI_SIDECAR_PORT.  The manager searches for the next free port if this one
# is already taken by a different process.
DEFAULT_SIDECAR_PORT: int = int(os.environ.get("PUVI_SIDECAR_PORT", "7787"))

# CDN base for auto-download fallback.  Enterprise mirrors can set
# PUVI_SIDECAR_DOWNLOAD_BASE to an internal URL.
DEFAULT_DOWNLOAD_BASE_URL: str = os.environ.get(
    "PUVI_SIDECAR_DOWNLOAD_BASE",
    "https://cdn.puvilabs.com/puvinoise/sidecar",
)

DOWNLOAD_TIMEOUT_SECS: float = 60.0

# How long to wait for the sidecar to open its port after spawn.
PORT_READY_TIMEOUT_SECS: float = float(os.environ.get("PUVI_SIDECAR_STARTUP_TIMEOUT", "10"))

# Supervisor health-check interval.
SUPERVISOR_POLL_SECS: float = 2.0

# Maximum auto-restarts before supervisor gives up.
MAX_RESTARTS_DEFAULT: int = int(os.environ.get("PUVI_SIDECAR_MAX_RESTARTS", "3"))

# Timeout for acquiring the cross-process file lock.
LOCK_ACQUIRE_TIMEOUT_SECS: float = 15.0

# ── Handshake constants ────────────────────────────────────────────────────
# Per-socket timeout for each individual HTTP call during handshake.
HANDSHAKE_TIMEOUT_PER_CALL: float = float(
    os.environ.get("PUVI_SIDECAR_HANDSHAKE_CALL_TIMEOUT", "2")
)

# Total wall-clock budget for the three-endpoint handshake sequence.
# Enforced as a shrinking deadline across all calls so one slow endpoint
# cannot silently consume the budget of the next.
HANDSHAKE_TOTAL_TIMEOUT: float = float(
    os.environ.get("PUVI_SIDECAR_HANDSHAKE_TOTAL_TIMEOUT", "5")
)

# How many full spawn → port-wait → handshake cycles to attempt before
# surfacing a SidecarHandshakeError to the caller.
HANDSHAKE_MAX_ATTEMPTS: int = int(
    os.environ.get("PUVI_SIDECAR_HANDSHAKE_RETRIES", "2")
)

# Protocol version the SDK expects the sidecar to report via GET /version.
HANDSHAKE_EXPECTED_PROTOCOL: str = os.environ.get("PUVI_SIDECAR_PROTOCOL", "v1")


# ---------------------------------------------------------------------------
# Lifecycle modes
# ---------------------------------------------------------------------------

class LifecycleMode:
    """Controls who owns the sidecar process lifetime.

    MANAGED  (default) — SDK starts, supervises, and stops the sidecar.
    EXTERNAL           — A sidecar is already running (e.g. Docker sidecar
                         container).  SDK attaches via port; never starts or
                         stops the process.
    DISABLED           — Skip sidecar entirely (pure OTLP / agent-only mode).
    """
    MANAGED  = "managed"
    EXTERNAL = "external"
    DISABLED = "disabled"


# ---------------------------------------------------------------------------
# OS / arch detection
# ---------------------------------------------------------------------------

class OSFamily:
    WINDOWS = "windows"
    MACOS   = "macos"
    LINUX   = "linux"


def detect_os() -> str:
    """Return OSFamily constant for the current host.  Raises on unsupported."""
    sysname = platform.system().lower()
    if sysname.startswith("win") or os.name == "nt":
        return OSFamily.WINDOWS
    if sysname == "darwin":
        return OSFamily.MACOS
    if sysname == "linux":
        return OSFamily.LINUX
    raise SidecarUnsupportedPlatform(
        f"Unsupported platform '{platform.system()}'. "
        "PUVINoise sidecar runs on Windows, macOS and Linux."
    )


def detect_arch() -> str:
    """Return 'amd64' or 'arm64'; falls back to raw value for clear errors."""
    m = (platform.machine() or "").lower()
    if m in ("x86_64", "amd64", "x64"):
        return "amd64"
    if m in ("arm64", "aarch64"):
        return "arm64"
    return m or "unknown"


def executable_suffix(os_family: str) -> str:
    return ".exe" if os_family == OSFamily.WINDOWS else ""


# ---------------------------------------------------------------------------
# Error hierarchy  (all subclass SidecarError for easy except-all)
# ---------------------------------------------------------------------------

class SidecarError(RuntimeError):
    """Base class — catch this to handle any sidecar problem."""

class SidecarNotFound(SidecarError):
    """Binary not found at any candidate path."""

class SidecarIncompatible(SidecarError):
    """Binary found but failed the --version probe (wrong arch / corrupt)."""

class SidecarUnsupportedPlatform(SidecarError):
    """Host OS is not in the supported matrix."""

class SidecarStartupError(SidecarError):
    """Process exited immediately or port never became ready."""

class SidecarPortConflict(SidecarError):
    """All ports in the search range are occupied."""

class SidecarOfflineError(SidecarError):
    """Auto-download attempted but network is unreachable."""

class SidecarLockTimeout(SidecarError):
    """Could not acquire the cross-process start lock in time."""

class SidecarHandshakeError(SidecarError):
    """Raised when the SDK ↔ sidecar HTTP handshake fails.

    A sidecar process may be running and listening on the port, but is not
    considered *started* until all three handshake endpoints respond correctly:
        GET /health  → {"status": "ok"}
        GET /version → {"version": "...", "protocol": "v1"}
        GET /ready   → {"ready": true}

    The error message always includes:
    - which endpoint failed
    - the response or error received
    - a suggested fix
    """


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class HandshakeResult:
    """Captured outcome of the three-endpoint SDK ↔ sidecar handshake.

    Stored on SidecarProcess and surfaced by get_sidecar_status() so that
    health endpoints can report the verified protocol and sidecar version
    rather than assumptions.
    """
    protocol:        str            # e.g. "v1" — from GET /version
    sidecar_version: str            # e.g. "0.3.7" — from GET /version
    ready:           bool           # from GET /ready
    latency_ms:      float          # wall-clock time for all three calls
    timestamp:       float          # time.time() at handshake completion


@dataclass
class SidecarProcess:
    """Handle returned by start_sidecar().  Safe to store and inspect."""
    pid:              int
    binary:           Path
    os_family:        str
    arch:             str
    port:             Optional[int]
    mode:             str
    popen:            Optional[subprocess.Popen]   # None for EXTERNAL / DISABLED
    started_at:       float = field(default_factory=time.monotonic)
    binary_version:   Optional[str] = None
    # Populated after a successful handshake; None for DISABLED mode or when
    # handshake was not performed (e.g. attach to pre-existing external sidecar
    # with skip_handshake=True).
    handshake_result: Optional[HandshakeResult] = None

    @property
    def is_running(self) -> bool:
        if self.mode == LifecycleMode.DISABLED:
            return False
        if self.mode == LifecycleMode.EXTERNAL:
            # Liveness = port check (we have no Popen handle)
            return self.port is not None and is_port_in_use(self.port)
        if self.popen is None:
            return False
        return self.popen.poll() is None

    @property
    def uptime_secs(self) -> float:
        return time.monotonic() - self.started_at


@dataclass
class DoctorCheck:
    """Result of a single doctor diagnostic step."""
    name:   str
    status: str        # "ok" | "warn" | "fail" | "skip"
    detail: str
    fix:    Optional[str] = None


@dataclass
class DoctorReport:
    """Full output of puvinoise_doctor()."""
    os_family: str
    arch:      str
    checks:    List[DoctorCheck] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(c.status != "fail" for c in self.checks)

    @property
    def failed(self) -> List[DoctorCheck]:
        return [c for c in self.checks if c.status == "fail"]

    @property
    def warnings(self) -> List[DoctorCheck]:
        return [c for c in self.checks if c.status == "warn"]


# ---------------------------------------------------------------------------
# Port management
# ---------------------------------------------------------------------------

def is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """True if something is accepting connections on host:port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        try:
            s.connect((host, port))
            return True
        except (OSError, socket.timeout):
            return False


def find_free_port(preferred: int = DEFAULT_SIDECAR_PORT, search_range: int = 50) -> int:
    """Return the first free port in [preferred, preferred+search_range).

    Uses bind() rather than connect() so we don't accidentally hit a half-open
    TCP connection.
    """
    for port in range(preferred, preferred + search_range):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise SidecarPortConflict(
        f"No free port found in range {preferred}–{preferred + search_range}. "
        f"Set PUVI_SIDECAR_PORT to a different value or free up ports."
    )


def wait_for_port(
    port: int,
    host: str = "127.0.0.1",
    timeout: float = PORT_READY_TIMEOUT_SECS,
) -> bool:
    """Poll until port is accepting connections or timeout elapses."""
    deadline = time.monotonic() + timeout
    interval = 0.05
    while time.monotonic() < deadline:
        if is_port_in_use(port, host):
            return True
        time.sleep(interval)
        interval = min(interval * 1.5, 0.5)
    return False


# ---------------------------------------------------------------------------
# Handshake — SDK ↔ sidecar contract verification
# ---------------------------------------------------------------------------

def _http_get_json(url: str, timeout: float) -> Tuple[int, Dict[str, Any]]:
    """GET *url* and return (http_status_code, parsed_body_dict).

    Uses only urllib (stdlib) — no requests, no httpx.

    Raises
    ------
    urllib.error.HTTPError   — 4xx / 5xx from the sidecar
    urllib.error.URLError    — connection refused, DNS failure
    json.JSONDecodeError     — response body is not valid JSON
    socket.timeout / OSError — per-call timeout exceeded
    """
    req = urllib.request.Request(
        url,
        headers={
            "Accept":     "application/json",
            "User-Agent": "puvinoise-sdk/handshake",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8", errors="replace")
        return resp.status, json.loads(body)


def handshake(
    port: int,
    expected_protocol: str = HANDSHAKE_EXPECTED_PROTOCOL,
    timeout_per_call: float = HANDSHAKE_TIMEOUT_PER_CALL,
    total_timeout: float = HANDSHAKE_TOTAL_TIMEOUT,
    host: str = "127.0.0.1",
) -> HandshakeResult:
    """Perform the three-endpoint SDK ↔ sidecar handshake.

    Contract
    --------
    GET /health   must return  {"status": "ok", ...}
    GET /version  must return  {"version": "<semver>", "protocol": "<id>", ...}
                               and protocol must equal expected_protocol
    GET /ready    must return  {"ready": true, ...}

    Timing
    ------
    Each call has timeout_per_call as its per-socket deadline.
    A shrinking budget from total_timeout is also enforced across all three
    calls: if /health is slow, /version and /ready get proportionally less
    time, preventing a single slow endpoint from silently absorbing the budget.

    Raises
    ------
    SidecarHandshakeError — any validation failure, HTTP error, timeout,
                            or JSON parse error.  The message always names
                            the failing endpoint, the response received, and
                            a suggested fix.
    """
    start_ts = time.monotonic()
    base_url = f"http://{host}:{port}"

    def _remaining() -> float:
        """Seconds left in total_timeout, capped to timeout_per_call."""
        elapsed = time.monotonic() - start_ts
        remaining = total_timeout - elapsed
        return min(timeout_per_call, max(0.1, remaining))

    def _get(path: str) -> Dict[str, Any]:
        """Make one GET call; translate all errors to SidecarHandshakeError."""
        url = f"{base_url}{path}"
        t = _remaining()
        try:
            _, body = _http_get_json(url, timeout=t)
            return body
        except urllib.error.HTTPError as exc:
            # Try to read the error body for richer diagnostics.
            try:
                err_body = exc.read().decode("utf-8", errors="replace")[:200]
            except Exception:
                err_body = exc.reason
            raise SidecarHandshakeError(
                f"Handshake endpoint {path!r} returned HTTP {exc.code}.\n"
                f"Response body: {err_body}\n"
                f"Fix: the sidecar binary may be outdated — run "
                f"'python -m puvinoise install-sidecar' to upgrade."
            ) from exc
        except urllib.error.URLError as exc:
            reason = getattr(exc, "reason", str(exc))
            raise SidecarHandshakeError(
                f"Handshake endpoint {path!r} unreachable at {url}: {reason}\n"
                f"Fix: confirm the sidecar is listening on port {port} "
                f"and that no firewall is blocking 127.0.0.1:{port}."
            ) from exc
        except json.JSONDecodeError as exc:
            raise SidecarHandshakeError(
                f"Handshake endpoint {path!r} returned non-JSON response: {exc}\n"
                f"Fix: ensure the sidecar version matches this SDK version."
            ) from exc
        except (OSError, TimeoutError, socket.timeout) as exc:
            raise SidecarHandshakeError(
                f"Handshake endpoint {path!r} timed out after {t:.1f}s: {exc}\n"
                f"Fix: increase PUVI_SIDECAR_HANDSHAKE_TOTAL_TIMEOUT "
                f"or check system load / resource limits."
            ) from exc

    # ── 1. /health ────────────────────────────────────────────────────────
    health_body = _get("/health")
    reported_status = str(health_body.get("status", "")).lower()
    if reported_status != "ok":
        raise SidecarHandshakeError(
            f"Handshake /health failed: expected {{\"status\": \"ok\"}}, "
            f"got status={reported_status!r}.\n"
            f"Full response: {health_body}\n"
            f"Fix: inspect sidecar stderr for startup errors "
            f"(run 'puvinoise doctor' for a full report)."
        )

    # ── 2. /version ───────────────────────────────────────────────────────
    version_body = _get("/version")
    sidecar_version = str(version_body.get("version", "unknown"))
    got_protocol    = str(version_body.get("protocol", ""))

    if got_protocol != expected_protocol:
        raise SidecarHandshakeError(
            f"Handshake /version protocol mismatch: "
            f"SDK expects protocol={expected_protocol!r}, "
            f"sidecar reports protocol={got_protocol!r}.\n"
            f"Sidecar version: {sidecar_version}\n"
            f"Fix: upgrade the sidecar binary to match this SDK — run "
            f"'python -m puvinoise install-sidecar'."
        )

    # ── 3. /ready ─────────────────────────────────────────────────────────
    ready_body = _get("/ready")
    is_ready = bool(ready_body.get("ready", False))

    if not is_ready:
        raise SidecarHandshakeError(
            f"Handshake /ready failed: sidecar not yet ready "
            f"(ready={ready_body.get('ready')!r}).\n"
            f"Full response: {ready_body}\n"
            f"Fix: increase PUVI_SIDECAR_STARTUP_TIMEOUT to give the "
            f"sidecar more time to complete initialization."
        )

    latency_ms = (time.monotonic() - start_ts) * 1000.0
    log.debug(
        "handshake complete: protocol=%s version=%s latency=%.0fms",
        got_protocol, sidecar_version, latency_ms,
    )
    return HandshakeResult(
        protocol=got_protocol,
        sidecar_version=sidecar_version,
        ready=True,
        latency_ms=latency_ms,
        timestamp=time.time(),
    )


def cleanup_sidecar(
    popen: subprocess.Popen,
    os_family: str,
    timeout: float = 5.0,
) -> None:
    """Forcibly terminate a sidecar Popen handle and clean up the PID file.

    Used by start_sidecar() after a failed handshake attempt and by tests.
    Safe to call on an already-dead process — poll() handles that case.

    Escalation: SIGTERM (or CTRL_BREAK on Windows) → wait → SIGKILL.
    """
    if popen.poll() is not None:
        # Already dead — nothing to do except clean the PID file.
        _clear_pid_file()
        return

    log.debug("cleanup_sidecar: terminating pid=%s", popen.pid)
    try:
        if os_family == OSFamily.WINDOWS:
            try:
                popen.send_signal(signal.CTRL_BREAK_EVENT)  # type: ignore[attr-defined]
            except Exception:
                popen.terminate()
        else:
            popen.terminate()

        try:
            popen.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            log.warning("cleanup_sidecar: SIGTERM timeout — sending SIGKILL (pid=%s)", popen.pid)
            popen.kill()
            popen.wait(timeout=3)
    except Exception as exc:
        log.debug("cleanup_sidecar: error during termination (ignored): %s", exc)
    finally:
        _clear_pid_file()


def _wait_for_port_release(
    port: int,
    host: str = "127.0.0.1",
    timeout: float = 3.0,
) -> None:
    """Block until the port stops accepting connections or timeout expires.

    Called between handshake retry attempts so the new spawn does not race
    with the previous process's OS-level TCP teardown.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not is_port_in_use(port, host):
            return
        time.sleep(0.1)
    log.debug(
        "_wait_for_port_release: port %s still in use after %.1fs — proceeding",
        port, timeout,
    )


# ---------------------------------------------------------------------------
# PID file helpers
# ---------------------------------------------------------------------------

def _pid_file_path() -> Path:
    return _user_cache_dir() / "puvinoise-sidecar.pid"


def _write_pid_file(pid: int) -> None:
    path = _pid_file_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(pid))


def _read_pid_file() -> Optional[int]:
    try:
        return int(_pid_file_path().read_text().strip())
    except (OSError, ValueError):
        return None


def _clear_pid_file() -> None:
    try:
        _pid_file_path().unlink()
    except OSError:
        pass


def _is_pid_alive(pid: int) -> bool:
    """Check whether a PID is alive — no external deps, works on all OSes."""
    try:
        # Works on POSIX; in Python 3 on Windows it checks process existence.
        os.kill(pid, 0)
        return True
    except PermissionError:
        # Process exists but belongs to another user.
        return True
    except (OSError, ProcessLookupError):
        return False


# ---------------------------------------------------------------------------
# Cross-process advisory file lock
# ---------------------------------------------------------------------------

class _CrossProcessLock:
    """Atomic file lock using O_CREAT | O_EXCL — no external deps.

    Works on NTFS (Windows), ext4, APFS, and tmpfs.  Not safe over NFS, but
    sidecar management always runs on localhost so that is not a concern.

    The lock file contains the owner's PID so a crashed process's stale lock
    is automatically detected and removed on the next acquire attempt.
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        self._fd: Optional[int] = None
        self._thread_lock = threading.Lock()  # guard _fd within one process

    def acquire(self, timeout: float = LOCK_ACQUIRE_TIMEOUT_SECS) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._thread_lock:
                try:
                    self._path.parent.mkdir(parents=True, exist_ok=True)
                    # O_EXCL guarantees atomicity: exactly one opener succeeds.
                    fd = os.open(
                        str(self._path),
                        os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                        0o600,
                    )
                    os.write(fd, str(os.getpid()).encode())
                    os.fsync(fd)
                    self._fd = fd
                    return True
                except FileExistsError:
                    # Existing lock — check for stale (crashed owner).
                    self._evict_stale()
            time.sleep(0.1)
        return False

    def release(self) -> None:
        with self._thread_lock:
            if self._fd is not None:
                try:
                    os.close(self._fd)
                except OSError:
                    pass
                self._fd = None
            try:
                self._path.unlink()
            except OSError:
                pass

    def _evict_stale(self) -> None:
        """Remove lock file if its owner PID no longer exists."""
        try:
            raw = self._path.read_text().strip()
            pid = int(raw)
            if not _is_pid_alive(pid):
                log.debug("removing stale sidecar lock (dead pid=%s)", pid)
                self._path.unlink()
        except (OSError, ValueError):
            # Corrupted or race with concurrent unlink — ignore.
            pass

    def __enter__(self) -> "_CrossProcessLock":
        if not self.acquire():
            raise SidecarLockTimeout(
                f"Could not acquire sidecar start lock after "
                f"{LOCK_ACQUIRE_TIMEOUT_SECS}s ({self._path}). "
                f"Another process may be starting the sidecar. "
                f"If not, delete the lock file manually and retry."
            )
        return self

    def __exit__(self, *_: Any) -> None:
        self.release()


def _lock_file_path() -> Path:
    return _user_cache_dir() / "puvinoise-sidecar.lock"


# ---------------------------------------------------------------------------
# Binary resolution
# ---------------------------------------------------------------------------

def sdk_install_dir() -> Path:
    """Directory that contains the ``puvinoise`` Python package (this file)."""
    return Path(__file__).resolve().parent


def _user_cache_dir() -> Path:
    """Per-user directory for downloaded binaries, PID files, and locks."""
    if os.name == "nt":
        root = os.environ.get("LOCALAPPDATA") or os.path.expanduser(
            "~\\AppData\\Local"
        )
        return Path(root) / "puvinoise" / "sidecar"
    return Path(os.path.expanduser("~")) / ".puvinoise" / "sidecar"


def _candidate_binary_paths(os_family: str, arch: str) -> List[Path]:
    """Ordered resolution list (first existing file wins).

    Priority
    --------
    1. PUVI_SIDECAR_BIN env override (absolute path).
    2. Bundled in wheel: <sdk>/bin/{os}/{arch}/puvinoise-sidecar[.exe]
    3. Bundled (arch-agnostic legacy):  <sdk>/bin/{os}/puvinoise-sidecar[.exe]
    4. Per-user auto-download cache: ~/.puvinoise/sidecar/{os}/{arch}/...
    """
    suffix = executable_suffix(os_family)
    filename = f"{SIDECAR_BINARY_NAME}{suffix}"
    candidates: List[Path] = []

    override = os.environ.get("PUVI_SIDECAR_BIN")
    if override:
        candidates.append(Path(override).expanduser().resolve())

    base = sdk_install_dir() / "bin"
    candidates.append(base / os_family / arch / filename)
    candidates.append(base / os_family / filename)
    candidates.append(_user_cache_dir() / os_family / arch / filename)

    return candidates


def resolve_binary(
    os_family: Optional[str] = None,
    arch: Optional[str] = None,
    auto_download: bool = True,
) -> Path:
    """Locate the sidecar binary.  Raises SidecarNotFound with full path list."""
    os_family = os_family or detect_os()
    arch = arch or detect_arch()

    probed = _candidate_binary_paths(os_family, arch)
    for path in probed:
        if path.is_file():
            log.debug("sidecar binary resolved: %s", path)
            return path

    if auto_download:
        try:
            downloaded = _download_binary(os_family, arch)
            if downloaded and downloaded.is_file():
                return downloaded
        except SidecarOfflineError:
            raise
        except Exception as exc:
            log.warning("sidecar auto-download failed: %s", exc)

    os_hint = {
        OSFamily.WINDOWS: "Run: pip install puvinoise-sdk[sidecar-windows]",
        OSFamily.MACOS:   "Run: pip install puvinoise-sdk[sidecar-macos]",
        OSFamily.LINUX:   "Run: pip install puvinoise-sdk[sidecar-linux]",
    }.get(os_family, "Run: python -m puvinoise install-sidecar")

    pretty = "\n  ".join(str(p) for p in probed)
    raise SidecarNotFound(
        f"Sidecar binary not found for {os_family}/{arch}.\n"
        f"Fix: {os_hint}\n"
        f"  or set PUVI_SIDECAR_BIN=/absolute/path/to/binary\n"
        f"Paths checked:\n  {pretty}"
    )


def _ensure_executable(path: Path, os_family: str) -> None:
    """Set executable bit on Unix.  No-op on Windows (.exe is self-describing)."""
    if os_family == OSFamily.WINDOWS:
        return
    try:
        st = path.stat()
        path.chmod(st.st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    except OSError as exc:
        raise SidecarError(
            f"Cannot set executable bit on {path}: {exc}\n"
            f"Fix: chmod +x '{path}'"
        ) from exc


# ---------------------------------------------------------------------------
# Binary compatibility validation
# ---------------------------------------------------------------------------

def validate_binary(path: Path, timeout: float = 5.0) -> Tuple[bool, str]:
    """Run `binary --version` and return (ok: bool, version_or_error: str).

    A binary is valid if it:
      - exists and is executable
      - completes within *timeout* seconds
      - exits with code 0 or produces recognisable version output

    Reasons for failure:
      - Wrong architecture (e.g. arm64 binary on amd64 host → Exec format error)
      - Corrupt download
      - Missing shared library (ldd error on Linux)
    """
    if not path.is_file():
        return False, f"file not found: {path}"

    try:
        result = subprocess.run(
            [str(path), "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            timeout=timeout,
            shell=False,
        )
        output = (
            (result.stdout or b"") + (result.stderr or b"")
        ).decode("utf-8", errors="replace").strip()

        if result.returncode == 0:
            return True, output or "ok (no version string)"

        # Some binaries use exit code 1 for --version; accept if output looks
        # like a version string.
        if output and any(c.isdigit() for c in output):
            return True, output

        os_family = detect_os()
        arch = detect_arch()
        hint = ""
        if "cannot execute" in output.lower() or "exec format" in output.lower():
            hint = (
                f" (Exec format error — this binary may be built for a different "
                f"architecture. You are on {os_family}/{arch}.)"
            )
        elif "no such file" in output.lower():
            hint = " (missing shared library — try reinstalling the sidecar)"

        return False, f"exit code {result.returncode}{hint}: {output[:300]}"

    except subprocess.TimeoutExpired:
        arch = detect_arch()
        return False, (
            f"--version timed out after {timeout}s. "
            f"Possible wrong architecture binary for {arch}."
        )
    except PermissionError as exc:
        return False, (
            f"Permission denied: {exc}. "
            f"Fix: chmod +x '{path}'"
        )
    except OSError as exc:
        return False, str(exc)


# ---------------------------------------------------------------------------
# Auto-download fallback  (best-effort, enterprise-mirroring-aware)
# ---------------------------------------------------------------------------

def _check_network_available(
    host: str = "8.8.8.8",
    port: int = 53,
    timeout: float = 3.0,
) -> bool:
    """Quick TCP probe to detect network connectivity without DNS dependency."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _download_binary(os_family: str, arch: str) -> Optional[Path]:
    """Download sidecar binary into per-user cache; atomic rename on completion.

    - Skips download if file already exists.
    - Detects offline before attempting the request (avoids 60s timeout hang).
    - Stores in ~/.puvinoise/sidecar/{os}/{arch}/.
    - Sets executable bit on Unix.
    """
    suffix = executable_suffix(os_family)
    filename = f"{SIDECAR_BINARY_NAME}{suffix}"
    url = f"{DEFAULT_DOWNLOAD_BASE_URL}/{os_family}/{arch}/{filename}"

    dest_dir = _user_cache_dir() / os_family / arch
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / filename

    if dest.is_file():
        return dest  # already cached

    # Check network before a potentially long request
    if not _check_network_available():
        raise SidecarOfflineError(
            f"Offline environment detected — cannot auto-download sidecar for "
            f"{os_family}/{arch}.\n"
            f"Fix: pre-install the binary and set PUVI_SIDECAR_BIN=/path, "
            f"or copy it to:\n  {dest}\n"
            f"Then retry.  If using a corporate proxy, set HTTPS_PROXY."
        )

    log.info("downloading sidecar binary: %s → %s", url, dest)
    tmp_fd, tmp_path_str = tempfile.mkstemp(prefix=".puvi-dl-", dir=str(dest_dir))
    os.close(tmp_fd)
    tmp = Path(tmp_path_str)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "puvinoise-sdk"})
        with urllib.request.urlopen(req, timeout=DOWNLOAD_TIMEOUT_SECS) as resp:
            status = getattr(resp, "status", 200)
            if status >= 400:
                raise SidecarError(
                    f"Download failed: HTTP {status} from {url}\n"
                    f"The sidecar binary for {os_family}/{arch} may not be "
                    f"available yet.  Check https://docs.puvilabs.com/sidecar."
                )
            with open(tmp, "wb") as fh:
                shutil.copyfileobj(resp, fh)
        _ensure_executable(tmp, os_family)
        os.replace(tmp, dest)
        log.info("sidecar binary cached at %s", dest)
        return dest
    except urllib.error.URLError as exc:
        raise SidecarOfflineError(
            f"Network error downloading sidecar: {exc}\n"
            f"If in an air-gapped environment, set "
            f"PUVI_SIDECAR_DOWNLOAD_BASE=https://your-internal-mirror"
        ) from exc
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


# ---------------------------------------------------------------------------
# Log stream reader  (drains subprocess pipes into Python logger)
# ---------------------------------------------------------------------------

class _StreamLogger(threading.Thread):
    """Daemon thread that reads lines from a binary pipe and emits log records.

    Pass ``custom_handler`` to redirect to a file, Loguru, structlog, etc.
    """

    def __init__(
        self,
        pipe: Any,
        level: int = logging.DEBUG,
        prefix: str = "sidecar",
        custom_handler: Optional[Callable[[str], None]] = None,
    ) -> None:
        super().__init__(name=f"puvi-log-{prefix}", daemon=True)
        self._pipe = pipe
        self._level = level
        self._prefix = prefix
        self._custom = custom_handler

    def run(self) -> None:
        try:
            for raw in iter(self._pipe.readline, b""):
                line = raw.decode("utf-8", errors="replace").rstrip()
                if not line:
                    continue
                if self._custom:
                    try:
                        self._custom(line)
                    except Exception:  # handler must never crash the reader
                        pass
                else:
                    log.log(self._level, "[%s] %s", self._prefix, line)
        except (ValueError, OSError):
            pass  # pipe closed (normal shutdown path)
        finally:
            try:
                self._pipe.close()
            except OSError:
                pass


# ---------------------------------------------------------------------------
# Doctor diagnostics
# ---------------------------------------------------------------------------

def _color(text: str, code: str) -> str:
    """Wrap text in ANSI escape code if terminal supports colour."""
    no_color = os.environ.get("NO_COLOR") or not (
        hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
    )
    if no_color:
        return text
    return f"\033[{code}m{text}\033[0m"


_STATUS_ICON = {
    "ok":   ("✓", "32"),   # green
    "warn": ("~", "33"),   # yellow
    "fail": ("✗", "31"),   # red
    "skip": ("-", "90"),   # dark grey
}


def puvinoise_doctor(
    *,
    port: int = DEFAULT_SIDECAR_PORT,
    test_start: bool = False,
    auto_download: bool = False,
    out: Any = None,  # file-like; defaults to sys.stdout
) -> DoctorReport:
    """Run all pre-flight checks and print a formatted report.

    Parameters
    ----------
    port         : Port to check for existing sidecar / port availability.
    test_start   : If True, attempt a real sidecar start/stop cycle.
    auto_download: If True, attempt download when binary is missing.
    out          : Output destination (defaults to sys.stdout).

    Returns a DoctorReport so callers can inspect individual check results
    programmatically (e.g. in CI pipelines).
    """
    if out is None:
        out = sys.stdout

    os_family = detect_os()
    arch      = detect_arch()
    report    = DoctorReport(os_family=os_family, arch=arch)

    def add(name: str, status: str, detail: str, fix: Optional[str] = None) -> None:
        report.checks.append(DoctorCheck(name, status, detail, fix))

    def emit(check: DoctorCheck) -> None:
        icon, colour = _STATUS_ICON.get(check.status, ("?", "0"))
        label  = _color(f"[{icon}]", colour)
        name   = f"{check.name:<26}"
        detail = _color(check.detail, "0")
        print(f"  {label} {name} {detail}", file=out)
        if check.fix and check.status in ("fail", "warn"):
            print(f"       {_color('↳ Fix:', '33')} {check.fix}", file=out)

    header = _color("PUVINoise Sidecar — Diagnostics", "1;36")
    print(f"\n{header}", file=out)
    print("  " + "─" * 52, file=out)

    # ── 1. OS + arch ──────────────────────────────────────────────────────
    add("OS / arch", "ok", f"{os_family} / {arch}")
    emit(report.checks[-1])

    # ── 2. Python version ─────────────────────────────────────────────────
    pyver = sys.version.split()[0]
    status = "ok" if tuple(int(x) for x in pyver.split(".")[:2]) >= (3, 8) else "fail"
    add("Python version", status, pyver,
        fix="Python 3.8+ is required." if status == "fail" else None)
    emit(report.checks[-1])

    # ── 3. Binary resolution ──────────────────────────────────────────────
    binary: Optional[Path] = None
    try:
        binary = resolve_binary(os_family=os_family, arch=arch, auto_download=auto_download)
        add("Binary found", "ok", str(binary))
    except SidecarNotFound as exc:
        add("Binary found", "fail", "not found",
            fix=str(exc).split("\n")[1] if "\n" in str(exc) else str(exc))
    emit(report.checks[-1])

    # ── 4. Executable bit (Unix only) ─────────────────────────────────────
    if binary and os_family != OSFamily.WINDOWS:
        executable_ok = bool(binary.stat().st_mode & stat.S_IXUSR)
        add(
            "Executable bit",
            "ok" if executable_ok else "fail",
            "set" if executable_ok else "not set",
            fix=f"chmod +x '{binary}'" if not executable_ok else None,
        )
        emit(report.checks[-1])

    # ── 5. Binary version probe ───────────────────────────────────────────
    if binary:
        ok, version_str = validate_binary(binary)
        add(
            "Version probe",
            "ok" if ok else "fail",
            version_str[:80],
            fix=(
                f"Re-install or re-download the sidecar for {os_family}/{arch}. "
                f"Run: python -m puvinoise install-sidecar"
            ) if not ok else None,
        )
        emit(report.checks[-1])
    else:
        add("Version probe", "skip", "skipped (binary not found)")
        emit(report.checks[-1])

    # ── 6. Port availability / existing sidecar ───────────────────────────
    if is_port_in_use(port):
        add(
            f"Port {port}",
            "warn",
            "already in use — existing sidecar may be running",
            fix=(
                "Call start_sidecar(mode=LifecycleMode.EXTERNAL) to attach, "
                "or change PUVI_SIDECAR_PORT."
            ),
        )
    else:
        add(f"Port {port}", "ok", "available")
    emit(report.checks[-1])

    # ── 7. Handshake probe (only if something is listening) ───────────────
    if is_port_in_use(port):
        try:
            hs = handshake(
                port,
                expected_protocol=HANDSHAKE_EXPECTED_PROTOCOL,
                timeout_per_call=2.0,
                total_timeout=5.0,
            )
            add(
                "Handshake",
                "ok",
                f"protocol={hs.protocol} version={hs.sidecar_version} "
                f"latency={hs.latency_ms:.0f}ms",
            )
        except SidecarHandshakeError as exc:
            add(
                "Handshake",
                "fail",
                str(exc).split("\n")[0][:80],
                fix=(
                    "Run 'python -m puvinoise install-sidecar' to upgrade the "
                    "sidecar binary to the version expected by this SDK."
                ),
            )
    else:
        add("Handshake", "skip", "no sidecar running on this port")
    emit(report.checks[-1])

    # ── 8. PID file ──────────────────────────────────────────────────────
    existing_pid = _read_pid_file()
    if existing_pid and _is_pid_alive(existing_pid):
        add("PID file", "warn",
            f"stale or active sidecar pid={existing_pid}",
            fix="Call stop_sidecar() or kill the process before starting a new one.")
    elif existing_pid:
        add("PID file", "warn", f"stale PID {existing_pid} (process gone — will be cleaned up)")
    else:
        add("PID file", "ok", "no stale PID file")
    emit(report.checks[-1])

    # ── 9. Network (auto-download feasibility) ────────────────────────────
    net_ok = _check_network_available(timeout=2.0)
    add(
        "Network access",
        "ok" if net_ok else "warn",
        "reachable" if net_ok else "unreachable (offline / firewall)",
        fix=(
            "Pre-install sidecar binary or set "
            "PUVI_SIDECAR_DOWNLOAD_BASE=https://your-mirror"
        ) if not net_ok else None,
    )
    emit(report.checks[-1])

    # ── 10. Optional: test start/stop cycle ───────────────────────────────
    if test_start and binary:
        print(f"\n  {_color('Running test start/stop cycle…', '90')}", file=out)
        try:
            mgr = SidecarManager()
            proc = mgr.start(port=port, supervise=False)
            add("Test start", "ok", f"pid={proc.pid}, port={proc.port}")
            emit(report.checks[-1])
            mgr.stop()
            add("Test stop", "ok", "clean exit")
            emit(report.checks[-1])
        except SidecarError as exc:
            add("Test start/stop", "fail", str(exc)[:120])
            emit(report.checks[-1])

    # ── Summary ───────────────────────────────────────────────────────────
    print("  " + "─" * 52, file=out)
    if report.passed:
        print(f"  {_color('All checks passed.', '32')}\n", file=out)
    else:
        fail_names = ", ".join(c.name for c in report.failed)
        print(
            f"  {_color(f'FAILED: {fail_names}', '31')}\n"
            f"  Run `python -m puvinoise doctor --fix` to attempt automatic repair.\n",
            file=out,
        )

    return report


# ---------------------------------------------------------------------------
# SidecarManager  — the core class
# ---------------------------------------------------------------------------

class SidecarManager:
    """Thread-safe, cross-process supervisor for the PUVINoise sidecar.

    Singleton usage
    ---------------
    Most callers use the module-level ``start_sidecar()`` / ``stop_sidecar()``
    helpers, which delegate to ``SidecarManager.instance()``.

    Direct instantiation
    --------------------
    Useful for testing or when you need separate manager instances per port:
        mgr = SidecarManager()
        proc = mgr.start(port=7788, mode=LifecycleMode.MANAGED)
        mgr.stop()
    """

    _instance_lock: threading.Lock = threading.Lock()
    _instance: "Optional[SidecarManager]" = None

    def __init__(self) -> None:
        self._proc: Optional[SidecarProcess] = None
        self._lock = threading.Lock()
        self._supervisor: Optional[threading.Thread] = None
        self._stop_flag = threading.Event()
        self._restart_count: int = 0
        self._max_restarts: int = MAX_RESTARTS_DEFAULT
        self._last_error: Optional[str] = None
        self._binary_version: Optional[str] = None
        self._handshake_result: Optional[HandshakeResult] = None
        self._stdout_handler: Optional[Callable[[str], None]] = None
        self._stderr_handler: Optional[Callable[[str], None]] = None

    # ── Singleton ──────────────────────────────────────────────────────────

    @classmethod
    def instance(cls) -> "SidecarManager":
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
                atexit.register(cls._instance.stop)
            return cls._instance

    # ── Public API ─────────────────────────────────────────────────────────

    def start(
        self,
        *,
        args: Optional[Sequence[str]] = None,
        env: Optional[Mapping[str, str]] = None,
        cwd: Optional[os.PathLike] = None,
        port: Optional[int] = None,
        mode: str = LifecycleMode.MANAGED,
        auto_download: bool = True,
        supervise: bool = True,
        stdout_handler: Optional[Callable[[str], None]] = None,
        stderr_handler: Optional[Callable[[str], None]] = None,
    ) -> SidecarProcess:
        """Start the sidecar (or attach to an existing one).  Idempotent.

        Parameters
        ----------
        args            : Extra CLI arguments forwarded to the binary.
        env             : Extra environment variables merged into the child env.
        cwd             : Working directory for the child process.
        port            : Sidecar listen port.  Defaults to PUVI_SIDECAR_PORT
                          env var or ``DEFAULT_SIDECAR_PORT``.  The manager
                          searches for the next free port if this one is busy.
        mode            : LifecycleMode.MANAGED (default) | EXTERNAL | DISABLED.
        auto_download   : Attempt auto-download if binary is missing.
        supervise       : Launch the restart-supervisor background thread.
        stdout_handler  : Callable(line: str) — receives each sidecar stdout line.
        stderr_handler  : Callable(line: str) — receives each sidecar stderr line.
        """
        with self._lock:
            # ── Idempotent: return if already healthy ──────────────────────
            if self._proc and self._proc.is_running:
                log.debug("sidecar already running (pid=%s, port=%s)",
                          self._proc.pid, self._proc.port)
                return self._proc

            self._stop_flag.clear()

            # ── DISABLED mode: no-op ──────────────────────────────────────
            if mode == LifecycleMode.DISABLED:
                log.info("sidecar disabled by LifecycleMode.DISABLED")
                dummy = SidecarProcess(
                    pid=0, binary=Path("/dev/null"),
                    os_family=detect_os(), arch=detect_arch(),
                    port=None, mode=mode, popen=None,
                )
                self._proc = dummy
                return dummy

            resolved_port = port or DEFAULT_SIDECAR_PORT

            # ── EXTERNAL mode: attach without spawning ─────────────────────
            if mode == LifecycleMode.EXTERNAL:
                return self._attach_external(resolved_port)

            # ── MANAGED mode ───────────────────────────────────────────────
            os_family = detect_os()
            arch      = detect_arch()

            # Cross-process lock: ensures only one process reaches the spawn
            # logic even when multiple Python interpreters (e.g. gunicorn
            # workers, pytest-xdist workers) call start_sidecar concurrently.
            with _CrossProcessLock(_lock_file_path()):
                # Re-check port inside the lock: another process may have just
                # started the sidecar while we were waiting for the lock.
                if is_port_in_use(resolved_port):
                    existing_pid = _read_pid_file()
                    if existing_pid and _is_pid_alive(existing_pid):
                        log.info(
                            "sidecar already running (pid=%s, port=%s) — attaching",
                            existing_pid, resolved_port,
                        )
                        return self._attach_external(resolved_port)
                    # Port is busy but PID file doesn't match — find another.
                    log.warning(
                        "port %s in use by unknown process; searching for free port",
                        resolved_port,
                    )
                    resolved_port = find_free_port(resolved_port + 1)

                binary = resolve_binary(os_family, arch, auto_download=auto_download)
                _ensure_executable(binary, os_family)

                # Validate binary before spawning (catches wrong-arch binaries
                # before they produce confusing OS-level error messages).
                ok, version_str = validate_binary(binary)
                if not ok:
                    raise SidecarIncompatible(
                        f"Sidecar binary failed validation on {os_family}/{arch}: "
                        f"{version_str}\n"
                        f"Binary: {binary}\n"
                        f"Fix: run 'python -m puvinoise install-sidecar' to "
                        f"re-download the correct binary for this platform."
                    )
                self._binary_version = version_str
                log.info("sidecar binary validated: %s — %s", binary, version_str)

                # Merge port into CLI args so the sidecar binds the right port.
                full_args: List[str] = [str(binary), f"--port={resolved_port}"]
                if args:
                    full_args.extend(args)
                merged_env = self._build_env(env, resolved_port)

                log.info(
                    "starting PUVINoise sidecar: binary=%s os=%s arch=%s port=%s",
                    binary.name, os_family, arch, resolved_port,
                )

                self._stdout_handler = stdout_handler
                self._stderr_handler = stderr_handler

                # ── Spawn + handshake  (retry loop) ───────────────────────
                #
                # Startup contract:
                #   spawn → wait_for_port → HANDSHAKE → success
                #
                # A sidecar is NOT considered started until all three
                # handshake endpoints confirm correct behaviour.  On failure
                # we kill the child, wait for the port to release, and retry
                # up to HANDSHAKE_MAX_ATTEMPTS times.
                #
                # Only SidecarHandshakeError triggers a retry — binary-level
                # failures (wrong binary, immediate crash) propagate straight
                # out, since retrying the same broken binary is futile.

                hs_result:   Optional[HandshakeResult]   = None
                active_popen: Optional[subprocess.Popen] = None

                for attempt in range(1, HANDSHAKE_MAX_ATTEMPTS + 1):
                    if attempt > 1:
                        # Previous handshake failed; give the port time to
                        # release before re-spawning on the same address.
                        _wait_for_port_release(resolved_port)

                    active_popen = self._spawn(full_args, merged_env, cwd, os_family)
                    _write_pid_file(active_popen.pid)

                    # Drain child stdio into logger threads.  These are daemon
                    # threads; they exit naturally when the pipes close.
                    _StreamLogger(
                        active_popen.stdout, logging.DEBUG, "stdout",
                        custom_handler=stdout_handler,
                    ).start()
                    _StreamLogger(
                        active_popen.stderr, logging.WARNING, "stderr",
                        custom_handler=stderr_handler,
                    ).start()

                    # Wait for TCP port to accept connections.
                    port_ready = wait_for_port(
                        resolved_port, timeout=PORT_READY_TIMEOUT_SECS
                    )
                    if not port_ready:
                        exit_code = active_popen.poll()
                        if exit_code is not None:
                            # Binary crashed before binding — not retryable.
                            cleanup_sidecar(active_popen, os_family)
                            raise SidecarStartupError(
                                f"Sidecar (attempt {attempt}) exited with code "
                                f"{exit_code} before port {resolved_port} became ready.\n"
                                f"Binary: {binary}\n"
                                f"Fix: run 'puvinoise doctor' to diagnose the binary."
                            )
                        # Process alive but port slow — attempt handshake anyway.
                        log.warning(
                            "sidecar port %s not ready after %.1fs on attempt %d; "
                            "proceeding to handshake (process still running)",
                            resolved_port, PORT_READY_TIMEOUT_SECS, attempt,
                        )

                    # ── Handshake ─────────────────────────────────────────
                    try:
                        hs_result = handshake(
                            port=resolved_port,
                            expected_protocol=HANDSHAKE_EXPECTED_PROTOCOL,
                        )
                        log.info(
                            "sidecar handshake OK (attempt %d/%d): "
                            "protocol=%s version=%s latency=%.0fms",
                            attempt, HANDSHAKE_MAX_ATTEMPTS,
                            hs_result.protocol,
                            hs_result.sidecar_version,
                            hs_result.latency_ms,
                        )
                        break   # ← success; exit retry loop

                    except SidecarHandshakeError as exc:
                        log.warning(
                            "sidecar handshake failed (attempt %d/%d): %s",
                            attempt, HANDSHAKE_MAX_ATTEMPTS, exc,
                        )
                        cleanup_sidecar(active_popen, os_family)
                        active_popen = None

                        if attempt >= HANDSHAKE_MAX_ATTEMPTS:
                            raise SidecarHandshakeError(
                                f"Sidecar handshake failed after "
                                f"{HANDSHAKE_MAX_ATTEMPTS} attempt(s) "
                                f"on port {resolved_port}.\n"
                                f"Last error: {exc}\n"
                                f"Fix: ensure the sidecar binary is "
                                f"up-to-date ('python -m puvinoise "
                                f"install-sidecar') and check sidecar logs."
                            ) from exc
                        # Continue loop for next attempt.

                # Defensive guard: should be unreachable if MAX_ATTEMPTS ≥ 1.
                if active_popen is None or hs_result is None:
                    raise SidecarStartupError(
                        "Sidecar start loop exited without a valid process or "
                        "handshake result — this is a SDK bug, please report it."
                    )

                self._handshake_result = hs_result

                proc = SidecarProcess(
                    pid=active_popen.pid,
                    binary=binary,
                    os_family=os_family,
                    arch=arch,
                    port=resolved_port,
                    mode=mode,
                    popen=active_popen,
                    binary_version=self._binary_version,
                    handshake_result=hs_result,
                )
                self._proc = proc

            # Start supervisor *outside* the file lock (it runs indefinitely).
            if supervise and self._supervisor is None:
                self._supervisor = threading.Thread(
                    target=self._supervise_loop,
                    name="puvi-sidecar-supervisor",
                    daemon=True,
                )
                self._supervisor.start()

            return proc

    def stop(self, timeout: float = 10.0) -> None:
        """Graceful shutdown: SIGTERM → wait → SIGKILL.  No-op if not running."""
        with self._lock:
            self._stop_flag.set()
            proc = self._proc
            self._proc = None

        _clear_pid_file()

        if not proc or proc.mode in (LifecycleMode.EXTERNAL, LifecycleMode.DISABLED):
            return
        if not proc.is_running:
            return

        log.info("stopping sidecar (pid=%s)", proc.pid)
        try:
            if proc.os_family == OSFamily.WINDOWS:
                # CTRL_BREAK_EVENT works only on a process group created with
                # CREATE_NEW_PROCESS_GROUP.  Falls back to terminate() on error.
                try:
                    proc.popen.send_signal(signal.CTRL_BREAK_EVENT)  # type: ignore[attr-defined]
                except Exception:
                    proc.popen.terminate()
            else:
                proc.popen.terminate()   # SIGTERM → graceful shutdown

            try:
                proc.popen.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                log.warning(
                    "sidecar did not exit in %.1fs — killing (pid=%s)",
                    timeout, proc.pid,
                )
                proc.popen.kill()
                proc.popen.wait(timeout=5)
        except Exception as exc:
            log.warning("error stopping sidecar: %s", exc)

    @property
    def current(self) -> Optional[SidecarProcess]:
        return self._proc

    @property
    def restart_count(self) -> int:
        return self._restart_count

    @property
    def last_error(self) -> Optional[str]:
        return self._last_error

    @property
    def handshake_result(self) -> Optional[HandshakeResult]:
        """Last successful handshake result; None if not yet started."""
        return self._handshake_result

    def set_log_handlers(
        self,
        stdout_handler: Optional[Callable[[str], None]] = None,
        stderr_handler: Optional[Callable[[str], None]] = None,
    ) -> None:
        """Update log handlers at runtime (e.g. to switch to structlog)."""
        self._stdout_handler = stdout_handler
        self._stderr_handler = stderr_handler

    # ── Internal helpers ──────────────────────────────────────────────────

    def _attach_external(self, port: int) -> SidecarProcess:
        """Verify an external sidecar is alive and passes the handshake.

        EXTERNAL mode means the SDK did not spawn the process, so we cannot
        retry or restart on failure.  We still run the handshake once so the
        caller knows the sidecar speaks the expected protocol — a process
        listening on the port but returning wrong responses fails fast here
        rather than producing silent data loss later.
        """
        if not is_port_in_use(port):
            raise SidecarStartupError(
                f"LifecycleMode.EXTERNAL requested but no sidecar is listening "
                f"on port {port}.\n"
                f"Start the sidecar manually, then call start_sidecar() again."
            )
        log.info("attaching to external sidecar on port %s — running handshake", port)

        try:
            hs_result = handshake(port=port, expected_protocol=HANDSHAKE_EXPECTED_PROTOCOL)
            log.info(
                "external sidecar handshake OK: protocol=%s version=%s latency=%.0fms",
                hs_result.protocol, hs_result.sidecar_version, hs_result.latency_ms,
            )
        except SidecarHandshakeError as exc:
            raise SidecarHandshakeError(
                f"External sidecar on port {port} failed the handshake.\n"
                f"{exc}\n"
                f"Fix: ensure the external sidecar is the correct version and "
                f"fully initialised before calling start_sidecar()."
            ) from exc

        self._handshake_result = hs_result
        existing_pid = _read_pid_file() or 0
        proc = SidecarProcess(
            pid=existing_pid,
            binary=Path(os.environ.get("PUVI_SIDECAR_BIN", "external")),
            os_family=detect_os(),
            arch=detect_arch(),
            port=port,
            mode=LifecycleMode.EXTERNAL,
            popen=None,
            handshake_result=hs_result,
        )
        self._proc = proc
        return proc

    @staticmethod
    def _build_env(extra: Optional[Mapping[str, str]], port: int) -> Dict[str, str]:
        env = os.environ.copy()
        if extra:
            env.update({k: str(v) for k, v in extra.items()})
        env.setdefault("PUVI_SIDECAR_LAUNCHED_BY", "sdk")
        env["PUVI_SIDECAR_PORT"] = str(port)
        return env

    @staticmethod
    def _spawn(
        args: List[str],
        env: Dict[str, str],
        cwd: Optional[os.PathLike],
        os_family: str,
    ) -> subprocess.Popen:
        """OS-aware subprocess.Popen wrapper.

        Windows specifics
        -----------------
        * shell=False always — never let cmd.exe re-interpret arguments.
        * CREATE_NEW_PROCESS_GROUP (0x200) — allows CTRL_BREAK_EVENT for
          graceful shutdown without killing the parent console session.

        Unix specifics
        --------------
        * start_new_session=True — Ctrl-C in the parent terminal does not
          propagate SIGINT to the sidecar; we own its lifecycle explicitly.
        * stdout/stderr piped to _StreamLogger threads; stdin devnull.
        """
        kwargs: Dict[str, Any] = dict(
            args=args,
            env=env,
            cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            shell=False,
        )
        if os_family == OSFamily.WINDOWS:
            kwargs["creationflags"] = 0x00000200  # CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["start_new_session"] = True

        try:
            return subprocess.Popen(**kwargs)
        except FileNotFoundError as exc:
            raise SidecarNotFound(
                f"Binary not found or not executable at {args[0]}: {exc}\n"
                f"On Windows: ensure the .exe suffix is present.\n"
                f"On Unix: ensure chmod +x has been run."
            ) from exc
        except PermissionError as exc:
            raise SidecarError(
                f"Permission denied launching {args[0]}: {exc}\n"
                f"Fix: chmod +x '{args[0]}'"
            ) from exc

    def _supervise_loop(self) -> None:
        """Restart-on-crash loop with exponential backoff.

        Runs as a daemon thread so it never prevents interpreter exit.
        The stop_flag is set by stop() so restarts do not happen during
        intentional shutdown.
        """
        backoff = 1.0
        while not self._stop_flag.is_set():
            self._stop_flag.wait(timeout=SUPERVISOR_POLL_SECS)
            if self._stop_flag.is_set():
                break

            proc = self._proc
            if not proc or proc.mode != LifecycleMode.MANAGED:
                continue
            if proc.is_running:
                backoff = 1.0  # healthy → reset backoff counter
                continue

            # Process has died unexpectedly.
            exit_code = proc.popen.returncode if proc.popen else -1
            self._last_error = (
                f"sidecar exited unexpectedly (pid={proc.pid}, code={exit_code})"
            )
            log.warning(
                "%s; restart %d/%d in %.1fs",
                self._last_error, self._restart_count + 1,
                self._max_restarts, backoff,
            )

            if self._restart_count >= self._max_restarts:
                log.error(
                    "sidecar restart budget exhausted (%d/%d); supervisor stopping. "
                    "Check your environment and call start_sidecar() manually.",
                    self._restart_count, self._max_restarts,
                )
                return

            self._restart_count += 1
            self._stop_flag.wait(timeout=backoff)  # interruptible sleep
            backoff = min(backoff * 2, 30.0)

            if self._stop_flag.is_set():
                break

            try:
                with self._lock:
                    self._proc = None
                # supervise=False: don't nest a second supervisor thread.
                self.start(
                    port=proc.port,
                    mode=proc.mode,
                    supervise=False,
                    stdout_handler=self._stdout_handler,
                    stderr_handler=self._stderr_handler,
                )
            except SidecarError as exc:
                self._last_error = str(exc)
                log.error("sidecar restart failed: %s", exc)
                return


# ---------------------------------------------------------------------------
# Module-level convenience API
# ---------------------------------------------------------------------------

def start_sidecar(
    *extra_args: str,
    port: Optional[int] = None,
    mode: str = LifecycleMode.MANAGED,
    env: Optional[Mapping[str, str]] = None,
    cwd: Optional[os.PathLike] = None,
    auto_download: bool = True,
    supervise: bool = True,
    stdout_handler: Optional[Callable[[str], None]] = None,
    stderr_handler: Optional[Callable[[str], None]] = None,
) -> SidecarProcess:
    """Start (or attach to) the PUVINoise sidecar.  Idempotent.

    Examples
    --------
    # Zero-config (most common)
    from puvinoise import start_sidecar
    start_sidecar()

    # External mode (sidecar runs in a Docker sidecar container)
    start_sidecar(port=7787, mode=LifecycleMode.EXTERNAL)

    # Redirect sidecar logs to your own logger
    import logging
    sidecar_log = logging.getLogger("my_app.sidecar")
    start_sidecar(stdout_handler=sidecar_log.debug, stderr_handler=sidecar_log.error)
    """
    return SidecarManager.instance().start(
        args=list(extra_args) if extra_args else None,
        env=env,
        cwd=cwd,
        port=port,
        mode=mode,
        auto_download=auto_download,
        supervise=supervise,
        stdout_handler=stdout_handler,
        stderr_handler=stderr_handler,
    )


def stop_sidecar(timeout: float = 10.0) -> None:
    """Gracefully stop the managed sidecar.  No-op if not running."""
    SidecarManager.instance().stop(timeout=timeout)


def get_sidecar_status() -> Dict[str, Any]:
    """Return a JSON-serialisable status dict — safe to expose from /health.

    Fields
    ------
    running              : bool   — process alive AND handshake previously succeeded
    pid                  : int|None
    port                 : int|None
    uptime_secs          : float
    restart_count        : int
    last_error           : str|None  — last error from supervisor or startup
    binary               : str|None  — absolute path to the binary
    binary_version       : str|None  — output of `binary --version`
    os                   : str
    arch                 : str
    mode                 : str       — managed | external | disabled
    handshake_protocol   : str|None  — protocol id from GET /version
    handshake_version    : str|None  — sidecar semver from GET /version
    handshake_ready      : bool|None — value from GET /ready
    handshake_latency_ms : float|None
    handshake_at         : float|None — Unix timestamp of last successful handshake
    """
    mgr  = SidecarManager.instance()
    proc = mgr.current
    hs   = mgr.handshake_result  # may be None if sidecar not yet started

    return {
        "running":              bool(proc and proc.is_running),
        "pid":                  proc.pid if proc else None,
        "port":                 proc.port if proc else None,
        "uptime_secs":          round(proc.uptime_secs, 2) if proc else 0.0,
        "restart_count":        mgr.restart_count,
        "last_error":           mgr.last_error,
        "binary":               str(proc.binary) if proc else None,
        "binary_version":       proc.binary_version if proc else None,
        "os":                   proc.os_family if proc else detect_os(),
        "arch":                 proc.arch if proc else detect_arch(),
        "mode":                 proc.mode if proc else LifecycleMode.MANAGED,
        # ── Handshake fields (None until first successful handshake) ──────
        "handshake_protocol":   hs.protocol        if hs else None,
        "handshake_version":    hs.sidecar_version if hs else None,
        "handshake_ready":      hs.ready           if hs else None,
        "handshake_latency_ms": round(hs.latency_ms, 1) if hs else None,
        "handshake_at":         hs.timestamp       if hs else None,
    }


# ---------------------------------------------------------------------------
# Public surface
# ---------------------------------------------------------------------------

__all__ = [
    # classes
    "OSFamily",
    "LifecycleMode",
    "SidecarError",
    "SidecarNotFound",
    "SidecarIncompatible",
    "SidecarUnsupportedPlatform",
    "SidecarStartupError",
    "SidecarPortConflict",
    "SidecarOfflineError",
    "SidecarLockTimeout",
    "SidecarHandshakeError",
    "HandshakeResult",
    "SidecarProcess",
    "SidecarManager",
    "DoctorCheck",
    "DoctorReport",
    # handshake
    "handshake",
    "cleanup_sidecar",
    # detection utilities
    "detect_os",
    "detect_arch",
    "executable_suffix",
    # binary utilities
    "sdk_install_dir",
    "resolve_binary",
    "validate_binary",
    # port utilities
    "is_port_in_use",
    "find_free_port",
    "wait_for_port",
    # network
    "_check_network_available",
    # module-level API
    "start_sidecar",
    "stop_sidecar",
    "get_sidecar_status",
    "puvinoise_doctor",
]
