"""
agent-sdk/puvinoise/framework_usage.py
──────────────────────────────────────
In-process runtime usage counters per known agent framework.

Used to choose **primary framework** for registration and telemetry: the
label with the highest observed instrumentation event count wins (not install
order). Thread-safe.
"""

from __future__ import annotations

import threading
from typing import Any, Dict, List, Tuple

_lock = threading.Lock()
# Labels align with KNOWN_FRAMEWORKS in framework_detection (lazy-init keys).
_counts: Dict[str, int] = {}


def _ensure_labels() -> None:
    """Populate counter keys from KNOWN_FRAMEWORKS (single source of truth)."""
    global _counts
    if _counts:
        return
    from puvinoise.framework_detection import KNOWN_FRAMEWORKS

    _counts = {fw["label"]: 0 for fw in KNOWN_FRAMEWORKS}


def record_framework_usage(label: str, n: int = 1) -> None:
    """
    Increment usage for a framework label when instrumentation fires
    (one increment per wrapped call / span).
    Unknown labels are ignored.
    """
    if not label or n <= 0:
        return
    _ensure_labels()
    from puvinoise.framework_detection import KNOWN_FRAMEWORKS

    allowed = {fw["label"] for fw in KNOWN_FRAMEWORKS}
    if label not in allowed:
        return
    with _lock:
        _counts[label] = _counts.get(label, 0) + n


def get_framework_usage_counts() -> Dict[str, int]:
    """Return a snapshot copy of per-framework usage counts."""
    _ensure_labels()
    with _lock:
        return dict(_counts)


def get_runtime_primary_framework() -> Tuple[str, str]:
    """
    Return (framework_label, detection_mode) from **runtime usage only**.

    * The label with the highest count wins.
    * Ties break lexicographically by label (deterministic, order-independent).
    * If total usage is zero → ("unknown", "unknown").

    The second value is only ``library`` (dominant framework from counters) or
    ``unknown`` (no usage yet). Registration-facing ``detection_mode`` also
    uses ``behavior`` when the behavior classifier has run; see
    :func:`puvinoise.framework_detection.effective_detection_mode`.
    """
    _ensure_labels()
    with _lock:
        counts = dict(_counts)
    total = sum(counts.values())
    if total <= 0:
        return "unknown", "unknown"
    max_c = max(counts.values())
    winners = sorted([k for k, v in counts.items() if v == max_c and v > 0])
    if not winners:
        return "unknown", "unknown"
    return winners[0], "library"


def reset_framework_usage() -> None:
    """Reset all counters (tests)."""
    global _counts
    _ensure_labels()
    with _lock:
        for k in list(_counts.keys()):
            _counts[k] = 0
