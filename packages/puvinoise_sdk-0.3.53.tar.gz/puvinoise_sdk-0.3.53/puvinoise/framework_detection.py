"""
agent-sdk/puvinoise/framework_detection.py
──────────────────────────────────────────
Runtime-based, framework-agnostic detection layer.

Design principles
─────────────────
1. Detection is **runtime-based** — we probe the live Python environment
   via importlib.util.find_spec(), never via static package lists.
2. Detection is **lazy** — we use ``importlib.util.find_spec()`` which does
   NOT execute the library's ``__init__.py`` nor trigger import side-effects.
3. Detection is **optional enrichment** — the SDK operates fully without any
   known framework present.  Detection merely adds labels and enables
   framework-specific instrumentation hooks.
4. **Behavior classification** (LLM→tool→LLM, etc.) runs in
   :mod:`puvinoise.framework_instrumentation`, not in this module. The
   registration field ``detection_mode`` is ``behavior`` only after the
   classifier has actually run; otherwise it is ``unknown`` (no framework
   usage) or ``library`` (instrumentation counters show a dominant framework).
5. **Primary framework** for registration is **not** install order: it comes
   from :mod:`puvinoise.framework_usage` (highest runtime instrumentation
   count). Static ``find_spec`` data remains for which packages are present.
6. Results are **idempotent** — calling ``detect_frameworks()`` twice returns
   the same snapshot; static parts of ``detect_all()`` are cached cheaply.
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("puvinoise.framework_detection")

# ─── Module-level state (static install probe cached; primary is always runtime) ─

_STATIC_DETECTION_CACHE: Optional[Dict[str, Any]] = None
_STATIC_DETECTION_DONE: bool = False


# ─── Known framework registry ───────────────────────────────────────────────
#
# Each entry defines:
#   - import_name:    the top-level module name to probe with find_spec()
#   - label:          the human-readable label emitted in telemetry
#   - version_attr:   dotted path to __version__ (or None)
#   - probe_classes:  class paths to look for to confirm the framework is
#                     actively used (not just installed).  These are checked
#                     ONLY when the top-level spec is found, and only with
#                     importlib.util.find_spec() (no actual import).
#
# This list is intentionally flat and data-driven.  Each label here must have
# matching instrumentation in ``puvinoise.framework_instrumentation`` (no
# detect-only entries).  To add a new framework: add a dict entry and implement
# ``_apply_<label>_hooks()`` (or extend an existing hook bundle).

KNOWN_FRAMEWORKS: List[Dict[str, Any]] = [
    {
        "import_name": "langchain",
        "label": "langchain",
        "version_attr": "langchain.__version__",
        "probe_classes": [
            "langchain.chains.base",
            "langchain_core.runnables.base",
        ],
    },
    {
        "import_name": "langgraph",
        "label": "langgraph",
        "version_attr": "langgraph.__version__",
        "probe_classes": [
            "langgraph.graph.state",
            "langgraph.graph.graph",
        ],
    },
    {
        "import_name": "crewai",
        "label": "crewai",
        "version_attr": "crewai.__version__",
        "probe_classes": [
            "crewai.agent",
            "crewai.crew",
        ],
    },
    {
        "import_name": "autogen",
        "label": "autogen",
        "version_attr": "autogen.__version__",
        "probe_classes": [
            "autogen.agentchat.conversable_agent",
        ],
    },
    {
        "import_name": "llama_index",
        "label": "llama_index",
        "version_attr": "llama_index.__version__",
        "probe_classes": [
            "llama_index.core.query_engine",
        ],
    },
]


# ─── Detection helpers ───────────────────────────────────────────────────────

def _spec_exists(module_path: str) -> bool:
    """
    Check whether a module/package is findable by the import machinery
    WITHOUT executing any code.

    Uses importlib.util.find_spec() which is the correct, safe probe:
    - It reads sys.path and package __path__ metadata only.
    - It does NOT execute __init__.py or trigger side-effects.
    - It returns None when the module is not installed.
    """
    try:
        return importlib.util.find_spec(module_path) is not None
    except (ModuleNotFoundError, ValueError, AttributeError):
        # ValueError: parent package not importable
        # AttributeError: broken __spec__ on some packages
        return False


def _try_get_version(dotted_path: str) -> Optional[str]:
    """
    Attempt to read a __version__ string from an already-imported module.
    If the module is not yet imported, try importlib.metadata first (no import).
    Returns None on any failure.
    """
    # 1. Check if already imported → cheap attribute lookup
    parts = dotted_path.rsplit(".", 1)
    if len(parts) == 2:
        mod_name, attr = parts
        mod = sys.modules.get(mod_name)
        if mod is not None:
            v = getattr(mod, attr, None)
            if v is not None:
                return str(v)

    # 2. Try importlib.metadata (reads installed package metadata, no import)
    top_level = dotted_path.split(".")[0]
    try:
        from importlib.metadata import version  # type: ignore[attr-defined]
        return str(version(top_level))
    except Exception:  # noqa: BLE001
        pass

    return None


# ─── Core detection API ──────────────────────────────────────────────────────

def detect_frameworks() -> Dict[str, bool]:
    """
    Probe the environment for known agent frameworks.

    Returns a dict like::

        {"langchain": True, "langgraph": False, "crewai": False, ...}

    This is a **pure detection** call — it does not import any framework,
    does not patch anything, and has no side-effects.
    """
    result: Dict[str, bool] = {}
    for fw in KNOWN_FRAMEWORKS:
        result[fw["label"]] = _spec_exists(fw["import_name"])
    return result


def detect_framework_details() -> List[Dict[str, Any]]:
    """
    Richer detection: for each known framework, return presence, version,
    and which probe classes are available.

    Returns a list of dicts::

        [
            {
                "label": "langchain",
                "present": True,
                "version": "0.2.14",
                "probe_classes": {"langchain.chains.base": True, ...}
            },
            ...
        ]
    """
    details: List[Dict[str, Any]] = []
    for fw in KNOWN_FRAMEWORKS:
        present = _spec_exists(fw["import_name"])
        version = _try_get_version(fw["version_attr"]) if (present and fw.get("version_attr")) else None
        probes: Dict[str, bool] = {}
        if present:
            for pc in fw.get("probe_classes", []):
                probes[pc] = _spec_exists(pc)
        details.append({
            "label": fw["label"],
            "present": present,
            "version": version,
            "probe_classes": probes,
        })
    return details


def get_primary_framework() -> Tuple[str, str]:
    """
    Return (framework_label, usage_mode) for the **dominant** framework.

    Delegates to :func:`puvinoise.framework_usage.get_runtime_primary_framework`:
    highest runtime instrumentation count wins (not registry order).
    If no usage recorded → ("unknown", "unknown").

    For the registration payload, use :func:`effective_detection_mode` which
    may return ``behavior`` when the behavior classifier has run.
    """
    from puvinoise.framework_usage import get_runtime_primary_framework

    return get_runtime_primary_framework()


def get_runtime_primary_framework() -> Tuple[str, str]:
    """
    Alias for :func:`puvinoise.framework_usage.get_runtime_primary_framework`
    (re-export for callers that import from ``framework_detection`` only).
    """
    from puvinoise.framework_usage import get_runtime_primary_framework as _rt

    return _rt()


def effective_detection_mode() -> str:
    """
    ``detection_mode`` for registration and env (``PUVINOISE_DETECTION_MODE``).

    * ``library`` — runtime instrumentation counters show a dominant framework.
    * ``behavior`` — the behavior classifier has run at least once
      (:mod:`puvinoise.framework_instrumentation`).
    * ``unknown`` — neither of the above yet.

    **Backward compatibility:** Older SDKs used ``behavior`` whenever no
    framework usage was recorded. That value now maps to ``unknown`` until the
    classifier runs; ``behavior`` is reserved for the classifier-backed case.
    """
    _, usage_mode = get_primary_framework()
    if usage_mode == "library":
        return "library"
    try:
        from puvinoise.framework_instrumentation import behavior_classifier_has_run

        if behavior_classifier_has_run():
            return "behavior"
    except Exception:  # noqa: BLE001
        pass
    return "unknown"


def _detect_all_static_cached() -> Dict[str, Any]:
    """Cached install-time probe only (frameworks + details)."""
    global _STATIC_DETECTION_CACHE, _STATIC_DETECTION_DONE
    if _STATIC_DETECTION_DONE and _STATIC_DETECTION_CACHE is not None:
        return _STATIC_DETECTION_CACHE

    frameworks = detect_frameworks()
    details = detect_framework_details()
    _STATIC_DETECTION_CACHE = {
        "frameworks": frameworks,
        "details": details,
    }
    _STATIC_DETECTION_DONE = True
    return _STATIC_DETECTION_CACHE


# ─── Composite detection (static cached + runtime primary each call) ────────

def detect_all() -> Dict[str, Any]:
    """
    Full detection sweep. Static install data is cached; ``primary`` comes from
    runtime usage counters; ``detection_mode`` uses :func:`effective_detection_mode`.

    Returns::

        {
            "frameworks": {"langchain": True, ...},
            "primary": "<highest-usage label or unknown>",
            "detection_mode": "library" | "behavior" | "unknown",
            "details": [...],
        }
    """
    static = _detect_all_static_cached()
    primary, _ = get_primary_framework()
    mode = effective_detection_mode()

    logger.debug(
        "framework detection: primary=%s  detection_mode=%s  installed=%s",
        primary,
        mode,
        [d["label"] for d in static["details"] if d["present"]],
    )
    return {
        **static,
        "primary": primary,
        "detection_mode": mode,
    }


def reset_detection_cache() -> None:
    """Clear cached static detection and framework usage counters (used in tests)."""
    global _STATIC_DETECTION_CACHE, _STATIC_DETECTION_DONE
    _STATIC_DETECTION_CACHE = None
    _STATIC_DETECTION_DONE = False
    try:
        from puvinoise.framework_usage import reset_framework_usage

        reset_framework_usage()
    except Exception:  # noqa: BLE001
        pass


# ─── Metadata helper for registration payload ───────────────────────────────

def framework_metadata_for_registration() -> Dict[str, str]:
    """
    Return the framework metadata fields that should be included in the
    /api/agent-register payload and in span attributes.

    ``framework`` / primary label comes from **runtime usage** (instrumentation
    counters), not install order. ``detection_mode`` is :func:`effective_detection_mode`.

    Returns::

        {
            "framework": "langchain",
            "detection_mode": "library" | "behavior" | "unknown",
            "instrumentation": "enabled",
        }
    """
    primary, _ = get_primary_framework()
    mode = effective_detection_mode()
    return {
        "framework": primary,
        "detection_mode": mode,
        "instrumentation": "enabled",
    }


def sync_framework_env_from_runtime() -> None:
    """
    Set ``PUVINOISE_FRAMEWORK`` and ``PUVINOISE_DETECTION_MODE`` from
    :func:`framework_metadata_for_registration` (see :func:`effective_detection_mode`).
    Also syncs behavior classifier fields via :func:`puvinoise.framework_instrumentation.sync_behavior_env_from_runtime`.

    Call after instrumentation may have recorded events, and before
    ``/api/agent-register`` so the payload matches observed behavior.
    """
    import os

    meta = framework_metadata_for_registration()
    os.environ["PUVINOISE_FRAMEWORK"] = meta["framework"]
    os.environ["PUVINOISE_DETECTION_MODE"] = meta["detection_mode"]
    try:
        from puvinoise.framework_instrumentation import sync_behavior_env_from_runtime

        sync_behavior_env_from_runtime()
    except Exception:  # noqa: BLE001
        pass
