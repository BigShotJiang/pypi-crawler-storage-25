"""
Backward-compatible shim: remote control + execution live in `puvinoise.agent_runtime`.

Prefer: `from puvinoise.agent_runtime import AgentControlWorker, start`
"""

from puvinoise.agent_runtime import (
    AgentControlWorker,
    ControlCommand,
    ControlHandler,
    DEFAULT_POLL_INTERVAL_SEC,
    OnAgentRestartHook,
    OnAgentStopHook,
    OnDeployRequestedHook,
    OnRollbackRequestedHook,
    ControlRuntimeExecutor,
    fetch_agent_config,
    get_runtime_executor,
    post_control_command_completion,
    post_control_command_completion_from_env,
    runtime_exec_enabled,
)

__all__ = [
    "AgentControlWorker",
    "ControlCommand",
    "ControlHandler",
    "DEFAULT_POLL_INTERVAL_SEC",
    "OnAgentStopHook",
    "OnAgentRestartHook",
    "OnDeployRequestedHook",
    "OnRollbackRequestedHook",
    "post_control_command_completion",
    "post_control_command_completion_from_env",
    "ControlRuntimeExecutor",
    "fetch_agent_config",
    "get_runtime_executor",
    "runtime_exec_enabled",
]
