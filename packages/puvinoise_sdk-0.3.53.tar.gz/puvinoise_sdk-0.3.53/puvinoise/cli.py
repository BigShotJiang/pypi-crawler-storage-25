"""
Console entrypoint for the `puvinoise` command (shipped with puvinoise-sdk).

Commands include bindcar, onboard, run, and mapping helpers (agents, mappings,
create, attach) — see puvinoise.puvinoise_run and puvinoise.tenant_commands.
"""

from __future__ import annotations

import argparse
import sys


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="puvinoise",
        description="PUVINoise SDK — bind environments, register agents, run with telemetry.",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    from puvinoise.bindcar import (
        register_bindcar_subparser as _register_bindcar,
        register_switch_subparser as _register_switch,
    )
    from puvinoise.puvinoise_run import (
        register_subparser as _register_run,
        register_upgrade_subparser as _register_upgrade,
    )
    from puvinoise.tenant_commands import register_tenant_subparsers as _register_tenant

    _register_bindcar(sub)
    _register_switch(sub)
    _register_run(sub)
    _register_upgrade(sub)
    _register_tenant(sub)
    return parser


def main() -> int:
    parser = build_parser()
    args, unknown = parser.parse_known_args()
    args._unknown_args = unknown  # noqa: SLF001 — merged in cmd_run for passthrough flags
    if not hasattr(args, "func"):
        parser.print_help()
        return 1
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
