"""
Canonical runtime environment accessors. See :mod:`puvinoise.env_resolve`.
"""

from puvinoise.env_resolve import (
    env_var,
    get_agent_id,
    get_agent_name,
    get_api_key,
    get_base_url,
    get_deploy_env,
    get_tenant_id,
    get_trace_endpoint,
    normalize_environment_aliases,
)

__all__ = [
    "env_var",
    "get_agent_id",
    "get_agent_name",
    "get_api_key",
    "get_base_url",
    "get_deploy_env",
    "get_platform_url",
    "get_tenant_id",
    "get_trace_endpoint",
    "normalize_environment_aliases",
]


def get_platform_url():
    """Alias for :func:`get_base_url`."""
    return get_base_url()
