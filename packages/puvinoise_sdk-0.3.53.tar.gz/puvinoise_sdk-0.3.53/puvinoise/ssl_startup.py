"""
Non-blocking SSL / TLS diagnostics for PUVINoise CLIs.

Logs the linked crypto library, warns on LibreSSL or very old OpenSSL, and
optionally probes HTTPS reachability. Never raises to callers; does not
suppress third-party warnings (e.g. urllib3).
"""

from __future__ import annotations

import re
import ssl
import sys
import urllib.error
import urllib.request
from typing import Optional, Tuple


def _openssl_version_str() -> str:
    try:
        return str(getattr(ssl, "OPENSSL_VERSION", None) or "").strip() or "unknown"
    except Exception:  # noqa: BLE001
        return "unknown"


def _openssl_version_triple_from_info() -> Optional[Tuple[int, int, int]]:
    info = getattr(ssl, "OPENSSL_VERSION_INFO", None)
    if not info or len(info) < 3:
        return None
    try:
        return int(info[0]), int(info[1]), int(info[2])
    except (TypeError, ValueError):
        return None


def _openssl_version_triple_from_string(s: str) -> Optional[Tuple[int, int, int]]:
    m = re.search(r"OpenSSL\s+(\d+)\.(\d+)\.(\d+)", s, re.I)
    if not m:
        return None
    try:
        return int(m.group(1)), int(m.group(2)), int(m.group(3))
    except ValueError:
        return None


def report_ssl_backend_and_warnings() -> None:
    """Print OpenSSL/LibreSSL identity and compatibility guidance (stderr)."""
    ver = _openssl_version_str()
    print(f"[puvinoise] SSL backend: {ver}", file=sys.stderr)

    low = ver.lower()
    if "libressl" in low:
        print(
            "[puvinoise] ⚠️ SSL compatibility warning:\n"
            "Your Python installation uses LibreSSL.\n\n"
            "This may affect secure HTTPS connections.\n\n"
            "Recommended:\n"
            "- Use Python 3.10+ with OpenSSL 1.1.1+\n"
            "- Install via pyenv or Homebrew\n",
            file=sys.stderr,
        )
        return

    triple = _openssl_version_triple_from_info() or _openssl_version_triple_from_string(ver)
    if triple is not None and triple < (1, 1, 1):
        print(
            "[puvinoise] ⚠️ SSL compatibility warning (strong):\n"
            f"Linked OpenSSL is older than 1.1.1 (parsed: {triple[0]}.{triple[1]}.{triple[2]}).\n\n"
            "HTTPS to modern servers may fail or be insecure.\n\n"
            "Recommended:\n"
            "- Upgrade Python to a build that links OpenSSL 1.1.1 or newer\n"
            "- Install via pyenv or your OS package manager\n",
            file=sys.stderr,
        )


def probe_https_to_base_url(base_url: Optional[str], *, timeout: float = 10.0) -> None:
    """
    Best-effort GET to *base_url* to verify TLS + TCP. Prints result on stderr.
    HTTP responses (4xx/5xx) still imply TLS succeeded and are treated as success.
    """
    url = (base_url or "").strip().rstrip("/")
    if not url or not url.lower().startswith("https:"):
        return
    try:
        req = urllib.request.Request(
            url + "/",
            method="GET",
            headers={"User-Agent": "PUVINoise-CLI/ssl-check"},
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                _ = resp.read(64)
        except urllib.error.HTTPError:
            # TLS and HTTP session OK; server returned an application-level status.
            pass
        print("[puvinoise] ✓ Secure connection verified", file=sys.stderr)
    except Exception as exc:  # noqa: BLE001
        print("[puvinoise] ✗ SSL connection failed", file=sys.stderr)
        detail = str(exc).strip()
        if detail:
            print(f"  ({detail})", file=sys.stderr)
