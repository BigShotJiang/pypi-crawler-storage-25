"""
PUVINoise traffic routing — polls the server for the active traffic split config
and routes each agent request to the correct version via weighted random selection.

Usage:
    from puvinoise.routing import RoutingClient, get_version, init_routing

    router = RoutingClient(
        api_key="your-agent-access-key",
        endpoint="https://api.yourplatform.com",
        agent_id="demo20-dev-learning",
        environment="development",
    )

    version = router.get_version()   # returns "0.1.2" or "0.1.1" based on split
"""

from __future__ import annotations

import json
import os
import random
import threading
import time
from typing import Dict, Optional

import urllib.error
import urllib.request

from puvinoise.env_keys import get_trace_endpoint, get_agent_id, get_agent_name


_DEFAULT_POLL_INTERVAL_S = 30
_DEFAULT_CACHE_TTL_S = 60


class RoutingConfig:
  """Snapshot of the current traffic split for one agent."""

  def __init__(self, data: dict):
    self.agent_id: str = data.get("agentId", "")
    self.environment: Optional[str] = data.get("environment")
    self.active_deployment: Optional[str] = data.get("activeDeployment")
    self.traffic_split: Dict[str, int] = data.get("trafficSplit") or {}
    self.active_version: Optional[str] = data.get("activeVersion")
    self.previous_version: Optional[str] = data.get("previousVersion")
    self.deployment_mode: Optional[str] = data.get("deploymentMode")
    self.active_slot: Optional[str] = data.get("activeSlot")
    self.progress: int = data.get("progress", 100)
    self.status: str = data.get("status", "completed")
    self.fetched_at: float = time.time()

  def select_version(self) -> Optional[str]:
    """
    Weighted random version selection based on trafficSplit.
    e.g. { "0.1.2": 25, "0.1.1": 75 } → 25% chance of 0.1.2
    Returns active_version if no split configured.
    """
    if not self.traffic_split:
      return self.active_version

    versions = list(self.traffic_split.keys())
    weights = [max(0, int(self.traffic_split[v])) for v in versions]
    total = sum(weights)
    if total == 0:
      return self.active_version

    r = random.uniform(0, total)
    cumulative = 0.0
    for v, w in zip(versions, weights):
      cumulative += w
      if r <= cumulative:
        return v
    return versions[-1]

  @property
  def is_stale(self) -> bool:
    return time.time() - self.fetched_at > _DEFAULT_CACHE_TTL_S


class RoutingClient:
  """
  Polls GET /api/agent-routing every poll_interval_s seconds.
  Thread-safe. Falls back to active_version on fetch failure.
  """

  def __init__(
      self,
      api_key: Optional[str] = None,
      endpoint: Optional[str] = None,
      agent_id: Optional[str] = None,
      environment: Optional[str] = None,
      poll_interval_s: int = _DEFAULT_POLL_INTERVAL_S,
  ):
    self._api_key = api_key or os.getenv("PUVINOISE_API_KEY") or ""
    self._endpoint = (endpoint or get_trace_endpoint() or "").rstrip("/")
    self._agent_id = agent_id or get_agent_id() or get_agent_name() or ""
    self._environment = environment or os.getenv("DEPLOYMENT_ENV", "")
    self._poll_interval = poll_interval_s
    self._config: Optional[RoutingConfig] = None
    self._lock = threading.Lock()
    self._stop = threading.Event()

    # Fetch once synchronously on init so first call is never cold
    try:
      self._fetch()
    except Exception:
      pass

    # Start background polling thread only when we have enough config
    if self._endpoint and self._agent_id:
      self._thread = threading.Thread(target=self._poll_loop, daemon=True)
      self._thread.start()
    else:
      self._thread = None
      import logging
      logging.getLogger(__name__).warning(
        "RoutingClient: endpoint or agent_id not set — polling disabled. "
        "Call init_routing() after bootstrap() or puvinoise.init()."
      )

  def _fetch(self) -> None:
    if not self._endpoint:
      return
    url = f"{self._endpoint}/api/agent-routing?agentId={self._agent_id}"
    if self._environment:
      url += f"&environment={self._environment}"
    req = urllib.request.Request(
        url,
        headers={
          "X-Api-Key": self._api_key,
          "Content-Type": "application/json",
        },
    )
    try:
      with urllib.request.urlopen(req, timeout=5) as resp:
        data = json.loads(resp.read().decode())
        with self._lock:
          self._config = RoutingConfig(data)
    except Exception:
      # Non-fatal: keep existing config
      pass

  def _poll_loop(self) -> None:
    while not self._stop.wait(self._poll_interval):
      try:
        self._fetch()
      except Exception:
        pass

  def get_version(self) -> Optional[str]:
    """
    Returns the version this request should use based on the current traffic split.
    Call once per agent invocation, before running the agent.
    """
    with self._lock:
      config = self._config
    if config is None:
      return None
    return config.select_version()

  def get_config(self) -> Optional[RoutingConfig]:
    with self._lock:
      return self._config

  def stop(self) -> None:
    self._stop.set()

  def start(self) -> None:
    """Start polling if not already running. Call after bootstrap() if constructed early."""
    if self._thread is None and self._endpoint and self._agent_id:
      self._stop.clear()
      self._thread = threading.Thread(target=self._poll_loop, daemon=True)
      self._thread.start()


# Module-level singleton for simple usage
_default_client: Optional[RoutingClient] = None


def init_routing(
    api_key: Optional[str] = None,
    endpoint: Optional[str] = None,
    agent_id: Optional[str] = None,
    environment: Optional[str] = None,
) -> RoutingClient:
  """Initialise the module-level routing client. Call once at startup."""
  global _default_client
  _default_client = RoutingClient(
      api_key=api_key,
      endpoint=endpoint,
      agent_id=agent_id,
      environment=environment,
  )
  return _default_client


def get_version() -> Optional[str]:
  """Get the routed version from the module-level client."""
  if _default_client is None:
    return None
  return _default_client.get_version()

