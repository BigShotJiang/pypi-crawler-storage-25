"""
Orchestrates deploy/rollback/sdk_upgrade/config using deploy_handler, rollback_handler,
bootstrap_apply (ENV + wrapper + pip), env_manager, and process_manager.

Order: applyBootstrap(config) → action → restart when required (see below).

Restart policy:
- deploy / rollback: restart after success if bootstrap changed OR deploy/rollback ran (successful
  run_deploy/run_rollback always counts as deployment action executed).
- config_update: restart only if bootstrap apply changed state (needs_restart).
- restart_host_process: explicit restart (control command).
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional

from puvinoise.agent_runtime.bootstrap_apply import apply_bootstrap_from_config
from puvinoise.agent_runtime.deploy_handler import run_deploy, run_sdk_upgrade
from puvinoise.agent_runtime.env_manager import fetch_agent_config
from puvinoise.agent_runtime.process_manager import ProcessManager
from puvinoise.agent_runtime.rollback_handler import run_rollback
from puvinoise.agent_runtime.runtime_flags import (
    require_runtime_exec,
    restart_approval_required,
    restart_approval_granted,
)


def _deployment_id_from_data(data: Dict[str, Any], payload: Optional[Dict[str, Any]]) -> Optional[str]:
    if payload and isinstance(payload.get("deploymentId"), str):
        s = payload["deploymentId"].strip()
        if s:
            return s
    cfg = data.get("config") or {}
    if isinstance(cfg, dict) and cfg.get("deploymentId"):
        return str(cfg["deploymentId"]).strip() or None
    return (os.environ.get("PUVINOISE_DEPLOYMENT_ID") or "").strip() or None


class ControlRuntimeExecutor:
    """Per-agent execution context (env-driven scripts + optional git/artifact/pip)."""

    def __init__(
        self,
        base_url: str,
        agent_id: str,
        api_key: str,
    ):
        self._base_url = base_url
        self._agent_id = (agent_id or "").strip()
        self._api_key = (api_key or "").strip()
        self._workdir = (os.environ.get("PUVINOISE_AGENT_WORKDIR") or "").strip()
        self._git_remote = (os.environ.get("PUVINOISE_GIT_REMOTE") or "origin").strip() or "origin"
        self._checkout_mode = (os.environ.get("PUVINOISE_GIT_CHECKOUT_MODE") or "tag").strip().lower()
        self._artifact_template = (os.environ.get("PUVINOISE_ARTIFACT_URL_TEMPLATE") or "").strip()
        self._env_file = (os.environ.get("PUVINOISE_ENV_FILE") or "").strip()
        self._pip_pkg = (os.environ.get("PUVINOISE_PIP_PACKAGE") or "puvinoise-sdk").strip() or "puvinoise-sdk"
        self._pip_extra = os.environ.get("PUVINOISE_PIP_EXTRA_ARGS") or ""

    def _pm(self) -> ProcessManager:
        return ProcessManager(self._workdir or None)

    def _restart_with_events(self, *, force: bool = False) -> bool:
        if (not force) and restart_approval_required() and not restart_approval_granted():
            try:
                from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

                post_control_execution_event_from_env(
                    "restart_approval_required",
                    "Restart withheld pending approval. Set PUVINOISE_RESTART_APPROVED=1 or create approval file.",
                )
            except Exception:
                pass
            return False
        try:
            from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

            post_control_execution_event_from_env("restart_started", "Restarting host process")
        except Exception:
            pass
        self._pm().restart()
        try:
            from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

            post_control_execution_event_from_env("restart_completed", "Host process restart completed")
        except Exception:
            pass
        return True

    def deploy(self, version: str, payload: Optional[Dict[str, Any]] = None) -> None:
        require_runtime_exec()
        data = fetch_agent_config(self._base_url, self._agent_id, self._api_key)
        dep_id = _deployment_id_from_data(data, payload)
        apply_bootstrap_from_config(
            data,
            payload=payload,
            env_file=self._env_file or None,
            workdir=self._workdir,
            pip_pkg=self._pip_pkg,
            pip_extra=self._pip_extra,
            deployment_id=dep_id,
        )
        run_deploy(
            version,
            payload,
            process_manager=self._pm(),
            workdir=self._workdir,
            artifact_template=self._artifact_template,
            checkout_mode=self._checkout_mode,
            git_remote=self._git_remote,
            restart_after=False,
        )
        # Successful deploy: restart (bootstrap may have changed and/or deploy action executed).
        self._restart_with_events()

    def rollback(self, version: str, payload: Optional[Dict[str, Any]] = None) -> None:
        require_runtime_exec()
        data = fetch_agent_config(self._base_url, self._agent_id, self._api_key)
        dep_id = _deployment_id_from_data(data, payload)
        apply_bootstrap_from_config(
            data,
            payload=payload,
            env_file=self._env_file or None,
            workdir=self._workdir,
            pip_pkg=self._pip_pkg,
            pip_extra=self._pip_extra,
            deployment_id=dep_id,
        )
        run_rollback(
            version,
            payload,
            process_manager=self._pm(),
            workdir=self._workdir,
            artifact_template=self._artifact_template,
            checkout_mode=self._checkout_mode,
            git_remote=self._git_remote,
            restart_after=False,
        )
        self._restart_with_events()

    def sdk_upgrade(self, version: str, payload: Optional[Dict[str, Any]] = None) -> None:
        require_runtime_exec()
        data = fetch_agent_config(self._base_url, self._agent_id, self._api_key)
        dep_id = _deployment_id_from_data(data, payload)
        apply_bootstrap_from_config(
            data,
            payload=payload,
            env_file=self._env_file or None,
            workdir=self._workdir,
            pip_pkg=self._pip_pkg,
            pip_extra=self._pip_extra,
            deployment_id=dep_id,
        )
        run_sdk_upgrade(
            version,
            payload,
            process_manager=self._pm(),
            pip_pkg=self._pip_pkg,
            pip_extra=self._pip_extra,
        )

    def config_update_from_platform(
        self,
        payload: Optional[Dict[str, Any]] = None,
        restart: bool = True,
    ) -> None:
        """Fetch config from platform, apply env file. restart=False skips process restart (hot_reload)."""
        require_runtime_exec()
        data = fetch_agent_config(self._base_url, self._agent_id, self._api_key)
        dep_id = _deployment_id_from_data(data, payload)
        r = apply_bootstrap_from_config(
            data,
            payload=payload,
            env_file=self._env_file or None,
            workdir=self._workdir,
            pip_pkg=self._pip_pkg,
            pip_extra=self._pip_extra,
            deployment_id=dep_id,
        )
        if restart and r.needs_restart:
            self._restart_with_events()

    def restart_host_process(self) -> None:
        """Explicit restart (control command); treated as operator-approved."""
        require_runtime_exec()
        self._restart_with_events(force=True)

    def stop_host_process(self) -> None:
        require_runtime_exec()
        self._pm().stop()

    def start_host_process(self) -> None:
        require_runtime_exec()
        self._pm().start()


def get_runtime_executor(base_url: str, agent_id: str, api_key: str) -> ControlRuntimeExecutor:
    return ControlRuntimeExecutor(base_url, agent_id, api_key)
