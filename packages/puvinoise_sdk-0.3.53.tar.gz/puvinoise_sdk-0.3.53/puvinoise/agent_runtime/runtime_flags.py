"""Feature flags for host execution (opt-in; telemetry works without these)."""

from __future__ import annotations

import os
import pathlib


def _truthy(name: str, default: str = "0") -> bool:
    return os.environ.get(name, default).strip().lower() in ("1", "true", "yes", "on")


def runtime_exec_enabled() -> bool:
    """When True, deploy/rollback/pip/env/process scripts may run."""
    return _truthy("PUVINOISE_CONTROL_RUNTIME_EXEC", "0")


def require_runtime_exec() -> None:
    if not runtime_exec_enabled():
        raise RuntimeError(
            "PUVINOISE_CONTROL_RUNTIME_EXEC=1 is required for built-in deploy/rollback/pip/env actions"
        )


def restart_after_sdk_upgrade() -> bool:
    return _truthy("PUVINOISE_RESTART_AFTER_SDK_UPGRADE", "0")


def restart_approval_required() -> bool:
    """
    Restart safety policy:
    - If PUVINOISE_RESTART_APPROVAL_REQUIRED is set, honor it.
    - Otherwise, require explicit approval in production environments.
    """
    explicit = os.environ.get("PUVINOISE_RESTART_APPROVAL_REQUIRED")
    if explicit is not None and str(explicit).strip() != "":
        return str(explicit).strip().lower() in ("1", "true", "yes", "on")
    env_name = (os.environ.get("PUVINOISE_DEPLOY_ENV") or os.environ.get("DEPLOYMENT_ENV") or "").strip().lower()
    return env_name in ("prod", "production")


def restart_approval_granted() -> bool:
    """
    Restart approval can be granted via:
    - PUVINOISE_RESTART_APPROVED=1
    - Presence of approval file path (PUVINOISE_RESTART_APPROVAL_FILE)
    """
    if _truthy("PUVINOISE_RESTART_APPROVED", "0"):
        return True
    approval_path = (
        os.environ.get("PUVINOISE_RESTART_APPROVAL_FILE")
        or os.path.join(os.path.expanduser("~"), ".puvinoise", "restart.approved")
    ).strip()
    if not approval_path:
        return False
    try:
        return pathlib.Path(approval_path).expanduser().exists()
    except Exception:
        return False
