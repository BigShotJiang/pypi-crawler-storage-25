"""Shell hooks for restart / stop / start (execution plane)."""

from __future__ import annotations

import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger(__name__)


class ProcessManager:
    """Runs optional scripts from env: RESTART, STOP, START."""

    def __init__(self, workdir: Optional[str] = None):
        self.workdir = (workdir or os.environ.get("PUVINOISE_AGENT_WORKDIR") or "").strip() or None

    def run_script(self, script: str, args: list[str], *, cwd: Optional[str] = None) -> None:
        path = (script or "").strip()
        if not path:
            raise RuntimeError("Script path is empty")
        cmd = [path, *args]
        logger.info("process_manager script: %s", cmd)
        subprocess.run(cmd, check=True, cwd=cwd or self.workdir, env=os.environ.copy())

    def restart(self) -> None:
        rs = (os.environ.get("PUVINOISE_RESTART_SCRIPT") or "").strip()
        if not rs:
            raise RuntimeError(
                "PUVINOISE_RESTART_SCRIPT is not set; host restart was not executed. "
                "Apply bootstrap pull config (writes puvinoise-agent-restart.sh) or set the env var."
            )
        self.run_script(rs, ["restart"], cwd=None)

    def stop(self) -> None:
        ss = (os.environ.get("PUVINOISE_STOP_SCRIPT") or "").strip()
        if not ss:
            logger.warning(
                "PUVINOISE_STOP_SCRIPT not set; stop command only flushes telemetry and sets stopped state."
            )
            return
        self.run_script(ss, ["stop"])

    def start(self) -> None:
        ss = (os.environ.get("PUVINOISE_START_SCRIPT") or "").strip()
        if not ss:
            logger.warning("PUVINOISE_START_SCRIPT not set; nothing to start.")
            return
        self.run_script(ss, ["start"])
