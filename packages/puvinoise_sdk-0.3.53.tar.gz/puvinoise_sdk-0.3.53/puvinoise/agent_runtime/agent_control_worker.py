"""
Optional control-plane poller (prefer running in the Agent / supervisor, not minimal SDK apps).

Polls GET /api/agent-control/{agentId} at a configurable interval, detects new
commands, and dispatches to internal handlers via a command router. Handlers are
hooks that the agent runtime may override; this module does not assume any
specific agent framework.

Bootstrap may auto-start when PUVINOISE_BASE_URL + PUVINOISE_API_KEY + PUVINOISE_AGENT_ID are set
(Fix & Upgrade / deployments). Exponential backoff applies when the server is unreachable.

Supported commands: pause, resume, stop, restart, start (host), deploy, rollback,
sdk_upgrade, config_update.

When PUVINOISE_CONTROL_RUNTIME_EXEC=1 and paths/scripts are set, default deploy/rollback
handlers run git/artifact/pip, write .env, and invoke restart/stop/start scripts.
Override via lifecycle_hooks for custom behaviour.
Emits telemetry events (agent.control.*) through the existing pipeline.
"""

from __future__ import annotations

import asyncio
import logging
import os
import pathlib
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Union, Awaitable

from puvinoise.env_keys import get_api_key

logger = logging.getLogger(__name__)

CONTROL_EVENT_PREFIX = "agent.control."
VALID_COMMANDS = (
    "pause",
    "resume",
    "stop",
    "force_kill",
    "restart",
    "start",
    "deploy",
    "redeploy",
    "rollback",
    "sdk_upgrade",
    "config_update",
    "hot_reload",
    "pin_version",
    "decommission",
    "write_contract_file",   # Contract discovery: PUVINoise writes puvinoise-agent.yaml
)

DEFAULT_POLL_INTERVAL_SEC = 5.0
CONTROL_BACKOFF_BASE_SEC = 5.0
CONTROL_BACKOFF_MAX_SEC = 300.0
CONTROL_BACKOFF_MULTIPLIER = 2.0


@dataclass
class ControlCommand:
    """Parsed control response from the platform."""

    command: str
    command_id: Optional[str] = None  # API: commandId; used for dedupe
    timestamp: Optional[str] = None
    version: Optional[str] = None
    payload: Optional[dict] = None  # e.g. fixHints, sdkTemplate from compliance fix


# Type for a handler that accepts optional version; may be sync or async.
ControlHandler = Callable[[Optional[str]], Union[None, Awaitable[None]]]

# Lifecycle hooks: callables invoked on stop/restart. Override for custom behaviour.
OnAgentStopHook = Callable[[], Union[None, Awaitable[None]]]
OnAgentStartHook = Callable[[], Union[None, Awaitable[None]]]
OnAgentRestartHook = Callable[[], Union[None, Awaitable[None]]]
# Deploy/rollback: SDK notifies host only; host handles version changes.
OnDeployRequestedHook = Callable[[str], Union[None, Awaitable[None]]]
OnRollbackRequestedHook = Callable[[str], Union[None, Awaitable[None]]]


def _noop(_version: Optional[str] = None) -> None:
    """Placeholder handler (no-op). Override via handlers dict or subclassing."""
    pass


class AgentControlWorker:
    """
    Polls the control endpoint and dispatches commands to handlers.
    Prevents duplicate execution of the same command (same command + timestamp).
    """

    def __init__(
        self,
        agent_id: str,
        base_url: str,
        *,
        poll_interval_seconds: float = DEFAULT_POLL_INTERVAL_SEC,
        api_key: Optional[str] = None,
        handlers: Optional[dict[str, ControlHandler]] = None,
        lifecycle_hooks: Optional[dict] = None,
    ):
        """
        Args:
            agent_id: Agent identifier (used in GET /api/agent-control/{agent_id}).
            base_url: Platform base URL (e.g. https://api.example.com), no trailing slash.
            poll_interval_seconds: Seconds between polls (default 5).
            api_key: Optional API key for Authorization header.
            handlers: Optional map of command name -> callable(version). Unlisted commands use no-op.
            lifecycle_hooks: Optional dict with keys: "on_agent_stop", "on_agent_start", "on_agent_restart",
                "on_deploy_requested", "on_rollback_requested" to override default behaviour.
        """
        self._agent_id = agent_id
        self._base_url = base_url.rstrip("/")
        self._poll_interval = max(0.5, float(poll_interval_seconds))
        self._api_key = api_key or os.environ.get("PUVINOISE_API_KEY", "").strip()
        self._handlers = dict(handlers) if handlers else {}
        hooks = lifecycle_hooks or {}
        self._on_agent_stop = hooks.get("on_agent_stop") or self._default_on_agent_stop
        self._on_agent_start = hooks.get("on_agent_start") or self._default_on_agent_start
        self._on_agent_restart = hooks.get("on_agent_restart") or self._default_on_agent_restart
        self._on_deploy_requested = hooks.get("on_deploy_requested") or self._default_on_deploy_requested
        self._on_rollback_requested = hooks.get("on_rollback_requested") or self._default_on_rollback_requested

        self._control_url = f"{self._base_url}/api/agent-control/{self._agent_id}"
        self._last_executed_command_id: Optional[str] = None  # last commandId executed
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._next_poll_wait = self._poll_interval  # for exponential backoff on API failure
        self._logged_control_401_hint = False  # one-time message when server rejects access key

        # Internal agent state (pause/resume/stop). Access under _lock.
        self._paused = False
        self._stopped = False
        self._resume_event = threading.Event()  # set when not paused; wait_if_paused blocks on this
        self._resume_event.set()  # initially not paused
        self._control_command_context: Optional[ControlCommand] = None
        # When True, start() does not spawn _poll_loop; caller must invoke poll_once() (e.g. SDK heartbeat).
        self._poll_via_heartbeat: bool = False

        try:
            from puvinoise.agent_runtime.pidfile import write_control_plane_pidfile

            write_control_plane_pidfile()
        except Exception:
            pass

    # -------------------------------------------------------------------------
    # Command router: dispatch_agent_command maps API command -> handler.
    # -------------------------------------------------------------------------

    def _call_version_payload_hook(
        self,
        fn: Callable[..., Union[None, Awaitable[None]]],
        version: str,
        payload: Optional[Dict[str, Any]],
    ) -> None:
        """Call hook with (version, payload) or (version) for backward compatibility."""
        try:
            result = fn(version, payload)
        except TypeError:
            result = fn(version)
        if asyncio.iscoroutine(result):
            asyncio.run(result)

    def dispatch_agent_command(self, command: ControlCommand) -> None:
        """
        Route a control command to the appropriate handler.
        Ignores commands already executed (by commandId), stores last commandId,
        supports async handlers, and logs execution.
        """
        command_id = (command.command_id or "").strip() or None
        cmd_name = (command.command or "").strip().lower()
        dedupe_key = command_id or f"{(command.command or '').strip()}:{(command.timestamp or '').strip()}"
        with self._lock:
            if dedupe_key and dedupe_key == self._last_executed_command_id:
                logger.debug("Ignoring already executed command commandId=%s", dedupe_key)
                # If completion delivery previously failed, the same command can remain at queue head.
                # Re-send completion idempotently so the control queue can advance.
                self._maybe_post_completion(command_id, cmd_name, "ok", None)
                return
            self._last_executed_command_id = dedupe_key

        version = (command.version or "").strip() or None

        logger.info(
            "CONTROL_COMMAND_RECEIVED command=%s commandId=%s version=%s",
            cmd_name,
            command_id or "(none)",
            version or "(none)",
        )

        if cmd_name not in VALID_COMMANDS:
            logger.debug("Unknown control command: %s", cmd_name)
            return

        prev_env = os.environ.get("PUVINOISE_CONTROL_COMMAND_ID")
        os.environ["PUVINOISE_CONTROL_COMMAND_ID"] = command_id or ""
        prev_dep_env = os.environ.get("PUVINOISE_DEPLOYMENT_ID")
        if command.payload and isinstance(command.payload, dict):
            did = command.payload.get("deploymentId")
            if did:
                os.environ["PUVINOISE_DEPLOYMENT_ID"] = str(did).strip()
        ctx_prev = getattr(self, "_control_command_context", None)
        self._control_command_context = command

        status = "ok"
        err_detail: Optional[str] = None
        try:
            result = None
            if cmd_name == "pause":
                result = self.handle_pause(version)
            elif cmd_name == "resume":
                result = self.handle_resume(version)
            elif cmd_name == "stop":
                result = self.handle_stop(version)
            elif cmd_name == "force_kill":
                result = self.handle_force_kill()
            elif cmd_name == "restart":
                result = self.handle_restart(version)
            elif cmd_name == "start":
                result = self.handle_process_start(version)
            elif cmd_name == "deploy":
                result = self.handle_deploy(version)
            elif cmd_name == "redeploy":
                result = self.handle_redeploy(version)
            elif cmd_name == "rollback":
                result = self.handle_rollback(version)
            elif cmd_name == "sdk_upgrade":
                result = self.handle_sdk_upgrade(version)
            elif cmd_name == "config_update":
                result = self.handle_config_update(version)
            elif cmd_name == "hot_reload":
                result = self.handle_hot_reload(version)
            elif cmd_name == "pin_version":
                result = self.handle_pin_version(version)
            elif cmd_name == "decommission":
                result = self.handle_decommission(version)
            elif cmd_name == "write_contract_file":
                result = self.handle_write_contract_file(command)

            if asyncio.iscoroutine(result):
                asyncio.run(result)
        except Exception as e:
            status = "failed"
            err_detail = str(e)[:2000]
            logger.warning("Control handler failed for command %s: %s", cmd_name, e)
        finally:
            logger.info(
                "CONTROL_COMMAND_FINISHED command=%s commandId=%s status=%s",
                cmd_name,
                command_id or "(none)",
                status,
            )
            self._control_command_context = ctx_prev
            self._emit_control_event(
                command=cmd_name,
                command_id=command_id,
                timestamp=command.timestamp,
                status=status,
                payload=command.payload,
            )
            self._maybe_post_completion(command_id, cmd_name, status, err_detail)
            try:
                if prev_env is not None:
                    os.environ["PUVINOISE_CONTROL_COMMAND_ID"] = prev_env
                else:
                    os.environ.pop("PUVINOISE_CONTROL_COMMAND_ID", None)
                if prev_dep_env is not None:
                    os.environ["PUVINOISE_DEPLOYMENT_ID"] = prev_dep_env
                else:
                    os.environ.pop("PUVINOISE_DEPLOYMENT_ID", None)
            except Exception:
                pass

    def _emit_control_event(
        self,
        command: str,
        command_id: Optional[str],
        timestamp: Optional[str],
        status: str,
        payload: Optional[dict] = None,
    ) -> None:
        """
        Emit a control command event through the existing telemetry pipeline.
        Event name: agent.control.{command}. Payload: agentId, command, commandId, timestamp, status.
        Failures are logged at debug and do not affect control flow.
        """
        if command not in VALID_COMMANDS:
            return
        event_name = f"{CONTROL_EVENT_PREFIX}{command}"
        try:
            from opentelemetry import trace
            from opentelemetry.trace import Status, StatusCode
            tracer = trace.get_tracer("puvinoise.agent_runtime", None)
            with tracer.start_as_current_span(event_name) as span:
                span.set_attribute("agentId", self._agent_id)
                span.set_attribute("command", command)
                if command_id:
                    span.set_attribute("commandId", command_id)
                if timestamp:
                    span.set_attribute("timestamp", timestamp)
                span.set_attribute("status", status)
                if payload:
                    try:
                        import json

                        span.set_attribute(
                            "puvinoise.agent_runtime.payload",
                            json.dumps(payload, default=str)[:4000],
                        )
                    except Exception:
                        pass
                if status == "failed":
                    span.set_status(Status(StatusCode.ERROR))
                else:
                    span.set_status(Status(StatusCode.OK))
        except Exception as e:
            logger.debug("Control telemetry emit failed: %s", e)

    def _maybe_post_completion(
        self,
        command_id: Optional[str],
        cmd_name: str,
        status: str,
        err_detail: Optional[str],
    ) -> None:
        """PATCH /api/agent-control/:id/complete — skipped when success may terminate the process."""
        if not command_id:
            return
        if cmd_name == "restart" and status == "ok":
            # Restart completion is verified server-side by a subsequent agent.startup span.
            return
        if cmd_name == "stop" and status == "ok":
            # Stop posts status=stopping from _finalize_controlled_stop; verified via agent.stop span.
            return
        if cmd_name == "force_kill" and status == "ok":
            # Force kill posts status=killing from handle_force_kill; verified via agent.force_kill span.
            return
        if cmd_name == "start" and status == "ok":
            # Start posts status=starting from _finalize_process_start; verified via agent.start span.
            return
        if cmd_name == "pause" and status == "ok":
            # Pause posts status=pausing from _finalize_controlled_pause; verified via agent.pause span.
            return
        if cmd_name == "resume" and status == "ok":
            # Resume posts status=resuming from _finalize_controlled_resume; verified via agent.resume span.
            return
        if cmd_name == "rollback" and status == "ok":
            # Rollback posts status=rolling_back from _finalize_controlled_rollback; verified via agent.rollback span.
            return
        try:
            from puvinoise.agent_runtime.completion import post_control_command_completion

            post_control_command_completion(
                self._base_url,
                self._agent_id,
                self._resolve_api_key(),
                command_id,
                "completed" if status == "ok" else "failed",
                err_detail if status != "ok" else None,
            )
        except Exception as e:
            logger.debug("post completion: %s", e)

    def _emit_agent_stop_span(self) -> None:
        """OTLP span agent.stop — non-blocking; ground truth for server-side confirmation."""
        try:
            from datetime import datetime, timezone

            from opentelemetry import trace

            agent_id = str(self._agent_id or "").strip()
            tenant_id = (
                (os.environ.get("PUVINOISE_TENANTID") or "").strip()
            )
            ver = os.environ.get("AGENT_VERSION", "unknown")
            tracer = trace.get_tracer("puvinoise.sdk.stop")
            with tracer.start_as_current_span("agent.stop") as span:
                span.set_attribute("agent.id", agent_id)
                span.set_attribute("agent.pid", int(os.getpid()))
                span.set_attribute("agent.version", str(ver))
                span.set_attribute("agent.stop_cause", "control_command")
                span.set_attribute("agent.stop_time", datetime.now(timezone.utc).isoformat())
                if tenant_id:
                    span.set_attribute("puvi.tenant_id", tenant_id)
                    span.set_attribute("tenant.id", tenant_id)
            try:
                provider = trace.get_tracer_provider()
                if hasattr(provider, "force_flush"):
                    provider.force_flush(timeout_millis=2000)
            except Exception:
                pass
        except Exception as e:
            logger.debug("agent.stop span emit failed: %s", e)

    def _emit_agent_start_span(self) -> None:
        """OTLP span agent.start — non-blocking; pairs with PATCH status=starting for server confirmation."""
        try:
            from datetime import datetime, timezone

            from opentelemetry import trace

            agent_id = str(self._agent_id or "").strip()
            tenant_id = (
                (os.environ.get("PUVINOISE_TENANTID") or "").strip()
            )
            ver = os.environ.get("AGENT_VERSION", "unknown")
            tracer = trace.get_tracer("puvinoise.sdk.start")
            with tracer.start_as_current_span("agent.start") as span:
                span.set_attribute("agent.id", agent_id)
                span.set_attribute("agent.pid", int(os.getpid()))
                span.set_attribute("agent.version", str(ver))
                span.set_attribute("agent.start_cause", "control_command")
                span.set_attribute("agent.start_time", datetime.now(timezone.utc).isoformat())
                if tenant_id:
                    span.set_attribute("puvi.tenant_id", tenant_id)
                    span.set_attribute("tenant.id", tenant_id)
            try:
                provider = trace.get_tracer_provider()
                if hasattr(provider, "force_flush"):
                    provider.force_flush(timeout_millis=2000)
            except Exception:
                pass
        except Exception as e:
            logger.debug("agent.start span emit failed: %s", e)

    def _emit_agent_pause_span(self) -> None:
        """OTLP span agent.pause — non-blocking; pairs with PATCH status=pausing for server confirmation."""
        try:
            from datetime import datetime, timezone

            from opentelemetry import trace

            agent_id = str(self._agent_id or "").strip()
            tenant_id = (
                (os.environ.get("PUVINOISE_TENANTID") or "").strip()
            )
            ver = os.environ.get("AGENT_VERSION", "unknown")
            tracer = trace.get_tracer("puvinoise.sdk.pause")
            with tracer.start_as_current_span("agent.pause") as span:
                span.set_attribute("agent.id", agent_id)
                span.set_attribute("agent.pid", int(os.getpid()))
                span.set_attribute("agent.version", str(ver))
                span.set_attribute("agent.pause_cause", "control_command")
                span.set_attribute("agent.pause_time", datetime.now(timezone.utc).isoformat())
                if tenant_id:
                    span.set_attribute("puvi.tenant_id", tenant_id)
                    span.set_attribute("tenant.id", tenant_id)
            try:
                provider = trace.get_tracer_provider()
                if hasattr(provider, "force_flush"):
                    provider.force_flush(timeout_millis=2000)
            except Exception:
                pass
        except Exception as e:
            logger.debug("agent.pause span emit failed: %s", e)

    def _emit_agent_resume_span(self) -> None:
        """OTLP span agent.resume — non-blocking; pairs with PATCH status=resuming for server confirmation."""
        try:
            from datetime import datetime, timezone

            from opentelemetry import trace

            agent_id = str(self._agent_id or "").strip()
            tenant_id = (
                (os.environ.get("PUVINOISE_TENANTID") or "").strip()
            )
            ver = os.environ.get("AGENT_VERSION", "unknown")
            tracer = trace.get_tracer("puvinoise.sdk.resume")
            with tracer.start_as_current_span("agent.resume") as span:
                span.set_attribute("agent.id", agent_id)
                span.set_attribute("agent.pid", int(os.getpid()))
                span.set_attribute("agent.version", str(ver))
                span.set_attribute("agent.resume_cause", "control_command")
                span.set_attribute("agent.resume_time", datetime.now(timezone.utc).isoformat())
                if tenant_id:
                    span.set_attribute("puvi.tenant_id", tenant_id)
                    span.set_attribute("tenant.id", tenant_id)
            try:
                provider = trace.get_tracer_provider()
                if hasattr(provider, "force_flush"):
                    provider.force_flush(timeout_millis=2000)
            except Exception:
                pass
        except Exception as e:
            logger.debug("agent.resume span emit failed: %s", e)

    def _emit_agent_rollback_span(self) -> None:
        """OTLP span agent.rollback — non-blocking; pairs with PATCH status=rolling_back for server confirmation."""
        try:
            from datetime import datetime

            from opentelemetry import trace

            agent_id = str(self._agent_id or "").strip()
            tenant_id = (
                (os.environ.get("PUVINOISE_TENANTID") or "").strip()
            )
            ver = os.environ.get("AGENT_VERSION", "unknown")
            ctx = self._control_command_context
            rb_ver = "unknown"
            if ctx and getattr(ctx, "version", None):
                rb_ver = str(ctx.version).strip() or "unknown"
            tracer = trace.get_tracer("puvinoise.sdk.rollback")
            with tracer.start_as_current_span("agent.rollback") as span:
                span.set_attribute("agent.id", agent_id)
                span.set_attribute("agent.pid", int(os.getpid()))
                span.set_attribute("agent.version", str(ver))
                span.set_attribute("agent.rollback_cause", "control_command")
                span.set_attribute("agent.rollback_time", datetime.utcnow().isoformat())
                span.set_attribute("agent.rollback_version", rb_ver)
                if tenant_id:
                    span.set_attribute("puvi.tenant_id", tenant_id)
                    span.set_attribute("tenant.id", tenant_id)
            try:
                provider = trace.get_tracer_provider()
                if hasattr(provider, "force_flush"):
                    provider.force_flush(timeout_millis=2000)
            except Exception:
                pass
        except Exception as e:
            logger.debug("agent.rollback span emit failed: %s", e)

    def _finalize_controlled_rollback(self) -> None:
        """Emit agent.rollback and PATCH rolling_back."""
        self._emit_agent_rollback_span()
        cid = (os.environ.get("PUVINOISE_CONTROL_COMMAND_ID") or "").strip()
        try:
            from puvinoise.agent_runtime.completion import post_control_command_completion

            if cid:
                post_control_command_completion(
                    self._base_url,
                    self._agent_id,
                    self._resolve_api_key(),
                    cid,
                    "rolling_back",
                    None,
                )
        except Exception as e:
            logger.debug("post rolling_back completion: %s", e)

    def _finalize_process_start(self, command_id: Optional[str]) -> None:
        """
        Emit agent.start, PATCH starting, then optional host start script.

        Note: for plain Python processes, 'start' boots a new process via
        PUVINOISE_CONTROL_RUNTIME_EXEC. In TS runtime, start signals the
        agent framework to begin accepting tasks if it was idle.
        process.exit is NOT called here — start keeps the process alive.
        """
        self._emit_agent_start_span()
        cid = (command_id or "").strip() or (os.environ.get("PUVINOISE_CONTROL_COMMAND_ID") or "").strip()
        try:
            from puvinoise.agent_runtime.completion import post_control_command_completion

            if cid:
                post_control_command_completion(
                    self._base_url,
                    self._agent_id,
                    self._resolve_api_key(),
                    cid,
                    "starting",
                    None,
                )
        except Exception as e:
            logger.debug("post starting completion: %s", e)
        try:
            from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
            from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

            if not runtime_exec_enabled():
                return
            ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
            ex.start_host_process()
        except Exception as e:
            logger.warning("Host start script failed: %s", e)

    def _finalize_controlled_pause(self, command_id: Optional[str]) -> None:
        """Emit agent.pause and PATCH pausing."""
        self._emit_agent_pause_span()
        cid = (command_id or "").strip() or (os.environ.get("PUVINOISE_CONTROL_COMMAND_ID") or "").strip()
        try:
            from puvinoise.agent_runtime.completion import post_control_command_completion

            if cid:
                post_control_command_completion(
                    self._base_url,
                    self._agent_id,
                    self._resolve_api_key(),
                    cid,
                    "pausing",
                    None,
                )
        except Exception as e:
            logger.debug("post pausing completion: %s", e)

    def _finalize_controlled_resume(self, command_id: Optional[str]) -> None:
        """Emit agent.resume and PATCH resuming."""
        self._emit_agent_resume_span()
        cid = (command_id or "").strip() or (os.environ.get("PUVINOISE_CONTROL_COMMAND_ID") or "").strip()
        try:
            from puvinoise.agent_runtime.completion import post_control_command_completion

            if cid:
                post_control_command_completion(
                    self._base_url,
                    self._agent_id,
                    self._resolve_api_key(),
                    cid,
                    "resuming",
                    None,
                )
        except Exception as e:
            logger.debug("post resuming completion: %s", e)

    def _finalize_controlled_stop(self, command_id: Optional[str]) -> None:
        """Emit agent.stop, PATCH stopping, set env, optional host stop script, then exit."""
        self._emit_agent_stop_span()
        cid = (command_id or "").strip() or (os.environ.get("PUVINOISE_CONTROL_COMMAND_ID") or "").strip()
        try:
            from puvinoise.agent_runtime.completion import post_control_command_completion

            if cid:
                post_control_command_completion(
                    self._base_url,
                    self._agent_id,
                    self._resolve_api_key(),
                    cid,
                    "stopping",
                    None,
                )
        except Exception as e:
            logger.debug("post stopping completion: %s", e)
        os.environ["PUVINOISE_STOP_CAUSE"] = "control_command"
        self._maybe_stop_host_process()
        sys.exit(0)

    def _emit_agent_force_kill_span(self) -> None:
        """OTLP span agent.force_kill — best-effort before SIGKILL."""
        try:
            from datetime import datetime, timezone

            from opentelemetry import trace

            agent_id = str(self._agent_id or "").strip()
            tenant_id = (
                (os.environ.get("PUVINOISE_TENANTID") or "").strip()
            )
            ver = os.environ.get("AGENT_VERSION", "unknown")
            tracer = trace.get_tracer("puvinoise.sdk.force_kill")
            with tracer.start_as_current_span("agent.force_kill") as span:
                span.set_attribute("agent.id", agent_id)
                span.set_attribute("agent.pid", int(os.getpid()))
                span.set_attribute("agent.version", str(ver))
                span.set_attribute("agent.force_kill_cause", "control_command")
                span.set_attribute("agent.force_kill_time", datetime.now(timezone.utc).isoformat())
                if tenant_id:
                    span.set_attribute("puvi.tenant_id", tenant_id)
                    span.set_attribute("tenant.id", tenant_id)
            try:
                provider = trace.get_tracer_provider()
                if hasattr(provider, "force_flush"):
                    provider.force_flush(timeout_millis=2000)
            except Exception:
                pass
        except Exception as e:
            logger.debug("agent.force_kill span emit failed: %s", e)

    def handle_force_kill(self) -> None:
        """
        Hard kill: no hooks, no handlers, no graceful cleanup. SIGKILL to current process.
        """
        self._emit_agent_force_kill_span()
        cid = None
        if self._control_command_context:
            cid = self._control_command_context.command_id
        cid = (cid or "").strip() or (os.environ.get("PUVINOISE_CONTROL_COMMAND_ID") or "").strip()
        try:
            from puvinoise.agent_runtime.completion import post_control_command_completion

            if cid:
                post_control_command_completion(
                    self._base_url,
                    self._agent_id,
                    self._resolve_api_key(),
                    cid,
                    "killing",
                    None,
                )
        except Exception:
            pass
        os.environ["PUVINOISE_FORCE_KILL_CAUSE"] = "control_command"
        import signal

        os.kill(os.getpid(), signal.SIGKILL)

    # -------------------------------------------------------------------------
    # Internal agent state (pause/resume/stop).
    # -------------------------------------------------------------------------

    @property
    def agent_state(self) -> dict:
        """Current control state: { "paused": bool, "stopped": bool }."""
        with self._lock:
            return {"paused": self._paused, "stopped": self._stopped}

    def is_paused(self) -> bool:
        """True if the agent is currently paused."""
        with self._lock:
            return self._paused

    def is_stopped(self) -> bool:
        """True if the agent has been stopped."""
        with self._lock:
            return self._stopped

    async def wait_if_paused(self) -> None:
        """
        Agent runtimes can call this in their main loop to block execution while paused.
        Returns when not paused. Safe to call repeatedly.

        Example:
            while running:
                await wait_if_paused()
                run_agent_step()
        """
        while True:
            with self._lock:
                if not self._paused:
                    return
                ev = self._resume_event
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None
            if loop is not None:
                await loop.run_in_executor(None, ev.wait)
            else:
                ev.wait(timeout=0.2)

    def wait_if_paused_sync(self) -> None:
        """
        Blocking variant for sync runtimes. Returns when not paused.
        Use in a sync main loop: while running: worker.wait_if_paused_sync(); run_agent_step()
        """
        while self.is_paused():
            self._resume_event.wait(timeout=0.2)

    # -------------------------------------------------------------------------
    # Lifecycle hooks: default implementations (flush telemetry). Override via lifecycle_hooks.
    # -------------------------------------------------------------------------

    def on_agent_stop(self) -> Union[None, Awaitable[None]]:
        """
        Invoked when stop is requested. Override via lifecycle_hooks["on_agent_stop"] or subclassing.
        Default: flush telemetry before exit.
        """
        result = self._on_agent_stop()
        return result

    def on_agent_restart(self) -> Union[None, Awaitable[None]]:
        """
        Invoked after stop() during restart. Override via lifecycle_hooks["on_agent_restart"] or subclassing.
        Default: flush telemetry; override to reinitialize agent runtime and telemetry.
        """
        result = self._on_agent_restart()
        return result

    def _default_on_agent_stop(self) -> None:
        """Default: flush telemetry so nothing is lost before exit."""
        try:
            from puvinoise.bootstrap import force_flush
            from puvinoise.decision_telemetry import flush_decision_events
            force_flush(timeout_millis=5000)
            flush_decision_events(timeout_seconds=5.0)
        except Exception as e:
            logger.debug("Telemetry flush on stop: %s", e)

    def _default_on_agent_start(self) -> None:
        """Default: no-op. Override for custom behaviour when a queued START command is received."""
        pass

    def on_agent_start(self) -> Union[None, Awaitable[None]]:
        """Invoked when a queued start command is received. Override via lifecycle_hooks['on_agent_start']."""
        return self._on_agent_start()

    def _default_on_agent_restart(self) -> None:
        """Default: flush telemetry. Override to reinitialize agent runtime and telemetry (e.g. bootstrap again)."""
        try:
            from puvinoise.bootstrap import force_flush
            from puvinoise.decision_telemetry import flush_decision_events
            force_flush(timeout_millis=5000)
            flush_decision_events(timeout_seconds=5.0)
        except Exception as e:
            logger.debug("Telemetry flush on restart: %s", e)

    def on_deploy_requested(self, version: str) -> Union[None, Awaitable[None]]:
        """
        Invoked when a deploy command is received. Override via lifecycle_hooks["on_deploy_requested"].
        Second arg payload is optional (backward compatible). Default: host deploy via runtime_executor when
        PUVINOISE_CONTROL_RUNTIME_EXEC=1.
        """
        pl = self._control_command_context.payload if self._control_command_context else None
        self._call_version_payload_hook(self._on_deploy_requested, version or "", pl)
        return None

    def on_rollback_requested(self, version: str) -> Union[None, Awaitable[None]]:
        """
        Invoked when a rollback command is received. Override via lifecycle_hooks["on_rollback_requested"].
        Default: git/artifact rollback via runtime_executor when PUVINOISE_CONTROL_RUNTIME_EXEC=1.
        """
        pl = self._control_command_context.payload if self._control_command_context else None
        self._call_version_payload_hook(self._on_rollback_requested, version or "", pl)
        return None

    def _default_on_deploy_requested(self, version: str, payload: Optional[Dict[str, Any]] = None) -> None:
        """Git/artifact deploy and optional restart when PUVINOISE_CONTROL_RUNTIME_EXEC=1."""
        from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
        from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

        if not runtime_exec_enabled():
            logger.info(
                "deploy skipped: set PUVINOISE_CONTROL_RUNTIME_EXEC=1 plus PUVINOISE_AGENT_WORKDIR "
                "or PUVINOISE_DEPLOY_SCRIPT (see runtime_executor)."
            )
            return
        ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
        ex.deploy(version, payload)

    def _default_on_rollback_requested(self, version: str, payload: Optional[Dict[str, Any]] = None) -> None:
        if not (version or "").strip():
            raise RuntimeError("rollback: version is required")
        from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
        from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

        if not runtime_exec_enabled():
            logger.info(
                "rollback skipped: set PUVINOISE_CONTROL_RUNTIME_EXEC=1 plus workdir/scripts (see runtime_executor)."
            )
            return
        ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
        ex.rollback(version, payload)

    # -------------------------------------------------------------------------
    # Handlers: pause/resume update state and log; stop/restart use lifecycle hooks.
    # -------------------------------------------------------------------------

    def handle_pause(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """Set paused=True, log, then invoke optional handlers['pause']."""
        with self._lock:
            self._paused = True
            self._resume_event.clear()
        logger.info("Agent paused by PUVINoise")
        fn = self._handlers.get("pause", _noop)
        handler_result = fn(version)
        cmd_id = None
        if self._control_command_context:
            cmd_id = self._control_command_context.command_id

        if asyncio.iscoroutine(handler_result):
            async def _await_then_pause() -> None:
                await handler_result
                self._finalize_controlled_pause(cmd_id)

            return _await_then_pause()

        self._finalize_controlled_pause(cmd_id)
        return None

    def handle_resume(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """Set paused=False, log, then invoke optional handlers['resume']."""
        with self._lock:
            self._paused = False
            self._resume_event.set()
        logger.info("Agent resumed by PUVINoise")
        fn = self._handlers.get("resume", _noop)
        handler_result = fn(version)
        cmd_id = None
        if self._control_command_context:
            cmd_id = self._control_command_context.command_id

        if asyncio.iscoroutine(handler_result):
            async def _await_then_resume() -> None:
                await handler_result
                self._finalize_controlled_resume(cmd_id)

            return _await_then_resume()

        self._finalize_controlled_resume(cmd_id)
        return None

    def handle_stop(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Stop: set agentState.stopped = True, run on_agent_stop() (default: flush telemetry),
        then optional handlers['stop'], then emit agent.stop + PATCH stopping + sys.exit(0).
        """
        with self._lock:
            self._stopped = True
        logger.info("Agent stopped by PUVINoise")
        result = self.on_agent_stop()
        if asyncio.iscoroutine(result):
            asyncio.run(result)
        fn = self._handlers.get("stop", _noop)
        handler_result = fn(version)
        cmd_id = None
        if self._control_command_context:
            cmd_id = self._control_command_context.command_id

        if asyncio.iscoroutine(handler_result):

            async def _await_then_exit() -> None:
                await handler_result
                self._finalize_controlled_stop(cmd_id)

            return _await_then_exit()

        self._finalize_controlled_stop(cmd_id)
        return None

    def handle_restart(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Soft restart: do **not** call handle_stop().

        Previously, restart invoked handle_stop(), which sets ``_stopped = True`` and runs full
        stop semantics. Many runtimes exit their main loop when ``is_stopped()`` becomes true,
        so the process could terminate before restart completed; the control thread could also
        drop an async ``handlers['stop']`` coroutine because handle_restart ignored the return
        value of handle_stop.

        Restart instead runs ``on_agent_restart()`` (default: flush telemetry) and optional
        ``handlers['restart']`` only. Use the **stop** command for a hard stop; override
        ``on_agent_restart`` / ``handlers['restart']`` to reload config or re-bootstrap.
        """
        logger.info("Agent restart by PUVINoise")
        try:
            from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

            post_control_execution_event_from_env("restart_started", "Restarting...")
        except Exception:
            pass
        try:
            result = self.on_agent_restart()
            if asyncio.iscoroutine(result):
                asyncio.run(result)
            fn = self._handlers.get("restart", _noop)
            handler_result = fn(version)
            if asyncio.iscoroutine(handler_result):
                return handler_result
            self._maybe_restart_host_process()
            try:
                from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

                post_control_execution_event_from_env("restart_completed", "Restart completed")
            except Exception:
                pass
            os.environ["PUVINOISE_RESTART_CAUSE"] = "control_command"
            # NOTE: requires process supervisor when this process is not directly managed by the SDK runtime executor.
            os.execv(sys.executable, [sys.executable] + sys.argv)
            return None
        except Exception as e:
            try:
                from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

                post_control_execution_event_from_env(
                    "restart_failed",
                    str(e)[:500],
                    error=str(e)[:2000],
                )
            except Exception:
                pass
            raise

    def _maybe_stop_host_process(self) -> None:
        try:
            from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
            from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

            if not runtime_exec_enabled():
                return
            ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
            ex.stop_host_process()
        except Exception as e:
            logger.warning("Host stop script failed: %s", e)

    def _maybe_restart_host_process(self) -> None:
        from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
        from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

        if not runtime_exec_enabled():
            return
        ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
        ex.restart_host_process()

    def handle_deploy(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Deploy: log structured event, invoke on_deploy_requested (default: runtime_executor). Then handlers['deploy'].
        """
        v = (version or "").strip() or ""
        logger.info(
            "action=deploy_requested agent_id=%s version=%s",
            self._agent_id,
            v or "(none)",
            extra={"action": "deploy_requested", "agent_id": self._agent_id, "version": v},
        )
        self.on_deploy_requested(v)
        logger.debug(
            "action=deploy_completed agent_id=%s version=%s",
            self._agent_id,
            v or "(none)",
            extra={"action": "deploy_completed", "agent_id": self._agent_id, "version": v},
        )
        fn = self._handlers.get("deploy", _noop)
        handler_result = fn(version)
        if asyncio.iscoroutine(handler_result):
            return handler_result
        return None

    def handle_rollback(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Rollback: default runtime_executor; then handlers['rollback'].
        """
        v = (version or "").strip() or ""
        logger.info(
            "action=rollback_requested agent_id=%s version=%s",
            self._agent_id,
            v or "(none)",
            extra={"action": "rollback_requested", "agent_id": self._agent_id, "version": v},
        )
        self.on_rollback_requested(v)
        logger.debug(
            "action=rollback_completed agent_id=%s version=%s",
            self._agent_id,
            v or "(none)",
            extra={"action": "rollback_completed", "agent_id": self._agent_id, "version": v},
        )
        fn = self._handlers.get("rollback", _noop)
        handler_result = fn(version)
        if asyncio.iscoroutine(handler_result):

            async def _after_rollback() -> None:
                await handler_result
                self._finalize_controlled_rollback()

            return _after_rollback()
        self._finalize_controlled_rollback()
        return None

    def handle_process_start(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Queued START: on_agent_start + handlers['start'], then agent.start span + PATCH starting
        (verified server-side), then optional start_host_process when runtime exec is enabled.
        Distinct from resume-after-pause and from control-agents UI START → SDK resume.
        """
        logger.info("Host process start (script) requested")
        result = self.on_agent_start()
        if asyncio.iscoroutine(result):
            asyncio.run(result)
        fn = self._handlers.get("start", _noop)
        handler_result = fn(version)
        cmd_id = None
        if self._control_command_context:
            cmd_id = self._control_command_context.command_id

        if asyncio.iscoroutine(handler_result):

            async def _await_then_start() -> None:
                await handler_result
                self._finalize_process_start(cmd_id)

            return _await_then_start()

        self._finalize_process_start(cmd_id)
        return None

    def handle_decommission(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Remove local PUVINoise runtime footprint on the host and optionally restart host process.
        This command is intended for tenant-approved agent de-registration flows.
        """
        payload = self._control_command_context.payload if self._control_command_context else {}
        payload = payload if isinstance(payload, dict) else {}

        env_keys = payload.get("envKeys")
        if not isinstance(env_keys, list) or not env_keys:
            env_keys = [
                "PUVINOISE_BASE_URL",
                "PUVINOISE_API_KEY",
                "PUVINOISE_AGENT_ID",
                "PUVINOISE_AGENT_NAME",
                "PUVINOISE_TENANTID",
                "PUVINOISE_CONTROL_AUTO_START",
                "PUVINOISE_AGENT_CONFIG_POLL",
            ]

        remove_env_file = bool(payload.get("removeEnvFile", True))
        env_file_path = str(payload.get("envFilePath") or os.environ.get("PUVINOISE_ENV_FILE") or "").strip()
        uninstall_sdk = bool(payload.get("uninstallSdk", True))
        uninstall_wrapper = bool(payload.get("uninstallWrapper", True))
        wrapper_paths = payload.get("wrapperPaths") if isinstance(payload.get("wrapperPaths"), list) else []
        wrapper_packages = payload.get("wrapperPackages") if isinstance(payload.get("wrapperPackages"), list) else []
        restart_after_cleanup = bool(payload.get("restartAfterCleanup", False))

        for key in env_keys:
            if isinstance(key, str) and key:
                os.environ.pop(key, None)

        if remove_env_file and env_file_path:
            self._remove_keys_from_env_file(env_file_path, env_keys)

        if uninstall_sdk:
            self._safe_pip_uninstall(["puvinoise", "puvinoise-sdk", "puvinoise_sdk"])

        if uninstall_wrapper:
            pkg_list = [str(p).strip() for p in wrapper_packages if isinstance(p, str) and str(p).strip()]
            if pkg_list:
                self._safe_pip_uninstall(pkg_list)
            for p in wrapper_paths:
                try:
                    path = pathlib.Path(str(p)).expanduser().resolve()
                    if path.exists():
                        if path.is_file():
                            path.unlink(missing_ok=True)
                        elif path.is_dir():
                            for child in sorted(path.glob("**/*"), reverse=True):
                                try:
                                    if child.is_file():
                                        child.unlink(missing_ok=True)
                                    elif child.is_dir():
                                        child.rmdir()
                                except Exception:
                                    pass
                            try:
                                path.rmdir()
                            except Exception:
                                pass
                except Exception as e:
                    logger.warning("decommission wrapper path cleanup failed (%s): %s", p, e)

        if restart_after_cleanup:
            self._maybe_restart_host_process()
        return None

    def _remove_keys_from_env_file(self, env_file_path: str, keys: list[str]) -> None:
        try:
            target = pathlib.Path(env_file_path).expanduser().resolve()
            if not target.exists() or not target.is_file():
                return
            key_set = {str(k).strip() for k in keys if isinstance(k, str) and str(k).strip()}
            if not key_set:
                return
            lines = target.read_text(encoding="utf-8").splitlines()
            kept = []
            for line in lines:
                raw = line.strip()
                if not raw or raw.startswith("#") or "=" not in raw:
                    kept.append(line)
                    continue
                left = raw.split("=", 1)[0].strip()
                if left in key_set:
                    continue
                kept.append(line)
            target.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")
        except Exception as e:
            logger.warning("decommission env cleanup failed: %s", e)

    def _safe_pip_uninstall(self, packages: list[str]) -> None:
        to_remove = [str(p).strip() for p in packages if isinstance(p, str) and str(p).strip()]
        if not to_remove:
            return
        try:
            cmd = [os.environ.get("PYTHON_BIN") or os.sys.executable, "-m", "pip", "uninstall", "-y", *to_remove]
            subprocess.run(cmd, check=False, capture_output=True, text=True, timeout=120)
        except Exception as e:
            logger.warning("decommission pip uninstall failed: %s", e)

    def handle_sdk_upgrade(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """pip install puvinoise-sdk (or PUVINOISE_PIP_PACKAGE)==version."""
        v = (version or "").strip() or ""
        pl = self._control_command_context.payload if self._control_command_context else None
        if not v and pl:
            v = str(pl.get("sdkVersion") or pl.get("version") or "").strip()
        logger.info("sdk_upgrade version=%s", v or "(none)")
        from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
        from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

        if not runtime_exec_enabled():
            logger.warning("PUVINOISE_CONTROL_RUNTIME_EXEC=1 required for sdk_upgrade")
            return None
        ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
        ex.sdk_upgrade(v, pl)
        return None

    def handle_config_update(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """GET /api/agent/config, write PUVINOISE_ENV_FILE, restart host process."""
        _ = version
        pl = self._control_command_context.payload if self._control_command_context else None
        from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
        from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

        if not runtime_exec_enabled():
            logger.warning("PUVINOISE_CONTROL_RUNTIME_EXEC=1 required for config_update")
            return None
        ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
        ex.config_update_from_platform(pl)
        return None

    def handle_redeploy(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Redeploy: re-apply the current (last deployed) version to fix drift.
        Behaves like deploy but uses the version already tracked in deploymentConfig.
        The platform triggers the GitHub workflow; the agent acknowledges the command
        and re-runs its own startup sequence so telemetry reflects the redeploy event.
        """
        v = (version or "").strip() or None
        pl = self._control_command_context.payload if self._control_command_context else None
        logger.info("redeploy command received version=%s payload=%s", v, pl)
        from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
        from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

        if not runtime_exec_enabled():
            logger.info(
                "redeploy: PUVINOISE_CONTROL_RUNTIME_EXEC=1 not set — "
                "platform has triggered the workflow; no local exec needed"
            )
            return None
        ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
        ex.deploy(v, pl)
        return None

    def handle_hot_reload(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Hot Reload: apply config/env changes without restarting the agent process.
        Pulls the latest config from the platform (PUVINOISE_ENV_FILE path), writes it,
        and signals the agent application layer via os.environ update + lifecycle_hooks
        so in-flight tasks are not interrupted.
        Unlike config_update, hot_reload does NOT invoke the restart script.
        """
        _ = version
        pl = self._control_command_context.payload if self._control_command_context else None
        logger.info("hot_reload: applying config changes without restart payload=%s", pl)
        from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
        from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

        if not runtime_exec_enabled():
            logger.warning("PUVINOISE_CONTROL_RUNTIME_EXEC=1 required for hot_reload")
            return None
        ex = get_runtime_executor(self._base_url, self._agent_id, self._resolve_api_key())
        # Fetch and write env config without triggering restart script
        ex.config_update_from_platform(pl, restart=False)
        return None

    def handle_pin_version(self, version: Optional[str] = None) -> Union[None, Awaitable[None]]:
        """
        Pin Version: lock the agent to a specific SDK/version so automatic upgrade
        commands are ignored until the pin is cleared.
        Writes PUVINOISE_PINNED_VERSION to the env file and sets an in-process flag.
        """
        v = (version or "").strip() or None
        pl = self._control_command_context.payload if self._control_command_context else None
        logger.info("pin_version: pinning agent to version=%s payload=%s", v, pl)

        if v:
            os.environ["PUVINOISE_PINNED_VERSION"] = v
            logger.info("pin_version: PUVINOISE_PINNED_VERSION=%s set in process env", v)
        else:
            # Clearing pin (no version means unpin)
            os.environ.pop("PUVINOISE_PINNED_VERSION", None)
            logger.info("pin_version: PUVINOISE_PINNED_VERSION cleared (unpin)")

        # Write to .env file if configured for persistence across restarts
        env_file = os.environ.get("PUVINOISE_ENV_FILE", "").strip()
        if env_file and os.path.isfile(env_file):
            try:
                with open(env_file, "r") as f:
                    lines = f.readlines()
                key = "PUVINOISE_PINNED_VERSION"
                updated = False
                new_lines = []
                for line in lines:
                    if line.strip().startswith(f"{key}="):
                        if v:
                            new_lines.append(f"{key}={v}\n")
                        updated = True
                    else:
                        new_lines.append(line)
                if not updated and v:
                    new_lines.append(f"{key}={v}\n")
                with open(env_file, "w") as f:
                    f.writelines(new_lines)
                logger.info("pin_version: persisted to env file %s", env_file)
            except Exception as exc:
                logger.warning("pin_version: could not write env file %s: %s", env_file, exc)
        return None

    def handle_write_contract_file(self, command: Any) -> None:
        """
        WRITE_CONTRACT_FILE — PUVINoise platform sends the generated
        puvinoise-agent.yaml content for the developer to review.

        Command payload:
          {
            "commandType": "write_contract_file",
            "payload": {
              "content":     "<yaml string>",
              "target_path": "<optional absolute path>"
            }
          }

        Mirrors the bootstrap pattern — PUVINoise generates, SDK writes,
        developer confirms via dashboard.
        """
        payload: Dict[str, Any] = {}
        if self._control_command_context:
            payload = self._control_command_context.payload or {}
        if not isinstance(payload, dict):
            payload = {}

        content = str(payload.get("content") or "").strip()
        target  = str(payload.get("target_path") or "").strip() or None

        if not content:
            logger.warning("write_contract_file: command received but no content in payload")
            return

        try:
            from puvinoise.agent_autoregister import handle_write_contract_command
            success = handle_write_contract_command({"payload": {"content": content, "target_path": target}})
            if success:
                logger.info("write_contract_file: puvinoise-agent.yaml written successfully")
            else:
                logger.warning("write_contract_file: failed to write YAML file")
        except Exception as exc:
            logger.warning("write_contract_file: error writing contract file: %s", exc)

    def _dispatch(self, cmd: ControlCommand) -> None:
        """Poll loop entry: run command through the dispatcher."""
        self.dispatch_agent_command(cmd)

    def _resolve_api_key(self) -> str:
        """Prefer constructor key; else PUVINOISE_API_KEY."""
        if self._api_key and str(self._api_key).strip():
            return str(self._api_key).strip()
        return (get_api_key() or "").strip()

    def _fetch_control(self) -> Optional[ControlCommand]:
        """
        GET control endpoint and return parsed command or None (200 OK but no command).
        Raises on network/HTTP errors so callers can apply backoff.
        Sends Authorization: Bearer and x-api-key (server accepts either per authenticateApiKeyFromHeaderOrBearer).
        """
        import urllib.request

        req = urllib.request.Request(self._control_url, method="GET")
        req.add_header("Accept", "application/json")
        key = self._resolve_api_key()
        headers_log: dict = {"Accept": "application/json"}
        if key:
            req.add_header("Authorization", f"Bearer {key}")
            req.add_header("x-api-key", key)
            headers_log["Authorization"] = "Bearer ***"
            headers_log["x-api-key"] = "***"
        else:
            headers_log["Authorization"] = "(missing)"
            headers_log["x-api-key"] = "(missing)"
        logger.debug("control poll headers: %s", headers_log)

        import urllib.error

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                return self._parse_response(body)
        except urllib.error.HTTPError as e:
            if e.code == 401 and not self._logged_control_401_hint:
                self._logged_control_401_hint = True
                err_body = ""
                try:
                    err_body = e.read().decode("utf-8", errors="replace")
                except Exception:
                    pass
                logger.warning(
                    "Control API 401: this agent access key is not accepted by the server "
                    "(revoked, wrong tenant, or DB reset). In PUVINoise, open the agent and copy "
                    "the current access key into .env as PUVINOISE_API_KEY, "
                    "then restart. Response: %s",
                    (err_body or "")[:500],
                )
            raise

    def _parse_response(self, body: str) -> Optional[ControlCommand]:
        """Parse JSON response into ControlCommand. Accepts { command, commandId?, timestamp?, version? }."""
        body = (body or "").strip()
        if not body:
            return None
        try:
            import json

            data = json.loads(body)
            if not isinstance(data, dict):
                return None
            command = data.get("command")
            if not command:
                return None
            command_id = data.get("commandId")
            timestamp = data.get("timestamp")
            version = data.get("version")
            raw_payload = data.get("payload")
            pl = raw_payload if isinstance(raw_payload, dict) else None
            return ControlCommand(
                command=str(command),
                command_id=str(command_id) if command_id is not None else None,
                timestamp=str(timestamp) if timestamp is not None else None,
                version=str(version) if version is not None else None,
                payload=pl,
            )
        except Exception:
            return None

    def _poll_loop(self) -> None:
        """Background loop: poll then dispatch if new command. Exponential backoff on API failure."""
        while True:
            wait_sec = self._next_poll_wait
            if self._stop.wait(timeout=wait_sec):
                break
            self._poll_cycle()

    def _poll_cycle(self) -> None:
        """One GET /api/agent-control poll + optional dispatch; updates backoff on failure."""
        try:
            logger.debug("POLLING_AGENT_CONTROL %s", {"url": self._control_url})
            cmd = self._fetch_control()
            self._next_poll_wait = self._poll_interval  # reset backoff on any successful response
            if cmd is not None:
                try:
                    self._dispatch(cmd)
                except Exception as e:
                    logger.warning("Control handler failed for %s: %s", cmd.command, e)
        except Exception as e:
            import urllib.error

            # 401: already logged in _fetch_control with remediation hint; avoid spamming
            if isinstance(e, urllib.error.HTTPError) and e.code == 401:
                self._apply_backoff()
                return
            logger.warning(
                "Control API unreachable (retry with backoff): %s",
                e,
            )
            self._apply_backoff()

    def poll_once(self) -> None:
        """
        Run a single control poll + dispatch when the worker is driven by the SDK heartbeat loop
        (PUVINOISE_CONTROL_POLL_VIA_HEARTBEAT=1). No-op if the internal poll thread is active.
        Safe to call from the heartbeat thread each tick.
        """
        if not self._poll_via_heartbeat:
            return
        if self._stop.is_set():
            return
        self._poll_cycle()

    def _apply_backoff(self) -> None:
        """Increase poll wait time (exponential backoff) up to CONTROL_BACKOFF_MAX_SEC."""
        prev = self._next_poll_wait
        self._next_poll_wait = min(
            CONTROL_BACKOFF_MAX_SEC,
            max(self._poll_interval, prev * CONTROL_BACKOFF_MULTIPLIER),
        )
        if self._next_poll_wait > prev:
            logger.info(
                "Control API backoff: next poll in %.1fs (was %.1fs)",
                self._next_poll_wait,
                prev,
            )

    def start(self, *, poll_via_heartbeat: bool = False) -> None:
        """
        Start the control worker.

        Default: background thread polls GET /api/agent-control on ``poll_interval``.

        When ``poll_via_heartbeat`` is True, no thread is started; call :meth:`poll_once` from the
        SDK heartbeat loop (see ``PUVINOISE_CONTROL_POLL_VIA_HEARTBEAT``).
        """
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._poll_via_heartbeat = bool(poll_via_heartbeat)
            self._stop.clear()
            if self._poll_via_heartbeat:
                self._thread = None
            else:
                self._thread = threading.Thread(target=self._poll_loop, daemon=True)
                self._thread.start()
        if self._poll_via_heartbeat:
            logger.info(
                "Control worker registered (heartbeat-driven poll) – %s/api/agent-control agent %s",
                self._base_url,
                self._agent_id,
            )
        else:
            logger.info(
                "Control worker started – polling %s/api/agent-control for agent %s",
                self._base_url,
                self._agent_id,
            )
        logger.debug(
            "Control worker agent_id=%s url=%s interval=%.1fs heartbeat_driven=%s",
            self._agent_id,
            self._control_url,
            self._poll_interval,
            self._poll_via_heartbeat,
        )

    def stop(self) -> None:
        """Stop the polling worker."""
        self._stop.set()
        t = self._thread
        self._thread = None
        self._poll_via_heartbeat = False
        if t is not None and t.is_alive():
            t.join(timeout=self._poll_interval * 2)
        logger.debug("Control worker stopped for agent %s", self._agent_id)
