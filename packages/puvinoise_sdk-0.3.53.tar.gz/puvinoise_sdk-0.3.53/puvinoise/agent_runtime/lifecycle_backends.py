"""
lifecycle_backends.py — Reference lifecycle hook implementations for AgentControlWorker.

Three backends are provided so that pause/resume/stop/restart/start commands from the
PUVINoise control plane produce a real OS-level effect, not just a flag flip:

  BareProcessBackend  — SIGSTOP/SIGCONT on the current PID (Linux/macOS only).
                        Works for any Python process regardless of framework.

  DockerBackend       — docker kill --signal / docker stop / docker start targeting
                        the container identified by $HOSTNAME (the default container ID
                        in Docker/K8s) or an explicit container name/ID.

  SystemdBackend      — systemctl stop/start/restart <service> targeting the systemd
                        unit specified at construction time.

Usage
-----
Pick the backend that matches your deployment target and pass it when starting the
control worker:

    import puvinoise
    from puvinoise.agent_runtime.lifecycle_backends import BareProcessBackend

    backend = BareProcessBackend()
    puvinoise.start_agent_control_worker(lifecycle_hooks=backend.as_hooks())

Or with Docker:

    from puvinoise.agent_runtime.lifecycle_backends import DockerBackend

    backend = DockerBackend()                    # container_id from $HOSTNAME
    # backend = DockerBackend(container_id="my-agent-container")  # explicit
    puvinoise.start_agent_control_worker(lifecycle_hooks=backend.as_hooks())

Or chain multiple backends (e.g. flush telemetry first, then stop):

    from puvinoise.agent_runtime.lifecycle_backends import BareProcessBackend, chain_hooks

    backend = BareProcessBackend()
    merged = chain_hooks(telemetry_flush_hooks(), backend.as_hooks())
    puvinoise.start_agent_control_worker(lifecycle_hooks=merged)
"""

from __future__ import annotations

import logging
import os
import signal
import subprocess
import sys
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run(cmd: list[str], *, check: bool = True, timeout: int = 30) -> None:
    """Run a subprocess command, logging stdout/stderr on failure."""
    logger.debug("lifecycle_backends: %s", cmd)
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if check and result.returncode != 0:
        raise RuntimeError(
            f"Command {cmd} failed (exit {result.returncode}): "
            f"stdout={result.stdout!r} stderr={result.stderr!r}"
        )


def _flush_telemetry() -> None:
    """Best-effort telemetry flush before a stop/restart."""
    try:
        from puvinoise.bootstrap import force_flush
        from puvinoise.decision_telemetry import flush_decision_events
        force_flush(timeout_millis=5000)
        flush_decision_events(timeout_seconds=5.0)
        logger.debug("lifecycle_backends: telemetry flushed")
    except Exception as exc:
        logger.debug("lifecycle_backends: telemetry flush failed (ignored): %s", exc)


def telemetry_flush_hooks() -> Dict[str, Callable]:
    """Return hooks that just flush telemetry — useful for chaining."""
    return {
        "on_agent_stop": lambda: _flush_telemetry(),
        "on_agent_restart": lambda: _flush_telemetry(),
        "on_agent_start": lambda: None,
    }


def chain_hooks(*hook_dicts: Dict[str, Callable]) -> Dict[str, Callable]:
    """
    Merge multiple hook dicts into one. When the same hook key appears in several
    dicts, all callables are called in order when the combined hook fires.
    """
    merged: Dict[str, list[Callable]] = {}
    for d in hook_dicts:
        if not isinstance(d, dict):
            continue
        for k, fn in d.items():
            if callable(fn):
                merged.setdefault(k, []).append(fn)

    result: Dict[str, Callable] = {}
    for k, fns in merged.items():
        def _make(funcs: list[Callable]) -> Callable:
            def _combined(*args: Any, **kwargs: Any) -> None:
                for f in funcs:
                    try:
                        f(*args, **kwargs)
                    except Exception as exc:
                        logger.warning("lifecycle chain: hook %s raised: %s", f, exc)
            return _combined
        result[k] = _make(fns)
    return result


# ---------------------------------------------------------------------------
# Backend 1: BareProcessBackend — SIGSTOP / SIGCONT on the current process
# ---------------------------------------------------------------------------

class BareProcessBackend:
    """
    Send OS-level signals to the current Python process:
      pause  → SIGSTOP  (immediate, uninterruptible; no user-space involvement)
      resume → SIGCONT
      stop   → flush telemetry + SIGTERM (then SIGKILL after grace_period_s)
      restart → flush telemetry + os.execv(sys.executable, sys.argv)
      start  → no-op (process is already running)

    Works on Linux and macOS. On Windows, SIGSTOP/SIGCONT are not supported;
    pause/resume fall back to a warning log.
    """

    def __init__(self, grace_period_s: float = 5.0):
        self._grace = float(grace_period_s)

    def on_pause(self) -> None:
        pid = os.getpid()
        logger.info("BareProcessBackend: SIGSTOP → PID %d", pid)
        try:
            os.kill(pid, signal.SIGSTOP)
        except (AttributeError, OSError) as exc:
            # Windows: signal.SIGSTOP doesn't exist
            logger.warning(
                "BareProcessBackend: SIGSTOP not supported on this platform (%s). "
                "The agent's _paused flag is set; your main loop must check is_paused().",
                exc,
            )

    def on_resume(self) -> None:
        # SIGCONT is sent by the control plane to the stopped process.
        # By definition the process is suspended and cannot run this hook.
        # We log here for completeness; in practice it is the *sender* that
        # needs to SIGCONT the target, which on bare-process means the
        # resume command handler (handle_resume) sets _resume_event — that
        # unblocks any code using worker.wait_for_resume().
        logger.info("BareProcessBackend: resume (SIGCONT auto-delivered by OS after SIGSTOP lifts)")

    def on_stop(self) -> None:
        _flush_telemetry()
        pid = os.getpid()
        logger.info("BareProcessBackend: SIGTERM → PID %d (grace %.1fs)", pid, self._grace)
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError as exc:
            logger.warning("BareProcessBackend: SIGTERM failed: %s — falling back to sys.exit", exc)
            sys.exit(0)

    def on_restart(self) -> None:
        _flush_telemetry()
        logger.info("BareProcessBackend: os.execv restart → %s %s", sys.executable, sys.argv)
        os.environ["PUVINOISE_RESTART_CAUSE"] = "control_command"
        os.execv(sys.executable, [sys.executable] + sys.argv)

    def on_start(self) -> None:
        logger.info("BareProcessBackend: start received (process already running; no-op)")

    def as_hooks(self) -> Dict[str, Callable]:
        return {
            "on_agent_stop": self.on_stop,
            "on_agent_restart": self.on_restart,
            "on_agent_start": self.on_start,
        }

    def as_handlers(self) -> Dict[str, Callable]:
        """Low-level handlers dict (passed as handlers= to AgentControlWorker)."""
        return {
            "pause": lambda _v=None: self.on_pause(),
            "resume": lambda _v=None: self.on_resume(),
            "stop": lambda _v=None: self.on_stop(),
            "restart": lambda _v=None: self.on_restart(),
            "start": lambda _v=None: self.on_start(),
        }


# ---------------------------------------------------------------------------
# Backend 2: DockerBackend — docker kill / stop / start
# ---------------------------------------------------------------------------

class DockerBackend:
    """
    Issue Docker CLI commands against the agent's own container.

    The container_id defaults to $HOSTNAME, which Docker sets to the short
    container ID by default. Override with an explicit name or full ID.

    Requires that the Docker socket (/var/run/docker.sock) is bind-mounted
    into the container (or that the host's docker CLI is available).

    Commands:
      pause  → docker kill --signal SIGSTOP <container>
      resume → docker kill --signal SIGCONT <container>
      stop   → flush telemetry + docker stop --time <grace> <container>
      restart → flush telemetry + docker restart --time <grace> <container>
      start  → docker start <container>
                (only useful when the container is stopped; a running container
                 receiving 'start' is a no-op at the Docker layer)
    """

    def __init__(
        self,
        container_id: Optional[str] = None,
        grace_period_s: int = 10,
        docker_binary: str = "docker",
    ):
        self._container = (container_id or os.environ.get("HOSTNAME") or "").strip()
        if not self._container:
            raise ValueError(
                "DockerBackend: container_id is required. "
                "Pass it explicitly or ensure $HOSTNAME is the container ID."
            )
        self._grace = int(grace_period_s)
        self._docker = docker_binary

    def _docker_kill(self, sig: str) -> None:
        _run([self._docker, "kill", f"--signal={sig}", self._container])

    def on_pause(self) -> None:
        logger.info("DockerBackend: SIGSTOP → container %s", self._container)
        self._docker_kill("SIGSTOP")

    def on_resume(self) -> None:
        logger.info("DockerBackend: SIGCONT → container %s", self._container)
        self._docker_kill("SIGCONT")

    def on_stop(self) -> None:
        _flush_telemetry()
        logger.info("DockerBackend: docker stop (grace %ds) → container %s", self._grace, self._container)
        _run([self._docker, "stop", f"--time={self._grace}", self._container])

    def on_restart(self) -> None:
        _flush_telemetry()
        logger.info("DockerBackend: docker restart (grace %ds) → container %s", self._grace, self._container)
        _run([self._docker, "restart", f"--time={self._grace}", self._container])

    def on_start(self) -> None:
        logger.info("DockerBackend: docker start → container %s", self._container)
        _run([self._docker, "start", self._container])

    def as_hooks(self) -> Dict[str, Callable]:
        return {
            "on_agent_stop": self.on_stop,
            "on_agent_restart": self.on_restart,
            "on_agent_start": self.on_start,
        }

    def as_handlers(self) -> Dict[str, Callable]:
        return {
            "pause": lambda _v=None: self.on_pause(),
            "resume": lambda _v=None: self.on_resume(),
            "stop": lambda _v=None: self.on_stop(),
            "restart": lambda _v=None: self.on_restart(),
            "start": lambda _v=None: self.on_start(),
        }


# ---------------------------------------------------------------------------
# Backend 3: SystemdBackend — systemctl stop/start/restart <service>
# ---------------------------------------------------------------------------

class SystemdBackend:
    """
    Use systemctl to manage the agent service.

    The service name defaults to $PUVINOISE_SYSTEMD_SERVICE or 'puvinoise-agent'.
    Systemd does not have a built-in SIGSTOP/SIGCONT equivalent at the service
    layer, so pause/resume send SIGSTOP/SIGCONT directly to the main PID via
    systemctl kill --signal.

    Commands:
      pause  → systemctl kill --signal=SIGSTOP <service>
      resume → systemctl kill --signal=SIGCONT <service>
      stop   → flush telemetry + systemctl stop <service>
      restart → flush telemetry + systemctl restart <service>
      start  → systemctl start <service>
    """

    def __init__(
        self,
        service_name: Optional[str] = None,
        systemctl_binary: str = "systemctl",
    ):
        self._service = (
            service_name
            or os.environ.get("PUVINOISE_SYSTEMD_SERVICE")
            or "puvinoise-agent"
        ).strip()
        self._ctl = systemctl_binary

    def _ctl_run(self, *args: str) -> None:
        _run([self._ctl, *args])

    def on_pause(self) -> None:
        logger.info("SystemdBackend: SIGSTOP → service %s", self._service)
        self._ctl_run("kill", f"--signal=SIGSTOP", self._service)

    def on_resume(self) -> None:
        logger.info("SystemdBackend: SIGCONT → service %s", self._service)
        self._ctl_run("kill", f"--signal=SIGCONT", self._service)

    def on_stop(self) -> None:
        _flush_telemetry()
        logger.info("SystemdBackend: systemctl stop %s", self._service)
        self._ctl_run("stop", self._service)

    def on_restart(self) -> None:
        _flush_telemetry()
        logger.info("SystemdBackend: systemctl restart %s", self._service)
        self._ctl_run("restart", self._service)

    def on_start(self) -> None:
        logger.info("SystemdBackend: systemctl start %s", self._service)
        self._ctl_run("start", self._service)

    def as_hooks(self) -> Dict[str, Callable]:
        return {
            "on_agent_stop": self.on_stop,
            "on_agent_restart": self.on_restart,
            "on_agent_start": self.on_start,
        }

    def as_handlers(self) -> Dict[str, Callable]:
        return {
            "pause": lambda _v=None: self.on_pause(),
            "resume": lambda _v=None: self.on_resume(),
            "stop": lambda _v=None: self.on_stop(),
            "restart": lambda _v=None: self.on_restart(),
            "start": lambda _v=None: self.on_start(),
        }


# ---------------------------------------------------------------------------
# Auto-detect backend from environment
# ---------------------------------------------------------------------------

_BACKEND_ENV_KEY = "PUVINOISE_LIFECYCLE_BACKEND"


def auto_backend(
    *,
    docker_container_id: Optional[str] = None,
    systemd_service: Optional[str] = None,
    grace_period_s: int = 10,
) -> "BareProcessBackend | DockerBackend | SystemdBackend":
    """
    Pick the best available backend automatically:

      PUVINOISE_LIFECYCLE_BACKEND=docker    → DockerBackend
      PUVINOISE_LIFECYCLE_BACKEND=systemd   → SystemdBackend
      PUVINOISE_LIFECYCLE_BACKEND=bare      → BareProcessBackend
      (not set)                             → Docker if /.dockerenv exists, else Bare

    You can still override by passing explicit kwargs.
    """
    hint = (os.environ.get(_BACKEND_ENV_KEY) or "").strip().lower()

    if hint == "docker" or (not hint and os.path.exists("/.dockerenv")):
        container = docker_container_id or os.environ.get("HOSTNAME") or ""
        if container:
            return DockerBackend(container_id=container, grace_period_s=grace_period_s)
        # Fallthrough: HOSTNAME not set, cannot use Docker backend
        logger.warning(
            "auto_backend: PUVINOISE_LIFECYCLE_BACKEND=docker but $HOSTNAME is empty; "
            "falling back to BareProcessBackend"
        )
        return BareProcessBackend(grace_period_s=grace_period_s)

    if hint == "systemd":
        return SystemdBackend(service_name=systemd_service)

    return BareProcessBackend(grace_period_s=grace_period_s)


__all__ = [
    "BareProcessBackend",
    "DockerBackend",
    "SystemdBackend",
    "auto_backend",
    "chain_hooks",
    "telemetry_flush_hooks",
]
