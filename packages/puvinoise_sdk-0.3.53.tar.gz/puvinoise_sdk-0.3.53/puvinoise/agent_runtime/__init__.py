"""
Agent runtime (execution plane): control polling, deploy/rollback, env, process hooks.

Telemetry and tracing live in the rest of `puvinoise`; importing this package is optional.
Use `puvinoise.agent_runtime.start()` to start the control poller without touching bootstrap.init().
"""

from __future__ import annotations

import logging
import os
from typing import Any, Optional

from puvinoise.agent_runtime.agent_control_worker import (
    AgentControlWorker,
    ControlCommand,
    ControlHandler,
    DEFAULT_POLL_INTERVAL_SEC,
    OnAgentRestartHook,
    OnAgentStopHook,
    OnDeployRequestedHook,
    OnRollbackRequestedHook,
)
from puvinoise.agent_runtime.completion import (
    post_control_command_completion,
    post_control_command_completion_from_env,
)
from puvinoise.agent_runtime.env_manager import fetch_agent_config
from puvinoise.agent_runtime.bootstrap_apply import BootstrapApplyResult, apply_bootstrap_from_config
from puvinoise.agent_runtime.runtime_executor import ControlRuntimeExecutor, get_runtime_executor
from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled
from puvinoise.env_keys import get_api_key, get_agent_id, get_base_url

from puvinoise.agent_runtime.lifecycle_backends import (
    BareProcessBackend,
    DockerBackend,
    SystemdBackend,
    auto_backend,
    chain_hooks,
    telemetry_flush_hooks,
)

from . import deploy_handler
from . import env_manager
from . import process_manager
from . import rollback_handler

logger = logging.getLogger(__name__)

__all__ = [
    "start",
    "AgentControlWorker",
    "ControlCommand",
    "ControlHandler",
    "DEFAULT_POLL_INTERVAL_SEC",
    "OnAgentStopHook",
    "OnAgentRestartHook",
    "OnDeployRequestedHook",
    "OnRollbackRequestedHook",
    "post_control_command_completion",
    "post_control_command_completion_from_env",
    "ControlRuntimeExecutor",
    "get_runtime_executor",
    "runtime_exec_enabled",
    "BootstrapApplyResult",
    "apply_bootstrap_from_config",
    "fetch_agent_config",
    # Lifecycle backends
    "BareProcessBackend",
    "DockerBackend",
    "SystemdBackend",
    "auto_backend",
    "chain_hooks",
    "telemetry_flush_hooks",
    "deploy_handler",
    "rollback_handler",
    "env_manager",
    "process_manager",
]


def _normalize_http_api_base(url: str) -> str:
    u = (url or "").strip().rstrip("/")
    if u.lower().endswith("/api"):
        u = u[: -len("/api")].rstrip("/")
    return u


def start(
    agent_id: Optional[str] = None,
    control_api_url: Optional[str] = None,
    *,
    polling_interval: Optional[float] = None,
    api_key: Optional[str] = None,
    lifecycle_hooks: Optional[dict[str, Any]] = None,
) -> Optional[AgentControlWorker]:
    """
    Start execution plane: background poll of GET /api/agent-control/:agentId.

    When arguments are omitted, reads env: PUVINOISE_AGENT_ID, PUVINOISE_BASE_URL,
    PUVINOISE_API_KEY, PUVINOISE_CONTROL_POLL_INTERVAL (optional).

    Does not enable span export; call `puvinoise.init` / `bootstrap` separately for observe mode.
    Returns the worker instance or None if misconfigured.
    """
    aid = (agent_id or get_agent_id() or "").strip()
    base = _normalize_http_api_base(control_api_url or get_base_url() or "")
    key = (api_key or "").strip() or get_api_key() or None
    if not aid or not base:
        logger.warning("agent_runtime.start: missing PUVINOISE_AGENT_ID or PUVINOISE_BASE_URL")
        return None
    interval = float(polling_interval) if polling_interval is not None else DEFAULT_POLL_INTERVAL_SEC
    raw = os.environ.get("PUVINOISE_CONTROL_POLL_INTERVAL") or os.environ.get("PUVINOISE_AGENT_CONTROL_POLL_INTERVAL")
    if polling_interval is None and raw:
        try:
            interval = float(raw)
        except ValueError:
            pass
    interval = max(0.5, interval)
    poll_via_hb = os.environ.get("PUVINOISE_CONTROL_POLL_VIA_HEARTBEAT", "").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    worker = AgentControlWorker(
        agent_id=aid,
        base_url=base,
        poll_interval_seconds=interval,
        api_key=key,
        lifecycle_hooks=lifecycle_hooks,
    )
    worker.start(poll_via_heartbeat=poll_via_hb)
    # Primary log line emitted by AgentControlWorker.start()
    logger.debug("agent_runtime.start: agent_id=%s url=%s", aid, base)
    return worker
