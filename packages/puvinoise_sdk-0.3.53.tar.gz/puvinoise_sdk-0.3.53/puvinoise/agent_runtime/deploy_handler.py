"""Deploy artifact / git / script + optional pip SDK upgrade."""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from typing import Any, Dict, Optional

from puvinoise.agent_runtime.process_manager import ProcessManager
from puvinoise.agent_runtime.runtime_flags import require_runtime_exec, restart_after_sdk_upgrade

logger = logging.getLogger(__name__)


def _emit_deploy_event(
    event: str,
    message: Optional[str] = None,
    *,
    progress_pct: Optional[float] = None,
    deployment_id: Optional[str] = None,
    error: Optional[str] = None,
) -> None:
    try:
        from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

        post_control_execution_event_from_env(
            event,
            message,
            progress_pct=progress_pct,
            deployment_id=deployment_id,
            error=error,
        )
    except Exception:
        pass


def run_deploy(
    version: str,
    payload: Optional[Dict[str, Any]],
    *,
    process_manager: ProcessManager,
    workdir: str,
    artifact_template: str,
    checkout_mode: str,
    git_remote: str,
    restart_after: bool = True,
) -> None:
    """Script, artifact URL, or git checkout; then restart."""
    v = (version or "").strip()
    if not v:
        raise RuntimeError("deploy: version is required")
    require_runtime_exec()

    _emit_deploy_event("deploy_started", "Deployment started on agent")

    try:
        ds = (os.environ.get("PUVINOISE_DEPLOY_SCRIPT") or "").strip()
        if ds:
            _emit_deploy_event("deploy_progress", "Running deploy script...")
            process_manager.run_script(ds, ["deploy", v], cwd=None)
            _emit_deploy_event("deploy_completed", "Deployment completed")
            if restart_after:
                process_manager.restart()
            return

        artifact_url = None
        if payload and isinstance(payload.get("artifactUrl"), str):
            artifact_url = payload["artifactUrl"].strip()
        elif payload and isinstance(payload.get("downloadUrl"), str):
            artifact_url = payload["downloadUrl"].strip()
        if not artifact_url and artifact_template and "{version}" in artifact_template:
            artifact_url = artifact_template.replace("{version}", v)

        if artifact_url:
            _emit_deploy_event("deploy_progress", "Downloading artifact...")
            download_and_extract_artifact(artifact_url, workdir, v)
            _emit_deploy_event("deploy_progress", "Artifact ready; restarting process...")
            _emit_deploy_event("deploy_completed", "Deployment completed")
            if restart_after:
                process_manager.restart()
            return

        if workdir and os.path.isdir(os.path.join(workdir, ".git")):
            _emit_deploy_event("deploy_progress", "Checking out version from git...")
            git_checkout(v, workdir, git_remote, checkout_mode)
            _emit_deploy_event("deploy_completed", "Deployment completed")
            if restart_after:
                process_manager.restart()
            return

        raise RuntimeError(
            "deploy: configure PUVINOISE_DEPLOY_SCRIPT, or PUVINOISE_AGENT_WORKDIR + git repo, "
            "or payload.artifactUrl / PUVINOISE_ARTIFACT_URL_TEMPLATE"
        )
    except Exception as e:
        _emit_deploy_event("deploy_failed", str(e)[:500], error=str(e)[:2000])
        raise


def run_sdk_upgrade(
    version: str,
    payload: Optional[Dict[str, Any]],
    *,
    process_manager: ProcessManager,
    pip_pkg: str,
    pip_extra: str,
) -> None:
    """pip install <package>==version."""
    v = (version or "").strip()
    if not v and payload:
        v = str(payload.get("sdkVersion") or payload.get("version") or "").strip()
    if not v:
        raise RuntimeError("sdk_upgrade: version is required")
    require_runtime_exec()
    pkg = pip_pkg
    if payload and isinstance(payload.get("package"), str) and payload["package"].strip():
        pkg = payload["package"].strip()
    extra = pip_extra.split() if pip_extra else []
    cmd = [sys.executable, "-m", "pip", "install", f"{pkg}=={v}", *extra]
    logger.info("sdk_upgrade: %s", cmd)
    subprocess.run(cmd, check=True, env=os.environ.copy())
    if restart_after_sdk_upgrade():
        process_manager.restart()


def download_and_extract_artifact(url: str, workdir: str, version: str) -> None:
    if not workdir:
        raise RuntimeError("artifact deploy: PUVINOISE_AGENT_WORKDIR is required")
    os.makedirs(workdir, exist_ok=True)
    logger.info("Downloading artifact v=%s url=%s", version, url)
    req = urllib.request.Request(url, method="GET")
    fd, tmp_path = tempfile.mkstemp(suffix=".zip")
    os.close(fd)
    try:
        with urllib.request.urlopen(req, timeout=600) as resp:
            with open(tmp_path, "wb") as f:
                shutil.copyfileobj(resp, f)
        with zipfile.ZipFile(tmp_path, "r") as zf:
            target = os.path.join(workdir, f"_artifact_{version.replace('/', '_')}")
            if os.path.isdir(target):
                shutil.rmtree(target)
            os.makedirs(target, exist_ok=True)
            zf.extractall(target)
        logger.info("Artifact extracted to %s", target)
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def git_checkout(version: str, workdir: str, git_remote: str, checkout_mode: str) -> None:
    if not workdir:
        raise RuntimeError("git checkout: PUVINOISE_AGENT_WORKDIR is not set")
    subprocess.run(
        ["git", "-C", workdir, "fetch", git_remote, "--tags", "--force"],
        check=True,
        env=os.environ.copy(),
    )
    refs = [version]
    if checkout_mode == "tag" and not version.startswith("refs/"):
        refs.extend([f"v{version}", f"tags/{version}", f"tags/v{version}"])
    last_err: Optional[BaseException] = None
    for candidate in refs:
        try:
            subprocess.run(
                ["git", "-C", workdir, "checkout", candidate],
                check=True,
                env=os.environ.copy(),
            )
            logger.info("git checkout ok: %s", candidate)
            return
        except subprocess.CalledProcessError as e:
            last_err = e
    raise RuntimeError(f"git: could not checkout {version}") from last_err
