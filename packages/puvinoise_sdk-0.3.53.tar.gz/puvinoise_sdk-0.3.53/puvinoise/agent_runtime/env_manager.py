"""Fetch GET /api/agent/config and write .env-style files (execution plane)."""

from __future__ import annotations

import json
import logging
import os
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def normalize_base_url(url: str) -> str:
    u = (url or "").strip().rstrip("/")
    if u.lower().endswith("/api"):
        u = u[: -len("/api")].rstrip("/")
    return u


def fetch_agent_config(
    base_url: str,
    agent_id: str,
    api_key: str,
    *,
    environment: Optional[str] = None,
) -> Dict[str, Any]:
    """GET /api/agent/config — same contract as AgentConfigPoller."""
    base = normalize_base_url(base_url)
    q: Dict[str, str] = {"agentId": (agent_id or "").strip()}
    env = (environment or os.environ.get("PUVINOISE_DEPLOY_ENV") or "").strip()
    if env:
        q["environment"] = env
    qs = urllib.parse.urlencode(q)
    url = f"{base}/api/agent/config?{qs}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json",
        },
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw)


def build_env_lines_from_platform_response(
    data: Dict[str, Any], payload: Optional[Dict[str, Any]] = None
) -> List[str]:
    """Build KEY=value lines from GET /api/agent/config JSON; optional payload.env overrides."""
    if payload and isinstance(payload.get("env"), dict):
        lines: List[str] = []
        for k, val in payload["env"].items():
            if val is None:
                continue
            lines.append(f"{k}={val}")
        return lines

    lines = []
    cfg = data.get("config") or {}
    for key in (
        "agentId",
        "deploymentId",
        "environment",
        "environmentSlug",
        "tenantId",
        "platformBaseUrl",
        "otlpEndpoint",
    ):
        if cfg.get(key) is not None:
            lines.append(f"PUVINOISE_{key.upper()}={cfg[key]}")
    desired = data.get("desired") or {}
    if desired.get("agentVersion"):
        lines.append(f"PUVINOISE_AGENT_VERSION={desired['agentVersion']}")
    return lines


def build_env_lines_from_config(data: Dict[str, Any], payload_override: Optional[Dict[str, Any]] = None) -> List[str]:
    """Backward-compatible alias: payload_override as flat env map."""
    if payload_override:
        lines = []
        for k, val in payload_override.items():
            if val is None:
                continue
            lines.append(f"{k}={val}")
        return lines
    return build_env_lines_from_platform_response(data, None)


def write_env_file(path: str, lines: List[str]) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    content = "\n".join(lines) + "\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    logger.info("Wrote %s (%d lines)", path, len(lines))
