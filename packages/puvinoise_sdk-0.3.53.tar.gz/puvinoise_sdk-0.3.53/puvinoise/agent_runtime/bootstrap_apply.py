"""
Single source of truth for applying platform bootstrap (ENV + wrapper + optional pip)
before deploy / rollback / config_update.

Atomic semantics: hash is updated only after env, wrapper, and pip succeed.
On any failure: log, emit config_failed, do not update hash (consistent retry).
"""

from __future__ import annotations

import hashlib
import logging
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from typing import Any, Dict, Optional

from puvinoise.agent_runtime.env_manager import (
    build_env_lines_from_platform_response,
)
from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

logger = logging.getLogger(__name__)


@dataclass
class BootstrapApplyResult:
    """Result of apply_bootstrap_from_config (only returned on full success)."""

    changed: bool
    wrote_env: bool
    wrote_wrapper: bool
    wrote_restart: bool
    ran_pip: bool

    @property
    def needs_restart(self) -> bool:
        return self.changed


def _hash_material(
    env_template: str,
    wrapper_script: str,
    sdk_version: str,
    restart_script: str = "",
) -> str:
    raw = f"{env_template}\0{wrapper_script}\0{sdk_version}\0{restart_script}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _default_hash_path(workdir: str) -> str:
    base = (workdir or os.getcwd()).strip() or os.getcwd()
    return os.path.join(base, ".puvinoise_bootstrap_hash")


def _emit_config_applied(deployment_id: Optional[str], message: str) -> None:
    try:
        from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

        post_control_execution_event_from_env(
            "config_applied",
            message,
            deployment_id=deployment_id,
        )
    except Exception:
        pass


def _emit_config_failed(deployment_id: Optional[str], err: str) -> None:
    try:
        from puvinoise.agent_runtime.completion import post_control_execution_event_from_env

        post_control_execution_event_from_env(
            "config_failed",
            "Bootstrap apply failed",
            deployment_id=deployment_id,
            error=err[:4000],
        )
    except Exception:
        pass


def _atomic_write_text(path: str, content: str, *, chmod_mode: Optional[int] = None) -> None:
    """Write `content` to `path` via a temp file in the same directory + os.replace (atomic on POSIX)."""
    path = os.path.abspath(path)
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".puvinoise_bootstrap_", suffix=".tmp", dir=parent or ".")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        if chmod_mode is not None:
            try:
                os.chmod(tmp, chmod_mode)
            except OSError:
                pass
        os.replace(tmp, path)
    except Exception:
        try:
            if os.path.isfile(tmp):
                os.unlink(tmp)
        except OSError:
            pass
        raise


def _run_pip_sdk(pip_pkg: str, sdk_version: str, pip_extra: str) -> None:
    extra = pip_extra.split() if pip_extra else []
    cmd = [sys.executable, "-m", "pip", "install", f"{pip_pkg}=={sdk_version}", *extra]
    logger.info("apply_bootstrap: pip install %s==%s", pip_pkg, sdk_version)
    subprocess.run(cmd, check=True, env=os.environ.copy())


def apply_bootstrap_from_config(
    data: Dict[str, Any],
    *,
    payload: Optional[Dict[str, Any]] = None,
    env_file: Optional[str] = None,
    wrapper_file: Optional[str] = None,
    workdir: Optional[str] = None,
    pip_pkg: Optional[str] = None,
    pip_extra: str = "",
    deployment_id: Optional[str] = None,
    emit_events: bool = True,
) -> BootstrapApplyResult:
    """
    Apply envTemplate, wrapperScript, and optional sdk pip install from GET /api/agent/config JSON.

    When PUVINOISE_CONTROL_RUNTIME_EXEC is disabled: logs intent only; no filesystem changes.

    Hash file is written only after env, wrapper, restart script (if any), and pip (if any) all succeed.
    """
    env_file = (env_file or os.environ.get("PUVINOISE_ENV_FILE") or "").strip()
    wrapper_file = (wrapper_file or os.environ.get("PUVINOISE_WRAPPER_FILE") or "").strip()
    wd = (workdir or os.environ.get("PUVINOISE_AGENT_WORKDIR") or "").strip() or os.getcwd()
    # PyPI distribution name is puvinoise-sdk (import package remains puvinoise).
    pip_pkg = (pip_pkg or os.environ.get("PUVINOISE_PIP_PACKAGE") or "puvinoise-sdk").strip() or "puvinoise-sdk"

    env_template = ""
    wrapper_script = ""
    restart_script = ""
    sdk_version = ""
    if isinstance(data, dict):
        env_template = str(data.get("envTemplate") or "").strip()
        wrapper_script = str(data.get("wrapperScript") or "").strip()
        restart_script = str(data.get("restartScript") or "").strip()
        sv = data.get("sdkVersion")
        if sv is not None and str(sv).strip():
            sdk_version = str(sv).strip()

    if not runtime_exec_enabled():
        logger.info(
            "apply_bootstrap: skipped (PUVINOISE_CONTROL_RUNTIME_EXEC!=1); would apply env=%s wrapper=%s sdk=%s",
            "yes" if env_template else "no",
            "yes" if wrapper_script else "no",
            sdk_version or "(none)",
        )
        return BootstrapApplyResult(
            changed=False,
            wrote_env=False,
            wrote_wrapper=False,
            wrote_restart=False,
            ran_pip=False,
        )

    h = _hash_material(env_template, wrapper_script, sdk_version, restart_script)
    hash_path = (os.environ.get("PUVINOISE_BOOTSTRAP_HASH_FILE") or "").strip() or _default_hash_path(wd)
    prev = ""
    try:
        if os.path.isfile(hash_path):
            with open(hash_path, "r", encoding="utf-8") as f:
                prev = f.read().strip()
    except OSError:
        prev = ""

    if prev == h:
        logger.debug("apply_bootstrap: hash unchanged; skip writes")
        return BootstrapApplyResult(
            changed=False,
            wrote_env=False,
            wrote_wrapper=False,
            wrote_restart=False,
            ran_pip=False,
        )

    wrote_env = False
    wrote_wrapper = False
    wrote_restart = False
    ran_pip = False

    try:
        if env_template:
            if not env_file:
                raise RuntimeError("apply_bootstrap: envTemplate set but PUVINOISE_ENV_FILE is empty")
            body = env_template if env_template.endswith("\n") else env_template + "\n"
            _atomic_write_text(env_file, body)
            logger.info("apply_bootstrap: wrote env file %s", env_file)
            wrote_env = True
        elif env_file:
            lines = build_env_lines_from_platform_response(data, payload)
            if lines:
                content = "\n".join(lines) + "\n"
                _atomic_write_text(env_file, content)
                logger.info("apply_bootstrap: wrote generated env lines to %s", env_file)
                wrote_env = True

        if wrapper_script:
            if not wrapper_file:
                raise RuntimeError("apply_bootstrap: wrapperScript set but PUVINOISE_WRAPPER_FILE is empty")
            body = wrapper_script if wrapper_script.endswith("\n") else wrapper_script + "\n"
            _atomic_write_text(wrapper_file, body, chmod_mode=0o755)
            logger.info("apply_bootstrap: wrote wrapper %s", wrapper_file)
            wrote_wrapper = True

        if restart_script:
            rs_env = (os.environ.get("PUVINOISE_RESTART_SCRIPT") or "").strip()
            if rs_env:
                restart_dest = rs_env if os.path.isabs(rs_env) else os.path.join(wd, rs_env.lstrip("./"))
            else:
                restart_dest = os.path.join(wd, "puvinoise-agent-restart.sh")
            body = restart_script if restart_script.endswith("\n") else restart_script + "\n"
            _atomic_write_text(restart_dest, body, chmod_mode=0o755)
            logger.info("apply_bootstrap: wrote restart script %s", restart_dest)
            wrote_restart = True

        if sdk_version:
            _run_pip_sdk(pip_pkg, sdk_version, pip_extra)
            ran_pip = True

        parent = os.path.dirname(os.path.abspath(hash_path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        _atomic_write_text(hash_path, h + "\n")

    except Exception as e:
        logger.error("apply_bootstrap failed: %s", e, exc_info=True)
        if emit_events:
            _emit_config_failed(deployment_id, str(e))
        raise

    changed = bool(wrote_env or wrote_wrapper or wrote_restart or ran_pip or prev != h)
    if emit_events and (wrote_env or wrote_wrapper or wrote_restart or ran_pip):
        _emit_config_applied(
            deployment_id,
            "Bootstrap config applied (env/wrapper/restart/sdk)",
        )
    return BootstrapApplyResult(
        changed=changed,
        wrote_env=wrote_env,
        wrote_wrapper=wrote_wrapper,
        wrote_restart=wrote_restart,
        ran_pip=ran_pip,
    )
