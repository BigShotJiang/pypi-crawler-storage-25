"""
End-to-end verification that span.add_event("decision.failure", {...}) is:

  1. Written to the span's event list **while the span is recording** (direct, synchronous call).
  2. **Included in the batch exported** by the OTEL SDK (verified via InMemorySpanExporter).
  3. **Serialized with the correct field names**: failure_category, error_type.
     In Jaeger each span event appears as a "Log" entry; the SDK adds a synthetic
     ``event`` key equal to the event name — consumers see:
       event              = "decision.failure"
       failure_category   = <category string>
       error_type         = <exception class name>

  4. Attribute values are **OTEL-compatible scalar types** (str/bool/int/float).
  5. **SpanLimits.max_events** is configured high enough that events are never
     silently truncated (default SDK limit is 128; we set 1024).

These tests do NOT require a real OTLP endpoint — InMemorySpanExporter captures
spans in-process.  They run without any PUVINoise platform credentials.
"""

from __future__ import annotations

import os

import pytest

# ---------------------------------------------------------------------------
# Required env stubs so SDK modules import without raising on missing identity.
# These are set BEFORE any puvinoise import.
# ---------------------------------------------------------------------------
os.environ.setdefault("PUVINOISE_AGENT_ID", "agt_test_export_001")
os.environ.setdefault("PUVINOISE_TENANTID", "test-tenant-export")
os.environ.setdefault("PUVINOISE_ENV_ID", "env_test_export_001")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_provider():
    """
    Return a (TracerProvider, InMemorySpanExporter) pair backed by a
    SimpleSpanProcessor (synchronous — no background thread, no race conditions).
    Sets the global tracer provider so trace.get_current_span() resolves correctly.
    """
    from opentelemetry.sdk.trace import TracerProvider, SpanLimits
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry import trace

    exporter = InMemorySpanExporter()
    # Use the same SpanLimits as production (generous event count).
    limits = SpanLimits(
        max_span_attributes=512,
        max_attribute_length=2048,
        max_events=1024,
        max_event_attributes=64,
    )
    provider = TracerProvider(span_limits=limits)
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    return provider, exporter


def _failure_events(exporter, span_name: str = "agent.run") -> list:
    """Return all 'decision.failure' events from finished spans matching *span_name*."""
    return [
        e
        for s in exporter.get_finished_spans()
        if s.name == span_name
        for e in s.events
        if e.name == "decision.failure"
    ]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestDecisionFailureEventEmission:
    """record_failure() emits a 'decision.failure' span event."""

    def test_event_present_in_span_events(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")

        from puvinoise.decision_telemetry import record_failure

        with tracer.start_as_current_span("agent.run"):
            record_failure(category="timeout", error_type="SlowLLMResponse", message="took 35s")

        evs = _failure_events(exporter)
        assert len(evs) >= 1, (
            f"Expected ≥1 'decision.failure' event, got {len(evs)}. "
            f"All event names in span: "
            f"{[e.name for s in exporter.get_finished_spans() for e in s.events]}"
        )

    def test_failure_category_attribute_correct(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")

        from puvinoise.decision_telemetry import record_failure

        with tracer.start_as_current_span("agent.run"):
            record_failure(category="rate_limit", error_type="RateLimitError")

        ev = _failure_events(exporter)[0]
        attrs = dict(ev.attributes or {})
        assert attrs.get("failure_category") == "rate_limit", (
            f"failure_category mismatch: {attrs}"
        )

    def test_error_type_attribute_correct(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")

        from puvinoise.decision_telemetry import record_failure

        with tracer.start_as_current_span("agent.run"):
            record_failure(category="tool_error", error_type="ToolExecutionError")

        ev = _failure_events(exporter)[0]
        attrs = dict(ev.attributes or {})
        assert attrs.get("error_type") == "ToolExecutionError", (
            f"error_type mismatch: {attrs}"
        )

    def test_event_name_is_exact_string(self):
        """Event name must be exactly 'decision.failure' — no prefix/suffix/case variation."""
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")

        from puvinoise.decision_telemetry import record_failure

        with tracer.start_as_current_span("agent.run"):
            record_failure(category="auth_error", error_type="AuthenticationError")

        all_names = [
            e.name
            for s in exporter.get_finished_spans()
            for e in s.events
        ]
        assert "decision.failure" in all_names, (
            f"Exact name 'decision.failure' not found. Got: {all_names}"
        )


class TestDecisionFailureExportedInBatch:
    """After the span ends, the exported span data includes the decision.failure event."""

    def test_event_survives_span_export(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")

        from puvinoise.decision_telemetry import record_failure

        with tracer.start_as_current_span("agent.run"):
            record_failure(category="content_filter", error_type="ContentFilterTriggered")

        finished = exporter.get_finished_spans()
        assert finished, "No spans exported after span.end()"

        span_data = next((s for s in finished if s.name == "agent.run"), None)
        assert span_data is not None, "agent.run span not in exported batch"

        event_names = [e.name for e in span_data.events]
        assert "decision.failure" in event_names, (
            f"'decision.failure' missing from exported span events: {event_names}"
        )

    def test_exported_event_attributes_match(self):
        """Attributes on the exported event must be the exact values that were set."""
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")

        from puvinoise.decision_telemetry import record_failure

        with tracer.start_as_current_span("agent.run"):
            record_failure(category="token_limit", error_type="MaxTokensReached")

        span_data = next(s for s in exporter.get_finished_spans() if s.name == "agent.run")
        ev = next(e for e in span_data.events if e.name == "decision.failure")
        attrs = dict(ev.attributes or {})

        assert attrs["failure_category"] == "token_limit"
        assert attrs["error_type"] == "MaxTokensReached"

    def test_multiple_failure_events_all_exported(self):
        """
        When record_failure() is called N times, at least N 'decision.failure' events
        must be present in the exported span.

        Note: each record_failure() call emits TWO decision.failure events —
          1. A minimal direct span.add_event() call (guaranteed, bypasses identity gate).
          2. A full-envelope span.add_event() call via _emit_with_envelope().
        Both are intentional: the first is always visible to the trace-normalizer; the
        second carries the full DecisionEventEnvelope for the behaviour pipeline.
        We assert >= N (not == N) to remain correct regardless of the identity-gate path.
        """
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")

        from puvinoise.decision_telemetry import record_failure

        with tracer.start_as_current_span("agent.run"):
            record_failure(category="rate_limit", error_type="RateLimitError")
            record_failure(category="timeout", error_type="SlowLLMResponse")
            record_failure(category="tool_error", error_type="ToolExecutionError")

        span_data = next(s for s in exporter.get_finished_spans() if s.name == "agent.run")
        failure_evs = [e for e in span_data.events if e.name == "decision.failure"]
        assert len(failure_evs) >= 3, (
            f"Expected at least 3 decision.failure events, got {len(failure_evs)}"
        )
        # Every emitted category must appear at least once.
        categories = {dict(e.attributes or {}).get("failure_category") for e in failure_evs}
        assert {"rate_limit", "timeout", "tool_error"}.issubset(categories), (
            f"Not all expected categories found: {categories}"
        )


class TestDecisionFailureAttributeTypes:
    """Span event attribute values must be OTEL-compatible scalar types."""

    _OTEL_SCALAR = (str, bool, int, float)

    def _check_attrs(self, attrs: dict) -> None:
        for key, val in attrs.items():
            if isinstance(val, (list, tuple)):
                for item in val:
                    assert isinstance(item, self._OTEL_SCALAR), (
                        f"Sequence attribute '{key}' element has non-OTEL type {type(item)}: {item!r}"
                    )
            else:
                assert isinstance(val, self._OTEL_SCALAR), (
                    f"Attribute '{key}' has non-OTEL type {type(val)}: {val!r}"
                )

    def test_timeout_category(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")
        from puvinoise.decision_telemetry import record_failure
        with tracer.start_as_current_span("agent.run"):
            record_failure(category="timeout", error_type="SlowLLMResponse")
        ev = _failure_events(exporter)[0]
        self._check_attrs(dict(ev.attributes or {}))

    def test_unknown_category(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")
        from puvinoise.decision_telemetry import record_failure
        with tracer.start_as_current_span("agent.run"):
            record_failure(category="EmptyLLMResponse", error_type="EmptyLLMResponse")
        ev = _failure_events(exporter)[0]
        self._check_attrs(dict(ev.attributes or {}))


class TestDecisionFailureCategoryNormalization:
    """Unknown / misspelled categories must be normalized to 'unknown', not dropped."""

    def test_unrecognised_category_becomes_unknown(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")
        from puvinoise.decision_telemetry import record_failure
        with tracer.start_as_current_span("agent.run"):
            record_failure(category="some_weird_category_xyz", error_type="WeirdError")
        evs = _failure_events(exporter)
        assert evs, "No failure event emitted for unrecognised category"
        assert dict(evs[0].attributes or {}).get("failure_category") == "unknown"

    def test_none_category_becomes_unknown(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")
        from puvinoise.decision_telemetry import record_failure
        with tracer.start_as_current_span("agent.run"):
            record_failure(category=None)  # type: ignore[arg-type]
        evs = _failure_events(exporter)
        assert evs, "No failure event emitted for None category"
        assert dict(evs[0].attributes or {}).get("failure_category") == "unknown"

    def test_all_canonical_categories_pass_through(self):
        """Every canonical category must appear in the exported events (at least once each)."""
        from puvinoise.decision_telemetry.events import FAILURE_CATEGORIES
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")
        from puvinoise.decision_telemetry import record_failure
        with tracer.start_as_current_span("agent.run"):
            for cat in FAILURE_CATEGORIES:
                record_failure(category=cat)
        evs = _failure_events(exporter)
        # >= len(FAILURE_CATEGORIES) because each call may emit >1 event (direct + envelope).
        assert len(evs) >= len(FAILURE_CATEGORIES), (
            f"Expected at least {len(FAILURE_CATEGORIES)} events, got {len(evs)}"
        )
        exported_categories = {dict(e.attributes or {}).get("failure_category") for e in evs}
        assert set(FAILURE_CATEGORIES).issubset(exported_categories), (
            f"Missing categories: {set(FAILURE_CATEGORIES) - exported_categories}"
        )


class TestDecisionFailureWithoutErrorType:
    """record_failure() without error_type must still emit failure_category."""

    def test_failure_category_present_without_error_type(self):
        provider, exporter = _make_provider()
        tracer = provider.get_tracer("test")
        from puvinoise.decision_telemetry import record_failure
        with tracer.start_as_current_span("agent.run"):
            record_failure(category="bad_request")
        evs = _failure_events(exporter)
        assert evs, "No failure event emitted"
        attrs = dict(evs[0].attributes or {})
        assert "failure_category" in attrs, f"failure_category missing: {attrs}"
        assert attrs["failure_category"] == "bad_request"
        # error_type may or may not be present — either is acceptable
        if "error_type" in attrs:
            assert isinstance(attrs["error_type"], str)


class TestSpanLimitsPreventEventDrop:
    """
    Verify that the production SpanLimits configuration (max_events=1024) does
    not silently drop decision.failure events even when many events are emitted.
    """

    def test_1000_events_all_exported(self):
        """
        With max_events=1024, emitting 200 record_failure() calls must result in
        at least 200 decision.failure events in the exported span.

        Each record_failure() call emits 2 events (direct + envelope), so the
        actual count will be ~400.  We assert >= N (200) to verify no events are
        dropped.  With the old default of max_events=128, calls beyond #64 would
        be silently dropped.
        """
        from opentelemetry.sdk.trace import TracerProvider, SpanLimits
        from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
        from opentelemetry.sdk.trace.export import SimpleSpanProcessor
        from opentelemetry import trace

        exporter = InMemorySpanExporter()
        limits = SpanLimits(max_events=1024, max_event_attributes=64)
        provider = TracerProvider(span_limits=limits)
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        trace.set_tracer_provider(provider)

        tracer = provider.get_tracer("test")
        from puvinoise.decision_telemetry import record_failure

        N = 200
        with tracer.start_as_current_span("agent.run"):
            for i in range(N):
                record_failure(category="tool_error", error_type=f"Error_{i}")

        span_data = next(s for s in exporter.get_finished_spans() if s.name == "agent.run")
        failure_evs = [e for e in span_data.events if e.name == "decision.failure"]
        assert len(failure_evs) >= N, (
            f"Expected at least {N} events with max_events=1024, got {len(failure_evs)} — "
            f"events are being dropped beyond the limit!"
        )

    def test_default_128_limit_would_drop_events(self):
        """
        Document (and verify) that the SDK default max_events=128 drops events
        beyond index 128.  This test confirms why we override to 1024.
        """
        from opentelemetry.sdk.trace import TracerProvider, SpanLimits
        from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
        from opentelemetry.sdk.trace.export import SimpleSpanProcessor
        from opentelemetry import trace

        exporter = InMemorySpanExporter()
        limits = SpanLimits(max_events=128)  # SDK default
        provider = TracerProvider(span_limits=limits)
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        trace.set_tracer_provider(provider)

        tracer = provider.get_tracer("test")
        from puvinoise.decision_telemetry import record_failure

        with tracer.start_as_current_span("agent.run"):
            for _ in range(200):  # emit more than the 128-event limit
                record_failure(category="tool_error", error_type="ToolError")

        span_data = next(s for s in exporter.get_finished_spans() if s.name == "agent.run")
        failure_evs = [e for e in span_data.events if e.name == "decision.failure"]
        # With max_events=128 the SDK drops events beyond the limit.
        assert len(failure_evs) <= 128, (
            "Unexpected: default limit didn't cap events — SDK may have changed behaviour"
        )
        # The important assertion: production config (1024) must be strictly better.
        # This assertion will fail if somehow the default suddenly allows >128 events,
        # in which case revisit _resolve_span_limits.
