"""
Tests for SDK control loop (polling, pause/resume, PATCH completion path, failures).
"""
from __future__ import annotations

import os
import threading
import time
import unittest
from unittest import mock

# Ensure package import
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class TestControlLoop(unittest.TestCase):
    def setUp(self) -> None:
        import puvinoise.control_loop as cl

        cl.stop_control_loop()
        cl._control_stop.clear()
        cl._delegating_worker = None
        cl._runtime.agent_paused = False
        cl._runtime.lifecycle = cl.ControlLifecycleState.ACTIVE
        cl._runtime.config.clear()
        cl._runtime._pause_event.set()

    def tearDown(self) -> None:
        import puvinoise.control_loop as cl

        cl.stop_control_loop()

    def test_pause_resume_lifecycle(self) -> None:
        import puvinoise.control_loop as cl
        from puvinoise.agent_runtime.agent_control_worker import AgentControlWorker, ControlCommand

        with mock.patch("puvinoise.agent_runtime.completion.post_control_command_completion", return_value=True):
            cl._delegating_worker = AgentControlWorker(agent_id="agt_test", base_url="http://127.0.0.1:9", api_key="k")
            cl._delegating_worker.dispatch_agent_command(ControlCommand(command="pause", command_id="p1"))
            cl._sync_runtime_from_worker()
            self.assertTrue(cl.is_agent_paused())
            cl._delegating_worker.dispatch_agent_command(ControlCommand(command="resume", command_id="p2"))
            cl._sync_runtime_from_worker()
            self.assertFalse(cl.is_agent_paused())

    def test_config_update_merges(self) -> None:
        import puvinoise.control_loop as cl

        cl._runtime.merge_config({"foo": "bar", "n": 1})
        snap = cl.get_runtime_config_snapshot()
        self.assertEqual(snap.get("foo"), "bar")
        self.assertEqual(snap.get("n"), 1)

    def test_execute_command_uses_patch_not_post_ack_on_success(self) -> None:
        import puvinoise.control_loop as cl

        cl._delegating_worker = None
        with mock.patch("puvinoise.control_loop._post_ack") as mock_ack:
            with mock.patch("puvinoise.agent_runtime.completion.post_control_command_completion", return_value=True):
                with mock.patch(
                    "puvinoise.control_loop._fetch_queue",
                    return_value=[{"command_id": "c1", "type": "pause", "payload": {}}],
                ):
                    cl._loop_body("https://x.example.com", "agt_test", "key")
        mock_ack.assert_not_called()

    def test_execute_command_failed_unknown_type_still_posts_ack(self) -> None:
        import puvinoise.control_loop as cl

        cl._delegating_worker = None
        with mock.patch("puvinoise.control_loop._post_ack") as mock_ack:
            with mock.patch(
                "puvinoise.control_loop._fetch_queue",
                return_value=[{"command_id": "x", "type": "unknown_xyz", "payload": {}}],
            ):
                cl._loop_body("https://x.example.com", "agt_test", "key")
        mock_ack.assert_called_once()
        args = mock_ack.call_args[0]
        self.assertEqual(args[3], "x")
        self.assertEqual(args[4], "failed")

    def test_dispatch_raises_posts_ack(self) -> None:
        import puvinoise.control_loop as cl

        cl._delegating_worker = None

        def boom(*_a, **_k):
            raise RuntimeError("boom")

        with mock.patch("puvinoise.control_loop._post_ack") as mock_ack:
            with mock.patch("puvinoise.control_loop._ensure_dispatch_worker", side_effect=boom):
                with mock.patch(
                    "puvinoise.control_loop._fetch_queue",
                    return_value=[{"command_id": "c2", "type": "pause", "payload": {}}],
                ):
                    cl._loop_body("https://x.example.com", "agt_test", "key")
        mock_ack.assert_called_once()
        self.assertEqual(mock_ack.call_args[0][3], "c2")
        self.assertEqual(mock_ack.call_args[0][4], "failed")

    def test_start_idempotent(self) -> None:
        import puvinoise.control_loop as cl

        os.environ["PUVINOISE_BASE_URL"] = "https://p.example.com"
        os.environ["PUVINOISE_AGENT_ID"] = "agt_1"
        os.environ["PUVINOISE_API_KEY"] = "k"
        try:
            self.assertTrue(cl.start_control_loop(interval_seconds=30.0))
            t1 = cl._control_thread
            self.assertTrue(cl.start_control_loop(interval_seconds=30.0))
            self.assertIs(t1, cl._control_thread)
        finally:
            del os.environ["PUVINOISE_BASE_URL"]
            del os.environ["PUVINOISE_AGENT_ID"]
            del os.environ["PUVINOISE_API_KEY"]
            cl.stop_control_loop()

    def test_run_loop_invokes_loop_body_after_interval(self) -> None:
        import puvinoise.control_loop as cl

        with mock.patch("puvinoise.control_loop._loop_body") as lb:
            cl._control_stop.clear()
            th = threading.Thread(target=lambda: cl._run_loop("https://p.example.com", "a1", "", 0.12), daemon=True)
            th.start()
            time.sleep(0.55)
            cl._control_stop.set()
            th.join(timeout=3.0)
        self.assertGreaterEqual(lb.call_count, 1)


if __name__ == "__main__":
    unittest.main()
