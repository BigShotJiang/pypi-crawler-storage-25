import os
import re
from pathlib import Path
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed
from sds_mng.setting.fetch_producs import fetch_products
from sds_mng.exception import UnauthorizedError
from aiohttp import ClientError
from inkreach_sync_data.lib.sds.token import maybe_refresh_token
from inkreach_sync_data.lib.sds.config import JSON_INDENT, SYNC_DATA_FILE_UPDATE_GAP
from sds_mng.util import logger
import arrow
import json


@retry(
    stop=stop_after_attempt(3),
    wait=wait_fixed(2),
    retry=retry_if_exception_type((UnauthorizedError, ClientError)),
    before_sleep=maybe_refresh_token,
    reraise=True,
)
async def update_sds_products():
    config_path = Path(os.getenv("SDS_MNG_PRODUCTS_PATH", "sds_mng_products.json"))
    token = os.getenv("SDS_MNG_TOKEN")

    data1 = await fetch_products(token)
    data2 = await fetch_products(token,{
        "publicStatus": 0
    })
    data = data1.get("list", []) + data2.get("list", [])

    def parse_name(name: str):
        parts = re.split(r"[（）]", name)
        if len(parts) < 3:
            return "", "", ""

        country = parts[0]
        middle = parts[2]
        subs = middle.split("-")

        if len(subs) == 2:
            return country, subs[0], ""
        if len(subs) == 3:
            return country, subs[0], subs[1]
        return "", "", ""

    products = {}
    for item in data.get("list", []):
        name = item.get("name", "")
        country, product_name, style_no = parse_name(name)
        products[name] = {
            "sku": item.get("sku", ""),
            "country": country,
            "product_name": product_name.strip(),
            "style_no": style_no,
        }

    with config_path.open("w", encoding="utf-8") as f:
        json.dump(products, f, ensure_ascii=False, indent=JSON_INDENT)

async def update_sds_products_file():
    products_config_path = (
        os.environ.get("SDS_MNG_PRODUCTS_PATH") or "sds_mng_products.json"
    )

    if not os.path.exists(products_config_path):
        await update_sds_products()
        return

    arrow.default_tz = "Asia/Shanghai"
    mtime = arrow.get(os.path.getmtime(products_config_path))
    if mtime < arrow.now().shift(hours=-SYNC_DATA_FILE_UPDATE_GAP):
        logger.info(
            f"产品信息上次更新时间为 {mtime.format('YYYY-MM-DD HH:mm:ss')}， "
            + "可以更新产品信息了"
        )
        await update_sds_products()
    else:
        logger.info(
            f"产品信息上次更新时间为 {mtime.format('YYYY-MM-DD HH:mm:ss')}， "
            + "无需更新产品信息"
        )
        return
