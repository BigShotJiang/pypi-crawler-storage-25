# tests/test_client.py
import unittest
from unittest.mock import patch, Mock
from ffclient import FFClient, ValidationError, AuthenticationError

base_url = "http://127.0.0.1:5000"

class TestFFClient(unittest.TestCase):

    def setUp(self):
        self.client = FFClient(api_key="sk_ff_test_key", base_url=base_url)

    def test_client_init(self):
        self.assertEqual(self.client.api_key, "sk_ff_test_key")
        self.assertEqual(self.client.base_url, "http://127.0.0.1:5000")
        self.assertEqual(self.client.session.headers["Authorization"], "Bearer sk_ff_test_key")

    def test_invalid_uid_validation(self):
        with self.assertRaises(ValidationError):
            self.client.get_player_basic("12") # Too short
        with self.assertRaises(ValidationError):
            self.client.get_player_basic("abc") # Not numeric

    @patch('requests.Session.request')
    def test_get_player_basic_success(self, mock_get):
        # Mocking a successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "success": True,
            "data": {"uid": "10001", "nickname": "TestUser"},
            "credits_left": 295
        }
        mock_get.return_value = mock_response

        data = self.client.get_player_basic("10001")
        self.assertTrue(data["success"])
        self.assertEqual(data["data"]["uid"], "10001")
        self.assertEqual(data["credits_left"], 295)

    @patch('requests.Session.request')
    def test_authentication_error(self, mock_get):
        # Mocking a 401 error
        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.json.return_value = {"success": False, "error": "Invalid API key"}
        mock_get.return_value = mock_response

        with self.assertRaises(AuthenticationError):
            self.client.get_player_basic("10001")

if __name__ == '__main__':
    unittest.main()
