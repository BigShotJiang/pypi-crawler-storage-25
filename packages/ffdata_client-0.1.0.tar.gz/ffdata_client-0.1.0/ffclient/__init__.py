# ffclient/__init__.py
from .client import FFClient
from .exceptions import (
    FFClientError,
    AuthenticationError,
    InsufficientCreditsError,
    RateLimitError,
    ValidationError,
    APIError
)

__version__ = "0.1.0"
__all__ = [
    "FFClient",
    "FFClientError",
    "AuthenticationError",
    "InsufficientCreditsError",
    "RateLimitError",
    "ValidationError",
    "APIError"
]
