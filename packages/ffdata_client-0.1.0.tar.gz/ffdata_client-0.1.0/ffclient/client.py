# ffclient/client.py
import os
import requests
import time
import random
import threading
import collections
from typing import Dict, Any, Optional, List, Union, Callable
from requests.adapters import HTTPAdapter
from .exceptions import (
    FFClientError,
    AuthError,
    AuthenticationError,
    InsufficientCreditsError,
    RateLimitError,
    NetworkError,
    APIError,
    ValidationError,
    CircuitBreakerError
)
from .utils import validate_uid, format_url

class FFClient:
    """
    Enterprise-grade Python SDK for the FFData API.
    
    Final stabilization phase:
    - LRU Bounded cache for memory safety
    - Adaptive circuit breaker cooldown
    - Global fail-safe mechanism
    - UID integer consistency
    - Enriched fallback metadata
    """
    
    VERSION = "0.1.0"
    API_VERSION = "v1"

    def __init__(
        self, 
        api_key: str, 
        base_url: Optional[str] = None, 
        debug: Union[bool, str] = False,
        timeout: int = 10,
        max_retries: int = 2,
        on_response: Optional[Callable[[Dict[str, Any], Dict[str, Any]], None]] = None,
        fallback_mode: bool = False
    ):
        """
        Initialize the FFClient with enterprise resilience features.
        
        :param on_response: Callback hook for metrics/logging: fn(data, meta).
        :param fallback_mode: If True, returns last successful response during circuit/limit outages.
        """
        if not api_key:
            raise ValueError("API key is required")
        if not base_url:
            base_url = os.getenv("FFCLIENT_BASE_URL")
        if not base_url:
            raise ValueError("Base URL must be provided")

        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.on_response = on_response
        self.fallback_mode = fallback_mode
        
        # Thread Safety
        self._lock = threading.Lock()
        
        # Setup Debug Level
        if isinstance(debug, bool):
            self.debug_level = "basic" if debug else "off"
        else:
            self.debug_level = str(debug).lower()

        # Connection Pooling
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=25, pool_maxsize=25)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": f"FFData-Python-SDK/{self.VERSION}",
            "X-Client": f"ffclient/{self.VERSION}"
        })

        # Resilience State
        self._breaker_state = {}     # {endpoint_key: {"failures": 0, "until": 0}}
        self._rate_limit_until = {}  # {endpoint_key: timestamp}
        self._failure_threshold = 5
        
        # Memory-Safe Bounded LRU Cache (max 100 entries)
        self._last_success = collections.OrderedDict() 
        
        # Global Fail-Safe State (massive failures across endpoints)
        self._global_failures = 0
        self._global_pause_until = 0

    def _get_state_key(self, path: str) -> str:
        """Extracts a base key for granular tracking (ignores query strings)."""
        return path.split("?")[0]

    def _check_resilience(self, path: str):
        """Pre-request check for granular rate limit or open circuit breaker."""
        key = self._get_state_key(path)
        now = time.time()
        
        with self._lock:
            # Check Global Pause Fail-Safe
            if now < self._global_pause_until:
                wait = int(self._global_pause_until - now)
                raise CircuitBreakerError(f"SDK in global fail-safe pause ({wait}s)")

            # Check Rate Limit
            rl_until = self._rate_limit_until.get(key, 0)
            if now < rl_until:
                wait = int(rl_until - now)
                raise RateLimitError(f"Rate limit active for {key} ({wait}s)", retry_after=wait, endpoint=path)
                
            # Check Circuit Breaker
            breaker = self._breaker_state.get(key, {"until": 0})
            if now < breaker["until"]:
                wait = int(breaker["until"] - now)
                raise CircuitBreakerError(f"Circuit OPEN for {key} ({wait}s cooldown)", endpoint=path)

    def _request(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        key = self._get_state_key(path)
        uid = params.get('uid') if params else ''
        
        try:
            self._check_resilience(path)
        except (CircuitBreakerError, RateLimitError) as e:
            # Fallback mode check: serve stale data if available
            if self.fallback_mode:
                fallback_key = f"{key}:{uid}"
                with self._lock:
                    if fallback_key in self._last_success:
                        cached = self._last_success[fallback_key]
                        stale_age = int(time.time() - cached["ts"])
                        return {
                            "data": cached["data"], 
                            "meta": {
                                "fallback": True, 
                                "stale_age": stale_age,
                                "reason": str(e), 
                                "version": self.VERSION
                            }
                        }
            raise e

        url = format_url(self.base_url, path)
        start_time = time.time()
        
        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                if self.debug_level != "off":
                    safe_headers = {k: (v[:10] + "..." if k.lower() == "authorization" else v) for k, v in self.session.headers.items()}
                    print(f"\n[FF SDK] {method} {path} | Attempt {attempt+1}")
                    if self.debug_level == "verbose":
                        print(f"URL: {url} | Headers: {safe_headers}")

                response = self.session.request(
                    method=method, url=url, params=params, json=json, timeout=self.timeout
                )
                
                if self.debug_level != "off":
                    print(f"Status: {response.status_code} | Latency: {int((time.time()-start_time)*1000)}ms")

                # Recovery Logic: Success (Status < 500) resets the circuit
                if response.status_code < 500:
                    with self._lock:
                        if key in self._breaker_state:
                            self._breaker_state[key]["failures"] = 0
                            self._breaker_state[key]["until"] = 0
                        # Gradually recover global failures
                        self._global_failures = max(0, self._global_failures - 1)

                # Handle 5xx (Server error triggers retry)
                if response.status_code >= 500:
                    raise APIError(f"Server Error {response.status_code}", status_code=response.status_code, endpoint=path, method=method)
                
                result = self._handle_response(response, start_time, path, method)
                
                # Metrics Hook & Fallback Cache
                if self.on_response:
                    self.on_response(result["data"], result["meta"])
                
                if self.fallback_mode:
                    fallback_key = f"{key}:{uid}"
                    with self._lock:
                        # Memory-safe LRU eviction logic
                        if fallback_key in self._last_success:
                            self._last_success.move_to_end(fallback_key)
                        self._last_success[fallback_key] = {"data": result["data"], "ts": time.time()}
                        if len(self._last_success) > 100:
                            self._last_success.popitem(last=False)
                        
                return result

            except (requests.exceptions.RequestException, NetworkError) as e:
                self._handle_failure(key)
                last_error = NetworkError(str(e), endpoint=path, method=method)
                if attempt < self.max_retries:
                    # Jittered backoff
                    time.sleep((0.5 * (attempt + 1)) + random.uniform(0, 0.3))
                    continue
                raise last_error
                
            except RateLimitError as e:
                with self._lock:
                    self._rate_limit_until[key] = time.time() + int(e.retry_after or 1)
                raise e
                
            except APIError as e:
                if e.status_code and e.status_code >= 500:
                    self._handle_failure(key)
                    if attempt < self.max_retries:
                        time.sleep((0.5 * (attempt + 1)) + random.uniform(0, 0.3))
                        continue
                raise e
            except FFClientError as e:
                raise e

        raise last_error or APIError("Max retries exceeded", endpoint=path, method=method)

    def _handle_failure(self, key: str):
        """Failure tracking to open circuit breakers per endpoint and global fail-safe."""
        with self._lock:
            # Adaptive Circuit Breaker Cooldown
            state = self._breaker_state.get(key, {"failures": 0, "until": 0})
            state["failures"] += 1
            if state["failures"] >= self._failure_threshold:
                # Cooldown increases with repeated failures: 30s -> 60s -> 90s -> 120s max
                cooldown = min(30 * (state["failures"] - self._failure_threshold + 1), 120)
                state["until"] = time.time() + cooldown
                if self.debug_level != "off":
                    print(f"[FF SDK] Circuit OPEN for {key} | Cooldown: {cooldown}s")
            self._breaker_state[key] = state
            
            # Global Fail-Safe Mechanism (massive failures across all endpoints)
            self._global_failures += 1
            if self._global_failures >= 20:
                self._global_pause_until = time.time() + 60
                self._global_failures = 0
                if self.debug_level != "off":
                    print("[FF SDK] GLOBAL FAIL-SAFE triggered | requests paused for 60s")

    def _handle_response(self, response: requests.Response, start_time: float, path: str, method: str) -> Dict[str, Any]:
        status_code = response.status_code
        duration_ms = int((time.time() - start_time) * 1000)
        
        try:
            body = response.json()
        except ValueError:
            raise APIError("Malformed JSON response", status_code=status_code, endpoint=path, method=method)

        request_id = body.get("request_id")

        if status_code == 401:
            raise AuthError(body.get("error", "Unauthorized"), request_id=request_id, endpoint=path, method=method)
        elif status_code == 403:
            raise InsufficientCreditsError(body.get("error", "Insufficient credits"), request_id=request_id, endpoint=path, method=method)
        elif status_code == 429:
            retry_after = response.headers.get("Retry-After", 1)
            raise RateLimitError(body.get("error", "Rate limit exceeded"), request_id=request_id, endpoint=path, method=method, retry_after=retry_after)
        elif status_code >= 400:
            raise APIError(body.get("error", "API error"), status_code=status_code, request_id=request_id, endpoint=path, method=method)

        if not body.get("success", False):
            raise APIError(body.get("error", "Internal API failure"), request_id=request_id, endpoint=path, method=method)

        return {
            "data": body.get("data"),
            "meta": {
                "time_ms": duration_ms,
                "request_id": request_id,
                "version": self.VERSION,
                "api_version": self.API_VERSION,
                "fallback": False
            }
        }

    def get_player(self, uid: int, region: str = "ind", detail_level: str = "basic") -> Dict[str, Any]:
        """
        Fetch Free Fire player data with enterprise resilience.
        
        :param uid: Player unique ID (must be an integer).
        """
        if not isinstance(uid, int):
            raise ValidationError("UID must be an integer")
        if detail_level not in ["basic", "detailed", "full"]:
            raise ValidationError("Invalid detail_level")
        return self._request("GET", f"/api/{self.API_VERSION}/player/basic", params={"uid": uid, "region": region.lower(), "detail": detail_level})

    def get_workshop_author(self, uid: int, detail_level: str = "basic") -> Dict[str, Any]:
        """
        Fetch Craftland creator info with enterprise resilience.
        
        :param uid: Creator unique ID (must be an integer).
        """
        if not isinstance(uid, int):
            raise ValidationError("UID must be an integer")
        if detail_level not in ["basic", "detailed", "full"]:
            raise ValidationError("Invalid detail_level")
        return self._request("GET", f"/api/{self.API_VERSION}/workshop/author", params={"uid": uid, "detail": detail_level})
