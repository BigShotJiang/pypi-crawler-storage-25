# ffclient/exceptions.py

class FFClientError(Exception):
    """Base exception for FFClient."""
    def __init__(self, message, request_id=None, endpoint=None, method=None):
        super().__init__(message)
        self.request_id = request_id
        self.endpoint = endpoint
        self.method = method

class AuthError(FFClientError):
    """Raised when API key is invalid (401)."""
    pass

class AuthenticationError(AuthError):
    """Backward compatibility alias for AuthError."""
    pass

class InsufficientCreditsError(FFClientError):
    """Raised when account has insufficient credits (403)."""
    pass

class RateLimitError(FFClientError):
    """Raised when rate limit is exceeded (429)."""
    def __init__(self, message, request_id=None, endpoint=None, method=None, retry_after=None):
        super().__init__(message, request_id=request_id, endpoint=endpoint, method=method)
        self.retry_after = retry_after

class NetworkError(FFClientError):
    """Raised for network-related errors (timeouts, connection issues)."""
    pass

class ValidationError(FFClientError):
    """Raised when input validation fails."""
    pass

class CircuitBreakerError(FFClientError):
    """Raised when requests are blocked due to frequent recent failures."""
    pass

class APIError(FFClientError):
    """Raised for other API-related errors."""
    def __init__(self, message, status_code=None, request_id=None, endpoint=None, method=None):
        super().__init__(message, request_id=request_id, endpoint=endpoint, method=method)
        self.status_code = status_code
