# ffclient/utils.py
import re
from .exceptions import ValidationError

def validate_uid(uid: str):
    """
    Validates that the UID is numeric and at least 3 digits.
    """
    if not isinstance(uid, str):
        raise ValidationError("UID must be a string")
    if not re.match(r"^\d{3,}$", uid):
        raise ValidationError("UID must be numeric and at least 3 digits long")

def format_url(base_url: str, path: str) -> str:
    """Formats the final API URL."""
    return f"{base_url.rstrip('/')}/{path.lstrip('/')}"
