from __future__ import annotations

import io
import tokenize
from pathlib import Path
from typing import Iterable

from .keywords import KEYWORDS


def _iter_tokens(source: str) -> Iterable[tokenize.TokenInfo]:
    if not source.endswith("\n"):
        source = source + "\n"
    buf = io.BytesIO(source.encode("utf-8"))
    return tokenize.tokenize(buf.readline)


def transpile(source: str) -> str:
    new_tokens: list[tuple[int, str]] = []
    for tok in _iter_tokens(source):
        if tok.type == tokenize.ENCODING:
            continue
        value = tok.string
        if tok.type == tokenize.NAME and value in KEYWORDS:
            value = KEYWORDS[value]
        new_tokens.append((tok.type, value))
    result = tokenize.untokenize(new_tokens)
    if isinstance(result, bytes):
        result = result.decode("utf-8")
    return result


def transpile_file(path: str | Path) -> str:
    return transpile(Path(path).read_text(encoding="utf-8"))


def run(source: str, filename: str = "<мелл>", globals_dict: dict | None = None) -> dict:
    py_source = transpile(source)
    g = globals_dict if globals_dict is not None else {"__name__": "__main__"}
    code = compile(py_source, filename, "exec")
    exec(code, g)
    return g


def run_file(path: str | Path) -> dict:
    p = Path(path)
    return run(p.read_text(encoding="utf-8"), filename=str(p))
