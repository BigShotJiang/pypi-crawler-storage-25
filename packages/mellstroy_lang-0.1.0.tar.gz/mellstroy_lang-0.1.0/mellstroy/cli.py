from __future__ import annotations

import argparse
import code
import sys
import tokenize
import traceback
from pathlib import Path

from . import __version__
from .transpiler import transpile, transpile_file, run_file


VERSION_LINE = f"Mellstroy Lang {__version__} | THE FOG IS COMING"
REPL_BANNER = (
    f"Mellstroy Lang REPL v{__version__}\n"
    "Боровы, даровы! Введи код:"
)


class _MellConsole(code.InteractiveConsole):
    def runsource(self, source, filename="<мелл>", symbol="single"):
        try:
            py = transpile(source)
        except tokenize.TokenError:
            return True
        except (SyntaxError, ValueError):
            return super().runsource(source, filename, symbol)
        try:
            return super().runsource(py, filename, symbol)
        except SystemExit:
            raise
        except BaseException:
            traceback.print_exc()
            return False


def _repl() -> int:
    console = _MellConsole(locals={"__name__": "__main__"})
    try:
        console.interact(banner=REPL_BANNER, exitmsg="")
    except SystemExit as e:
        return int(e.code or 0)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="мелл",
        description="Mellstroy Lang — питон, которым его задумывали.",
        add_help=True,
    )
    parser.add_argument("file", nargs="?", type=Path, help="Файл .мелл для запуска")
    parser.add_argument(
        "--transpile", action="store_true",
        help="Только транспилировать в Python, не запускать",
    )
    parser.add_argument(
        "-o", "--output", type=Path, default=None,
        help="Куда сохранить транспилированный Python (по умолчанию stdout)",
    )
    parser.add_argument("--repl", action="store_true", help="Запустить интерактивный REPL")
    parser.add_argument("--version", action="store_true", help="Показать версию и выйти")

    args = parser.parse_args(argv)

    if args.version:
        print(VERSION_LINE)
        return 0

    if args.repl:
        return _repl()

    if args.file is None:
        parser.print_help()
        return 0

    if args.transpile:
        py = transpile_file(args.file)
        if args.output:
            args.output.write_text(py, encoding="utf-8")
        else:
            sys.stdout.write(py)
        return 0

    run_file(args.file)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
