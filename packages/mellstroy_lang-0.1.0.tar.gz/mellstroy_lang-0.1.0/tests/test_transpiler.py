from __future__ import annotations

import io
from contextlib import redirect_stdout
from pathlib import Path

import pytest

from mellstroy import transpile, run


EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


def _exec(src: str) -> str:
    buf = io.StringIO()
    with redirect_stdout(buf):
        run(src, globals_dict={"__name__": "__main__"})
    return buf.getvalue()


def test_simple_print():
    out = _exec('ам_ам("привет")\n')
    assert out == "привет\n"


def test_function_and_return():
    src = (
        "боровыу удвой(x):\n"
        "    чекушность x * 2\n"
        "ам_ам(удвой(21))\n"
    )
    assert _exec(src).strip() == "42"


def test_if_elif_else():
    src = (
        "боровыу знак(x):\n"
        "    друн x > 0:\n"
        "        чекушность 'плюс'\n"
        "    а_если_брал x < 0:\n"
        "        чекушность 'минус'\n"
        "    жмурино:\n"
        "        чекушность 'ноль'\n"
        "ам_ам(знак(5), знак(-1), знак(0))\n"
    )
    assert _exec(src).strip() == "плюс минус ноль"


def test_for_in_range():
    src = (
        "s = 0\n"
        "самосбор i в_мурино от_до_мурино(5):\n"
        "    s += i\n"
        "ам_ам(s)\n"
    )
    assert _exec(src).strip() == "10"


def test_while_break_continue():
    src = (
        "i = 0\n"
        "акк = []\n"
        "фог_идёт вкусность:\n"
        "    i += 1\n"
        "    друн i == 3:\n"
        "        быстрее\n"
        "    друн i > 5:\n"
        "        ливт\n"
        "    акк.append(i)\n"
        "ам_ам(акк)\n"
    )
    assert _exec(src).strip() == "[1, 2, 4, 5]"


def test_truthy_falsy_none_types():
    src = (
        "ам_ам(вкусность, бурмалда, туман)\n"
        "ам_ам(омайгад(жирность(\"7\")).__name__)\n"
        "ам_ам(сколько_боровых(боровы([1, 2, 3])))\n"
    )
    assert _exec(src).splitlines() == ["True False None", "int", "3"]


def test_class_self_super():
    src = (
        "меллстройность A:\n"
        "    боровыу привет(ч):\n"
        "        чекушность 'A'\n"
        "меллстройность B(A):\n"
        "    боровыу привет(ч):\n"
        "        чекушность главборов().привет() + 'B'\n"
        "ам_ам(B().привет())\n"
    )
    assert _exec(src).strip() == "AB"


def test_try_except_finally_raise():
    src = (
        "боровыу f():\n"
        "    бурмалдим:\n"
        "        фог ValueError('боровы')\n"
        "    а_вдруг_фог ValueError as e:\n"
        "        ам_ам('поймал', e)\n"
        "    всё_равно_друн:\n"
        "        ам_ам('конец')\n"
        "f()\n"
    )
    assert _exec(src).splitlines() == ["поймал боровы", "конец"]


def test_lambda_and_logic():
    src = (
        "f = бэм_бэм x: (x > 0) и_друн не_нормалдаки (x == 5) или_фог бурмалда\n"
        "ам_ам(f(3), f(5), f(-1))\n"
    )
    assert _exec(src).strip() == "True False False"


def test_with_open(tmp_path):
    p = tmp_path / "t.txt"
    p.write_text("здарова\n", encoding="utf-8")
    src = (
        f"вместе_с_друном гермодверь({p.as_posix()!r}, encoding='utf-8') as f:\n"
        "    ам_ам(f.read().strip())\n"
    )
    assert _exec(src).strip() == "здарова"


def test_strings_are_not_translated():
    py = transpile('ам_ам("боровыу друн ч")\n')
    assert '"боровыу друн ч"' in py
    assert py.lstrip().startswith("print")


def test_comments_are_not_translated():
    py = transpile("# боровыу друн ч\nам_ам(1)\n")
    assert "# боровыу друн ч" in py


def test_imports():
    src = (
        "из_мурино мытищи выкрасть path\n"
        "ам_ам(омайгад(path).__name__)\n"
    )
    assert _exec(src).strip() == "module"


def test_yield_generator():
    src = (
        "боровыу гена():\n"
        "    бурмалдить 1\n"
        "    бурмалдить 2\n"
        "ам_ам(боровы(гена()))\n"
    )
    assert _exec(src).strip() == "[1, 2]"


def test_pass():
    src = (
        "боровыу пусто():\n"
        "    нормалдаки\n"
        "ам_ам(пусто())\n"
    )
    assert _exec(src).strip() == "None"


@pytest.mark.parametrize("example", ["hello_world.мелл", "fibonacci.мелл", "calculator.мелл"])
def test_examples_transpile(example):
    src = (EXAMPLES / example).read_text(encoding="utf-8")
    py = transpile(src)
    compile(py, example, "exec")


def test_hello_world_runs():
    src = (EXAMPLES / "hello_world.мелл").read_text(encoding="utf-8")
    out = _exec(src)
    assert "Привет, Мурино!" in out


def test_fibonacci_runs():
    src = (EXAMPLES / "fibonacci.мелл").read_text(encoding="utf-8")
    out = _exec(src)
    assert "0 -> 0" in out
    assert "9 -> 34" in out


def test_calculator_runs():
    src = (EXAMPLES / "calculator.мелл").read_text(encoding="utf-8")
    out = _exec(src)
    assert "итого: 12" in out
    assert "делить на туман нельзя" in out
    assert "после деления: None" in out
