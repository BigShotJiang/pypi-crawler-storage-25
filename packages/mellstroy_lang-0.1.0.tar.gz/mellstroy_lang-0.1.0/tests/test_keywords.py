from mellstroy.keywords import KEYWORDS, REVERSE_KEYWORDS


def test_keywords_are_unique_in_both_directions():
    assert len(set(KEYWORDS.keys())) == len(KEYWORDS)
    assert len(set(KEYWORDS.values())) == len(KEYWORDS)


def test_reverse_is_inverse():
    for k, v in KEYWORDS.items():
        assert REVERSE_KEYWORDS[v] == k


def test_expected_entries_present():
    expected = {
        "боровыу": "def",
        "чекушность": "return",
        "друн": "if",
        "жмурино": "else",
        "самосбор": "for",
        "в_мурино": "in",
        "ам_ам": "print",
        "ч": "self",
        "вкусность": "True",
        "бурмалда": "False",
        "туман": "None",
    }
    for k, v in expected.items():
        assert KEYWORDS[k] == v
