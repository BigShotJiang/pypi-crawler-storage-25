"""
QAMigrate CLI Application.

Main entry point for all QAMigrate commands.
"""

import io
import os
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from qamigrate import __version__
from qamigrate.core.config import get_config


def _ensure_utf8_stdout() -> None:
    """
    Force stdout/stderr to UTF-8 on legacy Windows terminals.

    Python on Windows defaults stdout to cp1252, which can't encode the
    box-drawing and symbol characters Rich emits. This reconfigures the
    streams to UTF-8 before any output happens.
    """
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        # TextIOWrapper.reconfigure is available on Python 3.7+
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:  # pragma: no cover -- best effort
                pass


_ensure_utf8_stdout()


# Initialize Typer app
app = typer.Typer(
    name="qamigrate",
    help="QAMigrate - AI-powered test framework migration.",
    add_completion=False,
    rich_markup_mode="rich",
)

# Console: Rich handles its own fallback when the terminal can't render
# some glyphs, but we still want a clean UTF-8 stream underneath.
console = Console()


def version_callback(value: bool) -> None:
    """Show version and exit."""
    if value:
        console.print(f"[bold blue]QAMigrate[/] version [green]{__version__}[/]")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit.",
            callback=version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """QAMigrate - AI-powered test framework migration."""
    pass


@app.command()
def init(
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    config_file: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            help="Path to configuration file.",
        ),
    ] = None,
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Answer yes to all prompts (auto-inject Playwright + detected test framework deps).",
        ),
    ] = False,
) -> None:
    """
    Initialize QAMigrate in a Selenium project.

    Detects your test framework (TestNG, JUnit 4, JUnit 5, Cucumber BDD)
    and injects the correct Playwright + framework deps into pom.xml /
    build.gradle so compilation validation works out of the box.
    Existing deps, comments, and formatting are preserved.
    """
    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Initializing project...",
            border_style="blue",
        )
    )

    # Check for build files
    pom_xml = project / "pom.xml"
    build_gradle = project / "build.gradle"
    build_gradle_kts = project / "build.gradle.kts"

    if pom_xml.exists():
        build_tool = "maven"
        console.print("[dim]Found pom.xml (Maven project)[/]")
    elif build_gradle.exists():
        build_tool = "gradle"
        console.print("[dim]Found build.gradle (Gradle project)[/]")
    elif build_gradle_kts.exists():
        build_tool = "gradle"
        console.print("[dim]Found build.gradle.kts (Gradle Kotlin DSL)[/]")
    else:
        console.print(
            "[yellow][!][/] No pom.xml or build.gradle found. "
            "Please specify build tool in qamigrate.yaml."
        )
        build_tool = "unknown"

    java_files = list(project.rglob("*.java"))
    test_files = [f for f in java_files if "test" in str(f).lower()]

    # Create qamigrate.yaml if it doesn't exist
    config_path = project / "qamigrate.yaml"
    if not config_path.exists():
        default_config = f"""# QAMigrate Configuration
# Generated for: {project.name}

compiler:
  build_tool: "{build_tool}"
  java_version: "17"

scanner:
  include_patterns:
    - "**/*.java"
  exclude_patterns:
    - "**/target/**"
    - "**/build/**"
    - "**/playwright/**"
"""
        config_path.write_text(default_config)
        console.print(f"[green][OK][/] Created configuration: {config_path.name}")
    else:
        console.print(f"[dim]qamigrate.yaml already exists, leaving as-is[/]")

    # Offer to inject Playwright + test-framework deps.
    # v0.5.13: detect the project's test framework so we inject the right dep.
    if build_tool in ("maven", "gradle"):
        from qamigrate.agents.dependency_injector import (
            DependencyInjector,
            JUNIT_VERSION,
            PLAYWRIGHT_VERSION,
            TESTNG_FALLBACK_VERSION,
        )

        # Detect test framework from the project.
        detected_framework = "junit5"
        detected_version: str | None = None
        detected_pw_version: str | None = None
        try:
            from qamigrate.intelligence import ProjectAnalyzer
            _pmap = ProjectAnalyzer().build(project)
            if _pmap and _pmap.infrastructure:
                fw = (_pmap.infrastructure.test_framework or "").lower()
                if fw in ("testng", "junit4", "junit5"):
                    detected_framework = fw
                detected_version = _pmap.infrastructure.test_framework_version or None
                # Use the project's existing Playwright version if already pinned.
                detected_pw_version = _pmap.infrastructure.playwright_version or None
        except Exception:  # pragma: no cover - best effort
            pass

        effective_pw_version = detected_pw_version or PLAYWRIGHT_VERSION

        # Human-readable dep name for the confirmation message.
        if detected_framework == "testng":
            fw_dep_display = f"org.testng:testng:{detected_version or TESTNG_FALLBACK_VERSION}"
        elif detected_framework == "junit4":
            fw_dep_display = "junit:junit:4.13.2"
        else:
            fw_dep_display = f"org.junit.jupiter:junit-jupyter:{JUNIT_VERSION}"

        should_inject = yes
        if not yes:
            console.print(
                f"\n[bold]Add required dependencies to your build file?[/]\n"
                f"  [cyan]com.microsoft.playwright:playwright:{effective_pw_version}[/]\n"
                f"  [cyan]{fw_dep_display}[/] [dim](detected framework: {detected_framework})[/]\n"
                "[dim]Needed so QAMigrate can compile-check generated code.[/]"
            )
            should_inject = typer.confirm("Add them?", default=True)

        if should_inject:
            injector = DependencyInjector(
                project,
                test_framework=detected_framework,
                test_framework_version=detected_version,
                playwright_version=detected_pw_version,
            )
            result = injector.ensure_playwright_deps(build_tool)
            if result.changed and result.added:
                console.print(f"[green][OK][/] Added to {result.build_file.name}:")
                for dep in result.added:
                    console.print(f"  [dim]+ {dep}[/]")
            elif result.already_present:
                console.print(f"[dim][OK] All deps already present in {result.build_file.name if result.build_file else 'build file'}[/]")
            if result.warning:
                console.print(f"[yellow][!][/] {result.warning}")

    # Display summary
    table = Table(title="Project Summary", show_header=False)
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    table.add_row("Project Path", str(project))
    table.add_row("Build Tool", build_tool.capitalize())
    table.add_row("Total Java Files", str(len(java_files)))
    table.add_row("Test Files", str(len(test_files)))

    console.print(table)
    console.print("\n[bold green][OK] Project initialized![/]")
    console.print("\nNext steps:")
    console.print("  1. Run [cyan]qamigrate scan[/] to analyze your codebase")
    console.print("  2. Run [cyan]qamigrate migrate --all --report ./qa-report[/] to migrate")


@app.command()
def scan(
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            help="Output file for scan results (JSON).",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-V",
            help="Show detailed scan output.",
        ),
    ] = False,
) -> None:
    """
    Scan and analyze a Selenium (or Cucumber BDD) Java codebase.

    Detects Selenium patterns, Cucumber step annotations, and BDD hooks.
    Shows pattern counts, complexity scores, and migration effort estimate.
    """
    from qamigrate.agents.scanner import ScannerAgent

    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Scanning project...",
            border_style="blue",
        )
    )

    config = get_config(project / "qamigrate.yaml")
    scanner = ScannerAgent(config.scanner)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Analyzing source files...", total=None)

        try:
            result = scanner.scan_project(project)
        except Exception as e:
            console.print(f"[red][FAIL] Scan failed: {e}[/]")
            raise typer.Exit(1)

        progress.update(task, description="Generating report...")

    # Display results
    console.print("\n[bold]Scan Results[/]\n")

    # File summary
    table = Table(title="File Analysis")
    table.add_column("Metric", style="cyan")
    table.add_column("Count", style="green", justify="right")
    table.add_row("Total Files Scanned", str(result.file_count))
    table.add_row("Page Objects", str(result.page_object_count))
    table.add_row("Test Classes", str(result.test_class_count))
    console.print(table)

    # Pattern summary
    if result.pattern_summary:
        console.print()
        pattern_table = Table(title="Detected Selenium Patterns")
        pattern_table.add_column("Pattern", style="cyan")
        pattern_table.add_column("Count", style="yellow", justify="right")
        pattern_table.add_column("Complexity", style="magenta", justify="right")

        for pattern_name, count in sorted(
            result.pattern_summary.items(), key=lambda x: x[1], reverse=True
        ):
            pattern_table.add_row(pattern_name, str(count), "*" * min(count // 10 + 1, 5))

        console.print(pattern_table)

    # Complexity distribution
    console.print()
    complexity_table = Table(title="Complexity Distribution")
    complexity_table.add_column("Level", style="cyan")
    complexity_table.add_column("Files", style="green", justify="right")
    complexity_table.add_row("Low (1-3)", str(result.complexity_distribution.get("low", 0)))
    complexity_table.add_row("Medium (4-6)", str(result.complexity_distribution.get("medium", 0)))
    complexity_table.add_row("High (7-10)", str(result.complexity_distribution.get("high", 0)))
    console.print(complexity_table)

    # Save output if requested
    if output:
        import json

        output.write_text(json.dumps(result.to_dict(), indent=2))
        console.print(f"\n[green][OK][/] Results saved to: {output}")

    console.print("\n[bold green][OK] Scan complete![/]")
    console.print(f"\nRun [cyan]qamigrate migrate --all[/] to start migration")


@app.command()
def analyze(
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            help="Directory for the architecture report (HTML + Markdown + JSON).",
        ),
    ] = None,
) -> None:
    """
    Analyze a Selenium project's architecture BEFORE migrating.

    Builds a ProjectMap describing every class, its role (page object,
    utility, base class, listener, ...), the cross-class dependency
    graph, and the conventions the project follows (method chaining,
    logging pattern, driver access style, assertion library, ...).

    Produces a consultant-grade report in three formats at the output
    directory (default: ./qamigrate-report):
        architecture.html   -- standalone, styled, shareable
        architecture.md     -- fits in a PR description
        project-map.json    -- machine-readable for CI / other tools

    Zero LLM calls, zero API cost. The report is what QAMigrate KNOWS
    about your project before writing a single line of Playwright code.
    """
    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Analyzing project...",
            border_style="blue",
        )
    )

    from qamigrate.intelligence import ProjectAnalyzer
    from qamigrate.intelligence.report import write_html, write_json, write_markdown

    output = output or (project / "qamigrate-report")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Building project map...", total=None)
        try:
            pm = ProjectAnalyzer().build(project)
        except Exception as e:
            console.print(f"[red][FAIL] Analysis failed: {e}[/]")
            raise typer.Exit(1)
        progress.update(task, description="Rendering report...")
        html_path = write_html(pm, output / "architecture.html")
        md_path = write_markdown(pm, output / "architecture.md")
        json_path = write_json(pm, output / "project-map.json")

    # One-shot summary to stdout so users see value without opening files.
    console.print()
    summary = Table(show_header=False, box=None, pad_edge=False)
    summary.add_column(style="cyan")
    summary.add_column(style="green")
    summary.add_row("Classes",   str(pm.file_count))
    summary.add_row("Pages",     str(len(pm.page_objects)))
    summary.add_row("Tests",     str(len(pm.test_classes)))
    summary.add_row("Utilities", str(len(pm.utility_classes)))
    summary.add_row("Bases",     str(len(pm.base_classes)))
    summary.add_row("Listeners", str(len(pm.listeners)))
    summary.add_row("Edges",     str(pm.total_edges))
    if pm.infrastructure:
        i = pm.infrastructure
        summary.add_row("Build",    i.build_tool)
        summary.add_row("Tests",    f"{i.test_framework} {i.test_framework_version or ''}".strip())
        if i.selenium_version:
            summary.add_row("Selenium", i.selenium_version)
    console.print(summary)

    # Headline conventions -- the stuff that matters for migration
    c = pm.conventions
    console.print()
    console.print("[bold]Project conventions detected:[/]")
    conventions_table = Table(show_header=False, box=None, pad_edge=False)
    conventions_table.add_column(style="cyan")
    conventions_table.add_column()
    conventions_table.add_row("Method chaining",      "[OK]" if c.method_chaining else "no")
    conventions_table.add_row("Logs every action",    "[OK]" if c.logs_every_action else "no")
    conventions_table.add_row("Logger pattern",       c.logger_call_pattern or "-")
    conventions_table.add_row("Assertion style",      c.assertion_style or "-")
    conventions_table.add_row("Driver access",        c.driver_access or "-")
    conventions_table.add_row("Parallel-safe",        "[OK]" if c.parallel_safe else "no")
    console.print(conventions_table)

    console.print()
    console.print("[bold]Report written:[/]")
    console.print(f"  [dim]HTML:[/]     {html_path}")
    console.print(f"  [dim]Markdown:[/] {md_path}")
    console.print(f"  [dim]JSON:[/]     {json_path}")


@app.command()
def migrate(
    file: Annotated[
        Optional[Path],
        typer.Argument(
            help="Specific Java file to migrate.",
        ),
    ] = None,
    all_files: Annotated[
        bool,
        typer.Option(
            "--all",
            "-a",
            help="Migrate all files in the project.",
        ),
    ] = False,
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Analyze files and preview what would happen without calling the LLM or writing output.",
        ),
    ] = False,
    report: Annotated[
        Optional[Path],
        typer.Option(
            "--report",
            "-r",
            help="Write migration report to this directory (HTML, JSON, and Markdown).",
        ),
    ] = None,
    no_batch_compile: Annotated[
        bool,
        typer.Option(
            "--no-batch-compile",
            help="Fall back to the v0.2 per-file compile loop instead of the "
                 "v0.3+ whole-project compile. Useful for debugging.",
        ),
    ] = False,
    provider: Annotated[
        Optional[str],
        typer.Option(
            "--provider",
            help="LLM provider for BOTH agents (anthropic, openai). "
                 "Shortcut for --coder-provider and --fixer-provider together.",
        ),
    ] = None,
    model: Annotated[
        Optional[str],
        typer.Option(
            "--model",
            help="Model name for BOTH agents (used with --provider). "
                 "Shortcut for --coder-model and --fixer-model together.",
        ),
    ] = None,
    coder_provider: Annotated[
        Optional[str],
        typer.Option(
            "--coder-provider",
            help="LLM provider for the Coder agent (overrides config).",
        ),
    ] = None,
    coder_model: Annotated[
        Optional[str],
        typer.Option(
            "--coder-model",
            help="Model for the Coder agent (overrides config).",
        ),
    ] = None,
    fixer_provider: Annotated[
        Optional[str],
        typer.Option(
            "--fixer-provider",
            help="LLM provider for the Fixer agent (overrides config).",
        ),
    ] = None,
    fixer_model: Annotated[
        Optional[str],
        typer.Option(
            "--fixer-model",
            help="Model for the Fixer agent (overrides config).",
        ),
    ] = None,
    confidence_threshold: Annotated[
        Optional[int],
        typer.Option(
            "--confidence-threshold",
            help="Fail the run (exit code 2) when any file's confidence "
                 "score falls below this value (0-100). Opt-in; no default. "
                 "Use in CI to gate merges on migration quality.",
            min=0,
            max=100,
        ),
    ] = None,
    confidence_mode: Annotated[
        str,
        typer.Option(
            "--confidence-mode",
            help="How --confidence-threshold applies: 'any' (default; any "
                 "single file below threshold fails the run) or 'avg' "
                 "(only the project average must be at or above threshold).",
        ),
    ] = "any",
    exclude: Annotated[
        list[str],
        typer.Option(
            "--exclude",
            help="Exclude files whose path contains this substring (or "
                 "matches the glob, if the pattern contains * or ?). "
                 "Repeatable: --exclude subproj-a --exclude subproj-c. "
                 "Substring form is recommended — no shell-quoting "
                 "headaches. Glob form (e.g. 'tests/**/*.java') still "
                 "supported when you need it.",
        ),
    ] = [],
    ignore_source_errors: Annotated[
        bool,
        typer.Option(
            "--ignore-source-errors",
            help="Migrate even if `mvn compile` fails on the source "
                 "Selenium project. By default, QAMigrate refuses to run "
                 "when the source has compile errors — it is a "
                 "translation tool, not a debugger, so migrating broken "
                 "source produces broken output. Use this flag when you "
                 "understand the migration will inherit those errors.",
        ),
    ] = False,
) -> None:
    """
    Migrate Selenium Java test files to Playwright Java.

    Supports plain Selenium projects AND Cucumber BDD projects.
    Detects and preserves your test framework: TestNG, JUnit 4, or JUnit 5.
    For Cucumber projects: feature files, step annotations, hooks, and the
    runner class are kept unchanged — only the WebDriver API is replaced.

    Use --all to migrate the entire project (recommended).
    Use --dry-run to preview patterns without calling the LLM.
    Use --report <dir> for HTML/JSON/Markdown report + review.md checklist.
    Use --provider / --model to select the LLM without editing qamigrate.yaml.
    """
    if not file and not all_files:
        console.print("[red]X Please specify a file or use --all[/]")
        raise typer.Exit(1)

    from qamigrate.agents.pipeline import (
        run_migration,
        run_project_migration,
    )
    from qamigrate.agents.scanner import ScannerAgent
    from qamigrate.core.report import MigrationRecord, MigrationReport, PatternSummary
    import time

    config = get_config(project / "qamigrate.yaml")
    if no_batch_compile:
        config.pipeline.batch_compile = False

    # Apply provider / model overrides from CLI flags.
    # Per-agent flags (--coder-provider) take precedence over the shared
    # --provider shortcut.
    effective_coder_provider = coder_provider or provider
    effective_coder_model = coder_model or model
    effective_fixer_provider = fixer_provider or provider
    effective_fixer_model = fixer_model or model

    if effective_coder_provider:
        config.coder.provider = effective_coder_provider
    if effective_coder_model:
        config.coder.model = effective_coder_model
    if effective_fixer_provider:
        config.fixer.provider = effective_fixer_provider
    if effective_fixer_model:
        config.fixer.model = effective_fixer_model

    # Collect files
    if all_files:
        # Walk every .java file under the project, then filter out anything
        # inside build output, generated output, or dependency folders.
        exclusions = (
            "target",          # Maven output
            "build",           # Gradle output
            "node_modules",
            "playwright",      # QAMigrate's own output dir
            "qamigrate-output",
            ".git",
            ".venv",
            ".idea",
        )
        # --exclude: dual-mode pattern matching.
        #
        # v0.6.7: each pattern is treated as a SUBSTRING match if it contains
        # no glob metacharacters (`*` or `?`), and as an fnmatch glob if it
        # does. This makes the common case work without any shell-quoting
        # surprises:
        #
        #   --exclude anotherSampleProject       → exclude any path containing
        #                                           "anotherSampleProject"
        #   --exclude 'subproj-b/**'              → glob form (still supported)
        #   --exclude src/test/java/Foo.java      → substring match (also works)
        #
        # The substring path is failure-resistant: shells that don't quote
        # `*` correctly never get a chance to expand it because there's no
        # `*` in the pattern at all. Recommended for monorepo sub-project
        # exclusion.
        #
        # Both pattern and candidate path are normalized to forward slashes
        # so Windows backslashes work the same as POSIX paths.
        from fnmatch import fnmatch

        def _normalize(s: str) -> str:
            return s.replace("\\", "/")

        exclude_patterns = [_normalize(p) for p in exclude]

        def _is_user_excluded(p: Path) -> bool:
            if not exclude_patterns:
                return False
            try:
                rel = p.resolve().relative_to(project).as_posix()
            except ValueError:
                # File outside the project root — keep it (caller asked for it).
                return False
            for pat in exclude_patterns:
                # Glob form (contains * or ?) — use fnmatch.
                if "*" in pat or "?" in pat:
                    if fnmatch(rel, pat):
                        return True
                # Substring form — match anywhere in the relative path.
                # Also match against any individual path segment so
                # `--exclude subproj-a` matches `subproj-a/src/x.java`.
                else:
                    if pat in rel:
                        return True
            return False

        java_files = sorted(
            {
                f.resolve()
                for f in project.rglob("*.java")
                if not any(part in exclusions for part in f.parts)
                and not _is_user_excluded(f)
            }
        )
        # Sort for deterministic ordering: page objects / base classes first,
        # helpers in the middle, actual @Test classes last. This matters
        # because later files can reference earlier ones.
        def _sort_key(p: Path) -> tuple[int, str]:
            s = str(p).lower()
            if "basepage" in s or "basetest" in s:
                rank = 0
            elif "/pages/" in s.replace("\\", "/"):
                rank = 1
            elif "/core/" in s.replace("\\", "/") or "/utils/" in s.replace("\\", "/"):
                rank = 2
            elif "/test/" in s.replace("\\", "/") or s.endswith("test.java") or s.endswith("tests.java"):
                rank = 3
            else:
                rank = 2
            return (rank, s)

        java_files = sorted(java_files, key=_sort_key)

        if not java_files:
            console.print("[red][FAIL] No .java files found under this project.[/]")
            raise typer.Exit(1)
    else:
        java_files = [file] if file else []

    banner = "[bold blue]QAMigrate[/] - " + ("Dry run" if dry_run else "Migrating") + f" {len(java_files)} file(s)"
    console.print(Panel.fit(banner, border_style="blue"))

    migration_report = MigrationReport()
    start_time = time.time()

    if dry_run:
        # Dry run: scan-only, show what WOULD happen per file
        scanner = ScannerAgent(config.scanner)
        for java_file in java_files:
            file_start = time.time()
            try:
                analysis = scanner.scan_file(java_file)
                pattern_counts: dict[str, tuple[int, str]] = {}
                for p in analysis.patterns:
                    if p.pattern_type in pattern_counts:
                        pattern_counts[p.pattern_type] = (
                            pattern_counts[p.pattern_type][0] + 1,
                            p.migration_strategy,
                        )
                    else:
                        pattern_counts[p.pattern_type] = (1, p.migration_strategy)

                patterns = [
                    PatternSummary(pattern_type=ptype, count=count, migration_strategy=strategy)
                    for ptype, (count, strategy) in pattern_counts.items()
                ]
                record = MigrationRecord(
                    source_path=str(java_file),
                    output_path=None,
                    success=True,
                    duration_seconds=round(time.time() - file_start, 2),
                    patterns=patterns,
                    compilation_attempts=0,
                    compiled=None,
                    original_lines=len(java_file.read_text(encoding="utf-8").splitlines()),
                )
                migration_report.add(record)

                total_patterns = sum(p.count for p in patterns)
                console.print(
                    f"[cyan]?[/] [bold]{java_file.name}[/] "
                    f"[dim]({total_patterns} patterns, complexity {analysis.complexity_score}/10)[/]"
                )
                for ptype, (count, _) in list(pattern_counts.items())[:5]:
                    console.print(f"    [dim]* {ptype} x {count}[/]")
                if len(pattern_counts) > 5:
                    console.print(f"    [dim]... and {len(pattern_counts) - 5} more[/]")
            except Exception as e:
                console.print(f"  [red]X[/] {java_file.name}: {e}")
    elif all_files and config.pipeline.batch_compile:
        # v0.3+ project-level pipeline: generate all files first, then
        # batch-compile them together with the resolved classpath, then
        # fix errors per file. This is the default for --all.
        def _on_gen(i: int, total: int, gen) -> None:
            status = "[green]OK[/]" if gen.success else "[red]FAIL[/]"
            console.print(
                f"[cyan]->[/] [{i}/{total}] {gen.source_path.name}  "
                f"{status}  [dim]{gen.duration_seconds:.1f}s[/]"
            )
            if not gen.success and gen.error:
                console.print(f"       [red]{gen.error[:100]}[/]")

        def _on_compile(iteration: int, errors: int, file_count: int) -> None:
            if errors == 0:
                console.print(f"[bold green]Project compile OK[/] [dim](iteration {iteration}, {file_count} files)[/]")
            else:
                console.print(
                    f"[yellow]Project compile iteration {iteration}:[/] "
                    f"{errors} error(s) across {file_count} files"
                )

        console.print()
        console.print("[bold]Phase 1: generating all files[/]")
        # v0.5.19: catch hard usage-cap aborts and exit with a clear message
        # instead of a stack trace + N spurious per-file FAILs.
        # v0.7: also catch SourceProjectNotCompilable from the new
        # pre-flight gate so users get an actionable diagnosis when their
        # Selenium source itself doesn't compile.
        from qamigrate.agents.pipeline import SourceProjectNotCompilable
        from qamigrate.llm.errors import LLMUsageCapExhausted
        try:
            pr = run_project_migration(
                files=java_files,
                project_path=project,
                config=config,
                on_generation=_on_gen,
                on_compile=_on_compile,
                ignore_source_errors=ignore_source_errors,
            )
        except SourceProjectNotCompilable as exc:
            console.print()
            console.print(
                "[bold red]Pre-flight check failed: source project does not compile.[/]"
            )
            console.print(
                f"[yellow]Source `mvn compile` reported {exc.error_count} error(s)."
                "[/]\n"
            )
            # Show a sample of errors so the user can see what's broken.
            for err in exc.errors[:5]:
                file_short = (
                    str(err.file_path).replace("\\", "/").rsplit("/", 1)[-1]
                    if err.file_path else "?"
                )
                console.print(
                    f"  [dim]{file_short}:{err.line_number}[/]  {err.message}"
                )
            if exc.error_count > 5:
                console.print(f"  [dim]... and {exc.error_count - 5} more[/]")
            console.print(
                "\n[bold]Why this matters[/]\n"
                "QAMigrate is a translation tool, not a debugger. It "
                "guarantees that valid Selenium Java patterns become valid "
                "Playwright Java patterns. It cannot fix logic bugs in your "
                "source — migrating broken source produces broken output.\n"
            )
            console.print(
                "[bold]Options[/]\n"
                "  1. Fix the errors above and re-run.\n"
                "  2. Re-run with [bold]--ignore-source-errors[/] to migrate "
                "anyway.\n"
                "     The migrated output will inherit these errors. "
                "QAMigrate's report\n"
                "     will distinguish 'caused by QAMigrate' from "
                "'inherited from source'."
            )
            raise typer.Exit(code=3) from exc
        except LLMUsageCapExhausted as exc:
            console.print()
            console.print(
                "[bold red]ABORTED — provider usage cap exhausted.[/]"
            )
            console.print(f"[yellow]Provider message:[/] {exc}")
            console.print(
                "[dim]Retrying now would just burn more budget on calls that "
                "are guaranteed to fail. Wait until your quota resets, then "
                "rerun. Files already migrated have been written to disk.[/]"
            )
            raise typer.Exit(code=2) from exc

        for rec in pr.records:
            migration_report.add(rec)

        if pr.classpath_reason:
            console.print(
                f"\n[yellow]Compile-check skipped:[/] [dim]{pr.classpath_reason}[/]"
            )
    else:
        # Single file, or --no-batch-compile. Use the v0.2 per-file loop.
        sibling_signatures: dict[str, list[str]] = {}
        for i, java_file in enumerate(java_files, start=1):
            console.print(f"[cyan]->[/] [{i}/{len(java_files)}] {java_file.name}")
            try:
                result = run_migration(
                    file_path=java_file,
                    project_path=project,
                    config=config,
                    sibling_signatures=sibling_signatures or None,
                )
                if result.record:
                    migration_report.add(result.record)
                if result.class_name and result.generated_signatures:
                    sibling_signatures[result.class_name] = result.generated_signatures

                if result.success:
                    console.print(
                        f"   [green]OK[/] {result.output_path} "
                        f"[dim]({result.record.duration_seconds:.1f}s, {result.record.confidence}% confidence)[/]"
                        if result.record
                        else f"   [green]OK[/] {result.output_path}"
                    )
                else:
                    console.print(f"   [red]FAIL[/] {result.error}")
            except Exception as e:
                console.print(f"   [red]ERROR[/] {e}")

    migration_report.finish()
    total_time = time.time() - start_time

    # Summary
    console.print()
    summary = Table(show_header=False, box=None, pad_edge=False)
    summary.add_column(style="cyan")
    summary.add_column(style="green" if migration_report.failed_count == 0 else "white")
    summary.add_row("Files", f"{migration_report.success_count} / {migration_report.total_files}")
    summary.add_row("Patterns handled", str(migration_report.total_patterns))
    if not dry_run:
        summary.add_row("Avg confidence", f"{migration_report.average_confidence}%")
    total_halluc = sum(len(r.hallucinations) for r in migration_report.records)
    if total_halluc:
        summary.add_row("Hallucinations", str(total_halluc))
    summary.add_row("Time", f"{total_time:.1f}s")
    summary.add_row("Est. hours saved", f"~{migration_report.estimated_hours_saved}")
    console.print(summary)

    # Surface hints for failure patterns the user can act on quickly.
    if not dry_run:
        skipped_classpath = [
            r for r in migration_report.records
            if r.compiled is None and r.success
        ]
        if skipped_classpath and len(skipped_classpath) == migration_report.total_files:
            console.print()
            console.print(
                "[yellow]Note:[/] Compilation validation was skipped because "
                "Playwright wasn't on the classpath.\n"
                "[dim]Add Playwright to your pom.xml/build.gradle to enable "
                "compile-check and the iterative fixer:[/]\n"
                "[dim]  <dependency>\n"
                "    <groupId>com.microsoft.playwright</groupId>\n"
                "    <artifactId>playwright</artifactId>\n"
                "    <version>1.48.0</version>\n"
                "  </dependency>[/]"
            )
        if total_halluc:
            console.print()
            console.print(
                f"[yellow]Note:[/] Detected {total_halluc} potential method "
                "hallucination(s) across generated files. These call methods "
                "that don't exist on migrated sibling classes and will likely "
                "cause compile errors. See the report for details."
            )

    # Write report if requested
    if report:
        report.mkdir(parents=True, exist_ok=True)
        html_path = migration_report.write_html(report / "report.html")
        json_path = migration_report.write_json(report / "report.json")
        md_path = migration_report.write_markdown(report / "report.md")
        review_path = migration_report.write_review_markdown(report / "review.md")
        console.print()
        console.print("[bold]Report written:[/]")
        console.print(f"  [dim]HTML:[/]     {html_path}")
        console.print(f"  [dim]JSON:[/]     {json_path}")
        console.print(f"  [dim]Markdown:[/] {md_path}")
        console.print(f"  [dim]Review:[/]   {review_path}")

    # v0.5.2(c): confidence gate. Evaluated BEFORE the failed_count check so
    # it fires even when some files failed generation. Exit code 2 is distinct
    # from exit code 1 (generation failure) so CI scripts can react differently
    # to "quality bar not met" vs "tool broke". Both checks run independently.
    if confidence_threshold is not None and not dry_run:
        from qamigrate.core.confidence_gate import evaluate_confidence_gate

        gate = evaluate_confidence_gate(
            migration_report, threshold=confidence_threshold, mode=confidence_mode,
        )
        if gate.error:
            console.print(f"[red]X {gate.error}[/]")
            raise typer.Exit(1)
        if not gate.passed:
            console.print()
            console.print(f"[red]X Confidence gate failed:[/] {gate.message}")
            for r in gate.offending_records:
                console.print(
                    f"  [yellow]-[/] {r.source_path} [dim]({r.confidence}%)[/]"
                )
            console.print()
            console.print(
                "[dim]CI tip: check exit code with [cyan]echo %ERRORLEVEL%[/] "
                "(cmd) or [cyan]echo $LASTEXITCODE[/] (PowerShell). "
                "$? in PowerShell is a bool, not the exit code.[/]"
            )
            # Belt-and-suspenders: Typer's Exit works in most environments.
            # os._exit(2) fires if Typer's exception is caught somewhere above
            # us (can happen in Windows .exe wrappers or certain CI runners).
            try:
                raise typer.Exit(code=2)
            except SystemExit:
                os._exit(2)

    if migration_report.failed_count > 0:
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
