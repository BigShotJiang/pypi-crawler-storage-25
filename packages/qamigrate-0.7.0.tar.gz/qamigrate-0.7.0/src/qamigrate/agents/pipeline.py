"""
Migration Pipeline.

Plain Python pipeline that runs the migration workflow:
Scanner -> Coder -> Compiler -> Fixer (retry loop) -> Done.

Replaces the LangGraph-based graph.py with a simple, debuggable flow.
"""

import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

from qamigrate.agents.classpath import ClasspathResolver
from qamigrate.agents.coder import CoderAgent
from qamigrate.agents.compiler import CompilerAgent, CompilerError, ErrorType
from qamigrate.agents.fixer import FixerAgent
from qamigrate.agents.scanner import ScannerAgent
from qamigrate.agents.state import MigrationState, Phase, _utcnow_iso, create_initial_state
from qamigrate.core.config import QAMigrateConfig
from qamigrate.core.hallucination import (
    DeclaredSelectors,
    detect_hallucinations,
    detect_selector_hallucinations,
    extract_declared_selectors,
)
from qamigrate.core.report import Hallucination, MigrationRecord, PatternSummary

logger = structlog.get_logger(__name__)


@dataclass
class MigrationResult:
    """Result of a migration run."""

    success: bool
    file_path: str
    output_path: str | None
    error: str | None
    compilation_attempts: int
    final_state: MigrationState
    record: MigrationRecord | None = None
    # Signatures of public methods / constructor of the generated class.
    # Callers can pass these as `sibling_signatures` when migrating later
    # files so dependent classes call real methods instead of invented ones.
    class_name: str | None = None
    generated_signatures: list[str] = field(default_factory=list)


def run_migration(
    file_path: Path,
    project_path: Path,
    config: QAMigrateConfig | None = None,
    on_phase: Callable[[Phase, MigrationState], None] | None = None,
    sibling_signatures: dict[str, list[str]] | None = None,
) -> MigrationResult:
    """
    Run the migration pipeline for a single file.

    Pipeline: Scanner -> Coder -> Compiler -> (Fixer -> Compiler)* -> Done

    Args:
        file_path: Path to the Java file to migrate
        project_path: Root path of the project
        config: Optional configuration
        on_phase: Optional callback fired on each phase transition

    Returns:
        MigrationResult with outcome
    """
    config = config or QAMigrateConfig()
    max_retries = config.pipeline.max_retries
    started = time.time()

    # v0.5.1: passthrough path for files with no Selenium markers (enums,
    # pure-data classes). Copy them verbatim instead of pushing them
    # through the LLM where the tool schema mangles them.
    from qamigrate.intelligence.passthrough import (
        is_passthrough,
        rewrite_package_for_passthrough,
    )

    passthrough, reason = is_passthrough(file_path)
    if passthrough:
        try:
            original_code = file_path.read_text(encoding="utf-8")
            # v0.5.4: rewrite `package X;` → `package X.playwright;` so
            # the copied file doesn't collide with the original Selenium
            # class in Maven's joint compilation.
            output_code = rewrite_package_for_passthrough(original_code)
            output_path = file_path.parent / "playwright" / file_path.name
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(output_code, encoding="utf-8")
            logger.info(
                "Pipeline: passthrough",
                file=str(file_path),
                reason=reason,
            )
            state = create_initial_state(
                file_path=str(file_path),
                project_path=str(project_path),
            )
            state["phase"] = Phase.COMPLETE
            record = MigrationRecord(
                source_path=str(file_path),
                output_path=str(output_path),
                success=True,
                duration_seconds=round(time.time() - started, 2),
                patterns=[],
                compilation_attempts=0,
                compiled=None,
                original_lines=len(original_code.splitlines()),
                generated_lines=len(output_code.splitlines()),
                error=None,
                original_code=original_code,
                generated_code=output_code,
            )
            return MigrationResult(
                success=True,
                file_path=str(file_path),
                output_path=str(output_path),
                error=None,
                compilation_attempts=0,
                final_state=state,
                record=record,
            )
        except OSError as e:  # pragma: no cover
            logger.warning(
                "Pipeline: passthrough failed, falling through to LLM",
                file=str(file_path),
                error=str(e),
            )

    # Build LLM providers from config so each agent uses whatever provider
    # the user selected (Anthropic, OpenAI, Ollama, ...).
    from qamigrate.llm.from_config import build_provider_for_agent

    coder_provider = build_provider_for_agent(config, "coder")
    fixer_provider = build_provider_for_agent(config, "fixer")

    # Initialize agents
    scanner = ScannerAgent(config.scanner)
    coder = CoderAgent(config.coder, llm_provider=coder_provider)
    compiler = CompilerAgent(config.compiler)
    fixer = FixerAgent(config.fixer, llm_provider=fixer_provider)

    # Create initial state
    state = create_initial_state(
        file_path=str(file_path),
        project_path=str(project_path),
    )

    def _notify(phase: Phase) -> None:
        state["phase"] = phase
        state["updated_at"] = _utcnow_iso()
        if on_phase:
            on_phase(phase, state)

    def _build_record(
        success: bool,
        output_path_str: str | None,
        error: str | None,
        compiled: bool | None,
        attempts: int,
    ) -> MigrationRecord:
        """Build a MigrationRecord from current state."""
        pattern_counts: dict[str, tuple[int, str]] = {}
        for p in state.get("patterns", []):
            ptype = p.get("pattern_type", "unknown")
            strategy = p.get("migration_strategy", "")
            if ptype in pattern_counts:
                pattern_counts[ptype] = (pattern_counts[ptype][0] + 1, strategy)
            else:
                pattern_counts[ptype] = (1, strategy)

        patterns = [
            PatternSummary(pattern_type=ptype, count=count, migration_strategy=strat)
            for ptype, (count, strat) in pattern_counts.items()
        ]

        original_code = state.get("original_code", "") or ""
        generated_code = state.get("generated_code", "") or ""

        # Check for cross-file hallucinations (calls to methods that don't
        # exist on already-migrated sibling classes).
        hallucinations: list[Hallucination] = []
        if sibling_signatures and generated_code:
            hallucinations = detect_hallucinations(generated_code, sibling_signatures)
            if hallucinations:
                logger.warning(
                    "Pipeline: detected cross-file hallucinations",
                    count=len(hallucinations),
                    file=str(file_path),
                    details=[h.called_method for h in hallucinations],
                )

        return MigrationRecord(
            source_path=str(file_path),
            output_path=output_path_str,
            success=success,
            duration_seconds=round(time.time() - started, 2),
            patterns=patterns,
            compilation_attempts=attempts,
            compiled=compiled,
            original_lines=len(original_code.splitlines()),
            generated_lines=len(generated_code.splitlines()),
            error=error,
            original_code=original_code,
            generated_code=generated_code,
            hallucinations=hallucinations,
        )

    try:
        # --- SCAN ---
        logger.info("Pipeline: scanning", file=str(file_path))
        _notify(Phase.INIT)

        analysis = scanner.scan_file(file_path)
        state["ast_data"] = analysis.class_info
        state["patterns"] = [
            {
                "pattern_type": p.pattern_type,
                "line_number": p.line_number,
                "migration_strategy": p.migration_strategy,
            }
            for p in analysis.patterns
        ]
        state["complexity_score"] = analysis.complexity_score
        state["original_code"] = file_path.read_text(encoding="utf-8")
        _notify(Phase.SCANNED)

        # --- GENERATE ---
        logger.info("Pipeline: generating Playwright code", file=str(file_path))

        result = coder.generate_from_class_info(
            class_info=state["ast_data"] or {},
            original_code=state["original_code"],
            patterns=state["patterns"],
            sibling_signatures=sibling_signatures,
        )
        generated_code = coder.assemble_file(result)
        generated_class_name = result.class_declaration.strip().split()[-1].rstrip("{").strip()
        generated_signatures = CoderAgent.extract_signatures(result)

        output_path = file_path.parent / "playwright" / file_path.name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(generated_code, encoding="utf-8")

        state["generated_code"] = generated_code
        state["generated_file_path"] = str(output_path)
        state["output_path"] = str(output_path)
        _notify(Phase.GENERATED)

        # --- SKIP COMPILATION IF CONFIGURED ---
        if config.compiler.skip:
            logger.info(
                "Pipeline: compilation skipped (compiler.skip=true)",
                file=str(file_path),
                output=str(output_path),
            )
            _notify(Phase.COMPILED)
            return MigrationResult(
                success=True,
                file_path=str(file_path),
                output_path=str(output_path),
                error=None,
                compilation_attempts=0,
                final_state=state,
                record=_build_record(
                    success=True,
                    output_path_str=str(output_path),
                    error=None,
                    compiled=None,
                    attempts=0,
                ),
                class_name=generated_class_name,
                generated_signatures=generated_signatures,
            )

        # --- COMPILE + FIX LOOP (non-regressing) ---
        # We keep the "best" version seen so far (fewest errors). A fix is
        # only accepted if it strictly reduces the error count. If the fixer
        # makes things worse, we roll back and try a different error the
        # next iteration. Bail out early if we can't make progress.
        best_code: str = state["generated_code"] or ""
        best_error_count: int | None = None
        no_progress_count = 0

        def _looks_like_classpath_issue(compile_result: Any) -> bool:
            """
            Detect 'package com.microsoft.playwright does not exist' and the
            downstream 'cannot find symbol' errors for Playwright types that
            follow. Trying to "fix" these with the LLM is hopeless -- the
            generated code is fine, we just have no Playwright JAR on the
            compile classpath.
            """
            if not compile_result.errors:
                return False

            # Known Playwright type names that show up in "cannot find symbol"
            # when the JAR is missing.
            playwright_types = {
                "Page", "Locator", "Browser", "BrowserContext", "BrowserType",
                "Playwright", "PlaywrightAssertions", "AriaRole", "SelectOption",
                "FileChooser", "Dialog", "Download", "Frame", "ElementHandle",
                "JSHandle", "Route", "Request", "Response", "TimeoutError",
            }

            classpath_errors = 0
            has_playwright_package_missing = False
            for e in compile_result.errors:
                # javac puts the real detail ("symbol: class Locator") in a
                # multi-line context block following the top-level "cannot
                # find symbol" message, so we need to check both fields.
                full_text = f"{e.message}\n{e.code_context or ''}"
                if "com.microsoft.playwright" in full_text and "does not exist" in full_text:
                    classpath_errors += 1
                    has_playwright_package_missing = True
                elif "cannot find symbol" in full_text.lower():
                    if any(f"class {t}" in full_text or f"symbol: {t}" in full_text
                           for t in playwright_types):
                        classpath_errors += 1
                    elif "class BasePage" in full_text or "class BaseTest" in full_text:
                        # Cross-file base classes under migration -- same root cause.
                        classpath_errors += 1

            # Require at least one explicit "package does not exist" and that
            # the classpath-looking errors are the majority -- otherwise we
            # might be masking real code bugs.
            if not has_playwright_package_missing:
                return False
            return classpath_errors * 2 >= len(compile_result.errors)

        for attempt in range(max_retries + 1):
            logger.info(
                "Pipeline: compiling",
                file=str(output_path),
                attempt=attempt + 1,
            )

            compile_result = compiler.compile_single_file(output_path)
            current_error_count = len(compile_result.errors)

            # Detect the "user hasn't added Playwright to their pom.xml yet"
            # case on the first attempt. Bailing here avoids burning API calls
            # on a classpath problem the LLM can't solve.
            if attempt == 0 and _looks_like_classpath_issue(compile_result):
                logger.warning(
                    "Pipeline: classpath issue detected "
                    "(Playwright JAR not on the compile classpath). "
                    "Generated code looks correct; skipping compilation check.",
                    file=str(file_path),
                )
                state["compilation_result"] = compile_result.to_dict()
                state["compilation_errors"] = []
                state["retry_count"] = 0
                _notify(Phase.COMPILED)
                return MigrationResult(
                    success=True,
                    file_path=str(file_path),
                    output_path=str(output_path),
                    error=None,
                    compilation_attempts=0,
                    final_state=state,
                    record=_build_record(
                        success=True,
                        output_path_str=str(output_path),
                        error=None,
                        compiled=None,  # None = skipped, not False = failed
                        attempts=0,
                    ),
                    class_name=generated_class_name,
                    generated_signatures=generated_signatures,
                )

            if compile_result.success:
                state["compilation_result"] = compile_result.to_dict()
                state["compilation_errors"] = []
                state["retry_count"] = attempt
                _notify(Phase.COMPILED)
                break

            # Compilation failed. Check if this version is better than the
            # best we've seen. If it's worse, roll back to best and log it.
            if best_error_count is None or current_error_count < best_error_count:
                best_code = output_path.read_text(encoding="utf-8")
                best_error_count = current_error_count
                no_progress_count = 0
            else:
                # This attempt was the same or worse than the last best.
                logger.warning(
                    "Pipeline: fix did not reduce errors; rolling back",
                    current_errors=current_error_count,
                    best_errors=best_error_count,
                )
                output_path.write_text(best_code, encoding="utf-8")
                state["generated_code"] = best_code
                no_progress_count += 1
                # Re-run compile on the rolled-back code so our error list
                # reflects the actual current state.
                compile_result = compiler.compile_single_file(output_path)
                current_error_count = len(compile_result.errors)

            state["compilation_result"] = compile_result.to_dict()
            state["compilation_errors"] = [e.to_dict() for e in compile_result.errors]
            state["retry_count"] = attempt + 1
            _notify(Phase.COMPILATION_FAILED)

            # Stop early if we've had two consecutive non-improvements.
            # Banging the LLM against the same code is expensive and
            # usually fruitless.
            if no_progress_count >= 2:
                logger.warning(
                    "Pipeline: no progress for 2 consecutive attempts; stopping early",
                    best_errors=best_error_count,
                )
                output_path.write_text(best_code, encoding="utf-8")
                state["generated_code"] = best_code
                _notify(Phase.FAILED)
                return MigrationResult(
                    success=False,
                    file_path=str(file_path),
                    output_path=str(output_path),
                    error=(
                        f"Compilation failed with {best_error_count} error(s); "
                        f"fixer could not make further progress after {attempt + 1} attempts"
                    ),
                    compilation_attempts=attempt + 1,
                    final_state=state,
                    record=_build_record(
                        success=False,
                        output_path_str=str(output_path),
                        error=(
                            f"Compilation failed with {best_error_count} error(s) "
                            "after the fixer stopped making progress"
                        ),
                        compiled=False,
                        attempts=attempt + 1,
                    ),
                    class_name=generated_class_name,
                    generated_signatures=generated_signatures,
                )

            if attempt >= max_retries:
                logger.warning(
                    "Pipeline: max retries reached",
                    file=str(file_path),
                    attempts=attempt + 1,
                    best_errors=best_error_count,
                )
                output_path.write_text(best_code, encoding="utf-8")
                state["generated_code"] = best_code
                _notify(Phase.FAILED)
                return MigrationResult(
                    success=False,
                    file_path=str(file_path),
                    output_path=str(output_path),
                    error=f"Compilation failed with {best_error_count} error(s) after {attempt + 1} attempts",
                    compilation_attempts=attempt + 1,
                    final_state=state,
                    record=_build_record(
                        success=False,
                        output_path_str=str(output_path),
                        error=f"Compilation failed with {best_error_count} error(s) after {attempt + 1} attempts",
                        compiled=False,
                        attempts=attempt + 1,
                    ),
                    class_name=generated_class_name,
                    generated_signatures=generated_signatures,
                )

            # --- FIX ---
            logger.info(
                "Pipeline: fixing errors",
                error_count=current_error_count,
                attempt=attempt + 1,
            )

            errors = []
            for e in state.get("compilation_errors", []):
                error_type_str = e.get("error_type", "unknown")
                try:
                    error_type = ErrorType(error_type_str)
                except ValueError:
                    error_type = ErrorType.UNKNOWN

                errors.append(CompilerError(
                    file_path=e["file_path"],
                    line_number=e["line_number"],
                    column=e["column"],
                    error_type=error_type,
                    message=e["message"],
                    code_context=e.get("code_context", ""),
                ))

            fixed_code, changes = fixer.fix(
                code=best_code,  # always fix from the best version, not drifted
                errors=errors,
                retry_count=attempt,
            )

            # If the fixer returned the same code, we're stuck -- count this
            # as no-progress so we bail out faster.
            if fixed_code == best_code:
                no_progress_count += 1

            output_path.write_text(fixed_code, encoding="utf-8")
            state["generated_code"] = fixed_code
            state["fix_changes"] = state.get("fix_changes", []) + changes
            _notify(Phase.FIXED)

        # If we got here via break (compilation succeeded)
        if state["phase"] == Phase.COMPILED:
            attempts = state.get("retry_count", 0)
            logger.info(
                "Pipeline: migration successful",
                file=str(file_path),
                output=str(output_path),
                attempts=attempts + 1,
            )
            return MigrationResult(
                success=True,
                file_path=str(file_path),
                output_path=str(output_path),
                error=None,
                compilation_attempts=attempts,
                final_state=state,
                record=_build_record(
                    success=True,
                    output_path_str=str(output_path),
                    error=None,
                    compiled=True,
                    attempts=attempts,
                ),
                class_name=generated_class_name,
                generated_signatures=generated_signatures,
            )

        # Should not reach here, but handle gracefully
        return MigrationResult(
            success=False,
            file_path=str(file_path),
            output_path=state.get("output_path"),
            error="Pipeline ended in unexpected state",
            compilation_attempts=state.get("retry_count", 0),
            final_state=state,
            record=_build_record(
                success=False,
                output_path_str=state.get("output_path"),
                error="Pipeline ended in unexpected state",
                compiled=None,
                attempts=state.get("retry_count", 0),
            ),
        )

    except Exception as e:
        logger.error("Pipeline: migration failed", error=str(e), file=str(file_path))
        state["phase"] = Phase.FAILED
        state["errors"].append({
            "phase": state.get("phase", Phase.INIT).value if isinstance(state.get("phase"), Phase) else "init",
            "error_type": type(e).__name__,
            "message": str(e),
            "timestamp": _utcnow_iso(),
        })
        return MigrationResult(
            success=False,
            file_path=str(file_path),
            output_path=state.get("output_path"),
            error=str(e),
            compilation_attempts=state.get("retry_count", 0),
            final_state=state,
            record=_build_record(
                success=False,
                output_path_str=state.get("output_path"),
                error=str(e),
                compiled=None,
                attempts=state.get("retry_count", 0),
            ),
        )


def run_batch_migration(
    files: list[Path],
    project_path: Path,
    config: QAMigrateConfig | None = None,
    on_progress: Callable[[int, int, MigrationResult], None] | None = None,
) -> list[MigrationResult]:
    """
    Run migration for multiple files.

    Args:
        files: List of Java files to migrate
        project_path: Root path of the project
        config: Optional configuration
        on_progress: Optional callback for progress updates

    Returns:
        List of MigrationResult for each file
    """
    results: list[MigrationResult] = []

    for i, file_path in enumerate(files):
        logger.info(f"Migrating file {i + 1}/{len(files)}", file=str(file_path))

        result = run_migration(file_path, project_path, config)
        results.append(result)

        if on_progress:
            on_progress(i + 1, len(files), result)

    success_count = sum(1 for r in results if r.success)
    logger.info(
        "Batch migration complete",
        total=len(files),
        success=success_count,
        failed=len(files) - success_count,
    )

    return results


# =====================================================================
# Project-level pipeline (v0.3+)
# =====================================================================


@dataclass
class GenerationResult:
    """Outcome of the generation-only phase for a single file."""

    source_path: Path
    output_path: Path | None
    success: bool
    error: str | None
    class_name: str | None
    signatures: list[str]
    analysis_patterns: list[dict[str, Any]]
    original_code: str
    generated_code: str
    duration_seconds: float


def run_generation(
    file_path: Path,
    project_path: Path,
    config: QAMigrateConfig,
    sibling_signatures: dict[str, list[str]] | None = None,
    project_map: "Any" = None,
    target_framework: str = "junit5",
    is_bdd: bool = False,
) -> GenerationResult:
    """
    Scan + generate for a single file. Writes the output to disk but does
    NOT compile or fix. Used as the first phase of `run_project_migration`.

    When `project_map` is supplied (v0.5+), we build a per-file "project
    context" block and pass it to the Coder so generated code preserves
    the project's conventions (method chaining, logging, etc.).
    """
    from qamigrate.intelligence.passthrough import (
        build_signatures_from_class_info,
        is_passthrough,
        rewrite_package_for_passthrough,
    )
    from qamigrate.llm.from_config import build_provider_for_agent

    started = time.time()

    # v0.5.1: passthrough path for files that don't need migration
    # (enums, constants classes without Selenium markers). Skipping the
    # LLM call here eliminates a whole class of hallucinations where a
    # correct enum gets "migrated" into broken Java.
    #
    # v0.5.2(a): Parse the original source so sibling tests that IMPORT
    # this enum see its real constants/methods in their Coder prompt --
    # otherwise the LLM hallucinates `Environment.DEVELOPMENT` instead
    # of the real `Environment.DEV`.
    passthrough, reason = is_passthrough(file_path)
    if passthrough:
        try:
            original_code = file_path.read_text(encoding="utf-8")
            # v0.5.4: rewrite package declaration to .playwright suffix so
            # the copied file doesn't collide with the original in Maven.
            output_code = rewrite_package_for_passthrough(original_code)
            output_path = file_path.parent / "playwright" / file_path.name
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(output_code, encoding="utf-8")

            # Still run the scanner so we can contribute this file's API
            # to sibling_signatures. If scanning fails, degrade gracefully
            # to empty signatures -- passthrough correctness shouldn't
            # depend on parser robustness.
            class_name: str | None = file_path.stem
            signatures: list[str] = []
            try:
                scanner = ScannerAgent(config.scanner)
                analysis = scanner.scan_file(file_path)
                if analysis.class_info.get("class_name"):
                    class_name = analysis.class_info["class_name"]
                signatures = build_signatures_from_class_info(analysis.class_info)
            except Exception as e:  # pragma: no cover - defensive
                logger.debug(
                    "Pipeline: passthrough signature extraction failed",
                    file=str(file_path),
                    error=str(e),
                )

            logger.info(
                "Pipeline: passthrough",
                file=str(file_path),
                reason=reason,
                signatures=len(signatures),
            )
            return GenerationResult(
                source_path=file_path,
                output_path=output_path,
                success=True,
                error=None,
                class_name=class_name,
                signatures=signatures,
                analysis_patterns=[],
                original_code=original_code,
                generated_code=output_code,
                duration_seconds=round(time.time() - started, 2),
            )
        except OSError as e:  # pragma: no cover - defensive
            logger.warning(
                "Pipeline: passthrough failed, falling through to LLM",
                file=str(file_path),
                error=str(e),
            )

    scanner = ScannerAgent(config.scanner)
    coder = CoderAgent(
        config.coder,
        llm_provider=build_provider_for_agent(config, "coder"),
    )

    try:
        analysis = scanner.scan_file(file_path)
        original_code = file_path.read_text(encoding="utf-8")
        patterns_list = [
            {
                "pattern_type": p.pattern_type,
                "line_number": p.line_number,
                "migration_strategy": p.migration_strategy,
            }
            for p in analysis.patterns
        ]

        # v0.5+: build the project-context prompt block for this file
        project_context_text: str | None = None
        if project_map is not None:
            # Work out the fully-qualified name of the class being migrated
            # so we can zoom in on its direct dependencies.
            migrating_fqn = None
            class_name = analysis.class_info.get("class_name")
            pkg = analysis.class_info.get("package") or ""
            if class_name:
                migrating_fqn = f"{pkg}.{class_name}" if pkg else class_name
            from qamigrate.intelligence.prompt_context import format_project_context
            project_context_text = format_project_context(
                project_map, migrating_fqn=migrating_fqn,
            )

        result = coder.generate_from_class_info(
            class_info=analysis.class_info,
            original_code=original_code,
            patterns=patterns_list,
            sibling_signatures=sibling_signatures,
            project_context=project_context_text,
            target_framework=target_framework,
            is_bdd=is_bdd,
        )
        generated_code = coder.assemble_file(result)
        generated_class_name = result.class_declaration.strip().split()[-1].rstrip("{").strip()
        signatures = CoderAgent.extract_signatures(result)

        output_path = file_path.parent / "playwright" / file_path.name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(generated_code, encoding="utf-8")

        return GenerationResult(
            source_path=file_path,
            output_path=output_path,
            success=True,
            error=None,
            class_name=generated_class_name,
            signatures=signatures,
            analysis_patterns=patterns_list,
            original_code=original_code,
            generated_code=generated_code,
            duration_seconds=round(time.time() - started, 2),
        )
    except Exception as e:
        logger.error("run_generation failed", file=str(file_path), error=str(e))
        return GenerationResult(
            source_path=file_path,
            output_path=None,
            success=False,
            error=str(e),
            class_name=None,
            signatures=[],
            analysis_patterns=[],
            original_code="",
            generated_code="",
            duration_seconds=round(time.time() - started, 2),
        )


def _build_record_from_generation(
    gen: GenerationResult,
    *,
    compiled: bool | None,
    attempts: int,
    error: str | None = None,
    hallucinations: list[Hallucination] | None = None,
    caused_error_count: int = 0,
    inherited_error_count: int = 0,
) -> MigrationRecord:
    """Build a MigrationRecord from a GenerationResult + compile outcome.

    v0.7: caused_error_count / inherited_error_count split the file's
    final errors into "QAMigrate's responsibility" vs. "pre-existing
    source bug we faithfully copied". See report.MigrationRecord docstring.
    """
    pattern_counts: dict[str, tuple[int, str]] = {}
    for p in gen.analysis_patterns:
        ptype = p.get("pattern_type", "unknown")
        strategy = p.get("migration_strategy", "")
        count, _ = pattern_counts.get(ptype, (0, strategy))
        pattern_counts[ptype] = (count + 1, strategy)

    patterns = [
        PatternSummary(pattern_type=ptype, count=count, migration_strategy=strat)
        for ptype, (count, strat) in pattern_counts.items()
    ]

    return MigrationRecord(
        source_path=str(gen.source_path),
        output_path=str(gen.output_path) if gen.output_path else None,
        success=(gen.success and (compiled is True or compiled is None)),
        duration_seconds=gen.duration_seconds,
        patterns=patterns,
        compilation_attempts=attempts,
        compiled=compiled,
        original_lines=len(gen.original_code.splitlines()),
        generated_lines=len(gen.generated_code.splitlines()),
        error=error or gen.error,
        original_code=gen.original_code,
        generated_code=gen.generated_code,
        hallucinations=hallucinations or [],
        caused_error_count=caused_error_count,
        inherited_error_count=inherited_error_count,
    )


@dataclass
class ProjectMigrationResult:
    """Aggregate result of a project-level migration."""

    records: list[MigrationRecord]
    classpath_reason: str | None  # Populated when we fell back to skip-compile
    compiled_count: int
    failed_count: int


_PACKAGE_RE = re.compile(r"^\s*package\s+([\w.]+)\s*;", re.MULTILINE)

# Matches a single Java import line, capturing the full qualified name.
# Group 1 = everything before the semicolon (e.g. "com.example.pages.LoginPage").
_IMPORT_LINE_RE = re.compile(r"^(\s*import\s+)([\w.]+)(\s*;)", re.MULTILINE)


def _rewrite_sibling_imports(generations: "list[GenerationResult]") -> dict[str, str]:
    """v0.5.5 Fix #1: rewrite import statements that reference migrated sibling
    classes to use their new `.playwright` package path.

    After migration every class `Foo` in package `com.x.y` moves to
    `com.x.y.playwright.Foo`. Other generated files that import `Foo` still
    carry `import com.x.y.Foo;` from the original source. This makes the
    internal `javac -sourcepath` check AND `mvn compile` both fail with
    `cannot find symbol`.

    We build a map  {simple_class_name: original_package}  from the
    generation results, then scan each generated file's import lines. Any
    import whose trailing simple name matches a migrated class AND whose
    package prefix matches that class's original package is rewritten to
    `import <pkg>.playwright.<Name>;`.

    Only `import` lines are touched -- never method bodies, comments, or
    string literals. The fix is applied in-place on disk and in the
    `GenerationResult.generated_code` field so downstream steps (compile
    check, hallucination detection, report diff) see consistent state.
    """
    # Build the lookup: simple_name -> original_package.
    # We read the original_code (not the generated_code) for the package
    # because the generated code already has the `.playwright` suffix.
    name_to_orig_pkg: dict[str, str] = {}
    for gen in generations:
        if not gen.success or not gen.class_name:
            continue
        m = _PACKAGE_RE.search(gen.original_code)
        if m:
            name_to_orig_pkg[gen.class_name] = m.group(1)

    if not name_to_orig_pkg:
        return name_to_orig_pkg

    # For each generated file, rewrite matching import lines.
    for gen in generations:
        if not gen.success or not gen.output_path:
            continue
        try:
            src = gen.output_path.read_text(encoding="utf-8")
        except OSError:
            continue

        rewritten = _apply_import_rewrite(src, name_to_orig_pkg)
        if rewritten == src:
            continue  # Nothing changed.

        try:
            gen.output_path.write_text(rewritten, encoding="utf-8")
            # Keep in-memory view consistent for the compile/halluc steps.
            gen.generated_code = rewritten
            logger.info(
                "Pipeline: rewrote sibling imports",
                file=str(gen.output_path),
            )
        except OSError as e:
            logger.warning(
                "Pipeline: import rewrite write failed",
                file=str(gen.output_path),
                error=str(e),
            )

    return name_to_orig_pkg


def _apply_import_rewrite(src: str, name_to_orig_pkg: dict[str, str]) -> str:
    """Apply the import rewrite to a single source string.

    Extracted so it can be unit-tested without touching the filesystem.
    """

    def _replace_import(m: re.Match) -> str:
        fq = m.group(2)  # fully-qualified name, e.g. "com.example.pages.LoginPage"
        # Split into (everything-before-last-dot, simple-name)
        dot = fq.rfind(".")
        if dot == -1:
            return m.group(0)  # default package -- leave alone
        pkg, simple = fq[:dot], fq[dot + 1:]
        if simple not in name_to_orig_pkg:
            return m.group(0)  # not a migrated sibling
        orig_pkg = name_to_orig_pkg[simple]
        if pkg != orig_pkg:
            return m.group(0)  # package doesn't match -- leave alone
        # Already has .playwright? Don't double it.
        if pkg.endswith(".playwright"):
            return m.group(0)
        new_fq = f"{pkg}.playwright.{simple}"
        return f"{m.group(1)}{new_fq}{m.group(3)}"

    return _IMPORT_LINE_RE.sub(_replace_import, src)


def _build_class_api_from_project_map(project_map: "Any") -> dict[str, dict] | None:
    """v0.6.6: flatten ProjectMap → {simple_class_name: {api}} for postgen.

    Postgen Fix 17 (constructor-arity guard) and Fix 18 (hallucinated method
    rewrite) need a quick lookup of what every project class actually
    exposes. This helper builds a one-shot dict so postgen doesn't pull in
    the whole ProjectMap dependency.

    Schema:
        {
          "DriverManager": {
            "constructor_arities": {0, 1},
            "method_names": ["getDriver", "quitDriver", ...],
          },
          ...
        }

    Method-name list contains both the source class's method names AND any
    method whose name appears in any source class. The Coder's API
    preservation rule means generated migrated classes expose the same
    public surface as the originals — so the source-side method list is
    the right reference for what callers should call.

    Returns None when ProjectMap is unavailable (postgen falls back to
    pre-v0.6.6 behaviour).
    """
    if project_map is None:
        return None
    classes_map = getattr(project_map, "classes", None)
    if not classes_map:
        return None

    # `classes` is a dict[fqn, ClassInfo]. v0.6.7: include BOTH public and
    # private methods/constructors. The v0.6.6 implementation used only
    # `public_methods`, which silently dropped private constructors (utility
    # classes' lockdown idiom) and any method whose visibility tree-sitter
    # couldn't classify, leaving entire exception classes invisible to
    # Fix 17 / Fix 18.
    api: dict[str, dict] = {}
    for cls in classes_map.values():
        constructor_arities: set[int] = set()
        method_names: list[str] = []
        # v0.7: track full overload signatures per method for Phase 1.9.
        # Schema: {name: [(modifiers, return_type, [(p_type, p_name)]), ...]}
        method_overloads: dict[str, list[tuple]] = {}
        all_methods = list(cls.public_methods or []) + list(
            getattr(cls, "private_methods", None) or []
        )
        for m in all_methods:
            params = m.parameters or []
            if m.is_constructor:
                constructor_arities.add(len(params))
            else:
                method_names.append(m.name)
                method_overloads.setdefault(m.name, []).append((
                    tuple(m.modifiers or ()),
                    m.return_type or "void",
                    tuple((p.type, p.name) for p in params),
                ))
        api[cls.name] = {
            "constructor_arities": constructor_arities,
            "method_names": method_names,
            # v0.6.7: also expose return types per method for Fix 18's
            # return-type signal. {method_name: [return_type, ...]} —
            # one list per name to keep overloads visible.
            "method_return_types": _index_method_return_types(all_methods),
            # v0.7 Phase 1.9: full per-method overload set for synthesis.
            "method_overloads": method_overloads,
        }
    logger.info(
        "class_api: built from ProjectMap",
        class_count=len(api),
        # Sample so we can verify the most-referenced classes are present
        # without flooding the log.
        sample=list(api.keys())[:10],
    )
    return api


def _index_method_return_types(methods: list) -> dict[str, list[str]]:
    """{method_name: [return_type, ...]} — preserves overloads."""
    out: dict[str, list[str]] = {}
    for m in methods:
        if m.is_constructor:
            continue
        out.setdefault(m.name, []).append(m.return_type or "void")
    return out


def _synthesize_missing_constructors(
    generations: list["GenerationResult"],
    class_api: dict[str, dict],
) -> None:
    """v0.6.7 Phase 1.7: re-add constructor overloads the Coder dropped.

    For each generated class whose simple name is in `class_api`, parse the
    constructor arities currently present in the file. If any source-side
    constructor arity is missing, inject a `super(...)`-delegating
    constructor of that arity right before the class's closing brace.

    Conservative scope:
      - Only acts when the simple class name matches a class_api entry —
        i.e. the source ProjectMap has the class.
      - Only adds; never removes or modifies existing constructors.
      - Generated constructors delegate to `super(...)` so they keep the
        same semantics as the original. Parameter names use the
        single-letter generic form (a, b, c) for predictability.
      - Skips classes that don't `extends X` (no parent class to delegate
        to means the synthesis would need defaults for every type, which
        is too risky).

    Why this exists: even with the required-signatures checklist in the
    Coder prompt, the LLM sometimes drops a 2-arg overload of an exception
    class. javac then breaks every caller of `new X(msg, cause)`. This
    pass mechanically restores the missing surface so the calls compile.
    """
    import re as _re

    # Pattern to identify the generated class's name and parent. Captures
    # `class Foo extends Bar` (and `Foo extends Bar implements ...` etc.).
    class_decl_re = _re.compile(
        r"\bclass\s+(\w+)(?:\s*<[^>]*>)?(?:\s+extends\s+(\w+))?",
    )
    # Pattern to identify each constructor in a class body.
    # Matches `(modifiers)? ClassName(params)` not preceded by a return type.
    # We approximate: any line shaped `<modifiers> ClassName(<params>)` where
    # ClassName matches the class declaration.
    for gen in generations:
        if not gen.output_path:
            continue
        try:
            src = gen.output_path.read_text(encoding="utf-8")
        except OSError:
            continue

        m = class_decl_re.search(src)
        if not m:
            continue
        class_name = m.group(1)
        parent_name = m.group(2)  # may be None

        info = class_api.get(class_name)
        if not info:
            continue
        source_arities: set[int] = info.get("constructor_arities") or set()
        if not source_arities:
            continue

        # Only act on subclasses where we can synthesize a `super(...)` call.
        # For classes without `extends`, we'd need to know fields to write a
        # sensible body — too risky.
        if not parent_name:
            continue

        # Find existing constructor arities in the generated file.
        ctor_re = _re.compile(
            rf"(?:public|protected|private)\s+{_re.escape(class_name)}\s*\(([^)]*)\)",
            _re.MULTILINE,
        )
        existing_arities: set[int] = set()
        for cm in ctor_re.finditer(src):
            params_text = cm.group(1).strip()
            if not params_text:
                existing_arities.add(0)
            else:
                # Count top-level commas; respect nested generics with <>.
                # Simple heuristic — params here are just type+name pairs.
                depth = 0
                count = 1
                for ch in params_text:
                    if ch == "<":
                        depth += 1
                    elif ch == ">":
                        depth -= 1
                    elif ch == "," and depth == 0:
                        count += 1
                existing_arities.add(count)

        missing = source_arities - existing_arities
        if not missing:
            continue

        # Find the class body's closing brace. We assume the LAST `}` in the
        # file is the class's outer brace, which is true for the assembler's
        # output format.
        last_brace = src.rfind("}")
        if last_brace < 0:
            continue

        # For each missing arity, build a synthesized constructor.
        # Parameter types: we don't know them, so use `String` for arity 1
        # and `(String, Throwable)` for arity 2 (the common exception
        # patterns). For other arities, fall back to `Object` for each.
        new_ctors: list[str] = []
        for arity in sorted(missing):
            if arity == 0:
                params = ""
                args = ""
            elif arity == 1:
                params = "String message"
                args = "message"
            elif arity == 2:
                params = "String message, Throwable cause"
                args = "message, cause"
            else:
                # Fallback: Object a, Object b, ...
                names = [f"a{i}" for i in range(arity)]
                params = ", ".join(f"Object {n}" for n in names)
                args = ", ".join(names)
            ctor = (
                f"\n    // QAMigrate v0.6.7: synthesized constructor — "
                f"missing from generated code\n"
                f"    public {class_name}({params}) {{\n"
                f"        super({args});\n"
                f"    }}\n"
            )
            new_ctors.append(ctor)

        new_src = src[:last_brace] + "".join(new_ctors) + src[last_brace:]
        gen.output_path.write_text(new_src, encoding="utf-8")
        gen.generated_code = new_src
        logger.info(
            "Phase 1.7: synthesized missing constructor(s)",
            class_=class_name,
            arities=sorted(missing),
        )


def _synthesize_missing_method_overloads(
    generations: list["GenerationResult"],
    class_api: dict[str, dict],
) -> None:
    """v0.7 Phase 1.9: re-add method overloads the Coder dropped.

    The v0.7 BDD run hit this on `ConfigurationReader.java`:
    source declares `getProperty(String key)` AND
    `getProperty(String key, String defaultValue)`, but the migrated
    class only kept the 1-arg form. Every caller using the 2-arg form
    failed with "method getProperty cannot be applied to (String, String)".

    The fix is mechanical: for every generated class whose name is in
    `class_api`, walk every method name in the source's overload set,
    check which arities the generated file declares, and synthesize any
    missing arities.

    Body strategy for synthesized methods:
      - 2-arg `(String key, String defaultValue)` and same name has a
        1-arg form: delegate `String v = name(key); return v != null ?
        v : defaultValue;` (default-value semantics).
      - Other shapes: throw `UnsupportedOperationException` and mark
        with a // QAMigrate comment so the user fixes it. Better than a
        compile error, worse than the right impl — but the user sees it.

    Conservative scope:
      - Only acts when the source has STRICTLY MORE arities than the
        generated class for that method name.
      - Only synthesizes methods that already exist with at least one
        arity in the generated file (otherwise the LLM intentionally
        dropped the whole method, e.g. `cleanup`).
    """
    import re as _re

    class_decl_re = _re.compile(
        r"\bclass\s+(\w+)(?:\s*<[^>]*>)?(?:\s+extends\s+\w+)?",
    )

    for gen in generations:
        if not gen.output_path:
            continue
        try:
            src = gen.output_path.read_text(encoding="utf-8")
        except OSError:
            continue

        m = class_decl_re.search(src)
        if not m:
            continue
        class_name = m.group(1)

        info = class_api.get(class_name)
        if not info:
            continue

        source_overloads: dict[str, list[tuple]] = info.get("method_overloads") or {}
        if not source_overloads:
            continue

        # Find existing method declarations in the generated file.
        # We only need (name → set of arities). A method header is matched
        # at line start with optional modifiers + return type + name + params.
        existing: dict[str, set[int]] = {}
        method_header_re = _re.compile(
            r"(?:public|protected|private)\s+(?:static\s+)?"
            r"(?:final\s+)?(?:[\w<>\[\],\s]+?)\s+"
            r"(\w+)\s*\(([^)]*)\)",
        )
        for hm in method_header_re.finditer(src):
            name = hm.group(1)
            params_text = hm.group(2).strip()
            # Class-name is also matched by this regex (constructors look
            # like methods syntactically). Skip those.
            if name == class_name:
                continue
            arity = 0
            if params_text:
                # Top-level commas (respect generics).
                depth = 0
                arity = 1
                for ch in params_text:
                    if ch == "<":
                        depth += 1
                    elif ch == ">":
                        depth -= 1
                    elif ch == "," and depth == 0:
                        arity += 1
            existing.setdefault(name, set()).add(arity)

        # For each method in the source's overload set: which arities are
        # declared in the source AND missing from the generated file?
        # Skip method names not present at all (LLM may have intentionally
        # dropped the whole method).
        missing_overloads: list[tuple[str, tuple]] = []
        for name, overloads in source_overloads.items():
            if name not in existing:
                continue
            existing_arities = existing[name]
            for ov in overloads:
                _modifiers, _ret, params = ov
                if len(params) not in existing_arities:
                    missing_overloads.append((name, ov))

        if not missing_overloads:
            continue

        # Build synthesized method bodies and insert before the class's
        # closing brace.
        new_methods: list[str] = []
        for name, (modifiers, ret_type, params) in missing_overloads:
            # Render parameter list using the source's actual types/names.
            params_str = ", ".join(f"{ptype} {pname}" for ptype, pname in params)
            mods_str = " ".join(modifiers) if modifiers else "public"
            # Body strategy.
            if (
                len(params) == 2
                and ret_type == "String"
                and any(
                    len(o[2]) == 1 and o[2][0][0] == params[0][0]
                    for o in source_overloads[name]
                )
            ):
                # 2-arg overload of `(<T> key, <T> defaultValue)` style:
                # delegate to 1-arg with default-value fallback.
                key_name = params[0][1]
                default_name = params[1][1]
                body = (
                    f"        String _v = {name}({key_name});\n"
                    f"        return _v != null ? _v : {default_name};"
                )
            elif ret_type == "void":
                body = f"        // QAMigrate v0.7: synthesized — fill in implementation\n        throw new UnsupportedOperationException(\"{name} not implemented\");"
            else:
                body = f"        // QAMigrate v0.7: synthesized — fill in implementation\n        throw new UnsupportedOperationException(\"{name} not implemented\");"

            new_methods.append(
                f"\n    // QAMigrate v0.7: synthesized overload — "
                f"missing from generated code\n"
                f"    {mods_str} {ret_type} {name}({params_str}) {{\n"
                f"{body}\n"
                f"    }}\n"
            )

        last_brace = src.rfind("}")
        if last_brace < 0:
            continue
        new_src = src[:last_brace] + "".join(new_methods) + src[last_brace:]
        gen.output_path.write_text(new_src, encoding="utf-8")
        gen.generated_code = new_src
        logger.info(
            "Phase 1.9: synthesized missing method overload(s)",
            class_=class_name,
            overloads=[
                f"{name}/{len(ov[2])}" for name, ov in missing_overloads
            ],
        )


# v0.7 Phase 1.8: ThreadLocal field name → Playwright type. Used by the
# undeclared-field synthesizer. The mapping is narrow on purpose: this
# rule only fires for fields with these exact names. Add to the map only
# after seeing the same hallucination shape in a real run.
_THREADLOCAL_FIELD_TYPES: dict[str, str] = {
    "pageThreadLocal": "Page",
    "contextThreadLocal": "BrowserContext",
    "browserThreadLocal": "Browser",
    "playwrightThreadLocal": "Playwright",
}


def _synthesize_missing_threadlocal_fields(
    generations: list["GenerationResult"],
) -> None:
    """v0.7 Phase 1.8: re-add ThreadLocal field declarations the Coder dropped.

    The v0.6.6 BDD run and the v0.6.7 production run both hit the same bug:
    DriverManager.java referenced `pageThreadLocal`, `contextThreadLocal`,
    and `browserThreadLocal` but only declared `playwrightThreadLocal`.
    Every caller that touched the missing fields failed with "cannot find
    symbol", and the cascade dragged down 7+ dependent files.

    This pass walks each generated file, finds references to the
    well-known ThreadLocal field names, and synthesizes any that are
    referenced but not declared. The synthesis uses a small fixed mapping
    of name → type (see `_THREADLOCAL_FIELD_TYPES`) so we never guess at
    the type.

    Why this is conservative:
      - Only acts on a fixed allowlist of ~4 field names. Won't touch
        arbitrary fields the LLM may legitimately have meant to drop.
      - Only synthesizes when at least ONE ThreadLocal field is already
        declared. If the file has zero ThreadLocals, it's not the
        DriverManager pattern and we leave it alone.
      - Does not modify methods, only inserts a field declaration line.
      - Marks each synthesized field with a `// QAMigrate v0.7:
        synthesized` comment so reviewers can see what was added.
    """
    import re as _re

    field_decl_re = _re.compile(
        r"\b(?:private|protected|public)\s+static\s+(?:final\s+)?"
        r"ThreadLocal\s*<[^>]+>\s+(\w+)\s*=",
    )
    # An identifier `xxxThreadLocal` referenced ANYWHERE in the file body
    # is a candidate for synthesis if not declared.
    name_re = _re.compile(r"\b(\w*ThreadLocal)\b")

    for gen in generations:
        if not gen.output_path:
            continue
        try:
            src = gen.output_path.read_text(encoding="utf-8")
        except OSError:
            continue

        declared = set(field_decl_re.findall(src))
        # Guard: only act when the file ALREADY has at least one
        # ThreadLocal declaration. That signals "this is the DriverManager
        # pattern" rather than an arbitrary class.
        if not declared:
            continue

        referenced = set(name_re.findall(src))
        # Restrict candidates to the well-known mapping. Other names are
        # too risky — we don't know their type.
        missing = [
            name for name in referenced
            if name not in declared and name in _THREADLOCAL_FIELD_TYPES
        ]
        if not missing:
            continue

        # Find a stable insertion point: right after the LAST existing
        # ThreadLocal declaration line. Preserves indentation and grouping.
        # Match the entire declaration line including its trailing newline.
        last_match = None
        full_line_re = _re.compile(
            r"^[ \t]*(?:private|protected|public)\s+static\s+(?:final\s+)?"
            r"ThreadLocal\s*<[^>]+>\s+\w+\s*=\s*new\s+ThreadLocal\s*<>\s*\(\s*\)\s*;[ \t]*\n",
            _re.MULTILINE,
        )
        for m in full_line_re.finditer(src):
            last_match = m
        if last_match is None:
            # Couldn't find a clean insertion point — skip for safety.
            continue

        insert_at = last_match.end()
        # Match the indentation of the existing declaration line.
        existing_line = last_match.group(0)
        indent = existing_line[: len(existing_line) - len(existing_line.lstrip())]

        # Build the synthesized lines.
        new_lines: list[str] = []
        for name in sorted(missing):
            java_type = _THREADLOCAL_FIELD_TYPES[name]
            new_lines.append(
                f"{indent}// QAMigrate v0.7: synthesized field — "
                f"referenced but not declared\n"
                f"{indent}private static final ThreadLocal<{java_type}> {name} = "
                f"new ThreadLocal<>();\n"
            )

        new_src = src[:insert_at] + "".join(new_lines) + src[insert_at:]
        gen.output_path.write_text(new_src, encoding="utf-8")
        gen.generated_code = new_src
        logger.info(
            "Phase 1.8: synthesized missing ThreadLocal field(s)",
            file=str(gen.output_path),
            fields=sorted(missing),
        )


def _warn_package_collisions(generations: list["GenerationResult"]) -> None:
    """v0.5.3: warn when a generated file's package matches its original.

    This is the root cause of the "~150 mvn errors" failure mode: when the
    Coder emits `package com.example.pages;` instead of
    `package com.example.pages.playwright;`, Maven's joint compilation sees
    two classes with the same FQN and collapses with duplicate-symbol errors.

    We can't fix already-generated files here, but we log a structured
    warning so the user sees a clear diagnosis in the output rather than
    150 opaque javac errors from `mvn clean compile`.

    The assemble_file() safety net in coder.py (v0.5.3) prevents this on
    fresh runs; this check catches any rogue paths that bypass assemble_file.
    """

    for gen in generations:
        if not gen.success or not gen.generated_code or not gen.source_path:
            continue

        # Extract package from generated file.
        gen_match = _PACKAGE_RE.search(gen.generated_code)
        if not gen_match:
            continue
        gen_pkg = gen_match.group(1)

        # Extract package from original source file.
        try:
            orig_src = gen.source_path.read_text(encoding="utf-8")
        except OSError:
            continue
        orig_match = _PACKAGE_RE.search(orig_src)
        if not orig_match:
            continue
        orig_pkg = orig_match.group(1)

        if gen_pkg == orig_pkg:
            logger.warning(
                "Package collision: generated file has same package as original. "
                "Maven will see duplicate class errors on `mvn clean compile`. "
                "Expected generated package to end with '.playwright'.",
                file=str(gen.source_path),
                original_package=orig_pkg,
                generated_package=gen_pkg,
                fix="Regenerate with v0.5.3+; the coder now appends .playwright automatically.",
            )


class SourceProjectNotCompilable(Exception):
    """v0.7: raised when the user's Selenium source project does not compile.

    QAMigrate is a translation tool, not a debugger. If `mvn compile` fails
    on the source project, QAMigrate refuses to run by default — migrating
    broken source produces broken output, and we'd be blamed for source
    bugs we faithfully copied forward.

    The user can override with `--ignore-source-errors` (CLI) or
    `ignore_source_errors=True` (Python API) when they understand the
    consequences.
    """

    def __init__(self, errors: list, error_count: int, project_path: Path) -> None:
        self.errors = errors
        self.error_count = error_count
        self.project_path = project_path
        super().__init__(
            f"Source project at {project_path} does not compile "
            f"({error_count} error(s)). Pass ignore_source_errors=True "
            "(or --ignore-source-errors) to migrate anyway."
        )


def _baseline_error_key(err: "Any") -> tuple[str, int, str]:
    """Stable identity for a CompilerError so we can match across runs.

    Errors keyed by (file_path, line_number, normalized_message). The
    message is stripped of whitespace and quoted symbols since the same
    underlying error can render slightly differently between Maven runs
    (different cwd, terminal width).

    Used by:
      - Item 2: attribute final errors as caused-by-us vs. inherited.
      - Item 3: Fixer skips errors whose key is in the source baseline.
    """
    msg = (err.message or "").strip()
    # Path normalization: take last 3 segments so absolute vs. relative
    # paths and forward/back slashes don't break matching.
    fp = (err.file_path or "").replace("\\", "/")
    fp = "/".join(fp.rsplit("/", 3)[-3:])
    return (fp, int(getattr(err, "line_number", 0) or 0), msg)


def _run_source_preflight(
    project_path: Path,
    config: QAMigrateConfig,
    ignore_source_errors: bool,
) -> set[tuple[str, int, str]]:
    """v0.7 Item 1+2: compile the source project before migrating.

    Returns the SET OF baseline error keys (empty set when source compiles
    cleanly). Raises `SourceProjectNotCompilable` when compilation fails
    AND `ignore_source_errors` is False.

    The set is then passed to:
      - the report generator so per-file error attribution distinguishes
        QAMigrate-caused vs. source-inherited errors;
      - the Fixer agent so it skips errors that were already there.
    """
    from qamigrate.agents.compiler import CompilerAgent

    logger.info(
        "Phase -1 (v0.7): source pre-flight compile",
        project=str(project_path),
    )
    try:
        compiler = CompilerAgent(config.compiler)
        result = compiler.compile(project_path)
    except Exception as e:  # pragma: no cover — defensive
        logger.warning(
            "Source pre-flight compile crashed; treating source as clean. "
            "Errors during migration may include latent source bugs.",
            error=str(e),
        )
        return set()

    if result.success:
        logger.info(
            "Source pre-flight: project compiles cleanly",
            build_time_ms=result.build_time_ms,
        )
        return set()

    # Source has errors. Build the baseline set.
    baseline = {_baseline_error_key(e) for e in result.errors}
    logger.warning(
        "Source pre-flight: project does NOT compile",
        error_count=len(result.errors),
        baseline_size=len(baseline),
    )

    if not ignore_source_errors:
        # Hard stop. Caller (CLI) catches this and prints a clear message.
        raise SourceProjectNotCompilable(
            errors=result.errors,
            error_count=len(result.errors),
            project_path=project_path,
        )

    # User opted into --ignore-source-errors.
    logger.info(
        "Source pre-flight: --ignore-source-errors set; baseline captured "
        "and will be excluded from QAMigrate's responsibility metrics.",
        baseline_size=len(baseline),
    )
    return baseline


def run_project_migration(
    files: list[Path],
    project_path: Path,
    config: QAMigrateConfig,
    on_generation: Callable[[int, int, GenerationResult], None] | None = None,
    on_compile: Callable[[int, int, int], None] | None = None,
    *,
    ignore_source_errors: bool = False,
) -> ProjectMigrationResult:
    """
    Migrate a whole project in three phases:

      0. (v0.7) Pre-flight: `mvn compile` on the source project. If it
         fails and `ignore_source_errors` is False, raise
         `SourceProjectNotCompilable`. The contract: QAMigrate translates
         working Selenium → working Playwright. Migrating broken source
         is the user's choice via the override.
      1. Generate all files (scanner + coder, no compile).
      2. Resolve classpath + batch-compile everything together.
      3. If errors, loop through affected files, ask Fixer to fix each one
         with only its own errors, recompile, accept only if errors
         strictly reduced. Stop after config.pipeline.max_retries passes or
         two consecutive non-improvements.

    This is the recommended path for `qamigrate migrate --all` in v0.3+.

    Args:
        ignore_source_errors: when True, proceed even if the source project
            doesn't compile. The pre-flight error set is captured as a
            "baseline" and excluded from the Fixer's repair queue + the
            report's attribution column.
    """
    logger.info("Project pipeline: start", file_count=len(files))

    # ---- Phase -1 (v0.7): source pre-flight ----
    source_baseline_errors = _run_source_preflight(
        project_path, config, ignore_source_errors
    )

    # ---- Phase 0 (v0.5+): build the ProjectMap once ----
    # This is the deep context the Coder uses on every file. Side effect:
    # zero LLM calls; costs a few hundred ms on a medium project.
    project_map = None
    try:
        from qamigrate.intelligence import ProjectAnalyzer
        project_map = ProjectAnalyzer().build(project_path)
        logger.info(
            "Project pipeline: intelligence ready",
            classes=project_map.file_count,
            edges=project_map.total_edges,
        )
    except Exception as e:  # pragma: no cover - defensive
        logger.warning(
            "Project pipeline: intelligence build failed; continuing without "
            "deep project context",
            error=str(e),
        )

    # v0.5.13: detect target test framework from the project intelligence so
    # the Coder, postgen fixes, and dep injector all use the SAME framework
    # as the source project.  "testng" stays TestNG; "junit4"/"junit5" keep
    # their respective framework.  Unknown defaults to "junit5" (safe).
    target_framework = "junit5"
    if project_map and project_map.infrastructure:
        detected = (project_map.infrastructure.test_framework or "").lower()
        if detected in ("testng", "junit4", "junit5"):
            target_framework = detected
    logger.info("Project pipeline: target framework", framework=target_framework)

    # v0.5.15: detect BDD framework
    is_bdd = bool(
        project_map
        and project_map.infrastructure
        and getattr(project_map.infrastructure, "bdd_framework", None) == "cucumber"
    )
    if is_bdd:
        logger.info("Project pipeline: BDD mode (Cucumber) detected")

    # ---- Phase 1: generate all files ----
    generations: list[GenerationResult] = []
    sibling_signatures: dict[str, list[str]] = {}
    # v0.5.1: catalogue of declared CSS/XPath selectors per class, so we
    # can detect tests that invent selectors not present on the page.
    # v0.5.2(b): now also tracks getByTestId strings (see DeclaredSelectors).
    sibling_locators: dict[str, DeclaredSelectors] = {}

    # v0.5.19: usage-cap errors are NOT transient — the entire run aborts
    # so we don't burn budget on guaranteed-failing calls and so the user
    # sees a clear "quota exhausted" message instead of N spurious FAILs.
    from qamigrate.llm.errors import LLMUsageCapExhausted

    for i, file_path in enumerate(files, start=1):
        try:
            gen = run_generation(
                file_path=file_path,
                project_path=project_path,
                config=config,
                sibling_signatures=sibling_signatures or None,
                project_map=project_map,
                target_framework=target_framework,
                is_bdd=is_bdd,
            )
        except LLMUsageCapExhausted as exc:
            logger.error(
                "Project pipeline: aborting — provider usage cap exhausted",
                files_completed=i - 1,
                files_remaining=len(files) - (i - 1),
                provider_message=str(exc)[:300],
            )
            raise
        generations.append(gen)
        if gen.success and gen.class_name:
            sibling_signatures[gen.class_name] = gen.signatures
            declared = extract_declared_selectors(gen.generated_code)
            if not declared.is_empty:
                sibling_locators[gen.class_name] = declared
        if on_generation:
            on_generation(i, len(files), gen)

    successful_gens = [g for g in generations if g.success and g.output_path is not None]

    # ---- Phase 1.5: rewrite sibling imports to .playwright package ----
    # v0.5.5 Fix #1: Generated files import siblings using the ORIGINAL
    # package path (e.g. `import com.qastarter.browser.BrowserFactory;`).
    # After migration, BrowserFactory lives at
    # `com.qastarter.browser.playwright.BrowserFactory`. javac resolves
    # cross-file references via -sourcepath, but only when the import
    # path matches the directory. This deterministic rewrite fixes all
    # `cannot find symbol` errors caused by stale sibling imports --
    # no LLM call required.
    #
    # v0.5.7 Bug #3: also return the mapping so Phase 3 (Fixer loop) can
    # re-apply the rewrite after each Fixer edit that may re-introduce the
    # old import paths.
    name_to_orig_pkg = _rewrite_sibling_imports(successful_gens)

    # ---- Phase 1.6: deterministic post-generation fixups ----
    # v0.5.8: apply known migration-gap fixes (e.g. @Listeners → @ExtendWith,
    # ScreenshotOptions import) before the first compile attempt. Zero LLM
    # cost; these are patterns the model consistently gets wrong.
    # v0.6.6: build a flat class_api lookup from the ProjectMap so postgen
    # Fix 17 (constructor-arity guard) and Fix 18 (hallucinated method
    # rewrite) can deterministically catch sibling-class hallucinations.
    from qamigrate.core.postgen_fixes import apply_all_postgen_fixes
    class_api = _build_class_api_from_project_map(project_map)
    for gen in successful_gens:
        if not gen.output_path:
            continue
        try:
            src = gen.output_path.read_text(encoding="utf-8")
            fixed = apply_all_postgen_fixes(
                src,
                file_path=str(gen.output_path),
                target_framework=target_framework,
                class_api=class_api,
            )
            if fixed is not src:  # identity check -- only write if changed
                gen.output_path.write_text(fixed, encoding="utf-8")
                gen.generated_code = fixed
        except OSError:
            pass

    # ---- Phase 1.7 (v0.6.7): synthesize missing constructors ----
    # The Coder occasionally drops constructor overloads from generated
    # exception classes (and similar simple classes), even with the v0.6.1
    # required-signatures checklist in the prompt. The v0.6.6 production
    # run had `new InvalidPathForExtentReportFileException(msg, cause)` fail
    # because the migrated class was missing the 2-arg constructor that the
    # source declared.
    #
    # The fix is mechanical: for every generated class whose simple name
    # matches an entry in `class_api`, ensure every source constructor
    # arity survives into the generated class. Missing arities get a
    # synthesized `super(...)`-delegating constructor inserted right
    # before the closing brace.
    if class_api:
        try:
            _synthesize_missing_constructors(successful_gens, class_api)
        except Exception as e:  # pragma: no cover — defensive
            logger.warning(
                "Phase 1.7: missing-constructor synthesis failed",
                error=str(e),
            )

    # ---- Phase 1.9 (v0.7): synthesize missing method overloads ----
    # The Coder occasionally drops a method overload when the source
    # declares two forms of the same method (e.g. ConfigurationReader
    # has both `getProperty(String)` and `getProperty(String, String)`
    # — the LLM kept only the 1-arg one). Phase 1.9 walks each generated
    # class's API against the source-side overload set and synthesizes
    # any missing arities. Body is delegate-with-default for the common
    # 2-arg key/default pattern, UnsupportedOperationException stub
    # otherwise (caught by tests at runtime, never silent).
    if class_api:
        try:
            _synthesize_missing_method_overloads(successful_gens, class_api)
        except Exception as e:  # pragma: no cover — defensive
            logger.warning(
                "Phase 1.9: method-overload synthesis failed",
                error=str(e),
            )

    # ---- Phase 1.8 (v0.7): synthesize missing ThreadLocal fields ----
    # The Coder occasionally references `pageThreadLocal` / `contextThreadLocal`
    # / `browserThreadLocal` in DriverManager but only declares ONE of them.
    # The bug cascades: every caller that touches the missing field fails
    # with "cannot find symbol", and the BDD/Production runs lost 7-8 files
    # to this single root cause. Phase 1.8 walks each generated file and
    # synthesizes the missing ThreadLocal declarations from a fixed
    # name → type mapping so we never guess at the type.
    try:
        _synthesize_missing_threadlocal_fields(successful_gens)
    except Exception as e:  # pragma: no cover — defensive
        logger.warning(
            "Phase 1.8: ThreadLocal field synthesis failed",
            error=str(e),
        )

    # ---- Phase 2: resolve classpath + batch compile ----
    classpath_reason: str | None = None
    compile_result = None
    classpath_entries: list[Path] = []

    if successful_gens:
        # Detect build tool by looking for pom.xml / build.gradle
        build_tool: str | None = None
        if (project_path / "pom.xml").exists():
            build_tool = "maven"
        elif (project_path / "build.gradle").exists() or (project_path / "build.gradle.kts").exists():
            build_tool = "gradle"

        if build_tool:
            resolver = ClasspathResolver(timeout_seconds=config.classpath.timeout_seconds)
            cp_result = resolver.resolve(
                project_path, build_tool,
                use_cache=config.classpath.use_cache,
            )
            if cp_result.ok:
                classpath_entries = cp_result.entries
                logger.info("Classpath resolved", entries=len(classpath_entries), cached=cp_result.cached)
            else:
                classpath_reason = cp_result.reason
                logger.warning("Classpath resolve failed; compile-check will be skipped",
                               reason=classpath_reason)
        else:
            classpath_reason = "No pom.xml or build.gradle found -- not a supported build tool"

    # ---- Phase 3: compile + fix loop ----
    from qamigrate.llm.from_config import build_provider_for_agent

    compiler = CompilerAgent(config.compiler)
    fixer = FixerAgent(
        config.fixer,
        llm_provider=build_provider_for_agent(config, "fixer"),
    )

    # If we couldn't resolve a classpath, skip compile entirely and mark
    # everything as "compiled=None" (generated, not verified).
    if classpath_reason is not None:
        records = _finalize_records_without_compile(generations, classpath_reason)
        return ProjectMigrationResult(
            records=records,
            classpath_reason=classpath_reason,
            compiled_count=0,
            failed_count=sum(1 for r in records if not r.success),
        )

    source_root = project_path / "src" / "main" / "java"
    test_source_root = project_path / "src" / "test" / "java"
    # Prefer main if present; otherwise use test. javac can handle mixed.
    if source_root.exists():
        effective_source_root = source_root
    elif test_source_root.exists():
        effective_source_root = test_source_root
    else:
        logger.warning(
            "Project pipeline: no Maven source root found; compile check skipped",
            project=str(project_path),
        )
        records = _finalize_records_without_compile(
            generations, "No Maven source root (src/main/java or src/test/java)"
        )
        return ProjectMigrationResult(
            records=records,
            classpath_reason="No Maven source root found",
            compiled_count=0,
            failed_count=sum(1 for r in records if not r.success),
        )

    # v0.5.3 Bug #3 fix: detect package-collision before compile.
    # When generated files declare the same package as their originals,
    # `mvn clean compile` sees duplicate class errors even though our
    # isolated javac check passes (it only sees the playwright/ files,
    # not the originals). We catch this deterministically here so the
    # user gets an actionable message instead of 150 javac errors.
    _warn_package_collisions(successful_gens)

    gen_paths = [g.output_path for g in successful_gens if g.output_path]

    max_iterations = config.pipeline.max_retries + 1
    # v0.5.16: wall-clock budget per file. The production run showed a single
    # file (TestSimpleCode.java) spending 7.4 hours in the fix loop.  Iteration
    # count alone is not enough — one iteration can call the LLM many times for
    # large files.  Files that exceed this budget are marked exhausted so the
    # loop continues with the remaining files.
    max_fix_seconds = getattr(config.fixer, "max_fix_seconds", 300)
    file_fix_start_time: dict[str, float] = {}

    # Per-file "best error count" so one stuck file doesn't block progress
    # on others (v0.3.1: fixes the Environment.java starvation reported
    # against v0.3.0). Each file gets its own attempt budget and its own
    # no-progress counter.
    per_file_best_errors: dict[str, int] = {}
    per_file_no_progress: dict[str, int] = {}
    attempts_per_file: dict[str, int] = {str(g.output_path): 0 for g in successful_gens}
    exhausted_files: set[str] = set()

    # v0.5.7 Bug #2: snapshot best content per file so we can restore the
    # best-known state when the Fixer regresses. Previously the loop tracked
    # best_errors but left the REGRESSED content on disk, causing "26 mvn
    # errors" after the Fixer had already reached "1 error" at peak.
    best_content_per_file: dict[str, str] = {}
    best_errors_per_file: dict[str, int] = {}

    # Also keep a global no-progress tracker so we bail out when the whole
    # project has plateaued, not just when one file got stuck.
    global_best: int | None = None
    global_no_progress = 0

    for iteration in range(max_iterations):
        logger.info("Project compile attempt", iteration=iteration + 1)
        compile_result = compiler.compile_batch(
            files=gen_paths,
            classpath=classpath_entries if classpath_entries else None,
            source_root=effective_source_root,
        )
        if on_compile:
            on_compile(iteration + 1, len(compile_result.errors), len(gen_paths))

        if compile_result.success:
            logger.info("Project compile succeeded", iteration=iteration + 1)
            break

        current_errors = len(compile_result.errors)
        if global_best is None or current_errors < global_best:
            global_best = current_errors
            global_no_progress = 0
            # Snapshot the best-known state for every file so we can
            # restore it if a later Fixer iteration regresses. We read
            # from disk (not from gen.generated_code) because the Fixer
            # may have already modified the files in earlier iterations.
            for g in successful_gens:
                if g.output_path and g.output_path.exists():
                    try:
                        content = g.output_path.read_text(encoding="utf-8")
                        file_key = str(g.output_path)
                        # Only update the snapshot when this file's error
                        # count also improved (or it had none).
                        file_errors_now = len(
                            [e for e in compile_result.errors
                             if g.output_path.name in (e.file_path or "")]
                        )
                        prev_best = best_errors_per_file.get(file_key)
                        if prev_best is None or file_errors_now <= prev_best:
                            best_content_per_file[file_key] = content
                            best_errors_per_file[file_key] = file_errors_now
                    except OSError:
                        pass
        else:
            global_no_progress += 1

        # Stop when the WHOLE project stops improving, or we hit the max.
        # A single file's budget is tracked separately below.
        if global_no_progress >= 2 or iteration == max_iterations - 1:
            logger.warning(
                "Project compile: stopping",
                reason="no global progress" if global_no_progress >= 2 else "max iterations",
                best_errors=global_best,
            )
            break

        # Group errors by file and fix each affected file individually.
        # Each file has its own budget (config.pipeline.max_retries per
        # file) and its own no-progress counter, so a stubborn file doesn't
        # starve its siblings and vice versa.
        groups = CompilerAgent.group_errors_by_file(compile_result)

        # v0.7 Item 3: skip baseline errors. The Fixer's job is to repair
        # bugs QAMigrate introduced, not to fix latent source-side issues.
        # An error whose (file, line, message) key matches a source-side
        # baseline error is inherited from the user's original Selenium
        # source — surface it in the report but don't burn API budget on it.
        if source_baseline_errors:
            filtered_groups: dict = {}
            inherited_count = 0
            for fp, errs in groups.items():
                fresh = [e for e in errs if _baseline_error_key(e) not in source_baseline_errors]
                inherited_count += len(errs) - len(fresh)
                if fresh:
                    filtered_groups[fp] = fresh
            if inherited_count:
                logger.info(
                    "Project compile: skipping inherited (source-side) errors",
                    inherited=inherited_count,
                    fixable=sum(len(v) for v in filtered_groups.values()),
                )
            groups = filtered_groups

        any_changed = False
        for file_str, errors in groups.items():
            if file_str in exhausted_files:
                continue
            try:
                file_path = Path(file_str)
                if not file_path.exists():
                    continue

                # v0.5.16: wall-clock budget check.
                # Record when we first see this file in the fix loop.
                if file_str not in file_fix_start_time:
                    file_fix_start_time[file_str] = time.time()
                else:
                    elapsed = time.time() - file_fix_start_time[file_str]
                    if elapsed > max_fix_seconds:
                        logger.warning(
                            "Fixer: retiring file (wall-clock budget exceeded)",
                            file=file_str,
                            elapsed_seconds=round(elapsed),
                            max_seconds=max_fix_seconds,
                        )
                        exhausted_files.add(file_str)
                        continue

                # Per-file progress check: if this file's error count has
                # gone up or stayed the same since we last fixed it, count
                # that against its no-progress budget.
                file_best = per_file_best_errors.get(file_str)
                if file_best is None or len(errors) < file_best:
                    per_file_best_errors[file_str] = len(errors)
                    per_file_no_progress[file_str] = 0
                else:
                    per_file_no_progress[file_str] = per_file_no_progress.get(file_str, 0) + 1

                if (
                    per_file_no_progress.get(file_str, 0) >= 2
                    or attempts_per_file.get(file_str, 0) >= config.pipeline.max_retries
                ):
                    logger.info(
                        "Fixer: retiring file (budget spent)",
                        file=file_str,
                        attempts=attempts_per_file.get(file_str, 0),
                    )
                    exhausted_files.add(file_str)
                    continue

                current_code = file_path.read_text(encoding="utf-8")
                fixed_code, changes = fixer.fix_file(
                    file_path=file_path,
                    code=current_code,
                    all_errors=errors,
                    retry_count=attempts_per_file.get(file_str, 0),
                )
                # Always count the attempt (even if the Fixer rejected its
                # own LLM output and returned the original). Without this,
                # stubborn files spin forever without consuming budget.
                attempts_per_file[file_str] = attempts_per_file.get(file_str, 0) + 1

                if fixed_code != current_code and changes:
                    # v0.5.7 Bug #3: re-apply sibling import rewrite after
                    # each Fixer edit. The Fixer may regenerate import lines
                    # using the original (non-.playwright) package path.
                    # _apply_import_rewrite is idempotent so this is safe.
                    fixed_code = _apply_import_rewrite(fixed_code, name_to_orig_pkg)
                    # v0.5.8: re-apply deterministic post-gen fixups
                    # (@Listeners → @ExtendWith, ScreenshotOptions import)
                    # in case the Fixer regenerated those sections.
                    from qamigrate.core.postgen_fixes import apply_all_postgen_fixes
                    fixed_code = apply_all_postgen_fixes(
                        fixed_code,
                        file_path=file_str,
                        target_framework=target_framework,
                        class_api=_build_class_api_from_project_map(project_map),
                    )
                    file_path.write_text(fixed_code, encoding="utf-8")
                    any_changed = True
                    logger.info("Fixer applied changes", file=file_str,
                                change_count=len(changes))
                else:
                    logger.info("Fixer produced no usable fix for file",
                                file=file_str)
            except Exception as e:  # pragma: no cover
                logger.warning("Fixer error on file", file=file_str, error=str(e))

        # If nothing changed across any file in this iteration AND every
        # file has either been fixed cleanly or retired, we're done.
        if not any_changed and len(exhausted_files) >= len(groups):
            logger.info("Fixer produced no changes anywhere; stopping")
            break

    # ---- Phase 3 epilogue: restore best-known content where Fixer regressed ----
    # v0.5.7 Bug #2: if the Fixer made things worse after a good iteration,
    # the file on disk reflects the regressed state. Restore the snapshot.
    restored_any = False
    if best_content_per_file and compile_result and not compile_result.success:
        for g in successful_gens:
            if not g.output_path:
                continue
            file_key = str(g.output_path)
            best = best_content_per_file.get(file_key)
            if best is None:
                continue
            try:
                current = g.output_path.read_text(encoding="utf-8")
                if current != best:
                    g.output_path.write_text(best, encoding="utf-8")
                    g.generated_code = best
                    restored_any = True
                    logger.info(
                        "Fixer: restored best-known content (rolled back regression)",
                        file=file_key,
                    )
            except OSError:
                pass

    # Re-compile once after restore to get accurate final error counts.
    if restored_any and compile_result is not None:
        logger.info("Recompiling after rollback to get accurate final error counts")
        compile_result = compiler.compile_batch(
            files=gen_paths,
            classpath=classpath_entries if classpath_entries else None,
            source_root=effective_source_root,
        )

    # ---- Finalize: build records from the final compile result ----
    final_errors_by_file = (
        CompilerAgent.group_errors_by_file(compile_result) if compile_result else {}
    )

    records: list[MigrationRecord] = []
    compiled_count = 0
    failed_count = 0

    for gen in generations:
        if not gen.success or gen.output_path is None:
            records.append(_build_record_from_generation(gen, compiled=None, attempts=0))
            failed_count += 1
            continue

        file_key = str(gen.output_path)
        # Match absolute+relative path variants (javac may emit either).
        file_errors = final_errors_by_file.get(file_key, [])
        if not file_errors:
            # Also try matching by basename
            for k, v in final_errors_by_file.items():
                if Path(k).name == gen.output_path.name:
                    file_errors = v
                    break

        attempts = attempts_per_file.get(file_key, 0)

        # v0.7 Item 2: split errors into "caused by QAMigrate" vs.
        # "inherited from source" so the user sees what's our fault.
        if source_baseline_errors:
            inherited = [
                e for e in file_errors
                if _baseline_error_key(e) in source_baseline_errors
            ]
            caused = [
                e for e in file_errors
                if _baseline_error_key(e) not in source_baseline_errors
            ]
        else:
            inherited = []
            caused = list(file_errors)

        if compile_result and compile_result.success:
            compiled = True
            error = None
            compiled_count += 1
        elif file_errors:
            compiled = False
            # Distinguish QAMigrate's responsibility from the source's.
            # The user runs `mvn compile` themselves and sees ALL errors,
            # but for QAMigrate's reporting purposes only `caused` counts.
            if inherited:
                error = (
                    f"{len(caused)} caused by QAMigrate + "
                    f"{len(inherited)} inherited from source "
                    f"(after {attempts} fix attempt(s))"
                )
            else:
                error = f"{len(caused)} compile error(s) after {attempts} fix attempt(s)"
            failed_count += 1
        else:
            # Batch failed overall but this specific file had no errors.
            compiled = True
            error = None
            compiled_count += 1

        # Refresh generated_code from disk (may have been updated by fixer)
        try:
            gen.generated_code = gen.output_path.read_text(encoding="utf-8")
        except OSError:
            pass

        # Run hallucination detection now that the file is final
        hallucinations: list[Hallucination] = []
        if sibling_signatures and gen.generated_code:
            hallucinations = detect_hallucinations(gen.generated_code, sibling_signatures)
        if sibling_locators and gen.generated_code:
            hallucinations.extend(
                detect_selector_hallucinations(gen.generated_code, sibling_locators)
            )

        records.append(_build_record_from_generation(
            gen,
            compiled=compiled,
            attempts=attempts,
            error=error,
            hallucinations=hallucinations,
            caused_error_count=len(caused),
            inherited_error_count=len(inherited),
        ))

    return ProjectMigrationResult(
        records=records,
        classpath_reason=None,
        compiled_count=compiled_count,
        failed_count=failed_count,
    )


def _finalize_records_without_compile(
    generations: list[GenerationResult],
    reason: str,
) -> list[MigrationRecord]:
    """Build records for all files when compile-check was skipped entirely."""
    records: list[MigrationRecord] = []
    for gen in generations:
        if gen.success and gen.output_path is not None:
            records.append(_build_record_from_generation(
                gen, compiled=None, attempts=0,
            ))
        else:
            records.append(_build_record_from_generation(
                gen, compiled=None, attempts=0,
                error=gen.error or f"Generation failed; compile skipped: {reason}",
            ))
    return records
