# QAMigrate Manual Review Checklist

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Finished:** 2026-04-29T08:12:36.866326+00:00

Three buckets, ordered by the attention each file deserves.
Start at the top: Priority first, then Verify, then skim Solid.

- **Priority:** 1 file(s) -- fix or re-run
- **Verify:**   0 file(s) -- glance at these
- **Solid:**    14 file(s) -- likely ship-ready

## 1. Priority -- look at these first

Generation failed, compilation failed, or confidence < 70%.

- [ ] **D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\core\BaseTest.java** -- Generation failed. Error: 1 compile error(s) after 1 fix attempt(s) → `1 compile error(s) after 1 fix attempt(s)`

## 2. Verify -- compiled, but worth a glance

_None. Every compiled file is either solid or priority._

## 3. Solid -- likely ship-ready

Confidence >= 90%, zero hallucinations, compiled cleanly. Spot-check a few at random.

- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\pages\BasePage.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\pages\LoginPage.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\config\ConfigurationReader.java -- 90%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\config\Environment.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\core\BrowserFactory.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\core\DriverManager.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\listeners\RetryAnalyzer.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\listeners\TestListener.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\utils\ExtentManager.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\utils\Log.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\utils\ScreenshotUtils.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\utils\WaitUtils.java -- 90%
- [x] D:\TestFlux\samples\selenium-java-project\src\main\java\com\qastarter\utils\WebActions.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project\src\test\java\com\qastarter\tests\LoginTests.java -- 100%
