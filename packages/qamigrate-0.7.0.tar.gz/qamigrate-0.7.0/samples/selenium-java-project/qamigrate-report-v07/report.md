# QAMigrate Migration Report

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Started:** 2026-04-29T08:07:46.352734+00:00
**Finished:** 2026-04-29T08:12:36.866326+00:00

## Summary

- **Files migrated:** 14 / 15
- **Patterns handled:** 44
- **Average confidence:** 95%
- **Time taken:** 217.8s
- **Estimated manual effort saved:** ~10.5 hours

## Patterns handled

| Pattern | Count |
|---------|-------|
| `By_id` | 6 |
| `WebDriver` | 6 |
| `ExpectedConditions` | 5 |
| `By_field` | 4 |
| `click` | 3 |
| `sendKeys` | 2 |
| `clear` | 2 |
| `By_cssSelector` | 2 |
| `JavascriptExecutor` | 2 |
| `assertTrue` | 2 |
| `JUnit4_Test` | 2 |
| `TestNG_BeforeMethod` | 1 |
| `TestNG_AfterMethod` | 1 |
| `ChromeDriver` | 1 |
| `FirefoxDriver` | 1 |
| `WebDriverWait` | 1 |
| `Actions` | 1 |
| `Select` | 1 |
| `hover` | 1 |

## Files

| File | Status | Confidence | Patterns | Hallucinations | Time |
|------|--------|------------|----------|----------------|------|
| `BaseTest.java` | FAIL | 50% | 2 | 0 | 20.5s |
| `BasePage.java` | OK | 100% | 3 | 0 | 21.2s |
| `LoginPage.java` | OK | 100% | 13 | 0 | 13.5s |
| `ConfigurationReader.java` | OK | 90% | 0 | 0 | 15.0s |
| `Environment.java` | OK | 100% | 0 | 0 | 1.2s |
| `BrowserFactory.java` | OK | 100% | 3 | 0 | 13.7s |
| `DriverManager.java` | OK | 100% | 3 | 0 | 15.1s |
| `RetryAnalyzer.java` | OK | 100% | 0 | 0 | 6.9s |
| `TestListener.java` | OK | 100% | 0 | 0 | 15.3s |
| `ExtentManager.java` | OK | 100% | 0 | 0 | 14.3s |
| `Log.java` | OK | 100% | 0 | 0 | 13.3s |
| `ScreenshotUtils.java` | OK | 100% | 2 | 0 | 10.6s |
| `WaitUtils.java` | OK | 90% | 6 | 0 | 22.3s |
| `WebActions.java` | OK | 100% | 8 | 0 | 21.7s |
| `LoginTests.java` | OK | 100% | 4 | 0 | 13.1s |
