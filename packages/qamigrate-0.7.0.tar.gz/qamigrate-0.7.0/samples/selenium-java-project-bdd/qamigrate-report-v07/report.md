# QAMigrate Migration Report

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Started:** 2026-04-29T16:02:43.354732+00:00
**Finished:** 2026-04-29T16:02:44.627027+00:00

## Summary

- **Files migrated:** 17 / 17
- **Patterns handled:** 56
- **Average confidence:** 0%
- **Time taken:** 1.2s
- **Estimated manual effort saved:** ~0.0 hours

## Patterns handled

| Pattern | Count |
|---------|-------|
| `ExpectedConditions` | 10 |
| `By_id` | 6 |
| `WebDriver` | 6 |
| `assertTrue` | 5 |
| `By_field` | 4 |
| `click` | 3 |
| `sendKeys` | 2 |
| `clear` | 2 |
| `By_cssSelector` | 2 |
| `WebDriverWait` | 2 |
| `JavascriptExecutor` | 2 |
| `Cucumber_Scenario_Inject` | 2 |
| `Cucumber_When` | 2 |
| `Cucumber_Then` | 2 |
| `ChromeDriver` | 1 |
| `FirefoxDriver` | 1 |
| `Actions` | 1 |
| `Select` | 1 |
| `hover` | 1 |
| `Cucumber_Given` | 1 |

## Files

| File | Status | Confidence | Patterns | Hallucinations | Time |
|------|--------|------------|----------|----------------|------|
| `BaseTest.java` | OK | 0% | 0 | 0 | 0.1s |
| `BasePage.java` | OK | 0% | 3 | 0 | 0.1s |
| `LoginPage.java` | OK | 0% | 13 | 0 | 0.1s |
| `ConfigurationReader.java` | OK | 0% | 0 | 0 | 0.1s |
| `Environment.java` | OK | 0% | 0 | 0 | 0.1s |
| `BrowserFactory.java` | OK | 0% | 3 | 0 | 0.1s |
| `DriverManager.java` | OK | 0% | 3 | 0 | 0.1s |
| `TestWatcher.java` | OK | 0% | 0 | 0 | 0.1s |
| `AllureManager.java` | OK | 0% | 0 | 0 | 0.1s |
| `Log.java` | OK | 0% | 0 | 0 | 0.1s |
| `ScreenshotUtils.java` | OK | 0% | 2 | 0 | 0.1s |
| `WaitUtils.java` | OK | 0% | 12 | 0 | 0.1s |
| `WebActions.java` | OK | 0% | 8 | 0 | 0.1s |
| `TestRunner.java` | OK | 0% | 0 | 0 | 0.1s |
| `Hooks.java` | OK | 0% | 2 | 0 | 0.1s |
| `LoginSteps.java` | OK | 0% | 8 | 0 | 0.1s |
| `LoginTests.java` | OK | 0% | 2 | 0 | 0.1s |
