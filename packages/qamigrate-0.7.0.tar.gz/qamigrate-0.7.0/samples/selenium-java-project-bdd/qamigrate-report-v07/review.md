# QAMigrate Manual Review Checklist

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Finished:** 2026-04-29T16:02:44.627027+00:00

Three buckets, ordered by the attention each file deserves.
Start at the top: Priority first, then Verify, then skim Solid.

- **Priority:** 17 file(s) -- fix or re-run
- **Verify:**   0 file(s) -- glance at these
- **Solid:**    0 file(s) -- likely ship-ready

## 1. Priority -- look at these first

Generation failed, compilation failed, or confidence < 70%.

- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\core\BaseTest.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\pages\BasePage.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\pages\LoginPage.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\config\ConfigurationReader.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\config\Environment.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\core\BrowserFactory.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\core\DriverManager.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\core\TestWatcher.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\AllureManager.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\Log.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\ScreenshotUtils.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\WaitUtils.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\WebActions.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\test\java\com\qastarter\runners\TestRunner.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\test\java\com\qastarter\stepdefinitions\Hooks.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\test\java\com\qastarter\stepdefinitions\LoginSteps.java** -- Generation failed — no output file produced.
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\test\java\com\qastarter\tests\LoginTests.java** -- Generation failed — no output file produced.

## 2. Verify -- compiled, but worth a glance

_None. Every compiled file is either solid or priority._

## 3. Solid -- likely ship-ready

_None yet -- run the full pipeline first._
