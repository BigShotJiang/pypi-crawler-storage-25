"""HTTP response with chainable .with_*() transformation API.

Each transformation returns a new Response. Immutable by convention,
built incrementally by design.
"""

import json as json_module
from collections.abc import AsyncIterator, Iterator, Mapping
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, Literal

from chirp.http.cookies import SetCookie

if TYPE_CHECKING:
    from chirp.http.request import Request

type RenderIntent = Literal["unknown", "full_page", "fragment"]

STOP_POLLING: int = 286
"""HTTP status code that tells htmx to stop polling (htmx extension)."""


@dataclass(frozen=True, slots=True)
class Response:
    """An HTTP response built through immutable transformations.

    Construct with a body, then chain ``.with_*()`` calls to set
    status, headers, and cookies. Each call returns a new ``Response``.
    """

    body: str | bytes = ""
    status: int = 200
    content_type: str = "text/html; charset=utf-8"
    headers: tuple[tuple[str, str], ...] = ()
    cookies: tuple[SetCookie, ...] = ()
    render_intent: RenderIntent = "unknown"  # unknown | full_page | fragment

    # -- Chainable transformations --

    def with_status(self, status: int) -> Response:
        """Return a new Response with a different status code."""
        return replace(self, status=status)

    def with_header(self, name: str, value: str) -> Response:
        """Return a new Response with an additional header."""
        return replace(self, headers=(*self.headers, (name, value)))

    def with_vary(self, *fields: str) -> Response:
        """Append field(s) to the ``Vary`` header without duplicating values.

        Merges with any existing ``Vary`` header so that CORS
        (``Vary: Origin``) and content negotiation (``Vary: HX-Request``)
        compose correctly.
        """
        existing = self.header("Vary")
        current: set[str] = set()
        if existing:
            current = {v.strip() for v in existing.split(",")}
        new_fields = [f for f in fields if f not in current]
        if not new_fields and existing:
            return self
        merged = ", ".join(sorted(current | set(fields)))
        # Replace existing Vary header if present
        if existing is not None:
            filtered = tuple((n, v) for n, v in self.headers if n.lower() != "vary")
            return replace(self, headers=(*filtered, ("Vary", merged)))
        return self.with_header("Vary", merged)

    def with_headers(self, headers: Mapping[str, str]) -> Response:
        """Return a new Response with additional headers."""
        new = tuple(headers.items())
        return replace(self, headers=(*self.headers, *new))

    def with_content_type(self, content_type: str) -> Response:
        """Return a new Response with a different content type."""
        return replace(self, content_type=content_type)

    def with_render_intent(self, render_intent: RenderIntent) -> Response:
        """Return a new Response with response render intent metadata."""
        return replace(self, render_intent=render_intent)

    def with_cookie(
        self,
        name: str,
        value: str,
        *,
        max_age: int | None = None,
        path: str = "/",
        domain: str | None = None,
        secure: bool = False,
        httponly: bool = True,
        samesite: str = "lax",
    ) -> Response:
        """Return a new Response with an additional Set-Cookie."""
        cookie = SetCookie(
            name=name,
            value=value,
            max_age=max_age,
            path=path,
            domain=domain,
            secure=secure,
            httponly=httponly,
            samesite=samesite,
        )
        return replace(self, cookies=(*self.cookies, cookie))

    def without_cookie(self, name: str, path: str = "/") -> Response:
        """Return a new Response that deletes a cookie (Max-Age=0)."""
        cookie = SetCookie(name=name, value="", max_age=0, path=path)
        return replace(self, cookies=(*self.cookies, cookie))

    # -- htmx response headers --

    def with_hx_redirect(self, url: str) -> Response:
        """Tell htmx to do a full-page redirect (like entering a URL).

        Sets the ``HX-Redirect`` response header.
        """
        return self.with_header("HX-Redirect", url)

    def with_hx_location(
        self,
        url: str,
        *,
        target: str | None = None,
        swap: str | None = None,
        source: str | None = None,
        event: str | None = None,
        select: str | None = None,
        values: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Response:
        """Tell htmx to navigate via AJAX (like clicking a boosted link).

        When only *url* is provided, sets ``HX-Location`` to the plain
        URL string.  When any extra option is given, sets the header to
        a JSON object per the htmx ``HX-Location`` spec.
        """
        opts: dict[str, str | None | dict[str, Any]] = {
            "target": target,
            "swap": swap,
            "source": source,
            "event": event,
            "select": select,
        }
        has_opts = (
            any(v is not None for v in opts.values()) or values is not None or headers is not None
        )
        if not has_opts:
            return self.with_header("HX-Location", url)
        obj: dict[str, Any] = {
            "path": url,
            **{key: val for key, val in opts.items() if val is not None},
        }
        if values is not None:
            obj["values"] = values
        if headers is not None:
            obj["headers"] = headers
        return self.with_header("HX-Location", json_module.dumps(obj))

    def with_hx_retarget(self, selector: str) -> Response:
        """Override the target element for this response.

        Sets the ``HX-Retarget`` response header to a CSS selector.
        """
        return self.with_header("HX-Retarget", selector)

    def with_hx_reswap(self, strategy: str) -> Response:
        """Override the swap strategy for this response.

        Sets the ``HX-Reswap`` response header.  Accepts any valid
        ``hx-swap`` value (e.g. ``"innerHTML"``, ``"outerHTML"``,
        ``"beforeend"``).
        """
        return self.with_header("HX-Reswap", strategy)

    def with_hx_reselect(self, selector: str) -> Response:
        """Override the hx-select for this response.

        Sets the ``HX-Reselect`` response header to a CSS selector that
        chooses which part of the response is used for swapping, overriding
        any ``hx-select`` on the triggering element.
        """
        return self.with_header("HX-Reselect", selector)

    def _merge_hx_trigger(self, header_name: str, event: str | dict[str, Any]) -> Response:
        """Merge an event into an ``HX-Trigger*`` header.

        Multiple calls are merged into a single JSON object so that all
        events travel in one header value. A plain string event ``"foo"``
        becomes ``{"foo": true}`` during merge; a dict is merged directly.
        """
        # Build the new events dict from the incoming event
        if isinstance(event, str):
            new_events: dict[str, Any] = {event: True}
        else:
            new_events = dict(event)

        # Check for an existing header value to merge with
        existing = self.header(header_name)
        if existing is not None:
            # Parse existing: could be plain string "evt" or JSON {"evt": {...}}
            try:
                parsed = json_module.loads(existing)
                if isinstance(parsed, dict):
                    merged = {**parsed, **new_events}
                else:
                    # Non-dict JSON (shouldn't happen, but be safe)
                    merged = {existing: True, **new_events}
            except json_module.JSONDecodeError, ValueError:
                # Plain string event name
                merged = {existing: True, **new_events}
            # Remove the old header, add the merged one
            filtered = tuple((n, v) for n, v in self.headers if n.lower() != header_name.lower())
            return replace(self, headers=(*filtered, (header_name, json_module.dumps(merged))))

        # No existing header — single event can stay as plain string
        if isinstance(event, str):
            return self.with_header(header_name, event)
        return self.with_header(header_name, json_module.dumps(event))

    def with_hx_trigger(self, event: str | dict[str, Any]) -> Response:
        """Trigger a client-side event after the response is received.

        Sets the ``HX-Trigger`` response header.  Accepts a plain
        event name string or a dict for events with payloads::

            .with_hx_trigger("closeModal")
            .with_hx_trigger({"showToast": {"message": "Saved!"}})

        Multiple calls are merged into a single JSON header::

            .with_hx_trigger("a").with_hx_trigger("b")
            # -> HX-Trigger: {"a": true, "b": true}
        """
        return self._merge_hx_trigger("HX-Trigger", event)

    def with_hx_trigger_after_settle(self, event: str | dict[str, Any]) -> Response:
        """Trigger a client-side event after the settle step.

        Sets the ``HX-Trigger-After-Settle`` response header.
        Multiple calls are merged into a single JSON header.
        """
        return self._merge_hx_trigger("HX-Trigger-After-Settle", event)

    def with_hx_trigger_after_swap(self, event: str | dict[str, Any]) -> Response:
        """Trigger a client-side event after the swap step.

        Sets the ``HX-Trigger-After-Swap`` response header.
        Multiple calls are merged into a single JSON header.
        """
        return self._merge_hx_trigger("HX-Trigger-After-Swap", event)

    def with_hx_triggers(self, **events: Any) -> Response:
        """Set multiple ``HX-Trigger`` events in a single call.

        Each keyword argument becomes an event name. Values are payloads
        (use ``True`` for events with no data)::

            .with_hx_triggers(closeModal=True, showToast={"message": "Saved!"})
            # -> HX-Trigger: {"closeModal": true, "showToast": {"message": "Saved!"}}
        """
        return self._merge_hx_trigger("HX-Trigger", events)

    def with_hx_push_url(self, url: str | bool) -> Response:
        """Push a URL into the browser history stack.

        Sets the ``HX-Push-Url`` response header.  Pass a URL string
        or ``False`` to prevent htmx from pushing.
        """
        value = url if isinstance(url, str) else ("true" if url else "false")
        return self.with_header("HX-Push-Url", value)

    def with_hx_replace_url(self, url: str | bool) -> Response:
        """Replace the current URL in the browser location bar.

        Sets the ``HX-Replace-Url`` response header.  Pass a URL
        string or ``False`` to prevent htmx from replacing.
        """
        value = url if isinstance(url, str) else ("true" if url else "false")
        return self.with_header("HX-Replace-Url", value)

    def with_hx_refresh(self) -> Response:
        """Tell htmx to do a full page refresh.

        Sets ``HX-Refresh: true``.
        """
        return self.with_header("HX-Refresh", "true")

    def with_hx_stop_polling(self) -> Response:
        """Tell htmx to stop polling this endpoint.

        Sets the response status to 286 (``STOP_POLLING``).
        """
        return self.with_status(STOP_POLLING)

    # -- Header lookup --

    def header(self, name: str, default: str | None = None) -> str | None:
        """Return the first header value matching *name* (case-insensitive)."""
        target = name.lower()
        for hname, hvalue in self.headers:
            if hname.lower() == target:
                return hvalue
        return default

    # -- Body helpers --

    @property
    def body_bytes(self) -> bytes:
        """Body as bytes."""
        if isinstance(self.body, str):
            return self.body.encode("utf-8")
        return self.body

    @property
    def text(self) -> str:
        """Body as string."""
        if isinstance(self.body, bytes):
            return self.body.decode("utf-8")
        return self.body

    @property
    def json(self) -> Any:
        """Body parsed as JSON.

        Raises ``ValueError`` if the body is not valid JSON.
        """
        return json_module.loads(self.text)


@dataclass(frozen=True, slots=True)
class JSONResponse(Response):
    """A compact JSON response serialized directly to bytes."""

    body: bytes = b""
    content_type: str = "application/json; charset=utf-8"

    @classmethod
    def from_value(
        cls,
        value: Any,
        *,
        status: int = 200,
        headers: Mapping[str, str] | None = None,
    ) -> JSONResponse:
        """Serialize *value* once and return a JSONResponse."""
        response = cls(
            body=json_module.dumps(value, default=str, separators=(",", ":")).encode("utf-8"),
            status=status,
        )
        if headers:
            return replace(response, headers=tuple(headers.items()))
        return response


@dataclass(frozen=True, slots=True)
class Redirect:
    """A redirect response."""

    url: str
    status: int = 302
    headers: tuple[tuple[str, str], ...] = ()


def hx_redirect(
    url: str,
    *,
    status: int = 303,
    body: str | bytes = "",
    headers: Mapping[str, str] | None = None,
) -> Response:
    """Build a redirect response that works for htmx and non-htmx clients.

    Adds both ``Location`` and ``HX-Redirect`` so a normal browser follows the
    HTTP redirect while htmx performs a full-page navigation.
    """
    response = (
        Response(body=body).with_status(status).with_header("Location", url).with_hx_redirect(url)
    )
    if headers:
        response = response.with_headers(headers)
    return response


@dataclass(frozen=True, slots=True)
class StreamingResponse:
    """A streaming HTTP response that sends chunks progressively.

    Used for chunked transfer encoding: headers are sent immediately,
    then each chunk is sent as an ASGI body message with ``more_body=True``.

    Supports the same ``.with_*()`` chainable API as ``Response``
    so middleware can modify headers/status without knowing the
    response is streamed.

    ``render_intent`` mirrors :class:`Response` so HTML middleware (e.g.
    :class:`~chirp.middleware.inject.AlpineInject`) can skip fragments.
    """

    chunks: Iterator[str] | AsyncIterator[str]
    status: int = 200
    content_type: str = "text/html; charset=utf-8"
    headers: tuple[tuple[str, str], ...] = ()
    render_intent: RenderIntent = "unknown"
    request_context: Request | None = None

    def with_status(self, status: int) -> StreamingResponse:
        """Return a new StreamingResponse with a different status code."""
        return replace(self, status=status)

    def with_header(self, name: str, value: str) -> StreamingResponse:
        """Return a new StreamingResponse with an additional header."""
        return replace(self, headers=(*self.headers, (name, value)))

    def with_headers(self, headers: Mapping[str, str]) -> StreamingResponse:
        """Return a new StreamingResponse with additional headers."""
        new = tuple(headers.items())
        return replace(self, headers=(*self.headers, *new))

    def with_content_type(self, content_type: str) -> StreamingResponse:
        """Return a new StreamingResponse with a different content type."""
        return replace(self, content_type=content_type)

    def header(self, name: str, default: str | None = None) -> str | None:
        """Return the first header value matching *name* (case-insensitive)."""
        target = name.lower()
        for hname, hvalue in self.headers:
            if hname.lower() == target:
                return hvalue
        return default

    def with_cookie(
        self,
        name: str,
        value: str,
        *,
        max_age: int | None = None,
        path: str = "/",
        domain: str | None = None,
        secure: bool = False,
        httponly: bool = True,
        samesite: str = "lax",
    ) -> StreamingResponse:
        """Return a new StreamingResponse with a Set-Cookie header."""
        cookie = SetCookie(
            name=name,
            value=value,
            max_age=max_age,
            path=path,
            domain=domain,
            secure=secure,
            httponly=httponly,
            samesite=samesite,
        )
        return self.with_header("Set-Cookie", cookie.to_header_value())

    def with_render_intent(self, render_intent: RenderIntent) -> StreamingResponse:
        """Return a new StreamingResponse with fragment vs full-page intent."""
        return replace(self, render_intent=render_intent)


@dataclass(frozen=True, slots=True)
class SSEResponse:
    """Sentinel response for Server-Sent Events.

    Wraps an EventStream and requires direct ASGI send/receive access
    (the handler bypasses the normal _send_response path).

    Provides no-op ``.with_*()`` methods so middleware chains don't crash.
    SSE headers (text/event-stream, no-cache) are always sent by the SSE
    handler itself; any middleware header modifications are ignored.

    A warning is logged the first time a no-op method is called, so
    middleware authors know their modifications are being silently dropped.
    """

    event_stream: Any  # EventStream (avoided import cycle)
    kida_env: Any = None  # kida Environment | None
    _noop_warned: bool = False

    def _warn_noop(self, method: str) -> None:
        if not self._noop_warned:
            # Bypass frozen restriction for this internal flag.
            object.__setattr__(self, "_noop_warned", True)
            import logging

            logging.getLogger("chirp.server").warning(
                "SSEResponse.%s() is a no-op — SSE headers are fixed by the "
                "protocol handler. Middleware modifications are silently "
                "ignored for SSE streams.",
                method,
            )

    def with_status(self, status: int) -> SSEResponse:
        """No-op: SSE always sends 200."""
        self._warn_noop("with_status")
        return self

    def with_header(self, name: str, value: str) -> SSEResponse:
        """No-op: SSE headers are fixed by the protocol handler."""
        self._warn_noop("with_header")
        return self

    def with_headers(self, headers: Mapping[str, str]) -> SSEResponse:
        """No-op: SSE headers are fixed by the protocol handler."""
        self._warn_noop("with_headers")
        return self

    def with_content_type(self, content_type: str) -> SSEResponse:
        """No-op: SSE content type is always text/event-stream."""
        return self

    def with_render_intent(self, render_intent: RenderIntent) -> SSEResponse:
        """No-op: SSE streams bypass normal response metadata."""
        return self

    def with_cookie(
        self,
        name: str = "",
        value: str = "",
        **kwargs: Any,
    ) -> SSEResponse:
        """No-op: SSE responses don't carry Set-Cookie headers."""
        return self

    def without_cookie(self, name: str = "", path: str = "/") -> SSEResponse:
        """No-op: SSE responses don't carry Set-Cookie headers."""
        return self

    # -- htmx no-ops (SSE streams bypass normal response headers) --

    def with_hx_redirect(self, url: str) -> SSEResponse:
        """No-op: SSE streams cannot set HX-Redirect."""
        return self

    def with_hx_location(
        self,
        url: str = "",
        *,
        target: str | None = None,
        swap: str | None = None,
        source: str | None = None,
        event: str | None = None,
        select: str | None = None,
        values: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> SSEResponse:
        """No-op: SSE streams cannot set HX-Location."""
        return self

    def with_hx_retarget(self, selector: str) -> SSEResponse:
        """No-op: SSE streams cannot set HX-Retarget."""
        return self

    def with_hx_reswap(self, strategy: str) -> SSEResponse:
        """No-op: SSE streams cannot set HX-Reswap."""
        return self

    def with_hx_reselect(self, selector: str = "") -> SSEResponse:
        """No-op: SSE streams cannot set HX-Reselect."""
        return self

    def with_hx_trigger(self, event: str | dict[str, Any] = "") -> SSEResponse:
        """No-op: SSE streams cannot set HX-Trigger."""
        return self

    def with_hx_trigger_after_settle(self, event: str | dict[str, Any] = "") -> SSEResponse:
        """No-op: SSE streams cannot set HX-Trigger-After-Settle."""
        return self

    def with_hx_trigger_after_swap(self, event: str | dict[str, Any] = "") -> SSEResponse:
        """No-op: SSE streams cannot set HX-Trigger-After-Swap."""
        return self

    def with_hx_push_url(self, url: str | bool = "") -> SSEResponse:
        """No-op: SSE streams cannot set HX-Push-Url."""
        return self

    def with_hx_replace_url(self, url: str | bool = "") -> SSEResponse:
        """No-op: SSE streams cannot set HX-Replace-Url."""
        return self

    def with_hx_refresh(self) -> SSEResponse:
        """No-op: SSE streams cannot set HX-Refresh."""
        return self

    def with_hx_stop_polling(self) -> SSEResponse:
        """No-op: SSE streams cannot stop polling."""
        return self

    def with_hx_triggers(self, **events: Any) -> SSEResponse:
        """No-op: SSE streams cannot set HX-Trigger."""
        return self

    def with_vary(self, *fields: str) -> SSEResponse:
        """No-op: SSE headers are fixed by the protocol handler."""
        return self
