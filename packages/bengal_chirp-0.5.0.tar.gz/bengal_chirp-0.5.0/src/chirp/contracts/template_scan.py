"""Template source scanners used by contracts checker."""

import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .patterns import ID_ATTR as _ID_PATTERN
from .patterns import METHOD_POST

# \baction\b avoids matching "action" inside form_action, data-action, etc.
_ACTION_OR_HX = r"(hx-(?:get|post|put|patch|delete)|\baction\b)"
_ATTR_PATTERN_DOUBLE = re.compile(
    rf'{_ACTION_OR_HX}\s*=\s*"([^"]*)"',
)
_ATTR_PATTERN_SINGLE = re.compile(
    rf"{_ACTION_OR_HX}\s*=\s*'([^']*)'",
)
_ATTRS_MAP_PATTERN = re.compile(rf"""["']{_ACTION_OR_HX}["']\s*:\s*["']([^"']*)["'](?=\s*[,}}])""")
_CONFIRM_URL_PATTERN = re.compile(r'confirm_url\s*=\s*["\']([^"\']*)["\']')
_CONFIRM_METHOD_PATTERN = re.compile(r'confirm_method\s*=\s*["\']([^"\']*)["\']', re.IGNORECASE)
_HX_TARGET_PATTERN = re.compile(r'hx-target\s*=\s*["\']([^"\']*)["\']')
_TEMPLATE_REF_PATTERN = re.compile(
    r"""\{%-?\s*(?:extends|include|from|import)\s+["']([^"']+)["']"""
)
_TEMPLATE_SOURCE_SUFFIXES = (".html", ".htm", ".jinja", ".j2")
_FRAGMENT_ISLAND_PATTERN = re.compile(r'fragment_island\s*\(\s*["\']([^"\']+)["\']')
_WIZARD_FORM_PATTERN = re.compile(r'wizard_form\s*\(\s*["\']([^"\']+)["\']')
_ID_WITH_DISINHERIT_PATTERN = re.compile(
    r'<[^>]+\bid\s*=\s*["\']([^"\']+)["\'][^>]*hx-disinherit',
    re.IGNORECASE | re.DOTALL,
)
_ID_WITH_DISINHERIT_REVERSE = re.compile(
    r'<[^>]+hx-disinherit[^>]*\bid\s*=\s*["\']([^"\']+)["\']',
    re.IGNORECASE | re.DOTALL,
)
_MUTATING_WITH_TARGET = re.compile(
    r"<(?:form|button|a|div|span)\b[^>]*\b(?:hx-(?:post|put|patch|delete)|\baction\b)\s*="
    r'[^>]*\bhx-target\s*=\s*["\']#([^"\'\s]+)["\']',
    re.IGNORECASE,
)
_LEGACY_ACTION_PATTERN = re.compile(r'(?<![-\w])action\s*=\s*["\']([A-Za-z][A-Za-z0-9_-]*)["\']')
_HREF_ATTR_PATTERN = re.compile(r'href\s*=\s*["\']([^"\']*)["\']')
_MACRO_URL_ARG_PATTERN = re.compile(
    r"""(?:href|url|search_url|action_url)\s*=\s*["'](/[^"']*?)["']"""
)
_POSITIONAL_URL_ARG_PATTERN = re.compile(r"""\(\s*["'](/[a-zA-Z][a-zA-Z0-9_/{}-]*)["']""")
_HTMX_PARTIAL_PATTERN = re.compile(
    r'<htmx-partial\b[^>]*(?<![-\w])src\s*=\s*["\']([^"\']*)["\']',
    re.IGNORECASE,
)
_FORM_OPEN_TAG = re.compile(r"<form\b", re.IGNORECASE)
_MUTATING_BLOCK_TARGET = re.compile(
    r"(?:hx-(?:post|put|patch|delete)|hx_post|hx_put|hx_patch|hx_delete|\baction\b)\s*[=:][^}]+"
    r'(?:hx-target|hx_target)\s*[=:]\s*["\']#([^"\']+)["\']',
    re.IGNORECASE | re.DOTALL,
)
_TARGET_IN_MUTATING = re.compile(
    r'(?:hx-target|hx_target)\s*[=:]\s*["\']#([^"\']+)["\'][^}]*'
    r"(?:hx-(?:post|put|patch|delete)|hx_post|hx_put|hx_patch|hx_delete)",
    re.IGNORECASE | re.DOTALL,
)


def _is_static_url_candidate(url: str) -> bool:
    return not (
        "{{" in url
        or "~" in url
        or "{%" in url
        or url.startswith(("#", "javascript:"))
        or "://" in url
    )


def _confirm_method_for_match(source: str, match_start: int, match_end: int) -> str:
    window_start = max(0, match_start - 160)
    window_end = min(len(source), match_end + 160)
    window = source[window_start:window_end]
    method_match = _CONFIRM_METHOD_PATTERN.search(window)
    if method_match is None:
        return "POST"
    return method_match.group(1).upper()


def _is_kida_expression_continued(source: str, match_end: int) -> bool:
    next_source = source[match_end:].lstrip()
    return next_source.startswith("~")


def get_form_method(source: str, action_pos: int) -> str | None:
    """Return POST only when form has method='post', otherwise GET."""
    from collections import deque

    before = source[:action_pos]
    last_match = next(
        iter(deque(_FORM_OPEN_TAG.finditer(before), maxlen=1)),
        None,
    )
    if last_match is None:
        return None
    form_start = last_match.start()
    tag_end = source.find(">", form_start)
    if tag_end == -1 or tag_end < action_pos:
        return None
    form_tag = source[form_start:tag_end]
    if METHOD_POST.search(form_tag):
        return "POST"
    return "GET"


def extract_targets_from_source(source: str) -> list[tuple[str, str, str | None]]:
    """Extract (attr_name, url, method_override) from template source."""
    targets: list[tuple[str, str, str | None]] = []
    seen: set[tuple[str, str, str | None]] = set()

    def _append_target(attr_name: str, url: str, method_override: str | None) -> None:
        if not _is_static_url_candidate(url):
            return
        target = (attr_name, url, method_override)
        if target in seen:
            return
        seen.add(target)
        targets.append(target)

    for pattern in (_ATTR_PATTERN_DOUBLE, _ATTR_PATTERN_SINGLE):
        for match in pattern.finditer(source):
            attr_name = match.group(1)
            url = match.group(2)
            method_override = (
                get_form_method(source, match.start()) if attr_name == "action" else None
            )
            _append_target(attr_name, url, method_override)

    for match in _ATTRS_MAP_PATTERN.finditer(source):
        attr_name = match.group(1)
        url = match.group(2)
        _append_target(attr_name, url, None)

    for match in _CONFIRM_URL_PATTERN.finditer(source):
        if _is_kida_expression_continued(source, match.end()):
            continue
        url = match.group(1)
        method_override = _confirm_method_for_match(source, match.start(), match.end())
        _append_target("confirm_url", url, method_override)

    return targets


def extract_href_references(source: str) -> set[str]:
    """Extract URL paths from href= attributes and macro keyword arguments.

    Used for orphan-route detection: catches ``<a href="/team">``, macro calls
    like ``sidebar_link("/team", ...)``, and keyword args like ``href="/login"``.
    Returns base paths (query strings and fragments stripped).
    """
    urls: set[str] = set()
    for pattern in (_HREF_ATTR_PATTERN, _MACRO_URL_ARG_PATTERN, _POSITIONAL_URL_ARG_PATTERN):
        for m in pattern.finditer(source):
            url = m.group(1)
            if not _is_static_url_candidate(url):
                continue
            if not url.startswith("/"):
                continue
            base = url.split("?")[0].split("#")[0]
            if base:
                urls.add(base)
    return urls


def extract_legacy_action_contracts(source: str) -> set[str]:
    """Extract legacy action= contract names from template call arguments."""
    names: set[str] = set()
    for match in _LEGACY_ACTION_PATTERN.finditer(source):
        value = match.group(1).strip()
        if value and _is_static_url_candidate(value) and not value.startswith("/"):
            names.add(value)
    return names


def extract_hx_target_selectors(source: str) -> list[str]:
    """Extract static hx-target selector values from source."""
    selectors: list[str] = []
    for match in _HX_TARGET_PATTERN.finditer(source):
        value = match.group(1).strip()
        if "{{" in value or "{%" in value:
            continue
        if value:
            selectors.append(value)
    return selectors


def extract_static_ids(source: str) -> set[str]:
    """Extract static id= values from source."""
    ids: set[str] = set()
    for match in _ID_PATTERN.finditer(source):
        value = match.group(1).strip()
        if value and "{{" not in value and "{%" not in value:
            ids.add(value)
    return ids


def extract_template_references(source: str) -> set[str]:
    """Extract static template references from Kida template tags."""
    return {m.group(1) for m in _TEMPLATE_REF_PATTERN.finditer(source)}


def extract_fragment_island_ids(source: str) -> set[str]:
    """Extract id values from fragment_island() macro calls."""
    return {m.group(1) for m in _FRAGMENT_ISLAND_PATTERN.finditer(source)}


def extract_wizard_form_ids(source: str) -> set[str]:
    """Extract id values from wizard_form() macro calls."""
    return {m.group(1) for m in _WIZARD_FORM_PATTERN.finditer(source)}


def extract_ids_with_disinherit(source: str) -> set[str]:
    """Extract id values from elements that have hx-disinherit."""
    ids: set[str] = set()
    for pattern in (_ID_WITH_DISINHERIT_PATTERN, _ID_WITH_DISINHERIT_REVERSE):
        for m in pattern.finditer(source):
            val = m.group(1).strip()
            if val and "{{" not in val and "{%" not in val:
                ids.add(val)
    ids.update(extract_fragment_island_ids(source))
    return ids


def extract_mutation_target_ids(source: str) -> set[str]:
    """Extract #id values from hx-target when element is mutating."""
    ids: set[str] = set()
    for m in _MUTATING_WITH_TARGET.finditer(source):
        val = m.group(1).strip()
        if val and "{{" not in val and "{%" not in val:
            ids.add(val)
    for val in _MUTATING_BLOCK_TARGET.findall(source):
        if "{{" not in val and "{%" not in val:
            ids.add(val.strip())
    for val in _TARGET_IN_MUTATING.findall(source):
        if "{{" not in val and "{%" not in val:
            ids.add(val.strip())
    return ids


def extract_htmx_partial_sources(source: str) -> list[str]:
    """Extract ``src=`` attribute values from ``<htmx-partial>`` elements.

    Values are normalized to URL paths suitable for route matching:
    query strings and fragments are stripped, and only leading-``/`` paths
    are kept.  Results are deduplicated while preserving order.
    """
    urls: list[str] = []
    seen: set[str] = set()
    for m in _HTMX_PARTIAL_PATTERN.finditer(source):
        raw = m.group(1).strip()
        if not _is_static_url_candidate(raw):
            continue
        path = raw
        for sep in ("?", "#"):
            if sep in path:
                path = path.split(sep, 1)[0]
        if not path.startswith("/"):
            continue
        if path and path not in seen:
            seen.add(path)
            urls.append(path)
    return urls


def _load_one(loader: Any, name: str) -> tuple[str, str] | None:
    """Load a single template; returns (name, source) or None on error."""
    try:
        source, _ = loader.get_source(name)
        return (name, source)
    except Exception:
        return None


def load_template_sources(kida_env: Any) -> dict[str, str]:
    """Load all template sources from environment loader (parallel disk reads)."""
    sources: dict[str, str] = {}
    loader = kida_env.loader
    if loader is None:
        return sources
    list_fn = getattr(loader, "list_templates", None)
    if list_fn is None:
        return sources
    try:
        names = [n for n in list_fn() if n.endswith(_TEMPLATE_SOURCE_SUFFIXES)]
        if not names:
            return sources
        with ThreadPoolExecutor(max_workers=min(8, len(names))) as pool:
            futures = {pool.submit(_load_one, loader, name): name for name in names}
            for future in as_completed(futures):
                result = future.result()
                if result is not None:
                    sources[result[0]] = result[1]
    except Exception:
        logging.getLogger("chirp.contracts").debug(
            "Template source loading failed during parallel scan",
            exc_info=True,
        )
    return sources
