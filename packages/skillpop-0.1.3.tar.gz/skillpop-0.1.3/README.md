<p align="center">
  <img src="https://img.shields.io/badge/python-3.10+-blue?style=flat-square&logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey?style=flat-square" />
  <img src="https://img.shields.io/badge/license-MIT-green?style=flat-square" />
  <img src="https://img.shields.io/github/stars/liyue2341/skillpop?style=flat-square" />
</p>

<h1 align="center">SkillPop</h1>

<p align="center">
  <strong>You need a pop for all your skills.</strong><br/>
  Scan, diff & sync AI agent skills across every platform — from one local dashboard.
</p>

<p align="center">
  <a href="#quick-start">Quick Start</a> &middot;
  <a href="#what-it-does">What It Does</a> &middot;
  <a href="#supported-platforms">Platforms</a> &middot;
  <a href="#how-it-works">How It Works</a> &middot;
  <a href="#support">Support</a>
</p>

---

## The Problem

SKILL.md is the open standard for AI agent skills — Anthropic published it, OpenAI Codex and Gemini CLI adopted the same format. But each platform stores skills in **different directories** with **no sync mechanism**. Skills drift, get duplicated, or live on only one platform.

SkillPop gives you **one dashboard** to see everything, spot differences, and sync with a drag.

---

## Quick Start

```bash
pip install skillpop
skillpop
```

Your browser opens at `http://127.0.0.1:7432`. That's it.

<details>
<summary>Install from source</summary>

```bash
git clone https://github.com/liyue2341/skillpop.git
cd skillpop
pip install -e .
```

</details>

---

## What It Does

### Card Grid — see all your skills at a glance

<p align="center">
  <img src="docs/grid-view.png" alt="Card grid overview" width="720" />
</p>

Every skill card shows its name, description, sync status, and which platforms it lives on. Click any card to dive into details.

### Tree View — platform-by-platform breakdown

<p align="center">
  <img src="docs/tree-view.png" alt="Tree view with detail panel" width="720" />
</p>

Left sidebar groups skills by platform with color-coded badges. Right panel shows full SKILL.md content, platform locations, copy buttons, and line-level diffs for diverged skills.

### Drag & Drop — copy skills between platforms

Drag any skill onto a platform header to copy it. If the skill already exists with different content, you'll get a confirmation prompt before overwriting.

### More features

- **Line-level diff view** — unified diff for diverged skills across platforms
- **Skill creation wizard** — create and deploy to multiple platforms in one step
- **Import** — drop in a SKILL.md file or ZIP archive to import skills
- **ZIP export** — bundle skills for manual upload (e.g., Claude.ai)
- **Live file watching** — `--watch` flag auto-rescans on filesystem changes
- **Custom platforms** — add your own skill directories from the UI, persisted across restarts
- **Chinese / English** — full i18n with one-click toggle
- **Dark / light theme** — auto-detects your system preference

---

## All Commands

| Command | Description |
|---|---|
| `skillpop` | Start and open browser |
| `skillpop --watch` | Auto-rescan on file changes |
| `skillpop --port 8080` | Custom port |
| `skillpop --no-browser` | Don't auto-open browser |
| `skillpop --add id:label:path` | Register a custom platform via CLI |

---

## Supported Platforms

| Platform | ID | Default Path |
|---|---|---|
| Claude Code (personal) | `cc` | `~/.claude/skills/` |
| Claude Code (project) | `ccp` | `./.claude/skills/` |
| Codex CLI | `cx` | `~/.codex/skills/` |
| Gemini CLI | `gm` | `~/.gemini/skills/` |
| OpenCode | `oc` | `~/.opencode/skills/` |
| Cursor | `cu` | `~/.cursor/skills/` |
| Amp | `am` | `~/.amp/skills/` |
| Claude.ai | `ai` | _(web upload only)_ |

**Managing platforms:** Don't use Codex or OpenCode? Click the `×` next to any platform to remove it. Want to add a new one? Click `+ add custom platform` at the bottom of the sidebar, or use `--add id:label:path` from the CLI. All changes are saved to `~/.skillpop/config.json`.

---

## How It Works

1. **Scan** — discovers skill directories across all platforms. Each subdirectory containing a `SKILL.md` is one skill.

2. **Compare** — skills with the same directory name on multiple platforms are grouped. Content hash determines sync status:
   - **synced** — identical content across platforms
   - **diverged** — same skill, different content
   - **unique** — exists on only one platform

3. **Act** — copy between platforms (drag-and-drop or click), view line-level diffs, create new skills, import files, or export as ZIP.

---

## Development

```bash
git clone https://github.com/Liyue2341/SkillPop.git
cd SkillPop
pip install -e .
skillpop --watch --no-browser
```

The frontend is a single HTML file (`skillpop/static/index.html`) — no build tools, no npm. Edit and refresh.

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Requirements

- Python 3.10+
- Dependencies auto-installed: `fastapi`, `uvicorn`, `watchdog`, `python-multipart`

---

## Support

If SkillPop saved you from skill chaos across platforms, consider buying me a coffee:

<p align="center">
  <a href="https://buymeacoffee.com/liyue2341">
    <img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" height="50" />
  </a>
</p>

---

<p align="center">MIT &copy; 2025 <a href="https://github.com/liyue2341">liyue2341</a></p>
