"""Platform discovery, SKILL.md parsing, and sync-status computation."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path


# ---------------------------------------------------------------------------
# Platform definitions
# ---------------------------------------------------------------------------

def _home(*parts: str) -> Path:
    return Path.home().joinpath(*parts)


def _cwd(*parts: str) -> Path:
    return Path.cwd().joinpath(*parts)


@dataclass
class PlatformDef:
    id: str
    label: str
    abbr: str
    color: str
    paths: list[Path]       # candidates; first existing dir wins
    writable: bool = True
    sublabel: str = ""
    note: str = ""


PLATFORM_DEFS: list[PlatformDef] = [
    PlatformDef(
        id="cc", label="Claude Code", sublabel="personal",
        abbr="CC", color="#D4530E",
        paths=[_home(".claude", "skills")],
    ),
    PlatformDef(
        id="ccp", label="Claude Code", sublabel="project",
        abbr="CC", color="#D4530E",
        paths=[_cwd(".claude", "skills")],
    ),
    PlatformDef(
        id="cx", label="Codex CLI", abbr="CX", color="#10A37F",
        paths=[_home(".codex", "skills"), _home(".openai", "codex", "skills")],
    ),
    PlatformDef(
        id="gm", label="Gemini CLI", abbr="GM", color="#4285F4",
        paths=[_home(".gemini", "skills"), _home(".config", "gemini", "skills")],
    ),
    PlatformDef(
        id="oc", label="OpenCode", abbr="OC", color="#7C3AED",
        paths=[_home(".opencode", "skills")],
    ),
    PlatformDef(
        id="cu", label="Cursor", abbr="CU", color="#1A1A1A",
        paths=[_cwd(".cursor", "skills"), _home(".cursor", "skills")],
    ),
    PlatformDef(
        id="am", label="Amp", abbr="AM", color="#FF6B35",
        paths=[_home(".amp", "skills")],
    ),
    PlatformDef(
        id="ai", label="Claude.ai", sublabel="web", abbr="AI", color="#CC785C",
        paths=[], writable=False,
        note="Upload via Customize > Skills. Use Export ZIP to prepare.",
    ),
]

_extra_platforms: list[PlatformDef] = []

CONFIG_DIR = Path.home() / ".skillpop"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _load_config() -> dict:
    import json
    if CONFIG_FILE.is_file():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _save_config(data: dict) -> None:
    import json
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def load_custom_platforms() -> None:
    """Load persisted custom platforms on startup."""
    cfg = _load_config()
    for entry in cfg.get("custom_platforms", []):
        pid = entry.get("id", "")
        if pid and not any(p.id == pid for p in _extra_platforms):
            _extra_platforms.append(PlatformDef(
                id=pid, label=entry.get("label", pid),
                abbr=entry.get("label", pid)[:2].upper(),
                color="#888880",
                paths=[Path(entry.get("path", "")).expanduser()],
            ))


def add_custom_platform(pid: str, label: str, path: str, persist: bool = False) -> None:
    _extra_platforms[:] = [p for p in _extra_platforms if p.id != pid]
    _extra_platforms.append(PlatformDef(
        id=pid, label=label, abbr=label[:2].upper(),
        color="#888880", paths=[Path(path).expanduser()],
    ))
    if persist:
        cfg = _load_config()
        custom = cfg.get("custom_platforms", [])
        custom = [c for c in custom if c.get("id") != pid]
        custom.append({"id": pid, "label": label, "path": path})
        # Also remove from hidden if re-adding
        hidden = cfg.get("hidden_platforms", [])
        hidden = [h for h in hidden if h != pid]
        cfg["custom_platforms"] = custom
        cfg["hidden_platforms"] = hidden
        _save_config(cfg)


def remove_platform(pid: str) -> None:
    """Remove any platform — custom or built-in (hides built-in permanently)."""
    # Remove from custom list if present
    _extra_platforms[:] = [p for p in _extra_platforms if p.id != pid]
    cfg = _load_config()
    cfg["custom_platforms"] = [c for c in cfg.get("custom_platforms", []) if c.get("id") != pid]
    # If it's a built-in, add to hidden list
    if any(p.id == pid for p in PLATFORM_DEFS):
        hidden = cfg.get("hidden_platforms", [])
        if pid not in hidden:
            hidden.append(pid)
        cfg["hidden_platforms"] = hidden
    _save_config(cfg)


def all_platform_defs() -> list[PlatformDef]:
    hidden = _load_config().get("hidden_platforms", [])
    return [p for p in PLATFORM_DEFS if p.id not in hidden] + _extra_platforms


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class SkillEntry:
    """One skill on one platform."""
    name: str
    description: str
    directory: str          # dir name = skill identity
    platform_id: str
    content: str
    content_hash: str
    path: str = ""          # absolute path to skill dir
    files: list[str] = field(default_factory=list)


@dataclass
class PlatformInfo:
    """Resolved platform for API responses."""
    id: str
    label: str
    sublabel: str
    abbr: str
    color: str
    path: str | None
    present: bool
    writable: bool
    skill_count: int = 0
    note: str = ""
    custom: bool = False


@dataclass
class SkillGroup:
    """A skill across all platforms."""
    directory: str
    name: str
    description: str
    status: str             # synced | diverged | unique
    platform_ids: list[str] = field(default_factory=list)
    entries: list[SkillEntry] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Frontmatter parser
# ---------------------------------------------------------------------------

_FM_RE = re.compile(r"\A---\s*\n(.*?)\n---", re.DOTALL)


def parse_frontmatter(text: str) -> dict[str, str]:
    m = _FM_RE.match(text)
    if not m:
        return {}
    result: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            key, _, val = line.partition(":")
            result[key.strip()] = val.strip().strip('"').strip("'")
    return result


# ---------------------------------------------------------------------------
# Scanning
# ---------------------------------------------------------------------------

def _hash(content: str) -> str:
    return hashlib.sha256(content.encode()).hexdigest()[:12]


def _resolve_path(pdef: PlatformDef) -> Path | None:
    for candidate in pdef.paths:
        if candidate.is_dir():
            return candidate
    return None


def scan_platform(pdef: PlatformDef) -> tuple[PlatformInfo, list[SkillEntry]]:
    resolved = _resolve_path(pdef)
    info = PlatformInfo(
        id=pdef.id, label=pdef.label, sublabel=pdef.sublabel,
        abbr=pdef.abbr, color=pdef.color,
        path=str(resolved) if resolved else None,
        present=resolved is not None,
        writable=pdef.writable,
        note=pdef.note,
        custom=pdef in _extra_platforms,
    )
    entries: list[SkillEntry] = []
    if not resolved:
        return info, entries

    for child in sorted(resolved.iterdir()):
        skill_file = child / "SKILL.md"
        if not child.is_dir() or not skill_file.is_file():
            continue
        content = skill_file.read_text(encoding="utf-8", errors="replace")
        fm = parse_frontmatter(content)
        files = [
            str(f.relative_to(child))
            for f in child.rglob("*") if f.is_file()
        ]
        entries.append(SkillEntry(
            name=fm.get("name", child.name),
            description=fm.get("description", ""),
            directory=child.name,
            platform_id=pdef.id,
            content=content,
            content_hash=_hash(content),
            path=str(child),
            files=files,
        ))

    info.skill_count = len(entries)
    return info, entries


def scan_all() -> tuple[list[PlatformInfo], list[SkillGroup]]:
    all_entries: dict[str, list[SkillEntry]] = {}
    platforms: list[PlatformInfo] = []

    for pdef in all_platform_defs():
        info, entries = scan_platform(pdef)
        platforms.append(info)
        for e in entries:
            all_entries.setdefault(e.directory, []).append(e)

    groups: list[SkillGroup] = []
    for directory, entries in sorted(all_entries.items()):
        hashes = {e.content_hash for e in entries}
        if len(entries) == 1:
            status = "unique"
        else:
            status = "synced" if len(hashes) == 1 else "diverged"
        groups.append(SkillGroup(
            directory=directory,
            name=entries[0].name,
            description=entries[0].description,
            status=status,
            platform_ids=[e.platform_id for e in entries],
            entries=entries,
        ))

    return platforms, groups
