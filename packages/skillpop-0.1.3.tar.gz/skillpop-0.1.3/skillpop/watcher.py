"""Filesystem watcher — triggers rescan on skill file changes."""

from __future__ import annotations

import asyncio
import threading
from pathlib import Path
from typing import Any, Callable

from watchdog.events import FileSystemEventHandler, FileSystemEvent
from watchdog.observers import Observer


class _Handler(FileSystemEventHandler):
    def __init__(self, callback: Callable[[], None], debounce: float = 1.0):
        self._callback = callback
        self._debounce = debounce
        self._timer: threading.Timer | None = None

    def _schedule(self):
        if self._timer:
            self._timer.cancel()
        self._timer = threading.Timer(self._debounce, self._callback)
        self._timer.daemon = True
        self._timer.start()

    def on_any_event(self, event: FileSystemEvent):
        if event.is_directory:
            return
        src = str(getattr(event, "src_path", ""))
        if "SKILL.md" in src or src.endswith(".md"):
            self._schedule()


def start_watching(
    platforms: dict[str, dict[str, Any]],
    on_change: Callable[[], None],
) -> Observer:
    observer = Observer()
    for pinfo in platforms.values():
        p = pinfo.get("path")
        if p and Path(p).is_dir():
            observer.schedule(_Handler(on_change), str(p), recursive=True)
    observer.daemon = True
    observer.start()
    return observer
