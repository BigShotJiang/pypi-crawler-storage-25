"""CLI entry point — ``skillpop`` or ``python -m skillpop``."""

from __future__ import annotations

import argparse
import asyncio
import webbrowser
from pathlib import Path

import uvicorn

from . import __version__
from .scanner import add_custom_platform, all_platform_defs, load_custom_platforms
from .server import app, broadcast


def main():
    parser = argparse.ArgumentParser(
        prog="skillpop",
        description="Scan, diff & sync AI agent skills across platforms",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--port", type=int, default=7432)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument(
        "--add", action="append", metavar="id:label:path",
        help="Register a custom platform (repeatable)",
    )
    parser.add_argument(
        "--watch", action="store_true",
        help="Auto-rescan on filesystem changes",
    )
    args = parser.parse_args()

    # Load persisted custom platforms
    load_custom_platforms()

    # Register CLI custom platforms
    if args.add:
        for raw in args.add:
            parts = raw.split(":", 2)
            if len(parts) != 3:
                parser.error(f"Expected id:label:path, got '{raw}'")
            add_custom_platform(*parts)

    # Start filesystem watcher
    if args.watch:
        from .watcher import start_watching

        plat_dicts = {
            p.id: {"label": p.label, "path": p.paths[0] if p.paths else None}
            for p in all_platform_defs()
        }

        def _on_change():
            loop = asyncio.new_event_loop()
            loop.run_until_complete(broadcast("rescan"))
            loop.close()

        start_watching(plat_dicts, _on_change)
        print("[skillpop] watching for file changes …")

    if not args.no_browser:
        @app.on_event("startup")
        async def _open():
            webbrowser.open(f"http://127.0.0.1:{args.port}")

    print(f"[skillpop] starting on http://127.0.0.1:{args.port}")
    uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
