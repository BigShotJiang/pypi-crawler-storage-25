"""FastAPI server — REST endpoints + SSE for live updates."""

from __future__ import annotations

import asyncio
import difflib
import io
import json
import shutil
import sys
import subprocess
import tempfile
import zipfile
from dataclasses import asdict
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, StreamingResponse

from . import scanner

app = FastAPI(title="SkillPop")

_sse_subscribers: list[asyncio.Queue] = []
STATIC_DIR = Path(__file__).parent / "static"


# ---------------------------------------------------------------------------
# SSE
# ---------------------------------------------------------------------------

async def broadcast(event: str, data: str = ""):
    for q in list(_sse_subscribers):
        try:
            q.put_nowait(f"event: {event}\ndata: {data}\n\n")
        except asyncio.QueueFull:
            pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _find_platform(pid: str) -> scanner.PlatformDef | None:
    return next((p for p in scanner.all_platform_defs() if p.id == pid), None)


def _find_skill_dir(pdef: scanner.PlatformDef, directory: str) -> Path | None:
    resolved = scanner._resolve_path(pdef)
    if not resolved:
        return None
    d = resolved / directory
    return d if d.is_dir() and (d / "SKILL.md").is_file() else None


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def index():
    return (STATIC_DIR / "index.html").read_text(encoding="utf-8")


@app.get("/api/scan")
async def api_scan():
    platforms, groups = scanner.scan_all()
    return {
        "platforms": [
            {
                "id": p.id, "label": p.label, "sublabel": p.sublabel,
                "abbr": p.abbr, "color": p.color, "path": p.path,
                "present": p.present, "writable": p.writable,
                "skill_count": p.skill_count, "note": p.note,
                "custom": p.custom,
            }
            for p in platforms
        ],
        "skills": [
            {
                "directory": g.directory, "name": g.name,
                "description": g.description, "status": g.status,
                "platform_ids": g.platform_ids,
                "entries": [
                    {
                        "name": e.name, "description": e.description,
                        "directory": e.directory, "platform_id": e.platform_id,
                        "content_hash": e.content_hash, "path": e.path,
                        "files": e.files,
                    }
                    for e in g.entries
                ],
            }
            for g in groups
        ],
    }


@app.get("/api/skill/{platform_id}/{directory}")
async def api_skill_content(platform_id: str, directory: str):
    pdef = _find_platform(platform_id)
    if not pdef:
        raise HTTPException(404, "Platform not found")
    skill_dir = _find_skill_dir(pdef, directory)
    if not skill_dir:
        raise HTTPException(404, "Skill not found")
    content = (skill_dir / "SKILL.md").read_text(encoding="utf-8", errors="replace")
    return {"content": content, "path": str(skill_dir)}


@app.get("/api/diff/{directory}")
async def api_diff(directory: str):
    _, groups = scanner.scan_all()
    group = next((g for g in groups if g.directory == directory), None)
    if not group or len(group.entries) < 2:
        raise HTTPException(404, "Need 2+ versions to diff")

    diffs = []
    base = group.entries[0]
    for other in group.entries[1:]:
        udiff = list(difflib.unified_diff(
            base.content.splitlines(keepends=True),
            other.content.splitlines(keepends=True),
            fromfile=f"{base.platform_id}/{directory}/SKILL.md",
            tofile=f"{other.platform_id}/{directory}/SKILL.md",
            lineterm="",
        ))
        diffs.append({
            "from_platform": base.platform_id,
            "to_platform": other.platform_id,
            "lines": udiff,
        })
    return {"directory": directory, "diffs": diffs}


@app.post("/api/copy")
async def api_copy(body: dict):
    src_pid = body.get("src_platform")
    dst_pid = body.get("dst_platform")
    directory = body.get("directory")
    confirm = body.get("confirm", False)

    if not all([src_pid, dst_pid, directory]):
        raise HTTPException(400, "Missing fields")

    src_pdef = _find_platform(src_pid)
    dst_pdef = _find_platform(dst_pid)
    if not src_pdef or not dst_pdef:
        raise HTTPException(404, "Platform not found")
    if not dst_pdef.writable:
        raise HTTPException(400, f"{dst_pdef.label} is read-only")

    src_dir = _find_skill_dir(src_pdef, directory)
    if not src_dir:
        raise HTTPException(404, "Source skill not found")

    dst_root = scanner._resolve_path(dst_pdef)
    if not dst_root:
        dst_root = dst_pdef.paths[0]
        dst_root.mkdir(parents=True, exist_ok=True)
    dst_dir = dst_root / directory

    # Confirmation check for diverged overwrite
    if dst_dir.is_dir() and not confirm:
        src_hash = scanner._hash(
            (src_dir / "SKILL.md").read_text(encoding="utf-8", errors="replace")
        )
        dst_hash = scanner._hash(
            (dst_dir / "SKILL.md").read_text(encoding="utf-8", errors="replace")
        )
        if src_hash != dst_hash:
            return {
                "status": "confirm_required",
                "message": f"'{directory}' on {dst_pdef.label} has different content. Overwrite?",
            }

    if dst_dir.exists():
        shutil.rmtree(dst_dir)
    shutil.copytree(src_dir, dst_dir)
    await broadcast("rescan")
    return {"status": "ok", "message": f"Copied {directory} → {dst_pdef.label}"}


@app.post("/api/create")
async def api_create(body: dict):
    name = body.get("name", "").strip()
    description = body.get("description", "").strip()
    content = body.get("content", "").strip()
    target_pids: list[str] = body.get("platforms", [])

    if not name:
        raise HTTPException(400, "Name required")

    dirname = name.lower().replace(" ", "-")
    dirname = "".join(c for c in dirname if c.isalnum() or c in "-_")
    if not dirname:
        raise HTTPException(400, "Invalid name")

    if not content:
        content = f"---\nname: {name}\ndescription: {description}\n---\n\n# {name}\n\n{description}\n"

    created_on = []
    for pid in target_pids:
        pdef = _find_platform(pid)
        if not pdef or not pdef.writable:
            continue
        root = scanner._resolve_path(pdef)
        if not root:
            root = pdef.paths[0]
        skill_dir = root / dirname
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text(content, encoding="utf-8")
        created_on.append(pdef.label)

    await broadcast("rescan")
    return {"status": "ok", "directory": dirname, "created_on": created_on}


@app.get("/api/export")
async def api_export(skills: str = Query(...)):
    dirs = [d.strip() for d in skills.split(",") if d.strip()]
    if not dirs:
        raise HTTPException(400, "No skills")

    _, groups = scanner.scan_all()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for g in groups:
            if g.directory not in dirs:
                continue
            for entry in g.entries:
                skill_dir = Path(entry.path)
                if skill_dir.is_dir():
                    for fpath in skill_dir.rglob("*"):
                        if fpath.is_file():
                            zf.write(fpath, f"{entry.directory}/{fpath.relative_to(skill_dir)}")
                    break
    buf.seek(0)
    return StreamingResponse(
        buf, media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=skillpop-export.zip"},
    )


@app.post("/api/open-folder")
async def api_open_folder(body: dict):
    path = Path(body.get("path", ""))
    if not path.exists():
        raise HTTPException(404, "Path not found")
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        elif sys.platform == "win32":
            subprocess.Popen(["explorer", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass
    return {"ok": True}


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

@app.post("/api/import")
async def api_import(
    files: list[UploadFile] = File(...),
    platforms: str = Form("[]"),
):
    """Import SKILL.md files or ZIP archives containing skills."""
    target_pids = json.loads(platforms)
    if not target_pids:
        raise HTTPException(400, "No target platforms")

    imported = []
    for upload in files:
        data = await upload.read()
        filename = upload.filename or ""

        if filename.endswith(".zip"):
            # Extract ZIP — each top-level dir with SKILL.md is a skill
            with tempfile.TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                with zipfile.ZipFile(io.BytesIO(data)) as zf:
                    zf.extractall(tmp_path)
                # Find skill dirs (dirs containing SKILL.md)
                for candidate in tmp_path.iterdir():
                    if candidate.is_dir() and (candidate / "SKILL.md").is_file():
                        _deploy_skill_dir(candidate, target_pids)
                        imported.append(candidate.name)
                # Also handle flat ZIP (SKILL.md at root)
                if (tmp_path / "SKILL.md").is_file() and not imported:
                    dirname = filename.rsplit(".", 1)[0]
                    skill_dir = tmp_path / dirname
                    skill_dir.mkdir(exist_ok=True)
                    for f in tmp_path.iterdir():
                        if f.is_file():
                            shutil.copy2(f, skill_dir / f.name)
                    _deploy_skill_dir(skill_dir, target_pids)
                    imported.append(dirname)

        elif filename.endswith(".md"):
            # Single SKILL.md file
            content = data.decode("utf-8", errors="replace")
            fm = scanner.parse_frontmatter(content)
            dirname = fm.get("name", filename.rsplit(".", 1)[0])
            dirname = dirname.lower().replace(" ", "-")
            dirname = "".join(c for c in dirname if c.isalnum() or c in "-_") or "imported-skill"
            with tempfile.TemporaryDirectory() as tmp:
                skill_dir = Path(tmp) / dirname
                skill_dir.mkdir()
                (skill_dir / "SKILL.md").write_text(content, encoding="utf-8")
                _deploy_skill_dir(skill_dir, target_pids)
                imported.append(dirname)

    if not imported:
        return {"error": "No valid skills found in uploaded files"}

    await broadcast("rescan")
    return {"message": f"Imported: {', '.join(imported)}", "imported": imported}


def _deploy_skill_dir(src_dir: Path, target_pids: list[str]):
    """Copy a skill directory to all target platforms."""
    for pid in target_pids:
        pdef = _find_platform(pid)
        if not pdef or not pdef.writable:
            continue
        root = scanner._resolve_path(pdef)
        if not root:
            root = pdef.paths[0]
            root.mkdir(parents=True, exist_ok=True)
        dst = root / src_dir.name
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src_dir, dst)


# ---------------------------------------------------------------------------
# Custom platform config
# ---------------------------------------------------------------------------

@app.post("/api/config/platforms")
async def api_add_platform(body: dict):
    pid = body.get("id", "").strip()
    label = body.get("label", "").strip()
    path = body.get("path", "").strip()
    if not all([pid, label, path]):
        raise HTTPException(400, "id, label, path required")
    scanner.add_custom_platform(pid, label, path, persist=True)
    await broadcast("rescan")
    return {"ok": True}


@app.delete("/api/config/platforms/{platform_id}")
async def api_remove_platform(platform_id: str):
    scanner.remove_platform(platform_id)
    await broadcast("rescan")
    return {"ok": True}


# ---------------------------------------------------------------------------
# SSE
# ---------------------------------------------------------------------------

@app.get("/api/events")
async def api_events(request: Request):
    q: asyncio.Queue = asyncio.Queue(maxsize=64)
    _sse_subscribers.append(q)

    async def stream():
        try:
            yield "event: connected\ndata: ok\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    msg = await asyncio.wait_for(q.get(), timeout=30)
                    yield msg
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            _sse_subscribers.remove(q)

    return StreamingResponse(stream(), media_type="text/event-stream")
