"""SCORCH audit phases."""
