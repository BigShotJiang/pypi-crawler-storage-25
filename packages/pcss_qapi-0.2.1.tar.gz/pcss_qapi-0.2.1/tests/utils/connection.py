from pytest_httpserver.httpserver import HTTPServer
from pcss_qapi.api.auth.auth_service import AuthConfig
from pcss_qapi.api.connection_base import ApiConnection
from pcss_qapi import AuthorizationService


def get_test_connection(httpserver: HTTPServer) -> ApiConnection:
    AuthorizationService.config = AuthConfig(
        oauth_client_id="test",
        oauth_issuer=httpserver.url_for("/health"),
        oauth_min_ttl_seconds=60,
    )
    return ApiConnection(base_url=httpserver.url_for(""))
