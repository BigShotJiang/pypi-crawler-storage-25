import functools
from pathlib import Path

import pcss_qapi.utils.fs_manager as fs_manager
from pcss_qapi.api.auth.auth_service import AuthorizationService


def del_non_empty(path: Path):
    for file in path.iterdir():
        file = path / file
        if file.is_dir():
            del_non_empty(file)
        else:
            file.unlink()

    path.rmdir()


def inject_conf(func):
    """
    Change default storage conf file location so tests don't
    change .conf/api_configuration.json as it must remain the same
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        storage_dir = Path.cwd() / "dummy_key"
        cache = fs_manager.DEFAULT_USER_CONFIG_PATH
        fs_manager.DEFAULT_USER_CONFIG_PATH = storage_dir
        try:
            func(*args, **kwargs)
        finally:
            AuthorizationService.logout()
            if storage_dir.exists():
                del_non_empty(storage_dir)
            fs_manager.DEFAULT_USER_CONFIG_PATH = cache

    return wrapper
