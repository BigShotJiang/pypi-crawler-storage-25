"""Job ABCs"""

import json
from typing import Any
from abc import ABC, abstractmethod
from pcss_qapi.utils import FSManager

from pcss_qapi.api.connection_base import ApiConnection
from pcss_qapi.api.connections import PcssQapiConnection


class BaseRemoteJob(ABC):
    """Blueprint for an api remote job (non qiskit)"""

    def __init__(self, job_type: str) -> None:
        super().__init__()
        self.uid = None
        self.type = job_type  # Provider type

    @abstractmethod
    def _is_remote_available(self) -> bool:
        """Check if remote api is up"""

    @abstractmethod
    def _submit(self):
        """Submit job to remote"""

    @abstractmethod
    def _get_job_metadata(self) -> dict:
        """Additional metadata to save"""

    def _save_job(self):
        save_path = FSManager.get_task_directory(self.type)
        save_path.mkdir(parents=True, exist_ok=True)
        with open(save_path / f"{self.uid}.json", "w", encoding="UTF-8") as f:
            f.write(json.dumps(self._get_job_metadata()))

    def submit(self) -> None:
        """Submit job to remote"""
        if not self._is_remote_available():
            raise ValueError("Remote server is unreachable")
        self._submit()
        self._save_job()

    @property
    @abstractmethod
    def status(self) -> Any:
        """Task status"""

    @abstractmethod
    def results(self) -> Any:
        """Get task results"""

    @abstractmethod
    def cancel(self) -> bool:
        """Attempt to cancel task if it is queued, return True if successful"""


class BaseProvider(ABC):
    """Backend provider ABC"""

    def __init__(self, connection: ApiConnection = PcssQapiConnection) -> None:
        self.connection = connection
        self._http_client = connection.http_client()

    @abstractmethod
    def get_backend(self, backend_name) -> Any:
        """Get backend with the name of backend_name"""

    @abstractmethod
    def available_backends(self, simulators: bool = False) -> list[str]:
        """
        Return names of available backends for the authed user.

        Returns:
            list[str]: Backend names.
        """

    @abstractmethod
    def least_busy(self) -> Any:
        """
        Return least busy backend from the pool of **real** backends.

        Returns:
            object: Least busy backend.
        """
