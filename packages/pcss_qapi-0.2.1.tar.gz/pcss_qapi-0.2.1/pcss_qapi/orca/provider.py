"""Backend provider for ORCA devices"""

import json
import warnings

from pcss_qapi.orca.base import BaseProvider
from pcss_qapi.orca.orca_task import OrcaTask
from pcss_qapi.utils import FSManager
from pcss_qapi.utils.requests import raise_for_common

try:
    from pcss_qapi.orca.backend import OrcaBackend
except ImportError:
    from pcss_qapi.orca.mock_backend import OrcaBackend


class OrcaProvider(BaseProvider):
    """Backend provider for ORCA devices"""

    _task_type = "orca"

    def get_backend(self, backend_name: str) -> "OrcaBackend":
        return OrcaBackend(self.connection, backend_name)  # type: ignore

    def available_backends(self, simulators: bool = False):
        if simulators:
            if len(OrcaBackend.always_available_backends) == 0:
                warnings.warn("Simulators are only available with ptseries library.")
            return OrcaBackend.always_available_backends
        response = self._http_client.get("/machines")

        raise_for_common(response)
        return response.json().get("names", [])

    def least_busy(self) -> "OrcaBackend":
        response = self._http_client.get("/machines/queue-count")

        raise_for_common(response)
        queue_counts = response.json()
        return self.get_backend(min(self.available_backends(False), key=lambda x: queue_counts.get(x, 0)))

    @staticmethod
    def get_task_ids() -> list[str]:
        """Get ids of all submitted tasks linked to this provider"""
        save_dir = FSManager.get_task_directory(OrcaProvider._task_type)
        if not save_dir.exists():
            return []
        return [str(x.with_suffix("")) for x in save_dir.iterdir()]

    def get_task(self, task_id: str) -> OrcaTask:
        """Get OrcaTask by task id"""
        file = FSManager.get_task_directory(OrcaProvider._task_type) / f"{task_id}.json"
        meta = json.loads(file.read_text())

        task = OrcaTask(**meta, connection=self.connection)
        task._submitted = True  # pylint:disable = protected-access
        task.uid = task_id
        return task
