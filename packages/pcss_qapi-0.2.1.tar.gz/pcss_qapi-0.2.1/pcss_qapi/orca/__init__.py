"""ORCA Computing providers, backends, etc."""

import warnings

from pcss_qapi.utils.exceptions import MissingOptionalDependencyError
from .orca_task import OrcaTask
from .provider import OrcaProvider


__all__ = ["OrcaTask", "OrcaProvider"]

# We want OrcaTask and OrcaProvider to be available even without ptseries
try:
    from .backend import OrcaBackend

    __all__ += ["OrcaBackend"]
except MissingOptionalDependencyError as e:
    warnings.warn(e.msg)
