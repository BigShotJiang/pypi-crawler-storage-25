import time
from typing import Any
from uuid import UUID
import httpx
from qiskit import QuantumCircuit

from qiskit_aqt_provider import api_client
from qiskit_aqt_provider.api_client import models_direct as api_models_direct
from qiskit_aqt_provider.api_client.errors import http_response_raise_for_status
from qiskit_aqt_provider.aqt_job import AQTDirectAccessJob
from qiskit_aqt_provider.aqt_options import AQTDirectAccessOptions
from qiskit_aqt_provider.aqt_resource import AQTDirectAccessResource
from qiskit_aqt_provider.aqt_resource import _ResourceBase
from qiskit_aqt_provider import AQTProvider

from pcss_qapi.api.connections import PcssQapiConnection


class PCSS_AQTDirectAccessResource(AQTDirectAccessResource):
    def __init__(self) -> None:
        self._http_client = PcssQapiConnection.http_client()

        # TODO: Add automatically count available qubits
        # available_qubits = models_direct.NumIons.model_validate(
        #     http_response_raise_for_status(self._http_client.get("/status/ions")).json()
        # ).num_ions
        available_qubits = 6
        self.timeout = 1.0

        _ResourceBase.__init__(
            self,
            provider=AQTProvider("TOKEN"),
            name="direct-access",
            options_type=AQTDirectAccessOptions,
            available_qubits=available_qubits,
        )

    def run(self, circuits: QuantumCircuit | list[QuantumCircuit], **options: Any) -> AQTDirectAccessJob:
        return self._create_job(AQTDirectAccessJob, circuits, **options)

    def submit(self, circuit: api_client.models.QuantumCircuit) -> UUID:
        resp = http_response_raise_for_status(
            self._http_client.post(
                "/tasks",
                json={
                    "machine": "AQT",
                    "payload": circuit.model_dump(),
                },
            )
        )

        self.last_task_uid = resp.json()["uid"]
        return resp.json()["uid"]

    def result(self, job_id: UUID, *, timeout: float | None) -> api_models_direct.JobResult:
        while True:
            try:
                response = self._http_client.get(f"/tasks/{job_id}/results", timeout=self.timeout)
                if response.status_code == 200:
                    break
            except httpx.ReadTimeout:
                pass
            time.sleep(self.timeout)
        return api_models_direct.JobResult.model_validate({"job_id": job_id, "payload": response.json()})
