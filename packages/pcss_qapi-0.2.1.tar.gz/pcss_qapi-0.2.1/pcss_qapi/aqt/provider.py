from qiskit_aqt_provider.aqt_resource import AQTDirectAccessResource, AQTResource
from pcss_qapi.aqt.aqt_resource import PCSS_AQTDirectAccessResource


class PCSS_AQTProvider:
    """Provider for backends from Alpine Quantum Technologies (AQT)."""

    def __init__(self) -> None:
        self.name = "aqt_provider"

    def get_backend(self, name: str | None = None) -> AQTResource:
        """Return a handle for a cloud quantum computing resource matching the specified filtering.

        Args:
            name: filter for the backend name.
            backend_type: if given, restrict the search to the given backend type.
            workspace: if given, restrict to matching workspace IDs.
            available_qubits: only valid for ``offline_simulator``-type backends. If given,
              set the size of the quantum register to simulate.

        Returns:
            Backend: backend matching the filtering.

        Raises:
            QiskitBackendNotFoundError: if no backend could be found or
                more than one backend matches the filtering criteria.
        """
        # TODO: Fill this function
        raise NotImplementedError

    def get_direct_access_backend(self, /) -> AQTDirectAccessResource:
        """Return a handle for a direct-access quantum computing resource.

        Args:
            base_url: URL of the direct-access interface.
        """
        return PCSS_AQTDirectAccessResource()
