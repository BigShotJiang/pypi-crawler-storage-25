"""Connection definitions"""

from pcss_qapi.api.auth.auth_service import AuthorizationService, AuthConfig
from pcss_qapi.api.connection_base import ApiConnection

AuthorizationService.config = AuthConfig(
    oauth_client_id="jupyter.quantum.psnc.pl-notebooks",
    oauth_issuer="https://sso.classroom.pionier.net.pl/auth/realms/Classroom",
    oauth_min_ttl_seconds=60,
)

PcssQapiConnection = ApiConnection(
    base_url="https://api.quantum.psnc.pl/api/open",
    timeout=5.0,
)


__all__ = ["AuthorizationService", "PcssQapiConnection"]
