"""Connection base"""

from __future__ import annotations
from dataclasses import dataclass

import httpx
from pcss_qapi.api.auth import AuthorizationService


@dataclass(frozen=True)
class ApiConnection:
    """Base class for defining a new api connection"""

    base_url: str
    timeout: float = 5.0

    def __str__(self) -> str:
        return f"<{self.base_url.replace('https://', '').replace('http://', '').split('/', maxsplit=1)[0]}>"

    def __repr__(self) -> str:
        return str(self)

    def get_header(self) -> dict:
        """Returns Header for API Connection"""
        header = {"Content-Type": "application/json"}
        header |= AuthorizationService.get_header()
        return header

    def http_client(self) -> httpx.Client:
        """Returns HTTP Client"""
        return httpx.Client(headers=self.get_header(), base_url=self.base_url, timeout=5.0, follow_redirects=True)

    @property
    def tasks_url(self) -> str:
        """Tasks URL"""
        return f"{self.base_url}/tasks"
