"""Python client for pccs quantum api"""

from pcss_qapi.api import AuthorizationService

__all__ = ["AuthorizationService"]
