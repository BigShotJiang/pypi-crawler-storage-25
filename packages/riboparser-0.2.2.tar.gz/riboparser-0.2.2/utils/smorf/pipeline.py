# Author: Rensc
# date: 2026-05-21

"""
Main smORF pipeline.

This pipeline connects all functional modules:
1. Read genome FASTA.
2. Read genePred annotation.
3. Reconstruct transcript sequences.
4. Scan ORFs.
5. Classify ORFs.
6. Mark ORF overlaps.
7. Write output files.
"""

from .fasta import FastaParser
from .genepred import GenePredParser
from .coordinate import CoordinateMapper
from .scanner import ORFScanner
from .classifier import ORFClassifier
from .overlap import ORFOverlapMarker
from .writer import GenePredWriter, MessageWriter, FastaWriter


class SmORFPipeline:
    """
    High-level pipeline for transcript-centric smORF detection.
    """

    def __init__(
        self,
        genome: str,
        annotation: str,
        out_prefix: str = "ORF",
        orf_prefix: str = "ORF",
        start_codons: str = "ATG",
        min_aa: int = 8,
        max_aa: int = 10000,
        scan_strand: str = "sense",
        kozak_up: int = 6,
        kozak_down: int = 6,
        mark_overlap: bool = False,
        remove_discarded: bool = False,
        include_stop: bool = False,
    ):
        """
        Initialize smORF pipeline.

        Parameters
        ----------
        genome : str
            Genome FASTA file.
        annotation : str
            genePred annotation file.
        out_prefix : str
            Output file prefix.
        orf_prefix : str
            ORF ID prefix.
        start_codons : str
            Comma-separated start codons.
        min_aa : int
            Minimum ORF peptide length.
        max_aa : int
            Maximum ORF peptide length.
        scan_strand : str
            sense, antisense, or both.
        kozak_up : int
            Upstream length for Kozak-like sequence.
        kozak_down : int
            Downstream length after start codon.
        mark_overlap : bool
            Whether to mark nested and overlapping ORFs.
        remove_discarded : bool
            Whether to remove same-frame internal ORFs.
        include_stop : bool
            Whether to keep stop symbol in peptide output.
        """

        self.genome_path = genome
        self.annotation_path = annotation
        self.out_prefix = out_prefix
        self.orf_prefix = orf_prefix
        self.start_codons = [x.strip().upper() for x in start_codons.split(",")]
        self.min_aa = min_aa
        self.max_aa = max_aa
        self.scan_strand = scan_strand
        self.kozak_up = kozak_up
        self.kozak_down = kozak_down
        self.mark_overlap = mark_overlap
        self.remove_discarded = remove_discarded
        self.include_stop = include_stop
        self.records = []

    def run(self) -> None:
        """
        Run the complete smORF scanning pipeline.
        """

        genome = FastaParser.read_fasta(self.genome_path)
        transcripts = GenePredParser.read_genepred(self.annotation_path)

        scanner = ORFScanner(
            start_codons=self.start_codons,
            min_aa=self.min_aa,
            max_aa=self.max_aa,
            scan_strand=self.scan_strand,
            kozak_up=self.kozak_up,
            kozak_down=self.kozak_down,
            include_stop=self.include_stop,
        )

        orf_index = 1

        for tx in transcripts:
            # Print the current transcript being scanned.
            print(
                f"[smORFScanner] Scanning gene={tx.gene_id}, "
                f"transcript={tx.transcript_id}, "
                f"chrom={tx.chrom}, strand={tx.strand}",
                flush=True
            )
            
            # Reconstruct spliced transcript sequence before ORF scanning.
            CoordinateMapper.build_transcript_sequence(tx, genome)

            # Scan candidate ORFs from the transcript sequence.
            tx_records = scanner.scan_transcript(tx)

            # Assign ORF category labels.
            ORFClassifier.classify(tx, tx_records)

            # Mark nested or overlapping ORFs if requested.
            if self.mark_overlap:
                ORFOverlapMarker.mark(tx_records)

            # Assign stable ORF IDs.
            for rec in tx_records:
                rec.orf_id = f"{self.orf_prefix}{orf_index:08d}"
                orf_index += 1

            # Remove same-frame internal ORFs if requested.
            if self.remove_discarded:
                tx_records = [x for x in tx_records if x.priority != "discarded"]

            self.records.extend(tx_records)

        self.write_outputs()

    def write_outputs(self) -> None:
        """
        Write all output files.
        """

        GenePredWriter.write(f"{self.out_prefix}.genePred", self.records)
        MessageWriter.write(f"{self.out_prefix}.message.txt", self.records)
        FastaWriter.write_nt(f"{self.out_prefix}.nt.fa", self.records)
        FastaWriter.write_pep(f"{self.out_prefix}.pep.fa", self.records)
