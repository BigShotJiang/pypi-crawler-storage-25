# Author: Rensc
# date: 2026-05-21

"""
ORF category classifier.

Categories:
1. uORF: ORF fully located in 5' UTR.
2. dORF: ORF fully located in 3' UTR.
3. lncORF: ORF from non-coding transcript.
4. emORF: ORF extends the annotated CDS upstream and shares CDS end.
5. iORF: ORF fully inside CDS but in a different reading frame.
6. same_frame_iORF: ORF fully inside CDS and in the same frame.
7. overlap_uORF: ORF overlaps 5' UTR and CDS.
8. overlap_dORF: ORF overlaps CDS and 3' UTR.
9. antisense_ORF: ORF detected from antisense transcript sequence.
"""

from typing import List
from .models import Transcript, ORFRecord


class ORFClassifier:
    """
    Classify ORFs by relative position to annotated CDS.
    """

    @staticmethod
    def classify(tx: Transcript, records: List[ORFRecord]) -> None:
        """
        Assign category labels to ORF records.

        Parameters
        ----------
        tx : Transcript
            Source transcript.
        records : list
            List of ORFRecord objects.
        """

        for rec in records:
            # Antisense ORFs are not classified by sense CDS structure.
            if rec.source_strand == "antisense":
                rec.category = "antisense_ORF"
                continue

            # Transcripts without valid CDS are treated as non-coding transcripts.
            if not tx.is_coding() or tx.cds_tx_start is None or tx.cds_tx_end is None:
                rec.category = "lncORF"
                continue

            cds_start = tx.cds_tx_start
            cds_end = tx.cds_tx_end
            orf_start = rec.tx_orf_start
            orf_end = rec.tx_orf_end

            if orf_end <= cds_start:
                rec.category = "uORF"
            elif orf_start >= cds_end:
                rec.category = "dORF"
            elif orf_start < cds_start and orf_end == cds_end:
                rec.category = "emORF"
            elif orf_start >= cds_start and orf_end <= cds_end:
                cds_frame = (orf_start - cds_start) % 3

                if cds_frame == 0:
                    rec.category = "same_frame_iORF"
                    rec.priority = "discarded"
                else:
                    rec.category = "iORF"
            elif orf_start < cds_start and orf_end > cds_start:
                rec.category = "overlap_uORF"
            elif orf_start < cds_end and orf_end > cds_end:
                rec.category = "overlap_dORF"
            else:
                rec.category = "other_ORF"
