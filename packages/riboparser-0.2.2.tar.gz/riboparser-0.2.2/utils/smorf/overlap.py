# Author: Rensc
# date: 2026-05-21

"""
ORF overlap marker.

This module marks nested or partially overlapping ORFs within the same:
1. transcript
2. source strand
3. reading frame
"""

from typing import List
from .models import ORFRecord


class ORFOverlapMarker:
    """
    Mark nested and overlapping ORFs.
    """

    @staticmethod
    def mark(records: List[ORFRecord]) -> None:
        """
        Mark ORF overlap type and priority.

        A shorter ORF fully contained in a longer ORF with the same frame
        is marked as secondary.

        Parameters
        ----------
        records : list
            List of ORFRecord objects.
        """

        grouped = {}

        # Group ORFs by transcript, strand, and frame.
        for rec in records:
            key = (rec.transcript_id, rec.source_strand, rec.frame)
            grouped.setdefault(key, []).append(rec)

        for _, items in grouped.items():
            items.sort(key=lambda x: (x.tx_orf_start, -(x.tx_orf_end - x.tx_orf_start)))

            for i, rec in enumerate(items):
                for j, other in enumerate(items):
                    if i == j:
                        continue

                    is_nested = (
                        other.tx_orf_start <= rec.tx_orf_start
                        and other.tx_orf_end >= rec.tx_orf_end
                        and (other.tx_orf_end - other.tx_orf_start)
                        > (rec.tx_orf_end - rec.tx_orf_start)
                    )

                    if is_nested:
                        rec.priority = "secondary"
                        rec.overlap_type = "nested"
                        break

                # If the ORF is not nested, check partial overlap.
                if rec.priority == "primary":
                    for other in items:
                        if rec is other:
                            continue

                        is_overlap = (
                            rec.tx_orf_start < other.tx_orf_end
                            and rec.tx_orf_end > other.tx_orf_start
                        )

                        if is_overlap:
                            rec.overlap_type = "partial_overlap"
                            break
