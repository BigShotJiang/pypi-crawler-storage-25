"""DKE-Forge CLI — command tree for the code intelligence engine."""

import json
import os
import sys
import time

import click

from dke_forge.client import ForgeClient, ForgeError
from dke_forge import config
from dke_forge import format as fmt


def _make_client(ctx, timeout=120):
    return ForgeClient(ctx.obj["url"], ctx.obj["key"], timeout=timeout)


def _output(ctx, data, formatter):
    if ctx.obj["json"]:
        click.echo(fmt.as_json(data))
    else:
        click.echo(formatter(data))


# -- Top-level group with global error handling --


class ForgeGroup(click.Group):
    def invoke(self, ctx):
        try:
            return super().invoke(ctx)
        except ForgeError as e:
            if e.status_code == 401:
                click.echo(f"Error: {e.message}", err=True)
                click.echo(
                    "Run: dke-forge config set api_key <your-key>", err=True
                )
            elif e.status_code == 403:
                click.echo(f"Error: {e.message}", err=True)
                click.echo(
                    "Your tier does not include this feature.", err=True
                )
            else:
                click.echo(f"Error: {e.message}", err=True)
            sys.exit(1)


@click.group(cls=ForgeGroup)
@click.option("--url", envvar="DKE_FORGE_URL", help="API base URL")
@click.option("--key", envvar="DKE_FORGE_KEY", help="API key")
@click.option("--json", "json_output", is_flag=True, help="Raw JSON output")
@click.version_option(package_name="dke-forge")
@click.pass_context
def main(ctx, url, key, json_output):
    """DKE-Forge -- Code Intelligence Engine"""
    cfg = config.load()
    ctx.ensure_object(dict)
    ctx.obj["url"] = url or cfg.get("url", config.DEFAULT_URL)
    ctx.obj["key"] = key or cfg.get("api_key", "")
    ctx.obj["json"] = json_output


# ======================================================================
# health
# ======================================================================


@main.command()
@click.pass_context
def health(ctx):
    """Check server health."""
    result = _make_client(ctx).health()
    _output(ctx, result, fmt.health)


# ======================================================================
# register
# ======================================================================


@main.command()
@click.option("--email", required=True, prompt="Email")
@click.option("--name", required=True, prompt="Name")
@click.pass_context
def register(ctx, email, name):
    """Register for DKE-Forge beta."""
    result = _make_client(ctx).register(email, name)
    _output(ctx, result, fmt.register_result)


# ======================================================================
# auth
# ======================================================================


@main.group()
def auth():
    """Authentication commands."""
    pass


@auth.command("verify")
@click.pass_context
def auth_verify(ctx):
    """Verify your API key."""
    result = _make_client(ctx).auth_verify()
    _output(ctx, result, fmt.auth_info)


# ======================================================================
# graph
# ======================================================================


@main.group()
def graph():
    """Graph query commands (Tier 1: Oracle)."""
    pass


@graph.command("stats")
@click.pass_context
def graph_stats(ctx):
    """Show graph statistics."""
    result = _make_client(ctx).graph_stats()
    _output(ctx, result, fmt.stats)


@graph.command("function")
@click.argument("name")
@click.pass_context
def graph_function(ctx, name):
    """Look up a function by name."""
    result = _make_client(ctx).graph_function(name)
    _output(ctx, result, fmt.function_list)


@graph.command("callers")
@click.argument("name")
@click.option("--depth", default=2, help="Traversal depth")
@click.pass_context
def graph_callers(ctx, name, depth):
    """Find callers of a function."""
    result = _make_client(ctx).graph_callers(name, depth)
    _output(ctx, result, fmt.function_list)


@graph.command("callees")
@click.argument("name")
@click.option("--depth", default=2, help="Traversal depth")
@click.pass_context
def graph_callees(ctx, name, depth):
    """Find callees of a function."""
    result = _make_client(ctx).graph_callees(name, depth)
    _output(ctx, result, fmt.function_list)


@graph.command("depends")
@click.argument("name")
@click.pass_context
def graph_depends(ctx, name):
    """Show dependencies of a file or module."""
    result = _make_client(ctx).graph_depends(name)
    _output(ctx, result, fmt.depends)


@graph.command("impact")
@click.argument("name")
@click.option(
    "--change-type",
    type=click.Choice(["modify", "rename", "remove"]),
    default="modify",
    help="Type of change",
)
@click.pass_context
def graph_impact(ctx, name, change_type):
    """Analyze impact of changing a function."""
    result = _make_client(ctx).graph_impact(name, change_type)
    _output(ctx, result, fmt.impact)


@graph.command("rules")
@click.pass_context
def graph_rules(ctx):
    """List validation rules."""
    result = _make_client(ctx).graph_rules()
    _output(ctx, result, fmt.rules)


@graph.command("check")
@click.argument("name")
@click.pass_context
def graph_check(ctx, name):
    """Check a function against all rules."""
    result = _make_client(ctx).graph_check(name)
    _output(ctx, result, fmt.violations)


@graph.command("patterns")
@click.pass_context
def graph_patterns(ctx):
    """List learned structural patterns."""
    result = _make_client(ctx).graph_patterns()
    _output(ctx, result, fmt.pattern_list)


@graph.command("pattern")
@click.argument("id", type=int)
@click.pass_context
def graph_pattern(ctx, id):
    """Get details of a specific pattern."""
    result = _make_client(ctx).graph_pattern(id)
    _output(ctx, result, fmt.pattern_detail)


# ======================================================================
# envelope
# ======================================================================


@main.command()
@click.argument("name")
@click.option("--task", required=True, prompt="Task description")
@click.option("--max-context", type=int, help="Max context nodes")
@click.pass_context
def envelope(ctx, name, task, max_context):
    """Assemble a Forge envelope for a function (Tier 2)."""
    result = _make_client(ctx).envelope(name, task, max_context)
    _output(ctx, result, fmt.envelope)


# ======================================================================
# generate
# ======================================================================


@main.command()
@click.argument("name")
@click.option("--task", required=True, prompt="Task description")
@click.option(
    "--provider",
    type=click.Choice(["anthropic", "openai"]),
    help="LLM provider",
)
@click.option("--llm-key", envvar="DKE_FORGE_LLM_KEY", help="LLM API key")
@click.option("--model", help="Model name override")
@click.option("--retries", type=int, help="Max generation retries")
@click.option("--build-command", help="Build command for compilation check")
@click.pass_context
def generate(ctx, name, task, provider, llm_key, model, retries, build_command):
    """Run full Forge cycle: envelope + LLM + audit (Tier 3)."""
    cfg = config.load()
    provider = provider or cfg.get("llm_provider")
    llm_key = llm_key or cfg.get("llm_key")
    if not provider:
        provider = click.prompt(
            "LLM provider", type=click.Choice(["anthropic", "openai"])
        )
    if not llm_key:
        llm_key = click.prompt("LLM API key", hide_input=True)
    result = _make_client(ctx, timeout=600).generate(
        name, task, provider, llm_key, model, retries, build_command
    )
    _output(ctx, result, fmt.generate_result)


# ======================================================================
# scan
# ======================================================================


@main.command()
@click.argument("path")
@click.option("--commit", help="Commit SHA to record")
@click.option(
    "--poll-interval",
    type=float,
    default=2.0,
    show_default=True,
    help="Seconds between status polls",
)
@click.option(
    "--no-wait",
    is_flag=True,
    help="Return the scan_id immediately; don't poll for completion",
)
@click.pass_context
def scan(ctx, path, commit, poll_interval, no_wait):
    """Scan a repository path on the server (Tier 3).

    The server accepts the scan asynchronously and processes files in the
    background. By default this command polls for completion; pass
    ``--no-wait`` to return the scan_id immediately.
    """
    client = _make_client(ctx)
    started = client.scan(path, commit)
    scan_id = started.get("scan_id", "")

    if no_wait:
        _output(ctx, started, fmt.scan_started)
        return

    json_mode = ctx.obj["json"]
    if not json_mode:
        click.echo(fmt.scan_started(started))

    while True:
        status = client.scan_status(scan_id)
        state = status.get("status", "unknown")
        if state in ("complete", "error"):
            if not json_mode:
                click.echo("")  # end the progress line
            _output(ctx, status, fmt.scan_status)
            if state == "error":
                sys.exit(1)
            return
        if not json_mode:
            processed = status.get("files_processed", 0)
            total = status.get("total_files", 0)
            sys.stdout.write(
                f"\r  Progress: {processed}/{total} files — {state}  "
            )
            sys.stdout.flush()
        time.sleep(poll_interval)


@main.command("scan-status")
@click.argument("scan_id")
@click.pass_context
def scan_status(ctx, scan_id):
    """Get the status of an async scan by ID."""
    result = _make_client(ctx).scan_status(scan_id)
    _output(ctx, result, fmt.scan_status)


# ======================================================================
# embed  /  embed-status  /  search   (Wave 1 / FG-29)
# ======================================================================


_EMBED_MODES = ("local", "byok", "managed")
_EMBED_PROVIDERS = ("ollama", "openai", "voyage")


@main.command()
@click.option(
    "--mode",
    type=click.Choice(_EMBED_MODES),
    default="local",
    show_default=True,
    help="Key delivery mode",
)
@click.option(
    "--provider",
    type=click.Choice(_EMBED_PROVIDERS),
    help="Embedding provider (default: ollama for local)",
)
@click.option("--model", help="Model name override (e.g. text-embedding-3-large)")
@click.option("--dim", type=int, help="Embedding dimension override")
@click.option(
    "--llm-key",
    help="BYOK API key (overrides stored key)",
)
@click.option(
    "--poll-interval",
    type=float,
    default=2.0,
    show_default=True,
    help="Seconds between status polls",
)
@click.option(
    "--no-wait",
    is_flag=True,
    help="Return the job_id immediately; don't poll for completion",
)
@click.pass_context
def embed(ctx, mode, provider, model, dim, llm_key, poll_interval, no_wait):
    """Embed the tenant's Function nodes for semantic search (Tier 3).

    Spawns a server-side worker that iterates every Function node in the
    tenant's graph, embeds ``signature + docstring`` via the chosen
    ``--mode`` / ``--provider``, and writes the vectors to the tenant's
    per-graph HNSW sidecar. Use ``dke-forge search <query>`` afterward.
    """
    client = _make_client(ctx)
    started = client.embed_async(
        mode=mode,
        provider=provider,
        model=model,
        dim=dim,
        llm_key=llm_key,
    )
    job_id = started.get("job_id", "")

    if no_wait:
        _output(ctx, started, fmt.embed_started)
        return

    json_mode = ctx.obj["json"]
    if not json_mode:
        click.echo(fmt.embed_started(started))

    while True:
        status = client.embed_status(job_id)
        state = status.get("status", "unknown")
        if state in ("complete", "error"):
            if not json_mode:
                click.echo("")  # end progress line
            _output(ctx, status, fmt.embed_status)
            if state == "error":
                sys.exit(1)
            return
        if not json_mode:
            processed = status.get("functions_processed", 0)
            total = status.get("total_functions", 0)
            sys.stdout.write(
                f"\r  Progress: {processed}/{total} functions — {state}  "
            )
            sys.stdout.flush()
        time.sleep(poll_interval)


@main.command("embed-status")
@click.argument("job_id")
@click.pass_context
def embed_status_cmd(ctx, job_id):
    """Get the status of an async embed job by ID."""
    result = _make_client(ctx).embed_status(job_id)
    _output(ctx, result, fmt.embed_status)


@main.command()
@click.argument("query")
@click.option("--top-k", "-k", type=int, default=10, show_default=True)
@click.option(
    "--mode",
    type=click.Choice(_EMBED_MODES),
    default="local",
    show_default=True,
)
@click.option(
    "--provider",
    type=click.Choice(_EMBED_PROVIDERS),
    help="Embedding provider (default: ollama for local)",
)
@click.option("--model", help="Model name override")
@click.option(
    "--no-expand",
    is_flag=True,
    help="Skip graph-expand (callers/callees/types)",
)
@click.pass_context
def search(ctx, query, top_k, mode, provider, model, no_expand):
    """Semantic-search the tenant's embedded Function index (Tier 1).

    Returns the top-k cosine-similar functions with provenance metadata
    and, by default, the graph layer attached to each hit
    (callers, callees, UsesType neighbors).
    """
    result = _make_client(ctx).graph_semantic_search(
        query=query,
        top_k=top_k,
        mode=mode,
        provider=provider,
        model=model,
        expand=not no_expand,
    )
    _output(ctx, result, fmt.semantic_search)


# ======================================================================
# Architecture Suite (Wave 1 / FG-30)
# ======================================================================


_CIRCULAR_DEPS_SCOPES = ("all", "file", "module", "library")
_DATA_FLOW_DIRECTIONS = ("forward", "backward", "both")


@main.command("circular-deps")
@click.option(
    "--scope",
    type=click.Choice(_CIRCULAR_DEPS_SCOPES),
    help="Cycle scope (default: all).",
)
@click.option("--max-cycles", type=int, help="Cap on cycles returned.")
@click.option("--max-length", type=int, help="Cap on cycle length.")
@click.pass_context
def analysis_circular_deps(ctx, scope, max_cycles, max_length):
    """Cycles in DependsOn + Includes edges (Tier 1)."""
    result = _make_client(ctx).analysis_circular_deps(scope, max_cycles, max_length)
    _output(ctx, result, fmt.circular_deps)


@main.command("god-classes")
@click.option(
    "--threshold",
    type=int,
    help="Minimum combined outgoing degree (default: 20).",
)
@click.pass_context
def analysis_god_classes(ctx, threshold):
    """Types with excessive outgoing edges (Tier 1)."""
    result = _make_client(ctx).analysis_god_classes(threshold)
    _output(ctx, result, fmt.god_classes)


@main.command("architecture-map")
@click.option("--top-n", type=int, help="Number of top nodes to return.")
@click.option(
    "--damping",
    type=float,
    help="PageRank damping factor, must be in (0, 1).",
)
@click.option("--max-iterations", type=int, help="PageRank iteration cap.")
@click.option("--tolerance", type=float, help="Convergence tolerance.")
@click.pass_context
def analysis_architecture_map(ctx, top_n, damping, max_iterations, tolerance):
    """Top-N most-central nodes by PageRank (Tier 2)."""
    result = _make_client(ctx).analysis_architecture_map(
        top_n, damping, max_iterations, tolerance,
    )
    _output(ctx, result, fmt.architecture_map)


@main.command("api-surface")
@click.option("--module-id", type=int, help="Module node ID.")
@click.option("--module-name", help="Module name.")
@click.pass_context
def analysis_api_surface(ctx, module_id, module_name):
    """Auto-detected public boundary for a module (Tier 1)."""
    if module_id is None and module_name is None:
        click.echo(
            "Error: pass --module-id or --module-name", err=True,
        )
        sys.exit(2)
    result = _make_client(ctx).analysis_api_surface(module_id, module_name)
    _output(ctx, result, fmt.api_surface)


@main.command("abstractions")
@click.option(
    "--min-group-size",
    type=int,
    help="Minimum cluster size, must be >= 2 (default: 3).",
)
@click.pass_context
def analysis_abstractions(ctx, min_group_size):
    """Candidate interfaces from shared method shapes (Tier 2)."""
    result = _make_client(ctx).analysis_abstractions(min_group_size)
    _output(ctx, result, fmt.abstractions)


@main.command("data-flow")
@click.option("--source-id", type=int, help="Source node ID (uint64).")
@click.option("--source-name", help="Source function name.")
@click.option("--max-depth", type=int, help="BFS depth cap (default: 5).")
@click.option(
    "--direction",
    type=click.Choice(_DATA_FLOW_DIRECTIONS),
    help="Traversal direction (default: forward).",
)
@click.option(
    "--paths",
    "include_paths",
    is_flag=True,
    help="Include edge-labeled paths for each reached node.",
)
@click.pass_context
def analysis_data_flow(
    ctx, source_id, source_name, max_depth, direction, include_paths,
):
    """Taint-track via Calls + HasParam + UsesType edges (Tier 2)."""
    if source_id is None and source_name is None:
        click.echo(
            "Error: pass --source-id or --source-name", err=True,
        )
        sys.exit(2)
    result = _make_client(ctx).analysis_data_flow(
        source_id=source_id,
        source_name=source_name,
        max_depth=max_depth,
        direction=direction,
        include_paths=include_paths or None,
    )
    _output(ctx, result, fmt.data_flow)


@main.command("module-topology")
@click.pass_context
def analysis_module_topology(ctx):
    """High-level module + dependency graph (Tier 1)."""
    result = _make_client(ctx).analysis_module_topology()
    _output(ctx, result, fmt.module_topology)


# ======================================================================
# change suite (Wave 2 / FG-32)
# ======================================================================


@main.command("refactor-preview")
@click.option("--symbol", "symbol_name", required=True, help="Symbol to rename.")
@click.option("--new-name", required=True, help="Proposed new name.")
@click.option("--kind", help="Optional NodeType filter (Function|Type|Variable|...)")
@click.pass_context
def change_refactor_preview(ctx, symbol_name, new_name, kind):
    """Preview the impact of a rename (Tier 1)."""
    result = _make_client(ctx).change_refactor_preview(symbol_name, new_name, kind)
    _output(ctx, result, fmt.refactor_preview)


@main.command("breaking-change")
@click.option("--symbol", "symbol_name", required=True, help="Symbol whose signature changes.")
@click.option("--return-type", "new_return_type", required=True, help="Proposed return type.")
@click.option(
    "--param-type",
    "new_param_types",
    multiple=True,
    help="Proposed param type (pass once per parameter, in order).",
)
@click.pass_context
def change_breaking_change(ctx, symbol_name, new_return_type, new_param_types):
    """Analyze a signature change (Tier 1)."""
    result = _make_client(ctx).change_breaking_change(
        symbol_name, new_return_type, list(new_param_types),
    )
    _output(ctx, result, fmt.breaking_change)


@main.command("deprecation-path")
@click.option("--symbol", "symbol_name", required=True, help="Symbol to deprecate.")
@click.option("--kind", help="Optional NodeType filter (Function|Type|Variable|...)")
@click.option("--max-depth", type=int, help="Reverse-dep closure depth cap (default 100).")
@click.pass_context
def change_deprecation_path(ctx, symbol_name, kind, max_depth):
    """Plan a staged deprecation (Tier 2)."""
    result = _make_client(ctx).change_deprecation_path(symbol_name, kind, max_depth)
    _output(ctx, result, fmt.deprecation_path)


@main.command("risky")
@click.option("--commit", required=True, help="Commit SHA to score.")
@click.pass_context
def change_risky(ctx, commit):
    """Risk score for a commit tag (Tier 2)."""
    result = _make_client(ctx).change_risky(commit)
    _output(ctx, result, fmt.risky_change)


@main.command("commit-impact")
@click.option("--commit", required=True, help="Commit SHA to analyze.")
@click.pass_context
def change_commit_impact(ctx, commit):
    """Structural impact of a commit (Tier 1)."""
    result = _make_client(ctx).change_commit_impact(commit)
    _output(ctx, result, fmt.commit_impact)


@main.command("review")
@click.option("--commit", required=True, help="Commit SHA to review.")
@click.option(
    "--focus-area-top-n",
    type=int,
    help="Cap on recommended focus areas (default 5; 0 = unlimited).",
)
@click.pass_context
def change_review(ctx, commit, focus_area_top_n):
    """Composite commit review (Tier 2)."""
    result = _make_client(ctx).change_review(commit, focus_area_top_n)
    _output(ctx, result, fmt.commit_review)


# ======================================================================
# ingest
# ======================================================================


@main.command()
@click.argument("files", nargs=-1, required=True, type=click.Path(exists=True))
@click.option("--commit", help="Commit SHA to record")
@click.pass_context
def ingest(ctx, files, commit):
    """Upload and ingest C++ files (Tier 3)."""
    file_list = []
    for path in files:
        with open(path) as f:
            file_list.append({"path": path, "content": f.read()})
    result = _make_client(ctx, timeout=300).ingest(file_list, commit)
    _output(ctx, result, fmt.ingest_result)


# ======================================================================
# config
# ======================================================================


@main.group("config")
def config_group():
    """Manage local configuration."""
    pass


@config_group.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key, value):
    """Set a config value (url, api_key, llm_provider, llm_key, model)."""
    try:
        config.set_value(key, value)
        click.echo(f"Set {key}")
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@config_group.command("show")
def config_show():
    """Show current configuration."""
    cfg = config.load()
    if not cfg:
        click.echo("No configuration set.")
        click.echo(f"Config file: {config.CONFIG_FILE}")
        return
    for k, v in sorted(cfg.items()):
        if "key" in k.lower():
            display = v[:8] + "..." if len(v) > 8 else "***"
        else:
            display = v
        click.echo(f"  {k}: {display}")
    click.echo(f"\nConfig file: {config.CONFIG_FILE}")


# ======================================================================
# admin
# ======================================================================


@main.group()
def admin():
    """Admin commands (requires admin key)."""
    pass


@admin.command("create-tenant")
@click.option("--name", required=True, prompt="Tenant name")
@click.option(
    "--tier",
    type=int,
    help="Tier level (1=Oracle, 2=Envelope, 3=Cycle)",
)
@click.pass_context
def admin_create_tenant(ctx, name, tier):
    """Create a new tenant."""
    result = _make_client(ctx).admin_create_tenant(name, tier)
    _output(ctx, result, fmt.tenant_created)


@admin.command("list-tenants")
@click.pass_context
def admin_list_tenants(ctx):
    """List all tenants."""
    result = _make_client(ctx).admin_list_tenants()
    _output(ctx, result, fmt.tenant_list)


@admin.command("revoke-tenant")
@click.argument("tenant_id")
@click.pass_context
def admin_revoke_tenant(ctx, tenant_id):
    """Revoke a tenant's API key."""
    result = _make_client(ctx).admin_revoke_tenant(tenant_id)
    _output(ctx, result, fmt.tenant_revoked)


@admin.command("learn-patterns")
@click.option("--threshold", type=float, help="Similarity threshold")
@click.option("--min-exemplars", type=int, help="Minimum exemplars")
@click.pass_context
def admin_learn_patterns(ctx, threshold, min_exemplars):
    """Run pattern learning on shared graph."""
    result = _make_client(ctx).admin_learn_patterns(threshold, min_exemplars)
    _output(ctx, result, fmt.patterns_learned)
