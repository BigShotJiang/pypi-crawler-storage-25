"""FastMCP server for DKE-Forge — 43 tools over ForgeClient.

Each ``@mcp.tool()`` function delegates to a ``ForgeClient`` method via
``asyncio.to_thread``, keeping the stdio JSON-RPC loop responsive while
the synchronous ``requests``-based client runs on a worker thread.

Configuration resolution order (matches CLI conventions, with MCP-specific
env var names):

1. Environment: ``FORGE_URL`` / ``FORGE_API_KEY``
2. Local config file: ``~/.config/dke-forge/config.json``
3. Built-in default URL; empty API key

Category tags are carried as a ``[Category]`` prefix in each tool's
description (the portable surface today — MCP annotations don't yet have a
formal ``category`` field).
"""

import asyncio
import os
import sys
from typing import Any, Dict, List, Optional, Union

from mcp.server.fastmcp import FastMCP

from dke_forge import config as _config
from dke_forge.client import ForgeClient, ForgeError


# -- Module state --------------------------------------------------------

_client: Optional[ForgeClient] = None


def _resolve_config():
    """Return ``(url, api_key)`` resolved from env → config → default."""
    cfg = _config.load()
    url = os.environ.get("FORGE_URL") or cfg.get("url") or _config.DEFAULT_URL
    api_key = os.environ.get("FORGE_API_KEY") or cfg.get("api_key", "")
    return url, api_key


mcp = FastMCP("dke-forge")


# -- Foundation ----------------------------------------------------------

@mcp.tool()
async def forge_graph_stats() -> Dict[str, Any]:
    """[Foundation] Graph statistics — node/edge counts, language breakdown, last ingest."""
    return await asyncio.to_thread(_client.graph_stats)


# -- Navigation ----------------------------------------------------------

@mcp.tool()
async def forge_query_function(name: str) -> List[Dict[str, Any]]:
    """[Navigation] Look up a function by name (cross-language)."""
    return await asyncio.to_thread(_client.graph_function, name)


@mcp.tool()
async def forge_callers_of(name: str, depth: int = 2) -> List[Dict[str, Any]]:
    """[Navigation] Callers of a function, transitively up to ``depth`` hops."""
    return await asyncio.to_thread(_client.graph_callers, name, depth)


@mcp.tool()
async def forge_callees_of(name: str, depth: int = 2) -> List[Dict[str, Any]]:
    """[Navigation] Functions called by ``name``, transitively up to ``depth`` hops."""
    return await asyncio.to_thread(_client.graph_callees, name, depth)


@mcp.tool()
async def forge_depends_on(path: str) -> Dict[str, Any]:
    """[Navigation] Dependencies of a file or module path."""
    return await asyncio.to_thread(_client.graph_depends, path)


@mcp.tool()
async def forge_impact_analysis(name: str, change_type: str = "modify") -> Dict[str, Any]:
    """[Navigation] Impact of changing a function. ``change_type``: modify | rename | remove."""
    return await asyncio.to_thread(_client.graph_impact, name, change_type)


@mcp.tool()
async def forge_callgraph_reachable(
    name: str, via: Optional[str] = None
) -> List[Dict[str, Any]]:
    """[Navigation] Transitively reachable functions from an entry point.

    Optional ``via`` restricts traversal to an edge label (e.g. ``Implements``).
    """
    return await asyncio.to_thread(_client.graph_reachable, name, via)


@mcp.tool()
async def forge_find_implementers(name: str) -> List[Dict[str, Any]]:
    """[Navigation] All implementers / subclasses of a type or interface."""
    return await asyncio.to_thread(_client.graph_implementers, name)


# -- Architecture --------------------------------------------------------

@mcp.tool()
async def forge_dead_code(exclude_tests: bool = True) -> List[Dict[str, Any]]:
    """[Architecture] Functions with no incoming Calls edges. Test files excluded by default."""
    return await asyncio.to_thread(_client.graph_dead_code, exclude_tests)


@mcp.tool()
async def forge_subgraph(
    module: Optional[str] = None,
    type: Optional[str] = None,
    functions: Optional[Union[List[str], str]] = None,
    max_depth: Optional[int] = None,
) -> Dict[str, Any]:
    """[Architecture] Focused subgraph by module, type, or a list of function names.

    ``functions`` accepts either a list or a comma-joined string.
    """
    kwargs: Dict[str, Any] = {}
    if module is not None:
        kwargs["module"] = module
    if type is not None:
        kwargs["type"] = type
    if functions is not None:
        kwargs["functions"] = functions
    if max_depth is not None:
        kwargs["max_depth"] = max_depth
    return await asyncio.to_thread(_client.graph_subgraph, **kwargs)


# -- Architecture Suite (Wave 1 / FG-30) ---------------------------------

@mcp.tool()
async def forge_circular_deps(
    scope: Optional[str] = None,
    max_cycles: Optional[int] = None,
    max_length: Optional[int] = None,
) -> Dict[str, Any]:
    """[Architecture] Cycles in DependsOn + Includes (Tier 1).

    ``scope`` is ``"all"`` | ``"file"`` | ``"module"`` | ``"library"``.
    ``max_cycles`` / ``max_length`` cap the result on pathological graphs.
    """
    return await asyncio.to_thread(
        _client.analysis_circular_deps, scope, max_cycles, max_length,
    )


@mcp.tool()
async def forge_god_classes(
    threshold: Optional[int] = None,
) -> Dict[str, Any]:
    """[Architecture] Types with excessive outgoing edges (Tier 1).

    ``threshold`` sets the minimum combined outgoing degree (default 20).
    """
    return await asyncio.to_thread(_client.analysis_god_classes, threshold)


@mcp.tool()
async def forge_architecture_map(
    top_n: Optional[int] = None,
    damping: Optional[float] = None,
    max_iterations: Optional[int] = None,
    tolerance: Optional[float] = None,
) -> Dict[str, Any]:
    """[Architecture] Top-N most-central nodes by PageRank (Tier 2).

    ``damping`` must be in ``(0, 1)``. Defaults: α=0.85, 50 iter, 1e-6 tol.
    """
    return await asyncio.to_thread(
        _client.analysis_architecture_map,
        top_n, damping, max_iterations, tolerance,
    )


@mcp.tool()
async def forge_api_surface(
    module_id: Optional[int] = None,
    module_name: Optional[str] = None,
) -> Dict[str, Any]:
    """[Architecture] Auto-detected public boundary for a module (Tier 1).

    Pass ``module_id`` (uint64) or ``module_name``; 404 when not found.
    """
    return await asyncio.to_thread(
        _client.analysis_api_surface, module_id, module_name,
    )


@mcp.tool()
async def forge_abstractions(
    min_group_size: Optional[int] = None,
) -> Dict[str, Any]:
    """[Architecture] Candidate interfaces from shared method shapes (Tier 2).

    ``min_group_size`` must be ``>= 2`` (default 3).
    """
    return await asyncio.to_thread(
        _client.analysis_abstractions, min_group_size,
    )


@mcp.tool()
async def forge_data_flow(
    source_id: Optional[int] = None,
    source_name: Optional[str] = None,
    max_depth: Optional[int] = None,
    direction: Optional[str] = None,
    include_paths: Optional[bool] = None,
) -> Dict[str, Any]:
    """[Architecture] Taint-tracking BFS over Calls + HasParam + UsesType (Tier 2).

    Pass ``source_id`` (uint64) or ``source_name``. ``direction`` is
    ``"forward"`` (default) | ``"backward"`` | ``"both"``.
    ``include_paths=True`` attaches the full edge-labeled paths.
    """
    return await asyncio.to_thread(
        _client.analysis_data_flow,
        source_id, source_name, max_depth, direction, include_paths,
    )


@mcp.tool()
async def forge_module_topology() -> Dict[str, Any]:
    """[Architecture] High-level Module-Module dep graph with edge-count weights (Tier 1)."""
    return await asyncio.to_thread(_client.analysis_module_topology)


# -- Change Suite (Wave 2 / FG-32) ---------------------------------------

@mcp.tool()
async def forge_refactor_preview(
    symbol_name: str,
    new_name: str,
    kind: Optional[str] = None,
) -> Dict[str, Any]:
    """[Change] Preview the impact of renaming a symbol (Tier 1).

    Returns affected callers, tests, and files plus any rule conflicts
    triggered by the new name. ``kind`` is an optional ``NodeType`` filter
    (``"Function"`` | ``"Type"`` | ``"Variable"`` ...) when the symbol is
    ambiguous.
    """
    return await asyncio.to_thread(
        _client.change_refactor_preview, symbol_name, new_name, kind,
    )


@mcp.tool()
async def forge_breaking_change(
    symbol_name: str,
    new_return_type: str,
    new_param_types: List[str],
) -> Dict[str, Any]:
    """[Change] Analyze a function-signature change (Tier 1).

    ``new_param_types`` is an ordered list of parameter-type strings.
    Returns affected callers with per-caller mismatch descriptions,
    the breaking test set, and reasoner contradictions against the
    proposed signature.
    """
    return await asyncio.to_thread(
        _client.change_breaking_change,
        symbol_name, new_return_type, new_param_types,
    )


@mcp.tool()
async def forge_deprecation_path(
    symbol_name: str,
    kind: Optional[str] = None,
    max_depth: Optional[int] = None,
) -> Dict[str, Any]:
    """[Change] Staged deprecation plan — migrate-then-remove ordering (Tier 2).

    Walks the canonical reverse-dep edge set
    (``Calls + DependsOn + UsesType + InheritsFrom``) via the cascade
    reasoner. ``max_depth`` caps the closure (default 100; 0 = seed only).
    """
    return await asyncio.to_thread(
        _client.change_deprecation_path, symbol_name, kind, max_depth,
    )


@mcp.tool()
async def forge_risky_change(commit: str) -> Dict[str, Any]:
    """[Change] Risk score for a commit tag (Tier 2).

    Composite of thermal mean + pattern-drift rate + rule-violation rate
    across nodes tagged with the commit SHA. Returns ``score`` plus a
    ``breakdown`` with the three components and the node/rule/pattern
    violation lists.
    """
    return await asyncio.to_thread(_client.change_risky, commit)


@mcp.tool()
async def forge_commit_impact(commit: str) -> Dict[str, Any]:
    """[Change] Structural impact of a commit tag (Tier 1).

    Returns ``{commit_sha, touched_count, touched_node_ids,
    cascade_summary, contradictions}``. ``cascade_summary`` has
    ``total_direct``, ``total_transitive``, ``modules_affected``,
    ``files_affected``.
    """
    return await asyncio.to_thread(_client.change_commit_impact, commit)


@mcp.tool()
async def forge_review(
    commit: str,
    focus_area_top_n: Optional[int] = None,
) -> Dict[str, Any]:
    """[Change] Composite commit review (Tier 2).

    Wraps structural impact with pattern-alignment + rule-violation
    summaries and a ranked list of recommended focus areas.
    ``focus_area_top_n`` caps the focus-area list (default 5; 0 = unlimited).
    """
    return await asyncio.to_thread(
        _client.change_review, commit, focus_area_top_n,
    )


# -- Rules ---------------------------------------------------------------

@mcp.tool()
async def forge_rules() -> List[Dict[str, Any]]:
    """[Rules] List all configured validation rules."""
    return await asyncio.to_thread(_client.graph_rules)


@mcp.tool()
async def forge_check_rules(name: str) -> List[Dict[str, Any]]:
    """[Rules] Check a function against every rule; returns violations only."""
    return await asyncio.to_thread(_client.graph_check, name)


# -- Provenance ----------------------------------------------------------

@mcp.tool()
async def forge_contradictions() -> List[Dict[str, Any]]:
    """[Provenance] ForgeReasoner-detected contradictions in the current graph."""
    return await asyncio.to_thread(_client.graph_contradictions)


@mcp.tool()
async def forge_last_modified(name: str) -> Dict[str, Any]:
    """[Provenance] Last-commit tag for the named node."""
    return await asyncio.to_thread(_client.graph_last_modified, name)


@mcp.tool()
async def forge_provenance(
    edge_id: Optional[int] = None,
    node_id: Optional[int] = None,
    property: Optional[str] = None,
) -> Dict[str, Any]:
    """[Provenance] Sources + confidence for a claim.

    Pass either ``edge_id`` OR both ``node_id`` and ``property``.
    """
    return await asyncio.to_thread(
        _client.graph_provenance,
        edge_id=edge_id,
        node_id=node_id,
        property=property,
    )


@mcp.tool()
async def forge_reasoning_trace(
    query_type: str,
    name: Optional[str] = None,
    change_type: Optional[str] = None,
) -> Dict[str, Any]:
    """[Provenance] Inference trace for a derived query.

    ``query_type`` is ``"cascade"`` (requires ``name``) or ``"check_all"``.
    """
    return await asyncio.to_thread(
        _client.graph_reasoning_trace, query_type, name, change_type
    )


# -- Patterns ------------------------------------------------------------

@mcp.tool()
async def forge_patterns(name: str) -> List[Dict[str, Any]]:
    """[Patterns] Structural patterns similar to the given function."""
    return await asyncio.to_thread(_client.graph_patterns_similar, name)


@mcp.tool()
async def forge_pattern_catalog() -> List[Dict[str, Any]]:
    """[Patterns] Catalog of every learned structural pattern."""
    return await asyncio.to_thread(_client.graph_patterns)


@mcp.tool()
async def forge_pattern_detail(
    pattern_id: Optional[int] = None,
    name: Optional[str] = None,
) -> Dict[str, Any]:
    """[Patterns] Pattern detail — pass either ``pattern_id`` or ``name``."""
    if pattern_id is not None:
        return await asyncio.to_thread(_client.graph_pattern, pattern_id)
    if name is not None:
        return await asyncio.to_thread(_client.graph_pattern_by_name, name)
    raise ValueError("forge_pattern_detail requires pattern_id or name")


@mcp.tool()
async def forge_learn_patterns(
    similarity_threshold: Optional[float] = None,
    min_exemplars: Optional[int] = None,
) -> Dict[str, Any]:
    """[Patterns] Run pattern learning on the shared graph (admin only)."""
    return await asyncio.to_thread(
        _client.admin_learn_patterns, similarity_threshold, min_exemplars
    )


# -- Generation-prep -----------------------------------------------------

@mcp.tool()
async def forge_envelope(
    name: str, task: str, max_context: Optional[int] = None
) -> Dict[str, Any]:
    """[Generation-prep] Assemble a Forge envelope (grounding context) for a function + task."""
    return await asyncio.to_thread(_client.envelope, name, task, max_context)


# -- Ingestion -----------------------------------------------------------

@mcp.tool()
async def forge_scan(path: str, commit: Optional[str] = None) -> Dict[str, Any]:
    """[Ingestion] Start an async repository scan.

    Returns ``{scan_id, status, commit}`` immediately. Poll
    ``forge_scan_status`` for progress and completion.
    """
    return await asyncio.to_thread(_client.scan, path, commit)


@mcp.tool()
async def forge_scan_status(scan_id: str) -> Dict[str, Any]:
    """[Ingestion] Progress / completion for a running or finished scan."""
    return await asyncio.to_thread(_client.scan_status, scan_id)


@mcp.tool()
async def forge_ingest(
    files: List[Dict[str, Any]], commit: Optional[str] = None
) -> Dict[str, Any]:
    """[Ingestion] Ingest files by content — ``files=[{"path": ..., "content": ...}, ...]``."""
    return await asyncio.to_thread(_client.ingest, files, commit)


# -- Semantic Search (Wave 1 / FG-29) ------------------------------------

@mcp.tool()
async def forge_semantic_search(
    query: str,
    top_k: int = 10,
    mode: str = "local",
    provider: Optional[str] = None,
    model: Optional[str] = None,
    expand: bool = True,
) -> Dict[str, Any]:
    """[Semantic Search] Cosine-similar Function nodes with graph-expand.

    Returns the top ``top_k`` hits ranked by cosine similarity against the
    query's embedding. Each hit includes ``similarity``,
    ``embedding_model``, ``embedding_version``, ``embedded_at_commit``,
    ``signature``, ``docstring``, and (when ``expand`` is true) attached
    ``callers``, ``callees``, and ``types`` from the graph layer.

    ``mode`` — ``"local"`` (zero-egress Ollama on the forge host),
    ``"byok"`` (tenant's stored or body-supplied API key),
    ``"managed"`` (operator-provisioned key, LCN-billed).
    ``provider`` — ``"ollama"`` | ``"openai"`` | ``"voyage"``
    (defaults to ``"ollama"`` for local mode).
    """
    return await asyncio.to_thread(
        _client.graph_semantic_search,
        query, top_k, mode, provider, model, expand,
    )


@mcp.tool()
async def forge_embed(
    mode: str = "local",
    provider: Optional[str] = None,
    model: Optional[str] = None,
    dim: Optional[int] = None,
    llm_key: Optional[str] = None,
    scan_commit: Optional[str] = None,
) -> Dict[str, Any]:
    """[Semantic Search] Start an async embedding job over Function nodes.

    Returns ``{job_id, status, mode, provider, model, dim}`` immediately.
    Poll ``forge_embed_status`` for progress. Each Function node embeds
    its ``signature + docstring`` into the tenant's per-graph HNSW sidecar.
    """
    return await asyncio.to_thread(
        _client.embed_async, mode, provider, model, dim, llm_key, scan_commit,
    )


@mcp.tool()
async def forge_embed_status(job_id: str) -> Dict[str, Any]:
    """[Semantic Search] Progress / completion for a running or finished embed job."""
    return await asyncio.to_thread(_client.embed_status, job_id)


# -- Generation ----------------------------------------------------------

@mcp.tool()
async def forge_generate(
    name: str,
    task: str,
    llm_provider: Optional[str] = None,
    llm_key: Optional[str] = None,
    model: Optional[str] = None,
    retries: Optional[int] = None,
    build_command: Optional[str] = None,
) -> Dict[str, Any]:
    """[Generation] Full Forge cycle: envelope + LLM + audit (Tier 3).

    Provider / key default to ``dke-forge config`` values when omitted.
    """
    cfg = _config.load()
    provider = llm_provider or cfg.get("llm_provider")
    key = llm_key or cfg.get("llm_key")
    if not provider or not key:
        raise ValueError(
            "forge_generate requires llm_provider + llm_key (pass as args or "
            "set with: dke-forge config set llm_provider <...>; "
            "dke-forge config set llm_key <...>)"
        )
    chosen_model = model or cfg.get("model")
    return await asyncio.to_thread(
        _client.generate, name, task, provider, key,
        chosen_model, retries, build_command,
    )


# -- Meta ----------------------------------------------------------------

@mcp.tool()
async def forge_health() -> Dict[str, Any]:
    """[Meta] Server health — connectivity + version."""
    return await asyncio.to_thread(_client.health)


@mcp.tool()
async def forge_auth_verify() -> Dict[str, Any]:
    """[Meta] Verify the current API key is accepted by the server."""
    return await asyncio.to_thread(_client.auth_verify)


# -- Entry point ---------------------------------------------------------

def main():
    """Console entry for ``dke-forge-mcp``.

    Resolves config, performs a one-shot health check, then hands control
    to FastMCP's stdio loop. Exits non-zero on unreachable server.
    """
    global _client
    url, api_key = _resolve_config()
    _client = ForgeClient(url, api_key)
    try:
        _client.health()
    except ForgeError as e:
        print(
            f"dke-forge-mcp: cannot reach forge-api at {url}: {e.message}\n"
            "  Set FORGE_URL / FORGE_API_KEY or run:\n"
            "    dke-forge config set url <url>\n"
            "    dke-forge config set api_key <key>",
            file=sys.stderr,
        )
        sys.exit(1)
    mcp.run()


if __name__ == "__main__":
    main()
