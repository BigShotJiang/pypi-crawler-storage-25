"""Tests for ForgeClient — REST client for the DKE-Forge API."""

import pytest
from unittest.mock import patch, MagicMock

from dke_forge.client import ForgeClient, ForgeError


def _mock_response(status=200, json_data=None, text=""):
    resp = MagicMock()
    resp.ok = 200 <= status < 400
    resp.status_code = status
    resp.json.return_value = json_data or {}
    resp.text = text
    return resp


class TestHeaders:
    def test_auth_header_present(self):
        client = ForgeClient("https://dke-forge.com", "fga_test123")
        h = client._headers()
        assert h["Authorization"] == "Bearer fga_test123"
        assert h["Content-Type"] == "application/json"

    def test_auth_header_absent_when_no_key(self):
        client = ForgeClient("https://dke-forge.com")
        h = client._headers()
        assert "Authorization" not in h


class TestURLConstruction:
    @patch("dke_forge.client.requests.request")
    def test_trailing_slash_stripped(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"status": "ok"})
        client = ForgeClient("https://dke-forge.com/", "key")
        client.health()
        url = mock_req.call_args[0][1]
        assert url == "https://dke-forge.com/health"

    @patch("dke_forge.client.requests.request")
    def test_function_name_encoded(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        client = ForgeClient("https://dke-forge.com", "key")
        client.graph_function("MyClass::method")
        url = mock_req.call_args[0][1]
        assert "MyClass%3A%3Amethod" in url

    @patch("dke_forge.client.requests.request")
    def test_function_with_template(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        client = ForgeClient("https://dke-forge.com", "key")
        client.graph_function("vector<int>")
        url = mock_req.call_args[0][1]
        assert "vector%3Cint%3E" in url


class TestHTTPMethods:
    @patch("dke_forge.client.requests.request")
    def test_health_is_get(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"status": "ok"})
        ForgeClient("http://localhost", "k").health()
        assert mock_req.call_args[0][0] == "GET"

    @patch("dke_forge.client.requests.request")
    def test_register_is_post(self, mock_req):
        mock_req.return_value = _mock_response(
            status=201, json_data={"api_key": "fga_x"}
        )
        ForgeClient("http://localhost", "").register("a@b.com", "Test")
        assert mock_req.call_args[0][0] == "POST"
        body = mock_req.call_args[1]["json"]
        assert body == {"email": "a@b.com", "name": "Test"}

    @patch("dke_forge.client.requests.request")
    def test_revoke_is_delete(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"revoked": True})
        ForgeClient("http://localhost", "k").admin_revoke_tenant("t1")
        assert mock_req.call_args[0][0] == "DELETE"

    @patch("dke_forge.client.requests.request")
    def test_callers_passes_depth(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_callers("fn", depth=5)
        assert mock_req.call_args[1]["params"] == {"depth": 5}

    @patch("dke_forge.client.requests.request")
    def test_impact_passes_change_type(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_impact("fn", "remove")
        assert mock_req.call_args[1]["params"] == {"change_type": "remove"}


class TestRequestBody:
    @patch("dke_forge.client.requests.request")
    def test_envelope_body(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"envelope_text": ""})
        ForgeClient("http://localhost", "k").envelope("fn", "add timeout", 50)
        body = mock_req.call_args[1]["json"]
        assert body == {"name": "fn", "task": "add timeout", "max_context": 50}

    @patch("dke_forge.client.requests.request")
    def test_envelope_omits_max_context_when_none(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"envelope_text": ""})
        ForgeClient("http://localhost", "k").envelope("fn", "task")
        body = mock_req.call_args[1]["json"]
        assert "max_context" not in body

    @patch("dke_forge.client.requests.request")
    def test_generate_body(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"accepted": True})
        ForgeClient("http://localhost", "k").generate(
            "fn", "task", "anthropic", "sk-ant-xxx", model="claude-sonnet-4-20250514"
        )
        body = mock_req.call_args[1]["json"]
        assert body["llm_provider"] == "anthropic"
        assert body["llm_key"] == "sk-ant-xxx"
        assert body["model"] == "claude-sonnet-4-20250514"
        assert "retries" not in body

    @patch("dke_forge.client.requests.request")
    def test_generate_timeout_is_600(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"accepted": True})
        ForgeClient("http://localhost", "k").generate(
            "fn", "task", "openai", "sk-xxx"
        )
        assert mock_req.call_args[1]["timeout"] == 600

    @patch("dke_forge.client.requests.request")
    def test_ingest_body(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"files_ingested": 1})
        files = [{"path": "src/a.cpp", "content": "int main() {}"}]
        ForgeClient("http://localhost", "k").ingest(files, commit="abc")
        body = mock_req.call_args[1]["json"]
        assert body["files"] == files
        assert body["commit"] == "abc"


class TestErrorHandling:
    @patch("dke_forge.client.requests.request")
    def test_401_raises_forge_error(self, mock_req):
        mock_req.return_value = _mock_response(
            status=401, json_data={"error": "Invalid API key"}
        )
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "bad").graph_stats()
        assert exc.value.status_code == 401
        assert "Invalid API key" in exc.value.message

    @patch("dke_forge.client.requests.request")
    def test_404_raises_forge_error(self, mock_req):
        mock_req.return_value = _mock_response(
            status=404, json_data={"error": "No function found: xyz"}
        )
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").graph_function("xyz")
        assert exc.value.status_code == 404

    @patch("dke_forge.client.requests.request")
    def test_non_json_error_uses_text(self, mock_req):
        resp = MagicMock()
        resp.ok = False
        resp.status_code = 500
        resp.json.side_effect = ValueError("no json")
        resp.text = "Internal Server Error"
        mock_req.return_value = resp
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").health()
        assert "Internal Server Error" in exc.value.message

    @patch("dke_forge.client.requests.request")
    def test_connection_error(self, mock_req):
        import requests
        mock_req.side_effect = requests.ConnectionError("refused")
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost:1", "k").health()
        assert exc.value.status_code == 0
        assert "Cannot connect" in exc.value.message

    @patch("dke_forge.client.requests.request")
    def test_timeout_error(self, mock_req):
        import requests
        mock_req.side_effect = requests.Timeout("timed out")
        with pytest.raises(ForgeError) as exc:
            ForgeClient("http://localhost", "k").health()
        assert exc.value.status_code == 0
        assert "timed out" in exc.value.message


# -- Wave 0 extensions --


class TestWave0GraphQueries:
    @patch("dke_forge.client.requests.request")
    def test_patterns_similar(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_patterns_similar("myFn")
        url = mock_req.call_args[0][1]
        assert url.endswith("/v1/graph/patterns/similar/myFn")
        assert mock_req.call_args[0][0] == "GET"

    @patch("dke_forge.client.requests.request")
    def test_pattern_by_name_encodes(self, mock_req):
        mock_req.return_value = _mock_response(json_data={})
        ForgeClient("http://localhost", "k").graph_pattern_by_name("ns::Name")
        url = mock_req.call_args[0][1]
        assert "ns%3A%3AName" in url
        assert "/v1/graph/pattern/by-name/" in url

    @patch("dke_forge.client.requests.request")
    def test_implementers(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_implementers("Renderer")
        assert mock_req.call_args[0][1].endswith(
            "/v1/graph/implementers/Renderer"
        )

    @patch("dke_forge.client.requests.request")
    def test_dead_code_default_excludes_tests(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_dead_code()
        assert mock_req.call_args[1]["params"] == {"exclude_tests": 1}

    @patch("dke_forge.client.requests.request")
    def test_dead_code_include_tests(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_dead_code(exclude_tests=False)
        assert mock_req.call_args[1]["params"] == {"exclude_tests": 0}

    @patch("dke_forge.client.requests.request")
    def test_subgraph_joins_functions(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"nodes": [], "edges": []}
        )
        ForgeClient("http://localhost", "k").graph_subgraph(
            functions=["live", "caller"], max_depth=0
        )
        params = mock_req.call_args[1]["params"]
        assert params["functions"] == "live,caller"
        assert params["max_depth"] == 0

    @patch("dke_forge.client.requests.request")
    def test_subgraph_module_filter(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"nodes": [], "edges": []}
        )
        ForgeClient("http://localhost", "k").graph_subgraph(module="render")
        params = mock_req.call_args[1]["params"]
        assert params == {"module": "render"}

    @patch("dke_forge.client.requests.request")
    def test_subgraph_accepts_string_functions(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"nodes": [], "edges": []}
        )
        ForgeClient("http://localhost", "k").graph_subgraph(functions="a,b")
        assert mock_req.call_args[1]["params"]["functions"] == "a,b"

    @patch("dke_forge.client.requests.request")
    def test_subgraph_no_filters(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"nodes": [], "edges": []}
        )
        ForgeClient("http://localhost", "k").graph_subgraph()
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_reachable_basic(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_reachable("caller")
        assert mock_req.call_args[0][1].endswith("/v1/graph/reachable/caller")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_reachable_with_via(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_reachable(
            "caller", via="Implements"
        )
        assert mock_req.call_args[1]["params"] == {"via": "Implements"}

    @patch("dke_forge.client.requests.request")
    def test_contradictions(self, mock_req):
        mock_req.return_value = _mock_response(json_data=[])
        ForgeClient("http://localhost", "k").graph_contradictions()
        assert mock_req.call_args[0][1].endswith("/v1/graph/contradictions")

    @patch("dke_forge.client.requests.request")
    def test_last_modified(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"name": "live", "entries": []}
        )
        ForgeClient("http://localhost", "k").graph_last_modified("live")
        assert mock_req.call_args[0][1].endswith("/v1/graph/last-modified/live")

    @patch("dke_forge.client.requests.request")
    def test_provenance_edge(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        ForgeClient("http://localhost", "k").graph_provenance(edge_id=42)
        assert mock_req.call_args[1]["params"] == {"edge_id": 42}

    @patch("dke_forge.client.requests.request")
    def test_provenance_node_property(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        ForgeClient("http://localhost", "k").graph_provenance(
            node_id=7, property="signature"
        )
        params = mock_req.call_args[1]["params"]
        assert params == {"node_id": 7, "property": "signature"}

    def test_provenance_missing_args_raises(self):
        client = ForgeClient("http://localhost", "k")
        with pytest.raises(ValueError):
            client.graph_provenance()
        with pytest.raises(ValueError):
            client.graph_provenance(node_id=1)  # property missing

    @patch("dke_forge.client.requests.request")
    def test_reasoning_trace_cascade(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"query_type": "cascade", "steps": []}
        )
        ForgeClient("http://localhost", "k").graph_reasoning_trace(
            "cascade", name="live", change_type="rename"
        )
        params = mock_req.call_args[1]["params"]
        assert params == {
            "query_type": "cascade",
            "name": "live",
            "change_type": "rename",
        }

    @patch("dke_forge.client.requests.request")
    def test_reasoning_trace_check_all(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"query_type": "check_all", "steps": []}
        )
        ForgeClient("http://localhost", "k").graph_reasoning_trace("check_all")
        assert mock_req.call_args[1]["params"] == {"query_type": "check_all"}


class TestWave0AsyncScan:
    @patch("dke_forge.client.requests.request")
    def test_scan_returns_scan_id(self, mock_req):
        mock_req.return_value = _mock_response(
            status=202,
            json_data={"scan_id": "abc123", "status": "pending", "commit": "HEAD"},
        )
        result = ForgeClient("http://localhost", "k").scan("/repo")
        assert result["scan_id"] == "abc123"
        assert result["status"] == "pending"
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith("/v1/scan")
        body = mock_req.call_args[1]["json"]
        assert body == {"path": "/repo"}
        # Short timeout — 202 returns immediately
        assert mock_req.call_args[1]["timeout"] == 30

    @patch("dke_forge.client.requests.request")
    def test_scan_with_commit(self, mock_req):
        mock_req.return_value = _mock_response(
            status=202, json_data={"scan_id": "x", "status": "pending"}
        )
        ForgeClient("http://localhost", "k").scan("/repo", commit="deadbeef")
        body = mock_req.call_args[1]["json"]
        assert body == {"path": "/repo", "commit": "deadbeef"}

    @patch("dke_forge.client.requests.request")
    def test_scan_status(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={
                "id": "abc",
                "status": "complete",
                "files_processed": 10,
                "total_files": 10,
            }
        )
        result = ForgeClient("http://localhost", "k").scan_status("abc")
        assert result["status"] == "complete"
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/scan/abc")


# -- FG-29 Phase 1.1.C: semantic search + embed client methods --


class TestSemanticSearch:
    @patch("dke_forge.client.requests.request")
    def test_local_mode_default_provider_ollama(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"hits": []})
        ForgeClient("http://localhost", "k").graph_semantic_search("parse json")
        assert mock_req.call_args[0][0] == "GET"
        params = mock_req.call_args[1]["params"]
        assert params["q"] == "parse json"
        assert params["mode"] == "local"
        assert params["provider"] == "ollama"  # defaulted for local mode
        assert params["k"] == 10
        assert params["expand"] == 1

    @patch("dke_forge.client.requests.request")
    def test_managed_mode_requires_explicit_provider(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"hits": []})
        ForgeClient("http://localhost", "k").graph_semantic_search(
            "q", mode="managed", provider="openai",
        )
        params = mock_req.call_args[1]["params"]
        assert params["mode"] == "managed"
        assert params["provider"] == "openai"

    @patch("dke_forge.client.requests.request")
    def test_expand_false_maps_to_zero(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"hits": []})
        ForgeClient("http://localhost", "k").graph_semantic_search(
            "q", expand=False,
        )
        assert mock_req.call_args[1]["params"]["expand"] == 0

    @patch("dke_forge.client.requests.request")
    def test_returns_hits_array(self, mock_req):
        hits = [{"function": "f", "similarity": 0.9}]
        mock_req.return_value = _mock_response(json_data={"hits": hits})
        r = ForgeClient("http://localhost", "k").graph_semantic_search("q")
        assert r["hits"][0]["function"] == "f"


class TestEmbedAsync:
    @patch("dke_forge.client.requests.request")
    def test_local_default_posts_mode_local(self, mock_req):
        mock_req.return_value = _mock_response(
            status=202,
            json_data={"job_id": "j1", "status": "pending"},
        )
        ForgeClient("http://localhost", "k").embed_async()
        assert mock_req.call_args[0][0] == "POST"
        body = mock_req.call_args[1]["json"]
        assert body["mode"] == "local"
        assert body["provider"] == "ollama"

    @patch("dke_forge.client.requests.request")
    def test_byok_forwards_llm_key(self, mock_req):
        mock_req.return_value = _mock_response(
            status=202, json_data={"job_id": "j2"},
        )
        ForgeClient("http://localhost", "k").embed_async(
            mode="byok", provider="openai", llm_key="sk-test",
        )
        body = mock_req.call_args[1]["json"]
        assert body == {
            "mode": "byok", "provider": "openai", "llm_key": "sk-test",
        }

    @patch("dke_forge.client.requests.request")
    def test_managed_with_model_and_dim(self, mock_req):
        mock_req.return_value = _mock_response(
            status=202, json_data={"job_id": "j3"},
        )
        ForgeClient("http://localhost", "k").embed_async(
            mode="managed", provider="openai",
            model="text-embedding-3-large", dim=3072,
        )
        body = mock_req.call_args[1]["json"]
        assert body["model"] == "text-embedding-3-large"
        assert body["dim"] == 3072


class TestEmbedStatus:
    @patch("dke_forge.client.requests.request")
    def test_embed_status_url(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"id": "j1", "status": "complete"},
        )
        r = ForgeClient("http://localhost", "k").embed_status("j1")
        assert r["status"] == "complete"
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/embed/j1")


# -- FG-30 Phase 1.2.D: architecture suite client methods --


class TestClientCircularDeps:
    @patch("dke_forge.client.requests.request")
    def test_default_no_params(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"cycles": [], "scope": "all"}
        )
        ForgeClient("http://localhost", "k").analysis_circular_deps()
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/analysis/circular-deps")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_forwards_all_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"cycles": []})
        ForgeClient("http://localhost", "k").analysis_circular_deps(
            scope="module", max_cycles=10, max_length=50,
        )
        params = mock_req.call_args[1]["params"]
        assert params == {"scope": "module", "max_cycles": 10, "max_length": 50}

    @patch("dke_forge.client.requests.request")
    def test_partial_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"cycles": []})
        ForgeClient("http://localhost", "k").analysis_circular_deps(scope="file")
        assert mock_req.call_args[1]["params"] == {"scope": "file"}


class TestClientGodClasses:
    @patch("dke_forge.client.requests.request")
    def test_default_no_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"entries": []})
        ForgeClient("http://localhost", "k").analysis_god_classes()
        assert mock_req.call_args[0][1].endswith("/v1/analysis/god-classes")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_threshold_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"entries": []})
        ForgeClient("http://localhost", "k").analysis_god_classes(threshold=30)
        assert mock_req.call_args[1]["params"] == {"threshold": 30}


class TestClientArchitectureMap:
    @patch("dke_forge.client.requests.request")
    def test_default_no_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"top_nodes": []})
        ForgeClient("http://localhost", "k").analysis_architecture_map()
        assert mock_req.call_args[0][1].endswith("/v1/analysis/architecture-map")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_all_params_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"top_nodes": []})
        ForgeClient("http://localhost", "k").analysis_architecture_map(
            top_n=100, damping=0.85, max_iterations=50, tolerance=1e-6,
        )
        params = mock_req.call_args[1]["params"]
        assert params == {
            "top_n": 100,
            "damping": 0.85,
            "max_iterations": 50,
            "tolerance": 1e-6,
        }


class TestClientApiSurface:
    @patch("dke_forge.client.requests.request")
    def test_module_id(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"module_id": 42, "public_symbols": []}
        )
        ForgeClient("http://localhost", "k").analysis_api_surface(module_id=42)
        assert mock_req.call_args[0][1].endswith("/v1/analysis/api-surface")
        assert mock_req.call_args[1]["params"] == {"module_id": 42}

    @patch("dke_forge.client.requests.request")
    def test_module_name(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"module_id": 1, "public_symbols": []}
        )
        ForgeClient("http://localhost", "k").analysis_api_surface(
            module_name="render",
        )
        assert mock_req.call_args[1]["params"] == {"module_name": "render"}

    def test_requires_one_of(self):
        client = ForgeClient("http://localhost", "k")
        with pytest.raises(ValueError):
            client.analysis_api_surface()


class TestClientAbstractions:
    @patch("dke_forge.client.requests.request")
    def test_default_no_params(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"groups": []})
        ForgeClient("http://localhost", "k").analysis_abstractions()
        assert mock_req.call_args[0][1].endswith("/v1/analysis/abstractions")
        assert mock_req.call_args[1]["params"] is None

    @patch("dke_forge.client.requests.request")
    def test_min_group_size_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"groups": []})
        ForgeClient("http://localhost", "k").analysis_abstractions(min_group_size=4)
        assert mock_req.call_args[1]["params"] == {"min_group_size": 4}


class TestClientDataFlow:
    @patch("dke_forge.client.requests.request")
    def test_source_id(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"source_id": 1, "reached": [], "paths": []}
        )
        ForgeClient("http://localhost", "k").analysis_data_flow(source_id=1)
        assert mock_req.call_args[0][1].endswith("/v1/analysis/data-flow")
        assert mock_req.call_args[1]["params"] == {"source_id": 1}

    @patch("dke_forge.client.requests.request")
    def test_source_name(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"reached": [], "paths": []}
        )
        ForgeClient("http://localhost", "k").analysis_data_flow(source_name="parse")
        assert mock_req.call_args[1]["params"] == {"source_name": "parse"}

    @patch("dke_forge.client.requests.request")
    def test_all_params_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"reached": [], "paths": []}
        )
        ForgeClient("http://localhost", "k").analysis_data_flow(
            source_name="parse",
            max_depth=10,
            direction="backward",
            include_paths=True,
        )
        params = mock_req.call_args[1]["params"]
        assert params == {
            "source_name": "parse",
            "max_depth": 10,
            "direction": "backward",
            "include_paths": 1,
        }

    @patch("dke_forge.client.requests.request")
    def test_include_paths_false_maps_to_zero(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"reached": [], "paths": []}
        )
        ForgeClient("http://localhost", "k").analysis_data_flow(
            source_id=1, include_paths=False,
        )
        assert mock_req.call_args[1]["params"]["include_paths"] == 0

    def test_requires_one_of(self):
        client = ForgeClient("http://localhost", "k")
        with pytest.raises(ValueError):
            client.analysis_data_flow()


class TestClientModuleTopology:
    @patch("dke_forge.client.requests.request")
    def test_no_params(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"modules": [], "deps": []}
        )
        ForgeClient("http://localhost", "k").analysis_module_topology()
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/analysis/module-topology")
        assert mock_req.call_args[1]["params"] is None


# -- FG-32 Phase 2.1.C: change suite client methods --


class TestClientChangeRefactorPreview:
    @patch("dke_forge.client.requests.request")
    def test_posts_required_fields(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"found": False, "conflicts": []},
        )
        ForgeClient("http://localhost", "k").change_refactor_preview(
            "oldName", "newName",
        )
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith("/v1/change/refactor-preview")
        assert mock_req.call_args[1]["json"] == {
            "symbol_name": "oldName", "new_name": "newName",
        }

    @patch("dke_forge.client.requests.request")
    def test_kind_forwarded_when_present(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        ForgeClient("http://localhost", "k").change_refactor_preview(
            "Foo", "Bar", kind="Type",
        )
        assert mock_req.call_args[1]["json"] == {
            "symbol_name": "Foo", "new_name": "Bar", "kind": "Type",
        }


class TestClientChangeBreakingChange:
    @patch("dke_forge.client.requests.request")
    def test_posts_required_fields(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"found": True, "affected_callers": []},
        )
        ForgeClient("http://localhost", "k").change_breaking_change(
            "parse", "int", ["const std::string&", "std::size_t"],
        )
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith("/v1/change/breaking-change")
        assert mock_req.call_args[1]["json"] == {
            "symbol_name": "parse",
            "new_return_type": "int",
            "new_param_types": ["const std::string&", "std::size_t"],
        }

    @patch("dke_forge.client.requests.request")
    def test_param_types_always_a_list(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        # Pass a tuple to prove it's normalized to a list before JSON encode.
        ForgeClient("http://localhost", "k").change_breaking_change(
            "f", "void", ("int",),
        )
        assert mock_req.call_args[1]["json"]["new_param_types"] == ["int"]


class TestClientChangeDeprecationPath:
    @patch("dke_forge.client.requests.request")
    def test_posts_required_fields_only(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"found": True, "stages": []},
        )
        ForgeClient("http://localhost", "k").change_deprecation_path("OldApi")
        assert mock_req.call_args[0][0] == "POST"
        assert mock_req.call_args[0][1].endswith("/v1/change/deprecation-path")
        assert mock_req.call_args[1]["json"] == {"symbol_name": "OldApi"}

    @patch("dke_forge.client.requests.request")
    def test_all_params_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(json_data={"found": True})
        ForgeClient("http://localhost", "k").change_deprecation_path(
            "OldApi", kind="Function", max_depth=50,
        )
        assert mock_req.call_args[1]["json"] == {
            "symbol_name": "OldApi", "kind": "Function", "max_depth": 50,
        }


class TestClientChangeRisky:
    @patch("dke_forge.client.requests.request")
    def test_commit_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"commit_sha": "abc123", "score": 0.12},
        )
        ForgeClient("http://localhost", "k").change_risky("abc123")
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/change/risky")
        assert mock_req.call_args[1]["params"] == {"commit": "abc123"}


class TestClientChangeCommitImpact:
    @patch("dke_forge.client.requests.request")
    def test_commit_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"commit_sha": "abc123", "touched_count": 0},
        )
        ForgeClient("http://localhost", "k").change_commit_impact("abc123")
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/change/commit-impact")
        assert mock_req.call_args[1]["params"] == {"commit": "abc123"}


class TestClientChangeReview:
    @patch("dke_forge.client.requests.request")
    def test_commit_only(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"commit_sha": "abc123", "risk_score": 0.0},
        )
        ForgeClient("http://localhost", "k").change_review("abc123")
        assert mock_req.call_args[0][0] == "GET"
        assert mock_req.call_args[0][1].endswith("/v1/change/review")
        assert mock_req.call_args[1]["params"] == {"commit": "abc123"}

    @patch("dke_forge.client.requests.request")
    def test_focus_area_top_n_forwarded(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"commit_sha": "abc123", "risk_score": 0.0},
        )
        ForgeClient("http://localhost", "k").change_review(
            "abc123", focus_area_top_n=10,
        )
        assert mock_req.call_args[1]["params"] == {
            "commit": "abc123", "focus_area_top_n": 10,
        }


class TestEmbedWait:
    @patch("dke_forge.client.requests.request")
    def test_returns_on_complete(self, mock_req):
        mock_req.side_effect = [
            _mock_response(json_data={"status": "running"}),
            _mock_response(json_data={"status": "complete", "functions_processed": 3}),
        ]
        client = ForgeClient("http://localhost", "k")
        r = client.embed_wait("job", poll_interval=0.01, timeout=5)
        assert r["status"] == "complete"
        assert r["functions_processed"] == 3

    @patch("dke_forge.client.requests.request")
    def test_returns_on_error(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"status": "error", "error": "nope"},
        )
        client = ForgeClient("http://localhost", "k")
        r = client.embed_wait("job", poll_interval=0.01, timeout=5)
        assert r["status"] == "error"

    @patch("dke_forge.client.requests.request")
    def test_raises_on_timeout(self, mock_req):
        mock_req.return_value = _mock_response(
            json_data={"status": "running"},
        )
        client = ForgeClient("http://localhost", "k")
        with pytest.raises(ForgeError):
            client.embed_wait("job", poll_interval=0.01, timeout=0.05)
