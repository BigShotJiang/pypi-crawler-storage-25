"""
Core test fixtures.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import shutil
import tempfile
from pathlib import Path

import pytest
import pytest_asyncio

try:
    from exonware.xwstorage.connectors.local_connector import (
        LocalConnectorConfig,
        LocalStorageConnection,
    )
except ModuleNotFoundError:
    LocalConnectorConfig = None  # type: ignore[assignment,misc]
    LocalStorageConnection = None  # type: ignore[assignment,misc]


@pytest.fixture
def local_config(temp_dir):
    """Create local connector config for core tests."""
    if LocalConnectorConfig is None:
        pytest.skip("exonware.xwstorage.connectors.local_connector not available")
    return LocalConnectorConfig(
        address=str(temp_dir / "test_storage.json"),
        security=False,
    )


@pytest_asyncio.fixture
async def local_connection(local_config):
    """Create local storage connection for core tests."""
    if LocalStorageConnection is None:
        pytest.skip("exonware.xwstorage.connectors.local_connector not available")
    connection = LocalStorageConnection(local_config, "json")
    yield connection
