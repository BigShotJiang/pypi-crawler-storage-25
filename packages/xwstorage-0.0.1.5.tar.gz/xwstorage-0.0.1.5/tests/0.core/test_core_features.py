﻿#!/usr/bin/env python3
"""Core features tests (skipped when auth mocks not present)."""
import pytest

pytest.skip(
    "Core feature tests require MockAuthProvider in exonware.xwstorage.auth.",
    allow_module_level=True,
)
