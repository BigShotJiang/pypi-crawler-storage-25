#!/usr/bin/env python3
"""
Core connector tests - Fast, high-value checks (80/20).
Tests critical connector functionality that must work for the library to be usable.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
pytest.importorskip(
    "exonware.xwstorage.connectors.local_connector",
    reason="local connector not available in workspace",
)
from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig, LocalStorageConnection
from exonware.xwstorage.errors import XWLocationError
@pytest.mark.xwstorage_core
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestCoreLocalConnector:
    """Core tests for LocalConnector - critical functionality."""

    def test_local_config_creation(self, temp_dir):
        """Test that LocalConnectorConfig can be created."""
        config = LocalConnectorConfig(
            address=str(temp_dir / "test.json"),
            security=False
        )
        assert config.connector_type == "local"
        # address can be str or Path - check appropriately
        if hasattr(config.address, 'name'):
            assert config.address.name == "test.json"
        else:
            assert str(config.address).endswith("test.json") or config.address == "test.json"

    def test_local_config_to_dict(self, temp_dir):
        """Test that config can be converted to dictionary."""
        config = LocalConnectorConfig(
            address=str(temp_dir / "test.json"),
            security=False
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "local"
        assert "address" in config_dict
    @pytest.mark.asyncio

    async def test_local_connection_save_and_load(self, local_connection, sample_data, test_path):
        """
        Test that data can be saved and loaded - core functionality.
        This is the most critical test - if save/load doesn't work, nothing works.
        """
        # Save data
        await local_connection.save(sample_data, test_path)
        # Verify file exists
        exists = await local_connection.exists(test_path)
        assert exists is True
        # Load data
        loaded_data = await local_connection.load(test_path)
        assert loaded_data == sample_data
    @pytest.mark.asyncio

    async def test_local_connection_delete(self, local_connection, sample_data, test_path):
        """Test that data can be deleted."""
        # Save data
        await local_connection.save(sample_data, test_path)
        # Verify exists
        assert await local_connection.exists(test_path) is True
        # Delete
        await local_connection.delete(test_path)
        # Verify deleted
        assert await local_connection.exists(test_path) is False
    @pytest.mark.asyncio

    async def test_local_connection_load_nonexistent_raises_error(self, local_connection):
        """Test that loading nonexistent path raises error."""
        with pytest.raises(XWLocationError, match="not found"):
            await local_connection.load("nonexistent_path")
    @pytest.mark.asyncio

    async def test_local_connection_list_support(self, local_connection, sample_list, test_path):
        """Test that list data can be saved and loaded."""
        # Save list
        await local_connection.save(sample_list, test_path)
        # Load list
        loaded_data = await local_connection.load(test_path)
        # LocalStorageConnection wraps lists in collection structure when file doesn't exist
        if isinstance(loaded_data, dict) and "entities" in loaded_data:
            loaded_list = loaded_data["entities"]
        else:
            loaded_list = loaded_data
        assert isinstance(loaded_list, list)
        assert len(loaded_list) == len(sample_list)
        assert loaded_list == sample_list
@pytest.mark.xwstorage_core
@pytest.mark.xwstorage_connector

class TestCoreConnectorInterfaces:
    """Core tests for connector interfaces - Protocol compliance."""

    def test_local_config_implements_iconnector_config(self, temp_dir):
        """Test that LocalConnectorConfig implements IConnectorConfig Protocol."""
        from exonware.xwstorage.contracts import IConnectorConfig
        config = LocalConnectorConfig(
            address=str(temp_dir / "test.json"),
            security=False
        )
        # Runtime check
        assert isinstance(config, IConnectorConfig)
        assert hasattr(config, 'connector_type')
        assert hasattr(config, 'to_dict')
    @pytest.mark.asyncio

    async def test_local_connection_implements_istorage_connection(self, local_connection):
        """Test that LocalStorageConnection implements IStorageConnection Protocol."""
        from exonware.xwstorage.contracts import IStorageConnection
        # Runtime check
        assert isinstance(local_connection, IStorageConnection)
        assert hasattr(local_connection, 'connection_id')
        assert hasattr(local_connection, 'save')
        assert hasattr(local_connection, 'load')
        assert hasattr(local_connection, 'exists')
        assert hasattr(local_connection, 'delete')
