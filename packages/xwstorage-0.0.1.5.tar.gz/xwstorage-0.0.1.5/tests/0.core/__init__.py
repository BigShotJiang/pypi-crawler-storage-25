"""
Core tests for xwstorage - Fast, high-value checks (80/20).
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""
