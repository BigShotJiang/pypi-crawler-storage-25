﻿import pytest


@pytest.mark.xwstorage_core
def test_workspace_core_smoke():
    """Minimal smoke test so the core layer reports a passing pytest session when other modules are optional."""
    assert True
