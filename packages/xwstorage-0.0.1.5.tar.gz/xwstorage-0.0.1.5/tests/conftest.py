"""
Shared test fixtures for xwstorage tests.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import sys
import tempfile
import shutil
from pathlib import Path
from typing import Any
import pytest
import pytest_asyncio


_TESTS_ROOT = Path(__file__).resolve().parent
_CONNECTOR_EXPERIMENTS_PARENTS = (
    _TESTS_ROOT / "1.unit",
    _TESTS_ROOT / "2.integration",
)

# Make both connector_experiments_tests package roots importable during collection.
for _parent in _CONNECTOR_EXPERIMENTS_PARENTS:
    _parent_str = str(_parent)
    if _parent_str not in sys.path:
        sys.path.append(_parent_str)
@pytest.fixture

def temp_dir():
    """Create a temporary directory for tests."""
    temp_path = Path(tempfile.mkdtemp(prefix="xwstorage_test_"))
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)
@pytest.fixture

def sample_data():
    """Sample data for testing."""
    return {
        "id": "test-1",
        "name": "Test Item",
        "value": 42,
        "nested": {
            "key": "value",
            "list": [1, 2, 3]
        }
    }
@pytest.fixture

def sample_list():
    """Sample list data for testing."""
    return [
        {"id": "item-1", "name": "Item 1", "value": 10},
        {"id": "item-2", "name": "Item 2", "value": 20},
        {"id": "item-3", "name": "Item 3", "value": 30},
    ]
@pytest.fixture

def test_path():
    """Test storage path."""
    return "test_data"
@pytest.fixture

def json_format():
    """JSON format configuration."""
    return "json"
