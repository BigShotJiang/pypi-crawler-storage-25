#!/usr/bin/env python3
"""
Unit tests for xwstorage Row-Level Security (RLS).
Tests RLSPolicy, default_tenant_predicate, default_role_predicate,
visible(), filter_rows(), and integration with PolicyContext.
Company: eXonware.com
"""

import pytest
from exonware.xwstorage.policies.rls import (
    RLSPolicy,
    default_tenant_predicate,
    default_role_predicate,
)
from exonware.xwstorage.policies.context import PolicyContext
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_policies


class TestDefaultPredicates:
    """Test default RLS predicates."""

    def test_tenant_no_context_tenant_sees_all(self):
        """When context.tenant_id is None, row is visible (admin bypass)."""
        ctx = PolicyContext(tenant_id=None, user_id="u1")
        assert default_tenant_predicate({"tenant_id": "t1"}, ctx) is True
        assert default_tenant_predicate({"tenantId": "t2"}, ctx) is True

    def test_tenant_matching_visible(self):
        """Row with matching tenant_id is visible."""
        ctx = PolicyContext(tenant_id="t1")
        assert default_tenant_predicate({"tenant_id": "t1"}, ctx) is True
        assert default_tenant_predicate({"tenantId": "t1"}, ctx) is True

    def test_tenant_mismatch_hidden(self):
        """Row with different tenant_id is hidden."""
        ctx = PolicyContext(tenant_id="t1")
        assert default_tenant_predicate({"tenant_id": "t2"}, ctx) is False

    def test_tenant_non_dict_row_visible(self):
        """Non-dict row is visible when tenant check would pass (no tenant_id on row)."""
        ctx = PolicyContext(tenant_id=None)
        assert default_tenant_predicate([1, 2, 3], ctx) is True

    def test_role_admin_sees_all(self):
        """Context with admin role sees any row."""
        ctx = PolicyContext(user_id="u1", roles=["admin"])
        assert default_role_predicate({"owner_id": "other"}, ctx) is True

    def test_role_owner_sees_own(self):
        """Context user_id matches row owner_id."""
        ctx = PolicyContext(user_id="u1", roles=[])
        assert default_role_predicate({"owner_id": "u1"}, ctx) is True
        assert default_role_predicate({"ownerId": "u1"}, ctx) is True
        assert default_role_predicate({"user_id": "u1"}, ctx) is True
        assert default_role_predicate({"userId": "u1"}, ctx) is True

    def test_role_other_hidden(self):
        """Row owned by another user is hidden when not admin."""
        ctx = PolicyContext(user_id="u1", roles=[])
        assert default_role_predicate({"owner_id": "u2"}, ctx) is False

    def test_role_no_user_id_hidden(self):
        """When context.user_id is None, non-admin sees no rows (except admin bypass)."""
        ctx = PolicyContext(user_id=None, roles=[])
        assert default_role_predicate({"owner_id": "x"}, ctx) is False
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_policies


class TestRLSPolicy:
    """Test RLSPolicy visible() and filter_rows()."""
    @pytest.fixture

    def policy(self):
        return RLSPolicy()
    @pytest.fixture

    def context_tenant_user(self):
        return PolicyContext(tenant_id="t1", user_id="u1", roles=[])

    def test_visible_tenant_and_owner_match(self, policy, context_tenant_user):
        """Row matching both tenant and owner is visible."""
        row = {"tenant_id": "t1", "owner_id": "u1", "data": "x"}
        assert policy.visible(row, context_tenant_user) is True

    def test_visible_tenant_mismatch_hidden(self, policy, context_tenant_user):
        """Row with wrong tenant is hidden."""
        row = {"tenant_id": "t2", "owner_id": "u1"}
        assert policy.visible(row, context_tenant_user) is False

    def test_visible_owner_mismatch_hidden(self, policy, context_tenant_user):
        """Row with wrong owner is hidden (no admin)."""
        row = {"tenant_id": "t1", "owner_id": "u2"}
        assert policy.visible(row, context_tenant_user) is False

    def test_filter_rows(self, policy, context_tenant_user):
        """filter_rows returns only visible rows."""
        rows = [
            {"tenant_id": "t1", "owner_id": "u1", "id": 1},
            {"tenant_id": "t2", "owner_id": "u1", "id": 2},
            {"tenant_id": "t1", "owner_id": "u2", "id": 3},
            {"tenant_id": "t1", "owner_id": "u1", "id": 4},
        ]
        filtered = policy.filter_rows(rows, context_tenant_user)
        assert len(filtered) == 2
        assert {r["id"] for r in filtered} == {1, 4}

    def test_custom_predicate(self, context_tenant_user):
        """Custom predicate is applied."""
        def only_even(row, ctx):
            return isinstance(row.get("id"), int) and row["id"] % 2 == 0
        policy = RLSPolicy(custom_predicate=only_even)
        assert policy.visible({"tenant_id": "t1", "owner_id": "u1", "id": 2}, context_tenant_user) is True
        assert policy.visible({"tenant_id": "t1", "owner_id": "u1", "id": 1}, context_tenant_user) is False

    def test_admin_context_sees_all_matching_tenant(self, policy):
        """Admin with tenant sees all rows in that tenant."""
        ctx = PolicyContext(tenant_id="t1", user_id="admin", roles=["admin"])
        row = {"tenant_id": "t1", "owner_id": "other"}
        assert policy.visible(row, ctx) is True
