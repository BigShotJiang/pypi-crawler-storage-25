#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/connector_experiments_tests/test_local_connectors_abcd.py
Unit tests for experimental Local connector X.
These tests validate that the connector behaves correctly for
basic save/load/exists/delete operations using the underlying
LocalStorageConnection implementation and codec handling.
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Callable
import asyncio
import pytest
from exonware.xwsystem.io.codec.registry import get_registry
# Experimental connector X - use pytest.importorskip to handle missing module
pytest.importorskip(
    "exonware.xwstorage.connectors.connector_x",
    reason="Experimental connector X not implemented"
)
# Import the classes we need
from exonware.xwstorage.connectors.connector_x import (
    LocalXConnectorConfig,
    LocalXStorageConnection,
)
ConnectorFactory = Callable[[Path, str], Any]


def _make_local_x(tmp_dir: Path, codec_id: str) -> Any:
    cfg = LocalXConnectorConfig(address=str(tmp_dir / f"local_x_storage.{codec_id}"))
    return LocalXStorageConnection(cfg, codec_id)


def _has_codec(codec_id: str) -> bool:
    """Check if a codec id is available in the global registry."""
    try:
        registry = get_registry()
        return registry.get_by_id(codec_id) is not None
    except Exception:
        return False
_PARAMS: list[pytest.ParamSpec] = [
    pytest.param(_make_local_x, "json", id="X-json"),
]
# Only add xwjson cases if the codec is registered. This keeps the
# test suite aligned with actual installed capabilities without
# rigging tests: as soon as xwjson is available, these cases will be
# exercised automatically.
if _has_codec("xwjson"):
    _PARAMS.append(pytest.param(_make_local_x, "xwjson", id="X-xwjson"))
@pytest.mark.xwstorage_unit
@pytest.mark.parametrize("factory,codec_id", _PARAMS)


def test_local_connector_x_basic_roundtrip(
    tmp_path: Path, factory: Callable[[Path, str], Any], codec_id: str
) -> None:
    """
    Basic roundtrip test for experimental Local connector X.
    Ensures that save/load/exists/delete behave correctly
    using the same payload and codec id.
    """
    async def _run() -> None:
        conn = factory(tmp_path, codec_id)
        payload = {
            "id": "item-1",
            "name": "Test Item",
            "value": 42,
            "tags": ["alpha", "beta"],
        }
        path = "test_item"
        # Save
        await conn.save(payload, path)
        assert await conn.exists(path) is True
        # Load
        loaded = await conn.load(path)
        assert loaded == payload
        # Delete
        await conn.delete(path)
        assert await conn.exists(path) is False
    asyncio.run(_run())
