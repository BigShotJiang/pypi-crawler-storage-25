#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/connector_experiments_tests/__init__.py
Unit tests for experimental connector options (A/B/C/D).
These tests exercise Local-based connectors only (no external services)
to validate behaviour and provide a baseline for later benchmarking.
"""

from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)
