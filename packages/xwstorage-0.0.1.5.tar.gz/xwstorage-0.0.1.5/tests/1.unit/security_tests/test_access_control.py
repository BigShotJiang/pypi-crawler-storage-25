#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/security_tests/test_access_control.py
Unit tests for access control manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.security.access_control import AccessControlManager
from exonware.xwstorage.auth import MockAuthProvider
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_security

class TestAccessControlManager:
    """Test AccessControlManager implementation."""
    @pytest.fixture

    def auth_provider(self):
        """Create mock auth provider fixture."""
        return MockAuthProvider(
            api_keys={
                "test_key": {
                    "user_id": "user1",
                    "scopes": ["storage:read", "storage:write"]
                }
            }
        )
    @pytest.fixture

    def access_control(self, auth_provider):
        """Create access control manager fixture."""
        return AccessControlManager(auth_provider)
    @pytest.mark.asyncio

    async def test_check_access_granted(self, access_control):
        """Test checking access when granted."""
        # Use a valid token
        result = await access_control.check_access(
            "api_key:test_key",
            "bucket:my-bucket",
            "read"
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_check_access_no_auth_provider(self):
        """Test checking access without auth provider (allows all)."""
        manager = AccessControlManager(None)
        result = await manager.check_access("token", "resource", "action")
        assert result is True  # No auth provider means allow all
    @pytest.mark.asyncio

    async def test_check_access_invalid_token(self, access_control):
        """Test checking access with invalid token."""
        result = await access_control.check_access(
            "invalid_token",
            "bucket:my-bucket",
            "read"
        )
        assert result is False
