#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/security_tests/test_tls_config.py
Unit tests for TLS/SSL Configuration.
Tests TLS 1.3 support, certificate validation using xwsystem patterns.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
import ssl
import tempfile
from pathlib import Path
from exonware.xwstorage.security.tls_config import (
    TLSConfig,
    TLSVersion,
    TLSConfigManager
)
@pytest.mark.xwstorage_unit

class TestTLSConfig:
    """Test TLSConfig implementation."""

    def test_create_default(self):
        """Test creating default TLS configuration."""
        config = TLSConfig.create_default()
        assert config.tls_version == TLSVersion.TLS_1_3
        assert config.verify_certificates is True
        assert config.check_hostname is True

    def test_create_insecure(self):
        """Test creating insecure TLS configuration."""
        config = TLSConfig.create_insecure()
        assert config.verify_certificates is False
        assert config.check_hostname is False
        assert config.allow_insecure is True

    def test_create_ssl_context_default(self):
        """Test creating SSL context with default configuration."""
        config = TLSConfig.create_default()
        ssl_context = config.create_ssl_context()
        assert ssl_context is not None
        assert isinstance(ssl_context, ssl.SSLContext)
        assert ssl_context.verify_mode == ssl.CERT_REQUIRED

    def test_create_ssl_context_insecure(self):
        """Test creating SSL context with insecure configuration."""
        config = TLSConfig.create_insecure()
        ssl_context = config.create_ssl_context()
        assert ssl_context is not None
        assert ssl_context.verify_mode == ssl.CERT_NONE
        assert ssl_context.check_hostname is False

    def test_create_ssl_context_tls_1_2(self):
        """Test creating SSL context with TLS 1.2."""
        config = TLSConfig(tls_version=TLSVersion.TLS_1_2)
        ssl_context = config.create_ssl_context()
        assert ssl_context is not None
        # Verify minimum version is set (if supported)
        try:
            assert ssl_context.minimum_version >= ssl.TLSVersion.TLSv1_2
        except AttributeError:
            # Python < 3.7 doesn't have minimum_version
            pass

    def test_create_ssl_context_tls_1_3(self):
        """Test creating SSL context with TLS 1.3."""
        config = TLSConfig(tls_version=TLSVersion.TLS_1_3)
        ssl_context = config.create_ssl_context()
        assert ssl_context is not None
        # TLS 1.3 should be preferred
        try:
            assert ssl_context.minimum_version >= ssl.TLSVersion.TLSv1_2
        except AttributeError:
            # Python < 3.7 doesn't have minimum_version
            pass

    def test_create_ssl_context_with_ca_cert(self):
        """Test creating SSL context with CA certificate."""
        # Create temporary CA cert file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.crt') as tmp:
            tmp.write("-----BEGIN CERTIFICATE-----\nTEST\n-----END CERTIFICATE-----\n")
            ca_cert_file = tmp.name
        try:
            config = TLSConfig(
                ca_cert_file=ca_cert_file,
                verify_certificates=True
            )
            ssl_context = config.create_ssl_context()
            assert ssl_context is not None
            assert ssl_context.verify_mode == ssl.CERT_REQUIRED
        finally:
            Path(ca_cert_file).unlink(missing_ok=True)

    def test_create_ssl_context_with_client_cert(self):
        """Test creating SSL context with client certificate."""
        # Create temporary cert and key files
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.crt') as cert_file:
            cert_file.write("-----BEGIN CERTIFICATE-----\nTEST\n-----END CERTIFICATE-----\n")
            cert_path = cert_file.name
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.key') as key_file:
            key_file.write("-----BEGIN PRIVATE KEY-----\nTEST\n-----END PRIVATE KEY-----\n")
            key_path = key_file.name
        try:
            config = TLSConfig(
                client_cert_file=cert_path,
                client_key_file=key_path
            )
            # This may fail if cert/key are invalid, but should create context
            ssl_context = config.create_ssl_context()
            assert ssl_context is not None
        except Exception:
            # Invalid cert/key files may cause errors, which is expected
            pass
        finally:
            Path(cert_path).unlink(missing_ok=True)
            Path(key_path).unlink(missing_ok=True)

    def test_create_with_certificates(self):
        """Test creating TLS config with certificates."""
        config = TLSConfig.create_with_certificates(
            ca_cert_file="/path/to/ca.crt",
            client_cert_file="/path/to/client.crt",
            client_key_file="/path/to/client.key"
        )
        assert config.ca_cert_file == "/path/to/ca.crt"
        assert config.client_cert_file == "/path/to/client.crt"
        assert config.client_key_file == "/path/to/client.key"
        assert config.tls_version == TLSVersion.TLS_1_3

    def test_cipher_suites(self):
        """Test setting cipher suites."""
        config = TLSConfig(
            cipher_suites=["ECDHE-RSA-AES256-GCM-SHA384", "ECDHE-RSA-AES128-GCM-SHA256"]
        )
        ssl_context = config.create_ssl_context()
        assert ssl_context is not None
@pytest.mark.xwstorage_unit

class TestTLSConfigManager:
    """Test TLSConfigManager implementation."""
    @pytest.fixture

    def manager(self):
        """Create TLS config manager fixture."""
        return TLSConfigManager()

    def test_register_and_get_config(self, manager):
        """Test registering and getting TLS configuration."""
        config = TLSConfig.create_default()
        manager.register_config("default", config)
        retrieved = manager.get_config("default")
        assert retrieved == config

    def test_get_nonexistent_config(self, manager):
        """Test getting nonexistent configuration."""
        config = manager.get_config("nonexistent")
        assert config is None

    def test_create_ssl_context_for_connector(self, manager):
        """Test creating SSL context for connector."""
        config = TLSConfig.create_default()
        ssl_context = manager.create_ssl_context_for_connector("postgresql", config)
        assert ssl_context is not None
        assert isinstance(ssl_context, ssl.SSLContext)

    def test_create_ssl_context_with_default(self, manager):
        """Test creating SSL context with default config."""
        ssl_context = manager.create_ssl_context_for_connector("mysql")
        assert ssl_context is not None
        assert isinstance(ssl_context, ssl.SSLContext)

    def test_validate_certificate(self, manager):
        """Test certificate validation."""
        # Create temporary cert file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.crt') as tmp:
            tmp.write("-----BEGIN CERTIFICATE-----\nTEST\n-----END CERTIFICATE-----\n")
            cert_file = tmp.name
        try:
            # Should return True if file exists (basic validation)
            result = manager.validate_certificate(cert_file)
            assert result is True
        finally:
            Path(cert_file).unlink(missing_ok=True)

    def test_validate_nonexistent_certificate(self, manager):
        """Test validating nonexistent certificate."""
        result = manager.validate_certificate("/nonexistent/cert.crt")
        assert result is False
