#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/security_tests/test_encryption_comprehensive.py
Comprehensive security tests for Encryption with various data types.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.security.encryption import EncryptionManager
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_security

class TestEncryptionComprehensive:
    """Comprehensive security tests for EncryptionManager."""
    @pytest.fixture

    def encryption_manager(self):
        """Create encryption manager fixture."""
        return EncryptionManager()
    @pytest.mark.asyncio

    async def test_encrypt_various_data_sizes(self, encryption_manager):
        """Test encrypting various data sizes."""
        test_cases = [
            b"",  # Empty
            b"a",  # Single byte
            b"x" * 100,  # Small
            b"x" * 1024,  # Medium
            b"x" * 10240,  # Large
        ]
        for data in test_cases:
            encrypted = await encryption_manager.encrypt(data)
            assert encrypted is not None
            assert isinstance(encrypted, bytes)
    @pytest.mark.asyncio

    async def test_encrypt_binary_data(self, encryption_manager):
        """Test encrypting binary data."""
        binary_data = bytes(range(256))
        encrypted = await encryption_manager.encrypt(binary_data)
        assert encrypted is not None
    @pytest.mark.asyncio

    async def test_encrypt_with_different_keys(self, encryption_manager):
        """Test encrypting with different keys."""
        data = b"test data"
        key1 = b"key1" * 8  # 32 bytes
        key2 = b"key2" * 8  # 32 bytes
        encrypted1 = await encryption_manager.encrypt(data, key=key1)
        encrypted2 = await encryption_manager.encrypt(data, key=key2)
        # Different keys should produce different ciphertext
        assert encrypted1 is not None
        assert encrypted2 is not None
