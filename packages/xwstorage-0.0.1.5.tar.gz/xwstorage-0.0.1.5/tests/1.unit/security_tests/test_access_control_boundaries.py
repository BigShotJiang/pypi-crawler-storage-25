#!/usr/bin/env python3
"""
Boundary-focused tests for AccessControlManager fallback behavior.
"""

from __future__ import annotations

import pytest

from exonware.xwstorage import AccessControlManager, PolicyContext


class _NoPolicyProvider:
    async def validate_token(self, token: str):
        _ = token
        return {"scopes": ["storage:read"]}


class _PolicyProvider:
    async def check_permission_context(self, context, resource: str, action: str):
        _ = context
        _ = resource
        return action == "read"


class _ResolverProvider:
    async def resolve_auth_context(self, token: str):
        if token == "ctx-token":
            class _Ctx:
                subject_id = "u1"
                tenant_id = "t1"
                roles = ["storage:read"]
            return _Ctx()
        return None


class _ResolverPolicyProvider:
    async def resolve_auth_context(self, token: str):
        if token == "ctx-token":
            class _Ctx:
                subject_id = "u1"
                tenant_id = "t1"
                roles = ["member"]
            return _Ctx()
        return None

    async def check_permission_context(self, context, resource: str, action: str):
        _ = resource
        return bool(getattr(context, "subject_id", "")) and action == "read"


@pytest.mark.xwstorage_unit
@pytest.mark.asyncio
async def test_access_control_can_disable_local_fallback() -> None:
    manager = AccessControlManager(_NoPolicyProvider(), allow_local_fallback=False)
    allowed = await manager.check_access("token", "bucket:data", "read")
    assert allowed is False


@pytest.mark.xwstorage_unit
@pytest.mark.asyncio
async def test_access_control_uses_policy_checker_when_available() -> None:
    manager = AccessControlManager(_PolicyProvider(), allow_local_fallback=False)
    context = PolicyContext(user_id="u1", tenant_id="t1", roles=["member"])
    assert await manager.check_access_context(context, "bucket:data", "read") is True
    assert await manager.check_access_context(context, "bucket:data", "write") is False


@pytest.mark.xwstorage_unit
@pytest.mark.asyncio
@pytest.mark.parametrize(
    "allow_local_fallback,expected",
    [
        pytest.param(True, True, id="local-fallback-enabled"),
        pytest.param(False, False, id="local-fallback-disabled"),
    ],
)
async def test_access_control_local_validate_token_fallback_toggle(
    allow_local_fallback: bool,
    expected: bool,
) -> None:
    manager = AccessControlManager(_NoPolicyProvider(), allow_local_fallback=allow_local_fallback)
    allowed = await manager.check_access("legacy-token", "bucket:data", "read")
    assert allowed is expected


@pytest.mark.xwstorage_unit
@pytest.mark.asyncio
async def test_access_control_uses_resolved_context_with_strict_mode() -> None:
    manager = AccessControlManager(_ResolverPolicyProvider(), allow_local_fallback=False)
    allowed = await manager.check_access("ctx-token", "bucket:data", "read")
    assert allowed is True


@pytest.mark.xwstorage_unit
@pytest.mark.asyncio
async def test_access_control_strict_context_only_disables_legacy_validate_path() -> None:
    manager = AccessControlManager(
        _NoPolicyProvider(),
        allow_local_fallback=True,
        strict_context_only=True,
    )
    allowed = await manager.check_access("legacy-token", "bucket:data", "read")
    assert allowed is False
