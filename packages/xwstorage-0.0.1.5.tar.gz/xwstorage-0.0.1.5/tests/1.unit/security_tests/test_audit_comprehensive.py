#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/security_tests/test_audit_comprehensive.py
Comprehensive security tests for Audit logging with various events.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.security.audit import AuditLogger
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_security

class TestAuditComprehensive:
    """Comprehensive security tests for AuditLogger."""
    @pytest.fixture

    def audit_logger(self):
        """Create audit logger fixture."""
        return AuditLogger()

    def test_audit_all_operation_types(self, audit_logger):
        """Test logging all operation types."""
        operations = ["read", "write", "delete", "create", "update", "list"]
        for op in operations:
            audit_logger.log_operation(
                user_id="user1",
                operation=op,
                resource=f"resource:{op}",
                result="success"
            )
        # Should not raise exception

    def test_audit_failed_operations(self, audit_logger):
        """Test logging failed operations."""
        audit_logger.log_operation(
            user_id="user1",
            operation="write",
            resource="table:users",
            result="failure",
            details={"error": "Permission denied"}
        )
        # Should not raise exception

    def test_audit_access_denied(self, audit_logger):
        """Test logging access denied."""
        audit_logger.log_access(
            user_id="user1",
            resource="table:admin",
            action="write",
            granted=False
        )
        # Should not raise exception

    def test_audit_compliance_events(self, audit_logger):
        """Test logging compliance events."""
        events = [
            ("data_retention", {"retention_days": 90}),
            ("data_deletion", {"deleted_records": 1000}),
            ("access_review", {"reviewed_users": 50})
        ]
        for event_type, details in events:
            audit_logger.log_compliance_event(
                event_type=event_type,
                resource="system",
                details=details
            )
        # Should not raise exception
