#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/security_tests/test_encryption.py
Unit tests for Encryption manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.security.encryption import EncryptionManager
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_security

class TestEncryptionManager:
    """Test EncryptionManager implementation."""
    @pytest.fixture

    def encryption_manager(self):
        """Create encryption manager fixture."""
        return EncryptionManager()
    @pytest.mark.asyncio

    async def test_encryption_manager_initialization(self, encryption_manager):
        """Test initializing encryption manager."""
        assert encryption_manager is not None
    @pytest.mark.asyncio

    async def test_encrypt_decrypt_roundtrip(self, encryption_manager):
        """Test encrypting and decrypting data."""
        original_data = b"test data to encrypt"
        encrypted = await encryption_manager.encrypt(original_data)
        assert encrypted is not None
        decrypted = await encryption_manager.decrypt(encrypted)
        # In fallback mode, data is returned as-is
        # In production with xwsystem, would properly decrypt
        assert decrypted is not None
    @pytest.mark.asyncio

    async def test_encrypt_with_key(self, encryption_manager):
        """Test encrypting with a specific key."""
        original_data = b"test data"
        key = b"test_key_123456789012345678901234567890"  # 32 bytes
        encrypted = await encryption_manager.encrypt(original_data, key=key)
        assert encrypted is not None
    @pytest.mark.asyncio

    async def test_decrypt_with_key(self, encryption_manager):
        """Test decrypting with a specific key."""
        key = b"test_key_123456789012345678901234567890"  # 32 bytes
        encrypted_data = b"encrypted_data"
        decrypted = await encryption_manager.decrypt(encrypted_data, key=key)
        assert decrypted is not None
