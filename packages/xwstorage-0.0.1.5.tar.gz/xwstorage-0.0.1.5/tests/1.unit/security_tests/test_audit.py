#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/security_tests/test_audit.py
Unit tests for Audit logging.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.security.audit import AuditLogger
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_security

class TestAuditLogger:
    """Test AuditLogger implementation."""
    @pytest.fixture

    def audit_logger(self):
        """Create audit logger fixture."""
        return AuditLogger()

    def test_audit_logger_initialization(self, audit_logger):
        """Test initializing audit logger."""
        assert audit_logger is not None
        assert audit_logger.audit_logger is not None

    def test_log_operation(self, audit_logger):
        """Test logging an operation."""
        audit_logger.log_operation(
            user_id="user1",
            operation="read",
            resource="table:users",
            result="success",
            details={"rows": 10}
        )
        # Should not raise exception

    def test_log_operation_without_details(self, audit_logger):
        """Test logging an operation without details."""
        audit_logger.log_operation(
            user_id="user1",
            operation="write",
            resource="table:users",
            result="success"
        )
        # Should not raise exception

    def test_log_access_granted(self, audit_logger):
        """Test logging granted access."""
        audit_logger.log_access(
            user_id="user1",
            resource="table:users",
            action="read",
            granted=True
        )
        # Should not raise exception

    def test_log_access_denied(self, audit_logger):
        """Test logging denied access."""
        audit_logger.log_access(
            user_id="user1",
            resource="table:users",
            action="write",
            granted=False
        )
        # Should not raise exception

    def test_log_compliance_event(self, audit_logger):
        """Test logging a compliance event."""
        audit_logger.log_compliance_event(
            event_type="data_retention",
            resource="table:users",
            details={"retention_days": 90}
        )
        # Should not raise exception
