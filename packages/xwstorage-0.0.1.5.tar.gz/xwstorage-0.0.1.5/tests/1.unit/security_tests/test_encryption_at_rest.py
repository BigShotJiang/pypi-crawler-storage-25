#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/security_tests/test_encryption_at_rest.py
Unit tests for Encryption at Rest.
Tests encryption/decryption, KMS integration, key rotation using xwsystem.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
import tempfile
import os
from exonware.xwsystem.io.serialization.formats.text import json as xw_json
from exonware.xwstorage.security.encryption_at_rest import (
    EncryptionAtRest,
    EncryptionAlgorithm,
    LocalKeyManager,
    EncryptionMetadata
)
@pytest.mark.xwstorage_unit

class TestEncryptionAtRest:
    """Test EncryptionAtRest implementation."""
    @pytest.fixture

    def encryption(self):
        """Create encryption fixture."""
        return EncryptionAtRest(algorithm=EncryptionAlgorithm.AES_GCM_256)
    @pytest.fixture

    def sample_data(self):
        """Create sample data fixture."""
        return b"This is sensitive data that needs encryption"

    def test_encrypt_decrypt(self, encryption, sample_data):
        """Test basic encryption and decryption."""
        # Encrypt
        encrypted_data, metadata = encryption.encrypt(sample_data)
        assert encrypted_data != sample_data
        assert len(encrypted_data) > len(sample_data)  # Encrypted is larger
        assert metadata.algorithm == EncryptionAlgorithm.AES_GCM_256
        assert metadata.key_id is not None
        # Decrypt
        decrypted_data = encryption.decrypt(encrypted_data, metadata)
        assert decrypted_data == sample_data

    def test_encrypt_with_associated_data(self, encryption, sample_data):
        """Test encryption with associated data."""
        associated_data = b"metadata_context"
        encrypted_data, metadata = encryption.encrypt(sample_data, associated_data)
        assert metadata.associated_data == associated_data
        # Decrypt with same AAD
        decrypted_data = encryption.decrypt(encrypted_data, metadata)
        assert decrypted_data == sample_data

    def test_fernet_algorithm(self, sample_data):
        """Test Fernet encryption algorithm."""
        encryption = EncryptionAtRest(algorithm=EncryptionAlgorithm.FERNET)
        encrypted_data, metadata = encryption.encrypt(sample_data)
        decrypted_data = encryption.decrypt(encrypted_data, metadata)
        assert decrypted_data == sample_data
        assert metadata.algorithm == EncryptionAlgorithm.FERNET

    def test_aes_gcm_128(self, sample_data):
        """Test AES-GCM-128 encryption algorithm."""
        encryption = EncryptionAtRest(algorithm=EncryptionAlgorithm.AES_GCM_128)
        encrypted_data, metadata = encryption.encrypt(sample_data)
        decrypted_data = encryption.decrypt(encrypted_data, metadata)
        assert decrypted_data == sample_data
        assert metadata.algorithm == EncryptionAlgorithm.AES_GCM_128

    def test_key_rotation(self, encryption, sample_data):
        """Test key rotation."""
        # Encrypt with original key
        encrypted_data, metadata = encryption.encrypt(sample_data)
        original_key_id = metadata.key_id
        # Rotate key
        new_key_id = encryption.rotate_key()
        assert new_key_id != original_key_id
        # Old encrypted data should still decrypt (key manager keeps old key)
        decrypted_data = encryption.decrypt(encrypted_data, metadata)
        assert decrypted_data == sample_data
        # New encryption uses new key
        new_encrypted_data, new_metadata = encryption.encrypt(sample_data)
        assert new_metadata.key_id == new_key_id

    def test_custom_key_manager(self, sample_data):
        """Test with custom key manager."""
        key_manager = LocalKeyManager()
        key, key_id = key_manager.generate_key("custom_key")
        encryption = EncryptionAtRest(
            key_manager=key_manager,
            key_id="custom_key"
        )
        encrypted_data, metadata = encryption.encrypt(sample_data)
        assert metadata.key_id == "custom_key"
        decrypted_data = encryption.decrypt(encrypted_data, metadata)
        assert decrypted_data == sample_data

    def test_encrypt_file(self, encryption, sample_data):
        """Test file encryption."""
        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            tmp_file.write(sample_data)
            tmp_file_path = tmp_file.name
        try:
            # Encrypt file
            encrypted_path, metadata = encryption.encrypt_file(tmp_file_path)
            assert os.path.exists(encrypted_path)
            assert os.path.exists(f"{encrypted_path}.meta")
            # Decrypt file
            decrypted_path = encryption.decrypt_file(encrypted_path)
            assert os.path.exists(decrypted_path)
            # Verify content
            with open(decrypted_path, 'rb') as f:
                decrypted_data = f.read()
            assert decrypted_data == sample_data
            # Cleanup
            os.unlink(encrypted_path)
            os.unlink(f"{encrypted_path}.meta")
            os.unlink(decrypted_path)
        finally:
            if os.path.exists(tmp_file_path):
                os.unlink(tmp_file_path)

    def test_metadata_serialization(self, encryption, sample_data):
        """Test metadata serialization."""
        encrypted_data, metadata = encryption.encrypt(sample_data)
        # Write and read metadata
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.meta') as tmp:
            metadata_dict = {
                "algorithm": metadata.algorithm.value,
                "key_id": metadata.key_id,
                "nonce": metadata.nonce.hex() if metadata.nonce else "",
                "associated_data": metadata.associated_data.hex() if metadata.associated_data else None,
                "timestamp": metadata.timestamp
            }
            xw_json.dump(metadata_dict, tmp)
            tmp_path = tmp.name
        try:
            # Read metadata back
            read_metadata = encryption._read_metadata(tmp_path)
            assert read_metadata.algorithm == metadata.algorithm
            assert read_metadata.key_id == metadata.key_id
            assert read_metadata.nonce == metadata.nonce
        finally:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

    def test_different_data_produces_different_ciphertext(self, encryption):
        """Test that different data produces different ciphertext."""
        data1 = b"data1"
        data2 = b"data2"
        encrypted1, _ = encryption.encrypt(data1)
        encrypted2, _ = encryption.encrypt(data2)
        assert encrypted1 != encrypted2

    def test_same_data_different_nonce(self, encryption, sample_data):
        """Test that same data with different nonces produces different ciphertext."""
        encrypted1, metadata1 = encryption.encrypt(sample_data)
        encrypted2, metadata2 = encryption.encrypt(sample_data)
        # Nonces should be different
        assert metadata1.nonce != metadata2.nonce
        # Ciphertexts should be different
        assert encrypted1 != encrypted2
        # But both should decrypt to same plaintext
        decrypted1 = encryption.decrypt(encrypted1, metadata1)
        decrypted2 = encryption.decrypt(encrypted2, metadata2)
        assert decrypted1 == decrypted2 == sample_data
@pytest.mark.xwstorage_unit

class TestLocalKeyManager:
    """Test LocalKeyManager implementation."""

    def test_generate_key(self):
        """Test key generation."""
        manager = LocalKeyManager()
        key, key_id = manager.generate_key()
        assert key is not None
        assert key_id is not None
        assert len(key) > 0

    def test_get_key(self):
        """Test getting key by ID."""
        manager = LocalKeyManager()
        key, key_id = manager.generate_key("test_key")
        retrieved_key = manager.get_key("test_key")
        assert retrieved_key == key

    def test_get_nonexistent_key(self):
        """Test getting nonexistent key raises error."""
        manager = LocalKeyManager()
        with pytest.raises(KeyError):
            manager.get_key("nonexistent")

    def test_rotate_key(self):
        """Test key rotation."""
        manager = LocalKeyManager()
        key1, key_id1 = manager.generate_key("test_key")
        key2, key_id2 = manager.rotate_key("test_key")
        assert key2 != key1
        assert key_id2 != key_id1
        # Old key should still be available for decryption
        old_key = manager.get_key("test_key")
        assert old_key == key1  # In simple implementation, old key is kept

    def test_delete_key(self):
        """Test key deletion."""
        manager = LocalKeyManager()
        _, key_id = manager.generate_key("test_key")
        result = manager.delete_key("test_key")
        assert result is True
        with pytest.raises(KeyError):
            manager.get_key("test_key")
