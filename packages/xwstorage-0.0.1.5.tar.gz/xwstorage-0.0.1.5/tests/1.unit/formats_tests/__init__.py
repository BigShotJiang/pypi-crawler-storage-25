#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/formats_tests/__init__.py
Unit tests for format support integration.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""
