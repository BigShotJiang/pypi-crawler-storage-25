#!/usr/bin/env python3
"""
Unit tests for MeilisearchConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.meilisearch_connector import MeilisearchConnectorConfig, MeilisearchStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_meilisearch

class TestMeilisearchConnectorConfig:
    """Unit tests for MeilisearchConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = MeilisearchConnectorConfig(
            address="http://localhost:7700",
            api_key="my_api_key"
        )
        assert config.connector_type == "meilisearch"
        assert config.url == "http://localhost:7700"
        assert config.api_key == "my_api_key"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = MeilisearchConnectorConfig(
            address="localhost:7700"
        )
        assert config.url == "http://localhost:7700"

    def test_config_to_dict(self):
        """Test config to_dict conversion (API key masked)."""
        config = MeilisearchConnectorConfig(
            address="http://localhost:7700",
            api_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "meilisearch"
        assert config_dict["url"] == "http://localhost:7700"
        # API key should be masked
        if "api_key" in config_dict:
            assert config_dict["api_key"] == "***"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_meilisearch

class TestMeilisearchStorageConnection:
    """Unit tests for MeilisearchStorageConnection."""

    def test_connection_requires_meilisearch_package(self):
        """Test that connection raises error if Meilisearch package not available."""
        config = MeilisearchConnectorConfig(
            address="http://localhost:7700"
        )
        try:
            connection = MeilisearchStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_meilisearch_config_type(self):
        """Test that connection requires MeilisearchConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MeilisearchStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected MeilisearchConnectorConfig" in error_msg)
