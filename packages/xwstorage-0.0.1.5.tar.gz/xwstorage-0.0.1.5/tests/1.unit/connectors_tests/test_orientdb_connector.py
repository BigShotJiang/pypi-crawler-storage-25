#!/usr/bin/env python3
"""
Unit tests for OrientDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.orientdb_connector import OrientDBConnectorConfig, OrientDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_orientdb

class TestOrientDBConnectorConfig:
    """Unit tests for OrientDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = OrientDBConnectorConfig(
            address="my_class",
            host="localhost",
            port=2424,
            database="testdb",
            username="admin",
            password="admin"
        )
        assert config.connector_type == "orientdb"
        assert config.host == "localhost"
        assert config.port == 2424
        assert config.database == "testdb"
        assert config.username == "admin"
        assert config.table_name == "my_class"

    def test_config_initialization_with_defaults(self):
        """Test config initialization with default values."""
        config = OrientDBConnectorConfig(
            address="my_class"
        )
        assert config.host == "localhost"
        assert config.port == 2424
        assert config.database == "testdb"
        assert config.username == "admin"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = OrientDBConnectorConfig(
            address="my_class",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "orientdb"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 2424
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_orientdb

class TestOrientDBStorageConnection:
    """Unit tests for OrientDBStorageConnection."""

    def test_connection_requires_orientdb_package(self):
        """Test that connection raises error if OrientDB package not available."""
        config = OrientDBConnectorConfig(
            address="my_class"
        )
        try:
            connection = OrientDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_orientdb_config_type(self):
        """Test that connection requires OrientDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            OrientDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected OrientDBConnectorConfig" in error_msg)
