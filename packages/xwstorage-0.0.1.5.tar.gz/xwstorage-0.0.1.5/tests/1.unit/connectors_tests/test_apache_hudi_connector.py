#!/usr/bin/env python3
"""
Unit tests for ApacheHudiConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.apache_hudi_connector import ApacheHudiConnectorConfig, ApacheHudiStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_hudi

class TestApacheHudiConnectorConfig:
    """Unit tests for ApacheHudiConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with table path."""
        config = ApacheHudiConnectorConfig(
            address="/tmp/hudi_table",
            table_type="COPY_ON_WRITE"
        )
        assert config.connector_type == "apache_hudi"
        assert str(config.table_path) == "/tmp/hudi_table"
        assert config.table_type == "COPY_ON_WRITE"
        assert config.primary_key == "id"  # Default

    def test_config_initialization_with_merge_on_read(self):
        """Test config initialization with MERGE_ON_READ table type."""
        config = ApacheHudiConnectorConfig(
            address="/tmp/hudi_table",
            table_type="MERGE_ON_READ",
            primary_key="user_id",
            precombine_key="timestamp"
        )
        assert config.table_type == "MERGE_ON_READ"
        assert config.primary_key == "user_id"
        assert config.precombine_key == "timestamp"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ApacheHudiConnectorConfig(
            address="/tmp/hudi_table",
            table_type="COPY_ON_WRITE"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "apache_hudi"
        assert config_dict["table_path"] == "/tmp/hudi_table"
        assert config_dict["table_type"] == "COPY_ON_WRITE"
        assert config_dict["primary_key"] == "id"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_hudi

class TestApacheHudiStorageConnection:
    """Unit tests for ApacheHudiStorageConnection."""

    def test_connection_requires_hudi_package(self):
        """Test that connection raises error if Hudi package not available."""
        config = ApacheHudiConnectorConfig(
            address="/tmp/hudi_table"
        )
        try:
            connection = ApacheHudiStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Hudi connector package" in error_msg)

    def test_connection_requires_hudi_config_type(self):
        """Test that connection requires ApacheHudiConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ApacheHudiStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Hudi connector package" in error_msg or
                "Expected ApacheHudiConnectorConfig" in error_msg)
