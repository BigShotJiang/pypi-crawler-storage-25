#!/usr/bin/env python3
"""
Comprehensive unit tests for RedisConnector - 100% coverage target.
Tests all code paths including error handling and edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from exonware.xwstorage.connectors.redis_connector import RedisConnectorConfig, RedisStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redis

class TestRedisConnectorConfigComprehensive:
    """Comprehensive tests for RedisConnectorConfig."""

    def test_config_address_parsing_variations(self):
        """Test various address string parsing scenarios."""
        # Test with host:port
        config = RedisConnectorConfig(
            address="localhost:6379",
            db=0
        )
        assert config.host == "localhost"
        assert config.port == 6379
        assert config.db == 0
        # Test with just host (default port)
        config2 = RedisConnectorConfig(
            address="localhost",
            db=1
        )
        assert config2.host == "localhost"
        assert config2.port == 6379
        assert config2.db == 1
        # Test with password
        config3 = RedisConnectorConfig(
            address="localhost:6379",
            db=0,
            password="secret"
        )
        assert config3.password == "secret"

    def test_config_to_dict(self):
        """Test to_dict conversion."""
        config = RedisConnectorConfig(
            address="localhost:6379",
            db=2,
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "redis"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 6379
        assert config_dict["db"] == 2
        assert "password" not in config_dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redis

class TestRedisStorageConnectionComprehensive:
    """Comprehensive tests for RedisStorageConnection."""
    @pytest.fixture

    def redis_config(self):
        """Redis config for testing."""
        return RedisConnectorConfig(
            address="localhost:6379",
            db=0,
            password=None
        )
    @pytest.mark.asyncio

    async def test_connection_client_creation_async(self, redis_config):
        """Test async client creation with redis.asyncio."""
        with patch('exonware.xwstorage.connectors.redis_connector.REDIS_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.redis_connector.REDIS_ASYNC', True):
                with patch('redis.asyncio.Redis') as mock_redis:
                    mock_client = AsyncMock()
                    mock_redis.return_value = mock_client
                    connection = RedisStorageConnection(redis_config, "json")
                    client = await connection._get_client()
                    assert client is not None
    @pytest.mark.asyncio

    async def test_connection_client_creation_sync(self, redis_config):
        """Test sync client creation with redis."""
        with patch('exonware.xwstorage.connectors.redis_connector.REDIS_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.redis_connector.REDIS_ASYNC', False):
                with patch('redis.Redis') as mock_redis:
                    mock_client = MagicMock()
                    mock_redis.return_value = mock_client
                    connection = RedisStorageConnection(redis_config, "json")
                    client = await connection._get_client()
                    assert client is not None

    def test_connection_requires_redis_package(self, redis_config):
        """Test that connection raises error if Redis package not available."""
        with patch('exonware.xwstorage.connectors.redis_connector.REDIS_AVAILABLE', False):
            with pytest.raises(XWLocationError) as exc_info:
                RedisStorageConnection(redis_config, "json")
            error_msg = str(exc_info.value)
            assert "not installed" in error_msg.lower()

    def test_connection_requires_redis_config_type(self):
        """Test that connection requires RedisConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RedisStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected RedisConnectorConfig" in error_msg)
