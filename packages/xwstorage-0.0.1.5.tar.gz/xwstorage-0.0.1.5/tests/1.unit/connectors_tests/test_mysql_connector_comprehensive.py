#!/usr/bin/env python3
"""
Comprehensive unit tests for MySQLConnector - 100% coverage target.
Tests all code paths including error handling and edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from exonware.xwstorage.connectors.mysql_connector import MySQLConnectorConfig, MySQLStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mysql

class TestMySQLConnectorConfigComprehensive:
    """Comprehensive tests for MySQLConnectorConfig."""

    def test_config_address_parsing_variations(self):
        """Test various address string parsing scenarios."""
        # Test with port and database
        config = MySQLConnectorConfig(
            address="localhost:3306/mydb",
            username="user",
            password="pass"
        )
        assert config.host == "localhost"
        assert config.port == 3306
        assert config.database == "mydb"
        # Test with just database name
        config2 = MySQLConnectorConfig(
            address="mydb",
            host="localhost",
            port=3306,
            username="user",
            password="pass"
        )
        assert config2.database == "mydb"
        assert config2.table_name == "mydb"

    def test_config_to_dict_with_username(self):
        """Test to_dict includes username but not password."""
        config = MySQLConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb",
            username="testuser",
            password="secret"
        )
        config_dict = config.to_dict()
        assert "username" in config_dict
        assert config_dict["username"] == "testuser"
        assert "password" not in config_dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mysql

class TestMySQLStorageConnectionComprehensive:
    """Comprehensive tests for MySQLStorageConnection."""
    @pytest.fixture

    def mysql_config(self):
        """MySQL config for testing."""
        return MySQLConnectorConfig(
            address="test_table",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="password"
        )
    @pytest.mark.asyncio

    async def test_connection_pool_creation_async(self, mysql_config):
        """Test async pool creation with aiomysql."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', True):
                with patch('exonware.xwstorage.connectors.mysql_connector.mysql', None):
                    with patch('aiomysql.create_pool', new_callable=AsyncMock) as mock_pool:
                        mock_pool.return_value = AsyncMock()
                        connection = MySQLStorageConnection(mysql_config, "json")
                        pool = await connection._get_pool()
                        assert pool is not None
    @pytest.mark.asyncio

    async def test_connection_pool_creation_sync(self, mysql_config):
        """Test sync pool creation with mysql.connector."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', False):
                with patch('exonware.xwstorage.connectors.mysql_connector.pooling') as mock_pooling:
                    mock_pool = MagicMock()
                    mock_pooling.MySQLConnectionPool.return_value = mock_pool
                    connection = MySQLStorageConnection(mysql_config, "json")
                    pool = await connection._get_pool()
                    assert pool is not None
    @pytest.mark.asyncio

    async def test_connection_pool_creation_error(self, mysql_config):
        """Test pool creation error handling."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', False):
                with patch('exonware.xwstorage.connectors.mysql_connector.pooling') as mock_pooling:
                    mock_pooling.MySQLConnectionPool.side_effect = Exception("Connection failed")
                    connection = MySQLStorageConnection(mysql_config, "json")
                    with pytest.raises(XWStorageError, match="Failed to create MySQL connection pool"):
                        await connection._get_pool()
    @pytest.mark.asyncio

    async def test_ensure_table_async(self, mysql_config):
        """Test table creation with async MySQL."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', True):
                with patch('exonware.xwstorage.connectors.mysql_connector.mysql', None):
                    mock_pool = AsyncMock()
                    mock_conn = AsyncMock()
                    mock_cursor = AsyncMock()
                    mock_pool.acquire.return_value.__aenter__.return_value = mock_conn
                    mock_conn.cursor.return_value.__aenter__.return_value = mock_cursor
                    connection = MySQLStorageConnection(mysql_config, "json")
                    connection._pool = mock_pool
                    connection._use_async = True
                    await connection._ensure_table()
                    assert connection._table_created is True
    @pytest.mark.asyncio

    async def test_ensure_table_sync(self, mysql_config):
        """Test table creation with sync MySQL."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', False):
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_pool.get_connection.return_value = mock_conn
                mock_conn.cursor.return_value = mock_cursor
                connection = MySQLStorageConnection(mysql_config, "json")
                connection._pool = mock_pool
                connection._use_async = False
                await connection._ensure_table()
                assert connection._table_created is True
    @pytest.mark.asyncio

    async def test_save_async(self, mysql_config):
        """Test save operation with async MySQL."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', True):
                with patch('exonware.xwstorage.connectors.mysql_connector.mysql', None):
                    mock_pool = AsyncMock()
                    mock_conn = AsyncMock()
                    mock_cursor = AsyncMock()
                    mock_pool.acquire.return_value.__aenter__.return_value = mock_conn
                    mock_conn.cursor.return_value.__aenter__.return_value = mock_cursor
                    connection = MySQLStorageConnection(mysql_config, "json")
                    connection._pool = mock_pool
                    connection._use_async = True
                    connection._table_created = True
                    codec = MagicMock()
                    codec.encode = MagicMock(return_value='{"test": "data"}')
                    with patch.object(connection, '_get_codec', return_value=codec):
                        await connection.save({"test": "data"}, "test_path")
    @pytest.mark.asyncio

    async def test_save_sync_with_error(self, mysql_config):
        """Test save operation error handling with sync MySQL."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', False):
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.execute.side_effect = Exception("SQL error")
                mock_pool.get_connection.return_value = mock_conn
                mock_conn.cursor.return_value = mock_cursor
                connection = MySQLStorageConnection(mysql_config, "json")
                connection._pool = mock_pool
                connection._use_async = False
                connection._table_created = True
                codec = MagicMock()
                codec.encode = MagicMock(return_value='{"test": "data"}')
                with patch.object(connection, '_get_codec', return_value=codec):
                    with pytest.raises(XWStorageError, match="Failed to save data"):
                        await connection.save({"test": "data"}, "test_path")
    @pytest.mark.asyncio

    async def test_load_async(self, mysql_config):
        """Test load operation with async MySQL."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', True):
                with patch('exonware.xwstorage.connectors.mysql_connector.mysql', None):
                    mock_pool = AsyncMock()
                    mock_conn = AsyncMock()
                    mock_cursor = AsyncMock()
                    mock_cursor.fetchone.return_value = ('{"test": "data"}',)
                    mock_pool.acquire.return_value.__aenter__.return_value = mock_conn
                    mock_conn.cursor.return_value.__aenter__.return_value = mock_cursor
                    connection = MySQLStorageConnection(mysql_config, "json")
                    connection._pool = mock_pool
                    connection._use_async = True
                    connection._table_created = True
                    codec = MagicMock()
                    codec.decode = MagicMock(return_value={"test": "data"})
                    with patch.object(connection, '_get_codec', return_value=codec):
                        result = await connection.load("test_path")
                        assert result == {"test": "data"}
    @pytest.mark.asyncio

    async def test_load_returns_none(self, mysql_config):
        """Test load returns None when no data found."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', True):
                with patch('exonware.xwstorage.connectors.mysql_connector.mysql', None):
                    mock_pool = AsyncMock()
                    mock_conn = AsyncMock()
                    mock_cursor = AsyncMock()
                    mock_cursor.fetchone.return_value = None
                    mock_pool.acquire.return_value.__aenter__.return_value = mock_conn
                    mock_conn.cursor.return_value.__aenter__.return_value = mock_cursor
                    connection = MySQLStorageConnection(mysql_config, "json")
                    connection._pool = mock_pool
                    connection._use_async = True
                    connection._table_created = True
                    with patch.object(connection, '_get_codec'):
                        result = await connection.load("test_path")
                        assert result is None
    @pytest.mark.asyncio

    async def test_exists_async(self, mysql_config):
        """Test exists check with async MySQL."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', True):
                with patch('exonware.xwstorage.connectors.mysql_connector.mysql', None):
                    mock_pool = AsyncMock()
                    mock_conn = AsyncMock()
                    mock_cursor = AsyncMock()
                    mock_cursor.fetchone.return_value = (1,)  # Count > 0
                    mock_pool.acquire.return_value.__aenter__.return_value = mock_conn
                    mock_conn.cursor.return_value.__aenter__.return_value = mock_cursor
                    connection = MySQLStorageConnection(mysql_config, "json")
                    connection._pool = mock_pool
                    connection._use_async = True
                    connection._table_created = True
                    exists = await connection.exists("test_path")
                    assert exists is True
    @pytest.mark.asyncio

    async def test_delete_async(self, mysql_config):
        """Test delete operation with async MySQL."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', True):
                with patch('exonware.xwstorage.connectors.mysql_connector.mysql', None):
                    mock_pool = AsyncMock()
                    mock_conn = AsyncMock()
                    mock_cursor = AsyncMock()
                    mock_pool.acquire.return_value.__aenter__.return_value = mock_conn
                    mock_conn.cursor.return_value.__aenter__.return_value = mock_cursor
                    connection = MySQLStorageConnection(mysql_config, "json")
                    connection._pool = mock_pool
                    connection._use_async = True
                    connection._table_created = True
                    await connection.delete("test_path")
                    mock_cursor.execute.assert_called_once()
    @pytest.mark.asyncio

    async def test_delete_sync_with_error(self, mysql_config):
        """Test delete operation error handling with sync MySQL."""
        with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mysql_connector.MYSQL_ASYNC', False):
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.execute.side_effect = Exception("SQL error")
                mock_pool.get_connection.return_value = mock_conn
                mock_conn.cursor.return_value = mock_cursor
                connection = MySQLStorageConnection(mysql_config, "json")
                connection._pool = mock_pool
                connection._use_async = False
                connection._table_created = True
                with pytest.raises(XWStorageError, match="Failed to delete data"):
                    await connection.delete("test_path")
