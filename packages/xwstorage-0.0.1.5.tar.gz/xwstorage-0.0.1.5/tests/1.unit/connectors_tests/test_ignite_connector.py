#!/usr/bin/env python3
"""
Unit tests for IgniteConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.ignite_connector import IgniteConnectorConfig, IgniteStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ignite

class TestIgniteConnectorConfig:
    """Unit tests for IgniteConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = IgniteConnectorConfig(
            address="localhost:10800",
            cache_name="default"
        )
        assert config.connector_type == "ignite"
        assert config.host == "localhost"
        assert config.port == 10800
        assert config.cache_name == "default"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 10800)."""
        config = IgniteConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 10800

    def test_config_to_dict(self):
        """Test config to_dict conversion (password masked)."""
        config = IgniteConnectorConfig(
            address="localhost:10800",
            cache_name="my_cache",
            username="user",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "ignite"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 10800
        assert config_dict["cache_name"] == "my_cache"
        if "password" in config_dict:
            assert config_dict["password"] == "***"  # Password should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ignite

class TestIgniteStorageConnection:
    """Unit tests for IgniteStorageConnection."""

    def test_connection_requires_ignite_package(self):
        """Test that connection raises error if Ignite package not available."""
        config = IgniteConnectorConfig(
            address="localhost:10800"
        )
        try:
            connection = IgniteStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_ignite_config_type(self):
        """Test that connection requires IgniteConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            IgniteStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected IgniteConnectorConfig" in error_msg)
