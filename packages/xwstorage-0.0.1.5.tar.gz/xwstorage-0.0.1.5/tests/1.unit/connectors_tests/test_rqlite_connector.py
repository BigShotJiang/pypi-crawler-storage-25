#!/usr/bin/env python3
"""
Unit tests for RqliteConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.rqlite_connector import RqliteConnectorConfig, RqliteStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_rqlite

class TestRqliteConnectorConfig:
    """Unit tests for RqliteConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = RqliteConnectorConfig(
            address="http://localhost:4001"
        )
        assert config.connector_type == "rqlite"
        assert config.base_url == "http://localhost:4001"
        assert config.database == "default"
        assert config.consistency_level == "weak"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = RqliteConnectorConfig(
            address="localhost:4001"
        )
        assert config.base_url == "http://localhost:4001"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RqliteConnectorConfig(
            address="http://localhost:4001",
            database="mydb",
            consistency_level="strong"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "rqlite"
        assert config_dict["base_url"] == "http://localhost:4001"
        assert config_dict["database"] == "mydb"
        assert config_dict["consistency_level"] == "strong"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_rqlite

class TestRqliteStorageConnection:
    """Unit tests for RqliteStorageConnection."""

    def test_connection_requires_rqlite_package(self):
        """Test that connection raises error if rqlite package not available."""
        config = RqliteConnectorConfig(
            address="http://localhost:4001"
        )
        try:
            connection = RqliteStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "rqlite connector package" in error_msg)

    def test_connection_requires_rqlite_config_type(self):
        """Test that connection requires RqliteConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RqliteStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "rqlite connector package" in error_msg or
                "Expected RqliteConnectorConfig" in error_msg)
