#!/usr/bin/env python3
"""
Unit tests for ValdConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.vald_connector import ValdConnectorConfig, ValdStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_vald

class TestValdConnectorConfig:
    """Unit tests for ValdConnectorConfig."""

    def test_config_initialization_with_http_url(self):
        """Test config initialization with HTTP URL."""
        config = ValdConnectorConfig(
            address="http://localhost:8080"
        )
        assert config.connector_type == "vald"
        assert config.base_url == "http://localhost:8080"
        assert config.use_http is True

    def test_config_initialization_with_grpc_address(self):
        """Test config initialization with gRPC address."""
        config = ValdConnectorConfig(
            address="localhost:8081"
        )
        assert config.host == "localhost"
        assert config.port == 8081
        assert config.use_http is False

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ValdConnectorConfig(
            address="http://localhost:8080"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "vald"
        assert config_dict["base_url"] == "http://localhost:8080"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_vald

class TestValdStorageConnection:
    """Unit tests for ValdStorageConnection."""

    def test_connection_requires_vald_package(self):
        """Test that connection raises error if Vald package not available."""
        config = ValdConnectorConfig(
            address="http://localhost:8080"
        )
        try:
            connection = ValdStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Vald connector package" in error_msg)

    def test_connection_requires_vald_config_type(self):
        """Test that connection requires ValdConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ValdStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Vald connector package" in error_msg or
                "Expected ValdConnectorConfig" in error_msg)
