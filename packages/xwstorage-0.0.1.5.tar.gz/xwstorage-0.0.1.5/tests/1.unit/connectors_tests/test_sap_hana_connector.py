#!/usr/bin/env python3
"""
Unit tests for SAPHANAConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.sap_hana_connector import SAPHANAConnectorConfig, SAPHANAStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sap_hana

class TestSAPHANAConnectorConfig:
    """Unit tests for SAPHANAConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = SAPHANAConnectorConfig(
            address="localhost:30015",
            database="HDB",
            user="SYSTEM",
            password="password"
        )
        assert config.connector_type == "sap_hana"
        assert config.database == "HDB"
        assert config.user == "SYSTEM"
        assert config.host == "localhost"
        assert config.port == 30015

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 30015)."""
        config = SAPHANAConnectorConfig(
            address="localhost",
            database="HDB"
        )
        assert config.host == "localhost"
        assert config.port == 30015

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = SAPHANAConnectorConfig(
            address="localhost:30015",
            database="HDB",
            user="SYSTEM",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "sap_hana"
        assert config_dict["database"] == "HDB"
        assert config_dict["user"] == "SYSTEM"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sap_hana

class TestSAPHANAStorageConnection:
    """Unit tests for SAPHANAStorageConnection."""

    def test_connection_requires_sap_hana_package(self):
        """Test that connection raises error if SAP HANA package not available."""
        config = SAPHANAConnectorConfig(
            address="localhost:30015",
            database="HDB"
        )
        try:
            connection = SAPHANAStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_sap_hana_config_type(self):
        """Test that connection requires SAPHANAConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            SAPHANAStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected SAPHANAConnectorConfig" in error_msg)
