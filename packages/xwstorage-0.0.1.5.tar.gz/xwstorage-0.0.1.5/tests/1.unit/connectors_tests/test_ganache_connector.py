#!/usr/bin/env python3
"""
Unit tests for GanacheConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.ganache_connector import GanacheConnectorConfig, GanacheStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ganache

class TestGanacheConnectorConfig:
    """Unit tests for GanacheConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with RPC URL."""
        config = GanacheConnectorConfig(
            address="http://localhost:8545"
        )
        assert config.connector_type == "ganache"
        assert config.url == "http://localhost:8545"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = GanacheConnectorConfig(
            address="localhost:8545"
        )
        assert config.url == "http://localhost:8545"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = GanacheConnectorConfig(
            address="http://localhost:8545"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "ganache"
        assert config_dict["url"] == "http://localhost:8545"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ganache

class TestGanacheStorageConnection:
    """Unit tests for GanacheStorageConnection."""

    def test_connection_requires_web3_package(self):
        """Test that connection raises error if web3 package not available."""
        config = GanacheConnectorConfig(
            address="http://localhost:8545"
        )
        try:
            connection = GanacheStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Ganache connector package" in error_msg)

    def test_connection_requires_ganache_config_type(self):
        """Test that connection requires GanacheConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            GanacheStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Ganache connector package" in error_msg or
                "Expected GanacheConnectorConfig" in error_msg)
