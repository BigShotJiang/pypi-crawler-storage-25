#!/usr/bin/env python3
"""
Unit tests for MemgraphConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.memgraph_connector import MemgraphConnectorConfig, MemgraphStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_memgraph

class TestMemgraphConnectorConfig:
    """Unit tests for MemgraphConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = MemgraphConnectorConfig(
            address="localhost:7687"
        )
        assert config.connector_type == "memgraph"
        assert config.host == "localhost"
        assert config.port == 7687

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 7687)."""
        config = MemgraphConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 7687

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = MemgraphConnectorConfig(
            address="localhost:7687"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "memgraph"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 7687
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_memgraph

class TestMemgraphStorageConnection:
    """Unit tests for MemgraphStorageConnection."""

    def test_connection_requires_memgraph_package(self):
        """Test that connection raises error if Memgraph package not available."""
        config = MemgraphConnectorConfig(
            address="localhost:7687"
        )
        try:
            connection = MemgraphStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_memgraph_config_type(self):
        """Test that connection requires MemgraphConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MemgraphStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected MemgraphConnectorConfig" in error_msg)
