#!/usr/bin/env python3
"""
Unit tests for GlusterFSConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.glusterfs_connector import GlusterFSConnectorConfig, GlusterFSStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_glusterfs

class TestGlusterFSConnectorConfig:
    """Unit tests for GlusterFSConnectorConfig."""

    def test_config_initialization_with_mount_point(self):
        """Test config initialization with mount point path."""
        config = GlusterFSConnectorConfig(
            address="/mnt/glusterfs"
        )
        assert config.connector_type == "glusterfs"
        assert str(config.mount_point) == "/mnt/glusterfs"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = GlusterFSConnectorConfig(
            address="/mnt/glusterfs"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "glusterfs"
        assert config_dict["mount_point"] == "/mnt/glusterfs"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_glusterfs

class TestGlusterFSStorageConnection:
    """Unit tests for GlusterFSStorageConnection."""

    def test_connection_requires_glusterfs_config_type(self):
        """Test that connection requires GlusterFSConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            GlusterFSStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected GlusterFSConnectorConfig" in error_msg)
