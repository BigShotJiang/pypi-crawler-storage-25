#!/usr/bin/env python3
"""
Unit tests for NebulaConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.nebula_connector import NebulaConnectorConfig, NebulaStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_nebula

class TestNebulaConnectorConfig:
    """Unit tests for NebulaConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = NebulaConnectorConfig(
            address="localhost:9669",
            space="test",
            user="root",
            password="nebula"
        )
        assert config.connector_type == "nebula"
        assert config.host == "localhost"
        assert config.port == 9669
        assert config.space == "test"
        assert config.user == "root"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 9669)."""
        config = NebulaConnectorConfig(
            address="localhost",
            space="test"
        )
        assert config.host == "localhost"
        assert config.port == 9669

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = NebulaConnectorConfig(
            address="localhost:9669",
            space="test",
            user="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "nebula"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 9669
        assert config_dict["space"] == "test"
        assert config_dict["user"] == "root"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_nebula

class TestNebulaStorageConnection:
    """Unit tests for NebulaStorageConnection."""

    def test_connection_requires_nebula_package(self):
        """Test that connection raises error if Nebula package not available."""
        config = NebulaConnectorConfig(
            address="localhost:9669",
            space="test"
        )
        try:
            connection = NebulaStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_nebula_config_type(self):
        """Test that connection requires NebulaConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            NebulaStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected NebulaConnectorConfig" in error_msg)
