#!/usr/bin/env python3
"""
Unit tests for GarageConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.garage_connector import GarageConnectorConfig, GarageStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_garage

class TestGarageConnectorConfig:
    """Unit tests for GarageConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with endpoint URL."""
        config = GarageConnectorConfig(
            address="http://localhost:3900",
            bucket="mybucket",
            access_key="my_access_key",
            secret_key="my_secret_key"
        )
        assert config.connector_type == "garage"
        assert config.endpoint_url == "http://localhost:3900"
        assert config.bucket == "mybucket"
        assert config.access_key == "my_access_key"
        assert config.region == "garage"  # Default

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = GarageConnectorConfig(
            address="localhost:3900",
            bucket="mybucket",
            access_key="my_access_key",
            secret_key="my_secret_key"
        )
        assert config.endpoint_url == "http://localhost:3900"

    def test_config_to_dict(self):
        """Test config to_dict conversion (keys masked)."""
        config = GarageConnectorConfig(
            address="http://localhost:3900",
            bucket="mybucket",
            access_key="my_access_key",
            secret_key="secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "garage"
        assert config_dict["endpoint_url"] == "http://localhost:3900"
        assert config_dict["bucket"] == "mybucket"
        assert config_dict["access_key"] == "***"  # Access key should be masked
        assert config_dict["secret_key"] == "***"  # Secret key should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_garage

class TestGarageStorageConnection:
    """Unit tests for GarageStorageConnection."""

    def test_connection_requires_boto3_package(self):
        """Test that connection raises error if boto3 package not available."""
        config = GarageConnectorConfig(
            address="http://localhost:3900",
            bucket="mybucket",
            access_key="my_access_key",
            secret_key="my_secret_key"
        )
        try:
            connection = GarageStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_garage_config_type(self):
        """Test that connection requires GarageConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            GarageStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected GarageConnectorConfig" in error_msg)
