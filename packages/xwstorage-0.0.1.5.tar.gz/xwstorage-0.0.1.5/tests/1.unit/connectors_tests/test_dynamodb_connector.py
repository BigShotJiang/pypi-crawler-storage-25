#!/usr/bin/env python3
"""
Unit tests for DynamoDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.dynamodb_connector import DynamoDBConnectorConfig, DynamoDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dynamodb

class TestDynamoDBConnectorConfig:
    """Unit tests for DynamoDBConnectorConfig."""

    def test_config_initialization_with_table_name(self):
        """Test config initialization with table name."""
        config = DynamoDBConnectorConfig(
            table_name="my-table",
            region="us-east-1"
        )
        assert config.connector_type == "dynamodb"
        assert config.table_name == "my-table"
        assert config.region == "us-east-1"

    def test_config_initialization_with_credentials(self):
        """Test config initialization with AWS credentials."""
        config = DynamoDBConnectorConfig(
            table_name="my-table",
            region="us-west-2",
            access_key_id="AKIAIOSFODNN7EXAMPLE",
            secret_access_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        )
        assert config.table_name == "my-table"
        assert config.region == "us-west-2"
        assert config.access_key_id == "AKIAIOSFODNN7EXAMPLE"
        assert config.secret_access_key == "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

    def test_config_initialization_with_local_endpoint(self):
        """Test config initialization with local DynamoDB endpoint."""
        config = DynamoDBConnectorConfig(
            table_name="my-table",
            region="us-east-1",
            endpoint_url="http://localhost:8000"
        )
        assert config.table_name == "my-table"
        assert config.endpoint_url == "http://localhost:8000"

    def test_config_to_dict(self):
        """Test config to_dict conversion (secret not included)."""
        config = DynamoDBConnectorConfig(
            table_name="my-table",
            region="us-east-1",
            access_key_id="AKIAIOSFODNN7EXAMPLE",
            secret_access_key="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "dynamodb"
        assert config_dict["table_name"] == "my-table"
        assert config_dict["region"] == "us-east-1"
        assert config_dict["access_key_id"] == "AKIAIOSFODNN7EXAMPLE"
        assert "secret_access_key" not in config_dict  # Secret should not be in dict

    def test_config_default_region(self):
        """Test config uses default region when not specified."""
        config = DynamoDBConnectorConfig(
            table_name="my-table"
        )
        assert config.region == "us-east-1"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dynamodb

class TestDynamoDBStorageConnection:
    """Unit tests for DynamoDBStorageConnection."""

    def test_connection_requires_boto3_package(self):
        """Test that connection raises error if boto3 package not available."""
        config = DynamoDBConnectorConfig(
            table_name="my-table",
            region="us-east-1"
        )
        try:
            connection = DynamoDBStorageConnection(config, "json")
            # If we get here, boto3 package is available
            assert connection._config == config
        except XWLocationError as e:
            # Expected if boto3 package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_dynamodb_config_type(self):
        """Test that connection requires DynamoDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        # If boto3 package is not installed, it will raise error about package first
        # If boto3 package is installed, it will raise error about config type
        with pytest.raises(XWLocationError) as exc_info:
            DynamoDBStorageConnection(local_config, "json")
        # Should raise error about either package or config type
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected DynamoDBConnectorConfig" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = DynamoDBConnectorConfig(
            table_name="my-table",
            region="us-east-1"
        )
        try:
            connection = DynamoDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("boto3 package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dynamodb
@pytest.mark.skip(reason="Requires AWS credentials and DynamoDB table")

class TestDynamoDBStorageConnectionOperations:
    """Unit tests for DynamoDB storage operations (requires AWS credentials and table)."""
    @pytest.fixture

    def dynamodb_config(self):
        """DynamoDB config for testing (requires AWS credentials)."""
        return DynamoDBConnectorConfig(
            table_name="test-table",
            region="us-east-1",
            access_key_id="AKIAIOSFODNN7EXAMPLE",
            secret_access_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        )
    @pytest.fixture

    async def dynamodb_connection(self, dynamodb_config):
        """DynamoDB connection for testing."""
        connection = DynamoDBStorageConnection(dynamodb_config, "json")
        yield connection
    @pytest.mark.asyncio

    async def test_dynamodb_save_and_load(self, dynamodb_connection, sample_data, test_path):
        """Test DynamoDB save and load operations."""
        await dynamodb_connection.save(sample_data, test_path)
        loaded = await dynamodb_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_dynamodb_exists(self, dynamodb_connection, sample_data, test_path):
        """Test DynamoDB exists check."""
        assert await dynamodb_connection.exists(test_path) is False
        await dynamodb_connection.save(sample_data, test_path)
        assert await dynamodb_connection.exists(test_path) is True
    @pytest.mark.asyncio

    async def test_dynamodb_delete(self, dynamodb_connection, sample_data, test_path):
        """Test DynamoDB delete operation."""
        await dynamodb_connection.save(sample_data, test_path)
        assert await dynamodb_connection.exists(test_path) is True
        await dynamodb_connection.delete(test_path)
        assert await dynamodb_connection.exists(test_path) is False
