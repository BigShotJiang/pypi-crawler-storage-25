#!/usr/bin/env python3
"""
Unit tests for Box connector strategy.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import patch, MagicMock
from exonware.xwstorage.connectors.box_connector_strategy import BoxConnector
from exonware.xwstorage.errors import XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_box

class TestBoxConnector:
    """Unit tests for BoxConnector."""

    def test_connector_initialization(self):
        """Test connector initialization."""
        connector = BoxConnector(access_token="test-token")
        assert connector.connector_type == "box"
        assert connector.access_token == "test-token"
        assert connector._connected is False

    def test_connector_type_property(self):
        """Test connector_type property."""
        connector = BoxConnector(access_token="test-token")
        assert connector.connector_type == "box"
    @pytest.mark.asyncio

    async def test_connect_with_access_token(self, mock_box_client):
        """Test connect with access token."""
        connector = BoxConnector(access_token="test-token")
        # Skip test if boxsdk is not available and we can't mock it
        try:
            import boxsdk
        except ImportError:
            # If boxsdk is not available, create a mock module
            import sys
            from types import ModuleType
            mock_boxsdk = ModuleType('boxsdk')
            mock_boxsdk.Client = MagicMock(return_value=mock_box_client)
            mock_boxsdk.OAuth2 = MagicMock()
            mock_exception = ModuleType('boxsdk.exception')
            mock_exception.BoxAPIException = Exception
            mock_exception.BoxOAuthException = Exception
            mock_boxsdk.exception = mock_exception
            sys.modules['boxsdk'] = mock_boxsdk
            sys.modules['boxsdk.exception'] = mock_exception
        with patch('exonware.xwstorage.connectors.box_connector_strategy.BOX_AVAILABLE', True):
            # Patch the imported Client and OAuth2 in the module
            with patch('exonware.xwstorage.connectors.box_connector_strategy.Client', MagicMock(return_value=mock_box_client)):
                with patch('exonware.xwstorage.connectors.box_connector_strategy.OAuth2', MagicMock()):
                    await connector.connect()
                    assert connector._connected is True
                    assert connector._client == mock_box_client
    @pytest.mark.asyncio

    async def test_connect_requires_package(self):
        """Test that connect requires boxsdk package."""
        connector = BoxConnector(access_token="test-token")
        with patch('exonware.xwstorage.connectors.box_connector_strategy.BOX_AVAILABLE', False):
            with pytest.raises(XWStorageError, match="boxsdk not available"):
                await connector.connect()
    @pytest.mark.asyncio

    async def test_connect_without_credentials(self):
        """Test connect without credentials raises error."""
        connector = BoxConnector()
        with patch('exonware.xwstorage.connectors.box_connector_strategy.BOX_AVAILABLE', True):
            with pytest.raises(XWStorageError, match="Box authentication required"):
                await connector.connect()
    @pytest.mark.asyncio

    async def test_disconnect(self):
        """Test disconnect."""
        connector = BoxConnector(access_token="test-token")
        connector._client = MagicMock()
        connector._oauth = MagicMock()
        connector._connected = True
        await connector.disconnect()
        assert connector._connected is False
        assert connector._client is None
        assert connector._oauth is None
