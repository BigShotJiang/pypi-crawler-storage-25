#!/usr/bin/env python3
"""
Unit tests for DgraphConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.dgraph_connector import DgraphConnectorConfig, DgraphStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dgraph

class TestDgraphConnectorConfig:
    """Unit tests for DgraphConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = DgraphConnectorConfig(
            host="localhost",
            port=9080,
            use_ssl=False
        )
        assert config.connector_type == "dgraph"
        assert config.host == "localhost"
        assert config.port == 9080
        assert config.use_ssl is False

    def test_config_initialization_with_ssl(self):
        """Test config initialization with SSL enabled."""
        config = DgraphConnectorConfig(
            host="dgraph.example.com",
            port=9080,
            use_ssl=True
        )
        assert config.use_ssl is True

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = DgraphConnectorConfig(
            host="localhost",
            port=9080,
            use_ssl=False
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "dgraph"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 9080
        assert config_dict["use_ssl"] is False

    def test_config_default_values(self):
        """Test config uses default values when not specified."""
        config = DgraphConnectorConfig()
        assert config.host == "localhost"
        assert config.port == 9080
        assert config.use_ssl is False
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dgraph

class TestDgraphStorageConnection:
    """Unit tests for DgraphStorageConnection."""

    def test_connection_requires_dgraph_package(self):
        """Test that connection raises error if Dgraph package not available."""
        config = DgraphConnectorConfig(
            host="localhost",
            port=9080
        )
        try:
            connection = DgraphStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_dgraph_config_type(self):
        """Test that connection requires DgraphConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DgraphStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected DgraphConnectorConfig" in error_msg)
