#!/usr/bin/env python3
"""
Unit tests for TARConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.tar_connector import TARConnectorConfig, TARStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_tar

class TestTARConnectorConfig:
    """Unit tests for TARConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with TAR file path."""
        config = TARConnectorConfig(
            address="/tmp/archive.tar"
        )
        assert config.connector_type == "tar"
        assert str(config.tar_path) == "/tmp/archive.tar"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = TARConnectorConfig(
            address="/tmp/archive.tar"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "tar"
        assert config_dict["tar_path"] == "/tmp/archive.tar"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_tar

class TestTARStorageConnection:
    """Unit tests for TARStorageConnection."""

    def test_connection_requires_tar_config_type(self):
        """Test that connection requires TARConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            TARStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected TARConnectorConfig" in error_msg)
