#!/usr/bin/env python3
"""
Unit tests for BackblazeB2Connector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.backblaze_b2_connector import BackblazeB2ConnectorConfig, BackblazeB2StorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_backblaze_b2

class TestBackblazeB2ConnectorConfig:
    """Unit tests for BackblazeB2ConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = BackblazeB2ConnectorConfig(
            bucket="my-bucket",
            application_key_id="K001abc123",
            application_key="my_secret_key"
        )
        assert config.connector_type == "backblaze_b2"
        assert config.bucket == "my-bucket"
        assert config.application_key_id == "K001abc123"
        assert config.application_key == "my_secret_key"
        assert "backblazeb2.com" in config.endpoint_url

    def test_config_initialization_with_custom_endpoint(self):
        """Test config initialization with custom endpoint URL."""
        config = BackblazeB2ConnectorConfig(
            bucket="my-bucket",
            application_key_id="K001abc123",
            application_key="my_secret_key",
            endpoint_url="https://s3.us-west-004.backblazeb2.com"
        )
        assert config.endpoint_url == "https://s3.us-west-004.backblazeb2.com"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = BackblazeB2ConnectorConfig(
            bucket="my-bucket",
            application_key_id="K001abc123",
            application_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "backblaze_b2"
        assert config_dict["bucket"] == "my-bucket"
        assert config_dict["application_key_id"] == "K001abc123"
        assert "application_key" not in config_dict  # Secret should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_backblaze_b2

class TestBackblazeB2StorageConnection:
    """Unit tests for BackblazeB2StorageConnection."""

    def test_connection_requires_s3_connector(self):
        """Test that connection raises error if S3 connector not available."""
        config = BackblazeB2ConnectorConfig(
            bucket="my-bucket",
            application_key_id="K001abc123",
            application_key="my_secret_key"
        )
        try:
            connection = BackblazeB2StorageConnection(config, "json")
            assert connection._config is not None
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not available" in error_msg.lower() or 
                    "S3 connector" in error_msg or
                    "boto3" in error_msg.lower())

    def test_connection_requires_backblaze_b2_config_type(self):
        """Test that connection requires BackblazeB2ConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            BackblazeB2StorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected BackblazeB2ConnectorConfig" in error_msg or
                "S3 connector not available" in error_msg)
