#!/usr/bin/env python3
"""
Unit tests for HyperledgerSawtoothConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.hyperledger_sawtooth_connector import HyperledgerSawtoothConnectorConfig, HyperledgerSawtoothStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hyperledger_sawtooth

class TestHyperledgerSawtoothConnectorConfig:
    """Unit tests for HyperledgerSawtoothConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with REST API URL."""
        config = HyperledgerSawtoothConnectorConfig(
            address="http://localhost:8008"
        )
        assert config.connector_type == "hyperledger_sawtooth"
        assert config.url == "http://localhost:8008"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = HyperledgerSawtoothConnectorConfig(
            address="localhost:8008"
        )
        assert config.url == "http://localhost:8008"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = HyperledgerSawtoothConnectorConfig(
            address="http://localhost:8008"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "hyperledger_sawtooth"
        assert config_dict["url"] == "http://localhost:8008"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hyperledger_sawtooth

class TestHyperledgerSawtoothStorageConnection:
    """Unit tests for HyperledgerSawtoothStorageConnection."""

    def test_connection_requires_sawtooth_package(self):
        """Test that connection raises error if Sawtooth package not available."""
        config = HyperledgerSawtoothConnectorConfig(
            address="http://localhost:8008"
        )
        try:
            connection = HyperledgerSawtoothStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Sawtooth connector package" in error_msg)

    def test_connection_requires_sawtooth_config_type(self):
        """Test that connection requires HyperledgerSawtoothConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            HyperledgerSawtoothStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Sawtooth connector package" in error_msg or
                "Expected HyperledgerSawtoothConnectorConfig" in error_msg)
