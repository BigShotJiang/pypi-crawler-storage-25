#!/usr/bin/env python3
"""
Unit tests for RavenDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.ravendb_connector import RavenDBConnectorConfig, RavenDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ravendb

class TestRavenDBConnectorConfig:
    """Unit tests for RavenDBConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with server URL."""
        config = RavenDBConnectorConfig(
            address="http://localhost:8080",
            database="testdb",
            collection="users"
        )
        assert config.connector_type == "ravendb"
        assert config.url == "http://localhost:8080"
        assert config.database == "testdb"
        assert config.collection == "users"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = RavenDBConnectorConfig(
            address="http://localhost:8080",
            database="testdb",
            username="admin",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "ravendb"
        assert config_dict["url"] == "http://localhost:8080"
        assert config_dict["database"] == "testdb"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ravendb

class TestRavenDBStorageConnection:
    """Unit tests for RavenDBStorageConnection."""

    def test_connection_requires_ravendb_package(self):
        """Test that connection raises error if RavenDB package not available."""
        config = RavenDBConnectorConfig(
            address="http://localhost:8080",
            database="testdb"
        )
        try:
            connection = RavenDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "RavenDB connector package" in error_msg)

    def test_connection_requires_ravendb_config_type(self):
        """Test that connection requires RavenDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RavenDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "RavenDB connector package" in error_msg or
                "Expected RavenDBConnectorConfig" in error_msg)
