#!/usr/bin/env python3
"""
Unit tests for SeaweedFSConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.seaweedfs_connector import SeaweedFSConnectorConfig, SeaweedFSStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_seaweedfs

class TestSeaweedFSConnectorConfig:
    """Unit tests for SeaweedFSConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = SeaweedFSConnectorConfig(
            address="http://localhost:9333"
        )
        assert config.connector_type == "seaweedfs"
        assert config.url == "http://localhost:9333"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = SeaweedFSConnectorConfig(
            address="localhost:9333"
        )
        assert config.url == "http://localhost:9333"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = SeaweedFSConnectorConfig(
            address="http://localhost:9333"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "seaweedfs"
        assert config_dict["url"] == "http://localhost:9333"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_seaweedfs

class TestSeaweedFSStorageConnection:
    """Unit tests for SeaweedFSStorageConnection."""

    def test_connection_requires_seaweedfs_package(self):
        """Test that connection raises error if SeaweedFS package not available."""
        config = SeaweedFSConnectorConfig(
            address="http://localhost:9333"
        )
        try:
            connection = SeaweedFSStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "SeaweedFS connector package" in error_msg)

    def test_connection_requires_seaweedfs_config_type(self):
        """Test that connection requires SeaweedFSConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            SeaweedFSStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "SeaweedFS connector package" in error_msg or
                "Expected SeaweedFSConnectorConfig" in error_msg)
