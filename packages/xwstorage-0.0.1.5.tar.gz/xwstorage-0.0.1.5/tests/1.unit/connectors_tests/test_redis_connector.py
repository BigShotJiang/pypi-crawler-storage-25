#!/usr/bin/env python3
"""
Unit tests for RedisConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.redis_connector import RedisConnectorConfig, RedisStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redis

class TestRedisConnectorConfig:
    """Unit tests for RedisConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host and port."""
        config = RedisConnectorConfig(
            address="localhost:6379",
            db=0,
            password=None
        )
        assert config.connector_type == "redis"
        assert config.host == "localhost"
        assert config.port == 6379
        assert config.db == 0
        assert config.password is None

    def test_config_initialization_with_password(self):
        """Test config initialization with password."""
        config = RedisConnectorConfig(
            address="localhost:6379",
            db=1,
            password="secret"
        )
        assert config.host == "localhost"
        assert config.port == 6379
        assert config.db == 1
        assert config.password == "secret"

    def test_config_initialization_with_host_port_separate(self):
        """Test config initialization with separate host and port."""
        config = RedisConnectorConfig(
            address="redis-server",
            host="redis-server",
            port=6380,
            db=2
        )
        assert config.host == "redis-server"
        assert config.port == 6380
        assert config.db == 2

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = RedisConnectorConfig(
            address="localhost:6379",
            db=0,
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "redis"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 6379
        assert config_dict["db"] == 0
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 6379 when not specified."""
        config = RedisConnectorConfig(
            address="localhost",
            db=0
        )
        assert config.port == 6379
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redis

class TestRedisStorageConnection:
    """Unit tests for RedisStorageConnection."""

    def test_connection_requires_redis_package(self):
        """Test that connection raises error if Redis package not available."""
        config = RedisConnectorConfig(
            address="localhost:6379",
            db=0
        )
        try:
            connection = RedisStorageConnection(config, "json")
            # If we get here, redis package is available
            assert connection._config == config
        except XWLocationError as e:
            # Expected if redis package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_redis_config_type(self):
        """Test that connection requires RedisConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        # If Redis package is not installed, it will raise error about package first
        # If Redis package is installed, it will raise error about config type
        with pytest.raises(XWLocationError) as exc_info:
            RedisStorageConnection(local_config, "json")
        # Should raise error about either package or config type
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected RedisConnectorConfig" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = RedisConnectorConfig(
            address="localhost:6379",
            db=0
        )
        try:
            connection = RedisStorageConnection(config, "json")
            assert connection._config == config
            assert connection._use_async is not None  # Should be set based on package availability
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("Redis package not installed")

    def test_connection_serializer_format(self):
        """Test connection handles different serializer formats."""
        config = RedisConnectorConfig(
            address="localhost:6379",
            db=0
        )
        try:
            # Test JSON format
            connection = RedisStorageConnection(config, "json")
            assert connection._serializer_format == "json"
            # Test MessagePack format (if available)
            connection_msgpack = RedisStorageConnection(config, "msgpack")
            # MessagePack may fallback to JSON if not available
            assert connection_msgpack._serializer_format in ("msgpack", "json")
        except XWLocationError:
            pytest.skip("Redis package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redis
@pytest.mark.skip(reason="Requires Redis server running")

class TestRedisStorageConnectionOperations:
    """Unit tests for Redis storage operations (requires running Redis server)."""
    @pytest.fixture

    def redis_config(self):
        """Redis config for testing (requires running Redis)."""
        return RedisConnectorConfig(
            address="localhost:6379",
            db=0,
            password=None
        )
    @pytest.fixture

    async def redis_connection(self, redis_config):
        """Redis connection for testing."""
        connection = RedisStorageConnection(redis_config, "json")
        yield connection
        # Cleanup: close connection if needed
        if hasattr(connection, '_client') and connection._client:
            if connection._use_async:
                await connection._client.aclose()
    @pytest.mark.asyncio

    async def test_redis_save_and_load(self, redis_connection, sample_data, test_path):
        """Test Redis save and load operations."""
        await redis_connection.save(sample_data, test_path)
        loaded = await redis_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_redis_exists(self, redis_connection, sample_data, test_path):
        """Test Redis exists check."""
        assert await redis_connection.exists(test_path) is False
        await redis_connection.save(sample_data, test_path)
        assert await redis_connection.exists(test_path) is True
    @pytest.mark.asyncio

    async def test_redis_delete(self, redis_connection, sample_data, test_path):
        """Test Redis delete operation."""
        await redis_connection.save(sample_data, test_path)
        assert await redis_connection.exists(test_path) is True
        await redis_connection.delete(test_path)
        assert await redis_connection.exists(test_path) is False
    @pytest.mark.asyncio

    async def test_redis_list_keys(self, redis_connection, sample_data):
        """Test Redis list keys operation."""
        # Save multiple items
        await redis_connection.save(sample_data, "key1")
        await redis_connection.save(sample_data, "key2")
        # List all keys (Redis-specific)
        keys = await redis_connection.list_all()
        assert "key1" in keys
        assert "key2" in keys
