#!/usr/bin/env python3
"""
Unit tests for TiDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.tidb_connector import TiDBConnectorConfig, TiDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_tidb

class TestTiDBConnectorConfig:
    """Unit tests for TiDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = TiDBConnectorConfig(
            address="localhost:4000/test",
            database="test",
            username="root",
            password="password"
        )
        assert config.connector_type == "tidb"
        assert config.database == "test"
        assert config.username == "root"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = TiDBConnectorConfig(
            address="localhost:4000/test",
            database="test",
            username="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "tidb"
        assert config_dict["database"] == "test"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 4000 when not specified."""
        config = TiDBConnectorConfig(
            address="localhost/test",
            database="test"
        )
        assert config.port == 4000
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_tidb

class TestTiDBStorageConnection:
    """Unit tests for TiDBStorageConnection."""

    def test_connection_requires_mysql_package(self):
        """Test that connection raises error if MySQL package not available."""
        config = TiDBConnectorConfig(
            address="localhost:4000/test",
            database="test"
        )
        try:
            connection = TiDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_tidb_config_type(self):
        """Test that connection requires TiDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            TiDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected TiDBConnectorConfig" in error_msg)
