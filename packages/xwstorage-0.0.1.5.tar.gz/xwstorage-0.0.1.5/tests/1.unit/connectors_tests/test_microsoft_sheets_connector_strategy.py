#!/usr/bin/env python3
"""
Unit tests for Microsoft Sheets connector strategy.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import patch, MagicMock
from exonware.xwstorage.connectors.microsoft_sheets_connector_strategy import MicrosoftSheetsConnector
from exonware.xwstorage.errors import XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_microsoft_sheets

class TestMicrosoftSheetsConnector:
    """Unit tests for MicrosoftSheetsConnector."""

    def test_connector_initialization(self):
        """Test connector initialization."""
        connector = MicrosoftSheetsConnector(
            spreadsheet_id="test-spreadsheet-id",
            client_id="test-client-id",
            client_secret="test-secret"
        )
        assert connector.connector_type == "microsoft_sheets"
        assert connector.spreadsheet_id == "test-spreadsheet-id"
        assert connector.client_id == "test-client-id"
        assert connector.drive_id == "me/drive"  # Default

    def test_connector_initialization_with_drive_id(self):
        """Test connector initialization with custom drive ID."""
        connector = MicrosoftSheetsConnector(
            spreadsheet_id="test-id",
            access_token="test-token",
            drive_id="sites/drive-id"
        )
        assert connector.drive_id == "sites/drive-id"
    @pytest.mark.asyncio

    async def test_connect_with_access_token(self):
        """Test connect with access token."""
        connector = MicrosoftSheetsConnector(
            spreadsheet_id="test-id",
            access_token="test-token"
        )
        with patch('exonware.xwstorage.connectors.microsoft_sheets_connector_strategy.MSAL_AVAILABLE', True):
            with patch('requests.get') as mock_get:
                mock_response = MagicMock()
                mock_response.status_code = 200
                mock_response.ok = True
                mock_get.return_value = mock_response
                await connector.connect()
                assert connector._connected is True
                assert connector._client is not None
    @pytest.mark.asyncio

    async def test_connect_with_app_credentials(self, mock_msal_app):
        """Test connect with app credentials."""
        connector = MicrosoftSheetsConnector(
            spreadsheet_id="test-id",
            client_id="test-client-id",
            client_secret="test-secret"
        )
        with patch('exonware.xwstorage.connectors.microsoft_sheets_connector_strategy.MSAL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.microsoft_sheets_connector_strategy.ConfidentialClientApplication', return_value=mock_msal_app):
                await connector.connect()
                assert connector._connected is True
                assert connector.access_token == "test-token"
    @pytest.mark.asyncio

    async def test_connect_requires_package(self):
        """Test that connect requires msal package."""
        connector = MicrosoftSheetsConnector(
            spreadsheet_id="test-id",
            access_token="test-token"
        )
        with patch('exonware.xwstorage.connectors.microsoft_sheets_connector_strategy.MSAL_AVAILABLE', False):
            with pytest.raises(XWStorageError, match="msal not available"):
                await connector.connect()
    @pytest.mark.asyncio

    async def test_connect_without_credentials(self):
        """Test connect without credentials raises error."""
        connector = MicrosoftSheetsConnector(spreadsheet_id="test-id")
        with patch('exonware.xwstorage.connectors.microsoft_sheets_connector_strategy.MSAL_AVAILABLE', True):
            with pytest.raises(XWStorageError, match="Microsoft Sheets authentication required"):
                await connector.connect()
    @pytest.mark.asyncio

    async def test_disconnect(self):
        """Test disconnect."""
        connector = MicrosoftSheetsConnector(
            spreadsheet_id="test-id",
            access_token="test-token"
        )
        connector._client = MagicMock()
        connector._app = MagicMock()
        connector._connected = True
        await connector.disconnect()
        assert connector._connected is False
        assert connector._client is None
        assert connector.access_token is None
