#!/usr/bin/env python3
"""
Unit tests for GreenplumConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.greenplum_connector import GreenplumConnectorConfig, GreenplumStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_greenplum

class TestGreenplumConnectorConfig:
    """Unit tests for GreenplumConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = GreenplumConnectorConfig(
            address="localhost:5432/postgres",
            database="postgres",
            username="gpadmin",
            password="password"
        )
        assert config.connector_type == "greenplum"
        assert config.database == "postgres"
        assert config.username == "gpadmin"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = GreenplumConnectorConfig(
            address="localhost:5432/postgres",
            database="postgres",
            username="gpadmin",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "greenplum"
        assert config_dict["database"] == "postgres"
        assert config_dict["username"] == "gpadmin"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_greenplum

class TestGreenplumStorageConnection:
    """Unit tests for GreenplumStorageConnection."""

    def test_connection_requires_postgresql_package(self):
        """Test that connection raises error if PostgreSQL package not available."""
        config = GreenplumConnectorConfig(
            address="localhost:5432/postgres",
            database="postgres"
        )
        try:
            connection = GreenplumStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_greenplum_config_type(self):
        """Test that connection requires GreenplumConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            GreenplumStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected GreenplumConnectorConfig" in error_msg)
