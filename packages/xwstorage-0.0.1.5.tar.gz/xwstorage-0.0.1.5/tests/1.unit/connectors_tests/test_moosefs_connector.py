#!/usr/bin/env python3
"""
Unit tests for MooseFSConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.moosefs_connector import MooseFSConnectorConfig, MooseFSStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_moosefs

class TestMooseFSConnectorConfig:
    """Unit tests for MooseFSConnectorConfig."""

    def test_config_initialization_with_mount_point(self):
        """Test config initialization with mount point path."""
        config = MooseFSConnectorConfig(
            address="/mnt/moosefs"
        )
        assert config.connector_type == "moosefs"
        assert str(config.mount_point) == "/mnt/moosefs"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = MooseFSConnectorConfig(
            address="/mnt/moosefs"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "moosefs"
        assert config_dict["mount_point"] == "/mnt/moosefs"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_moosefs

class TestMooseFSStorageConnection:
    """Unit tests for MooseFSStorageConnection."""

    def test_connection_requires_moosefs_config_type(self):
        """Test that connection requires MooseFSConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MooseFSStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected MooseFSConnectorConfig" in error_msg)
