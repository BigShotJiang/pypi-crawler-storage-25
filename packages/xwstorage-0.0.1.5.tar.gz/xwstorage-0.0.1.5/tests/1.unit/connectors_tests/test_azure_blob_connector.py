#!/usr/bin/env python3
"""
Unit tests for AzureBlobConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.azure_blob_connector import AzureBlobConnectorConfig, AzureBlobStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_azure_blob

class TestAzureBlobConnectorConfig:
    """Unit tests for AzureBlobConnectorConfig."""

    def test_config_initialization_with_container(self):
        """Test config initialization with container name."""
        config = AzureBlobConnectorConfig(
            container="my-container",
            account_name="myaccount",
            account_key="account-key"
        )
        assert config.connector_type == "azure_blob"
        assert config.container == "my-container"
        assert config.account_name == "myaccount"
        assert config.account_key == "account-key"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string."""
        config = AzureBlobConnectorConfig(
            container="my-container",
            connection_string="DefaultEndpointsProtocol=https;AccountName=myaccount;AccountKey=account-key;EndpointSuffix=core.windows.net"
        )
        assert config.container == "my-container"
        assert config.connection_string is not None

    def test_config_to_dict(self):
        """Test config to_dict conversion (account_key not included)."""
        config = AzureBlobConnectorConfig(
            container="my-container",
            account_name="myaccount",
            account_key="secret-key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "azure_blob"
        assert config_dict["container"] == "my-container"
        assert config_dict["account_name"] == "myaccount"
        assert "account_key" not in config_dict  # Secret should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_azure_blob

class TestAzureBlobStorageConnection:
    """Unit tests for AzureBlobStorageConnection."""

    def test_connection_requires_azure_storage_package(self):
        """Test that connection raises error if Azure Storage package not available."""
        config = AzureBlobConnectorConfig(
            container="my-container",
            account_name="myaccount",
            account_key="account-key"
        )
        try:
            connection = AzureBlobStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_azure_blob_config_type(self):
        """Test that connection requires AzureBlobConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            AzureBlobStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected AzureBlobConnectorConfig" in error_msg)
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_azure_blob
@pytest.mark.skip(reason="Requires Azure credentials and storage container")

class TestAzureBlobStorageConnectionOperations:
    """Unit tests for Azure Blob storage operations (requires Azure credentials)."""
    @pytest.fixture

    def azure_blob_config(self):
        """Azure Blob config for testing."""
        return AzureBlobConnectorConfig(
            container="test-container",
            account_name="testaccount",
            account_key="test-key"
        )
    @pytest.fixture

    async def azure_blob_connection(self, azure_blob_config):
        """Azure Blob connection for testing."""
        connection = AzureBlobStorageConnection(azure_blob_config, "json")
        yield connection
    @pytest.mark.asyncio

    async def test_azure_blob_save_and_load(self, azure_blob_connection, sample_data, test_path):
        """Test Azure Blob save and load operations."""
        await azure_blob_connection.save(sample_data, test_path)
        loaded = await azure_blob_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_azure_blob_exists(self, azure_blob_connection, sample_data, test_path):
        """Test Azure Blob exists check."""
        assert await azure_blob_connection.exists(test_path) is False
        await azure_blob_connection.save(sample_data, test_path)
        assert await azure_blob_connection.exists(test_path) is True
