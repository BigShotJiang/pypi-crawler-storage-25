#!/usr/bin/env python3
"""
Unit tests for SupabaseConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.supabase_connector import SupabaseConnectorConfig, SupabaseStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_supabase

class TestSupabaseConnectorConfig:
    """Unit tests for SupabaseConnectorConfig."""

    def test_config_initialization_with_project_url(self):
        """Test config initialization with Supabase project URL."""
        config = SupabaseConnectorConfig(
            address="https://xyz.supabase.co",
            database="postgres",
            username="postgres",
            password="password"
        )
        assert config.connector_type == "supabase"
        assert config.database == "postgres"
        assert config.username == "postgres"

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = SupabaseConnectorConfig(
            address="localhost:5432/postgres",
            username="postgres",
            password="password"
        )
        assert config.database == "postgres"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = SupabaseConnectorConfig(
            address="https://xyz.supabase.co",
            database="postgres",
            username="postgres",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "supabase"
        assert config_dict["database"] == "postgres"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_database(self):
        """Test config uses default database when not specified."""
        config = SupabaseConnectorConfig(
            address="https://xyz.supabase.co"
        )
        assert config.database == "postgres"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_supabase

class TestSupabaseStorageConnection:
    """Unit tests for SupabaseStorageConnection."""

    def test_connection_requires_postgresql_package(self):
        """Test that connection raises error if PostgreSQL package not available."""
        config = SupabaseConnectorConfig(
            address="https://xyz.supabase.co",
            database="postgres"
        )
        try:
            connection = SupabaseStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_supabase_config_type(self):
        """Test that connection requires SupabaseConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            SupabaseStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected SupabaseConnectorConfig" in error_msg)
