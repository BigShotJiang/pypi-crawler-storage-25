#!/usr/bin/env python3
"""
Unit tests for ExcelConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from pathlib import Path
from exonware.xwstorage.connectors.excel_connector_strategy import ExcelConnector
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_excel

class TestExcelConnector:
    """Unit tests for ExcelConnector."""

    def test_connector_initialization_with_file_path(self):
        """Test connector initialization with file path."""
        connector = ExcelConnector(
            file_path=Path("/tmp/test.xlsx")
        )
        assert connector.file_path == Path("/tmp/test.xlsx")

    def test_connector_type(self):
        """Test connector type property."""
        connector = ExcelConnector(
            file_path=Path("/tmp/test.xlsx")
        )
        assert connector.connector_type == "excel"
