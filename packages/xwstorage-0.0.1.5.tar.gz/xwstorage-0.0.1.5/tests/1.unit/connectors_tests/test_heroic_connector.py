#!/usr/bin/env python3
"""
Unit tests for HeroicConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.heroic_connector import HeroicConnectorConfig, HeroicStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_heroic

class TestHeroicConnectorConfig:
    """Unit tests for HeroicConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = HeroicConnectorConfig(
            address="http://localhost:8080"
        )
        assert config.connector_type == "heroic"
        assert config.base_url == "http://localhost:8080"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = HeroicConnectorConfig(
            address="localhost:8080"
        )
        assert config.base_url == "http://localhost:8080"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = HeroicConnectorConfig(
            address="http://localhost:8080"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "heroic"
        assert config_dict["base_url"] == "http://localhost:8080"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_heroic

class TestHeroicStorageConnection:
    """Unit tests for HeroicStorageConnection."""

    def test_connection_requires_heroic_package(self):
        """Test that connection raises error if Heroic package not available."""
        config = HeroicConnectorConfig(
            address="http://localhost:8080"
        )
        try:
            connection = HeroicStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Heroic connector package" in error_msg)

    def test_connection_requires_heroic_config_type(self):
        """Test that connection requires HeroicConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            HeroicStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Heroic connector package" in error_msg or
                "Expected HeroicConnectorConfig" in error_msg)
