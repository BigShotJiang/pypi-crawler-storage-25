#!/usr/bin/env python3
"""
Unit tests for HazelcastConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.hazelcast_connector import HazelcastConnectorConfig, HazelcastStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hazelcast

class TestHazelcastConnectorConfig:
    """Unit tests for HazelcastConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = HazelcastConnectorConfig(
            address="localhost:5701",
            cluster_name="dev"
        )
        assert config.connector_type == "hazelcast"
        assert config.host == "localhost"
        assert config.port == 5701
        assert config.cluster_name == "dev"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 5701)."""
        config = HazelcastConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 5701

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = HazelcastConnectorConfig(
            address="localhost:5701",
            cluster_name="prod"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "hazelcast"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 5701
        assert config_dict["cluster_name"] == "prod"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hazelcast

class TestHazelcastStorageConnection:
    """Unit tests for HazelcastStorageConnection."""

    def test_connection_requires_hazelcast_package(self):
        """Test that connection raises error if Hazelcast package not available."""
        config = HazelcastConnectorConfig(
            address="localhost:5701"
        )
        try:
            connection = HazelcastStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_hazelcast_config_type(self):
        """Test that connection requires HazelcastConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            HazelcastStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected HazelcastConnectorConfig" in error_msg)
