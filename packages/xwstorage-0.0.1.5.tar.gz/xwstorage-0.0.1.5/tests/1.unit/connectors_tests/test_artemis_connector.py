#!/usr/bin/env python3
"""
Unit tests for ArtemisConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.artemis_connector import ArtemisConnectorConfig, ArtemisStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_artemis

class TestArtemisConnectorConfig:
    """Unit tests for ArtemisConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = ArtemisConnectorConfig(
            address="localhost:61616"
        )
        assert config.connector_type == "artemis"
        assert config.host == "localhost"
        assert config.port == 61616

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 61616)."""
        config = ArtemisConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 61616

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ArtemisConnectorConfig(
            address="localhost:61616"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "artemis"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 61616
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_artemis

class TestArtemisStorageConnection:
    """Unit tests for ArtemisStorageConnection."""

    def test_connection_requires_artemis_package(self):
        """Test that connection raises error if Artemis package not available."""
        config = ArtemisConnectorConfig(
            address="localhost:61616"
        )
        try:
            connection = ArtemisStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_artemis_config_type(self):
        """Test that connection requires ArtemisConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ArtemisStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected ArtemisConnectorConfig" in error_msg)
