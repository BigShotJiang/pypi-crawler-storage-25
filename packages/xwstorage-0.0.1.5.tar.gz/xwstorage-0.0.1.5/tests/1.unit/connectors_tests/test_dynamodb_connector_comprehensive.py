#!/usr/bin/env python3
"""
Comprehensive unit tests for DynamoDBConnector - 100% coverage target.
Tests all code paths including error handling and edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from exonware.xwstorage.connectors.dynamodb_connector import DynamoDBConnectorConfig, DynamoDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dynamodb

class TestDynamoDBConnectorConfigComprehensive:
    """Comprehensive tests for DynamoDBConnectorConfig."""

    def test_config_initialization_variations(self):
        """Test various initialization scenarios."""
        # Test with table name and region
        config = DynamoDBConnectorConfig(
            table_name="mytable",
            region="us-east-1",
            access_key_id="AKIA...",
            secret_access_key="secret"
        )
        assert config.connector_type == "dynamodb"
        assert config.table_name == "mytable"
        assert config.region == "us-east-1"
        # Test with endpoint_url (for local DynamoDB)
        config2 = DynamoDBConnectorConfig(
            table_name="mytable",
            region="us-east-1",
            endpoint_url="http://localhost:8000"
        )
        assert config2.endpoint_url == "http://localhost:8000"

    def test_config_to_dict(self):
        """Test to_dict conversion."""
        config = DynamoDBConnectorConfig(
            table_name="test_table",
            region="us-west-2",
            access_key_id="AKIA...",
            secret_access_key="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "dynamodb"
        assert config_dict["table_name"] == "test_table"
        assert config_dict["region"] == "us-west-2"
        assert "secret_access_key" not in config_dict or config_dict["secret_access_key"] == "***"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dynamodb

class TestDynamoDBStorageConnectionComprehensive:
    """Comprehensive tests for DynamoDBStorageConnection."""
    @pytest.fixture

    def dynamodb_config(self):
        """DynamoDB config for testing."""
        return DynamoDBConnectorConfig(
            table_name="test_table",
            region="us-east-1",
            access_key_id="AKIA...",
            secret_access_key="secret"
        )

    def test_connection_requires_boto3_package(self, dynamodb_config):
        """Test that connection raises error if boto3 package not available."""
        with patch('exonware.xwstorage.connectors.dynamodb_connector.DYNAMODB_AVAILABLE', False):
            with pytest.raises(XWLocationError) as exc_info:
                DynamoDBStorageConnection(dynamodb_config, "json")
            error_msg = str(exc_info.value)
            assert "not installed" in error_msg.lower()

    def test_connection_requires_dynamodb_config_type(self):
        """Test that connection requires DynamoDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DynamoDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected DynamoDBConnectorConfig" in error_msg)
