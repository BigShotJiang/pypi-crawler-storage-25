#!/usr/bin/env python3
"""
Unit tests for CosmosDBEmulatorConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.cosmosdb_emulator_connector import CosmosDBEmulatorConnectorConfig, CosmosDBEmulatorStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cosmosdb_emulator

class TestCosmosDBEmulatorConnectorConfig:
    """Unit tests for CosmosDBEmulatorConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with endpoint URL."""
        config = CosmosDBEmulatorConnectorConfig(
            address="https://localhost:8081",
            key="test_key",
            database="test"
        )
        assert config.connector_type == "cosmosdb_emulator"
        assert config.url == "https://localhost:8081"
        assert config.key == "test_key"
        assert config.database == "test"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTPS)."""
        config = CosmosDBEmulatorConnectorConfig(
            address="localhost:8081"
        )
        assert config.url == "https://localhost:8081"

    def test_config_to_dict(self):
        """Test config to_dict conversion (key masked)."""
        config = CosmosDBEmulatorConnectorConfig(
            address="https://localhost:8081",
            key="secret_key",
            database="test"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "cosmosdb_emulator"
        assert config_dict["url"] == "https://localhost:8081"
        assert config_dict["database"] == "test"
        assert config_dict["key"] == "***"  # Key should be masked

    def test_config_default_values(self):
        """Test config uses default values when not specified."""
        config = CosmosDBEmulatorConnectorConfig()
        assert config.url == "https://localhost:8081"
        assert config.database == "test"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cosmosdb_emulator

class TestCosmosDBEmulatorStorageConnection:
    """Unit tests for CosmosDBEmulatorStorageConnection."""

    def test_connection_requires_cosmosdb_package(self):
        """Test that connection raises error if CosmosDB package not available."""
        config = CosmosDBEmulatorConnectorConfig(
            address="https://localhost:8081"
        )
        try:
            connection = CosmosDBEmulatorStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_cosmosdb_emulator_config_type(self):
        """Test that connection requires CosmosDBEmulatorConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            CosmosDBEmulatorStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected CosmosDBEmulatorConnectorConfig" in error_msg)
