#!/usr/bin/env python3
"""
Unit tests for YugabyteDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.yugabytedb_connector import YugabyteDBConnectorConfig, YugabyteDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_yugabytedb

class TestYugabyteDBConnectorConfig:
    """Unit tests for YugabyteDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = YugabyteDBConnectorConfig(
            address="localhost:5433/yugabyte",
            database="yugabyte",
            username="yugabyte",
            password="password"
        )
        assert config.connector_type == "yugabytedb"
        assert config.database == "yugabyte"
        assert config.username == "yugabyte"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = YugabyteDBConnectorConfig(
            address="localhost:5433/yugabyte",
            database="yugabyte",
            username="yugabyte",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "yugabytedb"
        assert config_dict["database"] == "yugabyte"
        assert config_dict["username"] == "yugabyte"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_yugabytedb

class TestYugabyteDBStorageConnection:
    """Unit tests for YugabyteDBStorageConnection."""

    def test_connection_requires_postgresql_package(self):
        """Test that connection raises error if PostgreSQL package not available."""
        config = YugabyteDBConnectorConfig(
            address="localhost:5433/yugabyte",
            database="yugabyte"
        )
        try:
            connection = YugabyteDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_yugabytedb_config_type(self):
        """Test that connection requires YugabyteDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            YugabyteDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected YugabyteDBConnectorConfig" in error_msg)
