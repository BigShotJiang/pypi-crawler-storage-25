#!/usr/bin/env python3
"""
Unit tests for S3Connector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.s3_connector import S3ConnectorConfig, S3StorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_s3

class TestS3ConnectorConfig:
    """Unit tests for S3ConnectorConfig."""

    def test_config_initialization_with_bucket(self):
        """Test config initialization with bucket name."""
        config = S3ConnectorConfig(
            bucket="my-bucket",
            region="us-east-1"
        )
        assert config.connector_type == "s3"
        assert config.bucket == "my-bucket"
        assert config.region == "us-east-1"

    def test_config_initialization_with_credentials(self):
        """Test config initialization with AWS credentials."""
        config = S3ConnectorConfig(
            bucket="my-bucket",
            region="us-west-2",
            access_key_id="AKIAIOSFODNN7EXAMPLE",
            secret_access_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        )
        assert config.bucket == "my-bucket"
        assert config.region == "us-west-2"
        assert config.access_key_id == "AKIAIOSFODNN7EXAMPLE"
        assert config.secret_access_key == "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

    def test_config_initialization_with_custom_endpoint(self):
        """Test config initialization with custom endpoint (S3-compatible)."""
        config = S3ConnectorConfig(
            bucket="my-bucket",
            region="us-east-1",
            endpoint_url="https://s3.example.com"
        )
        assert config.bucket == "my-bucket"
        assert config.endpoint_url == "https://s3.example.com"

    def test_config_to_dict(self):
        """Test config to_dict conversion (secret not included)."""
        config = S3ConnectorConfig(
            bucket="my-bucket",
            region="us-east-1",
            access_key_id="AKIAIOSFODNN7EXAMPLE",
            secret_access_key="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "s3"
        assert config_dict["bucket"] == "my-bucket"
        assert config_dict["region"] == "us-east-1"
        assert config_dict["access_key_id"] == "AKIAIOSFODNN7EXAMPLE"
        assert "secret_access_key" not in config_dict  # Secret should not be in dict

    def test_config_default_region(self):
        """Test config uses default region when not specified."""
        config = S3ConnectorConfig(
            bucket="my-bucket"
        )
        assert config.region == "us-east-1"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_s3

class TestS3StorageConnection:
    """Unit tests for S3StorageConnection."""

    def test_connection_requires_boto3_package(self):
        """Test that connection raises error if boto3 package not available."""
        config = S3ConnectorConfig(
            bucket="my-bucket",
            region="us-east-1"
        )
        try:
            connection = S3StorageConnection(config, "json")
            # If we get here, boto3 package is available
            assert connection._config == config
        except XWLocationError as e:
            # Expected if boto3 package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_s3_config_type(self):
        """Test that connection requires S3ConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        # If boto3 package is not installed, it will raise error about package first
        # If boto3 package is installed, it will raise error about config type
        with pytest.raises(XWLocationError) as exc_info:
            S3StorageConnection(local_config, "json")
        # Should raise error about either package or config type
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected S3ConnectorConfig" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = S3ConnectorConfig(
            bucket="my-bucket",
            region="us-east-1"
        )
        try:
            connection = S3StorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("boto3 package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_s3
@pytest.mark.skip(reason="Requires AWS credentials and S3 bucket")

class TestS3StorageConnectionOperations:
    """Unit tests for S3 storage operations (requires AWS credentials and bucket)."""
    @pytest.fixture

    def s3_config(self):
        """S3 config for testing (requires AWS credentials)."""
        return S3ConnectorConfig(
            bucket="test-bucket",
            region="us-east-1",
            access_key_id="AKIAIOSFODNN7EXAMPLE",
            secret_access_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        )
    @pytest.fixture

    async def s3_connection(self, s3_config):
        """S3 connection for testing."""
        connection = S3StorageConnection(s3_config, "json")
        yield connection
    @pytest.mark.asyncio

    async def test_s3_save_and_load(self, s3_connection, sample_data, test_path):
        """Test S3 save and load operations."""
        await s3_connection.save(sample_data, test_path)
        loaded = await s3_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_s3_exists(self, s3_connection, sample_data, test_path):
        """Test S3 exists check."""
        assert await s3_connection.exists(test_path) is False
        await s3_connection.save(sample_data, test_path)
        assert await s3_connection.exists(test_path) is True
    @pytest.mark.asyncio

    async def test_s3_delete(self, s3_connection, sample_data, test_path):
        """Test S3 delete operation."""
        await s3_connection.save(sample_data, test_path)
        assert await s3_connection.exists(test_path) is True
        await s3_connection.delete(test_path)
        assert await s3_connection.exists(test_path) is False
    @pytest.mark.asyncio

    async def test_s3_list_objects(self, s3_connection, sample_data):
        """Test S3 list objects operation."""
        # Save multiple objects
        await s3_connection.save(sample_data, "object1")
        await s3_connection.save(sample_data, "object2")
        # List all objects
        objects = await s3_connection.list_all()
        assert "object1" in objects
        assert "object2" in objects
