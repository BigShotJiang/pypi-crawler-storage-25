#!/usr/bin/env python3
"""
Unit tests for RethinkDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.rethinkdb_connector import RethinkDBConnectorConfig, RethinkDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_rethinkdb

class TestRethinkDBConnectorConfig:
    """Unit tests for RethinkDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = RethinkDBConnectorConfig(
            address="localhost:28015",
            database="testdb",
            table="users"
        )
        assert config.connector_type == "rethinkdb"
        assert config.host == "localhost"
        assert config.port == 28015
        assert config.database == "testdb"
        assert config.table == "users"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 28015)."""
        config = RethinkDBConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 28015

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RethinkDBConnectorConfig(
            address="localhost:28015",
            database="testdb"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "rethinkdb"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 28015
        assert config_dict["database"] == "testdb"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_rethinkdb

class TestRethinkDBStorageConnection:
    """Unit tests for RethinkDBStorageConnection."""

    def test_connection_requires_rethinkdb_package(self):
        """Test that connection raises error if RethinkDB package not available."""
        config = RethinkDBConnectorConfig(
            address="localhost:28015"
        )
        try:
            connection = RethinkDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_rethinkdb_config_type(self):
        """Test that connection requires RethinkDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RethinkDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected RethinkDBConnectorConfig" in error_msg)
