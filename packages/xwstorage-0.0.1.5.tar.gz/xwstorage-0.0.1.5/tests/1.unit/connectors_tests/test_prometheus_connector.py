#!/usr/bin/env python3
"""
Unit tests for PrometheusConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.prometheus_connector import PrometheusConnectorConfig, PrometheusStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_prometheus

class TestPrometheusConnectorConfig:
    """Unit tests for PrometheusConnectorConfig."""

    def test_config_initialization_with_http_url(self):
        """Test config initialization with HTTP URL."""
        config = PrometheusConnectorConfig(
            address="http://localhost:9090"
        )
        assert config.connector_type == "prometheus"
        assert config.url == "http://localhost:9090"

    def test_config_initialization_with_https_url(self):
        """Test config initialization with HTTPS URL."""
        config = PrometheusConnectorConfig(
            address="https://prometheus.example.com"
        )
        assert config.url == "https://prometheus.example.com"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = PrometheusConnectorConfig(
            address="localhost:9090"
        )
        assert config.url == "http://localhost:9090"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = PrometheusConnectorConfig(
            address="http://localhost:9090"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "prometheus"
        assert config_dict["url"] == "http://localhost:9090"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_prometheus

class TestPrometheusStorageConnection:
    """Unit tests for PrometheusStorageConnection."""

    def test_connection_requires_prometheus_package(self):
        """Test that connection raises error if Prometheus package not available."""
        config = PrometheusConnectorConfig(
            address="http://localhost:9090"
        )
        try:
            connection = PrometheusStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_prometheus_config_type(self):
        """Test that connection requires PrometheusConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            PrometheusStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected PrometheusConnectorConfig" in error_msg)
