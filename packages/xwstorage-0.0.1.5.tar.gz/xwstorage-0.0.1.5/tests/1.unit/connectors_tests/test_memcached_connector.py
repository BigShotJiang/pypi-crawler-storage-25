#!/usr/bin/env python3
"""
Unit tests for MemcachedConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.memcached_connector import MemcachedConnectorConfig, MemcachedStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_memcached

class TestMemcachedConnectorConfig:
    """Unit tests for MemcachedConnectorConfig."""

    def test_config_initialization_single_server(self):
        """Test config initialization with single server."""
        config = MemcachedConnectorConfig(
            address="localhost:11211"
        )
        assert config.connector_type == "memcached"
        assert config.servers == ["localhost:11211"]
        assert config.host == "localhost"
        assert config.port == 11211

    def test_config_initialization_multiple_servers(self):
        """Test config initialization with multiple servers."""
        config = MemcachedConnectorConfig(
            address="localhost:11211,memcached2:11211,memcached3:11211"
        )
        assert len(config.servers) == 3
        assert "localhost:11211" in config.servers
        assert "memcached2:11211" in config.servers
        assert "memcached3:11211" in config.servers

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = MemcachedConnectorConfig(
            address="localhost:11211"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "memcached"
        assert config_dict["servers"] == ["localhost:11211"]

    def test_config_default_port(self):
        """Test config uses default port 11211 when not specified."""
        config = MemcachedConnectorConfig(
            address="localhost"
        )
        assert config.port == 11211
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_memcached

class TestMemcachedStorageConnection:
    """Unit tests for MemcachedStorageConnection."""

    def test_connection_requires_memcached_package(self):
        """Test that connection raises error if Memcached package not available."""
        config = MemcachedConnectorConfig(
            address="localhost:11211"
        )
        try:
            connection = MemcachedStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_memcached_config_type(self):
        """Test that connection requires MemcachedConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MemcachedStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected MemcachedConnectorConfig" in error_msg)
