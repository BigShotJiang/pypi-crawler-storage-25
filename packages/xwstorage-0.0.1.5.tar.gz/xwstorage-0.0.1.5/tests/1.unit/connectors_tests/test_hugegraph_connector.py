#!/usr/bin/env python3
"""
Unit tests for HugeGraphConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.hugegraph_connector import HugeGraphConnectorConfig, HugeGraphStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hugegraph

class TestHugeGraphConnectorConfig:
    """Unit tests for HugeGraphConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = HugeGraphConnectorConfig(
            address="http://localhost:8080",
            graph="hugegraph"
        )
        assert config.connector_type == "hugegraph"
        assert config.url == "http://localhost:8080"
        assert config.graph == "hugegraph"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = HugeGraphConnectorConfig(
            address="localhost:8080"
        )
        assert config.url == "http://localhost:8080"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = HugeGraphConnectorConfig(
            address="http://localhost:8080",
            graph="mygraph"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "hugegraph"
        assert config_dict["url"] == "http://localhost:8080"
        assert config_dict["graph"] == "mygraph"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hugegraph

class TestHugeGraphStorageConnection:
    """Unit tests for HugeGraphStorageConnection."""

    def test_connection_requires_hugegraph_package(self):
        """Test that connection raises error if HugeGraph package not available."""
        config = HugeGraphConnectorConfig(
            address="http://localhost:8080"
        )
        try:
            connection = HugeGraphStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "HugeGraph connector package" in error_msg)

    def test_connection_requires_hugegraph_config_type(self):
        """Test that connection requires HugeGraphConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            HugeGraphStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "HugeGraph connector package" in error_msg or
                "Expected HugeGraphConnectorConfig" in error_msg)
