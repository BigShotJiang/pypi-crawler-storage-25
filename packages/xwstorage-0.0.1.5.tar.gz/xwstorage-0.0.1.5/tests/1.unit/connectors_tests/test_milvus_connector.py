#!/usr/bin/env python3
"""
Unit tests for MilvusConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.milvus_connector import MilvusConnectorConfig, MilvusStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_milvus

class TestMilvusConnectorConfig:
    """Unit tests for MilvusConnectorConfig."""

    def test_config_initialization_with_uri(self):
        """Test config initialization with HTTP URI."""
        config = MilvusConnectorConfig(
            address="http://localhost:19530",
            collection_name="my_collection",
            dimension=128
        )
        assert config.connector_type == "milvus"
        assert config.uri == "http://localhost:19530"
        assert config.collection_name == "my_collection"
        assert config.dimension == 128

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = MilvusConnectorConfig(
            address="localhost:19530",
            collection_name="my_collection"
        )
        assert config.uri == "http://localhost:19530"
        assert config.collection_name == "my_collection"

    def test_config_initialization_host_only(self):
        """Test config initialization with host only (defaults port)."""
        config = MilvusConnectorConfig(
            address="localhost"
        )
        assert config.uri == "http://localhost:19530"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = MilvusConnectorConfig(
            address="http://localhost:19530",
            collection_name="my_collection",
            dimension=256
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "milvus"
        assert config_dict["uri"] == "http://localhost:19530"
        assert config_dict["collection_name"] == "my_collection"
        assert config_dict["dimension"] == 256
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_milvus

class TestMilvusStorageConnection:
    """Unit tests for MilvusStorageConnection."""

    def test_connection_requires_milvus_package(self):
        """Test that connection raises error if Milvus package not available."""
        config = MilvusConnectorConfig(
            address="http://localhost:19530"
        )
        try:
            connection = MilvusStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_milvus_config_type(self):
        """Test that connection requires MilvusConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MilvusStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected MilvusConnectorConfig" in error_msg)
