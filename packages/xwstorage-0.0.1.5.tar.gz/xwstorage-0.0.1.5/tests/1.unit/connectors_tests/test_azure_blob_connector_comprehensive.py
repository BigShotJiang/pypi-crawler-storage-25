#!/usr/bin/env python3
"""
Comprehensive unit tests for AzureBlobConnector - 100% coverage target.
Tests all code paths including error handling and edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from exonware.xwstorage.connectors.azure_blob_connector import AzureBlobConnectorConfig, AzureBlobStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_azure_blob

class TestAzureBlobConnectorConfigComprehensive:
    """Comprehensive tests for AzureBlobConnectorConfig."""

    def test_config_initialization_variations(self):
        """Test various initialization scenarios."""
        # Test with account name and key
        config = AzureBlobConnectorConfig(
            bucket="my-container",
            account_name="mystorageaccount",
            account_key="key"
        )
        assert config.connector_type == "azure_blob"
        assert config.bucket == "my-container"
        assert config.container == "my-container"
        assert config.account_name == "mystorageaccount"
        # Test with connection string
        config2 = AzureBlobConnectorConfig(
            bucket="my-container",
            connection_string="DefaultEndpointsProtocol=https;AccountName=..."
        )
        assert config2.connection_string is not None
        # Test with SAS token
        config3 = AzureBlobConnectorConfig(
            bucket="my-container",
            account_name="mystorageaccount",
            sas_token="?sv=..."
        )
        assert config3.sas_token == "?sv=..."

    def test_config_to_dict(self):
        """Test to_dict conversion (connection_string masked)."""
        config = AzureBlobConnectorConfig(
            bucket="test-container",
            account_name="testaccount",
            connection_string="DefaultEndpointsProtocol=https;..."
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "azure_blob"
        assert config_dict["bucket"] == "test-container"
        assert config_dict["container"] == "test-container"
        if "connection_string" in config_dict:
            assert config_dict["connection_string"] == "***"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_azure_blob

class TestAzureBlobStorageConnectionComprehensive:
    """Comprehensive tests for AzureBlobStorageConnection."""
    @pytest.fixture

    def azure_config(self):
        """Azure Blob config for testing."""
        return AzureBlobConnectorConfig(
            bucket="test-container",
            account_name="testaccount",
            account_key="key"
        )

    def test_connection_requires_azure_package(self, azure_config):
        """Test that connection raises error if Azure package not available."""
        with patch('exonware.xwstorage.connectors.azure_blob_connector.AZURE_BLOB_AVAILABLE', False):
            with pytest.raises(XWLocationError) as exc_info:
                AzureBlobStorageConnection(azure_config, "json")
            error_msg = str(exc_info.value)
            assert "not installed" in error_msg.lower()

    def test_connection_requires_azure_config_type(self):
        """Test that connection requires AzureBlobConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            AzureBlobStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected AzureBlobConnectorConfig" in error_msg)
