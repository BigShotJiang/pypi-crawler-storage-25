#!/usr/bin/env python3
"""
Unit tests for DruidConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.druid_connector import DruidConnectorConfig, DruidStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_druid

class TestDruidConnectorConfig:
    """Unit tests for DruidConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = DruidConnectorConfig(
            address="http://localhost:8082"
        )
        assert config.connector_type == "druid"
        assert config.url == "http://localhost:8082"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = DruidConnectorConfig(
            address="localhost:8082"
        )
        assert config.url == "http://localhost:8082"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = DruidConnectorConfig(
            address="http://localhost:8082"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "druid"
        assert config_dict["url"] == "http://localhost:8082"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_druid

class TestDruidStorageConnection:
    """Unit tests for DruidStorageConnection."""

    def test_connection_requires_druid_package(self):
        """Test that connection raises error if Druid package not available."""
        config = DruidConnectorConfig(
            address="http://localhost:8082"
        )
        try:
            connection = DruidStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Druid connector package" in error_msg)

    def test_connection_requires_druid_config_type(self):
        """Test that connection requires DruidConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DruidStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Druid connector package" in error_msg or
                "Expected DruidConnectorConfig" in error_msg)
