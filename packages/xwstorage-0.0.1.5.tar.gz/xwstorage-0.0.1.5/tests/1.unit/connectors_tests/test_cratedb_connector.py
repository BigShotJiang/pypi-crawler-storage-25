#!/usr/bin/env python3
"""
Unit tests for CrateDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.cratedb_connector import CrateDBConnectorConfig, CrateDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cratedb

class TestCrateDBConnectorConfig:
    """Unit tests for CrateDBConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = CrateDBConnectorConfig(
            address="http://localhost:4200",
            database="doc"
        )
        assert config.connector_type == "cratedb"
        assert config.base_url == "http://localhost:4200"
        assert config.database == "doc"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = CrateDBConnectorConfig(
            address="localhost:4200"
        )
        assert config.base_url == "http://localhost:4200"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password masked)."""
        config = CrateDBConnectorConfig(
            address="http://localhost:4200",
            database="doc",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "cratedb"
        assert config_dict["base_url"] == "http://localhost:4200"
        if "password" in config_dict:
            assert config_dict["password"] == "***"  # Password should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cratedb

class TestCrateDBStorageConnection:
    """Unit tests for CrateDBStorageConnection."""

    def test_connection_requires_cratedb_package(self):
        """Test that connection raises error if CrateDB package not available."""
        config = CrateDBConnectorConfig(
            address="http://localhost:4200"
        )
        try:
            connection = CrateDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "CrateDB connector package" in error_msg)

    def test_connection_requires_cratedb_config_type(self):
        """Test that connection requires CrateDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            CrateDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "CrateDB connector package" in error_msg or
                "Expected CrateDBConnectorConfig" in error_msg)
