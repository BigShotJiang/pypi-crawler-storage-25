#!/usr/bin/env python3
"""
Unit tests for ApacheDerbyConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.apache_derby_connector import ApacheDerbyConnectorConfig, ApacheDerbyStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_derby

class TestApacheDerbyConnectorConfig:
    """Unit tests for ApacheDerbyConnectorConfig."""

    def test_config_initialization_with_jdbc_url(self):
        """Test config initialization with JDBC URL."""
        config = ApacheDerbyConnectorConfig(
            address="jdbc:derby:~/testdb;create=true"
        )
        assert config.connector_type == "apache_derby"
        assert config.jdbc_url == "jdbc:derby:~/testdb;create=true"

    def test_config_initialization_with_path(self):
        """Test config initialization with file path."""
        config = ApacheDerbyConnectorConfig(
            address="~/testdb"
        )
        assert config.jdbc_url.startswith("jdbc:derby:")
        assert "create=true" in config.jdbc_url

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ApacheDerbyConnectorConfig(
            address="jdbc:derby:~/testdb;create=true"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "apache_derby"
        assert config_dict["jdbc_url"] == "jdbc:derby:~/testdb;create=true"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_derby

class TestApacheDerbyStorageConnection:
    """Unit tests for ApacheDerbyStorageConnection."""

    def test_connection_requires_derby_package(self):
        """Test that connection raises error if Derby package not available."""
        config = ApacheDerbyConnectorConfig(
            address="jdbc:derby:~/testdb"
        )
        try:
            connection = ApacheDerbyStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_derby_config_type(self):
        """Test that connection requires ApacheDerbyConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ApacheDerbyStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected ApacheDerbyConnectorConfig" in error_msg)
