#!/usr/bin/env python3
"""
Unit tests for BigchainDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.bigchaindb_connector import BigchainDBConnectorConfig, BigchainDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_bigchaindb

class TestBigchainDBConnectorConfig:
    """Unit tests for BigchainDBConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = BigchainDBConnectorConfig(
            address="http://localhost:9984"
        )
        assert config.connector_type == "bigchaindb"
        assert config.base_url == "http://localhost:9984"
        assert config.timeout == 30  # Default

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = BigchainDBConnectorConfig(
            address="localhost:9984"
        )
        assert config.base_url == "http://localhost:9984"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = BigchainDBConnectorConfig(
            address="http://localhost:9984",
            timeout=60
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "bigchaindb"
        assert config_dict["base_url"] == "http://localhost:9984"
        assert config_dict["timeout"] == 60
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_bigchaindb

class TestBigchainDBStorageConnection:
    """Unit tests for BigchainDBStorageConnection."""

    def test_connection_requires_bigchaindb_package(self):
        """Test that connection raises error if BigchainDB package not available."""
        config = BigchainDBConnectorConfig(
            address="http://localhost:9984"
        )
        try:
            connection = BigchainDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "BigchainDB connector package" in error_msg)

    def test_connection_requires_bigchaindb_config_type(self):
        """Test that connection requires BigchainDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            BigchainDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "BigchainDB connector package" in error_msg or
                "Expected BigchainDBConnectorConfig" in error_msg)
