#!/usr/bin/env python3
"""
Unit tests for QuestDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.questdb_connector import QuestDBConnectorConfig, QuestDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_questdb

class TestQuestDBConnectorConfig:
    """Unit tests for QuestDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format (ILP)."""
        config = QuestDBConnectorConfig(
            address="localhost:9000"
        )
        assert config.connector_type == "questdb"
        assert config.host == "localhost"
        assert config.port == 9000
        assert config.use_http == False

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = QuestDBConnectorConfig(
            address="http://localhost:9000"
        )
        assert config.url == "http://localhost:9000"
        assert config.use_http == True

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 9000)."""
        config = QuestDBConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 9000

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = QuestDBConnectorConfig(
            address="localhost:9000"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "questdb"
        if not config.use_http:
            assert "host" in config_dict or "port" in config_dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_questdb

class TestQuestDBStorageConnection:
    """Unit tests for QuestDBStorageConnection."""

    def test_connection_requires_questdb_package(self):
        """Test that connection raises error if QuestDB package not available."""
        config = QuestDBConnectorConfig(
            address="localhost:9000"
        )
        try:
            connection = QuestDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "QuestDB connector package" in error_msg)

    def test_connection_requires_questdb_config_type(self):
        """Test that connection requires QuestDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            QuestDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "QuestDB connector package" in error_msg or
                "Expected QuestDBConnectorConfig" in error_msg)
