#!/usr/bin/env python3
"""
Unit tests for QdrantConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.qdrant_connector import QdrantConnectorConfig, QdrantStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_qdrant

class TestQdrantConnectorConfig:
    """Unit tests for QdrantConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = QdrantConnectorConfig(
            address="http://localhost:6333",
            api_key="my_api_key"
        )
        assert config.connector_type == "qdrant"
        assert config.url == "http://localhost:6333"
        assert config.api_key == "my_api_key"

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = QdrantConnectorConfig(
            address="localhost:6333"
        )
        assert config.url == "http://localhost:6333"

    def test_config_initialization_host_only(self):
        """Test config initialization with host only (defaults port)."""
        config = QdrantConnectorConfig(
            address="localhost"
        )
        assert config.url == "http://localhost:6333"

    def test_config_to_dict(self):
        """Test config to_dict conversion (API key masked)."""
        config = QdrantConnectorConfig(
            address="http://localhost:6333",
            api_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "qdrant"
        assert config_dict["url"] == "http://localhost:6333"
        # API key should be masked
        if "api_key" in config_dict:
            assert config_dict["api_key"] == "***"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_qdrant

class TestQdrantStorageConnection:
    """Unit tests for QdrantStorageConnection."""

    def test_connection_requires_qdrant_package(self):
        """Test that connection raises error if Qdrant package not available."""
        config = QdrantConnectorConfig(
            address="http://localhost:6333"
        )
        try:
            connection = QdrantStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_qdrant_config_type(self):
        """Test that connection requires QdrantConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            QdrantStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected QdrantConnectorConfig" in error_msg)
