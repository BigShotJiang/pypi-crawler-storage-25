#!/usr/bin/env python3
"""
Comprehensive unit tests for LocalStorageConnection.
Deep testing of all local storage functionality including:
- All CRUD operations (save, load, delete, exists)
- Error handling and edge cases
- Security validation
- Format support
- Batch operations
- File operations (copy, move, list, metadata)
- Performance characteristics
- Concurrent operations
- Data integrity
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 27-Jan-2026
"""

from __future__ import annotations
import pytest
import pytest_asyncio
import tempfile
import shutil
import asyncio
import time
from pathlib import Path

from exonware.xwsystem.io.serialization.formats.text import json as xw_json
from typing import Any
from exonware.xwstorage.connectors.local_connector import (
    LocalConnectorConfig,
    LocalStorageConnection
)
from exonware.xwstorage.errors import XWLocationError
# ============================================================================
# FIXTURES
# ============================================================================
@pytest.fixture

def comprehensive_temp_dir():
    """Create a temporary directory for comprehensive tests."""
    temp_path = Path(tempfile.mkdtemp(prefix="xwstorage_comprehensive_"))
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)
@pytest.fixture

def local_config_secure(comprehensive_temp_dir):
    """Create secure local connector config."""
    return LocalConnectorConfig(
        address=str(comprehensive_temp_dir / "secure_storage.json"),
        base_path=str(comprehensive_temp_dir),
        security=True,
        atomic_writes=False
    )
@pytest.fixture

def local_config_insecure(comprehensive_temp_dir):
    """Create insecure local connector config (for testing)."""
    return LocalConnectorConfig(
        address=str(comprehensive_temp_dir / "insecure_storage.json"),
        base_path=str(comprehensive_temp_dir),
        security=False,
        atomic_writes=False
    )
@pytest.fixture

def local_config_atomic(comprehensive_temp_dir):
    """Create local connector config with atomic writes."""
    return LocalConnectorConfig(
        address=str(comprehensive_temp_dir / "atomic_storage.json"),
        base_path=str(comprehensive_temp_dir),
        security=True,
        atomic_writes=True
    )
@pytest_asyncio.fixture
async def local_connection_secure(local_config_secure):
    """Create secure local storage connection."""
    connection = LocalStorageConnection(local_config_secure, "json")
    yield connection
@pytest_asyncio.fixture
async def local_connection_insecure(local_config_insecure):
    """Create insecure local storage connection."""
    connection = LocalStorageConnection(local_config_insecure, "json")
    yield connection
@pytest_asyncio.fixture
async def local_connection_atomic(local_config_atomic):
    """Create local storage connection with atomic writes."""
    connection = LocalStorageConnection(local_config_atomic, "json")
    yield connection
@pytest.fixture

def complex_nested_data():
    """Complex nested data structure for testing."""
    return {
        "users": [
            {
                "id": 1,
                "name": "Alice",
                "email": "alice@example.com",
                "preferences": {
                    "theme": "dark",
                    "notifications": True,
                    "languages": ["en", "fr", "es"]
                },
                "metadata": {
                    "created_at": "2025-01-01T00:00:00Z",
                    "updated_at": "2025-01-27T12:00:00Z",
                    "tags": ["admin", "premium"]
                }
            },
            {
                "id": 2,
                "name": "Bob",
                "email": "bob@example.com",
                "preferences": {
                    "theme": "light",
                    "notifications": False,
                    "languages": ["en"]
                },
                "metadata": {
                    "created_at": "2025-01-02T00:00:00Z",
                    "updated_at": "2025-01-27T12:00:00Z",
                    "tags": ["user"]
                }
            }
        ],
        "settings": {
            "version": "1.0.0",
            "features": {
                "feature_a": True,
                "feature_b": False,
                "feature_c": {"enabled": True, "config": {"key": "value"}}
            }
        }
    }
@pytest.fixture

def large_data():
    """Large data structure for performance testing."""
    return {
        "items": [
            {
                "id": i,
                "name": f"Item {i}",
                "description": "x" * 1000,  # 1KB per item
                "tags": [f"tag{j}" for j in range(10)],
                "metadata": {f"key{k}": f"value{k}" for k in range(20)}
            }
            for i in range(1000)  # 1000 items = ~1MB
        ]
    }
# ============================================================================
# CORE CRUD OPERATIONS - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageCRUD:
    """Comprehensive CRUD operation tests."""
    @pytest.mark.asyncio

    async def test_save_and_load_simple_dict(self, local_connection_secure, comprehensive_temp_dir):
        """Test saving and loading a simple dictionary."""
        data = {"key": "value", "number": 42, "boolean": True}
        path = "simple_dict"
        # Save
        await local_connection_secure.save(data, path)
        # Verify file exists
        assert await local_connection_secure.exists(path) is True
        # Load and verify
        loaded = await local_connection_secure.load(path)
        assert loaded == data
        assert loaded["key"] == "value"
        assert loaded["number"] == 42
        assert loaded["boolean"] is True
    @pytest.mark.asyncio

    async def test_save_and_load_complex_nested(self, local_connection_secure, complex_nested_data):
        """Test saving and loading complex nested data structures."""
        path = "complex_nested"
        # Save
        await local_connection_secure.save(complex_nested_data, path)
        # Load and verify
        loaded = await local_connection_secure.load(path)
        assert loaded == complex_nested_data
        assert len(loaded["users"]) == 2
        assert loaded["users"][0]["name"] == "Alice"
        assert loaded["users"][1]["name"] == "Bob"
        assert loaded["settings"]["version"] == "1.0.0"
    @pytest.mark.asyncio

    async def test_save_and_load_list(self, local_connection_secure):
        """Test saving and loading list data."""
        data = [1, 2, 3, {"nested": "value"}, [4, 5, 6]]
        path = "list_data"
        await local_connection_secure.save(data, path)
        loaded = await local_connection_secure.load(path)
        assert loaded == data
        assert isinstance(loaded, list)
        assert len(loaded) == 5
    @pytest.mark.asyncio

    async def test_save_and_load_empty_structures(self, local_connection_secure):
        """Test saving and loading empty data structures."""
        # Empty dict
        await local_connection_secure.save({}, "empty_dict")
        loaded = await local_connection_secure.load("empty_dict")
        assert loaded == {}
        assert isinstance(loaded, dict)
        # Empty list
        await local_connection_secure.save([], "empty_list")
        loaded = await local_connection_secure.load("empty_list")
        assert loaded == []
        assert isinstance(loaded, list)
    @pytest.mark.asyncio

    async def test_save_overwrites_existing(self, local_connection_secure):
        """Test that save overwrites existing data."""
        path = "overwrite_test"
        # Save initial data
        await local_connection_secure.save({"key": "old_value"}, path)
        assert await local_connection_secure.load(path) == {"key": "old_value"}
        # Overwrite with new data
        await local_connection_secure.save({"key": "new_value", "new_key": "value"}, path)
        loaded = await local_connection_secure.load(path)
        assert loaded == {"key": "new_value", "new_key": "value"}
        assert "old_value" not in str(loaded)
    @pytest.mark.asyncio

    async def test_save_append_mode_list(self, local_connection_secure):
        """Test save with append mode for lists."""
        path = "append_list"
        # Save initial list
        await local_connection_secure.save([1, 2, 3], path)
        # Append more items
        await local_connection_secure.save([4, 5, 6], path, append=True)
        # Verify all items
        loaded = await local_connection_secure.load(path)
        assert loaded == [1, 2, 3, 4, 5, 6]
        assert len(loaded) == 6
    @pytest.mark.asyncio

    async def test_save_append_mode_dict(self, local_connection_secure):
        """Test save with append mode for dictionaries."""
        path = "append_dict"
        # Save initial dict
        await local_connection_secure.save({"a": 1, "b": 2}, path)
        # Append/update with new keys
        await local_connection_secure.save({"c": 3, "d": 4}, path, append=True)
        # Verify merged dict
        loaded = await local_connection_secure.load(path)
        assert loaded == {"a": 1, "b": 2, "c": 3, "d": 4}
        assert len(loaded) == 4
    @pytest.mark.asyncio

    async def test_save_append_mode_type_mismatch(self, local_connection_secure):
        """Test that append mode overwrites when types don't match."""
        path = "append_mismatch"
        # Save list
        await local_connection_secure.save([1, 2, 3], path)
        # Try to append dict (should overwrite)
        await local_connection_secure.save({"key": "value"}, path, append=True)
        # Should be dict now (overwritten)
        loaded = await local_connection_secure.load(path)
        assert isinstance(loaded, dict)
        assert loaded == {"key": "value"}
    @pytest.mark.asyncio

    async def test_delete_existing_file(self, local_connection_secure):
        """Test deleting an existing file."""
        path = "delete_test"
        # Save and verify exists
        await local_connection_secure.save({"key": "value"}, path)
        assert await local_connection_secure.exists(path) is True
        # Delete
        await local_connection_secure.delete(path)
        # Verify deleted
        assert await local_connection_secure.exists(path) is False
    @pytest.mark.asyncio

    async def test_delete_nonexistent_file_no_error(self, local_connection_secure):
        """Test that deleting nonexistent file doesn't raise error."""
        # Should not raise error
        await local_connection_secure.delete("nonexistent_path")
    @pytest.mark.asyncio

    async def test_exists_for_existing_file(self, local_connection_secure):
        """Test exists() returns True for existing file."""
        path = "exists_test"
        await local_connection_secure.save({"key": "value"}, path)
        assert await local_connection_secure.exists(path) is True
    @pytest.mark.asyncio

    async def test_exists_for_nonexistent_file(self, local_connection_secure):
        """Test exists() returns False for nonexistent file."""
        assert await local_connection_secure.exists("nonexistent") is False
# ============================================================================
# ERROR HANDLING - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local
@pytest.mark.xwstorage_security

class TestLocalStorageErrorHandling:
    """Comprehensive error handling tests."""
    @pytest.mark.asyncio

    async def test_load_nonexistent_file_raises_error(self, local_connection_secure):
        """Test that loading nonexistent file raises XWLocationError."""
        with pytest.raises(XWLocationError, match="not found"):
            await local_connection_secure.load("nonexistent_path")
    @pytest.mark.asyncio

    async def test_load_invalid_json_raises_error(self, local_connection_secure, comprehensive_temp_dir):
        """Test that loading invalid JSON raises error."""
        path = "invalid_json"
        file_path = comprehensive_temp_dir / path
        # Write invalid JSON
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text("{ invalid json }", encoding='utf-8')
        # Should raise error when loading
        with pytest.raises(Exception):  # Could be JSONDecodeError or similar
            await local_connection_secure.load(path)
    @pytest.mark.asyncio

    async def test_save_with_invalid_path_characters(self, local_connection_secure):
        """Test saving with invalid path characters."""
        # Test with null bytes
        with pytest.raises(Exception):
            await local_connection_secure.save({"key": "value"}, "path\x00null")
        # Test with control characters
        with pytest.raises(Exception):
            await local_connection_secure.save({"key": "value"}, "path\nnewline")
# ============================================================================
# SECURITY - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local
@pytest.mark.xwstorage_security

class TestLocalStorageSecurity:
    """Comprehensive security tests."""
    @pytest.mark.asyncio

    async def test_path_traversal_prevention(self, local_connection_secure):
        """Test that path traversal attacks are prevented."""
        # Test various path traversal patterns
        dangerous_paths = [
            "../outside",
            "../../etc/passwd",
            "..\\..\\windows\\system32",
            "....//....//etc/passwd",
            "..%2F..%2Fetc%2Fpasswd",
        ]
        for dangerous_path in dangerous_paths:
            with pytest.raises(XWLocationError, match="dangerous patterns|Invalid path"):
                local_connection_secure.get_file_path(dangerous_path)
    @pytest.mark.asyncio

    async def test_absolute_path_prevention(self, local_connection_secure):
        """Test that absolute paths are prevented when security is enabled."""
        # Unix absolute path
        with pytest.raises(XWLocationError, match="dangerous patterns|Invalid path"):
            local_connection_secure.get_file_path("/etc/passwd")
        # Windows absolute path
        with pytest.raises(XWLocationError, match="dangerous patterns|Invalid path"):
            local_connection_secure.get_file_path("C:\\Windows\\System32")
    @pytest.mark.asyncio

    async def test_security_disabled_allows_relative_paths(self, local_connection_insecure):
        """Test that when security is disabled, relative paths work."""
        # With security disabled, relative paths should work
        # (Note: This is testing the behavior, not recommending it)
        path = local_connection_insecure.get_file_path("relative_path")
        assert path is not None
    @pytest.mark.asyncio

    async def test_base_path_restriction(self, comprehensive_temp_dir):
        """Test that base_path restricts operations to specified directory."""
        # Create config with base_path
        base_path = comprehensive_temp_dir / "restricted"
        base_path.mkdir(parents=True, exist_ok=True)
        config = LocalConnectorConfig(
            address=str(base_path / "storage.json"),
            base_path=str(base_path),
            security=True
        )
        connection = LocalStorageConnection(config, "json")
        # Should work for paths within base_path
        await connection.save({"key": "value"}, "allowed_path")
        assert await connection.exists("allowed_path") is True
        # Should fail for paths outside base_path
        with pytest.raises(XWLocationError):
            connection.get_file_path("../outside_path")
# ============================================================================
# FORMAT SUPPORT - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageFormats:
    """Comprehensive format support tests."""
    @pytest.mark.asyncio

    async def test_json_format(self, comprehensive_temp_dir):
        """Test JSON format support."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "json_storage.json"),
            security=False
        )
        connection = LocalStorageConnection(config, "json")
        data = {"key": "value", "number": 42}
        await connection.save(data, "json_test")
        loaded = await connection.load("json_test")
        assert loaded == data
    @pytest.mark.asyncio

    async def test_yaml_format(self, comprehensive_temp_dir):
        """Test YAML format support."""
        try:
            config = LocalConnectorConfig(
                address=str(comprehensive_temp_dir / "yaml_storage.yaml"),
                security=False
            )
            connection = LocalStorageConnection(config, "yaml")
            data = {"key": "value", "number": 42, "list": [1, 2, 3]}
            await connection.save(data, "yaml_test")
            loaded = await connection.load("yaml_test")
            assert loaded == data
        except Exception:
            # YAML codec might not be available
            pytest.skip("YAML codec not available")
    @pytest.mark.asyncio

    async def test_xml_format(self, comprehensive_temp_dir):
        """Test XML format support."""
        try:
            config = LocalConnectorConfig(
                address=str(comprehensive_temp_dir / "xml_storage.xml"),
                security=False
            )
            connection = LocalStorageConnection(config, "xml")
            data = {"root": {"key": "value", "number": 42}}
            await connection.save(data, "xml_test")
            loaded = await connection.load("xml_test")
            # XML might have different structure, so just verify it loads
            assert loaded is not None
        except Exception:
            # XML codec might not be available
            pytest.skip("XML codec not available")
# ============================================================================
# XWJSON FORMAT - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageXWJSON:
    """Comprehensive XWJSON format tests."""
    @pytest.fixture(autouse=True)

    def ensure_xwjson_available(self):
        """Ensure xwjson is available and registered."""
        try:
            import exonware.xwjson  # noqa: F401 - Auto-registers XWJSONSerializer
        except ImportError:
            pytest.skip("xwjson not available")
    @pytest.mark.asyncio

    async def test_xwjson_basic_save_and_load(self, comprehensive_temp_dir):
        """Test basic save and load with XWJSON format."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_storage.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        data = {"key": "value", "number": 42, "boolean": True}
        await connection.save(data, "xwjson_test")
        # Verify file exists
        assert await connection.exists("xwjson_test") is True
        # Load and verify
        loaded = await connection.load("xwjson_test")
        assert loaded == data
        assert loaded["key"] == "value"
        assert loaded["number"] == 42
        assert loaded["boolean"] is True
    @pytest.mark.asyncio

    async def test_xwjson_complex_nested_data(self, comprehensive_temp_dir, complex_nested_data):
        """Test XWJSON with complex nested data structures."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_complex.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        await connection.save(complex_nested_data, "complex_xwjson")
        loaded = await connection.load("complex_xwjson")
        assert loaded == complex_nested_data
        assert len(loaded["users"]) == 2
        assert loaded["users"][0]["name"] == "Alice"
        assert loaded["users"][1]["name"] == "Bob"
        assert loaded["settings"]["version"] == "1.0.0"
    @pytest.mark.asyncio

    async def test_xwjson_list_data(self, comprehensive_temp_dir):
        """Test XWJSON with list data."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_list.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        data = [1, 2, 3, {"nested": "value"}, [4, 5, 6]]
        await connection.save(data, "list_xwjson")
        loaded = await connection.load("list_xwjson")
        assert loaded == data
        assert isinstance(loaded, list)
        assert len(loaded) == 5
    @pytest.mark.asyncio

    async def test_xwjson_empty_structures(self, comprehensive_temp_dir):
        """Test XWJSON with empty data structures."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_empty.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        # Empty dict
        await connection.save({}, "empty_dict_xwjson")
        loaded = await connection.load("empty_dict_xwjson")
        assert loaded == {}
        assert isinstance(loaded, dict)
        # Empty list
        await connection.save([], "empty_list_xwjson")
        loaded = await connection.load("empty_list_xwjson")
        assert loaded == []
        assert isinstance(loaded, list)
    @pytest.mark.asyncio

    async def test_xwjson_unicode_characters(self, comprehensive_temp_dir):
        """Test XWJSON with Unicode characters."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_unicode.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        unicode_data = {
            "name": "测试",
            "description": "Café résumé",
            "emoji": "🚀 ✅ ❌",
            "arabic": "مرحبا",
            "chinese": "你好世界"
        }
        await connection.save(unicode_data, "unicode_xwjson")
        loaded = await connection.load("unicode_xwjson")
        assert loaded == unicode_data
        assert loaded["name"] == "测试"
        assert loaded["emoji"] == "🚀 ✅ ❌"
    @pytest.mark.asyncio

    async def test_xwjson_none_values(self, comprehensive_temp_dir):
        """Test XWJSON with None values."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_none.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        data_with_none = {
            "key1": "value",
            "key2": None,
            "key3": {"nested": None},
            "key4": [1, None, 3]
        }
        await connection.save(data_with_none, "none_xwjson")
        loaded = await connection.load("none_xwjson")
        assert loaded == data_with_none
        assert loaded["key2"] is None
        assert loaded["key3"]["nested"] is None
    @pytest.mark.asyncio

    async def test_xwjson_numeric_types(self, comprehensive_temp_dir):
        """Test XWJSON with various numeric types."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_numeric.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        numeric_data = {
            "int": 42,
            "float": 3.14159,
            "negative": -10,
            "zero": 0,
            "large": 999999999999,
            "small_float": 0.000001
        }
        await connection.save(numeric_data, "numeric_xwjson")
        loaded = await connection.load("numeric_xwjson")
        assert loaded == numeric_data
        assert isinstance(loaded["int"], int)
        assert isinstance(loaded["float"], float)
    @pytest.mark.asyncio

    async def test_xwjson_boolean_types(self, comprehensive_temp_dir):
        """Test XWJSON with boolean values."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_boolean.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        boolean_data = {
            "true": True,
            "false": False,
            "mixed": [True, False, True]
        }
        await connection.save(boolean_data, "boolean_xwjson")
        loaded = await connection.load("boolean_xwjson")
        assert loaded == boolean_data
        assert loaded["true"] is True
        assert loaded["false"] is False
    @pytest.mark.asyncio

    async def test_xwjson_overwrite_existing(self, comprehensive_temp_dir):
        """Test that XWJSON save overwrites existing data."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_overwrite.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        path = "overwrite_xwjson"
        # Save initial data
        await connection.save({"key": "old_value"}, path)
        assert await connection.load(path) == {"key": "old_value"}
        # Overwrite with new data
        await connection.save({"key": "new_value", "new_key": "value"}, path)
        loaded = await connection.load(path)
        assert loaded == {"key": "new_value", "new_key": "value"}
        assert "old_value" not in str(loaded)
    @pytest.mark.asyncio

    async def test_xwjson_append_mode_list(self, comprehensive_temp_dir):
        """Test XWJSON save with append mode for lists."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_append.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        path = "append_list_xwjson"
        # Save initial list
        await connection.save([1, 2, 3], path)
        # Append more items
        await connection.save([4, 5, 6], path, append=True)
        # Verify all items
        loaded = await connection.load(path)
        assert loaded == [1, 2, 3, 4, 5, 6]
        assert len(loaded) == 6
    @pytest.mark.asyncio

    async def test_xwjson_append_mode_dict(self, comprehensive_temp_dir):
        """Test XWJSON save with append mode for dictionaries."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_append_dict.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        path = "append_dict_xwjson"
        # Save initial dict
        await connection.save({"a": 1, "b": 2}, path)
        # Append/update with new keys
        await connection.save({"c": 3, "d": 4}, path, append=True)
        # Verify merged dict
        loaded = await connection.load(path)
        assert loaded == {"a": 1, "b": 2, "c": 3, "d": 4}
        assert len(loaded) == 4
    @pytest.mark.asyncio
    @pytest.mark.xwstorage_performance

    async def test_xwjson_large_data(self, comprehensive_temp_dir, large_data):
        """Test XWJSON with large data structure."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_large.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        path = "large_xwjson"
        start_time = time.time()
        await connection.save(large_data, path)
        save_time = time.time() - start_time
        # Should complete in reasonable time (< 5 seconds for 1MB)
        assert save_time < 5.0, f"XWJSON save took {save_time:.2f}s, expected < 5.0s"
        # Verify data integrity
        loaded = await connection.load(path)
        assert len(loaded["items"]) == 1000
        assert loaded["items"][0]["id"] == 0
        assert loaded["items"][999]["id"] == 999
    @pytest.mark.asyncio
    @pytest.mark.xwstorage_performance

    async def test_xwjson_batch_operations(self, comprehensive_temp_dir):
        """Test XWJSON batch operations."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_batch.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        # Batch save
        items = [
            ({"id": i, "name": f"Item {i}"}, f"item_{i}")
            for i in range(10)
        ]
        result = await connection.batch_save(items)
        assert result["success"] == 10
        assert result["failed"] == 0
        # Verify all items were saved
        for i in range(10):
            assert await connection.exists(f"item_{i}") is True
            loaded = await connection.load(f"item_{i}")
            assert loaded["id"] == i
        # Batch load
        paths = [f"item_{i}" for i in range(10)]
        batch_loaded = await connection.batch_load(paths)
        for i in range(10):
            assert f"item_{i}" in batch_loaded
            assert batch_loaded[f"item_{i}"]["id"] == i
    @pytest.mark.asyncio
    @pytest.mark.xwstorage_performance

    async def test_xwjson_concurrent_operations(self, comprehensive_temp_dir):
        """Test XWJSON with concurrent operations."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_concurrent.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        async def save_item(item_id: int):
            await connection.save({"id": item_id}, f"concurrent_xwjson_{item_id}")
        # Save 20 items concurrently
        await asyncio.gather(*[save_item(i) for i in range(20)])
        # Verify all saved
        for i in range(20):
            assert await connection.exists(f"concurrent_xwjson_{i}") is True
            loaded = await connection.load(f"concurrent_xwjson_{i}")
            assert loaded["id"] == i
    @pytest.mark.asyncio

    async def test_xwjson_roundtrip_integrity(self, comprehensive_temp_dir, complex_nested_data):
        """Test XWJSON roundtrip data integrity."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_integrity.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        path = "integrity_xwjson"
        # Save
        await connection.save(complex_nested_data, path)
        # Load multiple times and verify consistency
        for _ in range(5):
            loaded = await connection.load(path)
            assert loaded == complex_nested_data
            assert xw_json.dumps(loaded, sort_keys=True) == xw_json.dumps(complex_nested_data, sort_keys=True)
    @pytest.mark.asyncio

    async def test_xwjson_delete_operations(self, comprehensive_temp_dir):
        """Test XWJSON delete operations."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_delete.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        path = "delete_xwjson"
        # Save and verify exists
        await connection.save({"key": "value"}, path)
        assert await connection.exists(path) is True
        # Delete
        await connection.delete(path)
        # Verify deleted
        assert await connection.exists(path) is False
    @pytest.mark.asyncio

    async def test_xwjson_file_operations(self, comprehensive_temp_dir):
        """Test XWJSON file operations (copy, move, metadata)."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "xwjson_fileops.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        source_path = "source_xwjson"
        dest_path = "dest_xwjson"
        # Save source
        data = {"key": "value", "xwjson": True}
        await connection.save(data, source_path)
        # Copy
        await connection.copy(source_path, dest_path)
        assert await connection.exists(source_path) is True
        assert await connection.exists(dest_path) is True
        assert await connection.load(source_path) == await connection.load(dest_path)
        # Move
        move_dest = "moved_xwjson"
        await connection.move(dest_path, move_dest)
        assert await connection.exists(dest_path) is False
        assert await connection.exists(move_dest) is True
        assert await connection.load(move_dest) == data
        # Metadata
        metadata = await connection.get_metadata(move_dest)
        assert "size" in metadata
        assert metadata["is_file"] is True
        assert metadata["size"] > 0
# ============================================================================
# BATCH OPERATIONS - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageBatchOperations:
    """Comprehensive batch operation tests."""
    @pytest.mark.asyncio

    async def test_batch_save(self, local_connection_secure):
        """Test batch save operation."""
        items = [
            ({"id": i, "name": f"Item {i}"}, f"item_{i}")
            for i in range(10)
        ]
        result = await local_connection_secure.batch_save(items)
        assert result["success"] == 10
        assert result["failed"] == 0
        assert len(result["errors"]) == 0
        # Verify all items were saved
        for i in range(10):
            assert await local_connection_secure.exists(f"item_{i}") is True
            loaded = await local_connection_secure.load(f"item_{i}")
            assert loaded["id"] == i
    @pytest.mark.asyncio

    async def test_batch_load(self, local_connection_secure):
        """Test batch load operation."""
        # Save some items first
        for i in range(5):
            await local_connection_secure.save({"id": i, "name": f"Item {i}"}, f"item_{i}")
        paths = [f"item_{i}" for i in range(5)]
        result = await local_connection_secure.batch_load(paths)
        # Verify all items loaded
        for i in range(5):
            assert f"item_{i}" in result
            assert result[f"item_{i}"]["id"] == i
    @pytest.mark.asyncio

    async def test_batch_exists(self, local_connection_secure):
        """Test batch exists operation."""
        # Save some items
        for i in range(5):
            await local_connection_secure.save({"id": i}, f"item_{i}")
        paths = [f"item_{i}" for i in range(7)]  # 5 exist, 2 don't
        result = await local_connection_secure.batch_exists(paths)
        # Verify results
        for i in range(5):
            assert result[f"item_{i}"] is True
        for i in range(5, 7):
            assert result[f"item_{i}"] is False
    @pytest.mark.asyncio

    async def test_batch_delete(self, local_connection_secure):
        """Test batch delete operation."""
        # Save some items
        for i in range(5):
            await local_connection_secure.save({"id": i}, f"item_{i}")
        paths = [f"item_{i}" for i in range(5)]
        result = await local_connection_secure.batch_delete(paths)
        assert result["success"] == 5
        assert result["failed"] == 0
        # Verify all deleted
        for i in range(5):
            assert await local_connection_secure.exists(f"item_{i}") is False
# ============================================================================
# FILE OPERATIONS - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageFileOperations:
    """Comprehensive file operation tests."""
    @pytest.mark.asyncio

    async def test_list_files(self, local_connection_secure):
        """Test listing files."""
        # Save multiple files
        for i in range(5):
            await local_connection_secure.save({"id": i}, f"file_{i}.json")
        files = await local_connection_secure.list_files()
        assert len(files) >= 5
        assert any("file_0.json" in f for f in files)
    @pytest.mark.asyncio

    async def test_list_files_with_pattern(self, local_connection_secure):
        """Test listing files with pattern."""
        # Save files with different extensions
        await local_connection_secure.save({"data": 1}, "file1.json")
        await local_connection_secure.save({"data": 2}, "file2.json")
        await local_connection_secure.save({"data": 3}, "file3.txt")
        # List only JSON files
        json_files = await local_connection_secure.list_files(pattern="*.json")
        assert len(json_files) >= 2
        assert all(".json" in f for f in json_files)
    @pytest.mark.asyncio

    async def test_list_files_recursive(self, local_connection_secure):
        """Test recursive file listing."""
        # Save files in subdirectories
        await local_connection_secure.save({"data": 1}, "subdir1/file1.json")
        await local_connection_secure.save({"data": 2}, "subdir2/file2.json")
        files = await local_connection_secure.list_files(recursive=True)
        assert len(files) >= 2
        # Check for files in a path-agnostic way (handle both / and \ separators)
        file_names = [Path(f).name for f in files]
        file_paths_str = " ".join(files).replace("\\", "/")  # Normalize separators
        # Verify files exist (check by name or path pattern)
        assert any("file1.json" in f or "subdir1" in f.replace("\\", "/") for f in files), f"file1.json not found in {files}"
        assert any("file2.json" in f or "subdir2" in f.replace("\\", "/") for f in files), f"file2.json not found in {files}"
    @pytest.mark.asyncio

    async def test_copy_file(self, local_connection_secure):
        """Test copying a file."""
        source_path = "source_file"
        dest_path = "dest_file"
        # Save source
        await local_connection_secure.save({"key": "value"}, source_path)
        # Copy
        await local_connection_secure.copy(source_path, dest_path)
        # Verify both exist and have same content
        assert await local_connection_secure.exists(source_path) is True
        assert await local_connection_secure.exists(dest_path) is True
        assert await local_connection_secure.load(source_path) == await local_connection_secure.load(dest_path)
    @pytest.mark.asyncio

    async def test_copy_nonexistent_file_raises_error(self, local_connection_secure):
        """Test that copying nonexistent file raises error."""
        with pytest.raises(FileNotFoundError):
            await local_connection_secure.copy("nonexistent", "dest")
    @pytest.mark.asyncio

    async def test_move_file(self, local_connection_secure):
        """Test moving a file."""
        source_path = "move_source"
        dest_path = "move_dest"
        # Save source
        data = {"key": "value"}
        await local_connection_secure.save(data, source_path)
        # Move
        await local_connection_secure.move(source_path, dest_path)
        # Verify moved
        assert await local_connection_secure.exists(source_path) is False
        assert await local_connection_secure.exists(dest_path) is True
        assert await local_connection_secure.load(dest_path) == data
    @pytest.mark.asyncio

    async def test_move_nonexistent_file_raises_error(self, local_connection_secure):
        """Test that moving nonexistent file raises error."""
        with pytest.raises(FileNotFoundError):
            await local_connection_secure.move("nonexistent", "dest")
    @pytest.mark.asyncio

    async def test_get_metadata(self, local_connection_secure):
        """Test getting file metadata."""
        path = "metadata_test"
        await local_connection_secure.save({"key": "value"}, path)
        metadata = await local_connection_secure.get_metadata(path)
        assert "size" in metadata
        assert "modified_time" in metadata
        assert "created_time" in metadata
        assert "is_file" in metadata
        assert metadata["is_file"] is True
        assert metadata["size"] > 0
    @pytest.mark.asyncio

    async def test_get_metadata_nonexistent_raises_error(self, local_connection_secure):
        """Test that getting metadata for nonexistent file raises error."""
        with pytest.raises(FileNotFoundError):
            await local_connection_secure.get_metadata("nonexistent")
# ============================================================================
# CONCURRENT OPERATIONS - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local
@pytest.mark.xwstorage_performance

class TestLocalStorageConcurrency:
    """Comprehensive concurrency tests."""
    @pytest.mark.asyncio

    async def test_concurrent_saves(self, local_connection_secure):
        """Test concurrent save operations."""
        async def save_item(item_id: int):
            await local_connection_secure.save({"id": item_id}, f"concurrent_{item_id}")
        # Save 20 items concurrently
        await asyncio.gather(*[save_item(i) for i in range(20)])
        # Verify all saved
        for i in range(20):
            assert await local_connection_secure.exists(f"concurrent_{i}") is True
            loaded = await local_connection_secure.load(f"concurrent_{i}")
            assert loaded["id"] == i
    @pytest.mark.asyncio

    async def test_concurrent_loads(self, local_connection_secure):
        """Test concurrent load operations."""
        # Save items first
        for i in range(10):
            await local_connection_secure.save({"id": i}, f"load_{i}")
        async def load_item(item_id: int):
            loaded = await local_connection_secure.load(f"load_{item_id}")
            assert loaded["id"] == item_id
        # Load all concurrently
        await asyncio.gather(*[load_item(i) for i in range(10)])
    @pytest.mark.asyncio

    async def test_concurrent_save_and_load(self, local_connection_secure):
        """Test concurrent save and load operations."""
        async def save_and_load(item_id: int):
            await local_connection_secure.save({"id": item_id}, f"mixed_{item_id}")
            loaded = await local_connection_secure.load(f"mixed_{item_id}")
            assert loaded["id"] == item_id
        # Run save and load concurrently
        await asyncio.gather(*[save_and_load(i) for i in range(10)])
# ============================================================================
# PERFORMANCE - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local
@pytest.mark.xwstorage_performance

class TestLocalStoragePerformance:
    """Comprehensive performance tests."""
    @pytest.mark.asyncio

    async def test_save_large_data(self, local_connection_secure, large_data):
        """Test saving large data structure."""
        path = "large_data"
        start_time = time.time()
        await local_connection_secure.save(large_data, path)
        save_time = time.time() - start_time
        # Should complete in reasonable time (< 5 seconds for 1MB)
        assert save_time < 5.0, f"Save took {save_time:.2f}s, expected < 5.0s"
        # Verify data integrity
        loaded = await local_connection_secure.load(path)
        assert len(loaded["items"]) == 1000
        assert loaded["items"][0]["id"] == 0
        assert loaded["items"][999]["id"] == 999
    @pytest.mark.asyncio

    async def test_load_large_data(self, local_connection_secure, large_data):
        """Test loading large data structure."""
        path = "large_data_load"
        await local_connection_secure.save(large_data, path)
        start_time = time.time()
        loaded = await local_connection_secure.load(path)
        load_time = time.time() - start_time
        # Should complete in reasonable time (< 2 seconds for 1MB)
        assert load_time < 2.0, f"Load took {load_time:.2f}s, expected < 2.0s"
        assert len(loaded["items"]) == 1000
    @pytest.mark.asyncio

    async def test_batch_save_performance(self, local_connection_secure):
        """Test batch save performance."""
        items = [
            ({"id": i, "data": "x" * 100}, f"batch_{i}")
            for i in range(100)
        ]
        start_time = time.time()
        result = await local_connection_secure.batch_save(items)
        batch_time = time.time() - start_time
        # Batch should be faster than individual saves
        assert batch_time < 5.0, f"Batch save took {batch_time:.2f}s, expected < 5.0s"
        assert result["success"] == 100
# ============================================================================
# EDGE CASES - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageEdgeCases:
    """Comprehensive edge case tests."""
    @pytest.mark.asyncio

    async def test_save_with_special_characters_in_path(self, local_connection_secure):
        """Test saving with special characters in path."""
        special_paths = [
            "test-data_with.special_chars",
            "test_data-123",
            "test.data.json",
            "subdir/test_file",
        ]
        for path in special_paths:
            await local_connection_secure.save({"key": "value"}, path)
            assert await local_connection_secure.exists(path) is True
            loaded = await local_connection_secure.load(path)
            assert loaded == {"key": "value"}
    @pytest.mark.asyncio

    async def test_save_with_unicode_characters(self, local_connection_secure):
        """Test saving data with Unicode characters."""
        unicode_data = {
            "name": "测试",
            "description": "Café résumé",
            "emoji": "🚀 ✅ ❌",
            "arabic": "مرحبا",
            "chinese": "你好世界"
        }
        await local_connection_secure.save(unicode_data, "unicode_test")
        loaded = await local_connection_secure.load("unicode_test")
        assert loaded == unicode_data
        assert loaded["name"] == "测试"
        assert loaded["emoji"] == "🚀 ✅ ❌"
    @pytest.mark.asyncio

    async def test_save_with_none_values(self, local_connection_secure):
        """Test saving data with None values."""
        data_with_none = {
            "key1": "value",
            "key2": None,
            "key3": {"nested": None},
            "key4": [1, None, 3]
        }
        await local_connection_secure.save(data_with_none, "none_test")
        loaded = await local_connection_secure.load("none_test")
        assert loaded == data_with_none
        assert loaded["key2"] is None
        assert loaded["key3"]["nested"] is None
    @pytest.mark.asyncio

    async def test_save_with_numeric_types(self, local_connection_secure):
        """Test saving various numeric types."""
        numeric_data = {
            "int": 42,
            "float": 3.14159,
            "negative": -10,
            "zero": 0,
            "large": 999999999999,
            "small_float": 0.000001
        }
        await local_connection_secure.save(numeric_data, "numeric_test")
        loaded = await local_connection_secure.load("numeric_test")
        assert loaded == numeric_data
        assert isinstance(loaded["int"], int)
        assert isinstance(loaded["float"], float)
    @pytest.mark.asyncio

    async def test_save_with_boolean_types(self, local_connection_secure):
        """Test saving boolean values."""
        boolean_data = {
            "true": True,
            "false": False,
            "mixed": [True, False, True]
        }
        await local_connection_secure.save(boolean_data, "boolean_test")
        loaded = await local_connection_secure.load("boolean_test")
        assert loaded == boolean_data
        assert loaded["true"] is True
        assert loaded["false"] is False
# ============================================================================
# CONNECTION MANAGEMENT - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageConnectionManagement:
    """Comprehensive connection management tests."""

    def test_connection_id_uniqueness(self, comprehensive_temp_dir):
        """Test that connection IDs are unique."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "test.json"),
            security=False
        )
        conn1 = LocalStorageConnection(config, "json")
        conn2 = LocalStorageConnection(config, "json")
        conn3 = LocalStorageConnection(config, "json")
        # All IDs should be different
        assert conn1.connection_id != conn2.connection_id
        assert conn2.connection_id != conn3.connection_id
        assert conn1.connection_id != conn3.connection_id

    def test_connection_id_persistence(self, comprehensive_temp_dir):
        """Test that connection ID persists across operations."""
        config = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "test.json"),
            security=False
        )
        connection = LocalStorageConnection(config, "json")
        original_id = connection.connection_id
        # ID should remain the same
        assert connection.connection_id == original_id
    @pytest.mark.asyncio

    async def test_multiple_connections_same_directory(self, comprehensive_temp_dir):
        """Test multiple connections to the same directory."""
        config1 = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "storage1.json"),
            security=False
        )
        config2 = LocalConnectorConfig(
            address=str(comprehensive_temp_dir / "storage2.json"),
            security=False
        )
        conn1 = LocalStorageConnection(config1, "json")
        conn2 = LocalStorageConnection(config2, "json")
        # Both should work independently
        await conn1.save({"key1": "value1"}, "file1")
        await conn2.save({"key2": "value2"}, "file2")
        assert await conn1.exists("file1") is True
        assert await conn2.exists("file2") is True
        assert await conn1.load("file1") == {"key1": "value1"}
        assert await conn2.load("file2") == {"key2": "value2"}
# ============================================================================
# DATA INTEGRITY - DEEP TESTING
# ============================================================================
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageDataIntegrity:
    """Comprehensive data integrity tests."""
    @pytest.mark.asyncio

    async def test_roundtrip_data_integrity(self, local_connection_secure, complex_nested_data):
        """Test that data survives save/load roundtrip without corruption."""
        path = "integrity_test"
        # Save
        await local_connection_secure.save(complex_nested_data, path)
        # Load multiple times
        for _ in range(5):
            loaded = await local_connection_secure.load(path)
            assert loaded == complex_nested_data
            assert xw_json.dumps(loaded, sort_keys=True) == xw_json.dumps(complex_nested_data, sort_keys=True)
    @pytest.mark.asyncio

    async def test_multiple_saves_same_path(self, local_connection_secure):
        """Test multiple saves to same path maintain data integrity."""
        path = "multiple_saves"
        for i in range(10):
            data = {"iteration": i, "timestamp": time.time()}
            await local_connection_secure.save(data, path)
            # Immediately verify
            loaded = await local_connection_secure.load(path)
            assert loaded["iteration"] == i
    @pytest.mark.asyncio

    async def test_concurrent_saves_same_path(self, local_connection_secure):
        """Test concurrent saves to same path (last write wins)."""
        path = "concurrent_same_path"
        async def save_with_id(item_id: int):
            await local_connection_secure.save({"id": item_id}, path)
        # Save concurrently
        await asyncio.gather(*[save_with_id(i) for i in range(10)])
        # Last write should be present (or at least valid data)
        loaded = await local_connection_secure.load(path)
        assert "id" in loaded
        assert isinstance(loaded["id"], int)
