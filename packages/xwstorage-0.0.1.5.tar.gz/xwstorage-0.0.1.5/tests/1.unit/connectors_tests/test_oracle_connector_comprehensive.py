#!/usr/bin/env python3
"""
Comprehensive unit tests for OracleConnector - 100% coverage target.
Tests all code paths including error handling and edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from exonware.xwstorage.connectors.oracle_connector import OracleConnectorConfig, OracleStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_oracle

class TestOracleConnectorConfigComprehensive:
    """Comprehensive tests for OracleConnectorConfig."""

    def test_config_address_parsing_variations(self):
        """Test various address string parsing scenarios."""
        # Test with port and database
        config = OracleConnectorConfig(
            address="localhost:1521/xe",
            username="system",
            password="pass"
        )
        assert config.host == "localhost"
        assert config.port == 1521
        assert config.database == "xe"
        assert config.service_name == "xe"
        assert config.dsn == "localhost:1521/xe"
        # Test with service_name override
        config2 = OracleConnectorConfig(
            address="test_table",
            host="localhost",
            port=1521,
            database="xe",
            service_name="custom_service",
            username="system",
            password="pass"
        )
        assert config2.service_name == "custom_service"

    def test_config_to_dict_with_username(self):
        """Test to_dict includes username but not password."""
        config = OracleConnectorConfig(
            address="test_table",
            host="localhost",
            database="xe",
            username="system",
            password="secret"
        )
        config_dict = config.to_dict()
        assert "username" in config_dict
        assert config_dict["username"] == "system"
        assert "password" not in config_dict
        assert "dsn" in config_dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_oracle

class TestOracleStorageConnectionComprehensive:
    """Comprehensive tests for OracleStorageConnection."""
    @pytest.fixture

    def oracle_config(self):
        """Oracle config for testing."""
        return OracleConnectorConfig(
            address="test_table",
            host="localhost",
            port=1521,
            database="xe",
            username="system",
            password="password"
        )
    @pytest.mark.asyncio

    async def test_connection_pool_creation(self, oracle_config):
        """Test pool creation."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_oracledb.create_pool.return_value = mock_pool
                connection = OracleStorageConnection(oracle_config, "json")
                pool = await connection._get_pool()
                assert pool is not None
                mock_oracledb.create_pool.assert_called_once()
    @pytest.mark.asyncio

    async def test_connection_pool_creation_error(self, oracle_config):
        """Test pool creation error handling."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_oracledb.create_pool.side_effect = Exception("Connection failed")
                connection = OracleStorageConnection(oracle_config, "json")
                with pytest.raises(XWStorageError, match="Failed to create Oracle connection pool"):
                    await connection._get_pool()
    @pytest.mark.asyncio

    async def test_ensure_table(self, oracle_config):
        """Test table creation."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                await connection._ensure_table()
                assert connection._table_created is True
                mock_cursor.execute.assert_called_once()
    @pytest.mark.asyncio

    async def test_ensure_table_error(self, oracle_config):
        """Test table creation error handling."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.execute.side_effect = Exception("Table creation failed")
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                with pytest.raises(Exception):
                    await connection._ensure_table()
    @pytest.mark.asyncio

    async def test_save(self, oracle_config):
        """Test save operation."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                codec = MagicMock()
                codec.encode = MagicMock(return_value='{"test": "data"}')
                with patch.object(connection, '_get_codec', return_value=codec):
                    await connection.save({"test": "data"}, "test_path")
                    mock_cursor.execute.assert_called_once()
    @pytest.mark.asyncio

    async def test_save_with_data_id(self, oracle_config):
        """Test save with data containing id field."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                codec = MagicMock()
                codec.encode = MagicMock(return_value='{"id": "123", "test": "data"}')
                with patch.object(connection, '_get_codec', return_value=codec):
                    await connection.save({"id": "123", "test": "data"}, "test_path")
                    # Should use data['id'] as row_id
                    call_args = mock_cursor.execute.call_args
                    assert call_args is not None
    @pytest.mark.asyncio

    async def test_save_error_handling(self, oracle_config):
        """Test save error handling."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.execute.side_effect = Exception("SQL error")
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                codec = MagicMock()
                codec.encode = MagicMock(return_value='{"test": "data"}')
                with patch.object(connection, '_get_codec', return_value=codec):
                    with pytest.raises(XWStorageError, match="Failed to save data"):
                        await connection.save({"test": "data"}, "test_path")
    @pytest.mark.asyncio

    async def test_load(self, oracle_config):
        """Test load operation."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.fetchone.return_value = ('{"test": "data"}',)
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                codec = MagicMock()
                codec.decode = MagicMock(return_value={"test": "data"})
                with patch.object(connection, '_get_codec', return_value=codec):
                    result = await connection.load("test_path")
                    assert result == {"test": "data"}
    @pytest.mark.asyncio

    async def test_load_returns_none(self, oracle_config):
        """Test load returns None when no data found."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.fetchone.return_value = None
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                with patch.object(connection, '_get_codec'):
                    result = await connection.load("test_path")
                    assert result is None
    @pytest.mark.asyncio

    async def test_load_data_is_none(self, oracle_config):
        """Test load when data field is None."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.fetchone.return_value = (None,)
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                with patch.object(connection, '_get_codec'):
                    result = await connection.load("test_path")
                    assert result is None
    @pytest.mark.asyncio

    async def test_load_error_handling(self, oracle_config):
        """Test load error handling."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.execute.side_effect = Exception("SQL error")
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                with patch.object(connection, '_get_codec'):
                    with pytest.raises(XWStorageError, match="Failed to load data"):
                        await connection.load("test_path")
    @pytest.mark.asyncio

    async def test_exists(self, oracle_config):
        """Test exists check."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.fetchone.return_value = (1,)  # Count > 0
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                exists = await connection.exists("test_path")
                assert exists is True
    @pytest.mark.asyncio

    async def test_exists_error_handling(self, oracle_config):
        """Test exists error handling."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.execute.side_effect = Exception("SQL error")
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                # Should return False on error
                exists = await connection.exists("test_path")
                assert exists is False
    @pytest.mark.asyncio

    async def test_delete(self, oracle_config):
        """Test delete operation."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                await connection.delete("test_path")
                mock_cursor.execute.assert_called_once()
    @pytest.mark.asyncio

    async def test_delete_error_handling(self, oracle_config):
        """Test delete error handling."""
        with patch('exonware.xwstorage.connectors.oracle_connector.ORACLE_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.oracle_connector.oracledb') as mock_oracledb:
                mock_pool = MagicMock()
                mock_conn = MagicMock()
                mock_cursor = MagicMock()
                mock_cursor.execute.side_effect = Exception("SQL error")
                mock_pool.acquire.return_value = mock_conn
                mock_pool.release = MagicMock()
                mock_conn.cursor.return_value = mock_cursor
                connection = OracleStorageConnection(oracle_config, "json")
                connection._pool = mock_pool
                connection._table_created = True
                with pytest.raises(XWStorageError, match="Failed to delete data"):
                    await connection.delete("test_path")
