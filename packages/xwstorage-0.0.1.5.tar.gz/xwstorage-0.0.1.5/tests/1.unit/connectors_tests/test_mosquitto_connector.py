#!/usr/bin/env python3
"""
Unit tests for MosquittoConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.mosquitto_connector import MosquittoConnectorConfig, MosquittoStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mosquitto

class TestMosquittoConnectorConfig:
    """Unit tests for MosquittoConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = MosquittoConnectorConfig(
            address="localhost:1883"
        )
        assert config.connector_type == "mosquitto"
        assert config.host == "localhost"
        assert config.port == 1883

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 1883)."""
        config = MosquittoConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 1883

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = MosquittoConnectorConfig(
            address="localhost:1883"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "mosquitto"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 1883
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mosquitto

class TestMosquittoStorageConnection:
    """Unit tests for MosquittoStorageConnection."""

    def test_connection_requires_mosquitto_package(self):
        """Test that connection raises error if Mosquitto package not available."""
        config = MosquittoConnectorConfig(
            address="localhost:1883"
        )
        try:
            connection = MosquittoStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Mosquitto connector package" in error_msg)

    def test_connection_requires_mosquitto_config_type(self):
        """Test that connection requires MosquittoConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MosquittoStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Mosquitto connector package" in error_msg or
                "Expected MosquittoConnectorConfig" in error_msg)
