#!/usr/bin/env python3
"""
Unit tests for GoogleSheetsConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.google_sheets_connector_strategy import GoogleSheetsConnector
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_google_sheets

class TestGoogleSheetsConnector:
    """Unit tests for GoogleSheetsConnector."""

    def test_connector_initialization_with_spreadsheet_id(self):
        """Test connector initialization with spreadsheet ID."""
        connector = GoogleSheetsConnector(
            spreadsheet_id="1YpujKREKaw9Hfort4dR2R3lqHaVZt2iMqSn5avfza0Y"
        )
        assert connector.spreadsheet_id == "1YpujKREKaw9Hfort4dR2R3lqHaVZt2iMqSn5avfza0Y"

    def test_connector_initialization_with_path_dict(self):
        """Test connector initialization with path dictionary."""
        connector = GoogleSheetsConnector(
            path={"spreadsheet_id": "1YpujKREKaw9Hfort4dR2R3lqHaVZt2iMqSn5avfza0Y"}
        )
        assert connector.spreadsheet_id == "1YpujKREKaw9Hfort4dR2R3lqHaVZt2iMqSn5avfza0Y"

    def test_connector_read_only_default(self):
        """Test connector defaults to read-only False."""
        connector = GoogleSheetsConnector(
            spreadsheet_id="test_id"
        )
        assert connector.read_only == False
