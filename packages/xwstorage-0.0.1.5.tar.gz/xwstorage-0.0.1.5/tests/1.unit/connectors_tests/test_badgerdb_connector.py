#!/usr/bin/env python3
"""
Unit tests for BadgerDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.badgerdb_connector import BadgerDBConnectorConfig, BadgerDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_badgerdb

class TestBadgerDBConnectorConfig:
    """Unit tests for BadgerDBConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with database path."""
        config = BadgerDBConnectorConfig(
            address="/tmp/badgerdb"
        )
        assert config.connector_type == "badgerdb"
        assert config.db_path == "/tmp/badgerdb"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = BadgerDBConnectorConfig(
            address="/tmp/badgerdb"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "badgerdb"
        assert config_dict["db_path"] == "/tmp/badgerdb"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_badgerdb

class TestBadgerDBStorageConnection:
    """Unit tests for BadgerDBStorageConnection."""

    def test_connection_requires_badgerdb_package(self):
        """Test that connection raises error if BadgerDB package not available."""
        config = BadgerDBConnectorConfig(
            address="/tmp/badgerdb"
        )
        try:
            connection = BadgerDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_badgerdb_config_type(self):
        """Test that connection requires BadgerDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            BadgerDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected BadgerDBConnectorConfig" in error_msg)
