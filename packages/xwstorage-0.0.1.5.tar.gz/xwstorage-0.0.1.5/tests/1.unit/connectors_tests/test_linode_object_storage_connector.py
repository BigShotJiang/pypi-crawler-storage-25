#!/usr/bin/env python3
"""
Unit tests for Linode Object Storage connector.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import patch, MagicMock
from exonware.xwstorage.connectors.linode_object_storage_connector import (
    LinodeObjectStorageConnectorConfig,
    LinodeObjectStorageConnection
)
from exonware.xwstorage.errors import XWLocationError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_linode

class TestLinodeObjectStorageConnectorConfig:
    """Unit tests for LinodeObjectStorageConnectorConfig."""

    def test_config_initialization(self):
        """Test config initialization."""
        config = LinodeObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="us-east-1",
            access_key_id="test-key",
            secret_access_key="test-secret"
        )
        assert config.connector_type == "linode_object_storage"
        assert config.bucket == "test-bucket"
        assert config.region == "us-east-1"
        assert config.endpoint_url == "https://us-east-1.linodeobjects.com"

    def test_config_with_custom_endpoint(self):
        """Test config with custom endpoint URL."""
        config = LinodeObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="us-east-1",
            access_key_id="test-key",
            secret_access_key="test-secret",
            endpoint_url="https://custom.endpoint.com"
        )
        assert config.endpoint_url == "https://custom.endpoint.com"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = LinodeObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="us-east-1",
            access_key_id="test-key",
            secret_access_key="test-secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "linode_object_storage"
        assert config_dict["bucket"] == "test-bucket"
        assert "secret_access_key" not in config_dict  # Should not expose secrets
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_linode

class TestLinodeObjectStorageConnection:
    """Unit tests for LinodeObjectStorageConnection."""

    def test_connection_requires_s3_connector(self):
        """Test that connection requires S3 connector."""
        config = LinodeObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="us-east-1",
            access_key_id="test-key",
            secret_access_key="test-secret"
        )
        with patch('exonware.xwstorage.connectors.linode_object_storage_connector.S3_AVAILABLE', False):
            with pytest.raises(XWLocationError, match="S3 connector not available"):
                LinodeObjectStorageConnection(config, "json")

    def test_connection_with_invalid_config_type(self):
        """Test connection requires LinodeObjectStorageConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with patch('exonware.xwstorage.connectors.linode_object_storage_connector.S3_AVAILABLE', True):
            with pytest.raises(XWLocationError, match="Expected LinodeObjectStorageConnectorConfig"):
                LinodeObjectStorageConnection(local_config, "json")
    @pytest.mark.asyncio

    async def test_connection_initialization(self):
        """Test connection initialization."""
        config = LinodeObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="us-east-1",
            access_key_id="test-key",
            secret_access_key="test-secret"
        )
        with patch('exonware.xwstorage.connectors.linode_object_storage_connector.S3_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.linode_object_storage_connector.S3StorageConnection') as mock_s3:
                connection = LinodeObjectStorageConnection(config, "json")
                assert connection._config == config
                mock_s3.assert_called_once()
