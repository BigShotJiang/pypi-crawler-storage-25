#!/usr/bin/env python3
"""
Unit tests for RonConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.ron_connector import RonConnectorConfig, RonStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ron

class TestRonConnectorConfig:
    """Unit tests for RonConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with file path."""
        config = RonConnectorConfig(
            address="data/storage.ron"
        )
        assert config.connector_type == "ron"
        assert config.address == "data/storage.ron"
        assert config.security == True  # Default
        assert config.atomic_writes == False  # Default

    def test_config_initialization_with_options(self):
        """Test config initialization with options."""
        config = RonConnectorConfig(
            address="data/storage.ron",
            base_path="/allowed/path",
            security=False,
            atomic_writes=True
        )
        assert config.base_path == "/allowed/path"
        assert config.security == False
        assert config.atomic_writes == True

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RonConnectorConfig(
            address="data/storage.ron",
            base_path="/allowed/path",
            security=True
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "ron"
        assert config_dict["base_path"] == "/allowed/path"
        assert config_dict["security"] == True
        assert config_dict["atomic_writes"] == False
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ron

class TestRonStorageConnection:
    """Unit tests for RonStorageConnection."""

    def test_connection_requires_ron_config_type(self):
        """Test that connection requires RonConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RonStorageConnection(local_config, "ron")
        error_msg = str(exc_info.value)
        assert ("Expected RonConnectorConfig" in error_msg)
