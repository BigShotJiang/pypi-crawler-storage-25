#!/usr/bin/env python3
"""
Unit tests for CockroachDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.cockroachdb_connector import CockroachDBConnectorConfig, CockroachDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cockroachdb

class TestCockroachDBConnectorConfig:
    """Unit tests for CockroachDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = CockroachDBConnectorConfig(
            address="localhost:26257",
            database="defaultdb",
            username="root",
            password="password"
        )
        assert config.connector_type == "cockroachdb"
        assert config.database == "defaultdb"
        assert config.username == "root"
        assert config.port == 26257

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 26257)."""
        config = CockroachDBConnectorConfig(
            address="localhost",
            database="mydb"
        )
        assert config.port == 26257

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = CockroachDBConnectorConfig(
            address="localhost:26257",
            database="defaultdb",
            username="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "cockroachdb"
        assert config_dict["database"] == "defaultdb"
        assert config_dict["username"] == "root"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cockroachdb

class TestCockroachDBStorageConnection:
    """Unit tests for CockroachDBStorageConnection."""

    def test_connection_requires_postgresql_package(self):
        """Test that connection raises error if PostgreSQL package not available."""
        config = CockroachDBConnectorConfig(
            address="localhost:26257",
            database="defaultdb"
        )
        try:
            connection = CockroachDBStorageConnection(config, "json")
            assert connection._config is not None
        except XWLocationError as e:
            assert "not installed" in str(e).lower() or "PostgreSQL connector" in str(e)

    def test_connection_requires_cockroachdb_config_type(self):
        """Test that connection requires CockroachDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            CockroachDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected CockroachDBConnectorConfig" in error_msg or
                "not installed" in error_msg.lower())
