#!/usr/bin/env python3
"""
Unit tests for JanusGraphConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.janusgraph_connector import JanusGraphConnectorConfig, JanusGraphStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_janusgraph

class TestJanusGraphConnectorConfig:
    """Unit tests for JanusGraphConnectorConfig."""

    def test_config_initialization_with_ws_url(self):
        """Test config initialization with WebSocket URL."""
        config = JanusGraphConnectorConfig(
            address="ws://localhost:8182/gremlin"
        )
        assert config.connector_type == "janusgraph"
        assert config.url == "ws://localhost:8182/gremlin"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to ws://)."""
        config = JanusGraphConnectorConfig(
            address="localhost:8182/gremlin"
        )
        assert config.url == "ws://localhost:8182/gremlin"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = JanusGraphConnectorConfig(
            address="ws://localhost:8182/gremlin"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "janusgraph"
        assert config_dict["url"] == "ws://localhost:8182/gremlin"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_janusgraph

class TestJanusGraphStorageConnection:
    """Unit tests for JanusGraphStorageConnection."""

    def test_connection_requires_janusgraph_package(self):
        """Test that connection raises error if JanusGraph package not available."""
        config = JanusGraphConnectorConfig(
            address="ws://localhost:8182/gremlin"
        )
        try:
            connection = JanusGraphStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_janusgraph_config_type(self):
        """Test that connection requires JanusGraphConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            JanusGraphStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected JanusGraphConnectorConfig" in error_msg)
