#!/usr/bin/env python3
"""
Unit tests for MonetDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.monetdb_connector import MonetDBConnectorConfig, MonetDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_monetdb

class TestMonetDBConnectorConfig:
    """Unit tests for MonetDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = MonetDBConnectorConfig(
            address="localhost:50000",
            database="demo",
            username="monetdb",
            password="monetdb"
        )
        assert config.connector_type == "monetdb"
        assert config.host == "localhost"
        assert config.port == 50000
        assert config.database == "demo"
        assert config.username == "monetdb"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 50000)."""
        config = MonetDBConnectorConfig(
            address="localhost",
            database="demo"
        )
        assert config.host == "localhost"
        assert config.port == 50000

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = MonetDBConnectorConfig(
            address="localhost:50000",
            database="demo",
            username="monetdb",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "monetdb"
        assert config_dict["host"] == "localhost"
        assert config_dict["database"] == "demo"
        assert config_dict["username"] == "monetdb"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_monetdb

class TestMonetDBStorageConnection:
    """Unit tests for MonetDBStorageConnection."""

    def test_connection_requires_monetdb_package(self):
        """Test that connection raises error if MonetDB package not available."""
        config = MonetDBConnectorConfig(
            address="localhost:50000",
            database="demo"
        )
        try:
            connection = MonetDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_monetdb_config_type(self):
        """Test that connection requires MonetDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MonetDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected MonetDBConnectorConfig" in error_msg)
