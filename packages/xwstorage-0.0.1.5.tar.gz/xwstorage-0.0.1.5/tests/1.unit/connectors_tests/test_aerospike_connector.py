#!/usr/bin/env python3
"""
Unit tests for AerospikeConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.aerospike_connector import AerospikeConnectorConfig, AerospikeStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_aerospike

class TestAerospikeConnectorConfig:
    """Unit tests for AerospikeConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = AerospikeConnectorConfig(
            address="localhost:3000",
            namespace="test",
            set_name="my_set"
        )
        assert config.connector_type == "aerospike"
        assert config.host == "localhost"
        assert config.port == 3000
        assert config.namespace == "test"
        assert config.set_name == "my_set"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 3000)."""
        config = AerospikeConnectorConfig(
            address="localhost",
            namespace="test"
        )
        assert config.host == "localhost"
        assert config.port == 3000

    def test_config_initialization_with_empty_set_name(self):
        """Test config initialization with empty set_name (default)."""
        config = AerospikeConnectorConfig(
            address="localhost:3000",
            namespace="test"
        )
        assert config.set_name == ""

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = AerospikeConnectorConfig(
            address="localhost:3000",
            namespace="test",
            set_name="my_set"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "aerospike"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 3000
        assert config_dict["namespace"] == "test"
        assert config_dict["set_name"] == "my_set"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_aerospike

class TestAerospikeStorageConnection:
    """Unit tests for AerospikeStorageConnection."""

    def test_connection_requires_aerospike_package(self):
        """Test that connection raises error if Aerospike package not available."""
        config = AerospikeConnectorConfig(
            address="localhost:3000",
            namespace="test"
        )
        try:
            connection = AerospikeStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_aerospike_config_type(self):
        """Test that connection requires AerospikeConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            AerospikeStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected AerospikeConnectorConfig" in error_msg)
