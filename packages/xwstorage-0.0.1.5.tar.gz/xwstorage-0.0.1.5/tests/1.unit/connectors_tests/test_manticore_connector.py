#!/usr/bin/env python3
"""
Unit tests for ManticoreConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.manticore_connector import ManticoreConnectorConfig, ManticoreStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_manticore

class TestManticoreConnectorConfig:
    """Unit tests for ManticoreConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = ManticoreConnectorConfig(
            address="http://localhost:9308"
        )
        assert config.connector_type == "manticore"
        assert config.url == "http://localhost:9308"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = ManticoreConnectorConfig(
            address="localhost:9308"
        )
        assert config.url == "http://localhost:9308"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ManticoreConnectorConfig(
            address="http://localhost:9308"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "manticore"
        assert config_dict["url"] == "http://localhost:9308"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_manticore

class TestManticoreStorageConnection:
    """Unit tests for ManticoreStorageConnection."""

    def test_connection_requires_manticore_package(self):
        """Test that connection raises error if Manticore package not available."""
        config = ManticoreConnectorConfig(
            address="http://localhost:9308"
        )
        try:
            connection = ManticoreStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Manticore connector package" in error_msg)

    def test_connection_requires_manticore_config_type(self):
        """Test that connection requires ManticoreConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ManticoreStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Manticore connector package" in error_msg or
                "Expected ManticoreConnectorConfig" in error_msg)
