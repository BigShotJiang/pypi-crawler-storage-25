#!/usr/bin/env python3
"""
Unit tests for VictoriaMetricsConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.victoriametrics_connector import VictoriaMetricsConnectorConfig, VictoriaMetricsStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_victoriametrics

class TestVictoriaMetricsConnectorConfig:
    """Unit tests for VictoriaMetricsConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = VictoriaMetricsConnectorConfig(
            address="http://localhost:8428"
        )
        assert config.connector_type == "victoriametrics"
        assert config.url == "http://localhost:8428"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = VictoriaMetricsConnectorConfig(
            address="localhost:8428"
        )
        assert config.url == "http://localhost:8428"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = VictoriaMetricsConnectorConfig(
            address="http://localhost:8428"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "victoriametrics"
        assert config_dict["url"] == "http://localhost:8428"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_victoriametrics

class TestVictoriaMetricsStorageConnection:
    """Unit tests for VictoriaMetricsStorageConnection."""

    def test_connection_requires_victoriametrics_package(self):
        """Test that connection raises error if VictoriaMetrics package not available."""
        config = VictoriaMetricsConnectorConfig(
            address="http://localhost:8428"
        )
        try:
            connection = VictoriaMetricsStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "VictoriaMetrics connector package" in error_msg)

    def test_connection_requires_victoriametrics_config_type(self):
        """Test that connection requires VictoriaMetricsConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            VictoriaMetricsStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "VictoriaMetrics connector package" in error_msg or
                "Expected VictoriaMetricsConnectorConfig" in error_msg)
