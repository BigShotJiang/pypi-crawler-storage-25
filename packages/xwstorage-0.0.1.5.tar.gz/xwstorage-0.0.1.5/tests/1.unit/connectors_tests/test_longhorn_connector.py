#!/usr/bin/env python3
"""
Unit tests for LonghornConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.longhorn_connector import LonghornConnectorConfig, LonghornStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_longhorn

class TestLonghornConnectorConfig:
    """Unit tests for LonghornConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = LonghornConnectorConfig(
            address="http://localhost:9500"
        )
        assert config.connector_type == "longhorn"
        assert config.base_url == "http://localhost:9500"
        assert config.timeout == 30  # Default

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = LonghornConnectorConfig(
            address="localhost:9500"
        )
        assert config.base_url == "http://localhost:9500"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = LonghornConnectorConfig(
            address="http://localhost:9500",
            timeout=60
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "longhorn"
        assert config_dict["base_url"] == "http://localhost:9500"
        assert config_dict["timeout"] == 60
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_longhorn

class TestLonghornStorageConnection:
    """Unit tests for LonghornStorageConnection."""

    def test_connection_requires_longhorn_package(self):
        """Test that connection raises error if Longhorn package not available."""
        config = LonghornConnectorConfig(
            address="http://localhost:9500"
        )
        try:
            connection = LonghornStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Longhorn connector package" in error_msg)

    def test_connection_requires_longhorn_config_type(self):
        """Test that connection requires LonghornConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            LonghornStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Longhorn connector package" in error_msg or
                "Expected LonghornConnectorConfig" in error_msg)
