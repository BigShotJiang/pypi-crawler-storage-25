#!/usr/bin/env python3
"""
Unit tests for OneDrive connector strategy.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from exonware.xwstorage.connectors.onedrive_connector_strategy import OneDriveConnector
from exonware.xwstorage.errors import XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_onedrive

class TestOneDriveConnector:
    """Unit tests for OneDriveConnector."""

    def test_connector_initialization(self):
        """Test connector initialization."""
        connector = OneDriveConnector(
            client_id="test-client-id",
            client_secret="test-secret",
            tenant_id="test-tenant"
        )
        assert connector.connector_type == "onedrive"
        assert connector.client_id == "test-client-id"
        assert connector.tenant_id == "test-tenant"
        assert connector._connected is False

    def test_connector_initialization_with_token(self):
        """Test connector initialization with access token."""
        connector = OneDriveConnector(access_token="test-token")
        assert connector.access_token == "test-token"
    @pytest.mark.asyncio

    async def test_connect_with_access_token(self):
        """Test connect with access token."""
        connector = OneDriveConnector(access_token="test-token")
        with patch('exonware.xwstorage.connectors.onedrive_connector_strategy.MSAL_AVAILABLE', True):
            with patch('requests.get') as mock_get:
                mock_response = MagicMock()
                mock_response.status_code = 200
                mock_response.ok = True
                mock_get.return_value = mock_response
                await connector.connect()
                assert connector._connected is True
                assert connector._client is not None
    @pytest.mark.asyncio

    async def test_connect_with_app_credentials(self, mock_msal_app):
        """Test connect with app credentials."""
        connector = OneDriveConnector(
            client_id="test-client-id",
            client_secret="test-secret",
            tenant_id="test-tenant"
        )
        with patch('exonware.xwstorage.connectors.onedrive_connector_strategy.MSAL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.onedrive_connector_strategy.ConfidentialClientApplication', return_value=mock_msal_app):
                await connector.connect()
                assert connector._connected is True
                assert connector.access_token == "test-token"
    @pytest.mark.asyncio

    async def test_connect_requires_package(self):
        """Test that connect requires msal package."""
        connector = OneDriveConnector(access_token="test-token")
        with patch('exonware.xwstorage.connectors.onedrive_connector_strategy.MSAL_AVAILABLE', False):
            with pytest.raises(XWStorageError, match="msal not available"):
                await connector.connect()
    @pytest.mark.asyncio

    async def test_connect_without_credentials(self):
        """Test connect without credentials raises error."""
        connector = OneDriveConnector()
        with patch('exonware.xwstorage.connectors.onedrive_connector_strategy.MSAL_AVAILABLE', True):
            with pytest.raises(XWStorageError, match="OneDrive authentication required"):
                await connector.connect()
    @pytest.mark.asyncio

    async def test_disconnect(self):
        """Test disconnect."""
        connector = OneDriveConnector(access_token="test-token")
        connector._client = MagicMock()
        connector._connected = True
        await connector.disconnect()
        assert connector._connected is False
        assert connector._client is None
