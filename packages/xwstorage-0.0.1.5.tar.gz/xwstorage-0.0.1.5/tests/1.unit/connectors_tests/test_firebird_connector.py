#!/usr/bin/env python3
"""
Unit tests for FirebirdConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.firebird_connector import FirebirdConnectorConfig, FirebirdStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_firebird

class TestFirebirdConnectorConfig:
    """Unit tests for FirebirdConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with database file path."""
        config = FirebirdConnectorConfig(
            address="/path/to/database.fdb",
            user="SYSDBA",
            password="masterkey"
        )
        assert config.connector_type == "firebird"
        assert config.database_path == "/path/to/database.fdb"
        assert config.user == "SYSDBA"

    def test_config_defaults(self):
        """Test config uses default user and password."""
        config = FirebirdConnectorConfig(
            address="/path/to/database.fdb"
        )
        assert config.user == "SYSDBA"
        assert config.password == "masterkey"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = FirebirdConnectorConfig(
            address="/path/to/database.fdb",
            user="SYSDBA",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "firebird"
        assert config_dict["database_path"] == "/path/to/database.fdb"
        assert config_dict["user"] == "SYSDBA"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_firebird

class TestFirebirdStorageConnection:
    """Unit tests for FirebirdStorageConnection."""

    def test_connection_requires_firebird_package(self):
        """Test that connection raises error if Firebird package not available."""
        config = FirebirdConnectorConfig(
            address="/path/to/database.fdb"
        )
        try:
            connection = FirebirdStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_firebird_config_type(self):
        """Test that connection requires FirebirdConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            FirebirdStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected FirebirdConnectorConfig" in error_msg)
