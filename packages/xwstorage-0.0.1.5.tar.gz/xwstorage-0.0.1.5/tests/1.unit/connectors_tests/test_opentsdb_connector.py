#!/usr/bin/env python3
"""
Unit tests for OpenTSDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.opentsdb_connector import OpenTSDBConnectorConfig, OpenTSDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_opentsdb

class TestOpenTSDBConnectorConfig:
    """Unit tests for OpenTSDBConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = OpenTSDBConnectorConfig(
            address="http://localhost:4242"
        )
        assert config.connector_type == "opentsdb"
        assert config.url == "http://localhost:4242"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = OpenTSDBConnectorConfig(
            address="localhost:4242"
        )
        assert config.url == "http://localhost:4242"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = OpenTSDBConnectorConfig(
            address="http://localhost:4242"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "opentsdb"
        assert config_dict["url"] == "http://localhost:4242"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_opentsdb

class TestOpenTSDBStorageConnection:
    """Unit tests for OpenTSDBStorageConnection."""

    def test_connection_requires_opentsdb_package(self):
        """Test that connection raises error if OpenTSDB package not available."""
        config = OpenTSDBConnectorConfig(
            address="http://localhost:4242"
        )
        try:
            connection = OpenTSDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "OpenTSDB connector package" in error_msg)

    def test_connection_requires_opentsdb_config_type(self):
        """Test that connection requires OpenTSDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            OpenTSDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "OpenTSDB connector package" in error_msg or
                "Expected OpenTSDBConnectorConfig" in error_msg)
