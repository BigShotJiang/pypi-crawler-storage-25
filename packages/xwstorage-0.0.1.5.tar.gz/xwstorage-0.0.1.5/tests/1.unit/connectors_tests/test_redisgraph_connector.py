#!/usr/bin/env python3
"""
Unit tests for RedisGraphConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.redisgraph_connector import RedisGraphConnectorConfig, RedisGraphStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redisgraph

class TestRedisGraphConnectorConfig:
    """Unit tests for RedisGraphConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = RedisGraphConnectorConfig(
            address="localhost:6379",
            graph_name="graph"
        )
        assert config.connector_type == "redisgraph"
        assert config.host == "localhost"
        assert config.port == 6379
        assert config.graph_name == "graph"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 6379)."""
        config = RedisGraphConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 6379

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RedisGraphConnectorConfig(
            address="localhost:6379",
            graph_name="mygraph"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "redisgraph"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 6379
        assert config_dict["graph_name"] == "mygraph"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redisgraph

class TestRedisGraphStorageConnection:
    """Unit tests for RedisGraphStorageConnection."""

    def test_connection_requires_redis_package(self):
        """Test that connection raises error if Redis package not available."""
        config = RedisGraphConnectorConfig(
            address="localhost:6379"
        )
        try:
            connection = RedisGraphStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_redisgraph_config_type(self):
        """Test that connection requires RedisGraphConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RedisGraphStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected RedisGraphConnectorConfig" in error_msg)
