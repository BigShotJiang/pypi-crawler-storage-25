#!/usr/bin/env python3
"""
Unit tests for ElasticsearchConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.elasticsearch_connector import ElasticsearchConnectorConfig, ElasticsearchStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_elasticsearch

class TestElasticsearchConnectorConfig:
    """Unit tests for ElasticsearchConnectorConfig."""

    def test_config_initialization_with_index_name(self):
        """Test config initialization with index name."""
        config = ElasticsearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"],
            username="elastic",
            password="password"
        )
        assert config.connector_type == "elasticsearch"
        assert config.index_name == "my_index"
        assert config.hosts == ["localhost:9200"]
        assert config.username == "elastic"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string."""
        config = ElasticsearchConnectorConfig(
            address="http://localhost:9200",
            index_name="my_index"
        )
        assert config.connection_string == "http://localhost:9200"
        assert config.index_name == "my_index"
        assert config.host == "localhost"
        assert config.port == 9200

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host and port."""
        config = ElasticsearchConnectorConfig(
            address="my_index",
            host="localhost",
            port=9200
        )
        assert config.index_name == "my_index"
        assert config.host == "localhost"
        assert config.port == 9200

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ElasticsearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"],
            username="elastic",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "elasticsearch"
        assert config_dict["index_name"] == "my_index"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 9200 when not specified."""
        config = ElasticsearchConnectorConfig(
            address="my_index",
            host="localhost"
        )
        assert config.port == 9200
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_elasticsearch

class TestElasticsearchStorageConnection:
    """Unit tests for ElasticsearchStorageConnection."""

    def test_connection_requires_elasticsearch_package(self):
        """Test that connection raises error if Elasticsearch package not available."""
        config = ElasticsearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"]
        )
        try:
            connection = ElasticsearchStorageConnection(config, "json")
            # If we get here, elasticsearch package is available
            assert connection._config == config
        except XWLocationError as e:
            # Expected if elasticsearch package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_elasticsearch_config_type(self):
        """Test that connection requires ElasticsearchConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ElasticsearchStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected ElasticsearchConnectorConfig" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = ElasticsearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"]
        )
        try:
            connection = ElasticsearchStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("Elasticsearch package not installed")

    def test_connection_serializer_format(self):
        """Test connection handles different serializer formats."""
        config = ElasticsearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"]
        )
        try:
            # Test JSON format
            connection = ElasticsearchStorageConnection(config, "json")
            assert connection._serializer_format == "json"
        except XWLocationError:
            pytest.skip("Elasticsearch package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_elasticsearch
@pytest.mark.skip(reason="Requires Elasticsearch server running")

class TestElasticsearchStorageConnectionOperations:
    """Unit tests for Elasticsearch storage operations (requires running server)."""
    @pytest.fixture

    def elasticsearch_config(self):
        """Elasticsearch config for testing (requires running server)."""
        return ElasticsearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"]
        )
    @pytest.mark.asyncio

    async def test_elasticsearch_save_and_load(self, elasticsearch_config, sample_data, test_path):
        """Test Elasticsearch save and load operations."""
        connection = ElasticsearchStorageConnection(elasticsearch_config, "json")
        await connection.save(sample_data, test_path)
        loaded = await connection.load(test_path)
        assert loaded == sample_data
