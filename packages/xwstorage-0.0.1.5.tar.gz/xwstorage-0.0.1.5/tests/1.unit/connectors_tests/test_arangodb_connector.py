#!/usr/bin/env python3
"""
Unit tests for ArangoDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.arangodb_connector import ArangoDBConnectorConfig, ArangoDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_arangodb

class TestArangoDBConnectorConfig:
    """Unit tests for ArangoDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = ArangoDBConnectorConfig(
            database="mydb",
            collection="mycollection",
            host="localhost",
            port=8529,
            username="root",
            password="password"
        )
        assert config.connector_type == "arangodb"
        assert config.database == "mydb"
        assert config.collection == "mycollection"
        assert config.host == "localhost"
        assert config.port == 8529
        assert config.username == "root"

    def test_config_initialization_with_defaults(self):
        """Test config initialization with default values."""
        config = ArangoDBConnectorConfig(
            database="mydb",
            collection="mycollection"
        )
        assert config.host == "localhost"
        assert config.port == 8529
        assert config.username == "root"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = ArangoDBConnectorConfig(
            database="mydb",
            collection="mycollection",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "arangodb"
        assert config_dict["database"] == "mydb"
        assert config_dict["collection"] == "mycollection"
        assert config_dict["host"] == "localhost"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_arangodb

class TestArangoDBStorageConnection:
    """Unit tests for ArangoDBStorageConnection."""

    def test_connection_requires_arangodb_package(self):
        """Test that connection raises error if ArangoDB package not available."""
        config = ArangoDBConnectorConfig(
            database="mydb",
            collection="mycollection"
        )
        try:
            connection = ArangoDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_arangodb_config_type(self):
        """Test that connection requires ArangoDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ArangoDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected ArangoDBConnectorConfig" in error_msg)
