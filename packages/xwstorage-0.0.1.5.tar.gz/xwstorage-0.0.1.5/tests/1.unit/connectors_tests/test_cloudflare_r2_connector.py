#!/usr/bin/env python3
"""
Unit tests for CloudflareR2Connector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.cloudflare_r2_connector import CloudflareR2ConnectorConfig, CloudflareR2StorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cloudflare_r2

class TestCloudflareR2ConnectorConfig:
    """Unit tests for CloudflareR2ConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = CloudflareR2ConnectorConfig(
            bucket="my-bucket",
            account_id="abc123def456",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        assert config.connector_type == "cloudflare_r2"
        assert config.bucket == "my-bucket"
        assert config.account_id == "abc123def456"
        assert config.access_key_id == "my_access_key"
        assert config.secret_access_key == "my_secret_key"
        assert config.endpoint_url == "https://abc123def456.r2.cloudflarestorage.com"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = CloudflareR2ConnectorConfig(
            bucket="my-bucket",
            account_id="abc123def456",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "cloudflare_r2"
        assert config_dict["bucket"] == "my-bucket"
        assert config_dict["account_id"] == "abc123def456"
        assert config_dict["endpoint_url"] == "https://abc123def456.r2.cloudflarestorage.com"
        assert "secret_access_key" not in config_dict  # Secret should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cloudflare_r2

class TestCloudflareR2StorageConnection:
    """Unit tests for CloudflareR2StorageConnection."""

    def test_connection_requires_s3_connector(self):
        """Test that connection raises error if S3 connector not available."""
        config = CloudflareR2ConnectorConfig(
            bucket="my-bucket",
            account_id="abc123def456",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        try:
            connection = CloudflareR2StorageConnection(config, "json")
            assert connection._config is not None
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not available" in error_msg.lower() or 
                    "S3 connector" in error_msg or
                    "boto3" in error_msg.lower())

    def test_connection_requires_cloudflare_r2_config_type(self):
        """Test that connection requires CloudflareR2ConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            CloudflareR2StorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected CloudflareR2ConnectorConfig" in error_msg or
                "S3 connector not available" in error_msg)
