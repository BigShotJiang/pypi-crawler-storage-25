#!/usr/bin/env python3
"""
Unit tests for ChromaConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.chroma_connector import ChromaConnectorConfig, ChromaStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_chroma

class TestChromaConnectorConfig:
    """Unit tests for ChromaConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL (remote)."""
        config = ChromaConnectorConfig(
            address="http://localhost:8000"
        )
        assert config.connector_type == "chroma"
        assert config.url == "http://localhost:8000"
        assert config.is_remote is True

    def test_config_initialization_with_path(self):
        """Test config initialization with local path."""
        config = ChromaConnectorConfig(
            address="/tmp/chroma_db"
        )
        assert config.path == "/tmp/chroma_db"
        assert config.is_remote is False

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ChromaConnectorConfig(
            address="http://localhost:8000"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "chroma"
        assert config_dict["url"] == "http://localhost:8000"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_chroma

class TestChromaStorageConnection:
    """Unit tests for ChromaStorageConnection."""

    def test_connection_requires_chroma_package(self):
        """Test that connection raises error if Chroma package not available."""
        config = ChromaConnectorConfig(
            address="http://localhost:8000"
        )
        try:
            connection = ChromaStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_chroma_config_type(self):
        """Test that connection requires ChromaConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ChromaStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected ChromaConnectorConfig" in error_msg)
