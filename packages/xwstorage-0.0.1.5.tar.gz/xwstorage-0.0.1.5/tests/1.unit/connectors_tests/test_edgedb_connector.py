#!/usr/bin/env python3
"""
Unit tests for EdgeDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.edgedb_connector import EdgeDBConnectorConfig, EdgeDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_edgedb

class TestEdgeDBConnectorConfig:
    """Unit tests for EdgeDBConnectorConfig."""

    def test_config_initialization_with_instance_name(self):
        """Test config initialization with instance name."""
        config = EdgeDBConnectorConfig(
            address="my_instance",
            database="edgedb",
            user="edgedb",
            password="password"
        )
        assert config.connector_type == "edgedb"
        assert config.database == "edgedb"
        assert config.user == "edgedb"
        assert config.instance_name == "my_instance"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string."""
        config = EdgeDBConnectorConfig(
            address="edgedb://user:pass@localhost/edgedb"
        )
        assert config.connection_string == "edgedb://user:pass@localhost/edgedb"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = EdgeDBConnectorConfig(
            address="my_instance",
            database="edgedb",
            user="edgedb",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "edgedb"
        assert config_dict["database"] == "edgedb"
        assert config_dict["user"] == "edgedb"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_edgedb

class TestEdgeDBStorageConnection:
    """Unit tests for EdgeDBStorageConnection."""

    def test_connection_requires_edgedb_package(self):
        """Test that connection raises error if EdgeDB package not available."""
        config = EdgeDBConnectorConfig(
            address="my_instance"
        )
        try:
            connection = EdgeDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_edgedb_config_type(self):
        """Test that connection requires EdgeDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            EdgeDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected EdgeDBConnectorConfig" in error_msg)
