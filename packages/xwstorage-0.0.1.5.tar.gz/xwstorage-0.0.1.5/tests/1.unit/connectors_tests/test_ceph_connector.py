#!/usr/bin/env python3
"""
Unit tests for CephConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.ceph_connector import CephConnectorConfig, CephStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ceph

class TestCephConnectorConfig:
    """Unit tests for CephConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with S3 endpoint URL."""
        config = CephConnectorConfig(
            address="http://localhost:7480",
            access_key="my_access_key",
            secret_key="my_secret_key"
        )
        assert config.connector_type == "ceph"
        assert config.endpoint_url == "http://localhost:7480"
        assert config.access_key == "my_access_key"
        assert config.secret_key == "my_secret_key"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = CephConnectorConfig(
            address="localhost:7480",
            access_key="my_access_key",
            secret_key="my_secret_key"
        )
        assert config.endpoint_url == "http://localhost:7480"

    def test_config_to_dict(self):
        """Test config to_dict conversion (secret_key masked)."""
        config = CephConnectorConfig(
            address="http://localhost:7480",
            access_key="my_access_key",
            secret_key="secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "ceph"
        assert config_dict["endpoint_url"] == "http://localhost:7480"
        if "secret_key" in config_dict:
            assert config_dict["secret_key"] == "***"  # Secret key should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ceph

class TestCephStorageConnection:
    """Unit tests for CephStorageConnection."""

    def test_connection_requires_boto3_package(self):
        """Test that connection raises error if boto3 package not available."""
        config = CephConnectorConfig(
            address="http://localhost:7480",
            access_key="my_access_key",
            secret_key="my_secret_key"
        )
        try:
            connection = CephStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_ceph_config_type(self):
        """Test that connection requires CephConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            CephStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected CephConnectorConfig" in error_msg)
