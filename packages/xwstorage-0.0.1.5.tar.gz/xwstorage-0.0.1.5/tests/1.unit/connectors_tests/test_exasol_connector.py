#!/usr/bin/env python3
"""
Unit tests for EXASOLConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.exasol_connector import EXASOLConnectorConfig, EXASOLStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_exasol

class TestEXASOLConnectorConfig:
    """Unit tests for EXASOLConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = EXASOLConnectorConfig(
            address="localhost:8563",
            username="sys",
            password="password",
            schema="SYS"
        )
        assert config.connector_type == "exasol"
        assert config.host == "localhost"
        assert config.port == 8563
        assert config.username == "sys"
        assert config.schema == "SYS"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 8563)."""
        config = EXASOLConnectorConfig(
            address="localhost",
            username="sys",
            password="password"
        )
        assert config.host == "localhost"
        assert config.port == 8563

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = EXASOLConnectorConfig(
            address="localhost:8563",
            username="sys",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "exasol"
        assert config_dict["host"] == "localhost"
        assert config_dict["username"] == "sys"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_exasol

class TestEXASOLStorageConnection:
    """Unit tests for EXASOLStorageConnection."""

    def test_connection_requires_exasol_package(self):
        """Test that connection raises error if EXASOL package not available."""
        config = EXASOLConnectorConfig(
            address="localhost:8563",
            username="sys",
            password="password"
        )
        try:
            connection = EXASOLStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_exasol_config_type(self):
        """Test that connection requires EXASOLConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            EXASOLStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected EXASOLConnectorConfig" in error_msg)
