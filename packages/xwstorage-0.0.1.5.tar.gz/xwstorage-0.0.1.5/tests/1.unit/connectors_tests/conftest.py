"""
Unit test fixtures for connector tests.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest

from unittest.mock import MagicMock, AsyncMock, Mock
from typing import Any
@pytest.fixture

def mock_boto3_client():
    """Mock boto3 S3 client."""
    mock_client = MagicMock()
    mock_client.list_buckets = AsyncMock(return_value={'Buckets': [{'Name': 'test-bucket'}]})
    mock_client.put_object = AsyncMock(return_value={'ETag': 'test-etag'})
    mock_client.get_object = AsyncMock(return_value={'Body': Mock(read=Mock(return_value=b'test data'))})
    mock_client.delete_object = AsyncMock()
    mock_client.list_objects_v2 = AsyncMock(return_value={'Contents': []})
    mock_client.generate_presigned_url = Mock(return_value='https://presigned-url.com')
    return mock_client
@pytest.fixture

def mock_dropbox_client():
    """Mock Dropbox client."""
    mock_client = MagicMock()
    mock_client.users_get_current_account = Mock(return_value=Mock(name=Mock(display_name="Test User"), email="test@example.com"))
    return mock_client
@pytest.fixture

def mock_box_client():
    """Mock Box client."""
    mock_client = MagicMock()
    mock_user = Mock()
    mock_user.name = "Test User"
    mock_user.login = "test@example.com"
    mock_client.user.return_value.get = Mock(return_value=mock_user)
    return mock_client
@pytest.fixture

def mock_msal_app():
    """Mock MSAL application."""
    mock_app = MagicMock()
    mock_app.acquire_token_for_client = Mock(return_value={'access_token': 'test-token'})
    return mock_app
@pytest.fixture

def mock_riak_client():
    """Mock Riak client."""
    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_obj = Mock()
    mock_obj.data = b'test data'
    mock_bucket.get = Mock(return_value=mock_obj)
    mock_bucket.new = Mock(return_value=Mock(store=Mock()))
    mock_client.bucket = Mock(return_value=mock_bucket)
    return mock_client
@pytest.fixture

def mock_aerospike_client():
    """Mock Aerospike client."""
    mock_client = MagicMock()
    mock_client.get = Mock(return_value=((), {'value': b'test data'}))
    mock_client.put = Mock()
    mock_client.remove = Mock()
    mock_client.exists = Mock(return_value=((), {'value': b'test data'}))
    return mock_client
@pytest.fixture

def mock_rocksdb():
    """Mock RocksDB database."""
    mock_db = MagicMock()
    mock_db.get = Mock(return_value=b'test data')
    mock_db.put = Mock()
    mock_db.delete = Mock()
    return mock_db
@pytest.fixture

def mock_orientdb_client():
    """Mock OrientDB client."""
    mock_client = MagicMock()
    mock_client.command = Mock()
    mock_client.query = Mock(return_value=[Mock(oRecordData={'xwstorage_path': 'test', 'data': 'value'})])
    return mock_client
@pytest.fixture

def mock_mongodb_client():
    """Mock MongoDB client."""
    mock_client = MagicMock()
    mock_db = MagicMock()
    mock_collection = MagicMock()
    mock_collection.find_one = AsyncMock(return_value={'_id': 'test', 'data': 'value'})
    mock_collection.insert_one = AsyncMock(return_value=Mock(inserted_id='test-id'))
    mock_collection.update_one = AsyncMock()
    mock_collection.delete_one = AsyncMock()
    mock_db.__getitem__ = Mock(return_value=mock_collection)
    mock_client.__getitem__ = Mock(return_value=mock_db)
    return mock_client
@pytest.fixture

def mock_cassandra_session():
    """Mock Cassandra session."""
    mock_session = MagicMock()
    mock_session.execute = AsyncMock(return_value=[{'key': 'test', 'value': 'data'}])
    mock_session.prepare = Mock(return_value=Mock())
    return mock_session
