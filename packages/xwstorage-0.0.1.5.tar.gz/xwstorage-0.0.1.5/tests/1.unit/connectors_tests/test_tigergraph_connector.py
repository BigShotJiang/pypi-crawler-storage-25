#!/usr/bin/env python3
"""
Unit tests for TigerGraphConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.tigergraph_connector import TigerGraphConnectorConfig, TigerGraphStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_tigergraph

class TestTigerGraphConnectorConfig:
    """Unit tests for TigerGraphConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = TigerGraphConnectorConfig(
            address="http://localhost:9000",
            graphname="MyGraph",
            username="tigergraph",
            password="tigergraph"
        )
        assert config.connector_type == "tigergraph"
        assert config.host == "localhost"
        assert config.port == 9000
        assert config.graphname == "MyGraph"
        assert config.username == "tigergraph"

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = TigerGraphConnectorConfig(
            address="localhost:9000",
            graphname="MyGraph"
        )
        assert config.host == "localhost"
        assert config.port == 9000

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = TigerGraphConnectorConfig(
            address="localhost:9000",
            graphname="MyGraph",
            username="tigergraph",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "tigergraph"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 9000
        assert config_dict["graphname"] == "MyGraph"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 9000 when not specified."""
        config = TigerGraphConnectorConfig(
            address="localhost",
            graphname="MyGraph"
        )
        assert config.port == 9000
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_tigergraph

class TestTigerGraphStorageConnection:
    """Unit tests for TigerGraphStorageConnection."""

    def test_connection_requires_tigergraph_package(self):
        """Test that connection raises error if TigerGraph package not available."""
        config = TigerGraphConnectorConfig(
            address="localhost:9000",
            graphname="MyGraph"
        )
        try:
            connection = TigerGraphStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_tigergraph_config_type(self):
        """Test that connection requires TigerGraphConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            TigerGraphStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected TigerGraphConnectorConfig" in error_msg)
