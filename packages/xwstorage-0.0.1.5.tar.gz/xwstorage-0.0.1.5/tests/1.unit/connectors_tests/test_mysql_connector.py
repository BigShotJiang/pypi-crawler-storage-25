#!/usr/bin/env python3
"""
Unit tests for MySQLConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.mysql_connector import MySQLConnectorConfig, MySQLStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mysql

class TestMySQLConnectorConfig:
    """Unit tests for MySQLConnectorConfig."""

    def test_config_initialization_with_table_name(self):
        """Test config initialization with just table name."""
        config = MySQLConnectorConfig(
            address="test_table",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="password"
        )
        assert config.connector_type == "mysql"
        assert config.table_name == "test_table"
        assert config.host == "localhost"
        assert config.port == 3306
        assert config.database == "testdb"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string."""
        config = MySQLConnectorConfig(
            address="localhost:3306/testdb",
            username="root",
            password="password",
            table_name="custom_table"
        )
        assert config.host == "localhost"
        assert config.port == 3306
        assert config.database == "testdb"
        assert config.table_name == "custom_table"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = MySQLConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb",
            username="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "mysql"
        assert config_dict["table_name"] == "test_table"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mysql

class TestMySQLStorageConnection:
    """Unit tests for MySQLStorageConnection."""

    def test_connection_requires_mysql_package(self):
        """Test that connection raises error if MySQL package not available."""
        # This test will pass if mysql package is not installed
        # and fail if it is installed (which is expected behavior)
        config = MySQLConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb",
            username="root",
            password="password"
        )
        try:
            connection = MySQLStorageConnection(config, "json")
            # If we get here, mysql package is available
            # Connection should be valid
            assert connection._config == config
        except XWLocationError as e:
            # Expected if mysql package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_mysql_config_type(self):
        """Test that connection requires MySQLConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        # If MySQL package is not installed, it will raise error about package first
        # If MySQL package is installed, it will raise error about config type
        with pytest.raises(XWLocationError) as exc_info:
            MySQLStorageConnection(local_config, "json")
        # Should raise error about either package or config type
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected MySQLConnectorConfig" in error_msg)
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mysql
@pytest.mark.skip(reason="Requires MySQL database running")

class TestMySQLStorageConnectionOperations:
    """Unit tests for MySQL storage operations (requires running MySQL)."""
    @pytest.fixture

    def mysql_config(self):
        """MySQL config for testing (requires running MySQL)."""
        return MySQLConnectorConfig(
            address="test_storage",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="password"
        )
    @pytest.fixture

    async def mysql_connection(self, mysql_config):
        """MySQL connection for testing."""
        connection = MySQLStorageConnection(mysql_config, "json")
        yield connection
    @pytest.mark.asyncio

    async def test_mysql_save_and_load(self, mysql_connection, sample_data, test_path):
        """Test MySQL save and load operations."""
        await mysql_connection.save(sample_data, test_path)
        loaded = await mysql_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_mysql_append_not_supported(self, mysql_connection, sample_data, test_path):
        """Test that append mode is not supported."""
        with pytest.raises(XWStorageError, match="not supported"):
            await mysql_connection.save(sample_data, test_path, append=True)
    @pytest.mark.asyncio

    async def test_mysql_exists(self, mysql_connection, sample_data, test_path):
        """Test MySQL exists check."""
        assert await mysql_connection.exists(test_path) is False
        await mysql_connection.save(sample_data, test_path)
        assert await mysql_connection.exists(test_path) is True
    @pytest.mark.asyncio

    async def test_mysql_delete(self, mysql_connection, sample_data, test_path):
        """Test MySQL delete operation."""
        await mysql_connection.save(sample_data, test_path)
        await mysql_connection.delete(test_path)
        assert await mysql_connection.exists(test_path) is False
