#!/usr/bin/env python3
"""
Unit tests for ApacheKylinConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.apache_kylin_connector import ApacheKylinConnectorConfig, ApacheKylinStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_kylin

class TestApacheKylinConnectorConfig:
    """Unit tests for ApacheKylinConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = ApacheKylinConnectorConfig(
            address="http://localhost:7070",
            project="default",
            username="ADMIN",
            password="KYLIN"
        )
        assert config.connector_type == "apache_kylin"
        assert config.base_url == "http://localhost:7070"
        assert config.project == "default"
        assert config.username == "ADMIN"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = ApacheKylinConnectorConfig(
            address="localhost:7070"
        )
        assert config.base_url == "http://localhost:7070"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password masked)."""
        config = ApacheKylinConnectorConfig(
            address="http://localhost:7070",
            project="default",
            username="ADMIN",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "apache_kylin"
        assert config_dict["base_url"] == "http://localhost:7070"
        assert config_dict["project"] == "default"
        if "password" in config_dict:
            assert config_dict["password"] == "***"  # Password should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_kylin

class TestApacheKylinStorageConnection:
    """Unit tests for ApacheKylinStorageConnection."""

    def test_connection_requires_kylin_package(self):
        """Test that connection raises error if Kylin package not available."""
        config = ApacheKylinConnectorConfig(
            address="http://localhost:7070"
        )
        try:
            connection = ApacheKylinStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Kylin connector package" in error_msg)

    def test_connection_requires_kylin_config_type(self):
        """Test that connection requires ApacheKylinConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ApacheKylinStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Kylin connector package" in error_msg or
                "Expected ApacheKylinConnectorConfig" in error_msg)
