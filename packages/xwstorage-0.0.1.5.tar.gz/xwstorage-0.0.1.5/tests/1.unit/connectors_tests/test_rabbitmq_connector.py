#!/usr/bin/env python3
"""
Unit tests for RabbitMQConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.rabbitmq_connector import RabbitMQConnectorConfig, RabbitMQStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_rabbitmq

class TestRabbitMQConnectorConfig:
    """Unit tests for RabbitMQConnectorConfig."""

    def test_config_initialization_single_server(self):
        """Test config initialization with single server."""
        config = RabbitMQConnectorConfig(
            address="amqp://localhost:5672"
        )
        assert config.connector_type == "rabbitmq"
        assert config.connection_string == "amqp://localhost:5672"
        assert config.host == "localhost"
        assert config.port == 5672

    def test_config_initialization_with_credentials(self):
        """Test config initialization with credentials."""
        config = RabbitMQConnectorConfig(
            address="amqp://user:pass@localhost:5672",
            exchange="my_exchange"
        )
        assert config.connection_string == "amqp://user:pass@localhost:5672"
        assert config.exchange == "my_exchange"

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host and port."""
        config = RabbitMQConnectorConfig(
            address="localhost",
            host="localhost",
            port=5672
        )
        assert config.host == "localhost"
        assert config.port == 5672

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RabbitMQConnectorConfig(
            address="amqp://localhost:5672",
            exchange="my_exchange"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "rabbitmq"
        assert config_dict["connection_string"] == "amqp://localhost:5672"

    def test_config_default_port(self):
        """Test config uses default port 5672 when not specified."""
        config = RabbitMQConnectorConfig(
            address="localhost"
        )
        assert config.port == 5672
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_rabbitmq

class TestRabbitMQStorageConnection:
    """Unit tests for RabbitMQStorageConnection."""

    def test_connection_requires_rabbitmq_package(self):
        """Test that connection raises error if RabbitMQ package not available."""
        config = RabbitMQConnectorConfig(
            address="amqp://localhost:5672"
        )
        try:
            connection = RabbitMQStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_rabbitmq_config_type(self):
        """Test that connection requires RabbitMQConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RabbitMQStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected RabbitMQConnectorConfig" in error_msg)
