#!/usr/bin/env python3
"""
Unit tests for EMQXConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.emqx_connector import EMQXConnectorConfig, EMQXStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_emqx

class TestEMQXConnectorConfig:
    """Unit tests for EMQXConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = EMQXConnectorConfig(
            address="localhost:1883"
        )
        assert config.connector_type == "emqx"
        assert config.host == "localhost"
        assert config.port == 1883

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 1883)."""
        config = EMQXConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 1883

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = EMQXConnectorConfig(
            address="localhost:1883"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "emqx"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 1883
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_emqx

class TestEMQXStorageConnection:
    """Unit tests for EMQXStorageConnection."""

    def test_connection_requires_mqtt_package(self):
        """Test that connection raises error if MQTT package not available."""
        config = EMQXConnectorConfig(
            address="localhost:1883"
        )
        try:
            connection = EMQXStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_emqx_config_type(self):
        """Test that connection requires EMQXConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            EMQXStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected EMQXConnectorConfig" in error_msg)
