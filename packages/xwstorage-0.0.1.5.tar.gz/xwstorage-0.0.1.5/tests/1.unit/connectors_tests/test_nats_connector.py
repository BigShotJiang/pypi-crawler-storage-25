#!/usr/bin/env python3
"""
Unit tests for NATSConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.nats_connector import NATSConnectorConfig, NATSStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_nats

class TestNATSConnectorConfig:
    """Unit tests for NATSConnectorConfig."""

    def test_config_initialization_with_nats_url(self):
        """Test config initialization with nats:// URL."""
        config = NATSConnectorConfig(
            address="nats://localhost:4222"
        )
        assert config.connector_type == "nats"
        assert config.url == "nats://localhost:4222"

    def test_config_initialization_with_tls_url(self):
        """Test config initialization with tls:// URL."""
        config = NATSConnectorConfig(
            address="tls://localhost:4222"
        )
        assert config.url == "tls://localhost:4222"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to nats://)."""
        config = NATSConnectorConfig(
            address="localhost:4222"
        )
        assert config.url == "nats://localhost:4222"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = NATSConnectorConfig(
            address="nats://localhost:4222"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "nats"
        assert config_dict["url"] == "nats://localhost:4222"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_nats

class TestNATSStorageConnection:
    """Unit tests for NATSStorageConnection."""

    def test_connection_requires_nats_package(self):
        """Test that connection raises error if NATS package not available."""
        config = NATSConnectorConfig(
            address="nats://localhost:4222"
        )
        try:
            connection = NATSStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_nats_config_type(self):
        """Test that connection requires NATSConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            NATSStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected NATSConnectorConfig" in error_msg)
