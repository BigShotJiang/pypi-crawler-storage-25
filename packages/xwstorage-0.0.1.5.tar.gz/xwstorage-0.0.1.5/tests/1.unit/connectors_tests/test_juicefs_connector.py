#!/usr/bin/env python3
"""
Unit tests for JuiceFSConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.juicefs_connector import JuiceFSConnectorConfig, JuiceFSStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_juicefs

class TestJuiceFSConnectorConfig:
    """Unit tests for JuiceFSConnectorConfig."""

    def test_config_initialization_with_mount_point(self):
        """Test config initialization with mount point path."""
        config = JuiceFSConnectorConfig(
            address="/mnt/jfs"
        )
        assert config.connector_type == "juicefs"
        assert config.mount_point == "/mnt/jfs"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = JuiceFSConnectorConfig(
            address="/mnt/jfs"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "juicefs"
        assert config_dict["mount_point"] == "/mnt/jfs"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_juicefs

class TestJuiceFSStorageConnection:
    """Unit tests for JuiceFSStorageConnection."""

    def test_connection_requires_posix_support(self):
        """Test that connection raises error if POSIX support not available."""
        config = JuiceFSConnectorConfig(
            address="/mnt/jfs"
        )
        try:
            connection = JuiceFSStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "JuiceFS connector" in error_msg or
                    "POSIX" in error_msg)

    def test_connection_requires_juicefs_config_type(self):
        """Test that connection requires JuiceFSConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            JuiceFSStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected JuiceFSConnectorConfig" in error_msg)
