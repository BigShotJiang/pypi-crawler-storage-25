#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/connectors_tests/test_connection_pool.py
Unit tests for Enhanced Connection Pool.
Tests pool sizing, lifecycle management, health monitoring, auto-reconnection, and timeouts.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, Mock, patch
from exonware.xwstorage.connectors.pool import ConnectionPool, ConnectionState
@pytest.mark.xwstorage_unit

class TestConnectionPool:
    """Test ConnectionPool implementation."""
    @pytest.fixture

    def mock_connection(self):
        """Create mock connection fixture."""
        conn = Mock()
        conn.health_check = AsyncMock(return_value=True)
        conn.close = AsyncMock()
        return conn
    @pytest.fixture

    def connector_factory(self):
        """Create connector factory fixture."""
        async def factory():
            conn = Mock()
            conn.health_check = AsyncMock(return_value=True)
            conn.close = AsyncMock()
            return conn
        return factory
    @pytest.fixture

    def pool(self, connector_factory):
        """Create connection pool fixture."""
        return ConnectionPool(
            connector_factory=connector_factory,
            min_size=2,
            max_size=5,
            health_check_interval=1.0,
            connection_timeout=2.0,
            operation_timeout=10.0
        )
    @pytest.mark.asyncio

    async def test_pool_initialization(self, pool):
        """Test pool initialization."""
        await pool.initialize()
        stats = pool.get_stats()
        assert stats["pool_size"] >= pool.min_size
        assert stats["available"] >= pool.min_size
        assert stats["in_use"] == 0
    @pytest.mark.asyncio

    async def test_get_connection(self, pool):
        """Test getting connection from pool."""
        await pool.initialize()
        conn = await pool.get_connection()
        assert conn is not None
        stats = pool.get_stats()
        assert stats["in_use"] == 1
        assert stats["available"] >= 0
    @pytest.mark.asyncio

    async def test_return_connection(self, pool):
        """Test returning connection to pool."""
        await pool.initialize()
        conn = await pool.get_connection()
        await pool.return_connection(conn)
        stats = pool.get_stats()
        assert stats["in_use"] == 0
        assert stats["available"] >= 1
    @pytest.mark.asyncio

    async def test_pool_max_size(self, pool):
        """Test pool respects max size."""
        await pool.initialize()
        # Get all connections up to max size
        connections = []
        for _ in range(pool.max_size):
            conn = await pool.get_connection()
            connections.append(conn)
        stats = pool.get_stats()
        assert stats["pool_size"] == pool.max_size
        assert stats["in_use"] == pool.max_size
        # Return all connections
        for conn in connections:
            await pool.return_connection(conn)
    @pytest.mark.asyncio

    async def test_connection_timeout(self, pool, connector_factory):
        """Test connection timeout when pool is exhausted."""
        await pool.initialize()
        # Exhaust pool
        connections = []
        for _ in range(pool.max_size):
            conn = await pool.get_connection()
            connections.append(conn)
        # Try to get another connection (should timeout)
        with pytest.raises(TimeoutError):
            await asyncio.wait_for(
                pool.get_connection(),
                timeout=pool.connection_timeout + 1.0
            )
        # Return connections
        for conn in connections:
            await pool.return_connection(conn)
    @pytest.mark.asyncio

    async def test_health_check(self, pool):
        """Test health check functionality."""
        await pool.initialize()
        # Get connection
        conn = await pool.get_connection()
        # Mock unhealthy connection
        conn.health_check.return_value = False
        # Return connection (should be discarded)
        await pool.return_connection(conn)
        stats = pool.get_stats()
        # Connection should be closed, not returned to pool
        assert stats["stats"]["closed"] >= 1
    @pytest.mark.asyncio

    async def test_auto_reconnect(self, pool, connector_factory, mock_connection):
        """Test automatic reconnection."""
        pool.enable_auto_reconnect = True
        # First call fails, second succeeds
        connector_factory.side_effect = [
            Exception("Connection failed"),
            mock_connection
        ]
        await pool.initialize()
        # Should eventually get connection after retry
        conn = await asyncio.wait_for(pool.get_connection(), timeout=5.0)
        assert conn is not None
        stats = pool.get_stats()
        assert stats["stats"]["reconnections"] >= 1
    @pytest.mark.asyncio

    async def test_periodic_health_check(self, pool):
        """Test periodic health check."""
        await pool.initialize()
        # Wait for health check interval
        await asyncio.sleep(pool.health_check_interval + 0.5)
        stats = pool.get_stats()
        assert stats["health_checks"] >= 0  # Should have run at least once
    @pytest.mark.asyncio

    async def test_idle_connection_cleanup(self, pool):
        """Test idle connection cleanup."""
        pool.max_idle_time = 1.0  # 1 second
        await pool.initialize()
        # Get and return connection
        conn = await pool.get_connection()
        await pool.return_connection(conn)
        # Wait for cleanup
        await asyncio.sleep(2.0)
        # Connection should be cleaned up if idle too long
        # (but not if pool is at minimum size)
        stats = pool.get_stats()
        # Pool should maintain minimum size
        assert stats["pool_size"] >= pool.min_size
    @pytest.mark.asyncio

    async def test_close_all(self, pool):
        """Test closing all connections."""
        await pool.initialize()
        # Get some connections
        conn1 = await pool.get_connection()
        conn2 = await pool.get_connection()
        # Close all
        await pool.close_all()
        stats = pool.get_stats()
        assert stats["closed"] is True
        assert stats["pool_size"] == 0
    @pytest.mark.asyncio

    async def test_context_manager(self, connector_factory):
        """Test pool as context manager."""
        async with ConnectionPool(
            connector_factory=connector_factory,
            min_size=1,
            max_size=3
        ) as pool:
            conn = await pool.get_connection()
            assert conn is not None
        # Pool should be closed after context exit
        stats = pool.get_stats()
        assert stats["closed"] is True
    @pytest.mark.asyncio

    async def test_statistics_tracking(self, pool):
        """Test statistics tracking."""
        await pool.initialize()
        # Get and return connections
        conn1 = await pool.get_connection()
        await pool.return_connection(conn1)
        conn2 = await pool.get_connection()
        await pool.return_connection(conn2)
        stats = pool.get_stats()
        assert stats["stats"]["created"] >= 1
        assert stats["stats"]["reused"] >= 1
