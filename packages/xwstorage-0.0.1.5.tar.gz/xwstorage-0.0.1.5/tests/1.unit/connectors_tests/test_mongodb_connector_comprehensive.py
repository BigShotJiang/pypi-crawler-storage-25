#!/usr/bin/env python3
"""
Comprehensive unit tests for MongoDBConnector - 100% coverage target.
Tests all code paths including error handling and edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from exonware.xwstorage.connectors.mongodb_connector import MongoDBConnectorConfig, MongoDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mongodb

class TestMongoDBConnectorConfigComprehensive:
    """Comprehensive tests for MongoDBConnectorConfig."""

    def test_config_address_parsing_variations(self):
        """Test various address string parsing scenarios."""
        # Test with standard connection string
        config = MongoDBConnectorConfig(
            address="mongodb://localhost:27017/mydb",
            collection_name="mycollection"
        )
        assert config.collection_name == "mycollection"
        assert config.database == "mydb"
        # Test with SRV connection string
        config2 = MongoDBConnectorConfig(
            address="mongodb+srv://cluster.mongodb.net/mydb",
            collection_name="mycollection"
        )
        assert config2.collection_name == "mycollection"
        assert config2.database == "mydb"
        # Test with just collection name
        config3 = MongoDBConnectorConfig(
            address="mycollection",
            host="localhost",
            database="mydb"
        )
        assert config3.collection_name == "mycollection"
        assert config3.database == "mydb"

    def test_config_to_dict_with_username(self):
        """Test to_dict includes username but not password."""
        config = MongoDBConnectorConfig(
            address="test_collection",
            host="localhost",
            database="testdb",
            username="testuser",
            password="secret"
        )
        config_dict = config.to_dict()
        assert "collection_name" in config_dict
        assert config_dict["collection_name"] == "test_collection"
        assert "password" not in config_dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mongodb

class TestMongoDBStorageConnectionComprehensive:
    """Comprehensive tests for MongoDBStorageConnection."""
    @pytest.fixture

    def mongo_config(self):
        """MongoDB config for testing."""
        return MongoDBConnectorConfig(
            address="test_collection",
            host="localhost",
            port=27017,
            database="testdb",
            username="admin",
            password="password"
        )
    @pytest.mark.asyncio

    async def test_connection_client_creation_motor(self, mongo_config):
        """Test async client creation with Motor."""
        with patch('exonware.xwstorage.connectors.mongodb_connector.MONGODB_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mongodb_connector.MONGODB_ASYNC', True):
                with patch('motor.motor_asyncio.AsyncIOMotorClient') as mock_client:
                    mock_client_instance = AsyncMock()
                    mock_client.return_value = mock_client_instance
                    connection = MongoDBStorageConnection(mongo_config, "json")
                    client = await connection._get_client()
                    assert client is not None
    @pytest.mark.asyncio

    async def test_connection_client_creation_sync(self, mongo_config):
        """Test sync client creation with pymongo."""
        with patch('exonware.xwstorage.connectors.mongodb_connector.MONGODB_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.mongodb_connector.MONGODB_ASYNC', False):
                with patch('pymongo.MongoClient') as mock_client:
                    mock_client_instance = MagicMock()
                    mock_client.return_value = mock_client_instance
                    connection = MongoDBStorageConnection(mongo_config, "json")
                    client = await connection._get_client()
                    assert client is not None

    def test_connection_requires_mongodb_package(self, mongo_config):
        """Test that connection raises error if MongoDB package not available."""
        with patch('exonware.xwstorage.connectors.mongodb_connector.MONGODB_AVAILABLE', False):
            with pytest.raises(XWLocationError) as exc_info:
                MongoDBStorageConnection(mongo_config, "json")
            error_msg = str(exc_info.value)
            assert "not installed" in error_msg.lower()

    def test_connection_requires_mongodb_config_type(self):
        """Test that connection requires MongoDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MongoDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected MongoDBConnectorConfig" in error_msg)
