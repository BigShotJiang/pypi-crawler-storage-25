#!/usr/bin/env python3
"""
Unit tests for ZIPConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.zip_connector import ZIPConnectorConfig, ZIPStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_zip

class TestZIPConnectorConfig:
    """Unit tests for ZIPConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with ZIP file path."""
        config = ZIPConnectorConfig(
            address="/tmp/archive.zip"
        )
        assert config.connector_type == "zip"
        assert str(config.zip_path) == "/tmp/archive.zip"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ZIPConnectorConfig(
            address="/tmp/archive.zip"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "zip"
        assert config_dict["zip_path"] == "/tmp/archive.zip"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_zip

class TestZIPStorageConnection:
    """Unit tests for ZIPStorageConnection."""

    def test_connection_requires_zip_config_type(self):
        """Test that connection requires ZIPConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ZIPStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected ZIPConnectorConfig" in error_msg)
