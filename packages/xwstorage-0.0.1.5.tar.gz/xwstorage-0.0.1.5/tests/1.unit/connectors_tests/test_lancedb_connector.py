#!/usr/bin/env python3
"""
Unit tests for LanceDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.lancedb_connector import LanceDBConnectorConfig, LanceDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_lancedb

class TestLanceDBConnectorConfig:
    """Unit tests for LanceDBConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with database path."""
        config = LanceDBConnectorConfig(
            address="/tmp/lancedb"
        )
        assert config.connector_type == "lancedb"
        assert config.db_path == "/tmp/lancedb"

    def test_config_initialization_with_uri(self):
        """Test config initialization with URI."""
        config = LanceDBConnectorConfig(
            address="s3://bucket/lancedb"
        )
        assert config.db_path == "s3://bucket/lancedb"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = LanceDBConnectorConfig(
            address="/tmp/lancedb"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "lancedb"
        assert config_dict["db_path"] == "/tmp/lancedb"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_lancedb

class TestLanceDBStorageConnection:
    """Unit tests for LanceDBStorageConnection."""

    def test_connection_requires_lancedb_package(self):
        """Test that connection raises error if LanceDB package not available."""
        config = LanceDBConnectorConfig(
            address="/tmp/lancedb"
        )
        try:
            connection = LanceDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "LanceDB connector package" in error_msg)

    def test_connection_requires_lancedb_config_type(self):
        """Test that connection requires LanceDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            LanceDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "LanceDB connector package" in error_msg or
                "Expected LanceDBConnectorConfig" in error_msg)
