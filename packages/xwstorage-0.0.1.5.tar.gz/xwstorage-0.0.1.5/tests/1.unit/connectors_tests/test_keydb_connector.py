#!/usr/bin/env python3
"""
Unit tests for KeyDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.keydb_connector import KeyDBConnectorConfig, KeyDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_keydb

class TestKeyDBConnectorConfig:
    """Unit tests for KeyDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = KeyDBConnectorConfig(
            address="localhost:6379"
        )
        assert config.connector_type == "keydb"
        assert config.host == "localhost"
        assert config.port == 6379
        assert config.db == 0  # Default database

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 6379)."""
        config = KeyDBConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 6379

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = KeyDBConnectorConfig(
            address="localhost:6379",
            db=1,
            password="mypass"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "keydb"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 6379
        assert config_dict["db"] == 1
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_keydb

class TestKeyDBStorageConnection:
    """Unit tests for KeyDBStorageConnection."""

    def test_connection_requires_redis_package(self):
        """Test that connection raises error if Redis package not available."""
        config = KeyDBConnectorConfig(
            address="localhost:6379"
        )
        try:
            connection = KeyDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_keydb_config_type(self):
        """Test that connection requires KeyDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            KeyDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected KeyDBConnectorConfig" in error_msg)
