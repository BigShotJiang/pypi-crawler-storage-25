#!/usr/bin/env python3
"""
Unit tests for PgvectorConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.pgvector_connector import PgvectorConnectorConfig, PgvectorStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_pgvector

class TestPgvectorConnectorConfig:
    """Unit tests for PgvectorConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = PgvectorConnectorConfig(
            address="localhost:5432/testdb",
            database="testdb",
            username="postgres",
            password="password"
        )
        assert config.connector_type == "pgvector"
        assert config.database == "testdb"
        assert config.username == "postgres"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = PgvectorConnectorConfig(
            address="localhost:5432/testdb",
            database="testdb",
            username="postgres",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "pgvector"
        assert config_dict["database"] == "testdb"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 5432 when not specified."""
        config = PgvectorConnectorConfig(
            address="localhost/testdb",
            database="testdb"
        )
        assert config.port == 5432
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_pgvector

class TestPgvectorStorageConnection:
    """Unit tests for PgvectorStorageConnection."""

    def test_connection_requires_postgresql_package(self):
        """Test that connection raises error if PostgreSQL package not available."""
        config = PgvectorConnectorConfig(
            address="localhost:5432/testdb",
            database="testdb"
        )
        try:
            connection = PgvectorStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_pgvector_config_type(self):
        """Test that connection requires PgvectorConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            PgvectorStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected PgvectorConnectorConfig" in error_msg)
