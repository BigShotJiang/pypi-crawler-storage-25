#!/usr/bin/env python3
"""
Unit tests for OpenSearchConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.opensearch_connector import OpenSearchConnectorConfig, OpenSearchStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_opensearch

class TestOpenSearchConnectorConfig:
    """Unit tests for OpenSearchConnectorConfig."""

    def test_config_initialization_with_index_name(self):
        """Test config initialization with index name."""
        config = OpenSearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"],
            username="admin",
            password="password"
        )
        assert config.connector_type == "opensearch"
        assert config.index_name == "my_index"
        assert config.hosts == ["localhost:9200"]
        assert config.username == "admin"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string."""
        config = OpenSearchConnectorConfig(
            address="http://localhost:9200",
            index_name="my_index"
        )
        assert config.connection_string == "http://localhost:9200"
        assert config.index_name == "my_index"
        assert config.host == "localhost"
        assert config.port == 9200

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = OpenSearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"],
            username="admin",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "opensearch"
        assert config_dict["index_name"] == "my_index"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_opensearch

class TestOpenSearchStorageConnection:
    """Unit tests for OpenSearchStorageConnection."""

    def test_connection_requires_elasticsearch_connector(self):
        """Test that connection raises error if Elasticsearch connector not available."""
        config = OpenSearchConnectorConfig(
            address="my_index",
            hosts=["localhost:9200"]
        )
        try:
            connection = OpenSearchStorageConnection(config, "json")
            assert connection._config is not None
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not available" in error_msg.lower() or 
                    "Elasticsearch connector" in error_msg)

    def test_connection_requires_opensearch_config_type(self):
        """Test that connection requires OpenSearchConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            OpenSearchStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected OpenSearchConnectorConfig" in error_msg or
                "Elasticsearch connector not available" in error_msg)
