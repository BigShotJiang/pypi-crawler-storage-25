#!/usr/bin/env python3
"""
Unit tests for ACID document connection (document WAL wrapper).
"""

import pytest
from pathlib import Path
from exonware.xwstorage.connectors.local_connector import (
    LocalConnectorConfig,
    LocalStorageConnection,
)
from exonware.xwstorage.connectors.acid_document_connection import ACIDDocumentConnection
@pytest.fixture


def temp_store_and_wal(tmp_path):
    store_path = tmp_path / "store.json"
    wal_path = tmp_path / "store.json.docwal"
    config = LocalConnectorConfig(address=str(store_path))
    inner = LocalStorageConnection(config, "json")
    acid = ACIDDocumentConnection(inner, str(wal_path))
    return acid, inner, str(store_path), str(wal_path)
@pytest.mark.xwstorage_unit


class TestACIDDocumentConnection:
    @pytest.mark.asyncio

    async def test_save_load_roundtrip(self, temp_store_and_wal):
        acid, _, _, _ = temp_store_and_wal
        await acid.save({"id": 1, "name": "Alice"}, "users/1")
        data = await acid.load("users/1")
        assert data == {"id": 1, "name": "Alice"}
    @pytest.mark.asyncio

    async def test_exists_and_delete(self, temp_store_and_wal):
        acid, _, _, _ = temp_store_and_wal
        await acid.save({"x": 1}, "doc/path")
        assert await acid.exists("doc/path") is True
        await acid.delete("doc/path")
        assert await acid.exists("doc/path") is False
    @pytest.mark.asyncio

    async def test_replay_on_new_instance(self, temp_store_and_wal):
        acid, inner, store_path, wal_path = temp_store_and_wal
        await acid.save({"recovered": True}, "recovery/key")
        # New ACID wrapper over same paths: should replay and see data
        config2 = LocalConnectorConfig(address=store_path)
        inner2 = LocalStorageConnection(config2, "json")
        acid2 = ACIDDocumentConnection(inner2, wal_path)
        data = await acid2.load("recovery/key")
        assert data == {"recovered": True}
    @pytest.mark.asyncio

    async def test_save_with_lock_manager_acquires_lock(self, temp_store_and_wal):
        from exonware.xwstorage.core.lock_manager import LockManager
        acid, _, _, _ = temp_store_and_wal
        lock_mgr = LockManager()
        txn_id = "txn-1"
        await acid.save(
            {"locked": True},
            "path/1",
            transaction_id=txn_id,
            lock_manager=lock_mgr,
        )
        # Lock should have been acquired and still held until release_all_locks
        await lock_mgr.release_all_locks(txn_id)
        data = await acid.load("path/1")
        assert data == {"locked": True}
    @pytest.mark.asyncio

    async def test_second_txn_blocks_until_lock_released(self, temp_store_and_wal):
        from exonware.xwstorage.core.lock_manager import LockManager
        acid, _, _, _ = temp_store_and_wal
        lock_mgr = LockManager()
        txn1 = "txn-1"
        txn2 = "txn-2"
        # txn1 acquires by saving
        await acid.save(
            {"v": 1},
            "path/1",
            transaction_id=txn1,
            lock_manager=lock_mgr,
        )
        # txn2 cannot acquire same resource
        with pytest.raises(RuntimeError, match="Could not acquire lock"):
            await acid.save(
                {"v": 2},
                "path/1",
                transaction_id=txn2,
                lock_manager=lock_mgr,
            )
        await lock_mgr.release_all_locks(txn1)
        # Now txn2 can acquire
        await acid.save(
            {"v": 2},
            "path/1",
            transaction_id=txn2,
            lock_manager=lock_mgr,
        )
        await lock_mgr.release_all_locks(txn2)
        data = await acid.load("path/1")
        assert data == {"v": 2}
