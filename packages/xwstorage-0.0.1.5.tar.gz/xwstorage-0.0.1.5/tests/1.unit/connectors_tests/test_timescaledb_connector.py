#!/usr/bin/env python3
"""
Unit tests for TimescaleDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.timescaledb_connector import TimescaleDBConnectorConfig, TimescaleDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_timescaledb

class TestTimescaleDBConnectorConfig:
    """Unit tests for TimescaleDBConnectorConfig."""

    def test_config_initialization_with_table_name(self):
        """Test config initialization with table name."""
        config = TimescaleDBConnectorConfig(
            address="localhost:5432/postgres",
            database="postgres",
            username="postgres",
            password="password",
            table_name="mytable"
        )
        assert config.connector_type == "timescaledb"
        assert config.table_name == "mytable"
        assert config.database == "postgres"
        assert config.username == "postgres"

    def test_config_initialization_with_host_port_separate(self):
        """Test config initialization with separate host and port."""
        config = TimescaleDBConnectorConfig(
            address="mytable",
            host="localhost",
            port=5432,
            database="mydb"
        )
        assert config.host == "localhost"
        assert config.port == 5432
        assert config.database == "mydb"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = TimescaleDBConnectorConfig(
            address="localhost:5432/postgres",
            database="postgres",
            username="postgres",
            password="secret",
            table_name="mytable"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "timescaledb"
        assert config_dict["table_name"] == "mytable"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 5432 when not specified."""
        config = TimescaleDBConnectorConfig(
            address="mytable",
            host="localhost",
            database="postgres"
        )
        assert config.port == 5432
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_timescaledb

class TestTimescaleDBStorageConnection:
    """Unit tests for TimescaleDBStorageConnection."""

    def test_connection_requires_postgresql_package(self):
        """Test that connection raises error if PostgreSQL package not available."""
        config = TimescaleDBConnectorConfig(
            address="localhost:5432/postgres",
            database="postgres"
        )
        try:
            connection = TimescaleDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_timescaledb_config_type(self):
        """Test that connection requires TimescaleDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            TimescaleDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected TimescaleDBConnectorConfig" in error_msg)
