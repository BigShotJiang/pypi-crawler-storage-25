#!/usr/bin/env python3
"""
Unit tests for NeptuneConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.neptune_connector import NeptuneConnectorConfig, NeptuneStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_neptune

class TestNeptuneConnectorConfig:
    """Unit tests for NeptuneConnectorConfig."""

    def test_config_initialization_gremlin(self):
        """Test config initialization with Gremlin query language."""
        config = NeptuneConnectorConfig(
            endpoint="neptune-instance.cluster-xyz.us-east-1.neptune.amazonaws.com",
            port=8182,
            query_language="gremlin",
            region="us-east-1"
        )
        assert config.connector_type == "neptune"
        assert config.endpoint == "neptune-instance.cluster-xyz.us-east-1.neptune.amazonaws.com"
        assert config.port == 8182
        assert config.query_language == "gremlin"
        assert config.region == "us-east-1"

    def test_config_initialization_sparql(self):
        """Test config initialization with SPARQL query language."""
        config = NeptuneConnectorConfig(
            endpoint="neptune-instance.cluster-xyz.us-east-1.neptune.amazonaws.com",
            query_language="sparql"
        )
        assert config.query_language == "sparql"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = NeptuneConnectorConfig(
            endpoint="neptune-instance.cluster-xyz.us-east-1.neptune.amazonaws.com",
            port=8182,
            query_language="gremlin",
            region="us-east-1"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "neptune"
        assert config_dict["endpoint"] == "neptune-instance.cluster-xyz.us-east-1.neptune.amazonaws.com"
        assert config_dict["port"] == 8182
        assert config_dict["query_language"] == "gremlin"

    def test_config_default_values(self):
        """Test config uses default values when not specified."""
        config = NeptuneConnectorConfig(
            endpoint="neptune-instance.cluster-xyz.us-east-1.neptune.amazonaws.com"
        )
        assert config.port == 8182
        assert config.query_language == "gremlin"
        assert config.region == "us-east-1"
        assert config.use_ssl is True
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_neptune

class TestNeptuneStorageConnection:
    """Unit tests for NeptuneStorageConnection."""

    def test_connection_requires_neptune_package(self):
        """Test that connection raises error if Neptune package not available."""
        config = NeptuneConnectorConfig(
            endpoint="neptune-instance.cluster-xyz.us-east-1.neptune.amazonaws.com"
        )
        try:
            connection = NeptuneStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_neptune_config_type(self):
        """Test that connection requires NeptuneConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            NeptuneStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected NeptuneConnectorConfig" in error_msg)
