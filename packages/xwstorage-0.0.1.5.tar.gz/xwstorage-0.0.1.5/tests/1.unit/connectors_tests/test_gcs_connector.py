#!/usr/bin/env python3
"""
Unit tests for GCSConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.gcs_connector import GCSConnectorConfig, GCSStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_gcs

class TestGCSConnectorConfig:
    """Unit tests for GCSConnectorConfig."""

    def test_config_initialization_with_bucket(self):
        """Test config initialization with bucket name."""
        config = GCSConnectorConfig(
            bucket="my-bucket",
            project="my-project"
        )
        assert config.connector_type == "gcs"
        assert config.bucket == "my-bucket"
        assert config.project == "my-project"

    def test_config_initialization_with_credentials_file(self):
        """Test config initialization with credentials file path."""
        config = GCSConnectorConfig(
            bucket="my-bucket",
            project="my-project",
            credentials_file="/path/to/credentials.json"
        )
        assert config.bucket == "my-bucket"
        assert config.credentials_file == "/path/to/credentials.json"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = GCSConnectorConfig(
            bucket="my-bucket",
            project="my-project"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "gcs"
        assert config_dict["bucket"] == "my-bucket"
        assert config_dict["project"] == "my-project"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_gcs

class TestGCSStorageConnection:
    """Unit tests for GCSStorageConnection."""

    def test_connection_requires_google_cloud_storage_package(self):
        """Test that connection raises error if Google Cloud Storage package not available."""
        config = GCSConnectorConfig(
            bucket="my-bucket",
            project="my-project"
        )
        try:
            connection = GCSStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_gcs_config_type(self):
        """Test that connection requires GCSConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            GCSStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected GCSConnectorConfig" in error_msg)
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_gcs
@pytest.mark.skip(reason="Requires Google Cloud credentials and GCS bucket")

class TestGCSStorageConnectionOperations:
    """Unit tests for GCS storage operations (requires Google Cloud credentials)."""
    @pytest.fixture

    def gcs_config(self):
        """GCS config for testing."""
        return GCSConnectorConfig(
            bucket="test-bucket",
            project="test-project"
        )
    @pytest.fixture

    async def gcs_connection(self, gcs_config):
        """GCS connection for testing."""
        connection = GCSStorageConnection(gcs_config, "json")
        yield connection
    @pytest.mark.asyncio

    async def test_gcs_save_and_load(self, gcs_connection, sample_data, test_path):
        """Test GCS save and load operations."""
        await gcs_connection.save(sample_data, test_path)
        loaded = await gcs_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_gcs_exists(self, gcs_connection, sample_data, test_path):
        """Test GCS exists check."""
        assert await gcs_connection.exists(test_path) is False
        await gcs_connection.save(sample_data, test_path)
        assert await gcs_connection.exists(test_path) is True
