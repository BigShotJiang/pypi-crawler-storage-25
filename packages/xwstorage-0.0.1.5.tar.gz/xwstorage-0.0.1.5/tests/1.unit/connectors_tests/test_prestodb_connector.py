#!/usr/bin/env python3
"""
Unit tests for PrestoDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.prestodb_connector import PrestoDBConnectorConfig, PrestoDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_prestodb

class TestPrestoDBConnectorConfig:
    """Unit tests for PrestoDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = PrestoDBConnectorConfig(
            address="localhost:8080",
            catalog="system",
            schema="default",
            user="presto"
        )
        assert config.connector_type == "prestodb"
        assert config.host == "localhost"
        assert config.port == 8080
        assert config.catalog == "system"
        assert config.schema == "default"
        assert config.user == "presto"

    def test_config_initialization_with_url(self):
        """Test config initialization with URL."""
        config = PrestoDBConnectorConfig(
            address="http://localhost:8080",
            catalog="system"
        )
        assert config.host == "localhost"
        assert config.port == 8080

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = PrestoDBConnectorConfig(
            address="localhost:8080",
            catalog="system",
            schema="default",
            user="presto"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "prestodb"
        assert config_dict["catalog"] == "system"
        assert config_dict["schema"] == "default"
        assert config_dict["user"] == "presto"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_prestodb

class TestPrestoDBStorageConnection:
    """Unit tests for PrestoDBStorageConnection."""

    def test_connection_requires_prestodb_package(self):
        """Test that connection raises error if PrestoDB package not available."""
        config = PrestoDBConnectorConfig(
            address="localhost:8080",
            catalog="system"
        )
        try:
            connection = PrestoDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "PrestoDB connector package" in error_msg)

    def test_connection_requires_prestodb_config_type(self):
        """Test that connection requires PrestoDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            PrestoDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "PrestoDB connector package" in error_msg or
                "Expected PrestoDBConnectorConfig" in error_msg)
