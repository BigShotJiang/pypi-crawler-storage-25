#!/usr/bin/env python3
"""
Unit tests for TDengineConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.tdengine_connector import TDengineConnectorConfig, TDengineStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_tdengine

class TestTDengineConnectorConfig:
    """Unit tests for TDengineConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port (native protocol)."""
        config = TDengineConnectorConfig(
            address="localhost:6030",
            database="test",
            user="root",
            password="taosdata"
        )
        assert config.connector_type == "tdengine"
        assert config.host == "localhost"
        assert config.port == 6030
        assert config.database == "test"
        assert config.user == "root"
        assert config.use_http is False

    def test_config_initialization_with_http_url(self):
        """Test config initialization with HTTP URL."""
        config = TDengineConnectorConfig(
            address="http://localhost:6041",
            database="test"
        )
        assert config.url == "http://localhost:6041"
        assert config.use_http is True

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = TDengineConnectorConfig(
            address="localhost:6030",
            database="test",
            user="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "tdengine"
        assert config_dict["database"] == "test"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 6030 when not specified."""
        config = TDengineConnectorConfig(
            address="localhost",
            database="test"
        )
        assert config.port == 6030
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_tdengine

class TestTDengineStorageConnection:
    """Unit tests for TDengineStorageConnection."""

    def test_connection_requires_tdengine_package(self):
        """Test that connection raises error if TDengine package not available."""
        config = TDengineConnectorConfig(
            address="localhost:6030",
            database="test"
        )
        try:
            connection = TDengineStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_tdengine_config_type(self):
        """Test that connection requires TDengineConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            TDengineStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected TDengineConnectorConfig" in error_msg)
