#!/usr/bin/env python3
"""
Unit tests for InfluxDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.influxdb_connector import InfluxDBConnectorConfig, InfluxDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_influxdb

class TestInfluxDBConnectorConfig:
    """Unit tests for InfluxDBConnectorConfig."""

    def test_config_initialization_with_bucket(self):
        """Test config initialization with bucket name."""
        config = InfluxDBConnectorConfig(
            address="my_bucket",
            url="http://localhost:8086",
            token="mytoken",
            org="my-org"
        )
        assert config.connector_type == "influxdb"
        assert config.bucket == "my_bucket"
        assert config.url == "http://localhost:8086"
        assert config.token == "mytoken"
        assert config.org == "my-org"

    def test_config_initialization_with_url_in_address(self):
        """Test config initialization with URL in address field."""
        config = InfluxDBConnectorConfig(
            address="http://localhost:8086",
            bucket="my_bucket",
            token="mytoken"
        )
        assert config.url == "http://localhost:8086"
        assert config.bucket == "my_bucket"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = InfluxDBConnectorConfig(
            address="my_bucket",
            url="http://localhost:8086",
            token="mytoken",
            org="my-org"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "influxdb"
        assert config_dict["bucket"] == "my_bucket"
        assert config_dict["url"] == "http://localhost:8086"
        assert "token" not in config_dict  # Token should not be in dict

    def test_config_default_values(self):
        """Test config uses default values when not specified."""
        config = InfluxDBConnectorConfig(
            address="my_bucket"
        )
        assert config.url == "http://localhost:8086"
        assert config.org == "my-org"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_influxdb

class TestInfluxDBStorageConnection:
    """Unit tests for InfluxDBStorageConnection."""

    def test_connection_requires_influxdb_package(self):
        """Test that connection raises error if InfluxDB package not available."""
        config = InfluxDBConnectorConfig(
            address="my_bucket",
            url="http://localhost:8086"
        )
        try:
            connection = InfluxDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_influxdb_config_type(self):
        """Test that connection requires InfluxDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            InfluxDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected InfluxDBConnectorConfig" in error_msg)
