#!/usr/bin/env python3
"""
Unit tests for RedpandaConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.redpanda_connector import RedpandaConnectorConfig, RedpandaStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redpanda

class TestRedpandaConnectorConfig:
    """Unit tests for RedpandaConnectorConfig."""

    def test_config_initialization_single_server(self):
        """Test config initialization with single bootstrap server."""
        config = RedpandaConnectorConfig(
            address="localhost:9092"
        )
        assert config.connector_type == "redpanda"
        assert config.bootstrap_servers == ["localhost:9092"]

    def test_config_initialization_multiple_servers(self):
        """Test config initialization with multiple bootstrap servers."""
        config = RedpandaConnectorConfig(
            address="localhost:9092,redpanda2:9092,redpanda3:9092"
        )
        assert len(config.bootstrap_servers) == 3
        assert "localhost:9092" in config.bootstrap_servers

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RedpandaConnectorConfig(
            address="localhost:9092"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "redpanda"
        assert config_dict["bootstrap_servers"] == ["localhost:9092"]
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_redpanda

class TestRedpandaStorageConnection:
    """Unit tests for RedpandaStorageConnection."""

    def test_connection_requires_kafka_package(self):
        """Test that connection raises error if Kafka package not available."""
        config = RedpandaConnectorConfig(
            address="localhost:9092"
        )
        try:
            connection = RedpandaStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Kafka connector package" in error_msg)

    def test_connection_requires_redpanda_config_type(self):
        """Test that connection requires RedpandaConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RedpandaStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Kafka connector package" in error_msg or
                "Expected RedpandaConnectorConfig" in error_msg)
