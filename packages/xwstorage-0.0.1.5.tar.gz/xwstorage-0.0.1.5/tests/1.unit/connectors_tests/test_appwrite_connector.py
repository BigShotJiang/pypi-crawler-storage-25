#!/usr/bin/env python3
"""
Unit tests for AppwriteConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.appwrite_connector import AppwriteConnectorConfig, AppwriteStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_appwrite

class TestAppwriteConnectorConfig:
    """Unit tests for AppwriteConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with server URL."""
        config = AppwriteConnectorConfig(
            address="http://localhost/v1",
            project_id="my_project",
            api_key="my_api_key"
        )
        assert config.connector_type == "appwrite"
        assert config.url == "http://localhost/v1"
        assert config.project_id == "my_project"
        assert config.api_key == "my_api_key"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = AppwriteConnectorConfig(
            address="localhost/v1",
            project_id="my_project",
            api_key="my_api_key"
        )
        assert config.url == "http://localhost/v1"

    def test_config_to_dict(self):
        """Test config to_dict conversion (API key masked)."""
        config = AppwriteConnectorConfig(
            address="http://localhost/v1",
            project_id="my_project",
            api_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "appwrite"
        assert config_dict["url"] == "http://localhost/v1"
        assert config_dict["project_id"] == "my_project"
        assert config_dict["api_key"] == "***"  # API key should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_appwrite

class TestAppwriteStorageConnection:
    """Unit tests for AppwriteStorageConnection."""

    def test_connection_requires_appwrite_package(self):
        """Test that connection raises error if Appwrite package not available."""
        config = AppwriteConnectorConfig(
            address="http://localhost/v1",
            project_id="my_project",
            api_key="my_api_key"
        )
        try:
            connection = AppwriteStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_appwrite_config_type(self):
        """Test that connection requires AppwriteConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            AppwriteStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected AppwriteConnectorConfig" in error_msg)
