#!/usr/bin/env python3
"""
Unit tests for ZincSearchConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.zincsearch_connector import ZincSearchConnectorConfig, ZincSearchStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_zincsearch

class TestZincSearchConnectorConfig:
    """Unit tests for ZincSearchConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = ZincSearchConnectorConfig(
            address="http://localhost:4080",
            username="admin",
            password="Complexpass#123"
        )
        assert config.connector_type == "zincsearch"
        assert config.url == "http://localhost:4080"
        assert config.username == "admin"
        assert config.password == "Complexpass#123"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = ZincSearchConnectorConfig(
            address="localhost:4080"
        )
        assert config.url == "http://localhost:4080"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password masked)."""
        config = ZincSearchConnectorConfig(
            address="http://localhost:4080",
            username="admin",
            password="my_secret_password"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "zincsearch"
        assert config_dict["url"] == "http://localhost:4080"
        assert config_dict["password"] == "***"  # Password should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_zincsearch

class TestZincSearchStorageConnection:
    """Unit tests for ZincSearchStorageConnection."""

    def test_connection_requires_zincsearch_package(self):
        """Test that connection raises error if ZincSearch package not available."""
        config = ZincSearchConnectorConfig(
            address="http://localhost:4080"
        )
        try:
            connection = ZincSearchStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "ZincSearch connector package" in error_msg)

    def test_connection_requires_zincsearch_config_type(self):
        """Test that connection requires ZincSearchConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ZincSearchStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "ZincSearch connector package" in error_msg or
                "Expected ZincSearchConnectorConfig" in error_msg)
