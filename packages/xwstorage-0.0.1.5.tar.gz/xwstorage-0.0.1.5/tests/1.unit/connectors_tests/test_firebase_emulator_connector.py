#!/usr/bin/env python3
"""
Unit tests for FirebaseEmulatorConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.firebase_emulator_connector import FirebaseEmulatorConnectorConfig, FirebaseEmulatorStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_firebase_emulator

class TestFirebaseEmulatorConnectorConfig:
    """Unit tests for FirebaseEmulatorConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with endpoint URL."""
        config = FirebaseEmulatorConnectorConfig(
            address="http://localhost:8080",
            project_id="demo-project"
        )
        assert config.connector_type == "firebase_emulator"
        assert config.url == "http://localhost:8080"
        assert config.project_id == "demo-project"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = FirebaseEmulatorConnectorConfig(
            address="localhost:8080"
        )
        assert config.url == "http://localhost:8080"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = FirebaseEmulatorConnectorConfig(
            address="http://localhost:8080",
            project_id="my-project"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "firebase_emulator"
        assert config_dict["url"] == "http://localhost:8080"
        assert config_dict["project_id"] == "my-project"

    def test_config_default_values(self):
        """Test config uses default values when not specified."""
        config = FirebaseEmulatorConnectorConfig()
        assert config.url == "http://localhost:8080"
        assert config.project_id == "demo-project"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_firebase_emulator

class TestFirebaseEmulatorStorageConnection:
    """Unit tests for FirebaseEmulatorStorageConnection."""

    def test_connection_requires_firebase_package(self):
        """Test that connection raises error if Firebase package not available."""
        config = FirebaseEmulatorConnectorConfig(
            address="http://localhost:8080"
        )
        try:
            connection = FirebaseEmulatorStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_firebase_emulator_config_type(self):
        """Test that connection requires FirebaseEmulatorConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            FirebaseEmulatorStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected FirebaseEmulatorConnectorConfig" in error_msg)
