#!/usr/bin/env python3
"""
Unit tests for TypesenseConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.typesense_connector import TypesenseConnectorConfig, TypesenseStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_typesense

class TestTypesenseConnectorConfig:
    """Unit tests for TypesenseConnectorConfig."""

    def test_config_initialization_with_url_and_api_key(self):
        """Test config initialization with URL and API key."""
        config = TypesenseConnectorConfig(
            address="http://localhost:8108",
            api_key="my_api_key"
        )
        assert config.connector_type == "typesense"
        assert config.url == "http://localhost:8108"
        assert config.api_key == "my_api_key"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = TypesenseConnectorConfig(
            address="localhost:8108",
            api_key="my_api_key"
        )
        assert config.url == "http://localhost:8108"

    def test_config_to_dict(self):
        """Test config to_dict conversion (API key masked)."""
        config = TypesenseConnectorConfig(
            address="http://localhost:8108",
            api_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "typesense"
        assert config_dict["url"] == "http://localhost:8108"
        assert config_dict["api_key"] == "***"  # API key should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_typesense

class TestTypesenseStorageConnection:
    """Unit tests for TypesenseStorageConnection."""

    def test_connection_requires_typesense_package(self):
        """Test that connection raises error if Typesense package not available."""
        config = TypesenseConnectorConfig(
            address="http://localhost:8108",
            api_key="my_api_key"
        )
        try:
            connection = TypesenseStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_typesense_config_type(self):
        """Test that connection requires TypesenseConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            TypesenseStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected TypesenseConnectorConfig" in error_msg)
