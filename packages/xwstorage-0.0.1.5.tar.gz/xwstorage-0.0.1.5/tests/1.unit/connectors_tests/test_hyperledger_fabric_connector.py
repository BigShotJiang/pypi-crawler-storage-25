#!/usr/bin/env python3
"""
Unit tests for HyperledgerFabricConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.hyperledger_fabric_connector import HyperledgerFabricConnectorConfig, HyperledgerFabricStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hyperledger_fabric

class TestHyperledgerFabricConnectorConfig:
    """Unit tests for HyperledgerFabricConnectorConfig."""

    def test_config_initialization_with_network_config_path(self):
        """Test config initialization with network config path."""
        config = HyperledgerFabricConnectorConfig(
            address="/path/to/network.yaml",
            user_name="User1",
            org_name="org1"
        )
        assert config.connector_type == "hyperledger_fabric"
        assert config.network_config_path == "/path/to/network.yaml"
        assert config.user_name == "User1"
        assert config.org_name == "org1"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = HyperledgerFabricConnectorConfig(
            address="/path/to/network.yaml",
            user_name="User1",
            org_name="org1"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "hyperledger_fabric"
        assert config_dict["network_config_path"] == "/path/to/network.yaml"
        assert config_dict["user_name"] == "User1"
        assert config_dict["org_name"] == "org1"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hyperledger_fabric

class TestHyperledgerFabricStorageConnection:
    """Unit tests for HyperledgerFabricStorageConnection."""

    def test_connection_requires_hyperledger_package(self):
        """Test that connection raises error if Hyperledger package not available."""
        config = HyperledgerFabricConnectorConfig(
            address="/path/to/network.yaml",
            user_name="User1",
            org_name="org1"
        )
        try:
            connection = HyperledgerFabricStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Hyperledger Fabric connector package" in error_msg)

    def test_connection_requires_fabric_config_type(self):
        """Test that connection requires HyperledgerFabricConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            HyperledgerFabricStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Hyperledger Fabric connector package" in error_msg or
                "Expected HyperledgerFabricConnectorConfig" in error_msg)
