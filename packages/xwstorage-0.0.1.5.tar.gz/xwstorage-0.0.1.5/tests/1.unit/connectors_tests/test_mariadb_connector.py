#!/usr/bin/env python3
"""
Unit tests for MariaDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.mariadb_connector import MariaDBConnectorConfig, MariaDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mariadb

class TestMariaDBConnectorConfig:
    """Unit tests for MariaDBConnectorConfig."""

    def test_config_initialization_with_table_name(self):
        """Test config initialization with just table name."""
        config = MariaDBConnectorConfig(
            address="test_table",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="password"
        )
        assert config.connector_type == "mariadb"
        assert config.table_name == "test_table"
        assert config.host == "localhost"
        assert config.port == 3306
        assert config.database == "testdb"
        assert config.username == "root"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string format."""
        config = MariaDBConnectorConfig(
            address="localhost:3306/testdb",
            username="root",
            password="password",
            table_name="custom_table"
        )
        assert config.host == "localhost"
        assert config.port == 3306
        assert config.database == "testdb"
        assert config.table_name == "custom_table"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = MariaDBConnectorConfig(
            address="test_table",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "mariadb"
        assert config_dict["table_name"] == "test_table"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 3306
        assert config_dict["database"] == "testdb"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 3306 when not specified."""
        config = MariaDBConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb"
        )
        assert config.port == 3306
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mariadb

class TestMariaDBStorageConnection:
    """Unit tests for MariaDBStorageConnection."""

    def test_connection_requires_mysql_connector_config(self):
        """Test that connection requires MariaDBConnectorConfig."""
        config = MariaDBConnectorConfig(
            address="test_table",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="password"
        )
        try:
            connection = MariaDBStorageConnection(config, "json")
            # If we get here, MySQL package is available and config is correct
            assert connection._config is not None
        except XWLocationError as e:
            # Expected if MySQL package not installed or config incorrect
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Expected MariaDBConnectorConfig" in error_msg or
                    "MySQL connector not available" in error_msg)

    def test_connection_requires_mariadb_config_type(self):
        """Test that connection requires MariaDBConnectorConfig type."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MariaDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected MariaDBConnectorConfig" in error_msg or
                "MySQL connector not available" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = MariaDBConnectorConfig(
            address="test_table",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="password"
        )
        try:
            connection = MariaDBStorageConnection(config, "json")
            assert connection._config is not None
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("MySQL/MariaDB package not installed")

    def test_connection_serializer_format(self):
        """Test connection handles different serializer formats."""
        config = MariaDBConnectorConfig(
            address="test_table",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="password"
        )
        try:
            # Test JSON format
            connection = MariaDBStorageConnection(config, "json")
            assert connection._serializer_format == "json"
        except XWLocationError:
            pytest.skip("MySQL/MariaDB package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mariadb
@pytest.mark.skip(reason="Requires MariaDB/MySQL server running")

class TestMariaDBStorageConnectionOperations:
    """Unit tests for MariaDB storage operations (requires running server)."""
    @pytest.fixture

    def mariadb_config(self):
        """MariaDB config for testing (requires running server)."""
        return MariaDBConnectorConfig(
            address="test_table",
            host="localhost",
            port=3306,
            database="testdb",
            username="root",
            password="password"
        )
    @pytest.mark.asyncio

    async def test_mariadb_save_and_load(self, mariadb_config, sample_data, test_path):
        """Test MariaDB save and load operations."""
        connection = MariaDBStorageConnection(mariadb_config, "json")
        await connection.save(sample_data, test_path)
        loaded = await connection.load(test_path)
        assert loaded == sample_data
