#!/usr/bin/env python3
"""
Unit tests for TrinoConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.trino_connector import TrinoConnectorConfig, TrinoStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_trino

class TestTrinoConnectorConfig:
    """Unit tests for TrinoConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = TrinoConnectorConfig(
            address="localhost:8080",
            catalog="system",
            schema="default",
            user="trino"
        )
        assert config.connector_type == "trino"
        assert config.host == "localhost"
        assert config.port == 8080
        assert config.catalog == "system"
        assert config.schema == "default"
        assert config.user == "trino"

    def test_config_initialization_with_url(self):
        """Test config initialization with URL."""
        config = TrinoConnectorConfig(
            address="http://localhost:8080",
            catalog="system"
        )
        assert config.host == "localhost"
        assert config.port == 8080

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = TrinoConnectorConfig(
            address="localhost:8080",
            catalog="system",
            schema="default",
            user="trino"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "trino"
        assert config_dict["catalog"] == "system"
        assert config_dict["schema"] == "default"
        assert config_dict["user"] == "trino"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_trino

class TestTrinoStorageConnection:
    """Unit tests for TrinoStorageConnection."""

    def test_connection_requires_trino_package(self):
        """Test that connection raises error if Trino package not available."""
        config = TrinoConnectorConfig(
            address="localhost:8080",
            catalog="system"
        )
        try:
            connection = TrinoStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Trino connector package" in error_msg)

    def test_connection_requires_trino_config_type(self):
        """Test that connection requires TrinoConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            TrinoStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Trino connector package" in error_msg or
                "Expected TrinoConnectorConfig" in error_msg)
