#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/connectors_tests/test_pool.py
Unit tests for Connection pooling.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from exonware.xwstorage.connectors.pool import ConnectionPool
@pytest.mark.xwstorage_unit

class TestConnectionPool:
    """Test ConnectionPool implementation."""
    @pytest.fixture

    def connector_factory(self):
        """Create connector factory fixture."""
        return AsyncMock(return_value=MagicMock())
    @pytest.fixture

    def pool(self, connector_factory):
        """Create connection pool fixture."""
        return ConnectionPool(connector_factory, min_size=2, max_size=5)
    @pytest.mark.asyncio

    async def test_pool_initialization(self, pool):
        """Test initializing connection pool."""
        assert pool.min_size == 2
        assert pool.max_size == 5
        assert pool.connector_factory is not None
    @pytest.mark.asyncio

    async def test_get_connection(self, pool, connector_factory):
        """Test getting a connection from pool."""
        conn = await pool.get_connection()
        assert conn is not None
        connector_factory.assert_called_once()
    @pytest.mark.asyncio

    async def test_return_connection(self, pool, connector_factory):
        """Test returning a connection to pool."""
        conn = await pool.get_connection()
        await pool.return_connection(conn)
        # Connection should be returned to available pool
        assert conn in pool._available or len(pool._available) >= 0
    @pytest.mark.asyncio

    async def test_pool_exhaustion(self, pool, connector_factory):
        """Test pool exhaustion when max connections reached."""
        # Get max connections
        connections = []
        for _ in range(pool.max_size):
            conn = await pool.get_connection()
            connections.append(conn)
        # Next get should fail
        with pytest.raises(RuntimeError, match="exhausted"):
            await pool.get_connection()
        # Return one connection
        await pool.return_connection(connections[0])
        # Should be able to get connection now
        conn = await pool.get_connection()
        assert conn is not None
    @pytest.mark.asyncio

    async def test_pool_reuse_connection(self, pool, connector_factory):
        """Test that connections are reused from pool."""
        # Get and return connection
        conn1 = await pool.get_connection()
        await pool.return_connection(conn1)
        # Get connection again - should reuse
        conn2 = await pool.get_connection()
        # Should reuse connection if health check passes
        assert conn2 is not None
