#!/usr/bin/env python3
"""
Unit tests for SolrConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.solr_connector import SolrConnectorConfig, SolrStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_solr

class TestSolrConnectorConfig:
    """Unit tests for SolrConnectorConfig."""

    def test_config_initialization_with_http_url(self):
        """Test config initialization with HTTP URL."""
        config = SolrConnectorConfig(
            address="http://localhost:8983/solr"
        )
        assert config.connector_type == "solr"
        assert config.url == "http://localhost:8983/solr"

    def test_config_initialization_with_https_url(self):
        """Test config initialization with HTTPS URL."""
        config = SolrConnectorConfig(
            address="https://solr.example.com/solr"
        )
        assert config.url == "https://solr.example.com/solr"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = SolrConnectorConfig(
            address="localhost:8983/solr"
        )
        assert config.url == "http://localhost:8983/solr"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = SolrConnectorConfig(
            address="http://localhost:8983/solr"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "solr"
        assert config_dict["url"] == "http://localhost:8983/solr"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_solr

class TestSolrStorageConnection:
    """Unit tests for SolrStorageConnection."""

    def test_connection_requires_solr_package(self):
        """Test that connection raises error if Solr package not available."""
        config = SolrConnectorConfig(
            address="http://localhost:8983/solr"
        )
        try:
            connection = SolrStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Solr connector package" in error_msg)

    def test_connection_requires_solr_config_type(self):
        """Test that connection requires SolrConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            SolrStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Solr connector package" in error_msg or
                "Expected SolrConnectorConfig" in error_msg)
