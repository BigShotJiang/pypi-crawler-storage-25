#!/usr/bin/env python3
"""
Unit tests for MinIOConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.minio_connector import MinIOConnectorConfig, MinIOStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_minio

class TestMinIOConnectorConfig:
    """Unit tests for MinIOConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = MinIOConnectorConfig(
            bucket="my-bucket",
            endpoint_url="http://localhost:9000",
            access_key_id="minioadmin",
            secret_access_key="minioadmin"
        )
        assert config.connector_type == "minio"
        assert config.bucket == "my-bucket"
        assert config.endpoint_url == "http://localhost:9000"
        assert config.access_key_id == "minioadmin"
        assert config.secret_access_key == "minioadmin"
        assert config.region == "us-east-1"  # Default region

    def test_config_initialization_with_custom_region(self):
        """Test config initialization with custom region."""
        config = MinIOConnectorConfig(
            bucket="my-bucket",
            endpoint_url="http://localhost:9000",
            access_key_id="minioadmin",
            secret_access_key="minioadmin",
            region="us-west-2"
        )
        assert config.region == "us-west-2"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = MinIOConnectorConfig(
            bucket="my-bucket",
            endpoint_url="http://localhost:9000",
            access_key_id="minioadmin",
            secret_access_key="minioadmin"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "minio"
        assert config_dict["bucket"] == "my-bucket"
        assert config_dict["endpoint_url"] == "http://localhost:9000"
        assert config_dict["access_key_id"] == "minioadmin"
        assert "secret_access_key" not in config_dict  # Secret should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_minio

class TestMinIOStorageConnection:
    """Unit tests for MinIOStorageConnection."""

    def test_connection_requires_s3_connector(self):
        """Test that connection raises error if S3 connector not available."""
        config = MinIOConnectorConfig(
            bucket="my-bucket",
            endpoint_url="http://localhost:9000",
            access_key_id="minioadmin",
            secret_access_key="minioadmin"
        )
        try:
            connection = MinIOStorageConnection(config, "json")
            # If we get here, S3/boto3 package is available
            assert connection._config is not None
        except XWLocationError as e:
            # Expected if boto3 package not installed
            error_msg = str(e)
            assert ("not available" in error_msg.lower() or 
                    "boto3" in error_msg.lower())

    def test_connection_requires_minio_config_type(self):
        """Test that connection requires MinIOConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MinIOStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected MinIOConnectorConfig" in error_msg or
                "S3 connector not available" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = MinIOConnectorConfig(
            bucket="my-bucket",
            endpoint_url="http://localhost:9000",
            access_key_id="minioadmin",
            secret_access_key="minioadmin"
        )
        try:
            connection = MinIOStorageConnection(config, "json")
            assert connection._config is not None
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("S3/boto3 package not installed")

    def test_connection_serializer_format(self):
        """Test connection handles different serializer formats."""
        config = MinIOConnectorConfig(
            bucket="my-bucket",
            endpoint_url="http://localhost:9000",
            access_key_id="minioadmin",
            secret_access_key="minioadmin"
        )
        try:
            # Test JSON format
            connection = MinIOStorageConnection(config, "json")
            assert connection._serializer_format == "json"
        except XWLocationError:
            pytest.skip("S3/boto3 package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_minio
@pytest.mark.skip(reason="Requires MinIO server running")

class TestMinIOStorageConnectionOperations:
    """Unit tests for MinIO storage operations (requires running server)."""
    @pytest.fixture

    def minio_config(self):
        """MinIO config for testing (requires running server)."""
        return MinIOConnectorConfig(
            bucket="my-bucket",
            endpoint_url="http://localhost:9000",
            access_key_id="minioadmin",
            secret_access_key="minioadmin"
        )
    @pytest.mark.asyncio

    async def test_minio_save_and_load(self, minio_config, sample_data, test_path):
        """Test MinIO save and load operations."""
        connection = MinIOStorageConnection(minio_config, "json")
        await connection.save(sample_data, test_path)
        loaded = await connection.load(test_path)
        assert loaded == sample_data
