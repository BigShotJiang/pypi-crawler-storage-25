#!/usr/bin/env python3
"""
Unit tests for BBoltConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.bbolt_connector import BBoltConnectorConfig, BBoltStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_bbolt

class TestBBoltConnectorConfig:
    """Unit tests for BBoltConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with database file path."""
        config = BBoltConnectorConfig(
            address="/tmp/bbolt.db"
        )
        assert config.connector_type == "bbolt"
        assert str(config.db_path) == "/tmp/bbolt.db"
        assert config.mode == 0o600  # Default file permissions

    def test_config_initialization_with_custom_mode(self):
        """Test config initialization with custom file mode."""
        config = BBoltConnectorConfig(
            address="/tmp/bbolt.db",
            mode=0o644
        )
        assert config.mode == 0o644

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = BBoltConnectorConfig(
            address="/tmp/bbolt.db",
            mode=0o644
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "bbolt"
        assert config_dict["db_path"] == "/tmp/bbolt.db"
        assert config_dict["mode"] == 0o644
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_bbolt

class TestBBoltStorageConnection:
    """Unit tests for BBoltStorageConnection."""

    def test_connection_requires_bbolt_package(self):
        """Test that connection raises error if BBolt package not available."""
        config = BBoltConnectorConfig(
            address="/tmp/bbolt.db"
        )
        try:
            connection = BBoltStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_bbolt_config_type(self):
        """Test that connection requires BBoltConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            BBoltStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected BBoltConnectorConfig" in error_msg)
