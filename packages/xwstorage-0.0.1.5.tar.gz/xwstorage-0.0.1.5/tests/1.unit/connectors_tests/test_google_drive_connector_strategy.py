#!/usr/bin/env python3
"""
Unit tests for GoogleDriveConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.google_drive_connector_strategy import GoogleDriveConnector
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_google_drive

class TestGoogleDriveConnector:
    """Unit tests for GoogleDriveConnector."""

    def test_connector_initialization_with_folder_id(self):
        """Test connector initialization with folder ID."""
        connector = GoogleDriveConnector(
            folder_id="1q5zrX1OT2S1sKu8Zw0zSoYFfLyiAQwCZ"
        )
        assert connector.folder_id == "1q5zrX1OT2S1sKu8Zw0zSoYFfLyiAQwCZ"

    def test_connector_initialization_with_path_dict(self):
        """Test connector initialization with path dictionary."""
        connector = GoogleDriveConnector(
            path={"folder_id": "1q5zrX1OT2S1sKu8Zw0zSoYFfLyiAQwCZ"}
        )
        assert connector.folder_id == "1q5zrX1OT2S1sKu8Zw0zSoYFfLyiAQwCZ"

    def test_connector_type(self):
        """Test connector type property."""
        connector = GoogleDriveConnector(
            folder_id="test_id"
        )
        assert connector.connector_type == "google_drive"
