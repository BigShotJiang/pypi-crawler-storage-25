#!/usr/bin/env python3
"""
Unit tests for CouchDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.couchdb_connector import CouchDBConnectorConfig, CouchDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_couchdb

class TestCouchDBConnectorConfig:
    """Unit tests for CouchDBConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = CouchDBConnectorConfig(
            address="mydb",
            host="localhost",
            port=5984,
            username="admin",
            password="password"
        )
        assert config.connector_type == "couchdb"
        assert config.database == "mydb"
        assert config.collection_name == "mydb"
        assert config.host == "localhost"
        assert config.port == 5984
        assert config.username == "admin"

    def test_config_initialization_with_ssl(self):
        """Test config initialization with SSL enabled."""
        config = CouchDBConnectorConfig(
            address="mydb",
            use_ssl=True
        )
        assert config.use_ssl is True

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = CouchDBConnectorConfig(
            address="mydb",
            host="localhost",
            port=5984,
            username="admin",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "couchdb"
        assert config_dict["database"] == "mydb"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 5984 when not specified."""
        config = CouchDBConnectorConfig(
            address="mydb"
        )
        assert config.port == 5984
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_couchdb

class TestCouchDBStorageConnection:
    """Unit tests for CouchDBStorageConnection."""

    def test_connection_requires_couchdb_package(self):
        """Test that connection raises error if CouchDB package not available."""
        config = CouchDBConnectorConfig(
            address="mydb",
            host="localhost",
            port=5984
        )
        try:
            connection = CouchDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_couchdb_config_type(self):
        """Test that connection requires CouchDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            CouchDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected CouchDBConnectorConfig" in error_msg)
