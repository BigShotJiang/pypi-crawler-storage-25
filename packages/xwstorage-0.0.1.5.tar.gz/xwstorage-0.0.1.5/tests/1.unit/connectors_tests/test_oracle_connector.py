#!/usr/bin/env python3
"""
Unit tests for OracleConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.oracle_connector import OracleConnectorConfig, OracleStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_oracle

class TestOracleConnectorConfig:
    """Unit tests for OracleConnectorConfig."""

    def test_config_initialization_with_table_name(self):
        """Test config initialization with just table name."""
        config = OracleConnectorConfig(
            address="test_table",
            host="localhost",
            port=1521,
            database="xe",
            username="system",
            password="password"
        )
        assert config.connector_type == "oracle"
        assert config.table_name == "test_table"
        assert config.host == "localhost"
        assert config.port == 1521
        assert config.database == "xe"
        assert config.service_name == "xe"

    def test_config_initialization_with_dsn(self):
        """Test config initialization with DSN string."""
        config = OracleConnectorConfig(
            address="localhost:1521/xe",
            username="system",
            password="password",
            table_name="custom_table"
        )
        assert config.host == "localhost"
        assert config.port == 1521
        assert config.database == "xe"
        assert config.dsn == "localhost:1521/xe"
        assert config.table_name == "custom_table"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = OracleConnectorConfig(
            address="test_table",
            host="localhost",
            database="xe",
            username="system",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "oracle"
        assert config_dict["table_name"] == "test_table"
        assert "dsn" in config_dict
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_oracle

class TestOracleStorageConnection:
    """Unit tests for OracleStorageConnection."""

    def test_connection_requires_oracle_package(self):
        """Test that connection raises error if Oracle package not available."""
        config = OracleConnectorConfig(
            address="test_table",
            host="localhost",
            database="xe",
            username="system",
            password="password"
        )
        try:
            connection = OracleStorageConnection(config, "json")
            # If we get here, oracledb package is available
            # Connection should be valid
            assert connection._config == config
        except XWLocationError as e:
            # Expected if oracledb package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_oracle_config_type(self):
        """Test that connection requires OracleConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        # If Oracle package is not installed, it will raise error about package first
        # If Oracle package is installed, it will raise error about config type
        with pytest.raises(XWLocationError) as exc_info:
            OracleStorageConnection(local_config, "json")
        # Should raise error about either package or config type
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected OracleConnectorConfig" in error_msg)
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_oracle
@pytest.mark.skip(reason="Requires Oracle database running")

class TestOracleStorageConnectionOperations:
    """Unit tests for Oracle storage operations (requires running Oracle)."""
    @pytest.fixture

    def oracle_config(self):
        """Oracle config for testing (requires running Oracle)."""
        return OracleConnectorConfig(
            address="test_storage",
            host="localhost",
            port=1521,
            database="xe",
            username="system",
            password="password"
        )
    @pytest.fixture

    async def oracle_connection(self, oracle_config):
        """Oracle connection for testing."""
        connection = OracleStorageConnection(oracle_config, "json")
        yield connection
    @pytest.mark.asyncio

    async def test_oracle_save_and_load(self, oracle_connection, sample_data, test_path):
        """Test Oracle save and load operations."""
        await oracle_connection.save(sample_data, test_path)
        loaded = await oracle_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_oracle_append_not_supported(self, oracle_connection, sample_data, test_path):
        """Test that append mode is not supported."""
        with pytest.raises(XWStorageError, match="not supported"):
            await oracle_connection.save(sample_data, test_path, append=True)
    @pytest.mark.asyncio

    async def test_oracle_exists(self, oracle_connection, sample_data, test_path):
        """Test Oracle exists check."""
        assert await oracle_connection.exists(test_path) is False
        await oracle_connection.save(sample_data, test_path)
        assert await oracle_connection.exists(test_path) is True
    @pytest.mark.asyncio

    async def test_oracle_delete(self, oracle_connection, sample_data, test_path):
        """Test Oracle delete operation."""
        await oracle_connection.save(sample_data, test_path)
        await oracle_connection.delete(test_path)
        assert await oracle_connection.exists(test_path) is False
