#!/usr/bin/env python3
"""
Unit tests for AzuriteConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.azurite_connector import AzuriteConnectorConfig, AzuriteStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_azurite

class TestAzuriteConnectorConfig:
    """Unit tests for AzuriteConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with endpoint URL."""
        config = AzuriteConnectorConfig(
            address="http://127.0.0.1:10000",
            account_name="devstoreaccount1",
            account_key="test_key"
        )
        assert config.connector_type == "azurite"
        assert config.endpoint_url == "http://127.0.0.1:10000"
        assert config.account_name == "devstoreaccount1"
        assert config.account_key == "test_key"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = AzuriteConnectorConfig(
            address="127.0.0.1:10000"
        )
        assert config.endpoint_url == "http://127.0.0.1:10000"

    def test_config_default_values(self):
        """Test config uses default values when not specified."""
        config = AzuriteConnectorConfig()
        assert config.endpoint_url == "http://127.0.0.1:10000"
        assert config.account_name == "devstoreaccount1"

    def test_config_to_dict(self):
        """Test config to_dict conversion (key not exposed)."""
        config = AzuriteConnectorConfig(
            address="http://127.0.0.1:10000"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "azurite"
        assert config_dict["endpoint_url"] == "http://127.0.0.1:10000"
        assert config_dict["account_name"] == "devstoreaccount1"
        assert "account_key" not in config_dict  # Key should not be exposed
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_azurite

class TestAzuriteStorageConnection:
    """Unit tests for AzuriteStorageConnection."""

    def test_connection_requires_azure_package(self):
        """Test that connection raises error if Azure package not available."""
        config = AzuriteConnectorConfig(
            address="http://127.0.0.1:10000"
        )
        try:
            connection = AzuriteStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_azurite_config_type(self):
        """Test that connection requires AzuriteConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            AzuriteStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected AzuriteConnectorConfig" in error_msg)
