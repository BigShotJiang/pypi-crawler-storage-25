#!/usr/bin/env python3
"""
Unit tests for LocalConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
import tempfile
import shutil
from pathlib import Path
from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig, LocalStorageConnection
from exonware.xwstorage.errors import XWLocationError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalConnectorConfig:
    """Unit tests for LocalConnectorConfig."""

    def test_config_initialization_with_relative_path(self, unit_temp_dir):
        """Test config initialization with relative path."""
        config = LocalConnectorConfig(
            address="test.json",
            base_path=unit_temp_dir,
            security=True
        )
        assert config.connector_type == "local"
        assert config.address == Path("test.json")
        assert config.base_path == unit_temp_dir.resolve()
        assert config.security is True

    def test_config_initialization_with_absolute_path(self, unit_temp_dir):
        """Test config initialization with absolute path (converted to relative)."""
        abs_path = unit_temp_dir / "absolute_test.json"
        config = LocalConnectorConfig(
            address=str(abs_path),
            security=False
        )
        # Should be converted to relative
        assert config.address.name == "absolute_test.json"

    def test_config_to_dict(self, unit_temp_dir):
        """Test config to_dict conversion."""
        config = LocalConnectorConfig(
            address="test.json",
            base_path=unit_temp_dir,
            security=True
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "local"
        assert "address" in config_dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalStorageConnection:
    """Unit tests for LocalStorageConnection."""
    @pytest.mark.asyncio

    async def test_connection_initialization(self, local_config_unit):
        """Test connection initialization."""
        connection = LocalStorageConnection(local_config_unit, "json")
        assert connection.connection_id is not None
        assert connection._codec_id == "json"
    @pytest.mark.asyncio

    async def test_get_file_path_with_directory_address(self, local_config_unit):
        """Test get_file_path with directory address."""
        # Create config with directory address
        temp_dir = local_config_unit.address.parent
        dir_config = LocalConnectorConfig(
            address=str(temp_dir),
            security=False
        )
        connection = LocalStorageConnection(dir_config, "json")
        file_path = connection.get_file_path("test_data")
        assert file_path.exists() or file_path.parent.exists()
        assert file_path.suffix == ".json"
    @pytest.mark.asyncio

    async def test_get_file_path_with_file_address(self, local_config_unit):
        """Test get_file_path with file address."""
        connection = LocalStorageConnection(local_config_unit, "json")
        # With file address, path parameter is ignored (single-file mode)
        file_path = connection.get_file_path("ignored_path")
        assert file_path.name == local_config_unit.address.name
    @pytest.mark.asyncio

    async def test_path_security_validation(self, unit_temp_dir):
        """Test that path traversal is prevented."""
        config = LocalConnectorConfig(
            address=str(unit_temp_dir / "secure.json"),
            base_path=unit_temp_dir,
            security=True
        )
        connection = LocalStorageConnection(config, "json")
        # Should raise error for path traversal
        with pytest.raises(XWLocationError, match="dangerous patterns"):
            connection.get_file_path("../outside.json")
        # Should raise error for absolute path
        with pytest.raises(XWLocationError, match="dangerous patterns"):
            connection.get_file_path("/etc/passwd")
    @pytest.mark.asyncio

    async def test_save_with_different_formats(self, local_connection_unit, sample_data, test_path):
        """Test saving with different format configurations."""
        # Test JSON format
        json_conn = LocalStorageConnection(
            LocalConnectorConfig(address=str(local_connection_unit._full_base_path / "test.json"), security=False),
            "json"
        )
        await json_conn.save(sample_data, test_path)
        loaded = await json_conn.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_save_append_mode(self, local_connection_unit, sample_list, test_path):
        """Test save with append mode."""
        # Save initial list
        await local_connection_unit.save(sample_list[:2], test_path)
        # Append more items
        await local_connection_unit.save(sample_list[2:], test_path, append=True)
        # Load and verify all items
        loaded = await local_connection_unit.load(test_path)
        assert len(loaded) >= len(sample_list)
    @pytest.mark.asyncio

    async def test_save_empty_data(self, local_connection_unit, test_path):
        """Test saving empty data structures."""
        # Save empty dict
        await local_connection_unit.save({}, test_path)
        loaded = await local_connection_unit.load(test_path)
        assert loaded == {}
        # Save empty list
        await local_connection_unit.save([], test_path)
        loaded = await local_connection_unit.load(test_path)
        assert isinstance(loaded, list)
        assert len(loaded) == 0
    @pytest.mark.asyncio

    async def test_exists_for_nonexistent_path(self, local_connection_unit):
        """Test exists() returns False for nonexistent path."""
        exists = await local_connection_unit.exists("nonexistent")
        assert exists is False
    @pytest.mark.asyncio

    async def test_delete_nonexistent_path_no_error(self, local_connection_unit):
        """Test that deleting nonexistent path doesn't raise error."""
        # Should not raise error
        await local_connection_unit.delete("nonexistent")
    @pytest.mark.asyncio

    async def test_connection_id_uniqueness(self, local_config_unit):
        """Test that connection IDs are unique."""
        conn1 = LocalStorageConnection(local_config_unit, "json")
        conn2 = LocalStorageConnection(local_config_unit, "json")
        # IDs should be different
        assert conn1.connection_id != conn2.connection_id
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalConnectorEdgeCases:
    """Unit tests for edge cases and error handling."""
    @pytest.mark.asyncio

    async def test_save_with_special_characters_in_path(self, local_connection_unit, sample_data):
        """Test saving with special characters in path."""
        special_path = "test-data_with.special_chars"
        await local_connection_unit.save(sample_data, special_path)
        loaded = await local_connection_unit.load(special_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_save_large_data(self, local_connection_unit, test_path):
        """Test saving large data structures."""
        large_data = {
            "items": [{"id": i, "data": "x" * 1000} for i in range(100)]
        }
        await local_connection_unit.save(large_data, test_path)
        loaded = await local_connection_unit.load(test_path)
        assert len(loaded["items"]) == 100
    @pytest.mark.asyncio

    async def test_concurrent_save_operations(self, local_connection_unit, test_path):
        """Test concurrent save operations."""
        import asyncio
        async def save_item(item_id):
            await local_connection_unit.save({"id": item_id}, f"{test_path}_{item_id}")
        # Save multiple items concurrently
        await asyncio.gather(*[save_item(i) for i in range(5)])
        # Verify all were saved
        for i in range(5):
            exists = await local_connection_unit.exists(f"{test_path}_{i}")
            assert exists is True
