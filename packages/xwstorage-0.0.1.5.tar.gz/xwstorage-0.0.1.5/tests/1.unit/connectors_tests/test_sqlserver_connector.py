#!/usr/bin/env python3
"""
Unit tests for SQLServerConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.sqlserver_connector import (
    SQLServerConnectorConfig,
    SQLServerStorageConnection
)
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sqlserver

class TestSQLServerConnectorConfig:
    """Unit tests for SQLServerConnectorConfig."""

    def test_config_initialization_with_table_name(self):
        """Test config initialization with just table name."""
        config = SQLServerConnectorConfig(
            address="test_table",
            host="localhost",
            port=1433,
            database="testdb",
            username="sa",
            password="password"
        )
        assert config.connector_type == "sqlserver"
        assert config.table_name == "test_table"
        assert config.host == "localhost"
        assert config.port == 1433
        assert config.database == "testdb"
        assert config.driver == "ODBC Driver 17 for SQL Server"

    def test_config_initialization_with_custom_driver(self):
        """Test config initialization with custom ODBC driver."""
        config = SQLServerConnectorConfig(
            address="test_table",
            host="localhost",
            port=1433,
            database="testdb",
            username="sa",
            password="password",
            driver="ODBC Driver 18 for SQL Server"
        )
        assert config.driver == "ODBC Driver 18 for SQL Server"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string."""
        config = SQLServerConnectorConfig(
            address="localhost:1433/testdb",
            username="sa",
            password="password",
            table_name="custom_table"
        )
        assert config.host == "localhost"
        assert config.port == 1433
        assert config.database == "testdb"
        assert config.table_name == "custom_table"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = SQLServerConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb",
            username="sa",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "sqlserver"
        assert config_dict["table_name"] == "test_table"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sqlserver

class TestSQLServerStorageConnection:
    """Unit tests for SQLServerStorageConnection."""

    def test_connection_requires_sqlserver_package(self):
        """Test that connection raises error if SQL Server package not available."""
        # This test will pass if pyodbc/pymssql package is not installed
        # and fail if it is installed (which is expected behavior)
        config = SQLServerConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb",
            username="sa",
            password="password"
        )
        try:
            connection = SQLServerStorageConnection(config, "json")
            # If we get here, SQL Server package is available
            # Connection should be valid
            assert connection._config == config
        except XWLocationError as e:
            # Expected if SQL Server package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_sqlserver_config_type(self):
        """Test that connection requires SQLServerConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        # If SQL Server package is not installed, it will raise error about package first
        # If SQL Server package is installed, it will raise error about config type
        with pytest.raises(XWLocationError) as exc_info:
            SQLServerStorageConnection(local_config, "json")
        # Should raise error about either package or config type
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected SQLServerConnectorConfig" in error_msg)
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sqlserver
@pytest.mark.skip(reason="Requires SQL Server database running")

class TestSQLServerStorageConnectionOperations:
    """Unit tests for SQL Server storage operations (requires running SQL Server)."""
    @pytest.fixture

    def sqlserver_config(self):
        """SQL Server config for testing (requires running SQL Server)."""
        return SQLServerConnectorConfig(
            address="test_storage",
            host="localhost",
            port=1433,
            database="testdb",
            username="sa",
            password="password"
        )
    @pytest.fixture

    async def sqlserver_connection(self, sqlserver_config):
        """SQL Server connection for testing."""
        connection = SQLServerStorageConnection(sqlserver_config, "json")
        yield connection
    @pytest.mark.asyncio

    async def test_sqlserver_save_and_load(self, sqlserver_connection, sample_data, test_path):
        """Test SQL Server save and load operations."""
        await sqlserver_connection.save(sample_data, test_path)
        loaded = await sqlserver_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_sqlserver_append_not_supported(self, sqlserver_connection, sample_data, test_path):
        """Test that append mode is not supported."""
        with pytest.raises(XWStorageError, match="not supported"):
            await sqlserver_connection.save(sample_data, test_path, append=True)
    @pytest.mark.asyncio

    async def test_sqlserver_exists(self, sqlserver_connection, sample_data, test_path):
        """Test SQL Server exists check."""
        assert await sqlserver_connection.exists(test_path) is False
        await sqlserver_connection.save(sample_data, test_path)
        assert await sqlserver_connection.exists(test_path) is True
    @pytest.mark.asyncio

    async def test_sqlserver_delete(self, sqlserver_connection, sample_data, test_path):
        """Test SQL Server delete operation."""
        await sqlserver_connection.save(sample_data, test_path)
        await sqlserver_connection.delete(test_path)
        assert await sqlserver_connection.exists(test_path) is False
    @pytest.mark.asyncio

    async def test_sqlserver_list_items(self, sqlserver_connection, sample_data):
        """Test SQL Server list items operation."""
        # Save multiple items
        paths = [f"data/item_{i}" for i in range(5)]
        for path in paths:
            await sqlserver_connection.save(sample_data, path)
        # List items
        items = await sqlserver_connection.list_items("data/", recursive=False)
        assert len(items) >= 5
        for path in paths:
            assert path in items
