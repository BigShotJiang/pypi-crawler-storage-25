#!/usr/bin/env python3
"""
Unit tests for MongoDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.mongodb_connector import MongoDBConnectorConfig, MongoDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mongodb

class TestMongoDBConnectorConfig:
    """Unit tests for MongoDBConnectorConfig."""

    def test_config_initialization_with_collection_name(self):
        """Test config initialization with collection name."""
        config = MongoDBConnectorConfig(
            address="users",  # Collection name
            host="localhost",
            port=27017,
            database="testdb",
            username="admin",
            password="password"
        )
        assert config.connector_type == "mongodb"
        assert config.collection_name == "users"
        assert config.host == "localhost"
        assert config.port == 27017
        assert config.database == "testdb"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with MongoDB connection string."""
        config = MongoDBConnectorConfig(
            address="mongodb://localhost:27017/testdb",
            collection_name="users"
        )
        assert config.collection_name == "users"
        assert config.host == "localhost"
        assert config.port == 27017
        assert config.database == "testdb"

    def test_config_initialization_with_srv_connection_string(self):
        """Test config initialization with MongoDB SRV connection string."""
        config = MongoDBConnectorConfig(
            address="mongodb+srv://cluster.mongodb.net/testdb",
            collection_name="users"
        )
        assert config.collection_name == "users"
        assert config.database == "testdb"
        assert config.host is None  # SRV doesn't need explicit host

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = MongoDBConnectorConfig(
            address="users",
            host="localhost",
            database="testdb",
            username="admin",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "mongodb"
        assert config_dict["collection_name"] == "users"
        assert config_dict["database"] == "testdb"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_port(self):
        """Test config uses default port 27017 when not specified."""
        config = MongoDBConnectorConfig(
            address="users",
            host="localhost",
            database="testdb"
        )
        assert config.port == 27017
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mongodb

class TestMongoDBStorageConnection:
    """Unit tests for MongoDBStorageConnection."""

    def test_connection_requires_mongodb_package(self):
        """Test that connection raises error if MongoDB package not available."""
        config = MongoDBConnectorConfig(
            address="users",
            host="localhost",
            database="testdb"
        )
        try:
            connection = MongoDBStorageConnection(config, "json")
            # If we get here, mongodb package is available
            assert connection._config == config
        except XWLocationError as e:
            # Expected if mongodb package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_mongodb_config_type(self):
        """Test that connection requires MongoDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        # If MongoDB package is not installed, it will raise error about package first
        # If MongoDB package is installed, it will raise error about config type
        with pytest.raises(XWLocationError) as exc_info:
            MongoDBStorageConnection(local_config, "json")
        # Should raise error about either package or config type
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected MongoDBConnectorConfig" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = MongoDBConnectorConfig(
            address="users",
            host="localhost",
            database="testdb"
        )
        try:
            connection = MongoDBStorageConnection(config, "json")
            assert connection._config == config
            assert connection._use_async is not None  # Should be set based on package availability
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("MongoDB package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_mongodb
@pytest.mark.skip(reason="Requires MongoDB server running")

class TestMongoDBStorageConnectionOperations:
    """Unit tests for MongoDB storage operations (requires running MongoDB server)."""
    @pytest.fixture

    def mongodb_config(self):
        """MongoDB config for testing (requires running MongoDB)."""
        return MongoDBConnectorConfig(
            address="test_storage",
            host="localhost",
            port=27017,
            database="testdb",
            username=None,
            password=None
        )
    @pytest.fixture

    async def mongodb_connection(self, mongodb_config):
        """MongoDB connection for testing."""
        connection = MongoDBStorageConnection(mongodb_config, "json")
        yield connection
    @pytest.mark.asyncio

    async def test_mongodb_save_and_load(self, mongodb_connection, sample_data, test_path):
        """Test MongoDB save and load operations."""
        await mongodb_connection.save(sample_data, test_path)
        loaded = await mongodb_connection.load(test_path)
        assert loaded == sample_data
    @pytest.mark.asyncio

    async def test_mongodb_exists(self, mongodb_connection, sample_data, test_path):
        """Test MongoDB exists check."""
        assert await mongodb_connection.exists(test_path) is False
        await mongodb_connection.save(sample_data, test_path)
        assert await mongodb_connection.exists(test_path) is True
    @pytest.mark.asyncio

    async def test_mongodb_delete(self, mongodb_connection, sample_data, test_path):
        """Test MongoDB delete operation."""
        await mongodb_connection.save(sample_data, test_path)
        assert await mongodb_connection.exists(test_path) is True
        await mongodb_connection.delete(test_path)
        assert await mongodb_connection.exists(test_path) is False
    @pytest.mark.asyncio

    async def test_mongodb_list_documents(self, mongodb_connection, sample_data):
        """Test MongoDB list documents operation."""
        # Save multiple documents
        await mongodb_connection.save(sample_data, "doc1")
        await mongodb_connection.save(sample_data, "doc2")
        # List all documents
        documents = await mongodb_connection.list_all()
        assert "doc1" in documents
        assert "doc2" in documents
