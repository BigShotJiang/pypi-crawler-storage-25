#!/usr/bin/env python3
"""
Unit tests for SurrealDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.surrealdb_connector import SurrealDBConnectorConfig, SurrealDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_surrealdb

class TestSurrealDBConnectorConfig:
    """Unit tests for SurrealDBConnectorConfig."""

    def test_config_initialization_with_ws_url(self):
        """Test config initialization with WebSocket URL."""
        config = SurrealDBConnectorConfig(
            address="ws://localhost:8000/rpc",
            database="test",
            namespace="test"
        )
        assert config.connector_type == "surrealdb"
        assert config.url == "ws://localhost:8000/rpc"
        assert config.database == "test"
        assert config.namespace == "test"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to ws://)."""
        config = SurrealDBConnectorConfig(
            address="localhost:8000/rpc"
        )
        assert config.url == "ws://localhost:8000/rpc"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = SurrealDBConnectorConfig(
            address="ws://localhost:8000/rpc",
            database="test",
            namespace="ns"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "surrealdb"
        assert config_dict["url"] == "ws://localhost:8000/rpc"
        assert config_dict["database"] == "test"
        assert config_dict["namespace"] == "ns"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_surrealdb

class TestSurrealDBStorageConnection:
    """Unit tests for SurrealDBStorageConnection."""

    def test_connection_requires_surrealdb_package(self):
        """Test that connection raises error if SurrealDB package not available."""
        config = SurrealDBConnectorConfig(
            address="ws://localhost:8000/rpc"
        )
        try:
            connection = SurrealDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "SurrealDB connector package" in error_msg)

    def test_connection_requires_surrealdb_config_type(self):
        """Test that connection requires SurrealDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            SurrealDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "SurrealDB connector package" in error_msg or
                "Expected SurrealDBConnectorConfig" in error_msg)
