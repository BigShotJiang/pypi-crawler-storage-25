#!/usr/bin/env python3
"""
Unit tests for FaissConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.faiss_connector import FaissConnectorConfig, FaissStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_faiss

class TestFaissConnectorConfig:
    """Unit tests for FaissConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with index file path."""
        config = FaissConnectorConfig(
            address="/tmp/faiss.index",
            dimension=128
        )
        assert config.connector_type == "faiss"
        assert config.index_path is not None
        assert config.dimension == 128
        assert config.index_type == "flat"

    def test_config_initialization_with_dimension(self):
        """Test config initialization with dimension (creating new index)."""
        config = FaissConnectorConfig(
            address="128",  # Dimension as string
            index_type="ivf"
        )
        assert config.dimension == 128
        assert config.index_type == "ivf"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = FaissConnectorConfig(
            address="/tmp/faiss.index",
            dimension=128,
            index_type="hnsw"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "faiss"
        assert config_dict["dimension"] == 128
        assert config_dict["index_type"] == "hnsw"
        assert config_dict["metric"] == "L2"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_faiss

class TestFaissStorageConnection:
    """Unit tests for FaissStorageConnection."""

    def test_connection_requires_faiss_package(self):
        """Test that connection raises error if FAISS package not available."""
        config = FaissConnectorConfig(
            address="/tmp/faiss.index",
            dimension=128
        )
        try:
            connection = FaissStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_faiss_config_type(self):
        """Test that connection requires FaissConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            FaissStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected FaissConnectorConfig" in error_msg)
