#!/usr/bin/env python3
"""
Unit tests for DragonflyDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.dragonflydb_connector import DragonflyDBConnectorConfig, DragonflyDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dragonflydb

class TestDragonflyDBConnectorConfig:
    """Unit tests for DragonflyDBConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = DragonflyDBConnectorConfig(
            address="localhost:6379"
        )
        assert config.connector_type == "dragonflydb"
        assert config.host == "localhost"
        assert config.port == 6379

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 6379)."""
        config = DragonflyDBConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 6379

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = DragonflyDBConnectorConfig(
            address="localhost:6379"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "dragonflydb"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 6379
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dragonflydb

class TestDragonflyDBStorageConnection:
    """Unit tests for DragonflyDBStorageConnection."""

    def test_connection_requires_redis_package(self):
        """Test that connection raises error if Redis package not available."""
        config = DragonflyDBConnectorConfig(
            address="localhost:6379"
        )
        try:
            connection = DragonflyDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_dragonflydb_config_type(self):
        """Test that connection requires DragonflyDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DragonflyDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected DragonflyDBConnectorConfig" in error_msg)
