#!/usr/bin/env python3
"""
Unit tests for PineconeConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.pinecone_connector import PineconeConnectorConfig, PineconeStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_pinecone

class TestPineconeConnectorConfig:
    """Unit tests for PineconeConnectorConfig."""

    def test_config_initialization_with_api_key(self):
        """Test config initialization with API key in address."""
        config = PineconeConnectorConfig(
            address="my_api_key",
            environment="us-east-1"
        )
        assert config.connector_type == "pinecone"
        assert config.api_key == "my_api_key"
        assert config.environment == "us-east-1"

    def test_config_initialization_with_separate_api_key(self):
        """Test config initialization with separate API key parameter."""
        config = PineconeConnectorConfig(
            address="us-east-1",
            api_key="my_api_key"
        )
        assert config.api_key == "my_api_key"
        assert config.environment == "us-east-1"

    def test_config_to_dict(self):
        """Test config to_dict conversion (API key masked)."""
        config = PineconeConnectorConfig(
            address="my_api_key",
            environment="us-east-1"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "pinecone"
        assert config_dict["environment"] == "us-east-1"
        assert config_dict["api_key"] == "***"  # API key should be masked

    def test_config_default_environment(self):
        """Test config uses default environment when not specified."""
        config = PineconeConnectorConfig(
            address="my_api_key"
        )
        assert config.environment == "us-east-1"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_pinecone

class TestPineconeStorageConnection:
    """Unit tests for PineconeStorageConnection."""

    def test_connection_requires_pinecone_package(self):
        """Test that connection raises error if Pinecone package not available."""
        config = PineconeConnectorConfig(
            address="my_api_key"
        )
        try:
            connection = PineconeStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_pinecone_config_type(self):
        """Test that connection requires PineconeConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            PineconeStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected PineconeConnectorConfig" in error_msg)
