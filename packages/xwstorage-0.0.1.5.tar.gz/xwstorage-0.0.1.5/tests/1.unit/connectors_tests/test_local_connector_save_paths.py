#!/usr/bin/env python3
"""
Tests for all save operation code paths in LocalConnector.
Covers append mode, collection creation, error handling, and all conditional branches.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
import pytest_asyncio
import tempfile
import shutil
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig, LocalStorageConnection
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalConnectorSaveAppendPaths:
    """Tests for append mode save operations."""
    @pytest.mark.asyncio

    async def test_save_append_with_existing_collection_format(self, local_connection_unit, sample_list, test_path):
        """Test append with existing collection format."""
        # Save initial collection
        await local_connection_unit.save(sample_list[:2], test_path)
        # Append more - should merge with existing entities
        await local_connection_unit.save(sample_list[2:], test_path, append=True)
        loaded = await local_connection_unit.load(test_path)
        if isinstance(loaded, dict) and "entities" in loaded:
            assert len(loaded["entities"]) >= 3
    @pytest.mark.asyncio

    async def test_save_append_with_existing_array_format(self, local_connection_unit, sample_list, test_path):
        """Test append with existing simple array format."""
        # Create file with simple array format manually
        codec = local_connection_unit._get_codec()
        file_path = local_connection_unit.get_file_path(test_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        # Write simple array format
        if hasattr(codec, 'encode'):
            encoded = codec.encode(sample_list[:2])
            if isinstance(encoded, bytes):
                file_path.write_bytes(encoded)
            else:
                file_path.write_text(encoded, encoding='utf-8')
        # Append more
        await local_connection_unit.save(sample_list[2:], test_path, append=True)
        loaded = await local_connection_unit.load(test_path)
        if isinstance(loaded, list):
            assert len(loaded) >= 3
    @pytest.mark.asyncio

    async def test_save_append_with_unknown_format(self, local_connection_unit, sample_list, test_path):
        """Test append with unknown format falls back to overwrite."""
        # Create file with unknown format
        file_path = local_connection_unit.get_file_path(test_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text('{"unknown": "format"}', encoding='utf-8')
        # Append should fall back to overwrite
        await local_connection_unit.save(sample_list, test_path, append=True)
        loaded = await local_connection_unit.load(test_path)
        assert loaded is not None
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalConnectorSaveCollectionCreation:
    """Tests for collection structure creation."""
    @pytest.mark.asyncio

    async def test_save_list_creates_collection_structure(self, local_connection_unit, sample_list, test_path):
        """Test that saving a list creates collection structure."""
        await local_connection_unit.save(sample_list, test_path)
        loaded = await local_connection_unit.load(test_path)
        # Should be collection structure
        assert isinstance(loaded, dict)
        assert "id" in loaded
        assert "uid" in loaded
        assert "entities" in loaded
        assert loaded["entities"] == sample_list
    @pytest.mark.asyncio

    async def test_save_list_collection_id_from_path(self, local_connection_unit, sample_list):
        """Test collection ID derived from path."""
        path_with_dot = "my.collection"
        await local_connection_unit.save(sample_list, path_with_dot)
        loaded = await local_connection_unit.load(path_with_dot)
        if isinstance(loaded, dict) and "id" in loaded:
            # ID should be derived from path
            assert loaded["id"] in ["my", path_with_dot]
    @pytest.mark.asyncio

    async def test_save_list_collection_id_from_filename(self, local_connection_unit, sample_list, unit_temp_dir):
        """Test collection ID derived from filename when path has no dot."""
        config = LocalConnectorConfig(
            address=str(unit_temp_dir / "collection.json"),
            security=False
        )
        connection = LocalStorageConnection(config, "json")
        await connection.save(sample_list, "test_path")
        loaded = await connection.load("test_path")
        if isinstance(loaded, dict) and "id" in loaded:
            # ID should be from filename or path
            assert "id" in loaded
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalConnectorSaveErrorPaths:
    """Tests for error handling in save operations."""
    @pytest.mark.asyncio

    async def test_save_error_logging(self, local_connection_unit, sample_data, test_path):
        """Test that save errors are logged and re-raised."""
        # Force error in file path resolution
        with patch.object(local_connection_unit, '_get_file_path', side_effect=Exception("Test error")):
            with pytest.raises(Exception, match="Test error"):
                await local_connection_unit.save(sample_data, test_path)
    @pytest.mark.asyncio

    async def test_save_append_load_failure_handling(self, local_connection_unit, sample_list, test_path):
        """Test append mode handles load failures gracefully."""
        # Create file first
        await local_connection_unit.save(sample_list[:2], test_path)
        # Mock codec to fail on both load_file and decode
        codec = MagicMock()
        codec.load_file = MagicMock(side_effect=Exception("Load failed"))
        codec.decode = MagicMock(side_effect=Exception("Decode failed"))
        codec.is_binary_format = False
        with patch.object(local_connection_unit, '_get_codec', return_value=codec):
            # Should fall back to overwrite instead of append
            await local_connection_unit.save(sample_list[2:], test_path, append=True)
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalConnectorPathValidation:
    """Tests for path validation edge cases."""
    @pytest.mark.asyncio

    async def test_path_validation_windows_extended_path_normalization(self, unit_temp_dir):
        """Test Windows extended path normalization."""
        config = LocalConnectorConfig(
            address=str(unit_temp_dir / "test.json"),
            base_path=unit_temp_dir,
            security=True
        )
        connection = LocalStorageConnection(config, "json")
        # Test path that might trigger Windows extended path handling
        with patch('exonware.xwstorage.connectors.local_connector.PATH_VALIDATOR_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.local_connector.PathValidator') as mock_validator:
                mock_validator_instance = MagicMock()
                mock_validator.return_value = mock_validator_instance
                # Simulate Windows extended path in validated result
                validated_path = Path('\\\\?\\' + str(unit_temp_dir / "test.json"))
                mock_validator_instance.validate_path.return_value = validated_path
                file_path = connection.get_file_path("test")
                assert file_path is not None
    @pytest.mark.asyncio

    async def test_path_validation_path_security_error_windows_path(self, unit_temp_dir):
        """Test PathSecurityError handling for Windows extended paths."""
        with patch('exonware.xwstorage.connectors.local_connector.PATH_VALIDATOR_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.local_connector.PathValidator') as mock_validator:
                from exonware.xwstorage.connectors.local_connector import PathSecurityError
                mock_validator_instance = MagicMock()
                mock_validator.return_value = mock_validator_instance
                # Simulate Windows extended path error
                mock_validator_instance.validate_path.side_effect = PathSecurityError(
                    "Path contains \\\\?\\ or not in the subpath"
                )
                config = LocalConnectorConfig(
                    address=str(unit_temp_dir / "test.json"),
                    base_path=unit_temp_dir,
                    security=True
                )
                connection = LocalStorageConnection(config, "json")
                # Should continue with path resolution (not raise immediately)
                # The final boundary check will catch real issues
                file_path = connection.get_file_path("test")
                assert file_path is not None
