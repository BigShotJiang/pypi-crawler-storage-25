#!/usr/bin/env python3
"""
Comprehensive unit tests for GCSConnector - 100% coverage target.
Tests all code paths including error handling and edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from exonware.xwstorage.connectors.gcs_connector import GCSConnectorConfig, GCSStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_gcs

class TestGCSConnectorConfigComprehensive:
    """Comprehensive tests for GCSConnectorConfig."""

    def test_config_initialization_variations(self):
        """Test various initialization scenarios."""
        # Test with bucket and project
        config = GCSConnectorConfig(
            bucket="my-bucket",
            project="my-project"
        )
        assert config.connector_type == "gcs"
        assert config.bucket == "my-bucket"
        assert config.project == "my-project"
        # Test with credentials path
        config2 = GCSConnectorConfig(
            bucket="my-bucket",
            project="my-project",
            credentials_path="/path/to/credentials.json"
        )
        assert config2.credentials_path == "/path/to/credentials.json"
        # Test with credentials dict
        config3 = GCSConnectorConfig(
            bucket="my-bucket",
            credentials_dict={"type": "service_account", "project_id": "..."}
        )
        assert config3.credentials_dict is not None

    def test_config_to_dict(self):
        """Test to_dict conversion."""
        config = GCSConnectorConfig(
            bucket="test-bucket",
            project="test-project",
            credentials_path="/path/to/creds.json"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "gcs"
        assert config_dict["bucket"] == "test-bucket"
        assert config_dict["project"] == "test-project"
        assert config_dict["credentials_path"] == "/path/to/creds.json"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_gcs

class TestGCSStorageConnectionComprehensive:
    """Comprehensive tests for GCSStorageConnection."""
    @pytest.fixture

    def gcs_config(self):
        """GCS config for testing."""
        return GCSConnectorConfig(
            bucket="test-bucket",
            project="test-project"
        )

    def test_connection_requires_gcs_package(self, gcs_config):
        """Test that connection raises error if GCS package not available."""
        with patch('exonware.xwstorage.connectors.gcs_connector.GCS_AVAILABLE', False):
            with pytest.raises(XWLocationError) as exc_info:
                GCSStorageConnection(gcs_config, "json")
            error_msg = str(exc_info.value)
            assert "not installed" in error_msg.lower()

    def test_connection_requires_gcs_config_type(self):
        """Test that connection requires GCSConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            GCSStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected GCSConnectorConfig" in error_msg)
