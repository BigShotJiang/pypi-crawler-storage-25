#!/usr/bin/env python3
"""
Unit tests for LevelDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.leveldb_connector import LevelDBConnectorConfig, LevelDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_leveldb

class TestLevelDBConnectorConfig:
    """Unit tests for LevelDBConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with database path."""
        config = LevelDBConnectorConfig(
            address="/tmp/testdb"
        )
        assert config.connector_type == "leveldb"
        assert config.database_path == "/tmp/testdb"
        assert config.create_if_missing is True

    def test_config_initialization_with_create_if_missing(self):
        """Test config initialization with create_if_missing option."""
        config = LevelDBConnectorConfig(
            address="/tmp/testdb",
            create_if_missing=False
        )
        assert config.create_if_missing is False

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = LevelDBConnectorConfig(
            address="/tmp/testdb",
            create_if_missing=True
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "leveldb"
        assert config_dict["database_path"] == "/tmp/testdb"
        assert config_dict["create_if_missing"] is True
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_leveldb

class TestLevelDBStorageConnection:
    """Unit tests for LevelDBStorageConnection."""

    def test_connection_requires_leveldb_package(self):
        """Test that connection raises error if LevelDB package not available."""
        config = LevelDBConnectorConfig(
            address="/tmp/testdb"
        )
        try:
            connection = LevelDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_leveldb_config_type(self):
        """Test that connection requires LevelDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            LevelDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected LevelDBConnectorConfig" in error_msg)
