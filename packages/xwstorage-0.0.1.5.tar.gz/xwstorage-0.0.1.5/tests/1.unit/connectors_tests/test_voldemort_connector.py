#!/usr/bin/env python3
"""
Unit tests for VoldemortConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.voldemort_connector import VoldemortConnectorConfig, VoldemortStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_voldemort

class TestVoldemortConnectorConfig:
    """Unit tests for VoldemortConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = VoldemortConnectorConfig(
            address="localhost:6666",
            store_name="test"
        )
        assert config.connector_type == "voldemort"
        assert config.host == "localhost"
        assert config.port == 6666
        assert config.store_name == "test"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 6666)."""
        config = VoldemortConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 6666

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = VoldemortConnectorConfig(
            address="localhost:6666",
            store_name="my_store"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "voldemort"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 6666
        assert config_dict["store_name"] == "my_store"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_voldemort

class TestVoldemortStorageConnection:
    """Unit tests for VoldemortStorageConnection."""

    def test_connection_requires_voldemort_package(self):
        """Test that connection raises error if Voldemort package not available."""
        config = VoldemortConnectorConfig(
            address="localhost:6666"
        )
        try:
            connection = VoldemortStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Voldemort connector package" in error_msg)

    def test_connection_requires_voldemort_config_type(self):
        """Test that connection requires VoldemortConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            VoldemortStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Voldemort connector package" in error_msg or
                "Expected VoldemortConnectorConfig" in error_msg)
