"""
Unit tests for connector implementations.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""
