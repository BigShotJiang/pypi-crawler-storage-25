#!/usr/bin/env python3
"""
Unit tests for OpenIOConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.openio_connector import OpenIOConnectorConfig, OpenIOStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_openio

class TestOpenIOConnectorConfig:
    """Unit tests for OpenIOConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with endpoint URL."""
        config = OpenIOConnectorConfig(
            address="http://localhost:6007",
            bucket="mybucket",
            access_key="my_access_key",
            secret_key="my_secret_key",
            namespace="OPENIO"
        )
        assert config.connector_type == "openio"
        assert config.endpoint_url == "http://localhost:6007"
        assert config.bucket == "mybucket"
        assert config.access_key == "my_access_key"
        assert config.namespace == "OPENIO"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = OpenIOConnectorConfig(
            address="localhost:6007",
            bucket="mybucket",
            access_key="my_access_key",
            secret_key="my_secret_key"
        )
        assert config.endpoint_url == "http://localhost:6007"

    def test_config_to_dict(self):
        """Test config to_dict conversion (secret_key masked)."""
        config = OpenIOConnectorConfig(
            address="http://localhost:6007",
            bucket="mybucket",
            access_key="my_access_key",
            secret_key="secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "openio"
        assert config_dict["endpoint_url"] == "http://localhost:6007"
        assert config_dict["bucket"] == "mybucket"
        if "secret_key" in config_dict:
            assert config_dict["secret_key"] == "***"  # Secret key should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_openio

class TestOpenIOStorageConnection:
    """Unit tests for OpenIOStorageConnection."""

    def test_connection_requires_boto3_package(self):
        """Test that connection raises error if boto3 package not available."""
        config = OpenIOConnectorConfig(
            address="http://localhost:6007",
            bucket="mybucket",
            access_key="my_access_key",
            secret_key="my_secret_key"
        )
        try:
            connection = OpenIOStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_openio_config_type(self):
        """Test that connection requires OpenIOConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            OpenIOStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected OpenIOConnectorConfig" in error_msg)
