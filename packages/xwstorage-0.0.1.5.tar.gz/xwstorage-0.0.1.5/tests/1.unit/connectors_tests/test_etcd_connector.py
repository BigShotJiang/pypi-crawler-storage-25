#!/usr/bin/env python3
"""
Unit tests for EtcdConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.etcd_connector import EtcdConnectorConfig, EtcdStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_etcd

class TestEtcdConnectorConfig:
    """Unit tests for EtcdConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = EtcdConnectorConfig(
            address="localhost:2379"
        )
        assert config.connector_type == "etcd"
        assert config.host == "localhost"
        assert config.port == 2379

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 2379)."""
        config = EtcdConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 2379

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = EtcdConnectorConfig(
            address="localhost:2379"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "etcd"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 2379
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_etcd

class TestEtcdStorageConnection:
    """Unit tests for EtcdStorageConnection."""

    def test_connection_requires_etcd_package(self):
        """Test that connection raises error if etcd package not available."""
        config = EtcdConnectorConfig(
            address="localhost:2379"
        )
        try:
            connection = EtcdStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_etcd_config_type(self):
        """Test that connection requires EtcdConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            EtcdStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected EtcdConnectorConfig" in error_msg)
