#!/usr/bin/env python3
"""
Unit tests for BerkeleyDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.berkeley_db_connector import BerkeleyDBConnectorConfig, BerkeleyDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_berkeley_db

class TestBerkeleyDBConnectorConfig:
    """Unit tests for BerkeleyDBConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with database file path."""
        config = BerkeleyDBConnectorConfig(
            address="/tmp/berkeley.db",
            db_type="hash"
        )
        assert config.connector_type == "berkeley_db"
        assert str(config.db_path) == "/tmp/berkeley.db"
        assert config.db_type == "hash"
        assert config.flags == "c"  # Default create flag

    def test_config_initialization_with_custom_flags(self):
        """Test config initialization with custom flags."""
        config = BerkeleyDBConnectorConfig(
            address="/tmp/berkeley.db",
            db_type="btree",
            flags="r"  # Read-only
        )
        assert config.db_type == "btree"
        assert config.flags == "r"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = BerkeleyDBConnectorConfig(
            address="/tmp/berkeley.db",
            db_type="btree",
            flags="c"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "berkeley_db"
        assert config_dict["db_path"] == "/tmp/berkeley.db"
        assert config_dict["db_type"] == "btree"
        assert config_dict["flags"] == "c"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_berkeley_db

class TestBerkeleyDBStorageConnection:
    """Unit tests for BerkeleyDBStorageConnection."""

    def test_connection_requires_berkeley_db_package(self):
        """Test that connection raises error if Berkeley DB package not available."""
        config = BerkeleyDBConnectorConfig(
            address="/tmp/berkeley.db"
        )
        try:
            connection = BerkeleyDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_berkeley_db_config_type(self):
        """Test that connection requires BerkeleyDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            BerkeleyDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected BerkeleyDBConnectorConfig" in error_msg)
