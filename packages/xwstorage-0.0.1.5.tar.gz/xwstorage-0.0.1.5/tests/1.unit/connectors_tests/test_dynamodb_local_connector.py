#!/usr/bin/env python3
"""
Unit tests for DynamoDBLocalConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.dynamodb_local_connector import DynamoDBLocalConnectorConfig, DynamoDBLocalStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dynamodb_local

class TestDynamoDBLocalConnectorConfig:
    """Unit tests for DynamoDBLocalConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with endpoint URL."""
        config = DynamoDBLocalConnectorConfig(
            address="http://localhost:8000",
            region="us-east-1"
        )
        assert config.connector_type == "dynamodb_local"
        assert config.endpoint_url == "http://localhost:8000"
        assert config.region == "us-east-1"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = DynamoDBLocalConnectorConfig(
            address="localhost:8000"
        )
        assert config.endpoint_url == "http://localhost:8000"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = DynamoDBLocalConnectorConfig(
            address="http://localhost:8000",
            region="us-west-2"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "dynamodb_local"
        assert config_dict["endpoint_url"] == "http://localhost:8000"
        assert config_dict["region"] == "us-west-2"

    def test_config_default_values(self):
        """Test config uses default values when not specified."""
        config = DynamoDBLocalConnectorConfig()
        assert config.endpoint_url == "http://localhost:8000"
        assert config.region == "us-east-1"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dynamodb_local

class TestDynamoDBLocalStorageConnection:
    """Unit tests for DynamoDBLocalStorageConnection."""

    def test_connection_requires_boto3_package(self):
        """Test that connection raises error if boto3 package not available."""
        config = DynamoDBLocalConnectorConfig(
            address="http://localhost:8000"
        )
        try:
            connection = DynamoDBLocalStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_dynamodb_local_config_type(self):
        """Test that connection requires DynamoDBLocalConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DynamoDBLocalStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected DynamoDBLocalConnectorConfig" in error_msg)
