#!/usr/bin/env python3
"""
Unit tests for QuickwitConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.quickwit_connector import QuickwitConnectorConfig, QuickwitStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_quickwit

class TestQuickwitConnectorConfig:
    """Unit tests for QuickwitConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = QuickwitConnectorConfig(
            address="http://localhost:7280"
        )
        assert config.connector_type == "quickwit"
        assert config.url == "http://localhost:7280"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = QuickwitConnectorConfig(
            address="localhost:7280"
        )
        assert config.url == "http://localhost:7280"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = QuickwitConnectorConfig(
            address="http://localhost:7280"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "quickwit"
        assert config_dict["url"] == "http://localhost:7280"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_quickwit

class TestQuickwitStorageConnection:
    """Unit tests for QuickwitStorageConnection."""

    def test_connection_requires_quickwit_package(self):
        """Test that connection raises error if Quickwit package not available."""
        config = QuickwitConnectorConfig(
            address="http://localhost:7280"
        )
        try:
            connection = QuickwitStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Quickwit connector package" in error_msg)

    def test_connection_requires_quickwit_config_type(self):
        """Test that connection requires QuickwitConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            QuickwitStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Quickwit connector package" in error_msg or
                "Expected QuickwitConnectorConfig" in error_msg)
