#!/usr/bin/env python3
"""
Unit tests for WasabiConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.wasabi_connector import WasabiConnectorConfig, WasabiStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_wasabi

class TestWasabiConnectorConfig:
    """Unit tests for WasabiConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = WasabiConnectorConfig(
            bucket="my-bucket",
            region="us-east-1",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        assert config.connector_type == "wasabi"
        assert config.bucket == "my-bucket"
        assert config.region == "us-east-1"
        assert config.access_key_id == "my_access_key"
        assert config.secret_access_key == "my_secret_key"
        assert "wasabisys.com" in config.endpoint_url

    def test_config_initialization_with_custom_endpoint(self):
        """Test config initialization with custom endpoint URL."""
        config = WasabiConnectorConfig(
            bucket="my-bucket",
            region="us-east-1",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key",
            endpoint_url="https://s3.us-east-1.wasabisys.com"
        )
        assert config.endpoint_url == "https://s3.us-east-1.wasabisys.com"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = WasabiConnectorConfig(
            bucket="my-bucket",
            region="us-east-1",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "wasabi"
        assert config_dict["bucket"] == "my-bucket"
        assert config_dict["region"] == "us-east-1"
        assert "secret_access_key" not in config_dict  # Secret should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_wasabi

class TestWasabiStorageConnection:
    """Unit tests for WasabiStorageConnection."""

    def test_connection_requires_s3_connector(self):
        """Test that connection raises error if S3 connector not available."""
        config = WasabiConnectorConfig(
            bucket="my-bucket",
            region="us-east-1",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        try:
            connection = WasabiStorageConnection(config, "json")
            assert connection._config is not None
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not available" in error_msg.lower() or 
                    "S3 connector" in error_msg or
                    "boto3" in error_msg.lower())

    def test_connection_requires_wasabi_config_type(self):
        """Test that connection requires WasabiConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            WasabiStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected WasabiConnectorConfig" in error_msg or
                "S3 connector not available" in error_msg)
