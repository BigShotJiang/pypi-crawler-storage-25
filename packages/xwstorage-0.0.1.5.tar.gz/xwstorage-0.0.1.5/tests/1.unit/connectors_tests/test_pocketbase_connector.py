#!/usr/bin/env python3
"""
Unit tests for PocketBaseConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.pocketbase_connector import PocketBaseConnectorConfig, PocketBaseStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_pocketbase

class TestPocketBaseConnectorConfig:
    """Unit tests for PocketBaseConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with server URL."""
        config = PocketBaseConnectorConfig(
            address="http://localhost:8090",
            admin_email="admin@example.com",
            admin_password="admin"
        )
        assert config.connector_type == "pocketbase"
        assert config.url == "http://localhost:8090"
        assert config.admin_email == "admin@example.com"
        assert config.admin_password == "admin"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = PocketBaseConnectorConfig(
            address="localhost:8090"
        )
        assert config.url == "http://localhost:8090"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password masked)."""
        config = PocketBaseConnectorConfig(
            address="http://localhost:8090",
            admin_email="admin@example.com",
            admin_password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "pocketbase"
        assert config_dict["url"] == "http://localhost:8090"
        assert config_dict["admin_password"] == "***"  # Password should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_pocketbase

class TestPocketBaseStorageConnection:
    """Unit tests for PocketBaseStorageConnection."""

    def test_connection_requires_pocketbase_package(self):
        """Test that connection raises error if PocketBase package not available."""
        config = PocketBaseConnectorConfig(
            address="http://localhost:8090"
        )
        try:
            connection = PocketBaseStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_pocketbase_config_type(self):
        """Test that connection requires PocketBaseConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            PocketBaseStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected PocketBaseConnectorConfig" in error_msg)
