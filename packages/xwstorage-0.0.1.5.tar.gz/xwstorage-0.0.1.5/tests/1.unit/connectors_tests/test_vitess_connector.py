#!/usr/bin/env python3
"""
Unit tests for VitessConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.vitess_connector import VitessConnectorConfig, VitessStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_vitess

class TestVitessConnectorConfig:
    """Unit tests for VitessConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = VitessConnectorConfig(
            address="localhost:15306",
            database="commerce",
            username="vt_app",
            password="password"
        )
        assert config.connector_type == "vitess"
        assert config.database == "commerce"
        assert config.username == "vt_app"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 15306)."""
        config = VitessConnectorConfig(
            address="localhost",
            database="commerce"
        )
        assert config.port == 15306

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = VitessConnectorConfig(
            address="localhost:15306",
            database="commerce",
            username="vt_app",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "vitess"
        assert config_dict["database"] == "commerce"
        assert config_dict["username"] == "vt_app"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_vitess

class TestVitessStorageConnection:
    """Unit tests for VitessStorageConnection."""

    def test_connection_requires_mysql_package(self):
        """Test that connection raises error if MySQL package not available."""
        config = VitessConnectorConfig(
            address="localhost:15306",
            database="commerce"
        )
        try:
            connection = VitessStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_vitess_config_type(self):
        """Test that connection requires VitessConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            VitessStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected VitessConnectorConfig" in error_msg)
