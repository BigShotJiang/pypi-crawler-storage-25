#!/usr/bin/env python3
"""
Unit tests for CouchbaseConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.couchbase_connector import CouchbaseConnectorConfig, CouchbaseStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_couchbase

class TestCouchbaseConnectorConfig:
    """Unit tests for CouchbaseConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = CouchbaseConnectorConfig(
            bucket="mybucket",
            collection="mycollection",
            hosts=["localhost"],
            username="Administrator",
            password="password"
        )
        assert config.connector_type == "couchbase"
        assert config.bucket == "mybucket"
        assert config.collection == "mycollection"
        assert config.hosts == ["localhost"]
        assert config.username == "Administrator"

    def test_config_initialization_default_scope_collection(self):
        """Test config initialization with default scope and collection."""
        config = CouchbaseConnectorConfig(
            bucket="mybucket",
            hosts=["localhost"]
        )
        assert config.scope == "_default"
        assert config.collection == "_default"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = CouchbaseConnectorConfig(
            bucket="mybucket",
            collection="mycollection",
            hosts=["localhost"],
            username="Administrator",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "couchbase"
        assert config_dict["bucket"] == "mybucket"
        assert config_dict["collection"] == "mycollection"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_couchbase

class TestCouchbaseStorageConnection:
    """Unit tests for CouchbaseStorageConnection."""

    def test_connection_requires_couchbase_package(self):
        """Test that connection raises error if Couchbase package not available."""
        config = CouchbaseConnectorConfig(
            bucket="mybucket",
            hosts=["localhost"]
        )
        try:
            connection = CouchbaseStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_couchbase_config_type(self):
        """Test that connection requires CouchbaseConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            CouchbaseStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected CouchbaseConnectorConfig" in error_msg)
