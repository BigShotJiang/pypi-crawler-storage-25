#!/usr/bin/env python3
"""
Unit tests for VespaConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.vespa_connector import VespaConnectorConfig, VespaStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_vespa

class TestVespaConnectorConfig:
    """Unit tests for VespaConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = VespaConnectorConfig(
            address="http://localhost:19071"
        )
        assert config.connector_type == "vespa"
        assert config.url == "http://localhost:19071"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = VespaConnectorConfig(
            address="localhost:19071"
        )
        assert config.url == "http://localhost:19071"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = VespaConnectorConfig(
            address="http://localhost:19071"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "vespa"
        assert config_dict["url"] == "http://localhost:19071"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_vespa

class TestVespaStorageConnection:
    """Unit tests for VespaStorageConnection."""

    def test_connection_requires_vespa_package(self):
        """Test that connection raises error if Vespa package not available."""
        config = VespaConnectorConfig(
            address="http://localhost:19071"
        )
        try:
            connection = VespaStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Vespa connector package" in error_msg)

    def test_connection_requires_vespa_config_type(self):
        """Test that connection requires VespaConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            VespaStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Vespa connector package" in error_msg or
                "Expected VespaConnectorConfig" in error_msg)
