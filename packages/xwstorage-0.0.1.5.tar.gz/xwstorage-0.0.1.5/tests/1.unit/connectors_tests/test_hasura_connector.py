#!/usr/bin/env python3
"""
Unit tests for HasuraConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.hasura_connector import HasuraConnectorConfig, HasuraStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hasura

class TestHasuraConnectorConfig:
    """Unit tests for HasuraConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with GraphQL endpoint."""
        config = HasuraConnectorConfig(
            address="http://localhost:8080/v1/graphql",
            admin_secret="my_secret"
        )
        assert config.connector_type == "hasura"
        assert config.url == "http://localhost:8080/v1/graphql"
        assert config.admin_secret == "my_secret"

    def test_config_initialization_without_graphql_path(self):
        """Test config initialization without /v1/graphql path (auto-added)."""
        config = HasuraConnectorConfig(
            address="http://localhost:8080"
        )
        assert "/v1/graphql" in config.url

    def test_config_to_dict(self):
        """Test config to_dict conversion (admin_secret masked)."""
        config = HasuraConnectorConfig(
            address="http://localhost:8080/v1/graphql",
            admin_secret="secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "hasura"
        assert config_dict["url"] == "http://localhost:8080/v1/graphql"
        assert config_dict["admin_secret"] == "***"  # Secret should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hasura

class TestHasuraStorageConnection:
    """Unit tests for HasuraStorageConnection."""

    def test_connection_requires_hasura_package(self):
        """Test that connection raises error if Hasura package not available."""
        config = HasuraConnectorConfig(
            address="http://localhost:8080/v1/graphql"
        )
        try:
            connection = HasuraStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Hasura connector package" in error_msg)

    def test_connection_requires_hasura_config_type(self):
        """Test that connection requires HasuraConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            HasuraStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Hasura connector package" in error_msg or
                "Expected HasuraConnectorConfig" in error_msg)
