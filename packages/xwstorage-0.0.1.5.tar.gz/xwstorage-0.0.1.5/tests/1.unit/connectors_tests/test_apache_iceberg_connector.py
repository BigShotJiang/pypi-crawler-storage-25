#!/usr/bin/env python3
"""
Unit tests for ApacheIcebergConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.apache_iceberg_connector import ApacheIcebergConnectorConfig, ApacheIcebergStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_iceberg

class TestApacheIcebergConnectorConfig:
    """Unit tests for ApacheIcebergConnectorConfig."""

    def test_config_initialization_with_catalog_uri(self):
        """Test config initialization with catalog URI."""
        config = ApacheIcebergConnectorConfig(
            address="s3://my-bucket/iceberg",
            catalog_type="filesystem"
        )
        assert config.connector_type == "apache_iceberg"
        assert config.catalog_uri == "s3://my-bucket/iceberg"
        assert config.catalog_type == "filesystem"

    def test_config_initialization_with_warehouse(self):
        """Test config initialization with warehouse path."""
        config = ApacheIcebergConnectorConfig(
            address="s3://my-bucket/iceberg",
            catalog_type="filesystem",
            warehouse="/tmp/warehouse"
        )
        assert config.warehouse == "/tmp/warehouse"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ApacheIcebergConnectorConfig(
            address="s3://my-bucket/iceberg",
            catalog_type="hive",
            warehouse="/tmp/warehouse"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "apache_iceberg"
        assert config_dict["catalog_uri"] == "s3://my-bucket/iceberg"
        assert config_dict["catalog_type"] == "hive"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_iceberg

class TestApacheIcebergStorageConnection:
    """Unit tests for ApacheIcebergStorageConnection."""

    def test_connection_requires_iceberg_package(self):
        """Test that connection raises error if Iceberg package not available."""
        config = ApacheIcebergConnectorConfig(
            address="s3://my-bucket/iceberg"
        )
        try:
            connection = ApacheIcebergStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Iceberg connector package" in error_msg)

    def test_connection_requires_iceberg_config_type(self):
        """Test that connection requires ApacheIcebergConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ApacheIcebergStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Iceberg connector package" in error_msg or
                "Expected ApacheIcebergConnectorConfig" in error_msg)
