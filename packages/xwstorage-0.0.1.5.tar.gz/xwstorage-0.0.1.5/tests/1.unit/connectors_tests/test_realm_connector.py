#!/usr/bin/env python3
"""
Unit tests for RealmConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.realm_connector import RealmConnectorConfig, RealmStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_realm

class TestRealmConnectorConfig:
    """Unit tests for RealmConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with database file path."""
        config = RealmConnectorConfig(
            address="/tmp/realm.db"
        )
        assert config.connector_type == "realm"
        assert str(config.db_path) == "/tmp/realm.db"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RealmConnectorConfig(
            address="/tmp/realm.db"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "realm"
        assert config_dict["db_path"] == "/tmp/realm.db"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_realm

class TestRealmStorageConnection:
    """Unit tests for RealmStorageConnection."""

    def test_connection_requires_realm_package(self):
        """Test that connection raises error if Realm package not available."""
        config = RealmConnectorConfig(
            address="/tmp/realm.db"
        )
        try:
            connection = RealmStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Realm connector package" in error_msg)

    def test_connection_requires_realm_config_type(self):
        """Test that connection requires RealmConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RealmStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Realm connector package" in error_msg or
                "Expected RealmConnectorConfig" in error_msg)
