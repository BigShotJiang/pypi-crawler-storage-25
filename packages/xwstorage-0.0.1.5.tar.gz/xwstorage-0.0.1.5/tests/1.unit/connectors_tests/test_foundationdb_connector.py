#!/usr/bin/env python3
"""
Unit tests for FoundationDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.foundationdb_connector import FoundationDBConnectorConfig, FoundationDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_foundationdb

class TestFoundationDBConnectorConfig:
    """Unit tests for FoundationDBConnectorConfig."""

    def test_config_initialization_with_cluster_file(self):
        """Test config initialization with cluster file path."""
        config = FoundationDBConnectorConfig(
            address="/opt/foundationdb/fdb.cluster",
            database="DB"
        )
        assert config.connector_type == "foundationdb"
        assert config.cluster_file == "/opt/foundationdb/fdb.cluster"
        assert config.database == "DB"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = FoundationDBConnectorConfig(
            address="/opt/foundationdb/fdb.cluster",
            database="DB"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "foundationdb"
        assert config_dict["cluster_file"] == "/opt/foundationdb/fdb.cluster"
        assert config_dict["database"] == "DB"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_foundationdb

class TestFoundationDBStorageConnection:
    """Unit tests for FoundationDBStorageConnection."""

    def test_connection_requires_foundationdb_package(self):
        """Test that connection raises error if FoundationDB package not available."""
        config = FoundationDBConnectorConfig(
            address="/opt/foundationdb/fdb.cluster"
        )
        try:
            connection = FoundationDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "FoundationDB connector package" in error_msg)

    def test_connection_requires_foundationdb_config_type(self):
        """Test that connection requires FoundationDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            FoundationDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "FoundationDB connector package" in error_msg or
                "Expected FoundationDBConnectorConfig" in error_msg)
