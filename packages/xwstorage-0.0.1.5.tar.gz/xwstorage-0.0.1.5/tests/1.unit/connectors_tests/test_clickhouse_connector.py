#!/usr/bin/env python3
"""
Unit tests for ClickHouseConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.clickhouse_connector import ClickHouseConnectorConfig, ClickHouseStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_clickhouse

class TestClickHouseConnectorConfig:
    """Unit tests for ClickHouseConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = ClickHouseConnectorConfig(
            address="localhost:9000",
            database="default",
            username="default",
            password="password"
        )
        assert config.connector_type == "clickhouse"
        assert config.database == "default"
        assert config.username == "default"

    def test_config_initialization_with_host_port_database(self):
        """Test config initialization with host:port/database format."""
        config = ClickHouseConnectorConfig(
            address="localhost:9000/default",
            username="default"
        )
        assert config.database == "default"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = ClickHouseConnectorConfig(
            address="localhost:9000",
            database="default",
            username="default",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "clickhouse"
        assert config_dict["database"] == "default"
        assert config_dict["username"] == "default"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_clickhouse

class TestClickHouseStorageConnection:
    """Unit tests for ClickHouseStorageConnection."""

    def test_connection_requires_clickhouse_package(self):
        """Test that connection raises error if ClickHouse package not available."""
        config = ClickHouseConnectorConfig(
            address="localhost:9000",
            database="default"
        )
        try:
            connection = ClickHouseStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_clickhouse_config_type(self):
        """Test that connection requires ClickHouseConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ClickHouseStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected ClickHouseConnectorConfig" in error_msg)
