#!/usr/bin/env python3
"""
Unit tests for ConsulConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.consul_connector import ConsulConnectorConfig, ConsulStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_consul

class TestConsulConnectorConfig:
    """Unit tests for ConsulConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = ConsulConnectorConfig(
            address="localhost:8500"
        )
        assert config.connector_type == "consul"
        assert config.host == "localhost"
        assert config.port == 8500

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 8500)."""
        config = ConsulConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 8500

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ConsulConnectorConfig(
            address="localhost:8500"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "consul"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 8500
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_consul

class TestConsulStorageConnection:
    """Unit tests for ConsulStorageConnection."""

    def test_connection_requires_consul_package(self):
        """Test that connection raises error if Consul package not available."""
        config = ConsulConnectorConfig(
            address="localhost:8500"
        )
        try:
            connection = ConsulStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_consul_config_type(self):
        """Test that connection requires ConsulConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ConsulStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected ConsulConnectorConfig" in error_msg)
