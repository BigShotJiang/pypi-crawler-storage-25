#!/usr/bin/env python3
"""
Unit tests for MarkLogicConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.marklogic_connector import MarkLogicConnectorConfig, MarkLogicStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_marklogic

class TestMarkLogicConnectorConfig:
    """Unit tests for MarkLogicConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with server URL."""
        config = MarkLogicConnectorConfig(
            address="http://localhost:8000",
            database="Documents",
            username="admin",
            password="admin"
        )
        assert config.connector_type == "marklogic"
        assert config.url == "http://localhost:8000"
        assert config.database == "Documents"
        assert config.username == "admin"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = MarkLogicConnectorConfig(
            address="http://localhost:8000",
            database="Documents",
            username="admin",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "marklogic"
        assert config_dict["url"] == "http://localhost:8000"
        assert config_dict["database"] == "Documents"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_marklogic

class TestMarkLogicStorageConnection:
    """Unit tests for MarkLogicStorageConnection."""

    def test_connection_requires_marklogic_package(self):
        """Test that connection raises error if MarkLogic package not available."""
        config = MarkLogicConnectorConfig(
            address="http://localhost:8000",
            database="Documents"
        )
        try:
            connection = MarkLogicStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "MarkLogic connector package" in error_msg)

    def test_connection_requires_marklogic_config_type(self):
        """Test that connection requires MarkLogicConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MarkLogicStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "MarkLogic connector package" in error_msg or
                "Expected MarkLogicConnectorConfig" in error_msg)
