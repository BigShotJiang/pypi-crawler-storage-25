#!/usr/bin/env python3
"""
Unit tests for PostgreSQLConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.postgresql_connector import PostgreSQLConnectorConfig, PostgreSQLStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_postgresql

class TestPostgreSQLConnectorConfig:
    """Unit tests for PostgreSQLConnectorConfig."""

    def test_config_initialization_with_table_name(self):
        """Test config initialization with just table name."""
        config = PostgreSQLConnectorConfig(
            address="test_table",
            host="localhost",
            port=5432,
            database="testdb",
            username="postgres",
            password="password"
        )
        assert config.connector_type == "postgresql"
        assert config.table_name == "test_table"
        assert config.host == "localhost"
        assert config.port == 5432
        assert config.database == "testdb"

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string."""
        config = PostgreSQLConnectorConfig(
            address="localhost:5432/testdb",
            table_name="test_table",
            username="postgres",
            password="password"
        )
        assert config.table_name == "test_table"
        assert config.database == "testdb"

    def test_config_initialization_with_postgresql_url(self):
        """Test config initialization with postgresql:// URL."""
        config = PostgreSQLConnectorConfig(
            address="postgresql://postgres:password@localhost:5432/testdb",
            table_name="test_table"
        )
        assert config.table_name == "test_table"
        assert config.database == "testdb"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password masked)."""
        config = PostgreSQLConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb",
            username="postgres",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "postgresql"
        assert config_dict["table_name"] == "test_table"
        assert config_dict["host"] == "localhost"
        assert "password" not in config_dict or config_dict["password"] == "***"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_postgresql

class TestPostgreSQLStorageConnection:
    """Unit tests for PostgreSQLStorageConnection."""

    def test_connection_requires_postgresql_package(self):
        """Test that connection raises error if PostgreSQL package not available."""
        config = PostgreSQLConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb"
        )
        try:
            connection = PostgreSQLStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_postgresql_config_type(self):
        """Test that connection requires PostgreSQLConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            PostgreSQLStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected PostgreSQLConnectorConfig" in error_msg)
