#!/usr/bin/env python3
"""
Unit tests for SAPASEConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.sap_ase_connector import SAPASEConnectorConfig, SAPASEStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sap_ase

class TestSAPASEConnectorConfig:
    """Unit tests for SAPASEConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = SAPASEConnectorConfig(
            address="localhost:5000",
            database="mydb",
            username="sa",
            password="password"
        )
        assert config.connector_type == "sap_ase"
        assert config.database == "mydb"
        assert config.username == "sa"
        assert config.host == "localhost"
        assert config.port == 5000

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 5000)."""
        config = SAPASEConnectorConfig(
            address="localhost",
            database="mydb",
            username="sa",
            password="password"
        )
        assert config.host == "localhost"
        assert config.port == 5000

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = SAPASEConnectorConfig(
            address="localhost:5000",
            database="mydb",
            username="sa",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "sap_ase"
        assert config_dict["database"] == "mydb"
        assert config_dict["username"] == "sa"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sap_ase

class TestSAPASEStorageConnection:
    """Unit tests for SAPASEStorageConnection."""

    def test_connection_requires_sap_ase_package(self):
        """Test that connection raises error if SAP ASE package not available."""
        config = SAPASEConnectorConfig(
            address="localhost:5000",
            database="mydb",
            username="sa",
            password="password"
        )
        try:
            connection = SAPASEStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_sap_ase_config_type(self):
        """Test that connection requires SAPASEConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            SAPASEStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected SAPASEConnectorConfig" in error_msg)
