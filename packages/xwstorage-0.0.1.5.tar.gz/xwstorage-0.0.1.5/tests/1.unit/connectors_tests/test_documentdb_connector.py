#!/usr/bin/env python3
"""
Unit tests for Amazon DocumentDB connector.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import patch
from exonware.xwstorage.connectors.documentdb_connector import (
    DocumentDBConnectorConfig,
    DocumentDBStorageConnection
)
from exonware.xwstorage.errors import XWLocationError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_documentdb

class TestDocumentDBConnectorConfig:
    """Unit tests for DocumentDBConnectorConfig."""

    def test_config_initialization(self):
        """Test config initialization."""
        config = DocumentDBConnectorConfig(
            address="test_collection",
            host="docdb-cluster.cluster-xxxxx.us-east-1.docdb.amazonaws.com",
            port=27017,
            database="testdb",
            username="admin",
            password="password",
            tls_enabled=True,
            tls_ca_file="/path/to/ca.pem"
        )
        assert config.connector_type == "documentdb"
        assert config.tls_enabled is True
        assert config.tls_ca_file == "/path/to/ca.pem"
        assert config.replica_set == "rs0"

    def test_config_tls_enabled_by_default(self):
        """Test that TLS is enabled by default."""
        config = DocumentDBConnectorConfig(
            address="test_collection",
            host="cluster.docdb.amazonaws.com",
            database="testdb"
        )
        # TLS should be enabled even if not explicitly set
        assert config.tls_enabled is True

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = DocumentDBConnectorConfig(
            address="test_collection",
            host="cluster.docdb.amazonaws.com",
            database="testdb",
            tls_enabled=True
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "documentdb"
        assert config_dict["tls_enabled"] is True
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_documentdb

class TestDocumentDBStorageConnection:
    """Unit tests for DocumentDBStorageConnection."""

    def test_connection_requires_mongodb_connector(self):
        """Test that connection requires MongoDB connector."""
        config = DocumentDBConnectorConfig(
            address="test_collection",
            host="cluster.docdb.amazonaws.com",
            database="testdb"
        )
        with patch('exonware.xwstorage.connectors.documentdb_connector.MONGODB_AVAILABLE', False):
            with pytest.raises(XWLocationError, match="MongoDB connector not available"):
                DocumentDBStorageConnection(config, "json")

    def test_connection_with_invalid_config_type(self):
        """Test connection requires DocumentDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with patch('exonware.xwstorage.connectors.documentdb_connector.MONGODB_AVAILABLE', True):
            with pytest.raises(XWLocationError, match="Expected DocumentDBConnectorConfig"):
                DocumentDBStorageConnection(local_config, "json")
