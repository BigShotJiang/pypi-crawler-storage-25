#!/usr/bin/env python3
"""
Unit tests for DuckDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.duckdb_connector import DuckDBConnectorConfig, DuckDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_duckdb

class TestDuckDBConnectorConfig:
    """Unit tests for DuckDBConnectorConfig."""

    def test_config_initialization_with_file_path(self):
        """Test config initialization with file path."""
        config = DuckDBConnectorConfig(
            address="/tmp/testdb.duckdb"
        )
        assert config.connector_type == "duckdb"
        assert config.database_path == "/tmp/testdb.duckdb"

    def test_config_initialization_in_memory(self):
        """Test config initialization with in-memory database."""
        config = DuckDBConnectorConfig(
            address=":memory:"
        )
        assert config.database_path == ":memory:"

    def test_config_initialization_with_relative_path(self):
        """Test config initialization with relative path."""
        config = DuckDBConnectorConfig(
            address="./data/testdb.duckdb"
        )
        assert config.database_path == "./data/testdb.duckdb"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = DuckDBConnectorConfig(
            address="/tmp/testdb.duckdb"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "duckdb"
        assert config_dict["database_path"] == "/tmp/testdb.duckdb"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_duckdb

class TestDuckDBStorageConnection:
    """Unit tests for DuckDBStorageConnection."""

    def test_connection_requires_duckdb_package(self):
        """Test that connection raises error if DuckDB package not available."""
        config = DuckDBConnectorConfig(
            address=":memory:"
        )
        try:
            connection = DuckDBStorageConnection(config, "json")
            # If we get here, duckdb package is available
            assert connection._config == config
        except XWLocationError as e:
            # Expected if duckdb package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_duckdb_config_type(self):
        """Test that connection requires DuckDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DuckDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected DuckDBConnectorConfig" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = DuckDBConnectorConfig(
            address=":memory:"
        )
        try:
            connection = DuckDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("DuckDB package not installed")

    def test_connection_serializer_format(self):
        """Test connection handles different serializer formats."""
        config = DuckDBConnectorConfig(
            address=":memory:"
        )
        try:
            # Test JSON format
            connection = DuckDBStorageConnection(config, "json")
            assert connection._serializer_format == "json"
        except XWLocationError:
            pytest.skip("DuckDB package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_duckdb
@pytest.mark.skip(reason="Operations tests require DuckDB package and may have side effects")

class TestDuckDBStorageConnectionOperations:
    """Unit tests for DuckDB storage operations."""
    @pytest.fixture

    def duckdb_config(self):
        """DuckDB config for testing (in-memory)."""
        return DuckDBConnectorConfig(
            address=":memory:"
        )
    @pytest.mark.asyncio

    async def test_duckdb_save_and_load(self, duckdb_config, sample_data, test_path):
        """Test DuckDB save and load operations."""
        connection = DuckDBStorageConnection(duckdb_config, "json")
        await connection.save(sample_data, test_path)
        loaded = await connection.load(test_path)
        assert loaded == sample_data
