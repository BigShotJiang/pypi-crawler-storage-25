#!/usr/bin/env python3
"""
Unit tests for ActiveMQConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.activemq_connector import ActiveMQConnectorConfig, ActiveMQStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_activemq

class TestActiveMQConnectorConfig:
    """Unit tests for ActiveMQConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = ActiveMQConnectorConfig(
            address="localhost:61613"
        )
        assert config.connector_type == "activemq"
        assert config.host == "localhost"
        assert config.port == 61613

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 61613)."""
        config = ActiveMQConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 61613

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ActiveMQConnectorConfig(
            address="localhost:61613"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "activemq"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 61613
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_activemq

class TestActiveMQStorageConnection:
    """Unit tests for ActiveMQStorageConnection."""

    def test_connection_requires_activemq_package(self):
        """Test that connection raises error if ActiveMQ package not available."""
        config = ActiveMQConnectorConfig(
            address="localhost:61613"
        )
        try:
            connection = ActiveMQStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_activemq_config_type(self):
        """Test that connection requires ActiveMQConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ActiveMQStorageConnection(local_config, "json")
        error_msg = str(exc_info.value).lower()
        assert "not installed" in error_msg or "activemqconnectorconfig" in error_msg.replace(
            " ", ""
        )
