#!/usr/bin/env python3
"""
Unit tests for HBaseConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.hbase_connector import HBaseConnectorConfig, HBaseStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hbase

class TestHBaseConnectorConfig:
    """Unit tests for HBaseConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = HBaseConnectorConfig(
            address="localhost:9090"
        )
        assert config.connector_type == "hbase"
        assert config.host == "localhost"
        assert config.port == 9090

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 9090)."""
        config = HBaseConnectorConfig(
            address="localhost"
        )
        assert config.host == "localhost"
        assert config.port == 9090

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = HBaseConnectorConfig(
            address="localhost:9090"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "hbase"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 9090
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_hbase

class TestHBaseStorageConnection:
    """Unit tests for HBaseStorageConnection."""

    def test_connection_requires_hbase_package(self):
        """Test that connection raises error if HBase package not available."""
        config = HBaseConnectorConfig(
            address="localhost:9090"
        )
        try:
            connection = HBaseStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_hbase_config_type(self):
        """Test that connection requires HBaseConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            HBaseStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected HBaseConnectorConfig" in error_msg)
