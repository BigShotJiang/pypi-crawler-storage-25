#!/usr/bin/env python3
"""
Unit tests for RisingWaveConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.risingwave_connector import RisingWaveConnectorConfig, RisingWaveStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_risingwave

class TestRisingWaveConnectorConfig:
    """Unit tests for RisingWaveConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = RisingWaveConnectorConfig(
            address="localhost:4566",
            database="dev",
            user="root",
            password="password"
        )
        assert config.connector_type == "risingwave"
        assert config.database == "dev"
        assert config.user == "root"
        assert "postgresql://" in config.connection_string

    def test_config_initialization_with_connection_string(self):
        """Test config initialization with connection string."""
        config = RisingWaveConnectorConfig(
            address="postgresql://root:password@localhost:4566/dev",
            database="dev"
        )
        assert config.connection_string == "postgresql://root:password@localhost:4566/dev"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = RisingWaveConnectorConfig(
            address="localhost:4566",
            database="dev",
            user="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "risingwave"
        assert config_dict["database"] == "dev"
        assert config_dict["user"] == "root"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_risingwave

class TestRisingWaveStorageConnection:
    """Unit tests for RisingWaveStorageConnection."""

    def test_connection_requires_postgresql_package(self):
        """Test that connection raises error if PostgreSQL package not available."""
        config = RisingWaveConnectorConfig(
            address="localhost:4566",
            database="dev"
        )
        try:
            connection = RisingWaveStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_risingwave_config_type(self):
        """Test that connection requires RisingWaveConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RisingWaveStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected RisingWaveConnectorConfig" in error_msg)
