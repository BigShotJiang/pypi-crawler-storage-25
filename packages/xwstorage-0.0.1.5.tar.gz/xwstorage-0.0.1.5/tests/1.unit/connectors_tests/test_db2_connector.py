#!/usr/bin/env python3
"""
Unit tests for DB2Connector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.db2_connector import DB2ConnectorConfig, DB2StorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_db2

class TestDB2ConnectorConfig:
    """Unit tests for DB2ConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = DB2ConnectorConfig(
            address="localhost:50000/sample",
            database="sample",
            username="db2admin",
            password="password"
        )
        assert config.connector_type == "db2"
        assert config.database == "sample"
        assert config.username == "db2admin"
        assert config.port == 50000

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = DB2ConnectorConfig(
            address="localhost:50000/sample",
            database="sample",
            username="db2admin",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "db2"
        assert config_dict["database"] == "sample"
        assert config_dict["username"] == "db2admin"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_db2

class TestDB2StorageConnection:
    """Unit tests for DB2StorageConnection."""

    def test_connection_requires_db2_package(self):
        """Test that connection raises error if DB2 package not available."""
        config = DB2ConnectorConfig(
            address="localhost:50000/sample",
            database="sample",
            username="db2admin",
            password="password"
        )
        try:
            connection = DB2StorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_db2_config_type(self):
        """Test that connection requires DB2ConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DB2StorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected DB2ConnectorConfig" in error_msg)
