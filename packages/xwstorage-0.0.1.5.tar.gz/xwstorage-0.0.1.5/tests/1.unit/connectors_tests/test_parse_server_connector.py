#!/usr/bin/env python3
"""
Unit tests for ParseServerConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.parse_server_connector import ParseServerConnectorConfig, ParseServerStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_parse_server

class TestParseServerConnectorConfig:
    """Unit tests for ParseServerConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with server URL."""
        config = ParseServerConnectorConfig(
            address="http://localhost:1337/parse",
            application_id="my_app_id",
            rest_api_key="my_api_key"
        )
        assert config.connector_type == "parse_server"
        assert config.base_url == "http://localhost:1337/parse"
        assert config.application_id == "my_app_id"
        assert config.rest_api_key == "my_api_key"

    def test_config_initialization_without_parse_path(self):
        """Test config initialization without /parse path (auto-added)."""
        config = ParseServerConnectorConfig(
            address="http://localhost:1337",
            application_id="my_app_id"
        )
        assert "/parse" in config.base_url

    def test_config_to_dict(self):
        """Test config to_dict conversion (keys not fully exposed)."""
        config = ParseServerConnectorConfig(
            address="http://localhost:1337/parse",
            application_id="my_app_id",
            rest_api_key="my_api_key",
            master_key="my_master_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "parse_server"
        assert config_dict["base_url"] == "http://localhost:1337/parse"
        assert config_dict["application_id"] == "my_app_id"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_parse_server

class TestParseServerStorageConnection:
    """Unit tests for ParseServerStorageConnection."""

    def test_connection_requires_parse_server_package(self):
        """Test that connection raises error if Parse Server package not available."""
        config = ParseServerConnectorConfig(
            address="http://localhost:1337/parse",
            application_id="my_app_id"
        )
        try:
            connection = ParseServerStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Parse Server connector package" in error_msg)

    def test_connection_requires_parse_server_config_type(self):
        """Test that connection requires ParseServerConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ParseServerStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Parse Server connector package" in error_msg or
                "Expected ParseServerConnectorConfig" in error_msg)
