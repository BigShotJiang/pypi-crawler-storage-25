#!/usr/bin/env python3
"""
Unit tests for DeltaLakeConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.delta_lake_connector import DeltaLakeConnectorConfig, DeltaLakeStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_delta_lake

class TestDeltaLakeConnectorConfig:
    """Unit tests for DeltaLakeConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with table path."""
        config = DeltaLakeConnectorConfig(
            address="/tmp/delta_table"
        )
        assert config.connector_type == "delta_lake"
        assert str(config.table_path) == "/tmp/delta_table"

    def test_config_initialization_with_spark_url(self):
        """Test config initialization with Spark URL."""
        config = DeltaLakeConnectorConfig(
            address="/tmp/delta_table",
            spark_url="spark://localhost:7077"
        )
        assert config.spark_url == "spark://localhost:7077"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = DeltaLakeConnectorConfig(
            address="/tmp/delta_table",
            spark_url="spark://localhost:7077"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "delta_lake"
        assert config_dict["table_path"] == "/tmp/delta_table"
        assert config_dict["spark_url"] == "spark://localhost:7077"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_delta_lake

class TestDeltaLakeStorageConnection:
    """Unit tests for DeltaLakeStorageConnection."""

    def test_connection_requires_delta_lake_package(self):
        """Test that connection raises error if Delta Lake package not available."""
        config = DeltaLakeConnectorConfig(
            address="/tmp/delta_table"
        )
        try:
            connection = DeltaLakeStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Delta Lake connector package" in error_msg)

    def test_connection_requires_delta_lake_config_type(self):
        """Test that connection requires DeltaLakeConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DeltaLakeStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Delta Lake connector package" in error_msg or
                "Expected DeltaLakeConnectorConfig" in error_msg)
