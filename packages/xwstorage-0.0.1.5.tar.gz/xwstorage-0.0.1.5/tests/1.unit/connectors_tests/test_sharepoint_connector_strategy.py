#!/usr/bin/env python3
"""
Unit tests for SharePointConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.sharepoint_connector_strategy import SharePointConnector
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sharepoint

class TestSharePointConnector:
    """Unit tests for SharePointConnector."""

    def test_connector_initialization_with_site_url(self):
        """Test connector initialization with site URL."""
        connector = SharePointConnector(
            site_url="https://yourdomain.sharepoint.com/sites/sitename",
            client_id="client_id",
            client_secret="client_secret"
        )
        assert connector.site_url == "https://yourdomain.sharepoint.com/sites/sitename"
        assert connector.client_id == "client_id"
        assert connector.client_secret == "client_secret"

    def test_connector_initialization_with_username_password(self):
        """Test connector initialization with username/password."""
        connector = SharePointConnector(
            site_url="https://yourdomain.sharepoint.com/sites/sitename",
            username="user@domain.com",
            password="password"
        )
        assert connector.username == "user@domain.com"
        assert connector.password == "password"

    def test_connector_type(self):
        """Test connector type property."""
        connector = SharePointConnector(
            site_url="https://yourdomain.sharepoint.com/sites/sitename",
            client_id="client_id",
            client_secret="client_secret"
        )
        assert connector.connector_type == "sharepoint"
