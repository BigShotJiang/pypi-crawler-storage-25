#!/usr/bin/env python3
"""
Unit tests for Scaleway Object Storage connector.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import patch
from exonware.xwstorage.connectors.scaleway_object_storage_connector import (
    ScalewayObjectStorageConnectorConfig,
    ScalewayObjectStorageConnection
)
from exonware.xwstorage.errors import XWLocationError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_scaleway

class TestScalewayObjectStorageConnectorConfig:
    """Unit tests for ScalewayObjectStorageConnectorConfig."""

    def test_config_initialization(self):
        """Test config initialization."""
        config = ScalewayObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="fr-par",
            access_key_id="test-key",
            secret_access_key="test-secret"
        )
        assert config.connector_type == "scaleway_object_storage"
        assert config.bucket == "test-bucket"
        assert config.region == "fr-par"
        assert config.endpoint_url == "https://s3.fr-par.scw.cloud"

    def test_config_with_custom_endpoint(self):
        """Test config with custom endpoint URL."""
        config = ScalewayObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="fr-par",
            access_key_id="test-key",
            secret_access_key="test-secret",
            endpoint_url="https://custom.endpoint.com"
        )
        assert config.endpoint_url == "https://custom.endpoint.com"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ScalewayObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="fr-par",
            access_key_id="test-key",
            secret_access_key="test-secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "scaleway_object_storage"
        assert config_dict["bucket"] == "test-bucket"
        assert "secret_access_key" not in config_dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_scaleway

class TestScalewayObjectStorageConnection:
    """Unit tests for ScalewayObjectStorageConnection."""

    def test_connection_requires_s3_connector(self):
        """Test that connection requires S3 connector."""
        config = ScalewayObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="fr-par",
            access_key_id="test-key",
            secret_access_key="test-secret"
        )
        with patch('exonware.xwstorage.connectors.scaleway_object_storage_connector.S3_AVAILABLE', False):
            with pytest.raises(XWLocationError, match="S3 connector not available"):
                ScalewayObjectStorageConnection(config, "json")

    def test_connection_with_invalid_config_type(self):
        """Test connection requires ScalewayObjectStorageConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with patch('exonware.xwstorage.connectors.scaleway_object_storage_connector.S3_AVAILABLE', True):
            with pytest.raises(XWLocationError, match="Expected ScalewayObjectStorageConnectorConfig"):
                ScalewayObjectStorageConnection(local_config, "json")
