#!/usr/bin/env python3
"""
Unit tests for Warp10Connector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.warp10_connector import Warp10ConnectorConfig, Warp10StorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_warp10

class TestWarp10ConnectorConfig:
    """Unit tests for Warp10ConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = Warp10ConnectorConfig(
            address="http://localhost:8080",
            token="my_token"
        )
        assert config.connector_type == "warp10"
        assert config.base_url == "http://localhost:8080"
        assert config.token == "my_token"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = Warp10ConnectorConfig(
            address="localhost:8080"
        )
        assert config.base_url == "http://localhost:8080"

    def test_config_to_dict(self):
        """Test config to_dict conversion (token masked)."""
        config = Warp10ConnectorConfig(
            address="http://localhost:8080",
            token="secret_token"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "warp10"
        assert config_dict["base_url"] == "http://localhost:8080"
        if "token" in config_dict:
            assert config_dict["token"] == "***"  # Token should be masked
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_warp10

class TestWarp10StorageConnection:
    """Unit tests for Warp10StorageConnection."""

    def test_connection_requires_warp10_package(self):
        """Test that connection raises error if Warp 10 package not available."""
        config = Warp10ConnectorConfig(
            address="http://localhost:8080"
        )
        try:
            connection = Warp10StorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Warp 10 connector package" in error_msg)

    def test_connection_requires_warp10_config_type(self):
        """Test that connection requires Warp10ConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            Warp10StorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Warp 10 connector package" in error_msg or
                "Expected Warp10ConnectorConfig" in error_msg)
