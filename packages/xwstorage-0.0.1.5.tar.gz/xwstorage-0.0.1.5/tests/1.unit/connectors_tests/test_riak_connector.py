#!/usr/bin/env python3
"""
Unit tests for RiakConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.riak_connector import RiakConnectorConfig, RiakStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_riak

class TestRiakConnectorConfig:
    """Unit tests for RiakConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = RiakConnectorConfig(
            address="localhost:8087",
            bucket="my_bucket"
        )
        assert config.connector_type == "riak"
        assert config.host == "localhost"
        assert config.port == 8087
        assert config.bucket == "my_bucket"
        assert config.protocol == "pbc"  # Default Protocol Buffers

    def test_config_initialization_with_http_protocol(self):
        """Test config initialization with HTTP protocol."""
        config = RiakConnectorConfig(
            address="localhost:8098",
            bucket="my_bucket",
            protocol="http"
        )
        assert config.protocol == "http"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 8087)."""
        config = RiakConnectorConfig(
            address="localhost",
            bucket="my_bucket"
        )
        assert config.host == "localhost"
        assert config.port == 8087

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RiakConnectorConfig(
            address="localhost:8087",
            bucket="my_bucket",
            protocol="pbc"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "riak"
        assert config_dict["host"] == "localhost"
        assert config_dict["port"] == 8087
        assert config_dict["bucket"] == "my_bucket"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_riak

class TestRiakStorageConnection:
    """Unit tests for RiakStorageConnection."""

    def test_connection_requires_riak_package(self):
        """Test that connection raises error if Riak package not available."""
        config = RiakConnectorConfig(
            address="localhost:8087",
            bucket="my_bucket"
        )
        try:
            connection = RiakStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_riak_config_type(self):
        """Test that connection requires RiakConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            RiakStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected RiakConnectorConfig" in error_msg)
