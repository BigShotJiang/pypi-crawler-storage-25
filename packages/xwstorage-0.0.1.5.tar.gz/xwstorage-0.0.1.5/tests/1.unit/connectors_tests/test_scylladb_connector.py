#!/usr/bin/env python3
"""
Unit tests for ScyllaDB connector.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import patch
from exonware.xwstorage.connectors.scylladb_connector import (
    ScyllaDBConnectorConfig,
    ScyllaDBStorageConnection
)
from exonware.xwstorage.errors import XWLocationError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_scylladb

class TestScyllaDBConnectorConfig:
    """Unit tests for ScyllaDBConnectorConfig."""

    def test_config_initialization(self):
        """Test config initialization."""
        config = ScyllaDBConnectorConfig(
            keyspace="test_keyspace",
            table="test_table",
            hosts=["localhost"],
            port=9042,
            username="scylla",
            password="password"
        )
        assert config.connector_type == "scylladb"
        assert config.keyspace == "test_keyspace"
        assert config.table == "test_table"
        assert config.hosts == ["localhost"]
        assert config.port == 9042
        assert config.consistency_level == "QUORUM"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = ScyllaDBConnectorConfig(
            keyspace="test_keyspace",
            table="test_table",
            hosts=["localhost"],
            port=9042
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "scylladb"
        assert config_dict["keyspace"] == "test_keyspace"
        assert config_dict["table"] == "test_table"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_scylladb

class TestScyllaDBStorageConnection:
    """Unit tests for ScyllaDBStorageConnection."""

    def test_connection_requires_cassandra_connector(self):
        """Test that connection requires Cassandra connector."""
        config = ScyllaDBConnectorConfig(
            keyspace="test_keyspace",
            table="test_table",
            hosts=["localhost"]
        )
        with patch('exonware.xwstorage.connectors.scylladb_connector.CASSANDRA_AVAILABLE', False):
            with pytest.raises(XWLocationError, match="Cassandra connector not available"):
                ScyllaDBStorageConnection(config, "json")

    def test_connection_with_invalid_config_type(self):
        """Test connection requires ScyllaDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with patch('exonware.xwstorage.connectors.scylladb_connector.CASSANDRA_AVAILABLE', True):
            with pytest.raises(XWLocationError, match="Expected ScyllaDBConnectorConfig"):
                ScyllaDBStorageConnection(local_config, "json")
