#!/usr/bin/env python3
"""
Comprehensive unit tests for PostgreSQLConnector - 100% coverage target.
Tests all code paths including error handling and edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from exonware.xwstorage.connectors.postgresql_connector import (
    PostgreSQLConnectorConfig, PostgreSQLStorageConnection, PostgreSQLTransaction
)
from exonware.xwstorage.errors import XWLocationError, XWStorageError
from exonware.xwstorage.defs import IsolationLevel
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_postgresql

class TestPostgreSQLConnectorConfigComprehensive:
    """Comprehensive tests for PostgreSQLConnectorConfig."""

    def test_config_address_parsing_variations(self):
        """Test various address string parsing scenarios."""
        # Test with connection string
        config = PostgreSQLConnectorConfig(
            address="localhost:5432/mydb",
            table_name="mytable",
            username="user",
            password="pass"
        )
        assert config.host is None or config.host == "localhost"
        assert config.database == "mydb"
        assert config.table_name == "mytable"
        # Test with just table name
        config2 = PostgreSQLConnectorConfig(
            address="mytable",
            host="localhost",
            port=5432,
            database="mydb",
            username="user",
            password="pass"
        )
        assert config2.table_name == "mytable"
        assert config2.database == "mydb"
        # Test with postgresql:// URL
        config3 = PostgreSQLConnectorConfig(
            address="postgresql://user:pass@localhost:5432/mydb",
            table_name="mytable"
        )
        assert config3.table_name == "mytable"

    def test_config_to_dict_with_username(self):
        """Test to_dict includes username but not password."""
        config = PostgreSQLConnectorConfig(
            address="test_table",
            host="localhost",
            database="testdb",
            username="testuser",
            password="secret"
        )
        config_dict = config.to_dict()
        assert "username" in config_dict
        assert config_dict["username"] == "testuser"
        assert "password" not in config_dict or config_dict["password"] == "***"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_postgresql

class TestPostgreSQLStorageConnectionComprehensive:
    """Comprehensive tests for PostgreSQLStorageConnection."""
    @pytest.fixture

    def pg_config(self):
        """PostgreSQL config for testing."""
        return PostgreSQLConnectorConfig(
            address="test_table",
            host="localhost",
            port=5432,
            database="testdb",
            username="postgres",
            password="password"
        )
    @pytest.mark.asyncio

    async def test_connection_pool_creation_async(self, pg_config):
        """Test async pool creation with asyncpg."""
        with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_ASYNC', True):
                with patch('asyncpg.create_pool', new_callable=AsyncMock) as mock_pool:
                    mock_pool.return_value = AsyncMock()
                    connection = PostgreSQLStorageConnection(pg_config, "json")
                    pool = await connection._get_pool()
                    assert pool is not None
    @pytest.mark.asyncio

    async def test_connection_pool_creation_sync(self, pg_config):
        """Test sync pool creation with psycopg2."""
        with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_AVAILABLE', True):
            with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_ASYNC', False):
                with patch('exonware.xwstorage.connectors.postgresql_connector.pool') as mock_pool_module:
                    mock_pool = MagicMock()
                    mock_pool_module.SimpleConnectionPool.return_value = mock_pool
                    connection = PostgreSQLStorageConnection(pg_config, "json")
                    pool = await connection._get_pool()
                    assert pool is not None

    def test_connection_requires_postgresql_package(self, pg_config):
        """Test that connection raises error if PostgreSQL package not available."""
        with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_AVAILABLE', False):
            with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_ASYNC', False):
                with pytest.raises(XWLocationError) as exc_info:
                    PostgreSQLStorageConnection(pg_config, "json")
                error_msg = str(exc_info.value)
                assert "not installed" in error_msg.lower()

    def test_connection_requires_postgresql_config_type(self):
        """Test that connection requires PostgreSQLConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            PostgreSQLStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected PostgreSQLConnectorConfig" in error_msg)
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_postgresql

class TestPostgreSQLTransactionComprehensive:
    """Comprehensive tests for PostgreSQLTransaction."""
    @pytest.fixture

    def mock_async_connection(self):
        """Mock async connection."""
        conn = AsyncMock()
        conn.commit = AsyncMock()
        conn.rollback = AsyncMock()
        conn.execute = AsyncMock()
        return conn
    @pytest.fixture

    def mock_sync_connection(self):
        """Mock sync connection."""
        conn = MagicMock()
        cursor = MagicMock()
        conn.cursor.return_value = cursor
        return conn
    @pytest.mark.asyncio

    async def test_transaction_commit_async(self, mock_async_connection):
        """Test async transaction commit."""
        with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_ASYNC', True):
            transaction = PostgreSQLTransaction(
                mock_async_connection,
                "tx123",
                IsolationLevel.READ_COMMITTED
            )
            await transaction.commit()
            mock_async_connection.commit.assert_called_once()
    @pytest.mark.asyncio

    async def test_transaction_commit_sync(self, mock_sync_connection):
        """Test sync transaction commit."""
        with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_ASYNC', False):
            transaction = PostgreSQLTransaction(
                mock_sync_connection,
                "tx123",
                IsolationLevel.READ_COMMITTED
            )
            await transaction.commit()
            mock_sync_connection.commit.assert_called_once()
    @pytest.mark.asyncio

    async def test_transaction_rollback_async(self, mock_async_connection):
        """Test async transaction rollback."""
        with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_ASYNC', True):
            transaction = PostgreSQLTransaction(
                mock_async_connection,
                "tx123",
                IsolationLevel.READ_COMMITTED
            )
            await transaction.rollback()
            mock_async_connection.rollback.assert_called_once()
    @pytest.mark.asyncio

    async def test_transaction_savepoint_async(self, mock_async_connection):
        """Test async savepoint creation."""
        with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_ASYNC', True):
            transaction = PostgreSQLTransaction(
                mock_async_connection,
                "tx123",
                IsolationLevel.READ_COMMITTED
            )
            await transaction.create_savepoint("sp1")
            mock_async_connection.execute.assert_called_once()
            assert "sp1" in transaction._savepoints
    @pytest.mark.asyncio

    async def test_transaction_savepoint_sync(self, mock_sync_connection):
        """Test sync savepoint creation."""
        with patch('exonware.xwstorage.connectors.postgresql_connector.POSTGRESQL_ASYNC', False):
            transaction = PostgreSQLTransaction(
                mock_sync_connection,
                "tx123",
                IsolationLevel.READ_COMMITTED
            )
            await transaction.create_savepoint("sp1")
            mock_sync_connection.cursor.assert_called()
            assert "sp1" in transaction._savepoints
