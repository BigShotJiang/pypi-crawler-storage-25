#!/usr/bin/env python3
"""
Unit tests for PulsarConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.pulsar_connector import PulsarConnectorConfig, PulsarStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_pulsar

class TestPulsarConnectorConfig:
    """Unit tests for PulsarConnectorConfig."""

    def test_config_initialization_with_pulsar_url(self):
        """Test config initialization with pulsar:// URL."""
        config = PulsarConnectorConfig(
            address="pulsar://localhost:6650"
        )
        assert config.connector_type == "pulsar"
        assert config.service_url == "pulsar://localhost:6650"

    def test_config_initialization_with_ssl_url(self):
        """Test config initialization with pulsar+ssl:// URL."""
        config = PulsarConnectorConfig(
            address="pulsar+ssl://localhost:6651"
        )
        assert config.service_url == "pulsar+ssl://localhost:6651"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to pulsar://)."""
        config = PulsarConnectorConfig(
            address="localhost:6650"
        )
        assert config.service_url == "pulsar://localhost:6650"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = PulsarConnectorConfig(
            address="pulsar://localhost:6650"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "pulsar"
        assert config_dict["service_url"] == "pulsar://localhost:6650"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_pulsar

class TestPulsarStorageConnection:
    """Unit tests for PulsarStorageConnection."""

    def test_connection_requires_pulsar_package(self):
        """Test that connection raises error if Pulsar package not available."""
        config = PulsarConnectorConfig(
            address="pulsar://localhost:6650"
        )
        try:
            connection = PulsarStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Pulsar connector package" in error_msg)

    def test_connection_requires_pulsar_config_type(self):
        """Test that connection requires PulsarConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            PulsarStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Pulsar connector package" in error_msg or
                "Expected PulsarConnectorConfig" in error_msg)
