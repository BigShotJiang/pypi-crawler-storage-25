#!/usr/bin/env python3
"""
Unit tests for Dropbox connector strategy.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from unittest.mock import patch, MagicMock
from exonware.xwstorage.connectors.dropbox_connector_strategy import DropboxConnector
from exonware.xwstorage.errors import XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_dropbox

class TestDropboxConnector:
    """Unit tests for DropboxConnector."""

    def test_connector_initialization(self):
        """Test connector initialization."""
        connector = DropboxConnector(access_token="test-token")
        assert connector.connector_type == "dropbox"
        assert connector.access_token == "test-token"
        assert connector._connected is False

    def test_connector_type_property(self):
        """Test connector_type property."""
        connector = DropboxConnector(access_token="test-token")
        assert connector.connector_type == "dropbox"
    @pytest.mark.asyncio

    async def test_connect_with_access_token(self, mock_dropbox_client):
        """Test connect with access token."""
        connector = DropboxConnector(access_token="test-token")
        with patch('exonware.xwstorage.connectors.dropbox_connector_strategy.DROPBOX_AVAILABLE', True):
            with patch('dropbox.Dropbox', return_value=mock_dropbox_client):
                await connector.connect()
                assert connector._connected is True
                assert connector._client == mock_dropbox_client
    @pytest.mark.asyncio

    async def test_connect_requires_package(self):
        """Test that connect requires dropbox package."""
        connector = DropboxConnector(access_token="test-token")
        with patch('exonware.xwstorage.connectors.dropbox_connector_strategy.DROPBOX_AVAILABLE', False):
            with pytest.raises(XWStorageError, match="dropbox not available"):
                await connector.connect()
    @pytest.mark.asyncio

    async def test_connect_without_credentials(self):
        """Test connect without credentials raises error."""
        connector = DropboxConnector()
        with patch('exonware.xwstorage.connectors.dropbox_connector_strategy.DROPBOX_AVAILABLE', True):
            with pytest.raises(XWStorageError, match="Dropbox authentication required"):
                await connector.connect()
    @pytest.mark.asyncio

    async def test_disconnect(self):
        """Test disconnect."""
        connector = DropboxConnector(access_token="test-token")
        connector._client = MagicMock()
        connector._connected = True
        await connector.disconnect()
        assert connector._connected is False
        assert connector._client is None
    @pytest.mark.asyncio

    async def test_get_transport(self):
        """Test get_transport."""
        connector = DropboxConnector(access_token="test-token")
        mock_client = MagicMock()
        connector._client = mock_client
        connector._connected = True
        transport = await connector.get_transport()
        assert transport == mock_client
    @pytest.mark.asyncio

    async def test_get_transport_not_connected(self):
        """Test get_transport when not connected."""
        connector = DropboxConnector(access_token="test-token")
        with pytest.raises(XWStorageError, match="Not connected"):
            await connector.get_transport()
