#!/usr/bin/env python3
"""
Unit tests for FerretDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.ferretdb_connector import FerretDBConnectorConfig, FerretDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ferretdb

class TestFerretDBConnectorConfig:
    """Unit tests for FerretDBConnectorConfig."""

    def test_config_initialization_with_mongodb_url(self):
        """Test config initialization with MongoDB connection string."""
        config = FerretDBConnectorConfig(
            address="mongodb://localhost:27017",
            database="ferretdb"
        )
        assert config.connector_type == "ferretdb"
        assert config.connection_string == "mongodb://localhost:27017"
        assert config.database == "ferretdb"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to mongodb://)."""
        config = FerretDBConnectorConfig(
            address="localhost:27017",
            database="ferretdb"
        )
        assert config.connection_string == "mongodb://localhost:27017"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = FerretDBConnectorConfig(
            address="mongodb://localhost:27017",
            database="ferretdb"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "ferretdb"
        assert config_dict["connection_string"] == "mongodb://localhost:27017"
        assert config_dict["database"] == "ferretdb"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_ferretdb

class TestFerretDBStorageConnection:
    """Unit tests for FerretDBStorageConnection."""

    def test_connection_requires_mongodb_package(self):
        """Test that connection raises error if MongoDB package not available."""
        config = FerretDBConnectorConfig(
            address="mongodb://localhost:27017",
            database="ferretdb"
        )
        try:
            connection = FerretDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_ferretdb_config_type(self):
        """Test that connection requires FerretDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            FerretDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected FerretDBConnectorConfig" in error_msg)
