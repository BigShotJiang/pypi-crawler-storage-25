#!/usr/bin/env python3
"""
Tests for XWJSON dual-file format handling in LocalConnector.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
import pytest_asyncio
import tempfile
import shutil
import os
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig, LocalStorageConnection
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_local

class TestLocalConnectorXWJSON:
    """Tests for XWJSON dual-file format support."""
    @pytest.mark.asyncio

    async def test_save_xwjson_dual_file_format(self, unit_temp_dir):
        """Test save with XWJSON dual-file format."""
        config = LocalConnectorConfig(
            address=str(unit_temp_dir / "test.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        # Mock codec to simulate XWJSON behavior
        codec = MagicMock()
        codec.encode = MagicMock(return_value='{"test": "data"}')
        codec.__class__.__name__ = 'XWJSONSerializer'
        # Mock file existence check for dual-file format
        with patch.object(connection, '_get_codec', return_value=codec):
            with patch.object(Path, 'exists') as mock_exists:
                # Simulate dual-file format creation
                def side_effect(path):
                    if str(path).endswith('.data.xwjson') or str(path).endswith('.meta.xwjson'):
                        return True
                    return False
                mock_exists.side_effect = side_effect
                await connection.save({"test": "data"}, "test_path")
    @pytest.mark.asyncio

    async def test_save_xwjson_single_file_format(self, unit_temp_dir):
        """Test save with XWJSON single-file format (via env var)."""
        # Set environment variable to use single-file format
        os.environ['XWJSON_SINGLE_FILE'] = '1'
        try:
            config = LocalConnectorConfig(
                address=str(unit_temp_dir / "test.xwjson"),
                security=False
            )
            connection = LocalStorageConnection(config, "xwjson")
            codec = MagicMock()
            codec.encode = MagicMock(return_value='{"test": "data"}')
            codec.__class__.__name__ = 'XWJSONSerializer'
            with patch.object(connection, '_get_codec', return_value=codec):
                await connection.save({"test": "data"}, "test_path")
        finally:
            # Clean up environment variable
            os.environ.pop('XWJSON_SINGLE_FILE', None)
    @pytest.mark.asyncio

    async def test_save_xwjson_detection_by_format_name(self, unit_temp_dir):
        """Test XWJSON detection by format_name attribute."""
        config = LocalConnectorConfig(
            address=str(unit_temp_dir / "test.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        codec = MagicMock()
        codec.encode = MagicMock(return_value='{"test": "data"}')
        codec.format_name = 'XWJSON'
        with patch.object(connection, '_get_codec', return_value=codec):
            await connection.save({"test": "data"}, "test_path")
    @pytest.mark.asyncio

    async def test_save_xwjson_detection_by_aliases(self, unit_temp_dir):
        """Test XWJSON detection by aliases attribute."""
        config = LocalConnectorConfig(
            address=str(unit_temp_dir / "test.xwjson"),
            security=False
        )
        connection = LocalStorageConnection(config, "xwjson")
        codec = MagicMock()
        codec.encode = MagicMock(return_value='{"test": "data"}')
        codec.aliases = ['xwjson', 'xw-json']
        with patch.object(connection, '_get_codec', return_value=codec):
            await connection.save({"test": "data"}, "test_path")
