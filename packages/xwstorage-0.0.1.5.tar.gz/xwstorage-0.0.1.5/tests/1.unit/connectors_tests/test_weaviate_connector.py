#!/usr/bin/env python3
"""
Unit tests for WeaviateConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.weaviate_connector import WeaviateConnectorConfig, WeaviateStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_weaviate

class TestWeaviateConnectorConfig:
    """Unit tests for WeaviateConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = WeaviateConnectorConfig(
            address="http://localhost:8080",
            api_key="my_api_key"
        )
        assert config.connector_type == "weaviate"
        assert config.url == "http://localhost:8080"
        assert config.api_key == "my_api_key"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = WeaviateConnectorConfig(
            address="localhost:8080"
        )
        assert config.url == "http://localhost:8080"

    def test_config_to_dict(self):
        """Test config to_dict conversion (API key masked)."""
        config = WeaviateConnectorConfig(
            address="http://localhost:8080",
            api_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "weaviate"
        assert config_dict["url"] == "http://localhost:8080"
        # API key should be masked
        if "api_key" in config_dict:
            assert config_dict["api_key"] == "***"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_weaviate

class TestWeaviateStorageConnection:
    """Unit tests for WeaviateStorageConnection."""

    def test_connection_requires_weaviate_package(self):
        """Test that connection raises error if Weaviate package not available."""
        config = WeaviateConnectorConfig(
            address="http://localhost:8080"
        )
        try:
            connection = WeaviateStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_weaviate_config_type(self):
        """Test that connection requires WeaviateConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            WeaviateStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected WeaviateConnectorConfig" in error_msg)
