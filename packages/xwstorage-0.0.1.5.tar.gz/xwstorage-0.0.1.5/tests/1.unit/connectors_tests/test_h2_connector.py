#!/usr/bin/env python3
"""
Unit tests for H2Connector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.h2_connector import H2ConnectorConfig, H2StorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_h2

class TestH2ConnectorConfig:
    """Unit tests for H2ConnectorConfig."""

    def test_config_initialization_with_jdbc_url(self):
        """Test config initialization with JDBC URL."""
        config = H2ConnectorConfig(
            address="jdbc:h2:~/test"
        )
        assert config.connector_type == "h2"
        assert config.jdbc_url == "jdbc:h2:~/test"

    def test_config_initialization_with_path(self):
        """Test config initialization with file path."""
        config = H2ConnectorConfig(
            address="~/test.db"
        )
        assert config.jdbc_url.startswith("jdbc:h2:")
        assert "test" in config.jdbc_url

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = H2ConnectorConfig(
            address="jdbc:h2:~/test"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "h2"
        assert config_dict["jdbc_url"] == "jdbc:h2:~/test"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_h2

class TestH2StorageConnection:
    """Unit tests for H2StorageConnection."""

    def test_connection_requires_h2_package(self):
        """Test that connection raises error if H2 package not available."""
        config = H2ConnectorConfig(
            address="jdbc:h2:~/test"
        )
        try:
            connection = H2StorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_h2_config_type(self):
        """Test that connection requires H2ConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            H2StorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected H2ConnectorConfig" in error_msg)
