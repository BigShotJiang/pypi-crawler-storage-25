#!/usr/bin/env python3
"""
Unit tests for LocalStackConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.localstack_connector import LocalStackConnectorConfig, LocalStackStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_localstack

class TestLocalStackConnectorConfig:
    """Unit tests for LocalStackConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with endpoint URL."""
        config = LocalStackConnectorConfig(
            address="http://localhost:4566",
            region="us-east-1"
        )
        assert config.connector_type == "localstack"
        assert config.endpoint_url == "http://localhost:4566"
        assert config.region == "us-east-1"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = LocalStackConnectorConfig(
            address="localhost:4566"
        )
        assert config.endpoint_url == "http://localhost:4566"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = LocalStackConnectorConfig(
            address="http://localhost:4566",
            region="us-west-2"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "localstack"
        assert config_dict["endpoint_url"] == "http://localhost:4566"
        assert config_dict["region"] == "us-west-2"

    def test_config_default_values(self):
        """Test config uses default values when not specified."""
        config = LocalStackConnectorConfig()
        assert config.endpoint_url == "http://localhost:4566"
        assert config.region == "us-east-1"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_localstack

class TestLocalStackStorageConnection:
    """Unit tests for LocalStackStorageConnection."""

    def test_connection_requires_boto3_package(self):
        """Test that connection raises error if boto3 package not available."""
        config = LocalStackConnectorConfig(
            address="http://localhost:4566"
        )
        try:
            connection = LocalStackStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_localstack_config_type(self):
        """Test that connection requires LocalStackConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            LocalStackStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected LocalStackConnectorConfig" in error_msg)
