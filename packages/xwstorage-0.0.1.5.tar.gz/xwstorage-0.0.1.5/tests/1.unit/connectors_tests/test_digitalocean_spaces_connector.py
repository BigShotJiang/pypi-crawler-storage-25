#!/usr/bin/env python3
"""
Unit tests for DigitalOceanSpacesConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.digitalocean_spaces_connector import DigitalOceanSpacesConnectorConfig, DigitalOceanSpacesStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_digitalocean_spaces

class TestDigitalOceanSpacesConnectorConfig:
    """Unit tests for DigitalOceanSpacesConnectorConfig."""

    def test_config_initialization_basic(self):
        """Test config initialization with basic parameters."""
        config = DigitalOceanSpacesConnectorConfig(
            bucket="my-bucket",
            region="nyc3",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        assert config.connector_type == "digitalocean_spaces"
        assert config.bucket == "my-bucket"
        assert config.region == "nyc3"
        assert config.access_key_id == "my_access_key"
        assert config.secret_access_key == "my_secret_key"
        assert "digitaloceanspaces.com" in config.endpoint_url

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = DigitalOceanSpacesConnectorConfig(
            bucket="my-bucket",
            region="nyc3",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "digitalocean_spaces"
        assert config_dict["bucket"] == "my-bucket"
        assert config_dict["region"] == "nyc3"
        assert config_dict["endpoint_url"] == "https://nyc3.digitaloceanspaces.com"
        assert "secret_access_key" not in config_dict  # Secret should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_digitalocean_spaces

class TestDigitalOceanSpacesStorageConnection:
    """Unit tests for DigitalOceanSpacesStorageConnection."""

    def test_connection_requires_s3_connector(self):
        """Test that connection raises error if S3 connector not available."""
        config = DigitalOceanSpacesConnectorConfig(
            bucket="my-bucket",
            region="nyc3",
            access_key_id="my_access_key",
            secret_access_key="my_secret_key"
        )
        try:
            connection = DigitalOceanSpacesStorageConnection(config, "json")
            assert connection._config is not None
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not available" in error_msg.lower() or 
                    "S3 connector" in error_msg or
                    "boto3" in error_msg.lower())

    def test_connection_requires_digitalocean_spaces_config_type(self):
        """Test that connection requires DigitalOceanSpacesConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            DigitalOceanSpacesStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("Expected DigitalOceanSpacesConnectorConfig" in error_msg or
                "S3 connector not available" in error_msg)
