#!/usr/bin/env python3
"""
Unit tests for MarqoConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.marqo_connector import MarqoConnectorConfig, MarqoStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_marqo

class TestMarqoConnectorConfig:
    """Unit tests for MarqoConnectorConfig."""

    def test_config_initialization_with_url(self):
        """Test config initialization with HTTP URL."""
        config = MarqoConnectorConfig(
            address="http://localhost:8882"
        )
        assert config.connector_type == "marqo"
        assert config.url == "http://localhost:8882"

    def test_config_initialization_without_protocol(self):
        """Test config initialization without protocol (defaults to HTTP)."""
        config = MarqoConnectorConfig(
            address="localhost:8882"
        )
        assert config.url == "http://localhost:8882"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = MarqoConnectorConfig(
            address="http://localhost:8882"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "marqo"
        assert config_dict["url"] == "http://localhost:8882"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_marqo

class TestMarqoStorageConnection:
    """Unit tests for MarqoStorageConnection."""

    def test_connection_requires_marqo_package(self):
        """Test that connection raises error if Marqo package not available."""
        config = MarqoConnectorConfig(
            address="http://localhost:8882"
        )
        try:
            connection = MarqoStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            error_msg = str(e)
            assert ("not installed" in error_msg.lower() or 
                    "Marqo connector package" in error_msg)

    def test_connection_requires_marqo_config_type(self):
        """Test that connection requires MarqoConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            MarqoStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Marqo connector package" in error_msg or
                "Expected MarqoConnectorConfig" in error_msg)
