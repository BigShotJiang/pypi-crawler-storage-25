#!/usr/bin/env python3
"""
Unit tests for StarRocksConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.starrocks_connector import StarRocksConnectorConfig, StarRocksStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_starrocks

class TestStarRocksConnectorConfig:
    """Unit tests for StarRocksConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = StarRocksConnectorConfig(
            address="localhost:9030",
            database="test",
            user="root",
            password="password"
        )
        assert config.connector_type == "starrocks"
        assert config.host == "localhost"
        assert config.port == 9030
        assert config.database == "test"
        assert config.user == "root"

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 9030)."""
        config = StarRocksConnectorConfig(
            address="localhost",
            database="test"
        )
        assert config.host == "localhost"
        assert config.port == 9030

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = StarRocksConnectorConfig(
            address="localhost:9030",
            database="test",
            user="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "starrocks"
        assert config_dict["database"] == "test"
        assert config_dict["user"] == "root"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_starrocks

class TestStarRocksStorageConnection:
    """Unit tests for StarRocksStorageConnection."""

    def test_connection_requires_mysql_package(self):
        """Test that connection raises error if MySQL package not available."""
        config = StarRocksConnectorConfig(
            address="localhost:9030",
            database="test"
        )
        try:
            connection = StarRocksStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_starrocks_config_type(self):
        """Test that connection requires StarRocksConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            StarRocksStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected StarRocksConnectorConfig" in error_msg)
