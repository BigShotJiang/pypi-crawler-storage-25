#!/usr/bin/env python3
"""
Unit tests for CassandraConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.cassandra_connector import CassandraConnectorConfig, CassandraStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cassandra

class TestCassandraConnectorConfig:
    """Unit tests for CassandraConnectorConfig."""

    def test_config_initialization_with_hosts(self):
        """Test config initialization with hosts list."""
        config = CassandraConnectorConfig(
            address="mytable",
            database="mykeyspace",
            hosts=["localhost"],
            port=9042,
            username="cassandra",
            password="password"
        )
        assert config.connector_type == "cassandra"
        assert config.database == "mykeyspace"
        assert config.table_name == "mytable"
        assert config.hosts == ["localhost"]
        assert config.port == 9042

    def test_config_initialization_with_collection_name(self):
        """Test config initialization with collection_name."""
        config = CassandraConnectorConfig(
            collection_name="mytable",
            database="mykeyspace",
            hosts=["localhost"]
        )
        assert config.table_name == "mytable"

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = CassandraConnectorConfig(
            address="mytable",
            database="mykeyspace",
            hosts=["localhost"],
            username="cassandra",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "cassandra"
        assert config_dict["database"] == "mykeyspace"
        assert config_dict["table_name"] == "mytable"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_cassandra

class TestCassandraStorageConnection:
    """Unit tests for CassandraStorageConnection."""

    def test_connection_requires_cassandra_package(self):
        """Test that connection raises error if Cassandra package not available."""
        config = CassandraConnectorConfig(
            address="mytable",
            database="mykeyspace",
            hosts=["localhost"]
        )
        try:
            connection = CassandraStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_cassandra_config_type(self):
        """Test that connection requires CassandraConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            CassandraStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected CassandraConnectorConfig" in error_msg)
