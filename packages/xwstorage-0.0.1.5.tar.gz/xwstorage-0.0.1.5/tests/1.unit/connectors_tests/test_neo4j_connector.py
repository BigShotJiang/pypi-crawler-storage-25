#!/usr/bin/env python3
"""
Unit tests for Neo4jConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.neo4j_connector import Neo4jConnectorConfig, Neo4jStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_neo4j

class TestNeo4jConnectorConfig:
    """Unit tests for Neo4jConnectorConfig."""

    def test_config_initialization_with_label(self):
        """Test config initialization with label."""
        config = Neo4jConnectorConfig(
            address="StorageNode",
            uri="bolt://localhost:7687",
            username="neo4j",
            password="password"
        )
        assert config.connector_type == "neo4j"
        assert config.label == "StorageNode"
        assert config.uri == "bolt://localhost:7687"
        assert config.username == "neo4j"
        assert config.password == "password"

    def test_config_initialization_with_uri_in_address(self):
        """Test config initialization with URI in address field."""
        config = Neo4jConnectorConfig(
            address="neo4j://localhost:7687",
            username="neo4j",
            password="password"
        )
        assert config.uri == "neo4j://localhost:7687"
        assert config.label == "StorageNode"  # Default label

    def test_config_initialization_with_bolt_uri(self):
        """Test config initialization with bolt URI."""
        config = Neo4jConnectorConfig(
            address="bolt://localhost:7687",
            label="CustomNode"
        )
        assert config.uri == "bolt://localhost:7687"
        assert config.label == "CustomNode"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = Neo4jConnectorConfig(
            address="StorageNode",
            uri="bolt://localhost:7687",
            username="neo4j",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "neo4j"
        assert config_dict["label"] == "StorageNode"
        assert config_dict["uri"] == "bolt://localhost:7687"
        assert "password" not in config_dict  # Password should not be in dict

    def test_config_default_uri(self):
        """Test config uses default URI when not specified."""
        config = Neo4jConnectorConfig(
            address="StorageNode"
        )
        assert config.uri == "bolt://localhost:7687"
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_neo4j

class TestNeo4jStorageConnection:
    """Unit tests for Neo4jStorageConnection."""

    def test_connection_requires_neo4j_package(self):
        """Test that connection raises error if Neo4j package not available."""
        config = Neo4jConnectorConfig(
            address="StorageNode",
            uri="bolt://localhost:7687"
        )
        try:
            connection = Neo4jStorageConnection(config, "json")
            # If we get here, neo4j package is available
            assert connection._config == config
        except XWLocationError as e:
            # Expected if neo4j package not installed
            assert "not installed" in str(e).lower()

    def test_connection_requires_neo4j_config_type(self):
        """Test that connection requires Neo4jConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            Neo4jStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected Neo4jConnectorConfig" in error_msg)

    def test_connection_initialization(self):
        """Test connection initialization with valid config."""
        config = Neo4jConnectorConfig(
            address="StorageNode",
            uri="bolt://localhost:7687"
        )
        try:
            connection = Neo4jStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError:
            # Skip if package not installed
            pytest.skip("Neo4j package not installed")

    def test_connection_serializer_format(self):
        """Test connection handles different serializer formats."""
        config = Neo4jConnectorConfig(
            address="StorageNode",
            uri="bolt://localhost:7687"
        )
        try:
            # Test JSON format
            connection = Neo4jStorageConnection(config, "json")
            assert connection._serializer_format == "json"
        except XWLocationError:
            pytest.skip("Neo4j package not installed")
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_neo4j
@pytest.mark.skip(reason="Requires Neo4j server running")

class TestNeo4jStorageConnectionOperations:
    """Unit tests for Neo4j storage operations (requires running server)."""
    @pytest.fixture

    def neo4j_config(self):
        """Neo4j config for testing (requires running server)."""
        return Neo4jConnectorConfig(
            address="StorageNode",
            uri="bolt://localhost:7687",
            username="neo4j",
            password="password"
        )
    @pytest.mark.asyncio

    async def test_neo4j_save_and_load(self, neo4j_config, sample_data, test_path):
        """Test Neo4j save and load operations."""
        connection = Neo4jStorageConnection(neo4j_config, "json")
        await connection.save(sample_data, test_path)
        loaded = await connection.load(test_path)
        assert loaded == sample_data
