#!/usr/bin/env python3
"""
Unit tests for LMDBConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.lmdb_connector import LMDBConnectorConfig, LMDBStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_lmdb

class TestLMDBConnectorConfig:
    """Unit tests for LMDBConnectorConfig."""

    def test_config_initialization_with_path(self):
        """Test config initialization with database path."""
        config = LMDBConnectorConfig(
            address="/tmp/testdb"
        )
        assert config.connector_type == "lmdb"
        assert config.database_path == "/tmp/testdb"
        assert config.map_size == 1024 * 1024 * 1024  # 1GB default

    def test_config_initialization_with_custom_map_size(self):
        """Test config initialization with custom map size."""
        config = LMDBConnectorConfig(
            address="/tmp/testdb",
            map_size=2 * 1024 * 1024 * 1024  # 2GB
        )
        assert config.map_size == 2 * 1024 * 1024 * 1024

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = LMDBConnectorConfig(
            address="/tmp/testdb",
            map_size=512 * 1024 * 1024  # 512MB
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "lmdb"
        assert config_dict["database_path"] == "/tmp/testdb"
        assert config_dict["map_size"] == 512 * 1024 * 1024
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_lmdb

class TestLMDBStorageConnection:
    """Unit tests for LMDBStorageConnection."""

    def test_connection_requires_lmdb_package(self):
        """Test that connection raises error if LMDB package not available."""
        config = LMDBConnectorConfig(
            address="/tmp/testdb"
        )
        try:
            connection = LMDBStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_lmdb_config_type(self):
        """Test that connection requires LMDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            LMDBStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected LMDBConnectorConfig" in error_msg)
