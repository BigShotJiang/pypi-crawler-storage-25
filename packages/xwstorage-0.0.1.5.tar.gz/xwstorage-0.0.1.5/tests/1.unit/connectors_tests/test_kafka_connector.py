#!/usr/bin/env python3
"""
Unit tests for KafkaConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.kafka_connector import KafkaConnectorConfig, KafkaStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_kafka

class TestKafkaConnectorConfig:
    """Unit tests for KafkaConnectorConfig."""

    def test_config_initialization_single_server(self):
        """Test config initialization with single bootstrap server."""
        config = KafkaConnectorConfig(
            address="localhost:9092"
        )
        assert config.connector_type == "kafka"
        assert config.bootstrap_servers == ["localhost:9092"]
        assert config.host == "localhost"
        assert config.port == 9092

    def test_config_initialization_multiple_servers(self):
        """Test config initialization with multiple bootstrap servers."""
        config = KafkaConnectorConfig(
            address="localhost:9092,kafka2:9092,kafka3:9092"
        )
        assert len(config.bootstrap_servers) == 3
        assert "localhost:9092" in config.bootstrap_servers
        assert "kafka2:9092" in config.bootstrap_servers
        assert "kafka3:9092" in config.bootstrap_servers

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = KafkaConnectorConfig(
            address="localhost:9092"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "kafka"
        assert config_dict["bootstrap_servers"] == ["localhost:9092"]

    def test_config_default_port(self):
        """Test config uses default port 9092 when not specified."""
        config = KafkaConnectorConfig(
            address="localhost"
        )
        assert config.port == 9092
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_kafka

class TestKafkaStorageConnection:
    """Unit tests for KafkaStorageConnection."""

    def test_connection_requires_kafka_package(self):
        """Test that connection raises error if Kafka package not available."""
        config = KafkaConnectorConfig(
            address="localhost:9092"
        )
        try:
            connection = KafkaStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_kafka_config_type(self):
        """Test that connection requires KafkaConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            KafkaStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected KafkaConnectorConfig" in error_msg)
