#!/usr/bin/env python3
"""
Unit tests for ApacheDorisConnector implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
from exonware.xwstorage.connectors.apache_doris_connector import ApacheDorisConnectorConfig, ApacheDorisStorageConnection
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_doris

class TestApacheDorisConnectorConfig:
    """Unit tests for ApacheDorisConnectorConfig."""

    def test_config_initialization_with_host_port(self):
        """Test config initialization with host:port format."""
        config = ApacheDorisConnectorConfig(
            address="localhost:9030",
            database="test",
            user="root",
            password="password"
        )
        assert config.connector_type == "apache_doris"
        assert config.database == "test"
        assert config.user == "root"
        assert config.host == "localhost"
        assert config.port == 9030

    def test_config_initialization_without_port(self):
        """Test config initialization without port (defaults to 9030)."""
        config = ApacheDorisConnectorConfig(
            address="localhost",
            database="test"
        )
        assert config.host == "localhost"
        assert config.port == 9030

    def test_config_to_dict(self):
        """Test config to_dict conversion (password not included)."""
        config = ApacheDorisConnectorConfig(
            address="localhost:9030",
            database="test",
            user="root",
            password="secret"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "apache_doris"
        assert config_dict["database"] == "test"
        assert config_dict["user"] == "root"
        assert "password" not in config_dict  # Password should not be in dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_apache_doris

class TestApacheDorisStorageConnection:
    """Unit tests for ApacheDorisStorageConnection."""

    def test_connection_requires_mysql_package(self):
        """Test that connection raises error if MySQL package not available."""
        config = ApacheDorisConnectorConfig(
            address="localhost:9030",
            database="test"
        )
        try:
            connection = ApacheDorisStorageConnection(config, "json")
            assert connection._config == config
        except XWLocationError as e:
            assert "not installed" in str(e).lower()

    def test_connection_requires_doris_config_type(self):
        """Test that connection requires ApacheDorisConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with pytest.raises(XWLocationError) as exc_info:
            ApacheDorisStorageConnection(local_config, "json")
        error_msg = str(exc_info.value)
        assert ("not installed" in error_msg.lower() or 
                "Expected ApacheDorisConnectorConfig" in error_msg)
