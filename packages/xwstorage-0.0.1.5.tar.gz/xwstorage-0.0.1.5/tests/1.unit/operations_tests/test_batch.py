#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/operations_tests/test_batch.py
Unit tests for Batch operations.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from exonware.xwstorage.operations.batch import BatchOperations
@pytest.mark.xwstorage_unit

class TestBatchOperations:
    """Test BatchOperations implementation."""
    @pytest.fixture

    def mock_connection(self):
        """Create mock connection fixture."""
        connection = MagicMock()
        connection.save = AsyncMock()
        connection.load = AsyncMock(return_value={"data": "test"})
        return connection
    @pytest.fixture

    def batch_ops(self, mock_connection):
        """Create batch operations fixture."""
        return BatchOperations(mock_connection)
    @pytest.mark.asyncio

    async def test_batch_operations_initialization(self, batch_ops):
        """Test initializing batch operations."""
        assert batch_ops.connection is not None
    @pytest.mark.asyncio

    async def test_batch_write_with_bulk_store(self, batch_ops, mock_connection):
        """Test batch write using bulk_store if available."""
        mock_connection.bulk_store = AsyncMock(return_value={"total": 3, "success": 3})
        operations = [
            {"data": {"key": "value1"}, "path": "path1"},
            {"data": {"key": "value2"}, "path": "path2"},
            {"data": {"key": "value3"}, "path": "path3"}
        ]
        result = await batch_ops.batch_write(operations)
        assert result["total"] == 3
        assert result["success"] == 3
        mock_connection.bulk_store.assert_called_once_with(operations)
    @pytest.mark.asyncio

    async def test_batch_write_fallback(self, batch_ops, mock_connection):
        """Test batch write fallback when bulk_store not available."""
        # Remove bulk_store
        del mock_connection.bulk_store
        operations = [
            {"data": {"key": "value1"}, "path": "path1"},
            {"data": {"key": "value2"}, "path": "path2"}
        ]
        result = await batch_ops.batch_write(operations)
        assert result["total"] == 2
        assert result["success"] == 2
        assert mock_connection.save.call_count == 2
    @pytest.mark.asyncio

    async def test_batch_read_with_bulk_retrieve(self, batch_ops, mock_connection):
        """Test batch read using bulk_retrieve if available."""
        mock_connection.bulk_retrieve = AsyncMock(return_value={
            "path1": {"data": "value1"},
            "path2": {"data": "value2"}
        })
        paths = ["path1", "path2"]
        result = await batch_ops.batch_read(paths)
        assert len(result) == 2
        assert "path1" in result
        mock_connection.bulk_retrieve.assert_called_once_with(paths)
    @pytest.mark.asyncio

    async def test_batch_read_fallback(self, batch_ops, mock_connection):
        """Test batch read fallback when bulk_retrieve not available."""
        # Remove bulk_retrieve
        del mock_connection.bulk_retrieve
        paths = ["path1", "path2"]
        result = await batch_ops.batch_read(paths)
        assert len(result) == 2
        assert mock_connection.load.call_count == 2
