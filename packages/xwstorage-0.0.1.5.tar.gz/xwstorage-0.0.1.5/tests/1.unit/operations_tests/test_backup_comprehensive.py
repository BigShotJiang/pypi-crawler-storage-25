#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/operations_tests/test_backup_comprehensive.py
Comprehensive unit tests for Backup and restore with various scenarios.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import tempfile
from pathlib import Path
from unittest.mock import MagicMock
from exonware.xwstorage.operations.backup import BackupManager
@pytest.mark.xwstorage_unit

class TestBackupComprehensive:
    """Comprehensive tests for BackupManager."""
    @pytest.fixture

    def mock_connection(self):
        """Create mock connection fixture."""
        return MagicMock()
    @pytest.fixture

    def backup_manager(self, mock_connection):
        """Create backup manager fixture."""
        return BackupManager(mock_connection)
    @pytest.fixture

    def temp_backup_path(self):
        """Create temporary backup path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "backup.db"
    @pytest.mark.asyncio

    async def test_backup_incremental(self, backup_manager, temp_backup_path):
        """Test incremental backup."""
        # Create initial backup
        result1 = await backup_manager.create_backup(temp_backup_path)
        assert result1 is True
        # Create incremental backup
        result2 = await backup_manager.create_backup(temp_backup_path.with_name("backup_inc.db"))
        assert result2 is True
    @pytest.mark.asyncio

    async def test_backup_restore_cycle(self, backup_manager, temp_backup_path):
        """Test backup and restore cycle."""
        # Create backup
        result = await backup_manager.create_backup(temp_backup_path)
        assert result is True
        # Restore from backup
        result = await backup_manager.restore_backup(temp_backup_path)
        assert result is True
    @pytest.mark.asyncio

    async def test_backup_multiple_backups(self, backup_manager, temp_backup_path):
        """Test creating multiple backups."""
        for i in range(5):
            backup_path = temp_backup_path.with_name(f"backup_{i}.db")
            result = await backup_manager.create_backup(backup_path)
            assert result is True
