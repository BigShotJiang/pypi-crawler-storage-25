#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_transaction_manager.py
Unit tests for transaction manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.transactions.manager import TransactionManager, Transaction, TransactionState
from exonware.xwstorage.defs import IsolationLevel
@pytest.mark.xwstorage_unit

class TestTransactionManager:
    """Test TransactionManager implementation."""
    @pytest.fixture

    def manager(self):
        """Create transaction manager fixture."""
        return TransactionManager()

    def test_begin_transaction(self, manager):
        """Test beginning a transaction."""
        txn = manager.begin_transaction(IsolationLevel.READ_COMMITTED)
        assert txn is not None
        assert txn.transaction_id is not None
        assert txn.isolation_level == IsolationLevel.READ_COMMITTED.value
        assert txn.state == TransactionState.ACTIVE

    def test_get_transaction(self, manager):
        """Test getting a transaction by ID."""
        txn = manager.begin_transaction()
        retrieved = manager.get_transaction(txn.transaction_id)
        assert retrieved is not None
        assert retrieved.transaction_id == txn.transaction_id

    def test_get_current_transaction(self, manager):
        """Test getting current active transaction."""
        txn = manager.begin_transaction()
        current = manager.get_current_transaction()
        assert current is not None
        assert current.transaction_id == txn.transaction_id
    @pytest.mark.asyncio

    async def test_commit_transaction(self, manager):
        """Test committing a transaction."""
        txn = manager.begin_transaction()
        await manager.commit_transaction(txn.transaction_id)
        # Transaction should be committed
        retrieved = manager.get_transaction(txn.transaction_id)
        # After cleanup, transaction may be removed
        assert retrieved is None or retrieved.state == TransactionState.COMMITTED
    @pytest.mark.asyncio

    async def test_rollback_transaction(self, manager):
        """Test rolling back a transaction."""
        txn = manager.begin_transaction()
        await manager.rollback_transaction(txn.transaction_id)
        # Transaction should be rolled back
        retrieved = manager.get_transaction(txn.transaction_id)
        # After cleanup, transaction may be removed
        assert retrieved is None or retrieved.state == TransactionState.ROLLED_BACK
@pytest.mark.xwstorage_unit

class TestTransaction:
    """Test Transaction implementation."""
    @pytest.mark.asyncio

    async def test_commit(self):
        """Test committing a transaction."""
        txn = Transaction(
            transaction_id="test-txn-1",
            isolation_level=IsolationLevel.READ_COMMITTED.value
        )
        await txn.commit()
        assert txn.state == TransactionState.COMMITTED
    @pytest.mark.asyncio

    async def test_rollback(self):
        """Test rolling back a transaction."""
        txn = Transaction(
            transaction_id="test-txn-1",
            isolation_level=IsolationLevel.READ_COMMITTED.value
        )
        await txn.rollback()
        assert txn.state == TransactionState.ROLLED_BACK
    @pytest.mark.asyncio

    async def test_create_savepoint(self):
        """Test creating a savepoint."""
        txn = Transaction(
            transaction_id="test-txn-1",
            isolation_level=IsolationLevel.READ_COMMITTED.value
        )
        await txn.create_savepoint("sp1")
        assert "sp1" in txn.savepoints
    @pytest.mark.asyncio

    async def test_rollback_to_savepoint(self):
        """Test rolling back to a savepoint."""
        txn = Transaction(
            transaction_id="test-txn-1",
            isolation_level=IsolationLevel.READ_COMMITTED.value
        )
        await txn.create_savepoint("sp1")
        await txn.create_savepoint("sp2")
        await txn.rollback_to_savepoint("sp1")
        assert "sp1" in txn.savepoints
        assert "sp2" not in txn.savepoints
    @pytest.mark.asyncio

    async def test_release_savepoint(self):
        """Test releasing a savepoint."""
        txn = Transaction(
            transaction_id="test-txn-1",
            isolation_level=IsolationLevel.READ_COMMITTED.value
        )
        await txn.create_savepoint("sp1")
        await txn.release_savepoint("sp1")
        assert "sp1" not in txn.savepoints
