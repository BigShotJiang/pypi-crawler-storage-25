#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_isolation_lock_timing.py
Comprehensive tests for Transaction isolation lock release timing.
Tests lock release timing behavior for each isolation level:
- READ_UNCOMMITTED: No locks acquired
- READ_COMMITTED: Locks released after each operation
- REPEATABLE_READ: Locks held until transaction end
- SERIALIZABLE: Locks held until transaction end
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 27-Jan-2025
"""

import pytest
import asyncio
from exonware.xwstorage.transactions.isolation import IsolationManager
from exonware.xwstorage.core.lock_manager import LockManager
from exonware.xwstorage.defs import IsolationLevel, LockMode
@pytest.mark.xwstorage_unit

class TestIsolationLockTiming:
    """
    Comprehensive tests for lock release timing at each isolation level.
    Verifies that locks are released at the correct time based on isolation level:
    - READ_UNCOMMITTED: No locks
    - READ_COMMITTED: Per-operation release
    - REPEATABLE_READ: Transaction-end release
    - SERIALIZABLE: Transaction-end release
    """
    @pytest.fixture

    def lock_manager(self):
        """Create lock manager fixture."""
        return LockManager()
    @pytest.fixture

    def isolation_manager(self, lock_manager):
        """Create isolation manager fixture."""
        return IsolationManager(lock_manager)
    # ==================== READ_UNCOMMITTED Lock Timing ====================
    @pytest.mark.asyncio

    async def test_read_uncommitted_no_locks_acquired(self, isolation_manager):
        """
        Test READ_UNCOMMITTED does not acquire any locks.
        Verifies that READ_UNCOMMITTED isolation level does not acquire
        locks for read operations, allowing immediate access.
        """
        resource = "table:users"
        transaction_id = "txn_1"
        # Acquire read lock - should return True but not actually lock
        result = await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
        assert result is True
        # Verify no lock was actually acquired
        stats = isolation_manager.lock_manager.get_lock_stats()
        assert stats["total_locks"] == 0, "READ_UNCOMMITTED should not acquire locks"
    @pytest.mark.asyncio

    async def test_read_uncommitted_write_locks_acquired(self, isolation_manager):
        """
        Test READ_UNCOMMITTED still acquires write locks.
        Even at READ_UNCOMMITTED, write operations need exclusive locks
        to prevent concurrent writes.
        """
        resource = "table:users"
        transaction_id = "txn_1"
        # Acquire write lock - should acquire exclusive lock
        result = await isolation_manager.acquire_write_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
        assert result is True
        # Verify lock was acquired
        stats = isolation_manager.lock_manager.get_lock_stats()
        assert stats["total_locks"] == 1, "Write locks should be acquired even at READ_UNCOMMITTED"
        # Clean up
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
    @pytest.mark.asyncio

    async def test_read_uncommitted_release_does_nothing(self, isolation_manager):
        """
        Test READ_UNCOMMITTED release_locks does nothing for reads.
        Since no locks are acquired for reads, releasing should be a no-op.
        """
        resource = "table:users"
        transaction_id = "txn_1"
        # Acquire read lock (no actual lock)
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
        # Release locks - should do nothing
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
        # Verify no locks were ever held
        stats = isolation_manager.lock_manager.get_lock_stats()
        assert stats["total_locks"] == 0
    # ==================== READ_COMMITTED Lock Timing ====================
    @pytest.mark.asyncio

    async def test_read_committed_locks_released_after_operation(self, isolation_manager):
        """
        Test READ_COMMITTED releases locks after each operation.
        Verifies that READ_COMMITTED isolation level releases read locks
        immediately after each read operation completes.
        """
        resource = "table:users"
        transaction_id = "txn_1"
        # Acquire read lock
        result = await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        assert result is True
        # Verify lock was acquired
        stats_before = isolation_manager.lock_manager.get_lock_stats()
        assert stats_before["total_locks"] == 1, "Lock should be acquired"
        # Release lock after operation (READ_COMMITTED behavior)
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Verify lock was released
        stats_after = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after["total_locks"] == 0, "Lock should be released after operation"
    @pytest.mark.asyncio

    async def test_read_committed_multiple_operations_release_each(self, isolation_manager):
        """
        Test READ_COMMITTED releases locks after each of multiple operations.
        Verifies that each read operation in READ_COMMITTED acquires and
        releases its lock independently.
        """
        resource = "table:users"
        transaction_id = "txn_1"
        # First read operation
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_after_read1 = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_read1["total_locks"] == 1
        # Release after first operation
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_after_release1 = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_release1["total_locks"] == 0
        # Second read operation (should acquire new lock)
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_after_read2 = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_read2["total_locks"] == 1
        # Release after second operation
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_after_release2 = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_release2["total_locks"] == 0
    @pytest.mark.asyncio

    async def test_read_committed_release_read_lock_after_operation_only_for_read_committed(self, isolation_manager):
        """
        Test release_read_lock_after_operation only works for READ_COMMITTED.
        Verifies that release_read_lock_after_operation is a no-op for
        other isolation levels.
        """
        resource = "table:users"
        transaction_id = "txn_1"
        # Test with REPEATABLE_READ - should not release
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        stats_before = isolation_manager.lock_manager.get_lock_stats()
        assert stats_before["total_locks"] == 1
        # Try to release after operation (should not release for REPEATABLE_READ)
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # Lock should still be held
        stats_after = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after["total_locks"] == 1, "REPEATABLE_READ should not release locks after operation"
        # Clean up
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
    @pytest.mark.asyncio

    async def test_read_committed_allows_concurrent_reads_after_release(self, isolation_manager):
        """
        Test READ_COMMITTED allows concurrent reads after lock release.
        After releasing a read lock in READ_COMMITTED, another transaction
        should be able to acquire a write lock.
        """
        resource = "table:users"
        read_txn = "txn_read"
        write_txn = "txn_write"
        # Transaction 1 reads
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=read_txn,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Transaction 2 tries to write - should be blocked
        write_result = await isolation_manager.acquire_write_lock(
            resource=resource,
            transaction_id=write_txn,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        assert write_result is False, "Write should be blocked by read lock"
        # Transaction 1 releases lock after operation
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id=read_txn,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Now Transaction 2 should be able to write
        write_result_after = await isolation_manager.acquire_write_lock(
            resource=resource,
            transaction_id=write_txn,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        assert write_result_after is True, "Write should succeed after read lock release"
        # Clean up
        await isolation_manager.release_locks(
            transaction_id=write_txn,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
    # ==================== REPEATABLE_READ Lock Timing ====================
    @pytest.mark.asyncio

    async def test_repeatable_read_holds_locks_until_transaction_end(self, isolation_manager):
        """
        Test REPEATABLE_READ holds locks until transaction end.
        Verifies that REPEATABLE_READ isolation level holds read locks
        until the transaction commits or aborts.
        """
        resource = "table:users"
        transaction_id = "txn_1"
        # Acquire read lock
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # Verify lock is held
        stats_after_acquire = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_acquire["total_locks"] == 1
        # Try to release after operation (should not release)
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # Lock should still be held
        stats_after_operation = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_operation["total_locks"] == 1, "REPEATABLE_READ should hold locks until transaction end"
        # Release at transaction end
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # Now lock should be released
        stats_after_end = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_end["total_locks"] == 0
    @pytest.mark.asyncio

    async def test_repeatable_read_multiple_reads_hold_all_locks(self, isolation_manager):
        """
        Test REPEATABLE_READ holds all locks from multiple reads.
        Verifies that multiple read operations in REPEATABLE_READ
        all hold their locks until transaction end.
        """
        resource1 = "table:users"
        resource2 = "table:orders"
        transaction_id = "txn_1"
        # First read
        await isolation_manager.acquire_read_lock(
            resource=resource1,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # Second read
        await isolation_manager.acquire_read_lock(
            resource=resource2,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # Both locks should be held
        stats = isolation_manager.lock_manager.get_lock_stats()
        assert stats["total_locks"] == 2, "Both locks should be held"
        # Release at transaction end
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # All locks should be released
        stats_after = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after["total_locks"] == 0
    @pytest.mark.asyncio

    async def test_repeatable_read_prevents_writes_while_holding_locks(self, isolation_manager):
        """
        Test REPEATABLE_READ prevents writes while holding read locks.
        Verifies that while a REPEATABLE_READ transaction holds read locks,
        other transactions cannot acquire write locks on the same resources.
        """
        resource = "table:users"
        read_txn = "txn_read"
        write_txn = "txn_write"
        # Transaction 1 reads (holds lock)
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=read_txn,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # Transaction 2 tries to write - should be blocked
        write_result = await isolation_manager.acquire_write_lock(
            resource=resource,
            transaction_id=write_txn,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        assert write_result is False, "Write should be blocked while read lock is held"
        # Transaction 1 ends (releases locks)
        await isolation_manager.release_locks(
            transaction_id=read_txn,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # Now Transaction 2 should be able to write
        write_result_after = await isolation_manager.acquire_write_lock(
            resource=resource,
            transaction_id=write_txn,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        assert write_result_after is True, "Write should succeed after read lock release"
        # Clean up
        await isolation_manager.release_locks(
            transaction_id=write_txn,
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
    # ==================== SERIALIZABLE Lock Timing ====================
    @pytest.mark.asyncio

    async def test_serializable_holds_locks_until_transaction_end(self, isolation_manager):
        """
        Test SERIALIZABLE holds locks until transaction end.
        Verifies that SERIALIZABLE isolation level holds read locks
        until the transaction commits or aborts, same as REPEATABLE_READ.
        """
        resource = "table:users"
        transaction_id = "txn_1"
        # Acquire read lock
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        # Verify lock is held
        stats_after_acquire = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_acquire["total_locks"] == 1
        # Try to release after operation (should not release)
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        # Lock should still be held
        stats_after_operation = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_operation["total_locks"] == 1, "SERIALIZABLE should hold locks until transaction end"
        # Release at transaction end
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        # Now lock should be released
        stats_after_end = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after_end["total_locks"] == 0
    @pytest.mark.asyncio

    async def test_serializable_strictest_isolation(self, isolation_manager):
        """
        Test SERIALIZABLE provides strictest isolation with lock timing.
        Verifies that SERIALIZABLE holds all locks until transaction end,
        preventing all anomalies including phantom reads.
        """
        resource = "table:users"
        read_txn = "txn_read"
        write_txn = "txn_write"
        # Transaction 1 reads (holds lock)
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id=read_txn,
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        # Transaction 2 tries to write - should be blocked
        write_result = await isolation_manager.acquire_write_lock(
            resource=resource,
            transaction_id=write_txn,
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        assert write_result is False, "Write should be blocked while read lock is held"
        # Transaction 1 ends (releases locks)
        await isolation_manager.release_locks(
            transaction_id=read_txn,
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        # Now Transaction 2 should be able to write
        write_result_after = await isolation_manager.acquire_write_lock(
            resource=resource,
            transaction_id=write_txn,
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        assert write_result_after is True, "Write should succeed after read lock release"
        # Clean up
        await isolation_manager.release_locks(
            transaction_id=write_txn,
            isolation_level=IsolationLevel.SERIALIZABLE
        )
    # ==================== Cross-Isolation Level Comparison ====================
    @pytest.mark.asyncio

    async def test_lock_timing_comparison_read_committed_vs_repeatable_read(self, isolation_manager):
        """
        Test lock timing difference between READ_COMMITTED and REPEATABLE_READ.
        Verifies that READ_COMMITTED releases locks after operations while
        REPEATABLE_READ holds locks until transaction end.
        """
        resource = "table:users"
        # Test READ_COMMITTED
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id="txn_rc",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_rc_after_acquire = isolation_manager.lock_manager.get_lock_stats()
        assert stats_rc_after_acquire["total_locks"] == 1
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id="txn_rc",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_rc_after_release = isolation_manager.lock_manager.get_lock_stats()
        assert stats_rc_after_release["total_locks"] == 0, "READ_COMMITTED should release after operation"
        # Test REPEATABLE_READ
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id="txn_rr",
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        stats_rr_after_acquire = isolation_manager.lock_manager.get_lock_stats()
        assert stats_rr_after_acquire["total_locks"] == 1
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id="txn_rr",
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        stats_rr_after_release = isolation_manager.lock_manager.get_lock_stats()
        assert stats_rr_after_release["total_locks"] == 1, "REPEATABLE_READ should hold until transaction end"
        # Clean up
        await isolation_manager.release_locks(
            transaction_id="txn_rr",
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
    @pytest.mark.asyncio

    async def test_lock_timing_comparison_all_levels(self, isolation_manager):
        """
        Test lock timing behavior across all isolation levels.
        Comprehensive comparison of lock release timing for all isolation levels.
        """
        resource = "table:users"
        # READ_UNCOMMITTED: No locks for reads
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id="txn_ru",
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
        stats_ru = isolation_manager.lock_manager.get_lock_stats()
        assert stats_ru["total_locks"] == 0, "READ_UNCOMMITTED should not acquire read locks"
        # READ_COMMITTED: Release after operation
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id="txn_rc",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_rc_before = isolation_manager.lock_manager.get_lock_stats()
        assert stats_rc_before["total_locks"] == 1
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id="txn_rc",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_rc_after = isolation_manager.lock_manager.get_lock_stats()
        assert stats_rc_after["total_locks"] == 0, "READ_COMMITTED should release after operation"
        # REPEATABLE_READ: Hold until transaction end
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id="txn_rr",
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id="txn_rr",
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        stats_rr = isolation_manager.lock_manager.get_lock_stats()
        assert stats_rr["total_locks"] == 1, "REPEATABLE_READ should hold until transaction end"
        await isolation_manager.release_locks(
            transaction_id="txn_rr",
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        # SERIALIZABLE: Hold until transaction end
        await isolation_manager.acquire_read_lock(
            resource=resource,
            transaction_id="txn_ser",
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        await isolation_manager.release_read_lock_after_operation(
            resource=resource,
            transaction_id="txn_ser",
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        stats_ser = isolation_manager.lock_manager.get_lock_stats()
        assert stats_ser["total_locks"] == 1, "SERIALIZABLE should hold until transaction end"
        await isolation_manager.release_locks(
            transaction_id="txn_ser",
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        # Final check - all locks released
        stats_final = isolation_manager.lock_manager.get_lock_stats()
        assert stats_final["total_locks"] == 0
    # ==================== Edge Cases ====================
    @pytest.mark.asyncio

    async def test_release_locks_with_resource_parameter(self, isolation_manager):
        """
        Test release_locks with resource parameter for READ_COMMITTED.
        Verifies that release_locks can release a specific resource lock
        when resource parameter is provided (for READ_COMMITTED).
        """
        resource1 = "table:users"
        resource2 = "table:orders"
        transaction_id = "txn_1"
        # Acquire locks on two resources
        await isolation_manager.acquire_read_lock(
            resource=resource1,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        await isolation_manager.acquire_read_lock(
            resource=resource2,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_before = isolation_manager.lock_manager.get_lock_stats()
        assert stats_before["total_locks"] == 2
        # Release specific resource
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED,
            resource=resource1
        )
        # Only resource1 should be released
        stats_after = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after["total_locks"] == 1, "Only one resource should be released"
        # Clean up
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
    @pytest.mark.asyncio

    async def test_release_locks_without_resource_parameter(self, isolation_manager):
        """
        Test release_locks without resource parameter releases all locks.
        Verifies that release_locks without resource parameter releases
        all locks for the transaction.
        """
        resource1 = "table:users"
        resource2 = "table:orders"
        transaction_id = "txn_1"
        # Acquire locks on two resources
        await isolation_manager.acquire_read_lock(
            resource=resource1,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        await isolation_manager.acquire_read_lock(
            resource=resource2,
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        stats_before = isolation_manager.lock_manager.get_lock_stats()
        assert stats_before["total_locks"] == 2
        # Release all locks (no resource parameter)
        await isolation_manager.release_locks(
            transaction_id=transaction_id,
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # All locks should be released
        stats_after = isolation_manager.lock_manager.get_lock_stats()
        assert stats_after["total_locks"] == 0
