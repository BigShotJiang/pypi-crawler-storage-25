#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_mvcc.py
Unit tests for MVCC (Multi-Version Concurrency Control).
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import time
from exonware.xwstorage.transactions.mvcc import MVCCManager, Version
@pytest.mark.xwstorage_unit

class TestMVCCManager:
    """Test MVCCManager implementation."""
    @pytest.fixture

    def mvcc_manager(self):
        """Create MVCC manager fixture."""
        return MVCCManager()

    def test_mvcc_manager_initialization(self, mvcc_manager):
        """Test initializing MVCC manager."""
        assert mvcc_manager is not None

    def test_create_snapshot(self, mvcc_manager):
        """Test creating a transaction snapshot."""
        timestamp = time.time()
        mvcc_manager.create_snapshot("txn_1", timestamp)
        snapshot_ts = mvcc_manager.get_snapshot_timestamp("txn_1")
        assert snapshot_ts == timestamp

    def test_get_snapshot_none(self, mvcc_manager):
        """Test getting snapshot for non-existent transaction."""
        snapshot_ts = mvcc_manager.get_snapshot_timestamp("txn_nonexistent")
        assert snapshot_ts is None

    def test_create_version(self, mvcc_manager):
        """Test creating a data version."""
        timestamp = time.time()
        version = mvcc_manager.create_version(
            resource="table:users:1",
            transaction_id="txn_1",
            data={"name": "Alice", "age": 30},
            timestamp=timestamp
        )
        assert version is not None
        assert version.transaction_id == "txn_1"
        assert version.data == {"name": "Alice", "age": 30}
        assert version.deleted is False

    def test_get_version(self, mvcc_manager):
        """Test getting a version for a transaction."""
        timestamp = time.time()
        # Create version
        version = mvcc_manager.create_version(
            resource="table:users:1",
            transaction_id="txn_1",
            data={"name": "Alice"},
            timestamp=timestamp
        )
        # Get version
        retrieved = mvcc_manager.get_version(
            resource="table:users:1",
            transaction_id="txn_1"
        )
        assert retrieved is not None
        assert retrieved.version_id == version.version_id

    def test_get_version_for_snapshot(self, mvcc_manager):
        """Test getting version visible to a transaction snapshot."""
        base_time = time.time()
        # Create snapshot for txn_1 at base_time
        mvcc_manager.create_snapshot("txn_1", base_time)
        # Create version at base_time + 1 (after snapshot)
        mvcc_manager.create_version(
            resource="table:users:1",
            transaction_id="txn_2",
            data={"name": "Bob"},
            timestamp=base_time + 1
        )
        # txn_1 should not see version created after its snapshot
        version = mvcc_manager.get_version(
            resource="table:users:1",
            transaction_id="txn_1",
            snapshot_timestamp=base_time
        )
        # Should return None or earlier version
        assert version is None or version.created_at <= base_time

    def test_mark_version_deleted(self, mvcc_manager):
        """Test marking a version as deleted."""
        timestamp = time.time()
        version = mvcc_manager.create_version(
            resource="table:users:1",
            transaction_id="txn_1",
            data={"name": "Alice"},
            timestamp=timestamp
        )
        mvcc_manager.mark_version_deleted(
            resource="table:users:1",
            transaction_id="txn_1",
            timestamp=timestamp + 1
        )
        # Version should be marked as deleted
        retrieved = mvcc_manager.get_version(
            resource="table:users:1",
            transaction_id="txn_1"
        )
        # Check if version is deleted (implementation may vary)
        assert retrieved is not None
