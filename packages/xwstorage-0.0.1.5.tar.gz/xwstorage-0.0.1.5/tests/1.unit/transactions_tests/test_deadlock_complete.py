#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_deadlock_complete.py
Complete comprehensive tests for Deadlock detection and resolution.
Tests various deadlock scenarios, edge cases, and resolution strategies.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 21-Dec-2025
"""

import pytest
import asyncio
from typing import Optional
from exonware.xwstorage.transactions.deadlock import DeadlockDetector
from exonware.xwstorage.core.lock_manager import LockManager
@pytest.mark.xwstorage_unit

class TestDeadlockDetectionComplete:
    """
    Complete comprehensive tests for deadlock detection.
    Tests:
    - Simple 2-transaction deadlock
    - Complex multi-transaction deadlock cycles
    - Edge cases (self-deadlock, circular dependencies)
    - Deadlock resolution strategies
    - Performance with many transactions
    """
    @pytest.fixture

    def lock_manager(self):
        """Create lock manager fixture."""
        return LockManager()
    @pytest.fixture

    def detector(self, lock_manager):
        """Create deadlock detector fixture."""
        return DeadlockDetector(lock_manager)
    # ==================== Simple Deadlock Tests ====================
    @pytest.mark.asyncio

    async def test_simple_two_transaction_deadlock(self, detector, lock_manager):
        """
        Test simple 2-transaction deadlock.
        Transaction 1: locks A, waits for B
        Transaction 2: locks B, waits for A
        Result: Deadlock cycle T1 -> T2 -> T1
        """
        # Transaction 1 locks resource A
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_1"
        )
        # Transaction 2 locks resource B
        await lock_manager.acquire_lock(
            resource="resource:B",
            lock_mode="exclusive",
            transaction_id="txn_2"
        )
        # Transaction 1 tries to lock B (waits for txn_2)
        await lock_manager.acquire_lock(
            resource="resource:B",
            lock_mode="exclusive",
            transaction_id="txn_1"
        )
        # Transaction 2 tries to lock A (waits for txn_1) - deadlock!
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_2"
        )
        # Detect deadlock
        deadlock_cycle = await detector.detect_and_resolve()
        assert deadlock_cycle is not None
        assert len(deadlock_cycle) >= 2
        assert "txn_1" in deadlock_cycle
        assert "txn_2" in deadlock_cycle
    @pytest.mark.asyncio

    async def test_no_deadlock_single_transaction(self, detector):
        """Test no deadlock when single transaction holds locks."""
        has_deadlock = await detector.check_deadlock()
        assert has_deadlock is False
    @pytest.mark.asyncio

    async def test_no_deadlock_sequential_locks(self, detector, lock_manager):
        """Test no deadlock when locks are acquired sequentially."""
        # Transaction 1 locks A
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_1"
        )
        # Transaction 1 releases A
        await lock_manager.release_lock("resource:A", "txn_1")
        # Transaction 2 locks A
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_2"
        )
        # No deadlock
        has_deadlock = await detector.check_deadlock()
        assert has_deadlock is False
    # ==================== Complex Deadlock Tests ====================
    @pytest.mark.asyncio

    async def test_three_transaction_deadlock_cycle(self, detector, lock_manager):
        """
        Test 3-transaction deadlock cycle.
        Transaction 1: locks A, waits for B
        Transaction 2: locks B, waits for C
        Transaction 3: locks C, waits for A
        Result: Deadlock cycle T1 -> T2 -> T3 -> T1
        """
        # Transaction 1 locks A
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_1"
        )
        # Transaction 2 locks B
        await lock_manager.acquire_lock(
            resource="resource:B",
            lock_mode="exclusive",
            transaction_id="txn_2"
        )
        # Transaction 3 locks C
        await lock_manager.acquire_lock(
            resource="resource:C",
            lock_mode="exclusive",
            transaction_id="txn_3"
        )
        # Transaction 1 tries to lock B (waits for txn_2)
        await lock_manager.acquire_lock(
            resource="resource:B",
            lock_mode="exclusive",
            transaction_id="txn_1"
        )
        # Transaction 2 tries to lock C (waits for txn_3)
        await lock_manager.acquire_lock(
            resource="resource:C",
            lock_mode="exclusive",
            transaction_id="txn_2"
        )
        # Transaction 3 tries to lock A (waits for txn_1) - deadlock!
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_3"
        )
        # Detect deadlock
        deadlock_cycle = await detector.detect_and_resolve()
        assert deadlock_cycle is not None
        assert len(deadlock_cycle) >= 3
        assert "txn_1" in deadlock_cycle
        assert "txn_2" in deadlock_cycle
        assert "txn_3" in deadlock_cycle
    @pytest.mark.asyncio

    async def test_four_transaction_deadlock_cycle(self, detector, lock_manager):
        """Test 4-transaction deadlock cycle."""
        resources = ["A", "B", "C", "D"]
        txns = ["txn_1", "txn_2", "txn_3", "txn_4"]
        # Each transaction locks one resource
        for i, txn in enumerate(txns):
            await lock_manager.acquire_lock(
                resource=f"resource:{resources[i]}",
                lock_mode="exclusive",
                transaction_id=txn
            )
        # Each transaction tries to lock next resource (circular)
        for i, txn in enumerate(txns):
            next_resource = resources[(i + 1) % len(resources)]
            await lock_manager.acquire_lock(
                resource=f"resource:{next_resource}",
                lock_mode="exclusive",
                transaction_id=txn
            )
        # Detect deadlock
        deadlock_cycle = await detector.detect_and_resolve()
        assert deadlock_cycle is not None
        assert len(deadlock_cycle) >= 4
    # ==================== Edge Case Tests ====================
    @pytest.mark.asyncio

    async def test_shared_locks_no_deadlock(self, detector, lock_manager):
        """Test that shared locks don't cause deadlocks."""
        # Multiple transactions can hold shared locks
        for i in range(5):
            await lock_manager.acquire_lock(
                resource="resource:A",
                lock_mode="shared",
                transaction_id=f"txn_{i}"
            )
        # No deadlock with shared locks
        has_deadlock = await detector.check_deadlock()
        assert has_deadlock is False
        # Clean up
        for i in range(5):
            await lock_manager.release_lock("resource:A", f"txn_{i}")
    @pytest.mark.asyncio

    async def test_shared_exclusive_conflict_no_deadlock(self, detector, lock_manager):
        """Test shared-exclusive conflict doesn't create deadlock."""
        # Transaction 1 has shared lock
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="shared",
            transaction_id="txn_1"
        )
        # Transaction 2 tries exclusive (blocked, but not deadlock)
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_2"
        )
        # No deadlock (only one waiting transaction)
        has_deadlock = await detector.check_deadlock()
        assert has_deadlock is False
    @pytest.mark.asyncio

    async def test_multiple_resources_per_transaction(self, detector, lock_manager):
        """Test deadlock with transactions holding multiple resources."""
        # Transaction 1 locks A and B
        await lock_manager.acquire_lock("resource:A", "exclusive", "txn_1")
        await lock_manager.acquire_lock("resource:B", "exclusive", "txn_1")
        # Transaction 2 locks C and D
        await lock_manager.acquire_lock("resource:C", "exclusive", "txn_2")
        await lock_manager.acquire_lock("resource:D", "exclusive", "txn_2")
        # Transaction 1 tries to lock C (waits for txn_2)
        await lock_manager.acquire_lock("resource:C", "exclusive", "txn_1")
        # Transaction 2 tries to lock A (waits for txn_1) - deadlock!
        await lock_manager.acquire_lock("resource:A", "exclusive", "txn_2")
        deadlock_cycle = await detector.detect_and_resolve()
        assert deadlock_cycle is not None
        assert "txn_1" in deadlock_cycle
        assert "txn_2" in deadlock_cycle
    @pytest.mark.asyncio

    async def test_deadlock_resolution_clears_wait_for_graph(self, detector, lock_manager):
        """Test that deadlock resolution clears wait-for graph."""
        # Create deadlock
        await lock_manager.acquire_lock("resource:A", "exclusive", "txn_1")
        await lock_manager.acquire_lock("resource:B", "exclusive", "txn_2")
        await lock_manager.acquire_lock("resource:B", "exclusive", "txn_1")
        await lock_manager.acquire_lock("resource:A", "exclusive", "txn_2")
        # Detect and resolve
        deadlock_cycle = await detector.detect_and_resolve()
        assert deadlock_cycle is not None
        # After resolution, should be able to acquire locks
        # (In real implementation, one transaction would be aborted)
        # For testing, verify detector can detect the deadlock
    @pytest.mark.asyncio

    async def test_check_deadlock_vs_detect_and_resolve(self, detector, lock_manager):
        """Test difference between check_deadlock and detect_and_resolve."""
        # Create deadlock
        await lock_manager.acquire_lock("resource:A", "exclusive", "txn_1")
        await lock_manager.acquire_lock("resource:B", "exclusive", "txn_2")
        await lock_manager.acquire_lock("resource:B", "exclusive", "txn_1")
        await lock_manager.acquire_lock("resource:A", "exclusive", "txn_2")
        # check_deadlock returns boolean
        has_deadlock = await detector.check_deadlock()
        assert has_deadlock is True
        # detect_and_resolve returns cycle list
        cycle = await detector.detect_and_resolve()
        assert cycle is not None
        assert isinstance(cycle, list)
    # ==================== Performance Tests ====================
    @pytest.mark.asyncio

    async def test_deadlock_detection_with_many_transactions(self, detector, lock_manager):
        """Test deadlock detection performance with many transactions."""
        num_transactions = 10
        resources = [f"resource:{chr(65+i)}" for i in range(num_transactions)]
        txns = [f"txn_{i}" for i in range(num_transactions)]
        # Each transaction locks one resource
        for i, txn in enumerate(txns):
            await lock_manager.acquire_lock(
                resource=resources[i],
                lock_mode="exclusive",
                transaction_id=txn
            )
        # Create circular dependencies
        for i, txn in enumerate(txns):
            next_resource = resources[(i + 1) % len(resources)]
            await lock_manager.acquire_lock(
                resource=next_resource,
                lock_mode="exclusive",
                transaction_id=txn
            )
        # Detect deadlock
        deadlock_cycle = await detector.detect_and_resolve()
        assert deadlock_cycle is not None
        assert len(deadlock_cycle) >= 2
    @pytest.mark.asyncio

    async def test_no_deadlock_with_many_transactions(self, detector, lock_manager):
        """Test no false positives with many transactions."""
        num_transactions = 20
        # All transactions acquire shared locks (no conflict)
        for i in range(num_transactions):
            await lock_manager.acquire_lock(
                resource="resource:shared",
                lock_mode="shared",
                transaction_id=f"txn_{i}"
            )
        # No deadlock
        has_deadlock = await detector.check_deadlock()
        assert has_deadlock is False
        # Clean up
        for i in range(num_transactions):
            await lock_manager.release_lock("resource:shared", f"txn_{i}")
    # ==================== Real-World Scenario Tests ====================
    @pytest.mark.asyncio

    async def test_bank_account_transfer_deadlock(self, detector, lock_manager):
        """
        Test classic bank account transfer deadlock scenario.
        Transaction 1: Transfer from Account A to Account B
        Transaction 2: Transfer from Account B to Account A
        Both lock accounts in different order -> deadlock
        """
        # Transaction 1: Transfer A -> B (locks A first)
        await lock_manager.acquire_lock("account:A", "exclusive", "txn_1")
        await lock_manager.acquire_lock("account:B", "exclusive", "txn_1")
        # Transaction 2: Transfer B -> A (locks B first)
        await lock_manager.acquire_lock("account:B", "exclusive", "txn_2")
        await lock_manager.acquire_lock("account:A", "exclusive", "txn_2")
        # Actually, this won't deadlock because txn_1 already has both locks
        # Let's create proper scenario:
        # Reset
        await lock_manager.release_all_locks("txn_1")
        await lock_manager.release_all_locks("txn_2")
        # Transaction 1 locks A
        await lock_manager.acquire_lock("account:A", "exclusive", "txn_1")
        # Transaction 2 locks B
        await lock_manager.acquire_lock("account:B", "exclusive", "txn_2")
        # Transaction 1 tries to lock B (waits for txn_2)
        await lock_manager.acquire_lock("account:B", "exclusive", "txn_1")
        # Transaction 2 tries to lock A (waits for txn_1) - deadlock!
        await lock_manager.acquire_lock("account:A", "exclusive", "txn_2")
        deadlock_cycle = await detector.detect_and_resolve()
        assert deadlock_cycle is not None
    @pytest.mark.asyncio

    async def test_concurrent_updates_deadlock(self, detector, lock_manager):
        """Test deadlock with concurrent updates to related records."""
        # Transaction 1: Update user, then update user's posts
        await lock_manager.acquire_lock("user:1", "exclusive", "txn_1")
        await lock_manager.acquire_lock("post:user:1", "exclusive", "txn_1")
        # Transaction 2: Update post, then update post's user (reverse order)
        await lock_manager.acquire_lock("post:user:1", "exclusive", "txn_2")
        await lock_manager.acquire_lock("user:1", "exclusive", "txn_2")
        # Reset for proper deadlock
        await lock_manager.release_all_locks("txn_1")
        await lock_manager.release_all_locks("txn_2")
        # Transaction 1 locks user:1
        await lock_manager.acquire_lock("user:1", "exclusive", "txn_1")
        # Transaction 2 locks post:user:1
        await lock_manager.acquire_lock("post:user:1", "exclusive", "txn_2")
        # Transaction 1 tries to lock post (waits)
        await lock_manager.acquire_lock("post:user:1", "exclusive", "txn_1")
        # Transaction 2 tries to lock user (waits) - deadlock!
        await lock_manager.acquire_lock("user:1", "exclusive", "txn_2")
        deadlock_cycle = await detector.detect_and_resolve()
        assert deadlock_cycle is not None
