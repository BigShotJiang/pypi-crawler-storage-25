#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_mvcc_enhanced.py
Comprehensive unit tests for enhanced MVCC features.
Tests snapshot isolation, version tracking, revision history,
conflict detection, and automatic version management.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
import time
from exonware.xwstorage.transactions.mvcc import (
    MVCCManager,
    Version,
    VersionStatus,
    ConflictError
)
@pytest.mark.xwstorage_unit

class TestMVCCEnhanced:
    """Test enhanced MVCC features."""
    @pytest.fixture

    def mvcc_manager(self):
        """Create MVCC manager fixture."""
        return MVCCManager()
    @pytest.fixture

    def base_time(self):
        """Get base timestamp for tests."""
        return time.time()

    def test_version_visibility_same_transaction(self, mvcc_manager, base_time):
        """Test that transaction sees its own versions."""
        txn_id = "txn_1"
        mvcc_manager.create_snapshot(txn_id, base_time)
        # Create version
        version = mvcc_manager.create_version("resource:1", txn_id, {"data": "test"}, base_time + 1)
        # Transaction should see its own version even if uncommitted
        retrieved = mvcc_manager.get_version("resource:1", txn_id)
        assert retrieved is not None
        assert retrieved.version_id == version.version_id

    def test_version_visibility_committed(self, mvcc_manager, base_time):
        """Test that committed versions are visible to other transactions."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        # Transaction 1 creates snapshot and version
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        version = mvcc_manager.create_version("resource:1", txn_1_id, {"data": "test"}, base_time + 1)
        mvcc_manager.commit_transaction(txn_1_id, base_time + 2)
        # Transaction 2 creates snapshot after commit
        mvcc_manager.create_snapshot(txn_2_id, base_time + 3)
        # Transaction 2 should see committed version
        retrieved = mvcc_manager.get_version("resource:1", txn_2_id)
        assert retrieved is not None
        assert retrieved.version_id == version.version_id
        assert retrieved.status == VersionStatus.COMMITTED

    def test_version_visibility_uncommitted_not_visible(self, mvcc_manager, base_time):
        """Test that uncommitted versions are not visible to other transactions."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        # Transaction 1 creates version but doesn't commit
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        mvcc_manager.create_version("resource:1", txn_1_id, {"data": "test"}, base_time + 1)
        # Transaction 2 creates snapshot
        mvcc_manager.create_snapshot(txn_2_id, base_time + 2)
        # Transaction 2 should not see uncommitted version
        retrieved = mvcc_manager.get_version("resource:1", txn_2_id)
        assert retrieved is None

    def test_snapshot_isolation(self, mvcc_manager, base_time):
        """Test snapshot isolation - transaction sees consistent snapshot."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        # Transaction 1 creates version at base_time + 1
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        mvcc_manager.create_version("resource:1", txn_1_id, {"value": 1}, base_time + 1)
        mvcc_manager.commit_transaction(txn_1_id, base_time + 2)
        # Transaction 2 creates snapshot at base_time + 3
        mvcc_manager.create_snapshot(txn_2_id, base_time + 3)
        # Transaction 2 should see version created before its snapshot
        retrieved = mvcc_manager.get_version("resource:1", txn_2_id)
        assert retrieved is not None
        assert retrieved.data["value"] == 1

    def test_write_conflict_detection(self, mvcc_manager, base_time):
        """Test write conflict detection between concurrent transactions."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        # Transaction 1 creates snapshot and version
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        mvcc_manager.create_version("resource:1", txn_1_id, {"value": 1}, base_time + 1)
        # Transaction 2 creates snapshot after txn_1's snapshot but before commit
        mvcc_manager.create_snapshot(txn_2_id, base_time + 0.5)
        # Transaction 2 tries to modify same resource - should raise ConflictError
        with pytest.raises(ConflictError) as exc_info:
            mvcc_manager.create_version("resource:1", txn_2_id, {"value": 2}, base_time + 2)
        assert exc_info.value.transaction_id == txn_2_id
        assert exc_info.value.conflicting_transaction_id == txn_1_id

    def test_no_conflict_after_commit(self, mvcc_manager, base_time):
        """Test that no conflict occurs if previous transaction committed."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        # Transaction 1 creates and commits
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        mvcc_manager.create_version("resource:1", txn_1_id, {"value": 1}, base_time + 1)
        mvcc_manager.commit_transaction(txn_1_id, base_time + 2)
        # Transaction 2 creates snapshot after commit
        mvcc_manager.create_snapshot(txn_2_id, base_time + 3)
        # Transaction 2 should be able to modify (no conflict)
        version = mvcc_manager.create_version("resource:1", txn_2_id, {"value": 2}, base_time + 4)
        assert version is not None

    def test_revision_history(self, mvcc_manager, base_time):
        """Test revision history tracking."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        # Create multiple versions
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        v1 = mvcc_manager.create_version("resource:1", txn_1_id, {"value": 1}, base_time + 1)
        mvcc_manager.commit_transaction(txn_1_id, base_time + 2)
        mvcc_manager.create_snapshot(txn_2_id, base_time + 3)
        v2 = mvcc_manager.create_version("resource:1", txn_2_id, {"value": 2}, base_time + 4)
        mvcc_manager.commit_transaction(txn_2_id, base_time + 5)
        # Get revision history
        history = mvcc_manager.get_revision_history("resource:1")
        assert len(history) == 2
        assert history[0].version_id == v1.version_id
        assert history[1].version_id == v2.version_id

    def test_revision_history_limit(self, mvcc_manager, base_time):
        """Test revision history with limit."""
        txn_id = "txn_1"
        mvcc_manager.create_snapshot(txn_id, base_time)
        # Create multiple versions
        for i in range(5):
            mvcc_manager.create_version("resource:1", txn_id, {"value": i}, base_time + i + 1)
        mvcc_manager.commit_transaction(txn_id, base_time + 10)
        # Get last 2 revisions
        history = mvcc_manager.get_revision_history("resource:1", limit=2)
        assert len(history) == 2

    def test_transaction_commit(self, mvcc_manager, base_time):
        """Test transaction commit marks versions as committed."""
        txn_id = "txn_1"
        mvcc_manager.create_snapshot(txn_id, base_time)
        version = mvcc_manager.create_version("resource:1", txn_id, {"value": 1}, base_time + 1)
        assert version.status == VersionStatus.UNCOMMITTED
        mvcc_manager.commit_transaction(txn_id, base_time + 2)
        # Version should be marked as committed
        retrieved = mvcc_manager.get_version("resource:1", txn_id)
        assert retrieved is not None
        assert retrieved.status == VersionStatus.COMMITTED
        assert retrieved.committed_at == base_time + 2

    def test_transaction_abort(self, mvcc_manager, base_time):
        """Test transaction abort marks versions as aborted."""
        txn_id = "txn_1"
        mvcc_manager.create_snapshot(txn_id, base_time)
        version = mvcc_manager.create_version("resource:1", txn_id, {"value": 1}, base_time + 1)
        mvcc_manager.abort_transaction(txn_id)
        # Version should be marked as aborted
        retrieved = mvcc_manager.get_version("resource:1", txn_id)
        # Aborted versions are not visible
        assert retrieved is None or retrieved.status == VersionStatus.ABORTED

    def test_detect_conflicts(self, mvcc_manager, base_time):
        """Test conflict detection method."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        # Transaction 1 creates uncommitted version
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        mvcc_manager.create_version("resource:1", txn_1_id, {"value": 1}, base_time + 1)
        # Transaction 2 creates snapshot
        mvcc_manager.create_snapshot(txn_2_id, base_time + 0.5)
        # Detect conflicts
        conflicts = mvcc_manager.detect_conflicts(txn_2_id, ["resource:1"])
        assert len(conflicts) == 1
        assert conflicts[0]["resource"] == "resource:1"
        assert conflicts[0]["conflicting_transaction_id"] == txn_1_id

    def test_deletion_tombstone(self, mvcc_manager, base_time):
        """Test deletion tombstone creation."""
        txn_id = "txn_1"
        mvcc_manager.create_snapshot(txn_id, base_time)
        # Create version
        version = mvcc_manager.create_version("resource:1", txn_id, {"value": 1}, base_time + 1)
        mvcc_manager.commit_transaction(txn_id, base_time + 2)
        # Mark as deleted
        mvcc_manager.mark_version_deleted("resource:1", txn_id, base_time + 3)
        # Version should be marked as deleted
        retrieved = mvcc_manager.get_version("resource:1", txn_id)
        assert retrieved is None or retrieved.deleted is True

    def test_get_latest_version(self, mvcc_manager, base_time):
        """Test getting latest committed version."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        # Create multiple versions
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        v1 = mvcc_manager.create_version("resource:1", txn_1_id, {"value": 1}, base_time + 1)
        mvcc_manager.commit_transaction(txn_1_id, base_time + 2)
        mvcc_manager.create_snapshot(txn_2_id, base_time + 3)
        v2 = mvcc_manager.create_version("resource:1", txn_2_id, {"value": 2}, base_time + 4)
        mvcc_manager.commit_transaction(txn_2_id, base_time + 5)
        # Latest version should be v2
        latest = mvcc_manager.get_latest_version("resource:1")
        assert latest is not None
        assert latest.version_id == v2.version_id
    @pytest.mark.asyncio

    async def test_garbage_collection(self, mvcc_manager, base_time):
        """Test garbage collection of old versions."""
        txn_id = "txn_1"
        mvcc_manager.create_snapshot(txn_id, base_time)
        # Create old versions
        for i in range(5):
            mvcc_manager.create_version("resource:1", txn_id, {"value": i}, base_time + i + 1)
        mvcc_manager.commit_transaction(txn_id, base_time + 10)
        # Garbage collect versions older than base_time + 7
        collected = await mvcc_manager.garbage_collect(base_time + 7)
        assert collected > 0
        # Verify old versions are gone
        history = mvcc_manager.get_revision_history("resource:1")
        # Should have kept at least the latest committed version
        assert len(history) >= 1

    def test_get_stats(self, mvcc_manager, base_time):
        """Test MVCC statistics."""
        txn_id = "txn_1"
        mvcc_manager.create_snapshot(txn_id, base_time)
        # Create some versions
        mvcc_manager.create_version("resource:1", txn_id, {"value": 1}, base_time + 1)
        mvcc_manager.create_version("resource:2", txn_id, {"value": 2}, base_time + 2)
        mvcc_manager.commit_transaction(txn_id, base_time + 3)
        stats = mvcc_manager.get_stats()
        assert stats["total_versions"] == 2
        assert stats["committed_versions"] == 2
        assert stats["resources"] == 2
        assert stats["committed_transactions"] == 1

    def test_version_chain_with_previous_version_id(self, mvcc_manager, base_time):
        """Test version chain tracking with previous_version_id."""
        txn_1_id = "txn_1"
        txn_2_id = "txn_2"
        mvcc_manager.create_snapshot(txn_1_id, base_time)
        v1 = mvcc_manager.create_version("resource:1", txn_1_id, {"value": 1}, base_time + 1)
        mvcc_manager.commit_transaction(txn_1_id, base_time + 2)
        mvcc_manager.create_snapshot(txn_2_id, base_time + 3)
        v2 = mvcc_manager.create_version("resource:1", txn_2_id, {"value": 2}, base_time + 4)
        # v2 should have v1 as previous version
        assert v2.previous_version_id == v1.version_id
