#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_deadlock.py
Unit tests for Deadlock detection.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.transactions.deadlock import DeadlockDetector
@pytest.mark.xwstorage_unit

class TestDeadlockDetector:
    """Test DeadlockDetector implementation."""
    @pytest.fixture

    def lock_manager(self):
        """Create lock manager fixture."""
        from exonware.xwstorage.core.lock_manager import LockManager
        return LockManager()
    @pytest.fixture

    def detector(self, lock_manager):
        """Create deadlock detector fixture."""
        return DeadlockDetector(lock_manager)

    def test_deadlock_detector_initialization(self, detector):
        """Test initializing deadlock detector."""
        assert detector is not None
    @pytest.mark.asyncio

    async def test_detect_no_deadlock(self, detector):
        """Test detecting no deadlock when none exists."""
        # Use the detector's check method
        has_deadlock = await detector.check_deadlock()
        # Should return False when no deadlock
        assert isinstance(has_deadlock, bool)
    @pytest.mark.asyncio

    async def test_detect_and_resolve_deadlock(self, detector, lock_manager):
        """Test detecting and resolving a deadlock."""
        # Create a deadlock scenario
        # Transaction 1 locks resource A
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_1"
        )
        # Transaction 2 locks resource B
        await lock_manager.acquire_lock(
            resource="resource:B",
            lock_mode="exclusive",
            transaction_id="txn_2"
        )
        # Transaction 1 tries to lock B (waits for txn_2)
        await lock_manager.acquire_lock(
            resource="resource:B",
            lock_mode="exclusive",
            transaction_id="txn_1"
        )
        # Transaction 2 tries to lock A (waits for txn_1) - deadlock!
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode="exclusive",
            transaction_id="txn_2"
        )
        # Detect and resolve
        deadlock_cycle = await detector.detect_and_resolve()
        # May return None or a list of transaction IDs
        assert deadlock_cycle is None or isinstance(deadlock_cycle, list)
    @pytest.mark.asyncio

    async def test_check_deadlock(self, detector):
        """Test checking for deadlock."""
        has_deadlock = await detector.check_deadlock()
        assert isinstance(has_deadlock, bool)
