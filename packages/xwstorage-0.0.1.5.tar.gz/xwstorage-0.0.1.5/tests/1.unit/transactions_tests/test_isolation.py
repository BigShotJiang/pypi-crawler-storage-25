#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_isolation.py
Unit tests for Transaction isolation levels.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.transactions.isolation import IsolationManager
from exonware.xwstorage.core.lock_manager import LockManager
from exonware.xwstorage.defs import IsolationLevel
@pytest.mark.xwstorage_unit

class TestIsolationManager:
    """Test IsolationManager implementation."""
    @pytest.fixture

    def lock_manager(self):
        """Create lock manager fixture."""
        return LockManager()
    @pytest.fixture

    def isolation_manager(self, lock_manager):
        """Create isolation manager fixture."""
        return IsolationManager(lock_manager)
    @pytest.mark.asyncio

    async def test_isolation_manager_initialization(self, isolation_manager):
        """Test initializing isolation manager."""
        assert isolation_manager.lock_manager is not None
    @pytest.mark.asyncio

    async def test_read_uncommitted_no_locks(self, isolation_manager):
        """Test that READ_UNCOMMITTED doesn't acquire locks."""
        result = await isolation_manager.acquire_read_lock(
            resource="table:users",
            transaction_id="txn_1",
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_read_committed_shared_lock(self, isolation_manager):
        """Test that READ_COMMITTED acquires shared locks."""
        result = await isolation_manager.acquire_read_lock(
            resource="table:users",
            transaction_id="txn_1",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_repeatable_read_shared_lock(self, isolation_manager):
        """Test that REPEATABLE_READ acquires shared locks."""
        result = await isolation_manager.acquire_read_lock(
            resource="table:users",
            transaction_id="txn_1",
            isolation_level=IsolationLevel.REPEATABLE_READ
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_serializable_shared_lock(self, isolation_manager):
        """Test that SERIALIZABLE acquires shared locks."""
        result = await isolation_manager.acquire_read_lock(
            resource="table:users",
            transaction_id="txn_1",
            isolation_level=IsolationLevel.SERIALIZABLE
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_write_lock_exclusive(self, isolation_manager):
        """Test that write locks are always exclusive."""
        result = await isolation_manager.acquire_write_lock(
            resource="table:users",
            transaction_id="txn_1",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_release_locks(self, isolation_manager):
        """Test releasing locks for a transaction."""
        # Acquire locks
        await isolation_manager.acquire_read_lock(
            resource="table:users",
            transaction_id="txn_1",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Release locks
        await isolation_manager.release_locks("txn_1")
        # Should be able to acquire exclusive lock now
        result = await isolation_manager.acquire_write_lock(
            resource="table:users",
            transaction_id="txn_2",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        assert result is True
