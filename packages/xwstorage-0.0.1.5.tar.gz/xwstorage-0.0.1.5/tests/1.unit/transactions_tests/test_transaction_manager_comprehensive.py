#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_transaction_manager_comprehensive.py
Comprehensive unit tests for Transaction manager with complex scenarios.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import asyncio
from exonware.xwstorage.transactions.manager import TransactionManager
from exonware.xwstorage.defs import IsolationLevel
@pytest.mark.xwstorage_unit

class TestTransactionManagerComprehensive:
    """Comprehensive tests for TransactionManager."""
    @pytest.fixture

    def tx_manager(self):
        """Create transaction manager fixture."""
        return TransactionManager()
    @pytest.mark.asyncio

    async def test_concurrent_transactions(self, tx_manager):
        """Test concurrent transactions."""
        async def run_transaction(txn_id):
            txn = tx_manager.begin_transaction(
                isolation_level=IsolationLevel.READ_COMMITTED,
                transaction_id=txn_id,
            )
            assert txn.transaction_id == txn_id
            await tx_manager.commit_transaction(txn.transaction_id)
        # Run 10 concurrent transactions
        await asyncio.gather(*[
            run_transaction(f"txn_{i}") for i in range(10)
        ])
    @pytest.mark.asyncio

    async def test_nested_savepoints(self, tx_manager):
        """Test nested savepoints."""
        txn = tx_manager.begin_transaction(
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Create savepoints
        await txn.create_savepoint("sp1")
        await txn.create_savepoint("sp2")
        await txn.create_savepoint("sp3")
        assert len(txn.savepoints) == 3
        # Rollback to middle savepoint
        await txn.rollback_to_savepoint("sp2")
        assert "sp3" not in txn.savepoints
        await tx_manager.commit_transaction(txn.transaction_id)
    @pytest.mark.asyncio

    async def test_transaction_timeout(self, tx_manager):
        """Test transaction timeout."""
        txn = tx_manager.begin_transaction(
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Transaction should have start time
        assert txn.start_time > 0
        await tx_manager.commit_transaction(txn.transaction_id)
    @pytest.mark.asyncio

    async def test_transaction_rollback_all(self, tx_manager):
        """Test rolling back all changes."""
        txn = tx_manager.begin_transaction(
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Create savepoints
        await txn.create_savepoint("sp1")
        # Rollback entire transaction
        await tx_manager.rollback_transaction(txn.transaction_id)
        assert txn.state.value == "rolled_back"
    @pytest.mark.asyncio

    async def test_all_isolation_levels(self, tx_manager):
        """Test all isolation levels."""
        isolation_levels = [
            IsolationLevel.READ_UNCOMMITTED,
            IsolationLevel.READ_COMMITTED,
            IsolationLevel.REPEATABLE_READ,
            IsolationLevel.SERIALIZABLE
        ]
        for level in isolation_levels:
            txn = tx_manager.begin_transaction(isolation_level=level)
            assert txn.isolation_level == level.value
            await tx_manager.commit_transaction(txn.transaction_id)
