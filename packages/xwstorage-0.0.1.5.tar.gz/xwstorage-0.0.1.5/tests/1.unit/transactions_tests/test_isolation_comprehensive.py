#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_isolation_comprehensive.py
Comprehensive unit tests for Transaction isolation with complex scenarios.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import asyncio
from exonware.xwstorage.transactions.isolation import IsolationManager
from exonware.xwstorage.core.lock_manager import LockManager
from exonware.xwstorage.defs import IsolationLevel
@pytest.mark.xwstorage_unit

class TestIsolationComprehensive:
    """Comprehensive tests for IsolationManager."""
    @pytest.fixture

    def isolation_manager(self):
        """Create isolation manager fixture."""
        return IsolationManager(LockManager())
    @pytest.mark.asyncio

    async def test_isolation_read_uncommitted_dirty_reads(self, isolation_manager):
        """Test READ_UNCOMMITTED allows dirty reads."""
        # Transaction 1 writes
        await isolation_manager.acquire_write_lock(
            resource="table:users",
            transaction_id="txn_1",
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
        # Transaction 2 can read without lock (dirty read allowed)
        result = await isolation_manager.acquire_read_lock(
            resource="table:users",
            transaction_id="txn_2",
            isolation_level=IsolationLevel.READ_UNCOMMITTED
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_isolation_read_committed_no_dirty_reads(self, isolation_manager):
        """Test READ_COMMITTED prevents dirty reads."""
        # Transaction 1 writes (exclusive lock)
        await isolation_manager.acquire_write_lock(
            resource="table:users",
            transaction_id="txn_1",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Transaction 2 tries to read (should wait or fail)
        result = await isolation_manager.acquire_read_lock(
            resource="table:users",
            transaction_id="txn_2",
            isolation_level=IsolationLevel.READ_COMMITTED
        )
        # Should be blocked or return False
        assert isinstance(result, bool)
    @pytest.mark.asyncio

    async def test_isolation_repeatable_read_consistency(self, isolation_manager):
        """Test REPEATABLE_READ maintains consistency."""
        # Transaction reads same resource multiple times
        for _ in range(5):
            result = await isolation_manager.acquire_read_lock(
                resource="table:users",
                transaction_id="txn_1",
                isolation_level=IsolationLevel.REPEATABLE_READ
            )
            assert result is True
    @pytest.mark.asyncio

    async def test_isolation_serializable_strictest(self, isolation_manager):
        """Test SERIALIZABLE provides strictest isolation."""
        # Multiple transactions with SERIALIZABLE
        results = []
        for i in range(3):
            result = await isolation_manager.acquire_read_lock(
                resource="table:users",
                transaction_id=f"txn_{i}",
                isolation_level=IsolationLevel.SERIALIZABLE
            )
            results.append(result)
        # All should acquire locks (or be queued)
        assert all(isinstance(r, bool) for r in results)
