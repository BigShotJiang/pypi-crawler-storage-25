#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/transactions_tests/test_deadlock_enhanced.py
Comprehensive unit tests for enhanced Deadlock detection.
Tests improved victim selection, periodic detection, and resolution strategies.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
import asyncio
import time
from exonware.xwstorage.transactions.deadlock import (
    DeadlockDetector,
    VictimSelectionStrategy,
    TransactionMetadata
)
from exonware.xwstorage.core.lock_manager import LockManager
from exonware.xwstorage.defs import LockMode
@pytest.mark.xwstorage_unit

class TestDeadlockDetectorEnhanced:
    """Test enhanced DeadlockDetector implementation with victim selection."""
    @pytest.fixture

    def lock_manager(self):
        """Create lock manager fixture."""
        return LockManager()
    @pytest.fixture

    def detector_youngest(self, lock_manager):
        """Create deadlock detector with youngest strategy."""
        return DeadlockDetector(
            lock_manager,
            victim_strategy=VictimSelectionStrategy.YOUNGEST
        )
    @pytest.fixture

    def detector_least_work(self, lock_manager):
        """Create deadlock detector with least work strategy."""
        return DeadlockDetector(
            lock_manager,
            victim_strategy=VictimSelectionStrategy.LEAST_WORK
        )
    @pytest.fixture

    def detector_longest_wait(self, lock_manager):
        """Create deadlock detector with longest wait strategy."""
        return DeadlockDetector(
            lock_manager,
            victim_strategy=VictimSelectionStrategy.LONGEST_WAIT
        )

    def _create_transaction_metadata(self, txn_id: str, start_time: float, operation_count: int = 0) -> TransactionMetadata:
        """Helper to create transaction metadata."""
        return TransactionMetadata(
            transaction_id=txn_id,
            start_time=start_time,
            operation_count=operation_count
        )

    def _create_metadata_provider(self, metadatas: dict[str, TransactionMetadata]):
        """Create a metadata provider function."""
        def provider(txn_id: str) -> TransactionMetadata | None:
            return metadatas.get(txn_id)
        return provider
    @pytest.mark.asyncio

    async def test_victim_selection_youngest(self, detector_youngest, lock_manager):
        """Test victim selection using youngest strategy."""
        # Create deadlock scenario
        await lock_manager.acquire_lock("resource:A", LockMode.EXCLUSIVE, "txn_1")
        await lock_manager.acquire_lock("resource:B", LockMode.EXCLUSIVE, "txn_2")
        # Create wait-for relationships (simulate deadlock)
        lock_manager._wait_for["txn_1"].add("txn_2")
        lock_manager._wait_for["txn_2"].add("txn_1")
        # Create metadata provider with different start times
        current_time = time.time()
        metadatas = {
            "txn_1": self._create_transaction_metadata("txn_1", current_time - 10.0, 5),
            "txn_2": self._create_transaction_metadata("txn_2", current_time - 5.0, 3),  # Younger
        }
        detector_youngest.transaction_metadata_provider = self._create_metadata_provider(metadatas)
        # Detect and resolve
        deadlock_cycle = await detector_youngest.detect_and_resolve()
        assert deadlock_cycle is not None
        assert len(deadlock_cycle) >= 2
    @pytest.mark.asyncio

    async def test_victim_selection_least_work(self, detector_least_work, lock_manager):
        """Test victim selection using least work strategy."""
        # Create deadlock scenario
        await lock_manager.acquire_lock("resource:A", LockMode.EXCLUSIVE, "txn_1")
        await lock_manager.acquire_lock("resource:B", LockMode.EXCLUSIVE, "txn_2")
        # Create wait-for relationships
        lock_manager._wait_for["txn_1"].add("txn_2")
        lock_manager._wait_for["txn_2"].add("txn_1")
        # Create metadata provider with different operation counts
        current_time = time.time()
        metadatas = {
            "txn_1": self._create_transaction_metadata("txn_1", current_time, 10),  # More work
            "txn_2": self._create_transaction_metadata("txn_2", current_time, 2),   # Less work
        }
        detector_least_work.transaction_metadata_provider = self._create_metadata_provider(metadatas)
        # Detect and resolve
        deadlock_cycle = await detector_least_work.detect_and_resolve()
        assert deadlock_cycle is not None
    @pytest.mark.asyncio

    async def test_victim_selection_longest_wait(self, detector_longest_wait, lock_manager):
        """Test victim selection using longest wait strategy."""
        # Create deadlock scenario
        await lock_manager.acquire_lock("resource:A", LockMode.EXCLUSIVE, "txn_1")
        await lock_manager.acquire_lock("resource:B", LockMode.EXCLUSIVE, "txn_2")
        # Create wait-for relationships
        lock_manager._wait_for["txn_1"].add("txn_2")
        lock_manager._wait_for["txn_2"].add("txn_1")
        # Create metadata provider with different wait times
        current_time = time.time()
        txn1_metadata = TransactionMetadata("txn_1", current_time, 5)
        txn1_metadata.wait_time = 5.0  # Longer wait
        txn2_metadata = TransactionMetadata("txn_2", current_time, 3)
        txn2_metadata.wait_time = 2.0  # Shorter wait
        metadatas = {
            "txn_1": txn1_metadata,
            "txn_2": txn2_metadata,
        }
        detector_longest_wait.transaction_metadata_provider = self._create_metadata_provider(metadatas)
        # Detect and resolve
        deadlock_cycle = await detector_longest_wait.detect_and_resolve()
        assert deadlock_cycle is not None
    @pytest.mark.asyncio

    async def test_victim_selection_default_strategy(self, lock_manager):
        """Test default victim selection strategy."""
        detector = DeadlockDetector(lock_manager)
        assert detector.victim_strategy == VictimSelectionStrategy.DEFAULT
    @pytest.mark.asyncio

    async def test_victim_selection_without_metadata(self, detector_youngest, lock_manager):
        """Test victim selection when metadata provider is not available."""
        # Create deadlock scenario
        await lock_manager.acquire_lock("resource:A", LockMode.EXCLUSIVE, "txn_1")
        await lock_manager.acquire_lock("resource:B", LockMode.EXCLUSIVE, "txn_2")
        # Create wait-for relationships
        lock_manager._wait_for["txn_1"].add("txn_2")
        lock_manager._wait_for["txn_2"].add("txn_1")
        # No metadata provider - should still work (selects first transaction)
        deadlock_cycle = await detector_youngest.detect_and_resolve()
        assert deadlock_cycle is not None
    @pytest.mark.asyncio

    async def test_periodic_detection_start_stop(self, detector_youngest):
        """Test starting and stopping periodic deadlock detection."""
        # Start periodic detection
        await detector_youngest.start_periodic_detection()
        assert detector_youngest._running is True
        assert detector_youngest._detection_task is not None
        # Wait a bit
        await asyncio.sleep(0.1)
        # Stop periodic detection
        await detector_youngest.stop_periodic_detection()
        assert detector_youngest._running is False
        assert detector_youngest._detection_task is None
    @pytest.mark.asyncio

    async def test_periodic_detection_with_victim_callback(self, detector_youngest, lock_manager):
        """Test periodic detection with victim callback."""
        victims: list[str] = []
        async def victim_callback(txn_id: str) -> None:
            """Track aborted victims."""
            victims.append(txn_id)
        # Set short interval for testing
        detector_youngest.set_detection_interval(0.1)
        # Create deadlock scenario
        await lock_manager.acquire_lock("resource:A", LockMode.EXCLUSIVE, "txn_1")
        await lock_manager.acquire_lock("resource:B", LockMode.EXCLUSIVE, "txn_2")
        lock_manager._wait_for["txn_1"].add("txn_2")
        lock_manager._wait_for["txn_2"].add("txn_1")
        # Start periodic detection
        await detector_youngest.start_periodic_detection(victim_callback)
        # Wait for at least one detection cycle
        await asyncio.sleep(0.15)
        # Stop detection
        await detector_youngest.stop_periodic_detection()
        # Victim callback should have been called if deadlock was detected
        # (May or may not be called depending on timing, but should not raise errors)
    @pytest.mark.asyncio

    async def test_periodic_detection_disabled(self, detector_youngest):
        """Test that periodic detection can be disabled."""
        detector_youngest.set_detection_interval(0)
        await detector_youngest.start_periodic_detection()
        # Should not start when interval is 0
        assert detector_youngest._running is False
    @pytest.mark.asyncio

    async def test_set_victim_strategy(self, detector_youngest):
        """Test updating victim selection strategy."""
        detector_youngest.set_victim_strategy(VictimSelectionStrategy.LEAST_WORK)
        assert detector_youngest.victim_strategy == VictimSelectionStrategy.LEAST_WORK
    @pytest.mark.asyncio

    async def test_set_detection_interval(self, detector_youngest):
        """Test updating detection interval."""
        detector_youngest.set_detection_interval(10.0)
        assert detector_youngest.detection_interval == 10.0
        # Disable
        detector_youngest.set_detection_interval(0)
        assert detector_youngest.detection_interval == 0
    @pytest.mark.asyncio

    async def test_detect_no_deadlock(self, detector_youngest):
        """Test detecting no deadlock when none exists."""
        has_deadlock = await detector_youngest.check_deadlock()
        assert has_deadlock is False
        deadlock_cycle = await detector_youngest.detect_and_resolve()
        assert deadlock_cycle is None
    @pytest.mark.asyncio

    async def test_detect_complex_deadlock_cycle(self, detector_youngest, lock_manager):
        """Test detecting complex deadlock cycle with multiple transactions."""
        # Create 3-way deadlock: txn_1 -> txn_2 -> txn_3 -> txn_1
        await lock_manager.acquire_lock("resource:A", LockMode.EXCLUSIVE, "txn_1")
        await lock_manager.acquire_lock("resource:B", LockMode.EXCLUSIVE, "txn_2")
        await lock_manager.acquire_lock("resource:C", LockMode.EXCLUSIVE, "txn_3")
        # Create wait-for relationships
        lock_manager._wait_for["txn_1"].add("txn_2")
        lock_manager._wait_for["txn_2"].add("txn_3")
        lock_manager._wait_for["txn_3"].add("txn_1")
        # Detect deadlock
        deadlock_cycle = await detector_youngest.detect_and_resolve()
        assert deadlock_cycle is not None
        assert len(deadlock_cycle) >= 3
    @pytest.mark.asyncio

    async def test_victim_callback_error_handling(self, detector_youngest, lock_manager):
        """Test that errors in victim callback don't crash detector."""
        error_raised = False
        async def error_callback(txn_id: str) -> None:
            """Raise error to test error handling."""
            nonlocal error_raised
            error_raised = True
            raise RuntimeError("Test error")
        # Create deadlock
        await lock_manager.acquire_lock("resource:A", LockMode.EXCLUSIVE, "txn_1")
        await lock_manager.acquire_lock("resource:B", LockMode.EXCLUSIVE, "txn_2")
        lock_manager._wait_for["txn_1"].add("txn_2")
        lock_manager._wait_for["txn_2"].add("txn_1")
        # Detect and resolve with error callback
        deadlock_cycle = await detector_youngest.detect_and_resolve(error_callback)
        # Should still return deadlock cycle despite callback error
        assert deadlock_cycle is not None
        assert error_raised is True
