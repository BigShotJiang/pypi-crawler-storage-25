#!/usr/bin/env python3
"""Temporary script to run non-connector unit tests."""

import sys
import subprocess
from pathlib import Path
test_dir = Path(__file__).parent
root_dir = test_dir.parent.parent
# Directories to exclude (connector-related)
excludes = [
    "connectors_tests",
    "connector_experiments_tests"
]
# Build ignore args
ignore_args = []
for exclude in excludes:
    ignore_args.extend(["--ignore", str(test_dir / exclude)])
# Run pytest
result = subprocess.run(
    [sys.executable, "-m", "pytest",
     str(test_dir),
     "-m", "xwstorage_unit",
     "-v", "--tb=short", "-x"] + ignore_args,
    cwd=root_dir
)
sys.exit(result.returncode)
