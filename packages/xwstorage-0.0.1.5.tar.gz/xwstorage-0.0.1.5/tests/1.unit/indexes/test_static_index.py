#!/usr/bin/env python3
"""
Test Static Index with Custom Indexing Logic
Tests for StaticIndex with Python function and code string support.
"""

import pytest
from exonware.xwstorage.indexes.static_index import (
    StaticIndex,
    CodeExecutionTimeout,
    CodeExecutionSecurityError
)
@pytest.mark.asyncio
async def test_static_index_with_function():
    """Test StaticIndex with a Python function."""
    # Define mapping function
    def map_orders(order):
        return {
            'customer_id': order['customer']['id'],
            'total': sum(line['quantity'] * line['price'] 
                       for line in order.get('lines', [])),
        }
    # Create index
    index = StaticIndex(
        index_name="test_orders_index",
        map_function=map_orders
    )
    await index.create()
    # Index a document
    order_doc = {
        'customer': {'id': 'customer123'},
        'lines': [
            {'quantity': 2, 'price': 10.0},
            {'quantity': 1, 'price': 5.0}
        ]
    }
    await index.index_document("order1", order_doc)
    # Search
    result = await index.search({'customer_id': 'customer123', 'total': 25.0})
    assert result == "order1"
    # Cleanup
    await index.drop()
@pytest.mark.asyncio
async def test_static_index_with_code_string():
    """Test StaticIndex with a Python code string."""
    map_code = (
        "def map_product(product):\n"
        "    return {\n"
        "        'category': product.get('category', 'unknown'),\n"
        "        'price': product.get('price', 0.0)\n"
        "    }\n"
    )
    index = StaticIndex(
        index_name="test_products_index",
        map_code=map_code,
        function_name="map_product"
    )
    await index.create()
    # Index a document
    product_doc = {'category': 'electronics', 'price': 99.99}
    await index.index_document("product1", product_doc)
    # Search
    result = await index.search({'category': 'electronics', 'price': 99.99})
    assert result == "product1"
    # Cleanup
    await index.drop()
@pytest.mark.asyncio
async def test_static_index_security_validation():
    """Test that unsafe code is rejected."""
    # Try to import os (should be blocked)
    unsafe_code = (
        "import os\n"
        "def map_document(doc):\n"
        "    return {'key': 'value'}\n"
    )
    with pytest.raises(CodeExecutionSecurityError):
        StaticIndex(
            index_name="test_unsafe",
            map_code=unsafe_code,
            enable_ast_validation=True
        )
@pytest.mark.asyncio
async def test_static_index_timeout():
    """Test that long-running functions timeout."""
    def slow_function(doc):
        import time
        time.sleep(10)  # Sleep for 10 seconds
        return {'key': 'value'}
    index = StaticIndex(
        index_name="test_timeout",
        map_function=slow_function,
        timeout_seconds=0.1  # Very short timeout
    )
    await index.create()
    # This should timeout
    with pytest.raises(CodeExecutionTimeout):
        await index.index_document("doc1", {})
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
