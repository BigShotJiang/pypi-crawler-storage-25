#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/query_tests/test_query_optimization.py
Unit tests for Query Optimization Integration.
Tests xwquery optimization integration with xwstorage.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
from unittest.mock import Mock, AsyncMock, patch
from exonware.xwstorage.query.optimizer import StorageQueryOptimizer
@pytest.mark.xwstorage_unit

class TestStorageQueryOptimizer:
    """Test StorageQueryOptimizer implementation."""
    @pytest.fixture

    def mock_index_manager(self):
        """Create mock secondary index manager."""
        manager = Mock()
        manager.get_index_info = Mock(return_value={"name": "test_idx", "columns": ["age"]})
        manager.recommend_index = Mock(return_value="test_idx")
        return manager
    @pytest.fixture

    def optimizer(self, mock_index_manager):
        """Create optimizer fixture."""
        try:
            return StorageQueryOptimizer(
                secondary_index_manager=mock_index_manager,
                enable_cache=True
            )
        except ImportError:
            pytest.skip("xwquery optimization not available")

    def test_initialization(self, mock_index_manager):
        """Test optimizer initialization."""
        try:
            optimizer = StorageQueryOptimizer(
                secondary_index_manager=mock_index_manager
            )
            assert optimizer._planner is not None
            assert optimizer._optimizer is not None
            assert optimizer._stats_manager is not None
        except ImportError:
            pytest.skip("xwquery optimization not available")

    def test_update_statistics(self, optimizer):
        """Test updating statistics."""
        optimizer.update_statistics(
            table="users",
            row_count=10000,
            column_stats={"age": {"cardinality": 50}},
            indexes=["age_idx"]
        )
        # Statistics should be updated
        assert optimizer._stats_manager is not None
    @pytest.mark.asyncio

    async def test_optimize_query(self, optimizer):
        """Test query optimization."""
        query = "SELECT * FROM users WHERE age > 25"
        data = [{"age": 30}, {"age": 20}]
        # Update statistics first
        optimizer.update_statistics("users", row_count=100, indexes=["age_idx"])
        # Optimize query
        plan = await optimizer.optimize_query(query, data)
        # Should return optimized plan or None if optimization fails
        # (plan might be None if xwquery components are not fully available)
        assert plan is None or hasattr(plan, 'get_estimated_cost')

    def test_select_index(self, optimizer, mock_index_manager):
        """Test index selection."""
        # Use secondary index manager
        index = optimizer.select_index("users", ["age"], "equality")
        # Should return recommended index or None
        assert index is None or isinstance(index, str)

    def test_get_optimization_stats(self, optimizer):
        """Test getting optimization statistics."""
        stats = optimizer.get_optimization_stats()
        assert "optimization_level" in stats
        assert "cache_enabled" in stats
        assert stats["cache_enabled"] is True

    def test_invalidate_cache(self, optimizer):
        """Test cache invalidation."""
        # Should not raise
        optimizer.invalidate_cache()
        optimizer.invalidate_cache("users")

    def test_optimizer_without_xwquery(self):
        """Test optimizer when xwquery is not available."""
        with patch('exonware.xwquery.query.optimization.QueryPlanner', None):
            optimizer = StorageQueryOptimizer()
            assert optimizer._planner is None
            assert optimizer._optimizer is None
