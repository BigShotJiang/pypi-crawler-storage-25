#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/query_tests/test_executor.py
Unit tests for Query executor.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from exonware.xwstorage.query.executor import QueryExecutor
from exonware.xwstorage.query.adapter import QueryAdapter
@pytest.mark.xwstorage_unit

class TestQueryExecutor:
    """Test QueryExecutor implementation."""
    @pytest.fixture

    def query_executor(self):
        """Create query executor fixture."""
        return QueryExecutor()
    @pytest.fixture

    def mock_connection(self):
        """Create mock connection fixture."""
        connection = MagicMock()
        connection.execute_query = AsyncMock(return_value=[{"id": 1, "name": "Alice"}])
        connection.backend_type = "sql"
        return connection

    def test_query_executor_initialization(self, query_executor):
        """Test initializing query executor."""
        assert query_executor.query_adapter is not None
    @pytest.mark.asyncio

    async def test_execute_query(self, query_executor, mock_connection):
        """Test executing a query."""
        result = await query_executor.execute(
            query="SELECT * FROM users",
            connection=mock_connection
        )
        assert result is not None
        mock_connection.execute_query.assert_called_once()
    @pytest.mark.asyncio

    async def test_execute_query_with_params(self, query_executor, mock_connection):
        """Test executing a query with parameters."""
        params = {"user_id": 1}
        result = await query_executor.execute(
            query="SELECT * FROM users WHERE id = :user_id",
            connection=mock_connection,
            params=params
        )
        assert result is not None
        mock_connection.execute_query.assert_called_once()
    @pytest.mark.asyncio

    async def test_execute_query_no_execute_method(self, query_executor):
        """Test executing query when connection doesn't support execute_query."""
        mock_connection = MagicMock()
        del mock_connection.execute_query
        with pytest.raises(NotImplementedError, match="not supported"):
            await query_executor.execute(
                query="SELECT * FROM users",
                connection=mock_connection
            )
