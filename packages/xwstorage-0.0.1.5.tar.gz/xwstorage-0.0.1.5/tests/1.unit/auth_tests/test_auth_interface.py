﻿#!/usr/bin/env python3
"""Auth interface unit tests (skipped when auth API is incomplete in workspace)."""
import pytest

pytest.skip(
    "Auth interface tests require IAuthProvider/MockAuthProvider in exonware.xwstorage.auth.",
    allow_module_level=True,
)
