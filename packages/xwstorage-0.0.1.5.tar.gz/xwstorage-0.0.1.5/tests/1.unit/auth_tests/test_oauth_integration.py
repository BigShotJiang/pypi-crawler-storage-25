﻿#!/usr/bin/env python3
"""OAuth integration unit tests (skipped when OAuth helpers are incomplete)."""
import pytest

pytest.skip(
    "OAuth integration tests require OAuth helpers in exonware.xwstorage.auth.",
    allow_module_level=True,
)
