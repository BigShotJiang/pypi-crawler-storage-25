#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/realtime_tests/test_websocket_comprehensive.py
Comprehensive unit tests for WebSocket manager with concurrency.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock
from exonware.xwstorage.realtime.websocket import WebSocketManager
@pytest.mark.xwstorage_unit

class TestWebSocketComprehensive:
    """Comprehensive tests for WebSocketManager."""
    @pytest.fixture

    def websocket_manager(self):
        """Create WebSocket manager fixture."""
        return WebSocketManager()
    @pytest.fixture

    def mock_websocket(self):
        """Create mock WebSocket fixture."""
        websocket = MagicMock()
        websocket.receive = AsyncMock(side_effect=Exception("Closed"))
        websocket.send = AsyncMock()
        return websocket
    @pytest.mark.asyncio

    async def test_websocket_multiple_connections(self, websocket_manager, mock_websocket):
        """Test multiple WebSocket connections."""
        # Create multiple connections
        for i in range(5):
            conn_id = f"conn_{i}"
            websocket = MagicMock()
            websocket.receive = AsyncMock(side_effect=Exception("Closed"))
            websocket.send = AsyncMock()
            websocket_manager._connections[conn_id] = websocket
        assert len(websocket_manager._connections) == 5
    @pytest.mark.asyncio

    async def test_websocket_broadcast_to_all(self, websocket_manager):
        """Test broadcasting to all connections."""
        # Add connections
        connections = []
        for i in range(3):
            websocket = MagicMock()
            websocket.send = AsyncMock()
            conn_id = f"conn_{i}"
            websocket_manager._connections[conn_id] = websocket
            connections.append(websocket)
        # Broadcast
        message = {"type": "update", "data": "test"}
        await websocket_manager.broadcast(message)
        # All should receive
        for websocket in connections:
            websocket.send.assert_called_once_with(message)
    @pytest.mark.asyncio

    async def test_websocket_connection_cleanup(self, websocket_manager, mock_websocket):
        """Test connection cleanup on error."""
        conn_id = "conn_1"
        websocket_manager._connections[conn_id] = mock_websocket
        # Handle connection (will raise exception)
        await websocket_manager.handle_connection(mock_websocket, conn_id)
        # Connection should be removed
        assert conn_id not in websocket_manager._connections
