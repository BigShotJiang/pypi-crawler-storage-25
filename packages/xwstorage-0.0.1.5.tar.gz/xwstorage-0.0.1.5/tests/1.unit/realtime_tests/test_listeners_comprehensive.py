#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/realtime_tests/test_listeners_comprehensive.py
Comprehensive unit tests for Change listeners with concurrency.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import asyncio
from unittest.mock import AsyncMock
from exonware.xwstorage.realtime.listeners import ChangeListener
@pytest.mark.xwstorage_unit

class TestChangeListenerComprehensive:
    """Comprehensive tests for ChangeListener."""
    @pytest.fixture

    def callback(self):
        """Create callback fixture."""
        return AsyncMock()
    @pytest.fixture

    def listener(self, callback):
        """Create change listener fixture."""
        return ChangeListener("collection:users", callback)
    @pytest.mark.asyncio

    async def test_listener_multiple_changes(self, listener, callback):
        """Test listener with multiple changes."""
        await listener.start()
        changes = [
            {"type": "added", "data": {"id": 1}},
            {"type": "modified", "data": {"id": 1, "name": "Alice"}},
            {"type": "removed", "data": {"id": 1}}
        ]
        for change in changes:
            await listener.notify_change(change)
        assert callback.call_count == 3
    @pytest.mark.asyncio

    async def test_listener_concurrent_notifications(self, listener, callback):
        """Test concurrent notifications."""
        await listener.start()
        async def notify(change):
            await listener.notify_change(change)
        changes = [{"type": "added", "data": {"id": i}} for i in range(10)]
        await asyncio.gather(*[notify(change) for change in changes])
        assert callback.call_count == 10
    @pytest.mark.asyncio

    async def test_listener_filter_changes(self, callback):
        """Test listener with filtered changes."""
        def filter_callback(change):
            if change.get("type") == "added":
                callback(change)
        listener = ChangeListener("collection:users", filter_callback)
        await listener.start()
        await listener.notify_change({"type": "added", "data": {"id": 1}})
        await listener.notify_change({"type": "modified", "data": {"id": 1}})
        assert callback.call_count == 1
