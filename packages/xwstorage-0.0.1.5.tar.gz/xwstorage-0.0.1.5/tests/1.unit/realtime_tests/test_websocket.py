#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/realtime_tests/test_websocket.py
Unit tests for WebSocket manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from exonware.xwstorage.realtime.websocket import WebSocketManager
@pytest.mark.xwstorage_unit

class TestWebSocketManager:
    """Test WebSocketManager implementation."""
    @pytest.fixture

    def websocket_manager(self):
        """Create WebSocket manager fixture."""
        return WebSocketManager()
    @pytest.fixture

    def mock_websocket(self):
        """Create mock WebSocket fixture."""
        websocket = MagicMock()
        websocket.receive = AsyncMock(side_effect=Exception("Connection closed"))
        websocket.send = AsyncMock()
        return websocket

    def test_websocket_manager_initialization(self, websocket_manager):
        """Test initializing WebSocket manager."""
        assert websocket_manager is not None
        assert len(websocket_manager._connections) == 0
    @pytest.mark.asyncio

    async def test_handle_connection(self, websocket_manager, mock_websocket):
        """Test handling a WebSocket connection."""
        connection_id = "conn_1"
        # Should handle connection and then close when receive raises exception
        await websocket_manager.handle_connection(mock_websocket, connection_id)
        # Connection should be removed after handling
        assert connection_id not in websocket_manager._connections
    @pytest.mark.asyncio

    async def test_broadcast(self, websocket_manager, mock_websocket):
        """Test broadcasting message to all connections."""
        connection_id = "conn_1"
        websocket_manager._connections[connection_id] = mock_websocket
        message = {"type": "update", "data": "test"}
        await websocket_manager.broadcast(message)
        mock_websocket.send.assert_called_once_with(message)
