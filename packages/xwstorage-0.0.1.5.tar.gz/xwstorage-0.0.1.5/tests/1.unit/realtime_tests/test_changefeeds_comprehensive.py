#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/realtime_tests/test_changefeeds_comprehensive.py
Comprehensive unit tests for Changefeeds with various query scenarios.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from unittest.mock import MagicMock
from exonware.xwstorage.realtime.changefeeds import Changefeed
@pytest.mark.xwstorage_unit

class TestChangefeedComprehensive:
    """Comprehensive tests for Changefeed."""
    @pytest.fixture

    def mock_query(self):
        """Create mock query fixture."""
        return {"type": "SELECT", "table": "users", "filter": {"active": True}}
    @pytest.fixture

    def mock_connection(self):
        """Create mock connection fixture."""
        return MagicMock()
    @pytest.fixture

    def changefeed(self, mock_query, mock_connection):
        """Create changefeed fixture."""
        return Changefeed(mock_query, mock_connection)
    @pytest.mark.asyncio

    async def test_changefeed_subscribe_unsubscribe(self, changefeed):
        """Test subscribing and unsubscribing."""
        changes = []
        async for change in changefeed.subscribe():
            changes.append(change)
            if len(changes) >= 1:
                await changefeed.close()
                break
        assert changefeed._active is False
    @pytest.mark.asyncio

    async def test_changefeed_multiple_subscriptions(self, mock_query, mock_connection):
        """Test multiple changefeed subscriptions."""
        changefeeds = []
        for i in range(3):
            cf = Changefeed(mock_query, mock_connection)
            changefeeds.append(cf)
        # All should be independent
        assert len(changefeeds) == 3
        for cf in changefeeds:
            assert cf._active is False
