#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/realtime_tests/test_changefeeds.py
Unit tests for Changefeeds.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from unittest.mock import MagicMock
from exonware.xwstorage.realtime.changefeeds import Changefeed
@pytest.mark.xwstorage_unit

class TestChangefeed:
    """Test Changefeed implementation."""
    @pytest.fixture

    def mock_query(self):
        """Create mock query fixture."""
        return {"type": "SELECT", "table": "users"}
    @pytest.fixture

    def mock_connection(self):
        """Create mock connection fixture."""
        return MagicMock()
    @pytest.fixture

    def changefeed(self, mock_query, mock_connection):
        """Create changefeed fixture."""
        return Changefeed(mock_query, mock_connection)

    def test_changefeed_initialization(self, changefeed):
        """Test initializing changefeed."""
        assert changefeed.query is not None
        assert changefeed.connection is not None
        assert changefeed._active is False
    @pytest.mark.asyncio

    async def test_subscribe_changefeed(self, changefeed):
        """Test subscribing to changefeed."""
        changes = []
        async for change in changefeed.subscribe():
            changes.append(change)
            if len(changes) >= 1:  # Limit to avoid infinite loop
                break
        assert changefeed._active is True
    @pytest.mark.asyncio

    async def test_close_changefeed(self, changefeed):
        """Test closing changefeed."""
        await changefeed.close()
        assert changefeed._active is False
