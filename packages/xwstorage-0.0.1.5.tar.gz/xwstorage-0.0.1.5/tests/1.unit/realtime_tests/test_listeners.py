#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/realtime_tests/test_listeners.py
Unit tests for Change listeners.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from unittest.mock import AsyncMock
from exonware.xwstorage.realtime.listeners import ChangeListener
@pytest.mark.xwstorage_unit

class TestChangeListener:
    """Test ChangeListener implementation."""
    @pytest.fixture

    def callback(self):
        """Create callback fixture."""
        return AsyncMock()
    @pytest.fixture

    def listener(self, callback):
        """Create change listener fixture."""
        return ChangeListener("collection:users", callback)

    def test_listener_initialization(self, listener):
        """Test initializing change listener."""
        assert listener.resource == "collection:users"
        assert listener.callback is not None
        assert listener._active is False
    @pytest.mark.asyncio

    async def test_start_listener(self, listener):
        """Test starting a listener."""
        await listener.start()
        assert listener._active is True
    @pytest.mark.asyncio

    async def test_stop_listener(self, listener):
        """Test stopping a listener."""
        await listener.start()
        await listener.stop()
        assert listener._active is False
    @pytest.mark.asyncio

    async def test_notify_change(self, listener, callback):
        """Test notifying listener of a change."""
        await listener.start()
        change = {"type": "added", "data": {"id": 1, "name": "Alice"}}
        await listener.notify_change(change)
        callback.assert_called_once_with(change)
    @pytest.mark.asyncio

    async def test_notify_change_when_inactive(self, listener, callback):
        """Test that inactive listener doesn't notify."""
        # Don't start listener
        change = {"type": "added", "data": {"id": 1, "name": "Alice"}}
        await listener.notify_change(change)
        # Callback should not be called
        callback.assert_not_called()
