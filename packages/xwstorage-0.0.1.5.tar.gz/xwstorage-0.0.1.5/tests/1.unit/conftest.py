"""
Unit test fixtures.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import shutil
import tempfile
from pathlib import Path

import pytest
import pytest_asyncio

try:
    from exonware.xwstorage.connectors.local_connector import (
        LocalConnectorConfig,
        LocalStorageConnection,
    )
except ModuleNotFoundError:
    LocalConnectorConfig = None  # type: ignore[assignment,misc]
    LocalStorageConnection = None  # type: ignore[assignment,misc]


def pytest_ignore_collect(collection_path, config):
    """Omit optional-heavy unit test packages when implementations are not shipped."""
    parts = collection_path.parts

    if "connectors_tests" in parts:
        try:
            import importlib

            importlib.import_module("exonware.xwstorage.connectors.local_connector")
        except ModuleNotFoundError:
            return True

    if "core_tests" in parts:
        import importlib

        for mod in (
            "exonware.xwstorage.core.engine",
            "exonware.xwstorage.core.lock_manager",
        ):
            try:
                importlib.import_module(mod)
            except ModuleNotFoundError:
                return True

    return None


@pytest.fixture
def unit_temp_dir():
    """Create a temporary directory for unit tests."""
    temp_path = Path(tempfile.mkdtemp(prefix="xwstorage_unit_"))
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
def local_config_unit(unit_temp_dir):
    """Create local connector config for unit tests."""
    if LocalConnectorConfig is None:
        pytest.skip("exonware.xwstorage.connectors.local_connector not available")
    return LocalConnectorConfig(
        address=str(unit_temp_dir / "unit_test.json"),
        security=True,
    )


@pytest_asyncio.fixture
async def local_connection_unit(local_config_unit):
    """Create local storage connection for unit tests."""
    if LocalStorageConnection is None:
        pytest.skip("exonware.xwstorage.connectors.local_connector not available")
    connection = LocalStorageConnection(local_config_unit, "json")
    yield connection
