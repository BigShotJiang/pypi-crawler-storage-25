#!/usr/bin/env python3
"""
Unit tests for SQL-like stored procedures (ScriptLanguage.SQL, execution via xwquery).
"""

import pytest
try:
    from exonware.xwstorage.scripting.executor import ScriptLanguage
    from exonware.xwstorage.scripting.stored_procedures import StoredProcedureManager
    _SCRIPTING_AVAILABLE = True
except Exception:
    ScriptLanguage = None  # type: ignore[misc, assignment]
    StoredProcedureManager = None  # type: ignore[misc, assignment]
    _SCRIPTING_AVAILABLE = False
try:
    from exonware.xwquery import XWQuery
    _XWQUERY_AVAILABLE = True
except Exception:
    _XWQUERY_AVAILABLE = False
@pytest.mark.xwstorage_unit
@pytest.mark.skipif(not _SCRIPTING_AVAILABLE or not _XWQUERY_AVAILABLE, reason="scripting or xwquery not available")


class TestSQLStoredProcedure:
    """SQL procedure: register with language SQL, execute with scope."""
    @pytest.mark.asyncio

    async def test_register_and_execute_sql_procedure(self):
        """Register a procedure with language SQL and execute with scope; assert result."""
        manager = StoredProcedureManager()
        await manager.register(
            "select_users",
            ScriptLanguage.SQL,
            "SELECT * FROM users",
            parameters=["users"],
            description="Select all users",
        )
        scope = {"users": [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]}
        result = await manager.execute("select_users", scope)
        assert result.success is True
        assert result.result is not None
        # xwquery returns list of rows or similar
        if isinstance(result.result, list):
            assert len(result.result) == 2
        else:
            assert result.result is not None
    @pytest.mark.asyncio

    async def test_sql_procedure_with_where(self):
        """SQL procedure with WHERE returns filtered result."""
        manager = StoredProcedureManager()
        await manager.register(
            "adults",
            ScriptLanguage.SQL,
            "SELECT * FROM users WHERE age >= 18",
            parameters=["users"],
        )
        scope = {"users": [{"id": 1, "name": "Alice", "age": 25}, {"id": 2, "name": "Bob", "age": 17}]}
        result = await manager.execute("adults", scope)
        assert result.success is True
        if isinstance(result.result, list):
            assert len(result.result) == 1
            assert result.result[0]["name"] == "Alice"
