#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/performance_tests/test_cache_manager.py
Unit tests for cache manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.performance.cache import CacheManager
@pytest.mark.xwstorage_unit

class TestCacheManager:
    """Test CacheManager implementation."""
    @pytest.fixture

    def cache(self):
        """Create cache manager fixture."""
        return CacheManager(max_size=10)

    def test_get_put(self, cache):
        """Test getting and putting values."""
        cache.put("key1", "value1")
        result = cache.get("key1")
        assert result == "value1"

    def test_get_missing_key(self, cache):
        """Test getting a missing key."""
        result = cache.get("missing_key")
        assert result is None

    def test_delete(self, cache):
        """Test deleting a key."""
        cache.put("key1", "value1")
        cache.delete("key1")
        result = cache.get("key1")
        assert result is None

    def test_clear(self, cache):
        """Test clearing the cache."""
        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.clear()
        assert cache.get("key1") is None
        assert cache.get("key2") is None

    def test_get_stats(self, cache):
        """Test getting cache statistics."""
        cache.put("key1", "value1")
        stats = cache.get_stats()
        assert "size" in stats
        assert "max_size" in stats
