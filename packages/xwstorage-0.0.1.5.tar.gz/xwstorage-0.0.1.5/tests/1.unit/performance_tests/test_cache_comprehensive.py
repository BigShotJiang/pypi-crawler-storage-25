#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/performance_tests/test_cache_comprehensive.py
Comprehensive performance tests for Cache manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import time
from exonware.xwstorage.performance.cache import CacheManager
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_performance

class TestCacheComprehensive:
    """Comprehensive performance tests for CacheManager."""
    @pytest.fixture

    def cache_manager(self):
        """Create cache manager fixture."""
        return CacheManager(max_size=100)

    def test_cache_basic_operations(self, cache_manager):
        """Test basic cache operations."""
        # Put items
        for i in range(50):
            cache_manager.put(f"key_{i}", f"value_{i}")
        # Get items
        for i in range(50):
            result = cache_manager.get(f"key_{i}")
            assert result == f"value_{i}"

    def test_cache_delete(self, cache_manager):
        """Test deleting from cache."""
        cache_manager.put("key1", "value1")
        assert cache_manager.get("key1") == "value1"
        cache_manager.delete("key1")
        assert cache_manager.get("key1") is None

    def test_cache_clear(self, cache_manager):
        """Test clearing cache."""
        for i in range(10):
            cache_manager.put(f"key_{i}", f"value_{i}")
        cache_manager.clear()
        for i in range(10):
            assert cache_manager.get(f"key_{i}") is None

    def test_cache_eviction_policy(self, cache_manager):
        """Test cache eviction when full."""
        # Fill cache beyond capacity
        for i in range(150):  # More than max_size=100
            cache_manager.put(f"key_{i}", f"value_{i}")
        stats = cache_manager.get_stats()
        if "size" in stats:
            assert stats["size"] <= 100
