#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/performance_tests/test_cache_enhanced.py
Unit tests for Enhanced Cache Manager.
Tests LFU eviction, write-through/write-back, prefetching, cache warming, and adaptive sizing.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
from exonware.xwstorage.performance.cache import CacheManager, EvictionPolicy, WritePolicy
@pytest.mark.xwstorage_unit

class TestEnhancedCacheManager:
    """Test enhanced CacheManager implementation."""
    @pytest.fixture

    def cache_lru(self):
        """Create LRU cache manager fixture."""
        return CacheManager(max_size=100, eviction_policy=EvictionPolicy.LRU)
    @pytest.fixture

    def cache_lfu(self):
        """Create LFU cache manager fixture."""
        return CacheManager(max_size=100, eviction_policy=EvictionPolicy.LFU)
    @pytest.mark.asyncio

    async def test_lru_eviction(self, cache_lru):
        """Test LRU eviction policy."""
        # Fill cache beyond capacity
        for i in range(150):
            cache_lru.put(f"key{i}", f"value{i}")
        # First keys should be evicted (LRU)
        assert cache_lru.get("key0") is None  # Should be evicted
        assert cache_lru.get("key149") is not None  # Should still be in cache
    @pytest.mark.asyncio

    async def test_lfu_eviction(self, cache_lfu):
        """Test LFU eviction policy."""
        # Fill cache
        for i in range(50):
            cache_lfu.put(f"key{i}", f"value{i}")
        # Access some keys multiple times (increase frequency)
        for _ in range(10):
            cache_lfu.get("key0")
            cache_lfu.get("key1")
        # Fill cache beyond capacity
        for i in range(50, 150):
            cache_lfu.put(f"key{i}", f"value{i}")
        # Frequently accessed keys should still be in cache
        assert cache_lfu.get("key0") is not None
        assert cache_lfu.get("key1") is not None
    @pytest.mark.asyncio

    async def test_write_through(self):
        """Test write-through caching."""
        written_keys = []
        def writer(key, value):
            written_keys.append((key, value))
        cache = CacheManager(
            max_size=100,
            eviction_policy=EvictionPolicy.LRU,
            write_policy=WritePolicy.WRITE_THROUGH,
            writer=writer
        )
        cache.put("key1", "value1")
        # Should be written to storage immediately
        assert len(written_keys) > 0
        assert ("key1", "value1") in written_keys
    @pytest.mark.asyncio

    async def test_write_back(self):
        """Test write-back caching."""
        written_keys = []
        def writer(key, value):
            written_keys.append((key, value))
        cache = CacheManager(
            max_size=100,
            eviction_policy=EvictionPolicy.LRU,
            write_policy=WritePolicy.WRITE_BACK,
            writer=writer,
            flush_interval=1.0
        )
        cache.put("key1", "value1")
        # Should not be written immediately
        assert len(written_keys) == 0
        # Flush should write
        cache.flush()
        assert len(written_keys) > 0
    @pytest.mark.asyncio

    async def test_prefetch(self, cache_lru):
        """Test prefetching."""
        loaded_keys = []
        def loader(key):
            loaded_keys.append(key)
            return f"loaded_{key}"
        keys_to_prefetch = ["key1", "key2", "key3"]
        count = await cache_lru.prefetch(keys_to_prefetch, loader)
        assert count > 0
        assert len(loaded_keys) > 0
        # Prefetched keys should be in cache
        assert cache_lru.get("key1") is not None
    @pytest.mark.asyncio

    async def test_cache_warming(self, cache_lru):
        """Test cache warming."""
        def loader(key):
            return f"warmed_{key}"
        keys_to_warm = ["key1", "key2", "key3"]
        count = await cache_lru.warm_cache(keys_to_warm, loader, strategy="preload")
        assert count > 0
        # Warmed keys should be in cache
        assert cache_lru.get("key1") is not None
    @pytest.mark.asyncio

    async def test_adaptive_sizing(self):
        """Test adaptive cache sizing."""
        cache = CacheManager(
            max_size=100,
            enable_adaptive_sizing=True,
            min_size=50,
            max_size_limit=200
        )
        # Generate hits to increase hit rate
        cache.put("key1", "value1")
        for _ in range(100):
            cache.get("key1")  # High hit rate
        stats = cache.get_stats()
        assert "hit_rate" in stats
        assert stats["adaptive_sizing"] is True
    @pytest.mark.asyncio

    async def test_get_stats(self, cache_lru):
        """Test getting cache statistics."""
        cache_lru.put("key1", "value1")
        cache_lru.get("key1")
        stats = cache_lru.get_stats()
        assert "max_size" in stats
        assert "eviction_policy" in stats
        assert "write_policy" in stats
        assert stats["eviction_policy"] == "lru"
    @pytest.mark.asyncio

    async def test_clear(self, cache_lru):
        """Test clearing cache."""
        cache_lru.put("key1", "value1")
        assert cache_lru.get("key1") is not None
        cache_lru.clear()
        assert cache_lru.get("key1") is None
