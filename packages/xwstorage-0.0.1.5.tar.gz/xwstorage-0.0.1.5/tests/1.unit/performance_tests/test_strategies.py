#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/performance_tests/test_strategies.py
Unit tests for Performance strategies.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.performance.strategies import StrategyManager
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_performance

class TestStrategyManager:
    """Test StrategyManager implementation."""
    @pytest.fixture

    def strategy_manager(self):
        """Create strategy manager fixture."""
        return StrategyManager()

    def test_strategy_manager_initialization(self, strategy_manager):
        """Test initializing strategy manager."""
        assert strategy_manager is not None

    def test_get_strategy_lru_cache(self, strategy_manager):
        """Test getting LRU_CACHE strategy."""
        try:
            strategy = strategy_manager.get_strategy("LRU_CACHE", max_size=100)
            assert strategy is not None
        except ValueError:
            # Strategy not available (xwnode not installed)
            pytest.skip("xwnode strategies not available")

    def test_get_strategy_hash_map(self, strategy_manager):
        """Test getting HASH_MAP strategy."""
        try:
            strategy = strategy_manager.get_strategy("HASH_MAP")
            assert strategy is not None
        except ValueError:
            pytest.skip("xwnode strategies not available")

    def test_get_strategy_lsm_tree(self, strategy_manager):
        """Test getting LSM_TREE strategy."""
        try:
            strategy = strategy_manager.get_strategy("LSM_TREE")
            assert strategy is not None
        except ValueError:
            pytest.skip("xwnode strategies not available")

    def test_get_strategy_invalid(self, strategy_manager):
        """Test getting invalid strategy raises error."""
        with pytest.raises(ValueError, match="not available"):
            strategy_manager.get_strategy("INVALID_STRATEGY")

    def test_select_strategy_for_read(self, strategy_manager):
        """Test automatic strategy selection for read operations."""
        strategy = strategy_manager.select_strategy("read", data_size=1000)
        # May return None if strategies not available
        assert strategy is None or strategy in ["LRU_CACHE", "HASH_MAP"]

    def test_select_strategy_for_write(self, strategy_manager):
        """Test automatic strategy selection for write operations."""
        strategy = strategy_manager.select_strategy("write", data_size=1000)
        # May return None if strategies not available
        assert strategy is None or strategy in ["LSM_TREE", "HASH_MAP"]

    def test_select_strategy_for_range_query(self, strategy_manager):
        """Test automatic strategy selection for range queries."""
        strategy = strategy_manager.select_strategy("range_query", data_size=1000)
        # May return None if strategies not available
        assert strategy is None or strategy in ["LSM_TREE", "HASH_MAP"]
