#!/usr/bin/env python3
"""
Unit tests for xwstorage XWDB (unified full-stack facade).
Tests XWDB init (connection vs backend/format/address), storage/connection
properties, schema validation on write, and integration with local backend.
Company: eXonware.com
"""

import pytest
from pathlib import Path
from exonware.xwstorage import XWDB, XWConnection, XWStorage
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_facade


class TestXWDBInit:
    """Test XWDB initialization and properties."""

    def test_init_with_backend_format_address(self, tmp_path):
        """XWDB with backend, format, address creates internal XWStorage."""
        path = str(tmp_path / "store.json")
        db = XWDB(backend="local", format="json", address=path)
        assert db.storage is not None
        assert isinstance(db.storage, XWStorage)
        assert db.connection is not None
        assert db._schema is None
        assert db._auth is None
        assert db._action_engine is None

    def test_init_with_connection(self, tmp_path):
        """XWDB with connection uses that connection."""
        path = str(tmp_path / "store.json")
        conn = XWConnection(auth=None, config={"connector": "local", "format": "json", "address": path})
        db = XWDB(connection=conn)
        assert db.connection is conn
        assert db.storage._connection is conn

    def test_init_with_schema(self, tmp_path):
        """XWDB accepts optional schema and stores it."""
        path = str(tmp_path / "store.json")
        schema = type("MockSchema", (), {"validate": lambda self, data: None})()
        db = XWDB(backend="local", format="json", address=path, schema=schema)
        assert db._schema is schema

    def test_init_with_auth(self, tmp_path):
        """XWDB accepts optional auth and stores it."""
        path = str(tmp_path / "store.json")
        auth = object()
        db = XWDB(backend="local", format="json", address=path, auth=auth)
        assert db._auth is auth

    def test_init_with_action_engine(self, tmp_path):
        """XWDB accepts optional action_engine."""
        path = str(tmp_path / "store.json")
        engine = object()
        db = XWDB(backend="local", format="json", address=path, action_engine=engine)
        assert db._action_engine is engine
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_facade


class TestXWDBSchemaValidation:
    """Test XWDB write path with schema validation."""
    @pytest.mark.asyncio

    async def test_write_calls_schema_validate_when_present(self, tmp_path):
        """When schema has validate(), write() calls it before delegating to storage."""
        path = str(tmp_path / "store.json")
        validated = []
        class Validator:
            def validate(self, data):
                validated.append(data)
        db = XWDB(backend="local", format="json", address=path, schema=Validator())
        await db.write("doc/1", {"name": "Alice"})
        assert len(validated) == 1
        assert validated[0] == {"name": "Alice"}
    @pytest.mark.asyncio

    async def test_write_validation_error_raises_before_write(self, tmp_path):
        """When schema.validate raises, write does not reach storage."""
        path = str(tmp_path / "store.json")
        class FailingValidator:
            def validate(self, data):
                raise ValueError("invalid")
        db = XWDB(backend="local", format="json", address=path, schema=FailingValidator())
        with pytest.raises(ValueError, match="invalid"):
            await db.write("doc/1", {"bad": "data"})
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_facade


class TestXWDBReadWriteIntegration:
    """Integration-style tests: XWDB read/write with local backend."""
    @pytest.mark.asyncio

    async def test_write_then_read_roundtrip(self, tmp_path):
        """Data written via XWDB is readable back."""
        path = str(tmp_path / "store.json")
        db = XWDB(backend="local", format="json", address=path)
        await db.write("users/1", {"id": 1, "name": "Alice"})
        data = await db.read("users/1")
        assert data == {"id": 1, "name": "Alice"}
    @pytest.mark.asyncio

    async def test_delete_removes_data(self, tmp_path):
        """delete() removes path; read returns None or raises as per backend."""
        from exonware.xwstorage.errors import XWLocationError
        path = str(tmp_path / "store.json")
        db = XWDB(backend="local", format="json", address=path)
        await db.write("users/1", {"id": 1})
        await db.delete("users/1")
        try:
            result = await db.read("users/1")
            assert result is None or result == {}
        except XWLocationError:
            # Local backend raises when path not found; treat as "removed"
            pass
