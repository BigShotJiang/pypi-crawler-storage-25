#!/usr/bin/env python3
"""
Unit tests for Counter data types.
"""

import pytest
from exonware.xwstorage.data.counters import Counter, CounterManager, CounterType


class TestCounter:
    """Test Counter class."""
    @pytest.mark.asyncio

    async def test_counter_initialization(self):
        """Test counter initialization."""
        counter = Counter("test_counter", CounterType.INTEGER, initial_value=0)
        assert counter.name == "test_counter"
        assert counter.counter_type == CounterType.INTEGER
        assert await counter.get_value() == 0
    @pytest.mark.asyncio

    async def test_counter_increment(self):
        """Test counter increment."""
        counter = Counter("test_counter", CounterType.INTEGER, initial_value=10)
        value = await counter.increment(5)
        assert value == 15
        assert await counter.get_value() == 15
        value = await counter.increment()
        assert value == 16
    @pytest.mark.asyncio

    async def test_counter_decrement(self):
        """Test counter decrement."""
        counter = Counter("test_counter", CounterType.INTEGER, initial_value=20)
        value = await counter.decrement(5)
        assert value == 15
        assert await counter.get_value() == 15
        value = await counter.decrement()
        assert value == 14
    @pytest.mark.asyncio

    async def test_counter_set_value(self):
        """Test setting counter value."""
        counter = Counter("test_counter", CounterType.INTEGER, initial_value=0)
        await counter.set_value(100)
        assert await counter.get_value() == 100
    @pytest.mark.asyncio

    async def test_counter_reset(self):
        """Test counter reset."""
        counter = Counter("test_counter", CounterType.INTEGER, initial_value=50)
        await counter.increment(25)
        assert await counter.get_value() == 75
        await counter.reset()
        assert await counter.get_value() == 50
    @pytest.mark.asyncio

    async def test_counter_float_type(self):
        """Test float counter type."""
        counter = Counter("test_counter", CounterType.FLOAT, initial_value=0.5)
        value = await counter.increment(1.5)
        assert value == 2.0
        assert isinstance(value, float)
    @pytest.mark.asyncio

    async def test_counter_metadata(self):
        """Test counter metadata."""
        counter = Counter("test_counter", CounterType.INTEGER, initial_value=0)
        await counter.increment(5)
        await counter.decrement(2)
        metadata = counter.get_metadata()
        assert metadata.increment_count == 1
        assert metadata.decrement_count == 1
        assert metadata.initial_value == 0


class TestCounterManager:
    """Test CounterManager class."""
    @pytest.mark.asyncio

    async def test_manager_get_or_create(self):
        """Test getting or creating counters."""
        manager = CounterManager()
        counter1 = await manager.get_or_create("counter1", CounterType.INTEGER, 0)
        counter2 = await manager.get_or_create("counter1", CounterType.INTEGER, 0)
        # Should return same instance
        assert counter1 is counter2
    @pytest.mark.asyncio

    async def test_manager_list_counters(self):
        """Test listing counters."""
        manager = CounterManager()
        await manager.get_or_create("counter1")
        await manager.get_or_create("counter2")
        await manager.get_or_create("counter3")
        counters = manager.list_counters()
        assert len(counters) == 3
        assert "counter1" in counters
        assert "counter2" in counters
        assert "counter3" in counters
    @pytest.mark.asyncio

    async def test_manager_delete(self):
        """Test deleting counters."""
        manager = CounterManager()
        await manager.get_or_create("counter1")
        await manager.get_or_create("counter2")
        assert len(manager.list_counters()) == 2
        await manager.delete("counter1")
        assert len(manager.list_counters()) == 1
        assert "counter1" not in manager.list_counters()
    @pytest.mark.asyncio

    async def test_manager_stats(self):
        """Test getting statistics."""
        manager = CounterManager()
        counter1 = await manager.get_or_create("counter1", CounterType.INTEGER, 0)
        counter2 = await manager.get_or_create("counter2", CounterType.INTEGER, 10)
        await counter1.increment(5)
        await counter2.decrement(3)
        stats = await manager.get_all_stats()
        assert "counter1" in stats
        assert stats["counter1"]["value"] == 5
        assert "counter2" in stats
        assert stats["counter2"]["value"] == 7
