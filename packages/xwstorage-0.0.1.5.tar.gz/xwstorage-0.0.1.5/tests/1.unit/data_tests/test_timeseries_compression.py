#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/data_tests/test_timeseries_compression.py
Unit tests for TimeSeriesCompression implementation.
Tests time-series specific compression algorithms including:
- Delta encoding for timestamps
- Delta+RLE for repetitive values
- Gorilla-style compression for floating-point
- Hybrid automatic algorithm selection
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 27-Jan-2025
"""

import pytest
from datetime import datetime, timedelta
from exonware.xwstorage.data.timeseries_compression import TimeSeriesCompression


class TestTimeSeriesCompression:
    """Test TimeSeriesCompression functionality."""
    @pytest.fixture

    def compressor(self):
        """Fixture for TimeSeriesCompression instance."""
        return TimeSeriesCompression()

    def test_compress_delta_basic(self, compressor):
        """Test basic delta compression."""
        timestamps = [datetime(2025, 1, 1, 0, 0, i) for i in range(10)]
        values = [i * 1.5 for i in range(10)]
        compressed = compressor.compress_timeseries(timestamps, values, algorithm="delta")
        assert isinstance(compressed, bytes)
        assert len(compressed) > 0
        # Decompress
        decompressed_ts, decompressed_values = compressor.decompress_timeseries(compressed, algorithm="delta")
        assert len(decompressed_ts) == 10
        assert len(decompressed_values) == 10
        # Check timestamps (allow small floating point differences)
        for i, ts in enumerate(timestamps):
            assert abs(decompressed_ts[i] - ts.timestamp()) < 0.001
        # Check values
        for i, val in enumerate(values):
            assert abs(decompressed_values[i] - val) < 0.001

    def test_compress_delta_rle_repetitive(self, compressor):
        """Test delta+RLE compression with repetitive values."""
        timestamps = [datetime(2025, 1, 1, 0, 0, i) for i in range(10)]
        values = [5.0] * 10  # All same value
        compressed = compressor.compress_timeseries(timestamps, values, algorithm="delta_rle")
        assert isinstance(compressed, bytes)
        # Decompress
        decompressed_ts, decompressed_values = compressor.decompress_timeseries(compressed, algorithm="delta_rle")
        assert len(decompressed_ts) == 10
        assert len(decompressed_values) == 10
        assert all(v == 5.0 for v in decompressed_values)

    def test_compress_gorilla_numeric(self, compressor):
        """Test Gorilla compression for numeric values."""
        timestamps = [datetime(2025, 1, 1, 0, 0, i) for i in range(10)]
        values = [10.5 + i * 0.1 for i in range(10)]
        compressed = compressor.compress_timeseries(timestamps, values, algorithm="gorilla")
        assert isinstance(compressed, bytes)
        # Decompress
        decompressed_ts, decompressed_values = compressor.decompress_timeseries(compressed, algorithm="gorilla")
        assert len(decompressed_ts) == 10
        assert len(decompressed_values) == 10
        # Check values (allow small floating point differences)
        for i, val in enumerate(values):
            assert abs(decompressed_values[i] - val) < 0.001

    def test_compress_hybrid_automatic(self, compressor):
        """Test hybrid compression with automatic algorithm selection."""
        # Test with repetitive values (should use delta_rle)
        timestamps = [datetime(2025, 1, 1, 0, 0, i) for i in range(10)]
        values = [5.0] * 10
        compressed = compressor.compress_timeseries(timestamps, values, algorithm="hybrid")
        assert isinstance(compressed, bytes)
        # Decompress
        decompressed_ts, decompressed_values = compressor.decompress_timeseries(compressed, algorithm="hybrid")
        assert len(decompressed_ts) == 10
        assert len(decompressed_values) == 10

    def test_compress_empty(self, compressor):
        """Test compression with empty data."""
        compressed = compressor.compress_timeseries([], [], algorithm="delta")
        assert compressed == b""
        decompressed_ts, decompressed_values = compressor.decompress_timeseries(compressed, algorithm="delta")
        assert decompressed_ts == []
        assert decompressed_values == []

    def test_compress_single_value(self, compressor):
        """Test compression with single value."""
        timestamps = [datetime(2025, 1, 1, 0, 0, 0)]
        values = [42.0]
        compressed = compressor.compress_timeseries(timestamps, values, algorithm="delta")
        assert isinstance(compressed, bytes)
        decompressed_ts, decompressed_values = compressor.decompress_timeseries(compressed, algorithm="delta")
        assert len(decompressed_ts) == 1
        assert len(decompressed_values) == 1
        assert abs(decompressed_values[0] - 42.0) < 0.001

    def test_compress_mismatched_lengths(self, compressor):
        """Test that mismatched lengths raise ValueError."""
        timestamps = [datetime(2025, 1, 1, 0, 0, i) for i in range(5)]
        values = [i for i in range(10)]  # Different length
        with pytest.raises(ValueError, match="same length"):
            compressor.compress_timeseries(timestamps, values, algorithm="delta")

    def test_compress_invalid_algorithm(self, compressor):
        """Test that invalid algorithm raises ValueError."""
        timestamps = [datetime(2025, 1, 1, 0, 0, i) for i in range(5)]
        values = [i for i in range(5)]
        with pytest.raises(ValueError, match="Unknown"):
            compressor.compress_timeseries(timestamps, values, algorithm="invalid")

    def test_compress_string_values(self, compressor):
        """Test compression with string values."""
        timestamps = [datetime(2025, 1, 1, 0, 0, i) for i in range(5)]
        values = [f"value_{i}" for i in range(5)]
        compressed = compressor.compress_timeseries(timestamps, values, algorithm="delta")
        assert isinstance(compressed, bytes)
        decompressed_ts, decompressed_values = compressor.decompress_timeseries(compressed, algorithm="delta")
        assert len(decompressed_ts) == 5
        assert len(decompressed_values) == 5
        assert decompressed_values == values

    def test_compress_numeric_timestamps(self, compressor):
        """Test compression with numeric timestamps (Unix timestamps)."""
        base_ts = datetime(2025, 1, 1, 0, 0, 0).timestamp()
        timestamps = [base_ts + i for i in range(10)]
        values = [i * 1.5 for i in range(10)]
        compressed = compressor.compress_timeseries(timestamps, values, algorithm="delta")
        assert isinstance(compressed, bytes)
        decompressed_ts, decompressed_values = compressor.decompress_timeseries(compressed, algorithm="delta")
        assert len(decompressed_ts) == 10
        assert len(decompressed_values) == 10
