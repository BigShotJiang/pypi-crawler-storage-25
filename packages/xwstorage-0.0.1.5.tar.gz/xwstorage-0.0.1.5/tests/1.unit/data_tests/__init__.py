#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/data_tests/__init__.py
Data model tests package.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 27-Jan-2025
"""
