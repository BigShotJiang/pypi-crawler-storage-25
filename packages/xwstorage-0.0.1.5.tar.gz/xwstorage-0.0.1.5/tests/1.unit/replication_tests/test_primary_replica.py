#!/usr/bin/env python3
"""
Unit tests for primary-replica connection: read from replica, write to primary, failover.
"""

import pytest
from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig, LocalStorageConnection
from exonware.xwstorage.replication.primary_replica import PrimaryReplicaConnection
@pytest.mark.xwstorage_unit


class TestPrimaryReplicaConnection:
    """PrimaryReplicaConnection routes reads to replicas and writes to primary with failover."""
    @pytest.fixture

    def primary_and_replica(self, tmp_path):
        """Primary and one replica as local connections."""
        primary_path = str(tmp_path / "primary.json")
        replica_path = str(tmp_path / "replica.json")
        primary_cfg = LocalConnectorConfig(address=primary_path)
        replica_cfg = LocalConnectorConfig(address=replica_path)
        primary = LocalStorageConnection(primary_cfg, "json")
        replica = LocalStorageConnection(replica_cfg, "json")
        return primary, replica, primary_path, replica_path
    @pytest.mark.asyncio

    async def test_write_goes_to_primary_read_prefers_replica(self, primary_and_replica):
        """Write goes to primary; read prefers replica (replica may not have data until synced)."""
        primary, replica, primary_path, replica_path = primary_and_replica
        conn = PrimaryReplicaConnection(primary, [replica])
        await conn.save({"id": 1, "name": "Alice"}, "users/1")
        # Write went to primary; replica might not have it (no streaming sync in this test)
        data_primary = await primary.load("users/1")
        assert data_primary == {"id": 1, "name": "Alice"}
        # Read path tries replica first then primary; replica may not have data
        data = await conn.load("users/1")
        assert data == {"id": 1, "name": "Alice"}
    @pytest.mark.asyncio

    async def test_read_from_replica_when_available(self, primary_and_replica):
        """When replica has data, read can be served from replica."""
        primary, replica, _, _ = primary_and_replica
        await replica.save({"id": 2, "name": "Bob"}, "users/2")
        conn = PrimaryReplicaConnection(primary, [replica])
        data = await conn.load("users/2")
        assert data == {"id": 2, "name": "Bob"}
    @pytest.mark.asyncio

    async def test_delete_goes_to_primary(self, primary_and_replica):
        """Delete is a write operation and goes to primary."""
        primary, replica, _, _ = primary_and_replica
        await primary.save({"x": 1}, "doc/1")
        conn = PrimaryReplicaConnection(primary, [replica])
        await conn.delete("doc/1")
        exists = await primary.exists("doc/1")
        assert exists is False
