#!/usr/bin/env python3
"""
Unit tests for XWStorage trigger lifecycle (BEFORE/AFTER insert, update, delete).
When trigger_manager is set, write/delete run triggers; trigger failure raises.
"""

import pytest
from pathlib import Path
from exonware.xwstorage import XWStorage
from exonware.xwstorage.defs import TriggerEvent
try:
    from exonware.xwstorage.scripting.triggers import TriggerManager
    from exonware.xwstorage.scripting.executor import ScriptLanguage
    _TRIGGERS_AVAILABLE = True
except Exception:
    TriggerManager = None  # type: ignore[misc, assignment]
    ScriptLanguage = None  # type: ignore[misc, assignment]
    _TRIGGERS_AVAILABLE = False
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_facade
@pytest.mark.skipif(not _TRIGGERS_AVAILABLE, reason="scripting/triggers not importable (e.g. js2py/lupa)")


class TestFacadeTriggerLifecycle:
    """Trigger invocation from XWStorage write/delete path."""
    @pytest.mark.asyncio

    async def test_write_without_trigger_manager_succeeds(self, tmp_path):
        """Without trigger_manager, write works as before."""
        path = str(tmp_path / "store.json")
        storage = XWStorage(backend="local", format="json", address=path)
        await storage.write("users/1", {"id": 1, "name": "Alice"})
        data = await storage.read("users/1")
        assert data == {"id": 1, "name": "Alice"}
    @pytest.mark.asyncio

    async def test_before_insert_trigger_failure_prevents_insert(self, tmp_path):
        """BEFORE_INSERT trigger that fails causes write() to raise; document is not saved."""
        path = str(tmp_path / "store.json")
        trigger_mgr = TriggerManager()
        await trigger_mgr.register(
            "reject_insert",
            TriggerEvent.BEFORE_INSERT,
            "users",
            ScriptLanguage.LUA,
            "error('reject')",
        )
        storage = XWStorage(backend="local", format="json", address=path, trigger_manager=trigger_mgr)
        with pytest.raises(RuntimeError, match="Trigger before_insert failed"):
            await storage.write("users/1", {"id": 1})
        exists = await storage.exists("users/1")
        assert exists is False
    @pytest.mark.asyncio

    async def test_after_insert_trigger_failure_raises(self, tmp_path):
        """AFTER_INSERT trigger that fails causes write() to raise (caller should rollback if in transaction)."""
        path = str(tmp_path / "store.json")
        trigger_mgr = TriggerManager()
        await trigger_mgr.register(
            "reject_after",
            TriggerEvent.AFTER_INSERT,
            "users",
            ScriptLanguage.LUA,
            "error('after failed')",
        )
        storage = XWStorage(backend="local", format="json", address=path, trigger_manager=trigger_mgr)
        with pytest.raises(RuntimeError, match="Trigger after_insert failed"):
            await storage.write("users/1", {"id": 1})
        # Write may have been committed before AFTER ran; plan says treat as write failure and rollback if in transaction
        # We only assert that write() raised
        assert True
    @pytest.mark.asyncio

    async def test_before_delete_trigger_failure_prevents_delete(self, tmp_path):
        """BEFORE_DELETE trigger that fails causes delete() to raise; document is not deleted."""
        path = str(tmp_path / "store.json")
        storage = XWStorage(backend="local", format="json", address=path)
        await storage.write("users/1", {"id": 1})
        trigger_mgr = TriggerManager()
        await trigger_mgr.register(
            "reject_delete",
            TriggerEvent.BEFORE_DELETE,
            "users",
            ScriptLanguage.LUA,
            "error('reject delete')",
        )
        storage2 = XWStorage(backend="local", format="json", address=path, trigger_manager=trigger_mgr)
        with pytest.raises(RuntimeError, match="Trigger BEFORE_DELETE failed"):
            await storage2.delete("users/1")
        exists = await storage2.exists("users/1")
        assert exists is True
    @pytest.mark.asyncio

    async def test_successful_triggers_allow_write_and_delete(self, tmp_path):
        """With trigger_manager and no failing trigger, write and delete succeed."""
        path = str(tmp_path / "store.json")
        trigger_mgr = TriggerManager()
        await trigger_mgr.register(
            "noop",
            TriggerEvent.BEFORE_INSERT,
            "users",
            ScriptLanguage.LUA,
            "-- no-op",
        )
        await trigger_mgr.register(
            "noop_after",
            TriggerEvent.AFTER_INSERT,
            "users",
            ScriptLanguage.LUA,
            "-- no-op",
        )
        storage = XWStorage(backend="local", format="json", address=path, trigger_manager=trigger_mgr)
        await storage.write("users/1", {"id": 1, "name": "Bob"})
        data = await storage.read("users/1")
        assert data == {"id": 1, "name": "Bob"}
        await storage.delete("users/1")
        exists = await storage.exists("users/1")
        assert exists is False
