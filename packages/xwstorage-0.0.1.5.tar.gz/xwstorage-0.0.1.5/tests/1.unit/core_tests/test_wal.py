#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/core_tests/test_wal.py
Unit tests for Write-Ahead Logging (WAL) manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import tempfile
from pathlib import Path
from exonware.xwstorage.core.wal import WALManager, LogRecord
@pytest.mark.xwstorage_unit

class TestLogRecord:
    """Test LogRecord serialization and deserialization."""

    def test_log_record_creation(self):
        """Test creating a log record."""
        record = LogRecord(
            lsn=1,
            transaction_id="txn_123",
            operation="INSERT",
            page_id=5,
            data=b"test data"
        )
        assert record.lsn == 1
        assert record.transaction_id == "txn_123"
        assert record.operation == "INSERT"
        assert record.page_id == 5
        assert record.data == b"test data"

    def test_log_record_serialize_deserialize(self):
        """Test serializing and deserializing a log record."""
        original = LogRecord(
            lsn=100,
            transaction_id="txn_456",
            operation="UPDATE",
            page_id=10,
            data=b"updated data"
        )
        serialized = original.serialize()
        deserialized = LogRecord.deserialize(serialized)
        assert deserialized.lsn == original.lsn
        assert deserialized.transaction_id == original.transaction_id
        assert deserialized.operation == original.operation
        assert deserialized.page_id == original.page_id
        assert deserialized.data == original.data
@pytest.mark.xwstorage_unit

class TestWALManager:
    """Test WALManager implementation."""
    @pytest.fixture

    def temp_wal_path(self):
        """Create temporary WAL file path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "wal.log"
    @pytest.fixture

    def wal_manager(self, temp_wal_path):
        """Create WAL manager fixture."""
        return WALManager(temp_wal_path)
    @pytest.mark.asyncio

    async def test_wal_manager_initialization(self, wal_manager):
        """Test initializing WAL manager."""
        assert wal_manager.wal_path is not None
        assert wal_manager.current_lsn == 0
    @pytest.mark.asyncio

    async def test_append_log_record(self, wal_manager):
        """Test appending a log record."""
        lsn = await wal_manager.append_log(
            transaction_id="txn_1",
            operation="INSERT",
            page_id=1,
            data=b"test data"
        )
        assert lsn == 1
        assert wal_manager.current_lsn == 1
    @pytest.mark.asyncio

    async def test_append_multiple_records(self, wal_manager):
        """Test appending multiple log records."""
        for i in range(5):
            await wal_manager.append_log(
                transaction_id=f"txn_{i}",
                operation="INSERT",
                page_id=i,
                data=f"data_{i}".encode()
            )
        assert wal_manager.current_lsn == 5
    @pytest.mark.asyncio

    async def test_flush_wal(self, wal_manager):
        """Test flushing WAL to disk."""
        await wal_manager.append_log(
            transaction_id="txn_1",
            operation="INSERT",
            page_id=1,
            data=b"test data"
        )
        await wal_manager.flush_log()
        # After flush, WAL should be persisted
        assert wal_manager.wal_path.exists()
    @pytest.mark.asyncio

    async def test_create_checkpoint(self, wal_manager):
        """Test creating a WAL checkpoint."""
        # Append some records
        for i in range(3):
            await wal_manager.append_log(
                transaction_id=f"txn_{i}",
                operation="INSERT",
                page_id=i,
                data=f"data_{i}".encode()
            )
        checkpoint_lsn = await wal_manager.checkpoint()
        assert checkpoint_lsn >= 3
    @pytest.mark.asyncio

    async def test_replay_log(self, wal_manager):
        """Test replaying log records."""
        # Append records
        for i in range(3):
            await wal_manager.append_log(
                transaction_id=f"txn_{i}",
                operation="INSERT",
                page_id=i,
                data=f"data_{i}".encode()
            )
        # Replay from LSN 1
        records_replayed = []
        async def callback(record):
            records_replayed.append(record)
        await wal_manager.replay_log(from_lsn=1, callback=callback)
        assert len(records_replayed) >= 0  # May vary based on implementation
