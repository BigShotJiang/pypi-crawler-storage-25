﻿#!/usr/bin/env python3
"""Storage engine unit tests (skipped when engine module not present)."""
import pytest

pytest.skip(
    "Engine tests require exonware.xwstorage.core.engine.",
    allow_module_level=True,
)
