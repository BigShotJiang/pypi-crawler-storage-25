#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/core_tests/test_recovery_complete.py
Complete comprehensive tests for Crash Recovery manager.
Tests various crash scenarios, incomplete transactions, and data consistency.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 21-Dec-2025
"""

import pytest
import tempfile
import asyncio
from pathlib import Path
from typing import Any
from exonware.xwstorage.core.recovery import RecoveryManager, RecoveryResult
from exonware.xwstorage.core.paging import PageManager
from exonware.xwstorage.core.buffer_pool import BufferPool
from exonware.xwstorage.core.wal import WALManager, LogRecord
from exonware.xwstorage.core.checkpoint import CheckpointManager
from exonware.xwstorage.defs import PageSize
@pytest.mark.xwstorage_unit

class TestRecoveryComplete:
    """
    Complete comprehensive tests for crash recovery.
    Tests:
    - Recovery from various crash scenarios
    - Incomplete transaction rollback
    - Data consistency verification
    - Checkpoint recovery
    - WAL replay
    """
    @pytest.fixture

    def temp_db_path(self):
        """Create temporary database path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "test.db"
    @pytest.fixture

    def temp_wal_path(self):
        """Create temporary WAL path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "wal.log"
    @pytest.fixture

    async def page_manager(self, temp_db_path):
        """Create page manager fixture."""
        return PageManager(temp_db_path, PageSize.MEDIUM_8KB)
    @pytest.fixture

    async def buffer_pool(self, page_manager):
        """Create buffer pool fixture."""
        return BufferPool(page_manager, pool_size=10)
    @pytest.fixture

    async def wal_manager(self, temp_wal_path):
        """Create WAL manager fixture."""
        return WALManager(temp_wal_path)
    @pytest.fixture

    async def checkpoint_manager(self, buffer_pool, wal_manager):
        """Create checkpoint manager fixture."""
        return CheckpointManager(buffer_pool, wal_manager)
    @pytest.fixture

    async def recovery_manager(self, page_manager, buffer_pool, wal_manager, checkpoint_manager):
        """Create recovery manager fixture."""
        return RecoveryManager(page_manager, buffer_pool, wal_manager, checkpoint_manager)
    # ==================== Basic Recovery Tests ====================
    @pytest.mark.asyncio

    async def test_recovery_with_no_wal(self, recovery_manager):
        """Test recovery when WAL is empty."""
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.checkpoint_lsn == 0
        assert result.replayed_records == 0
        assert result.recovered_transactions == 0
        assert result.error is None
    @pytest.mark.asyncio

    async def test_recovery_with_checkpoint_only(self, recovery_manager, checkpoint_manager):
        """Test recovery when only checkpoint exists."""
        # Create checkpoint
        await checkpoint_manager.create_checkpoint()
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.checkpoint_lsn >= 0
        assert result.replayed_records == 0  # No records after checkpoint
    # ==================== Incomplete Transaction Tests ====================
    @pytest.mark.asyncio

    async def test_recovery_rolls_back_incomplete_insert(self, recovery_manager, wal_manager):
        """
        Test recovery rolls back incomplete INSERT transaction.
        Scenario: Transaction starts INSERT, but crashes before COMMIT.
        Expected: Transaction should be rolled back during recovery.
        """
        # Transaction starts INSERT but doesn't commit
        await wal_manager.append_log(
            transaction_id="txn_incomplete",
            operation="INSERT",
            page_id=1,
            data=b"incomplete_data"
        )
        # No COMMIT record - transaction is incomplete
        result = await recovery_manager.recover()
        assert result.success is True
        # Should detect and rollback incomplete transaction
        assert result.recovered_transactions >= 0
    @pytest.mark.asyncio

    async def test_recovery_rolls_back_incomplete_update(self, recovery_manager, wal_manager):
        """Test recovery rolls back incomplete UPDATE transaction."""
        # Transaction starts UPDATE but crashes
        await wal_manager.append_log(
            transaction_id="txn_update_incomplete",
            operation="UPDATE",
            page_id=2,
            data=b"updated_data"
        )
        # No COMMIT - incomplete
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.recovered_transactions >= 0
    @pytest.mark.asyncio

    async def test_recovery_rolls_back_incomplete_delete(self, recovery_manager, wal_manager):
        """Test recovery rolls back incomplete DELETE transaction."""
        # Transaction starts DELETE but crashes
        await wal_manager.append_log(
            transaction_id="txn_delete_incomplete",
            operation="DELETE",
            page_id=3,
            data=b""
        )
        # No COMMIT - incomplete
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.recovered_transactions >= 0
    @pytest.mark.asyncio

    async def test_recovery_with_multiple_incomplete_transactions(self, recovery_manager, wal_manager):
        """Test recovery with multiple incomplete transactions."""
        # Multiple incomplete transactions
        for i in range(5):
            await wal_manager.append_log(
                transaction_id=f"txn_incomplete_{i}",
                operation="INSERT",
                page_id=i + 10,
                data=f"data_{i}".encode()
            )
            # No COMMIT for any
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.recovered_transactions >= 0
    # ==================== Complete Transaction Tests ====================
    @pytest.mark.asyncio

    async def test_recovery_replays_complete_insert(self, recovery_manager, wal_manager):
        """Test recovery replays complete INSERT transaction."""
        # Complete transaction
        await wal_manager.append_log(
            transaction_id="txn_complete",
            operation="INSERT",
            page_id=1,
            data=b"complete_data"
        )
        await wal_manager.append_log(
            transaction_id="txn_complete",
            operation="COMMIT",
            page_id=0,
            data=b""
        )
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.replayed_records >= 1
    @pytest.mark.asyncio

    async def test_recovery_replays_complete_update(self, recovery_manager, wal_manager):
        """Test recovery replays complete UPDATE transaction."""
        # Complete UPDATE transaction
        await wal_manager.append_log(
            transaction_id="txn_update_complete",
            operation="UPDATE",
            page_id=2,
            data=b"updated_value"
        )
        await wal_manager.append_log(
            transaction_id="txn_update_complete",
            operation="COMMIT",
            page_id=0,
            data=b""
        )
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.replayed_records >= 1
    @pytest.mark.asyncio

    async def test_recovery_handles_aborted_transaction(self, recovery_manager, wal_manager):
        """Test recovery handles explicitly aborted transactions."""
        # Transaction that was aborted
        await wal_manager.append_log(
            transaction_id="txn_aborted",
            operation="INSERT",
            page_id=5,
            data=b"aborted_data"
        )
        await wal_manager.append_log(
            transaction_id="txn_aborted",
            operation="ABORT",
            page_id=0,
            data=b""
        )
        result = await recovery_manager.recover()
        assert result.success is True
        # Aborted transaction should be rolled back
    @pytest.mark.asyncio

    async def test_recovery_with_mixed_complete_incomplete(self, recovery_manager, wal_manager):
        """Test recovery with mix of complete and incomplete transactions."""
        # Complete transaction
        await wal_manager.append_log("txn_complete", "INSERT", 1, b"data1")
        await wal_manager.append_log("txn_complete", "COMMIT", 0, b"")
        # Incomplete transaction
        await wal_manager.append_log("txn_incomplete", "INSERT", 2, b"data2")
        # No COMMIT
        # Another complete transaction
        await wal_manager.append_log("txn_complete2", "UPDATE", 3, b"data3")
        await wal_manager.append_log("txn_complete2", "COMMIT", 0, b"")
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.replayed_records >= 0
        assert result.recovered_transactions >= 0
    # ==================== Checkpoint Recovery Tests ====================
    @pytest.mark.asyncio

    async def test_recovery_from_checkpoint(self, recovery_manager, wal_manager, checkpoint_manager):
        """Test recovery from checkpoint."""
        # Create some WAL records before checkpoint
        for i in range(3):
            await wal_manager.append_log(
                transaction_id=f"txn_pre_checkpoint_{i}",
                operation="INSERT",
                page_id=i + 1,
                data=f"pre_{i}".encode()
            )
            await wal_manager.append_log(
                transaction_id=f"txn_pre_checkpoint_{i}",
                operation="COMMIT",
                page_id=0,
                data=b""
            )
        # Create checkpoint
        await checkpoint_manager.create_checkpoint()
        checkpoint_lsn = checkpoint_manager.get_latest_checkpoint().lsn
        # Create more records after checkpoint
        for i in range(2):
            await wal_manager.append_log(
                transaction_id=f"txn_post_checkpoint_{i}",
                operation="INSERT",
                page_id=i + 10,
                data=f"post_{i}".encode()
            )
            await wal_manager.append_log(
                transaction_id=f"txn_post_checkpoint_{i}",
                operation="COMMIT",
                page_id=0,
                data=b""
            )
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.checkpoint_lsn >= checkpoint_lsn
        assert result.replayed_records >= 0
    @pytest.mark.asyncio

    async def test_recovery_from_multiple_checkpoints(self, recovery_manager, wal_manager, checkpoint_manager):
        """Test recovery from latest checkpoint when multiple exist."""
        # First checkpoint
        await wal_manager.append_log("txn_1", "INSERT", 1, b"data1")
        await wal_manager.append_log("txn_1", "COMMIT", 0, b"")
        await checkpoint_manager.create_checkpoint()
        # Second checkpoint
        await wal_manager.append_log("txn_2", "INSERT", 2, b"data2")
        await wal_manager.append_log("txn_2", "COMMIT", 0, b"")
        await checkpoint_manager.create_checkpoint()
        # Third checkpoint (latest)
        await wal_manager.append_log("txn_3", "INSERT", 3, b"data3")
        await wal_manager.append_log("txn_3", "COMMIT", 0, b"")
        await checkpoint_manager.create_checkpoint()
        latest_checkpoint = checkpoint_manager.get_latest_checkpoint()
        result = await recovery_manager.recover()
        assert result.success is True
        # Should recover from latest checkpoint
        assert result.checkpoint_lsn >= latest_checkpoint.lsn
    # ==================== Data Consistency Tests ====================
    @pytest.mark.asyncio

    async def test_recovery_verifies_consistency(self, recovery_manager, wal_manager):
        """Test that recovery verifies data consistency."""
        # Create some transactions
        await wal_manager.append_log("txn_1", "INSERT", 1, b"data1")
        await wal_manager.append_log("txn_1", "COMMIT", 0, b"")
        result = await recovery_manager.recover()
        assert result.success is True
        # Consistency check should pass
        assert result.error is None
    @pytest.mark.asyncio

    async def test_recovery_handles_corrupted_wal_gracefully(self, recovery_manager, wal_manager):
        """Test recovery handles corrupted WAL records gracefully."""
        # Try to append invalid records (if possible)
        # Recovery should handle gracefully
        result = await recovery_manager.recover()
        # Should either succeed or fail gracefully with error message
        assert isinstance(result, RecoveryResult)
        assert result.success or result.error is not None
    # ==================== Complex Scenario Tests ====================
    @pytest.mark.asyncio

    async def test_recovery_with_large_number_of_transactions(self, recovery_manager, wal_manager):
        """Test recovery with large number of transactions."""
        num_transactions = 100
        # Create many complete transactions
        for i in range(num_transactions):
            await wal_manager.append_log(
                transaction_id=f"txn_{i}",
                operation="INSERT",
                page_id=i % 10,  # Use 10 pages
                data=f"data_{i}".encode()
            )
            await wal_manager.append_log(
                transaction_id=f"txn_{i}",
                operation="COMMIT",
                page_id=0,
                data=b""
            )
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.replayed_records >= num_transactions
    @pytest.mark.asyncio

    async def test_recovery_with_nested_transactions(self, recovery_manager, wal_manager):
        """Test recovery with nested transaction structure."""
        # Parent transaction
        await wal_manager.append_log("txn_parent", "INSERT", 1, b"parent_data")
        # Child transactions (if supported in WAL)
        await wal_manager.append_log("txn_child_1", "INSERT", 2, b"child1_data")
        await wal_manager.append_log("txn_child_1", "COMMIT", 0, b"")
        await wal_manager.append_log("txn_child_2", "UPDATE", 3, b"child2_data")
        await wal_manager.append_log("txn_child_2", "COMMIT", 0, b"")
        # Parent commits
        await wal_manager.append_log("txn_parent", "COMMIT", 0, b"")
        result = await recovery_manager.recover()
        assert result.success is True
    @pytest.mark.asyncio

    async def test_recovery_handles_concurrent_transactions(self, recovery_manager, wal_manager):
        """Test recovery with interleaved concurrent transactions."""
        # Interleaved operations from multiple transactions
        operations = [
            ("txn_1", "INSERT", 1, b"data1"),
            ("txn_2", "INSERT", 2, b"data2"),
            ("txn_1", "UPDATE", 1, b"data1_updated"),
            ("txn_3", "INSERT", 3, b"data3"),
            ("txn_2", "COMMIT", 0, b""),
            ("txn_1", "COMMIT", 0, b""),
            ("txn_3", "COMMIT", 0, b""),
        ]
        for txn_id, op, page_id, data in operations:
            await wal_manager.append_log(txn_id, op, page_id, data)
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.replayed_records >= len(operations)
    # ==================== Edge Case Tests ====================
    @pytest.mark.asyncio

    async def test_recovery_with_empty_transaction(self, recovery_manager, wal_manager):
        """Test recovery with transaction that has no operations."""
        # Transaction that commits immediately
        await wal_manager.append_log("txn_empty", "COMMIT", 0, b"")
        result = await recovery_manager.recover()
        assert result.success is True
    @pytest.mark.asyncio

    async def test_recovery_with_single_operation_transaction(self, recovery_manager, wal_manager):
        """Test recovery with transaction containing single operation."""
        await wal_manager.append_log("txn_single", "INSERT", 1, b"single")
        await wal_manager.append_log("txn_single", "COMMIT", 0, b"")
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.replayed_records >= 1
    @pytest.mark.asyncio

    async def test_recovery_performance_with_many_pages(self, recovery_manager, wal_manager):
        """Test recovery performance with many different pages."""
        num_pages = 50
        for page_id in range(num_pages):
            await wal_manager.append_log(
                transaction_id=f"txn_page_{page_id}",
                operation="INSERT",
                page_id=page_id,
                data=f"page_{page_id}".encode()
            )
            await wal_manager.append_log(
                transaction_id=f"txn_page_{page_id}",
                operation="COMMIT",
                page_id=0,
                data=b""
            )
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.replayed_records >= num_pages
