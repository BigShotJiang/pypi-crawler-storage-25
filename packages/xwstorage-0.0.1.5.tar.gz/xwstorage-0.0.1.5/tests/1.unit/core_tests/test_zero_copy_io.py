#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/core_tests/test_zero_copy_io.py
Unit tests for Zero-Copy I/O.
Tests memory-mapped file I/O, direct I/O, and zero-copy operations.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
import tempfile
from pathlib import Path
from exonware.xwstorage.core.zero_copy_io import ZeroCopyIO
@pytest.mark.xwstorage_unit

class TestZeroCopyIO:
    """Test ZeroCopyIO implementation."""
    @pytest.fixture

    def temp_file(self):
        """Create temporary file fixture."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            # Write test data
            test_data = b"Hello, World! This is test data for zero-copy I/O."
            f.write(test_data)
            temp_path = Path(f.name)
        yield temp_path
        # Cleanup
        if temp_path.exists():
            temp_path.unlink()
    @pytest.fixture

    def large_temp_file(self):
        """Create large temporary file (>1MB) for mmap testing."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            # Write >1MB of data
            large_data = b"X" * (2 * 1024 * 1024)  # 2MB
            f.write(large_data)
            temp_path = Path(f.name)
        yield temp_path
        # Cleanup
        if temp_path.exists():
            temp_path.unlink()

    def test_memory_mapped_read_small_file(self, temp_file):
        """Test memory-mapped read for small file (should use regular I/O)."""
        zcio = ZeroCopyIO(temp_file)
        with zcio.memory_mapped_read(0, 13) as data:
            assert data == b"Hello, World!"

    def test_memory_mapped_read_large_file(self, large_temp_file):
        """Test memory-mapped read for large file (should use mmap)."""
        zcio = ZeroCopyIO(large_temp_file)
        # Read first 100 bytes
        with zcio.memory_mapped_read(0, 100) as data:
            assert len(data) == 100
            assert data == b"X" * 100

    def test_read_bytes(self, temp_file):
        """Test read_bytes method."""
        zcio = ZeroCopyIO(temp_file)
        data = zcio.read_bytes(0, 5)
        assert data == b"Hello"
        data = zcio.read_bytes(7, 5)
        assert data == b"World"

    def test_write_bytes_sync(self, temp_file):
        """Test synchronous write."""
        zcio = ZeroCopyIO(temp_file)
        # Write at offset
        zcio.write_bytes_sync(0, b"Hi")
        # Verify write
        data = zcio.read_bytes(0, 2)
        assert data == b"Hi"
    @pytest.mark.asyncio

    async def test_write_bytes_async(self, temp_file):
        """Test asynchronous write."""
        zcio = ZeroCopyIO(temp_file)
        # Write at offset
        await zcio.write_bytes_async(0, b"Async", atomic=False)
        # Verify write
        data = zcio.read_bytes(0, 5)
        assert data == b"Async"

    def test_memory_mapped_write(self, temp_file):
        """Test memory-mapped write."""
        zcio = ZeroCopyIO(temp_file)
        # Ensure file is large enough
        with open(temp_file, 'ab') as f:
            f.write(b'\x00' * 100)
        with zcio.memory_mapped_write(0, 10) as mmap_view:
            mmap_view[:10] = b"MMAP Write"
        # Verify write
        data = zcio.read_bytes(0, 10)
        assert data == b"MMAP Write"

    def test_get_stats(self, temp_file):
        """Test getting I/O statistics."""
        zcio = ZeroCopyIO(temp_file)
        stats = zcio.get_stats()
        assert "file_path" in stats
        assert "file_exists" in stats
        assert "enable_direct_io" in stats
        assert "mmap_threshold" in stats
        assert stats["file_exists"] is True

    def test_direct_io_flag(self):
        """Test direct I/O flag."""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            temp_path = Path(f.name)
        try:
            zcio = ZeroCopyIO(temp_path, enable_direct_io=True)
            assert zcio.enable_direct_io is True
            stats = zcio.get_stats()
            assert stats["enable_direct_io"] is True
        finally:
            if temp_path.exists():
                temp_path.unlink()
