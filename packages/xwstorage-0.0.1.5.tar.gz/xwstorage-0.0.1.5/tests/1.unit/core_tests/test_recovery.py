#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/core_tests/test_recovery.py
Unit tests for Crash Recovery manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import tempfile
from pathlib import Path
from exonware.xwstorage.core.recovery import RecoveryManager
from exonware.xwstorage.core.paging import PageManager
from exonware.xwstorage.core.buffer_pool import BufferPool
from exonware.xwstorage.core.wal import WALManager, LogRecord
from exonware.xwstorage.core.checkpoint import CheckpointManager
from exonware.xwstorage.defs import PageSize
@pytest.mark.xwstorage_unit

class TestRecoveryManager:
    """Test RecoveryManager implementation."""
    @pytest.fixture

    def temp_db_path(self):
        """Create temporary database path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "test.db"
    @pytest.fixture

    def temp_wal_path(self):
        """Create temporary WAL path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "wal.log"
    @pytest.fixture

    async def page_manager(self, temp_db_path):
        """Create page manager fixture."""
        return PageManager(temp_db_path, PageSize.MEDIUM_8KB)
    @pytest.fixture

    async def buffer_pool(self, page_manager):
        """Create buffer pool fixture."""
        return BufferPool(page_manager, pool_size=10)
    @pytest.fixture

    async def wal_manager(self, temp_wal_path):
        """Create WAL manager fixture."""
        return WALManager(temp_wal_path)
    @pytest.fixture

    async def checkpoint_manager(self, buffer_pool, wal_manager):
        """Create checkpoint manager fixture."""
        return CheckpointManager(buffer_pool, wal_manager)
    @pytest.fixture

    async def recovery_manager(self, page_manager, buffer_pool, wal_manager, checkpoint_manager):
        """Create recovery manager fixture."""
        return RecoveryManager(page_manager, buffer_pool, wal_manager, checkpoint_manager)
    @pytest.mark.asyncio

    async def test_recovery_manager_initialization(self, recovery_manager):
        """Test initializing recovery manager."""
        assert recovery_manager.page_manager is not None
        assert recovery_manager.buffer_pool is not None
        assert recovery_manager.wal_manager is not None
        assert recovery_manager.checkpoint_manager is not None
    @pytest.mark.asyncio

    async def test_recover_with_no_checkpoint(self, recovery_manager):
        """Test recovery when no checkpoint exists."""
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.checkpoint_lsn == 0
        assert result.replayed_records == 0
        assert result.recovered_transactions == 0
    @pytest.mark.asyncio

    async def test_recover_with_checkpoint(self, recovery_manager, wal_manager, checkpoint_manager):
        """Test recovery from checkpoint."""
        # Create some WAL records
        for i in range(5):
            await wal_manager.append_log(
                transaction_id=f"txn_{i}",
                operation="INSERT",
                page_id=i,
                data=f"data_{i}".encode()
            )
        # Create checkpoint
        await checkpoint_manager.create_checkpoint()
        # Recover
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.checkpoint_lsn >= 0
        assert result.replayed_records >= 0
    @pytest.mark.asyncio

    async def test_recover_with_incomplete_transactions(self, recovery_manager, wal_manager):
        """Test recovery with incomplete transactions."""
        # Create a transaction that started but didn't commit
        await wal_manager.append_log(
            transaction_id="txn_incomplete",
            operation="INSERT",
            page_id=1,
            data=b"data1"
        )
        # No COMMIT record - transaction is incomplete
        result = await recovery_manager.recover()
        assert result.success is True
        # Incomplete transactions should be rolled back
        assert result.recovered_transactions >= 0
    @pytest.mark.asyncio

    async def test_recover_with_complete_transaction(self, recovery_manager, wal_manager):
        """Test recovery with complete transactions."""
        # Create a complete transaction
        await wal_manager.append_log(
            transaction_id="txn_complete",
            operation="INSERT",
            page_id=1,
            data=b"data1"
        )
        await wal_manager.append_log(
            transaction_id="txn_complete",
            operation="COMMIT",
            page_id=0,
            data=b""
        )
        result = await recovery_manager.recover()
        assert result.success is True
        assert result.replayed_records >= 0
