﻿#!/usr/bin/env python3
"""Buffer pool unit tests (skipped when module not present)."""
import pytest

pytest.skip(
    "Buffer pool tests require exonware.xwstorage.core buffer pool implementation.",
    allow_module_level=True,
)
