#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/core_tests/test_lock_manager.py
Unit tests for Lock manager.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import asyncio
from exonware.xwstorage.core.lock_manager import LockManager
from exonware.xwstorage.defs import LockMode
@pytest.mark.xwstorage_unit

class TestLockManager:
    """Test LockManager implementation."""
    @pytest.fixture

    def lock_manager(self):
        """Create lock manager fixture."""
        return LockManager(lock_timeout=30.0)
    @pytest.mark.asyncio

    async def test_lock_manager_initialization(self, lock_manager):
        """Test initializing lock manager."""
        assert lock_manager.lock_timeout == 30.0
    @pytest.mark.asyncio

    async def test_acquire_shared_lock(self, lock_manager):
        """Test acquiring a shared lock."""
        result = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_1"
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_acquire_exclusive_lock(self, lock_manager):
        """Test acquiring an exclusive lock."""
        result = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_1"
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_multiple_shared_locks(self, lock_manager):
        """Test multiple transactions acquiring shared locks."""
        # Multiple transactions can hold shared locks
        result1 = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_1"
        )
        result2 = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_2"
        )
        assert result1 is True
        assert result2 is True
    @pytest.mark.asyncio

    async def test_exclusive_lock_conflicts_with_shared(self, lock_manager):
        """Test that exclusive lock conflicts with shared lock."""
        # Transaction 1 acquires shared lock
        await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_1"
        )
        # Transaction 2 tries to acquire exclusive lock - should conflict
        result = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_2"
        )
        # Should be blocked or return False
        assert result is False
    @pytest.mark.asyncio

    async def test_exclusive_lock_conflicts_with_exclusive(self, lock_manager):
        """Test that exclusive lock conflicts with another exclusive lock."""
        # Transaction 1 acquires exclusive lock
        await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_1"
        )
        # Transaction 2 tries to acquire exclusive lock - should conflict
        result = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_2"
        )
        assert result is False
    @pytest.mark.asyncio

    async def test_release_lock(self, lock_manager):
        """Test releasing a lock."""
        # Acquire lock
        await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_1"
        )
        # Release lock
        await lock_manager.release_lock(
            resource="table:users",
            transaction_id="txn_1"
        )
        # Should be able to acquire exclusive lock now
        result = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_2"
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_release_all_locks(self, lock_manager):
        """Test releasing all locks for a transaction."""
        # Acquire multiple locks
        await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_1"
        )
        await lock_manager.acquire_lock(
            resource="table:orders",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_1"
        )
        # Release all locks
        await lock_manager.release_all_locks("txn_1")
        # Both resources should be available
        result1 = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_2"
        )
        result2 = await lock_manager.acquire_lock(
            resource="table:orders",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_2"
        )
        assert result1 is True
        assert result2 is True
    @pytest.mark.asyncio

    async def test_lock_upgrade(self, lock_manager):
        """Test upgrading a lock from shared to exclusive."""
        # Acquire shared lock
        await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_1"
        )
        # Upgrade to exclusive (same transaction)
        result = await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_1"
        )
        assert result is True
    @pytest.mark.asyncio

    async def test_detect_deadlock(self, lock_manager):
        """Test deadlock detection."""
        # Transaction 1 locks resource A
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_1"
        )
        # Transaction 2 locks resource B
        await lock_manager.acquire_lock(
            resource="resource:B",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_2"
        )
        # Transaction 1 tries to lock B (waits for txn_2)
        await lock_manager.acquire_lock(
            resource="resource:B",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_1"
        )
        # Transaction 2 tries to lock A (waits for txn_1) - deadlock!
        await lock_manager.acquire_lock(
            resource="resource:A",
            lock_mode=LockMode.EXCLUSIVE,
            transaction_id="txn_2"
        )
        # Check for deadlock
        deadlock_cycle = await lock_manager.detect_deadlock()
        # Deadlock detection should find the cycle
        # Note: Actual implementation may vary
        assert deadlock_cycle is None or len(deadlock_cycle) > 0
    @pytest.mark.asyncio

    async def test_get_lock_statistics(self, lock_manager):
        """Test getting lock manager statistics."""
        # Acquire some locks
        await lock_manager.acquire_lock(
            resource="table:users",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_1"
        )
        await lock_manager.acquire_lock(
            resource="table:orders",
            lock_mode=LockMode.SHARED,
            transaction_id="txn_2"
        )
        stats = lock_manager.get_lock_stats()
        assert "total_locks" in stats
        assert "locked_resources" in stats
        assert "active_transactions" in stats
        assert stats["total_locks"] >= 2
