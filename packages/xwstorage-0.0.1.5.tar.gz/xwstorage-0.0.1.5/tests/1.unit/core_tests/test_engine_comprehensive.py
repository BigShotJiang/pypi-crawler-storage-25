﻿#!/usr/bin/env python3
"""Engine comprehensive tests (skipped when engine module not present)."""
import pytest

pytest.skip(
    "Engine comprehensive tests require exonware.xwstorage.core.engine.",
    allow_module_level=True,
)
