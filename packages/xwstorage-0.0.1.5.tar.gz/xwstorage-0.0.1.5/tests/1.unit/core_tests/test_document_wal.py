﻿#!/usr/bin/env python3
"""Document WAL tests (skipped when module not present)."""
import pytest

pytest.skip(
    "Document WAL tests require exonware.xwstorage.core.document_wal.",
    allow_module_level=True,
)
