﻿#!/usr/bin/env python3
"""Bloom filter unit tests (skipped when module not present)."""
import pytest

pytest.skip(
    "Bloom filter tests require exonware.xwstorage.core.bloom_filter.",
    allow_module_level=True,
)
