﻿#!/usr/bin/env python3
"""Checkpoint tests (skipped when module not present)."""
import pytest

pytest.skip(
    "Checkpoint tests require checkpoint implementation in exonware.xwstorage.core.",
    allow_module_level=True,
)
