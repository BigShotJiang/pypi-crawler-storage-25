﻿#!/usr/bin/env python3
"""Compression tests (skipped when module not present)."""
import pytest

pytest.skip(
    "Compression tests require exonware.xwstorage.core.compression.",
    allow_module_level=True,
)
