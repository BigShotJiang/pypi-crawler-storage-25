#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/core_tests/test_paging.py
Unit tests for page-based storage system.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import tempfile
from pathlib import Path
from exonware.xwstorage.core import PageManager, Page
from exonware.xwstorage.defs import PageSize
@pytest.mark.xwstorage_unit

class TestPage:
    """Test Page implementation."""

    def test_page_creation(self):
        """Test creating a page."""
        page = Page(
            page_id=1,
            page_size=8192,
            data=b'\x00' * 8192
        )
        assert page.page_id == 1
        assert page.page_size == 8192
        assert len(page.data) == 8192
        assert page.is_dirty is False

    def test_page_mark_dirty(self):
        """Test marking page as dirty."""
        page = Page(
            page_id=1,
            page_size=8192,
            data=b'\x00' * 8192
        )
        page.mark_dirty()
        assert page.is_dirty is True

    def test_page_mark_clean(self):
        """Test marking page as clean."""
        page = Page(
            page_id=1,
            page_size=8192,
            data=b'\x00' * 8192
        )
        page.mark_dirty()
        page.mark_clean()
        assert page.is_dirty is False

    def test_page_invalid_size(self):
        """Test page with invalid data size."""
        with pytest.raises(ValueError, match="Page data size"):
            Page(
                page_id=1,
                page_size=8192,
                data=b'\x00' * 4096  # Wrong size
            )
@pytest.mark.xwstorage_unit

class TestPageManager:
    """Test PageManager implementation."""
    @pytest.fixture

    def temp_db_path(self):
        """Create temporary database path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "test.db"

    def test_page_manager_initialization(self, temp_db_path):
        """Test initializing page manager."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        assert manager.page_size == 8192
        assert manager.get_page_count() == 0

    def test_allocate_page(self, temp_db_path):
        """Test allocating a new page."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_id = manager.allocate_page()
        assert page_id == 0
        assert manager.get_page_count() == 1

    def test_allocate_multiple_pages(self, temp_db_path):
        """Test allocating multiple pages."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_ids = [manager.allocate_page() for _ in range(5)]
        assert len(page_ids) == 5
        assert manager.get_page_count() == 5

    def test_deallocate_page(self, temp_db_path):
        """Test deallocating a page."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_id = manager.allocate_page()
        manager.deallocate_page(page_id)
        assert manager.get_free_page_count() == 1

    def test_read_write_page(self, temp_db_path):
        """Test reading and writing pages."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_id = manager.allocate_page()
        # Write page
        page = Page(
            page_id=page_id,
            page_size=8192,
            data=b'test data' + b'\x00' * (8192 - 9)
        )
        manager.write_page(page)
        # Read page
        read_page = manager.read_page(page_id)
        assert read_page.page_id == page_id
        assert read_page.data[:9] == b'test data'

    def test_get_page_offset(self, temp_db_path):
        """Test getting page offset."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_id = manager.allocate_page()
        offset = manager.get_page_offset(page_id)
        assert offset == 0
        page_id2 = manager.allocate_page()
        offset2 = manager.get_page_offset(page_id2)
        assert offset2 == 8192

    def test_reuse_free_page(self, temp_db_path):
        """Test reusing a free page."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_id = manager.allocate_page()
        manager.deallocate_page(page_id)
        # Next allocation should reuse the free page
        reused_id = manager.allocate_page()
        assert reused_id == page_id
        assert manager.get_free_page_count() == 0
