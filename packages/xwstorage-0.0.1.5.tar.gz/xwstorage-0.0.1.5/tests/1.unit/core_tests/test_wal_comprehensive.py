#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/core_tests/test_wal_comprehensive.py
Comprehensive unit tests for WAL with edge cases and error scenarios.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import tempfile
import asyncio
from pathlib import Path
from exonware.xwstorage.core.wal import WALManager, LogRecord
@pytest.mark.xwstorage_unit

class TestWALComprehensive:
    """Comprehensive tests for WAL with edge cases."""
    @pytest.fixture

    def temp_wal_path(self):
        """Create temporary WAL file path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "wal.log"
    @pytest.fixture

    def wal_manager(self, temp_wal_path):
        """Create WAL manager fixture."""
        return WALManager(temp_wal_path)
    @pytest.mark.asyncio

    async def test_wal_large_transaction(self, wal_manager):
        """Test WAL with large transaction."""
        # Append many records in one transaction
        transaction_id = "txn_large"
        for i in range(100):
            await wal_manager.append_log(
                transaction_id=transaction_id,
                operation="INSERT",
                page_id=i,
                data=f"large_data_{i}".encode() * 100  # Large data
            )
        assert wal_manager.current_lsn == 100
    @pytest.mark.asyncio

    async def test_wal_concurrent_append(self, wal_manager):
        """Test concurrent log appends."""
        async def append_logs(txn_id, count):
            for i in range(count):
                await wal_manager.append_log(
                    transaction_id=txn_id,
                    operation="INSERT",
                    page_id=i,
                    data=f"data_{txn_id}_{i}".encode()
                )
        # Concurrent appends
        await asyncio.gather(
            append_logs("txn_1", 10),
            append_logs("txn_2", 10),
            append_logs("txn_3", 10)
        )
        assert wal_manager.current_lsn == 30
    @pytest.mark.asyncio

    async def test_wal_all_operation_types(self, wal_manager):
        """Test all operation types."""
        operations = ["INSERT", "UPDATE", "DELETE", "COMMIT", "ABORT"]
        for op in operations:
            await wal_manager.append_log(
                transaction_id="txn_test",
                operation=op,
                page_id=1,
                data=b"test"
            )
        assert wal_manager.current_lsn == len(operations)
    @pytest.mark.asyncio

    async def test_wal_replay_from_middle(self, wal_manager):
        """Test replaying from middle LSN."""
        # Append records
        for i in range(10):
            await wal_manager.append_log(
                transaction_id=f"txn_{i}",
                operation="INSERT",
                page_id=i,
                data=f"data_{i}".encode()
            )
        # Replay from LSN 5
        records = []
        async def callback(record):
            records.append(record)
        await wal_manager.replay_log(from_lsn=5, callback=callback)
        # Should replay records from LSN 5 onwards
        assert len(records) >= 0
    @pytest.mark.asyncio

    async def test_wal_checkpoint_after_many_records(self, wal_manager):
        """Test checkpoint after many records."""
        # Append many records
        for i in range(50):
            await wal_manager.append_log(
                transaction_id=f"txn_{i}",
                operation="INSERT",
                page_id=i,
                data=f"data_{i}".encode()
            )
        checkpoint_lsn = await wal_manager.checkpoint()
        assert checkpoint_lsn >= 50
    @pytest.mark.asyncio

    async def test_wal_empty_transaction(self, wal_manager):
        """Test empty transaction (just commit)."""
        await wal_manager.append_log(
            transaction_id="txn_empty",
            operation="COMMIT",
            page_id=0,
            data=b""
        )
        assert wal_manager.current_lsn == 1
    @pytest.mark.asyncio

    async def test_wal_aborted_transaction(self, wal_manager):
        """Test aborted transaction."""
        # Insert some records
        for i in range(3):
            await wal_manager.append_log(
                transaction_id="txn_abort",
                operation="INSERT",
                page_id=i,
                data=f"data_{i}".encode()
            )
        # Abort transaction
        await wal_manager.append_log(
            transaction_id="txn_abort",
            operation="ABORT",
            page_id=0,
            data=b""
        )
        assert wal_manager.current_lsn == 4
