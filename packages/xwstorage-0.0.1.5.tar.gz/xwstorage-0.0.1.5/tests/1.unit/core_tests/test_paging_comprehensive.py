#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/core_tests/test_paging_comprehensive.py
Comprehensive unit tests for page-based storage system with edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import tempfile
from pathlib import Path
from exonware.xwstorage.core.paging import PageManager, Page
from exonware.xwstorage.defs import PageSize
@pytest.mark.xwstorage_unit

class TestPageComprehensive:
    """Comprehensive tests for Page with edge cases."""
    @pytest.mark.parametrize("page_size", [4096, 8192, 16384])

    def test_page_creation_different_sizes(self, page_size):
        """Test creating pages with different sizes."""
        page = Page(
            page_id=1,
            page_size=page_size,
            data=b'\x00' * page_size
        )
        assert page.page_size == page_size
        assert len(page.data) == page_size

    def test_page_with_max_data(self):
        """Test page with maximum data size."""
        page_size = 16384
        page = Page(
            page_id=1,
            page_size=page_size,
            data=b'\xFF' * page_size
        )
        assert len(page.data) == page_size
        assert all(b == 0xFF for b in page.data)

    def test_page_with_empty_data(self):
        """Test page with all zeros."""
        page = Page(
            page_id=1,
            page_size=8192,
            data=b'\x00' * 8192
        )
        assert len(page.data) == 8192
        assert all(b == 0 for b in page.data)

    def test_page_data_modification(self):
        """Test modifying page data."""
        page = Page(
            page_id=1,
            page_size=8192,
            data=b'\x00' * 8192
        )
        # Modify data
        new_data = b'MODIFIED' + b'\x00' * (8192 - 8)
        page.data = new_data
        assert page.data[:8] == b'MODIFIED'
        page.mark_dirty()
        assert page.is_dirty is True

    def test_page_dirty_state_transitions(self):
        """Test page dirty state transitions."""
        page = Page(
            page_id=1,
            page_size=8192,
            data=b'\x00' * 8192
        )
        assert page.is_dirty is False
        page.mark_dirty()
        assert page.is_dirty is True
        page.mark_clean()
        assert page.is_dirty is False
        page.mark_dirty()
        page.mark_dirty()  # Multiple marks
        assert page.is_dirty is True
@pytest.mark.xwstorage_unit

class TestPageManagerComprehensive:
    """Comprehensive tests for PageManager with edge cases."""
    @pytest.fixture

    def temp_db_path(self):
        """Create temporary database path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir) / "test.db"
    @pytest.mark.parametrize("page_size,expected_size", [
        (PageSize.SMALL_4KB, 4096),
        (PageSize.MEDIUM_8KB, 8192),
        (PageSize.LARGE_16KB, 16384)
    ])

    def test_page_manager_different_sizes(self, temp_db_path, page_size, expected_size):
        """Test page manager with different page sizes."""
        manager = PageManager(temp_db_path, page_size)
        assert manager.page_size == expected_size
        page_id = manager.allocate_page()
        assert page_id == 0

    def test_allocate_large_number_of_pages(self, temp_db_path):
        """Test allocating a large number of pages."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_ids = []
        for i in range(100):
            page_id = manager.allocate_page()
            page_ids.append(page_id)
        assert len(page_ids) == 100
        assert manager.get_page_count() == 100
        # Verify sequential allocation
        assert page_ids == list(range(100))

    def test_deallocate_multiple_pages(self, temp_db_path):
        """Test deallocating multiple pages."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_ids = [manager.allocate_page() for _ in range(10)]
        # Deallocate every other page
        for page_id in page_ids[::2]:
            manager.deallocate_page(page_id)
        assert manager.get_free_page_count() == 5

    def test_reuse_multiple_free_pages(self, temp_db_path):
        """Test reusing multiple free pages."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_ids = [manager.allocate_page() for _ in range(5)]
        # Deallocate all
        for page_id in page_ids:
            manager.deallocate_page(page_id)
        # Allocate again - should reuse
        reused_ids = [manager.allocate_page() for _ in range(5)]
        assert set(reused_ids) == set(page_ids)
        assert manager.get_free_page_count() == 0

    def test_read_write_large_data(self, temp_db_path):
        """Test reading and writing large data."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_id = manager.allocate_page()
        # Write large data
        large_data = b'X' * 8192
        page = Page(
            page_id=page_id,
            page_size=8192,
            data=large_data
        )
        manager.write_page(page)
        # Read back
        read_page = manager.read_page(page_id)
        assert read_page.data == large_data

    def test_read_write_binary_data(self, temp_db_path):
        """Test reading and writing binary data."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        page_id = manager.allocate_page()
        # Write binary data
        binary_data = bytes(range(256)) * 32  # 8192 bytes
        page = Page(
            page_id=page_id,
            page_size=8192,
            data=binary_data
        )
        manager.write_page(page)
        # Read back
        read_page = manager.read_page(page_id)
        assert read_page.data == binary_data

    def test_concurrent_page_operations(self, temp_db_path):
        """Test concurrent page operations."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        # Allocate pages concurrently (simulated)
        page_ids = []
        for i in range(20):
            page_id = manager.allocate_page()
            page_ids.append(page_id)
            # Write to each page
            page = Page(
                page_id=page_id,
                page_size=8192,
                data=f'page_{i}'.encode() + b'\x00' * (8192 - len(f'page_{i}'))
            )
            manager.write_page(page)
        # Verify all pages
        for i, page_id in enumerate(page_ids):
            read_page = manager.read_page(page_id)
            assert read_page.data[:len(f'page_{i}')] == f'page_{i}'.encode()

    def test_page_offset_calculation(self, temp_db_path):
        """Test page offset calculation for multiple pages."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        offsets = []
        for i in range(10):
            page_id = manager.allocate_page()
            offset = manager.get_page_offset(page_id)
            offsets.append(offset)
            assert offset == i * 8192

    def test_deallocate_nonexistent_page(self, temp_db_path):
        """Test deallocating a non-existent page."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        # Should raise ValueError for non-existent page
        with pytest.raises(ValueError, match="Page 999 does not exist"):
            manager.deallocate_page(999)

    def test_read_nonexistent_page(self, temp_db_path):
        """Test reading a non-existent page."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        # Implementation may raise error or return None
        try:
            page = manager.read_page(999)
            # If no error, page should be None or empty
            if page is not None:
                assert page.page_id == 999
        except (ValueError, KeyError, IndexError):
            pass  # Expected behavior

    def test_get_statistics(self, temp_db_path):
        """Test getting page manager statistics."""
        manager = PageManager(temp_db_path, PageSize.MEDIUM_8KB)
        # Allocate some pages
        for _ in range(5):
            manager.allocate_page()
        stats = manager.get_stats()
        assert "total_pages" in stats or "page_count" in stats
        assert stats.get("total_pages", stats.get("page_count", 0)) >= 5
