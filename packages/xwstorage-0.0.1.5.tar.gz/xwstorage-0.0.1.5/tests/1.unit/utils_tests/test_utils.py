#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/utils_tests/test_utils.py
Unit tests for xwstorage utility functions.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 26-Dec-2025
"""

import pytest
from pathlib import Path
from tempfile import TemporaryDirectory
from exonware.xwstorage.utils import get_google_auth_config
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_utils

class TestGetGoogleAuthConfig:
    """Unit tests for get_google_auth_config function."""

    def test_get_google_auth_config_returns_correct_structure(self, temp_dir):
        """Test that get_google_auth_config returns correct dictionary structure."""
        auth_config = get_google_auth_config(temp_dir)
        assert isinstance(auth_config, dict)
        assert "credentials_path" in auth_config
        assert "token_read_path" in auth_config
        assert "token_write_path" in auth_config

    def test_get_google_auth_config_returns_path_objects(self, temp_dir):
        """Test that all returned values are Path objects."""
        auth_config = get_google_auth_config(temp_dir)
        assert isinstance(auth_config["credentials_path"], Path)
        assert isinstance(auth_config["token_read_path"], Path)
        assert isinstance(auth_config["token_write_path"], Path)

    def test_get_google_auth_config_paths_are_relative_to_base(self, temp_dir):
        """Test that paths are correctly constructed relative to base_path."""
        auth_config = get_google_auth_config(temp_dir)
        expected_base = temp_dir / "data" / "xwstorage" / "auth" / "google"
        assert auth_config["credentials_path"] == expected_base / "auth.json"
        assert auth_config["token_read_path"] == expected_base / "token_read.json"
        assert auth_config["token_write_path"] == expected_base / "token_write.json"

    def test_get_google_auth_config_with_different_base_paths(self):
        """Test that function works with different base paths."""
        with TemporaryDirectory() as tmpdir1, TemporaryDirectory() as tmpdir2:
            path1 = Path(tmpdir1)
            path2 = Path(tmpdir2)
            config1 = get_google_auth_config(path1)
            config2 = get_google_auth_config(path2)
            # Paths should be different
            assert config1["credentials_path"] != config2["credentials_path"]
            # But structure should be same
            assert config1["credentials_path"].name == config2["credentials_path"].name
            assert config1["token_read_path"].name == config2["token_read_path"].name
            assert config1["token_write_path"].name == config2["token_write_path"].name

    def test_get_google_auth_config_paths_have_correct_names(self, temp_dir):
        """Test that path names are correct."""
        auth_config = get_google_auth_config(temp_dir)
        assert auth_config["credentials_path"].name == "auth.json"
        assert auth_config["token_read_path"].name == "token_read.json"
        assert auth_config["token_write_path"].name == "token_write.json"
