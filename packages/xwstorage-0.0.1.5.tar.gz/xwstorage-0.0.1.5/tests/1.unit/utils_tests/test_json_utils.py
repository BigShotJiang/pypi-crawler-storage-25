#!/usr/bin/env python3
"""
Unit tests for xwstorage json_utils (loads, dumps, load_file, dump_file).
Verifies roundtrips and that file I/O uses xwsystem JsonSerializer flyweight
so persisted files are readable by get_serializer(JsonSerializer).load_file (reuse).
Company: eXonware.com
"""

import io
import pytest
from pathlib import Path
from exonware.xwsystem import get_serializer, JsonSerializer
from exonware.xwstorage.utils.json_utils import loads, dumps, load, dump, load_file, dump_file
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_utils


class TestJsonUtilsLoadsDumps:
    """Tests for loads/dumps (string/bytes)."""

    def test_loads_string(self):
        data = loads('{"a": 1, "b": "x"}')
        assert data == {"a": 1, "b": "x"}

    def test_loads_bytes(self):
        data = loads(b'{"a": 1}')
        assert data == {"a": 1}

    def test_dumps_returns_str(self):
        s = dumps({"key": "value"})
        assert isinstance(s, str)
        assert '"key"' in s and '"value"' in s

    def test_loads_dumps_roundtrip(self):
        obj = {"nested": {"x": [1, 2]}, "utf": "café"}
        s = dumps(obj)
        back = loads(s)
        assert back == obj
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_utils


class TestJsonUtilsLoadDump:
    """Tests for load/dump (file-like)."""

    def test_load_from_stringio(self):
        fp = io.StringIO('{"x": 42}')
        data = load(fp)
        assert data == {"x": 42}

    def test_dump_to_stringio(self):
        fp = io.StringIO()
        dump({"a": 1}, fp)
        fp.seek(0)
        assert load(fp) == {"a": 1}
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_utils


class TestJsonUtilsLoadFileDumpFile:
    """Tests for load_file/dump_file and xwsystem reuse."""

    def test_dump_file_load_file_roundtrip(self, tmp_path):
        path = tmp_path / "data.json"
        obj = {"id": 1, "name": "test"}
        dump_file(obj, path)
        back = load_file(path)
        assert back == obj

    def test_load_file_path_object(self, tmp_path):
        path = tmp_path / "p.json"
        dump_file({"p": True}, path)
        back = load_file(path)
        assert back == {"p": True}

    def test_reuse_xwsystem_serializer_reads_dump_file_output(self, tmp_path):
        """Files written by dump_file must be readable via xwsystem get_serializer(JsonSerializer).load_file."""
        path = tmp_path / "shared.json"
        data = {"written": "by_xwstorage", "n": 99}
        dump_file(data, path)
        # Same stack: xwsystem flyweight must read what xwstorage wrote
        reader = get_serializer(JsonSerializer)
        loaded = reader.load_file(path)
        assert loaded == data
