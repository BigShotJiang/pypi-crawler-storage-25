#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_lsm_tree_index.py
Unit tests for LSM-tree index.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.lsm_tree import LSMTreeIndex
@pytest.mark.xwstorage_unit

class TestLSMTreeIndex:
    """Test LSMTreeIndex implementation."""
    @pytest.fixture

    def index(self):
        """Create LSM-tree index fixture."""
        return LSMTreeIndex("test_lsm_index")
    @pytest.mark.asyncio

    async def test_create_index(self, index):
        """Test creating an LSM-tree index."""
        await index.create()
        assert index.index_name == "test_lsm_index"
        assert index.index_type == "lsm_tree"
    @pytest.mark.asyncio

    async def test_insert_and_search(self, index):
        """Test inserting and searching in LSM-tree index."""
        await index.create()
        await index.insert("key1", "value1")
        await index.insert("key2", "value2")
        await index.insert("key3", "value3")
        result1 = await index.search("key1")
        result2 = await index.search("key2")
        result3 = await index.search("key3")
        assert result1 == "value1"
        assert result2 == "value2"
        assert result3 == "value3"
    @pytest.mark.asyncio

    async def test_insert_and_delete(self, index):
        """Test inserting and deleting from LSM-tree index."""
        await index.create()
        await index.insert("key1", "value1")
        await index.insert("key2", "value2")
        result = await index.search("key1")
        assert result == "value1"
        await index.delete("key1")
        result = await index.search("key1")
        assert result is None
    @pytest.mark.asyncio

    async def test_update_value(self, index):
        """Test updating a value in LSM-tree index."""
        await index.create()
        await index.insert("key1", "value1")
        result = await index.search("key1")
        assert result == "value1"
        await index.insert("key1", "updated_value")
        result = await index.search("key1")
        assert result == "updated_value"
    @pytest.mark.asyncio

    async def test_range_search(self, index):
        """Test range search in LSM-tree index."""
        await index.create()
        # Insert keys
        for i in range(10):
            await index.insert(f"key_{i}", f"value_{i}")
        # Range search
        results = []
        async for key, value in index.range_search("key_3", "key_7"):
            results.append((key, value))
        # Should return keys from key_3 to key_7
        assert len(results) >= 5
    @pytest.mark.asyncio

    async def test_drop_index(self, index):
        """Test dropping an LSM-tree index."""
        await index.create()
        await index.insert("key1", "value1")
        result = await index.search("key1")
        assert result == "value1"
        await index.drop()
        # After drop, search should return None
        result = await index.search("key1")
        assert result is None
    @pytest.mark.asyncio

    async def test_get_size(self, index):
        """Test getting index size."""
        await index.create()
        assert await index.size() == 0
        await index.insert("key1", "value1")
        await index.insert("key2", "value2")
        size = await index.size()
        assert size >= 2
