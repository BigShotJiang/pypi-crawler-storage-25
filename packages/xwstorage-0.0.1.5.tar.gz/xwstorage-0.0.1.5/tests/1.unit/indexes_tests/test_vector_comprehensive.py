#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_vector_comprehensive.py
Comprehensive unit tests for Vector index with similarity scenarios.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import math
from exonware.xwstorage.indexes.vector_index import VectorIndex
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_performance

class TestVectorComprehensive:
    """Comprehensive tests for VectorIndex."""
    @pytest.fixture

    def index(self):
        """Create vector index fixture."""
        return VectorIndex("test_vector_comprehensive", dimension=128)
    @pytest.mark.asyncio

    async def test_vector_high_dimensional(self, index):
        """Test high-dimensional vectors."""
        await index.create()
        # Insert high-dimensional vectors
        for i in range(100):
            vector = [math.sin(j + i) for j in range(128)]
            await index.insert(f"vec_{i}", vector)
        # Similarity search
        query_vector = [math.sin(j) for j in range(128)]
        results = await index.similarity_search(query_vector, top_k=10)
        assert len(results) == 10
    @pytest.mark.asyncio

    async def test_vector_normalized_vectors(self, index):
        """Test normalized vectors."""
        await index.create()
        # Create normalized vectors
        def normalize(v):
            magnitude = math.sqrt(sum(x*x for x in v))
            return [x/magnitude for x in v] if magnitude > 0 else v
        vec1 = normalize([1.0, 0.0, 0.0] + [0.0] * 125)
        vec2 = normalize([0.0, 1.0, 0.0] + [0.0] * 125)
        await index.insert("vec1", vec1)
        await index.insert("vec2", vec2)
        # Similarity search with cosine
        results = await index.similarity_search(vec1, top_k=2, metric="cosine")
        assert len(results) >= 1
