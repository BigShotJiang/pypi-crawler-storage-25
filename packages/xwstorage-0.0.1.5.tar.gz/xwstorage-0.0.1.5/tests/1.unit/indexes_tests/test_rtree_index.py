#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_rtree_index.py
Unit tests for R-tree index.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.rtree import RTreeIndex
@pytest.mark.xwstorage_unit

class TestRTreeIndex:
    """Test RTreeIndex implementation."""
    @pytest.fixture

    def index(self):
        """Create R-tree index fixture."""
        return RTreeIndex("test_rtree_index")
    @pytest.mark.asyncio

    async def test_create_index(self, index):
        """Test creating an R-tree index."""
        await index.create()
        assert index.index_name == "test_rtree_index"
        assert index.index_type == "rtree"
    @pytest.mark.asyncio

    async def test_insert_with_bbox(self, index):
        """Test inserting with bounding box."""
        await index.create()
        # Insert with bounding box (min_x, min_y, max_x, max_y)
        await index.insert("point1", "value1", bbox=(0.0, 0.0, 1.0, 1.0))
        await index.insert("point2", "value2", bbox=(2.0, 2.0, 3.0, 3.0))
        result1 = await index.search("point1")
        result2 = await index.search("point2")
        assert result1 == "value1"
        assert result2 == "value2"
    @pytest.mark.asyncio

    async def test_insert_with_key_as_bbox(self, index):
        """Test inserting with key as bounding box tuple."""
        await index.create()
        # Key is a bbox tuple
        bbox_key = (0.0, 0.0, 1.0, 1.0)
        await index.insert(bbox_key, "value1")
        result = await index.search(bbox_key)
        assert result == "value1"
    @pytest.mark.asyncio

    async def test_spatial_query(self, index):
        """Test spatial query with bounding box."""
        await index.create()
        # Insert points
        await index.insert("point1", "value1", bbox=(0.0, 0.0, 1.0, 1.0))
        await index.insert("point2", "value2", bbox=(2.0, 2.0, 3.0, 3.0))
        await index.insert("point3", "value3", bbox=(0.5, 0.5, 1.5, 1.5))
        # Query overlapping bbox
        results = []
        async for key, value in index.spatial_query((0.0, 0.0, 2.0, 2.0)):
            results.append((key, value))
        # Should find point1 and point3 (point2 is outside)
        assert len(results) >= 2
    @pytest.mark.asyncio

    async def test_delete(self, index):
        """Test deleting from R-tree index."""
        await index.create()
        await index.insert("point1", "value1", bbox=(0.0, 0.0, 1.0, 1.0))
        result = await index.search("point1")
        assert result == "value1"
        await index.delete("point1")
        result = await index.search("point1")
        assert result is None
    @pytest.mark.asyncio

    async def test_drop_index(self, index):
        """Test dropping an R-tree index."""
        await index.create()
        await index.insert("point1", "value1", bbox=(0.0, 0.0, 1.0, 1.0))
        await index.drop()
        result = await index.search("point1")
        assert result is None
    @pytest.mark.asyncio

    async def test_get_size(self, index):
        """Test getting index size."""
        await index.create()
        assert await index.size() == 0
        await index.insert("point1", "value1", bbox=(0.0, 0.0, 1.0, 1.0))
        await index.insert("point2", "value2", bbox=(2.0, 2.0, 3.0, 3.0))
        size = await index.size()
        assert size == 2
