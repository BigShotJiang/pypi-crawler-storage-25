#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_fulltext_index.py
Unit tests for Full-text index.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.fulltext import FullTextIndex
@pytest.mark.xwstorage_unit

class TestFullTextIndex:
    """Test FullTextIndex implementation."""
    @pytest.fixture

    def index(self):
        """Create full-text index fixture."""
        return FullTextIndex("test_fulltext_index")
    @pytest.mark.asyncio

    async def test_create_index(self, index):
        """Test creating a full-text index."""
        await index.create()
        assert index.index_name == "test_fulltext_index"
        assert index.index_type == "fulltext"
    @pytest.mark.asyncio

    async def test_insert_and_search(self, index):
        """Test inserting and searching in full-text index."""
        await index.create()
        await index.insert("doc1", "The quick brown fox jumps over the lazy dog")
        await index.insert("doc2", "Python is a programming language")
        await index.insert("doc3", "Machine learning and artificial intelligence")
        # Search for "fox"
        results = []
        async for doc_id, score in index.search("fox"):
            results.append((doc_id, score))
        assert len(results) > 0
        assert any(doc_id == "doc1" for doc_id, _ in results)
    @pytest.mark.asyncio

    async def test_search_multiple_terms(self, index):
        """Test searching with multiple terms."""
        await index.create()
        await index.insert("doc1", "Python programming language")
        await index.insert("doc2", "Java programming language")
        await index.insert("doc3", "Python machine learning")
        # Search for "Python programming"
        results = []
        async for doc_id, score in index.search("Python programming"):
            results.append((doc_id, score))
        # Should find doc1 (has both terms)
        assert len(results) > 0
        doc_ids = [doc_id for doc_id, _ in results]
        assert "doc1" in doc_ids
    @pytest.mark.asyncio

    async def test_search_case_insensitive(self, index):
        """Test that search is case-insensitive."""
        await index.create()
        await index.insert("doc1", "Python Programming")
        # Search with different case
        results = []
        async for doc_id, score in index.search("python"):
            results.append((doc_id, score))
        assert len(results) > 0
        assert any(doc_id == "doc1" for doc_id, _ in results)
    @pytest.mark.asyncio

    async def test_delete_document(self, index):
        """Test deleting a document."""
        await index.create()
        await index.insert("doc1", "The quick brown fox")
        await index.insert("doc2", "Python programming")
        # Search before delete
        results = []
        async for doc_id, score in index.search("fox"):
            results.append((doc_id, score))
        assert any(doc_id == "doc1" for doc_id, _ in results)
        # Delete document
        await index.delete("doc1")
        # Search after delete
        results = []
        async for doc_id, score in index.search("fox"):
            results.append((doc_id, score))
        assert not any(doc_id == "doc1" for doc_id, _ in results)
    @pytest.mark.asyncio

    async def test_drop_index(self, index):
        """Test dropping a full-text index."""
        await index.create()
        await index.insert("doc1", "The quick brown fox")
        await index.drop()
        # After drop, search should return no results
        results = []
        async for doc_id, score in index.search("fox"):
            results.append((doc_id, score))
        assert len(results) == 0
    @pytest.mark.asyncio

    async def test_get_size(self, index):
        """Test getting index size."""
        await index.create()
        assert await index.size() == 0
        await index.insert("doc1", "The quick brown fox")
        await index.insert("doc2", "Python programming")
        size = await index.size()
        assert size == 2
    @pytest.mark.asyncio

    async def test_relevance_scoring(self, index):
        """Test that search results are scored by relevance."""
        await index.create()
        await index.insert("doc1", "Python Python Python")  # High frequency
        await index.insert("doc2", "Python")  # Low frequency
        # Search for "Python"
        results = []
        async for doc_id, score in index.search("Python"):
            results.append((doc_id, score))
        # Results should be ordered by relevance
        assert len(results) >= 2
        # doc1 should have higher score (more occurrences)
        scores = {doc_id: score for doc_id, score in results}
        assert scores.get("doc1", 0) >= scores.get("doc2", 0)
