#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_secondary_index_manager.py
Unit tests for Secondary Index Manager.
Tests index registration, query routing, workload analysis, and recommendations.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.secondary_index_manager import (
    SecondaryIndexManager,
    IndexRecommendation,
    QueryPattern
)
from exonware.xwstorage.indexes import HashIndex, BTreeIndex, CompositeIndex
@pytest.mark.xwstorage_unit

class TestSecondaryIndexManager:
    """Test SecondaryIndexManager implementation."""
    @pytest.fixture

    def manager(self):
        """Create secondary index manager fixture."""
        return SecondaryIndexManager()
    @pytest.mark.asyncio

    async def test_register_index(self, manager):
        """Test registering an index."""
        await manager.initialize()
        hash_index = HashIndex("test_hash_idx")
        await manager.register_index("test_hash_idx", hash_index, fields=["email"])
        stats = manager.get_index_stats()
        assert stats["total_indexes"] == 1
        assert "test_hash_idx" in stats["indexes"]
        assert stats["indexes"]["test_hash_idx"]["fields"] == ["email"]
    @pytest.mark.asyncio

    async def test_unregister_index(self, manager):
        """Test unregistering an index."""
        await manager.initialize()
        hash_index = HashIndex("test_hash_idx")
        await manager.register_index("test_hash_idx", hash_index, fields=["email"])
        assert manager.get_index_stats()["total_indexes"] == 1
        await manager.unregister_index("test_hash_idx")
        assert manager.get_index_stats()["total_indexes"] == 0
    @pytest.mark.asyncio

    async def test_query_with_exact_match(self, manager):
        """Test querying with exact match."""
        await manager.initialize()
        hash_index = HashIndex("email_idx")
        await hash_index.create()
        await hash_index.insert("user@example.com", "doc1")
        await manager.register_index("email_idx", hash_index, fields=["email"])
        results = await manager.query(fields=["email"], value="user@example.com", query_type="exact")
        assert len(results) == 1
        assert results[0] == "doc1"
    @pytest.mark.asyncio

    async def test_select_best_index(self, manager):
        """Test selecting the best index for a query."""
        await manager.initialize()
        # Register hash index
        hash_index = HashIndex("email_hash_idx")
        await manager.register_index("email_hash_idx", hash_index, fields=["email"])
        # Register composite index (more specific)
        composite_index = CompositeIndex("user_email_composite", fields=["user_id", "email"])
        await manager.register_index("user_email_composite", composite_index, fields=["user_id", "email"])
        # Query on single field - should prefer hash index
        best = manager._select_best_index(["email"], "exact")
        assert best == "email_hash_idx"
        # Query on both fields - should prefer composite index
        best = manager._select_best_index(["user_id", "email"], "exact")
        assert best == "user_email_composite"
    @pytest.mark.asyncio

    async def test_workload_analysis(self, manager):
        """Test workload analysis and recommendations."""
        await manager.initialize()
        # Log some queries
        for _ in range(20):
            manager._log_query(["age"], "range")
        for _ in range(15):
            manager._log_query(["name"], "exact")
        # Analyze and get recommendations
        recommendations = await manager.analyze_workload_and_recommend(min_frequency=10)
        # Should recommend indexes for frequent patterns
        assert len(recommendations) >= 1
        # Check that recommendations have reasonable priority
        for rec in recommendations:
            assert rec.priority > 0.0
            assert rec.index_type in ("hash", "btree", "composite", "rtree")
            assert len(rec.fields) > 0
            assert len(rec.reason) > 0
    @pytest.mark.asyncio

    async def test_index_stats(self, manager):
        """Test getting index statistics."""
        await manager.initialize()
        hash_index = HashIndex("test_idx")
        await manager.register_index("test_idx", hash_index, fields=["field1"])
        # Query a few times
        await manager.query(fields=["field1"], value="value1", query_type="exact")
        await manager.query(fields=["field1"], value="value2", query_type="exact")
        stats = manager.get_index_stats()
        assert stats["total_indexes"] == 1
        assert stats["total_queries"] == 2
        assert stats["indexes"]["test_idx"]["query_count"] == 2
    @pytest.mark.asyncio

    async def test_index_type_recommendation(self, manager):
        """Test index type recommendation logic."""
        await manager.initialize()
        # Range query should recommend btree
        pattern = QueryPattern(fields=["age"], query_type="range", frequency=50)
        index_type = manager._recommend_index_type(pattern)
        assert index_type == "btree"
        # Exact query on single field should recommend hash
        pattern = QueryPattern(fields=["email"], query_type="exact", frequency=50)
        index_type = manager._recommend_index_type(pattern)
        assert index_type == "hash"
        # Multi-field should recommend composite
        pattern = QueryPattern(fields=["user_id", "email"], query_type="exact", frequency=50)
        index_type = manager._recommend_index_type(pattern)
        assert index_type == "composite"
        # Spatial should recommend rtree
        pattern = QueryPattern(fields=["location"], query_type="spatial", frequency=50)
        index_type = manager._recommend_index_type(pattern)
        assert index_type == "rtree"
