#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_hash_index_comprehensive.py
Comprehensive unit tests for Hash index with edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.hash_index import HashIndex
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_performance

class TestHashIndexComprehensive:
    """Comprehensive tests for HashIndex."""
    @pytest.fixture

    def index(self):
        """Create hash index fixture."""
        return HashIndex("test_hash_comprehensive")
    @pytest.mark.asyncio

    async def test_hash_index_collision_handling(self, index):
        """Test hash collision handling."""
        await index.create()
        # Insert keys that might collide
        await index.insert("key1", "value1")
        await index.insert("key2", "value2")
        await index.insert("key3", "value3")
        # All should be retrievable
        assert await index.search("key1") == "value1"
        assert await index.search("key2") == "value2"
        assert await index.search("key3") == "value3"
    @pytest.mark.asyncio

    async def test_hash_index_large_dataset(self, index):
        """Test hash index with large dataset."""
        await index.create()
        # Insert 1000 keys
        for i in range(1000):
            await index.insert(f"key_{i}", f"value_{i}")
        # Verify random access
        import random
        for _ in range(10):
            i = random.randint(0, 999)
            result = await index.search(f"key_{i}")
            assert result == f"value_{i}"
        size = await index.size()
        assert size == 1000
    @pytest.mark.asyncio

    async def test_hash_index_string_keys(self, index):
        """Test hash index with string keys."""
        await index.create()
        keys = ["alpha", "beta", "gamma", "delta", "epsilon"]
        for key in keys:
            await index.insert(key, f"value_{key}")
        for key in keys:
            result = await index.search(key)
            assert result == f"value_{key}"
    @pytest.mark.asyncio

    async def test_hash_index_numeric_keys(self, index):
        """Test hash index with numeric keys."""
        await index.create()
        for i in range(100):
            await index.insert(i, f"value_{i}")
        for i in range(100):
            result = await index.search(i)
            assert result == f"value_{i}"
    @pytest.mark.asyncio

    async def test_hash_index_delete_all(self, index):
        """Test deleting all keys."""
        await index.create()
        # Insert keys
        for i in range(10):
            await index.insert(i, f"value_{i}")
        # Delete all
        for i in range(10):
            await index.delete(i)
        # Verify all deleted
        for i in range(10):
            result = await index.search(i)
            assert result is None
        size = await index.size()
        assert size == 0
    @pytest.mark.asyncio

    async def test_hash_index_update_chain(self, index):
        """Test updating same key multiple times."""
        await index.create()
        key = "test_key"
        for i in range(10):
            await index.insert(key, f"value_{i}")
            result = await index.search(key)
            assert result == f"value_{i}"
