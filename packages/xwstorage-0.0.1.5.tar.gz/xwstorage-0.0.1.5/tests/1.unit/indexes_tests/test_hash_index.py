#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_hash_index.py
Unit tests for hash index implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes import HashIndex
@pytest.mark.xwstorage_unit

class TestHashIndex:
    """Test HashIndex implementation."""
    @pytest.fixture

    def index(self):
        """Create hash index fixture."""
        return HashIndex("test_hash_index")
    @pytest.mark.asyncio

    async def test_create_index(self, index):
        """Test creating an index."""
        await index.create()
        stats = index.get_stats()
        assert stats["index_name"] == "test_hash_index"
        assert stats["index_type"] == "hash"
    @pytest.mark.asyncio

    async def test_insert_and_search(self, index):
        """Test inserting and searching."""
        await index.create()
        await index.insert("key1", "value1")
        result = await index.search("key1")
        assert result == "value1"
    @pytest.mark.asyncio

    async def test_insert_and_delete(self, index):
        """Test inserting and deleting."""
        await index.create()
        await index.insert("key1", "value1")
        await index.delete("key1")
        result = await index.search("key1")
        assert result is None
    @pytest.mark.asyncio

    async def test_range_search_warning(self, index):
        """Test range search (inefficient for hash index)."""
        await index.create()
        await index.insert("key1", "value1")
        await index.insert("key2", "value2")
        # Range search should work but is inefficient
        results = await index.range_search("key1", "key2")
        assert len(results) >= 0  # May return results or empty
    @pytest.mark.asyncio

    async def test_drop_index(self, index):
        """Test dropping an index."""
        await index.create()
        await index.insert("key1", "value1")
        await index.drop()
        # After drop, search should return None
        result = await index.search("key1")
        # Index is cleared, so result may be None or empty
        assert result is None or result == "value1"  # Depending on implementation
