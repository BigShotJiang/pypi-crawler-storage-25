#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_universal_index.py
Unit tests for Universal Index.
Tests automatic indexing on ingest, key extraction, and path-based queries.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.universal_index import UniversalIndex
@pytest.mark.xwstorage_unit

class TestUniversalIndex:
    """Test UniversalIndex implementation."""
    @pytest.fixture

    def index(self):
        """Create universal index fixture."""
        return UniversalIndex("test_universal")
    @pytest.mark.asyncio

    async def test_create_universal_index(self, index):
        """Test creating a universal index."""
        await index.create()
        assert index.index_name == "test_universal"
        assert index.index_type == "universal"
    @pytest.mark.asyncio

    async def test_index_simple_document(self, index):
        """Test indexing a simple document."""
        await index.create()
        doc = {
            "id": "doc1",
            "name": "Alice",
            "age": 30
        }
        await index.index_document("doc1", doc)
        # Check that paths were indexed
        paths = index.get_indexed_paths()
        assert "id" in paths
        assert "name" in paths
        assert "age" in paths
    @pytest.mark.asyncio

    async def test_search_path(self, index):
        """Test searching by path."""
        await index.create()
        doc = {
            "id": "doc1",
            "name": "Alice",
            "age": 30
        }
        await index.index_document("doc1", doc)
        # Search by name
        results = await index.search_path("name", "Alice")
        assert "doc1" in results
        # Search by age
        results = await index.search_path("age", 30)
        assert "doc1" in results
    @pytest.mark.asyncio

    async def test_index_nested_document(self, index):
        """Test indexing a nested document."""
        await index.create()
        doc = {
            "id": "doc1",
            "user": {
                "name": "Alice",
                "age": 30
            },
            "tags": ["python", "database"]
        }
        await index.index_document("doc1", doc)
        # Check nested paths
        paths = index.get_indexed_paths()
        assert "user.name" in paths
        assert "user.age" in paths
        assert "tags[0]" in paths
        assert "tags[1]" in paths
    @pytest.mark.asyncio

    async def test_search_nested_path(self, index):
        """Test searching nested paths."""
        await index.create()
        doc = {
            "id": "doc1",
            "user": {
                "name": "Alice",
                "age": 30
            }
        }
        await index.index_document("doc1", doc)
        # Search nested path
        results = await index.search_path("user.name", "Alice")
        assert "doc1" in results
        results = await index.search_path("user.age", 30)
        assert "doc1" in results
    @pytest.mark.asyncio

    async def test_search_path_range(self, index):
        """Test range search on numeric paths."""
        await index.create()
        await index.index_document("doc1", {"id": "doc1", "age": 25})
        await index.index_document("doc2", {"id": "doc2", "age": 30})
        await index.index_document("doc3", {"id": "doc3", "age": 35})
        # Range search
        results = await index.search_path_range("age", 25, 35)
        assert len(results) >= 3
        assert "doc1" in results
        assert "doc2" in results
        assert "doc3" in results
    @pytest.mark.asyncio

    async def test_get_document_paths(self, index):
        """Test getting paths for a specific document."""
        await index.create()
        doc = {
            "id": "doc1",
            "name": "Alice",
            "age": 30,
            "tags": ["python"]
        }
        await index.index_document("doc1", doc)
        paths = index.get_document_paths("doc1")
        assert "id" in paths
        assert "name" in paths
        assert "age" in paths
        assert "tags[0]" in paths
    @pytest.mark.asyncio

    async def test_multiple_documents_same_value(self, index):
        """Test multiple documents with same value."""
        await index.create()
        await index.index_document("doc1", {"name": "Alice", "status": "active"})
        await index.index_document("doc2", {"name": "Bob", "status": "active"})
        await index.index_document("doc3", {"name": "Charlie", "status": "active"})
        # All should match status="active"
        results = await index.search_path("status", "active")
        assert len(results) == 3
        assert "doc1" in results
        assert "doc2" in results
        assert "doc3" in results
    @pytest.mark.asyncio

    async def test_get_stats(self, index):
        """Test getting index statistics."""
        await index.create()
        await index.index_document("doc1", {"name": "Alice", "age": 30})
        await index.index_document("doc2", {"name": "Bob", "age": 25})
        stats = index.get_stats()
        assert stats["index_name"] == "test_universal"
        assert stats["index_type"] == "universal"
        assert stats["indexed_documents"] == 2
        assert stats["total_paths"] > 0
