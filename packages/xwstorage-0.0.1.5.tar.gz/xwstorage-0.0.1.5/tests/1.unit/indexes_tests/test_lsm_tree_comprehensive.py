#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_lsm_tree_comprehensive.py
Comprehensive unit tests for LSM-tree index with write-heavy scenarios.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.lsm_tree import LSMTreeIndex
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_performance

class TestLSMTreeComprehensive:
    """Comprehensive tests for LSMTreeIndex."""
    @pytest.fixture

    def index(self):
        """Create LSM-tree index fixture."""
        return LSMTreeIndex("test_lsm_comprehensive")
    @pytest.mark.asyncio

    async def test_lsm_write_heavy_workload(self, index):
        """Test write-heavy workload."""
        await index.create()
        # Insert 1000 keys (write-heavy)
        for i in range(1000):
            await index.insert(f"key_{i}", f"value_{i}")
        # Verify random reads
        import random
        for _ in range(20):
            i = random.randint(0, 999)
            result = await index.search(f"key_{i}")
            assert result == f"value_{i}"
    @pytest.mark.asyncio

    async def test_lsm_range_query_performance(self, index):
        """Test range query performance."""
        await index.create()
        # Insert sequential keys
        for i in range(500):
            await index.insert(i, f"value_{i}")
        # Range query
        results = await index.range_search(100, 200)
        assert len(results) >= 100
    @pytest.mark.asyncio

    async def test_lsm_update_frequency(self, index):
        """Test frequent updates to same keys."""
        await index.create()
        # Update same key many times
        for i in range(100):
            await index.insert("hot_key", f"value_{i}")
            result = await index.search("hot_key")
            assert result == f"value_{i}"
