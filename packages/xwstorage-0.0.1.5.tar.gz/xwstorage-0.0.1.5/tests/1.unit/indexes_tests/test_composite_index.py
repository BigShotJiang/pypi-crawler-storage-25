#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_composite_index.py
Unit tests for Composite Index.
Tests multi-field indexing, prefix searches, and range queries.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.composite_index import CompositeIndex
@pytest.mark.xwstorage_unit

class TestCompositeIndex:
    """Test CompositeIndex implementation."""
    @pytest.fixture

    def index(self):
        """Create composite index fixture."""
        return CompositeIndex("test_composite", fields=["user_id", "timestamp"])
    @pytest.mark.asyncio

    async def test_create_composite_index(self, index):
        """Test creating a composite index."""
        await index.create()
        assert index.index_name == "test_composite"
        assert index.index_type == "composite"
        assert index.fields == ["user_id", "timestamp"]
        assert index.field_count == 2
    @pytest.mark.asyncio

    async def test_insert_with_tuple_key(self, index):
        """Test inserting with tuple key."""
        await index.create()
        await index.insert((123, 1609459200.0), {"user_id": 123, "timestamp": 1609459200.0})
        await index.insert((123, 1609545600.0), {"user_id": 123, "timestamp": 1609545600.0})
        await index.insert((456, 1609459200.0), {"user_id": 456, "timestamp": 1609459200.0})
        # Verify insertion
        result = await index.search((123, 1609459200.0))
        assert result is not None
        assert result["user_id"] == 123
    @pytest.mark.asyncio

    async def test_insert_with_dict_key(self, index):
        """Test inserting with dictionary key."""
        await index.create()
        await index.insert({"user_id": 123, "timestamp": 1609459200.0}, {"data": "test"})
        result = await index.search({"user_id": 123, "timestamp": 1609459200.0})
        assert result is not None
        assert result["data"] == "test"
    @pytest.mark.asyncio

    async def test_prefix_search(self, index):
        """Test prefix search on first field."""
        await index.create()
        # Insert multiple entries for user_id=123
        await index.insert((123, 1609459200.0), {"user_id": 123, "timestamp": 1609459200.0, "data": "a"})
        await index.insert((123, 1609545600.0), {"user_id": 123, "timestamp": 1609545600.0, "data": "b"})
        await index.insert((123, 1609632000.0), {"user_id": 123, "timestamp": 1609632000.0, "data": "c"})
        # Insert entry for different user_id
        await index.insert((456, 1609459200.0), {"user_id": 456, "timestamp": 1609459200.0, "data": "d"})
        # Prefix search for user_id=123
        results = await index.prefix_search((123,))
        assert len(results) == 3
        # Verify all results are for user_id=123
        user_ids = {r["user_id"] for r in results}
        assert user_ids == {123}
    @pytest.mark.asyncio

    async def test_prefix_search_single_value(self, index):
        """Test prefix search with single value."""
        await index.create()
        await index.insert((123, 1609459200.0), {"user_id": 123, "timestamp": 1609459200.0})
        await index.insert((123, 1609545600.0), {"user_id": 123, "timestamp": 1609545600.0})
        # Single value treated as first field
        results = await index.prefix_search(123)
        assert len(results) >= 2
    @pytest.mark.asyncio

    async def test_range_search(self, index):
        """Test range search on composite key."""
        await index.create()
        await index.insert((123, 1609459200.0), {"user_id": 123, "timestamp": 1609459200.0})
        await index.insert((123, 1609545600.0), {"user_id": 123, "timestamp": 1609545600.0})
        await index.insert((123, 1609632000.0), {"user_id": 123, "timestamp": 1609632000.0})
        # Range search: user_id=123, timestamp between 1609459200.0 and 1609545600.0
        results = await index.range_search(
            (123, 1609459200.0),
            (123, 1609545600.0)
        )
        assert len(results) >= 2
    @pytest.mark.asyncio

    async def test_exact_search(self, index):
        """Test exact search on composite key."""
        await index.create()
        await index.insert((123, 1609459200.0), {"user_id": 123, "timestamp": 1609459200.0, "data": "exact"})
        result = await index.search((123, 1609459200.0))
        assert result is not None
        assert result["data"] == "exact"
    @pytest.mark.asyncio

    async def test_delete(self, index):
        """Test deleting from composite index."""
        await index.create()
        await index.insert((123, 1609459200.0), {"user_id": 123, "timestamp": 1609459200.0})
        result = await index.search((123, 1609459200.0))
        assert result is not None
        await index.delete((123, 1609459200.0))
        result = await index.search((123, 1609459200.0))
        assert result is None
    @pytest.mark.asyncio

    async def test_three_field_composite(self):
        """Test composite index with three fields."""
        index = CompositeIndex("test_3field", fields=["user_id", "category", "timestamp"])
        await index.create()
        await index.insert((123, "A", 1609459200.0), {"user_id": 123, "category": "A", "timestamp": 1609459200.0})
        await index.insert((123, "A", 1609545600.0), {"user_id": 123, "category": "A", "timestamp": 1609545600.0})
        await index.insert((123, "B", 1609459200.0), {"user_id": 123, "category": "B", "timestamp": 1609459200.0})
        # Prefix search on first two fields
        results = await index.prefix_search((123, "A"))
        assert len(results) == 2
        # Verify all results have category "A"
        categories = {r["category"] for r in results}
        assert categories == {"A"}
    @pytest.mark.asyncio

    async def test_get_stats(self, index):
        """Test getting index statistics."""
        await index.create()
        await index.insert((123, 1609459200.0), {"user_id": 123, "timestamp": 1609459200.0})
        await index.insert((123, 1609545600.0), {"user_id": 123, "timestamp": 1609545600.0})
        stats = index.get_stats()
        assert stats["index_name"] == "test_composite"
        assert stats["index_type"] == "composite"
        assert stats["fields"] == ["user_id", "timestamp"]
        assert stats["field_count"] == 2
        assert stats["size"] >= 2
