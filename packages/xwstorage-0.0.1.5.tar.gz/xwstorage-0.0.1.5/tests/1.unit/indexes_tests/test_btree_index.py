#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_btree_index.py
Unit tests for B+tree index implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes import BTreeIndex
@pytest.mark.xwstorage_unit

class TestBTreeIndex:
    """Test BTreeIndex implementation."""
    @pytest.fixture

    def index(self):
        """Create B+tree index fixture."""
        return BTreeIndex("test_btree_index")
    @pytest.mark.asyncio

    async def test_create_index(self, index):
        """Test creating an index."""
        await index.create()
        stats = index.get_stats()
        assert stats["index_name"] == "test_btree_index"
        assert stats["index_type"] == "btree"
    @pytest.mark.asyncio

    async def test_insert_and_search(self, index):
        """Test inserting and searching."""
        await index.create()
        await index.insert("key1", "value1")
        result = await index.search("key1")
        assert result == "value1"
    @pytest.mark.asyncio

    async def test_range_search(self, index):
        """Test range search."""
        await index.create()
        await index.insert("key1", "value1")
        await index.insert("key2", "value2")
        await index.insert("key3", "value3")
        results = await index.range_search("key1", "key2")
        assert len(results) >= 1
        assert "value1" in results or "value2" in results
    @pytest.mark.asyncio

    async def test_delete(self, index):
        """Test deleting from index."""
        await index.create()
        await index.insert("key1", "value1")
        await index.delete("key1")
        result = await index.search("key1")
        assert result is None
