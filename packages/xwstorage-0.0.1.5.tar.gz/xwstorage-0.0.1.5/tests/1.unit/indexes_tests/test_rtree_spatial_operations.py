#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_rtree_spatial_operations.py
Comprehensive unit tests for R-tree spatial query operations.
Tests within, intersects, and distance queries for geospatial data.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 23-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.rtree import RTreeIndex
@pytest.mark.xwstorage_unit

class TestRTreeSpatialOperations:
    """Test R-tree spatial query operations."""
    @pytest.fixture

    def index(self):
        """Create R-tree index fixture."""
        return RTreeIndex("test_rtree_spatial")
    @pytest.mark.asyncio

    async def test_within_query(self, index):
        """Test within query - find geometries completely within a bounding box."""
        await index.create()
        # Insert geometries
        await index.insert("geom1", "value1", bbox=(1.0, 1.0, 2.0, 2.0))  # Completely within query box
        await index.insert("geom2", "value2", bbox=(1.5, 1.5, 2.5, 2.5))  # Partially overlaps (extends outside)
        await index.insert("geom3", "value3", bbox=(3.0, 3.0, 4.0, 4.0))  # Outside query box
        # Query box
        query_bbox = (0.0, 0.0, 2.0, 2.0)
        results = await index.within(query_bbox)
        # Only geom1 should be completely within
        assert "value1" in results
        assert "value2" not in results  # Extends outside
        assert "value3" not in results  # Outside
    @pytest.mark.asyncio

    async def test_within_query_edge_cases(self, index):
        """Test within query edge cases."""
        await index.create()
        # Insert geometry exactly matching query box
        await index.insert("geom1", "value1", bbox=(0.0, 0.0, 1.0, 1.0))
        query_bbox = (0.0, 0.0, 1.0, 1.0)
        results = await index.within(query_bbox)
        assert "value1" in results  # Should match exactly
        # Empty query box
        empty_results = await index.within((0.0, 0.0, 0.0, 0.0))
        assert len(empty_results) == 0
    @pytest.mark.asyncio

    async def test_intersects_query(self, index):
        """Test intersects query - find geometries that intersect with a bounding box."""
        await index.create()
        # Insert geometries
        await index.insert("geom1", "value1", bbox=(1.0, 1.0, 2.0, 2.0))  # Completely within
        await index.insert("geom2", "value2", bbox=(1.5, 1.5, 2.5, 2.5))  # Partially overlaps
        await index.insert("geom3", "value3", bbox=(3.0, 3.0, 4.0, 4.0))  # Outside
        await index.insert("geom4", "value4", bbox=(1.9, 1.9, 3.0, 3.0))  # Touches/overlaps
        # Query box
        query_bbox = (0.0, 0.0, 2.0, 2.0)
        results = await index.intersects(query_bbox)
        # geom1, geom2, and geom4 should intersect
        assert "value1" in results
        assert "value2" in results
        assert "value4" in results
        assert "value3" not in results  # No intersection
    @pytest.mark.asyncio

    async def test_intersects_query_touching(self, index):
        """Test intersects query with touching geometries."""
        await index.create()
        # Insert geometry that touches query box edge
        await index.insert("geom1", "value1", bbox=(2.0, 0.0, 3.0, 1.0))  # Touches right edge
        query_bbox = (0.0, 0.0, 2.0, 1.0)
        results = await index.intersects(query_bbox)
        # Touching should count as intersection
        assert "value1" in results
    @pytest.mark.asyncio

    async def test_distance_query(self, index):
        """Test distance query - find geometries within a distance from a point."""
        await index.create()
        # Insert geometries
        await index.insert("geom1", "value1", bbox=(1.0, 1.0, 2.0, 2.0))  # Close to point (0, 0)
        await index.insert("geom2", "value2", bbox=(5.0, 5.0, 6.0, 6.0))  # Far from point (0, 0)
        await index.insert("geom3", "value3", bbox=(0.5, 0.5, 1.0, 1.0))  # Very close
        # Query point and max distance
        point = (0.0, 0.0)
        max_distance = 2.0
        results = await index.distance(point, max_distance)
        # Results should be sorted by distance (closest first)
        assert len(results) >= 2
        values = [r[0] for r in results]
        distances = [r[1] for r in results]
        # Check that results are sorted by distance
        assert distances == sorted(distances)
        # geom3 and geom1 should be within distance, geom2 should not
        assert "value3" in values
        assert "value1" in values
        assert "value2" not in values
        # geom3 should be closer than geom1
        value3_idx = values.index("value3")
        value1_idx = values.index("value1")
        assert value3_idx < value1_idx
    @pytest.mark.asyncio

    async def test_distance_query_point_inside_bbox(self, index):
        """Test distance query when point is inside a bounding box."""
        await index.create()
        # Insert geometry containing the point
        await index.insert("geom1", "value1", bbox=(0.0, 0.0, 2.0, 2.0))
        # Point is inside the bbox, distance should be 0
        point = (1.0, 1.0)
        results = await index.distance(point, max_distance=1.0)
        assert len(results) == 1
        assert results[0][0] == "value1"
        assert results[0][1] == 0.0
    @pytest.mark.asyncio

    async def test_distance_query_empty(self, index):
        """Test distance query with no results."""
        await index.create()
        await index.insert("geom1", "value1", bbox=(10.0, 10.0, 11.0, 11.0))
        point = (0.0, 0.0)
        max_distance = 1.0
        results = await index.distance(point, max_distance)
        assert len(results) == 0
    @pytest.mark.asyncio

    async def test_combined_spatial_queries(self, index):
        """Test combining multiple spatial query types."""
        await index.create()
        # Insert various geometries
        await index.insert("geom1", "value1", bbox=(1.0, 1.0, 2.0, 2.0))
        await index.insert("geom2", "value2", bbox=(2.0, 2.0, 3.0, 3.0))
        await index.insert("geom3", "value3", bbox=(5.0, 5.0, 6.0, 6.0))
        query_bbox = (0.0, 0.0, 2.5, 2.5)
        # Test within
        within_results = await index.within(query_bbox)
        assert "value1" in within_results
        # Test intersects
        intersects_results = await index.intersects(query_bbox)
        assert "value1" in intersects_results
        assert "value2" in intersects_results  # Overlaps
        # Test distance
        point = (1.5, 1.5)
        distance_results = await index.distance(point, max_distance=2.0)
        values = [r[0] for r in distance_results]
        assert "value1" in values
        assert "value2" in values
        assert "value3" not in values
    @pytest.mark.asyncio

    async def test_spatial_query_invalid_input(self, index):
        """Test spatial queries with invalid input."""
        await index.create()
        # Invalid bbox (wrong type)
        within_results = await index.within("invalid")
        assert len(within_results) == 0
        intersects_results = await index.intersects("invalid")
        assert len(intersects_results) == 0
        # Invalid point (wrong type)
        distance_results = await index.distance("invalid", 1.0)
        assert len(distance_results) == 0
        # Invalid point (wrong length)
        distance_results2 = await index.distance((1.0,), 1.0)
        assert len(distance_results2) == 0
