#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_fulltext_comprehensive.py
Comprehensive unit tests for Full-text index with various text scenarios.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.fulltext import FullTextIndex
@pytest.mark.xwstorage_unit

class TestFullTextComprehensive:
    """Comprehensive tests for FullTextIndex."""
    @pytest.fixture

    def index(self):
        """Create full-text index fixture."""
        return FullTextIndex("test_fulltext_comprehensive")
    @pytest.mark.asyncio

    async def test_fulltext_multilingual(self, index):
        """Test multilingual text search."""
        await index.create()
        await index.insert("doc1", "Hello world")
        await index.insert("doc2", "Bonjour le monde")
        await index.insert("doc3", "Hola mundo")
        # Search for "world" variants using search_text
        results = await index.search_text("world")
        assert len(results) > 0
    @pytest.mark.asyncio

    async def test_fulltext_special_characters(self, index):
        """Test text with special characters."""
        await index.create()
        await index.insert("doc1", "Test with @special #characters $and %symbols")
        results = await index.search_text("special")
        assert len(results) > 0
    @pytest.mark.asyncio

    async def test_fulltext_long_document(self, index):
        """Test indexing long documents."""
        await index.create()
        long_text = " ".join([f"word_{i}" for i in range(1000)])
        await index.insert("doc_long", long_text)
        results = await index.search_text("word_500")
        assert len(results) > 0
    @pytest.mark.asyncio

    async def test_fulltext_phrase_search(self, index):
        """Test phrase search."""
        await index.create()
        await index.insert("doc1", "The quick brown fox jumps over the lazy dog")
        await index.insert("doc2", "A quick brown dog")
        # Search for phrase
        results = await index.search_text("quick brown fox")
        # doc1 should have higher relevance
        assert len(results) > 0
