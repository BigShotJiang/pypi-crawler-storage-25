#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_btree_comprehensive.py
Comprehensive unit tests for B+tree index with edge cases.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.btree import BTreeIndex
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_performance

class TestBTreeComprehensive:
    """Comprehensive tests for BTreeIndex."""
    @pytest.fixture

    def index(self):
        """Create B-tree index fixture."""
        return BTreeIndex("test_btree_comprehensive")
    @pytest.mark.asyncio

    async def test_btree_large_insertion(self, index):
        """Test inserting large number of keys."""
        await index.create()
        # Insert 1000 keys
        for i in range(1000):
            await index.insert(f"key_{i:04d}", f"value_{i}")
        # Verify all keys exist
        for i in range(1000):
            result = await index.search(f"key_{i:04d}")
            assert result == f"value_{i}"
        stats = index.get_stats()
        assert stats["size"] == 1000
    @pytest.mark.asyncio

    async def test_btree_sequential_insertion(self, index):
        """Test sequential key insertion."""
        await index.create()
        for i in range(100):
            await index.insert(i, f"value_{i}")
        # Verify sequential access
        for i in range(100):
            result = await index.search(i)
            assert result == f"value_{i}"
    @pytest.mark.asyncio

    async def test_btree_reverse_insertion(self, index):
        """Test reverse order insertion."""
        await index.create()
        for i in range(99, -1, -1):
            await index.insert(i, f"value_{i}")
        # Verify all keys
        for i in range(100):
            result = await index.search(i)
            assert result == f"value_{i}"
    @pytest.mark.asyncio

    async def test_btree_random_insertion(self, index):
        """Test random key insertion."""
        import random
        await index.create()
        keys = list(range(100))
        random.shuffle(keys)
        for key in keys:
            await index.insert(key, f"value_{key}")
        # Verify all keys
        for key in range(100):
            result = await index.search(key)
            assert result == f"value_{key}"
    @pytest.mark.asyncio

    async def test_btree_range_query_large(self, index):
        """Test range query on large dataset."""
        await index.create()
        # Insert 500 keys
        for i in range(500):
            await index.insert(i, f"value_{i}")
        # Range query (returns list of values)
        results = await index.range_search(100, 200)
        assert len(results) == 101  # Keys 100 to 200 inclusive
    @pytest.mark.asyncio

    async def test_btree_delete_and_reinsert(self, index):
        """Test deleting and reinserting keys."""
        await index.create()
        # Insert
        await index.insert("key1", "value1")
        await index.insert("key2", "value2")
        # Delete
        await index.delete("key1")
        result = await index.search("key1")
        assert result is None
        # Reinsert
        await index.insert("key1", "value1_new")
        result = await index.search("key1")
        assert result == "value1_new"
    @pytest.mark.asyncio

    async def test_btree_update_existing_key(self, index):
        """Test updating existing key."""
        await index.create()
        await index.insert("key1", "value1")
        result = await index.search("key1")
        assert result == "value1"
        # Update
        await index.insert("key1", "value1_updated")
        result = await index.search("key1")
        assert result == "value1_updated"
    @pytest.mark.asyncio

    async def test_btree_range_query_edge_cases(self, index):
        """Test range query with edge cases."""
        await index.create()
        for i in range(100):
            await index.insert(i, f"value_{i}")
        # Range query with same start and end
        results = await index.range_search(50, 50)
        assert len(results) >= 0  # May return 0 or 1 depending on implementation
    @pytest.mark.asyncio

    async def test_btree_string_keys_ordering(self, index):
        """Test string keys maintain ordering."""
        await index.create()
        keys = ["alpha", "beta", "gamma", "delta"]
        for key in keys:
            await index.insert(key, f"value_{key}")
        # Range query should return in order
        results = await index.range_search("alpha", "gamma")
        # Should return values in range
        assert len(results) >= 0
