#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/1.unit/indexes_tests/test_vector_index.py
Unit tests for Vector index.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
from exonware.xwstorage.indexes.vector_index import VectorIndex
@pytest.mark.xwstorage_unit

class TestVectorIndex:
    """Test VectorIndex implementation."""
    @pytest.fixture

    def index(self):
        """Create vector index fixture."""
        return VectorIndex("test_vector_index", dimension=4)
    @pytest.mark.asyncio

    async def test_create_index(self, index):
        """Test creating a vector index."""
        await index.create()
        assert index.index_name == "test_vector_index"
        assert index.index_type == "vector"
        assert index.dimension == 4
    @pytest.mark.asyncio

    async def test_insert_and_search(self, index):
        """Test inserting and searching in vector index."""
        await index.create()
        # Insert vectors
        await index.insert("vec1", [1.0, 0.0, 0.0, 0.0])
        await index.insert("vec2", [0.0, 1.0, 0.0, 0.0])
        await index.insert("vec3", [0.0, 0.0, 1.0, 0.0])
        result1 = await index.search("vec1")
        result2 = await index.search("vec2")
        assert result1 == [1.0, 0.0, 0.0, 0.0]
        assert result2 == [0.0, 1.0, 0.0, 0.0]
    @pytest.mark.asyncio

    async def test_similarity_search(self, index):
        """Test similarity search (nearest neighbors)."""
        await index.create()
        # Insert vectors
        await index.insert("vec1", [1.0, 0.0, 0.0, 0.0])
        await index.insert("vec2", [0.9, 0.1, 0.0, 0.0])  # Similar to vec1
        await index.insert("vec3", [0.0, 0.0, 1.0, 0.0])  # Different
        # Search for nearest neighbors to [1.0, 0.0, 0.0, 0.0]
        results = []
        async for key, similarity in index.similarity_search([1.0, 0.0, 0.0, 0.0], k=2):
            results.append((key, similarity))
        # Should find vec1 and vec2 as nearest neighbors
        assert len(results) >= 2
        keys = [key for key, _ in results]
        assert "vec1" in keys or "vec2" in keys
    @pytest.mark.asyncio

    async def test_similarity_search_with_cosine(self, index):
        """Test similarity search using cosine similarity."""
        await index.create()
        await index.insert("vec1", [1.0, 0.0, 0.0, 0.0])
        await index.insert("vec2", [0.0, 1.0, 0.0, 0.0])
        # Search with cosine similarity
        results = []
        async for key, similarity in index.similarity_search(
            [1.0, 0.0, 0.0, 0.0],
            k=2,
            metric="cosine"
        ):
            results.append((key, similarity))
        assert len(results) >= 1
        # vec1 should have highest similarity (1.0)
        similarities = {key: sim for key, sim in results}
        assert similarities.get("vec1", 0) >= similarities.get("vec2", 0)
    @pytest.mark.asyncio

    async def test_delete_vector(self, index):
        """Test deleting a vector from index."""
        await index.create()
        await index.insert("vec1", [1.0, 0.0, 0.0, 0.0])
        result = await index.search("vec1")
        assert result == [1.0, 0.0, 0.0, 0.0]
        await index.delete("vec1")
        result = await index.search("vec1")
        assert result is None
    @pytest.mark.asyncio

    async def test_drop_index(self, index):
        """Test dropping a vector index."""
        await index.create()
        await index.insert("vec1", [1.0, 0.0, 0.0, 0.0])
        await index.drop()
        result = await index.search("vec1")
        assert result is None
    @pytest.mark.asyncio

    async def test_get_size(self, index):
        """Test getting index size."""
        await index.create()
        assert await index.size() == 0
        await index.insert("vec1", [1.0, 0.0, 0.0, 0.0])
        await index.insert("vec2", [0.0, 1.0, 0.0, 0.0])
        size = await index.size()
        assert size == 2
    @pytest.mark.asyncio

    async def test_invalid_dimension(self, index):
        """Test that inserting vector with wrong dimension raises error."""
        await index.create()
        # Try to insert vector with wrong dimension
        with pytest.raises(ValueError, match="dimension"):
            await index.insert("vec1", [1.0, 0.0])  # dimension=2, expected=4
