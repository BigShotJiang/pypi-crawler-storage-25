#!/usr/bin/env python3
"""
Connector Test Registry
Tracks all xwstorage connectors and their test coverage status.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 2025-01-XX
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional
from pathlib import Path


class ConnectorCategory(Enum):
    """Connector categories."""
    SQL = "SQL"
    NOSQL = "NoSQL"
    GRAPH = "Graph"
    VECTOR = "Vector"
    TIME_SERIES = "Time-Series"
    SEARCH = "Search Engine"
    KEY_VALUE = "Key-Value"
    OBJECT_STORAGE = "Object Storage"
    STREAMING = "Streaming"
    OLAP = "OLAP"
    EMBEDDED = "Embedded"
    EMULATOR = "Emulator"
    BaaS = "BaaS"
    BLOCKCHAIN = "Blockchain"
    FILE_SYSTEM = "File System"
    CLOUD_SERVICE = "Cloud Service"
    ARCHIVE = "Archive"


class TestStatus(Enum):
    """Test coverage status."""
    NOT_TESTED = "not_tested"
    PARTIAL = "partial"
    COMPREHENSIVE = "comprehensive"
    INTEGRATION_ONLY = "integration_only"


class Priority(Enum):
    """Test implementation priority."""
    P1_CRITICAL = 1  # Production-critical connectors
    P2_COMMON = 2    # Commonly used connectors
    P3_SPECIALIZED = 3  # Specialized connectors
    P4_CLOUD = 4     # Cloud service connectors
@dataclass

class ConnectorInfo:
    """Information about a connector."""
    name: str
    module_name: str
    category: ConnectorCategory
    priority: Priority
    test_status: TestStatus
    test_file: Optional[str] = None
    config_class: Optional[str] = None
    connection_class: Optional[str] = None
    notes: Optional[str] = None
# All connectors with their metadata
CONNECTORS = [
    # SQL Connectors (Priority 1-2)
    ConnectorInfo("local", "local_connector", ConnectorCategory.SQL, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_local_connector.py"),
    ConnectorInfo("mysql", "mysql_connector", ConnectorCategory.SQL, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_mysql_connector.py"),
    ConnectorInfo("postgresql", "postgresql_connector", ConnectorCategory.SQL, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_postgresql_connector.py"),
    ConnectorInfo("sqlite", "sqlite_connector", ConnectorCategory.SQL, Priority.P2_COMMON, TestStatus.PARTIAL),
    ConnectorInfo("oracle", "oracle_connector", ConnectorCategory.SQL, Priority.P2_COMMON, TestStatus.COMPREHENSIVE, "test_oracle_connector.py"),
    ConnectorInfo("sqlserver", "sqlserver_connector", ConnectorCategory.SQL, Priority.P2_COMMON, TestStatus.PARTIAL, "test_sqlserver_connector.py"),
    ConnectorInfo("mariadb", "mariadb_connector", ConnectorCategory.SQL, Priority.P2_COMMON, TestStatus.PARTIAL, "test_mariadb_connector.py"),
    ConnectorInfo("cockroachdb", "cockroachdb_connector", ConnectorCategory.SQL, Priority.P2_COMMON, TestStatus.PARTIAL, "test_cockroachdb_connector.py"),
    ConnectorInfo("db2", "db2_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_db2_connector.py"),
    ConnectorInfo("yugabytedb", "yugabytedb_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_yugabytedb_connector.py"),
    ConnectorInfo("tidb", "tidb_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_tidb_connector.py"),
    ConnectorInfo("vitess", "vitess_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_vitess_connector.py"),
    ConnectorInfo("singlestore", "singlestore_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_singlestore_connector.py"),
    ConnectorInfo("risingwave", "risingwave_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_risingwave_connector.py"),
    ConnectorInfo("edgedb", "edgedb_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_edgedb_connector.py"),
    ConnectorInfo("dragonflydb", "dragonflydb_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_dragonflydb_connector.py"),
    ConnectorInfo("firebird", "firebird_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_firebird_connector.py"),
    ConnectorInfo("sap_hana", "sap_hana_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_sap_hana_connector.py"),
    ConnectorInfo("greenplum", "greenplum_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_greenplum_connector.py"),
    ConnectorInfo("sap_ase", "sap_ase_connector", ConnectorCategory.SQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_sap_ase_connector.py"),
    ConnectorInfo("h2", "h2_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_h2_connector.py"),
    ConnectorInfo("rqlite", "rqlite_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_rqlite_connector.py"),
    # NoSQL Connectors
    ConnectorInfo("mongodb", "mongodb_connector", ConnectorCategory.NOSQL, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_mongodb_connector.py"),
    ConnectorInfo("dynamodb", "dynamodb_connector", ConnectorCategory.NOSQL, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_dynamodb_connector.py"),
    ConnectorInfo("cassandra", "cassandra_connector", ConnectorCategory.NOSQL, Priority.P2_COMMON, TestStatus.PARTIAL, "test_cassandra_connector.py"),
    ConnectorInfo("couchdb", "couchdb_connector", ConnectorCategory.NOSQL, Priority.P2_COMMON, TestStatus.PARTIAL, "test_couchdb_connector.py"),
    ConnectorInfo("couchbase", "couchbase_connector", ConnectorCategory.NOSQL, Priority.P2_COMMON, TestStatus.PARTIAL, "test_couchbase_connector.py"),
    ConnectorInfo("ravendb", "ravendb_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_ravendb_connector.py"),
    ConnectorInfo("rethinkdb", "rethinkdb_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_rethinkdb_connector.py"),
    ConnectorInfo("marklogic", "marklogic_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_marklogic_connector.py"),
    ConnectorInfo("hbase", "hbase_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_hbase_connector.py"),
    ConnectorInfo("memcached", "memcached_connector", ConnectorCategory.KEY_VALUE, Priority.P2_COMMON, TestStatus.PARTIAL, "test_memcached_connector.py"),
    ConnectorInfo("scylladb", "scylladb_connector", ConnectorCategory.NOSQL, Priority.P2_COMMON, TestStatus.PARTIAL, "test_scylladb_connector.py"),
    ConnectorInfo("riak", "riak_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_riak_connector.py"),
    ConnectorInfo("aerospike", "aerospike_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_aerospike_connector.py"),
    ConnectorInfo("documentdb", "documentdb_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_documentdb_connector.py"),
    ConnectorInfo("ferretdb", "ferretdb_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_ferretdb_connector.py"),
    ConnectorInfo("cratedb", "cratedb_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_cratedb_connector.py"),
    ConnectorInfo("surrealdb", "surrealdb_connector", ConnectorCategory.NOSQL, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_surrealdb_connector.py"),
    # Graph Connectors
    ConnectorInfo("neo4j", "neo4j_connector", ConnectorCategory.GRAPH, Priority.P2_COMMON, TestStatus.PARTIAL, "test_neo4j_connector.py"),
    ConnectorInfo("arangodb", "arangodb_connector", ConnectorCategory.GRAPH, Priority.P2_COMMON, TestStatus.PARTIAL, "test_arangodb_connector.py"),
    ConnectorInfo("neptune", "neptune_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_neptune_connector.py"),
    ConnectorInfo("dgraph", "dgraph_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_dgraph_connector.py"),
    ConnectorInfo("janusgraph", "janusgraph_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_janusgraph_connector.py"),
    ConnectorInfo("tigergraph", "tigergraph_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_tigergraph_connector.py"),
    ConnectorInfo("nebula", "nebula_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_nebula_connector.py"),
    ConnectorInfo("orientdb", "orientdb_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_orientdb_connector.py"),
    ConnectorInfo("memgraph", "memgraph_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_memgraph_connector.py"),
    ConnectorInfo("hugegraph", "hugegraph_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_hugegraph_connector.py"),
    ConnectorInfo("redisgraph", "redisgraph_connector", ConnectorCategory.GRAPH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_redisgraph_connector.py"),
    # Vector Connectors
    ConnectorInfo("milvus", "milvus_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_milvus_connector.py"),
    ConnectorInfo("weaviate", "weaviate_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_weaviate_connector.py"),
    ConnectorInfo("qdrant", "qdrant_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_qdrant_connector.py"),
    ConnectorInfo("chroma", "chroma_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_chroma_connector.py"),
    ConnectorInfo("lancedb", "lancedb_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_lancedb_connector.py"),
    ConnectorInfo("vespa", "vespa_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_vespa_connector.py"),
    ConnectorInfo("marqo", "marqo_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_marqo_connector.py"),
    ConnectorInfo("pinecone", "pinecone_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_pinecone_connector.py"),
    ConnectorInfo("pgvector", "pgvector_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_pgvector_connector.py"),
    ConnectorInfo("vald", "vald_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_vald_connector.py"),
    ConnectorInfo("faiss", "faiss_connector", ConnectorCategory.VECTOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_faiss_connector.py"),
    # Time-Series Connectors
    ConnectorInfo("influxdb", "influxdb_connector", ConnectorCategory.TIME_SERIES, Priority.P2_COMMON, TestStatus.PARTIAL, "test_influxdb_connector.py"),
    ConnectorInfo("prometheus", "prometheus_connector", ConnectorCategory.TIME_SERIES, Priority.P2_COMMON, TestStatus.PARTIAL, "test_prometheus_connector.py"),
    ConnectorInfo("timescaledb", "timescaledb_connector", ConnectorCategory.TIME_SERIES, Priority.P2_COMMON, TestStatus.PARTIAL, "test_timescaledb_connector.py"),
    ConnectorInfo("victoriametrics", "victoriametrics_connector", ConnectorCategory.TIME_SERIES, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_victoriametrics_connector.py"),
    ConnectorInfo("opentsdb", "opentsdb_connector", ConnectorCategory.TIME_SERIES, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_opentsdb_connector.py"),
    ConnectorInfo("questdb", "questdb_connector", ConnectorCategory.TIME_SERIES, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_questdb_connector.py"),
    ConnectorInfo("tdengine", "tdengine_connector", ConnectorCategory.TIME_SERIES, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_tdengine_connector.py"),
    ConnectorInfo("greptimedb", "greptimedb_connector", ConnectorCategory.TIME_SERIES, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_greptimedb_connector.py"),
    ConnectorInfo("warp10", "warp10_connector", ConnectorCategory.TIME_SERIES, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_warp10_connector.py"),
    ConnectorInfo("heroic", "heroic_connector", ConnectorCategory.TIME_SERIES, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_heroic_connector.py"),
    # Search Engine Connectors
    ConnectorInfo("elasticsearch", "elasticsearch_connector", ConnectorCategory.SEARCH, Priority.P2_COMMON, TestStatus.PARTIAL, "test_elasticsearch_connector.py"),
    ConnectorInfo("opensearch", "opensearch_connector", ConnectorCategory.SEARCH, Priority.P2_COMMON, TestStatus.PARTIAL, "test_opensearch_connector.py"),
    ConnectorInfo("meilisearch", "meilisearch_connector", ConnectorCategory.SEARCH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_meilisearch_connector.py"),
    ConnectorInfo("typesense", "typesense_connector", ConnectorCategory.SEARCH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_typesense_connector.py"),
    ConnectorInfo("solr", "solr_connector", ConnectorCategory.SEARCH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_solr_connector.py"),
    ConnectorInfo("zincsearch", "zincsearch_connector", ConnectorCategory.SEARCH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_zincsearch_connector.py"),
    ConnectorInfo("manticore", "manticore_connector", ConnectorCategory.SEARCH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_manticore_connector.py"),
    ConnectorInfo("quickwit", "quickwit_connector", ConnectorCategory.SEARCH, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_quickwit_connector.py"),
    # Key-Value Connectors
    ConnectorInfo("redis", "redis_connector", ConnectorCategory.KEY_VALUE, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_redis_connector.py"),
    ConnectorInfo("etcd", "etcd_connector", ConnectorCategory.KEY_VALUE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_etcd_connector.py"),
    ConnectorInfo("consul", "consul_connector", ConnectorCategory.KEY_VALUE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_consul_connector.py"),
    ConnectorInfo("hazelcast", "hazelcast_connector", ConnectorCategory.KEY_VALUE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_hazelcast_connector.py"),
    ConnectorInfo("ignite", "ignite_connector", ConnectorCategory.KEY_VALUE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_ignite_connector.py"),
    ConnectorInfo("badgerdb", "badgerdb_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_badgerdb_connector.py"),
    ConnectorInfo("rocksdb", "rocksdb_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_rocksdb_connector.py"),
    ConnectorInfo("voldemort", "voldemort_connector", ConnectorCategory.KEY_VALUE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_voldemort_connector.py"),
    ConnectorInfo("foundationdb", "foundationdb_connector", ConnectorCategory.KEY_VALUE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_foundationdb_connector.py"),
    ConnectorInfo("keydb", "keydb_connector", ConnectorCategory.KEY_VALUE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_keydb_connector.py"),
    # Object Storage Connectors
    ConnectorInfo("s3", "s3_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_s3_connector.py"),
    ConnectorInfo("azure_blob", "azure_blob_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_azure_blob_connector.py"),
    ConnectorInfo("gcs", "gcs_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P1_CRITICAL, TestStatus.COMPREHENSIVE, "test_gcs_connector.py"),
    ConnectorInfo("minio", "minio_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P2_COMMON, TestStatus.PARTIAL, "test_minio_connector.py"),
    ConnectorInfo("cloudflare_r2", "cloudflare_r2_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P2_COMMON, TestStatus.PARTIAL, "test_cloudflare_r2_connector.py"),
    ConnectorInfo("digitalocean_spaces", "digitalocean_spaces_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_digitalocean_spaces_connector.py"),
    ConnectorInfo("backblaze_b2", "backblaze_b2_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_backblaze_b2_connector.py"),
    ConnectorInfo("wasabi", "wasabi_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_wasabi_connector.py"),
    ConnectorInfo("linode_object_storage", "linode_object_storage_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_linode_object_storage_connector.py"),
    ConnectorInfo("scaleway_object_storage", "scaleway_object_storage_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_scaleway_object_storage_connector.py"),
    ConnectorInfo("ceph", "ceph_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_ceph_connector.py"),
    ConnectorInfo("seaweedfs", "seaweedfs_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_seaweedfs_connector.py"),
    ConnectorInfo("juicefs", "juicefs_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_juicefs_connector.py"),
    ConnectorInfo("longhorn", "longhorn_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_longhorn_connector.py"),
    ConnectorInfo("openio", "openio_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_openio_connector.py"),
    ConnectorInfo("garage", "garage_connector", ConnectorCategory.OBJECT_STORAGE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_garage_connector.py"),
    # Streaming Connectors
    ConnectorInfo("kafka", "kafka_connector", ConnectorCategory.STREAMING, Priority.P2_COMMON, TestStatus.PARTIAL, "test_kafka_connector.py"),
    ConnectorInfo("rabbitmq", "rabbitmq_connector", ConnectorCategory.STREAMING, Priority.P2_COMMON, TestStatus.PARTIAL, "test_rabbitmq_connector.py"),
    ConnectorInfo("nats", "nats_connector", ConnectorCategory.STREAMING, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_nats_connector.py"),
    ConnectorInfo("redpanda", "redpanda_connector", ConnectorCategory.STREAMING, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_redpanda_connector.py"),
    ConnectorInfo("pulsar", "pulsar_connector", ConnectorCategory.STREAMING, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_pulsar_connector.py"),
    ConnectorInfo("emqx", "emqx_connector", ConnectorCategory.STREAMING, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_emqx_connector.py"),
    ConnectorInfo("mosquitto", "mosquitto_connector", ConnectorCategory.STREAMING, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_mosquitto_connector.py"),
    ConnectorInfo("activemq", "activemq_connector", ConnectorCategory.STREAMING, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_activemq_connector.py"),
    ConnectorInfo("artemis", "artemis_connector", ConnectorCategory.STREAMING, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_artemis_connector.py"),
    # OLAP Connectors
    ConnectorInfo("clickhouse", "clickhouse_connector", ConnectorCategory.OLAP, Priority.P2_COMMON, TestStatus.PARTIAL, "test_clickhouse_connector.py"),
    ConnectorInfo("duckdb", "duckdb_connector", ConnectorCategory.OLAP, Priority.P2_COMMON, TestStatus.PARTIAL, "test_duckdb_connector.py"),
    ConnectorInfo("druid", "druid_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_druid_connector.py"),
    ConnectorInfo("pinot", "pinot_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_pinot_connector.py"),
    ConnectorInfo("trino", "trino_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_trino_connector.py"),
    ConnectorInfo("starrocks", "starrocks_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_starrocks_connector.py"),
    ConnectorInfo("prestodb", "prestodb_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_prestodb_connector.py"),
    ConnectorInfo("apache_doris", "apache_doris_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_apache_doris_connector.py"),
    ConnectorInfo("delta_lake", "delta_lake_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_delta_lake_connector.py"),
    ConnectorInfo("apache_kylin", "apache_kylin_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_apache_kylin_connector.py"),
    ConnectorInfo("apache_iceberg", "apache_iceberg_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_apache_iceberg_connector.py"),
    ConnectorInfo("apache_hudi", "apache_hudi_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_apache_hudi_connector.py"),
    ConnectorInfo("exasol", "exasol_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_exasol_connector.py"),
    ConnectorInfo("monetdb", "monetdb_connector", ConnectorCategory.OLAP, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_monetdb_connector.py"),
    # Embedded Connectors
    ConnectorInfo("lmdb", "lmdb_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_lmdb_connector.py"),
    ConnectorInfo("leveldb", "leveldb_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_leveldb_connector.py"),
    ConnectorInfo("bbolt", "bbolt_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_bbolt_connector.py"),
    ConnectorInfo("apache_derby", "apache_derby_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_apache_derby_connector.py"),
    ConnectorInfo("berkeley_db", "berkeley_db_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_berkeley_db_connector.py"),
    ConnectorInfo("realm", "realm_connector", ConnectorCategory.EMBEDDED, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_realm_connector.py"),
    # Emulator Connectors
    ConnectorInfo("localstack", "localstack_connector", ConnectorCategory.EMULATOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_localstack_connector.py"),
    ConnectorInfo("azurite", "azurite_connector", ConnectorCategory.EMULATOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_azurite_connector.py"),
    ConnectorInfo("cosmosdb_emulator", "cosmosdb_emulator_connector", ConnectorCategory.EMULATOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_cosmosdb_emulator_connector.py"),
    ConnectorInfo("dynamodb_local", "dynamodb_local_connector", ConnectorCategory.EMULATOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_dynamodb_local_connector.py"),
    ConnectorInfo("firebase_emulator", "firebase_emulator_connector", ConnectorCategory.EMULATOR, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_firebase_emulator_connector.py"),
    # BaaS Connectors
    ConnectorInfo("appwrite", "appwrite_connector", ConnectorCategory.BaaS, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_appwrite_connector.py"),
    ConnectorInfo("pocketbase", "pocketbase_connector", ConnectorCategory.BaaS, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_pocketbase_connector.py"),
    ConnectorInfo("hasura", "hasura_connector", ConnectorCategory.BaaS, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_hasura_connector.py"),
    ConnectorInfo("supabase", "supabase_connector", ConnectorCategory.BaaS, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_supabase_connector.py"),
    ConnectorInfo("parse_server", "parse_server_connector", ConnectorCategory.BaaS, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_parse_server_connector.py"),
    # Blockchain Connectors
    ConnectorInfo("hyperledger_fabric", "hyperledger_fabric_connector", ConnectorCategory.BLOCKCHAIN, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_hyperledger_fabric_connector.py"),
    ConnectorInfo("ganache", "ganache_connector", ConnectorCategory.BLOCKCHAIN, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_ganache_connector.py"),
    ConnectorInfo("bigchaindb", "bigchaindb_connector", ConnectorCategory.BLOCKCHAIN, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_bigchaindb_connector.py"),
    ConnectorInfo("hyperledger_sawtooth", "hyperledger_sawtooth_connector", ConnectorCategory.BLOCKCHAIN, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_hyperledger_sawtooth_connector.py"),
    # File System Connectors
    ConnectorInfo("glusterfs", "glusterfs_connector", ConnectorCategory.FILE_SYSTEM, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_glusterfs_connector.py"),
    ConnectorInfo("moosefs", "moosefs_connector", ConnectorCategory.FILE_SYSTEM, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_moosefs_connector.py"),
    # Archive Connectors
    ConnectorInfo("tar", "tar_connector", ConnectorCategory.ARCHIVE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_tar_connector.py"),
    ConnectorInfo("zip", "zip_connector", ConnectorCategory.ARCHIVE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_zip_connector.py"),
    ConnectorInfo("ron", "ron_connector", ConnectorCategory.ARCHIVE, Priority.P3_SPECIALIZED, TestStatus.PARTIAL, "test_ron_connector.py"),
    # Cloud Service Connectors (Priority 4)
    ConnectorInfo("dropbox", "dropbox_connector_strategy", ConnectorCategory.CLOUD_SERVICE, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_dropbox_connector_strategy.py"),
    ConnectorInfo("onedrive", "onedrive_connector_strategy", ConnectorCategory.CLOUD_SERVICE, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_onedrive_connector_strategy.py"),
    ConnectorInfo("box", "box_connector_strategy", ConnectorCategory.CLOUD_SERVICE, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_box_connector_strategy.py"),
    ConnectorInfo("google_sheets", "google_sheets_connector_strategy", ConnectorCategory.CLOUD_SERVICE, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_google_sheets_connector_strategy.py"),
    ConnectorInfo("microsoft_sheets", "microsoft_sheets_connector_strategy", ConnectorCategory.CLOUD_SERVICE, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_microsoft_sheets_connector_strategy.py"),
    ConnectorInfo("google_drive", "google_drive_connector_strategy", ConnectorCategory.CLOUD_SERVICE, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_google_drive_connector_strategy.py"),
    ConnectorInfo("sharepoint", "sharepoint_connector_strategy", ConnectorCategory.CLOUD_SERVICE, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_sharepoint_connector_strategy.py"),
    ConnectorInfo("excel", "excel_connector_strategy", ConnectorCategory.CLOUD_SERVICE, Priority.P4_CLOUD, TestStatus.PARTIAL, "test_excel_connector_strategy.py"),
]


def get_connectors_by_priority(priority: Priority) -> list[ConnectorInfo]:
    """Get connectors by priority."""
    return [c for c in CONNECTORS if c.priority == priority]


def get_connectors_by_category(category: ConnectorCategory) -> list[ConnectorInfo]:
    """Get connectors by category."""
    return [c for c in CONNECTORS if c.category == category]


def get_connectors_by_status(status: TestStatus) -> list[ConnectorInfo]:
    """Get connectors by test status."""
    return [c for c in CONNECTORS if c.test_status == status]


def get_test_coverage_stats() -> dict:
    """Get test coverage statistics."""
    total = len(CONNECTORS)
    comprehensive = len(get_connectors_by_status(TestStatus.COMPREHENSIVE))
    partial = len(get_connectors_by_status(TestStatus.PARTIAL))
    integration_only = len(get_connectors_by_status(TestStatus.INTEGRATION_ONLY))
    not_tested = len(get_connectors_by_status(TestStatus.NOT_TESTED))
    return {
        "total": total,
        "comprehensive": comprehensive,
        "partial": partial,
        "integration_only": integration_only,
        "not_tested": not_tested,
        "coverage_percentage": ((comprehensive + partial) / total * 100) if total > 0 else 0
    }


def generate_test_file_name(connector: ConnectorInfo) -> str:
    """Generate test file name for a connector."""
    if "_strategy" in connector.module_name:
        return f"test_{connector.module_name}.py"
    return f"test_{connector.module_name.replace('_connector', '_connector')}.py"
if __name__ == "__main__":
    """Print test coverage report."""
    stats = get_test_coverage_stats()
    print("=" * 80)
    print("XWStorage Connector Test Coverage Report")
    print("=" * 80)
    print(f"\nTotal Connectors: {stats['total']}")
    print(f"Comprehensive Tests: {stats['comprehensive']}")
    print(f"Partial Tests: {stats['partial']}")
    print(f"Integration Only: {stats['integration_only']}")
    print(f"Not Tested: {stats['not_tested']}")
    print(f"Coverage: {stats['coverage_percentage']:.1f}%")
    print("\n" + "=" * 80)
    print("Priority 1 (Critical) - Not Tested:")
    print("=" * 80)
    for conn in get_connectors_by_priority(Priority.P1_CRITICAL):
        if conn.test_status == TestStatus.NOT_TESTED:
            print(f"  - {conn.name:30s} ({conn.category.value})")
    print("\n" + "=" * 80)
    print("Priority 2 (Common) - Not Tested:")
    print("=" * 80)
    for conn in get_connectors_by_priority(Priority.P2_COMMON):
        if conn.test_status == TestStatus.NOT_TESTED:
            print(f"  - {conn.name:30s} ({conn.category.value})")
    print("\n" + "=" * 80)
    print("All Connectors Needing Tests:")
    print("=" * 80)
    for conn in sorted(get_connectors_by_status(TestStatus.NOT_TESTED), key=lambda x: (x.priority.value, x.name)):
        test_file = generate_test_file_name(conn)
        print(f"  {conn.priority.value}. {conn.name:30s} -> {test_file}")
