# New Connectors Tests Summary

**Date:** January 27, 2025  
**Company:** eXonware.com  
**Author:** eXonware Backend Team

## Overview

Comprehensive test suite created for all 12 newly implemented connectors. Tests include both unit tests (with mocks) and integration tests (with Docker support).

## Test Files Created

### Unit Tests (`tests/1.unit/connectors_tests/`)

1. **test_linode_object_storage_connector.py** - Tests for Linode Object Storage connector
2. **test_scaleway_object_storage_connector.py** - Tests for Scaleway Object Storage connector
3. **test_documentdb_connector.py** - Tests for Amazon DocumentDB connector
4. **test_scylladb_connector.py** - Tests for ScyllaDB connector
5. **test_riak_connector.py** - Tests for Riak connector
6. **test_aerospike_connector.py** - Tests for Aerospike connector
7. **test_rocksdb_connector.py** - Tests for RocksDB/LevelDB connector
8. **test_orientdb_connector.py** - Tests for OrientDB connector
9. **test_dropbox_connector_strategy.py** - Tests for Dropbox connector
10. **test_onedrive_connector_strategy.py** - Tests for OneDrive connector
11. **test_box_connector_strategy.py** - Tests for Box connector
12. **test_microsoft_sheets_connector_strategy.py** - Tests for Microsoft Sheets connector

### Integration Tests (`tests/2.integration/scenarios/`)

1. **test_new_connectors_integration.py** - Integration tests for all new connectors
2. **test_new_connectors_docker.py** - Docker-based integration tests

### Test Infrastructure

- **conftest.py** (`tests/1.unit/connectors_tests/`) - Mock fixtures for external dependencies
- **docker-compose.test.yml** (`tests/2.integration/resources/`) - Docker Compose configuration for test services
- **README.md** (`tests/2.integration/resources/`) - Documentation for running integration tests

## Test Coverage

### Unit Tests

Each connector has unit tests covering:
- ✅ Config initialization and validation
- ✅ Config to_dict conversion
- ✅ Connection initialization
- ✅ Error handling (missing packages, invalid config types)
- ✅ Dependency checking (graceful handling when packages not installed)

### Integration Tests

Integration tests cover:
- ✅ Docker service availability checking
- ✅ Real service connectivity (when Docker services available)
- ✅ Credential handling (with environment variables)
- ✅ Skip behavior when services/credentials not available

## Running Tests

### Unit Tests

```bash
# Run all new connector unit tests
pytest tests/1.unit/connectors_tests/test_linode_object_storage_connector.py -v
pytest tests/1.unit/connectors_tests/test_scaleway_object_storage_connector.py -v
pytest tests/1.unit/connectors_tests/test_documentdb_connector.py -v
pytest tests/1.unit/connectors_tests/test_scylladb_connector.py -v
pytest tests/1.unit/connectors_tests/test_riak_connector.py -v
pytest tests/1.unit/connectors_tests/test_aerospike_connector.py -v
pytest tests/1.unit/connectors_tests/test_rocksdb_connector.py -v
pytest tests/1.unit/connectors_tests/test_orientdb_connector.py -v
pytest tests/1.unit/connectors_tests/test_dropbox_connector_strategy.py -v
pytest tests/1.unit/connectors_tests/test_onedrive_connector_strategy.py -v
pytest tests/1.unit/connectors_tests/test_box_connector_strategy.py -v
pytest tests/1.unit/connectors_tests/test_microsoft_sheets_connector_strategy.py -v

# Run all new connector tests
pytest tests/1.unit/connectors_tests/ -k "linode or scaleway or documentdb or scylladb or riak or aerospike or rocksdb or orientdb or dropbox or onedrive or box or microsoft_sheets" -v

# Run by marker
pytest tests/1.unit/connectors_tests/ -m "xwstorage_linode or xwstorage_scaleway or xwstorage_documentdb" -v
```

### Integration Tests

```bash
# Start Docker services first
docker-compose -f tests/2.integration/resources/docker-compose.test.yml up -d

# Run integration tests
pytest tests/2.integration/scenarios/test_new_connectors_integration.py -v

# Run Docker-based tests
export DOCKER_AVAILABLE=true
pytest tests/2.integration/scenarios/test_new_connectors_docker.py -v -m docker

# Stop Docker services
docker-compose -f tests/2.integration/resources/docker-compose.test.yml down
```

## Docker Services

The docker-compose.test.yml file includes:
- **MongoDB** (port 27017) - For DocumentDB compatibility testing
- **Cassandra** (port 9042) - For ScyllaDB compatibility testing  
- **Riak** (ports 8087/8098) - For Riak connector testing
- **Aerospike** (port 3000) - For Aerospike connector testing
- **OrientDB** (ports 2424/2480) - For OrientDB connector testing
- **MinIO** (ports 9000/9001) - S3-compatible storage for Linode/Scaleway testing

## Environment Variables for Testing

Some connectors require credentials (for real service testing):

```bash
export DROPBOX_ACCESS_TOKEN="your_token"
export ONEDRIVE_ACCESS_TOKEN="your_token"
export BOX_ACCESS_TOKEN="your_token"
export DOCKER_AVAILABLE=true  # If using Docker services
```

## Test Markers

All tests use appropriate pytest markers:
- `@pytest.mark.xwstorage_unit` - Unit tests
- `@pytest.mark.xwstorage_integration` - Integration tests
- `@pytest.mark.xwstorage_connector` - Connector tests
- `@pytest.mark.docker` - Tests requiring Docker
- Connector-specific markers: `xwstorage_linode`, `xwstorage_scaleway`, etc.

## Mock Fixtures

The `conftest.py` provides mock fixtures for:
- `mock_boto3_client` - For S3-compatible connectors
- `mock_dropbox_client` - For Dropbox connector
- `mock_box_client` - For Box connector
- `mock_msal_app` - For Microsoft connectors
- `mock_riak_client` - For Riak connector
- `mock_aerospike_client` - For Aerospike connector
- `mock_rocksdb` - For RocksDB connector
- `mock_orientdb_client` - For OrientDB connector
- `mock_mongodb_client` - For MongoDB/DocumentDB connectors
- `mock_cassandra_session` - For Cassandra/ScyllaDB connectors

## Notes

- All tests gracefully handle missing dependencies (skip or mock)
- Integration tests automatically skip if Docker services are not available
- Tests follow existing xwstorage test patterns and conventions
- All tests include proper error handling and validation
- Mock fixtures ensure unit tests run fast without external dependencies

