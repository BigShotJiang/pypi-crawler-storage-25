#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/2.integration/connector_experiments_tests/test_mysql_connectors_abcd.py
Integration tests for experimental MySQL connector X.
These tests require a running MySQL instance. Connection parameters are
read from environment variables:
    XWSTORAGE_TEST_MYSQL_HOST (default: localhost)
    XWSTORAGE_TEST_MYSQL_PORT (default: 3306)
    XWSTORAGE_TEST_MYSQL_DATABASE (default: testdb)
    XWSTORAGE_TEST_MYSQL_USERNAME (default: root)
    XWSTORAGE_TEST_MYSQL_PASSWORD (default: password)
The underlying connector creates the target table automatically.
"""

from __future__ import annotations
import asyncio
import os
from typing import Any, Callable
import pytest
# Experimental connector X - use pytest.importorskip to handle missing module
pytest.importorskip(
    "exonware.xwstorage.connectors.connector_x",
    reason="Experimental connector X not implemented"
)
from exonware.xwstorage.connectors.connector_x import (
    MySQLXConnectorConfig,
    MySQLXStorageConnection,
)


def _mysql_params() -> dict[str, Any]:
    return {
        "host": os.getenv("XWSTORAGE_TEST_MYSQL_HOST", "localhost"),
        "port": int(os.getenv("XWSTORAGE_TEST_MYSQL_PORT", "3306")),
        "database": os.getenv("XWSTORAGE_TEST_MYSQL_DATABASE", "testdb"),
        "username": os.getenv("XWSTORAGE_TEST_MYSQL_USERNAME", "root"),
        "password": os.getenv("XWSTORAGE_TEST_MYSQL_PASSWORD", "password"),
    }


def _make_mysql_x(codec_id: str) -> Any:
    params = _mysql_params()
    cfg = MySQLXConnectorConfig(
        address="xwstorage_test_table_x",
        **params,
    )
    return MySQLXStorageConnection(cfg, codec_id)
@pytest.mark.xwstorage_integration
@pytest.mark.parametrize(
    "factory,codec_id",
    [
        pytest.param(_make_mysql_x, "json", id="X-json"),
    ],
)


def test_mysql_connector_x_basic_roundtrip(
    factory: Callable[[str], Any], codec_id: str
) -> None:
    """
    Basic roundtrip test for experimental MySQL connector X.
    This validates that the connector can persist and retrieve
    JSON-encoded payloads using a MySQL instance.
    """
    async def _run() -> None:
        conn = factory(codec_id)
        payload = {
            "id": "mysql-item-1",
            "name": "MySQL Test Item",
            "value": 123,
            "active": True,
        }
        path = "mysql/test_item_1"
        # Save
        await conn.save(payload, path)
        assert await conn.exists(path) is True
        # Load
        loaded = await conn.load(path)
        assert loaded == payload
        # Delete
        await conn.delete(path)
        assert await conn.exists(path) is False
    asyncio.run(_run())
