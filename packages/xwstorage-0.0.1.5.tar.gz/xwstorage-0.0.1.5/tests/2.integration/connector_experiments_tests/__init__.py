#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/2.integration/connector_experiments_tests/__init__.py
Integration tests for experimental connector options (A/B/C/D).
These tests focus on MySQL-backed connectors and require a running
MySQL instance (for example, provided via Docker).
"""

from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)
