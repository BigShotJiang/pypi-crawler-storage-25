﻿#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/2.integration/test_transaction_integration_complete.py
Transaction integration tests (skipped when transaction subsystem is not present in workspace).
"""
import pytest

pytest.skip(
    "Transaction integration tests require exonware.xwstorage.transactions.* modules in the workspace.",
    allow_module_level=True,
)
