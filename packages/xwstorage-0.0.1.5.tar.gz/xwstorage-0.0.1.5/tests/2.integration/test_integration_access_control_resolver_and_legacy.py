#!/usr/bin/env python3
"""
Integration regression coverage for resolver vs legacy access-control paths.
"""

from __future__ import annotations

import asyncio

import pytest

from exonware.xwstorage import AccessControlManager


class _LegacyOnlyProvider:
    async def validate_token(self, token: str):
        if token != "legacy-token":
            return None
        return {"scopes": ["storage:read"]}


@pytest.mark.xwstorage_integration
def test_strict_context_only_denies_legacy_validate_token_provider() -> None:
    manager = AccessControlManager(
        _LegacyOnlyProvider(),
        allow_local_fallback=True,
        strict_context_only=True,
    )
    allowed = asyncio.run(manager.check_access("legacy-token", "bucket:data", "read"))
    assert allowed is False


@pytest.mark.xwstorage_integration
def test_non_strict_allows_legacy_validate_token_provider() -> None:
    manager = AccessControlManager(
        _LegacyOnlyProvider(),
        allow_local_fallback=True,
        strict_context_only=False,
    )
    allowed = asyncio.run(manager.check_access("legacy-token", "bucket:data", "read"))
    assert allowed is True
