"""
Integration tests for xwstorage - Cross-module scenario tests.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""
