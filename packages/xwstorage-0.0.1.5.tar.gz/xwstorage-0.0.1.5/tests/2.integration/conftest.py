"""
Integration test fixtures.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import shutil
import tempfile
from pathlib import Path

import pytest
import pytest_asyncio

try:
    from exonware.xwstorage.connectors.local_connector import (
        LocalConnectorConfig,
        LocalStorageConnection,
    )
except ModuleNotFoundError:  # optional / incomplete checkout
    LocalConnectorConfig = None  # type: ignore[assignment,misc]
    LocalStorageConnection = None  # type: ignore[assignment,misc]


@pytest.fixture
def integration_temp_dir():
    """Create a temporary directory for integration tests."""
    temp_path = Path(tempfile.mkdtemp(prefix="xwstorage_integration_"))
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest_asyncio.fixture
async def integration_local_connection(integration_temp_dir):
    """Create local storage connection for integration tests."""
    if LocalConnectorConfig is None or LocalStorageConnection is None:
        pytest.skip("exonware.xwstorage.connectors.local_connector not available")
    config = LocalConnectorConfig(
        address=str(integration_temp_dir / "integration_storage.json"),
        security=True,
    )
    connection = LocalStorageConnection(config, "json")
    yield connection
