#!/usr/bin/env python3
"""
Integration regression for strict context-only storage authorization delegation.
"""

from __future__ import annotations

import asyncio

import pytest

from exonware.xwauth import XWAuth
from exonware.xwauth.config.config import DEFAULT_TEST_CLIENTS, XWAuthConfig
from exonware.xwstorage import AccessControlManager


@pytest.mark.xwstorage_integration
def test_strict_storage_mode_delegates_to_xwauth_policy() -> None:
    auth = XWAuth(
        config=XWAuthConfig(
            jwt_secret="strict-delegation-secret",
            registered_clients=DEFAULT_TEST_CLIENTS,
        )
    )
    token = asyncio.run(
        auth._token_manager.generate_access_token(  # noqa: SLF001 - integration path
            user_id="user-123",
            client_id="test_client",
            scopes=["openid"],
            additional_claims={"roles": ["admin"], "tenant_id": "tenant-1"},
        )
    )
    manager = AccessControlManager(
        auth,
        allow_local_fallback=False,
        strict_context_only=True,
    )

    allowed = asyncio.run(manager.check_access(token, "bucket:data", "read"))
    denied = asyncio.run(manager.check_access("not-a-token", "bucket:data", "read"))

    assert allowed is True
    assert denied is False


@pytest.mark.xwstorage_integration
def test_strict_storage_mode_accepts_tid_claim_via_resolver_normalization() -> None:
    auth = XWAuth(
        config=XWAuthConfig(
            jwt_secret="strict-delegation-secret",
            registered_clients=DEFAULT_TEST_CLIENTS,
        )
    )
    token = asyncio.run(
        auth._token_manager.generate_access_token(  # noqa: SLF001 - integration path
            user_id="user-123",
            client_id="test_client",
            scopes=["openid"],
            additional_claims={"roles": ["admin"], "tid": "tenant-via-tid"},
        )
    )
    manager = AccessControlManager(
        auth,
        allow_local_fallback=False,
        strict_context_only=True,
    )
    allowed = asyncio.run(manager.check_access(token, "bucket:data", "read"))
    assert allowed is True
