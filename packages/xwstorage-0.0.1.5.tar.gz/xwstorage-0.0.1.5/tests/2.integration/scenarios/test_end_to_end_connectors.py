#!/usr/bin/env python3
"""
End-to-end integration tests for connectors.
Tests real-world scenarios with multiple operations.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
pytest.importorskip(
    "exonware.xwstorage.connectors.local_connector",
    reason="local connector not available in workspace",
)
from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig, LocalStorageConnection
from exonware.xwstorage.errors import XWLocationError
@pytest.mark.xwstorage_integration
@pytest.mark.xwstorage_connector

class TestEndToEndConnectorScenarios:
    """End-to-end integration tests for connector scenarios."""
    @pytest.mark.asyncio

    async def test_complete_crud_workflow(self, integration_local_connection):
        """
        Test complete CRUD workflow - Create, Read, Update, Delete.
        This tests the full lifecycle of data operations.
        """
        path = "workflow_test"
        initial_data = {"id": "1", "name": "Initial", "value": 10}
        # Create
        await integration_local_connection.save(initial_data, path)
        assert await integration_local_connection.exists(path) is True
        # Read
        loaded = await integration_local_connection.load(path)
        assert loaded == initial_data
        # Update
        updated_data = {"id": "1", "name": "Updated", "value": 20}
        await integration_local_connection.save(updated_data, path)
        loaded = await integration_local_connection.load(path)
        assert loaded == updated_data
        assert loaded["value"] == 20
        # Delete
        await integration_local_connection.delete(path)
        assert await integration_local_connection.exists(path) is False
    @pytest.mark.asyncio

    async def test_multiple_paths_management(self, integration_temp_dir):
        """Test managing multiple storage paths simultaneously."""
        # Use directory-based config to support multiple paths
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig, LocalStorageConnection
        # Create directory-based connection for multiple paths
        dir_config = LocalConnectorConfig(
            address=str(integration_temp_dir / "multi_path_storage"),
            security=False
        )
        connection = LocalStorageConnection(dir_config, "json")
        paths_data = {
            "users": [{"id": "u1", "name": "User 1"}],
            "posts": [{"id": "p1", "title": "Post 1"}],
            "comments": [{"id": "c1", "text": "Comment 1"}]
        }
        # Save multiple paths
        for path, data in paths_data.items():
            await connection.save(data, path)
            assert await connection.exists(path) is True
        # Load and verify all paths
        for path, expected_data in paths_data.items():
            loaded = await connection.load(path)
            # Handle collection structure if present
            if isinstance(loaded, dict) and "entities" in loaded:
                loaded = loaded["entities"]
            assert loaded == expected_data
        # Delete all paths
        for path in paths_data.keys():
            await connection.delete(path)
            assert await connection.exists(path) is False
    @pytest.mark.asyncio

    async def test_collection_append_workflow(self, integration_local_connection):
        """Test workflow with collection append operations."""
        path = "collection_test"
        # Initial collection
        initial_items = [
            {"id": "item-1", "value": 10},
            {"id": "item-2", "value": 20}
        ]
        await integration_local_connection.save(initial_items, path)
        # Append more items
        new_items = [
            {"id": "item-3", "value": 30},
            {"id": "item-4", "value": 40}
        ]
        await integration_local_connection.save(new_items, path, append=True)
        # Verify all items are present
        loaded = await integration_local_connection.load(path)
        # Handle collection structure if present
        if isinstance(loaded, dict) and "entities" in loaded:
            items = loaded["entities"]
        else:
            items = loaded if isinstance(loaded, list) else []
        assert len(items) >= 4  # Should have at least 4 items
        # Verify specific items
        item_ids = [item["id"] for item in items]
        assert "item-1" in item_ids
        assert "item-3" in item_ids
    @pytest.mark.asyncio

    async def test_error_handling_scenarios(self, integration_local_connection):
        """Test error handling in various scenarios."""
        # Load nonexistent path
        with pytest.raises(XWLocationError, match="not found"):
            await integration_local_connection.load("nonexistent")
        # Delete nonexistent path (should not raise error)
        await integration_local_connection.delete("nonexistent")
        # Save and then load to verify normal flow still works
        await integration_local_connection.save({"test": "data"}, "error_test")
        loaded = await integration_local_connection.load("error_test")
        assert loaded == {"test": "data"}
    @pytest.mark.asyncio

    async def test_data_persistence_across_connections(self, integration_temp_dir):
        """Test that data persists across different connection instances."""
        path = "persistence_test"
        test_data = {"id": "persist-1", "data": "persistent"}
        # Save with first connection
        config1 = LocalConnectorConfig(
            address=str(integration_temp_dir / "persist.json"),
            security=False
        )
        conn1 = LocalStorageConnection(config1, "json")
        await conn1.save(test_data, path)
        # Load with second connection (same storage)
        config2 = LocalConnectorConfig(
            address=str(integration_temp_dir / "persist.json"),
            security=False
        )
        conn2 = LocalStorageConnection(config2, "json")
        loaded = await conn2.load(path)
        assert loaded == test_data
    @pytest.mark.asyncio

    async def test_concurrent_operations(self, integration_temp_dir):
        """Test concurrent operations on same connection."""
        import asyncio
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig, LocalStorageConnection
        # Use directory-based connection for concurrent operations with different paths
        dir_config = LocalConnectorConfig(
            address=str(integration_temp_dir / "concurrent_storage"),
            security=False
        )
        connection = LocalStorageConnection(dir_config, "json")
        async def save_and_verify(item_id):
            path = f"concurrent_{item_id}"
            data = {"id": item_id, "value": item_id * 10}
            await connection.save(data, path)
            loaded = await connection.load(path)
            assert loaded == data
            return item_id
        # Run multiple operations concurrently
        results = await asyncio.gather(*[save_and_verify(i) for i in range(5)])
        assert len(results) == 5
        # Verify all were saved
        for i in range(5):
            exists = await connection.exists(f"concurrent_{i}")
            assert exists is True
