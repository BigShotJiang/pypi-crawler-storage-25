#!/usr/bin/env python3
"""
Docker-based integration tests for newly implemented connectors.
Requires Docker Compose services to be running.
Start with: docker-compose -f tests/2.integration/resources/docker-compose.test.yml up -d
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
import asyncio
import os
from typing import Optional


def check_docker_service(service_name: str, port: int) -> bool:
    """Check if Docker service is available."""
    try:
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex(('localhost', port))
        sock.close()
        return result == 0
    except Exception:
        return False
@pytest.fixture(scope="session")

def docker_services_available():
    """Check if Docker services are available."""
    services = {
        'mongodb': 27017,
        'cassandra': 9042,
        'riak_pb': 8087,
        'riak_http': 8098,
        'aerospike': 3000,
        'orientdb_binary': 2424,
        'orientdb_http': 2480,
        'minio': 9000,
        'sqlserver': 1434,  # Test container uses port 1434 to avoid conflict
    }
    available = {}
    for name, port in services.items():
        available[name] = check_docker_service(name, port)
    return available
@pytest.mark.xwstorage_integration
@pytest.mark.xwstorage_connector
@pytest.mark.docker

class TestDocumentDBWithMongoDB:
    """Integration tests for DocumentDB connector using MongoDB."""
    @pytest.mark.asyncio

    async def test_documentdb_basic_operations(self, docker_services_available):
        """Test basic DocumentDB operations with MongoDB."""
        if not docker_services_available.get('mongodb', False):
            pytest.skip("MongoDB service not available")
        try:
            from exonware.xwstorage.connectors.documentdb_connector import (
                DocumentDBConnectorConfig,
                DocumentDBStorageConnection
            )
        except ImportError:
            pytest.skip("DocumentDB connector not available")
        config = DocumentDBConnectorConfig(
            address="test_collection",
            host="localhost",
            port=27017,
            database="testdb",
            username="admin",
            password="password",
            tls_enabled=False  # MongoDB test doesn't require TLS
        )
        # Test connection initialization
        try:
            connection = DocumentDBStorageConnection(config, "json")
            # Connection should be initialized (actual connect happens on first operation)
            assert connection._config == config
        except Exception as e:
            # If MongoDB packages not installed, that's expected
            if "not installed" in str(e).lower():
                pytest.skip(f"MongoDB packages not installed: {e}")
            raise
@pytest.mark.xwstorage_integration
@pytest.mark.xwstorage_connector
@pytest.mark.docker

class TestScyllaDBWithCassandra:
    """Integration tests for ScyllaDB connector using Cassandra."""
    @pytest.mark.asyncio

    async def test_scylladb_basic_operations(self, docker_services_available):
        """Test basic ScyllaDB operations with Cassandra."""
        if not docker_services_available.get('cassandra', False):
            pytest.skip("Cassandra service not available")
        try:
            from exonware.xwstorage.connectors.scylladb_connector import (
                ScyllaDBConnectorConfig,
                ScyllaDBStorageConnection
            )
        except ImportError:
            pytest.skip("ScyllaDB connector not available")
        config = ScyllaDBConnectorConfig(
            keyspace="test_keyspace",
            table="test_table",
            hosts=["localhost"],
            port=9042
        )
        try:
            connection = ScyllaDBStorageConnection(config, "json")
            assert connection._config == config
        except Exception as e:
            if "not installed" in str(e).lower():
                pytest.skip(f"Cassandra packages not installed: {e}")
            raise
@pytest.mark.xwstorage_integration
@pytest.mark.xwstorage_connector
@pytest.mark.docker

class TestRiakConnector:
    """Integration tests for Riak connector."""
    @pytest.mark.asyncio

    async def test_riak_http_interface(self, docker_services_available):
        """Test Riak connector via HTTP interface."""
        if not docker_services_available.get('riak_http', False):
            pytest.skip("Riak HTTP service not available")
        try:
            from exonware.xwstorage.connectors.riak_connector import (
                RiakConnectorConfig,
                RiakStorageConnection
            )
        except ImportError:
            pytest.skip("Riak connector not available")
        config = RiakConnectorConfig(
            address="localhost:8098",
            bucket="test_bucket",
            protocol="http"
        )
        try:
            connection = RiakStorageConnection(config, "json")
            assert connection._config == config
        except Exception as e:
            if "not installed" in str(e).lower():
                pytest.skip(f"Riak packages not installed: {e}")
            raise
@pytest.mark.xwstorage_integration
@pytest.mark.xwstorage_connector
@pytest.mark.docker

class TestAerospikeConnector:
    """Integration tests for Aerospike connector."""
    @pytest.mark.asyncio

    async def test_aerospike_basic_operations(self, docker_services_available):
        """Test basic Aerospike operations."""
        if not docker_services_available.get('aerospike', False):
            pytest.skip("Aerospike service not available")
        try:
            from exonware.xwstorage.connectors.aerospike_connector import (
                AerospikeConnectorConfig,
                AerospikeStorageConnection
            )
        except ImportError:
            pytest.skip("Aerospike connector not available")
        config = AerospikeConnectorConfig(
            address="localhost:3000",
            namespace="test"
        )
        try:
            connection = AerospikeStorageConnection(config, "json")
            assert connection._config == config
        except Exception as e:
            if "not installed" in str(e).lower():
                pytest.skip(f"Aerospike packages not installed: {e}")
            raise
@pytest.mark.xwstorage_integration
@pytest.mark.xwstorage_connector
@pytest.mark.docker

class TestOrientDBConnector:
    """Integration tests for OrientDB connector."""
    @pytest.mark.asyncio

    async def test_orientdb_basic_operations(self, docker_services_available):
        """Test basic OrientDB operations."""
        if not docker_services_available.get('orientdb_http', False):
            pytest.skip("OrientDB HTTP service not available")
        try:
            from exonware.xwstorage.connectors.orientdb_connector import (
                OrientDBConnectorConfig,
                OrientDBStorageConnection
            )
        except ImportError:
            pytest.skip("OrientDB connector not available")
        config = OrientDBConnectorConfig(
            address="test_class",
            host="localhost",
            port=2424,
            database="testdb",
            username="root",
            password="root",
            db_type="document"
        )
        try:
            connection = OrientDBStorageConnection(config, "json")
            assert connection._config == config
        except Exception as e:
            if "not installed" in str(e).lower():
                pytest.skip(f"OrientDB packages not installed: {e}")
            raise
@pytest.mark.xwstorage_integration
@pytest.mark.xwstorage_connector
@pytest.mark.docker

class TestS3CompatibleWithMinIO:
    """Integration tests for S3-compatible connectors using MinIO."""
    @pytest.mark.asyncio

    async def test_linode_with_minio(self, docker_services_available):
        """Test Linode Object Storage connector with MinIO."""
        if not docker_services_available.get('minio', False):
            pytest.skip("MinIO service not available")
        try:
            from exonware.xwstorage.connectors.linode_object_storage_connector import (
                LinodeObjectStorageConnectorConfig,
                LinodeObjectStorageConnection
            )
        except ImportError:
            pytest.skip("Linode connector not available")
        config = LinodeObjectStorageConnectorConfig(
            bucket="test-bucket",
            region="us-east-1",
            access_key_id="minioadmin",
            secret_access_key="minioadmin",
            endpoint_url="http://localhost:9000"
        )
        try:
            connection = LinodeObjectStorageConnection(config, "json")
            assert connection._config == config
        except Exception as e:
            if "not installed" in str(e).lower() or "boto3" in str(e).lower():
                pytest.skip(f"S3/boto3 packages not installed: {e}")
            raise
@pytest.mark.xwstorage_integration
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_sqlserver
@pytest.mark.docker

class TestSQLServerConnector:
    """Integration tests for SQL Server connector."""
    @pytest.mark.asyncio

    async def test_sqlserver_basic_operations(self, docker_services_available):
        """Test basic SQL Server operations."""
        if not docker_services_available.get('sqlserver', False):
            pytest.skip("SQL Server service not available")
        try:
            from exonware.xwstorage.connectors.sqlserver_connector import (
                SQLServerConnectorConfig,
                SQLServerStorageConnection
            )
        except ImportError:
            pytest.skip("SQL Server connector not available")
        config = SQLServerConnectorConfig(
            address="test_storage",
            host="localhost",
            port=1434,  # Test container uses port 1434
            database="testdb",
            username="sa",
            password="TestPassword123!"
        )
        try:
            connection = SQLServerStorageConnection(config, "json")
            assert connection._config == config
            # Test basic operations if connection works
            test_data = {"test": "data", "value": 123}
            test_path = "test/path"
            # Save data
            await connection.save(test_data, test_path)
            # Check exists
            exists = await connection.exists(test_path)
            assert exists is True
            # Load data
            loaded = await connection.load(test_path)
            assert loaded == test_data
            # Delete data
            await connection.delete(test_path)
            exists_after = await connection.exists(test_path)
            assert exists_after is False
        except Exception as e:
            if "not installed" in str(e).lower():
                pytest.skip(f"SQL Server packages (pyodbc/pymssql) not installed: {e}")
            raise
