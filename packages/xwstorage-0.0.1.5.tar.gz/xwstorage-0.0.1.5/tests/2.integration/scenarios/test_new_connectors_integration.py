﻿#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/2.integration/scenarios/test_new_connectors_integration.py
New connector integration scenarios (skipped when connector implementations are not present).
"""
import pytest

pytest.skip(
    "New connector integration scenarios require connector modules under exonware.xwstorage.connectors.",
    allow_module_level=True,
)
