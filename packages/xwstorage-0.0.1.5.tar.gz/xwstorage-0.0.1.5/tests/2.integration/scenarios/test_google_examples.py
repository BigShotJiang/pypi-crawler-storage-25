﻿#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/2.integration/scenarios/test_google_examples.py
Google Drive/Sheets scenario tests (skipped when connector implementations are not present).
"""
import pytest

pytest.skip(
    "Google connector scenario tests require GoogleDrive/GoogleSheets connectors in the workspace.",
    allow_module_level=True,
)
