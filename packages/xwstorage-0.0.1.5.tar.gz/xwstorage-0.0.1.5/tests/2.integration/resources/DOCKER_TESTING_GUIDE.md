# Docker Testing Guide for xwstorage Integration Tests

**Company:** eXonware.com  
**Author:** eXonware Backend Team  
**Email:** connect@exonware.com  
**Version:** 0.0.1  
**Date:** January 27, 2025

---

## Overview

This guide explains how to run integration tests that require Docker services. The xwstorage library includes Docker Compose configuration to spin up various database services for testing connectors.

---

## Quick Start

### 1. Start Docker Services

```bash
# From the xwstorage root directory
docker-compose -f tests/2.integration/resources/docker-compose.test.yml up -d

# Wait for services to be healthy (check status)
docker-compose -f tests/2.integration/resources/docker-compose.test.yml ps
```

### 2. Run Integration Tests

```bash
# Run all integration tests
python tests/2.integration/runner.py

# Or use pytest directly
pytest tests/2.integration/ -m xwstorage_integration -v

# Run only Docker-based tests
pytest tests/2.integration/ -m docker -v
```

### 3. Stop Docker Services

```bash
# Stop services (keeps data volumes)
docker-compose -f tests/2.integration/resources/docker-compose.test.yml stop

# Stop and remove containers (keeps data volumes)
docker-compose -f tests/2.integration/resources/docker-compose.test.yml down

# Stop and remove everything including volumes
docker-compose -f tests/2.integration/resources/docker-compose.test.yml down -v
```

---

## Available Services

The Docker Compose file includes the following services:

| Service | Port(s) | Purpose | Connector |
|---------|---------|---------|-----------|
| **MongoDB** | 27017 | DocumentDB compatibility testing | `DocumentDBConnector` |
| **Cassandra** | 9042 | ScyllaDB compatibility testing | `ScyllaDBConnector` |
| **Riak** | 8087 (PB), 8098 (HTTP) | Riak connector testing | `RiakConnector` |
| **Aerospike** | 3000 | Aerospike connector testing | `AerospikeConnector` |
| **OrientDB** | 2424 (Binary), 2480 (HTTP) | OrientDB connector testing | `OrientDBConnector` |
| **MinIO** | 9000 (API), 9001 (Console) | S3-compatible storage testing | `LinodeObjectStorage`, `ScalewayObjectStorage` |

---

## Service Credentials

### MongoDB
- **Host:** `localhost`
- **Port:** `27017`
- **Username:** `admin`
- **Password:** `password`
- **Database:** `testdb`

### Cassandra
- **Host:** `localhost`
- **Port:** `9042`
- **Cluster Name:** `TestCluster`
- **Keyspace:** `test_keyspace` (auto-created)

### Riak
- **Protocol Buffers:** `localhost:8087`
- **HTTP:** `http://localhost:8098`
- **No authentication required** (test environment)

### Aerospike
- **Host:** `localhost`
- **Port:** `3000`
- **Namespace:** `test` (default)
- **No authentication required** (test environment)

### OrientDB
- **Binary:** `localhost:2424`
- **HTTP:** `http://localhost:2480`
- **Root Password:** `root`
- **Database:** `testdb`

### MinIO (S3-Compatible)
- **Endpoint:** `http://localhost:9000`
- **Access Key:** `minioadmin`
- **Secret Key:** `minioadmin`
- **Console:** `http://localhost:9001`

---

## Health Checks

All services include health checks. Verify services are ready:

```bash
# Check service status
docker-compose -f tests/2.integration/resources/docker-compose.test.yml ps

# View logs for a specific service
docker-compose -f tests/2.integration/resources/docker-compose.test.yml logs mongodb
docker-compose -f tests/2.integration/resources/docker-compose.test.yml logs cassandra

# View all logs
docker-compose -f tests/2.integration/resources/docker-compose.test.yml logs -f
```

---

## Running Specific Tests

### Test Specific Connectors

```bash
# DocumentDB tests (requires MongoDB)
pytest tests/2.integration/scenarios/test_new_connectors_docker.py::TestDocumentDBWithMongoDB -v

# ScyllaDB tests (requires Cassandra)
pytest tests/2.integration/scenarios/test_new_connectors_docker.py::TestScyllaDBWithCassandra -v

# S3-compatible tests (requires MinIO)
pytest tests/2.integration/scenarios/test_new_connectors_docker.py::TestS3CompatibleStorage -v
```

### Skip Docker Tests

Tests automatically skip if Docker services are not available. If you want to explicitly skip:

```bash
# Run integration tests without Docker marker
pytest tests/2.integration/ -m "xwstorage_integration and not docker" -v
```

---

## Troubleshooting

### Services Not Starting

1. **Check Docker is running:**
   ```bash
   docker ps
   ```

2. **Check ports are available:**
   ```bash
   # Linux/Mac
   lsof -i :27017
   
   # Windows
   netstat -ano | findstr :27017
   ```

3. **View service logs:**
   ```bash
   docker-compose -f tests/2.integration/resources/docker-compose.test.yml logs <service-name>
   ```

### Connection Timeouts

1. **Ensure services are healthy:**
   ```bash
   docker-compose -f tests/2.integration/resources/docker-compose.test.yml ps
   ```
   All services should show "healthy" status.

2. **Check firewall settings** - Docker services bind to localhost, firewall should allow local connections.

3. **Increase startup time** - Some services (like Cassandra) take longer to start. Wait 30-60 seconds after `docker-compose up`.

### Data Persistence

Data volumes persist between runs. To start fresh:

```bash
# Remove all volumes and containers
docker-compose -f tests/2.integration/resources/docker-compose.test.yml down -v

# Start fresh
docker-compose -f tests/2.integration/resources/docker-compose.test.yml up -d
```

### Service-Specific Issues

#### MongoDB
- **Issue:** Authentication failed
- **Solution:** Ensure using credentials: `admin`/`password`

#### Cassandra
- **Issue:** Connection timeout
- **Solution:** Wait 60+ seconds for cluster initialization

#### Riak
- **Issue:** Service not responding
- **Solution:** Check both Protocol Buffers (8087) and HTTP (8098) ports

#### Aerospike
- **Issue:** Namespace not found
- **Solution:** Namespace `test` is default, no setup needed

#### OrientDB
- **Issue:** Database connection failed
- **Solution:** Use root password `root`, create database via HTTP API first

#### MinIO
- **Issue:** Bucket access denied
- **Solution:** Create bucket via console (http://localhost:9001) or API first

---

## CI/CD Integration

For CI/CD pipelines, services should be started before running tests:

```yaml
# Example GitHub Actions
- name: Start Docker services
  run: |
    docker-compose -f tests/2.integration/resources/docker-compose.test.yml up -d
    # Wait for services to be healthy
    docker-compose -f tests/2.integration/resources/docker-compose.test.yml ps

- name: Run integration tests
  run: pytest tests/2.integration/ -m "xwstorage_integration" -v

- name: Stop Docker services
  run: docker-compose -f tests/2.integration/resources/docker-compose.test.yml down
```

---

## Performance Considerations

- **Startup Time:** Services take 30-120 seconds to become healthy
- **Resource Usage:** All services combined use ~2-4GB RAM
- **Network:** Services communicate over Docker bridge network
- **Volumes:** Data persists in Docker volumes (named volumes)

---

## Best Practices

1. **Start services before running tests** - Don't rely on tests to start services
2. **Check health status** - Verify services are healthy before running tests
3. **Clean up after tests** - Stop services when done to free resources
4. **Use environment variables** - Tests should read connection details from environment
5. **Parallel test execution** - Services support concurrent test execution
6. **Volume management** - Use `-v` flag to clean volumes between test runs

---

## Additional Resources

- **Docker Compose File:** `tests/2.integration/resources/docker-compose.test.yml`
- **Integration Test Files:** `tests/2.integration/scenarios/`
- **Test Runner:** `tests/2.integration/runner.py`
- **Main Test Runner:** `tests/runner.py`

---

## Support

For issues or questions:
- Check test logs for specific error messages
- Verify Docker services are healthy
- Review service-specific documentation
- Contact: connect@exonware.com

