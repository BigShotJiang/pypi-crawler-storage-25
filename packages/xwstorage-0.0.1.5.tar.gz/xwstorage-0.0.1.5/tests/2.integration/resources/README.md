# Integration Test Resources

This directory contains resources for integration testing of connectors.

## Docker Compose Setup

To run integration tests with real services, start the Docker Compose services:

```bash
# Start all services
docker-compose -f tests/2.integration/resources/docker-compose.test.yml up -d

# Check service status
docker-compose -f tests/2.integration/resources/docker-compose.test.yml ps

# View logs
docker-compose -f tests/2.integration/resources/docker-compose.test.yml logs -f

# Stop all services
docker-compose -f tests/2.integration/resources/docker-compose.test.yml down

# Stop and remove volumes
docker-compose -f tests/2.integration/resources/docker-compose.test.yml down -v
```

## Services

- **MongoDB** (port 27017) - For DocumentDB compatibility testing
- **Cassandra** (port 9042) - For ScyllaDB compatibility testing
- **Riak** (ports 8087/8098) - For Riak connector testing
- **Aerospike** (port 3000) - For Aerospike connector testing
- **OrientDB** (ports 2424/2480) - For OrientDB connector testing
- **MinIO** (ports 9000/9001) - S3-compatible storage for Linode/Scaleway testing

## Running Integration Tests

```bash
# Run all integration tests
pytest tests/2.integration/ -m xwstorage_integration

# Run Docker-based tests only
pytest tests/2.integration/ -m docker

# Run tests for specific connector
pytest tests/2.integration/scenarios/test_new_connectors_docker.py::TestDocumentDBWithMongoDB

# Set environment variable to indicate Docker is available
export DOCKER_AVAILABLE=true
pytest tests/2.integration/scenarios/test_new_connectors_docker.py
```

## Credentials for Testing

Some connectors require credentials:

- **Dropbox**: Set `DROPBOX_ACCESS_TOKEN` environment variable
- **OneDrive**: Set `ONEDRIVE_ACCESS_TOKEN` environment variable
- **Box**: Set `BOX_ACCESS_TOKEN` environment variable
- **MinIO**: Uses default `minioadmin`/`minioadmin` for testing

## Notes

- Integration tests will skip if Docker services are not available
- Tests are designed to work with or without Docker (using mocks when services unavailable)
- Some tests require actual credentials for cloud services (Dropbox, OneDrive, Box)

