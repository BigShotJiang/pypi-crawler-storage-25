#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/3.advance/test_performance.py
Comprehensive performance benchmarks for xwstorage.
Priority #4: Performance Excellence
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1
Generation Date: 07-Jan-2025
"""

import pytest
import time
import asyncio
from pathlib import Path
from exonware.xwstorage.facade import XWConnection
from exonware.xwstorage.registry import get_connector_registry
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_performance

class TestConnectorPerformance:
    """Performance tests for storage connectors."""
    @pytest.mark.asyncio

    async def test_local_connector_write_performance(self, tmp_path):
        """Test local connector write performance."""
        storage_path = tmp_path / "test_storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Test write performance with 1000 items
        data = [{"id": i, "value": f"data_{i}" * 10} for i in range(1000)]
        start = time.time()
        await connection.write("test_collection", data)
        elapsed = time.time() - start
        # 1000 items should write in < 1 second
        assert elapsed < 1.0, f"Write too slow: {elapsed:.3f}s for 1000 items"
    @pytest.mark.asyncio

    async def test_local_connector_read_performance(self, tmp_path):
        """Test local connector read performance."""
        storage_path = tmp_path / "test_storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Pre-populate with data
        data = [{"id": i, "value": f"data_{i}"} for i in range(1000)]
        await connection.write("test_collection", data)
        # Test read performance
        start = time.time()
        result = await connection.read("test_collection")
        elapsed = time.time() - start
        # 1000 items should read in < 0.5 seconds
        assert elapsed < 0.5, f"Read too slow: {elapsed:.3f}s for 1000 items"
        assert len(result) == 1000
    @pytest.mark.asyncio

    async def test_local_connector_query_performance(self, tmp_path):
        """Test local connector query performance."""
        storage_path = tmp_path / "test_storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Pre-populate with data
        data = [{"id": i, "value": f"data_{i}", "category": f"cat_{i % 10}"} for i in range(1000)]
        await connection.write("test_collection", data)
        # Test query performance
        start = time.time()
        result = await connection.query("test_collection", {"category": "cat_5"})
        elapsed = time.time() - start
        # Query should complete in < 0.5 seconds
        assert elapsed < 0.5, f"Query too slow: {elapsed:.3f}s"
        assert len(result) == 100  # 1000 items / 10 categories = 100 per category
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_performance

class TestBatchOperationsPerformance:
    """Performance tests for batch operations."""
    @pytest.mark.asyncio

    async def test_batch_write_performance(self, tmp_path):
        """Test batch write performance."""
        storage_path = tmp_path / "test_storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Test batch write with 10000 items
        batch_data = [{"id": i, "value": f"data_{i}"} for i in range(10000)]
        start = time.time()
        await connection.write("test_collection", batch_data)
        elapsed = time.time() - start
        # 10000 items should write in < 5 seconds
        assert elapsed < 5.0, f"Batch write too slow: {elapsed:.3f}s for 10000 items"
    @pytest.mark.asyncio

    async def test_batch_read_performance(self, tmp_path):
        """Test batch read performance."""
        storage_path = tmp_path / "test_storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Pre-populate with large dataset
        batch_data = [{"id": i, "value": f"data_{i}"} for i in range(10000)]
        await connection.write("test_collection", batch_data)
        # Test batch read
        start = time.time()
        result = await connection.read("test_collection")
        elapsed = time.time() - start
        # 10000 items should read in < 2 seconds
        assert elapsed < 2.0, f"Batch read too slow: {elapsed:.3f}s for 10000 items"
        assert len(result) == 10000
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_performance

class TestTransactionPerformance:
    """Performance tests for transaction operations."""
    @pytest.mark.asyncio

    async def test_transaction_commit_performance(self, tmp_path):
        """Test transaction commit performance."""
        storage_path = tmp_path / "test_storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Start transaction
        async with connection.transaction() as tx:
            # Write multiple items in transaction
            for i in range(100):
                await tx.write("test_collection", {"id": i, "value": f"data_{i}"})
        # Transaction commit should complete in < 1 second
        # (Note: actual commit happens in __aexit__, so we measure the whole context)
        start = time.time()
        async with connection.transaction() as tx:
            for i in range(100):
                await tx.write("test_collection", {"id": i + 100, "value": f"data_{i + 100}"})
        elapsed = time.time() - start
        assert elapsed < 1.0, f"Transaction commit too slow: {elapsed:.3f}s"
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_performance

class TestConnectorRegistryPerformance:
    """Performance tests for connector registry."""

    def test_connector_registry_lookup_performance(self):
        """Test connector registry lookup performance."""
        registry = get_connector_registry()
        # Test registry lookup performance
        start = time.time()
        for _ in range(1000):
            connector = registry.get_connector("local")
            assert connector is not None
        elapsed = time.time() - start
        # 1000 lookups should complete in < 0.1 seconds
        assert elapsed < 0.1, f"Registry lookup too slow: {elapsed:.3f}s for 1000 lookups"
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_performance

class TestMemoryPerformance:
    """Performance tests for memory usage."""
    @pytest.mark.asyncio

    async def test_large_dataset_memory_efficiency(self, tmp_path):
        """Test memory efficiency with large datasets."""
        import sys
        storage_path = tmp_path / "test_storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Create large dataset
        large_data = [{"id": i, "value": "x" * 1000} for i in range(10000)]
        # Measure memory before
        import gc
        gc.collect()
        before_size = sys.getsizeof(large_data)
        # Write data
        await connection.write("test_collection", large_data)
        # Clear local reference
        del large_data
        gc.collect()
        # Read back (should not use excessive memory)
        result = await connection.read("test_collection")
        # Verify data integrity
        assert len(result) == 10000
        assert result[0]["id"] == 0
