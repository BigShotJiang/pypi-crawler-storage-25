#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/3.advance/conftest.py
Advance test fixtures and configuration.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

import pytest
import sys
from pathlib import Path
# Add src to Python path
test_dir = Path(__file__).parent
src_path = test_dir.parent.parent.parent / "src"
sys.path.insert(0, str(src_path))
