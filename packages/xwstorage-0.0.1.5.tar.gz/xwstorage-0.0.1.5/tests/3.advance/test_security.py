#!/usr/bin/env python3
"""
#exonware/xwstorage/tests/3.advance/test_security.py
Comprehensive security tests for xwstorage.
Priority #1: Security Excellence
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1
Generation Date: 07-Jan-2025
"""

import pytest
import tempfile
from pathlib import Path
from exonware.xwstorage.facade import XWConnection
from exonware.xwstorage.errors import XWConnectionError
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_security

class TestPathValidation:
    """Security tests for path validation."""
    @pytest.mark.asyncio

    async def test_path_traversal_protection(self, tmp_path):
        """Test protection against path traversal attacks."""
        storage_path = tmp_path / "storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Path traversal attempts should be blocked
        malicious_paths = [
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32",
            "/etc/passwd",
            "C:\\Windows\\System32",
        ]
        for malicious_path in malicious_paths:
            with pytest.raises((XWConnectionError, ValueError, OSError)):
                malicious_connection = XWConnection(
                    None,
                    {
                        "connector": "local",
                        "format": "json",
                        "address": malicious_path
                    }
                )
                await malicious_connection.write("test", {"key": "value"})
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_security

class TestInputValidation:
    """Security tests for input validation."""
    @pytest.mark.asyncio

    async def test_malicious_input_handling(self, tmp_path):
        """Test handling of malicious input."""
        storage_path = tmp_path / "storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Test various malicious inputs
        malicious_inputs = [
            {"key": "<script>alert('xss')</script>"},
            {"key": "'; DROP TABLE users; --"},
            {"key": "value" * 1000000},  # Very large value
        ]
        for malicious_input in malicious_inputs:
            # Should handle safely without executing code
            try:
                await connection.write("test_collection", [malicious_input])
                result = await connection.read("test_collection")
                # Should store as data, not execute
                assert isinstance(result, list)
            except Exception as e:
                # Exception is acceptable for extremely large inputs
                assert "too large" in str(e).lower() or "memory" in str(e).lower()
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_security

class TestAccessControl:
    """Security tests for access control."""
    @pytest.mark.asyncio

    async def test_connection_isolation(self, tmp_path):
        """Test that connections are isolated."""
        storage_path1 = tmp_path / "storage1.json"
        storage_path2 = tmp_path / "storage2.json"
        connection1 = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path1)
            }
        )
        connection2 = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path2)
            }
        )
        # Write to connection1
        await connection1.write("collection1", [{"id": 1, "data": "secret"}])
        # Connection2 should not see connection1's data
        result = await connection2.read("collection1")
        assert result == [] or result is None
@pytest.mark.xwstorage_advance
@pytest.mark.xwstorage_security

class TestDataIntegrity:
    """Security tests for data integrity."""
    @pytest.mark.asyncio

    async def test_data_corruption_protection(self, tmp_path):
        """Test protection against data corruption."""
        storage_path = tmp_path / "storage.json"
        connection = XWConnection(
            None,
            {
                "connector": "local",
                "format": "json",
                "address": str(storage_path)
            }
        )
        # Write data
        original_data = [{"id": i, "value": f"data_{i}"} for i in range(100)]
        await connection.write("test_collection", original_data)
        # Read back and verify integrity
        result = await connection.read("test_collection")
        assert result == original_data
        # Verify no corruption occurred
        assert len(result) == 100
        assert all(item["id"] == i for i, item in enumerate(result))
