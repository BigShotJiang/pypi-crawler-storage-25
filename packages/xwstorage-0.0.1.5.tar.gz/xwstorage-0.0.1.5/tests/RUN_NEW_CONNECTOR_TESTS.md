# Running Tests for New Connectors

## Quick Start

### Unit Tests (Recommended - Fast, No Dependencies)

```bash
# Run all new connector unit tests
pytest tests/1.unit/connectors_tests/ -k "linode or scaleway or documentdb or scylladb or riak or aerospike or rocksdb or orientdb or dropbox or onedrive or box or microsoft_sheets" -v

# Run specific connector tests
pytest tests/1.unit/connectors_tests/test_linode_object_storage_connector.py -v
pytest tests/1.unit/connectors_tests/test_documentdb_connector.py -v
pytest tests/1.unit/connectors_tests/test_dropbox_connector_strategy.py -v
```

### Integration Tests (Requires Docker)

```bash
# 1. Start Docker services
docker-compose -f tests/2.integration/resources/docker-compose.test.yml up -d

# 2. Wait for services to be ready (check logs)
docker-compose -f tests/2.integration/resources/docker-compose.test.yml ps

# 3. Run integration tests
export DOCKER_AVAILABLE=true
pytest tests/2.integration/scenarios/test_new_connectors_docker.py -v -m docker

# 4. Stop services when done
docker-compose -f tests/2.integration/resources/docker-compose.test.yml down
```

## Test Files Overview

### Unit Tests (12 files)

All unit tests use mocks and don't require external services:

- `test_linode_object_storage_connector.py`
- `test_scaleway_object_storage_connector.py`
- `test_documentdb_connector.py`
- `test_scylladb_connector.py`
- `test_riak_connector.py`
- `test_aerospike_connector.py`
- `test_rocksdb_connector.py`
- `test_orientdb_connector.py`
- `test_dropbox_connector_strategy.py`
- `test_onedrive_connector_strategy.py`
- `test_box_connector_strategy.py`
- `test_microsoft_sheets_connector_strategy.py`

### Integration Tests (2 files)

- `test_new_connectors_integration.py` - General integration tests
- `test_new_connectors_docker.py` - Docker-based tests

## Expected Behavior

### Unit Tests
- ✅ Should run quickly (milliseconds per test)
- ✅ Don't require external services
- ✅ Use mocks for all external dependencies
- ✅ Test configuration, initialization, and error handling

### Integration Tests
- ✅ Skip gracefully if Docker services not available
- ✅ Test real connectivity when services are running
- ✅ Require proper environment setup

## Troubleshooting

### If tests fail with import errors:
- Make sure you're running from the xwstorage directory
- Check that all connector files exist in `src/exonware/xwstorage/connectors/`
- Verify no syntax errors in connector files

### If Docker tests are skipped:
- Check that Docker is running
- Verify services are up: `docker-compose -f tests/2.integration/resources/docker-compose.test.yml ps`
- Set `DOCKER_AVAILABLE=true` environment variable

### For cloud service tests (Dropbox, OneDrive, Box):
- Set environment variables with access tokens:
  - `DROPBOX_ACCESS_TOKEN`
  - `ONEDRIVE_ACCESS_TOKEN`
  - `BOX_ACCESS_TOKEN`
- Tests will skip if tokens not provided

