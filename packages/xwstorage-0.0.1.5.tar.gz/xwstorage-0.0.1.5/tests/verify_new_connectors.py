#!/usr/bin/env python3
"""
Quick verification script for new connector implementations.
This script verifies that all new connectors can be imported and initialized.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import sys
from pathlib import Path
# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


def test_imports():
    """Test that all new connectors can be imported."""
    connectors = [
        # Object Storage
        ("LinodeObjectStorageConnectorConfig", "exonware.xwstorage.connectors.linode_object_storage_connector"),
        ("ScalewayObjectStorageConnectorConfig", "exonware.xwstorage.connectors.scaleway_object_storage_connector"),
        # Document Databases
        ("DocumentDBConnectorConfig", "exonware.xwstorage.connectors.documentdb_connector"),
        # Key-Value Stores
        ("ScyllaDBConnectorConfig", "exonware.xwstorage.connectors.scylladb_connector"),
        ("RiakConnectorConfig", "exonware.xwstorage.connectors.riak_connector"),
        ("AerospikeConnectorConfig", "exonware.xwstorage.connectors.aerospike_connector"),
        ("RocksDBConnectorConfig", "exonware.xwstorage.connectors.rocksdb_connector"),
        # Graph Databases
        ("OrientDBConnectorConfig", "exonware.xwstorage.connectors.orientdb_connector"),
        # File Storage
        ("DropboxConnector", "exonware.xwstorage.connectors.dropbox_connector_strategy"),
        ("OneDriveConnector", "exonware.xwstorage.connectors.onedrive_connector_strategy"),
        ("BoxConnector", "exonware.xwstorage.connectors.box_connector_strategy"),
        ("MicrosoftSheetsConnector", "exonware.xwstorage.connectors.microsoft_sheets_connector_strategy"),
    ]
    print("=" * 70)
    print("Verifying New Connector Imports")
    print("=" * 70)
    passed = 0
    failed = 0
    for class_name, module_path in connectors:
        try:
            module = __import__(module_path, fromlist=[class_name])
            cls = getattr(module, class_name)
            print(f"✅ {class_name:50s} - OK")
            passed += 1
        except ImportError as e:
            print(f"❌ {class_name:50s} - ImportError: {e}")
            failed += 1
        except AttributeError as e:
            print(f"❌ {class_name:50s} - AttributeError: {e}")
            failed += 1
        except Exception as e:
            print(f"❌ {class_name:50s} - Error: {e}")
            failed += 1
    print("=" * 70)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 70)
    return failed == 0


def test_config_initialization():
    """Test that config classes can be initialized."""
    print("\n" + "=" * 70)
    print("Verifying Config Initialization")
    print("=" * 70)
    tests = [
        ("LinodeObjectStorageConnectorConfig", {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "access_key_id": "test-key",
            "secret_access_key": "test-secret"
        }),
        ("ScalewayObjectStorageConnectorConfig", {
            "bucket": "test-bucket",
            "region": "fr-par",
            "access_key_id": "test-key",
            "secret_access_key": "test-secret"
        }),
        ("DocumentDBConnectorConfig", {
            "address": "test_collection",
            "host": "localhost",
            "database": "testdb"
        }),
        ("ScyllaDBConnectorConfig", {
            "keyspace": "test_keyspace",
            "table": "test_table",
            "hosts": ["localhost"]
        }),
        ("RiakConnectorConfig", {
            "address": "localhost:8087",
            "bucket": "test_bucket"
        }),
        ("AerospikeConnectorConfig", {
            "address": "localhost:3000",
            "namespace": "test"
        }),
        ("RocksDBConnectorConfig", {
            "path": "/tmp/testdb"
        }),
        ("OrientDBConnectorConfig", {
            "address": "test_class",
            "database": "testdb"
        }),
    ]
    passed = 0
    failed = 0
    for config_class_name, kwargs in tests:
        try:
            # Import the class
            module_map = {
                "LinodeObjectStorageConnectorConfig": "exonware.xwstorage.connectors.linode_object_storage_connector",
                "ScalewayObjectStorageConnectorConfig": "exonware.xwstorage.connectors.scaleway_object_storage_connector",
                "DocumentDBConnectorConfig": "exonware.xwstorage.connectors.documentdb_connector",
                "ScyllaDBConnectorConfig": "exonware.xwstorage.connectors.scylladb_connector",
                "RiakConnectorConfig": "exonware.xwstorage.connectors.riak_connector",
                "AerospikeConnectorConfig": "exonware.xwstorage.connectors.aerospike_connector",
                "RocksDBConnectorConfig": "exonware.xwstorage.connectors.rocksdb_connector",
                "OrientDBConnectorConfig": "exonware.xwstorage.connectors.orientdb_connector",
            }
            module = __import__(module_map[config_class_name], fromlist=[config_class_name])
            config_class = getattr(module, config_class_name)
            # Initialize config
            config = config_class(**kwargs)
            assert config.connector_type is not None
            print(f"✅ {config_class_name:50s} - OK")
            passed += 1
        except Exception as e:
            print(f"❌ {config_class_name:50s} - Error: {e}")
            failed += 1
    print("=" * 70)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 70)
    return failed == 0
if __name__ == "__main__":
    print("\n🔍 Verifying New Connector Implementations\n")
    import_ok = test_imports()
    config_ok = test_config_initialization()
    if import_ok and config_ok:
        print("\n✅ All connectors verified successfully!")
        sys.exit(0)
    else:
        print("\n❌ Some connectors failed verification")
        sys.exit(1)
