"""Minimal connector strategy classes for unit tests (Box, Dropbox, MSAL-based, etc.)."""

from __future__ import annotations

import sys
from pathlib import Path
from types import ModuleType
from typing import Any

from exonware.xwstorage.errors import XWStorageError


def install_strategy_module(module: ModuleType, suffix: str) -> None:
    """Populate a virtual ``*_connector_strategy`` module; ``suffix`` is e.g. ``box_connector_strategy``."""
    if suffix == "box_connector_strategy":
        try:
            from boxsdk import Client, OAuth2

            module.BOX_AVAILABLE = True
            module.Client = Client
            module.OAuth2 = OAuth2
        except ImportError:
            module.BOX_AVAILABLE = False
            module.Client = None
            module.OAuth2 = None

        class BoxConnector:
            connector_type = "box"

            def __init__(self, access_token: str | None = None, **kwargs: Any) -> None:
                _ = kwargs
                self.access_token = access_token
                self._connected = False
                self._client = None
                self._oauth = None

            async def connect(self) -> None:
                mod = sys.modules[module.__name__]
                if not self.access_token:
                    raise XWStorageError("Box authentication required")
                if not getattr(mod, "BOX_AVAILABLE", False) or mod.Client is None:
                    raise XWStorageError("boxsdk not available")
                auth = mod.OAuth2(None, None, access_token=self.access_token)
                self._oauth = auth
                self._client = mod.Client(auth)
                self._connected = True

            async def disconnect(self) -> None:
                self._client = None
                self._oauth = None
                self._connected = False

        module.BoxConnector = BoxConnector
        return

    if suffix == "dropbox_connector_strategy":
        try:
            import dropbox as _dropbox

            module.Dropbox = _dropbox.Dropbox
            module.DROPBOX_AVAILABLE = True
        except ImportError:
            module.Dropbox = None
            module.DROPBOX_AVAILABLE = False

        class DropboxConnector:
            connector_type = "dropbox"

            def __init__(self, access_token: str | None = None, **kwargs: Any) -> None:
                _ = kwargs
                self.access_token = access_token
                self._connected = False
                self._client = None

            async def connect(self) -> None:
                mod = sys.modules[module.__name__]
                if not getattr(mod, "DROPBOX_AVAILABLE", False) or mod.Dropbox is None:
                    raise XWStorageError("dropbox not available")
                if not self.access_token:
                    raise XWStorageError("Dropbox authentication required")
                import dropbox as _dbx

                self._client = _dbx.Dropbox(self.access_token)
                self._connected = True

            async def disconnect(self) -> None:
                self._client = None
                self._connected = False

            async def get_transport(self) -> Any:
                if not self._connected or self._client is None:
                    raise XWStorageError("Not connected")
                return self._client

        module.DropboxConnector = DropboxConnector
        return

    if suffix in ("onedrive_connector_strategy", "microsoft_sheets_connector_strategy"):
        try:
            from msal import ConfidentialClientApplication

            module.ConfidentialClientApplication = ConfidentialClientApplication
            module.MSAL_AVAILABLE = True
        except ImportError:
            module.ConfidentialClientApplication = None
            module.MSAL_AVAILABLE = False

        is_sheets = suffix == "microsoft_sheets_connector_strategy"

        class _MSALConnector:
            connector_type = "onedrive" if not is_sheets else "microsoft_sheets"

            def __init__(self, **kwargs: Any) -> None:
                self.access_token = kwargs.pop("access_token", None)
                self.client_id = kwargs.pop("client_id", None)
                self.client_secret = kwargs.pop("client_secret", None)
                self.tenant_id = kwargs.pop("tenant_id", None)
                self.spreadsheet_id = kwargs.pop("spreadsheet_id", None)
                self.drive_id = kwargs.pop("drive_id", "me/drive")
                for k, v in kwargs.items():
                    setattr(self, k, v)
                self._connected = False
                self._client = None
                self._app = None

            async def connect(self) -> None:
                mod = sys.modules[module.__name__]
                if not getattr(mod, "MSAL_AVAILABLE", False):
                    raise XWStorageError("msal not available")
                if is_sheets and not (
                    self.access_token or (self.client_id and self.client_secret and self.spreadsheet_id)
                ):
                    raise XWStorageError("Microsoft Sheets authentication required")
                if not is_sheets and not (
                    self.access_token or (self.client_id and self.client_secret and self.tenant_id)
                ):
                    raise XWStorageError("OneDrive authentication required")
                if self.access_token:
                    import requests

                    r = requests.get(
                        "https://graph.microsoft.com/v1.0/me",
                        headers={"Authorization": f"Bearer {self.access_token}"},
                        timeout=30,
                    )
                    if not r.ok:
                        pass
                    self._client = r
                    self._connected = True
                    return
                app = mod.ConfidentialClientApplication(
                    self.client_id,
                    authority=f"https://login.microsoftonline.com/{self.tenant_id or 'common'}",
                    client_credential=self.client_secret,
                )
                self._app = app
                tok = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
                self.access_token = (tok or {}).get("access_token", "test-token")
                self._client = object()
                self._connected = True

            async def disconnect(self) -> None:
                self._client = None
                self._app = None
                self._connected = False
                if is_sheets:
                    self.access_token = None

        if is_sheets:
            module.MicrosoftSheetsConnector = _MSALConnector
        else:
            module.OneDriveConnector = _MSALConnector
        return

    if suffix == "sharepoint_connector_strategy":

        class SharePointConnector:
            connector_type = "sharepoint"

            def __init__(self, **kwargs: Any) -> None:
                self.site_url = kwargs.pop("site_url", None)
                self.client_id = kwargs.pop("client_id", None)
                self.client_secret = kwargs.pop("client_secret", None)
                self.username = kwargs.pop("username", None)
                self.password = kwargs.pop("password", None)
                for k, v in kwargs.items():
                    setattr(self, k, v)

        module.SharePointConnector = SharePointConnector
        return

    if suffix == "google_drive_connector_strategy":

        class GoogleDriveConnector:
            connector_type = "google_drive"

            def __init__(self, folder_id: str | None = None, path: dict[str, Any] | None = None, **kwargs: Any) -> None:
                _ = kwargs
                if path and "folder_id" in path:
                    self.folder_id = path["folder_id"]
                else:
                    self.folder_id = folder_id

        module.GoogleDriveConnector = GoogleDriveConnector
        return

    if suffix == "google_sheets_connector_strategy":

        class GoogleSheetsConnector:
            connector_type = "google_sheets"

            def __init__(self, spreadsheet_id: str | None = None, path: dict[str, Any] | None = None, **kwargs: Any) -> None:
                _ = kwargs
                if path and "spreadsheet_id" in path:
                    self.spreadsheet_id = path["spreadsheet_id"]
                else:
                    self.spreadsheet_id = spreadsheet_id
                self.read_only = False

        module.GoogleSheetsConnector = GoogleSheetsConnector
        return

    if suffix == "excel_connector_strategy":

        class ExcelConnector:
            connector_type = "excel"

            def __init__(self, file_path: Path | str | None = None, **kwargs: Any) -> None:
                _ = kwargs
                self.file_path = Path(file_path) if file_path is not None else None

        module.ExcelConnector = ExcelConnector
        return

    raise RuntimeError(f"unsupported strategy module: {suffix}")
