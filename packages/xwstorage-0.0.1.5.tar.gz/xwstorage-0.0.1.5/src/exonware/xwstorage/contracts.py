#exonware/xwstorage/src/exonware/xwstorage/contracts.py
"""Connector contracts; implementation lives in ``exonware.xwstorage`` package root."""

from __future__ import annotations

from exonware.xwstorage import IConnectorConfig, IStorageConnection

__all__ = ["IConnectorConfig", "IStorageConnection"]
