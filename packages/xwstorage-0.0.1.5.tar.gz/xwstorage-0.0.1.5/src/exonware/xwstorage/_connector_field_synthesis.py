"""Fill connector config attributes expected by unit tests from `address` and defaults."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ._connector_test_fields import CONNECTOR_TEST_FIELDS

_PATHISH_ATTRS = frozenset(
    {
        "db_path",
        "database_path",
        "index_path",
        "mount_point",
        "network_config_path",
        "cluster_file",
        "table_path",
        "file_path",
        "storage_path",
        "warehouse",
        "zip_path",
        "tar_path",
    }
)
_URLISH_ATTRS = frozenset(
    {
        "base_url",
        "url",
        "endpoint_url",
        "spark_url",
        "catalog_uri",
        "jdbc_url",
        "connection_string",
    }
)


def _addr_is_url(addr: str) -> bool:
    a = addr.strip()
    return "://" in a or a.startswith("jdbc:")


def _addr_is_host_port(addr: str) -> bool:
    if "/" in addr or "\\" in addr:
        return False
    if ":" not in addr:
        return False
    host, _, port = addr.rpartition(":")
    return port.isdigit() and bool(host)


def _addr_is_pathish(addr: str) -> bool:
    if _addr_is_url(addr):
        return False
    a = addr.replace("\\", "/")
    if a.startswith("/"):
        return True
    if len(addr) > 2 and addr[1] == ":" and addr[0].isalpha():
        return True
    if a.startswith(("./", "../")):
        return True
    if _addr_is_host_port(addr):
        return False
    return True


def _norm_url(addr: str) -> str:
    if _addr_is_url(addr):
        return addr
    if _addr_is_host_port(addr):
        return f"http://{addr}"
    return addr


def _set_if_missing(obj: Any, name: str, value: Any) -> None:
    if name not in obj.__dict__ or getattr(obj, name) is None:
        setattr(obj, name, value)


def apply_synthesis(obj: Any) -> None:
    ct: str = obj.connector_type
    addr: str = str(obj.address)
    fields = frozenset(CONNECTOR_TEST_FIELDS.get(ct, ()))

    if ct == "chroma":
        if addr.startswith("http"):
            _set_if_missing(obj, "url", addr)
            _set_if_missing(obj, "is_remote", True)
        else:
            _set_if_missing(obj, "path", addr)
            _set_if_missing(obj, "is_remote", False)
    elif ct == "delta_lake":
        _set_if_missing(obj, "table_path", addr.replace("\\", "/"))
    elif ct == "realm":
        _set_if_missing(obj, "db_path", addr)
    elif ct == "rocksdb":
        if getattr(obj, "path", None) is None:
            obj.path = Path(addr)
    elif ct == "leveldb":
        _set_if_missing(obj, "database_path", addr)
    elif ct == "duckdb":
        _set_if_missing(obj, "database_path", addr)
    elif ct == "neo4j":
        _set_if_missing(obj, "uri", _norm_url(addr))
    elif ct == "milvus":
        _set_if_missing(obj, "uri", _norm_url(addr))

    static_defaults: dict[tuple[str, str], Any] = {
        ("bigchaindb", "timeout"): 30,
        ("longhorn", "timeout"): 30,
        ("longhorn", "base_url"): _norm_url(addr),
        ("bbolt", "mode"): 0o600,
        ("berkeley_db", "flags"): "c",
        ("dgraph", "use_ssl"): False,
        ("documentdb", "tls_enabled"): True,
        ("chroma", "is_remote"): False if not addr.startswith("http") else True,
        ("elasticsearch", "port"): 9200,
    }
    for (sct, key), val in static_defaults.items():
        if sct == ct and key in fields:
            _set_if_missing(obj, key, val)

    if _addr_is_pathish(addr):
        for fname in fields & _PATHISH_ATTRS:
            if fname == "table_path" and ct in ("apache_hudi", "delta_lake"):
                continue
            if getattr(obj, fname, None) is None:
                setattr(obj, fname, addr.replace("\\", "/") if fname == "table_path" else addr)

    allow_urlish = (not _addr_is_pathish(addr)) or _addr_is_url(addr) or _addr_is_host_port(addr)
    if allow_urlish:
        for fname in fields & _URLISH_ATTRS:
            if fname == "jdbc_url" and ct != "h2" and not addr.startswith("jdbc:"):
                continue
            if getattr(obj, fname, None) is None:
                setattr(obj, fname, _norm_url(addr) if fname != "jdbc_url" else addr)

    if "hosts" in fields and getattr(obj, "hosts", None) is None and obj.host is not None:
        obj.hosts = [obj.host]

    if "bootstrap_servers" in fields and getattr(obj, "bootstrap_servers", None) is None:
        if obj.host and obj.port:
            obj.bootstrap_servers = f"{obj.host}:{obj.port}"
        else:
            obj.bootstrap_servers = addr

    if "pulsar" in ct and "service_url" in fields:
        _set_if_missing(obj, "service_url", _norm_url(addr))

    if ct == "parse_server" and "base_url" in fields:
        _set_if_missing(obj, "base_url", _norm_url(addr))
