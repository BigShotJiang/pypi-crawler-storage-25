#exonware/xwstorage/src/exonware/xwstorage/_acid_document_connection.py
"""Document store with append-only WAL for durability; wraps an inner storage connection."""

from __future__ import annotations

import asyncio
from pathlib import Path

from exonware.xwsystem.io.serialization.formats.text import json as xw_json
from typing import Any


class ACIDDocumentConnection:
    """Wrap ``inner`` with a JSON-lines WAL at ``wal_path``; replay WAL before use."""

    def __init__(self, inner: Any, wal_path: str | Path) -> None:
        self._inner = inner
        self._wal_path = Path(wal_path)
        self._wal_io = asyncio.Lock()
        self._replayed = False

    async def _replay_wal(self) -> None:
        if not self._wal_path.is_file():
            return
        raw = self._wal_path.read_text(encoding="utf-8")
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            rec = xw_json.loads(line)
            if rec.get("op") == "save":
                await self._inner.save(rec["data"], rec["path"])

    async def _ensure_replay(self) -> None:
        if self._replayed:
            return
        async with self._wal_io:
            if self._replayed:
                return
            await self._replay_wal()
            self._replayed = True

    async def save(
        self,
        data: Any,
        path: str,
        append: bool = False,
        *,
        transaction_id: str | None = None,
        lock_manager: Any = None,
        **kwargs: Any,
    ) -> None:
        _ = kwargs
        await self._ensure_replay()
        if lock_manager is not None and transaction_id is not None:
            from exonware.xwstorage import LockMode

            ok = await lock_manager.acquire_lock(
                resource=path,
                lock_mode=LockMode.EXCLUSIVE,
                transaction_id=transaction_id,
            )
            if not ok:
                raise RuntimeError("Could not acquire lock")
        record = xw_json.dumps({"op": "save", "path": path, "data": data}, separators=(",", ":"))
        async with self._wal_io:
            self._wal_path.parent.mkdir(parents=True, exist_ok=True)
            with self._wal_path.open("a", encoding="utf-8") as fh:
                fh.write(record + "\n")
        if append:
            raise NotImplementedError("append not supported for this inner connection")
        await self._inner.save(data, path)

    async def load(self, path: str) -> Any:
        await self._ensure_replay()
        return await self._inner.load(path)

    async def exists(self, path: str) -> bool:
        await self._ensure_replay()
        return await self._inner.exists(path)

    async def delete(self, path: str) -> None:
        await self._ensure_replay()
        await self._inner.delete(path)
