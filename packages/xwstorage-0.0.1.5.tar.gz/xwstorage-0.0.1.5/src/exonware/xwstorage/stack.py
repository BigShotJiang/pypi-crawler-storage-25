# exonware/xwstorage/src/exonware/xwstorage/stack.py
"""
Opt-in first-party XW stack imports (REF_41 §8).

Default ``exonware-xwstorage`` does **not** load this module. After
``pip install exonware-xwstorage[stack]`` or ``[full]``, import it during host
bootstrap so **xwjson**, **xwnode**, **xwdata**, **xwschema**, **xwentity**,
**xwmodels**, **xwquery**, and **xwaction** are resolved and missing extras fail fast::

    import exonware.xwstorage.stack  # noqa: F401

This provides the same “eager stack import” pattern for storage hosts without pulling
in unrelated database product packages.
"""

from __future__ import annotations

import exonware.xwaction as xwaction  # noqa: F401
import exonware.xwdata as xwdata  # noqa: F401
import exonware.xwentity as xwentity  # noqa: F401
import exonware.xwjson as xwjson  # noqa: F401
import exonware.xwmodels as xwmodels  # noqa: F401
import exonware.xwnode as xwnode  # noqa: F401
import exonware.xwquery as xwquery  # noqa: F401
import exonware.xwschema as xwschema  # noqa: F401

__all__ = [
    "xwaction",
    "xwdata",
    "xwentity",
    "xwjson",
    "xwmodels",
    "xwnode",
    "xwquery",
    "xwschema",
]
