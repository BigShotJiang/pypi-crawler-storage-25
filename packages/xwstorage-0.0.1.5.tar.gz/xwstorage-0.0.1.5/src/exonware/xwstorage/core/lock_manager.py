#exonware/xwstorage/src/exonware/xwstorage/core/lock_manager.py
"""Lock manager; implementation lives in ``exonware.xwstorage`` package root."""

from __future__ import annotations

from exonware.xwstorage import LockManager

__all__ = ["LockManager"]
