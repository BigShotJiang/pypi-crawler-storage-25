#exonware/xwstorage/src/exonware/xwstorage/core/__init__.py
"""Core storage engine subpackage."""
