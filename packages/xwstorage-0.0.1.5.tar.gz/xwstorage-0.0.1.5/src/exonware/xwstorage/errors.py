#exonware/xwstorage/src/exonware/xwstorage/errors.py
"""Storage exception types; implementation lives in ``exonware.xwstorage`` package root."""

from __future__ import annotations

from exonware.xwstorage import XWConnectionError, XWLocationError, XWStorageError

__all__ = ["XWStorageError", "XWConnectionError", "XWLocationError"]
