#exonware/xwstorage/src/exonware/xwstorage/data/__init__.py
"""Data-layer subpackage (counters, compression, etc.)."""
