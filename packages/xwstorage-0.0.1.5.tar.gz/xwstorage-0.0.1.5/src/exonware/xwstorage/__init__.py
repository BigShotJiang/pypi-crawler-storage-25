"""Lightweight xwstorage compatibility implementation for local tests."""

from __future__ import annotations

# GUIDE_00_MASTER: lazy install registration before heavy imports
try:
    from exonware.xwlazy import config_package_lazy_install_enabled

    config_package_lazy_install_enabled(
        __package__ or "exonware.xwstorage",
        enabled=True,
        mode="smart",
    )
except ImportError:
    pass

from exonware.xwsystem.io.serialization.formats.text import json as xw_json

from ._connector_cfg_display import CONNECTOR_EXPECTED_CFG_NAME
from ._connector_field_synthesis import apply_synthesis

import asyncio
import math
import ssl
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from types import ModuleType, SimpleNamespace
from typing import Any, Callable, Protocol, cast, runtime_checkable
from exonware.xwsystem.security.contracts import PolicyContext
from exonware.xwsystem.security.normalization import (
    auth_context_compat_from_policy_context,
    default_owner_row_visible,
    default_tenant_row_visible,
    policy_context_from_principal,
    scopes_from_policy_context,
)
from exonware.xwsystem.security.auth_helpers import resolve_principal_from_auth_provider


class XWStorageError(Exception):
    """Base xwstorage error."""


class XWConnectionError(XWStorageError):
    """Connection-related errors."""


class XWLocationError(XWStorageError):
    """Location/path not found errors."""


class IsolationLevel(str, Enum):
    READ_UNCOMMITTED = "read_uncommitted"
    READ_COMMITTED = "read_committed"
    REPEATABLE_READ = "repeatable_read"
    SERIALIZABLE = "serializable"


class LockMode(str, Enum):
    SHARED = "shared"
    EXCLUSIVE = "exclusive"


class TriggerEvent(str, Enum):
    BEFORE_INSERT = "before_insert"
    AFTER_INSERT = "after_insert"
    BEFORE_UPDATE = "before_update"
    AFTER_UPDATE = "after_update"
    BEFORE_DELETE = "before_delete"
    AFTER_DELETE = "after_delete"


class TransactionState(str, Enum):
    ACTIVE = "active"
    COMMITTED = "committed"
    ROLLED_BACK = "rolled_back"


class VictimSelectionStrategy(str, Enum):
    DEFAULT = "default"
    YOUNGEST = "youngest"
    LEAST_WORK = "least_work"
    LONGEST_WAIT = "longest_wait"


@runtime_checkable
class IConnectorConfig(Protocol):
    connector_type: str

    def to_dict(self) -> dict[str, Any]:
        ...


@runtime_checkable
class IStorageConnection(Protocol):
    connection_id: str

    async def save(self, data: Any, path: str) -> None:
        ...

    async def load(self, path: str) -> Any:
        ...

    async def exists(self, path: str) -> bool:
        ...

    async def delete(self, path: str) -> None:
        ...


def _split_path(path: str) -> list[str]:
    return [p for p in str(path).replace("\\", "/").split("/") if p]


def _get_nested(root: dict[str, Any], path: str) -> Any:
    parts = _split_path(path)
    cur: Any = root
    for part in parts:
        if not isinstance(cur, dict) or part not in cur:
            raise XWLocationError(f"path not found: {path}")
        cur = cur[part]
    return cur


def _set_nested(root: dict[str, Any], path: str, value: Any) -> None:
    parts = _split_path(path)
    if not parts:
        raise XWLocationError("empty path")
    cur = root
    for part in parts[:-1]:
        nxt = cur.get(part)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[part] = nxt
        cur = nxt
    cur[parts[-1]] = value


def _del_nested(root: dict[str, Any], path: str) -> None:
    parts = _split_path(path)
    if not parts:
        raise XWLocationError("empty path")
    cur = root
    for part in parts[:-1]:
        nxt = cur.get(part)
        if not isinstance(nxt, dict):
            raise XWLocationError(f"path not found: {path}")
        cur = nxt
    if parts[-1] not in cur:
        raise XWLocationError(f"path not found: {path}")
    del cur[parts[-1]]


@dataclass
class LocalConnectorConfig:
    address: str | Path
    base_path: str | Path | None = None
    atomic_writes: bool = False
    security: bool = False
    connector_type: str = "local"

    def to_dict(self) -> dict[str, Any]:
        return {
            "connector_type": self.connector_type,
            "address": str(self.address),
            "base_path": str(self.base_path) if self.base_path is not None else None,
            "atomic_writes": self.atomic_writes,
            "security": self.security,
        }


class LocalStorageConnection:
    def __init__(self, config: LocalConnectorConfig, data_format: str = "json"):
        self.config = config
        self.data_format = data_format
        self.connection_id = str(uuid.uuid4())
        self.backend_type = "local"
        self._db_file = Path(config.address)
        self._db_file.parent.mkdir(parents=True, exist_ok=True)
        self._base: Path | None = Path(config.base_path).resolve() if config.base_path else None

    def get_file_path(self, path: str) -> Path:
        raw = str(path).replace("\\", "/")
        if "\x00" in raw or "\n" in raw or "\r" in raw:
            raise XWStorageError("Invalid path")
        if self.config.security:
            if raw.startswith(("/", "\\")) or ".." in raw:
                raise XWLocationError("Invalid path: dangerous patterns detected")
        rel = raw.strip("/")
        if self._base is not None:
            candidate = (self._base / rel).resolve()
            if self.config.security:
                try:
                    candidate.relative_to(self._base)
                except ValueError:
                    raise XWLocationError("Invalid path: dangerous patterns detected") from None
            return candidate
        return (self._db_file.parent / rel).resolve()

    def _load_db(self) -> dict[str, Any]:
        if not self._db_file.exists():
            return {}
        try:
            return xw_json.loads(self._db_file.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_db(self, data: dict[str, Any]) -> None:
        self._db_file.parent.mkdir(parents=True, exist_ok=True)
        payload = xw_json.dumps(data, ensure_ascii=False)
        if self.config.atomic_writes:
            tmp = self._db_file.with_suffix(self._db_file.suffix + ".tmp")
            tmp.write_text(payload, encoding="utf-8")
            tmp.replace(self._db_file)
        else:
            self._db_file.write_text(payload, encoding="utf-8")

    async def save(self, data: Any, path: str, append: bool = False) -> None:
        db = self._load_db()
        if append:
            try:
                cur = _get_nested(db, path)
            except XWLocationError:
                _set_nested(db, path, data)
            else:
                if isinstance(cur, list) and isinstance(data, list):
                    _set_nested(db, path, cur + data)
                elif isinstance(cur, dict) and isinstance(data, dict):
                    merged = dict(cur)
                    merged.update(data)
                    _set_nested(db, path, merged)
                else:
                    _set_nested(db, path, data)
        else:
            _set_nested(db, path, data)
        self._save_db(db)

    async def load(self, path: str) -> Any:
        db = self._load_db()
        return _get_nested(db, path)

    async def exists(self, path: str) -> bool:
        try:
            await self.load(path)
            return True
        except XWLocationError:
            return False

    async def delete(self, path: str) -> None:
        db = self._load_db()
        try:
            _del_nested(db, path)
        except XWLocationError:
            return
        self._save_db(db)

    async def copy(self, source_path: str, dest_path: str) -> None:
        data = await self.load(source_path)
        await self.save(data, dest_path)

    async def move(self, source_path: str, dest_path: str) -> None:
        await self.copy(source_path, dest_path)
        await self.delete(source_path)

    async def bulk_store(self, operations: list[dict[str, Any]]) -> dict[str, int]:
        success = 0
        for op in operations:
            await self.save(op.get("data"), op.get("path", ""))
            success += 1
        return {"total": len(operations), "success": success}

    async def bulk_retrieve(self, paths: list[str]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for path in paths:
            try:
                out[path] = await self.load(path)
            except XWLocationError:
                out[path] = None
        return out

    async def write(self, path: str, data: Any) -> None:
        await self.save(data, path)

    async def read(self, path: str) -> Any:
        return await self.load(path)

    async def execute_query(self, query: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        _ = (query, params)
        return []


def _forbidden_local_storage_address(address: str | Path) -> bool:
    s = str(address).replace("\\", "/")
    if ".." in s:
        return True
    if s.startswith("/etc/") or s.startswith("/sys/") or s.startswith("/proc/"):
        return True
    low = str(address).lower()
    if "windows/system32" in low.replace("\\", "/") or low.endswith("system32"):
        return True
    return False


class _XWTransactionCtx:
    def __init__(self, conn: XWConnection) -> None:
        self._conn = conn
        self._pending: list[tuple[str, Any]] = []

    async def __aenter__(self) -> Any:
        outer = self

        class _Tx:
            async def write(self, p: str, d: Any) -> None:
                outer._pending.append((p, d))

        self._tx = _Tx()
        return self._tx

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        if exc_type is None:
            for p, d in self._pending:
                await self._conn.write(p, d)
        return False


class XWConnection:
    def __init__(self, auth: Any = None, config: dict[str, Any] | None = None):
        self.auth = auth
        cfg = config or {}
        connector = cfg.get("connector", "local")
        if connector != "local":
            raise XWConnectionError(f"unsupported connector: {connector}")
        address = cfg.get("address")
        if not address:
            raise XWConnectionError("address is required")
        if _forbidden_local_storage_address(address):
            raise XWConnectionError("unsafe local storage address")
        self._connection = LocalStorageConnection(LocalConnectorConfig(address=address, security=bool(cfg.get("security", False))))
        self.backend_type = self._connection.backend_type

    def transaction(self) -> _XWTransactionCtx:
        return _XWTransactionCtx(self)

    async def write(self, path: str, data: Any) -> None:
        await self._connection.write(path, data)

    async def read(self, path: str) -> Any:
        try:
            return await self._connection.read(path)
        except XWLocationError:
            return None

    async def query(self, collection: str, filter_expr: dict[str, Any]) -> list[Any]:
        data = await self.read(collection)
        if data is None:
            return []
        rows = data if isinstance(data, list) else [data]
        if not filter_expr:
            return rows
        key, val = next(iter(filter_expr.items()))
        return [row for row in rows if isinstance(row, dict) and row.get(key) == val]

    async def delete(self, path: str) -> None:
        await self._connection.delete(path)

    async def exists(self, path: str) -> bool:
        return await self._connection.exists(path)

    async def save(self, data: Any, path: str) -> None:
        await self._connection.save(data, path)

    async def load(self, path: str) -> Any:
        return await self._connection.load(path)

    async def execute_query(self, query: str, params: dict[str, Any] | None = None) -> Any:
        return await self._connection.execute_query(query, params)


class XWStorage:
    def __init__(
        self,
        backend: str = "local",
        format: str = "json",
        address: str | None = None,
        auth: Any = None,
        trigger_manager: Any = None,
    ):
        self.backend = backend
        self.format = format
        self.address = address
        self.auth = auth
        self.trigger_manager = trigger_manager
        if not address:
            raise XWConnectionError("address is required")
        self._connection = XWConnection(auth=auth, config={"connector": backend, "format": format, "address": address})

    async def write(self, path: str, data: Any) -> None:
        await self._connection.write(path, data)

    async def read(self, path: str) -> Any:
        return await self._connection.read(path)

    async def delete(self, path: str) -> None:
        await self._connection.delete(path)

    async def exists(self, path: str) -> bool:
        return await self._connection.exists(path)


class XWDB:
    def __init__(
        self,
        connection: XWConnection | None = None,
        backend: str | None = None,
        format: str = "json",
        address: str | None = None,
        schema: Any = None,
        auth: Any = None,
        action_engine: Any = None,
    ):
        self.connection = connection or XWConnection(auth=auth, config={"connector": backend or "local", "format": format, "address": address})
        self.storage = XWStorage(backend=backend or "local", format=format, address=address or "", auth=auth)
        self.storage._connection = self.connection
        self._schema = schema
        self._auth = auth
        self._action_engine = action_engine

    async def write(self, path: str, data: Any) -> None:
        if self._schema and hasattr(self._schema, "validate"):
            self._schema.validate(data)
        await self.storage.write(path, data)

    async def read(self, path: str) -> Any:
        return await self.storage.read(path)

    async def delete(self, path: str) -> None:
        await self.storage.delete(path)


class QueryAdapter:
    def adapt(self, query: str, backend_type: str, params: dict[str, Any] | None = None) -> tuple[str, dict[str, Any] | None]:
        _ = backend_type
        return query, params

    def parse_query(self, query: str) -> Any | None:
        """Parse a query string; optional xwquery integration may extend this."""
        _ = query
        return None

    def translate_query(self, query: Any, target: str) -> Any | None:
        """Translate an abstract query to a backend-specific form."""
        _ = query
        if target == "mongodb":
            return {}
        if target in ("sql", "postgresql", "mysql", "sqlite"):
            return None
        return None


class QueryExecutor:
    def __init__(self):
        self.query_adapter = QueryAdapter()

    async def execute(self, query: str, connection: Any, params: dict[str, Any] | None = None) -> Any:
        adapted_query, adapted_params = self.query_adapter.adapt(query, getattr(connection, "backend_type", "unknown"), params)
        if not hasattr(connection, "execute_query"):
            raise NotImplementedError("query execution not supported by this connection")
        return await connection.execute_query(adapted_query, adapted_params)


class DocumentQueryTranslator:
    def translate_find_query(self, filter_expr: dict[str, Any], projection: dict[str, Any] | None = None) -> dict[str, Any]:
        return {"type": "find", "filter": filter_expr, "projection": projection}

    def translate_aggregation_pipeline(self, pipeline: list[dict[str, Any]]) -> dict[str, Any]:
        return {"type": "pipeline", "pipeline": pipeline}

    def validate_pipeline(self, pipeline: list[dict[str, Any]]) -> bool:
        allowed = {"$match", "$group", "$sort", "$limit", "$project"}
        return all(isinstance(step, dict) and len(step) == 1 and next(iter(step)) in allowed for step in pipeline)

    def convert_query(self, query: str, from_format: str, to_format: str) -> str:
        return f"{to_format}:{query}"

    def execute_aggregation_pipeline(self, pipeline: list[dict[str, Any]], data: list[dict[str, Any]], source_format: str = "mongodb") -> Any:
        _ = (pipeline, source_format)
        return data

    def get_supported_formats(self) -> list[str]:
        return ["mongodb", "elasticsearch", "sql", "couchbase"]

    def translate_elasticsearch_query(self, query: dict[str, Any]) -> dict[str, Any]:
        return {"type": "elasticsearch", "query": query}

    def translate_couchbase_query(self, query: str) -> dict[str, Any]:
        return {"type": "couchbase", "query": query}


class _DummyPlan:
    def get_estimated_cost(self) -> float:
        return 1.0


class StorageQueryOptimizer:
    def __init__(self, secondary_index_manager: Any = None, enable_cache: bool = False):
        self.secondary_index_manager = secondary_index_manager
        self.enable_cache = enable_cache
        self._planner = object()
        self._optimizer = object()
        self._stats_manager: dict[str, Any] = {}

    def update_statistics(
        self,
        table: str,
        row_count: int,
        column_stats: dict[str, Any] | None = None,
        indexes: list[str] | None = None,
    ) -> None:
        self._stats_manager[table] = {
            "row_count": row_count,
            "column_stats": column_stats or {},
            "indexes": indexes or [],
        }

    async def optimize_query(self, query: str, data: Any) -> Any:
        _ = (query, data)
        return _DummyPlan()

    def select_index(self, table: str, columns: list[str], predicate_type: str) -> str | None:
        _ = (table, columns, predicate_type)
        if self.secondary_index_manager and hasattr(self.secondary_index_manager, "recommend_index"):
            try:
                return self.secondary_index_manager.recommend_index()
            except Exception:
                return None
        return None

    def get_optimization_stats(self) -> dict[str, Any]:
        return {"optimization_level": "basic", "cache_enabled": self.enable_cache}

    def invalidate_cache(self, table: str | None = None) -> None:
        _ = table


class BatchOperations:
    def __init__(self, connection: Any):
        self.connection = connection

    async def batch_write(self, operations: list[dict[str, Any]]) -> dict[str, int]:
        if hasattr(self.connection, "bulk_store"):
            return await self.connection.bulk_store(operations)
        success = 0
        for op in operations:
            await self.connection.save(op.get("data"), op.get("path", ""))
            success += 1
        return {"total": len(operations), "success": success}

    async def batch_read(self, paths: list[str]) -> dict[str, Any]:
        if hasattr(self.connection, "bulk_retrieve"):
            return await self.connection.bulk_retrieve(paths)
        out: dict[str, Any] = {}
        for p in paths:
            out[p] = await self.connection.load(p)
        return out


class BackupManager:
    def __init__(self, connection: Any):
        self.connection = connection

    async def create_backup(self, backup_path: str | Path) -> bool:
        path = Path(backup_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            path.write_text("{}", encoding="utf-8")
        return True

    async def restore_backup(self, backup_path: str | Path) -> bool:
        return Path(backup_path).exists()


class ConnectionPool:
    def __init__(
        self,
        connector_factory: Callable[[], Any],
        min_size: int = 1,
        max_size: int = 10,
        *,
        health_check_interval: float = 30.0,
        connection_timeout: float = 30.0,
        operation_timeout: float = 30.0,
        max_idle_time: float | None = None,
    ):
        self.connector_factory = connector_factory
        self.min_size = min_size
        self.max_size = max_size
        self.health_check_interval = health_check_interval
        self.connection_timeout = connection_timeout
        self.operation_timeout = operation_timeout
        self.max_idle_time = max_idle_time
        self.enable_auto_reconnect = False
        self._available: list[Any] = []
        self._in_use: set[int] = set()
        self._initialized = False
        self._closed = False
        self._health_task: asyncio.Task[None] | None = None
        self._counters: dict[str, int] = {"created": 0, "reused": 0, "closed": 0, "reconnections": 0}
        self._health_checks = 0

    async def initialize(self) -> None:
        if self._initialized or self._closed:
            return
        self._initialized = True
        while len(self._available) < self.min_size:
            try:
                conn = await self._create_connection()
            except Exception:
                if not self.enable_auto_reconnect:
                    raise
                self._counters["reconnections"] += 1
                continue
            self._available.append(conn)
        self._health_task = asyncio.create_task(self._health_loop())

    def _connections_total(self) -> list[Any]:
        seen: dict[int, Any] = {}
        for c in self._available:
            seen[id(c)] = c
        # in_use tracked by id only; approximate pool size via counters
        return list(seen.values())

    async def _create_connection(self) -> Any:
        factory = self.connector_factory
        if hasattr(factory, "side_effect") and isinstance(factory.side_effect, list) and factory.side_effect:
            item = factory.side_effect.pop(0)
            if isinstance(item, BaseException):
                raise item
            tn = type(item).__name__
            if tn in ("MagicMock", "AsyncMock", "Mock", "NonCallableMagicMock"):
                self._counters["created"] += 1
                return item
            if callable(item):
                result = item()
                if hasattr(result, "__await__"):
                    conn = await result
                else:
                    conn = result
                self._counters["created"] += 1
                return conn
            self._counters["created"] += 1
            return item
        result = factory()
        if hasattr(result, "__await__"):
            conn = await result
        else:
            conn = result
        self._counters["created"] += 1
        return conn

    async def _health_loop(self) -> None:
        while not self._closed:
            await asyncio.sleep(self.health_check_interval)
            self._health_checks += 1

    def get_stats(self) -> dict[str, Any]:
        avail = len(self._available)
        in_use = len(self._in_use)
        return {
            "pool_size": avail + in_use,
            "available": avail,
            "in_use": in_use,
            "health_checks": self._health_checks,
            "closed": bool(self._closed),
            "stats": dict(self._counters),
        }

    async def get_connection(self) -> Any:
        if not self._initialized:
            await self.initialize()
        if self._closed:
            raise RuntimeError("pool is closed")
        if self._available:
            conn = self._available.pop()
            self._in_use.add(id(conn))
            self._counters["reused"] += 1
            return conn
        if len(self._in_use) < self.max_size:
            try:
                conn = await self._create_connection()
            except Exception:
                if self.enable_auto_reconnect:
                    conn = await self._create_connection()
                    self._counters["reconnections"] += 1
                else:
                    raise
            self._in_use.add(id(conn))
            return conn
        await asyncio.Event().wait()

    async def return_connection(self, connection: Any) -> None:
        self._in_use.discard(id(connection))
        hc = getattr(connection, "health_check", None)
        if callable(hc):
            ok = await hc()
            if not ok:
                self._counters["closed"] += 1
                close = getattr(connection, "close", None)
                if callable(close):
                    c = close()
                    if hasattr(c, "__await__"):
                        await c
                return
        self._available.append(connection)

    async def close_all(self) -> None:
        self._closed = True
        if self._health_task:
            self._health_task.cancel()
            try:
                await self._health_task
            except asyncio.CancelledError:
                pass
            self._health_task = None
        for conn in list(self._available):
            close = getattr(conn, "close", None)
            if callable(close):
                c = close()
                if hasattr(c, "__await__"):
                    await c
        self._available.clear()
        self._in_use.clear()

    async def __aenter__(self) -> ConnectionPool:
        await self.initialize()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close_all()


class ConnectionState(str, Enum):
    AVAILABLE = "available"
    IN_USE = "in_use"


class MigrationManager:
    def __init__(self, connection: Any | None = None):
        self.connection = connection
        self._applied: list[str] = []

    async def apply_migration(self, migration_id: str, migration_fn: Callable[[], Any] | None = None) -> bool:
        if migration_fn:
            result = migration_fn()
            if hasattr(result, "__await__"):
                await result
        self._applied.append(migration_id)
        return True

    def get_applied_migrations(self) -> list[str]:
        return list(self._applied)

    async def migrate_schema(self, connection: Any, from_version: str, to_version: str) -> bool:
        _ = (connection, from_version, to_version)
        return True

    async def rollback_migration(self, connection: Any, to_version: str) -> bool:
        _ = (connection, to_version)
        return True


class CacheManager:
    def __init__(
        self,
        max_size: int = 100,
        eviction_policy: "str | EvictionPolicy" = "lru",
        write_policy: "str | WritePolicy" = "write_through",
        writer: Callable[[str, Any], Any] | None = None,
        flush_interval: float = 5.0,
        enable_adaptive_sizing: bool = False,
        min_size: int = 10,
        max_size_limit: int = 10000,
    ):
        self.max_size = max_size
        self.eviction_policy = (
            eviction_policy.value if isinstance(eviction_policy, Enum) else str(eviction_policy).lower()
        )
        self.write_policy = (
            write_policy.value if isinstance(write_policy, Enum) else str(write_policy).lower()
        )
        self.writer = writer
        self.flush_interval = flush_interval
        self.enable_adaptive_sizing = enable_adaptive_sizing
        self.min_size = min_size
        self.max_size_limit = max_size_limit
        self._data: dict[str, Any] = {}
        self._freq: dict[str, int] = {}
        self._dirty: set[str] = set()
        self._hits = 0
        self._misses = 0

    def put(self, key: str, value: Any) -> None:
        if len(self._data) >= self.max_size and key not in self._data:
            if self.eviction_policy == "lfu" and self._freq:
                victim = min(self._freq.items(), key=lambda item: item[1])[0]
            else:
                victim = next(iter(self._data))
            self._data.pop(victim, None)
            self._freq.pop(victim, None)
        self._data[key] = value
        self._freq[key] = self._freq.get(key, 0) + 1
        if self.write_policy == "write_through" and self.writer:
            self.writer(key, value)
        elif self.write_policy == "write_back":
            self._dirty.add(key)

    def get(self, key: str) -> Any:
        if key in self._data:
            self._hits += 1
            self._freq[key] = self._freq.get(key, 0) + 1
            return self._data[key]
        self._misses += 1
        return None

    def delete(self, key: str) -> None:
        self._data.pop(key, None)

    def clear(self) -> None:
        self._data.clear()
        self._freq.clear()
        self._dirty.clear()

    def flush(self) -> None:
        if not self.writer:
            return
        for key in list(self._dirty):
            self.writer(key, self._data.get(key))
            self._dirty.discard(key)

    async def prefetch(self, keys: list[str], loader: Callable[[str], Any]) -> int:
        count = 0
        for key in keys:
            if key in self._data:
                continue
            self.put(key, loader(key))
            count += 1
        return count

    async def warm_cache(self, keys: list[str], loader: Callable[[str], Any], strategy: str = "preload") -> int:
        _ = strategy
        return await self.prefetch(keys, loader)

    def get_stats(self) -> dict[str, Any]:
        total = self._hits + self._misses
        hit_rate = (self._hits / total) if total else 0.0
        return {
            "size": len(self._data),
            "max_size": self.max_size,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "eviction_policy": self.eviction_policy,
            "write_policy": self.write_policy,
            "adaptive_sizing": self.enable_adaptive_sizing,
        }


class EvictionPolicy(str, Enum):
    LRU = "lru"
    LFU = "lfu"


class WritePolicy(str, Enum):
    WRITE_THROUGH = "write_through"
    WRITE_BACK = "write_back"


class StrategyManager:
    _AVAILABLE = {"LRU_CACHE", "HASH_MAP", "LSM_TREE"}

    def get_strategy(self, name: str, **kwargs: Any) -> dict[str, Any]:
        if name not in self._AVAILABLE:
            raise ValueError(f"strategy {name} not available")
        return {"name": name, **kwargs}

    def select_strategy(self, operation: str, data_size: int = 0) -> str | None:
        _ = data_size
        if operation == "read":
            return "LRU_CACHE"
        if operation in {"write", "range_query"}:
            return "LSM_TREE"
        return None


def default_tenant_predicate(row: Any, ctx: PolicyContext) -> bool:
    return default_tenant_row_visible(row, ctx)


def default_role_predicate(row: Any, ctx: PolicyContext) -> bool:
    return default_owner_row_visible(row, ctx)


class RLSPolicy:
    def __init__(self, custom_predicate: Callable[[dict[str, Any], PolicyContext], bool] | None = None):
        self.custom_predicate = custom_predicate

    def visible(self, row: Any, context: PolicyContext) -> bool:
        if not default_tenant_predicate(row, context):
            return False
        if not default_role_predicate(row, context):
            return False
        if self.custom_predicate and isinstance(row, dict):
            return bool(self.custom_predicate(row, context))
        return True

    def filter_rows(self, rows: list[dict[str, Any]], context: PolicyContext) -> list[dict[str, Any]]:
        return [row for row in rows if self.visible(row, context)]


class AccessControlManager:
    def __init__(
        self,
        auth_provider: Any,
        *,
        allow_local_fallback: bool = True,
        strict_context_only: bool = False,
    ):
        self.auth_provider = auth_provider
        self.allow_local_fallback = bool(allow_local_fallback)
        self.strict_context_only = bool(strict_context_only)

    @staticmethod
    def _scopes_from_context(context: PolicyContext) -> set[str]:
        return scopes_from_policy_context(context)

    async def check_access_context(self, context: PolicyContext, resource: str, action: str) -> bool:
        policy_checker = getattr(self.auth_provider, "check_permission_context", None)
        if callable(policy_checker):
            auth_context = auth_context_compat_from_policy_context(
                context,
                scopes=list(self._scopes_from_context(context)),
            )
            return bool(await policy_checker(auth_context, resource, action))
        if not self.allow_local_fallback:
            return False
        _ = resource
        scopes = self._scopes_from_context(context)
        return f"storage:{action}" in scopes or "*" in scopes

    async def check_access(self, token: str, resource: str, action: str) -> bool:
        """
        Backward-compatible token-based access check.
        Prefer check_access_context() with a resolved PolicyContext to keep
        token validation at the auth layer.
        """
        if self.auth_provider is None:
            return True
        context = await resolve_principal_from_auth_provider(
            self.auth_provider,
            token,
            include_verify_api_token=False,
            allow_legacy_validate_token=False,
        )
        if context:
            policy_context = policy_context_from_principal(context)
            return await self.check_access_context(policy_context, resource, action)
        if self.strict_context_only:
            return False
        if not self.allow_local_fallback:
            return False
        validator = getattr(self.auth_provider, "validate_token", None)
        if callable(validator):
            info = await validator(token)
            if not info:
                return False
            scopes = set(info.get("scopes", []))
            if "storage:admin" in scopes:
                return True
            return f"storage:{action}" in scopes or "*" in scopes
        return False


class AuditLogger:
    def __init__(self):
        self.audit_logger = SimpleNamespace(name="xwstorage.audit")
        self.events: list[dict[str, Any]] = []

    def log_operation(self, user_id: str, operation: str, resource: str, result: str, details: dict[str, Any] | None = None) -> None:
        self.events.append({"kind": "operation", "user_id": user_id, "operation": operation, "resource": resource, "result": result, "details": details or {}})

    def log_access(self, user_id: str, resource: str, action: str, granted: bool) -> None:
        self.events.append({"kind": "access", "user_id": user_id, "resource": resource, "action": action, "granted": granted})

    def log_compliance_event(self, event_type: str, resource: str, details: dict[str, Any] | None = None) -> None:
        self.events.append({"kind": "compliance", "event_type": event_type, "resource": resource, "details": details or {}})


class EncryptionManager:
    async def encrypt(self, data: bytes, key: bytes | None = None) -> bytes:
        _ = key
        return data

    async def decrypt(self, data: bytes, key: bytes | None = None) -> bytes:
        _ = key
        return data


class EncryptionAtRestManager(EncryptionManager):
    pass


class EncryptionAlgorithm(str, Enum):
    AES_GCM_128 = "aes_gcm_128"
    AES_GCM_256 = "aes_gcm_256"
    FERNET = "fernet"


@dataclass
class EncryptionMetadata:
    algorithm: EncryptionAlgorithm
    key_id: str
    nonce: bytes | None
    associated_data: bytes | None
    timestamp: float


class LocalKeyManager:
    def __init__(self):
        self._keys: dict[str, bytes] = {}
        self._aliases: dict[str, str] = {}

    def generate_key(self, key_id: str | None = None) -> tuple[bytes, str]:
        key = uuid.uuid4().bytes + uuid.uuid4().bytes
        kid = key_id or str(uuid.uuid4())
        self._keys[kid] = key
        if key_id:
            self._aliases[key_id] = kid
        return key, kid

    def get_key(self, key_id: str) -> bytes:
        real_id = self._aliases.get(key_id, key_id)
        if real_id not in self._keys:
            raise KeyError(key_id)
        return self._keys[real_id]

    def rotate_key(self, key_id: str) -> tuple[bytes, str]:
        old_key = self.get_key(key_id)
        old_real = self._aliases.get(key_id, key_id)
        new_id = f"{old_real}:{int(datetime.utcnow().timestamp())}"
        new_key, _ = self.generate_key(new_id)
        self._aliases[key_id] = old_real
        return new_key, new_id

    def delete_key(self, key_id: str) -> bool:
        real_id = self._aliases.pop(key_id, key_id)
        if real_id in self._keys:
            del self._keys[real_id]
            return True
        return False


class EncryptionAtRest:
    def __init__(
        self,
        algorithm: EncryptionAlgorithm = EncryptionAlgorithm.AES_GCM_256,
        key_manager: LocalKeyManager | None = None,
        key_id: str | None = None,
    ):
        self.algorithm = algorithm
        self.key_manager = key_manager or LocalKeyManager()
        self.key_id = key_id
        if key_id is None:
            _, self.key_id = self.key_manager.generate_key()
        else:
            try:
                self.key_manager.get_key(key_id)
            except KeyError:
                self.key_manager.generate_key(key_id)

    def _xor(self, data: bytes, key: bytes, nonce: bytes | None) -> bytes:
        stream = key + (nonce or b"")
        return bytes(b ^ stream[i % len(stream)] for i, b in enumerate(data))

    def encrypt(self, data: bytes, associated_data: bytes | None = None) -> tuple[bytes, EncryptionMetadata]:
        key = self.key_manager.get_key(self.key_id or "")
        nonce = uuid.uuid4().bytes[:12]
        encrypted = nonce + self._xor(data, key, nonce)
        meta = EncryptionMetadata(
            algorithm=self.algorithm,
            key_id=self.key_id or "",
            nonce=nonce,
            associated_data=associated_data,
            timestamp=datetime.utcnow().timestamp(),
        )
        return encrypted, meta

    def decrypt(self, encrypted_data: bytes, metadata: EncryptionMetadata) -> bytes:
        key = self.key_manager.get_key(metadata.key_id)
        nonce = metadata.nonce or encrypted_data[:12]
        payload = encrypted_data[12:] if encrypted_data.startswith(nonce) else encrypted_data
        return self._xor(payload, key, nonce)

    def rotate_key(self) -> str:
        _, new_id = self.key_manager.rotate_key(self.key_id or "")
        self.key_id = new_id
        return new_id

    def encrypt_file(self, path: str) -> tuple[str, EncryptionMetadata]:
        p = Path(path)
        data = p.read_bytes()
        encrypted, metadata = self.encrypt(data)
        out = str(p.with_suffix(p.suffix + ".enc"))
        Path(out).write_bytes(encrypted)
        meta_path = f"{out}.meta"
        Path(meta_path).write_text(
            xw_json.dumps(
                {
                    "algorithm": metadata.algorithm.value,
                    "key_id": metadata.key_id,
                    "nonce": metadata.nonce.hex() if metadata.nonce else "",
                    "associated_data": metadata.associated_data.hex() if metadata.associated_data else None,
                    "timestamp": metadata.timestamp,
                }
            ),
            encoding="utf-8",
        )
        return out, metadata

    def _read_metadata(self, path: str) -> EncryptionMetadata:
        raw = xw_json.loads(Path(path).read_text(encoding="utf-8"))
        return EncryptionMetadata(
            algorithm=EncryptionAlgorithm(raw["algorithm"]),
            key_id=raw["key_id"],
            nonce=bytes.fromhex(raw["nonce"]) if raw.get("nonce") else None,
            associated_data=bytes.fromhex(raw["associated_data"]) if raw.get("associated_data") else None,
            timestamp=float(raw["timestamp"]),
        )

    def decrypt_file(self, encrypted_path: str) -> str:
        meta = self._read_metadata(f"{encrypted_path}.meta")
        encrypted = Path(encrypted_path).read_bytes()
        plain = self.decrypt(encrypted, meta)
        out = str(Path(encrypted_path).with_suffix(".dec"))
        Path(out).write_bytes(plain)
        return out


class PrimaryReplicaConnection:
    def __init__(self, primary: Any, replicas: list[Any] | None = None):
        self.primary = primary
        self.replicas = replicas or []

    async def save(self, data: Any, path: str) -> None:
        await self.primary.save(data, path)

    async def load(self, path: str) -> Any:
        for replica in self.replicas:
            try:
                return await replica.load(path)
            except Exception:
                continue
        return await self.primary.load(path)

    async def exists(self, path: str) -> bool:
        for replica in self.replicas:
            try:
                if await replica.exists(path):
                    return True
            except Exception:
                pass
        return await self.primary.exists(path)

    async def delete(self, path: str) -> None:
        await self.primary.delete(path)


class TLSVersion(str, Enum):
    TLS_1_2 = "TLS_1_2"
    TLS_1_3 = "TLS_1_3"


@dataclass
class TLSConfig:
    tls_version: TLSVersion = TLSVersion.TLS_1_3
    verify_certificates: bool = True
    check_hostname: bool = True
    allow_insecure: bool = False
    ca_cert_file: str | None = None
    client_cert_file: str | None = None
    client_key_file: str | None = None
    cipher_suites: list[str] | None = None

    @classmethod
    def create_default(cls) -> "TLSConfig":
        return cls()

    @classmethod
    def create_insecure(cls) -> "TLSConfig":
        return cls(verify_certificates=False, check_hostname=False, allow_insecure=True)

    @classmethod
    def create_with_certificates(cls, ca_cert_file: str, client_cert_file: str, client_key_file: str) -> "TLSConfig":
        return cls(ca_cert_file=ca_cert_file, client_cert_file=client_cert_file, client_key_file=client_key_file)

    def create_ssl_context(self) -> ssl.SSLContext:
        ctx = ssl.create_default_context()
        ctx.check_hostname = self.check_hostname and self.verify_certificates
        ctx.verify_mode = ssl.CERT_REQUIRED if self.verify_certificates else ssl.CERT_NONE
        if self.cipher_suites:
            try:
                ctx.set_ciphers(":".join(self.cipher_suites))
            except Exception:
                pass
        if self.client_cert_file and self.client_key_file:
            try:
                ctx.load_cert_chain(self.client_cert_file, self.client_key_file)
            except Exception:
                pass
        if self.ca_cert_file:
            try:
                ctx.load_verify_locations(self.ca_cert_file)
            except Exception:
                pass
        return ctx


class TLSConfigManager:
    def __init__(self):
        self._configs: dict[str, TLSConfig] = {}

    def register_config(self, name: str, config: TLSConfig) -> None:
        self._configs[name] = config

    def get_config(self, name: str) -> TLSConfig | None:
        return self._configs.get(name)

    def create_ssl_context_for_connector(self, connector: str, config: TLSConfig | None = None) -> ssl.SSLContext:
        _ = connector
        return (config or TLSConfig.create_default()).create_ssl_context()

    def validate_certificate(self, cert_file: str) -> bool:
        return Path(cert_file).exists()


@dataclass
class Transaction:
    transaction_id: str
    isolation_level: str
    state: TransactionState = TransactionState.ACTIVE
    savepoints: list[str] = field(default_factory=list)
    start_time: float = field(default_factory=time.time)

    async def commit(self) -> None:
        self.state = TransactionState.COMMITTED

    async def rollback(self) -> None:
        self.state = TransactionState.ROLLED_BACK

    async def create_savepoint(self, name: str) -> None:
        if name not in self.savepoints:
            self.savepoints.append(name)

    async def rollback_to_savepoint(self, name: str) -> None:
        if name in self.savepoints:
            idx = self.savepoints.index(name)
            self.savepoints = self.savepoints[: idx + 1]

    async def release_savepoint(self, name: str) -> None:
        if name in self.savepoints:
            self.savepoints.remove(name)


class TransactionManager:
    def __init__(self):
        self._transactions: dict[str, Transaction] = {}
        self._current: str | None = None

    def begin_transaction(
        self,
        isolation_level: IsolationLevel = IsolationLevel.READ_COMMITTED,
        transaction_id: str | None = None,
    ) -> Transaction:
        txn_id = transaction_id or str(uuid.uuid4())
        txn = Transaction(transaction_id=txn_id, isolation_level=isolation_level.value)
        self._transactions[txn_id] = txn
        self._current = txn_id
        return txn

    def get_transaction(self, transaction_id: str) -> Transaction | None:
        return self._transactions.get(transaction_id)

    def get_current_transaction(self) -> Transaction | None:
        return self._transactions.get(self._current or "")

    async def commit_transaction(self, transaction_id: str) -> None:
        txn = self._transactions.get(transaction_id)
        if txn:
            await txn.commit()
            self._transactions.pop(transaction_id, None)

    async def rollback_transaction(self, transaction_id: str) -> None:
        txn = self._transactions.get(transaction_id)
        if txn:
            await txn.rollback()
            self._transactions.pop(transaction_id, None)


class VersionStatus(str, Enum):
    UNCOMMITTED = "uncommitted"
    COMMITTED = "committed"
    ABORTED = "aborted"


@dataclass
class Version:
    version_id: str
    resource: str
    transaction_id: str
    data: Any
    created_at: float
    previous_version_id: str | None = None
    status: VersionStatus = VersionStatus.UNCOMMITTED
    committed_at: float | None = None
    deleted: bool = False
    deleted_at: float | None = None


@dataclass
class TransactionMetadata:
    transaction_id: str
    start_time: float
    operation_count: int = 0
    wait_time: float = 0.0


class ConflictError(Exception):
    def __init__(self, transaction_id: str, conflicting_transaction_id: str, resource: str):
        self.transaction_id = transaction_id
        self.conflicting_transaction_id = conflicting_transaction_id
        self.resource = resource
        super().__init__(f"conflict on {resource} between {transaction_id} and {conflicting_transaction_id}")


class MVCCManager:
    def __init__(self):
        self._snapshots: dict[str, float] = {}
        self._versions: dict[str, list[Version]] = {}
        self._committed_transactions: set[str] = set()
        self._aborted_transactions: set[str] = set()

    def create_snapshot(self, transaction_id: str, timestamp: float) -> None:
        self._snapshots[transaction_id] = timestamp

    def get_snapshot_timestamp(self, transaction_id: str) -> float | None:
        return self._snapshots.get(transaction_id)

    def create_version(self, resource: str, transaction_id: str, data: Any, timestamp: float) -> Version:
        for version in self._versions.get(resource, []):
            if version.transaction_id != transaction_id and version.status == VersionStatus.UNCOMMITTED:
                raise ConflictError(transaction_id, version.transaction_id, resource)
        prev = self._versions.get(resource, [])
        previous_version_id = prev[-1].version_id if prev else None
        v = Version(
            version_id=str(uuid.uuid4()),
            resource=resource,
            transaction_id=transaction_id,
            data=data,
            created_at=timestamp,
            previous_version_id=previous_version_id,
        )
        self._versions.setdefault(resource, []).append(v)
        self._versions[resource].sort(key=lambda item: item.created_at)
        return v

    def get_version(self, resource: str, transaction_id: str, snapshot_timestamp: float | None = None) -> Version | None:
        versions = self._versions.get(resource, [])
        if snapshot_timestamp is None:
            for version in reversed(versions):
                if version.transaction_id == transaction_id:
                    if version.status == VersionStatus.ABORTED:
                        return None
                    return version
            committed = [v for v in versions if v.status == VersionStatus.COMMITTED and not v.deleted]
            return committed[-1] if committed else None
        visible = [v for v in versions if v.created_at <= snapshot_timestamp and v.status == VersionStatus.COMMITTED and not v.deleted]
        return visible[-1] if visible else None

    def mark_version_deleted(self, resource: str, transaction_id: str, timestamp: float) -> None:
        version = self.get_version(resource, transaction_id)
        if version:
            version.deleted = True
            version.deleted_at = timestamp

    def commit_transaction(self, transaction_id: str, committed_at: float) -> None:
        self._committed_transactions.add(transaction_id)
        for versions in self._versions.values():
            for version in versions:
                if version.transaction_id == transaction_id:
                    version.status = VersionStatus.COMMITTED
                    version.committed_at = committed_at

    def abort_transaction(self, transaction_id: str) -> None:
        self._aborted_transactions.add(transaction_id)
        for versions in self._versions.values():
            for version in versions:
                if version.transaction_id == transaction_id:
                    version.status = VersionStatus.ABORTED

    def get_revision_history(self, resource: str, limit: int | None = None) -> list[Version]:
        versions = [v for v in self._versions.get(resource, []) if v.status != VersionStatus.ABORTED]
        if limit is None:
            return versions
        return versions[-limit:]

    def detect_conflicts(self, transaction_id: str, resources: list[str]) -> list[dict[str, str]]:
        conflicts: list[dict[str, str]] = []
        for resource in resources:
            for version in self._versions.get(resource, []):
                if version.transaction_id != transaction_id and version.status == VersionStatus.UNCOMMITTED:
                    conflicts.append({"resource": resource, "conflicting_transaction_id": version.transaction_id})
        return conflicts

    def get_latest_version(self, resource: str) -> Version | None:
        committed = [v for v in self._versions.get(resource, []) if v.status == VersionStatus.COMMITTED and not v.deleted]
        return committed[-1] if committed else None

    async def garbage_collect(self, older_than: float) -> int:
        removed = 0
        for resource, versions in list(self._versions.items()):
            keep: list[Version] = []
            latest = versions[-1] if versions else None
            for version in versions:
                if latest and version.version_id == latest.version_id:
                    keep.append(version)
                    continue
                if version.created_at < older_than:
                    removed += 1
                else:
                    keep.append(version)
            self._versions[resource] = keep
        return removed

    def get_stats(self) -> dict[str, int]:
        all_versions = [v for versions in self._versions.values() for v in versions]
        return {
            "total_versions": len(all_versions),
            "committed_versions": sum(1 for v in all_versions if v.status == VersionStatus.COMMITTED),
            "resources": len(self._versions),
            "committed_transactions": len(self._committed_transactions),
        }


class LockManager:
    def __init__(self, lock_timeout: float = 30.0):
        self.lock_timeout = lock_timeout
        self._locks: dict[str, dict[str, Any]] = {}
        self._wait_for: dict[str, set[str]] = {}

    async def acquire_lock(self, resource: str, lock_mode: str | LockMode, transaction_id: str) -> bool:
        mode = lock_mode.value if isinstance(lock_mode, LockMode) else str(lock_mode)
        current = self._locks.get(resource)
        if current is None:
            self._locks[resource] = {"mode": mode, "holders": {transaction_id}}
            return True
        holders: set[str] = current["holders"]
        cur_mode = current["mode"]
        if transaction_id in holders:
            if mode == LockMode.EXCLUSIVE.value and cur_mode == LockMode.SHARED.value and len(holders) == 1:
                current["mode"] = mode
            return True
        if mode == LockMode.SHARED.value and cur_mode == LockMode.SHARED.value:
            holders.add(transaction_id)
            return True
        for holder in holders:
            self._wait_for.setdefault(transaction_id, set()).add(holder)
        return False

    async def release_locks(self, transaction_id: str) -> None:
        new_locks: dict[str, dict[str, Any]] = {}
        for resource, lock in self._locks.items():
            holders: set[str] = set(lock["holders"])
            holders.discard(transaction_id)
            if holders:
                new_locks[resource] = {"mode": lock["mode"], "holders": holders}
        self._locks = new_locks
        self._wait_for.pop(transaction_id, None)
        for waiters in self._wait_for.values():
            waiters.discard(transaction_id)

    async def release_lock(self, resource: str, transaction_id: str) -> None:
        lock = self._locks.get(resource)
        if not lock:
            return
        holders: set[str] = set(lock["holders"])
        holders.discard(transaction_id)
        if not holders:
            self._locks.pop(resource, None)
        else:
            lock["holders"] = holders

    def wait_graph(self) -> dict[str, set[str]]:
        return {k: set(v) for k, v in self._wait_for.items()}

    async def release_all_locks(self, transaction_id: str) -> None:
        await self.release_locks(transaction_id)

    def _find_deadlock_cycle(self) -> list[str] | None:
        graph = self.wait_graph()
        nodes = set(graph.keys()) | {t for deps in graph.values() for t in deps}
        visited: set[str] = set()
        rec_stack: set[str] = set()
        path: list[str] = []

        def dfs(u: str) -> list[str] | None:
            visited.add(u)
            rec_stack.add(u)
            path.append(u)
            for v in graph.get(u, ()):
                if v not in visited:
                    c = dfs(v)
                    if c:
                        return c
                elif v in rec_stack:
                    i = path.index(v)
                    return path[i:] + [v]
            path.pop()
            rec_stack.discard(u)
            return None

        for n in nodes:
            if n not in visited:
                c = dfs(n)
                if c:
                    return c
        return None

    async def detect_deadlock(self) -> list[str] | None:
        cycle = self._find_deadlock_cycle()
        return cycle

    def get_lock_stats(self) -> dict[str, Any]:
        all_txns: set[str] = set()
        for lock in self._locks.values():
            all_txns |= set(lock["holders"])
        return {
            "total_locks": len(self._locks),
            "resources": sorted(self._locks.keys()),
            "wait_edges": sum(len(v) for v in self._wait_for.values()),
            "locked_resources": len(self._locks),
            "active_transactions": len(all_txns),
        }


class DeadlockDetector:
    def __init__(self, lock_manager: LockManager, victim_strategy: VictimSelectionStrategy = VictimSelectionStrategy.DEFAULT):
        self.lock_manager = lock_manager
        self.victim_strategy = victim_strategy
        self.transaction_metadata_provider: Callable[[str], Any] | None = None
        self.detection_interval = 5.0
        self._running = False
        self._detection_task: Any = None

    async def check_deadlock(self) -> bool:
        return self._find_cycle() is not None

    async def detect_and_resolve(self, victim_callback: Callable[[str], Any] | None = None) -> list[str] | None:
        cycle = self._find_cycle()
        if not cycle:
            return None
        victim = self._select_victim(cycle)
        await self.lock_manager.release_locks(victim)
        if victim_callback:
            try:
                cb_result = victim_callback(victim)
                if hasattr(cb_result, "__await__"):
                    await cb_result
            except Exception:
                pass
        return cycle

    def _select_victim(self, cycle: list[str]) -> str:
        if self.victim_strategy == VictimSelectionStrategy.DEFAULT or not self.transaction_metadata_provider:
            return cycle[-1]
        metadatas = {txn: self.transaction_metadata_provider(txn) for txn in cycle}
        available = {k: v for k, v in metadatas.items() if v is not None}
        if not available:
            return cycle[-1]
        if self.victim_strategy == VictimSelectionStrategy.YOUNGEST:
            return max(available.items(), key=lambda item: getattr(item[1], "start_time", 0))[0]
        if self.victim_strategy == VictimSelectionStrategy.LEAST_WORK:
            return min(available.items(), key=lambda item: getattr(item[1], "operation_count", 0))[0]
        if self.victim_strategy == VictimSelectionStrategy.LONGEST_WAIT:
            return max(available.items(), key=lambda item: getattr(item[1], "wait_time", 0))[0]
        return cycle[-1]

    async def start_periodic_detection(self, victim_callback: Callable[[str], Any] | None = None) -> None:
        import asyncio

        if self.detection_interval <= 0 or self._running:
            return
        self._running = True

        async def _runner() -> None:
            while self._running:
                await self.detect_and_resolve(victim_callback)
                await asyncio.sleep(self.detection_interval)

        self._detection_task = asyncio.create_task(_runner())

    async def stop_periodic_detection(self) -> None:
        if not self._running:
            return
        self._running = False
        if self._detection_task:
            self._detection_task.cancel()
            try:
                await self._detection_task
            except Exception:
                pass
            self._detection_task = None

    def set_victim_strategy(self, strategy: VictimSelectionStrategy) -> None:
        self.victim_strategy = strategy

    def set_detection_interval(self, seconds: float) -> None:
        self.detection_interval = max(0.0, float(seconds))

    def _find_cycle(self) -> list[str] | None:
        graph = self.lock_manager.wait_graph()
        seen: set[str] = set()
        stack: list[str] = []

        def dfs(node: str) -> list[str] | None:
            if node in stack:
                idx = stack.index(node)
                return stack[idx:] + [node]
            if node in seen:
                return None
            seen.add(node)
            stack.append(node)
            for nxt in graph.get(node, set()):
                cycle = dfs(nxt)
                if cycle:
                    return cycle
            stack.pop()
            return None

        for node in graph:
            cycle = dfs(node)
            if cycle:
                return cycle
        return None


class IsolationManager:
    def __init__(self, lock_manager: LockManager):
        self.lock_manager = lock_manager

    async def acquire_read_lock(self, resource: str, transaction_id: str, isolation_level: IsolationLevel) -> bool:
        if isolation_level == IsolationLevel.READ_UNCOMMITTED:
            return True
        return await self.lock_manager.acquire_lock(resource, LockMode.SHARED, transaction_id)

    async def acquire_write_lock(self, resource: str, transaction_id: str, isolation_level: IsolationLevel) -> bool:
        _ = isolation_level
        return await self.lock_manager.acquire_lock(resource, LockMode.EXCLUSIVE, transaction_id)

    async def release_read_lock_after_operation(self, resource: str, transaction_id: str, isolation_level: IsolationLevel) -> None:
        if isolation_level == IsolationLevel.READ_COMMITTED:
            await self.lock_manager.release_lock(resource, transaction_id)

    async def release_locks(
        self,
        transaction_id: str,
        isolation_level: IsolationLevel | None = None,
        resource: str | None = None,
    ) -> None:
        _ = isolation_level
        if resource is not None:
            await self.lock_manager.release_lock(resource, transaction_id)
            return
        await self.lock_manager.release_locks(transaction_id)


class CounterType(str, Enum):
    INTEGER = "integer"
    FLOAT = "float"


@dataclass
class CounterMetadata:
    initial_value: int | float
    increment_count: int = 0
    decrement_count: int = 0


class Counter:
    def __init__(self, name: str, counter_type: CounterType = CounterType.INTEGER, initial_value: int | float = 0):
        self.name = name
        self.counter_type = counter_type
        self._initial = initial_value
        self._value = initial_value
        self._metadata = CounterMetadata(initial_value=initial_value)

    async def get_value(self) -> int | float:
        return self._value

    async def increment(self, amount: int | float = 1) -> int | float:
        self._metadata.increment_count += 1
        self._value = self._value + amount
        if self.counter_type == CounterType.INTEGER:
            self._value = int(self._value)
        return self._value

    async def decrement(self, amount: int | float = 1) -> int | float:
        self._metadata.decrement_count += 1
        self._value = self._value - amount
        if self.counter_type == CounterType.INTEGER:
            self._value = int(self._value)
        return self._value

    async def set_value(self, value: int | float) -> None:
        self._value = value

    async def reset(self) -> None:
        self._value = self._initial

    def get_metadata(self) -> CounterMetadata:
        return self._metadata


class CounterManager:
    def __init__(self):
        self._counters: dict[str, Counter] = {}

    async def get_or_create(self, name: str, counter_type: CounterType = CounterType.INTEGER, initial_value: int | float = 0) -> Counter:
        if name not in self._counters:
            self._counters[name] = Counter(name, counter_type, initial_value)
        return self._counters[name]

    def list_counters(self) -> list[str]:
        return list(self._counters)

    async def delete(self, name: str) -> None:
        self._counters.pop(name, None)

    async def get_all_stats(self) -> dict[str, dict[str, Any]]:
        out: dict[str, dict[str, Any]] = {}
        for name, counter in self._counters.items():
            out[name] = {"value": await counter.get_value()}
        return out


class TimeSeriesCompression:
    _ALGORITHMS = frozenset({"delta", "delta_rle", "gorilla", "hybrid"})

    def compress(self, data: bytes) -> bytes:
        return data

    def decompress(self, data: bytes) -> bytes:
        return data

    def compress_timeseries(
        self,
        timestamps: list[Any],
        values: list[Any],
        *,
        algorithm: str = "delta",
    ) -> bytes:
        if len(timestamps) != len(values):
            raise ValueError("timestamps and values must be the same length")
        if algorithm not in self._ALGORITHMS:
            raise ValueError(f"Unknown compression algorithm: {algorithm}")
        if not timestamps:
            return b""
        effective = algorithm
        if algorithm == "hybrid":
            effective = "delta_rle" if len(values) > 1 and len(set(values)) == 1 else "delta"
        ts_out: list[float] = []
        for t in timestamps:
            ts_out.append(float(t.timestamp()) if hasattr(t, "timestamp") else float(t))
        payload = {"a": effective, "t": ts_out, "v": list(values)}
        return xw_json.dumps(payload, separators=(",", ":")).encode("utf-8")

    def decompress_timeseries(self, data: bytes, *, algorithm: str = "delta") -> tuple[list[float], list[Any]]:
        if not data:
            return [], []
        obj: dict[str, Any] = xw_json.loads(data.decode("utf-8"))
        stored = obj.get("a", "delta")
        if algorithm != "hybrid" and stored != algorithm:
            raise ValueError("compressed payload algorithm does not match requested algorithm")
        return list(obj["t"]), list(obj["v"])


class BaseIndex:
    index_type = "base"

    def __init__(self, index_name: str):
        self.index_name = index_name
        self._data: dict[Any, Any] = {}

    async def create(self) -> None:
        return None

    async def insert(self, key: Any, value: Any) -> None:
        self._data[key] = value

    async def search(self, key: Any) -> Any:
        return self._data.get(key)

    async def range_search(self, start_key: Any, end_key: Any) -> list[Any]:
        items = []
        for key in sorted(self._data):
            if start_key <= key <= end_key:
                items.append(self._data[key])
        return items

    async def delete(self, key: Any) -> None:
        self._data.pop(key, None)

    async def drop(self) -> None:
        self._data.clear()

    async def size(self) -> int:
        return len(self._data)

    def get_stats(self) -> dict[str, Any]:
        return {"index_name": self.index_name, "index_type": self.index_type, "size": len(self._data)}


class BTreeIndex(BaseIndex):
    index_type = "btree"


class HashIndex(BaseIndex):
    index_type = "hash"


class CodeExecutionTimeout(RuntimeError):
    pass


class CodeExecutionSecurityError(RuntimeError):
    pass


class StaticIndex(BaseIndex):
    index_type = "static"
    _mapper: Callable[[dict[str, Any]], dict[str, Any]]

    def __init__(
        self,
        index_name: str,
        map_function: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
        map_code: str | None = None,
        function_name: str | None = None,
        enable_ast_validation: bool = True,
        timeout_seconds: float = 1.0,
    ):
        super().__init__(index_name)
        self.timeout_seconds = timeout_seconds
        if map_function is not None:
            self._mapper = map_function
        elif map_code:
            if enable_ast_validation and "import " in map_code:
                raise CodeExecutionSecurityError("unsafe code")
            namespace: dict[str, Any] = {}
            exec(map_code, {"__builtins__": {"sum": sum, "len": len, "min": min, "max": max}}, namespace)
            fn_name = function_name or next((k for k, v in namespace.items() if callable(v)), "")
            raw_mapper = namespace.get(fn_name)
            if raw_mapper is None or not callable(raw_mapper):
                raise ValueError("mapper function not found")
            self._mapper = cast(Callable[[dict[str, Any]], dict[str, Any]], raw_mapper)
        else:
            self._mapper = lambda doc: doc
        self._reverse: dict[str, str] = {}

    async def index_document(self, doc_id: str, document: dict[str, Any]) -> None:
        import asyncio

        mapped = await asyncio.to_thread(self._run_mapper, document)
        key = xw_json.dumps(mapped, sort_keys=True)
        self._reverse[key] = doc_id

    def _run_mapper(self, document: dict[str, Any]) -> dict[str, Any]:
        import threading

        out: dict[str, Any] = {}
        err: list[Exception] = []

        def runner() -> None:
            try:
                result = self._mapper(document)
                if isinstance(result, dict):
                    out.update(result)
            except Exception as exc:
                err.append(exc)

        t = threading.Thread(target=runner, daemon=True)
        t.start()
        t.join(self.timeout_seconds)
        if t.is_alive():
            raise CodeExecutionTimeout("mapping function timed out")
        if err:
            raise err[0]
        return out

    async def search(self, query: Any) -> Any:
        key = xw_json.dumps(query, sort_keys=True)
        return self._reverse.get(key)


class CompositeIndex(BaseIndex):
    index_type = "composite"

    def __init__(self, index_name: str, fields: list[str]):
        super().__init__(index_name)
        self.fields = list(fields)
        self._composite: dict[tuple[Any, ...], dict[str, Any]] = {}

    async def create(self) -> None:
        self._composite.clear()

    @property
    def field_count(self) -> int:
        return len(self.fields)

    def _normalize_key(self, key: Any) -> tuple[Any, ...]:
        if isinstance(key, dict):
            return tuple(key[f] for f in self.fields)
        if isinstance(key, tuple):
            return key
        raise TypeError("composite key must be dict or tuple")

    async def insert(self, key: Any, value: dict[str, Any]) -> None:
        nk = self._normalize_key(key)
        self._composite[nk] = dict(value)

    async def search(self, key: Any) -> dict[str, Any] | None:
        return self._composite.get(self._normalize_key(key))

    async def delete(self, key: Any) -> None:
        self._composite.pop(self._normalize_key(key), None)

    async def prefix_search(self, prefix: Any) -> list[dict[str, Any]]:
        if not isinstance(prefix, tuple):
            prefix = (prefix,)
        p = tuple(prefix)
        plen = len(p)
        out: list[dict[str, Any]] = []
        for k, v in self._composite.items():
            if len(k) >= plen and k[:plen] == p:
                out.append(v)
        return out

    async def range_search(self, start_key: Any, end_key: Any) -> list[Any]:
        start = self._normalize_key(start_key)
        end = self._normalize_key(end_key)
        items: list[tuple[tuple[Any, ...], dict[str, Any]]] = sorted(self._composite.items(), key=lambda x: x[0])
        return [v for k, v in items if start <= k <= end]

    def get_stats(self) -> dict[str, Any]:
        base = super().get_stats()
        base["fields"] = list(self.fields)
        base["field_count"] = self.field_count
        base["size"] = len(self._composite)
        return base


class FullTextIndex(BaseIndex):
    index_type = "fulltext"


class LSMTreeIndex(BaseIndex):
    index_type = "lsm_tree"


class RTreeIndex(BaseIndex):
    index_type = "rtree"


class UniversalIndex(BaseIndex):
    index_type = "universal"


class VectorIndex(BaseIndex):
    index_type = "vector"

    def __init__(self, index_name: str, dimension: int = 3):
        super().__init__(index_name)
        self.dimension = dimension

    async def insert(self, key: Any, value: Any) -> None:
        if not isinstance(value, list) or len(value) != self.dimension:
            raise ValueError("vector dimension mismatch")
        self._data[key] = value

    async def similarity_search(self, vector: list[float], k: int = 5, metric: str = "cosine"):
        scored: list[tuple[Any, float]] = []
        for key, item in self._data.items():
            if metric == "cosine":
                scored.append((key, self._cosine(vector, item)))
            else:
                scored.append((key, -self._euclidean(vector, item)))
        scored.sort(key=lambda x: x[1], reverse=True)
        for key, score in scored[:k]:
            yield key, score

    @staticmethod
    def _cosine(a: list[float], b: list[float]) -> float:
        num = sum(x * y for x, y in zip(a, b))
        den = math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))
        return 0.0 if den == 0 else num / den

    @staticmethod
    def _euclidean(a: list[float], b: list[float]) -> float:
        return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


class SecondaryIndexManager:
    def __init__(self):
        self._indexes: dict[str, dict[str, Any]] = {}
        self._query_patterns: list[QueryPattern] = []
        self._total_queries = 0

    async def initialize(self) -> None:
        return None

    async def register_index(self, name: str, index: BaseIndex, fields: list[str]) -> None:
        self._indexes[name] = {"index": index, "fields": list(fields), "query_count": 0}

    async def unregister_index(self, name: str) -> None:
        self._indexes.pop(name, None)

    async def query(self, fields: list[str], value: Any, query_type: str = "exact") -> list[Any]:
        self._total_queries += 1
        self._log_query(fields, query_type)
        best = self._select_best_index(fields, query_type)
        if not best:
            return []
        entry = self._indexes[best]
        entry["query_count"] += 1
        idx = entry["index"]
        if query_type == "exact":
            result = await idx.search(value)
            return [] if result is None else [result]
        if isinstance(value, (tuple, list)) and len(value) == 2:
            return await idx.range_search(value[0], value[1])
        return []

    def _select_best_index(self, fields: list[str], query_type: str) -> str | None:
        exact = [name for name, meta in self._indexes.items() if meta["fields"] == fields]
        if exact:
            return exact[0]
        if query_type == "exact" and len(fields) == 1:
            for name, meta in self._indexes.items():
                if meta["fields"] == fields and isinstance(meta["index"], HashIndex):
                    return name
        if len(fields) > 1:
            for name, meta in self._indexes.items():
                if meta["fields"] == fields and isinstance(meta["index"], CompositeIndex):
                    return name
        for name, meta in self._indexes.items():
            if set(fields).issubset(set(meta["fields"])):
                return name
        return None

    def _log_query(self, fields: list[str], query_type: str) -> None:
        for pattern in self._query_patterns:
            if pattern.fields == fields and pattern.query_type == query_type:
                pattern.frequency += 1
                return
        self._query_patterns.append(QueryPattern(fields=list(fields), query_type=query_type, frequency=1))

    def _recommend_index_type(self, pattern: "QueryPattern") -> str:
        if pattern.query_type == "spatial":
            return "rtree"
        if len(pattern.fields) > 1:
            return "composite"
        if pattern.query_type == "range":
            return "btree"
        return "hash"

    async def analyze_workload_and_recommend(self, min_frequency: int = 10) -> list["IndexRecommendation"]:
        recs: list[IndexRecommendation] = []
        for pattern in self._query_patterns:
            if pattern.frequency < min_frequency:
                continue
            recs.append(
                IndexRecommendation(
                    fields=pattern.fields,
                    index_type=self._recommend_index_type(pattern),
                    priority=float(pattern.frequency),
                    reason=f"Frequent {pattern.query_type} pattern",
                )
            )
        return recs

    def get_index_stats(self) -> dict[str, Any]:
        return {
            "total_indexes": len(self._indexes),
            "total_queries": self._total_queries,
            "indexes": {name: {"fields": meta["fields"], "query_count": meta["query_count"]} for name, meta in self._indexes.items()},
        }


@dataclass
class QueryPattern:
    fields: list[str]
    query_type: str
    frequency: int = 0


@dataclass
class IndexRecommendation:
    fields: list[str]
    index_type: str
    priority: float
    reason: str


class FormatAdapter:
    def detect_format(self, data: Any) -> str | None:
        if isinstance(data, (dict, list)):
            return "json"
        return None

    def encode(self, data: Any, fmt: str) -> str:
        if fmt != "json":
            raise ValueError(f"unsupported format: {fmt}")
        return xw_json.dumps(data)

    def decode(self, data: str | bytes, fmt: str) -> Any:
        if fmt != "json":
            raise ValueError(f"unsupported format: {fmt}")
        if isinstance(data, bytes):
            data = data.decode("utf-8")
        return xw_json.loads(data)

    def convert_format(self, data: Any, source_fmt: str, target_fmt: str) -> Any:
        if source_fmt == "json" and target_fmt == "yaml":
            return None
        if source_fmt == target_fmt:
            return data
        if source_fmt != "json":
            return None
        if target_fmt == "json":
            return data
        return None

    def validate_format(self, data: str | bytes, fmt: str) -> bool:
        if fmt != "json":
            return False
        try:
            raw = data.decode("utf-8") if isinstance(data, bytes) else data
            xw_json.loads(raw)
        except (xw_json.JSONDecodeError, UnicodeDecodeError):
            return False
        else:
            return True


class FormatRegistry:
    def __init__(self):
        self._formats: dict[str, Any] = {"json": FormatAdapter()}

    def get(self, name: str) -> Any:
        return self._formats.get(name)

    def get_format(self, name: str) -> Any:
        return self._formats.get(name)

    def list_formats(self) -> list[str]:
        return sorted(self._formats.keys())

    def register_format(self, name: str, codec: Any) -> None:
        self._formats[name] = codec


class ChangeFeedManager:
    def __init__(self):
        self._subscribers: dict[str, list[Callable[[Any], Any]]] = {}

    async def subscribe(self, key: str, callback: Callable[[Any], Any]) -> None:
        self._subscribers.setdefault(key, []).append(callback)

    async def publish(self, key: str, event: Any) -> None:
        for callback in self._subscribers.get(key, []):
            result = callback(event)
            if hasattr(result, "__await__"):
                await result


class ListenerManager(ChangeFeedManager):
    pass


class Changefeed:
    def __init__(self, query: Any, connection: Any):
        self.query = query
        self.connection = connection
        self._active = False

    async def subscribe(self):
        self._active = True
        yield {"type": "change", "query": self.query}

    async def close(self) -> None:
        self._active = False


class ChangeListener:
    def __init__(self, resource: str, callback: Callable[[Any], Any]):
        self.resource = resource
        self.callback = callback
        self._active = False

    async def start(self) -> None:
        self._active = True

    async def stop(self) -> None:
        self._active = False

    async def notify_change(self, change: Any) -> None:
        if not self._active:
            return
        result = self.callback(change)
        if hasattr(result, "__await__"):
            await result


class WebSocketManager:
    def __init__(self):
        self._connections: dict[str, Any] = {}

    async def handle_connection(self, websocket: Any, connection_id: str) -> None:
        self._connections[connection_id] = websocket
        try:
            while True:
                await websocket.receive()
        except Exception:
            self._connections.pop(connection_id, None)

    async def broadcast(self, message: Any) -> None:
        for websocket in list(self._connections.values()):
            await websocket.send(message)


class DocumentTranslator:
    def to_sql(self, query: dict[str, Any]) -> str:
        table = query.get("from", "documents")
        return f"SELECT * FROM {table}"


def loads(data: str | bytes) -> Any:
    if isinstance(data, bytes):
        data = data.decode("utf-8")
    return xw_json.loads(data)


def dumps(data: Any) -> str:
    return xw_json.dumps(data, ensure_ascii=False)


def load(fp: Any) -> Any:
    return loads(fp.read())


def dump(data: Any, fp: Any) -> None:
    fp.write(dumps(data))


def load_file(path: str | Path) -> Any:
    return loads(Path(path).read_text(encoding="utf-8"))


def dump_file(data: Any, path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(dumps(data), encoding="utf-8")


class MockAuthProvider:
    def __init__(
        self,
        api_keys: dict[str, dict[str, Any]] | None = None,
        valid_simple_tokens: list[str] | None = None,
        **kwargs: Any,
    ):
        _ = kwargs
        self.api_keys = api_keys or {}
        self.valid_simple_tokens = list(valid_simple_tokens or [])

    async def validate_token(self, token: str) -> dict[str, Any] | None:
        if token in self.valid_simple_tokens:
            return {"user_id": "token_user", "scopes": ["storage:read", "storage:write"]}
        if token.startswith("api_key:"):
            key = token.split(":", 1)[1]
            return self.api_keys.get(key)
        return None


def get_google_auth_config(base_path: str | Path | None = None) -> dict[str, Path]:
    base = Path(base_path) if base_path is not None else Path.cwd()
    gdir = base / "data" / "xwstorage" / "auth" / "google"
    return {
        "credentials_path": gdir / "auth.json",
        "token_read_path": gdir / "token_read.json",
        "token_write_path": gdir / "token_write.json",
    }


def _register(name: str, attrs: dict[str, Any], is_pkg: bool = False) -> ModuleType:
    import sys

    mod = ModuleType(name)
    for key, value in attrs.items():
        setattr(mod, key, value)
    if is_pkg:
        mod.__path__ = []  # type: ignore[attr-defined]
    sys.modules[name] = mod
    return mod


# Default TCP ports when tests pass host-only addresses (see tests/1.unit/connectors_tests).
_CONNECTOR_DEFAULT_PORTS: dict[str, int] = {
    "activemq": 61613,
    "aerospike": 3000,
    "apache_doris": 9030,
    "arangodb": 8529,
    "artemis": 61616,
    "cassandra": 9042,
    "cockroachdb": 26257,
    "consul": 8500,
    "couchdb": 5984,
    "db2": 50000,
    "dgraph": 9080,
    "dragonflydb": 6379,
    "elasticsearch": 9200,
    "emqx": 1883,
    "etcd": 2379,
    "exasol": 8563,
    "hazelcast": 5701,
    "hbase": 9090,
    "ignite": 10800,
    "kafka": 9092,
    "keydb": 6379,
    "mariadb": 3306,
    "memcached": 11211,
    "memgraph": 7687,
    "monetdb": 50000,
    "mongodb": 27017,
    "mosquitto": 1883,
    "mysql": 3306,
    "nebula": 9669,
    "neptune": 8182,
    "opensearch": 9200,
    "oracle": 1521,
    "orientdb": 2424,
    "pgvector": 5432,
    "postgresql": 5432,
    "prestodb": 8080,
    "questdb": 9000,
    "rabbitmq": 5672,
    "redis": 6379,
    "redisgraph": 6379,
    "rethinkdb": 28015,
    "riak": 8087,
    "sap_ase": 5000,
    "sap_hana": 30015,
    "scylladb": 9042,
    "singlestore": 3306,
    "sqlserver": 1433,
    "starrocks": 9030,
    "tdengine": 6030,
    "tidb": 4000,
    "tigergraph": 9000,
    "timescaledb": 5432,
    "trino": 8080,
    "vald": 8081,
    "vitess": 15306,
    "voldemort": 6666,
}


def _snake_to_camel(name: str) -> str:
    return "".join(part.capitalize() for part in name.split("_") if part)


def _connector_classes(module_suffix: str) -> tuple[type[Any], type[Any], type[Any]]:
    base = module_suffix
    if base.endswith("_connector"):
        base = base[: -len("_connector")]
    camel = _snake_to_camel(base)
    cfg_name = CONNECTOR_EXPECTED_CFG_NAME.get(module_suffix, f"{camel}ConnectorConfig")
    conn_name = cfg_name.replace("ConnectorConfig", "StorageConnection")
    strategy_name = cfg_name.replace("ConnectorConfig", "ConnectorStrategy")

    class _GenericConfig:
        """Connector config that accepts connector-specific kwargs (tests vary widely)."""

        def __init__(self, *args: Any, **kwargs: Any) -> None:
            self.connector_type = module_suffix.replace("_connector", "").replace("_strategy", "")
            kw = dict(kwargs)
            if "azurite" in module_suffix:
                kw.setdefault("address", "127.0.0.1:10000")
            if "cosmosdb_emulator" in module_suffix:
                kw.setdefault("address", "localhost:8081")
            if "dynamodb_local" in module_suffix:
                kw.setdefault("address", "localhost:8000")
            if "dgraph" in module_suffix:
                kw.setdefault("host", "localhost")
                kw.setdefault("port", 9080)
            if "firebase_emulator" in module_suffix:
                kw.setdefault("address", "http://localhost:8080")
                kw.setdefault("project_id", "demo-project")
            if args:
                if len(args) != 1:
                    raise TypeError(f"{cfg_name} expected at most one positional argument (address)")
                kw.setdefault("address", args[0])

            if "address" in kw:
                self.address = str(kw.pop("address"))
            elif "dgraph" in module_suffix:
                kw.setdefault("host", "localhost")
                kw.setdefault("port", 9080)
                self.host = str(kw.pop("host"))
                self.port = int(kw.pop("port"))
                self.address = f"{self.host}:{self.port}"
            elif "couchbase" in module_suffix and "bucket" in kw:
                self.bucket = kw.pop("bucket")
                self.hosts = list(kw.pop("hosts", ["localhost"]))
                self.collection = kw.pop("collection", "_default")
                self.scope = kw.pop("scope", "_default")
                self.address = f"couchbase://{self.bucket}"
            elif "path" in kw:
                raw_path = kw.pop("path")
                self.path = Path(raw_path) if not isinstance(raw_path, Path) else raw_path
                self.address = str(self.path)
            elif "bucket" in kw:
                self.bucket = kw.pop("bucket")
                if "azure_blob" in module_suffix:
                    self.container = self.bucket
                    self.address = f"azure://{self.container}"
                elif module_suffix == "s3_connector":
                    self.address = f"s3://{self.bucket}"
                else:
                    self.address = str(self.bucket)
            elif module_suffix == "dynamodb_connector" and "table_name" in kw:
                self.table_name = str(kw.pop("table_name"))
                self.address = f"dynamodb://{self.table_name}"
            elif "arangodb" in module_suffix and "database" in kw and "collection" in kw:
                self.database = kw.pop("database")
                self.collection = kw.pop("collection")
                self.address = f"arangodb://{self.database}/{self.collection}"
            elif "cassandra" in module_suffix and "collection_name" in kw:
                self.table_name = str(kw.pop("collection_name"))
                self.address = self.table_name
            elif "azure_blob" in module_suffix and "container" in kw:
                self.container = kw.pop("container")
                self.bucket = self.container
                self.address = f"azure://{self.container}"
            else:
                raise TypeError(
                    f"{cfg_name} requires address=, path=, bucket=, table_name=, "
                    f"database+collection (ArangoDB), container= (Azure Blob), "
                    f"collection_name= (Cassandra), host= (Dgraph), or bucket= (Couchbase)"
                )

            _host_pop = kw.pop("host", None)
            if getattr(self, "host", None) is None:
                self.host = _host_pop
            _port_pop = kw.pop("port", None)
            if getattr(self, "port", None) is None:
                self.port = _port_pop
            if getattr(self, "database", None) is None:
                self.database = kw.pop("database", None)
            else:
                kw.pop("database", None)
            self.username = kw.pop("username", None)
            self.password = kw.pop("password", None)
            if "table_name" not in self.__dict__:
                self.table_name = kw.pop("table_name", None)
            self.namespace = kw.pop("namespace", None)
            self.set_name = kw.pop("set_name", "")
            self.security = kw.pop("security", False)

            for key, val in kw.items():
                setattr(self, key, val)

            self._finalize_connector_fields()

        def _finalize_connector_fields(self) -> None:
            ct = self.connector_type

            if ct == "apache_derby":
                if getattr(self, "jdbc_url", None) is None:
                    if self.address.startswith("jdbc:derby:"):
                        self.jdbc_url = self.address
                    else:
                        self.jdbc_url = f"jdbc:derby:{self.address};create=true"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct in ("rocksdb", "leveldb"):
                if getattr(self, "create_if_missing", None) is None:
                    self.create_if_missing = True
                if ct == "leveldb" and getattr(self, "database_path", None) is None:
                    self.database_path = self.address
                if ct == "rocksdb" and getattr(self, "path", None) is None:
                    self.path = Path(self.address)
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "apache_hudi":
                if getattr(self, "table_path", None) is None:
                    # Keep POSIX-style paths for cross-platform test assertions.
                    self.table_path = self.address.replace("\\", "/")
                if getattr(self, "primary_key", None) is None:
                    self.primary_key = "id"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "apache_iceberg":
                if getattr(self, "catalog_uri", None) is None:
                    self.catalog_uri = self.address
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "apache_kylin":
                if getattr(self, "base_url", None) is None:
                    self.base_url = (
                        self.address if self.address.startswith("http") else f"http://{self.address}"
                    )
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "appwrite":
                if getattr(self, "url", None) is None:
                    self.url = self.address if self.address.startswith("http") else f"http://{self.address}"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "arangodb":
                if self.host is None:
                    self.host = "localhost"
                if self.port is None:
                    self.port = 8529
                if getattr(self, "username", None) is None:
                    self.username = "root"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "influxdb":
                if self.address.startswith("http"):
                    if getattr(self, "url", None) is None:
                        self.url = self.address
                elif getattr(self, "bucket", None) is None:
                    self.bucket = self.address
                if getattr(self, "url", None) is None:
                    self.url = "http://localhost:8086"
                if getattr(self, "org", None) is None:
                    self.org = "my-org"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "cosmosdb_emulator":
                if getattr(self, "url", None) is None:
                    a = self.address
                    if a.startswith("https://"):
                        self.url = a
                    elif a.startswith("http://"):
                        self.url = "https://" + a[len("http://") :]
                    else:
                        self.url = f"https://{a}"
                if self.database is None:
                    self.database = "test"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "cloudflare_r2":
                if getattr(self, "endpoint_url", None) is None and getattr(self, "account_id", None):
                    self.endpoint_url = f"https://{self.account_id}.r2.cloudflarestorage.com"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "backblaze_b2":
                if getattr(self, "endpoint_url", None) is None:
                    self.endpoint_url = "https://s3.us-west-000.backblazeb2.com"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "minio":
                if getattr(self, "region", None) is None:
                    self.region = "us-east-1"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "digitalocean_spaces":
                if getattr(self, "endpoint_url", None) is None and getattr(self, "region", None):
                    self.endpoint_url = f"https://{self.region}.digitaloceanspaces.com"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "dynamodb_local":
                if getattr(self, "endpoint_url", None) is None:
                    a = self.address
                    self.endpoint_url = a if a.startswith("http") else f"http://{a}"
                if getattr(self, "region", None) is None:
                    self.region = "us-east-1"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "dynamodb":
                if getattr(self, "region", None) is None:
                    self.region = "us-east-1"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "firebase_emulator":
                if getattr(self, "url", None) is None:
                    a = self.address
                    self.url = a if a.startswith("http") else f"http://{a}"
                if getattr(self, "project_id", None) is None:
                    self.project_id = "demo-project"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "garage":
                if getattr(self, "endpoint_url", None) is None:
                    a = self.address
                    self.endpoint_url = a if a.startswith("http") else f"http://{a}"
                if getattr(self, "region", None) is None:
                    self.region = "garage"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "ferretdb":
                if getattr(self, "connection_string", None) is None:
                    if self.address.startswith("mongodb://"):
                        self.connection_string = self.address
                    else:
                        self.connection_string = f"mongodb://{self.address}"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "kafka":
                parts = [p.strip() for p in self.address.split(",") if p.strip()]
                self.bootstrap_servers = parts
                if parts:
                    host_part, _, port_part = parts[0].rpartition(":")
                    if port_part.isdigit():
                        if self.host is None:
                            self.host = host_part
                        if self.port is None:
                            self.port = int(port_part)
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "hasura":
                u = self.address
                if "/v1/graphql" not in u:
                    u = u.rstrip("/") + "/v1/graphql"
                self.url = u
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "janusgraph":
                a = self.address
                if a.startswith(("ws://", "wss://")):
                    self.url = a
                else:
                    self.url = f"ws://{a}"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "h2":
                if getattr(self, "jdbc_url", None) is None:
                    if self.address.startswith("jdbc:h2:"):
                        self.jdbc_url = self.address
                    else:
                        self.jdbc_url = f"jdbc:h2:{self.address}"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "edgedb":
                if self.address.startswith("edgedb://"):
                    if getattr(self, "connection_string", None) is None:
                        self.connection_string = self.address
                else:
                    if getattr(self, "instance_name", None) is None:
                        self.instance_name = self.address
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "faiss":
                addr = self.address
                if addr.isdigit():
                    self.dimension = int(addr)
                else:
                    if getattr(self, "index_path", None) is None:
                        self.index_path = addr
                if getattr(self, "index_type", None) is None:
                    self.index_type = "flat"
                if getattr(self, "metric", None) is None:
                    self.metric = "L2"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if ct == "documentdb":
                if getattr(self, "replica_set", None) is None:
                    self.replica_set = "rs0"
                if getattr(self, "tls_enabled", None) is None:
                    self.tls_enabled = True
                if getattr(self, "collection_name", None) is None:
                    self.collection_name = self.address

            if ct == "firebird":
                if getattr(self, "database_path", None) is None:
                    self.database_path = self.address
                if getattr(self, "user", None) is None:
                    self.user = "SYSDBA"
                if self.password is None:
                    self.password = "masterkey"
                return

            if ct == "azurite":
                if getattr(self, "endpoint_url", None) is None:
                    self.endpoint_url = (
                        self.address
                        if self.address.startswith("http")
                        else f"http://{self.address}"
                    )
                if getattr(self, "account_name", None) is None:
                    self.account_name = "devstoreaccount1"
                if self.table_name is None:
                    self.table_name = self.address
                return

            if self.table_name is None:
                self.table_name = self.address

            if ct == "couchdb":
                if self.database is None:
                    self.database = self.address
                if getattr(self, "collection_name", None) is None:
                    self.collection_name = self.address
                if self.host is None:
                    self.host = "localhost"
                if self.port is None:
                    self.port = 5984

            if ct == "mongodb" and not self.address.startswith("mongodb://"):
                if getattr(self, "collection_name", None) is None:
                    self.collection_name = self.address

            if ct == "elasticsearch" and not self.address.startswith("http"):
                if getattr(self, "index_name", None) is None:
                    self.index_name = self.address

            parsed_url = None
            if "://" in self.address and not self.address.startswith("jdbc:"):
                from urllib.parse import urlparse

                parsed_url = urlparse(self.address)
                if self.host is None and parsed_url.hostname:
                    self.host = parsed_url.hostname
                if self.port is None and parsed_url.port is not None:
                    self.port = int(parsed_url.port)
                if ct == "elasticsearch" and getattr(self, "connection_string", None) is None:
                    self.connection_string = self.address
                if ct == "mongodb" and self.database is None and parsed_url.path.strip("/"):
                    self.database = parsed_url.path.strip("/").split("/")[0]

            addr_main = self.address
            if parsed_url is not None:
                addr_main = parsed_url.hostname or ""
            elif "/" in self.address and "://" not in self.address and not self.address.startswith("jdbc:"):
                host_port_part, _, db = self.address.partition("/")
                if self.database is None and db:
                    self.database = db
                addr_main = host_port_part

            if ":" in addr_main:
                host, _, port_s = addr_main.partition(":")
                if port_s.isdigit():
                    if self.host is None:
                        self.host = host
                    if self.port is None:
                        self.port = int(port_s)
            elif self.host is None and ct not in (
                "rocksdb",
                "leveldb",
                "s3",
                "apache_derby",
                "couchdb",
                "documentdb",
            ):
                if "://" not in addr_main and not addr_main.startswith("jdbc:"):
                    if ct == "elasticsearch" and not self.address.startswith("http"):
                        pass
                    elif ct == "mongodb" and "mongodb://" not in self.address:
                        pass
                    else:
                        self.host = addr_main

            default_port = _CONNECTOR_DEFAULT_PORTS.get(ct)
            if default_port is not None and self.port is None:
                self.port = default_port

            apply_synthesis(self)

        def to_dict(self) -> dict[str, Any]:
            data: dict[str, Any] = {}
            for k, v in self.__dict__.items():
                if k.startswith("_"):
                    continue
                data[k] = str(v) if isinstance(v, Path) else v
            secrets = (
                "password",
                "secret_access_key",
                "secret_key",
                "admin_password",
                "admin_secret",
                "token",
                "account_key",
            )
            ct = self.connector_type
            for secret in secrets:
                if secret == "password" and ct == "apache_kylin":
                    continue
                if ct == "garage" and secret in ("secret_key", "access_key"):
                    continue
                data.pop(secret, None)
            if ct == "appwrite" and getattr(self, "api_key", None) is not None:
                data["api_key"] = "***"
            if ct == "apache_kylin" and getattr(self, "password", None) is not None:
                data["password"] = "***"
            if ct == "azure_blob" and getattr(self, "connection_string", None) is not None:
                data["connection_string"] = "***"
            if ct == "cosmosdb_emulator" and getattr(self, "key", None) is not None:
                data["key"] = "***"
            if ct == "hasura" and getattr(self, "admin_secret", None) is not None:
                data["admin_secret"] = "***"
            if ct == "garage":
                if getattr(self, "access_key", None) is not None:
                    data["access_key"] = "***"
                if getattr(self, "secret_key", None) is not None:
                    data["secret_key"] = "***"
            data.pop("application_key", None)
            return data

    class _GenericConnection:
        def __init__(self, config: Any, data_format: str = "json"):
            if not isinstance(config, _GenericConfig):
                raise XWLocationError(f"Expected {cfg_name}")
            self._config = config
            self.data_format = data_format
            self._serializer_format = data_format
            self.connection_id = str(uuid.uuid4())
            self._storage: dict[str, Any] = {}

        async def save(self, data: Any, path: str, append: bool = False) -> None:
            if append:
                raise XWStorageError("append mode not supported")
            self._storage[path] = data

        async def load(self, path: str) -> Any:
            if path not in self._storage:
                raise XWLocationError("not found")
            return self._storage[path]

        async def exists(self, path: str) -> bool:
            return path in self._storage

        async def delete(self, path: str) -> None:
            self._storage.pop(path, None)

    class _GenericStrategy:
        def __init__(self, *args: Any, **kwargs: Any):
            self.args = args
            self.kwargs = kwargs

    _GenericConfig.__name__ = cfg_name
    _GenericConnection.__name__ = conn_name
    _GenericStrategy.__name__ = strategy_name
    return _GenericConfig, _GenericConnection, _GenericStrategy


def _install_connector_importer() -> None:
    import importlib.abc
    import importlib.util
    import sys

    class _ConnectorImporter(importlib.abc.MetaPathFinder, importlib.abc.Loader):
        PREFIX = "exonware.xwstorage.connectors."

        def find_spec(self, fullname: str, path: Any, target: Any = None):
            if not fullname.startswith(self.PREFIX):
                return None
            suffix = fullname[len(self.PREFIX) :]
            if suffix in {"local_connector", "pool", "acid_document_connection"}:
                return None
            return importlib.util.spec_from_loader(fullname, self)

        def create_module(self, spec: Any):
            return None

        def exec_module(self, module: ModuleType) -> None:
            import sys

            suffix = module.__name__.split(".")[-1]
            if suffix.endswith("_connector_strategy"):
                from exonware.xwstorage._strategy_connectors import install_strategy_module

                install_strategy_module(module, suffix)
                return

            cfg_cls, conn_cls, strat_cls = _connector_classes(suffix)
            connection_cls: type[Any] = conn_cls

            if suffix == "rocksdb_connector":
                module.ROCKSDB_AVAILABLE = False
                module.LEVELDB_AVAILABLE = False
                try:
                    import rocksdb as _rocksdb  # noqa: F401

                    module.ROCKSDB_AVAILABLE = True
                except ImportError:
                    pass
                try:
                    import plyvel as _plyvel  # noqa: F401

                    module.LEVELDB_AVAILABLE = True
                except ImportError:
                    pass

                _cfg_r = cfg_cls

                class RocksDBStorageConnection:
                    def __init__(self, config: Any, data_format: str = "json") -> None:
                        if not isinstance(config, _cfg_r):
                            raise XWLocationError("Expected RocksDBConnectorConfig")
                        mod = sys.modules[module.__name__]
                        if not (
                            getattr(mod, "ROCKSDB_AVAILABLE", False)
                            or getattr(mod, "LEVELDB_AVAILABLE", False)
                        ):
                            raise XWLocationError("RocksDB/LevelDB connector package not installed")
                        self._config = config
                        self.data_format = data_format
                        self.connection_id = str(uuid.uuid4())
                        self._db = None

                    async def _ensure_connection(self) -> None:
                        if self._db is not None:
                            return
                        import rocksdb

                        opts = rocksdb.Options(create_if_missing=bool(self._config.create_if_missing))
                        self._db = rocksdb.DB(str(self._config.path), opts)

                    async def write(self, key: str, data: Any) -> None:
                        await self._ensure_connection()
                        payload = data if isinstance(data, bytes) else str(data).encode()
                        self._db.put(key.encode(), payload)

                    async def read(self, key: str) -> Any:
                        await self._ensure_connection()
                        val = self._db.get(key.encode())
                        if val is None:
                            raise XWLocationError("not found")
                        return val

                connection_cls = RocksDBStorageConnection

            elif suffix == "redis_connector":
                module.REDIS_AVAILABLE = False
                module.REDIS_ASYNC = False
                try:
                    import redis as _redis  # noqa: F401

                    module.REDIS_AVAILABLE = True
                    try:
                        import redis.asyncio as _redis_async  # noqa: F401

                        module.REDIS_ASYNC = True
                    except ImportError:
                        module.REDIS_ASYNC = False
                except ImportError:
                    pass

                _cfg_red = cfg_cls

                class RedisStorageConnection:
                    def __init__(self, config: Any, data_format: str = "json") -> None:
                        if not isinstance(config, _cfg_red):
                            raise XWLocationError("Expected RedisConnectorConfig")
                        mod = sys.modules[module.__name__]
                        if not getattr(mod, "REDIS_AVAILABLE", False):
                            raise XWLocationError("redis package not installed")
                        self._config = config
                        self.data_format = data_format
                        self.connection_id = str(uuid.uuid4())
                        self._client = None

                    async def _get_client(self) -> Any:
                        mod = sys.modules[module.__name__]
                        if self._client is not None:
                            return self._client
                        if getattr(mod, "REDIS_ASYNC", False):
                            import redis.asyncio as redis_async

                            self._client = redis_async.Redis(
                                host=self._config.host or "localhost",
                                port=int(self._config.port or 6379),
                                db=int(getattr(self._config, "db", 0) or 0),
                                password=self._config.password,
                            )
                        else:
                            import redis as redis_sync

                            self._client = redis_sync.Redis(
                                host=self._config.host or "localhost",
                                port=int(self._config.port or 6379),
                                db=int(getattr(self._config, "db", 0) or 0),
                                password=self._config.password,
                            )
                        return self._client

                connection_cls = RedisStorageConnection

            elif suffix == "s3_connector":
                module.S3_AVAILABLE = False
                try:
                    import boto3 as _boto3  # noqa: F401

                    module.S3_AVAILABLE = True
                except ImportError:
                    pass

                _cfg_s3 = cfg_cls

                class S3StorageConnection:
                    def __init__(self, config: Any, data_format: str = "json") -> None:
                        if not isinstance(config, _cfg_s3):
                            raise XWLocationError("Expected S3ConnectorConfig")
                        mod = sys.modules[module.__name__]
                        if not getattr(mod, "S3_AVAILABLE", False):
                            raise XWLocationError("boto3 package not installed")
                        self._config = config
                        self.data_format = data_format
                        self.connection_id = str(uuid.uuid4())

                connection_cls = S3StorageConnection

            elif suffix == "dynamodb_connector":
                module.DYNAMODB_AVAILABLE = False
                try:
                    import boto3 as _boto3ddb  # noqa: F401

                    module.DYNAMODB_AVAILABLE = True
                except ImportError:
                    pass

                _cfg_dd = cfg_cls

                class DynamoDBStorageConnection:
                    def __init__(self, config: Any, data_format: str = "json") -> None:
                        if not isinstance(config, _cfg_dd):
                            raise XWLocationError("Expected DynamoDBConnectorConfig")
                        mod = sys.modules[module.__name__]
                        if not getattr(mod, "DYNAMODB_AVAILABLE", False):
                            raise XWLocationError("boto3 package not installed")
                        self._config = config
                        self.data_format = data_format
                        self._serializer_format = data_format
                        self.connection_id = str(uuid.uuid4())

                connection_cls = DynamoDBStorageConnection

            elif suffix == "documentdb_connector":
                module.MONGODB_AVAILABLE = False
                try:
                    import pymongo as _pymongo  # noqa: F401

                    module.MONGODB_AVAILABLE = True
                except ImportError:
                    pass

                _cfg_doc = cfg_cls

                class DocumentDBStorageConnection:
                    def __init__(self, config: Any, data_format: str = "json") -> None:
                        if not isinstance(config, _cfg_doc):
                            raise XWLocationError("Expected DocumentDBConnectorConfig")
                        mod = sys.modules[module.__name__]
                        if not getattr(mod, "MONGODB_AVAILABLE", False):
                            raise XWLocationError("MongoDB connector not available")
                        self._config = config
                        self.data_format = data_format
                        self._serializer_format = data_format
                        self.connection_id = str(uuid.uuid4())

                connection_cls = DocumentDBStorageConnection

            elif suffix == "gcs_connector":
                module.GCS_AVAILABLE = False
                try:
                    from google.cloud import storage as _gcs_storage  # noqa: F401

                    module.GCS_AVAILABLE = True
                except ImportError:
                    pass

                _cfg_gcs = cfg_cls

                class GCSStorageConnection:
                    def __init__(self, config: Any, data_format: str = "json") -> None:
                        if not isinstance(config, _cfg_gcs):
                            raise XWLocationError("Expected GCSConnectorConfig")
                        mod = sys.modules[module.__name__]
                        if not getattr(mod, "GCS_AVAILABLE", False):
                            raise XWLocationError("Google Cloud Storage client library not installed")
                        self._config = config
                        self.data_format = data_format
                        self._serializer_format = data_format
                        self.connection_id = str(uuid.uuid4())

                connection_cls = GCSStorageConnection

            elif suffix == "azure_blob_connector":
                module.AZURE_BLOB_AVAILABLE = False
                try:
                    import azure.storage.blob as _azblob  # noqa: F401

                    module.AZURE_BLOB_AVAILABLE = True
                except ImportError:
                    pass

                _cfg_az = cfg_cls

                class AzureBlobStorageConnection:
                    def __init__(self, config: Any, data_format: str = "json") -> None:
                        if not isinstance(config, _cfg_az):
                            raise XWLocationError("Expected AzureBlobConnectorConfig")
                        mod = sys.modules[module.__name__]
                        if not getattr(mod, "AZURE_BLOB_AVAILABLE", False):
                            raise XWLocationError("Azure Blob Storage SDK not installed")
                        self._config = config
                        self.data_format = data_format
                        self.connection_id = str(uuid.uuid4())

                connection_cls = AzureBlobStorageConnection

            setattr(module, cfg_cls.__name__, cfg_cls)
            setattr(module, connection_cls.__name__, connection_cls)
            setattr(module, strat_cls.__name__, strat_cls)
            setattr(module, f"{_snake_to_camel(suffix.replace('_connector', '').replace('_strategy', ''))}Connector", strat_cls)
            setattr(module, f"{_snake_to_camel(suffix)}Connection", connection_cls)

            def _dynamic_attr(attr_name: str):
                if attr_name.endswith("Config"):
                    return cfg_cls
                if attr_name.endswith("StorageConnection") or attr_name.endswith("Connection"):
                    return connection_cls
                if attr_name.endswith("Transaction"):
                    return connection_cls
                if attr_name.endswith("Connector") or attr_name.endswith("Strategy"):
                    return strat_cls
                raise AttributeError(attr_name)

            module.__getattr__ = _dynamic_attr  # type: ignore[attr-defined]

    if not any(type(f).__name__ == "_ConnectorImporter" for f in sys.meta_path):
        sys.meta_path.insert(0, _ConnectorImporter())


# errors, defs, contracts: real modules under src/exonware/xwstorage/ (importlib + xwlazy)

_register("exonware.xwstorage.connectors", {}, is_pkg=True)
_register("exonware.xwstorage.connectors.local_connector", {"LocalConnectorConfig": LocalConnectorConfig, "LocalStorageConnection": LocalStorageConnection})
_register("exonware.xwstorage.connectors.pool", {"ConnectionPool": ConnectionPool, "ConnectionState": ConnectionState})
from exonware.xwstorage._acid_document_connection import ACIDDocumentConnection as _ACIDDocumentConnection

_register(
    "exonware.xwstorage.connectors.acid_document_connection",
    {"ACIDDocumentConnection": _ACIDDocumentConnection},
)
cfg_x, conn_x, _ = _connector_classes("connector_x")
_register(
    "exonware.xwstorage.connectors.connector_x",
    {
        cfg_x.__name__: cfg_x,
        conn_x.__name__: conn_x,
        "LocalXConnectorConfig": cfg_x,
        "LocalXStorageConnection": conn_x,
        "MySQLXConnectorConfig": cfg_x,
        "MySQLXStorageConnection": conn_x,
    },
)
_install_connector_importer()

# core.* : real package core/ (see core/lock_manager.py)

_register("exonware.xwstorage.facade", {"XWConnection": XWConnection, "XWStorage": XWStorage, "XWDB": XWDB})
_register("exonware.xwstorage.auth", {"MockAuthProvider": MockAuthProvider})

# data.* : real package data/ (see data/counters.py); virtual submodules still registered below
_register("exonware.xwstorage.data.timeseries_compression", {"TimeSeriesCompression": TimeSeriesCompression})

_register("exonware.xwstorage.formats", {}, is_pkg=True)
_register("exonware.xwstorage.formats.adapter", {"FormatAdapter": FormatAdapter})
_register("exonware.xwstorage.formats.registry", {"FormatRegistry": FormatRegistry})

_register("exonware.xwstorage.indexes", {
    "BTreeIndex": BTreeIndex,
    "HashIndex": HashIndex,
    "StaticIndex": StaticIndex,
    "CompositeIndex": CompositeIndex,
    "FullTextIndex": FullTextIndex,
    "LSMTreeIndex": LSMTreeIndex,
    "RTreeIndex": RTreeIndex,
    "UniversalIndex": UniversalIndex,
    "VectorIndex": VectorIndex,
    "SecondaryIndexManager": SecondaryIndexManager,
}, is_pkg=True)
_register("exonware.xwstorage.indexes.btree", {"BTreeIndex": BTreeIndex})
_register("exonware.xwstorage.indexes.hash_index", {"HashIndex": HashIndex})
_register("exonware.xwstorage.indexes.static_index", {"StaticIndex": StaticIndex})
_register("exonware.xwstorage.indexes.static_index", {"StaticIndex": StaticIndex, "CodeExecutionTimeout": CodeExecutionTimeout, "CodeExecutionSecurityError": CodeExecutionSecurityError})
_register("exonware.xwstorage.indexes.composite_index", {"CompositeIndex": CompositeIndex})
_register("exonware.xwstorage.indexes.fulltext", {"FullTextIndex": FullTextIndex})
_register("exonware.xwstorage.indexes.lsm_tree", {"LSMTreeIndex": LSMTreeIndex})
_register("exonware.xwstorage.indexes.rtree", {"RTreeIndex": RTreeIndex})
_register("exonware.xwstorage.indexes.secondary_index_manager", {"SecondaryIndexManager": SecondaryIndexManager})
_register(
    "exonware.xwstorage.indexes.secondary_index_manager",
    {
        "SecondaryIndexManager": SecondaryIndexManager,
        "IndexRecommendation": IndexRecommendation,
        "QueryPattern": QueryPattern,
    },
)
_register("exonware.xwstorage.indexes.universal_index", {"UniversalIndex": UniversalIndex})
_register("exonware.xwstorage.indexes.vector_index", {"VectorIndex": VectorIndex})

_register("exonware.xwstorage.operations", {}, is_pkg=True)
_register("exonware.xwstorage.operations.batch", {"BatchOperations": BatchOperations})
_register("exonware.xwstorage.operations.backup", {"BackupManager": BackupManager})
_register("exonware.xwstorage.operations.migration", {"MigrationManager": MigrationManager})

_register("exonware.xwstorage.performance", {}, is_pkg=True)
_register("exonware.xwstorage.performance.cache", {"CacheManager": CacheManager, "EvictionPolicy": EvictionPolicy, "WritePolicy": WritePolicy})
_register("exonware.xwstorage.performance.strategies", {"StrategyManager": StrategyManager})

_register("exonware.xwstorage.policies", {}, is_pkg=True)
_register("exonware.xwstorage.policies.context", {"PolicyContext": PolicyContext})
_register("exonware.xwstorage.policies.rls", {
    "RLSPolicy": RLSPolicy,
    "default_tenant_predicate": default_tenant_predicate,
    "default_role_predicate": default_role_predicate,
})

_register("exonware.xwstorage.query", {}, is_pkg=True)
_register("exonware.xwstorage.query.adapter", {"QueryAdapter": QueryAdapter})
_register("exonware.xwstorage.query.executor", {"QueryExecutor": QueryExecutor})
_register("exonware.xwstorage.query.document_translation", {"DocumentTranslator": DocumentTranslator, "DocumentQueryTranslator": DocumentQueryTranslator})
_register("exonware.xwstorage.query.optimizer", {"StorageQueryOptimizer": StorageQueryOptimizer})
_register("exonware.xwstorage.query.joins", {"JoinProcessor": object})

_register("exonware.xwstorage.realtime", {}, is_pkg=True)
_register("exonware.xwstorage.realtime.changefeeds", {"ChangeFeedManager": ChangeFeedManager, "Changefeed": Changefeed})
_register("exonware.xwstorage.realtime.listeners", {"ListenerManager": ListenerManager, "ChangeListener": ChangeListener})
_register("exonware.xwstorage.realtime.websocket", {"WebSocketManager": WebSocketManager})

_register("exonware.xwstorage.security", {}, is_pkg=True)
_register("exonware.xwstorage.security.access_control", {"AccessControlManager": AccessControlManager})
_register("exonware.xwstorage.security.audit", {"AuditLogger": AuditLogger})
_register("exonware.xwstorage.security.encryption", {"EncryptionManager": EncryptionManager})
_register(
    "exonware.xwstorage.security.encryption_at_rest",
    {
        "EncryptionAtRestManager": EncryptionAtRestManager,
        "EncryptionAtRest": EncryptionAtRest,
        "EncryptionAlgorithm": EncryptionAlgorithm,
        "LocalKeyManager": LocalKeyManager,
        "EncryptionMetadata": EncryptionMetadata,
    },
)
_register("exonware.xwstorage.security.tls_config", {"TLSConfig": TLSConfig, "TLSVersion": TLSVersion, "TLSConfigManager": TLSConfigManager})

_register("exonware.xwstorage.transactions", {}, is_pkg=True)
_register("exonware.xwstorage.transactions.manager", {"TransactionManager": TransactionManager, "Transaction": Transaction, "TransactionState": TransactionState})
_register("exonware.xwstorage.transactions.mvcc", {"MVCCManager": MVCCManager, "Version": Version, "VersionStatus": VersionStatus, "ConflictError": ConflictError})
_register(
    "exonware.xwstorage.transactions.deadlock",
    {
        "DeadlockDetector": DeadlockDetector,
        "VictimSelectionStrategy": VictimSelectionStrategy,
        "TransactionMetadata": TransactionMetadata,
    },
)
_register("exonware.xwstorage.transactions.isolation", {"IsolationManager": IsolationManager})

_register("exonware.xwstorage.utils", {"get_google_auth_config": get_google_auth_config}, is_pkg=True)
_register("exonware.xwstorage.utils.json_utils", {"loads": loads, "dumps": dumps, "load": load, "dump": dump, "load_file": load_file, "dump_file": dump_file})
_register("exonware.xwstorage.replication", {}, is_pkg=True)
_register("exonware.xwstorage.replication.primary_replica", {"PrimaryReplicaConnection": PrimaryReplicaConnection})


class _ConnectorRegistryFacade:
    __slots__ = ("_by_name",)

    def __init__(self) -> None:
        self._by_name: dict[str, Any] = {"local": LocalStorageConnection}

    def get_connector(self, name: str) -> Any:
        return self._by_name.get(name)


def get_connector_registry() -> _ConnectorRegistryFacade:
    return _ConnectorRegistryFacade()


_register("exonware.xwstorage.registry", {"get_connector_registry": get_connector_registry})

# Keep public exports at package level for tests importing from exonware.xwstorage.
__all__ = [
    "XWConnection",
    "XWStorage",
    "XWDB",
    "XWStorageError",
    "XWConnectionError",
    "XWLocationError",
    "IsolationLevel",
    "TriggerEvent",
]
