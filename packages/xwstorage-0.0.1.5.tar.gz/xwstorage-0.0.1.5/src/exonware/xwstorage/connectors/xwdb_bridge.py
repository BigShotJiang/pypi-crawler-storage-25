# exonware/xwstorage/src/exonware/xwstorage/connectors/xwdb_bridge.py
"""
Attach **exonware-xwstorage** to a database or engine surface over **HTTP**.

``exonware-xwstorage`` does not declare ``exonware-xwdb`` as a dependency. Treat any
database product as a separate service with a documented HTTP API (for example an
``*-api`` host on XWApiServer). Use ``XWDBRemoteConfig`` and your HTTP client of choice.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


@dataclass(frozen=True, slots=True)
class XWDBRemoteConfig:
    """HTTP client configuration for a remote database / engine deployment."""

    base_url: str
    """Scheme + host (+ optional port), no trailing slash, e.g. ``https://db.example.com``."""

    timeout_s: float = 30.0


class XWDBBridgeMode(str, Enum):
    """Where the database engine is resolved for this storage deployment."""

    REMOTE_API = "remote_api"


def load_xwdb_package() -> Any:
    """
    .. deprecated::
        In-process coupling to a database product wheel was removed. Use
        ``XWDBBridgeMode.REMOTE_API`` with ``XWDBRemoteConfig`` and HTTPS against
        your engine's API.
    """
    raise ImportError(
        "exonware-xwstorage does not load database products in-process. "
        "Use XWDBBridgeMode.REMOTE_API with XWDBRemoteConfig (base URL + HTTP client) "
        "against your database or engine deployment."
    )
