# exonware/xwstorage/src/exonware/xwstorage/connectors/__init__.py
"""Bridge contracts for attaching storage to remote database/engine HTTP APIs (REF_41 §6).

For eager first-party imports (xwjson … xwaction), use optional
``import exonware.xwstorage.stack`` after installing the ``[stack]`` or ``[full]`` extra.
"""

from __future__ import annotations

from .xwdb_bridge import XWDBBridgeMode, XWDBRemoteConfig, load_xwdb_package

__all__ = ["XWDBBridgeMode", "XWDBRemoteConfig", "load_xwdb_package"]
