"""
Smoke test for a built timeSpace package.

Run after installing from sdist/wheel (not editable mode):
    make test-package
"""

import sys
import warnings


def main():
    errors = []

    # ── Version and root ─────────────────────────────────────────────
    import timeSpace

    print(f"timeSpace {timeSpace.__version__}")
    print(f"Installed at: {timeSpace.PROJECT_ROOT}")

    # ── Public API imports ───────────────────────────────────────────
    try:
        from timeSpace import (
            create_space_time_figure,
            add_magnitude_labels,
            add_processes,
            add_predefined_processes,
            add_diffusion_lines,
            add_light_cone,
            add_legend,
            create_ellipse_data,
            calculate_diffusion_length,
            calculate_sphere_volume,
            classify_process_geometry,
            transform_process_response_sheet,
            transform_predefined_processes,
            transform_measurement_sheet,
            add_measurements,
            add_grouped_measurement,
            resolve_label_overlaps,
            count_overlaps,
            extract_google_sheet,
        )

        print(f"Public API: 19 functions imported OK")
    except ImportError as e:
        errors.append(f"Import error: {e}")

    # ── Bundled CSV data ─────────────────────────────────────────────
    csv_dir = timeSpace.PROJECT_ROOT / "data" / "datasets"
    csvs = sorted(csv_dir.glob("*.csv"))
    print(f"CSV files: {len(csvs)}")
    if len(csvs) < 11:
        errors.append(f"Expected at least 11 CSVs, got {len(csvs)}")

    # ── No SyntaxWarning on import ───────────────────────────────────
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        from timeSpace import constants

        syntax_warns = [x for x in w if issubclass(x.category, SyntaxWarning)]
        if syntax_warns:
            errors.append(f"SyntaxWarnings: {syntax_warns}")
        else:
            print("No SyntaxWarnings")

    # ── Build a plot from bundled data ───────────────────────────────
    import pandas as pd
    from timeSpace.etl import transform_predefined_processes

    df = pd.read_csv(csv_dir / "stommel_boyd2015_volumes.csv")
    transformed = transform_predefined_processes(df)
    print(f"Loaded {len(transformed)} processes from Boyd (2015)")

    p = create_space_time_figure()
    p = add_magnitude_labels(p)
    p = add_diffusion_lines(p)
    p = add_predefined_processes(p, transformed)
    p = add_legend(p)
    print("Built Stommel diagram OK")

    # ── Save HTML ────────────────────────────────────────────────────
    from bokeh.io import save, output_file

    output_file("test_stommel.html", title="timeSpace local test", mode="inline")
    save(p)
    print("Saved: test_stommel.html")

    # ── Result ───────────────────────────────────────────────────────
    if errors:
        print(f"\nFAILED — {len(errors)} errors:")
        for e in errors:
            print(f"  {e}")
        return 1
    else:
        print("\nAll checks passed. Open test_stommel.html in a browser to verify.")
        return 0


if __name__ == "__main__":
    sys.exit(main())
