from groundx import GroundX
from openai import OpenAI


class sfsclient:

    def __init__(self):

        # GroundX
        self.groundx = GroundX(
            api_key="509b4b21-9f98-4db9-a683-8faa72391e14"
        )

        # GitHub Models
        self.github_client = OpenAI(
            api_key="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",
            base_url="https://models.github.ai/inference"
        )

        self.content_id = 28141

    def ask(self, query: str):

        try:

            # Retrieve relevant chunks
            response = self.groundx.search.content(
                id=self.content_id,
                query=query
            )

            # Build context
            context = ""

            for item in response.search.results[:3]:
                context += item.text + "\n"

            # Ask GitHub-hosted GPT
            completion = self.github_client.chat.completions.create(
                model="openai/gpt-4o-mini",
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Answer briefly and clearly using the provided context."
                        )
                    },
                    {
                        "role": "user",
                        "content": f"""
Context:
{context}

Question:
{query}
"""
                    }
                ],
                temperature=0.3,
                max_tokens=200
            )

            return completion.choices[0].message.content

        except Exception as e:

            return str(e)