# SFS AI

A lightweight RAG (Retrieval-Augmented Generation) Python package built using GroundX + GitHub Models.

`sfs_ai` allows you to query indexed documents using natural language and receive clean AI-generated answers instead of raw document chunks.

---

# Project Structure

```text
sfs-ai/
│
├── setup.py
├── README.md
├── requirements.txt
│
└── sfs_ai/
    ├── __init__.py
    └── client.py
```

---

# Quick Start

```python
from sfs_ai import sfsclient

sfs = sfsclient()

response = sfs.ask(
    "What is the revenue model of a restaurant?"
)

print(response)
```

---
# Books & Knowledge Sources Used

The ingestion and retrieval pipeline powering `sfs_ai` was built using curated hospitality, business strategy, forecasting, and operational management resources. These materials were indexed to improve contextual reasoning and answer generation for hospitality-related queries.

---

## Hospitality & Hotel Management

### Revenue Management and Pricing

#### Revenue Management for the Hospitality Industry
**Authors:** David K. Hayes and Allisha A. Miller

Focus areas:
- Dynamic pricing
- Demand forecasting
- Occupancy optimization
- Revenue strategy

---

### Customer Experience & Hospitality

#### The Heart of Hospitality
**Author:** Micah Solomon

Focus areas:
- Customer experience strategy
- Guest satisfaction
- Hospitality service excellence
- Brand loyalty

---

### Restaurant & Hospitality Leadership

#### Setting the Table
**Author:** Danny Meyer

Focus areas:
- Hospitality leadership
- Restaurant operations
- Team culture
- Customer-first service philosophy

---

## Business & Strategic Management

### Strategic Market Positioning

#### Blue Ocean Strategy
**Authors:** W. Chan Kim and Renée Mauborgne

Focus areas:
- Strategic differentiation
- Competitive market creation
- Hotel brand positioning
- Business innovation

---

### Competitive Analysis

#### Competitive Strategy
**Author:** Michael E. Porter

Focus areas:
- Industry competition
- Competitive advantage
- Strategic positioning
- Market analysis

---

### Innovation & Disruption

#### The Innovator's Dilemma
**Author:** Clayton M. Christensen

Focus areas:
- Innovation strategy
- Disruptive technologies
- Business transformation
- Emerging market adaptation

---

### Organizational Excellence

#### Good to Great
**Author:** Jim Collins

Focus areas:
- Organizational performance
- Leadership excellence
- Sustainable growth
- Business scalability

---

### Performance Measurement & OKRs

#### Measure What Matters
**Author:** John Doerr

Focus areas:
- OKRs (Objectives and Key Results)
- Performance systems
- Strategic execution
- Operational accountability

---

## Hospitality Business Frameworks

### Hospitality Strategic Management

#### Hospitality Strategic Management
**Authors:** Cathy A. Enz

Focus areas:
- Hospitality business frameworks
- Strategic planning
- Hotel operations management
- Service industry competitiveness

---

# Purpose of These Sources

These books and frameworks were indexed into the ingestion pipeline to provide:

- Better hospitality-specific reasoning
- Strategic business insights
- Revenue optimization knowledge
- Operational management intelligence
- Improved contextual retrieval for hotel and restaurant queries

The combined knowledge base enables `sfs_ai` to generate concise, context-aware responses for hospitality and business-related use cases.