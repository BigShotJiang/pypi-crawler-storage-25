from setuptools import setup, find_packages

setup(
    name="sfs_ai",
    version="1.1",
    packages=find_packages(),
    install_requires=[
        "groundx",
        "openai"
    ],
    author="Santhoshkumar K",
    description="RAG AI client using GroundX + GitHub Models",
    python_requires=">=3.9",
)