"""WebSocket recording server — receives events from the browser extension."""
from __future__ import annotations

import asyncio
import json
import signal
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

import websockets
from rich.console import Console

from .models import ActionEvent, Recording

console = Console()


class RecordingServer:
    """Listens for browser extension events on a local WebSocket port
    and writes them into a :class:`Recording` file on stop."""

    def __init__(
        self,
        port: int = 7892,
        output: str = "recording.json",
        name: Optional[str] = None,
        verbose: bool = True,
    ) -> None:
        self.port = port
        self.output = Path(output)
        self.name = name or self.output.stem
        self.verbose = verbose

        self.recording = Recording(
            id=datetime.now().strftime("%Y%m%d_%H%M%S"),
            name=self.name,
            created_at=datetime.now().isoformat(),
        )
        self._stop_event = asyncio.Event()

    # ── WebSocket handler ────────────────────────────────────────

    async def _handle_client(self, websocket) -> None:
        if self.verbose:
            console.print(
                "[green]  Browser connected[/green] — "
                "start interacting with the page in your browser"
            )

        try:
            async for raw in websocket:
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                msg_type = msg.get("type")

                if msg_type == "stop":
                    if self.verbose:
                        console.print("[yellow]  Recording stopped by extension[/yellow]")
                    self._stop_event.set()
                    break

                if msg_type == "event":
                    event = ActionEvent.from_dict(msg.get("data", {}))
                    self.recording.events.append(event)
                    if self.verbose:
                        self._log_event(event)

        except websockets.exceptions.ConnectionClosed:
            pass

    def _log_event(self, event: ActionEvent) -> None:
        el = event.element
        el_desc = ""
        if el:
            ident = (f"#{el.id}" if el.id else
                     (f".{el.class_name.split()[0]}" if el.class_name else ""))
            label = el.nearest_label or el.text[:40]
            el_desc = f"  [dim]<{el.tag}{ident}>[/dim]"
            if label:
                el_desc += f" [italic dim]{label}[/italic dim]"

        color = {
            "click": "cyan", "input": "blue", "change": "blue",
            "scroll": "dim", "keydown": "magenta",
            "navigate": "yellow", "note": "green", "page_load": "white",
        }.get(event.action, "white")

        val = ""
        if event.value is not None and event.action in ("input", "change"):
            val = f"  [dim]→ {str(event.value)[:30]}[/dim]"
        if event.key:
            val = f"  [dim]→ [{event.key}][/dim]"

        console.print(
            f"  [dim]{event.step:>4}[/dim]  [{color}]{event.action:<10}[/{color}]"
            f"{el_desc}{val}"
        )

    # ── Save ─────────────────────────────────────────────────────

    def save(self) -> Path:
        from .exporter import export_markdown
        self.output.parent.mkdir(parents=True, exist_ok=True)
        with open(self.output, "w", encoding="utf-8") as f:
            json.dump(self.recording.to_dict(), f, ensure_ascii=False, indent=2)
        md_path = self.output.with_suffix(".md")
        md_path.write_text(export_markdown(self.recording), encoding="utf-8")
        return self.output

    # ── Run ──────────────────────────────────────────────────────

    async def run(self) -> None:
        console.rule("[bold red]WebAct Kakashi recorder[/bold red]")
        console.print(f"  Listening on  [cyan]ws://localhost:{self.port}[/cyan]")
        console.print(f"  Output file   [cyan]{self.output}[/cyan]")
        console.print()
        console.print("  Steps:")
        console.print("    1. Install the kakashi browser extension (Chrome or Edge)")
        console.print("    2. Navigate to your target website")
        console.print("    3. Click [bold]Start Recording[/bold] in the extension popup")
        console.print("    4. Perform all actions you want to demonstrate")
        console.print("    5. Click [bold]Stop Recording[/bold] — the file is saved automatically")
        console.print()
        console.print("  Press [bold]Ctrl+C[/bold] to abort and save what has been recorded so far")
        console.rule()

        # Cross-platform Ctrl+C handling
        loop = asyncio.get_event_loop()
        if sys.platform != "win32":
            loop.add_signal_handler(signal.SIGINT, self._stop_event.set)
        else:
            signal.signal(signal.SIGINT, lambda s, f: self._stop_event.set())

        try:
            async with websockets.serve(
                self._handle_client,
                "localhost",
                self.port,
                ping_interval=None,   # extensions don't respond to pings
            ):
                await self._stop_event.wait()
        except asyncio.CancelledError:
            pass
        finally:
            saved = self.save()
            n = len(self.recording.events)
            console.print()
            console.print(f"[green]  Saved[/green] → [bold]{saved}[/bold]  ([dim]{n} steps[/dim])")
            console.print(f"[green]  Saved[/green] → [bold]{saved.with_suffix('.md')}[/bold]")
            console.print()
            console.print(f"  View:   [cyan]kakashi show {saved}[/cyan]")
            console.print(f"  Agent:  [cyan]kakashi export {saved} --format compact[/cyan]")
            console.rule()
