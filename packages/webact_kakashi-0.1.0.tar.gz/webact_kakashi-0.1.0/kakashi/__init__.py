"""WebAct Kakashi: Record human web interactions for AI agent automation.

Quick start
-----------
    # Start recording server (then use the browser extension)
    $ kakashi record --output my_workflow.json

    # In Python — load a recording and get agent context
    from kakashi import Recording

    recording = Recording.load("my_workflow.json")
    context = recording.to_agent_context()
    # Inject `context` into your agent's prompt alongside the task description

See https://github.com/your-org/WebAct Kakashi for full documentation.
"""

from .models import ActionEvent, BoundingBox, ElementInfo, Modifiers, Recording
from .exporter import export_compact, export_json, export_markdown

__version__ = "0.1.0"

__all__ = [
    # Core models
    "Recording",
    "ActionEvent",
    "ElementInfo",
    "BoundingBox",
    "Modifiers",
    # Export helpers
    "export_json",
    "export_markdown",
    "export_compact",
]
