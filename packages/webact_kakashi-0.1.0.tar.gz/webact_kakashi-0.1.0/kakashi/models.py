"""Data models for WebAct Kakashi recordings."""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class BoundingBox:
    x: float
    y: float
    width: float
    height: float


@dataclass
class Modifiers:
    ctrl: bool = False
    shift: bool = False
    alt: bool = False
    meta: bool = False


@dataclass
class ElementInfo:
    tag: str
    id: Optional[str]
    class_name: str
    text: str
    value: Optional[str]
    css_selector: str
    xpath: str
    attributes: Dict[str, str]
    bounding_box: BoundingBox
    nearest_label: str
    is_visible: bool = True

    @classmethod
    def from_dict(cls, d: dict) -> "ElementInfo":
        bb = d.get("bounding_box", {})
        return cls(
            tag=d.get("tag", ""),
            id=d.get("id"),
            class_name=d.get("class_name", ""),
            text=d.get("text", ""),
            value=d.get("value"),
            css_selector=d.get("css_selector", ""),
            xpath=d.get("xpath", ""),
            attributes=d.get("attributes", {}),
            bounding_box=BoundingBox(**bb) if isinstance(bb, dict) else BoundingBox(0, 0, 0, 0),
            nearest_label=d.get("nearest_label", ""),
            is_visible=d.get("is_visible", True),
        )

    def to_dict(self) -> dict:
        return asdict(self)

    def best_locator(self) -> str:
        """Return the most stable locator for this element."""
        attrs = self.attributes
        if self.id:
            return f"#{self.id}"
        if attrs.get("data-testid"):
            return f'[data-testid="{attrs["data-testid"]}"]'
        if attrs.get("name"):
            return f'[name="{attrs["name"]}"]'
        return self.css_selector


@dataclass
class ActionEvent:
    step: int
    action: str  # click | input | change | scroll | keydown | navigate | page_load | note
    timestamp: str
    url: str
    page_title: str
    element: Optional[ElementInfo] = None
    value: Optional[str] = None        # for input/change
    scroll_x: Optional[float] = None  # for scroll
    scroll_y: Optional[float] = None
    key: Optional[str] = None         # for keydown
    modifiers: Optional[Modifiers] = None
    note: Optional[str] = None
    screenshot: Optional[str] = None  # base64, optional

    @classmethod
    def from_dict(cls, d: dict) -> "ActionEvent":
        el = d.get("element")
        mods = d.get("modifiers")
        return cls(
            step=d.get("step", 0),
            action=d.get("action", ""),
            timestamp=d.get("timestamp", ""),
            url=d.get("url", ""),
            page_title=d.get("page_title", ""),
            element=ElementInfo.from_dict(el) if el else None,
            value=d.get("value"),
            scroll_x=d.get("scroll_x"),
            scroll_y=d.get("scroll_y"),
            key=d.get("key"),
            modifiers=Modifiers(**mods) if isinstance(mods, dict) else None,
            note=d.get("note"),
            screenshot=d.get("screenshot"),
        )

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Recording:
    id: str
    name: str
    created_at: str
    events: List[ActionEvent] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    # ── Serialization ────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "created_at": self.created_at,
            "metadata": self.metadata,
            "events": [e.to_dict() for e in self.events],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Recording":
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            created_at=d.get("created_at", ""),
            events=[ActionEvent.from_dict(e) for e in d.get("events", [])],
            metadata=d.get("metadata", {}),
        )

    @classmethod
    def load(cls, path: str) -> "Recording":
        with open(path, encoding="utf-8") as f:
            return cls.from_dict(json.load(f))

    def save(self, path: str) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)

    # ── Agent context ────────────────────────────────────────────

    def to_agent_context(self, max_steps: Optional[int] = None) -> str:
        """Generate an LLM-friendly context string from this recording.

        Feed this into your agent's prompt alongside the automation task.
        The agent should use it as a reference for element locators,
        NOT as a script to replay step-by-step.
        """
        header = (
            f"## Web Interaction Reference: {self.name}\n\n"
            "This context was captured from a human manually operating a browser.\n"
            "Each step shows: the action taken, the target element, and reliable locators.\n"
            "Use the CSS/XPath selectors below as trusted references when locating elements.\n"
            "Do NOT replay these steps literally — decide your own action sequence for the task.\n\n"
        )

        events = self.events[:max_steps] if max_steps else self.events
        parts = []

        for event in events:
            lines = [f"[Step {event.step}] {event.action.upper()}  {event.url}"]
            el = event.element

            if el:
                lines.append(f"  Tag:      <{el.tag}>")
                if el.nearest_label:
                    lines.append(f"  Label:    {el.nearest_label}")
                if el.text:
                    lines.append(f"  Text:     {el.text[:80]}")
                if el.id:
                    lines.append(f"  ID:       #{el.id}")
                lines.append(f"  CSS:      {el.css_selector}")
                lines.append(f"  XPath:    {el.xpath}")
                for attr in ("name", "type", "data-testid", "placeholder", "aria-label", "href", "role"):
                    val = el.attributes.get(attr)
                    if val:
                        lines.append(f"  {attr}:  {val}")

            if event.value is not None:
                lines.append(f"  Value:    {event.value}")
            if event.key:
                lines.append(f"  Key:      {event.key}")
            if event.scroll_y is not None:
                lines.append(f"  Scroll:   x={event.scroll_x} y={event.scroll_y}")
            if event.note:
                lines.append(f"  NOTE:     {event.note}")

            parts.append("\n".join(lines))

        return header + "\n\n".join(parts)
