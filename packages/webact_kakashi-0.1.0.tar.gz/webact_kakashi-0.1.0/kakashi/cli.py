"""CLI entry point for WebAct Kakashi."""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.syntax import Syntax
from rich.table import Table

console = Console()


@click.group()
@click.version_option("0.1.0", prog_name="kakashi")
def main() -> None:
    """WebAct Kakashi — Record human web interactions for AI agent automation.

    \b
    Quick start:
      1. kakashi record --output my_workflow.json
      2. Install the browser extension, click Start Recording
      3. Perform your demo actions in the browser
      4. Click Stop Recording — file is saved automatically
      5. kakashi show my_workflow.json
    """


# ── record ────────────────────────────────────────────────────────────────────


@main.command()
@click.option("--output", "-o", default="recording.json", show_default=True,
              help="Path for the output recording file.")
@click.option("--port", "-p", default=7892, show_default=True,
              help="Local WebSocket port the extension connects to.")
@click.option("--name", "-n", default=None,
              help="Human-readable name for this recording.")
@click.option("--quiet", "-q", is_flag=True,
              help="Suppress per-step logging.")
def record(output: str, port: int, name: str | None, quiet: bool) -> None:
    """Start the recording server and wait for the browser extension."""
    from .server import RecordingServer

    server = RecordingServer(port=port, output=output, name=name, verbose=not quiet)
    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        pass


# ── show ──────────────────────────────────────────────────────────────────────


@main.command()
@click.argument("recording_file", type=click.Path(exists=True))
def show(recording_file: str) -> None:
    """Display a recording as a formatted table."""
    from .models import Recording

    r = Recording.load(recording_file)

    console.print()
    console.print(f"[bold]Recording:[/bold] {r.name}")
    console.print(f"[dim]ID:[/dim]       {r.id}")
    console.print(f"[dim]Created:[/dim]  {r.created_at}")
    console.print(f"[dim]Steps:[/dim]    {len(r.events)}")
    console.print()

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold", expand=False)
    table.add_column("#", style="dim", width=4)
    table.add_column("Action", width=10)
    table.add_column("Element / Label", width=34)
    table.add_column("Value / Key", width=22)
    table.add_column("URL", width=36)

    for ev in r.events:
        el = ev.element
        el_desc = ""
        if el:
            ident = f"#{el.id}" if el.id else el.css_selector[:28]
            label = (el.nearest_label or el.text)[:26]
            el_desc = f"[bold]{el.tag}[/bold] [dim]{ident}[/dim]"
            if label:
                el_desc += f"\n[italic dim]{label}[/italic dim]"

        val = ""
        if ev.value is not None:
            val = str(ev.value)[:22]
        elif ev.key:
            val = f"[{ev.key}]"
        elif ev.note:
            val = f"NOTE: {ev.note[:16]}"

        url_short = ev.url.replace("https://", "").replace("http://", "")[:36]

        color = {
            "click": "cyan", "input": "blue", "change": "blue",
            "scroll": "dim", "keydown": "magenta",
            "navigate": "yellow", "note": "green",
        }.get(ev.action, "white")

        table.add_row(
            str(ev.step),
            f"[{color}]{ev.action}[/{color}]",
            el_desc,
            val,
            f"[dim]{url_short}[/dim]",
        )

    console.print(table)
    console.print()


# ── export ────────────────────────────────────────────────────────────────────


@main.command()
@click.argument("recording_file", type=click.Path(exists=True))
@click.option(
    "--format", "-f", "fmt",
    type=click.Choice(["json", "markdown", "compact"]),
    default="markdown", show_default=True,
    help=(
        "json: full JSON dump  |  "
        "markdown: human-readable doc  |  "
        "compact: trimmed JSON for LLM context"
    ),
)
@click.option("--output", "-o", default=None,
              help="Output file path.  Defaults to stdout.")
@click.option("--max-steps", default=None, type=int,
              help="Only export the first N steps.")
def export(recording_file: str, fmt: str, output: str | None, max_steps: int | None) -> None:
    """Export a recording to JSON, Markdown, or compact LLM context."""
    from .models import Recording
    from .exporter import export_json, export_markdown, export_compact

    r = Recording.load(recording_file)
    if max_steps:
        r.events = r.events[:max_steps]

    if fmt == "json":
        content = export_json(r)
    elif fmt == "markdown":
        content = export_markdown(r)
    else:
        content = export_compact(r)

    if output:
        Path(output).write_text(content, encoding="utf-8")
        console.print(f"[green]Exported[/green] → {output}  ([dim]{len(content)} chars[/dim])")
    else:
        if fmt in ("json", "compact"):
            console.print(Syntax(content, "json", theme="monokai"))
        else:
            print(content)


# ── context (shortcut for agents) ────────────────────────────────────────────


@main.command()
@click.argument("recording_file", type=click.Path(exists=True))
@click.option("--output", "-o", default=None,
              help="Write context to file instead of stdout.")
@click.option("--max-steps", default=None, type=int,
              help="Limit to the first N steps.")
def context(recording_file: str, output: str | None, max_steps: int | None) -> None:
    """Generate agent-ready context from a recording.

    This is the primary command for feeding a recording into an AI agent.
    The output is a plain-text block describing element locators and actions.

    \b
    Example (Python):
        from kakashi import Recording
        ctx = Recording.load("workflow.json").to_agent_context()
        # inject ctx into your agent's system prompt
    """
    from .models import Recording

    r = Recording.load(recording_file)
    text = r.to_agent_context(max_steps=max_steps)

    if output:
        Path(output).write_text(text, encoding="utf-8")
        console.print(f"[green]Context written[/green] → {output}")
    else:
        print(text)


if __name__ == "__main__":
    main()
