"""Export recordings to various formats."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Union

from .models import ActionEvent, Recording


# ── JSON ─────────────────────────────────────────────────────────────────────


def export_json(recording: Recording, pretty: bool = True) -> str:
    """Full JSON dump — all fields preserved."""
    return json.dumps(recording.to_dict(), ensure_ascii=False, indent=2 if pretty else None)


# ── Markdown ──────────────────────────────────────────────────────────────────


def export_markdown(recording: Recording) -> str:
    """Human-readable Markdown — great for documentation or review."""
    lines = [
        f"# Recording: {recording.name}",
        "",
        f"**ID:** `{recording.id}`  ",
        f"**Created:** {recording.created_at}  ",
        f"**Steps:** {len(recording.events)}",
        "",
        "---",
        "",
    ]

    for event in recording.events:
        lines += [
            f"## Step {event.step} — {_action_label(event)}",
            "",
            f"**Action:** `{event.action}`  ",
            f"**URL:** {event.url}  ",
            f"**Page:** {event.page_title}  ",
            f"**Time:** {event.timestamp}",
            "",
        ]

        el = event.element
        if el:
            tag_str = f"<{el.tag}"
            if el.id:
                tag_str += f' id="{el.id}"'
            if el.class_name:
                tag_str += f' class="{el.class_name}"'
            tag_str += ">"

            lines += [
                "### Element",
                "",
                f"```html",
                tag_str,
                "```",
                "",
            ]

            if el.nearest_label:
                lines.append(f"**Label / Placeholder:** {el.nearest_label}  ")
            if el.text:
                lines.append(f"**Visible text:** {el.text[:200]}  ")
            lines.append("")

            lines += [
                "**Locators:**",
                "",
                "| Method | Selector |",
                "|--------|----------|",
            ]
            if el.id:
                lines.append(f"| CSS (id) | `#{el.id}` |")
            lines.append(f"| CSS | `{el.css_selector}` |")
            lines.append(f"| XPath | `{el.xpath}` |")
            for attr in ("data-testid", "name", "aria-label", "placeholder", "role"):
                val = el.attributes.get(attr)
                if val:
                    lines.append(f"| `[{attr}]` | `{val}` |")

            if el.bounding_box:
                bb = el.bounding_box
                lines.append(
                    f"| Position | x={bb.x} y={bb.y} w={bb.width} h={bb.height} |"
                )
            lines.append("")

        if event.value is not None and event.action in ("input", "change"):
            lines += [f"**Input value:** `{event.value}`", ""]

        if event.key:
            mods_str = ""
            if event.modifiers:
                active = [k for k, v in vars(event.modifiers).items() if v]
                if active:
                    mods_str = f"  (modifiers: {', '.join(active)})"
            lines += [f"**Key pressed:** `{event.key}`{mods_str}", ""]

        if event.scroll_x is not None:
            lines += [f"**Scroll position:** x={event.scroll_x}  y={event.scroll_y}", ""]

        if event.note:
            lines += [f"> **Note:** {event.note}", ""]

        lines += ["---", ""]

    return "\n".join(lines)


# ── Compact (for LLM context) ─────────────────────────────────────────────────


def export_compact(recording: Recording) -> str:
    """Compact JSON optimised for LLM context window.

    Strips screenshots, trims verbose fields.  Feed this directly into
    an agent prompt alongside your automation task description.
    """
    events = []
    for event in recording.events:
        d: dict = {
            "step": event.step,
            "action": event.action,
            "url": event.url,
            "page": event.page_title,
        }

        if event.element:
            el = event.element
            ed: dict = {
                "tag": el.tag,
                "css": el.css_selector,
                "xpath": el.xpath,
            }
            if el.id:
                ed["id"] = el.id
            label = el.nearest_label or el.text[:60]
            if label:
                ed["label"] = label
            for attr in ("name", "type", "data-testid", "placeholder", "aria-label", "href", "role"):
                if el.attributes.get(attr):
                    ed[attr] = el.attributes[attr]
            d["element"] = {k: v for k, v in ed.items() if v}

        if event.value is not None:
            d["value"] = event.value
        if event.key:
            d["key"] = event.key
        if event.scroll_y is not None:
            d["scroll"] = {"x": event.scroll_x, "y": event.scroll_y}
        if event.note:
            d["note"] = event.note

        events.append(d)

    payload = {
        "recording": recording.name,
        "created_at": recording.created_at,
        "total_steps": len(events),
        "note": (
            "Use element selectors as trusted locators. "
            "Do NOT replay these steps literally — use your own judgment."
        ),
        "events": events,
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


# ── Helpers ───────────────────────────────────────────────────────────────────


def _action_label(event: ActionEvent) -> str:
    label_map = {
        "click": "Click",
        "input": "Input text",
        "change": "Change value",
        "scroll": "Scroll",
        "keydown": "Press key",
        "navigate": "Navigate",
        "page_load": "Page load",
        "note": "Note",
    }
    base = label_map.get(event.action, event.action.capitalize())
    if event.element:
        hint = event.element.nearest_label or event.element.text[:40] or event.element.tag
        return f"{base}: {hint}"
    if event.key:
        return f"{base}: {event.key}"
    return base


def save_export(content: str, path: Union[str, Path]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
