"""Basic tests for the WebAct Kakashi Python library."""
import json
import tempfile
from pathlib import Path

import pytest

from kakashi import Recording, export_compact, export_json, export_markdown
from kakashi.models import ActionEvent, BoundingBox, ElementInfo, Modifiers


# ── Fixtures ──────────────────────────────────────────────────────────────────


def make_element(
    tag="button",
    id="submit-btn",
    text="Submit",
    css="#submit-btn",
    xpath='//*[@id="submit-btn"]',
    label="Submit Order",
    attrs=None,
) -> ElementInfo:
    return ElementInfo(
        tag=tag,
        id=id,
        class_name="btn btn-primary",
        text=text,
        value=None,
        css_selector=css,
        xpath=xpath,
        attributes=attrs or {"type": "submit"},
        bounding_box=BoundingBox(x=100, y=200, width=120, height=40),
        nearest_label=label,
        is_visible=True,
    )


def make_recording() -> Recording:
    r = Recording(
        id="test_20260405",
        name="Login Flow",
        created_at="2026-04-05T10:00:00",
    )

    r.events.append(ActionEvent(
        step=1,
        action="page_load",
        timestamp="2026-04-05T10:00:01Z",
        url="https://example.com/login",
        page_title="Login — Example",
    ))

    r.events.append(ActionEvent(
        step=2,
        action="input",
        timestamp="2026-04-05T10:00:05Z",
        url="https://example.com/login",
        page_title="Login — Example",
        element=make_element(
            tag="input",
            id="username",
            text="",
            css="input[name=\"username\"]",
            xpath='//input[@name="username"]',
            label="Username",
            attrs={"type": "text", "name": "username", "placeholder": "Username"},
        ),
        value="alice",
    ))

    r.events.append(ActionEvent(
        step=3,
        action="click",
        timestamp="2026-04-05T10:00:10Z",
        url="https://example.com/login",
        page_title="Login — Example",
        element=make_element(),
    ))

    r.events.append(ActionEvent(
        step=4,
        action="keydown",
        timestamp="2026-04-05T10:00:11Z",
        url="https://example.com/login",
        page_title="Login — Example",
        element=make_element(tag="input", id="password"),
        key="Enter",
        modifiers=Modifiers(),
    ))

    return r


# ── Model tests ───────────────────────────────────────────────────────────────


def test_recording_to_dict():
    r = make_recording()
    d = r.to_dict()
    assert d["id"] == "test_20260405"
    assert d["name"] == "Login Flow"
    assert len(d["events"]) == 4
    assert d["events"][1]["action"] == "input"
    assert d["events"][1]["value"] == "alice"


def test_recording_roundtrip():
    r = make_recording()
    r2 = Recording.from_dict(r.to_dict())

    assert r2.id == r.id
    assert r2.name == r.name
    assert len(r2.events) == len(r.events)

    ev = r2.events[1]
    assert ev.element.css_selector == 'input[name="username"]'
    assert ev.element.nearest_label == "Username"
    assert ev.element.attributes["type"] == "text"


def test_recording_save_load(tmp_path):
    r = make_recording()
    path = str(tmp_path / "test.json")
    r.save(path)
    r2 = Recording.load(path)
    assert r2.id == r.id
    assert len(r2.events) == len(r.events)


def test_element_best_locator():
    el = make_element(id="submit-btn")
    assert el.best_locator() == "#submit-btn"

    el_no_id = make_element(id=None, attrs={"data-testid": "submit"})
    assert el_no_id.best_locator() == '[data-testid="submit"]'

    el_name = make_element(id=None, attrs={"name": "submit"})
    assert el_name.best_locator() == '[name="submit"]'


# ── Export tests ──────────────────────────────────────────────────────────────


def test_export_json():
    r = make_recording()
    content = export_json(r)
    data = json.loads(content)
    assert data["id"] == "test_20260405"
    assert len(data["events"]) == 4


def test_export_markdown():
    r = make_recording()
    md = export_markdown(r)
    assert "# Recording: Login Flow" in md
    assert "#username" in md or 'input[name="username"]' in md
    assert "alice" in md
    assert "Enter" in md


def test_export_compact():
    r = make_recording()
    content = export_compact(r)
    data = json.loads(content)
    assert data["recording"] == "Login Flow"
    assert data["total_steps"] == 4
    assert data["events"][1]["value"] == "alice"
    # Screenshots should not be present (there are none in test data)
    for ev in data["events"]:
        assert "screenshot" not in ev


def test_export_compact_no_screenshot_field():
    """Compact export must not include screenshot even if present in source."""
    r = make_recording()
    r.events[0].screenshot = "data:image/png;base64,AAAA"  # simulate screenshot
    content = export_compact(r)
    data = json.loads(content)
    for ev in data["events"]:
        assert "screenshot" not in ev


# ── Agent context tests ───────────────────────────────────────────────────────


def test_agent_context_contains_selectors():
    r = make_recording()
    ctx = r.to_agent_context()
    assert "Web Interaction Reference" in ctx
    assert "#submit-btn" in ctx
    assert 'input[name="username"]' in ctx or "username" in ctx


def test_agent_context_max_steps():
    r = make_recording()
    ctx_full = r.to_agent_context()
    ctx_2 = r.to_agent_context(max_steps=2)
    assert len(ctx_2) < len(ctx_full)
    # Step 3 should not appear
    assert "Step 3" not in ctx_2


def test_agent_context_note_warning():
    """Context header must warn agent not to replay steps literally."""
    r = make_recording()
    ctx = r.to_agent_context()
    assert "Do NOT replay" in ctx or "do not" in ctx.lower()
