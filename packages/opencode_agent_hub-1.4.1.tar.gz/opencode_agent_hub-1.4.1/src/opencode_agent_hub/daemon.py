#!/usr/bin/env python3
# opencode-agent-hub - Multi-agent coordination daemon for OpenCode
# Copyright (c) 2025 xnoto
# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "requests",
#     "watchdog",
# ]
# ///
"""Agent Hub Daemon - Watch ~/.agent-hub/messages and inject into OpenCode sessions.

WARNING: USE AT YOUR OWN RISK. This daemon enables autonomous agent-to-agent
communication which triggers LLM API calls. The authors are not responsible
for any token usage, API costs, or other expenses incurred by running this
software. Enable rate limiting if you are concerned about runaway costs.

Features:
- Hub server management (auto-starts headless OpenCode server on port 4096)
- Session polling to detect new agents and inject orientation
- Push notifications to OpenCode sessions (always wake, always expect response)
- Thread management (auto-create, track, resolve)
- Garbage collection (expire stale messages/threads)
- Rate limiting (optional, via environment variables)
- Self-contained response instructions in every injection

Hub server:
- Daemon auto-starts `opencode serve --port 4096` if not already running
- Hub server uses the user's normal OpenCode config (no isolation)
- TUI instances discover and connect to the hub server for message injection
- Session discovery uses direct SQLite queries (hub API listing is stale)
- Daemon injects messages via POST /session/{id}/prompt_async

Wake behavior: ALL messages wake agents (noReply: false)
- Agents don't need hub protocol in their definitions
- Daemon injects full response instructions with each message
- Running daemon = opt-in to coordination

Session polling:
- Polls OpenCode /session endpoint periodically
- Auto-creates unique agent identity per session (from slug or session ID)
- Injects orientation message on first match (identifies agent, no action required)
- Routes messages to agents by session ID (not directory)
- Tracks oriented sessions to avoid re-injection
- Agents do NOT need to proactively sync - messages are pushed to them

Thread lifecycle:
- Messages without threadId get one auto-assigned
- Threads tracked in ~/.agent-hub/threads/
- Thread resolved when owner sends type="completion" with "RESOLVED" in content
- Threads expire when all participants are stale (>1hr lastSeen)
- Messages expire after 1 hour regardless
- Stale agents (>1hr lastSeen) are removed automatically
"""

import argparse
import json
import logging
import os
import queue
import shutil
import signal
import sqlite3
import subprocess
import sys
import threading
import time
import uuid
from contextlib import suppress
from dataclasses import dataclass

# For accessing package data files reliably across install methods (pip, deb, rpm, aur)
from importlib.resources import files
from pathlib import Path
from typing import Any, cast

import requests
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

# =============================================================================
# Atomic File Operations
# =============================================================================


def atomic_write_json(path: Path, data: Any, indent: int | None = 2) -> None:
    """Write JSON to file atomically using temp file + rename.

    This prevents readers from seeing partial/empty files during writes.
    POSIX guarantees rename() is atomic - readers see old or new, never partial.

    Args:
        path: Target file path
        data: JSON-serializable data
        indent: JSON indentation (None for compact, 2 for pretty-print)

    Raises:
        OSError: If write fails
    """
    json_str = json.dumps(data, indent=indent)
    temp_path = path.with_suffix(f".tmp.{os.getpid()}")

    try:
        # Write to temp file first
        temp_path.write_text(json_str, encoding="utf-8")

        # Atomic rename - readers see either old or new, never partial
        temp_path.rename(path)
    except Exception:
        # Clean up temp file on any error
        with suppress(OSError):
            temp_path.unlink()
        raise


# =============================================================================
# Configuration
# =============================================================================
# Precedence: environment variables > config file > defaults
# Config file: ~/.config/agent-hub-daemon/config.json

# Static paths (not configurable)
AGENT_HUB_DIR = Path.home() / ".agent-hub"
MESSAGES_DIR = AGENT_HUB_DIR / "messages"
ARCHIVE_DIR = MESSAGES_DIR / "archive"
THREADS_DIR = AGENT_HUB_DIR / "threads"
AGENTS_DIR = AGENT_HUB_DIR / "agents"
ORIENTED_SESSIONS_FILE = AGENT_HUB_DIR / "oriented_sessions.json"
OPENCODE_DATA_DIR = Path.home() / ".local/share/opencode"
OPENCODE_DB_PATH = OPENCODE_DATA_DIR / "opencode.db"
OPENCODE_STORAGE_DIR = OPENCODE_DATA_DIR / "storage"  # Watch all project subdirs, not just global
CONFIG_DIR = Path.home() / ".config" / "agent-hub-daemon"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _load_config_file() -> dict[str, Any]:
    """Load configuration from JSON file if it exists."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        return cast(dict[str, Any], json.loads(CONFIG_FILE.read_text()))
    except (json.JSONDecodeError, OSError):
        # Log warning later after logging is set up
        return {}


def _get_config_value(
    env_var: str,
    config_path: list[str],
    default: str | int | bool,
    config: dict[str, Any],
    type_: type = str,
) -> Any:
    """Get config value with precedence: env var > config file > default.

    Args:
        env_var: Environment variable name
        config_path: Path in config dict (e.g., ["rate_limit", "enabled"])
        default: Default value
        config: Loaded config dict
        type_: Expected type (str, int, or bool)
    """
    # Check environment variable first
    env_value = os.environ.get(env_var)
    if env_value is not None:
        if type_ is bool:
            return env_value.lower() in ("1", "true", "yes")
        elif type_ is int:
            return int(env_value)
        return env_value

    # Check config file - traverse path to get leaf value
    value: str | int | bool | dict | None = config
    for key in config_path:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return default

    # If we got a dict, the path didn't reach a leaf - return default
    if isinstance(value, dict):
        return default

    # Type coercion for config file values
    if type_ is bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ("1", "true", "yes")
    elif type_ is int:
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, str):
            return int(value)

    # Return value if it matches expected type, otherwise default
    if value is None:
        return default
    return cast("str | int | bool", value)


# Load config file once at module load
_CONFIG = _load_config_file()

# OpenCode connection
OPENCODE_PORT = int(_get_config_value("OPENCODE_PORT", ["opencode_port"], 4096, _CONFIG, int))
OPENCODE_URL = f"http://localhost:{OPENCODE_PORT}"
LOG_LEVEL = str(_get_config_value("AGENT_HUB_DAEMON_LOG_LEVEL", ["log_level"], "INFO", _CONFIG))

# Expiry/timing settings
MESSAGE_TTL_SECONDS = int(
    _get_config_value("AGENT_HUB_MESSAGE_TTL", ["gc", "message_ttl_seconds"], 3600, _CONFIG, int)
)
AGENT_STALE_SECONDS = int(
    _get_config_value("AGENT_HUB_AGENT_STALE", ["gc", "agent_stale_seconds"], 3600, _CONFIG, int)
)
GC_INTERVAL_SECONDS = int(
    _get_config_value("AGENT_HUB_GC_INTERVAL", ["gc", "interval_seconds"], 60, _CONFIG, int)
)
SESSION_POLL_SECONDS = int(
    _get_config_value("AGENT_HUB_SESSION_POLL", ["session", "poll_seconds"], 5, _CONFIG, int)
)
SESSION_CACHE_TTL = int(
    _get_config_value("AGENT_HUB_SESSION_CACHE_TTL", ["session", "cache_ttl"], 10, _CONFIG, int)
)
INJECTION_WORKERS = int(
    _get_config_value("AGENT_HUB_INJECTION_WORKERS", ["injection", "workers"], 4, _CONFIG, int)
)
INJECTION_RETRIES = int(
    _get_config_value("AGENT_HUB_INJECTION_RETRIES", ["injection", "retries"], 3, _CONFIG, int)
)
INJECTION_TIMEOUT = int(
    _get_config_value("AGENT_HUB_INJECTION_TIMEOUT", ["injection", "timeout"], 5, _CONFIG, int)
)
METRICS_INTERVAL = int(
    _get_config_value("AGENT_HUB_METRICS_INTERVAL", ["metrics_interval"], 30, _CONFIG, int)
)

# Orientation retry settings
# When a new session is oriented but never responds, retry the orientation injection
# up to ORIENTATION_RETRY_MAX times, waiting ORIENTATION_RETRY_DELAY seconds between attempts.
# This handles the case where an agent session is busy and misses the initial orientation.
ORIENTATION_RETRY_MAX = int(
    _get_config_value(
        "AGENT_HUB_ORIENTATION_RETRY_MAX", ["orientation", "retry_max"], 2, _CONFIG, int
    )
)
ORIENTATION_RETRY_DELAY = int(
    _get_config_value(
        "AGENT_HUB_ORIENTATION_RETRY_DELAY", ["orientation", "retry_delay"], 60, _CONFIG, int
    )
)

# Rate limiting settings (disabled by default)
# RATE_LIMIT_ENABLED: Enable per-agent message rate limiting
# RATE_LIMIT_MAX_MESSAGES: Max messages per agent per window (default: 10)
# RATE_LIMIT_WINDOW_SECONDS: Time window for rate limiting (default: 300 = 5 min)
# RATE_LIMIT_COOLDOWN_SECONDS: Minimum seconds between messages from same agent (default: 0)
RATE_LIMIT_ENABLED = bool(
    _get_config_value("AGENT_HUB_RATE_LIMIT", ["rate_limit", "enabled"], False, _CONFIG, bool)
)
RATE_LIMIT_MAX_MESSAGES = int(
    _get_config_value("AGENT_HUB_RATE_LIMIT_MAX", ["rate_limit", "max_messages"], 10, _CONFIG, int)
)
RATE_LIMIT_WINDOW_SECONDS = int(
    _get_config_value(
        "AGENT_HUB_RATE_LIMIT_WINDOW", ["rate_limit", "window_seconds"], 300, _CONFIG, int
    )
)
RATE_LIMIT_COOLDOWN_SECONDS = int(
    _get_config_value(
        "AGENT_HUB_RATE_LIMIT_COOLDOWN", ["rate_limit", "cooldown_seconds"], 0, _CONFIG, int
    )
)

# Coordinator settings
# The coordinator is a dedicated OpenCode session that facilitates agent collaboration
# COORDINATOR_ENABLED: Enable the coordinator agent (default: true)
# COORDINATOR_PRESERVE_LOCAL_AGENTS_MD: Keep existing coordinator AGENTS.md (default: false)
# COORDINATOR_READY_TIMEOUT_SECONDS: Wait for READY after bootstrap (default: 20)
# COORDINATOR_STRICT_READY: Require exact READY (default: false)
# COORDINATOR_BOOTSTRAP_REQUIRED: Fail daemon startup if coordinator bootstrap is not ready (default: false)
# COORDINATOR_DIR: Directory for coordinator session (default: ~/.agent-hub/coordinator)
# COORDINATOR_AGENTS_MD: Custom path to coordinator AGENTS.md (default: auto-detect)
# Note: The coordinator model is set in its project-level opencode.json
# at COORDINATOR_DIR/opencode.json (default: opencode/minimax-m2.5-free).
COORDINATOR_ENABLED = bool(
    _get_config_value("AGENT_HUB_COORDINATOR", ["coordinator", "enabled"], True, _CONFIG, bool)
)
COORDINATOR_PRESERVE_LOCAL_AGENTS_MD = bool(
    _get_config_value(
        "AGENT_HUB_COORDINATOR_PRESERVE_LOCAL_AGENTS_MD",
        ["coordinator", "preserve_local_agents_md"],
        False,
        _CONFIG,
        bool,
    )
)
COORDINATOR_READY_TIMEOUT_SECONDS = int(
    _get_config_value(
        "AGENT_HUB_COORDINATOR_READY_TIMEOUT",
        ["coordinator", "ready_timeout_seconds"],
        20,
        _CONFIG,
        int,
    )
)
COORDINATOR_STRICT_READY = bool(
    _get_config_value(
        "AGENT_HUB_COORDINATOR_STRICT_READY",
        ["coordinator", "strict_ready"],
        False,
        _CONFIG,
        bool,
    )
)
COORDINATOR_BOOTSTRAP_REQUIRED = bool(
    _get_config_value(
        "AGENT_HUB_COORDINATOR_BOOTSTRAP_REQUIRED",
        ["coordinator", "bootstrap_required"],
        False,
        _CONFIG,
        bool,
    )
)
_coordinator_dir_str = str(
    _get_config_value(
        "AGENT_HUB_COORDINATOR_DIR",
        ["coordinator", "directory"],
        str(AGENT_HUB_DIR / "coordinator"),
        _CONFIG,
    )
)
COORDINATOR_DIR = Path(os.path.expanduser(_coordinator_dir_str))
_coordinator_agents_md_str = str(
    _get_config_value(
        "AGENT_HUB_COORDINATOR_AGENTS_MD",
        ["coordinator", "agents_md"],
        "",  # Empty string means auto-detect
        _CONFIG,
    )
)
# None means auto-detect, otherwise use the specified path
COORDINATOR_AGENTS_MD: Path | None = (
    Path(os.path.expanduser(_coordinator_agents_md_str)) if _coordinator_agents_md_str else None
)
# Base title for coordinator sessions
COORDINATOR_TITLE_BASE = "agent-hub-coordinator"


def _get_coordinator_title() -> str:
    """Get the coordinator session title.

    Always uses the base title. Since we kill all coordinators at startup,
    there's no need for hash-based differentiation.

    Returns the title to use for coordinator session creation.
    """
    return COORDINATOR_TITLE_BASE


COORDINATOR_BOOTSTRAP_PROMPT = (
    "Initialize as the coordinator for agent-hub in a non-interactive session. "
    "Never ask the human user questions and never call the question tool. "
    "Follow AGENTS.md exactly. Reply once with exactly READY and then wait for NEW_AGENT messages."
)


def _is_running_from_source() -> bool:
    """Return True when daemon is running from a source checkout."""
    repo_root = Path(__file__).parent.parent.parent
    return (repo_root / "pyproject.toml").exists() and (repo_root / "contrib").exists()


def _coordinator_has_ready_ack(messages: list[dict[str, Any]]) -> bool:
    """Return True when coordinator replied with exact READY text."""
    for msg in messages:
        info = msg.get("info", {})
        if info.get("role") != "assistant":
            continue

        for part in msg.get("parts", []):
            if part.get("type") == "text" and str(part.get("text", "")).strip() == "READY":
                return True
    return False


def _coordinator_has_activity_after(messages: list[dict[str, Any]], after_ms: int) -> bool:
    """Return True when coordinator produced assistant output after a timestamp."""
    for msg in messages:
        info = msg.get("info", {})
        if info.get("role") != "assistant":
            continue

        created = int(info.get("time", {}).get("created", 0))
        if created <= after_ms:
            continue

        if msg.get("parts"):
            return True
    return False


def _fetch_session_messages(session_id: str) -> list[dict[str, Any]]:
    """Fetch session messages, returning an empty list on errors."""
    try:
        resp = requests.get(
            f"{OPENCODE_URL}/session/{session_id}/message", timeout=INJECTION_TIMEOUT
        )
        resp.raise_for_status()
        payload = resp.json()
        if isinstance(payload, list):
            return payload
    except requests.RequestException:
        return []
    except (ValueError, TypeError):
        return []
    return []


def _get_recent_hub_error_context(session_id: str, max_entries: int = 2) -> str:
    """Get concise recent hub error lines related to a session."""
    if not HUB_STDERR_LOG_FILE.exists():
        return ""

    try:
        lines = HUB_STDERR_LOG_FILE.read_text(errors="replace").splitlines()
    except OSError:
        return ""

    sid_token = f"sessionID={session_id}"
    related_errors = [line.strip() for line in lines if sid_token in line and "ERROR" in line]
    if not related_errors:
        return ""

    tail = related_errors[-max_entries:]
    clipped = [entry[:280] for entry in tail]
    return " | ".join(clipped)


def _wait_for_coordinator_ready(session_id: str, timeout_seconds: int, after_ms: int = 0) -> bool:
    """Wait for coordinator readiness based on READY or assistant activity."""
    deadline = time.time() + max(1, timeout_seconds)
    while time.time() < deadline:
        messages = _fetch_session_messages(session_id)
        if _coordinator_has_ready_ack(messages):
            return True
        if not COORDINATOR_STRICT_READY and _coordinator_has_activity_after(messages, after_ms):
            return True
        time.sleep(0.5)
    return False


def _wait_for_coordinator_activity(
    session_id: str, after_ms: int, timeout_seconds: int = 5
) -> bool:
    """Wait for coordinator assistant output after a specific timestamp."""
    deadline = time.time() + max(1, timeout_seconds)
    while time.time() < deadline:
        messages = _fetch_session_messages(session_id)
        if _coordinator_has_activity_after(messages, after_ms):
            return True
        time.sleep(0.5)
    return False


# Coordinator cost estimation pricing (per token, NOT per million tokens)
# Default prices: MiniMax M2.5 standard pricing as of 2025-06
# Override via env vars or config file ["coordinator"]["pricing"][...]
# Set all to 0 to disable cost estimation (tokens still tracked)
PRICING_INPUT = float(
    _get_config_value(
        "AGENT_HUB_PRICING_INPUT",
        ["coordinator", "pricing", "input"],
        "0.0000015",  # $1.50/MTok (MiniMax M2.5 standard)
        _CONFIG,
    )
)
PRICING_OUTPUT = float(
    _get_config_value(
        "AGENT_HUB_PRICING_OUTPUT",
        ["coordinator", "pricing", "output"],
        "0.000006",  # $6/MTok (MiniMax M2.5 standard)
        _CONFIG,
    )
)
PRICING_CACHE_READ = float(
    _get_config_value(
        "AGENT_HUB_PRICING_CACHE_READ",
        ["coordinator", "pricing", "cache_read"],
        "0.0",  # MiniMax M2.5 does not support prompt caching
        _CONFIG,
    )
)
PRICING_CACHE_WRITE = float(
    _get_config_value(
        "AGENT_HUB_PRICING_CACHE_WRITE",
        ["coordinator", "pricing", "cache_write"],
        "0.0",  # MiniMax M2.5 does not support prompt caching
        _CONFIG,
    )
)

# Track message timestamps per agent for rate limiting
_agent_message_times: dict[str, list[float]] = {}

# Track sessions that have been oriented (session_id -> True)
ORIENTED_SESSIONS: set[str] = set()

# Session-to-agent mapping: maps session_id to agent info
# This enables multiple sessions in the same directory to have unique agent identities
# Structure: {session_id: {"agentId": str, "directory": str, "slug": str | None}}
SESSION_AGENTS: dict[str, dict] = {}
SESSION_AGENTS_FILE = AGENT_HUB_DIR / "session_agents.json"

# Orientation retry tracking
# Tracks sessions that have been oriented but haven't responded yet.
# Structure: {session_id: {"oriented_at": float (time.time()), "retries": int, "agent_id": str}}
ORIENTATION_PENDING: dict[str, dict] = {}

# Daemon start time - only orient sessions created after this
DAEMON_START_TIME_MS: int = int(time.time() * 1000)

# Session cache (avoids repeated API calls)
_sessions_cache: list[dict] = []
_sessions_cache_time: float = 0
_sessions_cache_lock = threading.Lock()


# Work queues (non-blocking handlers)
@dataclass
class InjectionTask:
    session_id: str
    text: str
    agent: str | None = None


@dataclass
class MessageTask:
    path: Path


@dataclass
class SessionTask:
    path: Path


_injection_queue: queue.Queue[InjectionTask] = queue.Queue()
_message_queue: queue.Queue[MessageTask] = queue.Queue()
_session_queue: queue.Queue[SessionTask] = queue.Queue()


# Prometheus-compatible metrics
class PrometheusMetrics:
    """Thread-safe Prometheus-compatible metrics collector."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._start_time = time.time()

        # Counters (only increase)
        self._counters = {
            "agent_hub_messages_total": 0,
            "agent_hub_messages_failed_total": 0,
            "agent_hub_injections_total": 0,
            "agent_hub_injections_failed_total": 0,
            "agent_hub_injections_retried_total": 0,
            "agent_hub_sessions_oriented_total": 0,
            "agent_hub_agents_auto_created_total": 0,
            "agent_hub_cache_hits_total": 0,
            "agent_hub_cache_misses_total": 0,
            "agent_hub_orientation_retries_total": 0,
            "agent_hub_orientation_gave_up_total": 0,
            "agent_hub_gc_runs_total": 0,
            "agent_hub_gc_sessions_cleaned_total": 0,
            "agent_hub_gc_agents_cleaned_total": 0,
            "agent_hub_gc_messages_archived_total": 0,
            "agent_hub_coordinator_tokens_input": 0,
            "agent_hub_coordinator_tokens_output": 0,
            "agent_hub_coordinator_tokens_cache_read": 0,
            "agent_hub_coordinator_tokens_cache_write": 0,
            "agent_hub_coordinator_messages_total": 0,
        }

        # Gauges (can increase or decrease)
        self._gauges: dict[str, int | float] = {
            "agent_hub_active_agents": 0,
            "agent_hub_oriented_sessions": 0,
            "agent_hub_injection_queue_size": 0,
            "agent_hub_message_queue_size": 0,
            "agent_hub_coordinator_estimated_cost_usd": 0.0,
        }

        # Metadata for metrics
        self._help = {
            "agent_hub_messages_total": "Total messages processed successfully",
            "agent_hub_messages_failed_total": "Total messages that failed processing",
            "agent_hub_injections_total": "Total message injections sent to sessions",
            "agent_hub_injections_failed_total": "Total injection failures after retries",
            "agent_hub_injections_retried_total": "Total injection retry attempts",
            "agent_hub_sessions_oriented_total": "Total sessions that received orientation",
            "agent_hub_agents_auto_created_total": "Total agents auto-created from sessions",
            "agent_hub_cache_hits_total": "Total session cache hits",
            "agent_hub_cache_misses_total": "Total session cache misses",
            "agent_hub_orientation_retries_total": "Total orientation retry attempts for unresponsive sessions",
            "agent_hub_orientation_gave_up_total": "Total sessions that never responded after all orientation retries",
            "agent_hub_gc_runs_total": "Total garbage collection runs",
            "agent_hub_gc_sessions_cleaned_total": "Total stale sessions cleaned by GC",
            "agent_hub_gc_agents_cleaned_total": "Total stale agents cleaned by GC",
            "agent_hub_gc_messages_archived_total": "Total messages archived by GC",
            "agent_hub_coordinator_tokens_input": "Coordinator cumulative input tokens",
            "agent_hub_coordinator_tokens_output": "Coordinator cumulative output tokens",
            "agent_hub_coordinator_tokens_cache_read": "Coordinator cumulative cache read tokens",
            "agent_hub_coordinator_tokens_cache_write": "Coordinator cumulative cache write tokens",
            "agent_hub_coordinator_messages_total": "Coordinator total assistant messages processed",
            "agent_hub_coordinator_estimated_cost_usd": "Estimated coordinator cost in USD",
            "agent_hub_active_agents": "Current number of registered agents",
            "agent_hub_oriented_sessions": "Current number of oriented sessions",
            "agent_hub_injection_queue_size": "Current injection queue depth",
            "agent_hub_message_queue_size": "Current message queue depth",
            "agent_hub_start_time_seconds": "Unix timestamp when daemon started",
        }

    def inc(self, name: str, value: int = 1) -> None:
        """Increment a counter."""
        with self._lock:
            if name in self._counters:
                self._counters[name] += value

    def set_gauge(self, name: str, value: int | float) -> None:
        """Set a gauge value."""
        with self._lock:
            self._gauges[name] = value

    def get(self, name: str) -> float:
        """Get current value of a metric."""
        with self._lock:
            if name in self._counters:
                return self._counters[name]
            if name in self._gauges:
                return self._gauges[name]
            return 0

    def to_prometheus(self) -> str:
        """Export all metrics in Prometheus text format."""
        lines = []
        with self._lock:
            # Add start time as a gauge
            lines.append(
                f"# HELP agent_hub_start_time_seconds {self._help['agent_hub_start_time_seconds']}"
            )
            lines.append("# TYPE agent_hub_start_time_seconds gauge")
            lines.append(f"agent_hub_start_time_seconds {self._start_time}")

            # Counters
            for name, value in self._counters.items():
                if name in self._help:
                    lines.append(f"# HELP {name} {self._help[name]}")
                lines.append(f"# TYPE {name} counter")
                lines.append(f"{name} {value}")

            # Gauges
            for gname, gvalue in self._gauges.items():
                if gname in self._help:
                    lines.append(f"# HELP {gname} {self._help[gname]}")
                lines.append(f"# TYPE {gname} gauge")
                lines.append(f"{gname} {gvalue}")

        return "\n".join(lines) + "\n"

    def log_summary(self) -> str:
        """Return a human-readable summary for logging."""
        with self._lock:
            uptime = time.time() - self._start_time
            hours, remainder = divmod(int(uptime), 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = (
                f"{hours}h{minutes}m{seconds}s"
                if hours
                else f"{minutes}m{seconds}s"
                if minutes
                else f"{seconds}s"
            )

            coord_cost = self._gauges.get("agent_hub_coordinator_estimated_cost_usd", 0)
            coord_msgs = self._counters.get("agent_hub_coordinator_messages_total", 0)

            return (
                f"uptime={uptime_str} "
                f"msgs={self._counters['agent_hub_messages_total']}/{self._counters['agent_hub_messages_failed_total']} "
                f"inj={self._counters['agent_hub_injections_total']}/{self._counters['agent_hub_injections_failed_total']} "
                f"orient={self._counters['agent_hub_sessions_oriented_total']} "
                f"cache={self._counters['agent_hub_cache_hits_total']}/{self._counters['agent_hub_cache_misses_total']} "
                f"gc={self._counters['agent_hub_gc_runs_total']} "
                f"coord=${coord_cost:.4f}/{coord_msgs}msgs"
            )


metrics = PrometheusMetrics()

# Metrics file location
METRICS_FILE = AGENT_HUB_DIR / "metrics.prom"
HUB_SERVER_PID_FILE = AGENT_HUB_DIR / "hub-server.pid"
DAEMON_LOG_DIR = Path.home() / ".local/share/agent-hub-daemon"
HUB_STDERR_LOG_FILE = DAEMON_LOG_DIR / "hub-stderr.log"


def load_oriented_sessions() -> set[str]:
    """Load oriented sessions from disk."""
    if not ORIENTED_SESSIONS_FILE.exists():
        return set()
    try:
        return set(json.loads(ORIENTED_SESSIONS_FILE.read_text()))
    except (json.JSONDecodeError, OSError) as e:
        log.warning(f"Failed to load oriented sessions: {e}")
        return set()


def save_oriented_sessions() -> None:
    """Save oriented sessions to disk."""
    try:
        AGENT_HUB_DIR.mkdir(parents=True, exist_ok=True)
        atomic_write_json(ORIENTED_SESSIONS_FILE, list(ORIENTED_SESSIONS), indent=None)
    except OSError as e:
        log.warning(f"Failed to save oriented sessions: {e}")


def save_session_agents() -> None:
    """Save session-to-agent mapping to disk."""
    try:
        AGENT_HUB_DIR.mkdir(parents=True, exist_ok=True)
        atomic_write_json(SESSION_AGENTS_FILE, SESSION_AGENTS, indent=2)
    except OSError as e:
        log.warning(f"Failed to save session agents: {e}")


def load_session_agents() -> dict[str, dict[str, Any]]:
    """Load session-to-agent mapping from disk."""
    if not SESSION_AGENTS_FILE.exists():
        return {}
    try:
        return cast(dict[str, dict[str, Any]], json.loads(SESSION_AGENTS_FILE.read_text()))
    except (json.JSONDecodeError, OSError) as e:
        log.warning(f"Failed to load session agents: {e}")
        return {}


# Hub server process (launched by daemon if needed)
HUB_SERVER_PROCESS: subprocess.Popen | None = None

# Coordinator session (lives on hub server, no local process needed)
COORDINATOR_SESSION_ID: str | None = None

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# =============================================================================
# Rate Limiting
# =============================================================================


def check_rate_limit(agent_id: str) -> tuple[bool, str | None]:
    """Check if agent is within rate limits.

    Returns (allowed, rejection_reason).
    If allowed is False, rejection_reason explains why.
    """
    if not RATE_LIMIT_ENABLED:
        return True, None

    now = time.time()

    # Initialize tracking for this agent
    if agent_id not in _agent_message_times:
        _agent_message_times[agent_id] = []

    times = _agent_message_times[agent_id]

    # Check cooldown (minimum time between messages)
    if RATE_LIMIT_COOLDOWN_SECONDS > 0 and times:
        last_msg = times[-1]
        elapsed = now - last_msg
        if elapsed < RATE_LIMIT_COOLDOWN_SECONDS:
            remaining = int(RATE_LIMIT_COOLDOWN_SECONDS - elapsed)
            return False, f"Cooldown: wait {remaining}s before sending again"

    # Prune old timestamps outside the window
    window_start = now - RATE_LIMIT_WINDOW_SECONDS
    times[:] = [t for t in times if t > window_start]

    # Check rate limit
    if len(times) >= RATE_LIMIT_MAX_MESSAGES:
        return (
            False,
            f"Rate limit: max {RATE_LIMIT_MAX_MESSAGES} messages per {RATE_LIMIT_WINDOW_SECONDS}s",
        )

    return True, None


def record_message_sent(agent_id: str) -> None:
    """Record that an agent sent a message (for rate limiting)."""
    if not RATE_LIMIT_ENABLED:
        return

    now = time.time()
    if agent_id not in _agent_message_times:
        _agent_message_times[agent_id] = []
    _agent_message_times[agent_id].append(now)


# =============================================================================
# Agent Management
# =============================================================================


def load_agents() -> dict[str, dict[str, Any]]:
    """Load all registered agents, keyed by agent ID.

    Retries on JSON decode errors to handle transient file states
    when external writers are updating agent files.
    """
    agents: dict[str, dict[str, Any]] = {}
    if not AGENTS_DIR.exists():
        return agents
    for f in AGENTS_DIR.glob("*.json"):
        agent = _load_agent_with_retry(f)
        if agent:
            agents[agent["id"]] = agent
    return agents


def _load_agent_with_retry(
    path: Path, max_retries: int = 3, base_delay: float = 0.05
) -> dict[str, Any] | None:
    """Load a single agent file with retry for transient errors.

    Args:
        path: Path to agent JSON file
        max_retries: Maximum number of retry attempts
        base_delay: Initial delay between retries (doubles each attempt)

    Returns:
        Agent dict or None if loading failed after all retries
    """
    for attempt in range(max_retries):
        try:
            content = path.read_text()
            if not content.strip():
                # File is empty - writer hasn't finished yet
                if attempt < max_retries - 1:
                    delay = base_delay * (2**attempt)
                    log.debug(
                        f"Agent file {path.name} empty, retrying in {delay:.0f}ms (attempt {attempt + 1}/{max_retries})"
                    )
                    time.sleep(delay)
                    continue
                log.warning(f"Agent file {path.name} is empty after {max_retries} attempts")
                return None

            agent = json.loads(content)
            if "id" not in agent:
                log.warning(f"Agent file {path.name} missing 'id' field")
                return None
            return agent

        except json.JSONDecodeError:
            if attempt < max_retries - 1:
                delay = base_delay * (2**attempt)
                log.debug(
                    f"Failed to parse agent {path.name}, retrying in {delay:.0f}ms (attempt {attempt + 1}/{max_retries})"
                )
                time.sleep(delay)
            else:
                log.warning(
                    f"Failed to load agent {path.name}: JSON decode error after {max_retries} attempts"
                )
        except OSError as e:
            log.warning(f"Failed to read agent {path.name}: {e}")
            return None

    return None


def is_agent_active(agent: dict[str, Any]) -> bool:
    """Check if agent has been seen within the stale threshold."""
    last_seen = cast(float, agent.get("lastSeen", 0))
    age_seconds = (time.time() * 1000 - last_seen) / 1000
    return cast(bool, age_seconds < AGENT_STALE_SECONDS)


# =============================================================================
# Thread Management
# =============================================================================


def load_thread(thread_id: str) -> dict[str, Any] | None:
    """Load a thread by ID."""
    path = THREADS_DIR / f"{thread_id}.json"
    if not path.exists():
        return None
    try:
        return cast(dict[str, Any], json.loads(path.read_text()))
    except (json.JSONDecodeError, OSError) as e:
        log.warning(f"Failed to load thread {thread_id}: {e}")
        return None


def save_thread(thread: dict[str, Any]) -> None:
    """Save a thread."""
    THREADS_DIR.mkdir(parents=True, exist_ok=True)
    path = THREADS_DIR / f"{thread['id']}.json"
    atomic_write_json(path, thread, indent=2)


def create_thread(msg: dict[str, Any]) -> dict[str, Any]:
    """Create a new thread from a message."""
    thread_id = msg.get("threadId") or str(uuid.uuid4())[:12]
    now = int(time.time() * 1000)

    participants = {msg.get("from", "unknown")}
    to = msg.get("to", "")
    if to and to != "all":
        participants.add(to)

    thread = {
        "id": thread_id,
        "createdBy": msg.get("from", "unknown"),
        "createdAt": now,
        "participants": list(participants),
        "status": "open",
        "resolvedBy": None,
        "resolvedAt": None,
    }
    save_thread(thread)
    return thread


def update_thread_participants(thread: dict[str, Any], msg: dict[str, Any]) -> None:
    """Add new participants to a thread."""
    participants = set(thread.get("participants", []))
    participants.add(msg.get("from", "unknown"))
    to = msg.get("to", "")
    if to and to != "all":
        participants.add(to)
    thread["participants"] = list(participants)
    save_thread(thread)


def resolve_thread(thread_id: str, resolved_by: str) -> None:
    """Mark a thread as resolved and archive its messages."""
    thread = load_thread(thread_id)
    if not thread:
        return

    thread["status"] = "resolved"
    thread["resolvedBy"] = resolved_by
    thread["resolvedAt"] = int(time.time() * 1000)
    save_thread(thread)

    # Archive all messages in this thread
    archive_thread_messages(thread_id)
    log.info(f"Thread {thread_id} resolved by {resolved_by}")


def archive_thread_messages(thread_id: str) -> None:
    """Move all messages in a thread to archive."""
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    for msg_path in MESSAGES_DIR.glob("*.json"):
        try:
            msg = json.loads(msg_path.read_text())
            if msg.get("threadId") == thread_id:
                dest = ARCHIVE_DIR / msg_path.name
                shutil.move(str(msg_path), str(dest))
                log.debug(f"Archived message {msg_path.name} (thread resolved)")
        except (json.JSONDecodeError, OSError):
            continue


def ensure_thread_id(msg: dict[str, Any], msg_path: Path) -> str:
    """Ensure message has a threadId, creating one if needed."""
    if msg.get("threadId"):
        thread_id = cast(str, msg["threadId"])
        thread = load_thread(thread_id)
        if thread:
            update_thread_participants(thread, msg)
        else:
            create_thread(msg)
    else:
        # Auto-generate threadId
        thread = create_thread(msg)
        thread_id = thread["id"]
        msg["threadId"] = thread_id
        # Rewrite the message file with threadId
        msg_path.write_text(json.dumps(msg, indent=2))
        log.debug(f"Auto-assigned threadId {thread_id} to message {msg_path.name}")

    return cast(str, msg.get("threadId", ""))


def check_thread_resolution(msg: dict[str, Any]) -> bool:
    """Check if message resolves a thread. Returns True if resolved."""
    if msg.get("type") != "completion":
        return False

    content = cast(str, msg.get("content", "")).upper()
    if "RESOLVED" not in content:
        return False

    thread_id = cast(str, msg.get("threadId"))
    if not thread_id:
        return False

    thread = load_thread(thread_id)
    if not thread:
        return False

    # Check if sender is the thread owner (creator) or it's a broadcast thread
    sender = msg.get("from", "")
    is_owner = thread.get("createdBy") == sender
    is_broadcast = msg.get("to") == "all" or thread.get("createdBy") == "all"

    if is_owner or is_broadcast:
        resolve_thread(thread_id, cast(str, sender))
        return True

    return False


# =============================================================================
# Garbage Collection
# =============================================================================


def gc_oriented_sessions() -> int:
    """Remove oriented session IDs for sessions inactive for >1 hour.

    This allows re-orientation when a user returns to an old session,
    and prevents the cache from growing unbounded.

    Returns number of sessions cleaned.
    """
    global ORIENTED_SESSIONS

    if not ORIENTED_SESSIONS:
        return 0

    # Get current sessions from API
    current_sessions = get_sessions()
    if current_sessions is None:
        return 0  # Don't clear on API failure

    now_ms = int(time.time() * 1000)
    stale_threshold_ms = MESSAGE_TTL_SECONDS * 1000  # 1 hour

    # Build set of recently active session IDs
    active_ids = set()
    for s in current_sessions:
        session_id = s.get("id", "")
        if not session_id:
            continue
        updated = s.get("time", {}).get("updated", 0)
        if now_ms - updated < stale_threshold_ms:
            active_ids.add(session_id)

    # Always keep coordinator session active regardless of update time
    if COORDINATOR_SESSION_ID:
        active_ids.add(COORDINATOR_SESSION_ID)

    # Keep only recently active sessions in oriented cache
    stale = ORIENTED_SESSIONS - active_ids
    if stale:
        ORIENTED_SESSIONS -= stale
        save_oriented_sessions()
        metrics.set_gauge("agent_hub_oriented_sessions", len(ORIENTED_SESSIONS))
        log.info(
            f"GC: Removed {len(stale)} inactive oriented sessions, {len(ORIENTED_SESSIONS)} remaining"
        )
        return len(stale)
    return 0


def gc_session_agents() -> int:
    """Remove session-agent mappings for sessions that no longer exist or are stale.

    Cleans up mappings for sessions that are either missing from the database
    or haven't been updated within the stale threshold (AGENT_STALE_SECONDS).

    Returns number of mappings cleaned.
    """
    global SESSION_AGENTS

    if not SESSION_AGENTS:
        return 0

    current_sessions = get_sessions()
    if current_sessions is None:
        return 0  # Don't clear on DB failure

    now_ms = int(time.time() * 1000)
    stale_threshold_ms = AGENT_STALE_SECONDS * 1000

    # Build set of active session IDs (exist AND updated recently)
    active_ids = set()
    for s in current_sessions:
        session_id = s.get("id", "")
        if not session_id:
            continue
        updated = s.get("time", {}).get("updated", 0)
        if now_ms - updated < stale_threshold_ms:
            active_ids.add(session_id)

    # Always keep coordinator session
    if COORDINATOR_SESSION_ID:
        active_ids.add(COORDINATOR_SESSION_ID)

    stale_session_ids = [sid for sid in SESSION_AGENTS if sid not in active_ids]

    if stale_session_ids:
        for sid in stale_session_ids:
            del SESSION_AGENTS[sid]
        save_session_agents()
        log.info(
            f"GC: Removed {len(stale_session_ids)} stale session-agent mappings, "
            f"{len(SESSION_AGENTS)} remaining"
        )
        return len(stale_session_ids)
    return 0


def run_gc(agents: dict[str, dict[str, Any]]) -> None:
    """Run garbage collection on messages, threads, stale agents, and oriented sessions."""
    now_ms = int(time.time() * 1000)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

    agents_cleaned = 0
    messages_archived = 0

    # 0. Clean up oriented sessions - keep only sessions that still exist in API
    sessions_cleaned = gc_oriented_sessions()

    # 0.5. Clean up session-agent mappings for non-existent sessions
    gc_session_agents()

    # 1. Remove stale agents (>1hr since lastSeen)
    if AGENTS_DIR.exists():
        for agent_path in AGENTS_DIR.glob("*.json"):
            try:
                agent = json.loads(agent_path.read_text())
                last_seen = agent.get("lastSeen", 0)
                age_ms = now_ms - last_seen
                if age_ms > AGENT_STALE_SECONDS * 1000:
                    agent_id = agent.get("id", agent_path.stem)
                    session_id = agent.get("sessionId")
                    agent_path.unlink()
                    # Remove from in-memory cache too
                    agents.pop(agent_id, None)
                    # Also remove from session-agent mapping
                    if session_id and session_id in SESSION_AGENTS:
                        del SESSION_AGENTS[session_id]
                    agents_cleaned += 1
                    log.info(f"Removed stale agent {agent_id} (age: {age_ms / 1000 / 60:.0f}m)")
            except (json.JSONDecodeError, OSError) as e:
                log.warning(f"Failed to check agent {agent_path}: {e}")
                continue

    # Save session agents if any were cleaned
    if agents_cleaned > 0:
        save_session_agents()

    # 2. Archive expired messages (>1hr old)
    for msg_path in MESSAGES_DIR.glob("*.json"):
        try:
            msg = json.loads(msg_path.read_text())
            timestamp = msg.get("timestamp", 0)
            age_ms = now_ms - timestamp
            if age_ms > MESSAGE_TTL_SECONDS * 1000:
                dest = ARCHIVE_DIR / msg_path.name
                shutil.move(str(msg_path), str(dest))
                messages_archived += 1
                log.debug(f"Archived expired message {msg_path.name} (age: {age_ms / 1000:.0f}s)")
        except (json.JSONDecodeError, OSError):
            continue

    # 3. Check threads with all stale participants
    if THREADS_DIR.exists():
        for thread_path in THREADS_DIR.glob("*.json"):
            try:
                thread = json.loads(thread_path.read_text())
                if thread.get("status") == "resolved":
                    continue

                participants = thread.get("participants", [])
                all_stale = True
                for participant_id in participants:
                    agent = agents.get(participant_id)
                    if agent and is_agent_active(agent):
                        all_stale = False
                        break

                if all_stale and participants:
                    log.debug(f"Thread {thread['id']} expired (all participants stale)")
                    thread["status"] = "expired"
                    thread["resolvedAt"] = now_ms
                    thread_path.write_text(json.dumps(thread, indent=2))
                    archive_thread_messages(thread["id"])
            except (json.JSONDecodeError, OSError):
                continue

    # Update metrics
    metrics.inc("agent_hub_gc_runs_total")
    metrics.inc("agent_hub_gc_sessions_cleaned_total", sessions_cleaned)
    metrics.inc("agent_hub_gc_agents_cleaned_total", agents_cleaned)
    metrics.inc("agent_hub_gc_messages_archived_total", messages_archived)
    metrics.set_gauge("agent_hub_active_agents", len(agents))


# =============================================================================
# Preflight Checks
# =============================================================================


class PreflightError(Exception):
    """Raised when preflight checks fail."""

    pass


def check_agent_hub_mcp_configured() -> bool:
    """Verify agent-hub MCP is configured and enabled in OpenCode.

    Uses `opencode debug config` to get the resolved configuration,
    which handles all config file locations automatically.

    Returns True if configured and enabled, raises PreflightError otherwise.
    """
    opencode_bin = shutil.which("opencode")
    if not opencode_bin:
        raise PreflightError(
            "opencode binary not found in PATH.\n\n"
            "To fix:\n"
            "  1. Install OpenCode: https://github.com/sst/opencode\n"
            "  2. Ensure 'opencode' is in your PATH\n"
        )

    # Get config file location for error messages
    try:
        paths_result = subprocess.run(
            [opencode_bin, "debug", "paths"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        config_path = "your OpenCode config file (run 'opencode debug paths' to find it)"
        if paths_result.returncode == 0:
            for line in paths_result.stdout.splitlines():
                # Format is: "config     /path/to/config"
                if line.lower().startswith("config"):
                    parts = line.split(None, 1)  # Split on whitespace, max 2 parts
                    if len(parts) == 2:
                        config_path = parts[1].strip() + "/opencode.json"
                    break
    except (subprocess.TimeoutExpired, OSError):
        config_path = "your OpenCode config file (run 'opencode debug paths' to find it)"

    try:
        result = subprocess.run(
            [opencode_bin, "debug", "config"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except subprocess.TimeoutExpired as e:
        raise PreflightError("Timed out getting OpenCode config") from e
    except OSError as e:
        raise PreflightError(f"Failed to run opencode: {e}") from e

    if result.returncode != 0:
        raise PreflightError(
            f"opencode debug config failed (exit {result.returncode}): {result.stderr}"
        )

    try:
        config = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        raise PreflightError(f"Failed to parse OpenCode config: {e}") from e

    mcp_config = config.get("mcp", {})
    agent_hub = mcp_config.get("agent-hub")

    if agent_hub is None:
        raise PreflightError(
            "agent-hub MCP is not configured in OpenCode.\n\n"
            "The daemon requires agent-hub-mcp to enable agent communication.\n\n"
            f'To fix, set "enabled": true for mcp.agent-hub in {config_path}:\n\n'
            '  "mcp": {{\n'
            '    "agent-hub": {{\n'
            "      ...\n"
            '      "enabled": true\n'
            "    }}\n"
            "  }}\n\n"
            "Then restart OpenCode.\n\n"
            "More info: https://github.com/gilbarbara/agent-hub-mcp"
        )

    if not agent_hub.get("enabled", False):
        raise PreflightError(
            "agent-hub MCP is configured but disabled.\n\n"
            f'To fix, set "enabled": true for mcp.agent-hub in {config_path}, '
            "then restart OpenCode."
        )

    log.info("Preflight: agent-hub MCP configured and enabled")

    # Check that agent-hub tools are allowed in permissions
    permissions = config.get("permission", {})
    agent_hub_allowed = False

    if isinstance(permissions, dict):
        # Check for agent-hub_* permission
        agent_hub_perm = permissions.get("agent-hub_*")
        if agent_hub_perm == "allow":
            agent_hub_allowed = True

    if not agent_hub_allowed:
        raise PreflightError(
            "agent-hub tools are not allowed in OpenCode permissions.\n\n"
            f'To fix, add "agent-hub_*": "allow" to the permission section in {config_path}:\n\n'
            '  "permission": {\n'
            '    "agent-hub_*": "allow",\n'
            "    ...\n"
            "  }\n\n"
            "Then restart OpenCode."
        )

    log.info("Preflight: agent-hub tools allowed in permissions")
    return True


# =============================================================================
# Hub Server Management
# =============================================================================


def is_hub_server_running() -> bool:
    """Check if OpenCode hub server is responding on the configured port."""
    try:
        resp = requests.get(f"{OPENCODE_URL}/session", timeout=2)
        return cast(bool, resp.status_code == 200)
    except requests.RequestException:
        return False


def _find_opencode_serve_pids_on_port() -> list[int]:
    """Find opencode serve PIDs listening on configured hub port."""
    try:
        out = subprocess.run(
            ["lsof", "-nP", f"-iTCP:{OPENCODE_PORT}", "-sTCP:LISTEN", "-t"],
            capture_output=True,
            text=True,
            timeout=2,
        )
    except (OSError, subprocess.SubprocessError):
        return []

    pids: list[int] = []
    for line in out.stdout.splitlines():
        token = line.strip()
        if not token.isdigit():
            continue
        pid = int(token)
        try:
            ps = subprocess.run(
                ["ps", "-p", str(pid), "-o", "command="],
                capture_output=True,
                text=True,
                timeout=2,
            )
        except (OSError, subprocess.SubprocessError):
            continue

        cmd = ps.stdout.strip()
        if "opencode" in cmd and "serve" in cmd:
            pids.append(pid)

    return pids


def _kill_opencode_serve_pids(pids: list[int]) -> None:
    """Terminate/kill opencode serve processes by pid."""
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            continue

    time.sleep(0.5)

    for pid in pids:
        try:
            os.kill(pid, 0)
        except OSError:
            continue
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            continue


def start_hub_server() -> subprocess.Popen[bytes] | None:
    """Launch OpenCode hub server in headless mode.

    The hub server provides HTTP API access for message injection into sessions.
    It uses the user's normal OpenCode config (no XDG_CONFIG_HOME isolation) so
    that TUI instances discover and connect to it, enabling prompt_async injection.

    Session discovery is handled separately via direct SQLite queries, since the
    hub server's listing API only returns sessions it manages internally.
    """
    global HUB_SERVER_PROCESS

    if is_hub_server_running():
        log.info(f"Hub server already running on port {OPENCODE_PORT}")
        return None

    log.info(f"Starting OpenCode hub server on port {OPENCODE_PORT}...")

    # Find opencode binary
    opencode_bin = shutil.which("opencode")
    if not opencode_bin:
        log.error("opencode binary not found in PATH")
        return None

    # Launch headless server
    try:
        # Redirect stdout/stderr to log files
        # NOTE: Files intentionally not using context manager - must stay open for subprocess
        DAEMON_LOG_DIR.mkdir(parents=True, exist_ok=True)
        hub_stdout = open(DAEMON_LOG_DIR / "hub-stdout.log", "a")  # noqa: SIM115
        hub_stderr = open(HUB_STDERR_LOG_FILE, "a")  # noqa: SIM115

        HUB_SERVER_PROCESS = subprocess.Popen(
            [
                opencode_bin,
                "serve",
                "--port",
                str(OPENCODE_PORT),
                "--print-logs",
            ],
            stdout=hub_stdout,
            stderr=hub_stderr,
            start_new_session=True,  # Detach from terminal
        )

        # Wait for server to start
        for _ in range(30):  # 30 attempts, 0.5s each = 15s max
            time.sleep(0.5)
            if is_hub_server_running():
                log.info(f"Hub server started (PID {HUB_SERVER_PROCESS.pid})")
                HUB_SERVER_PID_FILE.write_text(str(HUB_SERVER_PROCESS.pid))
                return HUB_SERVER_PROCESS

        log.error("Hub server failed to start within timeout")
        HUB_SERVER_PROCESS.terminate()
        _kill_opencode_serve_pids(_find_opencode_serve_pids_on_port())
        HUB_SERVER_PROCESS = None
        return None

    except Exception as e:
        log.error(f"Failed to start hub server: {e}")
        return None


def stop_hub_server() -> None:
    """Stop the hub server if we started it."""
    global HUB_SERVER_PROCESS

    if HUB_SERVER_PROCESS is not None:
        log.info(f"Stopping hub server (PID {HUB_SERVER_PROCESS.pid})...")
        try:
            HUB_SERVER_PROCESS.terminate()
            HUB_SERVER_PROCESS.wait(timeout=5)
        except subprocess.TimeoutExpired:
            log.warning("Hub server didn't stop gracefully, killing...")
            HUB_SERVER_PROCESS.kill()
        HUB_SERVER_PROCESS = None

    elif HUB_SERVER_PID_FILE.exists():
        try:
            pid = int(HUB_SERVER_PID_FILE.read_text().strip())
            cmd = subprocess.run(
                ["ps", "-p", str(pid), "-o", "command="],
                capture_output=True,
                text=True,
                timeout=2,
            )
            command = cmd.stdout.strip()
            if "opencode serve" in command and f"--port {OPENCODE_PORT}" in command:
                log.info(f"Stopping hub server from PID file (PID {pid})...")
                os.kill(pid, signal.SIGTERM)
        except (ValueError, OSError, subprocess.SubprocessError):
            pass

    try:
        if HUB_SERVER_PID_FILE.exists():
            HUB_SERVER_PID_FILE.unlink()
    except OSError:
        pass

    # Final safety: kill any stray opencode serve still bound to this port.
    _kill_opencode_serve_pids(_find_opencode_serve_pids_on_port())


# =============================================================================
# Coordinator Management
# =============================================================================


def find_coordinator_agents_md_template() -> Path | None:
    """Find the AGENTS.md template for the coordinator.

    Search order:
    1. Explicit config/env var path (COORDINATOR_AGENTS_MD)
    2. ~/.config/agent-hub-daemon/AGENTS.md (user override)
    3. ~/.config/agent-hub-daemon/COORDINATOR.md (alias)
    4. Development: repo contrib/ directory (when running from source)
    5. importlib.resources (pip/PyPI package data)
    6. /usr/share/opencode-agent-hub/coordinator/AGENTS.md (system packages: deb, rpm)
    7. /usr/local/share/opencode-agent-hub/coordinator/AGENTS.md (local install)
    8. ~/.local/share/opencode-agent-hub/coordinator/AGENTS.md (user local)

    Returns the first existing path, or None if no template found.
    """
    # 1. Explicit config path takes highest priority
    if COORDINATOR_AGENTS_MD is not None:
        if COORDINATOR_AGENTS_MD.exists():
            return COORDINATOR_AGENTS_MD
        else:
            log.warning(f"Configured coordinator AGENTS.md not found: {COORDINATOR_AGENTS_MD}")
            # Fall through to other locations

    # 2-3. User config directory overrides
    user_config_locations = [
        CONFIG_DIR / "AGENTS.md",
        CONFIG_DIR / "COORDINATOR.md",
    ]

    for path in user_config_locations:
        if path.exists():
            return path

    # 4. Development: repo contrib/ directory (when running from source)
    if _is_running_from_source():
        dev_template = Path(__file__).parent.parent.parent / "contrib" / "coordinator" / "AGENTS.md"
        if dev_template.exists():
            return dev_template

    # 5. importlib.resources - works with pip/PyPI installs
    try:
        import opencode_agent_hub

        pkg_path = files(opencode_agent_hub) / "contrib" / "coordinator" / "AGENTS.md"
        if pkg_path.is_file():
            return Path(str(pkg_path))
    except (ImportError, TypeError):
        pass

    # 6-8. System locations (FHS-compliant + Homebrew)
    system_locations = [
        Path("/usr/share/opencode-agent-hub/coordinator/AGENTS.md"),  # deb, rpm
        Path(
            "/usr/local/share/opencode-agent-hub/coordinator/AGENTS.md"
        ),  # local, Homebrew (Intel)
        Path(
            "/opt/homebrew/share/opencode-agent-hub/coordinator/AGENTS.md"
        ),  # Homebrew (Apple Silicon)
        Path.home() / ".local/share/opencode-agent-hub/coordinator/AGENTS.md",  # user
    ]

    for path in system_locations:
        if path.exists():
            return path

    return None


def find_coordinator_opencode_json_template() -> Path | None:
    """Find the opencode.json template for the coordinator.

    Search order:
    1. ~/.config/agent-hub-daemon/opencode.json (user override - highest priority)
    2. Development: repo contrib/ directory (when running from source)
    3. importlib.resources (pip/PyPI package data)
    4. /usr/share/opencode-agent-hub/coordinator/opencode.json (system packages: deb, rpm)
    5. /usr/local/share/opencode-agent-hub/coordinator/opencode.json (local install)
    6. ~/.local/share/opencode-agent-hub/coordinator/opencode.json (user local)

    Returns the first existing path, or None if no template found.
    """
    # 1. User config directory override (highest priority)
    user_config_path = CONFIG_DIR / "opencode.json"
    if user_config_path.exists():
        return user_config_path

    # 2. Development: repo contrib/ directory (when running from source)
    if _is_running_from_source():
        dev_template = (
            Path(__file__).parent.parent.parent / "contrib" / "coordinator" / "opencode.json"
        )
        if dev_template.exists():
            return dev_template

    # 3. importlib.resources - works with pip/PyPI installs
    try:
        import opencode_agent_hub

        pkg_path = files(opencode_agent_hub) / "contrib" / "coordinator" / "opencode.json"
        if pkg_path.is_file():
            return Path(str(pkg_path))
    except (ImportError, TypeError):
        pass

    # 4-6. System locations (FHS-compliant + Homebrew)
    system_locations = [
        Path("/usr/share/opencode-agent-hub/coordinator/opencode.json"),  # deb, rpm
        Path(
            "/usr/local/share/opencode-agent-hub/coordinator/opencode.json"
        ),  # local, Homebrew (Intel)
        Path(
            "/opt/homebrew/share/opencode-agent-hub/coordinator/opencode.json"
        ),  # Homebrew (Apple Silicon)
        Path.home() / ".local/share/opencode-agent-hub/coordinator/opencode.json",  # user
    ]

    for path in system_locations:
        if path.exists():
            return path

    return None


def session_has_blocking_permissions(session: dict) -> bool:
    """Check if a session has blocking permissions that prevent message injection.

    A session is blocking if it has a permission rule that denies the "question"
    permission with pattern "*". This prevents prompt_async injections from
    being delivered.

    Args:
        session: Session dict from the OpenCode API containing 'permission' field.

    Returns:
        True if session has blocking permissions, False otherwise.
    """
    permissions = session.get("permission")
    if not isinstance(permissions, list):
        return False

    for perm in permissions:
        if not isinstance(perm, dict):
            continue

        permission_name = perm.get("permission", "")
        pattern = perm.get("pattern", "")
        action = perm.get("action", "")

        # Check for question:deny which blocks prompt_async
        if permission_name == "question" and pattern == "*" and action == "deny":
            return True

    return False


def setup_coordinator_directory() -> bool:
    """Set up the coordinator directory with AGENTS.md and opencode.json.

    Files copied/overwritten:
    - AGENTS.md: instructions for the coordinator agent (see find_coordinator_agents_md_template())
    - opencode.json: permissions config for the coordinator (see find_coordinator_opencode_json_template())

    Returns True if setup succeeded, False otherwise.
    """
    try:
        COORDINATOR_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        log.error(f"Failed to create coordinator directory: {e}")
        return False

    # Always copy/overwrite opencode.json from template (REQUIRED)
    opencode_json = COORDINATOR_DIR / "opencode.json"
    json_template = find_coordinator_opencode_json_template()
    if json_template is not None:
        shutil.copy(json_template, opencode_json)
        log.info(f"Copied coordinator opencode.json from {json_template}")
    else:
        log.error("No opencode.json template found for coordinator - cannot continue")
        return False

    # Handle AGENTS.md (overwrite by default to avoid stale coordinator behavior)
    agents_md = COORDINATOR_DIR / "AGENTS.md"

    if agents_md.exists() and COORDINATOR_PRESERVE_LOCAL_AGENTS_MD:
        log.info(f"Preserving existing coordinator AGENTS.md at {agents_md}")
        return True

    # Find and copy template
    template = find_coordinator_agents_md_template()
    if template is not None:
        shutil.copy(template, agents_md)
        log.info(f"Copied coordinator AGENTS.md from {template}")
    else:
        # Create minimal AGENTS.md if no template found
        minimal_agents_md = """# Coordinator Agent

You are the coordinator for a multi-agent system. Your job is to facilitate collaboration.

## When You Receive "NEW_AGENT" Notification

1. Ask the new agent: "What task are you working on?"
2. Check if other agents are working on related tasks
3. If matches found, introduce them to each other

## Tools

- `agent-hub_send_message` - Send messages to agents
- `agent-hub_sync` - Get hub state

## Behavior

- Be concise
- Just facilitate introductions, don't micromanage
- Let agents coordinate directly after introduction
"""
        agents_md.write_text(minimal_agents_md)
        log.info(f"Created minimal coordinator AGENTS.md at {agents_md}")

    return True


def kill_all_coordinator_sessions() -> int:
    """Kill all existing coordinator sessions on the hub server.

    Returns the number of sessions killed.
    """
    sessions = get_sessions_uncached()
    if sessions is None:
        return 0

    coordinator_title = _get_coordinator_title()
    killed = 0
    for session in sessions:
        session_id = session.get("id")
        title = session.get("title", "")

        # Only kill coordinator sessions (exact title match)
        if title != coordinator_title:
            continue

        if session_id:
            log.info(f"Killing coordinator session {session_id[:8]} (title: {title})")
            try:
                resp = requests.delete(f"{OPENCODE_URL}/session/{session_id}", timeout=5)
                if resp.status_code in (200, 204):
                    log.info(f"Killed coordinator session {session_id[:8]}")
                    killed += 1
                else:
                    log.warning(
                        f"Failed to kill coordinator session {session_id[:8]}: "
                        f"HTTP {resp.status_code}"
                    )
            except requests.RequestException as e:
                log.warning(f"Failed to kill coordinator session: {e}")

    return killed


def find_coordinator_session() -> str | None:
    """Find the coordinator's session on the hub server.

    Checks for blocking permissions and raises PreflightError if found,
    so the caller knows to kill the existing session and create a new one.

    Returns the coordinator session ID if it exists and has valid permissions.
    Returns None if no coordinator session exists.

    Raises:
        PreflightError: If coordinator session exists but has blocking permissions.
    """
    sessions = get_sessions_uncached()
    if sessions is None:
        return None

    coordinator_title = _get_coordinator_title()

    for session in sessions:
        title = session.get("title", "")
        if title != coordinator_title:
            continue

        # Check for blocking permissions
        if session_has_blocking_permissions(session):
            session_id = session.get("id", "unknown")
            raise PreflightError(
                f"Coordinator session {session_id[:8]} has blocking permissions (question: deny). "
                "This prevents message injection. The session must be recreated with correct permissions."
            )

        return session.get("id")
    return None


def start_coordinator() -> bool:
    """Start the coordinator OpenCode session.

    Startup remains lightweight, but requires a READY acknowledgement after
    bootstrap to avoid silent coordinator failures.

    Returns True if coordinator session is ready, False otherwise.
    """
    global COORDINATOR_SESSION_ID

    if not COORDINATOR_ENABLED:
        log.info("Coordinator disabled via AGENT_HUB_COORDINATOR=false")
        return False

    # Set up coordinator directory
    if not setup_coordinator_directory():
        log.error("Failed to set up coordinator directory")
        return False

    # Kill all existing coordinator sessions before starting a new one
    killed = kill_all_coordinator_sessions()
    if killed > 0:
        log.info(f"Killed {killed} existing coordinator session(s)")

    log.info("Starting coordinator session...")

    # Create session via HTTP API instead of CLI to inherit global permissions
    try:
        coordinator_title = _get_coordinator_title()
        # Note: Model is set in coordinator's opencode.json, not via API
        # The API model parameter is not always respected by OpenCode
        resp = requests.post(
            f"{OPENCODE_URL}/session",
            json={
                "title": coordinator_title,
                "directory": str(COORDINATOR_DIR),
            },
            timeout=10,
        )
        if resp.status_code != 200:
            log.error(f"Failed to create coordinator session via API: HTTP {resp.status_code}")
            return False

        session_data = resp.json()
        session_id = session_data.get("id")
        if not session_id:
            log.error("API created session but no session ID returned")
            return False

        log.info(f"Created coordinator session via API: {session_id[:8]}")

        COORDINATOR_SESSION_ID = session_id
        ORIENTED_SESSIONS.add(session_id)

        # Log the coordinator's agent if we can detect it
        coordinator_agent_name = get_agent_from_session_messages(session_id)
        if coordinator_agent_name:
            log.info(f"Coordinator is using agent: {coordinator_agent_name}")
        else:
            log.info("Coordinator agent not yet detected (will be logged after first message)")

        # Register coordinator as an agent so other agents can message it
        coordinator_agent = {
            "id": "coordinator",
            "sessionId": session_id,
            "projectPath": str(COORDINATOR_DIR),
            "role": "Agent hub coordinator - facilitates collaboration between agents",
            "capabilities": [
                "agent-hub_send_message",
                "agent-hub_sync",
                "agent-hub_get_hub_status",
            ],
            "collaboratesWith": [],
            "status": "active",
            "lastSeen": int(time.time() * 1000),
        }
        # Write agent file directly (atomic write)
        AGENTS_DIR.mkdir(parents=True, exist_ok=True)
        agent_file = AGENTS_DIR / "coordinator.json"
        atomic_write_json(agent_file, coordinator_agent, indent=2)
        log.info("Registered coordinator as agent 'coordinator'")

        # Send bootstrap prompt synchronously before waiting for READY.
        ready_after_ms = int(time.time() * 1000)

        if not inject_message_sync(session_id, COORDINATOR_BOOTSTRAP_PROMPT):
            log.error(f"Failed to inject coordinator bootstrap prompt for session {session_id[:8]}")
            with suppress(requests.RequestException):
                requests.delete(f"{OPENCODE_URL}/session/{session_id}", timeout=5)
            COORDINATOR_SESSION_ID = None
            ORIENTED_SESSIONS.discard(session_id)
            if agent_file.exists():
                agent_file.unlink()
            return False

        log.info(f"Injected coordinator bootstrap prompt for session {session_id[:8]}")

        if not _wait_for_coordinator_ready(
            session_id, COORDINATOR_READY_TIMEOUT_SECONDS, after_ms=ready_after_ms
        ):
            msg = (
                "Coordinator did not become ready after bootstrap "
                f"within {COORDINATOR_READY_TIMEOUT_SECONDS}s"
            )
            error_context = _get_recent_hub_error_context(session_id)
            if error_context:
                msg = f"{msg}; recent hub error context: {error_context}"
            if COORDINATOR_BOOTSTRAP_REQUIRED:
                log.error(msg)
                with suppress(requests.RequestException):
                    requests.delete(f"{OPENCODE_URL}/session/{session_id}", timeout=5)
                COORDINATOR_SESSION_ID = None
                ORIENTED_SESSIONS.discard(session_id)
                if agent_file.exists():
                    agent_file.unlink()
                return False
            log.warning(f"{msg}; continuing with coordinator in best-effort mode")

        log.info(f"Coordinator session ready: {session_id[:8]}")
        return True

    except Exception as e:
        log.error(f"Failed to start coordinator: {e}")
        return False


def stop_coordinator() -> None:
    """Stop the coordinator session.

    Kills the coordinator session on the hub server via API call.
    """
    global COORDINATOR_SESSION_ID

    if COORDINATOR_SESSION_ID is not None:
        log.info(f"Stopping coordinator session: {COORDINATOR_SESSION_ID[:8]}")
        try:
            resp = requests.delete(f"{OPENCODE_URL}/session/{COORDINATOR_SESSION_ID}", timeout=5)
            if resp.status_code in (200, 204):
                log.info(f"Killed coordinator session {COORDINATOR_SESSION_ID[:8]}")
            else:
                log.warning(f"Failed to kill coordinator session: HTTP {resp.status_code}")
        except Exception as e:
            log.warning(f"Failed to kill coordinator session: {e}")
        COORDINATOR_SESSION_ID = None

        # Clean up coordinator agent file
        try:
            agent_file = AGENTS_DIR / "coordinator.json"
            if agent_file.exists():
                agent_file.unlink()
                log.info("Removed coordinator agent registration")
        except Exception as e:
            log.warning(f"Failed to remove coordinator agent file: {e}")


def notify_coordinator_new_agent(agent_id: str, directory: str) -> None:
    """Notify the coordinator that a new agent has joined.

    Injects a message into the coordinator session so it can
    reach out to the new agent and facilitate collaboration.
    """
    if not COORDINATOR_ENABLED or not COORDINATOR_SESSION_ID:
        return

    before_ms = int(time.time() * 1000)
    notification = f"NEW_AGENT: {agent_id} at {directory}"
    # Notification to coordinator should use coordinator's own agent
    inject_message(COORDINATOR_SESSION_ID, notification, agent="coordinator")
    log.info(f"Notified coordinator of new agent: {agent_id}")

    if not _wait_for_coordinator_activity(COORDINATOR_SESSION_ID, before_ms, timeout_seconds=5):
        log.warning(
            f"Coordinator showed no activity after NEW_AGENT {agent_id}; retrying notification once"
        )
        inject_message(COORDINATOR_SESSION_ID, notification, agent="coordinator")


def poll_coordinator_cost() -> None:
    """Poll coordinator session messages and update cost/token metrics.

    Fetches all messages from the coordinator session via the OpenCode API,
    sums token usage from assistant messages, computes estimated USD cost
    using the configured pricing table, and updates Prometheus metrics.

    Token counts are set as absolute values (not incremented) since we
    re-sum from the full message history each poll. This is idempotent
    and self-correcting.
    """
    if not COORDINATOR_ENABLED or not COORDINATOR_SESSION_ID:
        return

    try:
        resp = requests.get(
            f"{OPENCODE_URL}/session/{COORDINATOR_SESSION_ID}/message",
            timeout=INJECTION_TIMEOUT,
        )
        resp.raise_for_status()
        messages = resp.json()
    except requests.RequestException as e:
        log.debug(f"Failed to fetch coordinator messages for cost tracking: {e}")
        return
    except (ValueError, TypeError):
        return

    if not isinstance(messages, list):
        return

    # Log the coordinator's current agent from most recent message
    if messages:
        most_recent = messages[-1]  # Messages are in chronological order
        info = most_recent.get("info", {})
        agent = info.get("agent")
        if agent:
            log.debug(f"Coordinator using agent: {agent}")

    # Sum token usage from all assistant messages
    total_input = 0
    total_output = 0
    total_cache_read = 0
    total_cache_write = 0
    assistant_count = 0

    for msg in messages:
        info = msg.get("info", {})
        if info.get("role") != "assistant":
            continue

        tokens = info.get("tokens", {})
        total_input += tokens.get("input", 0)
        total_output += tokens.get("output", 0)
        cache = tokens.get("cache", {})
        total_cache_read += cache.get("read", 0)
        total_cache_write += cache.get("write", 0)
        assistant_count += 1

    # Compute estimated cost
    estimated_cost = (
        total_input * PRICING_INPUT
        + total_output * PRICING_OUTPUT
        + total_cache_read * PRICING_CACHE_READ
        + total_cache_write * PRICING_CACHE_WRITE
    )

    # Update metrics (set absolute values, not increments)
    with metrics._lock:
        metrics._counters["agent_hub_coordinator_tokens_input"] = total_input
        metrics._counters["agent_hub_coordinator_tokens_output"] = total_output
        metrics._counters["agent_hub_coordinator_tokens_cache_read"] = total_cache_read
        metrics._counters["agent_hub_coordinator_tokens_cache_write"] = total_cache_write
        metrics._counters["agent_hub_coordinator_messages_total"] = assistant_count
    metrics.set_gauge("agent_hub_coordinator_estimated_cost_usd", round(estimated_cost, 6))

    log.debug(
        f"Coordinator cost: ${estimated_cost:.4f} "
        f"({assistant_count} msgs, {total_input}in/{total_output}out/"
        f"{total_cache_read}cr/{total_cache_write}cw tokens)"
    )


# =============================================================================
# OpenCode Integration
# =============================================================================


def get_sessions_from_db() -> list[dict[str, Any]] | None:
    """Fetch sessions directly from OpenCode's SQLite database.

    This is the primary session discovery mechanism. The hub server's HTTP API
    only returns sessions it created or knew about at startup — it does NOT
    see sessions created by independent TUI processes. Querying the shared
    SQLite database directly sees ALL sessions regardless of which process
    created them.
    """
    if not OPENCODE_DB_PATH.exists():
        log.warning(f"OpenCode database not found: {OPENCODE_DB_PATH}")
        return None

    try:
        # Use WAL mode and read-only to avoid interfering with OpenCode processes
        conn = sqlite3.connect(f"file:{OPENCODE_DB_PATH}?mode=ro", uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                "SELECT id, slug, project_id, directory, title, version,"
                " time_created, time_updated FROM session"
                " WHERE time_archived IS NULL"
                " ORDER BY time_updated DESC"
            ).fetchall()

            sessions: list[dict[str, Any]] = []
            for row in rows:
                sessions.append(
                    {
                        "id": row["id"],
                        "slug": row["slug"],
                        "projectID": row["project_id"],
                        "directory": row["directory"],
                        "title": row["title"],
                        "version": row["version"] or "",
                        "time": {
                            "created": row["time_created"],
                            "updated": row["time_updated"],
                        },
                    }
                )

            log.debug(f"Discovered {len(sessions)} sessions from SQLite DB")
            return sessions
        finally:
            conn.close()

    except sqlite3.OperationalError as e:
        log.warning(f"SQLite session query failed (DB may be locked): {e}")
    except Exception as e:
        log.warning(f"SQLite session discovery failed: {e}")

    return None


def get_sessions_uncached() -> list[dict[str, Any]] | None:
    """Fetch active OpenCode sessions across all projects.

    Queries the shared SQLite database directly for reliable session discovery.
    The hub server HTTP API only sees sessions it manages — independent TUI
    sessions are invisible to it. SQLite sees everything.
    """
    return get_sessions_from_db()


def get_sessions() -> list[dict[str, Any]] | None:
    """Fetch sessions with caching to avoid repeated API calls."""
    global _sessions_cache, _sessions_cache_time

    now = time.time()
    with _sessions_cache_lock:
        if now - _sessions_cache_time < SESSION_CACHE_TTL and _sessions_cache is not None:
            metrics.inc("agent_hub_cache_hits_total")
            return cast(list[dict[str, Any]], _sessions_cache)

        # Cache miss or expired
        metrics.inc("agent_hub_cache_misses_total")
        sessions = get_sessions_uncached()
        if sessions is not None:  # Only update cache on success
            _sessions_cache = sessions
            _sessions_cache_time = now
        return sessions


def invalidate_session_cache() -> None:
    """Force cache refresh on next get_sessions() call."""
    global _sessions_cache_time
    with _sessions_cache_lock:
        _sessions_cache_time = 0


def find_sessions_for_agent(agent: dict, sessions: list[dict]) -> list[dict]:
    """Find the session for an agent by session ID.

    Uses session ID-based lookup for precise routing. Each agent is now
    associated with exactly one session, enabling multiple agents to
    operate in the same working directory.

    Falls back to directory-based matching for legacy agents without sessionId.
    """
    # Primary: session ID-based lookup (new behavior)
    session = find_session_for_agent(agent, sessions)
    if session:
        return [session]

    # Fallback: directory-based matching for legacy agents
    agent_path = agent.get("projectPath", "")
    if not agent_path:
        return []

    matching = [s for s in sessions if s.get("directory") == agent_path]
    if not matching:
        return []

    # Return only the most recently updated session
    matching.sort(key=lambda s: s.get("time", {}).get("updated", 0), reverse=True)
    return [matching[0]]


def inject_message_sync(session_id: str, text: str, agent: str | None = None) -> bool:
    """Inject message into OpenCode session (synchronous, with retries).

    Uses /prompt_async endpoint which triggers LLM invocation even when idle.
    The /message endpoint with noReply:false only adds to context without
    actually invoking the LLM when the session is idle.

    Args:
        session_id: Target session ID
        text: Message text to inject
        agent: Optional agent ID to use for handling this message. When provided,
               OpenCode will use this agent instead of the default.
    """
    payload: dict[str, Any] = {
        "parts": [{"type": "text", "text": text}],
    }
    if agent:
        payload["agent"] = agent

    for attempt in range(INJECTION_RETRIES):
        try:
            # Use prompt_async to actually trigger LLM invocation
            # The /message endpoint only adds to context, doesn't wake idle sessions
            resp = requests.post(
                f"{OPENCODE_URL}/session/{session_id}/prompt_async",
                json=payload,
                timeout=INJECTION_TIMEOUT,
            )
            # prompt_async returns 204 No Content on success
            if resp.status_code in (200, 204):
                agent_info = f" [agent={agent}]" if agent else ""
                log.info(
                    f"Injected message into session {session_id[:8]}... (prompt_async){agent_info}"
                )
                metrics.inc("agent_hub_injections_total")
                return True
            else:
                log.warning(f"Injection attempt {attempt + 1} failed: {resp.status_code}")
        except requests.RequestException as e:
            log.warning(f"Injection attempt {attempt + 1} failed: {e}")

        if attempt < INJECTION_RETRIES - 1:
            metrics.inc("agent_hub_injections_retried_total")
            time.sleep(0.5 * (attempt + 1))  # Backoff

    log.error(f"Injection failed after {INJECTION_RETRIES} attempts for session {session_id[:8]}")
    metrics.inc("agent_hub_injections_failed_total")
    return False


def inject_message(session_id: str, text: str, agent: str | None = None) -> None:
    """Queue message for async injection (non-blocking).

    Args:
        session_id: Target session ID
        text: Message text to inject
        agent: Optional agent ID to use for handling this message
    """
    _injection_queue.put(InjectionTask(session_id=session_id, text=text, agent=agent))


def injection_worker(shutdown_event: threading.Event) -> None:
    """Worker thread that processes injection queue."""
    while not shutdown_event.is_set():
        try:
            task = _injection_queue.get(timeout=1)
        except queue.Empty:
            continue

        try:
            inject_message_sync(task.session_id, task.text, task.agent)
        except Exception as e:
            log.error(f"Injection worker error: {e}")
        finally:
            _injection_queue.task_done()


def message_worker(agents: dict[str, dict], shutdown_event: threading.Event) -> None:
    """Worker thread that processes message queue."""
    while not shutdown_event.is_set():
        try:
            task = _message_queue.get(timeout=1)
        except queue.Empty:
            continue

        try:
            # Small delay to ensure file is fully written
            time.sleep(0.1)
            if task.path.exists():
                process_message_file(task.path, agents)
        except Exception as e:
            log.error(f"Message worker error: {e}")
        finally:
            _message_queue.task_done()


def session_worker(agents: dict[str, dict], shutdown_event: threading.Event) -> None:
    """Worker thread that processes session orientation queue."""
    while not shutdown_event.is_set():
        try:
            task = _session_queue.get(timeout=1)
        except queue.Empty:
            continue

        try:
            # Small delay to ensure file is fully written
            time.sleep(0.2)
            if task.path.exists():
                process_session_file(task.path, agents)
        except Exception as e:
            log.error(f"Session worker error: {e}")
        finally:
            _session_queue.task_done()


# =============================================================================
# Session Orientation
# =============================================================================


def load_opencode_session(path: Path) -> dict[str, Any] | None:
    """Load an OpenCode session file."""
    try:
        return cast(dict[str, Any], json.loads(path.read_text()))
    except (json.JSONDecodeError, OSError) as e:
        log.warning(f"Failed to load session {path}: {e}")
        return None


def find_agent_for_directory(
    directory: str, agents: dict[str, dict[str, Any]]
) -> dict[str, Any] | None:
    """Find registered agent matching a directory/projectPath."""
    for agent in agents.values():
        if agent.get("projectPath") == directory:
            return agent
    return None


def get_or_create_agent_for_directory(
    directory: str, agents: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    """Find or auto-create an agent for a directory.

    If no agent is registered for this directory, creates one automatically
    based on the directory name.
    """
    # Check for existing agent
    existing = find_agent_for_directory(directory, agents)
    if existing:
        return existing

    # Auto-create agent from directory
    dir_name = Path(directory).name or "root"
    agent_id = dir_name.lower().replace(" ", "-").replace("_", "-")

    # Handle conflicts by appending parent dir
    if agent_id in agents:
        parent = Path(directory).parent.name
        agent_id = f"{parent}-{agent_id}".lower().replace(" ", "-")

    agent = {
        "id": agent_id,
        "projectPath": directory,
        "role": f"Auto-registered agent for {directory}",
        "capabilities": [],
        "collaboratesWith": [],
        "lastSeen": int(time.time() * 1000),
        "status": "active",
        "autoCreated": True,
    }

    # Save to disk (atomic write to prevent readers seeing partial files)
    agent_file = AGENTS_DIR / f"{agent_id}.json"
    try:
        atomic_write_json(agent_file, agent, indent=2)
        agents[agent_id] = agent
        metrics.inc("agent_hub_agents_auto_created_total")
        metrics.set_gauge("agent_hub_active_agents", len(agents))
        log.info(f"Auto-registered agent '{agent_id}' for {directory}")
    except OSError as e:
        log.error(f"Failed to save auto-created agent: {e}")

    return agent


def generate_agent_id_for_session(session: dict[str, Any]) -> str:
    """Generate a unique agent ID from session metadata.

    Uses session slug if available (human-readable), otherwise falls back
    to session ID. This ensures each session gets a unique agent identity
    even when multiple sessions share the same working directory.
    """
    slug = session.get("slug")
    session_id = cast(str, session.get("id", ""))

    if slug:
        # Use slug as primary identifier (e.g., "cosmic-panda")
        return cast(str, slug)

    # Fallback to session ID (truncated for readability)
    if session_id.startswith("ses_"):
        # Use the unique portion after "ses_" prefix, truncated
        return f"session-{session_id[4:16]}"

    return f"session-{session_id[:12]}" if session_id else "unknown-session"


def get_agent_from_session_messages(session_id: str) -> str | None:
    """Get the current agent for a session from the most recent message.

    Queries the OpenCode SQLite database to find the agent used in the
    most recent message for this session. This reflects the actual running
    agent, not just the configured default.

    Args:
        session_id: The session ID to look up

    Returns:
        The agent name (e.g., "kimi", "claude", " coordinator") or None
    """
    if not session_id or not OPENCODE_DB_PATH.exists():
        return None

    try:
        conn = sqlite3.connect(f"file:{OPENCODE_DB_PATH}?mode=ro", uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            # Get the most recent message for this session
            row = conn.execute(
                "SELECT data FROM message WHERE session_id = ? ORDER BY time_created DESC LIMIT 1",
                (session_id,),
            ).fetchone()

            if row and row["data"]:
                msg_data = json.loads(row["data"])
                # Agent is stored in the message data
                agent = msg_data.get("agent")
                if isinstance(agent, str) and agent:
                    log.debug(f"Detected agent '{agent}' from session {session_id[:12]}")
                    return agent
        finally:
            conn.close()
    except (sqlite3.Error, json.JSONDecodeError, OSError) as e:
        log.debug(f"Failed to get agent from session messages: {e}")

    return None


def get_or_create_agent_for_session(
    session: dict[str, Any], agents: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    """Find or auto-create an agent for a specific session.

    Unlike get_or_create_agent_for_directory(), this creates a unique agent
    identity per session, allowing multiple TUI sessions in the same directory
    to have separate agent identities.

    The agent ID is derived from the session's actual running agent (queried
    from the SQLite database), or falls back to the session slug/ID.
    """
    session_id = cast(str, session.get("id", ""))

    # Check if we already have a mapping for this session
    if session_id in SESSION_AGENTS:
        agent_id = SESSION_AGENTS[session_id]["agentId"]
        if agent_id in agents:
            return agents[agent_id]

    directory = cast(str, session.get("directory", ""))

    # Try to get the actual agent from the session's most recent message
    detected_agent = get_agent_from_session_messages(session_id)
    # Use detected agent, or fall back to session slug/ID
    agent_id = detected_agent or generate_agent_id_for_session(session)

    # Handle conflicts by appending session ID fragment
    if agent_id in agents and agents[agent_id].get("sessionId") != session_id:
        # Different session has this slug - append uniquifier
        agent_id = f"{agent_id}-{session_id[4:12]}" if session_id.startswith("ses_") else agent_id

    agent = {
        "id": agent_id,
        "sessionId": session_id,  # Track which session this agent represents
        "projectPath": directory,  # Keep for reference/display
        "slug": session.get("slug"),
        "role": f"Session agent for {cast(str, session.get('title', directory))[:50]}",
        "capabilities": [],
        "collaboratesWith": [],
        "lastSeen": int(time.time() * 1000),
        "status": "active",
        "autoCreated": True,
    }

    # Update session-to-agent mapping
    SESSION_AGENTS[session_id] = {
        "agentId": agent_id,
        "directory": directory,
        "slug": session.get("slug"),
    }
    save_session_agents()

    # Save agent to disk (atomic write to prevent readers seeing partial files)
    agent_file = AGENTS_DIR / f"{agent_id}.json"
    try:
        atomic_write_json(agent_file, agent, indent=2)
        agents[agent_id] = agent
        metrics.inc("agent_hub_agents_auto_created_total")
        metrics.set_gauge("agent_hub_active_agents", len(agents))
        log.info(f"Auto-registered session agent '{agent_id}' for session {session_id[:12]}")
    except OSError as e:
        log.error(f"Failed to save auto-created session agent: {e}")

    return agent


def find_session_for_agent(
    agent: dict[str, Any], sessions: list[dict[str, Any]]
) -> dict[str, Any] | None:
    """Find the session associated with an agent by session ID.

    This replaces directory-based matching with direct session ID lookup,
    enabling precise routing to specific sessions.
    """
    agent_session_id = agent.get("sessionId")
    if not agent_session_id:
        # Fallback for legacy agents without sessionId - check SESSION_AGENTS mapping
        agent_id = agent.get("id", "")
        for sid, mapping in SESSION_AGENTS.items():
            if mapping.get("agentId") == agent_id:
                agent_session_id = sid
                break

    if not agent_session_id:
        return None

    for session in sessions:
        if session.get("id") == agent_session_id:
            return session

    return None


def format_orientation(agent: dict[str, Any], all_agents: dict[str, dict[str, Any]]) -> str:
    """Format orientation message for a newly detected agent session.

    Includes registration instructions with the session-specific agent ID.
    This ensures the agent registers with agent-hub-mcp using the unique
    ID assigned by the daemon, enabling multiple sessions in the same
    directory to have separate identities.
    """
    agent_id = agent.get("id", "unknown")
    directory = agent.get("projectPath", "")

    # List other active agents (exclude self)
    other_agents = [aid for aid, a in all_agents.items() if aid != agent_id and is_agent_active(a)]

    parts = [f"Agent hub connected. You are: {agent_id}"]

    if other_agents:
        agents_str = ", ".join(other_agents[:5])
        if len(other_agents) > 5:
            agents_str += f" (+{len(other_agents) - 5} more)"
        parts.append(f"Other agents: {agents_str}")

    parts.append("Tools: agent-hub_send_message, agent-hub_sync")

    # Add registration instruction with session-specific ID
    # This ensures agent-hub-mcp creates a unique agent entry for this session
    parts.append(
        f'Register with: agent-hub_register_agent(id="{agent_id}", '
        f'projectPath="{directory}", role="your role")'
    )

    return " | ".join(parts)


def orient_session(
    session_id: str, agent: dict[str, Any], all_agents: dict[str, dict[str, Any]]
) -> bool:
    """Inject orientation message into a session and notify coordinator."""
    if not session_id:
        return False

    if session_id in ORIENTED_SESSIONS:
        return False  # Already oriented

    agent_id = agent.get("id", "unknown")
    directory = agent.get("projectPath", "")

    # Skip coordinator session itself — match by session ID, not directory,
    # because OpenCode resolves directory to the hub server's project root
    # rather than honouring the cwd passed to `opencode run`.
    if COORDINATOR_SESSION_ID and session_id == COORDINATOR_SESSION_ID:
        ORIENTED_SESSIONS.add(session_id)
        save_oriented_sessions()
        return True

    # Inject minimal orientation to the agent
    orientation = format_orientation(agent, all_agents)
    # Orientation comes from the daemon, use the target agent's ID as context
    inject_message(session_id, orientation, agent=agent_id)

    # Notify coordinator of new agent (coordinator will reach out to capture task)
    notify_coordinator_new_agent(cast(str, agent_id), cast(str, directory))

    ORIENTED_SESSIONS.add(session_id)
    save_oriented_sessions()
    metrics.inc("agent_hub_sessions_oriented_total")
    metrics.set_gauge("agent_hub_oriented_sessions", len(ORIENTED_SESSIONS))

    # Track for retry if agent doesn't respond
    if ORIENTATION_RETRY_MAX > 0:
        ORIENTATION_PENDING[session_id] = {
            "oriented_at": time.time(),
            "retries": 0,
            "agent_id": agent_id,
        }

    log.info(f"Oriented session {session_id[:8]} for agent {agent_id}")
    return True


def check_orientation_retries(agents: dict[str, dict[str, Any]]) -> None:
    """Re-inject orientation for sessions that haven't responded.

    Checks ORIENTATION_PENDING for sessions where:
    - More than ORIENTATION_RETRY_DELAY seconds have passed since last attempt
    - Retries < ORIENTATION_RETRY_MAX

    A session is considered "responded" when its agent's lastSeen timestamp
    (updated by agent-hub MCP register_agent) is newer than the orientation time.

    After ORIENTATION_RETRY_MAX retries without response, the session is
    removed from pending and a warning is logged.
    """
    if not ORIENTATION_PENDING:
        return

    now = time.time()
    resolved: list[str] = []

    for session_id, pending in ORIENTATION_PENDING.items():
        agent_id = pending["agent_id"]
        oriented_at = pending["oriented_at"]
        retries = pending["retries"]

        # Check if agent has responded (lastSeen updated after orientation)
        agent = agents.get(agent_id)
        if agent:
            last_seen_s = agent.get("lastSeen", 0) / 1000  # Convert ms to s
            if last_seen_s > oriented_at:
                resolved.append(session_id)
                log.debug(f"Session {session_id[:8]} agent {agent_id} responded, clearing retry")
                continue

        elapsed = now - oriented_at
        if elapsed < ORIENTATION_RETRY_DELAY:
            continue  # Not yet time to retry

        if retries >= ORIENTATION_RETRY_MAX:
            # Give up
            resolved.append(session_id)
            metrics.inc("agent_hub_orientation_gave_up_total")
            log.warning(
                f"Session {session_id[:8]} agent {agent_id} never responded "
                f"after {retries} orientation retries, giving up"
            )
            continue

        # Retry: re-inject orientation
        orientation = format_orientation(
            agent or {"id": agent_id, "projectPath": ""},
            agents,
        )
        inject_message(session_id, orientation, agent=agent_id)
        pending["retries"] = retries + 1
        pending["oriented_at"] = now  # Reset timer for next retry window
        metrics.inc("agent_hub_orientation_retries_total")
        log.info(
            f"Orientation retry {pending['retries']}/{ORIENTATION_RETRY_MAX} "
            f"for session {session_id[:8]} agent {agent_id}"
        )

    for session_id in resolved:
        del ORIENTATION_PENDING[session_id]


def process_session_file(path: Path, agents: dict[str, dict[str, Any]]) -> None:
    """Process an OpenCode session file and orient if needed.

    Only orients sessions created AFTER the daemon started.
    Creates a unique agent identity per session using session ID/slug.
    """
    session = load_opencode_session(path)
    if not session:
        return

    session_id = cast(str, session.get("id", ""))
    if not session_id:
        return

    if session_id in ORIENTED_SESSIONS:
        return  # Already oriented

    # Skip coordinator session - mark as oriented but don't create agent
    if COORDINATOR_SESSION_ID and session_id == COORDINATOR_SESSION_ID:
        ORIENTED_SESSIONS.add(session_id)
        return

    # Only orient sessions created AFTER daemon started
    created_ms = cast(int, session.get("time", {}).get("created", 0))
    if created_ms < DAEMON_START_TIME_MS:
        log.debug(f"Session {session_id[:8]} predates daemon start, skipping")
        return

    directory = session.get("directory", "")
    if not directory:
        return

    # Get or auto-create agent for this session (unique per session)
    # Note: Coordinator also registers as an agent so it can receive messages
    agent = get_or_create_agent_for_session(session, agents)
    log.info(f"File watcher: new session {session_id[:8]}, orienting as {agent.get('id')}")
    orient_session(session_id, agent, agents)


def poll_active_sessions(agents: dict[str, dict[str, Any]]) -> None:
    """Poll API for active sessions and orient any new ones.

    Only considers sessions created AFTER the daemon started. This ensures:
    - Historical sessions are never spammed with orientation messages
    - Only genuinely new TUI sessions get oriented
    - Daemon restart gives a clean slate

    Sessions are oriented once and tracked in ORIENTED_SESSIONS to prevent
    repeated messaging. Each session gets a unique agent identity based on
    its session ID/slug, allowing multiple sessions in the same directory.
    """
    sessions = get_sessions()
    if not sessions:
        return

    for session in sessions:
        session_id = cast(str, session.get("id", ""))
        if not session_id or session_id in ORIENTED_SESSIONS:
            continue

        # Skip coordinator session - mark as oriented but don't create agent
        if COORDINATOR_SESSION_ID and session_id == COORDINATOR_SESSION_ID:
            ORIENTED_SESSIONS.add(session_id)
            continue

        # Only orient sessions created AFTER daemon started
        created_ms = cast(int, session.get("time", {}).get("created", 0))
        if created_ms < DAEMON_START_TIME_MS:
            continue

        directory = session.get("directory", "")
        if not directory:
            continue

        agent = get_or_create_agent_for_session(session, agents)
        log.info(f"New session {session_id[:8]} orienting as {agent.get('id')}")
        orient_session(session_id, agent, agents)


def format_notification(msg: dict[str, Any], to_agent_id: str) -> str:
    """Format minimal agent-hub message notification."""
    from_agent = msg.get("from", "unknown")
    msg_type = msg.get("type", "message")
    content = msg.get("content", "")
    priority = msg.get("priority", "normal")
    thread_id = msg.get("threadId", "")

    # Build concise notification
    prefix = "URGENT: " if priority == "urgent" else ""
    header = f"[{msg_type}] from {from_agent}"
    if thread_id:
        header += f" (thread: {thread_id})"

    lines = [
        f"{prefix}{header}",
        cast(str, content),
        "",
        f'Reply: agent-hub_send_message(from="{to_agent_id}", to="{from_agent}", type="completion", content="...")',
    ]

    return "\n".join(lines)


# =============================================================================
# Message Processing
# =============================================================================


def process_message_file(path: Path, agents: dict[str, dict[str, Any]]) -> None:
    """Process a new message file and inject if applicable."""
    try:
        msg = cast(dict[str, Any], json.loads(path.read_text()))
    except (json.JSONDecodeError, OSError) as e:
        log.warning(f"Failed to read message {path}: {e}")
        metrics.inc("agent_hub_messages_failed_total")
        return

    # Check rate limiting for sender
    sender = cast(str, msg.get("from", "unknown"))
    allowed, reason = check_rate_limit(sender)
    if not allowed:
        log.warning(f"Rate limited message from {sender}: {reason}")
        metrics.inc("agent_hub_messages_failed_total")
        # Archive the rate-limited message
        ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        msg["rateLimited"] = True
        msg["rateLimitReason"] = reason
        path.write_text(json.dumps(msg, indent=2))
        dest = ARCHIVE_DIR / path.name
        path.rename(dest)
        return

    # Record this message for rate limiting
    record_message_sent(sender)

    # Ensure message has a threadId
    ensure_thread_id(msg, path)

    # Check if this message resolves a thread
    if check_thread_resolution(msg):
        metrics.inc("agent_hub_messages_total")
        return  # Thread resolved, messages archived

    # Determine target agent(s)
    to = msg.get("to", "")
    if to == "all":
        target_agents = list(agents.values())
    elif to in agents:
        target_agents = [agents[cast(str, to)]]
    else:
        log.info(f"Unknown target agent: {to}")
        metrics.inc("agent_hub_messages_failed_total")
        return

    # Skip if already read
    if msg.get("read"):
        return

    all_sessions = get_sessions()
    if not all_sessions:
        log.info("No active sessions for message delivery")
        return

    # Only deliver to sessions created after daemon start (plus coordinator)
    sessions = [
        s
        for s in all_sessions
        if s.get("time", {}).get("created", 0) >= DAEMON_START_TIME_MS
        or (COORDINATOR_SESSION_ID and s.get("id") == COORDINATOR_SESSION_ID)
    ]

    log.info(
        f"Processing message from {msg.get('from')} to {to}, "
        f"{len(sessions)} active sessions (of {len(all_sessions)} total)"
    )

    delivered = False
    for agent in target_agents:
        # Don't notify sender
        if agent["id"] == msg.get("from"):
            log.info(f"Skipping sender {agent['id']}")
            continue

        matching_sessions = find_sessions_for_agent(agent, sessions)
        log.info(
            f"Agent {agent['id']} (path={agent.get('projectPath')}) has {len(matching_sessions)} matching sessions"
        )
        if matching_sessions:
            notification = format_notification(msg, cast(str, agent["id"]))
            # Use the target agent's ID so the message is handled by their configured agent
            target_agent_id = cast(str, agent["id"])
            for session in matching_sessions:
                log.info(
                    f"Injecting message into session {session['id']} for agent {target_agent_id}"
                )
                inject_message(cast(str, session["id"]), notification, agent=target_agent_id)
                delivered = True
        else:
            log.info(f"No session found for agent {agent['id']}")

    if delivered:
        # Mark message as read to prevent re-delivery
        msg["read"] = True
        msg["deliveredAt"] = time.time()
        try:
            path.write_text(json.dumps(msg, indent=2))
            log.info(f"Marked message {path.name} as read")
        except OSError as e:
            log.warning(f"Marked message as read failed: {e}")
        metrics.inc("agent_hub_messages_total")
    else:
        metrics.inc("agent_hub_messages_failed_total")


# =============================================================================
# Event Handler
# =============================================================================


class MessageHandler(FileSystemEventHandler):
    """Handle new message files in ~/.agent-hub/messages/."""

    def on_created(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        path = Path(cast(str, event.src_path))
        if path.suffix != ".json":
            return
        # Ignore archive directory
        if "archive" in path.parts:
            return

        log.info(f"New message file detected: {path.name}")
        # Queue for async processing (non-blocking)
        _message_queue.put(MessageTask(path=path))


class SessionHandler(FileSystemEventHandler):
    """Handle NEW OpenCode session files for orientation.

    Only orients on file creation, not modification.
    This prevents re-orienting existing sessions on every file update.
    """

    def on_created(self, event: FileSystemEvent) -> None:
        """Only orient when a NEW session file is created."""
        if event.is_directory:
            return
        path = Path(cast(str, event.src_path))
        if path.suffix != ".json":
            return
        if not path.name.startswith("ses_"):
            return

        log.debug(f"New session file created: {path.name}")
        # Queue for async processing (non-blocking)
        _session_queue.put(SessionTask(path=path))


class AgentHandler(FileSystemEventHandler):
    """Handle agent registration changes to reload agents dict."""

    def __init__(self, agents: dict[str, dict[str, Any]]):
        self.agents = agents

    def on_created(self, event: FileSystemEvent) -> None:
        self._reload()

    def on_modified(self, event: FileSystemEvent) -> None:
        self._reload()

    def on_deleted(self, event: FileSystemEvent) -> None:
        self._reload()

    def _reload(self) -> None:
        """Reload agents from disk."""
        new_agents = load_agents()
        self.agents.clear()
        self.agents.update(new_agents)
        log.debug(f"Reloaded agents: {list(self.agents.keys())}")


# =============================================================================
# Service Installation
# =============================================================================

# Systemd user service template - ExecStart path is dynamically set
SYSTEMD_SERVICE_TEMPLATE = """\
# systemd user service for agent-hub-daemon
# Installed by: agent-hub-daemon --install-service

[Unit]
Description=OpenCode Agent Hub Daemon
Documentation=https://github.com/xnoto/opencode-agent-hub
After=network.target

[Service]
Type=simple
ExecStart={exec_path}
Restart=on-failure
RestartSec=5

# Environment
Environment=AGENT_HUB_DAEMON_LOG_LEVEL=INFO
Environment=OPENCODE_PORT=4096

# Logging (stdout/stderr go to journal)
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=default.target
"""


def find_daemon_executable() -> str:
    """Find the path to the agent-hub-daemon executable."""
    daemon_bin = shutil.which("agent-hub-daemon")
    if daemon_bin:
        return daemon_bin

    common_paths = [
        Path.home() / ".local/bin/agent-hub-daemon",
        Path("/usr/bin/agent-hub-daemon"),
        Path("/usr/local/bin/agent-hub-daemon"),
    ]
    for p in common_paths:
        if p.exists() and os.access(p, os.X_OK):
            return str(p)

    return "agent-hub-daemon"


def install_systemd_service() -> bool:
    """Install and start the systemd user service (Linux only)."""
    if sys.platform != "linux":
        print("Error: --install-service is only supported on Linux.", file=sys.stderr)
        print()
        if sys.platform == "darwin":
            print("On macOS, install via Homebrew instead:")
            print("  brew install xnoto/tap/opencode-agent-hub")
            print("  brew services start opencode-agent-hub")
        else:
            print(f"Platform '{sys.platform}' is not supported for service installation.")
            print("Run the daemon manually or create a service configuration for your platform.")
        return False

    service_dir = Path.home() / ".config/systemd/user"
    service_file = service_dir / "agent-hub-daemon.service"

    exec_path = find_daemon_executable()
    log.info(f"Using executable: {exec_path}")

    try:
        service_dir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        log.error(f"Failed to create service directory: {e}")
        return False

    service_content = SYSTEMD_SERVICE_TEMPLATE.format(exec_path=exec_path)
    try:
        service_file.write_text(service_content)
        log.info(f"Wrote service file: {service_file}")
    except OSError as e:
        log.error(f"Failed to write service file: {e}")
        return False

    result = subprocess.run(
        ["systemctl", "--user", "daemon-reload"], capture_output=True, text=True
    )
    if result.returncode != 0:
        log.error(f"Failed to reload systemd: {result.stderr}")
        return False

    result = subprocess.run(
        ["systemctl", "--user", "enable", "agent-hub-daemon"], capture_output=True, text=True
    )
    if result.returncode != 0:
        log.error(f"Failed to enable service: {result.stderr}")
        return False

    result = subprocess.run(
        ["systemctl", "--user", "start", "agent-hub-daemon"], capture_output=True, text=True
    )
    if result.returncode != 0:
        log.error(f"Failed to start service: {result.stderr}")
        return False

    print("Service installed and started successfully!")
    print("\nManagement commands:")
    print("  systemctl --user status agent-hub-daemon")
    print("  systemctl --user stop agent-hub-daemon")
    print("  systemctl --user restart agent-hub-daemon")
    print("  journalctl --user -u agent-hub-daemon -f")
    print("\nTo uninstall: agent-hub-daemon --uninstall-service")
    return True


def uninstall_systemd_service() -> bool:
    """Stop, disable, and remove the systemd user service (Linux only)."""
    if sys.platform != "linux":
        print("Error: --uninstall-service is only supported on Linux.", file=sys.stderr)
        print()
        if sys.platform == "darwin":
            print("On macOS, uninstall via Homebrew:")
            print("  brew services stop opencode-agent-hub")
            print("  brew uninstall opencode-agent-hub")
        else:
            print(f"Platform '{sys.platform}' is not supported for service uninstallation.")
        return False

    service_file = Path.home() / ".config/systemd/user/agent-hub-daemon.service"

    subprocess.run(
        ["systemctl", "--user", "stop", "agent-hub-daemon"], capture_output=True, text=True
    )
    subprocess.run(
        ["systemctl", "--user", "disable", "agent-hub-daemon"], capture_output=True, text=True
    )

    if service_file.exists():
        try:
            service_file.unlink()
            log.info(f"Removed service file: {service_file}")
        except OSError as e:
            log.error(f"Failed to remove service file: {e}")
            return False

    subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True, text=True)
    print("Service uninstalled successfully!")
    return True


# =============================================================================
# Main
# =============================================================================


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Agent Hub Daemon - Multi-agent coordination for OpenCode",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  agent-hub-daemon                    # Run daemon in foreground
  agent-hub-daemon --install-service  # Install as systemd user service
  agent-hub-daemon --uninstall-service
""",
    )
    parser.add_argument(
        "--install-service", action="store_true", help="Install and start as systemd user service"
    )
    parser.add_argument(
        "--uninstall-service", action="store_true", help="Remove systemd user service"
    )
    parser.add_argument("--version", action="store_true", help="Show version and exit")

    args = parser.parse_args()

    if args.version:
        from opencode_agent_hub import __version__

        print(f"agent-hub-daemon {__version__}")
        sys.exit(0)

    if args.install_service:
        sys.exit(0 if install_systemd_service() else 1)

    if args.uninstall_service:
        sys.exit(0 if uninstall_systemd_service() else 1)

    # Preflight: verify agent-hub MCP is configured before starting
    try:
        check_agent_hub_mcp_configured()
    except PreflightError as e:
        log.error(f"Preflight check failed: {e}")
        raise SystemExit(1) from None

    # Ensure directories exist
    MESSAGES_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    THREADS_DIR.mkdir(parents=True, exist_ok=True)
    AGENTS_DIR.mkdir(parents=True, exist_ok=True)

    # Purge stale agent registrations from previous daemon runs.
    # Agents are ephemeral — live agents re-register via MCP on their own.
    # Without this, the coordinator would broadcast to dead agents on startup.
    purged = 0
    for agent_file in AGENTS_DIR.glob("*.json"):
        try:
            agent_file.unlink()
            purged += 1
        except OSError:
            pass
    if purged:
        log.info(f"Purged {purged} stale agent registrations from previous run")

    # Load persisted state
    # Only sessions created AFTER daemon starts will be oriented
    global ORIENTED_SESSIONS, SESSION_AGENTS, DAEMON_START_TIME_MS, ORIENTATION_PENDING
    DAEMON_START_TIME_MS = int(time.time() * 1000)
    ORIENTED_SESSIONS = load_oriented_sessions()
    SESSION_AGENTS = load_session_agents()
    ORIENTATION_PENDING = {}

    log.info(
        f"Daemon starting at {DAEMON_START_TIME_MS} - {len(ORIENTED_SESSIONS)} sessions already oriented"
    )
    log.info(f"Watching messages: {MESSAGES_DIR}")
    log.info(f"Watching sessions: {OPENCODE_STORAGE_DIR}")
    log.info(f"Watching agents: {AGENTS_DIR}")
    log.info(f"OpenCode API: {OPENCODE_URL}")
    log.info(f"Message TTL: {MESSAGE_TTL_SECONDS}s, GC interval: {GC_INTERVAL_SECONDS}s")
    log.info("Agent detection: enabled (detects agent from session messages)")
    if COORDINATOR_ENABLED:
        log.info(f"Coordinator: enabled, dir={COORDINATOR_DIR}")
    else:
        log.info("Coordinator: disabled")

    # Start hub server if not already running
    start_hub_server()

    # Start coordinator (after hub server is ready)
    if not start_coordinator():
        log.error("Failed to start coordinator - daemon cannot function without it")
        # Clean up resources before exiting
        stop_hub_server()
        sys.exit(1)

    # Shared agents dict - updated by AgentHandler
    agents = load_agents()
    log.info(f"Loaded {len(agents)} registered agents: {list(agents.keys())}")

    # Set up observers
    observer = Observer()

    # Watch messages directory
    message_handler = MessageHandler()
    observer.schedule(message_handler, str(MESSAGES_DIR), recursive=False)

    # Watch OpenCode sessions directory (if exists)
    # Watches recursively to catch both global/ and project-specific subdirectories
    # Only triggers on NEW session files - does NOT scan existing sessions on startup
    # This prevents spamming hundreds of sessions with orientation messages
    if OPENCODE_STORAGE_DIR.exists():
        session_handler = SessionHandler()
        observer.schedule(session_handler, str(OPENCODE_STORAGE_DIR), recursive=True)
        log.info(f"Watching for new sessions in {OPENCODE_STORAGE_DIR} (recursive)")
    else:
        log.warning(f"Sessions directory not found: {OPENCODE_STORAGE_DIR}")

    # Watch agents directory for registration changes
    agent_handler = AgentHandler(agents)
    observer.schedule(agent_handler, str(AGENTS_DIR), recursive=False)

    observer.start()

    # Shutdown event for coordinating thread termination
    shutdown_event = threading.Event()

    # Handle signals for graceful shutdown
    def shutdown_handler(signum: int, frame: Any) -> None:
        log.info(f"Received signal {signum}, shutting down...")
        shutdown_event.set()
        observer.stop()
        stop_coordinator()
        stop_hub_server()

    signal.signal(signal.SIGTERM, shutdown_handler)
    signal.signal(signal.SIGINT, shutdown_handler)
    if hasattr(signal, "SIGHUP"):
        signal.signal(signal.SIGHUP, shutdown_handler)

    def session_poller() -> None:
        """Background thread that polls for new active sessions."""
        while not shutdown_event.is_set():
            try:
                poll_active_sessions(agents)
                check_orientation_retries(agents)
            except Exception as e:
                log.error(f"Session poller error: {e}")
            shutdown_event.wait(SESSION_POLL_SECONDS)

    def gc_worker() -> None:
        """Background thread for garbage collection."""
        while not shutdown_event.is_set():
            try:
                run_gc(agents)
            except Exception as e:
                log.error(f"GC error: {e}")
            shutdown_event.wait(GC_INTERVAL_SECONDS)

    def hub_monitor() -> None:
        """Background thread to monitor hub server health."""
        while not shutdown_event.is_set():
            if HUB_SERVER_PROCESS is not None and HUB_SERVER_PROCESS.poll() is not None:
                log.warning("Hub server died, restarting...")
                start_hub_server()
            shutdown_event.wait(10)  # Check every 10 seconds

    def coordinator_monitor() -> None:
        """Background thread to monitor coordinator session on hub server."""
        while not shutdown_event.is_set():
            if COORDINATOR_ENABLED and COORDINATOR_SESSION_ID is not None:
                # Verify session still exists on hub
                session = find_coordinator_session()
                if session is None:
                    log.warning("Coordinator session disappeared from hub")
                    # Note: We don't restart - coordinator is only created at daemon startup
            shutdown_event.wait(30)  # Check every 30 seconds

    def metrics_worker() -> None:
        """Background thread to write metrics and log summaries."""
        while not shutdown_event.is_set():
            try:
                # Update queue gauges
                metrics.set_gauge("agent_hub_injection_queue_size", _injection_queue.qsize())
                metrics.set_gauge("agent_hub_message_queue_size", _message_queue.qsize())

                # Update coordinator cost metrics
                poll_coordinator_cost()

                # Write Prometheus metrics file
                METRICS_FILE.write_text(metrics.to_prometheus())

                # Log summary
                log.info(f"Metrics: {metrics.log_summary()}")
            except Exception as e:
                log.error(f"Metrics worker error: {e}")
            shutdown_event.wait(METRICS_INTERVAL)

    # Set initial gauge values
    metrics.set_gauge("agent_hub_active_agents", len(agents))
    metrics.set_gauge("agent_hub_oriented_sessions", len(ORIENTED_SESSIONS))

    # Start background threads
    threads = [
        threading.Thread(target=session_poller, name="session-poller", daemon=True),
        threading.Thread(target=gc_worker, name="gc-worker", daemon=True),
        threading.Thread(target=hub_monitor, name="hub-monitor", daemon=True),
        threading.Thread(target=coordinator_monitor, name="coordinator-monitor", daemon=True),
        threading.Thread(target=metrics_worker, name="metrics-worker", daemon=True),
        threading.Thread(
            target=lambda: message_worker(agents, shutdown_event),
            name="message-worker",
            daemon=True,
        ),
        threading.Thread(
            target=lambda: session_worker(agents, shutdown_event),
            name="session-worker",
            daemon=True,
        ),
    ]

    # Start injection workers (pool for concurrent injections)
    for i in range(INJECTION_WORKERS):
        t = threading.Thread(
            target=lambda: injection_worker(shutdown_event),
            name=f"injection-worker-{i}",
            daemon=True,
        )
        threads.append(t)

    for t in threads:
        t.start()
    log.info(f"Started {len(threads)} background threads ({INJECTION_WORKERS} injection workers)")

    try:
        # Main thread just waits - all work happens in threads and watchdog callbacks
        while not shutdown_event.is_set():
            time.sleep(1)
    except KeyboardInterrupt:
        log.info("Shutting down")
    finally:
        shutdown_event.set()
        observer.stop()
        # Wait for threads to finish
        for t in threads:
            t.join(timeout=2)
        stop_coordinator()
        stop_hub_server()
    observer.join()


if __name__ == "__main__":
    main()
