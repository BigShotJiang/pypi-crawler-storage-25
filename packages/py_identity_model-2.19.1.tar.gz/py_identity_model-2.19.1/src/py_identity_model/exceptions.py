"""
Exception hierarchy for py-identity-model.

This module defines a comprehensive exception hierarchy for all errors
that can occur during OAuth 2.0 and OpenID Connect operations.
"""

from __future__ import annotations


class PyIdentityModelException(Exception):
    """Base exception for all py-identity-model errors."""

    def __init__(self, message: str, details: dict | None = None):
        """
        Initialize a PyIdentityModelException.

        Args:
            message: The error message.
            details: Optional dictionary containing additional error context.
        """
        super().__init__(message)
        self.message = message
        self.details = details or {}


class ValidationException(PyIdentityModelException):
    """Raised when validation fails."""


class TokenValidationException(ValidationException):
    """Raised when token validation fails."""

    def __init__(
        self,
        message: str,
        token_part: str | None = None,
        details: dict | None = None,
    ):
        """
        Initialize a TokenValidationException.

        Args:
            message: The error message.
            token_part: The part of the token that failed validation
                       ('header', 'payload', or 'signature').
            details: Optional dictionary containing additional error context.
        """
        super().__init__(message, details)
        self.token_part = token_part


class SignatureVerificationException(TokenValidationException):
    """Raised when token signature verification fails."""

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message, token_part="signature", details=details)


class TokenExpiredException(TokenValidationException):
    """Raised when token has expired."""

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message, token_part="payload", details=details)


class InvalidAudienceException(TokenValidationException):
    """Raised when audience validation fails."""

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message, token_part="payload", details=details)


class InvalidIssuerException(TokenValidationException):
    """Raised when issuer validation fails."""

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message, token_part="payload", details=details)


class AuthorizeCallbackException(ValidationException):
    """Raised when authorization callback validation fails."""


class NetworkException(PyIdentityModelException):
    """Raised when network operations fail."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        status_code: int | None = None,
        details: dict | None = None,
    ):
        """
        Initialize a NetworkException.

        Args:
            message: The error message.
            url: The URL that was being accessed when the error occurred.
            status_code: The HTTP status code if available.
            details: Optional dictionary containing additional error context.
        """
        super().__init__(message, details)
        self.url = url
        self.status_code = status_code


class DiscoveryException(NetworkException):
    """Raised when discovery document cannot be fetched or parsed."""


class JwksException(NetworkException):
    """Raised when JWKS cannot be fetched or parsed."""


class TokenRequestException(NetworkException):
    """Raised when token request fails."""


class UserInfoException(NetworkException):
    """Raised when UserInfo request fails."""


class ConfigurationException(PyIdentityModelException):
    """Raised when configuration is invalid or incomplete."""


class FailedResponseAccessError(PyIdentityModelException):
    """Raised when accessing data fields on a failed response."""

    def __init__(self, field_name: str, error: str | None = None):
        error_detail = f": {error}" if error else ""
        message = (
            f"Cannot access '{field_name}' on a failed response{error_detail}. "
            f"Check 'is_successful' before accessing response data."
        )
        super().__init__(message)
        self.field_name = field_name


class SuccessfulResponseAccessError(PyIdentityModelException):
    """Raised when accessing the error field on a successful response."""

    def __init__(self, field_name: str = "error"):
        message = (
            f"Cannot access '{field_name}' on a successful response. "
            f"Check 'is_successful' before accessing error details."
        )
        super().__init__(message)
        self.field_name = field_name


__all__ = [
    "AuthorizeCallbackException",
    "ConfigurationException",
    "DiscoveryException",
    "FailedResponseAccessError",
    "InvalidAudienceException",
    "InvalidIssuerException",
    "JwksException",
    "NetworkException",
    "PyIdentityModelException",
    "SignatureVerificationException",
    "SuccessfulResponseAccessError",
    "TokenExpiredException",
    "TokenRequestException",
    "TokenValidationException",
    "UserInfoException",
    "ValidationException",
]
