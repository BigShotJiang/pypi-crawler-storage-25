"""徽章信任链验证模块。

提供徽章 - 报告配对验证，基于密码学哈希确保信任可验证。
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import TypedDict

from .badge import compute_report_hash
from .models import ScanReport


class VerificationResult(TypedDict):
    """验证结果"""
    valid: bool
    reason: str
    report_hash: str | None
    badge_hash: str | None
    report_path: str | None


def extract_hash_from_svg(svg_content: str) -> str | None:
    """从 SVG 内容中提取 data-report-hash 属性值。
    
    支持两种格式：
    1. data-report-hash="full_hash" 属性
    2. data-report-hash 属性（任何值）
    """
    # 匹配 data-report-hash="..." 属性
    match = re.search(r'data-report-hash="([a-fA-F0-9]+)"', svg_content)
    if match:
        return match.group(1).lower()
    return None


def verify_badge_report_pair(
    badge_path: str | Path,
    report_path: str | Path | None = None,
    report_hash: str | None = None,
) -> VerificationResult:
    """验证徽章和报告的配对关系。
    
    验证逻辑：
    1. 从徽章 SVG 中提取 data-report-hash
    2. 如果提供了 report_path，读取报告并计算哈希，与徽章哈希对比
    3. 如果提供了 report_hash，直接与徽章哈希对比
    
    Args:
        badge_path: 徽章 SVG 文件路径
        report_path: 可选，报告 JSON 文件路径
        report_hash: 可选，预期的报告哈希值
    
    Returns:
        VerificationResult: 验证结果
    """
    badge_path = Path(badge_path)
    
    # 读取徽章 SVG
    if not badge_path.exists():
        return VerificationResult(
            valid=False,
            reason=f"Badge file not found: {badge_path}",
            report_hash=None,
            badge_hash=None,
            report_path=None,
        )
    
    svg_content = badge_path.read_text(encoding="utf-8")
    badge_hash = extract_hash_from_svg(svg_content)
    
    if not badge_hash:
        return VerificationResult(
            valid=False,
            reason="No data-report-hash found in badge SVG",
            report_hash=None,
            badge_hash=None,
            report_path=None,
        )
    
    # 如果提供了报告路径，验证报告
    if report_path:
        report_path = Path(report_path)
        if not report_path.exists():
            return VerificationResult(
                valid=False,
                reason=f"Report file not found: {report_path}",
                report_hash=None,
                badge_hash=badge_hash,
                report_path=str(report_path),
            )
        
        try:
            report_data = json.loads(report_path.read_text(encoding="utf-8"))
            report = ScanReport.from_dict(report_data)
            computed_hash = compute_report_hash(report)
            
            if computed_hash.lower() == badge_hash.lower():
                return VerificationResult(
                    valid=True,
                    reason="Badge and report hash match",
                    report_hash=computed_hash,
                    badge_hash=badge_hash,
                    report_path=str(report_path),
                )
            else:
                return VerificationResult(
                    valid=False,
                    reason="Hash mismatch: badge hash does not match report content",
                    report_hash=computed_hash,
                    badge_hash=badge_hash,
                    report_path=str(report_path),
                )
        except json.JSONDecodeError as e:
            return VerificationResult(
                valid=False,
                reason=f"Invalid JSON in report file: {e}",
                report_hash=None,
                badge_hash=badge_hash,
                report_path=str(report_path),
            )
        except Exception as e:
            return VerificationResult(
                valid=False,
                reason=f"Error parsing report: {e}",
                report_hash=None,
                badge_hash=badge_hash,
                report_path=str(report_path),
            )
    
    # 如果提供了预期哈希，直接对比
    if report_hash:
        if report_hash.lower() == badge_hash.lower():
            return VerificationResult(
                valid=True,
                reason="Badge hash matches provided hash",
                report_hash=report_hash,
                badge_hash=badge_hash,
                report_path=None,
            )
        else:
            return VerificationResult(
                valid=False,
                reason="Hash mismatch: badge hash does not match provided hash",
                report_hash=report_hash,
                badge_hash=badge_hash,
                report_path=None,
            )
    
    # 仅提取哈希，不进行验证
    return VerificationResult(
        valid=True,
        reason="Badge hash extracted (no report provided for verification)",
        report_hash=None,
        badge_hash=badge_hash,
        report_path=None,
    )


def verify_github_pages_badge(
    badge_url: str,
    report_url: str,
) -> VerificationResult:
    """验证 GitHub Pages 托管的徽章和报告。
    
    从远程 URL 获取徽章和报告，验证哈希匹配。
    
    注意：此函数需要网络访问，实际实现可能需要 urllib 或 requests。
    目前作为占位符，提示用户如何使用 curl 等工具手动验证。
    """
    # 占位符实现 - 实际使用需要网络请求
    return VerificationResult(
        valid=False,
        reason="GitHub Pages verification requires network access. Use: curl -s <badge_url> | grep data-report-hash",
        report_hash=None,
        badge_hash=None,
        report_path=None,
    )


def format_verification_result(result: VerificationResult, output_format: str = "text") -> str:
    """格式化验证结果为文本、JSON 或 Markdown。"""
    if output_format == "json":
        return json.dumps(result, indent=2, ensure_ascii=False)
    
    if output_format == "markdown":
        status = "✅ Valid" if result["valid"] else "❌ Invalid"
        lines = [f"## Badge Verification: {status}", ""]
        lines.append(f"**Reason**: {result['reason']}")
        if result["badge_hash"]:
            lines.append(f"**Badge Hash**: `{result['badge_hash']}`")
        if result["report_hash"]:
            lines.append(f"**Report Hash**: `{result['report_hash']}`")
        if result["report_path"]:
            lines.append(f"**Report Path**: {result['report_path']}")
        return "\n".join(lines)
    
    # 默认文本格式
    status = "VALID" if result["valid"] else "INVALID"
    lines = [f"Verification: {status}"]
    lines.append(f"Reason: {result['reason']}")
    if result["badge_hash"]:
        lines.append(f"Badge Hash: {result['badge_hash']}")
    if result["report_hash"]:
        lines.append(f"Report Hash: {result['report_hash']}")
    if result["report_path"]:
        lines.append(f"Report Path: {result['report_path']}")
    return "\n".join(lines)
