from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

from .discovery import discover_skill_targets

DEFAULT_TARGETS_FILES = (".clawaudit/targets.txt", "clawaudit-targets.txt")


@dataclass(slots=True)
class ScanPlan:
    scan_mode: str
    target: str
    targets_file: str
    discovery_mode: str
    discovered_count: int
    targets: list[str]

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "ScanPlan":
        return cls(
            scan_mode=data["scan_mode"],
            target=data["target"],
            targets_file=data["targets_file"],
            discovery_mode=data["discovery_mode"],
            discovered_count=data["discovered_count"],
            targets=list(data.get("targets", [])),
        )


def plan_scan_targets(
    repo_root: str | Path,
    *,
    explicit_target: str | None = None,
    explicit_targets_file: str | None = None,
    changed_files: list[str] | None = None,
    discovered_targets_output: str | Path | None = None,
) -> ScanPlan:
    repo_path = resolve_repo_root(repo_root)
    normalized_target = normalize_optional(explicit_target)
    normalized_targets_file = normalize_optional(explicit_targets_file)

    if normalized_target:
        return ScanPlan(
            scan_mode="single",
            target=normalized_target,
            targets_file="",
            discovery_mode="explicit-target",
            discovered_count=0,
            targets=[],
        )

    conventional_targets_file = resolve_targets_file(repo_path, normalized_targets_file)
    if conventional_targets_file is not None:
        return ScanPlan(
            scan_mode="batch",
            target="",
            targets_file=str(conventional_targets_file),
            discovery_mode="explicit-targets-file" if normalized_targets_file else "conventional-targets-file",
            discovered_count=0,
            targets=[],
        )

    if changed_files:
        discovered_targets = discover_skill_targets(repo_path, changed_files=changed_files)
        discovery_mode = "changed-files"
    else:
        discovered_targets = discover_skill_targets(repo_path)
        discovery_mode = "full-scan"

    if len(discovered_targets) > 1:
        targets_file = write_discovered_targets(discovered_targets, repo_path, discovered_targets_output)
        return ScanPlan(
            scan_mode="batch",
            target="",
            targets_file=str(targets_file),
            discovery_mode=discovery_mode,
            discovered_count=len(discovered_targets),
            targets=discovered_targets,
        )

    if len(discovered_targets) == 1:
        return ScanPlan(
            scan_mode="single",
            target=discovered_targets[0],
            targets_file="",
            discovery_mode=discovery_mode,
            discovered_count=1,
            targets=discovered_targets,
        )

    return ScanPlan(
        scan_mode="single",
        target=str(repo_path),
        targets_file="",
        discovery_mode="repo-root-fallback",
        discovered_count=0,
        targets=[],
    )


def resolve_repo_root(repo_root: str | Path) -> Path:
    path = Path(repo_root).expanduser()
    if not path.is_absolute():
        path = (Path.cwd() / path).resolve()
    path = path.resolve()
    if not path.exists():
        raise FileNotFoundError(f"Repository root does not exist: {path}")
    if not path.is_dir():
        raise NotADirectoryError(f"Repository root is not a directory: {path}")
    return path


def resolve_targets_file(repo_root: Path, explicit_targets_file: str | None) -> Path | None:
    if explicit_targets_file:
        path = Path(explicit_targets_file).expanduser()
        if not path.is_absolute():
            path = (repo_root / path).resolve()
        if not path.exists():
            raise FileNotFoundError(f"Targets file not found: {path}")
        return path.resolve()

    for candidate in DEFAULT_TARGETS_FILES:
        candidate_path = (repo_root / candidate).resolve()
        if candidate_path.exists():
            return candidate_path
    return None


def write_discovered_targets(targets: list[str], repo_root: Path, output_path: str | Path | None) -> Path:
    if output_path is None:
        path = repo_root / "artifacts" / "reports" / "discovered-targets.txt"
    else:
        path = Path(output_path).expanduser()
        if not path.is_absolute():
            path = (repo_root / path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(targets) + "\n", encoding="utf-8")
    return path.resolve()


def normalize_optional(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def format_scan_plan_markdown(
    plan: ScanPlan,
    *,
    changed_files: list[str] | None = None,
    max_targets: int = 8,
    max_files: int = 10,
) -> str:
    lines = [
        "# ClawAudit Scan Plan",
        "",
        f"- Scan Mode: **{plan.scan_mode}**",
        f"- Discovery Mode: **{plan.discovery_mode}**",
        f"- Discovered Targets: **{plan.discovered_count}**",
    ]

    if plan.target:
        lines.append(f"- Target: `{plan.target}`")
    if plan.targets_file:
        lines.append(f"- Targets File: `{plan.targets_file}`")
    if changed_files is not None:
        lines.append(f"- Changed Files: **{len(changed_files)}**")

    lines.extend(["", "## Target Preview", ""])
    if plan.targets:
        lines.extend(format_preview_list(plan.targets, limit=max_targets))
    elif plan.target:
        lines.append(f"- `{plan.target}`")
    else:
        lines.append("- none")

    lines.extend(["", "## Changed Files Preview", ""])
    if changed_files:
        lines.extend(format_preview_list(changed_files, limit=max_files))
    else:
        lines.append("- none")

    return "\n".join(lines)


def format_preview_list(values: list[str], *, limit: int) -> list[str]:
    lines = [f"- `{value}`" for value in values[:limit]]
    remaining = len(values) - limit
    if remaining > 0:
        lines.append(f"- ... and `{remaining}` more")
    return lines
