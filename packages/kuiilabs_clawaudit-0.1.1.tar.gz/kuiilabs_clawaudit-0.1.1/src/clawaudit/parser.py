from __future__ import annotations

from pathlib import Path
import re

from .models import SkillMetadata

PERMISSION_KEYWORDS = {
    "network": [
        "network",
        "http",
        "api",
        "webhook",
        "internet",
        "remote",
        "fetch",
        "url",
    ],
    "shell": [
        "shell",
        "command",
        "terminal",
        "bash",
        "subprocess",
        "exec",
        "spawn",
    ],
    "env": [
        "env",
        "environment",
        "secret",
        "token",
        "api key",
        "apikey",
        "credential",
    ],
    "filesystem": [
        "filesystem",
        "file system",
        "file",
        "directory",
        "path",
        "read",
        "write",
    ],
}

SECTION_HEADER_PATTERN = re.compile(
    r"^#+\s*(permissions?|capabilities?|required permissions?|required access|requirements?)\b",
    re.IGNORECASE,
)
SECTION_LABEL_PATTERN = re.compile(
    r"^(permissions?|capabilities?|required permissions?|required access|requirements?)\s*:?\s*$",
    re.IGNORECASE,
)


def parse_skill_metadata(root_path: Path) -> SkillMetadata:
    skill_file = find_skill_file(root_path)
    if skill_file is None:
        return SkillMetadata(name=root_path.name, declared_permissions=[], skill_file=None)

    text = skill_file.read_text(encoding="utf-8", errors="ignore")
    name = extract_name(text) or root_path.name
    permissions = sorted(extract_declared_permissions(text))

    return SkillMetadata(
        name=name,
        declared_permissions=permissions,
        skill_file=str(skill_file.relative_to(root_path)),
    )


def find_skill_file(root_path: Path) -> Path | None:
    direct = root_path / "SKILL.md"
    if direct.exists():
        return direct

    matches = sorted(root_path.rglob("SKILL.md"))
    return matches[0] if matches else None


def extract_name(text: str) -> str | None:
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("# "):
            return line[2:].strip()
    return None


def extract_declared_permissions(text: str) -> set[str]:
    lines = text.splitlines()
    candidates: list[str] = []
    in_relevant_section = False

    for raw_line in lines:
        line = raw_line.strip()
        lowered = line.lower()

        if line.startswith("#"):
            in_relevant_section = bool(SECTION_HEADER_PATTERN.match(line))
            continue

        if SECTION_LABEL_PATTERN.match(line):
            candidates.append(lowered)
            in_relevant_section = True
            continue

        if in_relevant_section and (line.startswith("-") or line.startswith("*")):
            candidates.append(lowered)
            continue

        if in_relevant_section and line == "":
            continue

        if in_relevant_section:
            candidates.append(lowered)

    candidate_text = "\n".join(candidates)
    permissions: set[str] = set()
    for permission, keywords in PERMISSION_KEYWORDS.items():
        for keyword in keywords:
            pattern = rf"\b{re.escape(keyword)}\b"
            if re.search(pattern, candidate_text):
                permissions.add(permission)
                break

    return permissions
