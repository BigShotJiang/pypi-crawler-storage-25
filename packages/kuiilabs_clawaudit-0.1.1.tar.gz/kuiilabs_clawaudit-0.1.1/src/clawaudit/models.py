from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Literal

Severity = Literal["low", "medium", "high"]
RiskLevel = Literal["Safe", "Warning", "High Risk"]
BatchEntryStatus = Literal["ok", "error"]


@dataclass(slots=True)
class Finding:
    rule_id: str
    title: str
    severity: Severity
    category: str
    file_path: str | None
    evidence: str
    recommendation: str
    score: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Finding":
        return cls(
            rule_id=data["rule_id"],
            title=data["title"],
            severity=data["severity"],
            category=data["category"],
            file_path=data.get("file_path"),
            evidence=data["evidence"],
            recommendation=data["recommendation"],
            score=data.get("score", 0),
        )


@dataclass(slots=True)
class SkillMetadata:
    name: str
    declared_permissions: list[str] = field(default_factory=list)
    skill_file: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "SkillMetadata":
        return cls(
            name=data["name"],
            declared_permissions=list(data.get("declared_permissions", [])),
            skill_file=data.get("skill_file"),
        )


@dataclass(slots=True)
class PreparedSource:
    target: str
    source_kind: str
    root_path: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class RuleProfile:
    rule_id: str
    title: str
    category: str
    default_severity: Severity
    recommendation: str


@dataclass(slots=True)
class RuleSetting:
    enabled: bool = True
    severity: Severity | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class ScoringConfig:
    severity_weights: dict[Severity, int]
    category_multipliers: dict[str, float]
    thresholds: dict[str, int]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class PersistenceConfig:
    enabled: bool = True
    directory: str = ".clawaudit/reports"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class PolicyConfig:
    max_risk_level: RiskLevel | None = None
    max_risk_score: int | None = None
    forbidden_rules: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class RuntimePolicyConfig:
    block_network: bool = False
    block_env: bool = False
    block_shell: bool = False
    allowed_hosts: list[str] = field(default_factory=list)
    allowed_env_vars: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class RuntimeExecutionConfig:
    runner: str = "local-subprocess"
    timeout_ms: int = 5000

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class RuntimeConfig:
    rule_settings: dict[str, RuleSetting]
    scoring: ScoringConfig
    persistence: PersistenceConfig
    policy: PolicyConfig
    runtime_policy: RuntimePolicyConfig
    runtime_execution: RuntimeExecutionConfig
    config_path: str | None = None

    def to_dict(self) -> dict:
        return {
            "rule_settings": {rule_id: setting.to_dict() for rule_id, setting in self.rule_settings.items()},
            "scoring": self.scoring.to_dict(),
            "persistence": self.persistence.to_dict(),
            "policy": self.policy.to_dict(),
            "runtime_policy": self.runtime_policy.to_dict(),
            "runtime_execution": self.runtime_execution.to_dict(),
            "config_path": self.config_path,
        }


@dataclass(slots=True)
class ScanReport:
    report_id: str
    generated_at: str
    target: str
    source_kind: str
    root_path: str
    metadata: SkillMetadata
    risk_level: RiskLevel
    risk_score: int
    summary: str
    findings: list[Finding]
    score_breakdown: dict = field(default_factory=dict)
    persisted_paths: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        data = asdict(self)
        data["metadata"] = self.metadata.to_dict()
        data["findings"] = [finding.to_dict() for finding in self.findings]
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "ScanReport":
        return cls(
            report_id=data["report_id"],
            generated_at=data["generated_at"],
            target=data["target"],
            source_kind=data["source_kind"],
            root_path=data["root_path"],
            metadata=SkillMetadata.from_dict(data["metadata"]),
            risk_level=data["risk_level"],
            risk_score=data["risk_score"],
            summary=data["summary"],
            findings=[Finding.from_dict(item) for item in data.get("findings", [])],
            score_breakdown=dict(data.get("score_breakdown", {})),
            persisted_paths=list(data.get("persisted_paths", [])),
        )

    @classmethod
    def create(
        cls,
        *,
        report_id: str,
        target: str,
        source_kind: str,
        root_path: str,
        metadata: SkillMetadata,
        risk_level: RiskLevel,
        risk_score: int,
        summary: str,
        score_breakdown: dict,
        findings: list[Finding],
    ) -> "ScanReport":
        return cls(
            report_id=report_id,
            generated_at=datetime.now(timezone.utc).isoformat(),
            target=target,
            source_kind=source_kind,
            root_path=root_path,
            metadata=metadata,
            risk_level=risk_level,
            risk_score=risk_score,
            summary=summary,
            score_breakdown=score_breakdown,
            findings=findings,
        )


@dataclass(slots=True)
class BatchScanEntry:
    target: str
    status: BatchEntryStatus
    source_kind: str | None = None
    skill_name: str | None = None
    report_id: str | None = None
    risk_level: RiskLevel | None = None
    risk_score: int | None = None
    findings_count: int = 0
    summary: str | None = None
    rule_ids: list[str] = field(default_factory=list)
    persisted_paths: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_report(cls, report: ScanReport) -> "BatchScanEntry":
        return cls(
            target=report.target,
            status="ok",
            source_kind=report.source_kind,
            skill_name=report.metadata.name,
            report_id=report.report_id,
            risk_level=report.risk_level,
            risk_score=report.risk_score,
            findings_count=len(report.findings),
            summary=report.summary,
            rule_ids=sorted({finding.rule_id for finding in report.findings}),
            persisted_paths=list(report.persisted_paths),
        )

    @classmethod
    def from_dict(cls, data: dict) -> "BatchScanEntry":
        return cls(
            target=data["target"],
            status=data["status"],
            source_kind=data.get("source_kind"),
            skill_name=data.get("skill_name"),
            report_id=data.get("report_id"),
            risk_level=data.get("risk_level"),
            risk_score=data.get("risk_score"),
            findings_count=data.get("findings_count", 0),
            summary=data.get("summary"),
            rule_ids=list(data.get("rule_ids", [])),
            persisted_paths=list(data.get("persisted_paths", [])),
            error=data.get("error"),
        )


@dataclass(slots=True)
class BatchScanReport:
    generated_at: str
    total_targets: int
    succeeded: int
    failed: int
    risk_level_counts: dict[RiskLevel, int]
    entries: list[BatchScanEntry]

    def to_dict(self) -> dict:
        return {
            "generated_at": self.generated_at,
            "total_targets": self.total_targets,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "risk_level_counts": dict(self.risk_level_counts),
            "entries": [entry.to_dict() for entry in self.entries],
        }

    @classmethod
    def create(cls, entries: list[BatchScanEntry]) -> "BatchScanReport":
        succeeded = sum(1 for entry in entries if entry.status == "ok")
        failed = len(entries) - succeeded
        risk_level_counts: dict[RiskLevel, int] = {
            "Safe": 0,
            "Warning": 0,
            "High Risk": 0,
        }

        for entry in entries:
            if entry.status != "ok" or entry.risk_level is None:
                continue
            risk_level_counts[entry.risk_level] += 1

        return cls(
            generated_at=datetime.now(timezone.utc).isoformat(),
            total_targets=len(entries),
            succeeded=succeeded,
            failed=failed,
            risk_level_counts=risk_level_counts,
            entries=entries,
        )

    @classmethod
    def from_dict(cls, data: dict) -> "BatchScanReport":
        return cls(
            generated_at=data["generated_at"],
            total_targets=data["total_targets"],
            succeeded=data["succeeded"],
            failed=data["failed"],
            risk_level_counts=dict(data["risk_level_counts"]),
            entries=[BatchScanEntry.from_dict(item) for item in data.get("entries", [])],
        )


@dataclass(slots=True)
class DiffSnapshot:
    report_id: str
    target: str
    skill_name: str
    risk_level: RiskLevel
    risk_score: int
    findings_count: int

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "DiffSnapshot":
        return cls(
            report_id=data["report_id"],
            target=data["target"],
            skill_name=data["skill_name"],
            risk_level=data["risk_level"],
            risk_score=data["risk_score"],
            findings_count=data["findings_count"],
        )


@dataclass(slots=True)
class DiffReport:
    generated_at: str
    before: DiffSnapshot
    after: DiffSnapshot
    summary: str
    risk_score_delta: int
    findings_count_delta: int
    changed: bool
    added_findings: list[Finding] = field(default_factory=list)
    removed_findings: list[Finding] = field(default_factory=list)
    added_rules: list[str] = field(default_factory=list)
    removed_rules: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "generated_at": self.generated_at,
            "before": self.before.to_dict(),
            "after": self.after.to_dict(),
            "summary": self.summary,
            "risk_score_delta": self.risk_score_delta,
            "findings_count_delta": self.findings_count_delta,
            "changed": self.changed,
            "added_findings": [finding.to_dict() for finding in self.added_findings],
            "removed_findings": [finding.to_dict() for finding in self.removed_findings],
            "added_rules": list(self.added_rules),
            "removed_rules": list(self.removed_rules),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "DiffReport":
        return cls(
            generated_at=data["generated_at"],
            before=DiffSnapshot.from_dict(data["before"]),
            after=DiffSnapshot.from_dict(data["after"]),
            summary=data["summary"],
            risk_score_delta=data["risk_score_delta"],
            findings_count_delta=data["findings_count_delta"],
            changed=bool(data["changed"]),
            added_findings=[Finding.from_dict(item) for item in data.get("added_findings", [])],
            removed_findings=[Finding.from_dict(item) for item in data.get("removed_findings", [])],
            added_rules=list(data.get("added_rules", [])),
            removed_rules=list(data.get("removed_rules", [])),
        )


@dataclass(slots=True)
class RuntimeEvent:
    kind: str
    target: str
    detail: str | None = None
    blocked: bool = False

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "RuntimeEvent":
        return cls(
            kind=data["kind"],
            target=data["target"],
            detail=data.get("detail"),
            blocked=bool(data.get("blocked", False)),
        )


@dataclass(slots=True)
class RuntimeObservationReport:
    report_id: str
    generated_at: str
    target: str
    source_kind: str
    root_path: str
    script_path: str
    entrypoint: str
    status: str
    decision: str
    summary: str
    runner: str = "local-subprocess"
    duration_ms: int | None = None
    timed_out: bool = False
    probe_pid: int | None = None
    probe_host: str | None = None
    events: list[RuntimeEvent] = field(default_factory=list)
    policy_violations: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict:
        return {
            "report_id": self.report_id,
            "generated_at": self.generated_at,
            "target": self.target,
            "source_kind": self.source_kind,
            "root_path": self.root_path,
            "script_path": self.script_path,
            "entrypoint": self.entrypoint,
            "status": self.status,
            "decision": self.decision,
            "summary": self.summary,
            "runner": self.runner,
            "duration_ms": self.duration_ms,
            "timed_out": self.timed_out,
            "probe_pid": self.probe_pid,
            "probe_host": self.probe_host,
            "events": [event.to_dict() for event in self.events],
            "policy_violations": list(self.policy_violations),
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RuntimeObservationReport":
        return cls(
            report_id=data["report_id"],
            generated_at=data["generated_at"],
            target=data["target"],
            source_kind=data["source_kind"],
            root_path=data["root_path"],
            script_path=data["script_path"],
            entrypoint=data["entrypoint"],
            status=data["status"],
            decision=data["decision"],
            summary=data["summary"],
            runner=data.get("runner", "local-subprocess"),
            duration_ms=data.get("duration_ms"),
            timed_out=bool(data.get("timed_out", False)),
            probe_pid=data.get("probe_pid"),
            probe_host=data.get("probe_host"),
            events=[RuntimeEvent.from_dict(item) for item in data.get("events", [])],
            policy_violations=list(data.get("policy_violations", [])),
            error=data.get("error"),
        )
