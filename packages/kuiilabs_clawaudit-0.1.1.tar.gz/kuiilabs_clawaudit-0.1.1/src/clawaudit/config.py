from __future__ import annotations

from pathlib import Path
import tomllib

from .models import (
    PersistenceConfig,
    PolicyConfig,
    RuleSetting,
    RuntimeConfig,
    RuntimeExecutionConfig,
    RuntimePolicyConfig,
    ScoringConfig,
)

DEFAULT_SCORING = ScoringConfig(
    severity_weights={
        "low": 6,
        "medium": 18,
        "high": 40,
    },
    category_multipliers={
        "network": 1.2,
        "shell": 1.8,
        "env": 1.1,
        "filesystem": 1.0,
        "metadata": 0.7,
    },
    thresholds={
        "warning": 15,
        "high_risk": 70,
    },
)

DEFAULT_PERSISTENCE = PersistenceConfig(
    enabled=True,
    directory=".clawaudit/reports",
)

DEFAULT_POLICY = PolicyConfig()
DEFAULT_RUNTIME_POLICY = RuntimePolicyConfig()
DEFAULT_RUNTIME_EXECUTION = RuntimeExecutionConfig()

DEFAULT_RULE_IDS = {
    "network-call",
    "network-url-reference",
    "shell-exec",
    "env-access",
    "sensitive-path-write",
    "sensitive-path-read",
    "sensitive-path-reference",
    "download-exec",
    "embedded-secret",
    "permission-missing",
    "permission-mismatch",
}

VALID_SEVERITIES = {"low", "medium", "high"}
VALID_RISK_LEVELS = {"Safe", "Warning", "High Risk"}


def load_runtime_config(config_path: str | None = None, cwd: Path | None = None) -> RuntimeConfig:
    cwd = cwd or Path.cwd()
    resolved_path = resolve_config_path(config_path, cwd)
    config = default_runtime_config()

    if resolved_path is None:
        return config

    raw = tomllib.loads(resolved_path.read_text(encoding="utf-8"))
    apply_rule_overrides(config, raw.get("rules", {}))
    apply_scoring_overrides(config, raw.get("scoring", {}))
    apply_persistence_overrides(config, raw.get("persistence", {}))
    apply_policy_overrides(config, raw.get("policy", {}))
    apply_runtime_policy_overrides(config, raw.get("runtime_policy", {}))
    apply_runtime_execution_overrides(config, raw.get("runtime_execution", {}))
    config.config_path = str(resolved_path.resolve())
    return config


def default_runtime_config() -> RuntimeConfig:
    rule_settings = {rule_id: RuleSetting() for rule_id in DEFAULT_RULE_IDS}
    scoring = ScoringConfig(
        severity_weights=dict(DEFAULT_SCORING.severity_weights),
        category_multipliers=dict(DEFAULT_SCORING.category_multipliers),
        thresholds=dict(DEFAULT_SCORING.thresholds),
    )
    persistence = PersistenceConfig(
        enabled=DEFAULT_PERSISTENCE.enabled,
        directory=DEFAULT_PERSISTENCE.directory,
    )
    policy = PolicyConfig(
        max_risk_level=DEFAULT_POLICY.max_risk_level,
        max_risk_score=DEFAULT_POLICY.max_risk_score,
        forbidden_rules=list(DEFAULT_POLICY.forbidden_rules),
    )
    runtime_policy = RuntimePolicyConfig(
        block_network=DEFAULT_RUNTIME_POLICY.block_network,
        block_env=DEFAULT_RUNTIME_POLICY.block_env,
        block_shell=DEFAULT_RUNTIME_POLICY.block_shell,
        allowed_hosts=list(DEFAULT_RUNTIME_POLICY.allowed_hosts),
        allowed_env_vars=list(DEFAULT_RUNTIME_POLICY.allowed_env_vars),
    )
    runtime_execution = RuntimeExecutionConfig(
        runner=DEFAULT_RUNTIME_EXECUTION.runner,
        timeout_ms=DEFAULT_RUNTIME_EXECUTION.timeout_ms,
    )
    return RuntimeConfig(
        rule_settings=rule_settings,
        scoring=scoring,
        persistence=persistence,
        policy=policy,
        runtime_policy=runtime_policy,
        runtime_execution=runtime_execution,
    )


def resolve_config_path(config_path: str | None, cwd: Path) -> Path | None:
    if config_path:
        path = Path(config_path).expanduser()
        if not path.is_absolute():
            path = cwd / path
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        return path

    default_path = cwd / "clawaudit.toml"
    return default_path if default_path.exists() else None


def apply_rule_overrides(config: RuntimeConfig, raw_rules: dict) -> None:
    for rule_id, overrides in raw_rules.items():
        if rule_id not in config.rule_settings:
            config.rule_settings[rule_id] = RuleSetting()
        setting = config.rule_settings[rule_id]

        enabled = overrides.get("enabled")
        if enabled is not None:
            setting.enabled = bool(enabled)

        severity = overrides.get("severity")
        if severity is not None:
            if severity not in VALID_SEVERITIES:
                raise ValueError(f"Invalid severity override for {rule_id}: {severity}")
            setting.severity = severity


def apply_scoring_overrides(config: RuntimeConfig, raw_scoring: dict) -> None:
    severity_weights = raw_scoring.get("severity_weights", {})
    for severity, weight in severity_weights.items():
        if severity not in VALID_SEVERITIES:
            raise ValueError(f"Invalid scoring severity: {severity}")
        config.scoring.severity_weights[severity] = int(weight)

    category_multipliers = raw_scoring.get("category_multipliers", {})
    for category, multiplier in category_multipliers.items():
        config.scoring.category_multipliers[category] = float(multiplier)

    thresholds = raw_scoring.get("thresholds", {})
    for name, value in thresholds.items():
        config.scoring.thresholds[name] = int(value)


def apply_persistence_overrides(config: RuntimeConfig, raw_persistence: dict) -> None:
    enabled = raw_persistence.get("enabled")
    if enabled is not None:
        config.persistence.enabled = bool(enabled)

    directory = raw_persistence.get("directory")
    if directory:
        config.persistence.directory = str(directory)


def apply_policy_overrides(config: RuntimeConfig, raw_policy: dict) -> None:
    max_risk_level = raw_policy.get("max_risk_level")
    if max_risk_level is not None:
        if max_risk_level not in VALID_RISK_LEVELS:
            raise ValueError(f"Invalid policy max_risk_level: {max_risk_level}")
        config.policy.max_risk_level = max_risk_level

    max_risk_score = raw_policy.get("max_risk_score")
    if max_risk_score is not None:
        config.policy.max_risk_score = int(max_risk_score)

    forbidden_rules = raw_policy.get("forbidden_rules")
    if forbidden_rules is not None:
        config.policy.forbidden_rules = [str(rule_id) for rule_id in forbidden_rules]


def apply_runtime_policy_overrides(config: RuntimeConfig, raw_runtime_policy: dict) -> None:
    block_network = raw_runtime_policy.get("block_network")
    if block_network is not None:
        config.runtime_policy.block_network = bool(block_network)

    block_env = raw_runtime_policy.get("block_env")
    if block_env is not None:
        config.runtime_policy.block_env = bool(block_env)

    block_shell = raw_runtime_policy.get("block_shell")
    if block_shell is not None:
        config.runtime_policy.block_shell = bool(block_shell)

    allowed_hosts = raw_runtime_policy.get("allowed_hosts")
    if allowed_hosts is not None:
        config.runtime_policy.allowed_hosts = [str(host) for host in allowed_hosts]

    allowed_env_vars = raw_runtime_policy.get("allowed_env_vars")
    if allowed_env_vars is not None:
        config.runtime_policy.allowed_env_vars = [str(name) for name in allowed_env_vars]


def apply_runtime_execution_overrides(config: RuntimeConfig, raw_runtime_execution: dict) -> None:
    runner = raw_runtime_execution.get("runner")
    if runner is not None:
        config.runtime_execution.runner = str(runner)

    timeout_ms = raw_runtime_execution.get("timeout_ms")
    if timeout_ms is not None:
        config.runtime_execution.timeout_ms = max(1, int(timeout_ms))
