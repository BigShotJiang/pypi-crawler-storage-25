from __future__ import annotations

from dataclasses import asdict, dataclass
from html import escape
from urllib.parse import quote
import json
import hashlib
import re

from .models import ScanReport

DEFAULT_LABEL = "ClawAudit"
DEFAULT_LABEL_COLOR = "2f363d"
HEX_COLOR_RE = re.compile(r"^[0-9a-fA-F]{6}$")


@dataclass(slots=True)
class BadgeOptions:
    label: str = DEFAULT_LABEL
    display: str = "both"
    style: str = "pill"
    label_color: str = DEFAULT_LABEL_COLOR
    message_color: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def build_badge_options(
    *,
    label: str | None = None,
    display: str = "both",
    style: str = "pill",
    label_color: str | None = None,
    message_color: str | None = None,
) -> BadgeOptions:
    normalized_label = DEFAULT_LABEL if label is None else label.strip()
    if display not in {"both", "level", "score"}:
        raise ValueError(f"Unsupported badge display mode: {display}")
    if style not in {"pill", "flat"}:
        raise ValueError(f"Unsupported badge style: {style}")

    return BadgeOptions(
        label=normalized_label,
        display=display,
        style=style,
        label_color=normalize_badge_color(label_color, field_name="label_color", default=DEFAULT_LABEL_COLOR),
        message_color=normalize_badge_color(message_color, field_name="message_color"),
    )


def badge_message(report: ScanReport, *, display: str = "both") -> str:
    if display == "level":
        return report.risk_level
    if display == "score":
        return f"{report.risk_score}/100"
    return f"{report.risk_level} {report.risk_score}/100"


def build_badge_payload(report: ScanReport, options: BadgeOptions | None = None) -> dict:
    badge_options = options or build_badge_options()
    message_color = badge_options.message_color or badge_color(report.risk_level)
    return {
        "schemaVersion": 1,
        "label": badge_options.label,
        "message": badge_message(report, display=badge_options.display),
        "color": message_color,
        "style": badge_options.style,
        "labelColor": badge_options.label_color,
        "display": badge_options.display,
    }


def format_badge_json(report: ScanReport, options: BadgeOptions | None = None) -> str:
    return json.dumps(build_badge_payload(report, options), indent=2, ensure_ascii=False)


def format_badge_markdown(report: ScanReport, options: BadgeOptions | None = None) -> str:
    badge_options = options or build_badge_options()
    payload = build_badge_payload(report, badge_options)
    label = quote(payload["label"] or " ", safe="")
    message = quote(payload["message"], safe="")
    params = [
        f"style={quote(shields_style(badge_options.style), safe='')}",
        f"labelColor={quote(payload['labelColor'], safe='')}",
    ]
    if badge_options.message_color:
        params.append(f"color={quote(payload['color'], safe='')}")
    query = "&".join(params)
    return f"![{payload['label'] or DEFAULT_LABEL}](https://img.shields.io/badge/{label}-{message}-{payload['color']}?{query})"


def format_badge_svg(report: ScanReport, options: BadgeOptions | None = None) -> str:
    """生成带哈希数据的 SVG 徽章（向后兼容）。"""
    svg_content, _ = format_badge_svg_with_hash(report, options)
    return svg_content


def measure_badge_width(text: str) -> int:
    return max(48, len(text) * 7 + 14)


def badge_color(risk_level: str) -> str:
    if risk_level == "High Risk":
        return "b42318"
    if risk_level == "Warning":
        return "c77d1f"
    return "1c7c54"


def shields_style(style: str) -> str:
    return "flat" if style == "flat" else "plastic"


def normalize_badge_color(value: str | None, *, field_name: str, default: str | None = None) -> str | None:
    if value is None:
        return default

    normalized = value.strip().lstrip("#")
    if not normalized:
        return default
    if not HEX_COLOR_RE.match(normalized):
        raise ValueError(f"Invalid {field_name}: expected a 6-digit hex color")
    return normalized.lower()


def compute_report_hash(report: ScanReport) -> str:
    """计算报告的 SHA256 哈希值，用于信任验证。
    
    哈希基于报告的核心字段（排除时间戳和持久化路径），确保内容一致性验证。
    """
    data = report.to_dict()
    # 排除易变字段，只哈希核心内容
    core_data = {
        "target": data["target"],
        "source_kind": data["source_kind"],
        "root_path": data["root_path"],
        "metadata": data["metadata"],
        "risk_level": data["risk_level"],
        "risk_score": data["risk_score"],
        "summary": data["summary"],
        "findings": data["findings"],
        "score_breakdown": data["score_breakdown"],
    }
    content = json.dumps(core_data, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def format_badge_svg_with_hash(report: ScanReport, options: BadgeOptions | None = None) -> tuple[str, str]:
    """生成带哈希数据的 SVG 徽章。
    
    返回：(svg_content, report_hash)
    哈希作为 data 属性嵌入 SVG，供前端验证使用。
    """
    badge_options = options or build_badge_options()
    label = badge_options.label
    message = badge_message(report, display=badge_options.display)
    label_width = measure_badge_width(label) if label else 0
    message_width = measure_badge_width(message)
    total_width = label_width + message_width
    message_color = f"#{badge_options.message_color or badge_color(report.risk_level)}"
    label_color = f"#{badge_options.label_color}"
    radius = 10 if badge_options.style == "pill" else 4
    aria_label = escape(f"{label}: {message}" if label else message)
    
    # 计算报告哈希
    report_hash = compute_report_hash(report)
    hash_short = report_hash[:16]  # 短哈希用于显示
    
    label_segment = ""
    label_text = ""
    if label:
        label_segment = f'    <rect width="{label_width}" height="20" fill="{label_color}"/>\n'
        label_text = f'    <text x="{label_width / 2}" y="14">{escape(label)}</text>\n'

    gradient = ""
    overlay = ""
    if badge_options.style == "pill":
        gradient = """  <linearGradient id="smooth" x2="0" y2="100%">
    <stop offset="0" stop-color="#fff" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
"""
        overlay = f'    <rect width="{total_width}" height="20" fill="url(#smooth)"/>\n'

    # 添加 data-report-hash 属性
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{total_width}" height="20" role="img" aria-label="{aria_label}" data-report-hash="{report_hash}">
{gradient}  <mask id="round">
    <rect width="{total_width}" height="20" rx="{radius}" fill="#fff"/>
  </mask>
  <g mask="url(#round)">
{label_segment}    <rect x="{label_width}" width="{message_width}" height="20" fill="{message_color}"/>
{overlay}  </g>
  <g fill="#fff" text-anchor="middle" font-family="Verdana,Geneva,DejaVu Sans,sans-serif" font-size="11">
{label_text}    <text x="{label_width + (message_width / 2)}" y="14">{escape(message)}</text>
  </g>
</svg>'''
    return svg, report_hash
