from __future__ import annotations

from hashlib import sha1
from pathlib import Path

from .config import default_runtime_config
from .models import ScanReport
from .parser import parse_skill_metadata
from .rules import run_rules
from .scoring import score_findings
from .source import prepare_source


def scan_target(target: str, runtime_config=None) -> ScanReport:
    runtime_config = runtime_config or default_runtime_config()

    with prepare_source(target) as prepared:
        root_path = Path(prepared.root_path)
        metadata = parse_skill_metadata(root_path)
        findings = run_rules(root_path, metadata, runtime_config)
        risk_level, risk_score, summary, score_breakdown = score_findings(findings, runtime_config.scoring)
        report_id = build_report_id(prepared.target, metadata.name)

        return ScanReport.create(
            report_id=report_id,
            target=prepared.target,
            source_kind=prepared.source_kind,
            root_path=prepared.root_path,
            metadata=metadata,
            risk_level=risk_level,
            risk_score=risk_score,
            summary=summary,
            score_breakdown=score_breakdown,
            findings=findings,
        )


def build_report_id(target: str, skill_name: str) -> str:
    fingerprint = sha1(f"{target}:{skill_name}".encode("utf-8")).hexdigest()
    return fingerprint[:12]
