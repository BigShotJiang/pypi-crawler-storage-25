from __future__ import annotations

from pathlib import Path
import json

from .config import load_runtime_config
from .models import BatchScanReport, ScanReport
from .status import batch_policy_violations, report_policy_violations


def build_comment_marker(identifier: str = "summary") -> str:
    sanitized = "".join(character if character.isalnum() or character in {"-", "_", "."} else "-" for character in identifier)
    sanitized = sanitized.strip("-") or "summary"
    return f"<!-- clawaudit:pr-comment:{sanitized} -->"


def format_markdown_link(label: str, url: str | None) -> str:
    if not url:
        return label
    return f"[{label}]({url})"


def short_sha(value: str | None) -> str | None:
    if not value:
        return None
    return value[:8]


def load_report_artifact(path_value: str | Path | None) -> ScanReport | BatchScanReport | None:
    if not path_value:
        return None

    path = resolve_path(path_value)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if "metadata" in payload and "report_id" in payload:
        return ScanReport.from_dict(payload)
    if "entries" in payload and "total_targets" in payload:
        return BatchScanReport.from_dict(payload)
    raise ValueError(f"Unsupported report artifact: {path}")


def load_scan_plan(path_value: str | Path | None) -> dict | None:
    if not path_value:
        return None
    path = resolve_path(path_value)
    return json.loads(path.read_text(encoding="utf-8"))


def load_changed_files(path_value: str | Path | None) -> list[str]:
    if not path_value:
        return []
    path = resolve_path(path_value)
    return [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]


def compute_policy_violations(
    report: ScanReport | BatchScanReport | None,
    *,
    config_path: str | Path | None = None,
    cwd: Path | None = None,
) -> list[str]:
    if report is None:
        return []

    runtime_config = load_runtime_config(str(config_path) if config_path else None, cwd=cwd or Path.cwd())
    if isinstance(report, ScanReport):
        return report_policy_violations(report, runtime_config.policy)
    return batch_policy_violations(report, runtime_config.policy)


def build_reviewer_sections(
    *,
    report: ScanReport | BatchScanReport | None = None,
    gate_status: str | None = None,
    scan_mode: str | None = None,
    policy_violations: list[str] | None = None,
    scan_plan: dict | None = None,
    changed_files: list[str] | None = None,
    artifact_name: str | None = None,
    artifact_paths: list[str] | None = None,
    repository: str | None = None,
    run_url: str | None = None,
    pr_url: str | None = None,
    compare_url: str | None = None,
) -> dict[str, list[str]]:
    policy_hits = list(policy_violations or [])
    sections: dict[str, list[str]] = {}

    decision_lines: list[str] = []
    if gate_status:
        decision_lines.append(f"- Review Status: `{review_status_label(gate_status)}`")
    if isinstance(report, ScanReport):
        decision_lines.extend(
            [
                f"- Current Risk: `{report.risk_level}` ({report.risk_score}/100)",
                f"- Findings: `{len(report.findings)}`",
            ]
        )
        top_rules = sorted({finding.rule_id for finding in report.findings})
        if top_rules:
            decision_lines.append(f"- Top Rule Hits: {format_code_list(top_rules[:5])}")
    elif isinstance(report, BatchScanReport):
        distribution = report.risk_level_counts
        decision_lines.extend(
            [
                f"- Targets Scanned: `{report.total_targets}` (`{report.succeeded}` ok, `{report.failed}` failed)",
                (
                    "- Risk Distribution: "
                    f"`Safe {distribution['Safe']}` / "
                    f"`Warning {distribution['Warning']}` / "
                    f"`High Risk {distribution['High Risk']}`"
                ),
            ]
        )
        highest_risk = [
            entry
            for entry in sorted(
                [entry for entry in report.entries if entry.status == "ok" and entry.risk_score is not None],
                key=lambda entry: entry.risk_score,
                reverse=True,
            )[:3]
        ]
        if highest_risk:
            decision_lines.append(
                "- Highest Risk Targets: "
                + ", ".join(f"`{entry.skill_name or entry.target}` ({entry.risk_score}/100)" for entry in highest_risk)
            )
    if policy_hits:
        decision_lines.append(f"- Policy Hits: `{len(policy_hits)}`")
    if decision_lines:
        sections["decision"] = decision_lines

    scope_lines: list[str] = []
    if scan_mode:
        scope_lines.append(f"- Scan Mode: `{scan_mode}`")
    if scan_plan:
        discovery_mode = scan_plan.get("discovery_mode")
        if discovery_mode:
            scope_lines.append(f"- Discovery Mode: `{discovery_mode}`")
        discovered_count = scan_plan.get("discovered_count")
        if discovered_count is not None:
            scope_lines.append(f"- Discovered Targets: `{discovered_count}`")
        targets = list(scan_plan.get("targets", []))
        if targets:
            preview = ", ".join(f"`{Path(target).name or target}`" for target in targets[:3])
            if len(targets) > 3:
                preview = f"{preview}, ... and `{len(targets) - 3}` more"
            scope_lines.append(f"- Target Preview: {preview}")
    if changed_files:
        scope_lines.append(f"- Changed Files in Scope: `{len(changed_files)}`")
        preview = ", ".join(f"`{path}`" for path in changed_files[:3])
        if len(changed_files) > 3:
            preview = f"{preview}, ... and `{len(changed_files) - 3}` more"
        scope_lines.append(f"- Changed File Preview: {preview}")
    if scope_lines:
        sections["scope"] = scope_lines

    if policy_hits:
        sections["policy"] = [f"- {item}" for item in policy_hits[:6]]

    artifact_lines: list[str] = []
    if pr_url:
        artifact_lines.append(f"- Pull Request: {format_markdown_link('view PR', pr_url)}")
    if compare_url:
        artifact_lines.append(f"- Compare: {format_markdown_link('base...head', compare_url)}")
    if run_url:
        artifact_lines.append(f"- Workflow Run: {format_markdown_link('view run', run_url)}")
    if repository:
        artifact_lines.append(f"- Repository: `{repository}`")
    if artifact_name:
        artifact_lines.append(f"- Artifact Bundle: `{artifact_name}` on the workflow run")
    basenames = [Path(path).name for path in artifact_paths or [] if path]
    if basenames:
        artifact_lines.append("- Files: " + ", ".join(f"`{name}`" for name in basenames))
    if artifact_lines:
        sections["artifacts"] = artifact_lines

    return sections


def build_pr_comment(
    markdown_body: str,
    *,
    title: str = "ClawAudit PR Summary",
    identifier: str = "summary",
    scan_mode: str | None = None,
    target: str | None = None,
    targets_file: str | None = None,
    gate_status: str | None = None,
    policy_mode: str | None = None,
    repository: str | None = None,
    workflow_name: str | None = None,
    run_url: str | None = None,
    pr_url: str | None = None,
    compare_url: str | None = None,
    base_ref: str | None = None,
    head_ref: str | None = None,
    head_sha: str | None = None,
    artifact_name: str | None = None,
    decision_lines: list[str] | None = None,
    scope_lines: list[str] | None = None,
    policy_lines: list[str] | None = None,
    artifact_lines: list[str] | None = None,
) -> str:
    body = markdown_body.strip() or "_No report content was generated._"
    lines = [build_comment_marker(identifier), f"## {title}", ""]

    context_lines: list[str] = []
    if gate_status:
        context_lines.append(f"- Status: `{gate_status}`")
    if scan_mode:
        context_lines.append(f"- Mode: `{scan_mode}`")
    if policy_mode:
        context_lines.append(f"- Policy Gate: `{policy_mode}`")
    if target:
        context_lines.append(f"- Target: `{target}`")
    if targets_file:
        context_lines.append(f"- Targets File: `{targets_file}`")
    if repository:
        context_lines.append(f"- Repository: `{repository}`")
    if workflow_name:
        context_lines.append(f"- Workflow: `{workflow_name}`")
    if pr_url:
        context_lines.append(f"- Pull Request: {format_markdown_link('view PR', pr_url)}")
    if compare_url:
        context_lines.append(f"- Compare: {format_markdown_link('base...head', compare_url)}")
    if run_url:
        context_lines.append(f"- Workflow Run: {format_markdown_link('view run', run_url)}")
    if artifact_name:
        context_lines.append(f"- Artifacts: `{artifact_name}` attached to the workflow run")
    if base_ref:
        context_lines.append(f"- Base Ref: `{base_ref}`")
    if head_ref or head_sha:
        head_descriptor = head_ref or "head"
        short = short_sha(head_sha)
        if short:
            head_descriptor = f"{head_descriptor}@{short}"
        context_lines.append(f"- Head Ref: `{head_descriptor}`")

    if context_lines:
        lines.extend(context_lines)
        lines.append("")

    lines.extend(render_comment_section("Decision", decision_lines))
    lines.extend(render_comment_section("Scope", scope_lines))
    lines.extend(render_comment_section("Policy Hits", policy_lines))
    lines.extend(render_comment_section("Artifacts", artifact_lines))

    lines.extend(
        [
            "<details open>",
            "<summary>ClawAudit Report</summary>",
            "",
            body,
            "",
            "</details>",
            "",
            "_Generated by ClawAudit workflow automation._",
        ]
    )
    return "\n".join(lines)


def resolve_path(path_value: str | Path) -> Path:
    path = Path(path_value).expanduser()
    if not path.is_absolute():
        path = (Path.cwd() / path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Path not found: {path}")
    return path


def review_status_label(gate_status: str) -> str:
    if gate_status == "failed":
        return "blocked"
    if gate_status == "passed":
        return "pass"
    return gate_status


def format_code_list(values: list[str]) -> str:
    return ", ".join(f"`{value}`" for value in values)


def render_comment_section(title: str, lines: list[str] | None) -> list[str]:
    if not lines:
        return []
    return [f"### {title}", "", *lines, ""]
