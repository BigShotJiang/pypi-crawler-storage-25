from __future__ import annotations

from pathlib import Path


def discover_skill_targets(root: str | Path, *, changed_files: list[str] | None = None) -> list[str]:
    root_path = Path(root).expanduser()
    if not root_path.is_absolute():
        root_path = (Path.cwd() / root_path).resolve()
    root_path = root_path.resolve()
    if not root_path.exists():
        raise FileNotFoundError(f"Discovery root does not exist: {root_path}")
    if not root_path.is_dir():
        raise NotADirectoryError(f"Discovery root is not a directory: {root_path}")

    if changed_files:
        targets = {
            str(target)
            for target in (
                nearest_skill_root(resolve_changed_file_path(root_path, changed_file), root_path)
                for changed_file in changed_files
            )
            if target is not None
        }
        return sorted(targets)

    matches = {
        str(skill_path.parent.resolve())
        for skill_path in root_path.rglob("SKILL.md")
        if ".git" not in skill_path.parts and ".venv" not in skill_path.parts
    }
    return sorted(matches)


def resolve_changed_file_path(root_path: Path, changed_file: str) -> Path:
    path = Path(changed_file).expanduser()
    if not path.is_absolute():
        path = (root_path / path).resolve()
    return path


def nearest_skill_root(path: Path, root_path: Path) -> Path | None:
    current = path if path.is_dir() else path.parent
    try:
        current.relative_to(root_path)
    except ValueError:
        return None

    while True:
        if (current / "SKILL.md").exists():
            return current.resolve()
        if current == root_path:
            return None
        current = current.parent
