from __future__ import annotations

from .models import BatchScanReport, DiffReport, PolicyConfig, RiskLevel, ScanReport

RISK_ORDER: dict[RiskLevel, int] = {
    "Safe": 0,
    "Warning": 1,
    "High Risk": 2,
}


def exceeds_risk_threshold(risk_level: RiskLevel, threshold: RiskLevel | None) -> bool:
    if threshold is None:
        return False
    return RISK_ORDER[risk_level] >= RISK_ORDER[threshold]


def report_trips_gate(
    report: ScanReport,
    *,
    fail_on: RiskLevel | None = None,
    max_risk_score: int | None = None,
    policy: PolicyConfig | None = None,
) -> bool:
    return exceeds_risk_threshold(report.risk_level, fail_on) or (
        max_risk_score is not None and report.risk_score >= max_risk_score
    ) or bool(report_policy_violations(report, policy))


def batch_trips_gate(
    report: BatchScanReport,
    *,
    fail_on: RiskLevel | None = None,
    max_risk_score: int | None = None,
    fail_on_error: bool = False,
    policy: PolicyConfig | None = None,
) -> bool:
    if fail_on_error and report.failed > 0:
        return True

    for entry in report.entries:
        if entry.status != "ok" or entry.risk_level is None or entry.risk_score is None:
            continue
        if exceeds_risk_threshold(entry.risk_level, fail_on):
            return True
        if max_risk_score is not None and entry.risk_score >= max_risk_score:
            return True

    return bool(batch_policy_violations(report, policy))


def diff_trips_gate(
    report: DiffReport,
    *,
    fail_on: RiskLevel | None = None,
    max_risk_score: int | None = None,
    fail_on_regression: bool = False,
) -> bool:
    if exceeds_risk_threshold(report.after.risk_level, fail_on):
        return True
    if max_risk_score is not None and report.after.risk_score >= max_risk_score:
        return True
    if fail_on_regression and (
        report.risk_score_delta > 0 or len(report.added_findings) > 0 or RISK_ORDER[report.after.risk_level] > RISK_ORDER[report.before.risk_level]
    ):
        return True
    return False


def report_policy_violations(report: ScanReport, policy: PolicyConfig | None) -> list[str]:
    if policy is None:
        return []

    violations: list[str] = []
    if policy.max_risk_level and exceeds_risk_threshold(report.risk_level, policy.max_risk_level):
        violations.append(
            f"Risk level {report.risk_level} exceeds policy maximum {policy.max_risk_level}."
        )
    if policy.max_risk_score is not None and report.risk_score >= policy.max_risk_score:
        violations.append(
            f"Risk score {report.risk_score} exceeds policy maximum {policy.max_risk_score}."
        )

    forbidden = sorted({finding.rule_id for finding in report.findings if finding.rule_id in set(policy.forbidden_rules)})
    if forbidden:
        violations.append(f"Forbidden rules detected: {', '.join(forbidden)}.")
    return violations


def batch_policy_violations(report: BatchScanReport, policy: PolicyConfig | None) -> list[str]:
    if policy is None:
        return []

    violations: list[str] = []
    for entry in report.entries:
        if entry.status != "ok" or entry.risk_level is None or entry.risk_score is None:
            continue

        label = entry.skill_name or entry.target
        if policy.max_risk_level and exceeds_risk_threshold(entry.risk_level, policy.max_risk_level):
            violations.append(f"{label}: risk level {entry.risk_level} exceeds policy maximum {policy.max_risk_level}.")
        if policy.max_risk_score is not None and entry.risk_score >= policy.max_risk_score:
            violations.append(f"{label}: risk score {entry.risk_score} exceeds policy maximum {policy.max_risk_score}.")

        forbidden = sorted(set(entry.rule_ids) & set(policy.forbidden_rules))
        if forbidden:
            violations.append(f"{label}: forbidden rules detected: {', '.join(forbidden)}.")

    return violations
