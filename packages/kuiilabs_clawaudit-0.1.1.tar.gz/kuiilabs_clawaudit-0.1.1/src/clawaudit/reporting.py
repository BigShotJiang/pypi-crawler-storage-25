from __future__ import annotations

from pathlib import Path
import json

from .config import RuntimeConfig, default_runtime_config
from .models import ScanReport
from .scanner import scan_target
from .source import is_repo_url


def resolve_report_reference(reference: str, runtime_config: RuntimeConfig | None = None) -> ScanReport:
    runtime_config = runtime_config or default_runtime_config()
    path = Path(reference).expanduser()

    if path.exists():
        if path.is_file():
            return load_report_file(path)
        if path.is_dir():
            return scan_target(str(path.resolve()), runtime_config=runtime_config)

    if is_repo_url(reference):
        return scan_target(reference, runtime_config=runtime_config)

    raise FileNotFoundError(f"Reference does not exist and is not a supported repository URL: {reference}")


def load_report_file(path: Path) -> ScanReport:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return ScanReport.from_dict(payload)
