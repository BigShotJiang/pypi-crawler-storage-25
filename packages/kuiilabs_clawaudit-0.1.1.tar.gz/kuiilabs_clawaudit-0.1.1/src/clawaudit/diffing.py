from __future__ import annotations

from collections import OrderedDict
from datetime import datetime, timezone

from .config import RuntimeConfig, default_runtime_config
from .models import DiffReport, DiffSnapshot, Finding, ScanReport
from .reporting import resolve_report_reference


def diff_reports(before: ScanReport, after: ScanReport) -> DiffReport:
    before_index = index_findings(before.findings)
    after_index = index_findings(after.findings)

    added_keys = [key for key in after_index if key not in before_index]
    removed_keys = [key for key in before_index if key not in after_index]
    added_findings = [after_index[key] for key in added_keys]
    removed_findings = [before_index[key] for key in removed_keys]

    risk_score_delta = after.risk_score - before.risk_score
    findings_count_delta = len(after.findings) - len(before.findings)
    changed = (
        before.risk_level != after.risk_level
        or before.risk_score != after.risk_score
        or bool(added_findings)
        or bool(removed_findings)
    )

    summary = build_summary(
        before.risk_level,
        after.risk_level,
        risk_score_delta,
        len(added_findings),
        len(removed_findings),
    )

    return DiffReport(
        generated_at=datetime.now(timezone.utc).isoformat(),
        before=DiffSnapshot(
            report_id=before.report_id,
            target=before.target,
            skill_name=before.metadata.name,
            risk_level=before.risk_level,
            risk_score=before.risk_score,
            findings_count=len(before.findings),
        ),
        after=DiffSnapshot(
            report_id=after.report_id,
            target=after.target,
            skill_name=after.metadata.name,
            risk_level=after.risk_level,
            risk_score=after.risk_score,
            findings_count=len(after.findings),
        ),
        summary=summary,
        risk_score_delta=risk_score_delta,
        findings_count_delta=findings_count_delta,
        changed=changed,
        added_findings=added_findings,
        removed_findings=removed_findings,
        added_rules=sorted({finding.rule_id for finding in added_findings}),
        removed_rules=sorted({finding.rule_id for finding in removed_findings}),
    )


def diff_references(
    before_reference: str,
    after_reference: str,
    runtime_config: RuntimeConfig | None = None,
) -> DiffReport:
    runtime_config = runtime_config or default_runtime_config()
    before = resolve_report_reference(before_reference, runtime_config=runtime_config)
    after = resolve_report_reference(after_reference, runtime_config=runtime_config)
    return diff_reports(before, after)


def index_findings(findings: list[Finding]) -> OrderedDict[tuple[str, str | None, str], Finding]:
    indexed: OrderedDict[tuple[str, str | None, str], Finding] = OrderedDict()
    for finding in findings:
        indexed[(finding.rule_id, finding.file_path, finding.evidence)] = finding
    return indexed


def build_summary(
    before_risk_level: str,
    after_risk_level: str,
    risk_score_delta: int,
    added_findings: int,
    removed_findings: int,
) -> str:
    direction = "unchanged"
    if risk_score_delta > 0:
        direction = f"+{risk_score_delta}"
    elif risk_score_delta < 0:
        direction = str(risk_score_delta)

    return (
        f"Risk changed from {before_risk_level} to {after_risk_level} "
        f"(score delta {direction}); "
        f"{added_findings} added finding(s), {removed_findings} removed finding(s)."
    )
