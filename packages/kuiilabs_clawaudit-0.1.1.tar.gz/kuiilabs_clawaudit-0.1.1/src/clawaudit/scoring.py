from __future__ import annotations

from collections import Counter

from .models import Finding, RiskLevel, ScoringConfig


def score_findings(findings: list[Finding], scoring: ScoringConfig) -> tuple[RiskLevel, int, str, dict]:
    if not findings:
        return (
            "Safe",
            0,
            "Risk score 0/100. No risky patterns were detected by the current static rule set.",
            {
                "severity_counts": {"high": 0, "medium": 0, "low": 0},
                "category_counts": {},
                "thresholds": dict(scoring.thresholds),
                "capped": False,
            },
        )

    counts = Counter(finding.severity for finding in findings)
    category_counts = Counter(finding.category for finding in findings)
    duplicate_counts: Counter[str] = Counter()
    total_score = 0.0

    for finding in findings:
        base_weight = scoring.severity_weights[finding.severity]
        category_multiplier = scoring.category_multipliers.get(finding.category, 1.0)
        duplicate_factor = 1.0 if duplicate_counts[finding.rule_id] == 0 else 0.6
        finding.score = max(1, round(base_weight * category_multiplier * duplicate_factor))
        total_score += finding.score
        duplicate_counts[finding.rule_id] += 1

    capped = total_score > 100
    risk_score = min(100, round(total_score))

    if risk_score >= scoring.thresholds["high_risk"]:
        risk_level: RiskLevel = "High Risk"
    elif risk_score >= scoring.thresholds["warning"]:
        risk_level = "Warning"
    else:
        risk_level = "Safe"

    summary = (
        f"Risk score {risk_score}/100 from {len(findings)} finding(s): "
        f"{counts['high']} high, {counts['medium']} medium, {counts['low']} low."
    )
    breakdown = {
        "severity_counts": dict(counts),
        "category_counts": dict(category_counts),
        "thresholds": dict(scoring.thresholds),
        "capped": capped,
    }
    return risk_level, risk_score, summary, breakdown
