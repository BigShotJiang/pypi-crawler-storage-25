from __future__ import annotations

from hashlib import sha1
from pathlib import Path
from datetime import datetime, timezone

from .config import RuntimeConfig, default_runtime_config
from .models import RuntimeObservationReport, RuntimePolicyConfig
from .runtime_runner import RuntimeRunRequest, get_runtime_runner
from .source import prepare_source


def observe_target(
    target: str,
    *,
    script_path: str = "skill.py",
    entrypoint: str = "run",
    allow_missing_entrypoint: bool = False,
    runtime_config: RuntimeConfig | None = None,
    runner_name: str | None = None,
    timeout_ms: int | None = None,
    block_network: bool | None = None,
    block_env: bool | None = None,
    block_shell: bool | None = None,
    allowed_hosts: list[str] | None = None,
    allowed_env_vars: list[str] | None = None,
) -> RuntimeObservationReport:
    runtime_config = runtime_config or default_runtime_config()
    effective_timeout_ms = runtime_config.runtime_execution.timeout_ms if timeout_ms is None else max(1, int(timeout_ms))
    effective_policy = build_effective_runtime_policy(
        runtime_config.runtime_policy,
        block_network=block_network,
        block_env=block_env,
        block_shell=block_shell,
        allowed_hosts=allowed_hosts,
        allowed_env_vars=allowed_env_vars,
    )

    with prepare_source(target) as prepared:
        root_path = Path(prepared.root_path)
        resolved_script_path = resolve_script_path(root_path, script_path)
        runner = get_runtime_runner(runner_name or runtime_config.runtime_execution.runner)
        report = runner.run(
            RuntimeRunRequest(
                target=target,
                prepared_source=prepared,
                root_path=root_path,
                script_path=resolved_script_path,
                entrypoint=entrypoint,
                allow_missing_entrypoint=allow_missing_entrypoint,
                policy=effective_policy,
                timeout_ms=effective_timeout_ms,
            )
        )
        if not report.generated_at:
            report.generated_at = datetime.now(timezone.utc).isoformat()
        if not report.report_id:
            report.report_id = build_runtime_report_id(target, report.generated_at)
        report.script_path = normalize_script_path_for_report(report.root_path, report.script_path)
        return report


def build_effective_runtime_policy(
    base_policy: RuntimePolicyConfig,
    *,
    block_network: bool | None = None,
    block_env: bool | None = None,
    block_shell: bool | None = None,
    allowed_hosts: list[str] | None = None,
    allowed_env_vars: list[str] | None = None,
) -> RuntimePolicyConfig:
    return RuntimePolicyConfig(
        block_network=base_policy.block_network if block_network is None else block_network,
        block_env=base_policy.block_env if block_env is None else block_env,
        block_shell=base_policy.block_shell if block_shell is None else block_shell,
        allowed_hosts=list(base_policy.allowed_hosts if allowed_hosts is None else allowed_hosts),
        allowed_env_vars=list(base_policy.allowed_env_vars if allowed_env_vars is None else allowed_env_vars),
    )


def resolve_script_path(root_path: Path, script_path: str) -> Path:
    path = Path(script_path).expanduser()
    if not path.is_absolute():
        path = (root_path / path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Runtime script not found: {path}")
    if not path.is_file():
        raise FileNotFoundError(f"Runtime script is not a file: {path}")
    return path


def build_runtime_report_id(target: str, generated_at: str) -> str:
    seed = f"{target}:{generated_at}"
    return f"runtime-{sha1(seed.encode('utf-8')).hexdigest()[:12]}"


def normalize_script_path_for_report(root_path: str, script_path: str) -> str:
    root = Path(root_path).resolve()
    script = Path(script_path).resolve()
    try:
        return str(script.relative_to(root))
    except ValueError:
        return str(script)
