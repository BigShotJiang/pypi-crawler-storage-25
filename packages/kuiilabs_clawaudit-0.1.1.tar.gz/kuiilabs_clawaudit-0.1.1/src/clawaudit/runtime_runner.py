from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from shutil import copytree
from tempfile import TemporaryDirectory
from time import perf_counter
import json
import os
import socket
import subprocess
import sys

from .models import PreparedSource, RuntimeObservationReport, RuntimePolicyConfig

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RUNTIME_PROBE_SCRIPT = PROJECT_ROOT / "scripts" / "runtime_probe.py"
DOCKER_RUNTIME_IMAGE = "clawaudit/runtime-probe:latest"


@dataclass(slots=True)
class RuntimeRunRequest:
    target: str
    prepared_source: PreparedSource
    root_path: Path
    script_path: Path
    entrypoint: str
    allow_missing_entrypoint: bool
    policy: RuntimePolicyConfig
    timeout_ms: int


class RuntimeRunner:
    name = "runtime-runner"

    def run(self, request: RuntimeRunRequest) -> RuntimeObservationReport:
        raise NotImplementedError

    def build_probe_command(
        self,
        request: RuntimeRunRequest,
        *,
        root_path: Path,
        script_path: Path,
        policy_path: Path,
        output_path: Path,
    ) -> list[str]:
        command = [
            sys.executable,
            str(RUNTIME_PROBE_SCRIPT),
            "--root-path",
            str(root_path),
            "--target",
            request.target,
            "--source-kind",
            request.prepared_source.source_kind,
            "--script-path",
            str(script_path),
            "--entrypoint",
            request.entrypoint,
            "--policy-json",
            str(policy_path),
            "--output",
            str(output_path),
            "--runner",
            self.name,
        ]
        if request.allow_missing_entrypoint:
            command.append("--allow-missing-entrypoint")
        return command

    def run_probe(
        self,
        request: RuntimeRunRequest,
        *,
        root_path: Path,
        script_path: Path,
        policy_path: Path,
        output_path: Path,
        env: dict[str, str] | None = None,
    ) -> RuntimeObservationReport:
        command = self.build_probe_command(
            request,
            root_path=root_path,
            script_path=script_path,
            policy_path=policy_path,
            output_path=output_path,
        )
        timeout_seconds = request.timeout_ms / 1000 if request.timeout_ms > 0 else None
        started_at = perf_counter()
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False,
                timeout=timeout_seconds,
                env=env,
            )
        except subprocess.TimeoutExpired:
            duration_ms = int((perf_counter() - started_at) * 1000)
            return RuntimeObservationReport(
                report_id="",
                generated_at="",
                target=request.target,
                source_kind=request.prepared_source.source_kind,
                root_path=str(root_path),
                script_path=str(script_path),
                entrypoint=request.entrypoint,
                status="timeout",
                decision="deny",
                summary=f"Runtime analysis timed out after {duration_ms} ms using {self.name}.",
                runner=self.name,
                duration_ms=duration_ms,
                timed_out=True,
                probe_host=socket.gethostname(),
                events=[],
                policy_violations=[f"Runtime analysis exceeded timeout of {request.timeout_ms} ms."],
                error=f"Runtime analysis exceeded timeout of {request.timeout_ms} ms.",
            )

        duration_ms = int((perf_counter() - started_at) * 1000)
        if result.returncode != 0 and not output_path.exists():
            raise RuntimeError(result.stderr.strip() or "runtime probe failed")

        report = RuntimeObservationReport.from_dict(json.loads(output_path.read_text(encoding="utf-8")))
        if report.duration_ms is None:
            report.duration_ms = duration_ms
        report.runner = report.runner or self.name
        return report


class LocalSubprocessRuntimeRunner(RuntimeRunner):
    name = "local-subprocess"

    def run(self, request: RuntimeRunRequest) -> RuntimeObservationReport:
        with TemporaryDirectory(prefix="clawaudit-runtime-") as tmp_dir:
            policy_path = Path(tmp_dir) / "runtime-policy.json"
            output_path = Path(tmp_dir) / "runtime-report.json"
            policy_path.write_text(json.dumps(request.policy.to_dict(), ensure_ascii=False), encoding="utf-8")
            return self.run_probe(
                request,
                root_path=request.root_path,
                script_path=request.script_path,
                policy_path=policy_path,
                output_path=output_path,
            )


class LocalIsolatedCopyRuntimeRunner(RuntimeRunner):
    name = "local-isolated-copy"

    def run(self, request: RuntimeRunRequest) -> RuntimeObservationReport:
        with TemporaryDirectory(prefix="clawaudit-runtime-copy-") as tmp_dir:
            tmp_root = Path(tmp_dir)
            workspace_root = tmp_root / "workspace"
            copytree(request.root_path, workspace_root)
            policy_path = tmp_root / "runtime-policy.json"
            output_path = tmp_root / "runtime-report.json"
            home_dir = tmp_root / "home"
            cache_dir = tmp_root / "cache"
            config_dir = tmp_root / "config"
            data_dir = tmp_root / "data"
            runtime_tmp_dir = tmp_root / "tmp"
            for directory in [home_dir, cache_dir, config_dir, data_dir, runtime_tmp_dir]:
                directory.mkdir(parents=True, exist_ok=True)

            relative_script = request.script_path.relative_to(request.root_path)
            workspace_script_path = workspace_root / relative_script
            policy_path.write_text(json.dumps(request.policy.to_dict(), ensure_ascii=False), encoding="utf-8")

            env = self.build_isolated_env(
                home_dir=home_dir,
                cache_dir=cache_dir,
                config_dir=config_dir,
                data_dir=data_dir,
                tmp_dir=runtime_tmp_dir,
            )
            report = self.run_probe(
                request,
                root_path=workspace_root,
                script_path=workspace_script_path,
                policy_path=policy_path,
                output_path=output_path,
                env=env,
            )
            return remap_runtime_report_paths(
                report,
                original_root=request.root_path,
                workspace_root=workspace_root,
                original_script_path=request.script_path,
            )

    def build_isolated_env(
        self,
        *,
        home_dir: Path,
        cache_dir: Path,
        config_dir: Path,
        data_dir: Path,
        tmp_dir: Path,
    ) -> dict[str, str]:
        env: dict[str, str] = {
            "HOME": str(home_dir),
            "TMPDIR": str(tmp_dir),
            "XDG_CACHE_HOME": str(cache_dir),
            "XDG_CONFIG_HOME": str(config_dir),
            "XDG_DATA_HOME": str(data_dir),
            "PATH": os.environ.get("PATH", ""),
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "LC_ALL": os.environ.get("LC_ALL", os.environ.get("LANG", "C.UTF-8")),
            "PYTHONIOENCODING": "utf-8",
            "PYTHONUTF8": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
        }
        for key in ["SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT"]:
            if key in os.environ:
                env[key] = os.environ[key]
        return env


def get_runtime_runner(name: str | None = None) -> RuntimeRunner:
    normalized = (name or LocalSubprocessRuntimeRunner.name).strip().lower()
    if normalized in {"local-subprocess", "subprocess"}:
        return LocalSubprocessRuntimeRunner()
    if normalized in {"local-isolated-copy", "isolated-copy", "copy"}:
        return LocalIsolatedCopyRuntimeRunner()
    if normalized in {"docker", "container"}:
        return DockerRuntimeRunner()
    raise ValueError(f"Unsupported runtime runner: {name}")


class DockerRuntimeRunner(RuntimeRunner):
    """Container-based runtime runner using Docker for strong isolation.
    
    Runs the runtime probe inside a Docker container with:
    - Read-only source code mount
    - Network disabled by default (--network none)
    - No privileged access
    - Resource limits (memory, CPU)
    - Ephemeral filesystem (container removed after execution)
    """
    name = "docker"

    def __init__(self, image: str = DOCKER_RUNTIME_IMAGE, network_enabled: bool = False):
        self.image = image
        self.network_enabled = network_enabled

    def _check_docker_available(self) -> None:
        """Check if Docker daemon is available."""
        try:
            subprocess.run(
                ["docker", "info"],
                capture_output=True,
                text=True,
                check=True,
                timeout=10,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError) as e:
            raise RuntimeError(
                "Docker daemon not available. Ensure Docker is installed and running. "
                "Alternatively, use 'local-subprocess' or 'local-isolated-copy' runner."
            ) from e

    def _ensure_image_available(self) -> None:
        """Pull the runtime probe image if not present locally."""
        try:
            subprocess.run(
                ["docker", "image", "inspect", self.image],
                capture_output=True,
                text=True,
                check=True,
                timeout=30,
            )
        except subprocess.CalledProcessError:
            subprocess.run(
                ["docker", "pull", self.image],
                capture_output=True,
                text=True,
                check=True,
                timeout=300,
            )

    def run(self, request: RuntimeRunRequest) -> RuntimeObservationReport:
        self._check_docker_available()
        self._ensure_image_available()

        with TemporaryDirectory(prefix="clawaudit-docker-") as tmp_dir:
            tmp_root = Path(tmp_dir)
            policy_path = tmp_root / "runtime-policy.json"
            output_path = tmp_root / "runtime-report.json"
            policy_path.write_text(json.dumps(request.policy.to_dict(), ensure_ascii=False), encoding="utf-8")

            # Build docker run command
            network_arg = "--network host" if self.network_enabled else "--network none"
            docker_args = [
                "docker", "run", "--rm",
                network_arg,
                "--read-only",
                "--tmpfs", "/tmp:exec,size=64m",
                "--tmpfs", "/var/tmp:exec,size=64m",
                "--cap-drop=ALL",
                "--security-opt", "no-new-privileges",
                "--memory", "256m",
                "--cpus", "0.5",
                "-v", f"{request.root_path}:/workspace:ro",
                "-v", f"{policy_path}:/policy.json:ro",
                "-v", f"{output_path}:/report.json",
            ]

            # Build probe command inside container
            container_script_path = f"/workspace/{request.script_path.relative_to(request.root_path)}"
            probe_cmd = [
                "python",
                "/probe.py",
                "--root-path", "/workspace",
                "--target", request.target,
                "--source-kind", request.prepared_source.source_kind,
                "--script-path", container_script_path,
                "--entrypoint", request.entrypoint,
                "--policy-json", "/policy.json",
                "--output", "/report.json",
                "--runner", self.name,
            ]
            if request.allow_missing_entrypoint:
                probe_cmd.append("--allow-missing-entrypoint")

            timeout_seconds = request.timeout_ms / 1000 if request.timeout_ms > 0 else None
            started_at = perf_counter()

            try:
                # Mount the probe script into the container
                probe_mount_args = ["-v", f"{RUNTIME_PROBE_SCRIPT}:/probe.py:ro"]
                full_args = docker_args + probe_mount_args + [self.image] + probe_cmd

                result = subprocess.run(
                    full_args,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=timeout_seconds,
                )
            except subprocess.TimeoutExpired:
                duration_ms = int((perf_counter() - started_at) * 1000)
                return RuntimeObservationReport(
                    report_id="",
                    generated_at="",
                    target=request.target,
                    source_kind=request.prepared_source.source_kind,
                    root_path=str(request.root_path),
                    script_path=str(request.script_path),
                    entrypoint=request.entrypoint,
                    status="timeout",
                    decision="deny",
                    summary=f"Runtime analysis timed out after {duration_ms} ms using {self.name}.",
                    runner=self.name,
                    duration_ms=duration_ms,
                    timed_out=True,
                    probe_host=socket.gethostname(),
                    events=[],
                    policy_violations=[f"Runtime analysis exceeded timeout of {request.timeout_ms} ms."],
                    error=f"Runtime analysis exceeded timeout of {request.timeout_ms} ms.",
                )

            duration_ms = int((perf_counter() - started_at) * 1000)
            if result.returncode != 0 and not output_path.exists():
                raise RuntimeError(result.stderr.strip() or "docker runtime probe failed")

            report = RuntimeObservationReport.from_dict(json.loads(output_path.read_text(encoding="utf-8")))
            if report.duration_ms is None:
                report.duration_ms = duration_ms
            report.runner = report.runner or self.name
            return report


def remap_runtime_report_paths(
    report: RuntimeObservationReport,
    *,
    original_root: Path,
    workspace_root: Path,
    original_script_path: Path,
) -> RuntimeObservationReport:
    report.root_path = str(original_root)
    report.script_path = str(original_script_path)
    for event in report.events:
        remapped_target = remap_path_string(event.target, workspace_root, original_root)
        if remapped_target is not None:
            event.target = remapped_target
    if report.error:
        report.error = report.error.replace(str(workspace_root), str(original_root))
    report.summary = report.summary.replace(str(workspace_root), str(original_root))
    return report


def remap_path_string(value: str, source_root: Path, target_root: Path) -> str | None:
    candidate = Path(value)
    if not candidate.is_absolute():
        return None
    try:
        relative = candidate.resolve().relative_to(source_root.resolve())
    except ValueError:
        return None
    return str((target_root / relative).resolve())
