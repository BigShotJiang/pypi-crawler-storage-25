from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.parse import parse_qs
import re
import subprocess

from .models import PreparedSource

REPO_URL_PATTERN = re.compile(r"^(https?|ssh|git|file)://|^git@")
GITHUB_TREE_URL_PATTERN = re.compile(
    r"^https://github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+)/tree/(?P<ref>[^/]+)(?:/(?P<subpath>.+))?$"
)
COMMIT_REF_PATTERN = re.compile(r"^[0-9a-f]{7,40}$", re.IGNORECASE)


def is_repo_url(target: str) -> bool:
    parsed = parse_target_spec(target)
    return bool(REPO_URL_PATTERN.match(parsed["base_target"]))


def parse_target_spec(target: str) -> dict[str, str | None]:
    github_tree_match = GITHUB_TREE_URL_PATTERN.match(target)
    if github_tree_match:
        owner = github_tree_match.group("owner")
        repo = github_tree_match.group("repo")
        return {
            "base_target": f"https://github.com/{owner}/{repo}",
            "ref": github_tree_match.group("ref"),
            "subpath": github_tree_match.group("subpath"),
        }

    if "#" in target:
        base_target, fragment = target.split("#", 1)
        fragment_values = parse_fragment_values(fragment)
        return {
            "base_target": base_target,
            "ref": fragment_values.get("ref"),
            "subpath": fragment_values.get("subdir"),
        }

    return {
        "base_target": target,
        "ref": None,
        "subpath": None,
    }


def resolve_root_path(base_path: Path, subpath: str | None) -> Path:
    root_path = base_path
    if subpath:
        root_path = base_path / subpath

    if not root_path.exists():
        raise FileNotFoundError(f"Resolved scan root does not exist: {root_path}")
    if not root_path.is_dir():
        raise NotADirectoryError(f"Resolved scan root is not a directory: {root_path}")

    return root_path


@contextmanager
def prepare_source(target: str):
    target_spec = parse_target_spec(target)
    base_target = str(target_spec["base_target"])
    ref = target_spec["ref"]
    subpath = target_spec["subpath"]
    path = Path(base_target).expanduser()

    if path.exists():
        if ref:
            raise ValueError("Local path targets do not support #ref. Use a repository URL such as https://...#ref=<tag> or file://...#ref=<tag>.")
        root_path = resolve_root_path(path.resolve(), subpath)
        yield PreparedSource(target=target, source_kind="local", root_path=str(root_path))
        return

    if not is_repo_url(target):
        raise FileNotFoundError(f"Target does not exist and is not a supported repository URL: {target}")

    if ref and COMMIT_REF_PATTERN.match(ref):
        raise ValueError(
            "Commit-pinned GitHub tree URLs are not supported yet. Use a branch/tag tree URL or a repo URL with #subdir=..."
        )

    with TemporaryDirectory(prefix="clawaudit-") as tmp_dir:
        repo_dir = Path(tmp_dir) / "repo"
        clone_command = ["git", "clone", "--depth", "1"]
        if ref:
            clone_command.extend(["--branch", ref])
        clone_command.extend([base_target, str(repo_dir)])
        result = subprocess.run(clone_command, capture_output=True, text=True, check=False)
        if result.returncode != 0:
            stderr = result.stderr.strip() or "unknown git clone error"
            raise RuntimeError(f"Failed to clone repository: {stderr}")

        root_path = resolve_root_path(repo_dir.resolve(), subpath)
        yield PreparedSource(target=target, source_kind="git", root_path=str(root_path))


def parse_fragment_values(fragment: str) -> dict[str, str | None]:
    if "=" not in fragment:
        return {"ref": None, "subdir": None}

    parsed = parse_qs(fragment, keep_blank_values=False)
    return {
        "ref": parsed.get("ref", [None])[0],
        "subdir": parsed.get("subdir", [None])[0],
    }
