from __future__ import annotations

import argparse
from functools import lru_cache
import importlib.metadata
import json
from pathlib import Path
import sys
import tomllib

from .batch import scan_targets
from .badge import build_badge_options, format_badge_json, format_badge_markdown, format_badge_svg
from .config import load_runtime_config
from .discovery import discover_skill_targets
from .diffing import diff_references
from .formatters import (
    format_batch_markdown,
    format_batch_text,
    format_diff_markdown,
    ReleaseNotesOptions,
    format_release_markdown,
    format_release_text,
    format_diff_text,
    format_json,
    format_markdown,
    format_runtime_json,
    format_runtime_markdown,
    format_runtime_text,
    format_sarif,
    format_text,
)
from .persistence import persist_report
from .reporting import resolve_report_reference
from .rules import get_rule_details, RULE_CATALOG
from .runtime_analysis import observe_target
from .source import is_repo_url
from .status import batch_trips_gate, diff_trips_gate, report_trips_gate
from .scanner import scan_target
from .verification import verify_badge_report_pair, format_verification_result


def add_scan_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--format", choices=["text", "json", "markdown", "sarif"], default="text", help="Output format")
    parser.add_argument("--output", help="Write the report to a file instead of stdout")
    parser.add_argument("--config", help="Path to clawaudit TOML config")
    parser.add_argument("--persist-dir", help="Override report persistence directory")
    parser.add_argument("--no-persist", action="store_true", help="Disable persistence for this run")
    parser.add_argument("--enforce-policy", action="store_true", help="Apply policy gates from the loaded config file")
    parser.add_argument("--fail-on", choices=["Safe", "Warning", "High Risk"], help="Return exit code 2 when this risk level or higher is reached")
    parser.add_argument("--max-risk-score", type=int, help="Return exit code 2 when the risk score is greater than or equal to this value")


def add_output_arguments(parser: argparse.ArgumentParser, *, formats: list[str]) -> None:
    parser.add_argument("--format", choices=formats, default=formats[0], help="Output format")
    parser.add_argument("--output", help="Write the report to a file instead of stdout")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="clawaudit", description="Static scanner for OpenClaw skills.")
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {get_cli_version()}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan", help="Scan a local skill directory or repository URL.")
    scan_parser.add_argument("target", help="Local path or git repository URL")
    add_scan_arguments(scan_parser)

    batch_parser = subparsers.add_parser(
        "scan-batch",
        help="Scan multiple skill directories or repository URLs in one run.",
    )
    batch_parser.add_argument("targets", nargs="*", help="Targets to scan")
    batch_parser.add_argument("--targets-file", help="Path to a newline-delimited targets file")
    add_output_arguments(batch_parser, formats=["text", "json", "markdown"])
    batch_parser.add_argument("--config", help="Path to clawaudit TOML config")
    batch_parser.add_argument("--persist-dir", help="Override report persistence directory")
    batch_parser.add_argument("--no-persist", action="store_true", help="Disable persistence for this run")
    batch_parser.add_argument("--enforce-policy", action="store_true", help="Apply policy gates from the loaded config file")
    batch_parser.add_argument("--fail-on", choices=["Safe", "Warning", "High Risk"], help="Return exit code 2 when any result reaches this risk level or higher")
    batch_parser.add_argument("--max-risk-score", type=int, help="Return exit code 2 when any result reaches this risk score")
    batch_parser.add_argument("--fail-on-error", action="store_true", help="Return exit code 2 when any target fails to scan")

    diff_parser = subparsers.add_parser(
        "diff",
        help="Compare two scan references. Each reference can be a target path, repository URL, or report JSON file.",
    )
    diff_parser.add_argument("before", help="Baseline reference")
    diff_parser.add_argument("after", help="Current reference")
    add_output_arguments(diff_parser, formats=["text", "json", "markdown"])
    diff_parser.add_argument("--config", help="Path to clawaudit TOML config")
    diff_parser.add_argument("--fail-on", choices=["Safe", "Warning", "High Risk"], help="Return exit code 2 when the current side reaches this risk level or higher")
    diff_parser.add_argument("--max-risk-score", type=int, help="Return exit code 2 when the current side reaches this risk score")
    diff_parser.add_argument("--fail-on-regression", action="store_true", help="Return exit code 2 when the current side introduces additional risk")

    release_parser = subparsers.add_parser(
        "release-notes",
        help="Generate release-oriented notes from two scan references.",
    )
    release_parser.add_argument("before", help="Baseline reference")
    release_parser.add_argument("after", help="Current reference")
    add_output_arguments(release_parser, formats=["markdown", "text", "json"])
    release_parser.add_argument("--config", help="Path to clawaudit TOML config")
    release_parser.add_argument("--release-label", help="Release label or tag shown in the notes")
    release_parser.add_argument("--release-url", help="Release page URL")
    release_parser.add_argument("--repository", help="Repository name to include in the notes")
    release_parser.add_argument("--compare-url", help="Repository compare URL for this release")
    release_parser.add_argument("--base-label", help="Readable baseline label instead of the before report id")
    release_parser.add_argument("--head-label", help="Readable current label instead of the after report id")
    release_parser.add_argument("--workflow-run-url", help="Workflow run URL associated with this release artifact")

    runtime_parser = subparsers.add_parser(
        "runtime-scan",
        help="Run a Python skill with runtime observation and optional policy blocking.",
    )
    runtime_parser.add_argument("target", help="Local path or repository URL")
    runtime_parser.add_argument("--script", default="skill.py", help="Script path inside the skill root")
    runtime_parser.add_argument("--entrypoint", default="run", help="Function to call after import")
    runtime_parser.add_argument("--allow-missing-entrypoint", action="store_true", help="Import the script even when the entrypoint is missing")
    add_output_arguments(runtime_parser, formats=["text", "json", "markdown"])
    runtime_parser.add_argument("--config", help="Path to clawaudit TOML config")
    runtime_parser.add_argument("--persist-dir", help="Override report persistence directory")
    runtime_parser.add_argument("--no-persist", action="store_true", help="Disable persistence for this run")
    runtime_parser.add_argument("--runner", help="Runtime runner to use: local-subprocess (default), local-isolated-copy, or docker (container isolation)")
    runtime_parser.add_argument("--timeout-ms", type=int, help="Maximum runtime execution time in milliseconds")
    runtime_parser.add_argument("--block-network", action="store_true", help="Block all outbound network access during runtime analysis")
    runtime_parser.add_argument("--block-env", action="store_true", help="Block environment variable reads during runtime analysis")
    runtime_parser.add_argument("--block-shell", action="store_true", help="Block subprocess and shell execution during runtime analysis")
    runtime_parser.add_argument("--allow-host", action="append", default=[], help="Host allowed during runtime analysis; repeated flag")
    runtime_parser.add_argument("--allow-env-var", action="append", default=[], help="Environment variable name allowed during runtime analysis; repeated flag")

    badge_parser = subparsers.add_parser(
        "badge",
        help="Generate a badge payload or markdown snippet from a target or report JSON.",
    )
    badge_parser.add_argument("reference", help="Target path, repository URL, or report JSON file")
    badge_parser.add_argument("--format", choices=["json", "markdown", "svg"], default="json", help="Output format")
    badge_parser.add_argument("--output", help="Write the badge to a file instead of stdout")
    badge_parser.add_argument("--config", help="Path to clawaudit TOML config")
    badge_parser.add_argument("--label", help="Badge label text; pass an empty string for a compact badge")
    badge_parser.add_argument("--display", choices=["both", "level", "score"], default="both", help="Badge value content")
    badge_parser.add_argument("--style", choices=["pill", "flat"], default="pill", help="Badge visual style")
    badge_parser.add_argument("--label-color", help="Badge label segment color as a 6-digit hex code")
    badge_parser.add_argument("--message-color", help="Badge message segment color as a 6-digit hex code")

    verify_parser = subparsers.add_parser(
        "verify",
        help="Verify a badge-report pair using cryptographic hash verification.",
    )
    verify_parser.add_argument("badge", help="Path to badge SVG file")
    verify_parser.add_argument("--report", help="Path to report JSON file for verification")
    verify_parser.add_argument("--report-hash", help="Expected report hash for verification (alternative to --report)")
    verify_parser.add_argument("--format", choices=["text", "json", "markdown"], default="text", help="Output format")
    verify_parser.add_argument("--output", help="Write output to a file instead of stdout")
    verify_parser.add_argument("--config", help="Path to clawaudit TOML config (unused, for consistency)")

    discover_parser = subparsers.add_parser("discover-targets", help="Discover local skill roots in a monorepo.")
    discover_parser.add_argument("root", nargs="?", default=".", help="Repository root to inspect")
    discover_parser.add_argument("--changed-file", action="append", dest="changed_files", default=[], help="Changed file path to map back to a skill root")
    discover_parser.add_argument("--changed-files-file", help="Path to a newline-delimited changed files list")
    add_output_arguments(discover_parser, formats=["text", "json"])

    serve_parser = subparsers.add_parser("serve", help="Run the ClawAudit API and web app.")
    serve_parser.add_argument("--host", default="127.0.0.1", help="Host interface to bind")
    serve_parser.add_argument("--port", type=int, default=8000, help="Port to bind")
    serve_parser.add_argument("--reload", action="store_true", help="Enable auto-reload")

    explain_parser = subparsers.add_parser(
        "explain",
        help="Show detailed explanation of a specific rule including examples and fix suggestions.",
    )
    explain_parser.add_argument("rule_id", help="Rule ID to explain (e.g., shell-exec, network-call)")
    explain_parser.add_argument("--format", choices=["text", "json", "markdown"], default="text", help="Output format")

    return parser


def collect_batch_targets(cli_targets: list[str], targets_file: str | None) -> list[str]:
    targets = list(cli_targets)
    if targets_file:
        targets.extend(load_targets_from_file(targets_file))
    if not targets:
        raise ValueError("scan-batch requires at least one target or --targets-file")
    return targets


def load_targets_from_file(targets_file: str) -> list[str]:
    file_path = Path(targets_file).expanduser()
    if not file_path.is_absolute():
        file_path = Path.cwd() / file_path
    if not file_path.exists():
        raise FileNotFoundError(f"Targets file not found: {file_path}")

    targets: list[str] = []
    for raw_line in file_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue

        if is_repo_url(line):
            targets.append(line)
            continue

        path = Path(line).expanduser()
        if not path.is_absolute():
            path = (file_path.parent / path).resolve()
        targets.append(str(path))

    return targets


def load_changed_files_from_file(changed_files_file: str) -> list[str]:
    file_path = Path(changed_files_file).expanduser()
    if not file_path.is_absolute():
        file_path = Path.cwd() / file_path
    if not file_path.exists():
        raise FileNotFoundError(f"Changed files list not found: {file_path}")

    changed_files: list[str] = []
    for raw_line in file_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        changed_files.append(line)

    return changed_files


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command not in {"scan", "scan-batch", "diff", "release-notes", "runtime-scan", "badge", "verify", "discover-targets", "serve", "explain"}:
        parser.error(f"Unsupported command: {args.command}")

    if args.command == "serve":
        return run_serve_command(args)

    if args.command == "explain":
        return handle_explain_command(args)

    try:
        if args.command == "discover-targets":
            changed_files = list(args.changed_files)
            if args.changed_files_file:
                changed_files.extend(load_changed_files_from_file(args.changed_files_file))
            targets = discover_skill_targets(args.root, changed_files=changed_files or None)
            payload = {
                "root": str(Path(args.root).expanduser().resolve()),
                "count": len(targets),
                "targets": targets,
                "mode": "changed-files" if changed_files else "full-scan",
            }
            output = json.dumps(payload, indent=2, ensure_ascii=False) if args.format == "json" else "\n".join(targets)
            exit_code = 0
        else:
            runtime_config = load_runtime_config(args.config, cwd=Path.cwd())

            if args.command == "scan":
                if args.persist_dir:
                    runtime_config.persistence.directory = args.persist_dir
                if args.no_persist:
                    runtime_config.persistence.enabled = False

                report = scan_target(args.target, runtime_config=runtime_config)
                if runtime_config.persistence.enabled:
                    report.persisted_paths = persist_report(report, runtime_config.persistence, cwd=Path.cwd())
                output = format_single_output(report, args.format)
                exit_code = 2 if report_trips_gate(
                    report,
                    fail_on=args.fail_on,
                    max_risk_score=args.max_risk_score,
                    policy=runtime_config.policy if args.enforce_policy else None,
                ) else 0
            elif args.command == "scan-batch":
                if args.persist_dir:
                    runtime_config.persistence.directory = args.persist_dir
                if args.no_persist:
                    runtime_config.persistence.enabled = False

                targets = collect_batch_targets(args.targets, args.targets_file)
                report = scan_targets(targets, runtime_config=runtime_config, cwd=Path.cwd())
                output = format_batch_output(report, args.format)
                exit_code = 2 if batch_trips_gate(
                    report,
                    fail_on=args.fail_on,
                    max_risk_score=args.max_risk_score,
                    fail_on_error=args.fail_on_error,
                    policy=runtime_config.policy if args.enforce_policy else None,
                ) else 0
            elif args.command == "diff":
                report = diff_references(args.before, args.after, runtime_config=runtime_config)
                output = format_diff_output(report, args.format)
                exit_code = 2 if diff_trips_gate(
                    report,
                    fail_on=args.fail_on,
                    max_risk_score=args.max_risk_score,
                    fail_on_regression=args.fail_on_regression,
                ) else 0
            elif args.command == "release-notes":
                report = diff_references(args.before, args.after, runtime_config=runtime_config)
                output = format_release_output(report, args.format, build_release_notes_options_from_args(args))
                exit_code = 0
            elif args.command == "runtime-scan":
                if args.persist_dir:
                    runtime_config.persistence.directory = args.persist_dir
                if args.no_persist:
                    runtime_config.persistence.enabled = False

                report = observe_target(
                    args.target,
                    script_path=args.script,
                    entrypoint=args.entrypoint,
                    allow_missing_entrypoint=args.allow_missing_entrypoint,
                    runtime_config=runtime_config,
                    runner_name=args.runner,
                    timeout_ms=args.timeout_ms,
                    block_network=True if args.block_network else None,
                    block_env=True if args.block_env else None,
                    block_shell=True if args.block_shell else None,
                    allowed_hosts=args.allow_host or None,
                    allowed_env_vars=args.allow_env_var or None,
                )
                # RuntimeObservationReport 不使用 persist_report (该函数仅支持 ScanReport)
                # 如需持久化 runtime 报告，使用专门的 runtime 持久化逻辑
                output = format_runtime_output(report, args.format)
                exit_code = 2 if report.decision == "deny" and report.status in {"blocked", "timeout"} else (1 if report.status == "error" else 0)
            elif args.command == "verify":
                result = verify_badge_report_pair(
                    badge_path=args.badge,
                    report_path=args.report,
                    report_hash=args.report_hash,
                )
                output = format_verification_result(result, output_format=args.format)
                exit_code = 0 if result["valid"] else 1
            else:
                report = resolve_report_reference(args.reference, runtime_config=runtime_config)
                badge_options = build_badge_options(
                    label=args.label,
                    display=args.display,
                    style=args.style,
                    label_color=args.label_color,
                    message_color=args.message_color,
                )
                if args.format == "json":
                    output = format_badge_json(report, badge_options)
                elif args.format == "svg":
                    output = format_badge_svg(report, badge_options)
                else:
                    output = format_badge_markdown(report, badge_options)
                exit_code = 0
    except Exception as exc:
        print(f"Scan failed: {exc}", file=sys.stderr)
        return 1

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
    else:
        print(output)
    return exit_code


def format_single_output(report, output_format: str) -> str:
    if output_format == "json":
        return format_json(report)
    if output_format == "markdown":
        return format_markdown(report)
    if output_format == "sarif":
        return format_sarif(report)
    return format_text(report)


def format_batch_output(report, output_format: str) -> str:
    if output_format == "json":
        return format_json(report)
    if output_format == "markdown":
        return format_batch_markdown(report)
    return format_batch_text(report)


def format_diff_output(report, output_format: str) -> str:
    if output_format == "json":
        return format_json(report)
    if output_format == "markdown":
        return format_diff_markdown(report)
    return format_diff_text(report)


def format_release_output(report, output_format: str, options: ReleaseNotesOptions | None = None) -> str:
    if output_format == "json":
        return format_json(report)
    if output_format == "markdown":
        return format_release_markdown(report, options)
    return format_release_text(report, options)


def format_runtime_output(report, output_format: str) -> str:
    if output_format == "json":
        return format_runtime_json(report)
    if output_format == "markdown":
        return format_runtime_markdown(report)
    return format_runtime_text(report)


def build_release_notes_options_from_args(args) -> ReleaseNotesOptions:
    return ReleaseNotesOptions(
        release_label=getattr(args, "release_label", None),
        release_url=getattr(args, "release_url", None),
        repository=getattr(args, "repository", None),
        compare_url=getattr(args, "compare_url", None),
        base_label=getattr(args, "base_label", None),
        head_label=getattr(args, "head_label", None),
        workflow_run_url=getattr(args, "workflow_run_url", None),
    )


@lru_cache(maxsize=1)
def get_cli_version() -> str:
    pyproject_path = Path(__file__).resolve().parents[2] / "pyproject.toml"
    if pyproject_path.exists():
        pyproject_data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
        version = pyproject_data.get("project", {}).get("version")
        if isinstance(version, str) and version.strip():
            return version.strip()

    for distribution_name in ("kuiilabs-clawaudit", "clawaudit"):
        try:
            return importlib.metadata.version(distribution_name)
        except importlib.metadata.PackageNotFoundError:
            continue
    return "0.0.0"


def run_serve_command(args) -> int:
    project_root = Path(__file__).resolve().parents[2]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

    import uvicorn
    from services.api.app import create_app

    uvicorn.run(create_app(), host=args.host, port=args.port, reload=args.reload)
    return 0


def handle_explain_command(args) -> int:
    """处理 explain 命令 - 显示规则详细说明。"""
    rule_id = args.rule_id
    output_format = args.format

    if rule_id not in RULE_CATALOG:
        available_rules = ", ".join(sorted(RULE_CATALOG.keys()))
        print(f"未知规则：{rule_id}", file=sys.stderr)
        print(f"可用规则：{available_rules}", file=sys.stderr)
        return 1

    profile = RULE_CATALOG[rule_id]
    details = get_rule_details(rule_id)

    if output_format == "json":
        output = format_rule_explain_json(rule_id, profile, details)
    elif output_format == "markdown":
        output = format_rule_explain_markdown(rule_id, profile, details)
    else:
        output = format_rule_explain_text(rule_id, profile, details)

    print(output)
    return 0


def format_rule_explain_text(rule_id: str, profile, details: dict | None) -> str:
    """生成 rules 命令的文本输出。"""
    if not details:
        return f"规则 {rule_id} 暂无详细说明。"

    lines = [
        f"规则说明：{profile.title}",
        "=" * 50,
        "",
        f"规则 ID: {rule_id}",
        f"分类：{profile.category}",
        f"默认严重级别：{profile.default_severity}",
        "",
        "检测内容:",
        f"  {details['description']}",
        "",
        "触发示例:",
    ]

    for example in details["examples"]["trigger"]:
        lines.append(f"  {example}")

    lines.extend(["", "安全示例:"])
    for example in details["examples"]["safe"]:
        lines.append(f"  {example}")

    lines.extend([
        "",
        "修复建议:",
        f"  {details['fix']}",
        "",
        f"更多文档：rules/{rule_id}.md",
    ])

    return "\n".join(lines)


def format_rule_explain_markdown(rule_id: str, profile, details: dict | None) -> str:
    """生成 rules 命令的 Markdown 输出。"""
    if not details:
        return f"# 规则 {rule_id}\n\n暂无详细说明。"

    lines = [
        f"# 规则说明：{profile.title}",
        "",
        f"| 属性 | 值 |",
        f"|------|-----|",
        f"| 规则 ID | `{rule_id}` |",
        f"| 分类 | {profile.category} |",
        f"| 默认严重级别 | {profile.default_severity} |",
        "",
        "## 检测内容",
        "",
        details["description"],
        "",
        "## 触发示例",
        "",
        "```python",
    ]

    for example in details["examples"]["trigger"]:
        lines.append(example)

    lines.extend([
        "```",
        "",
        "## 安全示例",
        "",
        "```python",
    ])

    for example in details["examples"]["safe"]:
        lines.append(example)

    lines.extend([
        "```",
        "",
        "## 修复建议",
        "",
        details["fix"],
        "",
        "## 更多文档",
        "",
        f"参见 `rules/{rule_id}.md`",
    ])

    return "\n".join(lines)


def format_rule_explain_json(rule_id: str, profile, details: dict | None) -> str:
    """生成 rules 命令的 JSON 输出。"""
    payload = {
        "rule_id": rule_id,
        "title": profile.title,
        "category": profile.category,
        "default_severity": profile.default_severity,
        "recommendation": profile.recommendation,
        "details": details,
    }
    return json.dumps(payload, indent=2, ensure_ascii=False)
