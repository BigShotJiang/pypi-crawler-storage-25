from __future__ import annotations

from hashlib import sha1
from pathlib import Path
import json
import re

from .models import PersistenceConfig, ScanReport


def persist_report(report: ScanReport, persistence: PersistenceConfig, cwd: Path | None = None) -> list[str]:
    cwd = cwd or Path.cwd()
    base_dir = Path(persistence.directory)
    if not base_dir.is_absolute():
        base_dir = cwd / base_dir

    target_dir = base_dir / build_target_slug(report)
    target_dir.mkdir(parents=True, exist_ok=True)

    timestamp = sanitize_timestamp(report.generated_at)
    timestamped_path = target_dir / f"{timestamp}.json"
    latest_path = target_dir / "latest.json"

    payload = json.dumps(report.to_dict(), indent=2, ensure_ascii=False)
    timestamped_path.write_text(payload, encoding="utf-8")
    latest_path.write_text(payload, encoding="utf-8")

    return [str(timestamped_path.resolve()), str(latest_path.resolve())]


def build_target_slug(report: ScanReport) -> str:
    name = slugify(report.metadata.name or "skill")
    target_hash = sha1(report.target.encode("utf-8")).hexdigest()[:10]
    return f"{name}-{target_hash}"


def slugify(value: str) -> str:
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or "scan"


def sanitize_timestamp(value: str) -> str:
    sanitized = value.replace("+00:00", "Z").replace(":", "")
    return sanitized.replace("-", "")
