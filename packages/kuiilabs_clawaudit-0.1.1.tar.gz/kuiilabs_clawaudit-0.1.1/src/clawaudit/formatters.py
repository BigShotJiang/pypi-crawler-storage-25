from __future__ import annotations

from dataclasses import asdict, dataclass
import json

from .models import BatchScanReport, DiffReport, Finding, RuntimeObservationReport, ScanReport
from .rules import RULE_CATALOG


@dataclass(slots=True)
class ReleaseNotesOptions:
    release_label: str | None = None
    release_url: str | None = None
    repository: str | None = None
    compare_url: str | None = None
    base_label: str | None = None
    head_label: str | None = None
    workflow_run_url: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def format_text(report: ScanReport) -> str:
    # Build rule transparency breakdown
    rules_checked = set(finding.rule_id for finding in report.findings)
    rules_by_category = {}
    for rule_id, profile in RULE_CATALOG.items():
        cat = profile.category
        if cat not in rules_by_category:
            rules_by_category[cat] = {"passed": [], "failed": []}
        if rule_id in rules_checked:
            rules_by_category[cat]["failed"].append(rule_id)
        else:
            rules_by_category[cat]["passed"].append(rule_id)

    lines = [
        f"Report ID: {report.report_id}",
        f"Generated At: {report.generated_at}",
        f"Skill: {report.metadata.name}",
        f"Target: {report.target}",
        f"Source: {report.source_kind}",
        f"Root: {report.root_path}",
        f"Risk Level: {report.risk_level}",
        f"Risk Score: {report.risk_score}/100",
        f"Summary: {report.summary}",
        "",
        "Rules Checked:",
    ]

    for category in sorted(rules_by_category.keys()):
        passed = rules_by_category[category]["passed"]
        failed = rules_by_category[category]["failed"]
        passed_count = len(passed)
        failed_count = len(failed)
        total = passed_count + failed_count
        status_str = f"{failed_count}/{total} issues" if failed_count > 0 else f"{passed_count}/{passed_count} clean"
        lines.append(f"  {category}: {status_str}")
        for rule_id in failed:
            lines.append(f"    - [FAIL] {rule_id}")
        for rule_id in passed:
            lines.append(f"    - [PASS] {rule_id}")

    lines.extend([
        "",
        "Declared Permissions: " + (
            ", ".join(report.metadata.declared_permissions)
            if report.metadata.declared_permissions
            else "none detected"
        ),
        "",
        "Findings:",
    ])

    if not report.findings:
        lines.append("- None")
        return "\n".join(lines)

    for finding in report.findings:
        lines.extend(
            [
                f"- [{finding.severity.upper()}] {finding.title}",
                f"  Rule: {finding.rule_id}",
                f"  Category: {finding.category}",
                f"  Score: {finding.score}",
                f"  File: {finding.file_path or 'n/a'}",
                f"  Evidence: {finding.evidence}",
                f"  Recommendation: {finding.recommendation}",
            ]
        )

    if report.persisted_paths:
        lines.extend(["", "Persisted Reports:"])
        lines.extend([f"- {path}" for path in report.persisted_paths])

    return "\n".join(lines)


def format_batch_text(report: BatchScanReport) -> str:
    lines = [
        f"Generated At: {report.generated_at}",
        f"Total Targets: {report.total_targets}",
        f"Succeeded: {report.succeeded}",
        f"Failed: {report.failed}",
        "Risk Levels: "
        + ", ".join(
            [
                f"Safe={report.risk_level_counts['Safe']}",
                f"Warning={report.risk_level_counts['Warning']}",
                f"High Risk={report.risk_level_counts['High Risk']}",
            ]
        ),
        "",
        "Batch Results:",
    ]

    if not report.entries:
        lines.append("- None")
        return "\n".join(lines)

    for entry in report.entries:
        if entry.status == "error":
            lines.extend(
                [
                    f"- [ERROR] {entry.target}",
                    f"  Error: {entry.error}",
                ]
            )
            continue

        lines.extend(
            [
                f"- [{entry.risk_level}] {entry.skill_name}",
                f"  Target: {entry.target}",
                f"  Source: {entry.source_kind}",
                f"  Report ID: {entry.report_id}",
                f"  Risk Score: {entry.risk_score}/100",
                f"  Findings: {entry.findings_count}",
                f"  Summary: {entry.summary}",
            ]
        )
        if entry.persisted_paths:
            lines.append(f"  Persisted Reports: {', '.join(entry.persisted_paths)}")

    return "\n".join(lines)


def format_markdown(report: ScanReport) -> str:
    lines = [
        f"# ClawAudit Report: {report.metadata.name}",
        "",
        f"- Risk Level: **{report.risk_level}**",
        f"- Risk Score: **{report.risk_score}/100**",
        f"- Target: `{report.target}`",
        f"- Source: `{report.source_kind}`",
        f"- Summary: {report.summary}",
        "",
        "## Declared Permissions",
        "",
    ]

    if report.metadata.declared_permissions:
        lines.extend([f"- `{permission}`" for permission in report.metadata.declared_permissions])
    else:
        lines.append("- none detected")

    lines.extend(["", "## Findings", ""])
    if not report.findings:
        lines.append("No findings.")
        return "\n".join(lines)

    lines.extend(
        [
            "| Severity | Rule | File | Evidence | Score |",
            "|---|---|---|---|---:|",
        ]
    )
    for finding in report.findings:
        evidence = sanitize_markdown(finding.evidence)
        file_path = sanitize_markdown(finding.file_path or "n/a")
        lines.append(
            f"| {finding.severity.upper()} | `{finding.rule_id}` | `{file_path}` | {evidence} | {finding.score} |"
        )

    return "\n".join(lines)


def format_batch_markdown(report: BatchScanReport) -> str:
    lines = [
        "# ClawAudit Batch Scan",
        "",
        f"- Total Targets: **{report.total_targets}**",
        f"- Succeeded: **{report.succeeded}**",
        f"- Failed: **{report.failed}**",
        "",
        "## Results",
        "",
        "| Skill | Risk Level | Score | Findings | Target |",
        "|---|---|---:|---:|---|",
    ]

    for entry in report.entries:
        if entry.status == "error":
            lines.append(f"| error | ERROR | - | - | `{sanitize_markdown(entry.target)}` |")
            continue

        lines.append(
            f"| {sanitize_markdown(entry.skill_name or 'unknown')} | {entry.risk_level} | {entry.risk_score} | "
            f"{entry.findings_count} | `{sanitize_markdown(entry.target)}` |"
        )

    return "\n".join(lines)


def format_diff_text(report: DiffReport) -> str:
    lines = [
        f"Generated At: {report.generated_at}",
        f"Before: {report.before.skill_name} ({report.before.risk_level}, {report.before.risk_score}/100)",
        f"After: {report.after.skill_name} ({report.after.risk_level}, {report.after.risk_score}/100)",
        f"Summary: {report.summary}",
        f"Added Rules: {', '.join(report.added_rules) if report.added_rules else 'none'}",
        f"Removed Rules: {', '.join(report.removed_rules) if report.removed_rules else 'none'}",
        "",
        "Added Findings:",
    ]
    lines.extend(format_diff_findings(report.added_findings))
    lines.extend(["", "Removed Findings:"])
    lines.extend(format_diff_findings(report.removed_findings))
    return "\n".join(lines)


def format_diff_markdown(report: DiffReport) -> str:
    lines = [
        f"# ClawAudit Diff: {report.before.skill_name} -> {report.after.skill_name}",
        "",
        f"- Before: **{report.before.risk_level}** ({report.before.risk_score}/100)",
        f"- After: **{report.after.risk_level}** ({report.after.risk_score}/100)",
        f"- Summary: {report.summary}",
        "",
        "## Added Findings",
        "",
    ]
    if report.added_findings:
        lines.extend(["| Severity | Rule | File | Evidence |", "|---|---|---|---|"])
        for finding in report.added_findings:
            lines.append(
                f"| {finding.severity.upper()} | `{finding.rule_id}` | `{sanitize_markdown(finding.file_path or 'n/a')}` | "
                f"{sanitize_markdown(finding.evidence)} |"
            )
    else:
        lines.append("No added findings.")

    lines.extend(["", "## Removed Findings", ""])
    if report.removed_findings:
        lines.extend(["| Severity | Rule | File | Evidence |", "|---|---|---|---|"])
        for finding in report.removed_findings:
            lines.append(
                f"| {finding.severity.upper()} | `{finding.rule_id}` | `{sanitize_markdown(finding.file_path or 'n/a')}` | "
                f"{sanitize_markdown(finding.evidence)} |"
            )
    else:
        lines.append("No removed findings.")

    return "\n".join(lines)


def format_release_text(report: DiffReport, options: ReleaseNotesOptions | None = None) -> str:
    release_options = options or ReleaseNotesOptions()
    lines = [
        f"ClawAudit Release Notes: {report.after.skill_name}",
        f"Comparison: {compare_display_label(report, release_options)}",
        f"Status: {release_status(report)}",
        f"Previous Risk: {report.before.risk_level} ({report.before.risk_score}/100)",
        f"Current Risk: {report.after.risk_level} ({report.after.risk_score}/100)",
        f"Risk Delta: {signed_delta(report.risk_score_delta)}",
        f"Findings Delta: {signed_delta(report.findings_count_delta)}",
        f"Added Rules: {', '.join(report.added_rules) if report.added_rules else 'none'}",
        f"Resolved Rules: {', '.join(report.removed_rules) if report.removed_rules else 'none'}",
    ]
    metadata_lines = format_release_metadata_text(release_options)
    if metadata_lines:
        lines.extend(metadata_lines)
    lines.extend(["", "Release Guidance:", f"- {release_guidance(report)}"])

    if report.added_findings:
        lines.extend(["", "New Findings:"])
        lines.extend(format_diff_findings(report.added_findings[:5]))

    if report.removed_findings:
        lines.extend(["", "Resolved Findings:"])
        lines.extend(format_diff_findings(report.removed_findings[:5]))

    return "\n".join(lines)


def format_release_markdown(report: DiffReport, options: ReleaseNotesOptions | None = None) -> str:
    release_options = options or ReleaseNotesOptions()
    lines = [
        f"# ClawAudit Release Notes: {report.after.skill_name}",
        "",
        f"- Compare: {format_release_compare_markdown(report, release_options)}",
        f"- Status: **{release_status(report)}**",
        f"- Previous Risk: **{report.before.risk_level}** ({report.before.risk_score}/100)",
        f"- Current Risk: **{report.after.risk_level}** ({report.after.risk_score}/100)",
        f"- Risk Delta: **{signed_delta(report.risk_score_delta)}**",
        f"- Findings Delta: **{signed_delta(report.findings_count_delta)}**",
        "",
    ]
    metadata_lines = format_release_metadata_markdown(release_options)
    if metadata_lines:
        lines.extend(["## Release Metadata", "", *metadata_lines, ""])
    lines.extend(
        [
            "## Rule Changes",
            "",
            f"- New Rule Hits: {format_release_rule_list(report.added_rules)}",
            f"- Resolved Rule Hits: {format_release_rule_list(report.removed_rules)}",
            "",
            "## Release Guidance",
            "",
            f"- {release_guidance(report)}",
            "",
            "## New Findings",
            "",
        ]
    )

    if report.added_findings:
        lines.extend(["| Severity | Rule | File | Evidence |", "|---|---|---|---|"])
        for finding in report.added_findings[:5]:
            lines.append(
                f"| {finding.severity.upper()} | `{finding.rule_id}` | `{sanitize_markdown(finding.file_path or 'n/a')}` | "
                f"{sanitize_markdown(finding.evidence)} |"
            )
    else:
        lines.append("No new findings.")

    lines.extend(["", "## Resolved Findings", ""])
    if report.removed_findings:
        lines.extend(["| Severity | Rule | File | Evidence |", "|---|---|---|---|"])
        for finding in report.removed_findings[:5]:
            lines.append(
                f"| {finding.severity.upper()} | `{finding.rule_id}` | `{sanitize_markdown(finding.file_path or 'n/a')}` | "
                f"{sanitize_markdown(finding.evidence)} |"
            )
    else:
        lines.append("No resolved findings.")

    return "\n".join(lines)


def format_sarif(report: ScanReport) -> str:
    rules = {}
    results = []
    for finding in report.findings:
        rules[finding.rule_id] = {
            "id": finding.rule_id,
            "name": finding.title,
            "shortDescription": {"text": finding.title},
            "fullDescription": {"text": finding.recommendation},
            "properties": {
                "category": finding.category,
                "severity": finding.severity,
            },
        }
        result = {
            "ruleId": finding.rule_id,
            "level": severity_to_sarif_level(finding.severity),
            "message": {"text": finding.evidence},
            "properties": {
                "recommendation": finding.recommendation,
                "score": finding.score,
                "riskLevel": report.risk_level,
            },
        }
        if finding.file_path:
            result["locations"] = [
                {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": finding.file_path,
                        }
                    }
                }
            ]
        results.append(result)

    payload = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "ClawAudit",
                        "version": "0.1.0",
                        "rules": list(rules.values()),
                    }
                },
                "artifacts": [{"location": {"uri": report.target}}],
                "results": results,
            }
        ],
    }
    return json.dumps(payload, indent=2, ensure_ascii=False)


def format_runtime_text(report: RuntimeObservationReport) -> str:
    lines = [
        f"Runtime Report ID: {report.report_id}",
        f"Generated At: {report.generated_at}",
        f"Target: {report.target}",
        f"Source: {report.source_kind}",
        f"Root: {report.root_path}",
        f"Script: {report.script_path}",
        f"Entrypoint: {report.entrypoint}",
        f"Runner: {report.runner}",
        f"Duration: {report.duration_ms if report.duration_ms is not None else 'n/a'} ms",
        f"Status: {report.status}",
        f"Decision: {report.decision}",
        f"Summary: {report.summary}",
    ]
    if report.probe_host:
        lines.append(f"Probe Host: {report.probe_host}")
    if report.probe_pid is not None:
        lines.append(f"Probe PID: {report.probe_pid}")
    if report.timed_out:
        lines.append("Timed Out: yes")
    lines.extend(["", "Runtime Events:"])
    if not report.events:
        lines.append("- None")
    else:
        for event in report.events:
            blocked_suffix = " [BLOCKED]" if event.blocked else ""
            detail_suffix = f" ({event.detail})" if event.detail else ""
            lines.append(f"- {event.kind}: {event.target}{detail_suffix}{blocked_suffix}")

    if report.policy_violations:
        lines.extend(["", "Policy Violations:"])
        lines.extend([f"- {violation}" for violation in report.policy_violations])

    if report.error:
        lines.extend(["", f"Error: {report.error}"])

    return "\n".join(lines)


def format_runtime_json(report: RuntimeObservationReport) -> str:
    import json
    return json.dumps(report.to_dict(), indent=2, ensure_ascii=False)


def format_runtime_markdown(report: RuntimeObservationReport) -> str:
    lines = [
        "# ClawAudit Runtime Report",
        "",
        f"- Runner: `{report.runner}`",
        f"- Duration: **{report.duration_ms if report.duration_ms is not None else 'n/a'} ms**",
        f"- Status: **{report.status}**",
        f"- Decision: **{report.decision}**",
        f"- Target: `{report.target}`",
        f"- Script: `{sanitize_markdown(report.script_path)}`",
        f"- Entrypoint: `{report.entrypoint}`",
        f"- Summary: {report.summary}",
        "",
    ]
    if report.probe_host or report.probe_pid is not None or report.timed_out:
        lines.extend(["## Execution Metadata", ""])
        if report.probe_host:
            lines.append(f"- Probe Host: `{sanitize_markdown(report.probe_host)}`")
        if report.probe_pid is not None:
            lines.append(f"- Probe PID: `{report.probe_pid}`")
        if report.timed_out:
            lines.append("- Timed Out: `yes`")
        lines.append("")
    lines.extend(["## Runtime Events", ""])
    if report.events:
        lines.extend(["| Kind | Target | Detail | Blocked |", "|---|---|---|---|"])
        for event in report.events:
            lines.append(
                f"| `{event.kind}` | `{sanitize_markdown(event.target)}` | {sanitize_markdown(event.detail or '-')} | "
                f"{'yes' if event.blocked else 'no'} |"
            )
    else:
        lines.append("No runtime events.")

    lines.extend(["", "## Policy Violations", ""])
    if report.policy_violations:
        lines.extend([f"- {sanitize_markdown(violation)}" for violation in report.policy_violations])
    else:
        lines.append("No policy violations.")

    if report.error:
        lines.extend(["", "## Error", "", sanitize_markdown(report.error)])

    return "\n".join(lines)


def format_json(report: ScanReport | BatchScanReport | DiffReport | RuntimeObservationReport) -> str:
    return json.dumps(report.to_dict(), indent=2, ensure_ascii=False)


def format_diff_findings(findings: list[Finding]) -> list[str]:
    if not findings:
        return ["- None"]

    lines: list[str] = []
    for finding in findings:
        lines.extend(
            [
                f"- [{finding.severity.upper()}] {finding.title}",
                f"  Rule: {finding.rule_id}",
                f"  File: {finding.file_path or 'n/a'}",
                f"  Evidence: {finding.evidence}",
            ]
        )
    return lines


def sanitize_markdown(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")


def severity_to_sarif_level(severity: str) -> str:
    if severity == "high":
        return "error"
    if severity == "medium":
        return "warning"
    return "note"


def signed_delta(value: int) -> str:
    if value > 0:
        return f"+{value}"
    return str(value)


def short_report_id(report_id: str) -> str:
    return report_id[:8]


def release_status(report: DiffReport) -> str:
    if report.risk_score_delta > 0:
        return "Risk increased"
    if report.risk_score_delta < 0:
        return "Risk reduced"
    if report.changed:
        return "Findings changed"
    return "No security-relevant change"


def release_guidance(report: DiffReport) -> str:
    if report.risk_score_delta > 0 or report.after.risk_level == "High Risk":
        return "Hold release for security review before publishing this skill update."
    if report.risk_score_delta < 0:
        return "Risk dropped compared with the previous version; validate the removed findings before release."
    if report.changed:
        return "Risk level is stable, but findings changed; review the diff before release."
    return "No material security change detected in this comparison."


def format_release_rule_list(rules: list[str]) -> str:
    if not rules:
        return "none"
    return ", ".join(f"`{rule}`" for rule in rules)


def compare_display_label(report: DiffReport, options: ReleaseNotesOptions) -> str:
    before_label = options.base_label or short_report_id(report.before.report_id)
    after_label = options.head_label or short_report_id(report.after.report_id)
    return f"{before_label} -> {after_label}"


def format_release_compare_markdown(report: DiffReport, options: ReleaseNotesOptions) -> str:
    label = sanitize_markdown(compare_display_label(report, options))
    if not options.compare_url:
        return f"`{label}`"
    return f"[`{label}`]({options.compare_url})"


def format_release_metadata_markdown(options: ReleaseNotesOptions) -> list[str]:
    lines: list[str] = []
    if options.release_label:
        lines.append(f"- Release: {format_markdown_link_or_code(options.release_label, options.release_url)}")
    if options.repository:
        lines.append(f"- Repository: `{sanitize_markdown(options.repository)}`")
    if options.compare_url:
        lines.append(f"- Compare URL: [open compare]({options.compare_url})")
    if options.workflow_run_url:
        lines.append(f"- Workflow Run: [view run]({options.workflow_run_url})")
    return lines


def format_release_metadata_text(options: ReleaseNotesOptions) -> list[str]:
    lines: list[str] = []
    if options.release_label:
        if options.release_url:
            lines.append(f"Release: {options.release_label} ({options.release_url})")
        else:
            lines.append(f"Release: {options.release_label}")
    if options.repository:
        lines.append(f"Repository: {options.repository}")
    if options.compare_url:
        lines.append(f"Compare URL: {options.compare_url}")
    if options.workflow_run_url:
        lines.append(f"Workflow Run: {options.workflow_run_url}")
    return lines


def format_markdown_link_or_code(label: str, url: str | None) -> str:
    safe_label = sanitize_markdown(label)
    if not url:
        return f"`{safe_label}`"
    return f"[`{safe_label}`]({url})"
