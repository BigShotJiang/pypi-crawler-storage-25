from __future__ import annotations

from pathlib import Path

from .config import default_runtime_config
from .models import BatchScanEntry, BatchScanReport, RuntimeConfig
from .persistence import persist_report
from .scanner import scan_target


def scan_targets(
    targets: list[str],
    runtime_config: RuntimeConfig | None = None,
    cwd: Path | None = None,
) -> BatchScanReport:
    runtime_config = runtime_config or default_runtime_config()
    cwd = cwd or Path.cwd()
    entries: list[BatchScanEntry] = []

    for target in targets:
        try:
            report = scan_target(target, runtime_config=runtime_config)
            if runtime_config.persistence.enabled:
                report.persisted_paths = persist_report(report, runtime_config.persistence, cwd=cwd)
            entries.append(BatchScanEntry.from_report(report))
        except Exception as exc:
            entries.append(BatchScanEntry(target=target, status="error", error=str(exc)))

    return BatchScanReport.create(entries)
