from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
import importlib.metadata
import json
import subprocess
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "src"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

from clawaudit.cli import get_cli_version, main as cli_main
from clawaudit.config import load_runtime_config
from clawaudit.discovery import discover_skill_targets
from clawaudit.diffing import diff_references
from clawaudit.models import ScanReport
from clawaudit.persistence import persist_report
from clawaudit.planning import ScanPlan, format_scan_plan_markdown, plan_scan_targets
from clawaudit.pr_comments import build_comment_marker, build_pr_comment, build_reviewer_sections
from clawaudit.reporting import resolve_report_reference
from clawaudit.runtime_analysis import observe_target
from clawaudit.scanner import scan_target
from clawaudit.source import parse_target_spec
from clawaudit.status import batch_policy_violations, report_policy_violations


FIXTURES = Path(__file__).parent / "fixtures"


class ScannerTests(unittest.TestCase):
    def test_safe_skill_reports_safe(self) -> None:
        report = scan_target(str(FIXTURES / "safe_skill"))

        self.assertEqual(report.risk_level, "Safe")
        self.assertEqual(report.risk_score, 0)
        self.assertEqual(len(report.findings), 0)
        self.assertEqual(report.metadata.name, "Safe Skill")
        self.assertEqual(report.metadata.declared_permissions, ["filesystem"])

    def test_risky_skill_reports_high_risk(self) -> None:
        report = scan_target(str(FIXTURES / "risky_skill"))

        self.assertEqual(report.risk_level, "High Risk")
        self.assertGreaterEqual(report.risk_score, 70)
        self.assertGreaterEqual(len(report.findings), 4)
        self.assertTrue(all(finding.score > 0 for finding in report.findings))
        rule_ids = {finding.rule_id for finding in report.findings}
        self.assertIn("network-call", rule_ids)
        self.assertIn("shell-exec", rule_ids)
        self.assertIn("env-access", rule_ids)
        self.assertIn("permission-mismatch", rule_ids)

    def test_git_url_source_is_supported(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            repo_dir = Path(tmp_dir) / "repo"
            repo_dir.mkdir()
            (repo_dir / "SKILL.md").write_text("# Temp Skill\n\n## Permissions\n\n- filesystem read\n", encoding="utf-8")
            (repo_dir / "skill.py").write_text("print('ok')\n", encoding="utf-8")

            self.run_git(["init"], cwd=repo_dir)
            self.run_git(["config", "user.name", "ClawAudit Test"], cwd=repo_dir)
            self.run_git(["config", "user.email", "test@example.com"], cwd=repo_dir)
            self.run_git(["add", "."], cwd=repo_dir)
            self.run_git(["commit", "-m", "init"], cwd=repo_dir)

            report = scan_target(f"file://{repo_dir}")

        self.assertEqual(report.source_kind, "git")
        self.assertEqual(report.risk_level, "Safe")
        self.assertEqual(report.metadata.name, "Temp Skill")

    def test_local_target_with_subdir_fragment_is_supported(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            repo_dir = Path(tmp_dir) / "skill-set"
            skill_dir = repo_dir / "skills" / "weather"
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text("# Weather Skill\n\n## Permissions\n\n- network\n", encoding="utf-8")
            (skill_dir / "skill.py").write_text("print('ok')\n", encoding="utf-8")

            report = scan_target(f"{repo_dir}#subdir=skills/weather")

        self.assertEqual(report.source_kind, "local")
        self.assertEqual(report.risk_level, "Safe")
        self.assertEqual(report.metadata.name, "Weather Skill")

    def test_git_url_with_subdir_fragment_is_supported(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            repo_dir = Path(tmp_dir) / "repo"
            skill_dir = repo_dir / "skills" / "temp-skill"
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text("# Temp Skill\n\n## Permissions\n\n- filesystem read\n", encoding="utf-8")
            (skill_dir / "skill.py").write_text("print('ok')\n", encoding="utf-8")

            self.run_git(["init"], cwd=repo_dir)
            self.run_git(["config", "user.name", "ClawAudit Test"], cwd=repo_dir)
            self.run_git(["config", "user.email", "test@example.com"], cwd=repo_dir)
            self.run_git(["add", "."], cwd=repo_dir)
            self.run_git(["commit", "-m", "init"], cwd=repo_dir)

            report = scan_target(f"file://{repo_dir}#subdir=skills/temp-skill")

        self.assertEqual(report.source_kind, "git")
        self.assertEqual(report.risk_level, "Safe")
        self.assertEqual(report.metadata.name, "Temp Skill")

    def test_git_url_with_ref_fragment_is_supported(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            repo_dir = Path(tmp_dir) / "repo"
            repo_dir.mkdir()
            (repo_dir / "SKILL.md").write_text("# Temp Skill\n\n## Permissions\n\n- filesystem read\n", encoding="utf-8")
            (repo_dir / "skill.py").write_text("print('ok')\n", encoding="utf-8")

            self.run_git(["init"], cwd=repo_dir)
            self.run_git(["config", "user.name", "ClawAudit Test"], cwd=repo_dir)
            self.run_git(["config", "user.email", "test@example.com"], cwd=repo_dir)
            self.run_git(["add", "."], cwd=repo_dir)
            self.run_git(["commit", "-m", "init"], cwd=repo_dir)
            self.run_git(["tag", "v1.0.0"], cwd=repo_dir)

            report = scan_target(f"file://{repo_dir}#ref=v1.0.0")

        self.assertEqual(report.source_kind, "git")
        self.assertEqual(report.risk_level, "Safe")
        self.assertEqual(report.metadata.name, "Temp Skill")

    def test_parse_target_spec_supports_github_tree_urls(self) -> None:
        parsed = parse_target_spec("https://github.com/openclaw/openclaw/tree/main/skills/github")

        self.assertEqual(parsed["base_target"], "https://github.com/openclaw/openclaw")
        self.assertEqual(parsed["ref"], "main")
        self.assertEqual(parsed["subpath"], "skills/github")

    def test_parse_target_spec_supports_ref_and_subdir_fragments(self) -> None:
        parsed = parse_target_spec("https://github.com/openclaw/openclaw#ref=v1.0.0&subdir=skills/github")

        self.assertEqual(parsed["base_target"], "https://github.com/openclaw/openclaw")
        self.assertEqual(parsed["ref"], "v1.0.0")
        self.assertEqual(parsed["subpath"], "skills/github")

    def test_discover_skill_targets_finds_all_skill_roots(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            weather = root / "skills" / "weather"
            finance = root / "skills" / "finance"
            weather.mkdir(parents=True)
            finance.mkdir(parents=True)
            (weather / "SKILL.md").write_text("# Weather Skill\n", encoding="utf-8")
            (finance / "SKILL.md").write_text("# Finance Skill\n", encoding="utf-8")

            discovered = discover_skill_targets(root)

        self.assertEqual(discovered, sorted([str(weather.resolve()), str(finance.resolve())]))

    def test_discover_skill_targets_from_changed_files(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            weather = root / "skills" / "weather"
            weather.mkdir(parents=True)
            (weather / "SKILL.md").write_text("# Weather Skill\n", encoding="utf-8")
            (weather / "src").mkdir()
            changed_path = weather / "src" / "tool.py"
            changed_path.write_text("print('ok')\n", encoding="utf-8")

            discovered = discover_skill_targets(root, changed_files=["skills/weather/src/tool.py"])

        self.assertEqual(discovered, [str(weather.resolve())])

    def test_plan_scan_targets_prefers_changed_file_discovery_for_multiple_skills(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            weather = root / "skills" / "weather"
            finance = root / "skills" / "finance"
            weather.mkdir(parents=True)
            finance.mkdir(parents=True)
            (weather / "SKILL.md").write_text("# Weather Skill\n", encoding="utf-8")
            (finance / "SKILL.md").write_text("# Finance Skill\n", encoding="utf-8")

            plan = plan_scan_targets(
                root,
                changed_files=["skills/weather/tool.py", "skills/finance/tool.py"],
                discovered_targets_output=root / "artifacts" / "reports" / "targets.txt",
            )

        self.assertEqual(plan.scan_mode, "batch")
        self.assertEqual(plan.discovery_mode, "changed-files")
        self.assertEqual(plan.discovered_count, 2)
        self.assertTrue(plan.targets_file.endswith("targets.txt"))

    def test_plan_scan_targets_falls_back_to_repo_root_when_nothing_discovered(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            plan = plan_scan_targets(root)

        self.assertEqual(plan.scan_mode, "single")
        self.assertEqual(plan.discovery_mode, "repo-root-fallback")
        self.assertEqual(plan.target, str(root.resolve()))

    def test_config_can_disable_rules(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "clawaudit.toml"
            config_path.write_text(
                """
[rules.shell-exec]
enabled = false

[rules.download-exec]
enabled = false
""".strip(),
                encoding="utf-8",
            )
            config = load_runtime_config(str(config_path), cwd=Path(tmp_dir))
            report = scan_target(str(FIXTURES / "risky_skill"), runtime_config=config)

        rule_ids = {finding.rule_id for finding in report.findings}
        self.assertNotIn("shell-exec", rule_ids)
        self.assertNotIn("download-exec", rule_ids)
        self.assertEqual(report.risk_level, "Warning")

    def test_report_persistence_writes_latest_and_timestamped_copy(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "clawaudit.toml"
            config_path.write_text(
                """
[persistence]
directory = "reports"
enabled = true
""".strip(),
                encoding="utf-8",
            )
            config = load_runtime_config(str(config_path), cwd=Path(tmp_dir))
            report = scan_target(str(FIXTURES / "safe_skill"), runtime_config=config)
            persisted_paths = persist_report(report, config.persistence, cwd=Path(tmp_dir))

            latest_path = Path(persisted_paths[1])
            timestamped_path = Path(persisted_paths[0])
            latest_data = json.loads(latest_path.read_text(encoding="utf-8"))
            timestamped_exists = timestamped_path.exists()

            self.assertEqual(len(persisted_paths), 2)
            self.assertTrue(timestamped_exists)
            self.assertEqual(latest_data["risk_level"], "Safe")
            self.assertEqual(latest_data["metadata"]["name"], "Safe Skill")

    def test_policy_config_reports_forbidden_rule_violation(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "clawaudit.toml"
            config_path.write_text(
                """
[policy]
forbidden_rules = ["env-access"]
""".strip(),
                encoding="utf-8",
            )
            config = load_runtime_config(str(config_path), cwd=Path(tmp_dir))
            report = scan_target(str(FIXTURES / "risky_skill"), runtime_config=config)

        violations = report_policy_violations(report, config.policy)
        self.assertEqual(config.policy.forbidden_rules, ["env-access"])
        self.assertTrue(any("env-access" in violation for violation in violations))

    def test_config_can_parse_runtime_policy(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "clawaudit.toml"
            config_path.write_text(
                """
[runtime_policy]
block_network = true
block_env = true
allowed_hosts = ["example.com"]
allowed_env_vars = ["OPENAI_API_KEY"]

[runtime_execution]
runner = "local-subprocess"
timeout_ms = 250
""".strip(),
                encoding="utf-8",
            )
            config = load_runtime_config(str(config_path), cwd=Path(tmp_dir))

        self.assertTrue(config.runtime_policy.block_network)
        self.assertTrue(config.runtime_policy.block_env)
        self.assertEqual(config.runtime_policy.allowed_hosts, ["example.com"])
        self.assertEqual(config.runtime_policy.allowed_env_vars, ["OPENAI_API_KEY"])
        self.assertEqual(config.runtime_execution.runner, "local-subprocess")
        self.assertEqual(config.runtime_execution.timeout_ms, 250)

    def test_runtime_observe_target_records_file_reads(self) -> None:
        report = observe_target(str(FIXTURES / "runtime_safe_skill"))

        self.assertEqual(report.status, "completed")
        self.assertEqual(report.decision, "allow")
        self.assertEqual(report.runner, "local-subprocess")
        self.assertEqual(report.script_path, "skill.py")
        self.assertIsNotNone(report.duration_ms)
        self.assertTrue(any(event.kind == "file-read" for event in report.events))
        self.assertIn("file-read", report.summary)

    def test_runtime_observe_target_blocks_network_by_policy(self) -> None:
        report = observe_target(
            str(FIXTURES / "runtime_risky_skill"),
            block_network=True,
            allowed_env_vars=["OPENAI_API_KEY"],
        )

        self.assertEqual(report.status, "blocked")
        self.assertEqual(report.decision, "deny")
        self.assertTrue(any(event.kind == "env-read" for event in report.events))
        self.assertTrue(any(event.kind == "network-connect" and event.blocked for event in report.events))
        self.assertTrue(any("blocked network access" in violation for violation in report.policy_violations))

    def test_runtime_observe_target_times_out(self) -> None:
        report = observe_target(
            str(FIXTURES / "runtime_sleepy_skill"),
            timeout_ms=10,
        )

        self.assertEqual(report.status, "timeout")
        self.assertEqual(report.decision, "deny")
        self.assertTrue(report.timed_out)
        self.assertEqual(report.runner, "local-subprocess")
        self.assertTrue(any("timeout" in violation.lower() for violation in report.policy_violations))

    def test_runtime_observe_target_with_isolated_copy_runner_does_not_modify_original_root(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            skill_dir = Path(tmp_dir) / "writer_skill"
            skill_dir.mkdir()
            (skill_dir / "SKILL.md").write_text("# Writer Skill\n\n## Permissions\n\n- filesystem\n", encoding="utf-8")
            (skill_dir / "skill.py").write_text(
                "\n".join(
                    [
                        "from pathlib import Path",
                        "",
                        "",
                        "def run() -> None:",
                        "    Path('artifact.txt').write_text('generated', encoding='utf-8')",
                    ]
                ),
                encoding="utf-8",
            )

            report = observe_target(
                str(skill_dir),
                runner_name="local-isolated-copy",
            )

        self.assertEqual(report.status, "completed")
        self.assertEqual(report.decision, "allow")
        self.assertEqual(report.runner, "local-isolated-copy")
        self.assertEqual(report.root_path, str(skill_dir.resolve()))
        self.assertFalse((skill_dir / "artifact.txt").exists())
        self.assertTrue(any(event.kind == "file-write" for event in report.events))

    def test_batch_policy_violations_include_rule_hits(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "clawaudit.toml"
            config_path.write_text(
                """
[policy]
forbidden_rules = ["shell-exec"]
""".strip(),
                encoding="utf-8",
            )
            config = load_runtime_config(str(config_path), cwd=Path(tmp_dir))

            stdout = StringIO()
            stderr = StringIO()
            with redirect_stdout(stdout), redirect_stderr(stderr):
                exit_code = cli_main(
                    [
                        "scan-batch",
                        str((FIXTURES / "safe_skill").resolve()),
                        str((FIXTURES / "risky_skill").resolve()),
                        "--config",
                        str(config_path),
                        "--enforce-policy",
                        "--format",
                        "json",
                        "--no-persist",
                    ]
                )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(exit_code, 2)
        self.assertIn("rule_ids", payload["entries"][1])
        self.assertIn("shell-exec", payload["entries"][1]["rule_ids"])

    def test_cli_scan_enforce_policy_returns_2(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "clawaudit.toml"
            config_path.write_text(
                """
[policy]
max_risk_level = "Warning"
max_risk_score = 50
forbidden_rules = ["env-access"]
""".strip(),
                encoding="utf-8",
            )
            stdout = StringIO()
            stderr = StringIO()

            with redirect_stdout(stdout), redirect_stderr(stderr):
                exit_code = cli_main(
                    [
                        "scan",
                        str((FIXTURES / "risky_skill").resolve()),
                        "--config",
                        str(config_path),
                        "--enforce-policy",
                        "--format",
                        "json",
                        "--no-persist",
                    ]
                )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 2)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["risk_level"], "High Risk")

    def test_cli_scan_outputs_json(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "scan",
                    str((FIXTURES / "safe_skill").resolve()),
                    "--format",
                    "json",
                    "--no-persist",
                ]
            )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["risk_level"], "Safe")
        self.assertEqual(payload["metadata"]["name"], "Safe Skill")

    def test_cli_discover_targets_outputs_json(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            weather = root / "skills" / "weather"
            weather.mkdir(parents=True)
            (weather / "SKILL.md").write_text("# Weather Skill\n", encoding="utf-8")
            changed_files = root / "changed-files.txt"
            changed_files.write_text("skills/weather/skill.py\n", encoding="utf-8")

            stdout = StringIO()
            stderr = StringIO()
            with redirect_stdout(stdout), redirect_stderr(stderr):
                exit_code = cli_main(
                    [
                        "discover-targets",
                        str(root),
                        "--changed-files-file",
                        str(changed_files),
                        "--format",
                        "json",
                    ]
                )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["mode"], "changed-files")
        self.assertEqual(payload["count"], 1)
        self.assertEqual(payload["targets"], [str(weather.resolve())])

    def test_plan_scan_targets_script_writes_github_outputs(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            weather = root / "skills" / "weather"
            finance = root / "skills" / "finance"
            weather.mkdir(parents=True)
            finance.mkdir(parents=True)
            (weather / "SKILL.md").write_text("# Weather Skill\n", encoding="utf-8")
            (finance / "SKILL.md").write_text("# Finance Skill\n", encoding="utf-8")
            changed_files = root / "changed-files.txt"
            changed_files.write_text("skills/weather/tool.py\nskills/finance/tool.py\n", encoding="utf-8")
            github_output = root / "github-output.txt"
            plan_output = root / "scan-plan.json"

            result = subprocess.run(
                [
                    sys.executable,
                    str((ROOT / "scripts" / "plan_scan_targets.py").resolve()),
                    "--repo-root",
                    str(root),
                    "--changed-files-file",
                    str(changed_files),
                    "--discovered-targets-output",
                    str(root / "artifacts" / "reports" / "targets.txt"),
                    "--github-output-file",
                    str(github_output),
                    "--output",
                    str(plan_output),
                ],
                capture_output=True,
                text=True,
                check=False,
                cwd=ROOT,
            )

            github_lines = github_output.read_text(encoding="utf-8")
            payload = json.loads(plan_output.read_text(encoding="utf-8"))

        self.assertEqual(result.returncode, 0, msg=result.stderr)
        self.assertIn("scan_mode=batch", github_lines)
        self.assertIn("discovery_mode=changed-files", github_lines)
        self.assertEqual(payload["scan_mode"], "batch")
        self.assertEqual(payload["discovered_count"], 2)

    def test_format_scan_plan_markdown_renders_target_and_file_preview(self) -> None:
        plan = ScanPlan(
            scan_mode="batch",
            target="",
            targets_file="/tmp/discovered-targets.txt",
            discovery_mode="changed-files",
            discovered_count=2,
            targets=["/repo/skills/weather", "/repo/skills/finance"],
        )

        rendered = format_scan_plan_markdown(
            plan,
            changed_files=["skills/weather/tool.py", "skills/finance/tool.py"],
        )

        self.assertIn("# ClawAudit Scan Plan", rendered)
        self.assertIn("- Scan Mode: **batch**", rendered)
        self.assertIn("- Discovery Mode: **changed-files**", rendered)
        self.assertIn("- Targets File: `/tmp/discovered-targets.txt`", rendered)
        self.assertIn("- `/repo/skills/weather`", rendered)
        self.assertIn("- `skills/weather/tool.py`", rendered)

    def test_render_scan_plan_script_outputs_markdown(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            root = Path(tmp_dir)
            plan_path = root / "scan-plan.json"
            changed_files_path = root / "changed-files.txt"
            output_path = root / "scan-plan-summary.md"
            plan_path.write_text(
                json.dumps(
                    {
                        "scan_mode": "single",
                        "target": "/repo/skills/weather",
                        "targets_file": "",
                        "discovery_mode": "changed-files",
                        "discovered_count": 1,
                        "targets": ["/repo/skills/weather"],
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            changed_files_path.write_text("skills/weather/tool.py\n", encoding="utf-8")

            result = subprocess.run(
                [
                    sys.executable,
                    str((ROOT / "scripts" / "render_scan_plan.py").resolve()),
                    "--scan-plan-json",
                    str(plan_path),
                    "--changed-files-file",
                    str(changed_files_path),
                    "--output",
                    str(output_path),
                ],
                capture_output=True,
                text=True,
                check=False,
                cwd=ROOT,
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            rendered = output_path.read_text(encoding="utf-8")
            self.assertIn("# ClawAudit Scan Plan", rendered)
            self.assertIn("- Target: `/repo/skills/weather`", rendered)
            self.assertIn("- `skills/weather/tool.py`", rendered)

    def test_cli_scan_batch_supports_targets_file(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "scan-batch",
                    "--targets-file",
                    str((Path(__file__).parent / "batch_targets.txt").resolve()),
                    "--format",
                    "json",
                    "--no-persist",
                ]
            )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["total_targets"], 2)
        self.assertEqual(payload["succeeded"], 2)
        self.assertEqual(payload["failed"], 0)
        self.assertEqual(payload["risk_level_counts"]["Safe"], 1)
        self.assertEqual(payload["risk_level_counts"]["High Risk"], 1)

    def test_cli_scan_batch_reports_partial_failures(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "scan-batch",
                    str((FIXTURES / "safe_skill").resolve()),
                    str((FIXTURES / "missing_skill").resolve()),
                    "--format",
                    "json",
                    "--no-persist",
                ]
            )

        payload = json.loads(stdout.getvalue())
        error_entries = [entry for entry in payload["entries"] if entry["status"] == "error"]

        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["total_targets"], 2)
        self.assertEqual(payload["succeeded"], 1)
        self.assertEqual(payload["failed"], 1)
        self.assertEqual(len(error_entries), 1)
        self.assertIn("Target does not exist", error_entries[0]["error"])

    def test_cli_scan_markdown_output(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "scan",
                    str((FIXTURES / "risky_skill").resolve()),
                    "--format",
                    "markdown",
                    "--no-persist",
                ]
            )

        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("# ClawAudit Report: Risky Skill", output)
        self.assertIn("| Severity | Rule | File | Evidence | Score |", output)

    def test_cli_scan_sarif_output(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "scan",
                    str((FIXTURES / "risky_skill").resolve()),
                    "--format",
                    "sarif",
                    "--no-persist",
                ]
            )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["version"], "2.1.0")
        self.assertGreaterEqual(len(payload["runs"][0]["results"]), 4)

    def test_cli_runtime_scan_outputs_json(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "runtime-scan",
                    str((FIXTURES / "runtime_safe_skill").resolve()),
                    "--format",
                    "json",
                ]
            )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["status"], "completed")
        self.assertEqual(payload["decision"], "allow")
        self.assertTrue(any(event["kind"] == "file-read" for event in payload["events"]))

    def test_cli_runtime_scan_returns_2_when_policy_blocks(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "runtime-scan",
                    str((FIXTURES / "runtime_risky_skill").resolve()),
                    "--format",
                    "json",
                    "--block-network",
                    "--allow-env-var",
                    "OPENAI_API_KEY",
                ]
            )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 2)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["status"], "blocked")
        self.assertEqual(payload["decision"], "deny")

    def test_cli_runtime_scan_returns_2_when_timeout(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "runtime-scan",
                    str((FIXTURES / "runtime_sleepy_skill").resolve()),
                    "--format",
                    "json",
                    "--timeout-ms",
                    "10",
                ]
            )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 2)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["status"], "timeout")
        self.assertTrue(payload["timed_out"])
        self.assertEqual(payload["runner"], "local-subprocess")

    def test_cli_scan_fail_on_threshold_returns_2(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "scan",
                    str((FIXTURES / "risky_skill").resolve()),
                    "--fail-on",
                    "Warning",
                    "--no-persist",
                ]
            )

        self.assertEqual(exit_code, 2)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("High Risk", stdout.getvalue())

    def test_cli_batch_fail_on_error_returns_2(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "scan-batch",
                    str((FIXTURES / "safe_skill").resolve()),
                    str((FIXTURES / "missing_skill").resolve()),
                    "--fail-on-error",
                    "--format",
                    "markdown",
                    "--no-persist",
                ]
            )

        self.assertEqual(exit_code, 2)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("# ClawAudit Batch Scan", stdout.getvalue())

    def test_diff_references_detects_regression(self) -> None:
        report = diff_references(str(FIXTURES / "safe_skill"), str(FIXTURES / "risky_skill"))

        self.assertTrue(report.changed)
        self.assertGreater(report.risk_score_delta, 0)
        self.assertGreaterEqual(len(report.added_findings), 4)
        self.assertEqual(report.before.risk_level, "Safe")
        self.assertEqual(report.after.risk_level, "High Risk")

    def test_cli_diff_markdown_output(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "diff",
                    str((FIXTURES / "safe_skill").resolve()),
                    str((FIXTURES / "risky_skill").resolve()),
                    "--format",
                    "markdown",
                    "--fail-on-regression",
                ]
            )

        output = stdout.getvalue()
        self.assertEqual(exit_code, 2)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("# ClawAudit Diff: Safe Skill -> Risky Skill", output)
        self.assertIn("## Added Findings", output)

    def test_cli_release_notes_markdown_output(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "release-notes",
                    str((FIXTURES / "safe_skill").resolve()),
                    str((FIXTURES / "risky_skill").resolve()),
                    "--format",
                    "markdown",
                    "--release-label",
                    "v2.0.0",
                    "--release-url",
                    "https://github.com/openclaw/clawaudit/releases/tag/v2.0.0",
                    "--repository",
                    "openclaw/clawaudit",
                    "--compare-url",
                    "https://github.com/openclaw/clawaudit/compare/v1.9.0...v2.0.0",
                    "--base-label",
                    "v1.9.0",
                    "--head-label",
                    "v2.0.0",
                    "--workflow-run-url",
                    "https://github.com/openclaw/clawaudit/actions/runs/123",
                ]
            )

        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("# ClawAudit Release Notes: Risky Skill", output)
        self.assertIn("## Release Metadata", output)
        self.assertIn("[`v2.0.0`](https://github.com/openclaw/clawaudit/releases/tag/v2.0.0)", output)
        self.assertIn("[`v1.9.0 -> v2.0.0`](https://github.com/openclaw/clawaudit/compare/v1.9.0...v2.0.0)", output)
        self.assertIn("[view run](https://github.com/openclaw/clawaudit/actions/runs/123)", output)
        self.assertIn("## Rule Changes", output)
        self.assertIn("Hold release for security review", output)

    def test_cli_explain_points_to_rules_directory(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(["explain", "shell-exec"])

        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("更多文档：rules/shell-exec.md", stdout.getvalue())

    def test_get_cli_version_falls_back_to_new_distribution_name(self) -> None:
        get_cli_version.cache_clear()

        def fake_version(name: str) -> str:
            if name == "kuiilabs-clawaudit":
                return "0.1.1"
            raise importlib.metadata.PackageNotFoundError(name)

        with patch("clawaudit.cli.Path.exists", return_value=False):
            with patch("clawaudit.cli.importlib.metadata.version", side_effect=fake_version):
                version = get_cli_version()

        get_cli_version.cache_clear()
        self.assertEqual(version, "0.1.1")

    def test_render_release_notes_script_outputs_metadata(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            output_path = Path(tmp_dir) / "release-notes.md"

            result = subprocess.run(
                [
                    sys.executable,
                    str((ROOT / "scripts" / "render_release_notes.py").resolve()),
                    "--before",
                    str((FIXTURES / "safe_skill").resolve()),
                    "--after",
                    str((FIXTURES / "risky_skill").resolve()),
                    "--release-label",
                    "v2.0.0",
                    "--release-url",
                    "https://github.com/openclaw/clawaudit/releases/tag/v2.0.0",
                    "--repository",
                    "openclaw/clawaudit",
                    "--compare-url",
                    "https://github.com/openclaw/clawaudit/compare/v1.9.0...v2.0.0",
                    "--base-label",
                    "v1.9.0",
                    "--head-label",
                    "v2.0.0",
                    "--workflow-run-url",
                    "https://github.com/openclaw/clawaudit/actions/runs/123",
                    "--output",
                    str(output_path),
                ],
                capture_output=True,
                text=True,
                check=False,
                cwd=ROOT,
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            rendered = output_path.read_text(encoding="utf-8")
            self.assertIn("## Release Metadata", rendered)
            self.assertIn("[`v2.0.0`](https://github.com/openclaw/clawaudit/releases/tag/v2.0.0)", rendered)
            self.assertIn("[open compare](https://github.com/openclaw/clawaudit/compare/v1.9.0...v2.0.0)", rendered)
            self.assertIn("[view run](https://github.com/openclaw/clawaudit/actions/runs/123)", rendered)

    def test_merge_release_notes_script_replaces_existing_marker_section(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            existing_path = Path(tmp_dir) / "existing.md"
            addition_path = Path(tmp_dir) / "addition.md"
            output_path = Path(tmp_dir) / "merged.md"
            existing_path.write_text(
                "\n".join(
                    [
                        "# Existing Release",
                        "",
                        "Intro text.",
                        "",
                        "<!-- clawaudit:release-notes -->",
                        "## ClawAudit Release Notes",
                        "",
                        "old content",
                        "",
                        "## Manual Notes",
                        "",
                        "Keep this section.",
                    ]
                ),
                encoding="utf-8",
            )
            addition_path.write_text("# New Release Notes\n", encoding="utf-8")

            result = subprocess.run(
                [
                    sys.executable,
                    str((ROOT / "scripts" / "merge_release_notes.py").resolve()),
                    "--existing",
                    str(existing_path),
                    "--addition",
                    str(addition_path),
                    "--output",
                    str(output_path),
                ],
                capture_output=True,
                text=True,
                check=False,
                cwd=ROOT,
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            rendered = output_path.read_text(encoding="utf-8")
            self.assertIn("# Existing Release", rendered)
            self.assertIn("## Manual Notes", rendered)
            self.assertIn("Keep this section.", rendered)
            self.assertIn("<!-- clawaudit:release-notes -->", rendered)
            self.assertIn("# New Release Notes", rendered)
            self.assertNotIn("old content", rendered)

    def test_resolve_report_reference_supports_json_file(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            report = scan_target(str(FIXTURES / "safe_skill"))
            report_path = Path(tmp_dir) / "report.json"
            report_path.write_text(json.dumps(report.to_dict(), ensure_ascii=False), encoding="utf-8")

            loaded = resolve_report_reference(str(report_path))

        self.assertIsInstance(loaded, ScanReport)
        self.assertEqual(loaded.metadata.name, "Safe Skill")

    def test_cli_badge_json_output(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "badge",
                    str((FIXTURES / "risky_skill").resolve()),
                    "--format",
                    "json",
                ]
            )

        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertEqual(payload["schemaVersion"], 1)
        self.assertEqual(payload["label"], "ClawAudit")
        self.assertEqual(payload["display"], "both")

    def test_cli_badge_markdown_output(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "badge",
                    str((FIXTURES / "risky_skill").resolve()),
                    "--format",
                    "markdown",
                ]
            )

        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("High%20Risk%20100%2F100", stdout.getvalue())

    def test_cli_badge_svg_supports_variants_and_colors(self) -> None:
        stdout = StringIO()
        stderr = StringIO()

        with redirect_stdout(stdout), redirect_stderr(stderr):
            exit_code = cli_main(
                [
                    "badge",
                    str((FIXTURES / "risky_skill").resolve()),
                    "--format",
                    "svg",
                    "--label",
                    "Risk Gate",
                    "--display",
                    "score",
                    "--style",
                    "flat",
                    "--label-color",
                    "111111",
                    "--message-color",
                    "222222",
                ]
            )

        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("<svg", output)
        self.assertIn("Risk Gate", output)
        self.assertIn("100/100", output)
        self.assertIn("#111111", output)
        self.assertIn("#222222", output)
        self.assertIn('rx="4"', output)

    def test_pr_comment_builder_wraps_markdown_with_marker_and_context(self) -> None:
        body = build_pr_comment(
            "# ClawAudit Batch Scan\n\n- Total Targets: **2**",
            title="ClawAudit PR Summary",
            identifier="summary",
            scan_mode="batch",
            targets_file="clawaudit-targets.txt",
            gate_status="failed",
            policy_mode="enforced",
            repository="openclaw/clawaudit",
            workflow_name="ClawAudit Scan",
            run_url="https://github.com/openclaw/clawaudit/actions/runs/123",
            pr_url="https://github.com/openclaw/clawaudit/pull/45",
            compare_url="https://github.com/openclaw/clawaudit/compare/base...head",
            base_ref="main",
            head_ref="feature/skill-audit",
            head_sha="abcdef1234567890",
            artifact_name="clawaudit-artifacts",
        )

        self.assertIn(build_comment_marker("summary"), body)
        self.assertIn("## ClawAudit PR Summary", body)
        self.assertIn("- Status: `failed`", body)
        self.assertIn("- Mode: `batch`", body)
        self.assertIn("- Policy Gate: `enforced`", body)
        self.assertIn("- Targets File: `clawaudit-targets.txt`", body)
        self.assertIn("- Repository: `openclaw/clawaudit`", body)
        self.assertIn("- Workflow: `ClawAudit Scan`", body)
        self.assertIn("[view PR](https://github.com/openclaw/clawaudit/pull/45)", body)
        self.assertIn("[base...head](https://github.com/openclaw/clawaudit/compare/base...head)", body)
        self.assertIn("[view run](https://github.com/openclaw/clawaudit/actions/runs/123)", body)
        self.assertIn("- Base Ref: `main`", body)
        self.assertIn("- Head Ref: `feature/skill-audit@abcdef12`", body)
        self.assertIn("- Artifacts: `clawaudit-artifacts` attached to the workflow run", body)
        self.assertIn("# ClawAudit Batch Scan", body)

    def test_build_reviewer_sections_summarizes_policy_hits_and_scope(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            config_path = Path(tmp_dir) / "clawaudit.toml"
            config_path.write_text(
                """
[policy]
max_risk_level = "Warning"
forbidden_rules = ["env-access"]
""".strip(),
                encoding="utf-8",
            )
            report = scan_target(str(FIXTURES / "risky_skill"))
            sections = build_reviewer_sections(
                report=report,
                gate_status="failed",
                scan_mode="single",
                policy_violations=report_policy_violations(report, load_runtime_config(str(config_path), cwd=Path(tmp_dir)).policy),
                scan_plan={
                    "discovery_mode": "changed-files",
                    "discovered_count": 1,
                    "targets": [str((FIXTURES / "risky_skill").resolve())],
                },
                changed_files=["skills/risky/skill.py"],
                artifact_name="clawaudit-artifacts",
                artifact_paths=["artifacts/reports/clawaudit-summary.md", "artifacts/reports/clawaudit-report.json"],
                repository="openclaw/clawaudit",
                run_url="https://github.com/openclaw/clawaudit/actions/runs/123",
                pr_url="https://github.com/openclaw/clawaudit/pull/45",
                compare_url="https://github.com/openclaw/clawaudit/compare/base...head",
            )

        self.assertIn("- Review Status: `blocked`", sections["decision"])
        self.assertIn("- Current Risk: `High Risk` (100/100)", sections["decision"])
        self.assertTrue(any("Policy Hits" in line for line in sections["decision"]))
        self.assertIn("- Discovery Mode: `changed-files`", sections["scope"])
        self.assertIn("- Changed Files in Scope: `1`", sections["scope"])
        self.assertTrue(any("Target Preview" in line for line in sections["scope"]))
        self.assertTrue(any("Changed File Preview" in line for line in sections["scope"]))
        self.assertTrue(any("Forbidden rules detected: env-access." in line for line in sections["policy"]))
        self.assertTrue(any("clawaudit-summary.md" in line for line in sections["artifacts"]))

    def test_render_pr_comment_script_outputs_sticky_comment(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            markdown_path = Path(tmp_dir) / "summary.md"
            output_path = Path(tmp_dir) / "comment.md"
            markdown_path.write_text("# ClawAudit Report: Safe Skill\n", encoding="utf-8")

            result = subprocess.run(
                [
                    sys.executable,
                    str((ROOT / "scripts" / "render_pr_comment.py").resolve()),
                    "--input",
                    str(markdown_path),
                    "--output",
                    str(output_path),
                    "--identifier",
                    "summary",
                    "--scan-mode",
                    "single",
                    "--target",
                    "./tests/fixtures/safe_skill",
                    "--gate-status",
                    "passed",
                    "--policy-mode",
                    "enforced",
                    "--repository",
                    "openclaw/clawaudit",
                    "--workflow-name",
                    "ClawAudit Scan",
                    "--run-url",
                    "https://github.com/openclaw/clawaudit/actions/runs/123",
                    "--pr-url",
                    "https://github.com/openclaw/clawaudit/pull/45",
                    "--compare-url",
                    "https://github.com/openclaw/clawaudit/compare/base...head",
                    "--base-ref",
                    "main",
                    "--head-ref",
                    "feature/skill-audit",
                    "--head-sha",
                    "abcdef1234567890",
                    "--artifact-name",
                    "clawaudit-artifacts",
                ],
                capture_output=True,
                text=True,
                check=False,
                cwd=ROOT,
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            rendered = output_path.read_text(encoding="utf-8")
            self.assertIn(build_comment_marker("summary"), rendered)

    def test_render_pr_comment_script_includes_reviewer_sections_from_report_json(self) -> None:
        with TemporaryDirectory() as tmp_dir:
            markdown_path = Path(tmp_dir) / "summary.md"
            output_path = Path(tmp_dir) / "comment.md"
            report_path = Path(tmp_dir) / "report.json"
            plan_path = Path(tmp_dir) / "scan-plan.json"
            changed_files_path = Path(tmp_dir) / "changed-files.txt"
            config_path = Path(tmp_dir) / "clawaudit.toml"

            markdown_path.write_text("# ClawAudit Report: Risky Skill\n", encoding="utf-8")
            report = scan_target(str(FIXTURES / "risky_skill"))
            report_path.write_text(json.dumps(report.to_dict(), ensure_ascii=False), encoding="utf-8")
            plan_path.write_text(
                json.dumps(
                    {
                        "scan_mode": "single",
                        "target": str((FIXTURES / "risky_skill").resolve()),
                        "targets_file": "",
                        "discovery_mode": "changed-files",
                        "discovered_count": 1,
                        "targets": [str((FIXTURES / "risky_skill").resolve())],
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            changed_files_path.write_text("skills/risky/skill.py\n", encoding="utf-8")
            config_path.write_text(
                """
[policy]
max_risk_level = "Warning"
forbidden_rules = ["env-access"]
""".strip(),
                encoding="utf-8",
            )

            result = subprocess.run(
                [
                    sys.executable,
                    str((ROOT / "scripts" / "render_pr_comment.py").resolve()),
                    "--input",
                    str(markdown_path),
                    "--output",
                    str(output_path),
                    "--identifier",
                    "summary",
                    "--scan-mode",
                    "single",
                    "--target",
                    "./tests/fixtures/risky_skill",
                    "--gate-status",
                    "failed",
                    "--policy-mode",
                    "configured",
                    "--repository",
                    "openclaw/clawaudit",
                    "--workflow-name",
                    "ClawAudit Scan",
                    "--run-url",
                    "https://github.com/openclaw/clawaudit/actions/runs/123",
                    "--pr-url",
                    "https://github.com/openclaw/clawaudit/pull/45",
                    "--compare-url",
                    "https://github.com/openclaw/clawaudit/compare/base...head",
                    "--base-ref",
                    "main",
                    "--head-ref",
                    "feature/skill-audit",
                    "--head-sha",
                    "abcdef1234567890",
                    "--artifact-name",
                    "clawaudit-artifacts",
                    "--report-json",
                    str(report_path),
                    "--scan-plan-json",
                    str(plan_path),
                    "--changed-files-file",
                    str(changed_files_path),
                    "--config",
                    str(config_path),
                    "--artifact-path",
                    str(markdown_path),
                    "--artifact-path",
                    str(report_path),
                ],
                capture_output=True,
                text=True,
                check=False,
                cwd=ROOT,
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr)
            rendered = output_path.read_text(encoding="utf-8")
            self.assertIn("### Decision", rendered)
            self.assertIn("- Review Status: `blocked`", rendered)
            self.assertIn("- Current Risk: `High Risk` (100/100)", rendered)
            self.assertIn("### Scope", rendered)
            self.assertIn("- Changed Files in Scope: `1`", rendered)
            self.assertIn("- Target Preview: `risky_skill`", rendered)
            self.assertIn("- Changed File Preview: `skills/risky/skill.py`", rendered)
            self.assertIn("### Policy Hits", rendered)
            self.assertIn("Forbidden rules detected: env-access.", rendered)
            self.assertIn("### Artifacts", rendered)
            self.assertIn("`summary.md`", rendered)
            self.assertIn("`report.json`", rendered)
            self.assertIn("- Status: `failed`", rendered)
            self.assertIn("- Mode: `single`", rendered)
            self.assertIn("- Target: `./tests/fixtures/risky_skill`", rendered)
            self.assertIn("- Policy Gate: `configured`", rendered)
            self.assertIn("[view PR](https://github.com/openclaw/clawaudit/pull/45)", rendered)
            self.assertIn("[view run](https://github.com/openclaw/clawaudit/actions/runs/123)", rendered)
            self.assertIn("- Head Ref: `feature/skill-audit@abcdef12`", rendered)
            self.assertIn("# ClawAudit Report: Risky Skill", rendered)

    def test_cli_serve_command_is_recognized(self) -> None:
        with self.assertRaises(SystemExit) as exc:
            cli_main(["serve", "--help"])
        self.assertEqual(exc.exception.code, 0)

    def run_git(self, args: list[str], cwd: Path) -> None:
        result = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0, msg=result.stderr)


if __name__ == "__main__":
    unittest.main()
