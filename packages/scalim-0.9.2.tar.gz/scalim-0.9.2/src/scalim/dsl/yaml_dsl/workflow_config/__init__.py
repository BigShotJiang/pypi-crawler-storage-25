"""`workflow` 配置解析实现(稳定导入路径).

说明:
- 对外保持稳定导入路径: `scalim.dsl.yaml_dsl.workflow_config`
- 运行时需兼容 `Python 3.6`
- 具体实现按阶段拆分到内部模块中(非公共契约)
"""

from ....workflow.errors import ScalimWorkflowConfigError
from ._load import load_workflow_config, validate_workflow_yaml_text_json
from ._models import (
    WorkflowConfig,
    WorkflowOutputStagingOptions,
    WorkflowResourcesWaitDiagnosticsOptions,
    WorkflowResourcesWaitOptions,
    WorkflowRun,
)
from ._parse import load_workflow_config_from_mapping
from ._paths import resolve_workflow_demand_path

__all__ = (
    "ScalimWorkflowConfigError",
    "WorkflowConfig",
    "WorkflowOutputStagingOptions",
    "WorkflowResourcesWaitDiagnosticsOptions",
    "WorkflowResourcesWaitOptions",
    "WorkflowRun",
    "load_workflow_config",
    "load_workflow_config_from_mapping",
    "resolve_workflow_demand_path",
    "validate_workflow_yaml_text_json",
)
