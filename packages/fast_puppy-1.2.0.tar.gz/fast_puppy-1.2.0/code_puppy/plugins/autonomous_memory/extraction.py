"""Stub extraction engine for the Autonomous Memory Pipeline.

Reads a session's messages file and produces a basic markdown summary.
Future iterations will drive this via a headless LLM agent.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_ROLE_RE = re.compile(r'"role"\s*:\s*"(\w+)"')
_TOOL_RE = re.compile(r'"name"\s*:\s*"([^"]+)"')


@dataclass
class ExtractionResult:
    """Output of extracting knowledge from a single session."""

    session_path: str
    raw_memory: str
    synopsis: str
    extracted_at: str


def _parse_messages_jsonl(path: Path) -> list[dict[str, Any]]:
    """Best-effort parse of a JSONL messages file."""
    messages: list[dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    messages.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except Exception as exc:
        logger.warning(f"Failed to read messages file {path}: {exc}")
    return messages


def _parse_messages_json(path: Path) -> list[dict[str, Any]]:
    """Best-effort parse of a JSON array messages file."""
    try:
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
            if isinstance(data, list):
                return data
    except Exception as exc:
        logger.warning(f"Failed to read messages file {path}: {exc}")
    return []


def _load_messages(path: Path) -> list[dict[str, Any]]:
    """Load messages from either JSONL or JSON array format."""
    if path.suffix == ".jsonl":
        return _parse_messages_jsonl(path)
    return _parse_messages_json(path)


def _count_roles(messages: list[dict[str, Any]]) -> dict[str, int]:
    """Tally message roles."""
    counts: dict[str, int] = {}
    for msg in messages:
        role = msg.get("role", "unknown")
        counts[role] = counts.get(role, 0) + 1
    return counts


def _extract_tools(messages: list[dict[str, Any]]) -> set[str]:
    """Extract unique tool names from tool-call messages."""
    tools: set[str] = set()
    for msg in messages:
        if msg.get("role") != "tool":
            # Also look inside assistant messages for tool_calls
            tool_calls = msg.get("tool_calls", [])
            if isinstance(tool_calls, list):
                for tc in tool_calls:
                    name = (
                        tc.get("function", {}).get("name")
                        if isinstance(tc, dict)
                        else None
                    )
                    if name:
                        tools.add(name)
                    elif isinstance(tc, dict):
                        name = tc.get("name")
                        if name:
                            tools.add(name)
            continue
        content = msg.get("content", "")
        if isinstance(content, str):
            match = _TOOL_RE.search(content)
            if match:
                tools.add(match.group(1))
        name = msg.get("name") or msg.get("tool_name")
        if isinstance(name, str):
            tools.add(name)
    return tools


def _extract_topics(messages: list[dict[str, Any]]) -> list[str]:
    """Extract user message content snippets as 'topics'."""
    topics: list[str] = []
    for msg in messages:
        if msg.get("role") != "user":
            continue
        content = msg.get("content", "")
        if isinstance(content, str) and content.strip():
            # Truncate long messages to first 120 chars for brevity
            snippet = content.strip().replace("\n", " ")
            if len(snippet) > 120:
                snippet = snippet[:117] + "..."
            topics.append(snippet)
    # Deduplicate while preserving order
    seen: set[str] = set()
    deduped: list[str] = []
    for t in topics:
        if t not in seen:
            seen.add(t)
            deduped.append(t)
    return deduped[:20]  # Cap at 20 topics


def extract_session_knowledge(session_path: Path) -> ExtractionResult | None:
    """Extract a basic memory summary from a session directory.

    This is a stub implementation. Future work will replace it with a
    headless LLM agent that performs deeper semantic extraction.
    """
    try:
        messages_file = None
        for candidate in (
            session_path / "messages.json",
            *session_path.glob("*.jsonl"),
        ):
            if candidate.exists():
                messages_file = candidate
                break

        if messages_file is None:
            logger.warning(f"No messages file found in {session_path}")
            return None

        messages = _load_messages(messages_file)
        if not messages:
            logger.warning(f"Empty or unreadable messages file in {session_path}")
            return None

        counts = _count_roles(messages)
        tools = _extract_tools(messages)
        topics = _extract_topics(messages)

        user_count = counts.get("user", 0)
        assistant_count = counts.get("assistant", 0)
        tool_count = counts.get("tool", 0)

        lines = [
            "## Session Summary",
            f"- Messages: {user_count} user, {assistant_count} assistant, {tool_count} tool",
        ]
        if tools:
            lines.append(f"- Tools: {', '.join(sorted(tools))}")
        if topics:
            lines.append(f"- Topics: {'; '.join(topics)}")

        raw_memory = "\n".join(lines)
        synopsis = f"Session with {user_count} user messages, {len(tools)} tools, {len(topics)} topics"
        extracted_at = datetime.now(timezone.utc).isoformat()

        return ExtractionResult(
            session_path=str(session_path),
            raw_memory=raw_memory,
            synopsis=synopsis,
            extracted_at=extracted_at,
        )
    except Exception as exc:
        logger.warning(f"Extraction failed for {session_path}: {exc}")
        return None
