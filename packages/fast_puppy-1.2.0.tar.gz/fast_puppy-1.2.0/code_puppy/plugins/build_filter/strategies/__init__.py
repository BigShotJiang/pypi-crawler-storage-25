"""Compression strategies for the build filter."""

from __future__ import annotations
