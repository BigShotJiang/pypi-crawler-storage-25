"""Build Filter plugin — compresses build command output."""

from __future__ import annotations
