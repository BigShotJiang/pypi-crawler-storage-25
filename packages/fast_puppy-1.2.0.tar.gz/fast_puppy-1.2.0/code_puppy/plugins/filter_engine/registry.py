"""Strategy registry for the filter engine.

Maps command categories to compression strategy functions.  Handles
registration, duplicate detection, and priority-based overrides.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

logger = logging.getLogger(__name__)


class StrategyRegistry:
    """Registry mapping category names to compression strategy functions."""

    def __init__(self) -> None:
        """Initialize the registry with the built-in ``unknown`` passthrough."""
        self._strategies: dict[str, tuple[Callable, int]] = {}
        self._register_passthrough()

    def _register_passthrough(self) -> None:
        """Register the built-in passthrough strategy for ``unknown``."""

        def _passthrough(
            command: str,
            stdout: str,
            stderr: str,
            exit_code: int,
            verbosity: Any,  # noqa: ANN401
        ) -> Any:  # noqa: ANN401
            """Return None to signal that normal execution should proceed."""
            return None

        self._strategies["unknown"] = (_passthrough, -1)

    def register(
        self,
        category: str,
        strategy_fn: Callable,
        priority: int = 0,
    ) -> None:
        """Register a strategy function for a category.

        If a strategy is already registered for the category, the new one
        wins only when *priority* is greater than the existing priority.
        A warning is logged on collision regardless.

        Args:
            category: The command category (e.g. ``"git"``).
            strategy_fn: Callable that accepts
                ``(command, stdout, stderr, exit_code, verbosity)`` and returns
                a ``ShellCommandOutput`` or ``None``.
            priority: Higher values win on collision.  Defaults to ``0``.
        """
        existing = self._strategies.get(category)
        if existing is not None:
            _, existing_priority = existing
            if priority > existing_priority:
                logger.warning(
                    "StrategyRegistry: overriding '%s' strategy (priority %d > %d)",
                    category,
                    priority,
                    existing_priority,
                )
                self._strategies[category] = (strategy_fn, priority)
            else:
                logger.warning(
                    "StrategyRegistry: ignoring '%s' strategy registration "
                    "(priority %d <= %d)",
                    category,
                    priority,
                    existing_priority,
                )
        else:
            self._strategies[category] = (strategy_fn, priority)

    def get_strategy(self, category: str) -> Callable | None:
        """Return the strategy function for *category*, or ``None``.

        The built-in ``unknown`` passthrough always returns a callable that
        itself returns ``None``.
        """
        entry = self._strategies.get(category)
        if entry is None:
            return None
        return entry[0]

    def list_categories(self) -> list[str]:
        """Return a sorted list of all registered category names."""
        return sorted(self._strategies.keys())


# Module-level singleton instance
_registry_instance: StrategyRegistry | None = None


def get_registry() -> StrategyRegistry:
    """Return the module-level singleton registry."""
    global _registry_instance
    if _registry_instance is None:
        _registry_instance = StrategyRegistry()
    return _registry_instance
