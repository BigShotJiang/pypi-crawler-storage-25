"""Code / read compression strategies for the filter engine.

Handles comment stripping, tree compression, and smart truncation for
file-reading commands.
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import ClassVar

from code_puppy.plugins.filter_engine.registry import get_registry
from code_puppy.plugins.filter_engine.verbosity import VerbosityLevel
from code_puppy.tools.command_runner import ShellCommandOutput


# ---------------------------------------------------------------------------
# Comment stripping helpers
# ---------------------------------------------------------------------------


class MinimalFilter:
    """Strip only comments, preserving docstrings that look like API docs."""

    # Language → (single_line_pattern, multi_line_pattern)
    # multi_line_pattern should capture the content between delimiters.
    PATTERNS: ClassVar[dict[str, tuple[str | None, str | None]]] = {
        "python": (
            r"#.*$",
            r'("""[\s\S]*?""")|(\'\'\'[\s\S]*?\'\'\')',
        ),
        "javascript": (
            r"//.*$",
            r"/\*[\s\S]*?\*/",
        ),
        "typescript": (
            r"//.*$",
            r"/\*[\s\S]*?\*/",
        ),
        "rust": (
            r"//.*$",
            r"/\*[\s\S]*?\*/",
        ),
        "go": (
            r"//.*$",
            r"/\*[\s\S]*?\*/",
        ),
        "java": (
            r"//.*$",
            r"/\*[\s\S]*?\*/",
        ),
        "cpp": (
            r"//.*$",
            r"/\*[\s\S]*?\*/",
        ),
        "ruby": (
            r"#.*$",
            r"=begin[\s\S]*?=end",
        ),
        "bash": (
            r"#.*$",
            None,
        ),
        "sql": (
            r"--.*$",
            r"/\*[\s\S]*?\*/",
        ),
    }

    @classmethod
    def strip_comments(cls, text: str, language: str = "python") -> str:
        """Remove single-line comments from *text* for *language*.

        Multi-line comments / docstrings are kept when they look like API
        documentation (contain words such as ``Args``, ``Returns``,
        ``Example``, ``Note``).

        Args:
            text: Source code text.
            language: Language key (see :attr:`PATTERNS`).

        Returns:
            Text with comments stripped.
        """
        single, multi = cls.PATTERNS.get(language, (None, None))
        result = text

        if single:
            result = re.sub(single, "", result, flags=re.MULTILINE)

        if multi:
            # Replace multi-line comments, but keep those that look like docs
            def _maybe_keep(match: re.Match[str]) -> str:
                block = match.group(0)
                doc_markers = (
                    "Args:",
                    "Returns:",
                    "Raises:",
                    "Example:",
                    "Note:",
                    "Notes:",
                )
                if any(marker in block for marker in doc_markers):
                    return block
                return ""

            result = re.sub(multi, _maybe_keep, result)

        return result


class AggressiveFilter:
    """Strip comments, docstrings, blank lines, and boilerplate."""

    PATTERNS: ClassVar[dict[str, tuple[str | None, str | None]]] = (
        MinimalFilter.PATTERNS
    )

    @classmethod
    def strip_comments(cls, text: str, language: str = "python") -> str:
        """Aggressively strip all comments and collapse blank lines.

        Args:
            text: Source code text.
            language: Language key.

        Returns:
            Compact text.
        """
        single, multi = cls.PATTERNS.get(language, (None, None))
        result = text

        if single:
            result = re.sub(single, "", result, flags=re.MULTILINE)

        if multi:
            result = re.sub(multi, "", result)

        # Collapse multiple blank lines into one
        result = re.sub(r"\n\s*\n+", "\n\n", result)

        return result.strip()


# ---------------------------------------------------------------------------
# Smart truncation
# ---------------------------------------------------------------------------


def _is_important_line(line: str) -> bool:
    """Heuristic: is this line important enough to preserve during truncation?"""
    stripped = line.strip()
    if not stripped:
        return False

    # Import lines
    if stripped.startswith("import ") or stripped.startswith("from "):
        return True

    # Function / class / method signatures
    if re.match(
        r"^(def |class |async def |fn |pub fn |func |function |method )", stripped
    ):
        return True

    # Decorators
    if stripped.startswith("@"):
        return True

    # Type signatures / interfaces
    if re.match(r"^(interface |type |struct |enum |trait |impl )", stripped):
        return True

    # Module / package declarations
    if re.match(r"^(module |package |namespace )", stripped):
        return True

    return False


def _is_boilerplate(line: str) -> bool:
    """Heuristic: is this line boilerplate that can be dropped?"""
    stripped = line.strip()
    boilerplate_patterns = [
        r"^#\s*TODO",
        r"^#\s*FIXME",
        r"^#\s*HACK",
        r"^#\s*NOTE",
        r"^\s*\{\s*\}\s*$",  # empty blocks
        r"^\s*pass\s*$",  # Python pass
    ]
    for pattern in boilerplate_patterns:
        if re.search(pattern, stripped):
            return True
    return False


def smart_truncate(
    text: str,
    max_lines: int = 60,
    preserve_imports: bool = True,
    preserve_signatures: bool = True,
) -> str:
    """Truncate *text* to at most *max_lines* while preserving important lines.

    Important lines (imports, signatures, decorators) are always kept.
    Blank runs and boilerplate are collapsed or dropped.

    Args:
        text: The text to truncate.
        max_lines: Maximum number of lines to return.
        preserve_imports: Keep import lines even if they'd be dropped.
        preserve_signatures: Keep function/class signatures.

    Returns:
        Truncated text.
    """
    if not text:
        return ""

    lines = text.splitlines()
    if len(lines) <= max_lines:
        return text

    important: list[str] = []
    body: list[str] = []

    for line in lines:
        if _is_boilerplate(line):
            continue
        if (preserve_imports and line.strip().startswith(("import ", "from "))) or (
            preserve_signatures and _is_important_line(line)
        ):
            important.append(line)
        else:
            body.append(line)

    # Keep all important lines, then fill with body up to max_lines
    result = important[:max_lines]
    remaining = max_lines - len(result)
    if remaining > 0:
        result.extend(body[:remaining])

    if len(body) > remaining and remaining > 0:
        result.append(f"... ({len(body) - remaining} more lines)")

    return "\n".join(result)


# ---------------------------------------------------------------------------
# Tree / ls compression
# ---------------------------------------------------------------------------


def compress_tree(
    stdout: str,
    stderr: str,
    verbosity: VerbosityLevel,
) -> ShellCommandOutput:
    """Convert flat ``ls -R`` or ``tree`` output into a hierarchical summary.

    Args:
        stdout: Raw stdout.
        stderr: Raw stderr.
        verbosity: Current verbosity level.

    Returns:
        Compressed :class:`ShellCommandOutput`.
    """
    lines = stdout.splitlines()
    current_dir = "."
    dir_files: dict[str, list[str]] = defaultdict(list)
    dir_dirs: dict[str, list[str]] = defaultdict(list)

    for line in lines:
        stripped = line.rstrip("\r")
        if stripped.endswith(":"):
            current_dir = stripped.rstrip(":")
            continue
        if not stripped or stripped.startswith("total "):
            continue

        # Heuristic: directories in ls -R are often marked with / or listed before files
        if stripped.endswith("/"):
            dir_dirs[current_dir].append(stripped)
        else:
            dir_files[current_dir].append(stripped)

    if not dir_files and not dir_dirs:
        return ShellCommandOutput(
            success=True,
            command="ls/tree",
            stdout=stdout.strip() or "Empty directory",
            stderr=stderr if verbosity >= VerbosityLevel.VERY_VERBOSE else None,
            exit_code=0,
            execution_time=None,
        )

    parts: list[str] = []
    for directory in sorted(set(list(dir_files.keys()) + list(dir_dirs.keys()))):
        files = dir_files.get(directory, [])
        dirs = dir_dirs.get(directory, [])
        parts.append(f"{directory}: {len(files)} files, {len(dirs)} dirs")
        if verbosity >= VerbosityLevel.VERBOSE:
            for d in dirs[:5]:
                parts.append(f"  /{d}")
            for f in files[:10]:
                parts.append(f"  {f}")
            if len(files) > 10:
                parts.append(f"  ... {len(files) - 10} more files")
            if len(dirs) > 5:
                parts.append(f"  ... {len(dirs) - 5} more dirs")

    return ShellCommandOutput(
        success=True,
        command="ls/tree",
        stdout="\n".join(parts),
        stderr=stderr if verbosity >= VerbosityLevel.VERY_VERBOSE else None,
        exit_code=0,
        execution_time=None,
    )


# ---------------------------------------------------------------------------
# Read command compression
# ---------------------------------------------------------------------------


def compress_read(
    command: str,
    stdout: str,
    stderr: str,
    exit_code: int,
    verbosity: VerbosityLevel,
) -> ShellCommandOutput:
    """Compress output from read commands (``cat``, ``head``, ``tail``, etc.).

    Applies smart truncation and optional comment stripping.

    Args:
        command: The original read command.
        stdout: Raw stdout.
        stderr: Raw stderr.
        exit_code: Process exit code.
        verbosity: Current verbosity level.

    Returns:
        Compressed :class:`ShellCommandOutput`.
    """
    if verbosity >= VerbosityLevel.VERY_VERBOSE:
        return ShellCommandOutput(
            success=exit_code == 0,
            command=command,
            stdout=stdout,
            stderr=stderr,
            exit_code=exit_code,
            execution_time=None,
        )

    # Detect language from file extension in command
    language = "python"
    ext_match = re.search(r"\.(py|js|ts|tsx|rs|go|java|cpp|c|h|rb|sh|sql)\b", command)
    if ext_match:
        ext_map = {
            "py": "python",
            "js": "javascript",
            "ts": "typescript",
            "tsx": "typescript",
            "rs": "rust",
            "go": "go",
            "java": "java",
            "cpp": "cpp",
            "c": "cpp",
            "h": "cpp",
            "rb": "ruby",
            "sh": "bash",
            "sql": "sql",
        }
        language = ext_map.get(ext_match.group(1), "python")

    text = stdout

    # Strip comments at compact / ultra-compact levels
    if verbosity <= VerbosityLevel.COMPACT:
        text = MinimalFilter.strip_comments(text, language)

    # Truncate
    max_lines = 60
    if verbosity == VerbosityLevel.ULTRA_COMPACT:
        max_lines = 20
    elif verbosity == VerbosityLevel.COMPACT:
        max_lines = 60
    elif verbosity == VerbosityLevel.VERBOSE:
        max_lines = 120

    truncated = smart_truncate(text, max_lines=max_lines)

    return ShellCommandOutput(
        success=exit_code == 0,
        command=command,
        stdout=truncated,
        stderr=stderr if verbosity >= VerbosityLevel.VERY_VERBOSE else None,
        exit_code=exit_code,
        execution_time=None,
    )


# ---------------------------------------------------------------------------
# Code command compression (alias for read + ls/tree)
# ---------------------------------------------------------------------------


def compress_ls(
    command: str,
    stdout: str,
    stderr: str,
    exit_code: int,
    verbosity: VerbosityLevel,
) -> ShellCommandOutput:
    """Compress ``ls`` / ``tree`` output.

    Args:
        command: The original ls command.
        stdout: Raw stdout.
        stderr: Raw stderr.
        exit_code: Process exit code.
        verbosity: Current verbosity level.

    Returns:
        Compressed :class:`ShellCommandOutput`.
    """
    return compress_tree(stdout, stderr, verbosity)


def compress_code(
    command: str,
    stdout: str,
    stderr: str,
    exit_code: int,
    verbosity: VerbosityLevel,
) -> ShellCommandOutput | None:
    """Main dispatcher for code / read compression strategies.

    Args:
        command: The original command.
        stdout: Raw stdout.
        stderr: Raw stderr.
        exit_code: Process exit code.
        verbosity: Current verbosity level.

    Returns:
        A compressed :class:`ShellCommandOutput` or ``None``.
    """
    stripped = command.strip()

    # Read commands
    if re.search(r"\b(cat|head|tail|less|bat|nl)\b", stripped):
        return compress_read(command, stdout, stderr, exit_code, verbosity)

    # Directory listing
    if re.search(r"\b(ls|tree)\b", stripped):
        return compress_ls(command, stdout, stderr, exit_code, verbosity)

    # Generic code commands: apply smart truncate + minimal comment strip
    text = stdout
    if verbosity <= VerbosityLevel.COMPACT:
        text = MinimalFilter.strip_comments(text, "python")

    max_lines = 60
    if verbosity == VerbosityLevel.ULTRA_COMPACT:
        max_lines = 20
    elif verbosity == VerbosityLevel.VERBOSE:
        max_lines = 120

    truncated = smart_truncate(text, max_lines=max_lines)

    return ShellCommandOutput(
        success=exit_code == 0,
        command=command,
        stdout=truncated,
        stderr=stderr if verbosity >= VerbosityLevel.VERY_VERBOSE else None,
        exit_code=exit_code,
        execution_time=None,
    )


# ---------------------------------------------------------------------------
# Register with the strategy registry
# ---------------------------------------------------------------------------
get_registry().register("code", compress_code, priority=0)
get_registry().register("read", compress_code, priority=0)
