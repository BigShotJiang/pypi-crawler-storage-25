"""Compression strategies for the filter engine."""

from __future__ import annotations
