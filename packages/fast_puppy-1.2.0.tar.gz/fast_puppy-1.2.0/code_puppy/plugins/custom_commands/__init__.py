"""Custom commands plugin — TOML-defined shortcuts with {{args}} injection."""

from __future__ import annotations

from code_puppy.plugins.custom_commands.command_discovery import (
    CommandDef as CommandDef,
    discover_commands as discover_commands,
)
from code_puppy.plugins.custom_commands.command_toml_schema import (
    parse_command_toml as parse_command_toml,
)
from code_puppy.plugins.custom_commands.register_callbacks import (
    CustomCommandResult as CustomCommandResult,
)
