"""Token tracking plugin for Code Puppy.

Records every command execution with token counts and provides slash-command
reports for gain, economics, session adoption, and edit efficiency.
"""

from __future__ import annotations

from code_puppy.plugins.token_tracking.database import TrackingDatabase
from code_puppy.plugins.token_tracking.edit_analyzer import analyze_replacement
from code_puppy.plugins.token_tracking.reports import (
    cc_economics_report,
    edit_efficiency_report,
    gain_report,
    session_report,
)
from code_puppy.plugins.token_tracking.record import (
    SESSION_ID,
    record_command,
)

__all__ = [
    "SESSION_ID",
    "TrackingDatabase",
    "analyze_replacement",
    "cc_economics_report",
    "edit_efficiency_report",
    "gain_report",
    "record_command",
    "session_report",
]
