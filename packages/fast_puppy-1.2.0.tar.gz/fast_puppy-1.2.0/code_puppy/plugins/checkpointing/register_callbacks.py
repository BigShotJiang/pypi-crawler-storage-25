"""Register checkpointing callbacks and commands."""

from __future__ import annotations

import logging

from code_puppy.callbacks import register_callback
from code_puppy.plugins.checkpointing.checkpoint_hook import (
    on_pre_tool_call_checkpoint,
)
from code_puppy.plugins.checkpointing.restore_command import (
    _custom_help,
    _handle_custom_command,
)
from code_puppy.plugins.checkpointing.rewind_shortcut import RewindKeyListener

logger = logging.getLogger(__name__)

_rewind_listener: RewindKeyListener | None = None


def _start_rewind_listener() -> None:
    global _rewind_listener
    if _rewind_listener is not None:
        return

    def _on_double_esc() -> None:
        from code_puppy.plugins.checkpointing.restore_command import (
            _handle_restore_command,
        )

        _handle_restore_command("/restore")

    _rewind_listener = RewindKeyListener(_on_double_esc)
    _rewind_listener.start()


def _stop_rewind_listener() -> None:
    global _rewind_listener
    if _rewind_listener is not None:
        _rewind_listener.stop()
        _rewind_listener = None


def _on_startup() -> None:
    # Disabled: RewindKeyListener opens stdin in cbreak mode and consumes
    # keystrokes via select+read(1), which steals input from prompt_toolkit
    # when the user types slash commands like /g. The /restore slash command
    # is sufficient for now. A proper prompt_toolkit key-binding can be
    # added later without the stdin conflict.
    # try:
    #     _start_rewind_listener()
    # except Exception as exc:
    #     logger.warning(f"Could not start rewind listener: {exc}")
    pass


def _on_shutdown() -> None:
    _stop_rewind_listener()


# Register callbacks
register_callback("pre_tool_call", on_pre_tool_call_checkpoint)
register_callback("custom_command_help", _custom_help)
register_callback("custom_command", _handle_custom_command)
register_callback("startup", _on_startup)
register_callback("shutdown", _on_shutdown)
