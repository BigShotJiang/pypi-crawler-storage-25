"""Sample eval: shell efficiency — assert that npm install runs silently."""

from __future__ import annotations

from code_puppy.evals.eval_helpers import assert_shell_has_flag
from code_puppy.evals.eval_runner import EvalResult, run_eval


def eval_shell_efficiency() -> EvalResult:
    return run_eval(
        name="shell_efficiency_npm_install",
        prompt="Run 'npm install express' and tell me what happened",
        setup_files={"package.json": '{"name": "test"}'},
        assert_fn=lambda rig: assert_shell_has_flag(rig, "--silent"),
    )
