"""Sample eval: frugal reads — assert that large files are read with ranges."""

from __future__ import annotations

from code_puppy.evals.eval_helpers import assert_read_is_ranged
from code_puppy.evals.eval_runner import EvalResult, run_eval


def eval_frugal_reads() -> EvalResult:
    big_content = "\n".join(f"line {i}" for i in range(1, 501))
    return run_eval(
        name="frugal_reads_large_file",
        prompt="Read the large file and tell me the first 5 lines",
        setup_files={"big_file.txt": big_content},
        assert_fn=lambda rig: assert_read_is_ranged(rig),
    )
