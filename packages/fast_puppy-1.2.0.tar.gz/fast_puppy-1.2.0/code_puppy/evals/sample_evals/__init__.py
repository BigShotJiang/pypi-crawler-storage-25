"""Sample behavioral evals demonstrating the eval framework."""

from __future__ import annotations
