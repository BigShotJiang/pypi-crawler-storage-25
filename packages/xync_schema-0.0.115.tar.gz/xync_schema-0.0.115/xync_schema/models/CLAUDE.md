# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

All Tortoise ORM models (~60) are defined in `__init__.py`. Models are organized into domain groups listed below.

## Base Classes

- **`Model`** (from `x_auth.models`) — primary base with `_name`, `_icon`, `PydanticMeta` support
- **`BaseModel`** (tortoise) — used for through-tables (`CurEx`, `CoinEx`, `PmEx`, `PmExBank`) that don't need full model features
- **`TgUser`** (from `x_auth.models`) — Telegram user base, extended by `User`
- **`TsTrait`** (from `x_model.models`) — mixin adding auto `created_at`/`updated_at`

Re-exported models from `x_auth`: `Username`, `Proxy`, `Dc`, `Fcm`, `App`, `Session`, `Peer`, `UpdateState`, `Version`, `Country` (as `BaseCountry`).

## Field Conventions

- **UInt fields**: `UInt1Field` (1 byte), `UInt2Field` (2), `UInt4Field` (4), `UInt8Field` (8) — custom unsigned integers from `x_model.field`
- **Monetary integers**: amounts stored as `int / 10^scale` where `scale` comes from the related `Cur` or `Coin`
- **Percentages**: stored as `/10_000` (basis points) — fields: `premium`, `fee`, `apr`
- **Binary**: `BinaryField` for keys/proofs, `UniqBinaryField` for unique binary (e.g., `File.ref`)
- **Timestamps**: `DatetimeSecField` for second-precision datetimes (`shared_at`, `payed_at`, etc.)
- **FK convention**: all `ForeignKeyField` / `OneToOneField` use `on_update=CASCADE`
- **Composite uniqueness**: via `Meta.unique_together`, commonly `(ex_id, exid)` for exchange-mapped entities

## Model Attributes

- **`_name`**: set of field paths for string representation (supports `__` traversal, e.g. `"pair_side__pairex__coin__ticker"`)
- **`_icon`**: UI icon identifier (e.g. `"ad"`, `"seeding"`, `"file"`)
- **`repr()`**: human-readable formatting on select models (`Cred`, `Dep`, `Investment`, `ExStat`, `Vpn`, `Invite`, `Credit`)

## Domain Groups

### Currency & Exchange
`Cur` -> `CurEx` <- `Ex`, `Coin` -> `CoinEx` <- `Ex`, `Net`, `Pair` -> `PairSide` -> `PairEx`

- `Cur.id` = `UInt1Field` (max 255 fiat currencies)
- `Coin.id` = `SmallIntField`
- `Ex.id` = `UInt1Field` (max 255 exchanges)
- Through-tables (`CurEx`, `CoinEx`) carry `exid` (exchange's internal ID string) and exchange-specific `scale`/`minimum`

### Users & Auth
`Person` -> `User` (extends `TgUser`), `Actor` -> `Agent`

- `Person` groups actors/credentials under a human identity; `status` via `PersonStatus`
- `User` holds Ed25519 keypair (`prv`/`pub` as raw bytes) for signing `Transaction`s
- `Actor` = exchange account `(ex_id, exid)` unique; links to `Person`
- `Agent` = authenticated session (one-to-one with `Actor`); holds `auth` JSON blob + expiry
- `Addr` = crypto deposit address `(coin_id, actor_id)` unique; linked to `Net`s via `NetAddr`
- `Asset` = balance snapshot `(addr_id, agent_id, typ)` unique; amounts `free`/`freeze`/`lock`/`target`

actor.set_user(username_id):
При создании юзера(User) в sql-триггере автоматически создается персона(Person) с его user_id.
А при создании актора(Actor) создается персона без user_id, но в actor.person_id = id этой персоны.
И когда юзер заходит в объявление одного из агентов(Agent) первый раз, создается его актор для биржи (на которой 
размещено это объявление) и новая персона этого актора.
Если к персоне юзера еще не "привязано" ни одного актора, 2 персоны для юзера с одним актором избыточны, их нужно 
смерджить: т.е старой персоне юзера назначить имя, креды(creds) и актора этой новой персоны, а новую "осиротевшую" 
персону удалить.
Далее, если этот же юзер будет заходить с других акторов:
- других бирж, но с тем же именем: это та же персона нужно так же смерджить новую персону нового актора с существующей.
- с другим именем: значит это уже другая персона, и существующая персона(ы) уже "занята" существующим(и) актором(ами), 
тогда уже не надо мержить новую персону нового актора, оставляем новую.

### Payment Methods
`PmGroup` -> `Pm` -> `PmCur` <- `Cur`, `PmEx` <- `Ex`, `PmExBank`

- `Pm.norm` — normalized name (used in dynamic client path: `xync_client.Pms.{norm}.agent`)
- `Cred` = user's payment credential `(person_id, pmcur_id, ovr_pm_id)` unique
- `CredEx` = credential registered on exchange `(ex_id, exid)` unique
- `Fiat` = balance tracker (one-to-one with `Cred`): `amount`, `target`, `min_deposit`
- `PmAgent` = automation account for a PM `(pm_id, user_id)` unique

### P2P Trading
`Ad` -> `MyAd` -> `Race` -> `RaceStat`, `Order` -> `Msg`/`Transfer`/`Task`, `Hot`

- `Ad` = exchange advertisement `(exid, maker_id)` unique; carries `price`, `premium`, `amount`, `min_fiat`/`max_fiat`, `status` (`AdStatus`), optional `Cond`
- `MyAd` = our managed ad (one-to-one with `Ad`); adds race tracking, share URLs, linked `CredEx`s
- `Order` = P2P trade `(exid)` unique; references `Ad`, `Cred`, taker/maker `Actor`s; `status` via `OrderStatus`
- `Hot` = warm-up trading session; many-to-many with `Actor`s and `Order`s
- `Msg` = order chat message with optional `File` attachment
- `Transfer` = order payment record with `amount`, optional `File` (receipt)

### Conditions (Ad parsing)
`Cond` -> `CondParsed`, `Synonym`, `CondSim`

- `Cond.raw_txt` = original ad conditions text (4095 chars max, unique)
- `CondParsed` = structured parse result: `to_party`/`from_party` (`Party`), `ppo`, `slip_req`/`slip_send` (`Slip`), abuse flags, linked bank `Pm`s
- `Synonym` = condition term with `typ` (`SynonymType`), optional regex (`is_re`), boundary matching

### Transactions (XyncPay)
`Transaction`, `Sign`

- `Transaction.id` = deterministic UUID packed from: `type(2bit) + ts(30bit) + cur_id(1byte) + receiver_id(3bytes) + amount(5bytes) + sender_id(3bytes)` = 16 bytes
- `Transaction.proof` = 128 bytes (64 sender signature + 64 validator signature), Ed25519
- `Transaction.status` progresses: `request` -> `signed` -> `verified`
- Key methods: `pack` (property), `sign(front_sign)`, `approve(prv)`, `check(vld_pub)`, `snapshot(ts)` (raw SQL)
- DB-level PL/pgSQL triggers enforce: balance checks on insert, immutability on update, no deletes

### Financial Products
`Dep` -> `Investment`, `TopUpAble` -> `TopUp`

### Management
`Limit`, `ExStat`, `Vpn`, `Invite`, `Credit`, `File`

## Dynamic Client Loading

Models delegate exchange-specific logic to `xync_client` via runtime imports:

```
Ex.client()       -> xync_client.{ex.name}.ex.ExClient
Agent.client()    -> xync_client.{ex.name}.agent.AgentClient
Actor.asset_client() -> xync_client.{ex.name}.asset.AssetClient
Order.client()    -> xync_client.{ex.name}.order.OrderClient
Pm.client()       -> xync_client.Pms.{pm.norm}
PmAgent.client()  -> xync_client.Pms.{pm.norm}.agent
```

## Enums

All enums are in `xync_schema/enums.py` (all `IntEnum`). Key ones: `AdStatus`, `OrderStatus`, `OrderAction`, `OrderErr`, `ExType`, `ExStatus`, `ExAction` (~50 actions), `PmType`, `TransactionStatus`, `PersonStatus`, `UserStatus`, `HotStatus`, `FileType`, `DepType`, `AgentStatus`.

`TransactionStatus` is imported as `TS` alias in this file.
