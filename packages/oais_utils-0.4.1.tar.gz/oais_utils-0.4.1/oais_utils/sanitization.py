import logging
import re
import urllib


def sanitize_filename(filename, log=None):
    """
    Converts filename to be able to be safely processed in the pipeline (like Archivematica).
    """
    if log is None:
        log = logging.getLogger(__name__)

    filename = urllib.parse.unquote(filename).strip()

    if re.search(r'[<>:"/\\|?*\x00-\x1F\U00010000-\U0010FFFF]', filename):
        log.warning("Filename with invalid characters detected. Sanitizing.")
        filename = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "-", filename)
        filename = re.sub(r"[^\u0000-\uFFFF]", "-", filename)
        filename = re.sub(r"-+", "-", filename)

    filename = filename.strip("-").strip()
    filename = re.sub(r"\s+", "_", filename)

    return filename
