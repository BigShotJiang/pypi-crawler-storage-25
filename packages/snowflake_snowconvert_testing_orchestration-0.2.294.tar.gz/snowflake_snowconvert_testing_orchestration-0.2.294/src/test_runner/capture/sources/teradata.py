"""
Teradata executor factory.

Wraps the ``ConnectorTeradata`` from ``snowflake-data-validation`` to provide
connection management, SQL literal formatting, and stored-procedure execution.

Column types are derived from ``cursor.description`` (which uses Python type
classes as type codes in ``teradatasql``) and mapped to Snowflake types through
the framework's YAML type-mapping templates.
"""

from __future__ import annotations

import datetime
import decimal
import logging
from collections import deque
from typing import Any

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.teradata.connector.connector_factory_teradata import (
    TeradataConnectorFactory,
)
from snowflake.snowflake_data_validation.teradata.model.teradata_credentials_connection import (
    TeradataCredentialsConnection,
)
from snowflake.snowflake_data_validation.utils.constants import Platform

from test_runner.common.builders.common import is_call
from test_runner.common.builders.models import TeradataBuiltSQL
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import (
    DatabaseExecutor,
    DatabaseExecutorFactory,
    LiteralFormatter,
)
from test_runner.common.models import (
    ColumnTypeMap,
    StepOrigin,
    TestCaseResult,
    ValidationSteps,
)
from test_runner.common.models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    Step,
    ValidateSkip,
)
from test_runner.common.type_mapping import base_type_name, load_datatypes_mapping
from test_runner.replay.isolation.factory import TeradataIsolationFactory
from test_runner.replay.source_introspector import TeradataIntrospector

LOGGER = logging.getLogger(__name__)

# teradatasql uses Python type classes as cursor.description type codes.
_PYTHON_TYPE_TO_TD: dict[type, str] = {
    int: "integer",
    float: "float",
    str: "varchar",
    bytes: "varbyte",
    decimal.Decimal: "decimal",
    datetime.datetime: "timestamp",
    datetime.date: "date",
    datetime.time: "time",
    datetime.timedelta: "interval",
}

def _period_cols_from_cursor(cursor: Any, column_names: list[str]) -> set[str]:
    """Return column names (uppercase) whose Teradata type starts with "PERIOD".

    Uses ``cursor.columntypename``, a teradatasql-specific attribute that is a
    list of Teradata type name strings parallel to ``cursor.description``.
    Returns an empty set when the attribute is absent or not a list (e.g. in
    tests using plain ``MagicMock`` cursors without explicit configuration).
    """
    type_names = getattr(cursor, "columntypename", None)
    if not isinstance(type_names, (list, tuple)):
        return set()
    return {
        col
        for col, type_name in zip(column_names, type_names)
        if isinstance(type_name, str) and type_name.startswith("PERIOD")
    }


def _normalize_period_value(v: str) -> str:
    """Convert a teradatasql PERIOD string to the SnowConvert/Snowflake VARCHAR format.

    teradatasql returns: "2024-01-01,2024-06-30"
    Snowflake stores:    "2024-01-01*2024-06-30"

    Returns the value unchanged if it does not contain a comma (unexpected format).
    Whitespace around the comma separator is stripped.
    """
    parts = v.split(",", 1)
    if len(parts) != 2:
        return v
    begin, end = parts
    return f"{begin.strip()}*{end.strip()}"


def _build_row_dicts(
    column_names: list[str], rows: list, period_cols: set[str]
) -> list[dict]:
    """Build row dicts from *rows*, normalizing PERIOD values in one pass.

    If *period_cols* is empty the inner loop reduces to a plain ``zip``.
    Otherwise, each value whose column is in *period_cols* is normalized via
    :func:`_normalize_period_value` during construction — no second iteration.
    """
    if not period_cols:
        return [dict(zip(column_names, row)) for row in rows]
    return [
        {
            col: (_normalize_period_value(val) if col in period_cols and isinstance(val, str) else val)
            for col, val in zip(column_names, row)
        }
        for row in rows
    ]


# ---------------------------------------------------------------------------
# Literal formatter
# ---------------------------------------------------------------------------

class TeradataLiteralFormatter(LiteralFormatter):
    """Teradata SQL literal formatting.

    Booleans are rendered as 0/1 (Teradata has no native boolean type;
    BYTEINT is conventionally used).
    """

    def format_literal(self, value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "1" if value else "0"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, str):
            escaped = value.replace("'", "''")
            return f"'{escaped}'"
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'"


# ---------------------------------------------------------------------------
# Executor
# ---------------------------------------------------------------------------

class TeradataExecutor(DatabaseExecutor):
    """Executes SQL on Teradata via the data-validation ``ConnectorTeradata``.

    Uses the underlying ``teradatasql`` connection to execute queries and
    captures column type names from ``cursor.description``.

    When ``output_parameters`` is declared, scalar OUT/INOUT values are
    read from the CALL result set and stored in ``result.output_params``.

    When ``fetch_stmts`` are provided (pre-rendered by Jinja templates),
    each is executed in sequence after the CALL and its result set is
    captured.
    """

    def __init__(
        self,
        connector: ConnectorBase,
        datatypes_mappings: ColumnTypeMap | None = None,
    ) -> None:
        self._connector = connector
        self._datatypes_mappings = datatypes_mappings

    @property
    def connector(self) -> ConnectorBase:
        return self._connector

    def close(self) -> None:
        self._connector.close()

    def execute(
        self,
        sql: str,
        steps: ValidationSteps | None = None,
        fetch_stmts: list[str] | None = None,
    ) -> TestCaseResult:
        output_params = steps.output_parameters if steps else None
        has_outputs = bool(output_params or fetch_stmts)

        result = TestCaseResult()
        conn = self._connector.connection
        cursor = conn.cursor()
        try:
            cursor.execute(sql)

            if has_outputs:
                if output_params:
                    self._extract_output_params(cursor, result, output_params)

                for stmt in (fetch_stmts or []):
                    cursor.execute(stmt)
                    self._append_result_set(cursor, result)
            else:
                self._collect_all_result_sets(cursor, result)
        except Exception as exc:
            result.success = False
            result.error = str(exc)
        finally:
            cursor.close()

        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _collect_all_result_sets(
        self, cursor: Any, result: TestCaseResult,
    ) -> None:
        """Collect every non-empty result set from *cursor*.

        Teradata procedures declared with ``DYNAMIC RESULT SETS`` return
        cursor-based result sets that appear as subsequent result sets on
        the DB-API cursor after the initial ``execute``.  The first result
        set from the CALL itself is typically empty — some driver versions
        report ``description is None`` while others provide a description
        with zero rows.  We skip both cases and only keep result sets that
        actually contain rows.

        Errors from ``cursor.nextset()`` propagate up to the caller's
        outer error handler — ``teradatasql`` returns ``False`` cleanly
        at end-of-results, so any exception here is a real driver/network
        failure that should fail the capture rather than be silently
        swallowed.
        """
        has_more = True
        while has_more:
            description = cursor.description
            if description is not None:
                column_names = [desc[0] for desc in description]
                col_types = self._describe_types(cursor)
                period_cols = _period_cols_from_cursor(cursor, column_names)
                rows = cursor.fetchall()
                if rows:
                    row_dicts = _build_row_dicts(column_names, rows, period_cols)
                    result.result_sets.append(row_dicts)
                    result.row_counts.append(len(row_dicts))
                    result.column_types.append(col_types)
            has_more = cursor.nextset()

    def _append_result_set(self, cursor: Any, result: TestCaseResult) -> None:
        """Read the current cursor result set and append it to *result*."""
        description = cursor.description
        if description is None:
            result.result_sets.append([])
            result.row_counts.append(0)
            result.column_types.append({})
            return

        column_names = [desc[0] for desc in description]
        period_cols = _period_cols_from_cursor(cursor, column_names)
        rows = cursor.fetchall()
        row_dicts = _build_row_dicts(column_names, rows, period_cols)
        result.result_sets.append(row_dicts)
        result.row_counts.append(len(row_dicts))
        result.column_types.append(self._describe_types(cursor))

    def _extract_output_params(
        self,
        cursor: Any,
        result: TestCaseResult,
        param_names: list[str],
    ) -> None:
        """Read scalar OUT/INOUT values from the CALL result set.

        In Teradata, output parameters from stored procedures appear as
        columns in the result set returned by the CALL.
        """
        description = cursor.description
        if description is None:
            return

        column_names = [desc[0] for desc in description]
        row = cursor.fetchone()
        if row is None:
            return

        col_types = self._describe_types(cursor)
        row_dict = dict(zip(column_names, row))

        lower_to_declared = {n.lower(): n for n in param_names}
        output_params: dict[str, Any] = {}
        output_param_types: dict[str, str] = {}

        for col_name, col_value in row_dict.items():
            declared = lower_to_declared.get(col_name.lower())
            if declared is not None:
                output_params[declared] = col_value

        for col_name, col_type in col_types.items():
            declared = lower_to_declared.get(col_name.lower())
            if declared is not None:
                output_param_types[declared] = col_type

        result.output_params = output_params
        result.output_param_types = output_param_types

    # ------------------------------------------------------------------
    # Step-based execution
    # ------------------------------------------------------------------

    def execute_steps(
        self,
        built_sql: TeradataBuiltSQL,
        steps: list[Step],
    ) -> TestCaseResult:
        """Run step-based SQL on a Teradata cursor.

        Mirrors :meth:`RedshiftExecutor.execute_steps` with two
        Teradata-specific twists:

        - When the CALL is **not** validated (proc has output params), we
          read the first result set as the INOUT row, then walk
          ``cursor.nextset()`` to collect every subsequent non-empty
          result set into a queue.  Subsequent ``CursorStep`` indices
          consume from this queue in order.
        - When the CALL **is** validated (proc has no output params), the
          first non-empty result set on the cursor (which may be the CALL
          row itself or the first dynamic result set) becomes the
          captured result for that step.  Any remaining result sets are
          drained.

        No ``BEGIN``/``ROLLBACK`` wrapping — atomicity is owned by the
        caller's isolation provider (``TeradataIsolationFactory`` via
        ``capture_deltas``).
        """
        result = TestCaseResult(step_origins=[])
        conn = self._connector.connection
        cursor = conn.cursor()
        last_call_result: dict[str, Any] | None = None
        last_call_types: ColumnTypeMap = {}
        had_call = False
        pending_cursor_results: deque[tuple[list[dict[str, Any]], ColumnTypeMap]] = (
            deque()
        )

        try:
            validated = set(built_sql.validated_step_indices)
            all_indices = set(built_sql.main_sql.keys()) | validated
            max_idx = max(all_indices) if all_indices else -1

            for idx in range(max_idx + 1):
                sql = built_sql.main_sql.get(idx)
                if sql is None:
                    self._handle_replay_only_step(
                        idx, validated, steps, last_call_result,
                        last_call_types, pending_cursor_results, result,
                        had_call,
                    )
                    continue

                cursor.execute(sql)

                if is_call(sql):
                    had_call = True
                    last_call_result, last_call_types, pending_cursor_results = (
                        self._handle_call_step(
                            idx, cursor, steps, validated, result,
                        )
                    )
                elif idx in validated:
                    self._append_result_set(cursor, result)
                    result.step_origins.append(StepOrigin(step_index=idx))
        except Exception as exc:
            result.success = False
            result.error = str(exc)
        finally:
            cursor.close()

        return result

    def _handle_replay_only_step(
        self,
        idx: int,
        validated: set[int],
        steps: list[Step],
        last_call_result: dict[str, Any] | None,
        last_call_types: ColumnTypeMap,
        pending_cursor_results: deque[tuple[list[dict[str, Any]], ColumnTypeMap]],
        result: TestCaseResult,
        had_call: bool,
    ) -> None:
        """Handle a step that emits no SQL (``ParamStep`` / ``CursorStep``).

        These steps don't execute against the DB; they consume state
        produced by an earlier CALL.  ``ParamStep`` synthesizes a
        single-row result from the previous CALL's INOUT row;
        ``CursorStep`` pops the next entry from the DRS queue.
        """
        if idx not in validated:
            return
        step = steps[idx]
        if isinstance(step, ParamStep) and step.source_params:
            self._synthesize_param_result(
                step.source_params, last_call_result,
                last_call_types, result, had_call,
            )
            result.step_origins.append(StepOrigin(step_index=idx))
        elif isinstance(step, CursorStep):
            self._consume_pending_cursor(pending_cursor_results, result)
            result.step_origins.append(StepOrigin(step_index=idx))

    def _handle_call_step(
        self,
        idx: int,
        cursor: Any,
        steps: list[Step],
        validated: set[int],
        result: TestCaseResult,
    ) -> tuple[
        dict[str, Any] | None,
        ColumnTypeMap,
        deque[tuple[list[dict[str, Any]], ColumnTypeMap]],
    ]:
        """Dispatch a CALL step to one of three sub-handlers.

        Returns the new ``(last_call_result, last_call_types,
        pending_cursor_results)`` tuple so the caller can rebind its
        cross-step state.  The three branches are:

        - **``validate: [list]``** — hand-written multi-RS YAML; collect
          every DRS, map positionally to validate-list entries, and
          clear param state (no downstream consumers expected).
        - **validated CALL** (proc has no output params) — capture the
          first non-empty result set, drain the rest, clear param state
          so a stray ``ParamStep`` downstream raises clearly.
        - **CALL with output params** (``validate=False``) — read the
          INOUT row into ``last_call_result`` and queue every subsequent
          non-empty DRS for later ``CursorStep`` consumption.
        """
        step = steps[idx]
        if isinstance(step, QueryStep) and isinstance(step.validate, list):
            rs_list = self._collect_call_result_sets(cursor)
            self._map_validate_list(step.validate, rs_list, idx, result)
            return None, {}, deque()
        if idx in validated:
            rows, col_types = self._read_first_nonempty_set(cursor)
            result.result_sets.append(rows)
            result.row_counts.append(len(rows))
            result.column_types.append(col_types)
            result.step_origins.append(StepOrigin(step_index=idx))
            return None, {}, deque()
        last_call_result, last_call_types = self._read_call_param_row(cursor)
        pending_cursor_results = deque(self._collect_dynamic_result_sets(cursor))
        return last_call_result, last_call_types, pending_cursor_results

    @staticmethod
    def _synthesize_param_result(
        param_names: list[str],
        last_call_result: dict[str, Any] | None,
        last_call_types: ColumnTypeMap,
        result: TestCaseResult,
        had_call: bool = True,
    ) -> None:
        """Build a single-row result set from the previous CALL's INOUT row."""
        if last_call_result is None:
            if had_call:
                raise RuntimeError(
                    "ParamStep requires output columns from the preceding CALL, "
                    "but the CALL returned no rows"
                )
            raise RuntimeError(
                "ParamStep requires a preceding CALL result, but no CALL was executed"
            )
        lower_to_actual = {k.lower(): k for k in last_call_result}
        row: dict[str, Any] = {}
        col_types: dict[str, str] = {}
        for name in param_names:
            actual_key = lower_to_actual.get(name.lower())
            if actual_key is not None:
                row[name] = last_call_result[actual_key]
                upper_key = actual_key.upper()
                if upper_key in last_call_types:
                    col_types[name.upper()] = last_call_types[upper_key]
        result.result_sets.append([row])
        result.row_counts.append(1)
        result.column_types.append(col_types)

    def _read_call_param_row(
        self, cursor: Any,
    ) -> tuple[dict[str, Any] | None, ColumnTypeMap]:
        """Read the INOUT row from a CALL cursor.

        Returns ``(None, {})`` when the cursor has no description or no
        rows on the first result set.
        """
        description = cursor.description
        if description is None:
            return None, {}
        col_names = [d[0] for d in description]
        row = cursor.fetchone()
        if row is None:
            return None, {}
        types = self._describe_types(cursor)
        return dict(zip(col_names, row)), types

    def _collect_dynamic_result_sets(
        self, cursor: Any,
    ) -> list[tuple[list[dict[str, Any]], ColumnTypeMap]]:
        """Walk ``cursor.nextset()`` and collect every non-empty result set.

        Used to capture ``DYNAMIC RESULT SETS`` data after the CALL's
        INOUT row has been read.  Empty result sets (no description or
        zero rows) are skipped — Teradata sometimes interleaves empty
        bookkeeping payloads.

        Errors from ``cursor.nextset()`` propagate up to ``execute_steps``'s
        outer error handler — see ``_collect_all_result_sets`` for rationale.
        """
        collected: list[tuple[list[dict[str, Any]], ColumnTypeMap]] = []
        has_more = cursor.nextset()
        while has_more:
            description = cursor.description
            if description is not None:
                column_names = [d[0] for d in description]
                col_types = self._describe_types(cursor)
                rows = cursor.fetchall()
                if rows:
                    row_dicts = [dict(zip(column_names, r)) for r in rows]
                    collected.append((row_dicts, col_types))
            has_more = cursor.nextset()
        return collected

    def _collect_call_result_sets(
        self,
        cursor: Any,
    ) -> list[tuple[list[dict[str, Any]], ColumnTypeMap]]:
        """Collect every DYNAMIC RESULT SET from a CALL cursor.

        Used by the ``validate: [list]`` path where each entry maps
        positionally to a result set.  ``teradatasql`` positions the
        cursor on RS#0 after a CALL — that slot is always the
        synthesized INOUT-parameter row (when the proc declares OUT/
        INOUT params) or an empty bookkeeping payload (when it does
        not).  Either way it is not a DRS, so we discard it and start
        collecting from the next set.

        Empty result sets are preserved so positional alignment with
        ``validate: [list]`` entries is maintained when a DRS legitimately
        returns zero rows; pure driver-bookkeeping sets (those with
        ``description is None``) are skipped.

        Errors from ``cursor.nextset()`` propagate up to ``execute_steps``'s
        outer error handler — see ``_collect_all_result_sets`` for rationale.
        """
        collected: list[tuple[list[dict[str, Any]], ColumnTypeMap]] = []
        # Drain RS#0 (INOUT row or empty CALL ack) before advancing.
        if cursor.description is not None:
            cursor.fetchall()
        has_more = cursor.nextset()
        while has_more:
            description = cursor.description
            if description is not None:
                column_names = [d[0] for d in description]
                col_types = self._describe_types(cursor)
                rows = cursor.fetchall()
                row_dicts = [dict(zip(column_names, r)) for r in rows]
                collected.append((row_dicts, col_types))
            has_more = cursor.nextset()
        return collected

    @staticmethod
    def _map_validate_list(
        validate_list: list,
        rs_list: list[tuple[list[dict[str, Any]], ColumnTypeMap]],
        step_index: int,
        result: TestCaseResult,
    ) -> None:
        """Map collected result sets to ``validate: [list]`` entries.

        ``ValidateSkip`` entries advance past a result set without
        recording anything — keeping the positional alignment with the
        target side.  Too few source result sets raises so the YAML
        author sees it as a capture-time error rather than a mysterious
        row-count diff; too many is logged at WARNING (we drop the
        trailing DRSes rather than fail because the YAML author may
        legitimately only care about a prefix of the DRS list, but they
        should still see the asymmetry so they can decide whether to add
        ``validate`` entries or use ``ValidateSkip`` explicitly).
        """
        rs_idx = 0
        for entry_idx, entry in enumerate(validate_list):
            if isinstance(entry, ValidateSkip):
                rs_idx += 1
                continue
            if rs_idx >= len(rs_list):
                raise RuntimeError(
                    f"Step {step_index}: source returned {len(rs_list)} "
                    f"result set(s) but validate list expects at least "
                    f"{rs_idx + 1}"
                )
            rows, col_types = rs_list[rs_idx]
            result.result_sets.append(rows)
            result.row_counts.append(len(rows))
            result.column_types.append(col_types)
            result.step_origins.append(
                StepOrigin(step_index=step_index, validate_entry=entry_idx)
            )
            rs_idx += 1

        if rs_idx < len(rs_list):
            LOGGER.warning(
                "Step %d: source returned %d result set(s) but validate "
                "list only consumes %d; dropping the trailing %d",
                step_index, len(rs_list), rs_idx, len(rs_list) - rs_idx,
            )

    def _read_first_nonempty_set(
        self, cursor: Any,
    ) -> tuple[list[dict[str, Any]], ColumnTypeMap]:
        """Read the first non-empty result set from *cursor*, draining the rest.

        Used for validated CALL steps where the proc has no output
        params: the captured result is whatever non-empty result set the
        CALL produces (the CALL row itself or the first dynamic result
        set).  Subsequent result sets are drained but discarded.

        Errors from ``cursor.nextset()`` propagate up to ``execute_steps``'s
        outer error handler — see ``_collect_all_result_sets`` for rationale.
        """
        first_rows: list[dict[str, Any]] = []
        first_types: ColumnTypeMap = {}
        captured = False
        has_more = True
        while has_more:
            description = cursor.description
            if description is not None:
                column_names = [d[0] for d in description]
                col_types = self._describe_types(cursor)
                rows = cursor.fetchall()
                if rows and not captured:
                    first_rows = [dict(zip(column_names, r)) for r in rows]
                    first_types = col_types
                    captured = True
            has_more = cursor.nextset()
        return first_rows, first_types

    @staticmethod
    def _consume_pending_cursor(
        pending_cursor_results: deque[tuple[list[dict[str, Any]], ColumnTypeMap]],
        result: TestCaseResult,
    ) -> None:
        """Pop the next collected result set into *result*.

        When the queue is empty (e.g. the CALL produced fewer dynamic
        result sets than expected), append an empty result set rather
        than raising — this keeps step indexing aligned and lets the
        validate-side comparator surface the discrepancy as a row-count
        mismatch.

        ``deque.popleft()`` is O(1); ``list.pop(0)`` would be O(n).
        Negligible in practice (n is the number of DYNAMIC RESULT SETS,
        usually <5) but the deque also signals FIFO intent.
        """
        if pending_cursor_results:
            rows, types = pending_cursor_results.popleft()
            result.result_sets.append(rows)
            result.row_counts.append(len(rows))
            result.column_types.append(types)
        else:
            result.result_sets.append([])
            result.row_counts.append(0)
            result.column_types.append({})

    def _describe_types(self, cursor: Any) -> ColumnTypeMap:
        """Map cursor.description type codes to Snowflake type names.

        ``teradatasql`` uses Python type classes (``int``, ``str``,
        ``datetime.datetime``, etc.) as type codes.  These are mapped
        to Teradata type names and then through ``_datatypes_mappings``
        to produce the Snowflake type.
        """
        description = cursor.description
        if not description:
            return {}

        column_types: dict[str, str] = {}
        for desc in description:
            col_name = desc[0].upper()
            type_code = desc[1]
            type_name = _PYTHON_TYPE_TO_TD.get(type_code, "varchar")
            base = base_type_name(type_name)
            if self._datatypes_mappings:
                snowflake_type = self._datatypes_mappings.get(base, base)
            else:
                snowflake_type = base
            column_types[col_name] = snowflake_type
        return column_types


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

class TeradataExecutorFactory(DatabaseExecutorFactory):
    """Factory for Teradata executors backed by data-validation connectors."""

    @property
    def dialect(self) -> DatabaseDialect:
        return DatabaseDialect.TERADATA

    def build_config(self, raw: dict[str, Any]) -> TeradataCredentialsConnection:
        return TeradataCredentialsConnection(
            host=raw.get("host") or raw.get("server_url", "localhost"),
            database=raw.get("database", ""),
            username=raw.get("username") or raw.get("user", ""),
            password=raw.get("password", ""),
        )

    def create_literal_formatter(self) -> TeradataLiteralFormatter:
        return TeradataLiteralFormatter()

    def create_executor(self, config: TeradataCredentialsConnection) -> TeradataExecutor:
        connector = TeradataConnectorFactory.create_connector(config)
        datatypes_mappings = load_datatypes_mapping(Platform.TERADATA)
        return TeradataExecutor(connector, datatypes_mappings)

    def create_isolation(self, **kwargs):
        contains_commit = kwargs.pop("contains_commit", False)
        return TeradataIsolationFactory().create(contains_commit)

    def create_introspector(self):
        return TeradataIntrospector()
