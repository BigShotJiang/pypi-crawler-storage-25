"""Best-effort cleanup of stranded ephemeral baseline directories.

When ``run_capture`` runs without ``--keep-baselines`` it writes
baselines into ``tempfile.gettempdir()/mto-baselines-<pid>-<rand>/``
and relies on ``TemporaryDirectory.__exit__`` to delete the directory
before exit.  Catastrophic failures (``SIGKILL``, OOM, power loss) bypass
that cleanup and leave the baselines on disk.

This module scans ``tempfile.gettempdir()`` on the next CLI invocation
and removes directories whose owning process is no longer alive.  It is
concurrency-safe:

- Our own tempdir (matching ``os.getpid()``) is skipped explicitly.
- Sibling processes' tempdirs are protected by a live-PID probe
  (``os.kill(pid, 0)``); we never delete a directory whose PID answers.
- A stale-threshold on ``mtime`` guards against deleting a freshly
  allocated directory in the narrow window where the OS has reused the
  PID of a crashed run.
- Races with a parallel sweeper are absorbed by
  ``shutil.rmtree(ignore_errors=True)``.

The sweeper is best-effort: it never raises, so a failure to clean up
cannot break the capture or validate pipeline.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

LOGGER = logging.getLogger(__name__)

# ``shutil.rmtree`` renamed ``onerror`` to ``onexc`` in 3.12; the old
# keyword still works but emits ``DeprecationWarning``.  Pick the
# supported kwarg at import time so we stay warning-free on 3.12+ while
# still supporting 3.10/3.11 declared in pyproject.toml.
_RMTREE_CB_KWARG = "onexc" if sys.version_info >= (3, 12) else "onerror"

TEMPDIR_PREFIX = "mto-baselines-"
_NAME_PATTERN = re.compile(r"mto-baselines-(\d+)-.+")

# Only delete dead-PID directories whose mtime is older than this.  The
# window guards against a freshly-allocated tempdir whose PID was reused
# from a crashed run -- we'd rather leak a stranded dir for a few more
# minutes than wrongly delete a live run's data.
STALE_THRESHOLD_SEC = 10 * 60


def _pid_alive(pid: int) -> bool:
    """Return True if *pid* names a running process we can see.

    ``os.kill(pid, 0)`` is the portable "is this PID alive" probe:

    - returns cleanly    -> process exists, we own it
    - ``ProcessLookupError`` -> no such pid
    - ``PermissionError``    -> process exists but owned by another user
    - other ``OSError``      -> treat conservatively as alive (especially
      relevant on Windows where ``os.kill(pid, 0)`` raises ``OSError``
      with errno ``EPERM``/``ESRCH`` depending on the PID state)
    """
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return True


def build_tempdir_prefix() -> str:
    """Return the prefix passed to ``TemporaryDirectory`` at capture time.

    Shared between the allocator in ``run_capture`` and the sweep scan
    here so the two cannot drift.
    """
    return f"{TEMPDIR_PREFIX}{os.getpid()}-"


def sweep_stranded_tempdirs(
    tempdir_root: str | Path | None = None,
    stale_threshold_sec: float = STALE_THRESHOLD_SEC,
) -> int:
    """Remove ``mto-baselines-<pid>-*`` directories left by crashed runs.

    Args:
        tempdir_root: Directory to scan.  Defaults to
            ``tempfile.gettempdir()``.  Exposed for tests.
        stale_threshold_sec: Minimum age (seconds) before a dead-PID
            directory is eligible for deletion.  Defaults to
            ``STALE_THRESHOLD_SEC``.

    Returns:
        The number of directories deleted.  Zero if nothing matched or
        if the scan could not run; errors are swallowed so capture and
        validate are never blocked by a sweep failure.
    """
    root = Path(tempdir_root) if tempdir_root is not None else Path(tempfile.gettempdir())
    own_pid = os.getpid()
    now = time.time()
    deleted = 0

    try:
        entries = list(os.scandir(root))
    except (FileNotFoundError, PermissionError, OSError) as exc:
        LOGGER.debug("Tempdir sweep skipped (%s): %s", root, exc)
        return 0

    for entry in entries:
        match = _NAME_PATTERN.fullmatch(entry.name)
        if match is None:
            continue
        try:
            if not entry.is_dir(follow_symlinks=False):
                continue
        except OSError:
            continue

        pid = int(match.group(1))
        if pid == own_pid or _pid_alive(pid):
            continue

        try:
            mtime = entry.stat(follow_symlinks=False).st_mtime
        except OSError:
            continue
        if (now - mtime) < stale_threshold_sec:
            continue

        rmtree_failed = False

        def _on_exc(*_: object) -> None:
            nonlocal rmtree_failed
            rmtree_failed = True

        try:
            shutil.rmtree(entry.path, **{_RMTREE_CB_KWARG: _on_exc})
        except OSError as exc:
            # ``onexc`` normally suppresses rmtree's own errors, but a
            # monkeypatched or pathological implementation may still
            # raise.  Log and continue so one bad entry cannot break the
            # rest of the sweep (capture/validate depend on this).
            LOGGER.debug("rmtree failed for %s: %s", entry.path, exc)
            continue
        if not rmtree_failed:
            deleted += 1
            LOGGER.info("Swept stranded baseline tempdir: %s", entry.path)

    if deleted:
        LOGGER.info("Tempdir sweep removed %d stranded directories under %s", deleted, root)
    return deleted
