"""Parsed test YAML file produced by ``scai test seed``."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional

from .step_types import StepBasedValidation
from .validation_steps import ValidationSteps

if TYPE_CHECKING:
    from test_runner.common.collation import CollationClassifier


@dataclass
class TestFile:
    """A parsed test YAML file produced by ``scai test seed``."""

    file_path: str
    """Absolute path to the YAML file on disk."""

    source: ValidationSteps
    """Source-side execution steps (used by capture)."""

    test_cases: list[list[Any]]
    """List of test cases; each is an array of positional values."""

    target: Optional[ValidationSteps] = None
    """Target-side execution steps (used by validate). Optional."""

    code_unit_name: str = ""
    """Code unit name (procedure or function) resolved from the CUR or artifacts path."""

    code_unit_id: Optional[str] = None
    """CUR UUID for this code unit, used by enrichment to look up dependency metadata."""

    parameter_names: list[str] = field(default_factory=list)
    """Parameter names extracted from the source ``run`` template."""

    modifies_data: Optional[bool] = None
    """Override flag indicating this procedure modifies data."""

    affected_tables: Optional[list[str]] = None
    """Override list of affected tables."""

    pk_columns_by_table: dict[str, list[str]] = field(default_factory=dict)
    """Primary key columns per affected table (keyed by SCHEMA.TABLE FQN).

    Populated from CUR ``signature.columns[].isPrimaryKey`` during enrichment.
    Used by ``_resolve_table_configs`` to enable the PK_DIFF delta strategy.
    """

    read_tables: Optional[list[str]] = None
    """Tables this procedure reads from (from CUR dependency closure)."""

    set_tables: list[str] = field(default_factory=list)
    """Source FQNs of affected/read tables that use Teradata SET semantics.

    Populated from CUR ``issues`` (presence of ``SSC-FDM-TD0024``) during
    enrichment via :func:`~dependency_classifier._format_name` which reads
    ``unit.source``.  Teradata uses 2-part naming (database.object) which
    maps 1:1 to Snowflake's schema.object, so source FQNs match
    ``TableConfig.fqn`` in the delta path without normalization.  If this
    pattern is extended to 3-part-FQN dialects (Redshift, SQL Server),
    FQN normalization or CUR UUID lookup will be needed.

    Used by :class:`~test_runner.common.comparison_context.ComparisonContext`
    to trigger DISTINCT re-comparison when row counts mismatch.
    """

    source_checksum: Optional[str] = None
    """BLAKE3 checksum of the source procedure file, computed at test-run time."""

    converted_checksum: Optional[str] = None
    """BLAKE3 checksum of the converted procedure file, computed at test-run time."""

    target_database: Optional[str] = None
    """Target database from CUR (used for clone isolation during validation)."""

    contains_commit: bool = False
    """Whether the procedure contains an explicit COMMIT (from CUR ``containsCommit`` field).

    When True, the capture handler selects backup/restore isolation instead of
    transaction-based isolation to prevent the COMMIT from breaking rollback.
    """

    has_collation_fdm: bool = False
    """Whether the code unit has ``SSC-FDM-TD0032`` (CaseSpecificClauseWasRemoved).

    When True, failures from this code unit may be caused by collation
    behavior differences between Teradata (NOT CASESPECIFIC default) and
    Snowflake (case-sensitive default).  Used for advisory annotation on
    comparison mismatches — does not change pass/fail behavior.
    """

    case_insensitive_columns_by_table: dict[str, list[str]] = field(default_factory=dict)
    """Per-table list of NOT CASESPECIFIC columns (keyed by SCHEMA.TABLE FQN).

    Populated from CUR ``signature.columns[].isCaseSpecific`` during
    enrichment.  For Teradata dialect, CHAR/VARCHAR columns without
    explicit ``isCaseSpecific: true`` are assumed NOT CASESPECIFIC
    (Teradata Mode default).  Used for advisory annotation on comparison
    mismatches — does not change pass/fail behavior.
    """

    collation: Optional[CollationClassifier] = None
    """Collation classifier built from CUR metadata during enrichment.

    Comparators call ``collation.annotate_diffs()`` to tag mismatches;
    all dialect-specific collation knowledge is encapsulated here.
    ``None`` when CUR enrichment was not performed or the code unit
    has no collation signals.
    """

    step_validation: Optional[StepBasedValidation] = None
    """Step-based validation definition (v2 schema).

    When set, this file uses the new ``validation.steps`` list format
    instead of the v1 ``source``/``target`` blocks.  The ``source`` field
    is set to a sentinel ``ValidationSteps(run="<step-based>")`` so that
    downstream code which assumes ``source`` is always present does not
    break.  SNOW-3280023 will add runner logic to check this field and
    route to step-based execution.
    """
