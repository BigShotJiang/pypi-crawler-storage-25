"""SET table dedup classifier for Teradata.

Teradata SET tables silently reject duplicate rows on insert.  After
conversion to Snowflake (MULTISET semantics), duplicates are accepted,
causing row-count mismatches in both delta and result-set comparisons.

This module provides free functions that:

1. Detect whether a count mismatch involves a SET table.
2. Deduplicate the *actual* side (Polars ``unique`` for delta rows,
   DuckDB ``SELECT DISTINCT`` for in-memory result sets).
3. Re-run L3 cell-level comparison on the deduped data.
4. Stamp ``set_table_risk`` on the diff dict and optionally flip
   ``match`` to ``True`` when dedup fully resolves the mismatch.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

import duckdb
import polars as pl

logger = logging.getLogger(__name__)

RISK_POSSIBLE = "possible"
RISK_CONFIRMED = "confirmed"


def _dedup_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return *rows* with duplicate dicts removed, preserving order."""
    if not rows:
        return rows
    try:
        df = pl.DataFrame(rows)
        return df.unique(maintain_order=True).to_dicts()
    except pl.exceptions.PolarsError as exc:
        logger.warning("Polars failed during dedup (%s); returning original rows", exc)
        return rows


def adjust_delta_diff(
    diff: dict[str, Any],
    table_fqn: str,
    set_tables: frozenset[str],
    baseline_rows: list[dict[str, Any]],
    actual_rows: list[dict[str, Any]],
    compare_fn: Callable[
        [list[dict[str, Any]], list[dict[str, Any]], dict[str, str], int],
        list[dict[str, Any]],
    ],
    max_cell_diffs: int,
    column_types: dict[str, str] | None = None,
) -> None:
    """Annotate and optionally resolve a delta count-mismatch on a SET table.

    Parameters
    ----------
    diff:
        A single difference dict from ``compare_table_deltas`` (e.g.
        ``{"type": "insert_count_mismatch", "baseline": 5, "actual": 8}``).
    table_fqn:
        Fully-qualified table name.
    set_tables:
        Upper-cased FQNs of tables known to be Teradata SET tables.
    baseline_rows:
        Baseline delta rows for this mismatch type (inserts, deletes, or
        update-after rows).
    actual_rows:
        Actual delta rows for this mismatch type.
    compare_fn:
        Cell-level comparison callable with signature
        ``(baseline, actual, table_fqn, max_cell_diffs) -> list[dict]``.
    max_cell_diffs:
        Cap on reported cell diffs.
    """
    if table_fqn.upper() not in set_tables:
        return

    distinct_actual = _dedup_rows(actual_rows)
    diff["set_table_risk"] = RISK_POSSIBLE
    diff["distinct_actual"] = len(distinct_actual)
    diff["duplicate_rows"] = len(actual_rows) - len(distinct_actual)

    if len(distinct_actual) != len(baseline_rows):
        return

    cell_diffs = compare_fn(baseline_rows, distinct_actual, column_types or {}, max_cell_diffs)
    if not cell_diffs:
        diff["set_table_risk"] = RISK_CONFIRMED


def adjust_in_memory_result(
    result: dict[str, Any],
    conn: duckdb.DuckDBPyConnection,
    columns: list[str],
    baseline_rows: list[dict[str, Any]],
    validate_cell_fn: Callable[..., Any],
    cell_level_kwargs: dict[str, Any],
) -> None:
    """Annotate and optionally resolve a row-count mismatch in the in-memory path.

    Parameters
    ----------
    result:
        The full comparison result dict (with ``row_counts``, etc.).
    conn:
        Open DuckDB connection with ``baseline`` and ``actual`` tables.
    columns:
        Column names.
    baseline_rows:
        Original baseline row list (used for cell-level re-comparison
        against the de-duplicated actual rows from DuckDB).
    validate_cell_fn:
        Cell-level validation callable; must accept ``baseline_rows``,
        ``actual_rows`` keyword args plus any extra ``cell_level_kwargs``
        and return an object with an ``is_valid`` attribute.
    cell_level_kwargs:
        Extra keyword args forwarded to *validate_cell_fn*.
    """
    row_counts = result.get("row_counts", {})
    if row_counts.get("match", True):
        return

    col_list = ", ".join('"' + col.replace('"', '""') + '"' for col in columns)
    distinct_rows = [
        dict(zip(columns, row))
        for row in conn.execute(f"SELECT DISTINCT {col_list} FROM actual").fetchall()
    ]
    distinct_count = len(distinct_rows)
    row_counts["set_table_risk"] = RISK_POSSIBLE
    row_counts["distinct_actual"] = distinct_count
    row_counts["duplicate_rows"] = row_counts["actual"] - distinct_count

    if distinct_count != row_counts["baseline"]:
        return

    cell_comparison = validate_cell_fn(
        baseline_rows=baseline_rows,
        actual_rows=distinct_rows,
        **cell_level_kwargs,
    )

    if cell_comparison.is_valid:
        row_counts["set_table_risk"] = RISK_CONFIRMED
        row_counts["match"] = True
        summary_stats_match = result.get("summary_stats", {}).get("match", True)
        result["match"] = summary_stats_match
