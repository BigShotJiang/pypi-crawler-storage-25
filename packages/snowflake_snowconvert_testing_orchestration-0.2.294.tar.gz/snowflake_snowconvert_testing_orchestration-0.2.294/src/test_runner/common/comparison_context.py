"""Dialect-aware post-comparison adjustment context.

``ComparisonContext`` bundles metadata that comparators need to adjust
their verdicts for dialect-specific semantics (SET table dedup,
collation, etc.) without scattering if-then-else branches in the
comparison code itself.

The context is constructed once per test file and threaded into
``compare_table_deltas`` and ``compare_in_memory``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from test_runner.common.models.test_file import TestFile


@dataclass(frozen=True)
class ComparisonContext:
    """Immutable bag of dialect-specific metadata for comparison adjusters."""

    set_tables: frozenset[str] = field(default_factory=frozenset)
    """FQNs of tables that use Teradata SET semantics (reject duplicate inserts)."""

    reads_set_table: bool = False
    """Whether the procedure reads from or writes to any SET table."""

    @classmethod
    def from_test_file(cls, test_file: TestFile) -> ComparisonContext:
        """Build a context from enriched :class:`TestFile` metadata."""
        set_tables = frozenset(fqn.upper() for fqn in test_file.set_tables)
        combined = (test_file.read_tables or []) + (test_file.affected_tables or [])
        reads_set = bool(set_tables and set_tables & {fqn.upper() for fqn in combined})
        return cls(set_tables=set_tables, reads_set_table=reads_set)
