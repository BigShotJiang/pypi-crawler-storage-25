"""Centralized SQL data-type classification helpers.

Constants and predicate functions for categorizing SQL column types
(character, numeric, timestamp) used across the test runner — e.g. by
``teradata_collation`` (character-type detection) and
``transient_table_manager`` (numeric/timestamp coercion).
"""

from __future__ import annotations

CHAR_TYPE_PREFIXES: frozenset[str] = frozenset((
    "CHAR", "VARCHAR", "NCHAR", "NVARCHAR", "CHARACTER", "TEXT", "STRING",
))

NUMERIC_TYPE_PREFIXES: tuple[str, ...] = (
    "NUMBER", "NUMERIC", "DECIMAL",
    "INT", "INTEGER", "BIGINT", "SMALLINT", "TINYINT", "BYTEINT",
    "FLOAT", "FLOAT4", "FLOAT8", "DOUBLE", "REAL",
)

TIMESTAMP_TYPE_PREFIXES: tuple[str, ...] = ("TIMESTAMP",)


def is_char_type(type_str: str | None) -> bool:
    """Return True if *type_str* is a character/string SQL type."""
    if not type_str:
        return False
    upper = type_str.upper().strip()
    return any(upper.startswith(prefix) for prefix in CHAR_TYPE_PREFIXES)


def is_numeric_type(sql_type: str) -> bool:
    """Return True if *sql_type* is a numeric SQL data type."""
    base = sql_type.upper().split("(")[0].strip()
    return base in NUMERIC_TYPE_PREFIXES or base.startswith(NUMERIC_TYPE_PREFIXES)


def is_timestamp_type(sql_type: str) -> bool:
    """Return True if *sql_type* is a timestamp SQL data type."""
    base = sql_type.upper().split("(")[0].strip()
    return base.startswith(TIMESTAMP_TYPE_PREFIXES)
