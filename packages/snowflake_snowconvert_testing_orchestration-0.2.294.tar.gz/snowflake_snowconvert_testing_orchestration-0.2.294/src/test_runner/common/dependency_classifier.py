"""Classify procedures from CUR dependency closures."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from snowflake_code_unit_registry import CodeUnit, CodeUnitRegistry, FindOptions, compute_file_checksum
from snowflake_code_unit_registry.types import ObjectType
from .collation import CollationBuilder, CollationClassifier
from .database_dialect import DatabaseDialect
from .teradata_collation import TeradataCollationBuilder

LOGGER = logging.getLogger(__name__)

_COLLATION_BUILDERS: dict[DatabaseDialect, CollationBuilder] = {
    DatabaseDialect.TERADATA: TeradataCollationBuilder(),
}

WRITE_RELATIONS: frozenset[str] = frozenset(
    r.upper() for r in ("INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE", "ALTER", "DROP")
)


@dataclass(frozen=True)
class ClassificationResult:
    """Classification output for one procedure."""
    modifies_data: bool = False
    affected: tuple[CodeUnit, ...] = ()
    reads: tuple[CodeUnit, ...] = ()


def classify(
    code_unit_id: str,
    index: dict[str, CodeUnit],
) -> ClassificationResult:
    """Scan a CUR dependency closure for write and read operations.

    Iterates every dependency edge in *index* (the transitive closure
    returned by ``FindOptions(include_dependencies=True)``).  If any edge
    carries a write relation type (INSERT, UPDATE, DELETE, MERGE, TRUNCATE,
    ALTER, DROP) the procedure is classified as read-write and the target
    code unit is collected.  Edges that carry only non-write relation
    types are collected as read dependencies.

    Returns ``modifies_data`` flag, the tuple of affected (write) units,
    and the tuple of read-only dependency units.
    """
    if code_unit_id not in index:
        return ClassificationResult()

    all_deps = [dependency for unit in index.values() for dependency in _get_deps(unit)]
    write_deps = [dependency for dependency in all_deps if _has_write_relation(dependency)]
    read_deps = [dependency for dependency in all_deps if not _has_write_relation(dependency) and _has_any_relation(dependency)]
    affected = {
        dep_id: index[dep_id]
        for dependency in write_deps
        if (dep_id := getattr(dependency, "id", None)) and dep_id in index
    }
    read_units = {
        dep_id: index[dep_id]
        for dependency in read_deps
        if (dep_id := getattr(dependency, "id", None)) and dep_id in index
    }

    return ClassificationResult(
        modifies_data=bool(write_deps),
        affected=tuple(affected.values()),
        reads=tuple(read_units.values()),
    )


def _get_deps(unit: CodeUnit) -> list:
    deps = getattr(unit, "dependencies", None)
    if deps is None:
        return []
    return getattr(deps, "dependsOn", None) or []


def _has_write_relation(dep: object) -> bool:
    types = getattr(dep, "relationTypes", None) or []
    return bool(WRITE_RELATIONS & {t.upper() for t in types})


def _has_any_relation(dep: object) -> bool:
    types = getattr(dep, "relationTypes", None) or []
    return bool(types)


TABULAR_OBJECT_TYPES: frozenset[ObjectType] = frozenset({
    ObjectType.table,
    ObjectType.view,
    ObjectType.materializedView,
})


def _is_tabular(unit: CodeUnit) -> bool:
    """Return whether *unit* represents a tabular object (table, view, materialized view).

    Checks ``source.objectType`` against :data:`TABULAR_OBJECT_TYPES`.
    When the attribute is missing (older CUR data), defaults to ``True``
    so existing behaviour is preserved.
    """
    source = getattr(unit, "source", None)
    if source is None:
        return True
    object_type = getattr(source, "objectType", None)
    if object_type is None:
        LOGGER.debug("objectType missing on unit %s; assuming tabular", getattr(unit, "id", "?"))
        return True
    return object_type in TABULAR_OBJECT_TYPES


def _format_name(unit: CodeUnit) -> Optional[str]:
    source = getattr(unit, "source", None)
    if source is None:
        return None
    name = getattr(source, "name", None)
    if not name:
        return None
    schema = getattr(source, "schema_", None) or getattr(source, "schema", None)
    database = getattr(source, "database", None)
    parts = [p for p in (database, schema, name) if p]
    return ".".join(parts)


def _extract_pk_columns(
    units: tuple[CodeUnit, ...],
) -> dict[str, list[str]]:
    """Extract primary key columns from CUR ``signature.columns`` for affected tables.

    Returns a dict keyed by SCHEMA.TABLE (or DB.SCHEMA.TABLE) with PK column
    name lists.  Tables without PK info are omitted.
    """
    result: dict[str, list[str]] = {}
    for unit in units:
        fqn = _format_name(unit)
        if not fqn:
            continue
        sig = getattr(unit, "signature", None)
        if sig is None:
            continue
        columns = getattr(sig, "columns", None)
        if not columns:
            continue
        pk_cols = [
            getattr(col, "name", "")
            for col in columns
            if getattr(col, "isPrimaryKey", False)
        ]
        if pk_cols:
            result[fqn] = pk_cols
    return result


_SET_TABLE_FDM = "SSC-FDM-TD0024"


def _extract_set_tables(
    units: tuple[CodeUnit, ...],
) -> list[str]:
    """Extract FQNs of tables whose CUR ``issues`` contain :data:`_SET_TABLE_FDM`."""
    result: list[str] = []
    for unit in units:
        issues = getattr(unit, "issues", None)
        if not issues:
            continue
        issue_list = getattr(issues, "root", issues) or []
        has_set_fdm = any(
            getattr(issue, "code", "") == _SET_TABLE_FDM
            for issue in issue_list
        )
        if not has_set_fdm:
            continue
        fqn = _format_name(unit)
        if fqn:
            result.append(fqn)
    return result


def _build_closure_index(registry: CodeUnitRegistry, code_unit_id: str) -> dict[str, CodeUnit]:
    units = registry.find_all(FindOptions(
        filter=f"id = '{code_unit_id}'",
        include_dependencies=True,
        fields=["id", "source", "target", "dependencies", "files", "signature", "codeStatus", "issues"],
    ))
    return {u.id: u for u in units if u.id}


def _compute_checksums(
    unit: CodeUnit,
    project_root: Path,
) -> tuple[Optional[str], Optional[str]]:
    """Compute BLAKE3 checksums for the source and converted files on disk.

    Paths stored in CUR are relative to *project_root*.  Returns
    ``(source_checksum, converted_checksum)``; either may be ``None`` if the
    file path is absent or the file cannot be read.
    """
    def _checksum(file_entry: object) -> Optional[str]:
        path_str = getattr(file_entry, "path", None)
        if not path_str:
            return None
        abs_path = project_root / path_str
        try:
            return compute_file_checksum(str(abs_path))
        except Exception as exc:
            LOGGER.warning("Could not compute checksum for %s: %s", abs_path, exc)
            return None

    files = getattr(unit, "files", None)
    if files is None:
        return None, None
    return (
        _checksum(getattr(files, "source", None)),
        _checksum(getattr(files, "converted", None)),
    )


def extract_code_unit_id(test_file_path: str) -> Optional[str]:
    """Extract code unit ID from a generated test YAML path."""
    return Path(test_file_path).stem


def enrich_test_files(
    test_files: list,
    project_root: str | Path,
    registry: CodeUnitRegistry,
    source_dialect: DatabaseDialect = DatabaseDialect.SQL_SERVER,
) -> None:
    """Populate modifies_data, affected_tables, and collation metadata from CUR.

    Skips test files where modifies_data is already set (YAML override).
    Collation metadata (``has_collation_fdm``, ``case_insensitive_columns_by_table``)
    is always populated when available — regardless of YAML override — because it
    is advisory annotation that does not change pass/fail behavior.
    """
    collation_builder = _COLLATION_BUILDERS.get(source_dialect)

    project_root = Path(project_root)
    for test_file in test_files:
        cu_id = test_file.code_unit_id
        assert cu_id is not None, f"code_unit_id must not be None for {test_file.file_path}"
        try:
            index = _build_closure_index(registry, cu_id)
        except Exception as exc:
            LOGGER.warning("Could not query code unit %s from CUR: %s", cu_id, exc)
            continue
        if cu_id not in index:
            continue

        test_file.source_checksum, test_file.converted_checksum = _compute_checksums(
            index[cu_id], project_root,
        )

        test_file.contains_commit = any(
            getattr(
                getattr(getattr(unit, "codeStatus", None), "assessment", None),
                "containsCommit", False,
            )
            for unit in index.values()
        )

        # -- collation metadata (advisory, always populated) ----------------
        if collation_builder is not None:
            all_table_ids = frozenset(
                aid for aid in index
                if aid != cu_id and _format_name(index.get(aid)) is not None
            )
            test_file.collation = collation_builder.build(
                index[cu_id], all_table_ids, index, _format_name,
            )
        else:
            test_file.collation = CollationClassifier()
        test_file.has_collation_fdm = test_file.collation.has_collation_fdm
        test_file.case_insensitive_columns_by_table = test_file.collation.case_insensitive_columns_by_table

        if test_file.modifies_data is not None:
            continue
        result = classify(cu_id, index)
        test_file.modifies_data = result.modifies_data
        tabular_affected = tuple(unit for unit in result.affected if _is_tabular(unit))
        test_file.affected_tables = sorted(
            filter(None, (_format_name(unit) for unit in tabular_affected))
        )
        tabular_reads = tuple(unit for unit in result.reads if _is_tabular(unit))
        test_file.read_tables = sorted(
            filter(None, (_format_name(unit) for unit in tabular_reads))
        )
        test_file.pk_columns_by_table = _extract_pk_columns(tabular_affected)
        all_tabular = tabular_affected + tabular_reads
        test_file.set_tables = sorted(_extract_set_tables(all_tabular))
