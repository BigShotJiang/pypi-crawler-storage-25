"""Collation-aware failure classification.

Provides :class:`CollationClassifier`, a dialect-agnostic container that
annotates comparison mismatches with collation context.  Comparators
(``delta_comparator``, ``in_memory_comparator``) call
:meth:`~CollationClassifier.annotate_diffs` without knowing anything about
specific dialects, FDM codes, or column-level metadata.

Dialect-specific construction logic (which FDM code to look for, which
columns are case-insensitive, what the session-mode defaults are) lives in
dialect-specific :class:`CollationBuilder` subclasses (e.g.
``teradata_collation.TeradataCollationBuilder``).

Design: SNOW-3377025.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Callable, Optional


@dataclass(frozen=True)
class CollationClassifier:
    """Annotates comparison mismatches with collation context.

    Comparators call :meth:`annotate_diffs` after producing cell-level
    diffs; the classifier decides which diffs to tag.  This keeps all
    dialect-specific collation knowledge out of the comparison code.

    Use :meth:`for_table` to scope the classifier to a specific table
    (precise column-level tagging).  Without scoping, only the coarse
    code-unit-level signal is applied.

    An instance where ``is_active`` is False is a no-op — safe to pass
    through the entire pipeline regardless of dialect.

    Parameters are injected at construction time by dialect-aware code
    (e.g. ``dependency_classifier``); this class never decides *what*
    constitutes a collation risk — it only carries and applies the
    metadata it was given.
    """

    has_collation_fdm: bool = False
    """True when the code unit carries a collation-related FDM."""

    fdm_code: str = ""
    """The specific FDM code to stamp on tagged diffs (e.g. ``SSC-FDM-TD0032``)."""

    case_insensitive_columns_by_table: dict[str, list[str]] = field(default_factory=dict)
    """SCHEMA.TABLE -> list of case-insensitive column names."""

    @classmethod
    def for_flat_columns(
        cls,
        columns: list[str],
        has_collation_fdm: bool = False,
        fdm_code: str = "",
    ) -> CollationClassifier:
        """Build a classifier from a flat column list (result-set comparison)."""
        by_table = {"*": columns} if columns else {}
        return cls(
            has_collation_fdm=has_collation_fdm,
            fdm_code=fdm_code,
            case_insensitive_columns_by_table=by_table,
        )

    @property
    def is_active(self) -> bool:
        return self.has_collation_fdm or bool(self.case_insensitive_columns_by_table)

    def for_table(self, table_fqn: str) -> _TableCollationClassifier:
        """Return a table-scoped classifier with pre-resolved column set."""
        ci_cols = self.case_insensitive_columns_by_table.get(table_fqn, [])
        return _TableCollationClassifier(
            ci_columns_upper=frozenset(c.upper() for c in ci_cols),
            has_collation_fdm=self.has_collation_fdm,
            fdm_code=self.fdm_code,
        )

    def for_result_set(self) -> _TableCollationClassifier:
        """Return a classifier for result-set comparison (no specific table).

        Flattens all known case-insensitive columns into one set for
        best-effort column-name matching against result-set columns.
        """
        all_cols: set[str] = set()
        for cols in self.case_insensitive_columns_by_table.values():
            all_cols.update(c.upper() for c in cols)
        return _TableCollationClassifier(
            ci_columns_upper=frozenset(all_cols),
            has_collation_fdm=self.has_collation_fdm,
            fdm_code=self.fdm_code,
        )

    def annotate_diffs(self, diffs: list[dict], *, table_fqn: str | None = None) -> None:
        """Annotate diffs using table-scoped or result-set classifier."""
        if not self.is_active:
            return
        if table_fqn is not None:
            self.for_table(table_fqn).annotate_diffs(diffs)
        else:
            self.for_result_set().annotate_diffs(diffs)

    def annotate_count_mismatch(self, diff: dict, *, table_fqn: str | None = None) -> None:
        """Stamp ``collation_risk`` on a count-mismatch diff dict.

        When *table_fqn* is provided, only annotates if that specific
        table has known CI columns or the code unit carries an FDM.
        Without *table_fqn*, falls back to :attr:`is_active`.
        """
        if not self.is_active:
            return
        if table_fqn is not None:
            self.for_table(table_fqn).annotate_count_mismatch(diff)
        else:
            self.for_result_set().annotate_count_mismatch(diff)


class CollationBuilder(ABC):
    """Dialect-specific factory that builds a :class:`CollationClassifier`.

    Subclass per source dialect (e.g. ``TeradataCollationBuilder``) and
    register in ``dependency_classifier._COLLATION_BUILDERS``.
    """

    @abstractmethod
    def build(
        self,
        code_unit: object,
        table_ids: frozenset[str],
        index: dict[str, object],
        format_name: Callable[[object], Optional[str]],
    ) -> CollationClassifier:
        """Construct a classifier from CUR metadata for one code unit."""
        ...


@dataclass(frozen=True)
class _TableCollationClassifier:
    """Table-scoped classifier that annotates cell-level diffs in-place.

    Level 1 (precise): column is in *ci_columns_upper* ->
    ``collation_risk: True``, ``fdm_code`` set to the injected code.

    Level 2 (coarse): column not in the set but *has_collation_fdm* is
    True and both values are strings -> ``collation_risk: "possible"``,
    ``fdm_code`` set to the injected code.
    """

    ci_columns_upper: frozenset[str] = field(default_factory=frozenset)
    has_collation_fdm: bool = False
    fdm_code: str = ""

    def annotate_diffs(self, diffs: list[dict]) -> None:
        if not self.ci_columns_upper and not self.has_collation_fdm:
            return
        for diff in diffs:
            col = (diff.get("column") or "").upper()
            if col in self.ci_columns_upper:
                diff["collation_risk"] = True
                if self.fdm_code:
                    diff["fdm_code"] = self.fdm_code
            elif (
                self.has_collation_fdm
                and isinstance(diff.get("baseline"), str)
                and isinstance(diff.get("actual"), str)
                and diff["baseline"].upper() == diff["actual"].upper()
            ):
                diff["collation_risk"] = "possible"
                if self.fdm_code:
                    diff["fdm_code"] = self.fdm_code

    def annotate_count_mismatch(self, diff: dict) -> None:
        """Stamp ``collation_risk: "possible"`` on a structural count diff."""
        if not self.ci_columns_upper and not self.has_collation_fdm:
            return
        diff["collation_risk"] = "possible"
        if self.fdm_code:
            diff["fdm_code"] = self.fdm_code
