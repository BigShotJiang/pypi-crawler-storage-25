"""Teradata-specific collation metadata extraction from CUR.

Reads ``isCaseSpecific`` column attributes and collation-related FDM
issues from the Code Unit Registry to build a
:class:`~collation.CollationClassifier`.  All Teradata-specific
assumptions (TMODE defaults, FDM codes, character type prefixes) are
confined to this module.

The single public entry point is :func:`build_collation_classifier`
(or :class:`TeradataCollationBuilder` for the ABC-based dispatch).
"""

from __future__ import annotations

from typing import Callable, Optional

from .collation import CollationBuilder, CollationClassifier
from .sql_types import is_char_type


_COLLATION_FDM_CODES: frozenset[str] = frozenset({
    "SSC-FDM-TD0032",
    "SSC-FDM-TD0039",
})


class TeradataCollationBuilder(CollationBuilder):
    """Dialect-specific builder for Teradata collation metadata."""

    def build(
        self,
        code_unit: object,
        table_ids: frozenset[str],
        index: dict[str, object],
        format_name: Callable[[object], str | None],
    ) -> CollationClassifier:
        return build_collation_classifier(code_unit, table_ids, index, format_name)


def build_collation_classifier(
    code_unit: object,
    table_ids: frozenset[str],
    index: dict[str, object],
    format_name: Callable[[object], Optional[str]],
) -> CollationClassifier:
    """Build a :class:`CollationClassifier` from Teradata CUR metadata.

    *code_unit* is the root procedure's CUR record.  *table_ids* are
    the IDs of table-type units in the same closure.  *index* maps
    unit IDs to CUR records.  *format_name* converts a CUR record to
    its ``SCHEMA.TABLE`` (or ``DB.SCHEMA.TABLE``) string.

    Teradata Mode assumption: CHAR/VARCHAR columns without explicit
    ``isCaseSpecific: true`` are treated as NOT CASESPECIFIC.
    See ``docs/collation-research.md`` for rationale (SNOW-3377025).
    """
    matched_fdm = _find_collation_fdm(code_unit)
    ci_columns = _extract_case_insensitive_columns(table_ids, index, format_name)
    return CollationClassifier(
        has_collation_fdm=matched_fdm is not None,
        fdm_code=matched_fdm or "",
        case_insensitive_columns_by_table=ci_columns,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _find_collation_fdm(unit: object) -> str | None:
    """Return the first matching collation FDM code, or ``None``."""
    issues = getattr(unit, "issues", None)
    if not issues:
        return None
    for issue in issues:
        code = getattr(issue, "code", None)
        if code in _COLLATION_FDM_CODES:
            return code
    return None


def _has_collation_fdm(unit: object) -> bool:
    """Return True if the code unit carries a collation-related FDM."""
    return _find_collation_fdm(unit) is not None


def _is_char_type(type_str: str | None) -> bool:
    """Thin wrapper kept for backward compatibility with tests."""
    return is_char_type(type_str)


def _extract_case_insensitive_columns(
    table_ids: frozenset[str],
    index: dict[str, object],
    format_name: Callable[[object], Optional[str]],
) -> dict[str, list[str]]:
    """Extract NOT CASESPECIFIC columns from CUR ``signature.columns``.

    CHAR/VARCHAR columns without explicit ``isCaseSpecific: true`` are
    assumed NOT CASESPECIFIC (Teradata Mode default).
    """
    result: dict[str, list[str]] = {}
    for tid in table_ids:
        unit = index.get(tid)
        if unit is None:
            continue
        fqn = format_name(unit)
        if not fqn:
            continue
        sig = getattr(unit, "signature", None)
        if sig is None:
            continue
        columns = getattr(sig, "columns", None)
        if not columns:
            continue
        ci_cols: list[str] = []
        for col in columns:
            col_type = getattr(col, "type", None)
            if not is_char_type(col_type):
                continue
            if getattr(col, "isCaseSpecific", None) is True:
                continue
            col_name = getattr(col, "name", "")
            if col_name:
                ci_cols.append(col_name)
        if ci_cols:
            result[fqn] = ci_cols
    return result
