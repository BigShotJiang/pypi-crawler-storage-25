"""Snowflake ``cursor.description`` → SDV-compatible column-type helpers.

Both the result-set capture path (``validate/targets/snowflake.py``) and
the delta-capture path (``replay/delta_capture.py``) need to translate a
Snowflake connector ``cursor.description`` into the canonical Snowflake
DDL names that ``snowflake-data-validation``'s public ``ResultSet`` API
expects (e.g. ``snowflake_to_result_set_datatypes_mapping_template.yaml``).

The connector exposes wire-protocol aliases (``FIXED``/``REAL``/``TEXT``)
via ``FIELD_ID_TO_NAME``; SDV's mapping template is keyed on the DDL
spelling (``NUMBER``/``FLOAT``/``VARCHAR``).  Without this remap SDV's
type-aware normalisation falls back to defaults and we lose the
Decimal-vs-Float canonicalisation that motivated SNOW-3414326.
"""

from __future__ import annotations

import logging
from typing import Any, Sequence

from snowflake.connector.constants import FIELD_ID_TO_NAME

from test_runner.common.models import ColumnTypeMap

LOGGER = logging.getLogger(__name__)


# Names that already match the SDV YAML (DATE, TIME, TIMESTAMP_*, BOOLEAN,
# BINARY, VARIANT, OBJECT, ARRAY, GEOGRAPHY, GEOMETRY, VECTOR, ...) pass
# through unchanged.
_FIELD_NAME_TO_DDL: dict[str, str] = {
    "FIXED": "NUMBER",
    "REAL": "FLOAT",
    "TEXT": "VARCHAR",
}


def field_type_to_ddl(type_code: int) -> str:
    """Translate a Snowflake connector ``type_code`` to its canonical DDL name.

    Falls back to ``VARCHAR`` for type codes that aren't present in the
    connector's ``FIELD_ID_TO_NAME`` mapping (and emits a DEBUG log so the
    silent fallback is observable — useful when the connector ships a new
    type code that isn't yet covered here).
    """
    field_name = FIELD_ID_TO_NAME.get(type_code)
    if field_name is None:
        LOGGER.debug(
            "Unknown Snowflake cursor.description type_code %r; "
            "falling back to VARCHAR for SDV normalisation.",
            type_code,
        )
        return "VARCHAR"
    return _FIELD_NAME_TO_DDL.get(field_name, field_name)


def describe_to_column_types(
    cursor_description: Sequence[Any],
) -> ColumnTypeMap:
    """Map Snowflake ``cursor.description`` to ``{COLUMN_NAME: DDL_TYPE}``.

    Column names are uppercased to match the rest of the test runner's
    case convention; type names are remapped to the DDL spelling SDV's
    ``ResultSet`` API recognises.
    """
    return {
        desc[0].upper(): field_type_to_ddl(desc[1])
        for desc in cursor_description
    }
