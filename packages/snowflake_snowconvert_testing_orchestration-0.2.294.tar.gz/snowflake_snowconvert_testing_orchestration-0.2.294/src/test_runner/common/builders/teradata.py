"""Teradata dialect SQL builder for step-based execution.

Produces individual SQL statements keyed by step index for sequential
execution on a single ``teradatasql`` cursor.

Differences from the Redshift builder:

- ``CursorStep`` emits **no** SQL.  Teradata returns cursor data declared
  via ``DYNAMIC RESULT SETS`` as additional ``cursor.nextset()`` payloads
  on the same CALL cursor — there is no ``FETCH ALL FROM <cursor>``
  syntax.  The executor walks ``nextset()`` after the CALL and assigns
  each non-empty result set to the next validated ``CursorStep`` index.
- ``ParamStep`` (same as Redshift) emits no SQL.  The executor reads the
  CALL's INOUT row and synthesizes the result.
"""

from __future__ import annotations

from typing import Any

from ..models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    Step,
    TableStep,
)
from .common import (
    format_teradata_literal,
    is_call,
    substitute_placeholders,
    substitute_raw_placeholders,
)
from .models import TeradataBuiltSQL


def build_teradata_sql(
    steps: list[Step],
    test_case: list[Any],
) -> TeradataBuiltSQL:
    """Build individual Teradata statements from step-based definitions.

    Parameters
    ----------
    steps
        Parsed step objects from ``StepBasedValidation.steps``.
    test_case
        A single test-case value array.
    """
    main_sql: dict[int, str] = {}
    validated: list[int] = []

    for i, step in enumerate(steps):
        if isinstance(step.validate, list):
            _check_validate_list_allowed(step, i, steps, test_case)
        sql = _build_step_sql(step, i, test_case)
        if sql is not None:
            main_sql[i] = sql
        if _is_validated(step, sql):
            validated.append(i)

    return TeradataBuiltSQL(
        main_sql=main_sql,
        validated_step_indices=validated,
    )


def _check_validate_list_allowed(
    step: Step,
    index: int,
    steps: list[Step],
    test_case: list[Any],
) -> None:
    """Reject ``validate: [list]`` on anything other than a CALL ``QueryStep``.

    Also rejects when downstream ``CursorStep``s appear between this CALL
    and the next CALL — both would try to consume the same DYNAMIC RESULT
    SETS off the cursor (the validate-list path consumes them up-front; a
    later ``CursorStep`` would have nothing to pop).
    """
    if not isinstance(step, QueryStep) or step.source_query is None:
        raise ValueError(
            f"Step {index}: validate: [list] is only supported on a CALL "
            f"QueryStep (got {type(step).__name__})"
        )
    rendered = substitute_placeholders(step.source_query, test_case, format_teradata_literal)
    if not is_call(rendered):
        raise ValueError(
            f"Step {index}: validate: [list] requires a CALL statement; "
            f"non-CALL queries return at most one result set"
        )
    for j in range(index + 1, len(steps)):
        following = steps[j]
        if isinstance(following, QueryStep) and following.source_query is not None:
            following_rendered = substitute_placeholders(
                following.source_query, test_case, format_teradata_literal,
            )
            if is_call(following_rendered):
                # Subsequent CALL owns its own RS queue — stop scanning.
                break
        if isinstance(following, CursorStep) and following.source_cursor:
            raise ValueError(
                f"Step {index}: validate: [list] on a CALL is mutually "
                f"exclusive with a downstream CursorStep (step {j}) that "
                f"would consume the same DYNAMIC RESULT SETS"
            )


def _is_validated(step: Step, sql: str | None) -> bool:
    """Determine if a step should be in ``validated_step_indices``.

    A step is validated when ``validate`` is truthy AND either:

    - the step produced SQL, or
    - it is a ``ParamStep`` with ``source_params`` (executor synthesizes
      from the previous CALL result), or
    - it is a ``CursorStep`` (executor pops from collected ``nextset()``
      result sets).
    """
    if step.validate is False:
        return False
    if sql is not None:
        return True
    if isinstance(step, ParamStep) and step.source_params:
        return True
    if isinstance(step, CursorStep) and step.source_cursor:
        return True
    return False


def _build_step_sql(
    step: Step,
    index: int,
    test_case: list[Any],
) -> str | None:
    """Return SQL for a single step, or ``None`` if no SQL is needed."""
    if isinstance(step, QueryStep):
        if step.source_query is None:
            return None
        return substitute_placeholders(step.source_query, test_case, format_teradata_literal)

    if isinstance(step, ParamStep):
        if step.validate is False:
            raise ValueError(
                f"Step {index}: ParamStep does not support validate: false"
            )
        # No SQL — executor extracts INOUT from previous CALL result.
        return None

    if isinstance(step, TableStep):
        if step.source_table is None:
            return None
        if step.validate is False:
            raise ValueError(
                f"Step {index}: TableStep does not support validate: false"
            )
        table = substitute_raw_placeholders(step.source_table, test_case)
        return f"SELECT * FROM {table}"

    if isinstance(step, CursorStep):
        if step.source_cursor is None:
            return None
        if step.validate is False:
            raise ValueError(
                f"Step {index}: CursorStep does not support validate: false"
            )
        # No SQL — Teradata returns cursor data via cursor.nextset() on
        # the preceding CALL.  The executor pops from the queue of
        # collected dynamic result sets.
        return None

    raise TypeError(f"Step {index}: unexpected step type {type(step).__name__}")
