"""Redshift dialect SQL builder for step-based execution.

Produces individual SQL statements keyed by step index for sequential
execution within a transaction.  ParamSteps are absent from the output —
the executor extracts INOUT params from the previous CALL result.
"""

from __future__ import annotations

from typing import Any

from ..models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    Step,
    TableStep,
)
from .common import format_redshift_literal, substitute_placeholders, substitute_raw_placeholders
from .models import RedshiftBuiltSQL


def build_redshift_sql(
    steps: list[Step],
    test_case: list[Any],
) -> RedshiftBuiltSQL:
    """Build individual Redshift statements from step-based definitions.

    Parameters
    ----------
    steps
        Parsed step objects from ``StepBasedValidation.steps``.
    test_case
        A single test-case value array.
    """
    main_sql: dict[int, str] = {}
    validated: list[int] = []

    for i, step in enumerate(steps):
        if isinstance(step.validate, list):
            raise ValueError(
                f"Step {i}: validate: [list] is not supported for Redshift"
            )
        sql = _build_step_sql(step, i, test_case)
        if sql is not None:
            main_sql[i] = sql
        if _is_validated(step, sql):
            validated.append(i)

    return RedshiftBuiltSQL(
        main_sql=main_sql,
        validated_step_indices=validated,
    )


def _is_validated(step: Step, sql: str | None) -> bool:
    """Determine if a step should be in validated_step_indices.

    A step is validated if ``validate`` is truthy AND the step produced
    SQL or is a ParamStep (which the executor handles via INOUT extraction).
    """
    if step.validate is False:
        return False
    if sql is not None:
        return True
    # ParamStep with source_params — executor extracts from CALL result.
    if isinstance(step, ParamStep) and step.source_params:
        return True
    return False


def _build_step_sql(
    step: Step,
    index: int,
    test_case: list[Any],
) -> str | None:
    """Return SQL for a single step, or ``None`` if no SQL is needed."""
    if isinstance(step, QueryStep):
        if step.source_query is None:
            return None
        return substitute_placeholders(step.source_query, test_case, format_redshift_literal)

    if isinstance(step, ParamStep):
        if step.validate is False:
            raise ValueError(
                f"Step {index}: ParamStep does not support validate: false"
            )
        # No SQL — executor extracts INOUT from previous CALL result.
        return None

    if isinstance(step, TableStep):
        if step.source_table is None:
            return None
        if step.validate is False:
            raise ValueError(
                f"Step {index}: TableStep does not support validate: false"
            )
        table = substitute_raw_placeholders(step.source_table, test_case)
        return f"SELECT * FROM {table}"

    if isinstance(step, CursorStep):
        if step.source_cursor is None:
            return None
        if step.validate is False:
            raise ValueError(
                f"Step {index}: CursorStep does not support validate: false"
            )
        cursor = substitute_raw_placeholders(step.source_cursor, test_case)
        return f"FETCH ALL FROM {cursor}"

    raise TypeError(f"Step {index}: unexpected step type {type(step).__name__}")
