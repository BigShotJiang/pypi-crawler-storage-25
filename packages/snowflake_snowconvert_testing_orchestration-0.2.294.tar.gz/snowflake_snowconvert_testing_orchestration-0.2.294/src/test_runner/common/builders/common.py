"""Shared helpers for dialect SQL builders."""

from __future__ import annotations

import re
from typing import Any, Callable

_PLACEHOLDER_RE = re.compile(r"\{(\d+)\}")
_CALL_PREFIX_RE = re.compile(r"^\s*CALL\s+", re.IGNORECASE)


# ---------------------------------------------------------------------------
# CALL-statement helpers
# ---------------------------------------------------------------------------

def is_call(sql: str) -> bool:
    """Return ``True`` if *sql* is a stored-procedure CALL statement.

    Matches ``CALL`` case-insensitively after leading whitespace, with at
    least one trailing whitespace character (so ``CALLBACK`` does not
    qualify).
    """
    return bool(_CALL_PREFIX_RE.match(sql))


# ---------------------------------------------------------------------------
# Literal formatters — one per dialect
# ---------------------------------------------------------------------------

def _format_literal(value: Any, bool_true: str, bool_false: str) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return bool_true if value else bool_false
    if isinstance(value, (int, float)):
        return str(value)
    escaped = str(value).replace("'", "''")
    return f"'{escaped}'"


def format_sqlserver_literal(value: Any) -> str:
    """T-SQL literal: booleans as ``1`` / ``0``."""
    return _format_literal(value, "1", "0")


def format_redshift_literal(value: Any) -> str:
    """Redshift/PostgreSQL literal: booleans as ``TRUE`` / ``FALSE``."""
    return _format_literal(value, "TRUE", "FALSE")


def format_teradata_literal(value: Any) -> str:
    """Teradata literal: booleans as ``1`` / ``0`` (no native BOOLEAN; BYTEINT)."""
    return _format_literal(value, "1", "0")


def format_snowflake_literal(value: Any) -> str:
    """Snowflake literal: booleans as ``TRUE`` / ``FALSE``."""
    return _format_literal(value, "TRUE", "FALSE")


# ---------------------------------------------------------------------------
# Placeholder substitution
# ---------------------------------------------------------------------------

def substitute_placeholders(
    sql: str,
    test_case: list[Any],
    format_literal: Callable[[Any], str],
) -> str:
    """Replace ``{0}``, ``{1}``, ... with dialect-formatted SQL literals."""
    def _replace(match: re.Match) -> str:
        idx = int(match.group(1))
        if idx >= len(test_case):
            return match.group(0)
        return format_literal(test_case[idx])

    return _PLACEHOLDER_RE.sub(_replace, sql)


def substitute_raw_placeholders(
    value: str,
    test_case: list[Any],
) -> str:
    """Replace ``{N}`` with raw (unquoted) string values.

    Used for table/cursor names that appear in identifier positions.
    """
    def _replace(match: re.Match) -> str:
        idx = int(match.group(1))
        if idx >= len(test_case):
            return match.group(0)
        return str(test_case[idx])

    return _PLACEHOLDER_RE.sub(_replace, value)


def ensure_semicolon(sql: str) -> str:
    """Ensure *sql* ends with exactly one semicolon.

    Idempotent — strips any trailing ``;`` before re-adding one, so it
    works whether the YAML author included a semicolon or not.
    """
    return sql.rstrip().rstrip(";").rstrip() + ";"
