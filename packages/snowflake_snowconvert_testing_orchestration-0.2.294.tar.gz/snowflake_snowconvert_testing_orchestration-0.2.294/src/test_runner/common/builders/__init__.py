"""Dialect-specific SQL builders for step-based execution."""

from typing import Any

from test_runner.common.database_dialect import DatabaseDialect

from .redshift import build_redshift_sql
from .snowflake import build_snowflake_sql
from .sqlserver import build_sqlserver_sql
from .teradata import build_teradata_sql

__all__ = [
    "build_redshift_sql",
    "build_snowflake_sql",
    "build_source_sql",
    "build_sqlserver_sql",
    "build_teradata_sql",
]


def build_source_sql(
    dialect: DatabaseDialect,
    steps: list[Any],
    test_case: list[Any],
) -> Any:
    """Dispatch to the correct source-side builder for *dialect*.

    Returns a dialect-specific ``BuiltSQL`` subtype (``SqlServerBuiltSQL``,
    ``RedshiftBuiltSQL``, etc.).  The return type is ``Any`` because each
    dialect produces a different concrete type; the caller passes the result
    to ``executor.execute_steps()`` which accepts the matching type.
    """
    if dialect == DatabaseDialect.SQL_SERVER:
        return build_sqlserver_sql(steps, test_case)
    elif dialect == DatabaseDialect.REDSHIFT:
        return build_redshift_sql(steps, test_case)
    elif dialect == DatabaseDialect.TERADATA:
        return build_teradata_sql(steps, test_case)
    raise ValueError(f"No source builder for {dialect}")
