"""In-memory validation using DuckDB.

Compares baseline and actual result sets in three levels:
row counts → per-column summary stats → cell-level diffs.
Results are plain dicts suitable for JSON serialization.

The cell-level diff delegates to SDV's public
``result_set_cell_level_validation`` API, which handles dtype
unification (Snowflake type strings → canonical Polars dtypes)
and canonical-string normalization (rounding floats, formatting
datetimes) before comparing values.  See SNOW-3414326.

TODO: migrate read-only sproc comparison to use SDV directly
(row/cell validation APIs) instead of the DuckDB row-count and
summary-stats layers here.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import duckdb
import pandas as pd
from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.public import (
    ResultSet,
    ValidationResult,
    result_set_cell_level_validation,
)

from test_runner.common.collation import CollationClassifier
from test_runner.common.comparison_context import ComparisonContext
from test_runner.common.config import TestRunnerConfig, ValidationConfiguration
from test_runner.common.set_table import adjust_in_memory_result
from test_runner.common.models import (
    MAX_ERROR_LENGTH,
    ColumnTypeMap,
    ComparisonResult,
    RowDict,
    ValidationDifference,
    truncate,
)
from test_runner.validate.implicit_return import is_implicit_snowflake_return
from test_runner.validate.transient_table_manager import (
    execute_with_capture,
    extract_result_set,
    fetch_baseline_output_rows,
    fetch_baseline_rows,
    is_numeric_type,
)

LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_duckdb(
    baseline_rows: list[RowDict],
    actual_rows: list[RowDict],
    col_types: ColumnTypeMap,
) -> tuple[duckdb.DuckDBPyConnection, list[str]]:
    """Register baseline and actual rows as DuckDB tables; return ``(conn, columns)``."""
    columns = list(col_types.keys()) if col_types else (
        list(baseline_rows[0].keys()) if baseline_rows else
        list(actual_rows[0].keys()) if actual_rows else []
    )

    conn = duckdb.connect()

    def _register(name: str, rows: list[RowDict]) -> None:
        if rows:
            df = pd.DataFrame(rows, columns=columns)
        else:
            df = pd.DataFrame(columns=columns)
        # Assign sequential 1-based row numbers for join-based cell diff
        df.insert(0, "_row", range(1, len(df) + 1))
        conn.register(name, df)

    _register("baseline", baseline_rows)
    _register("actual", actual_rows)
    return conn, columns


def _row_count_diff(conn: duckdb.DuckDBPyConnection, columns: list[str]) -> dict[str, Any]:
    """Return a row-counts section with baseline/actual counts."""
    b_count = conn.execute("SELECT COUNT(*) FROM baseline").fetchone()[0]
    a_count = conn.execute("SELECT COUNT(*) FROM actual").fetchone()[0]
    return {
        "baseline": b_count,
        "actual": a_count,
        "match": b_count == a_count,
    }


def _summary_stats_diff(
    conn: duckdb.DuckDBPyConnection,
    columns: list[str],
    col_types: ColumnTypeMap | None = None,
    *,
    tolerance: float,
) -> dict[str, Any]:
    """Return per-column summary stat mismatches for numeric columns.

    Non-numeric columns are skipped (handled by cell-level diff).
    Each mismatch: ``{"column": ..., "metrics": {"sum": {"baseline": x, "actual": y}, ...}}``.
    """
    mismatches: list[dict] = []

    # col_types maps column name -> Snowflake SQL type (e.g. "NUMBER", "VARCHAR").
    # is_numeric_type checks the type string against known numeric type prefixes
    # (_NUMERIC_TYPE_PREFIXES in transient_table_manager) so only numeric columns
    # get aggregate stats; text/date columns are handled by cell-level diff instead.
    for col in columns:
        if col_types and not is_numeric_type(col_types.get(col, "")):
            continue  # skip VARCHAR, DATE, BOOLEAN, etc.
        quoted = f'"{col}"'
        try:
            b_stats = conn.execute(
                f"SELECT COUNT(*) - COUNT({quoted}) AS null_count,"
                f" MIN(TRY_CAST({quoted} AS DOUBLE)) AS min_val,"
                f" MAX(TRY_CAST({quoted} AS DOUBLE)) AS max_val,"
                f" AVG(TRY_CAST({quoted} AS DOUBLE)) AS avg_val,"
                f" SUM(TRY_CAST({quoted} AS DOUBLE)) AS sum_val"
                f" FROM baseline"
            ).fetchone()
            a_stats = conn.execute(
                f"SELECT COUNT(*) - COUNT({quoted}) AS null_count,"
                f" MIN(TRY_CAST({quoted} AS DOUBLE)) AS min_val,"
                f" MAX(TRY_CAST({quoted} AS DOUBLE)) AS max_val,"
                f" AVG(TRY_CAST({quoted} AS DOUBLE)) AS avg_val,"
                f" SUM(TRY_CAST({quoted} AS DOUBLE)) AS sum_val"
                f" FROM actual"
            ).fetchone()
        except Exception as exc:  # noqa: BLE001
            LOGGER.debug("Stats computation skipped for column %r: %s", col, exc)
            continue

        b_null, b_min, b_max, b_avg, b_sum = b_stats
        a_null, a_min, a_max, a_avg, a_sum = a_stats

        # All numeric metrics use tolerance-aware float comparison.
        # Both-None means TRY_CAST failed on both sides (text column) → equal.
        candidates = [
            ("null_count", b_null, a_null),
            ("min", b_min, a_min),
            ("max", b_max, a_max),
            ("avg", b_avg, a_avg),
            ("sum", b_sum, a_sum),
        ]
        metric_diffs = {}
        for metric, b_val, a_val in candidates:
            if metric == "null_count":
                if b_val != a_val:
                    metric_diffs[metric] = {"baseline": b_val, "actual": a_val}
            else:
                if b_val is None and a_val is None:
                    continue  # both non-numeric (text col) — skip
                if b_val is None or a_val is None or abs(b_val - a_val) > tolerance:
                    metric_diffs[metric] = {"baseline": b_val, "actual": a_val}

        if metric_diffs:
            mismatches.append({"column": col, "metrics": metric_diffs})

    return {
        "match": len(mismatches) == 0,
        "mismatches": mismatches,
    }

def _validate_cell_level(
    baseline_rows: list[RowDict],
    actual_rows: list[RowDict],
    col_types: ColumnTypeMap,
) -> ValidationResult:
    """Compare two row sets cell-by-cell via the SDV public ResultSet API.

    Wrapping the rows in ``ResultSet`` lets SDV perform Snowflake-type-aware
    dtype unification and canonical-string normalization before the diff,
    which avoids spurious mismatches from Decimal-vs-Float stringification
    differences (SNOW-3356602) and is the public entry point introduced in
    migrations-data-validation PR #557.
    """
    return result_set_cell_level_validation(
        first_result_set=ResultSet(rows=baseline_rows, column_types=col_types),
        second_result_set=ResultSet(rows=actual_rows, column_types=col_types),
    )


def _try_set_table_adjustment(
    row_counts: dict[str, Any],
    summary_stats: dict[str, Any],
    cell_diffs: list[dict],
    cmp_ctx: ComparisonContext,
    conn: duckdb.DuckDBPyConnection,
    columns: list[str],
    baseline_rows: list[RowDict],
    actual_rows: list[RowDict],
    col_types: ColumnTypeMap,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Apply SET table dedup adjustment if applicable, returning updated (row_counts, summary_stats).

    The gate here is intentionally procedure-level (``reads_set_table``)
    rather than per-table.  Unlike the delta path — where each
    ``TableConfig`` provides a table FQN — the in-memory path compares
    the procedure's aggregate result set, which has no single table FQN
    to check against.  The adjustment is conservative: it only flips
    ``match`` when DISTINCT count equals baseline AND cell-level
    re-comparison passes, so a false trigger on a non-SET result set
    would at most annotate ``set_table_risk: "possible"`` without
    changing the verdict.
    """
    if not cmp_ctx.reads_set_table:
        return row_counts, summary_stats
    result_dict: dict[str, Any] = {
        "match": False,
        "row_counts": row_counts,
        "summary_stats": summary_stats,
        "cell_diffs": cell_diffs,
    }
    adjust_in_memory_result(
        result_dict,
        conn=conn,
        columns=columns,
        baseline_rows=baseline_rows,
        validate_cell_fn=_validate_cell_level,
        cell_level_kwargs={"col_types": col_types},
    )
    return result_dict["row_counts"], result_dict.get("summary_stats", summary_stats)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compare_in_memory(
    baseline_rows: list[RowDict],
    actual_rows: list[RowDict],
    col_types: ColumnTypeMap,
    tolerance: float = ValidationConfiguration().tolerance,
    max_cell_diffs: int = ValidationConfiguration().max_cell_diffs,
    collation: CollationClassifier | None = None,
    case_insensitive_columns: list[str] | None = None,
    has_collation_fdm: bool = False,
    cmp_ctx: ComparisonContext | None = None,
) -> dict[str, Any]:
    """Compare two result sets in memory using DuckDB.

    Returns a dict with ``match``, ``row_counts``, ``summary_stats``, and ``cell_diffs``.

    When *collation* is provided, cell-level mismatches are annotated via
    the classifier (dialect-agnostic).  The legacy *case_insensitive_columns*
    / *has_collation_fdm* params are accepted for backward compatibility.
    """
    conn, columns = _load_duckdb(baseline_rows, actual_rows, col_types)

    if collation is None and (case_insensitive_columns or has_collation_fdm):
        collation = CollationClassifier.for_flat_columns(
            list(case_insensitive_columns or []),
            has_collation_fdm=has_collation_fdm,
        )

    try:
        row_counts = _row_count_diff(conn, columns)
        summary_stats = _summary_stats_diff(conn, columns, col_types=col_types, tolerance=tolerance)
        cell_diffs: list[dict] = []
        if row_counts["match"]:
            cell_comparison = _validate_cell_level(
                baseline_rows=baseline_rows,
                actual_rows=actual_rows,
                col_types=col_types,
            )
            df = cell_comparison.results_dataframe.rename(columns={
                "ROW": "row",
                "COLUMN": "column",
                "SOURCE_VALUE": "baseline",
                "TARGET_VALUE": "actual",
            })
            cell_diffs = df.head(max_cell_diffs).to_dict(orient="records")
            if cell_diffs and collation is not None:
                collation.annotate_diffs(cell_diffs)
        else:
            LOGGER.warning(
                "Row count mismatch (baseline=%d, actual=%d); skipping cell-level diff.",
                row_counts["baseline"], row_counts["actual"],
            )
            if collation is not None:
                collation.annotate_count_mismatch(row_counts)

            if cmp_ctx is not None:
                row_counts, summary_stats = _try_set_table_adjustment(
                    row_counts, summary_stats, cell_diffs, cmp_ctx,
                    conn, columns, baseline_rows,
                    actual_rows, col_types,
                )
    finally:
        conn.close()

    overall_match = row_counts["match"] and summary_stats["match"] and len(cell_diffs) == 0
    return {
        "match": overall_match,
        "row_counts": row_counts,
        "summary_stats": summary_stats,
        "cell_diffs": cell_diffs,
    }


class InMemoryResultComparator:
    """Orchestrates in-memory comparison for a single test case.

    Fetches the baseline from the Snowflake stage, executes the procedure,
    and delegates to :func:`compare_in_memory`.
    """

    def __init__(
        self,
        config: TestRunnerConfig,
        connector: ConnectorBase,
        code_unit_name: str,
        baseline_procedure: str = "",
        baseline_rows_cache: dict[str, dict] | None = None,
        baseline_output_cache: dict[str, tuple[list[dict], dict[str, str]]] | None = None,
        collation: CollationClassifier | None = None,
        case_insensitive_columns: list[str] | None = None,
        has_collation_fdm: bool = False,
        cmp_ctx: ComparisonContext | None = None,
    ) -> None:
        self._config = config
        self._connector = connector
        self._code_unit_name = code_unit_name
        self._baseline_procedure = baseline_procedure or code_unit_name
        # baseline_rows_cache stores the FULL baseline JSON dict per
        # params_hash (not a pre-extracted single result set). Per-step
        # comparisons must extract their own ``result_set_index`` on lookup,
        # otherwise multi-result-set step-based tests would all collide on
        # the same cached entry.
        self._baseline_rows_cache = baseline_rows_cache or {}
        self._baseline_output_cache = baseline_output_cache or {}
        if collation is not None:
            self._collation = collation
        elif case_insensitive_columns or has_collation_fdm:
            self._collation = CollationClassifier.for_flat_columns(
                list(case_insensitive_columns or []),
                has_collation_fdm=has_collation_fdm,
            )
        else:
            self._collation: CollationClassifier | None = None
        self._cmp_ctx = cmp_ctx

    def compare(
        self,
        rendered_sql: str,
        params_hash: str,
        dump_baseline_and_actual: bool = False,
        fetch_stmts: list[str] | None = None,
        outputs_sql: str | None = None,
        outputs_only: bool = False,
        result_set_index: int = -1,
    ) -> ComparisonResult:
        """Fetch baseline from stage, execute *rendered_sql*, and compare in memory.

        When *dump_baseline_and_actual* is True, attaches ``_baseline_rows`` and
        ``_actual_rows`` to the result for ``write_results_local`` to persist.

        When *fetch_stmts* is provided (e.g. ``SELECT * FROM IDENTIFIER('...')``
        for ``output.tables`` procedures), each statement is executed after the
        CALL and the last result set is used as the actual data.
        """
        database: str = self._config.validation_database or ""

        t0 = time.monotonic()
        if outputs_only:
            if params_hash in self._baseline_output_cache:
                baseline_rows, col_types = self._baseline_output_cache[params_hash]
                source = "cache"
            else:
                baseline_rows, col_types = fetch_baseline_output_rows(
                    self._connector, database, params_hash,
                    procedure=self._baseline_procedure,
                )
                source = "stage"
            label = "fetch_baseline_output_rows"
        else:
            # The rows cache stores the full baseline JSON, so we extract the
            # caller's specific result_set_index on every lookup. This is what
            # makes the cache safe for step-based YAMLs that emit multiple
            # result sets per test case.
            if params_hash in self._baseline_rows_cache:
                baseline_rows, col_types = extract_result_set(
                    self._baseline_rows_cache[params_hash], result_set_index,
                )
                source = "cache"
            else:
                baseline_rows, col_types = fetch_baseline_rows(
                    self._connector, database, params_hash,
                    result_set_index=result_set_index,
                    procedure=self._baseline_procedure,
                )
                source = "stage"
            label = "fetch_baseline_rows"
        LOGGER.info("[timing] %s (from %s, %d rows): %.3fs",
                    label, source, len(baseline_rows), time.monotonic() - t0)

        # Isolation is handled by the caller via clone databases — the
        # rendered_sql already targets a disposable clone so EXECUTE AS
        # OWNER side effects never touch the original database.
        cursor = self._connector.connection.cursor()
        actual_rows: list[RowDict] = []
        try:
            t1 = time.monotonic()
            execution_sql = outputs_sql if outputs_only and outputs_sql else rendered_sql
            execution_fetch_stmts = None if outputs_only else fetch_stmts
            execute_with_capture(cursor, execution_sql, execution_fetch_stmts)

            col_names = (
                [d[0] for d in cursor.description] if cursor.description else list(col_types.keys())
            )
            raw_rows = cursor.fetchall() or []
            actual_rows = [dict(zip(col_names, r)) for r in raw_rows]
            LOGGER.info(
                "[timing] execute CALL + fetchall (%d rows): %.3fs",
                len(actual_rows), time.monotonic() - t1,
            )
        except Exception as exc:
            LOGGER.warning("In-memory comparison failed during execution: %s", exc)
            return ComparisonResult(
                match=False,
                match_type="error",
                match_level="in_memory",
                differences=[
                    ValidationDifference(type="ERROR", detail=truncate(str(exc), MAX_ERROR_LENGTH)),
                ],
            )
        finally:
            cursor.close()

        # Snowflake CALL on a non-RETURNS-TABLE procedure always emits a
        # 1-row, 1-column status payload (column == proc short name, or
        # ``ANONYMOUS BLOCK`` when wrapped in a scripting block).  Source
        # dialects whose pure-DML procs return nothing (Teradata's bare
        # ``BEGIN ... DELETE ... END``, T-SQL procs without
        # ``SELECT @@ROWCOUNT``) would otherwise produce a spurious
        # ``baseline=0 actual=1`` row-count diff on every DML case.  Mirrors
        # the v1 ``no_resultset`` short-circuit in
        # :func:`test_runner.validate.runner._validate_case`.  Step-based
        # DML cases follow this with delta validation in
        # ``_validate_step_based_case``, the same way v1 does.
        if (
            not outputs_only
            and len(baseline_rows) == 0
            and is_implicit_snowflake_return(
                col_names, len(actual_rows), self._baseline_procedure,
            )
        ):
            LOGGER.info(
                "Implicit Snowflake CALL return detected for %s "
                "(baseline empty, actual=[{%s: %r}]); skipping result-set "
                "comparison.",
                self._code_unit_name, col_names[0], actual_rows[0].get(col_names[0]),
            )
            result = ComparisonResult(
                match=True,
                match_type="no_resultset",
                match_level="skipped",
                differences=[],
            )
            if dump_baseline_and_actual:
                result.baseline_rows = baseline_rows
                result.actual_rows = actual_rows
            return result

        vc = self._config.validation_configuration or ValidationConfiguration()
        tolerance: float = vc.tolerance
        max_cell_diffs: int = vc.max_cell_diffs

        t2 = time.monotonic()
        diff = compare_in_memory(
            baseline_rows=baseline_rows,
            actual_rows=actual_rows,
            col_types=col_types,
            tolerance=tolerance,
            max_cell_diffs=max_cell_diffs,
            collation=self._collation,
            cmp_ctx=self._cmp_ctx,
        )
        LOGGER.info("[timing] compare_in_memory (duckdb): %.3fs", time.monotonic() - t2)

        human_diffs: list[str] = []
        if not diff["match"]:
            rc = diff["row_counts"]
            if not rc["match"]:
                human_diffs.append(
                    f"row_counts: baseline={rc['baseline']} actual={rc['actual']}"
                )
            for m in diff["summary_stats"]["mismatches"]:
                for metric, vals in m["metrics"].items():
                    human_diffs.append(
                        f"column={m['column']}  metric={metric}"
                        f"  baseline={vals['baseline']}  actual={vals['actual']}"
                    )
            for d in diff["cell_diffs"][:10]:
                human_diffs.append(
                    f"cell diff row={d['row']} col={d['column']} "
                    f"baseline={d['baseline']!r} actual={d['actual']!r}"
                )

        match_type = "data_match" if diff["match"] else (
            "row_count_mismatch" if not diff["row_counts"]["match"] else
            "metrics_mismatch" if diff["summary_stats"]["mismatches"] else
            "data_mismatch"
        )

        result = ComparisonResult(
            match=diff["match"],
            match_type=match_type,
            match_level="in_memory",
            differences=human_diffs,
            in_memory_diff=diff,
        )
        if dump_baseline_and_actual:
            result.baseline_rows = baseline_rows
            result.actual_rows = actual_rows
        return result
