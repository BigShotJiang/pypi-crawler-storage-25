"""
Transient table management for Snowflake-native validation.

Creates and cleans up transient tables for both baseline and actual
result sets so the data-validation framework's ``MetadataExtractorSnowflake``
can query them via SQL.

Baseline tables are built directly from the staged JSON files using
``LATERAL FLATTEN``, avoiding any intermediate table.

When capture or fetch statements are present, the **last** result set
(and its column types) is used for comparison.  For legacy capture
baselines, ``result_sets[0]`` is the OUT row and ``result_sets[-1]`` is
the data.  For template-driven baselines (``output.tables`` /
``output.cursors``), scalar params are in ``output_params`` and each
``result_sets`` entry corresponds to one table or cursor FETCH.
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime as _datetime

from snowflake.connector.cursor import SnowflakeCursor
from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase


from test_runner.common.sql_types import is_numeric_type, is_timestamp_type

LOGGER = logging.getLogger(__name__)

_SCHEMA = "VALIDATION"


def coerce_timestamp(value: object) -> object:
    """Parse ISO 8601 timestamp strings to Python datetime objects.

    Baseline JSON stores datetimes as ISO strings (e.g. ``'2026-01-15T10:30:00'``).
    Snowflake returns ``datetime`` objects for TIMESTAMP columns, which Polars
    infers as ``Datetime`` dtype.  Parsing baseline strings to ``datetime``
    ensures both sides get the same Polars column type, preventing false
    type-mismatch failures in ``validate_cell``.
    """
    if value is None or isinstance(value, _datetime):
        return value
    if isinstance(value, str):
        try:
            return _datetime.fromisoformat(value)
        except (ValueError, TypeError):
            pass
    return value


def coerce_numeric(value: object) -> object:
    """Cast numeric strings to ``int`` or ``float``; return everything else unchanged."""
    if value is None or isinstance(value, (int, float)):
        return value
    s = str(value).strip()
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        return value


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_table_name(database: str, procedure: str, params_hash: str, side: str) -> str:
    """Generate a unique transient table name."""
    safe = procedure.replace(".", "_").replace(" ", "_")[:50].upper()
    return f"{database}.{_SCHEMA}.TEMP_{side}_{safe}_{params_hash}".upper()


def _sql_escape(value: str) -> str:
    """Escape single quotes for safe SQL string interpolation."""
    return value.replace("'", "''")


def _safe_cast_type(typ: str) -> str:
    """Widen bare ``NUMBER`` to ``DOUBLE`` for VARIANT casts.

    Snowflake defaults bare ``NUMBER`` to ``NUMBER(38,0)`` which
    truncates decimals when casting from VARIANT/JSON.  Using ``DOUBLE``
    preserves the original decimal values stored in the baseline JSON
    without imposing a fixed scale that could mismatch the target table's
    native column types.
    """
    if typ.upper() == "NUMBER":
        return "DOUBLE"
    return typ


def _safe_proc_name(procedure: str) -> str:
    """Sanitize procedure name for use in stage paths."""
    return procedure.replace(".", "_").replace(" ", "_").replace("/", "_")


def _ensure_raw_format(cursor: SnowflakeCursor, fq_schema: str) -> str:
    """Create the RAW_TEXT_FORMAT file format if it doesn't exist. Returns the format ref."""
    raw_fmt = f"{fq_schema}.RAW_TEXT_FORMAT"
    cursor.execute(
        f"CREATE FILE FORMAT IF NOT EXISTS {raw_fmt} "
        f"TYPE = CSV FIELD_DELIMITER = NONE RECORD_DELIMITER = NONE"
    )
    return raw_fmt


def _resolve_stage_source(
    connector: ConnectorBase,
    database: str,
    base_stage: str,
    raw_fmt: str,
    procedure: str = "",
) -> str:
    """Resolve the best stage source path for a procedure.

    Returns a SQL FROM clause source (stage path with file format).
    When a procedure is provided and date directories exist, narrows
    to the most recent date/procedure path for performance.
    """
    if procedure:
        date_dirs = _discover_stage_date_dirs(connector, database)
        if date_dirs:
            safe_proc = _safe_proc_name(procedure)
            return f"{base_stage}/{date_dirs[0]}/{safe_proc}/ (FILE_FORMAT => '{raw_fmt}')"

    return f"{base_stage} (FILE_FORMAT => '{raw_fmt}')"



def _query_stage_raw_single(
    cursor: SnowflakeCursor,
    stage_source: str,
    raw_fmt: str,
    base_stage: str,
    params_hash: str,
    procedure: str = "",
) -> tuple | None:
    """Execute a single-row raw text query against the stage. Returns the row or None."""
    # If we're using path-based filtering (stage_source != base_stage), no proc filter needed
    using_path_filter = stage_source != f"{base_stage} (FILE_FORMAT => '{raw_fmt}')"
    proc_filter = ""
    if procedure and not using_path_filter:
        proc_filter = f"\n  AND PARSE_JSON($1):procedure::VARCHAR = '{_sql_escape(procedure)}'"

    cursor.execute(f"""\
SELECT $1 AS raw_text
FROM {stage_source}
WHERE PARSE_JSON($1):params_hash::VARCHAR = '{_sql_escape(params_hash)}'{proc_filter}
LIMIT 1""")
    return cursor.fetchone()


def _query_stage_raw_batch(
    cursor: SnowflakeCursor,
    stage_source: str,
    raw_fmt: str,
    base_stage: str,
    params_hashes: list[str],
    procedure: str = "",
) -> list[tuple]:
    """Execute a batch raw text query against the stage. Returns all rows."""
    using_path_filter = stage_source != f"{base_stage} (FILE_FORMAT => '{raw_fmt}')"
    proc_filter = ""
    if procedure and not using_path_filter:
        proc_filter = f"\n  AND PARSE_JSON($1):procedure::VARCHAR = '{_sql_escape(procedure)}'"

    hash_list = ", ".join(f"'{_sql_escape(h)}'" for h in params_hashes)
    cursor.execute(f"""\
SELECT
    PARSE_JSON($1):params_hash::VARCHAR AS params_hash,
    $1 AS raw_text
FROM {stage_source}
WHERE PARSE_JSON($1):params_hash::VARCHAR IN ({hash_list}){proc_filter}""")
    return cursor.fetchall()


def extract_result_set(
    baseline: dict,
    result_set_index: int = -1,
) -> tuple[list[dict], dict[str, str]]:
    """Extract and normalize rows + col_types from a baseline JSON dict.

    Handles index resolution, dict-vs-list row format, and coerces
    numeric and timestamp values for in-memory comparison.
    """
    result_sets = baseline.get("result_sets", [[]])
    col_types_list: list[dict] = baseline.get("column_types", [{}])

    data_idx = result_set_index if result_set_index >= 0 else (len(result_sets) - 1 if result_sets else 0)
    col_types: dict[str, str] = col_types_list[data_idx] if data_idx < len(col_types_list) else {}
    data_set: list = result_sets[data_idx] if data_idx < len(result_sets) else []

    if not col_types:
        return [], col_types

    if data_set and isinstance(data_set[0], dict):
        rows = [{k.upper(): v for k, v in r.items()} for r in data_set]
    else:
        rows = [dict(zip(col_types.keys(), r)) for r in data_set]

    # Coerce numeric and timestamp columns for consistent comparison
    numeric_cols = {col for col, typ in col_types.items() if is_numeric_type(typ)}
    timestamp_cols = {col for col, typ in col_types.items() if is_timestamp_type(typ)}
    if numeric_cols or timestamp_cols:
        rows = [
            {
                k: (coerce_numeric(v) if k in numeric_cols
                     else coerce_timestamp(v) if k in timestamp_cols
                     else v)
                for k, v in row.items()
            }
            for row in rows
        ]

    return rows, col_types


def _extract_output_params(baseline: dict) -> tuple[list[dict], dict[str, str]]:
    """Extract and normalize output params from a baseline JSON dict."""
    output_params: dict | None = baseline.get("output_params")
    if not output_params:
        return [], {}

    col_types: dict[str, str] = {
        k.upper(): v
        for k, v in (baseline.get("output_param_types") or {}).items()
    }
    if not col_types:
        col_types = {k.upper(): "VARCHAR" for k in output_params.keys()}

    numeric_cols = {col for col, typ in col_types.items() if is_numeric_type(typ)}
    row_data = {
        key.upper(): (coerce_numeric(value) if key.upper() in numeric_cols else value)
        for key, value in output_params.items()
    }
    return [row_data], col_types


# ---------------------------------------------------------------------------
# Materialize baseline directly from stage JSON
# ---------------------------------------------------------------------------

def materialize_baseline_transient_table(
    connector: ConnectorBase,
    database: str,
    procedure: str,
    params_hash: str,
    target_col_types: dict[str, str] | None = None,
    result_set_index: int = -1,
) -> str:
    """Create a transient table from baseline JSON files on the stage.

    Reads the staged baseline as raw text so ``json.loads`` preserves
    the original column order, then uses ``LATERAL FLATTEN`` with
    ``GET_IGNORE_CASE`` to materialize the transient table.

    When *target_col_types* is provided, baseline columns are cast to
    the target table's actual types so the validation framework sees
    matching column types on both sides.

    Returns the fully qualified transient table name.
    """
    table_side = f"SOURCE_S{result_set_index}" if result_set_index >= 0 else "SOURCE"
    table_name = _make_table_name(database, procedure, params_hash, table_side)
    fq = f"{database}.{_SCHEMA}"
    base_stage = f"@{fq}.BASELINES"
    fmt = f"{fq}.JSON_FORMAT"
    file_filter = (
        f"s.$1:params_hash::VARCHAR = '{_sql_escape(params_hash)}'"
        f" AND s.$1:procedure::VARCHAR = '{_sql_escape(procedure)}'"
    )

    cursor = connector.connection.cursor()
    try:
        raw_fmt = _ensure_raw_format(cursor, fq)

        # Use procedure-specific stage path (same as fetch_baseline_rows)
        stage_source = _resolve_stage_source(connector, database, base_stage, raw_fmt, procedure)

        # Now query the narrowed path instead of entire stage
        row = _query_stage_raw_single(cursor, stage_source, raw_fmt, base_stage, params_hash, procedure)
        if row is None:
            LOGGER.warning("No baseline on stage for %s (hash=%s)", procedure, params_hash)
            cursor.execute(
                f"CREATE OR REPLACE TRANSIENT TABLE {table_name} (DUMMY VARCHAR)"
            )
            return table_name

        baseline: dict = json.loads(row[0])
        result_sets = baseline.get("result_sets", [])
        col_types_list: list[dict] = baseline.get("column_types", [{}])

        data_idx = result_set_index if result_set_index >= 0 else (len(result_sets) - 1 if result_sets else 0)
        col_types: dict[str, str] = (
            col_types_list[data_idx] if data_idx < len(col_types_list) else {}
        )

        cast_types = {}
        for col, typ in col_types.items():
            if target_col_types and col in target_col_types:
                cast_types[col] = target_col_types[col]
            else:
                cast_types[col] = _safe_cast_type(typ)

        select_cols = ", ".join(
            f"GET_IGNORE_CASE(f.value, '{col}')"
            f"::{cast_typ} "
            f'AS "{col}"'
            for col, cast_typ in cast_types.items()
        )

        # Extract just the stage path from stage_source (remove FILE_FORMAT clause)
        stage_path = stage_source.split(" (FILE_FORMAT")[0]

        cursor.execute(f"""\
CREATE OR REPLACE TRANSIENT TABLE {table_name} AS
SELECT {select_cols}
FROM {stage_path} (FILE_FORMAT => '{fmt}') s,
LATERAL FLATTEN(input => s.$1:result_sets[{data_idx}]) f
WHERE {file_filter}""")

    finally:
        cursor.close()

    return table_name


# ---------------------------------------------------------------------------
# Materialize actual results via CALL + RESULT_SCAN
# ---------------------------------------------------------------------------

def execute_with_capture(
    cursor: SnowflakeCursor,
    sql: str,
    fetch_stmts: list[str] | None = None,
) -> None:
    """Execute *sql* and optionally run follow-up statements on *cursor*.

    After return the cursor is positioned at the final result set.
    """
    cursor.execute(sql)
    if fetch_stmts:
        for stmt in fetch_stmts:
            cursor.execute(stmt)


def materialize_actual_transient_table(
    connector: ConnectorBase,
    database: str,
    sql: str,
    procedure: str,
    params_hash: str,
    fetch_stmts: list[str] | None = None,
) -> str:
    """Execute a procedure and capture its results into a transient table.

    Returns the fully qualified transient table name.
    """
    table_name = _make_table_name(database, procedure, params_hash, "TARGET")

    cursor = connector.connection.cursor()
    try:
        execute_with_capture(cursor, sql, fetch_stmts)
        query_id = cursor.sfqid
        cursor.execute(
            f"CREATE OR REPLACE TRANSIENT TABLE {table_name} "
            f"AS SELECT * FROM TABLE(RESULT_SCAN('{query_id}'))"
        )
    finally:
        cursor.close()

    return table_name


# ---------------------------------------------------------------------------
# Discover date directories in stage (cached)
# ---------------------------------------------------------------------------

def _discover_stage_date_dirs(connector: ConnectorBase, database: str) -> list[str]:
    """Discover available date directories in the baselines stage.

    Returns date strings in YYYYMMDD format, sorted newest first.
    Caches result per database to avoid repeated LIST queries.
    """
    cache_key = f"_stage_dates_{database}"
    if hasattr(connector, cache_key):
        return getattr(connector, cache_key)

    fq = f"{database}.{_SCHEMA}"
    stage_ref = f"@{fq}.BASELINES"

    try:
        cursor = connector.connection.cursor()
        try:
            cursor.execute(f"LIST {stage_ref}")
            rows = cursor.fetchall()

            date_dirs: list[str] = []
            for row in rows:
                name = row[0] if row else ""
                parts = name.split("/")
                if len(parts) >= 2:
                    potential_date = parts[1]
                    if len(potential_date) == 8 and potential_date.isdigit():
                        if potential_date not in date_dirs:
                            date_dirs.append(potential_date)

            result = sorted(date_dirs, reverse=True)
            LOGGER.debug("Discovered %d date directories in stage: %s", len(result), result)
            setattr(connector, cache_key, result)
            return result
        finally:
            cursor.close()
    except Exception as e:
        LOGGER.warning("Failed to discover date directories in stage: %s", e)
        return []


# ---------------------------------------------------------------------------
# Fetch baseline rows into Python memory (for in-memory validation)
# ---------------------------------------------------------------------------

def fetch_baseline_rows(
    connector: ConnectorBase,
    database: str,
    params_hash: str,
    result_set_index: int = -1,
    procedure: str = "",
) -> tuple[list[dict], dict[str, str]]:
    """Return ``(rows, col_types)`` for the baseline matching *params_hash*.

    Reads the stage JSON directly into Python — no Snowflake objects created.
    Used by the in-memory (DuckDB) comparison path.
    """
    fq = f"{database}.{_SCHEMA}"
    base_stage = f"@{fq}.BASELINES"

    cursor = connector.connection.cursor()
    try:
        t0 = time.monotonic()
        raw_fmt = _ensure_raw_format(cursor, fq)
        LOGGER.info("[timing] CREATE FILE FORMAT: %.3fs", time.monotonic() - t0)

        t1 = time.monotonic()
        stage_source = _resolve_stage_source(connector, database, base_stage, raw_fmt, procedure)
        row = _query_stage_raw_single(cursor, stage_source, raw_fmt, base_stage, params_hash, procedure)
        LOGGER.info("[timing] stage SELECT (fetch baseline JSON): %.3fs", time.monotonic() - t1)

        if row is None:
            LOGGER.warning("No baseline on stage for hash=%s, procedure=%s", params_hash, procedure)
            return [], {}

        baseline: dict = json.loads(row[0])
        return extract_result_set(baseline, result_set_index)
    finally:
        cursor.close()


def fetch_baseline_output_rows(
    connector: ConnectorBase,
    database: str,
    params_hash: str,
    procedure: str = "",
) -> tuple[list[dict], dict[str, str]]:
    """Return ``(rows, col_types)`` for baseline output params."""
    fq = f"{database}.{_SCHEMA}"
    base_stage = f"@{fq}.BASELINES"

    cursor = connector.connection.cursor()
    try:
        raw_fmt = _ensure_raw_format(cursor, fq)
        stage_source = _resolve_stage_source(connector, database, base_stage, raw_fmt, procedure)
        row = _query_stage_raw_single(cursor, stage_source, raw_fmt, base_stage, params_hash, procedure)

        if row is None:
            LOGGER.warning("No baseline on stage for output params hash=%s, procedure=%s", params_hash, procedure)
            return [], {}

        baseline: dict = json.loads(row[0])
        return _extract_output_params(baseline)
    finally:
        cursor.close()


# ---------------------------------------------------------------------------
# Batch fetch baseline rows (for multiple test cases)
# ---------------------------------------------------------------------------

def fetch_baseline_jsons_batch(
    connector: ConnectorBase,
    database: str,
    params_hashes: list[str],
    procedure: str = "",
) -> dict[str, dict]:
    """Batch fetch raw baseline JSONs for multiple params_hash values.

    Returns dict mapping params_hash -> raw baseline JSON (decoded). Result-set
    extraction is intentionally deferred to the caller via
    :func:`extract_result_set` so that the same cached entry can serve multiple
    per-step comparisons that each need a different ``result_set_index``.
    """
    if not params_hashes:
        return {}

    fq = f"{database}.{_SCHEMA}"
    base_stage = f"@{fq}.BASELINES"

    cursor = connector.connection.cursor()
    try:
        t0 = time.monotonic()
        raw_fmt = _ensure_raw_format(cursor, fq)
        LOGGER.info("[timing] CREATE FILE FORMAT: %.3fs", time.monotonic() - t0)

        t1 = time.monotonic()
        stage_source = _resolve_stage_source(connector, database, base_stage, raw_fmt, procedure)
        fetched_rows = _query_stage_raw_batch(cursor, stage_source, raw_fmt, base_stage, params_hashes, procedure)
        LOGGER.info("[timing] stage SELECT (batch fetch %d baselines): %.3fs",
                    len(params_hashes), time.monotonic() - t1)

        LOGGER.info("Fetched %d baseline files from stage", len(fetched_rows))

        result: dict[str, dict] = {}
        for row in fetched_rows:
            ph = row[0]
            result[ph] = json.loads(row[1])

        return result
    finally:
        cursor.close()


def fetch_baseline_output_rows_batch(
    connector: ConnectorBase,
    database: str,
    params_hashes: list[str],
    procedure: str = "",
) -> dict[str, tuple[list[dict], dict[str, str]]]:
    """Batch fetch baseline output params for multiple params_hash values.

    Returns dict mapping params_hash -> (rows, col_types).
    """
    if not params_hashes:
        return {}

    fq = f"{database}.{_SCHEMA}"
    base_stage = f"@{fq}.BASELINES"

    cursor = connector.connection.cursor()
    try:
        raw_fmt = _ensure_raw_format(cursor, fq)
        stage_source = _resolve_stage_source(connector, database, base_stage, raw_fmt, procedure)
        fetched_rows = _query_stage_raw_batch(cursor, stage_source, raw_fmt, base_stage, params_hashes, procedure)

        result: dict[str, tuple[list[dict], dict[str, str]]] = {}
        for row in fetched_rows:
            ph = row[0]
            baseline: dict = json.loads(row[1])
            result[ph] = _extract_output_params(baseline)

        return result
    finally:
        cursor.close()


# ---------------------------------------------------------------------------
# Materialize output parameters -- baseline (from staged JSON)
# ---------------------------------------------------------------------------

def materialize_baseline_output_params_table(
    connector: ConnectorBase,
    database: str,
    procedure: str,
    params_hash: str,
) -> str | None:
    """Create a single-row transient table from baseline ``output_params``.

    Returns ``None`` if the baseline has no output params.
    """
    table_name = _make_table_name(database, procedure, params_hash, "SOURCE_OUTPUTS")
    fq = f"{database}.{_SCHEMA}"
    stage = f"@{fq}.BASELINES"

    cursor = connector.connection.cursor()
    try:
        raw_fmt = _ensure_raw_format(cursor, fq)
        cursor.execute(f"""\
SELECT $1 AS raw_text
FROM {stage} (FILE_FORMAT => '{raw_fmt}')
WHERE PARSE_JSON($1):params_hash::VARCHAR = '{_sql_escape(params_hash)}'
  AND PARSE_JSON($1):procedure::VARCHAR = '{_sql_escape(procedure)}'
LIMIT 1""")
        row = cursor.fetchone()
        if row is None:
            return None

        baseline: dict = json.loads(row[0])
        output_params: dict | None = baseline.get("output_params")
        if not output_params:
            return None

        stored_types: dict[str, str] = {
            k.upper(): v
            for k, v in (baseline.get("output_param_types") or {}).items()
        }

        col_expressions: list[str] = []
        for k, v in output_params.items():
            col_upper = k.upper()
            cast_type = stored_types.get(col_upper, "VARCHAR")
            if v is None:
                col_expressions.append(f"NULL::{cast_type} AS \"{col_upper}\"")
            elif isinstance(v, str):
                escaped = v.replace("'", "''")
                col_expressions.append(
                    f"'{escaped}'::{cast_type} AS \"{col_upper}\""
                )
            else:
                col_expressions.append(
                    f"{v}::{cast_type} AS \"{col_upper}\""
                )

        columns = ", ".join(col_expressions)
        cursor.execute(
            f"CREATE OR REPLACE TRANSIENT TABLE {table_name} AS SELECT {columns}"
        )
        return table_name
    finally:
        cursor.close()


# ---------------------------------------------------------------------------
# Materialize output parameters -- actual (via anonymous block)
# ---------------------------------------------------------------------------

def materialize_actual_output_params_table(
    connector: ConnectorBase,
    database: str,
    outputs_sql: str,
    procedure: str,
    params_hash: str,
) -> str:
    """Execute a Snowflake anonymous block and capture output params.

    Returns the fully qualified transient table name.
    """
    table_name = _make_table_name(database, procedure, params_hash, "TARGET_OUTPUTS")

    cursor = connector.connection.cursor()
    try:
        cursor.execute(outputs_sql)
        query_id = cursor.sfqid
        cursor.execute(
            f"CREATE OR REPLACE TRANSIENT TABLE {table_name} "
            f"AS SELECT * FROM TABLE(RESULT_SCAN('{query_id}'))"
        )
    finally:
        cursor.close()

    return table_name


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def drop_transient_tables(connector: ConnectorBase, *table_names: str) -> None:
    """Drop transient tables, ignoring errors."""
    for name in table_names:
        try:
            connector.execute_statement(f"DROP TABLE IF EXISTS {name}")
        except Exception:
            pass
