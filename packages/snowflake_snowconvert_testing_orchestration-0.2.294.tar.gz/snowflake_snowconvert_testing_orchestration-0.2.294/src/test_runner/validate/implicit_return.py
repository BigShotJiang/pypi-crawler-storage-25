"""Snowflake CALL implicit-return detection.

Snowflake SQL Script procedures whose RETURNS clause is *not* a TABLE always
emit a single-row, single-column status payload from ``CALL`` — the column is
named after the procedure's short name (uppercased), or ``ANONYMOUS BLOCK``
when the CALL is wrapped in a scripting block.

This is dialect-asymmetric: source dialects like Teradata return *nothing* for
pure-DML procs (no body ``SELECT``), while Snowflake's converted procs still
emit the implicit-return row.  Without compensation, every DML procedure would
produce a spurious ``baseline=0 actual=1`` row-count diff.

The check here is a precise observable on the Snowflake actual payload — it
never neutralises real result-set data, because real result-sets either have
more than one row/column or a column name distinct from the proc.
"""

from __future__ import annotations


def is_implicit_snowflake_return(
    col_names: list[str],
    row_count: int,
    procedure: str,
) -> bool:
    """True iff the result set looks like Snowflake's implicit CALL return.

    Parameters
    ----------
    col_names
        Column names from the cursor description (in declaration order).
    row_count
        Number of rows fetched from the cursor.
    procedure
        Fully-qualified procedure name (``db.schema.name``) or short name.
        Only the trailing segment after the last ``.`` is compared.
    """
    if row_count != 1 or len(col_names) != 1:
        return False
    col = col_names[0].upper()
    short_name = procedure.rsplit(".", 1)[-1].upper()
    return col == short_name or col == "ANONYMOUS BLOCK"
