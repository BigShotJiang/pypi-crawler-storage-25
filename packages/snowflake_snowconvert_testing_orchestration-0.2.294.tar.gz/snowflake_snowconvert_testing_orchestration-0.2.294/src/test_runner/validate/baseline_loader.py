"""
Baseline loading strategies (OCP: open for extension via new loaders).

Each loader implements :class:`BaselineLoader` and knows how to load
baselines from a single source.  The :func:`create_baseline_loader`
factory selects the appropriate loader based on the configuration.

The actual baseline *data* for Snowflake comparison is read directly
from the stage by ``materialize_baseline_transient_table`` at comparison
time.  The loader only needs to discover which baselines exist and
their success/error status.
"""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Optional

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase

from test_runner.common.baseline import discover_baselines, discover_baselines_per_object, load_baseline
from test_runner.common.models import BaselineData
from test_runner.validate.transient_table_manager import (
    _discover_stage_date_dirs,
    _safe_proc_name,
)

LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Abstract loader
# ---------------------------------------------------------------------------

class BaselineLoader(ABC):
    """Loads baselines from a single source."""

    @abstractmethod
    def load(self) -> list[BaselineData]:
        """Load all available baselines from this source."""

    @property
    @abstractmethod
    def source_label(self) -> str:
        """Human-readable label describing this baseline source."""


# ---------------------------------------------------------------------------
# Disk loader (offline / testing)
# ---------------------------------------------------------------------------

class DiskBaselineLoader(BaselineLoader):
    """Load baselines from local JSON files on disk."""

    def __init__(self, baseline_dir: Path, per_object: bool = False) -> None:
        self._baseline_dir = baseline_dir
        self._per_object = per_object

    def load(self) -> list[BaselineData]:
        paths = (
            discover_baselines_per_object(self._baseline_dir)
            if self._per_object
            else discover_baselines(self._baseline_dir)
        )
        baselines: list[BaselineData] = []
        for path in paths:
            bl = load_baseline(path)
            if bl is not None:
                baselines.append(bl)
        return baselines

    @property
    def source_label(self) -> str:
        return f"{self._baseline_dir} (local)"


# ---------------------------------------------------------------------------
# Stage loader
# ---------------------------------------------------------------------------

def _parse_variant(raw: Any) -> Optional[dict[str, Any]]:
    """Parse a Snowflake VARIANT value into a Python dict.

    The connector may return VARIANT as a JSON string or as a dict
    depending on the driver version and result format.
    """
    if raw is None:
        return None
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else None
        except (ValueError, TypeError):
            return None
    return None


class StageBaselineLoader(BaselineLoader):
    """Load baseline metadata and deltas from the implicit Snowflake stage.

    The stage is ``@{validation_database}.VALIDATION.BASELINES``.
    Metadata (procedure, params_hash, success, error, row_counts) and
    ``table_deltas`` (for DML validation) are loaded here.  The actual
    result-set row data is read directly from the stage at comparison
    time by ``materialize_baseline_transient_table``.
    """

    _STAGE_NAME = "BASELINES"
    _STAGE_SELECT_PROJECTION = """\
    $1:procedure::VARCHAR AS procedure_name,
    $1:params_hash::VARCHAR AS params_hash,
    $1:parameters AS params,
    $1:captured_at::VARCHAR AS captured_at,
    $1:success::BOOLEAN AS success,
    $1:error::VARCHAR AS error,
    $1:row_counts::ARRAY AS row_counts,
    $1:table_deltas AS table_deltas,
    $1:column_metadata AS column_metadata"""
    _infrastructure_ensured: set[tuple[str, str]] = set()  # Class-level cache: (database, schema)

    def __init__(
        self,
        connector: ConnectorBase,
        database: str,
        procedures: Optional[list[str]] = None,
    ) -> None:
        self._connector = connector
        self._database = database
        self._procedures = procedures
        self._fq_schema = f"{self._database}.VALIDATION"
        self._stage_ref = f"@{self._fq_schema}.{self._STAGE_NAME}"
        LOGGER.info("StageBaselineLoader initialized: database=%s, stage=%s, procedures=%s",
                    self._database, self._stage_ref, procedures)

    def load(self) -> list[BaselineData]:
        self._ensure_infrastructure()

        # Try loading from metadata table first (fast: ~0.5s)
        baselines = self._load_from_table()
        if baselines:
            LOGGER.info("Loaded %d baselines from metadata table", len(baselines))
            return baselines

        # Fall back to stage query (slow: ~3-4s)
        LOGGER.info("Metadata table empty or unavailable, falling back to stage query")
        return self._load_from_stage()

    def _load_from_table(self) -> list[BaselineData]:
        """Load baseline metadata from VALIDATION.BASELINE_METADATA table (fast).

        Returns empty list if table doesn't exist or query fails.
        """
        table_name = f"{self._fq_schema}.BASELINE_METADATA"

        try:
            # Build query with procedure filtering if specified
            if self._procedures:
                proc_filter = "WHERE procedure IN (" + ", ".join(f"'{p}'" for p in self._procedures) + ")"
            else:
                proc_filter = ""

            query = f"""
                SELECT
                    procedure,
                    params_hash,
                    parameters,
                    captured_at,
                    success,
                    error,
                    row_counts,
                    table_deltas,
                    column_metadata
                FROM {table_name}
                {proc_filter}
            """

            LOGGER.info("Loading baselines from metadata table: %s", table_name)
            LOGGER.debug("Table query: %s", query)

            rows = self._connector.execute_query(query)

            if not rows:
                LOGGER.info("No baselines found in metadata table")
                return []

            return self._parse_baseline_rows(rows)

        except Exception as e:
            LOGGER.debug("Metadata table query failed: %s", e)
            return []

    def _load_from_stage(self) -> list[BaselineData]:
        """Load baseline metadata directly from the stage files."""
        fmt_ref = f"{self._fq_schema}.JSON_FORMAT"

        # Use path-based filtering when procedures are specified for performance
        if self._procedures:
            LOGGER.info("Using path-based filtering for %d procedures", len(self._procedures))
            query = self._build_path_filtered_query(fmt_ref)
        else:
            # Original behavior: query all files (slower with many files)
            query = f"""\
SELECT
{self._STAGE_SELECT_PROJECTION}
FROM {self._stage_ref} (FILE_FORMAT => '{fmt_ref}')"""

        LOGGER.info("Loading baselines from stage: %s", self._stage_ref)
        LOGGER.debug("Stage query: %s", query)

        try:
            rows = self._connector.execute_query(query)
        except Exception as e:
            LOGGER.error("Stage query failed for %s: %s", self._stage_ref, e)
            print(f"Warning: Stage query failed: {e}")
            return []

        if not rows:
            LOGGER.info("No baselines found in stage %s", self._stage_ref)
            return []

        LOGGER.info("Found %d baseline files in stage", len(rows))
        return self._parse_baseline_rows(rows)

    def _parse_baseline_rows(self, rows: list[dict]) -> list[BaselineData]:
        """Parse baseline metadata rows into BaselineData objects."""
        baselines: list[BaselineData] = []
        for row in rows:
            try:
                # Handle both table columns (lowercase) and stage file columns (mixed case)
                params_raw = row.get("PARAMETERS") or row.get("parameters") or row.get("PARAMS") or row.get("params") or "{}"
                params = json.loads(params_raw) if isinstance(params_raw, str) else params_raw

                row_counts_raw = row.get("ROW_COUNTS") or row.get("row_counts")
                if row_counts_raw is not None:
                    try:
                        row_counts = json.loads(row_counts_raw) if isinstance(row_counts_raw, str) else list(row_counts_raw)
                    except (ValueError, TypeError):
                        row_counts = []
                else:
                    row_counts = []

                table_deltas = _parse_variant(
                    row.get("TABLE_DELTAS") or row.get("table_deltas")
                )

                col_meta_raw = _parse_variant(
                    row.get("COLUMN_METADATA") or row.get("column_metadata")
                )

                bl = BaselineData(
                    procedure=row.get("PROCEDURE") or row.get("procedure") or row.get("PROCEDURE_NAME") or row.get("procedure_name", ""),
                    parameters=params if isinstance(params, dict) else {},
                    captured_at=row.get("CAPTURED_AT") or row.get("captured_at", ""),
                    result_sets=[],
                    row_counts=row_counts,
                    success=row.get("SUCCESS", True) if row.get("SUCCESS") is not None else row.get("success", True),
                    error=row.get("ERROR") or row.get("error"),
                    stored_params_hash=row.get("PARAMS_HASH") or row.get("params_hash"),
                    table_deltas=table_deltas,
                    column_metadata=col_meta_raw,
                )
                baselines.append(bl)
            except Exception as exc:
                print(f"Warning: failed to parse baseline: {exc}")

        return baselines

    def _build_path_filtered_query(self, fmt_ref: str) -> str:
        """Build a UNION ALL query for procedure-specific paths."""
        from datetime import datetime

        date_dirs = _discover_stage_date_dirs(self._connector, self._database)
        if not date_dirs:
            date_dirs = [datetime.now().strftime("%Y%m%d")]

        queries = []
        for date_dir in date_dirs:
            for proc in self._procedures:
                safe_proc = _safe_proc_name(proc)
                proc_path = f"{self._stage_ref}/{date_dir}/{safe_proc}/"

                queries.append(f"""\
SELECT
{self._STAGE_SELECT_PROJECTION}
FROM {proc_path} (FILE_FORMAT => '{fmt_ref}')""")

        return "\nUNION ALL\n".join(queries)

    def _ensure_infrastructure(self) -> None:
        """Create database, schema, stage, and file format if they don't exist.

        Uses class-level cache to skip redundant CREATE IF NOT EXISTS calls
        after the first successful run, avoiding ~2.6s overhead per validation.
        """
        cache_key = (self._database, self._fq_schema)
        if cache_key in StageBaselineLoader._infrastructure_ensured:
            LOGGER.debug("Skipping infrastructure setup (already ensured): %s", cache_key)
            return

        LOGGER.debug("Ensuring infrastructure exists: %s", cache_key)
        stmts = [
            f"CREATE DATABASE IF NOT EXISTS {self._database}",
            f"CREATE SCHEMA IF NOT EXISTS {self._fq_schema}",
            f"CREATE STAGE IF NOT EXISTS {self._fq_schema}.{self._STAGE_NAME} "
            f"COMMENT = 'Baseline JSON files'",
            f"CREATE FILE FORMAT IF NOT EXISTS {self._fq_schema}.JSON_FORMAT "
            f"TYPE = 'JSON'",
        ]
        for sql in stmts:
            try:
                self._connector.execute_statement(sql)
            except Exception:
                pass

        # Mark as ensured after successful completion
        StageBaselineLoader._infrastructure_ensured.add(cache_key)

    @property
    def source_label(self) -> str:
        return f"{self._stage_ref} (stage)"


# ---------------------------------------------------------------------------
# Factory function
# ---------------------------------------------------------------------------

def create_baseline_loader(
    connector: Optional[ConnectorBase],
    database: str,
    baseline_stage: Optional[str],
    project_root: Path,
    procedures: Optional[list[str]] = None,
) -> BaselineLoader:
    """Select the appropriate baseline loader based on configuration.

    When a Snowflake connector is available the implicit stage
    ``@{database}.VALIDATION.BASELINES`` is used.  Falls back to
    local disk (``artifacts/`` per-object structure) for offline /
    testing scenarios.

    Args:
        connector: Snowflake connector for stage access
        database: Validation database name
        baseline_stage: Stage reference (currently unused, uses implicit stage)
        project_root: Project root directory
        procedures: Optional list of procedure names for path-based filtering
    """
    if connector is not None:
        stage_loader = StageBaselineLoader(connector, database, procedures=procedures)
        baselines = stage_loader.load()
        if baselines:
            return _PreloadedLoader(baselines, stage_loader.source_label)

    artifacts_dir = project_root / "artifacts"
    loader = DiskBaselineLoader(artifacts_dir, per_object=True)
    baselines = loader.load()

    if baselines:
        return _PreloadedLoader(baselines, loader.source_label)

    return loader


class _PreloadedLoader(BaselineLoader):
    """Wraps already-loaded baselines to avoid loading twice."""

    def __init__(self, baselines: list[BaselineData], label: str) -> None:
        self._baselines = baselines
        self._label = label

    def load(self) -> list[BaselineData]:
        return self._baselines

    @property
    def source_label(self) -> str:
        return self._label
