"""Server-side delta capture for source databases."""
