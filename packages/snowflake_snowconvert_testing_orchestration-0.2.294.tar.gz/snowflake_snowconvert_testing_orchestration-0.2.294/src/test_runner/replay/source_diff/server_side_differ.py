"""ServerSideDiffer abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..models import RowDict, TableConfig


class ServerSideDiffer(ABC):
    """Compute delta dicts entirely on the source database.

    Pushes the actual delta computation into the source database (where
    the data already lives), so that only delta rows transit the wire
    from Source DB to test-runner. Today's pre-existing path snapshots
    both before and after states and computes the diff in client-side
    Python (DuckDB strategies, or the two-pass hash optimization in
    ``replay/delta_capture.py`` -- still client-assembled).

    Concrete implementations live in dialect-specific modules
    (e.g. :mod:`.sqlserver_diff`) and are wired into
    ``DatabaseExecutorFactory.create_source_differ()``.

    Variant locked at the Stage 1 decision gate: **B (column-pruned
    wire, full dict shape)**. The differ ships a column-pruned payload
    over the wire (only PK + changed cells per updated row, with
    unchanged cells shipped once for reuse) and the Python side
    reconstructs full ``before``/``after`` dicts so the existing
    comparator and baseline format remain unchanged.

    A differ is responsible for:

    1. Materializing a before-snapshot into a sibling table on the
       source (without fetching it to Python).
    2. Computing the delta server-side after the procedure executes,
       returning only delta rows over the wire.
    3. Cleaning up its sibling tables.

    All FQNs are 3-part ``[database].[schema].[table]`` strings; the
    differ never assumes a current-DB session context. The connector
    wrapper used in production has unreliable ``USE`` propagation
    across cursor and commit boundaries (observed during the Stage 1
    spike), so database-qualified identifiers are load-bearing.
    """

    @abstractmethod
    def snapshot_to_diff_table(
        self,
        connection: Any,
        database: str,
        schema: str,
        table: str,
        all_columns: list[str],
        has_pk: bool,
    ) -> str:
        """Materialize the before-snapshot of ``[database].[schema].[table]``
        into a sibling table on the same source.

        When ``has_pk`` is False, the differ projects synthetic-key columns
        inline so a no-PK table can still be diffed via composite synth PK.

        Returns the FQN of the diff table the differ created.
        """

    @abstractmethod
    def diff(
        self,
        connection: Any,
        table_cfg: TableConfig,
        database: str,
        all_columns: list[str],
    ) -> dict[str, Any]:
        """Compute the delta and return a ``make_delta``-shaped dict.

        Dispatches to :meth:`diff_with_pk` when ``table_cfg`` has primary
        key columns, otherwise to :meth:`diff_with_synthetic_pk`.
        """

    @abstractmethod
    def diff_with_pk(
        self,
        connection: Any,
        before_fqn: str,
        after_fqn: str,
        pk_columns: list[str],
        all_columns: list[str],
    ) -> tuple[list[RowDict], list[RowDict], list[dict[str, Any]]]:
        """Server-side anti-join + hash-compare diff using the table's PK.

        Returns ``(inserts, deletes, updates)`` where:

        - ``inserts`` and ``deletes`` are full row dicts.
        - ``updates`` is a list of ``make_update_pair``-shaped dicts with
          full ``before`` and ``after`` (Variant B reconstructs unchanged
          cells from a single-shipped value).
        """

    @abstractmethod
    def diff_with_synthetic_pk(
        self,
        connection: Any,
        before_fqn: str,
        after_fqn: str,
        all_columns: list[str],
    ) -> tuple[list[RowDict], list[RowDict], list[dict[str, Any]]]:
        """Server-side diff for tables without a real PK.

        Joins on a composite synthetic key projected inline from a hash
        of all columns plus a duplicate-row sequence number. Promotes
        delete+insert pairs into updates via the production
        ``_infer_updates_from_pairs`` helper.
        """

    @abstractmethod
    def drop_diff_table(self, connection: Any, fqn: str) -> None:
        """Drop the diff table at ``fqn``. Never raises on missing table."""
