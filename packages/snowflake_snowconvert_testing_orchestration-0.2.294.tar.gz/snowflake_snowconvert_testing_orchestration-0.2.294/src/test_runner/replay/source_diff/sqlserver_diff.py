"""SQL Server implementation of :class:`ServerSideDiffer`.

Variant B (column-pruned wire, full dict shape). Single CTE query per
delta section, returning per updated row:

  PK + (changed_cells_before, changed_cells_after) + unchanged_cells_once

Unchanged cells appear once per updated row because they are by
definition equal in before and after. Python uses that single value to
populate both ``update.before[col]`` and ``update.after[col]`` so the
output dict shape matches production ``make_update_pair``.

Concrete projection per non-PK column:

  - ``[col]__B``: before-value when changed, NULL when unchanged
  - ``[col]__A``: after-value when changed, NULL when unchanged
  - ``[col]__U``: shared value when unchanged, NULL when changed

For SQL Server pre-2022 (which lacks ``IS DISTINCT FROM``), the
distinct-from predicate is rewritten to the ANSI-equivalent form. See
:func:`_replace_is_distinct_from`.

For tables without a real PK, :meth:`SqlServerDiffer.diff_with_synthetic_pk`
projects a synthetic ``__SYNTH_KEY__`` (HASHBYTES SHA2_256 over all
columns) plus ``__SYNTH_DUP_SEQ__`` (ROW_NUMBER over hash partition) inline
and joins on the composite. Update inference reuses the production
:func:`_infer_updates_from_pairs` helper from
``replay.strategies.synthetic_key`` to stay byte-identical to
``SyntheticKeyStrategy``.

3-part FQNs (``[database].[schema].[table]``) are used everywhere; this
differ never depends on the connection's current-DB context.
"""

from __future__ import annotations

import re
from typing import Any

from ..models import (
    DeltaStrategy,
    RowDict,
    TableConfig,
    make_delta,
    make_update_pair,
)
from ..source_introspector import SqlServerIntrospector
from ..strategies.synthetic_key import _infer_updates_from_pairs
from .server_side_differ import ServerSideDiffer


DIFF_BEFORE_SUFFIX = "__SCAI_DIFF_BEFORE"
SYNTH_KEY_COL = "__SYNTH_KEY__"
SYNTH_DUP_SEQ_COL = "__SYNTH_DUP_SEQ__"

_IS_DISTINCT_FROM = re.compile(
    r'(?P<left>(?:\w+\.)?(?:\[[^\]]*\]|\w+))'
    r'\s+IS\s+DISTINCT\s+FROM\s+'
    r'(?P<right>(?:\w+\.)?(?:\[[^\]]*\]|\w+))',
    re.IGNORECASE,
)


def _qualified_name(database: str, schema: str, table: str) -> str:
    """Return a 3-part bracketed identifier ``[db].[schema].[table]``."""
    return f"[{database}].[{schema}].[{table}]"


def _diff_table_name(database: str, schema: str, table: str) -> str:
    """FQN for the sibling diff table created during ``snapshot_to_diff_table``."""
    return _qualified_name(database, schema, f"{table}{DIFF_BEFORE_SUFFIX}")


def _drop_table_if_exists_sql(fqn: str) -> str:
    """SQL Server ``DROP TABLE IF EXISTS`` via ``OBJECT_ID``.

    Accepts a 3-part bracketed FQN; OBJECT_ID is given the unbracketed
    form (it expects the dotted name without quoting). Single quotes
    inside the identifier are doubled per T-SQL string-literal escaping
    so the OBJECT_ID literal stays well-formed for unusual names.
    """
    unbracketed = fqn.replace("[", "").replace("]", "").replace("'", "''")
    return f"IF OBJECT_ID('{unbracketed}', 'U') IS NOT NULL DROP TABLE {fqn}"


def _replace_is_distinct_from(sql: str) -> str:
    """Rewrite ``X IS DISTINCT FROM Y`` to an ANSI-safe equivalent for
    SQL Server versions older than 2022 which lack the operator.

    ``X IS DISTINCT FROM Y`` is true exactly when ``X != Y`` treating two
    NULLs as equal but a NULL on one side as different. The rewrite:

    ``(X <> Y OR X IS NULL OR Y IS NULL) AND NOT (X IS NULL AND Y IS NULL)``

    Idempotent: applying twice produces the same string as applying once.
    """
    def _sub(m: re.Match) -> str:
        left, right = m.group("left"), m.group("right")
        return (
            f"(({left} <> {right} OR {left} IS NULL OR {right} IS NULL) "
            f"AND NOT ({left} IS NULL AND {right} IS NULL))"
        )
    return _IS_DISTINCT_FROM.sub(_sub, sql)


def _hash_expr_on_alias(hash_expr: str, alias: str) -> str:
    """Rewrite a hash expression so column refs are prefixed with an alias.

    :func:`SqlServerIntrospector.hash_row_expression` emits column refs as
    double-quoted identifiers (``"col"``). When the expression is used in
    a JOIN where the same column name appears in two tables, we need to
    qualify each ref with the table alias.
    """
    return re.sub(r'"([^"]+)"', rf'{alias}.[\1]', hash_expr)


def _fetch_rows(cursor: Any) -> list[RowDict]:
    """Fetch all rows from the last-executed cursor as ``RowDict``s with
    uppercase column names. Binary columns are hex-encoded for parity
    with :func:`replay.delta_capture.snapshot_table`.
    """
    columns = [desc[0].upper() for desc in cursor.description]
    rows: list[RowDict] = []
    for raw in cursor.fetchall():
        row: RowDict = {}
        for col, val in zip(columns, raw):
            row[col] = val.hex() if isinstance(val, (bytes, bytearray)) else val
        rows.append(row)
    return rows


class SqlServerDiffer(ServerSideDiffer):
    """SQL Server differ. See module docstring for SQL shape and rationale."""

    def _run_query_to_rows(self, connection: Any, sql: str) -> list[RowDict]:
        """Open a fresh cursor, execute one statement, fetch all rows."""
        cursor = connection.cursor()
        try:
            cursor.execute(sql)
            return _fetch_rows(cursor)
        finally:
            cursor.close()

    def snapshot_to_diff_table(
        self,
        connection: Any,
        database: str,
        schema: str,
        table: str,
        all_columns: list[str],
        has_pk: bool,
    ) -> str:
        diff_fqn = _diff_table_name(database, schema, table)
        source_fqn = _qualified_name(database, schema, table)

        cursor = connection.cursor()
        try:
            cursor.execute(_drop_table_if_exists_sql(diff_fqn))
            if has_pk:
                cursor.execute(f"SELECT * INTO {diff_fqn} FROM {source_fqn}")
            else:
                introspector = SqlServerIntrospector()
                hash_expr = introspector.hash_row_expression(all_columns) or ""
                col_list = ", ".join(f"[{c}]" for c in all_columns)
                cursor.execute(
                    f"SELECT {col_list}, "
                    f"{hash_expr} AS [{SYNTH_KEY_COL}], "
                    f"ROW_NUMBER() OVER ("
                    f"PARTITION BY {hash_expr} "
                    f"ORDER BY (SELECT NULL)"
                    f") AS [{SYNTH_DUP_SEQ_COL}] "
                    f"INTO {diff_fqn} FROM {source_fqn}"
                )
        finally:
            cursor.close()
        return diff_fqn

    def diff(
        self,
        connection: Any,
        table_cfg: TableConfig,
        database: str,
        all_columns: list[str],
    ) -> dict[str, Any]:
        before_fqn = _diff_table_name(
            database, table_cfg.schema_name, table_cfg.table_name,
        )
        after_fqn = _qualified_name(
            database, table_cfg.schema_name, table_cfg.table_name,
        )

        if table_cfg.primary_key_columns:
            inserts, deletes, updates = self.diff_with_pk(
                connection, before_fqn, after_fqn,
                table_cfg.primary_key_columns, all_columns,
            )
            strategy = DeltaStrategy.PK_DIFF
        else:
            inserts, deletes, updates = self.diff_with_synthetic_pk(
                connection, before_fqn, after_fqn, all_columns,
            )
            strategy = DeltaStrategy.SYNTHETIC_KEY

        return make_delta(
            table_cfg.fqn, strategy_used=strategy,
            inserts=inserts, deletes=deletes, updates=updates,
        )

    def diff_with_pk(
        self,
        connection: Any,
        before_fqn: str,
        after_fqn: str,
        pk_columns: list[str],
        all_columns: list[str],
    ) -> tuple[list[RowDict], list[RowDict], list[dict[str, Any]]]:
        if not pk_columns:
            raise ValueError(
                "diff_with_pk requires at least one PK column. "
                "Use diff_with_synthetic_pk for tables without a PK."
            )

        non_pk_cols = [c for c in all_columns if c not in pk_columns]

        introspector = SqlServerIntrospector()
        hash_expr = introspector.hash_row_expression(non_pk_cols) or ""

        pk_on = " AND ".join(f"a.[{c}] = b.[{c}]" for c in pk_columns)
        pk_order_a = ", ".join(f"a.[{c}]" for c in pk_columns)
        pk_order_b = ", ".join(f"b.[{c}]" for c in pk_columns)
        all_cols_a = ", ".join(f"a.[{c}]" for c in all_columns)
        all_cols_b = ", ".join(f"b.[{c}]" for c in all_columns)

        # Inserts: rows in live with no matching PK in before
        inserts_sql = (
            f"SELECT {all_cols_a} "
            f"FROM {after_fqn} a "
            f"LEFT JOIN {before_fqn} b ON {pk_on} "
            f"WHERE b.[{pk_columns[0]}] IS NULL "
            f"ORDER BY {pk_order_a}"
        )

        # Deletes: rows in before with no matching PK in live
        deletes_sql = (
            f"SELECT {all_cols_b} "
            f"FROM {before_fqn} b "
            f"LEFT JOIN {after_fqn} a ON {pk_on} "
            f"WHERE a.[{pk_columns[0]}] IS NULL "
            f"ORDER BY {pk_order_b}"
        )

        # Updates: matching PK, differing hash. Variant B projection.
        update_projections: list[str] = [f"a.[{c}]" for c in pk_columns]
        for col in non_pk_cols:
            update_projections.append(
                f"CASE WHEN b.[{col}] IS DISTINCT FROM a.[{col}] "
                f"THEN b.[{col}] ELSE NULL END AS [{col}__B]"
            )
            update_projections.append(
                f"CASE WHEN b.[{col}] IS DISTINCT FROM a.[{col}] "
                f"THEN a.[{col}] ELSE NULL END AS [{col}__A]"
            )
            update_projections.append(
                f"CASE WHEN b.[{col}] IS DISTINCT FROM a.[{col}] "
                f"THEN NULL ELSE b.[{col}] END AS [{col}__U]"
            )

        updates_sql = _replace_is_distinct_from(
            f"SELECT {', '.join(update_projections)} "
            f"FROM {before_fqn} b "
            f"INNER JOIN {after_fqn} a ON {pk_on} "
            f"WHERE {_hash_expr_on_alias(hash_expr, 'b')} "
            f"<> {_hash_expr_on_alias(hash_expr, 'a')} "
            f"ORDER BY {pk_order_a}"
        )

        # Use a fresh cursor per query. Reusing a single cursor across
        # multiple SELECTs has surprised us in the past on driver quirks
        # around description carry-over; isolating per query is safer and
        # makes the FIFO-cursor test fixture pattern work cleanly.
        inserts = self._run_query_to_rows(connection, inserts_sql)
        deletes = self._run_query_to_rows(connection, deletes_sql)
        update_rows = self._run_query_to_rows(connection, updates_sql)

        # Reconstruct full before/after dicts from the three nullable
        # projections. Exactly one of (col__B + col__A) vs col__U is non-NULL
        # for each non-PK column on each updated row.
        updates: list[dict[str, Any]] = []
        pk_upper = [c.upper() for c in pk_columns]
        non_pk_upper = [c.upper() for c in non_pk_cols]

        for raw in update_rows:
            before_row: RowDict = {c: raw[c] for c in pk_upper}
            after_row: RowDict = {c: raw[c] for c in pk_upper}
            changed: list[str] = []

            for col in non_pk_upper:
                u_key = f"{col}__U"
                b_key = f"{col}__B"
                a_key = f"{col}__A"

                # A column is projected as "changed" only when
                # b IS DISTINCT FROM a, which requires at least one side
                # to be non-NULL (NULL vs NULL is not distinct). So both
                # __B and __A being NULL uniquely identifies the
                # unchanged case, even when the unchanged value itself
                # is NULL (in which case __U is also NULL).
                b_val = raw.get(b_key)
                a_val = raw.get(a_key)
                if b_val is None and a_val is None:
                    unchanged_val = raw.get(u_key)
                    before_row[col] = unchanged_val
                    after_row[col] = unchanged_val
                else:
                    before_row[col] = b_val
                    after_row[col] = a_val
                    changed.append(col)

            key = {c: after_row[c] for c in pk_upper}
            updates.append(make_update_pair(key, before_row, after_row, changed))

        return inserts, deletes, updates

    def diff_with_synthetic_pk(
        self,
        connection: Any,
        before_fqn: str,
        after_fqn: str,
        all_columns: list[str],
    ) -> tuple[list[RowDict], list[RowDict], list[dict[str, Any]]]:
        if not all_columns:
            raise ValueError(
                "diff_with_synthetic_pk requires at least one column."
            )

        introspector = SqlServerIntrospector()
        hash_expr = introspector.hash_row_expression(all_columns) or ""

        col_list = ", ".join(f"[{c}]" for c in all_columns)
        all_cols_a = ", ".join(f"a.[{c}]" for c in all_columns)
        all_cols_b = ", ".join(f"b.[{c}]" for c in all_columns)

        live_keyed_cte = (
            f"WITH after_keyed AS ("
            f"  SELECT {col_list}, "
            f"    {hash_expr} AS [{SYNTH_KEY_COL}], "
            f"    ROW_NUMBER() OVER ("
            f"      PARTITION BY {hash_expr} "
            f"      ORDER BY (SELECT NULL)"
            f"    ) AS [{SYNTH_DUP_SEQ_COL}] "
            f"  FROM {after_fqn}"
            f")"
        )

        synth_join = (
            f"a.[{SYNTH_KEY_COL}] = b.[{SYNTH_KEY_COL}] "
            f"AND a.[{SYNTH_DUP_SEQ_COL}] = b.[{SYNTH_DUP_SEQ_COL}]"
        )

        inserts_sql = (
            f"{live_keyed_cte} "
            f"SELECT {all_cols_a} "
            f"FROM after_keyed a "
            f"LEFT JOIN {before_fqn} b ON {synth_join} "
            f"WHERE b.[{SYNTH_KEY_COL}] IS NULL "
            f"ORDER BY a.[{SYNTH_KEY_COL}], a.[{SYNTH_DUP_SEQ_COL}]"
        )

        deletes_sql = (
            f"{live_keyed_cte} "
            f"SELECT {all_cols_b} "
            f"FROM {before_fqn} b "
            f"LEFT JOIN after_keyed a ON {synth_join} "
            f"WHERE a.[{SYNTH_KEY_COL}] IS NULL "
            f"ORDER BY b.[{SYNTH_KEY_COL}], b.[{SYNTH_DUP_SEQ_COL}]"
        )

        raw_inserts = self._run_query_to_rows(connection, inserts_sql)
        raw_deletes = self._run_query_to_rows(connection, deletes_sql)

        # Strip synth columns from output rows. They were used only for the
        # join and have no meaning in the final delta dict.
        def _strip_synth(row: RowDict) -> RowDict:
            return {
                k: v for k, v in row.items()
                if k not in (SYNTH_KEY_COL, SYNTH_DUP_SEQ_COL)
            }
        inserts = [_strip_synth(r) for r in raw_inserts]
        deletes = [_strip_synth(r) for r in raw_deletes]

        # Reuse production update inference. The fqn argument is only used
        # for log messages; we synthesize a placeholder since the differ
        # doesn't know the table fqn at this layer.
        cols_upper = [c.upper() for c in all_columns]
        final_inserts, final_deletes, updates = _infer_updates_from_pairs(
            inserts, deletes, cols_upper, before_fqn,
        )
        return final_inserts, final_deletes, updates

    def drop_diff_table(self, connection: Any, fqn: str) -> None:
        cursor = connection.cursor()
        try:
            cursor.execute(_drop_table_if_exists_sql(fqn))
        finally:
            cursor.close()
