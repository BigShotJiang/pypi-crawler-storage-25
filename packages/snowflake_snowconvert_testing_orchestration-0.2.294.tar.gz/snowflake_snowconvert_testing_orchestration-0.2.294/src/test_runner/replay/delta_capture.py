"""Delta capture orchestrator and strategy selector.

Supports ``FULL_SNAPSHOT``, ``PK_DIFF``, and ``SYNTHETIC_KEY``.

Decision tree (see SNOW-3309234 experiment results):

1. Table has PK columns → ``PK_DIFF``
2. No PK, known-small table (< ``small_table_threshold``) → ``FULL_SNAPSHOT``
3. No PK, wide table (>= ``synthetic_key_column_threshold`` cols) → ``SYNTHETIC_KEY``
4. No PK, narrow table → ``FULL_SNAPSHOT``

Two-pass fetch optimisation (SNOW-3330643)
------------------------------------------
For PK_DIFF on wide tables (>= ``two_pass_column_threshold`` columns),
the after-snapshot is replaced by:

* **Phase 1** — ``SELECT pk, hash(non_pk_cols) FROM table`` (lightweight)
* Hash comparison against the before-snapshot hashes to identify
  changed PKs (inserts, deletes, updates).
* **Phase 2** — ``SELECT * FROM table WHERE pk IN (changed)`` (selective)

This reduces wire transfer by up to 94 % on wide remote tables
(experiment SNOW-3309234).
"""

from __future__ import annotations

import logging
import time
from typing import Any

from ..common.config import ReplayConfiguration
from ..common.snowflake_types import describe_to_column_types
from .models import DeltaStrategy, RowDict, TableConfig, make_delta, make_update_pair
from .strategies import DeltaCaptureStrategy
from .strategies.full_snapshot import FullSnapshotStrategy
from .strategies.pk_diff import PkDiffStrategy
from .strategies.synthetic_key import SyntheticKeyStrategy

logger = logging.getLogger(__name__)

_FULL_SNAPSHOT = FullSnapshotStrategy()
_PK_DIFF = PkDiffStrategy()
_SYNTHETIC_KEY = SyntheticKeyStrategy()


def select_strategy(
    table_cfg: TableConfig,
    replay_cfg: ReplayConfiguration,
    *,
    column_count: int = 0,
) -> DeltaCaptureStrategy:
    """Pick a delta strategy for *table_cfg* given *replay_cfg* thresholds.

    Returns ``PK_DIFF`` when the table has known primary key columns.
    For tables without PKs, returns ``FULL_SNAPSHOT`` when the table is
    known-small (``estimated_row_count`` below ``small_table_threshold``),
    ``SYNTHETIC_KEY`` when the column count meets the
    ``synthetic_key_column_threshold``, otherwise ``FULL_SNAPSHOT``.
    """
    if table_cfg.primary_key_columns:
        return _PK_DIFF

    row_count = table_cfg.estimated_row_count
    if 0 < row_count < replay_cfg.small_table_threshold:
        return _FULL_SNAPSHOT

    if column_count >= replay_cfg.synthetic_key_column_threshold:
        return _SYNTHETIC_KEY

    if column_count > 0:
        logger.info(
            "Table %s has no PK and only %d columns (threshold=%d); "
            "using FULL_SNAPSHOT.  Consider adding PK metadata for "
            "better diff accuracy.",
            table_cfg.fqn, column_count,
            replay_cfg.synthetic_key_column_threshold,
        )
    return _FULL_SNAPSHOT


def _materialize_rows(cursor: Any, columns: list[str]) -> list[RowDict]:
    """Drain *cursor* into a list of ``{col: value}`` dicts (hex-encoding bytes)."""
    rows: list[RowDict] = []
    for raw_row in cursor.fetchall():
        rows.append({
            col: (val.hex() if isinstance(val, (bytes, bytearray)) else val)
            for col, val in zip(columns, raw_row)
        })
    return rows


def _select_all_sql(schema: str, table: str, database: str | None) -> str:
    if database:
        return f'SELECT * FROM "{database}"."{schema}"."{table}"'
    return f'SELECT * FROM "{schema}"."{table}"'


def snapshot_table_with_types(
    connection: Any,
    schema: str,
    table: str,
    database: str | None = None,
) -> tuple[list[RowDict], dict[str, str]]:
    """Capture all rows from ``schema.table`` and the column types in one pass.

    Returns ``(rows, column_types)`` where *column_types* is a
    ``{COLUMN_NAME: SNOWFLAKE_DDL_TYPE}`` mapping derived from the same
    ``cursor.description`` produced by the ``SELECT *`` snapshot query
    — no additional round-trip is required (cf. SNOW-3414326 PR review).

    .. note::
       This helper is **Snowflake-only** because the type translation
       relies on ``snowflake.connector``'s ``FIELD_ID_TO_NAME`` table.
       Source-side captures (Redshift / SQL Server / Teradata) must use
       :func:`snapshot_table` instead, which performs no type extraction.

    When *database* is provided the query is fully qualified
    (``"database"."schema"."table"``), which is required when the target
    lives in a clone database that differs from the session's current DB.

    Binary columns (``bytes``) are hex-encoded so that downstream
    consumers (Pandas, DuckDB, Polars) can process them safely.
    """
    cursor = connection.cursor()
    try:
        cursor.execute(_select_all_sql(schema, table, database))
        col_types = describe_to_column_types(cursor.description)
        rows = _materialize_rows(cursor, list(col_types.keys()))
        return rows, col_types
    finally:
        cursor.close()


def snapshot_table(
    connection: Any,
    schema: str,
    table: str,
    database: str | None = None,
) -> list[RowDict]:
    """Capture all rows from ``schema.table`` via ``SELECT *``.

    Driver-agnostic: works against any DB-API cursor (Snowflake,
    Redshift, SQL Server, Teradata) because it does **not** translate
    column type codes — only column names are read from
    ``cursor.description``.  Callers that need Snowflake column types
    (e.g. the validate-side before-snapshot) should use
    :func:`snapshot_table_with_types` instead.
    """
    cursor = connection.cursor()
    try:
        cursor.execute(_select_all_sql(schema, table, database))
        columns = [desc[0].upper() for desc in cursor.description]
        return _materialize_rows(cursor, columns)
    finally:
        cursor.close()


_HASH_COL = "__ROW_HASH__"


def _qualified_name(
    schema: str, table: str, database: str | None = None,
) -> str:
    if database:
        return f'"{database}"."{schema}"."{table}"'
    return f'"{schema}"."{table}"'


def get_column_names(
    connection: Any,
    schema: str,
    table: str,
) -> list[str]:
    """Return uppercased column names via a zero-row query."""
    cursor = connection.cursor()
    try:
        cursor.execute(
            f'SELECT * FROM "{schema}"."{table}" WHERE 1=0',
        )
        return [desc[0].upper() for desc in cursor.description]
    finally:
        cursor.close()


def snapshot_table_with_hash(
    connection: Any,
    schema: str,
    table: str,
    pk_columns: list[str],
    hash_expression: str,
) -> tuple[list[RowDict], dict[tuple, str]]:
    """Full snapshot augmented with a per-row hash (two-pass Phase 1 before).

    Returns ``(rows, hash_index)`` where *rows* are standard
    :class:`RowDict` instances (hash column stripped) and *hash_index*
    maps PK-value tuples to their hash strings.
    """
    fqn = _qualified_name(schema, table)
    cursor = connection.cursor()
    try:
        cursor.execute(
            f'SELECT *, {hash_expression} AS "{_HASH_COL}" FROM {fqn}',
        )
        columns = [desc[0].upper() for desc in cursor.description]
        pk_upper = [c.upper() for c in pk_columns]

        rows: list[RowDict] = []
        hash_index: dict[tuple, str] = {}

        for raw_row in cursor.fetchall():
            row_dict: RowDict = {}
            hash_val: Any = None
            for col, val in zip(columns, raw_row):
                processed = val.hex() if isinstance(val, (bytes, bytearray)) else val
                if col == _HASH_COL:
                    hash_val = processed
                else:
                    row_dict[col] = processed
            rows.append(row_dict)
            pk_key = tuple(row_dict.get(c) for c in pk_upper)
            hash_index[pk_key] = str(hash_val) if hash_val is not None else ""

        return rows, hash_index
    finally:
        cursor.close()


def snapshot_table_hashed(
    connection: Any,
    schema: str,
    table: str,
    pk_columns: list[str],
    hash_expression: str,
) -> dict[tuple, str]:
    """PK + hash snapshot (two-pass Phase 1 after).

    Returns a mapping of PK-value tuples to hash strings — no full
    row data is transferred, just keys and hashes.
    """
    pk_select = ", ".join(f'"{c}"' for c in pk_columns)
    fqn = _qualified_name(schema, table)
    cursor = connection.cursor()
    try:
        cursor.execute(
            f'SELECT {pk_select}, {hash_expression} AS "{_HASH_COL}" '
            f"FROM {fqn}",
        )
        columns = [desc[0].upper() for desc in cursor.description]
        pk_upper = [c.upper() for c in pk_columns]

        hash_index: dict[tuple, str] = {}
        for raw_row in cursor.fetchall():
            row_data = {
                col: (val.hex() if isinstance(val, (bytes, bytearray)) else val)
                for col, val in zip(columns, raw_row)
            }
            pk_key = tuple(row_data.get(c) for c in pk_upper)
            hash_val = row_data.get(_HASH_COL)
            hash_index[pk_key] = str(hash_val) if hash_val is not None else ""

        return hash_index
    finally:
        cursor.close()


_SELECTIVE_BATCH_SIZE = 1000


def snapshot_table_selective(
    connection: Any,
    schema: str,
    table: str,
    pk_columns: list[str],
    pk_values: list[tuple],
) -> list[RowDict]:
    """Fetch full rows for specific PK values (two-pass Phase 2).

    Batches into chunks of :data:`_SELECTIVE_BATCH_SIZE` to stay within
    database limits on ``IN`` clause size and query length.  This
    workaround is inherent to client-side two-pass diffing; server-side
    diffing would replace this with a single JOIN on the source.

    Binary columns are hex-encoded, consistent with :func:`snapshot_table`.
    """
    if not pk_values:
        return []

    fqn = _qualified_name(schema, table)
    rows: list[RowDict] = []

    for offset in range(0, len(pk_values), _SELECTIVE_BATCH_SIZE):
        batch = pk_values[offset:offset + _SELECTIVE_BATCH_SIZE]
        where = _build_pk_where(pk_columns, batch)
        cursor = connection.cursor()
        try:
            cursor.execute(f"SELECT * FROM {fqn} WHERE {where}")
            columns = [desc[0].upper() for desc in cursor.description]
            for raw_row in cursor.fetchall():
                rows.append({
                    col: (val.hex() if isinstance(val, (bytes, bytearray)) else val)
                    for col, val in zip(columns, raw_row)
                })
        finally:
            cursor.close()

    return rows


def compute_changed_pks(
    before_hashes: dict[tuple, str],
    after_hashes: dict[tuple, str],
) -> tuple[list[tuple], list[tuple], list[tuple]]:
    """Compare before/after hash indices to classify PK changes.

    Returns ``(inserted_pks, deleted_pks, updated_pks)`` as sorted
    lists of PK-value tuples.
    """
    before_keys = set(before_hashes)
    after_keys = set(after_hashes)

    inserted = sorted(after_keys - before_keys)
    deleted = sorted(before_keys - after_keys)
    updated = sorted(
        pk for pk in before_keys & after_keys
        if before_hashes[pk] != after_hashes[pk]
    )

    return inserted, deleted, updated


def build_two_pass_delta(
    before_rows: list[RowDict],
    after_selective: list[RowDict],
    pk_columns: list[str],
    inserted_pks: list[tuple],
    deleted_pks: list[tuple],
    updated_pks: list[tuple],
    table_cfg: TableConfig,
) -> dict[str, Any]:
    """Build a ``PK_DIFF`` delta from two-pass fetch results.

    *before_rows* is the full before-snapshot.  *after_selective*
    contains only the rows for inserted + updated PKs.
    """
    pk_upper = [c.upper() for c in pk_columns]

    before_by_pk: dict[tuple, RowDict] = {}
    for row in before_rows:
        pk = tuple(row.get(c) for c in pk_upper)
        before_by_pk[pk] = row

    after_by_pk: dict[tuple, RowDict] = {}
    for row in after_selective:
        pk = tuple(row.get(c) for c in pk_upper)
        after_by_pk[pk] = row

    inserts = [after_by_pk[pk] for pk in inserted_pks if pk in after_by_pk]
    deletes = [before_by_pk[pk] for pk in deleted_pks if pk in before_by_pk]

    ignore = {c.upper() for c in table_cfg.ignore_columns}
    pk_set = set(pk_upper)
    sample = (before_rows or after_selective or [{}])[0]
    all_cols = sorted(c for c in sample if c.upper() not in ignore)
    non_pk_cols = [c for c in all_cols if c not in pk_set]

    updates: list[dict[str, Any]] = []
    for pk in updated_pks:
        before_row = before_by_pk.get(pk)
        after_row = after_by_pk.get(pk)
        if before_row and after_row:
            key = {c: after_row[c] for c in pk_upper}
            changed = [
                c for c in non_pk_cols
                if before_row.get(c) != after_row.get(c)
            ]
            if changed:
                updates.append(
                    make_update_pair(key, before_row, after_row, changed),
                )

    return make_delta(
        table_cfg.fqn, DeltaStrategy.PK_DIFF,
        inserts=inserts, deletes=deletes, updates=updates,
    )


def _build_pk_where(pk_columns: list[str], pk_values: list[tuple]) -> str:
    """Build a WHERE clause matching any of the given PK value tuples."""
    if len(pk_columns) == 1:
        literals = ", ".join(_sql_literal(v[0]) for v in pk_values)
        return f'"{pk_columns[0]}" IN ({literals})'

    conditions = []
    for vals in pk_values:
        parts = " AND ".join(
            f'"{col}" = {_sql_literal(val)}'
            for col, val in zip(pk_columns, vals)
        )
        conditions.append(f"({parts})")
    return " OR ".join(conditions)


def _sql_literal(val: Any) -> str:
    """Convert a Python value to a SQL literal for WHERE clauses.

    Covers ``None``, ``bool``, ``int``, ``float``, ``bytes``,
    ``datetime``, ``date``, ``Decimal``, and ``uuid.UUID``.  All other
    types fall through to ``str(val)`` which produces a single-quoted
    string literal — safe for any type whose ``__str__`` returns a
    DB-parseable representation.
    """
    if val is None:
        return "NULL"
    if isinstance(val, bool):
        return "1" if val else "0"
    if isinstance(val, int):
        return str(val)
    if isinstance(val, float):
        return repr(val)
    if isinstance(val, (bytes, bytearray)):
        return f"0x{val.hex()}"
    import datetime
    import decimal
    import uuid
    if isinstance(val, datetime.datetime):
        return f"'{val.isoformat()}'"
    if isinstance(val, datetime.date):
        return f"'{val.isoformat()}'"
    if isinstance(val, decimal.Decimal):
        return str(val)
    if isinstance(val, uuid.UUID):
        return f"'{val}'"
    escaped = str(val).replace("'", "''")
    return f"'{escaped}'"


def compute_table_delta(
    before: list[RowDict],
    after: list[RowDict],
    table_cfg: TableConfig,
    replay_cfg: ReplayConfiguration,
) -> dict[str, Any]:
    """Compute a delta between *before* and *after* using the selected strategy."""
    sample = before or after
    col_count = len(sample[0]) if sample else 0
    strategy = select_strategy(table_cfg, replay_cfg, column_count=col_count)
    table_cfg.strategy = strategy.name

    logger.info(
        "Computing delta for %s using %s (rows_before=%d, rows_after=%d)",
        table_cfg.fqn, strategy.name.value, len(before), len(after),
    )

    start_time = time.perf_counter()
    delta = strategy.compute_delta(before, after, table_cfg)
    elapsed_ms = int((time.perf_counter() - start_time) * 1000)
    delta.setdefault("metadata", {})["capture_duration_ms"] = elapsed_ms
    return delta
