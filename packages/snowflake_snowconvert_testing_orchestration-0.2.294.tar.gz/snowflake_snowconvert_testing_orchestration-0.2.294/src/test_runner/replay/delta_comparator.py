"""Delta comparison via SDV's public ResultSet cell-level validation.

Compares baseline deltas (from capture, JSON-deserialised) against actual
deltas (from validate, cursor-typed) by routing both sides through
``result_set_cell_level_validation`` from
``snowflake.snowflake_data_validation.public``.

The public ResultSet API performs two stages of normalisation that the
old ``validate_cell`` callsite was missing:

1. Dtype unification — Snowflake DDL type names (``NUMBER``, ``TIMESTAMP_NTZ``,
   ...) are translated to canonical Polars dtypes (``Float64``, ``Datetime``,
   ...) on both sides via the SDV YAML mappings.
2. Canonical-string normalisation — DuckDB SQL templates render every value
   to a consistent string (rounded floats, ``%Y-%m-%d-%H:%M:%S`` datetimes,
   ...) before the cell-by-cell diff.

Together these eliminate the false positives the previous implementation
needed bespoke ``_align_mismatched_columns`` / ``_cast_str_to_*`` shims to
work around.  See SNOW-3414326 for the full RCA.
"""

from __future__ import annotations

import logging
from typing import Any

from snowflake.snowflake_data_validation.public import (
    ResultSet,
    result_set_cell_level_validation,
)

from test_runner.common.collation import CollationClassifier
from test_runner.common.comparison_context import ComparisonContext
from test_runner.common.config import ValidationConfiguration
from test_runner.common.set_table import RISK_CONFIRMED, adjust_delta_diff

logger = logging.getLogger(__name__)


def compare_table_deltas(
    baseline_delta: dict[str, Any],
    actual_delta: dict[str, Any],
    table_fqn: str,
    column_types: dict[str, str],
    max_cell_diffs: int = ValidationConfiguration().max_cell_diffs,
    ignore_columns: list[str] | None = None,
    collation: CollationClassifier | None = None,
    case_insensitive_columns: list[str] | None = None,
    has_collation_fdm: bool = False,
    cmp_ctx: ComparisonContext | None = None,
) -> dict[str, Any]:
    """Compare baseline vs actual delta for a single table.

    Compares inserts-vs-inserts and deletes-vs-deletes via SDV's
    public ``result_set_cell_level_validation``.  Updates are compared
    by their ``after`` rows.

    *column_types* maps uppercased column name to Snowflake DDL type
    string (e.g. ``{"AMOUNT": "NUMBER"}``); it is forwarded to the
    public API so both sides go through identical type-aware
    normalisation.

    When *ignore_columns* is provided, those columns are stripped from
    both baseline and actual row dicts before any comparison.

    When *collation* is provided, cell-level mismatches are annotated
    with collation context via the classifier (dialect-agnostic).
    The legacy *case_insensitive_columns* / *has_collation_fdm* params
    are accepted for backward compatibility and used to build a
    ``CollationClassifier`` when *collation* is not provided.

    Returns a result dict with ``match``, ``table``, ``differences``.
    """
    ignore = {c.upper() for c in ignore_columns} if ignore_columns else set()

    result: dict[str, Any] = {"match": True, "table": table_fqn, "differences": []}

    if collation is None and (case_insensitive_columns or has_collation_fdm):
        ci_by_table = {table_fqn: list(case_insensitive_columns)} if case_insensitive_columns else {}
        collation = CollationClassifier(
            has_collation_fdm=has_collation_fdm,
            case_insensitive_columns_by_table=ci_by_table,
        )

    b_inserts = _strip_columns(baseline_delta.get("inserts", []), ignore)
    a_inserts = _strip_columns(actual_delta.get("inserts", []), ignore)
    b_deletes = _strip_columns(baseline_delta.get("deletes", []), ignore)
    a_deletes = _strip_columns(actual_delta.get("deletes", []), ignore)
    b_updates = baseline_delta.get("updates", [])
    a_updates = actual_delta.get("updates", [])

    if len(b_inserts) != len(a_inserts):
        result["match"] = False
        result["differences"].append({
            "type": "insert_count_mismatch",
            "baseline": len(b_inserts),
            "actual": len(a_inserts),
        })

    if len(b_deletes) != len(a_deletes):
        result["match"] = False
        result["differences"].append({
            "type": "delete_count_mismatch",
            "baseline": len(b_deletes),
            "actual": len(a_deletes),
        })

    if len(b_updates) != len(a_updates):
        result["match"] = False
        result["differences"].append({
            "type": "update_count_mismatch",
            "baseline": len(b_updates),
            "actual": len(a_updates),
        })

    if not result["match"]:
        if collation is not None:
            for diff in result["differences"]:
                collation.annotate_count_mismatch(diff, table_fqn=table_fqn)

        if cmp_ctx is not None and cmp_ctx.set_tables:
            row_map = {
                "insert_count_mismatch": (b_inserts, a_inserts),
                "delete_count_mismatch": (b_deletes, a_deletes),
                "update_count_mismatch": (
                    _strip_columns([u.get("after", {}) for u in b_updates], ignore),
                    _strip_columns([u.get("after", {}) for u in a_updates], ignore),
                ),
            }
            _apply_set_table_adjustments(result, cmp_ctx, table_fqn, row_map, column_types, max_cell_diffs)

        return result

    for label, b_rows, a_rows in [
        ("insert", b_inserts, a_inserts),
        ("delete", b_deletes, a_deletes),
    ]:
        if not b_rows and not a_rows:
            continue
        diffs = _compare_row_sets(b_rows, a_rows, column_types, max_cell_diffs)
        if diffs:
            if collation is not None:
                collation.annotate_diffs(diffs, table_fqn=table_fqn)
            result["match"] = False
            result["differences"].append({
                "type": f"{label}_content_mismatch",
                "cell_diffs": diffs,
            })

    if b_updates or a_updates:
        b_after = _strip_columns([u.get("after", {}) for u in b_updates], ignore)
        a_after = _strip_columns([u.get("after", {}) for u in a_updates], ignore)
        diffs = _compare_row_sets(b_after, a_after, column_types, max_cell_diffs)
        if diffs:
            if collation is not None:
                collation.annotate_diffs(diffs, table_fqn=table_fqn)
            result["match"] = False
            result["differences"].append({
                "type": "update_content_mismatch",
                "cell_diffs": diffs,
            })

    return result


def _apply_set_table_adjustments(
    result: dict[str, Any],
    cmp_ctx: ComparisonContext,
    table_fqn: str,
    row_map: dict[str, tuple[list[dict[str, Any]], list[dict[str, Any]]]],
    column_types: dict[str, str],
    max_cell_diffs: int,
) -> None:
    """Run SET table dedup on every count-mismatch diff and flip match if all confirmed."""
    all_confirmed = True
    for diff in result["differences"]:
        pair = row_map.get(diff["type"])
        if pair is None:
            all_confirmed = False
            continue
        adjust_delta_diff(
            diff, table_fqn, cmp_ctx.set_tables,
            baseline_rows=pair[0], actual_rows=pair[1],
            compare_fn=_compare_row_sets,
            max_cell_diffs=max_cell_diffs,
            column_types=column_types,
        )
        if diff.get("set_table_risk") != RISK_CONFIRMED:
            all_confirmed = False
    if all_confirmed and result["differences"]:
        result["match"] = True


def _strip_columns(
    rows: list[dict[str, Any]],
    ignore: set[str],
) -> list[dict[str, Any]]:
    """Remove ignored columns (upper-cased) from each row dict."""
    if not ignore or not rows:
        return rows
    return [
        {k: v for k, v in row.items() if k.upper() not in ignore}
        for row in rows
    ]


def _compare_row_sets(
    baseline_rows: list[dict[str, Any]],
    actual_rows: list[dict[str, Any]],
    column_types: dict[str, str],
    max_cell_diffs: int,
) -> list[dict]:
    """Compare two row sets via the SDV public ResultSet API."""
    if not baseline_rows and not actual_rows:
        return []

    # Restrict column_types to the columns actually present in the row sets:
    # ignored columns may have been stripped, and update.after dicts may be
    # narrower than the full table schema.  ResultSet rejects column_types
    # entries with no matching column data.
    present = set()
    for row in baseline_rows[:1] + actual_rows[:1]:
        present.update(row.keys())
    types = {c: t for c, t in column_types.items() if c in present}

    validation_result = result_set_cell_level_validation(
        first_result_set=ResultSet(rows=baseline_rows, column_types=types),
        second_result_set=ResultSet(rows=actual_rows, column_types=types),
    )

    df = validation_result.results_dataframe
    if df.empty:
        return []

    df = df.rename(columns={
        "ROW": "row",
        "COLUMN": "column",
        "SOURCE_VALUE": "baseline",
        "TARGET_VALUE": "actual",
    })
    return df.head(max_cell_diffs).to_dict(orient="records")
