"""Primary-key based delta capture strategy.

Joins before/after snapshots on PK columns to detect inserts, deletes,
and true updates.  Uses DuckDB for efficient in-process SQL joins.

Unlike ``FullSnapshotStrategy`` (which can only produce delete+insert
pairs for modified rows), this strategy identifies the exact rows that
changed and which columns were modified.
"""

from __future__ import annotations

import logging
from typing import Any

import duckdb
import pandas as pd

from ..models import (
    DeltaStrategy,
    RowDict,
    TableConfig,
    make_delta,
    make_update_pair,
)
from . import DeltaCaptureStrategy

logger = logging.getLogger(__name__)


class PkDiffStrategy(DeltaCaptureStrategy):
    """PK-based diff using DuckDB JOIN on primary key columns."""

    @property
    def name(self) -> DeltaStrategy:
        return DeltaStrategy.PK_DIFF

    def compute_delta(
        self,
        before: list[RowDict],
        after: list[RowDict],
        table_cfg: TableConfig,
    ) -> dict[str, Any]:
        pk_cfg = [c.upper() for c in table_cfg.primary_key_columns]
        if not pk_cfg:
            raise ValueError(
                f"PkDiffStrategy requires primary_key_columns but "
                f"{table_cfg.fqn} has none"
            )

        columns = _resolve_columns(before or after, table_cfg)
        if not columns:
            return make_delta(table_cfg.fqn, self.name)

        col_upper = {c.upper(): c for c in columns}
        pk_cols = [col_upper[k] for k in pk_cfg if k in col_upper]
        missing_pks = [k for k in pk_cfg if k not in col_upper]
        if missing_pks:
            warning_msg = (
                f"PK columns {missing_pks} not found in snapshot for "
                f"{table_cfg.fqn}; fell back to FULL_SNAPSHOT"
            )
            logger.warning("%s", warning_msg)
            from .full_snapshot import FullSnapshotStrategy
            delta = FullSnapshotStrategy().compute_delta(before, after, table_cfg)
            delta["metadata"]["warnings"].append(warning_msg)
            return delta

        pk_set = set(pk_cols)
        non_pk_cols = [c for c in columns if c not in pk_set]

        conn = duckdb.connect()
        try:
            _register(conn, "before_snap", before, columns)
            _register(conn, "after_snap", after, columns)

            col_list = ", ".join(f'"{c}"' for c in columns)
            pk_join = " AND ".join(
                f'a."{c}" IS NOT DISTINCT FROM b."{c}"' for c in pk_cols
            )

            inserts = conn.execute(
                f"SELECT a.{col_list} FROM after_snap a "
                f"WHERE NOT EXISTS ("
                f"  SELECT 1 FROM before_snap b WHERE {pk_join}"
                f")"
            ).fetchdf().to_dict(orient="records")

            deletes = conn.execute(
                f"SELECT b.{col_list} FROM before_snap b "
                f"WHERE NOT EXISTS ("
                f"  SELECT 1 FROM after_snap a WHERE {pk_join}"
                f")"
            ).fetchdf().to_dict(orient="records")

            updates = _detect_updates(
                conn, pk_cols, non_pk_cols, columns, pk_join,
            )
        finally:
            conn.close()

        logger.debug(
            "pk_diff delta for %s: +%d -%d ~%d",
            table_cfg.fqn, len(inserts), len(deletes), len(updates),
        )
        return make_delta(
            table_cfg.fqn, self.name,
            inserts=inserts, deletes=deletes, updates=updates,
        )


def _detect_updates(
    conn: duckdb.DuckDBPyConnection,
    pk_cols: list[str],
    non_pk_cols: list[str],
    all_cols: list[str],
    pk_join: str,
) -> list[dict[str, Any]]:
    """Find rows with matching PKs but differing non-PK columns."""
    if not non_pk_cols:
        return []

    differ_clause = " OR ".join(
        f'b."{c}" IS DISTINCT FROM a."{c}"' for c in non_pk_cols
    )

    b_prefix = ", ".join(f'b."{c}" AS "b_{c}"' for c in all_cols)
    a_prefix = ", ".join(f'a."{c}" AS "a_{c}"' for c in all_cols)

    rows = conn.execute(
        f"SELECT {b_prefix}, {a_prefix} "
        f"FROM before_snap b "
        f"INNER JOIN after_snap a ON {pk_join} "
        f"WHERE {differ_clause}"
    ).fetchdf().to_dict(orient="records")

    updates: list[dict[str, Any]] = []
    for row in rows:
        before_row = {c: row[f"b_{c}"] for c in all_cols}
        after_row = {c: row[f"a_{c}"] for c in all_cols}
        key = {c: after_row[c] for c in pk_cols}
        changed = [
            c for c in non_pk_cols
            if not _values_equal(before_row[c], after_row[c])
        ]
        updates.append(make_update_pair(key, before_row, after_row, changed))

    return updates


def _values_equal(a: Any, b: Any) -> bool:
    """Compare two values, treating None/NaN/pd.NA as equal to themselves.

    Uses ``pd.isna`` to handle all missing-value variants uniformly
    (``None``, ``float('nan')``, ``pd.NA``, ``np.nan``).  The ``bool()``
    wrapper on the comparison result guards against ``pd.NA`` propagation
    from nullable dtype comparisons.
    """
    try:
        a_na = pd.isna(a)
        b_na = pd.isna(b)
    except (TypeError, ValueError):
        a_na = a is None
        b_na = b is None
    if a_na and b_na:
        return True
    if a_na or b_na:
        return False
    try:
        return bool(a == b)
    except (TypeError, ValueError):
        return False


def _resolve_columns(
    sample_rows: list[RowDict],
    table_cfg: TableConfig,
) -> list[str]:
    if not sample_rows:
        return []
    ignore = {c.upper() for c in table_cfg.ignore_columns}
    return sorted(c for c in sample_rows[0] if c.upper() not in ignore)


def _register(
    conn: duckdb.DuckDBPyConnection,
    name: str,
    rows: list[RowDict],
    columns: list[str],
) -> None:
    sanitized = [
        {k: (v.hex() if isinstance(v, (bytes, bytearray)) else v) for k, v in row.items()}
        for row in rows
    ] if rows else []
    df = pd.DataFrame(sanitized, columns=columns) if sanitized else pd.DataFrame(columns=columns)
    for col in df.columns:
        if df[col].dtype == "float64" and df[col].dropna().apply(float.is_integer).all():
            df[col] = df[col].astype("Int64")
    conn.register(name, df)
