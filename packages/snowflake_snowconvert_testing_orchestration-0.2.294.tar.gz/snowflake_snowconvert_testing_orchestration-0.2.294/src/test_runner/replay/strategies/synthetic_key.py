"""Synthetic-key delta capture strategy.

Hashes all columns into a deterministic surrogate key using SHA256,
then applies PK_DIFF-style JOIN logic on the synthetic key to detect
inserts and deletes.

Encoding uses a null-bit prefix per column (CHR(0) for NULL, CHR(1)
prefix for non-NULL) and a non-printable delimiter (CHR(31), Unit
Separator) to avoid ambiguity between SQL NULL / literal ``"NULL"``
and delimiter-containing values.

Designed for tables that lack a natural primary key.  Experiment results
(SNOW-3309234) confirm SHA256 is collision-free at production scales —
apparent "collisions" are genuine data duplicates.

Duplicate handling: when multiple rows share the same hash (i.e. fully
identical rows), the strategy counts occurrences per side.  Extra
occurrences on the *after* side are inserts; extra on the *before* side
are deletes.

Update inference (SNOW-3342102): after the hash diff, a post-processing
pass correlates delete+insert pairs into structured updates when a
majority of columns match between the deleted and inserted row.  This
uses greedy best-match pairing — the pair with the fewest differing
columns is matched first.  Pairs where the changed columns outnumber
the unchanged columns are left as separate inserts/deletes.
"""

from __future__ import annotations

import logging
from typing import Any

import duckdb
import pandas as pd

from ..models import (
    DeltaStrategy,
    RowDict,
    TableConfig,
    make_delta,
    make_update_pair,
)
from . import DeltaCaptureStrategy

logger = logging.getLogger(__name__)

_SYNTH_COL = "__synth_key__"

_PAIR_MATRIX_LIMIT = 10_000


class SyntheticKeyStrategy(DeltaCaptureStrategy):
    """Content-hash diff using DuckDB with a synthetic SHA256 key."""

    @property
    def name(self) -> DeltaStrategy:
        return DeltaStrategy.SYNTHETIC_KEY

    def compute_delta(
        self,
        before: list[RowDict],
        after: list[RowDict],
        table_cfg: TableConfig,
    ) -> dict[str, Any]:
        columns = _resolve_columns(before or after, table_cfg)
        if not columns:
            return make_delta(table_cfg.fqn, self.name)

        conn = duckdb.connect()
        try:
            _register(conn, "before_snap", before, columns)
            _register(conn, "after_snap", after, columns)

            hash_expr = _hash_expression(columns)
            col_list = ", ".join(f'"{c}"' for c in columns)

            order_cols = ", ".join(f'"{c}"' for c in columns)
            for tbl in ("before_snap", "after_snap"):
                conn.execute(
                    f"CREATE TABLE {tbl}_keyed AS "
                    f"SELECT {hash_expr} AS {_SYNTH_COL}, "
                    f"ROW_NUMBER() OVER (PARTITION BY {hash_expr} ORDER BY {order_cols}) AS __dup_seq__, "
                    f"{col_list} FROM {tbl}"
                )

            join_cond = (
                f'a."{_SYNTH_COL}" = b."{_SYNTH_COL}" '
                f"AND a.__dup_seq__ = b.__dup_seq__"
            )

            inserts = conn.execute(
                f"SELECT a.{col_list} FROM after_snap_keyed a "
                f"WHERE NOT EXISTS ("
                f"  SELECT 1 FROM before_snap_keyed b WHERE {join_cond}"
                f")"
            ).fetchdf().to_dict(orient="records")

            deletes = conn.execute(
                f"SELECT b.{col_list} FROM before_snap_keyed b "
                f"WHERE NOT EXISTS ("
                f"  SELECT 1 FROM after_snap_keyed a WHERE {join_cond}"
                f")"
            ).fetchdf().to_dict(orient="records")
        finally:
            conn.close()

        inserts, deletes, updates = _infer_updates_from_pairs(
            inserts, deletes, columns, table_cfg.fqn,
        )

        logger.debug(
            "synthetic_key delta for %s: +%d -%d ~%d",
            table_cfg.fqn, len(inserts), len(deletes), len(updates),
        )
        return make_delta(
            table_cfg.fqn, self.name,
            inserts=inserts, deletes=deletes, updates=updates,
        )


def _infer_updates_from_pairs(
    inserts: list[RowDict],
    deletes: list[RowDict],
    columns: list[str],
    fqn: str,
) -> tuple[list[RowDict], list[RowDict], list[dict[str, Any]]]:
    """Correlate delete+insert pairs into structured updates.

    A (delete, insert) pair is promoted to an update when strictly more
    columns match than differ — i.e. at least one column is unchanged and
    the changed columns are a minority.

    Uses greedy matching: the pair with the fewest differing columns is
    matched first, then both rows are removed from consideration.

    Returns ``(remaining_inserts, remaining_deletes, updates)``.
    """
    if not inserts or not deletes:
        return inserts, deletes, []

    if len(inserts) * len(deletes) > _PAIR_MATRIX_LIMIT:
        logger.info(
            "Skipping update inference for %s: %d inserts x %d deletes "
            "exceeds pair matrix limit (%d)",
            fqn, len(inserts), len(deletes), _PAIR_MATRIX_LIMIT,
        )
        return inserts, deletes, []

    candidates: list[tuple[int, int, int, list[str]]] = []
    for delete_idx, delete_row in enumerate(deletes):
        for insert_idx, insert_row in enumerate(inserts):
            changed = [
                column for column in columns
                if not _values_equal(delete_row.get(column), insert_row.get(column))
            ]
            n_changed = len(changed)
            n_same = len(columns) - n_changed
            if n_same > n_changed and n_same >= 1:
                candidates.append((n_changed, delete_idx, insert_idx, changed))

    candidates.sort(key=lambda t: t[0])

    used_deletes: set[int] = set()
    used_inserts: set[int] = set()
    updates: list[dict[str, Any]] = []

    for n_changed, delete_idx, insert_idx, changed in candidates:
        if delete_idx in used_deletes or insert_idx in used_inserts:
            continue
        used_deletes.add(delete_idx)
        used_inserts.add(insert_idx)

        before_row = deletes[delete_idx]
        after_row = inserts[insert_idx]
        unchanged = [column for column in columns if column not in set(changed)]
        key = {column: after_row[column] for column in unchanged}
        updates.append(make_update_pair(key, before_row, after_row, changed))

    remaining_deletes = [
        row for idx, row in enumerate(deletes) if idx not in used_deletes
    ]
    remaining_inserts = [
        row for idx, row in enumerate(inserts) if idx not in used_inserts
    ]
    return remaining_inserts, remaining_deletes, updates


def _values_equal(a: Any, b: Any) -> bool:
    """Compare two values, treating None/NaN/pd.NA as equal."""
    try:
        a_na = pd.isna(a)
        b_na = pd.isna(b)
    except (TypeError, ValueError):
        a_na = a is None
        b_na = b is None
    if a_na and b_na:
        return True
    if a_na or b_na:
        return False
    try:
        return bool(a == b)
    except (TypeError, ValueError):
        return False


def _hash_expression(columns: list[str]) -> str:
    """Build an unambiguous per-column hash input.

    Each column is encoded as:
      NULL  → CHR(0)           (single NUL byte)
      value → CHR(1) || CAST(value AS VARCHAR)  (SOH prefix + text)

    Columns are joined with CHR(31) (Unit Separator).  This avoids
    collisions between SQL NULL / literal ``"NULL"`` string and between
    values that contain the delimiter character.
    """
    encoded = ", ".join(
        f"""CASE WHEN "{c}" IS NULL THEN CHR(0) """
        f"""ELSE CHR(1) || CAST("{c}" AS VARCHAR) END"""
        for c in columns
    )
    return f"SHA256(CONCAT_WS(CHR(31), {encoded}))"


def _resolve_columns(
    sample_rows: list[RowDict],
    table_cfg: TableConfig,
) -> list[str]:
    if not sample_rows:
        return []
    ignore = {c.upper() for c in table_cfg.ignore_columns}
    return sorted(c for c in sample_rows[0] if c.upper() not in ignore)


def _register(
    conn: duckdb.DuckDBPyConnection,
    name: str,
    rows: list[RowDict],
    columns: list[str],
) -> None:
    sanitized = [
        {k: (v.hex() if isinstance(v, (bytes, bytearray)) else v) for k, v in row.items()}
        for row in rows
    ] if rows else []
    df = pd.DataFrame(sanitized, columns=columns) if sanitized else pd.DataFrame(columns=columns)
    for col in df.columns:
        if df[col].dtype == "float64" and df[col].dropna().apply(float.is_integer).all():
            df[col] = df[col].astype("Int64")
    conn.register(name, df)
