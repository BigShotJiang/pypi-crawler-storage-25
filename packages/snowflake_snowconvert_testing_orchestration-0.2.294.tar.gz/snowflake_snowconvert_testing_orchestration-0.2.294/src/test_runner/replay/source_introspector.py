"""Source platform introspection strategy.

Encapsulates platform-specific behavior needed during delta capture:

* **Identifier normalization** — each RDBMS stores unquoted identifiers
  in a different case (SQL Server preserves original, Redshift/PostgreSQL
  lowercases, Snowflake uppercases).

* **Column introspection** — queries the source catalog to identify
  platform-managed columns (temporal, identity, computed) so they can
  be excluded from delta comparison on the validate side.

Use :func:`get_source_introspector` to obtain the right implementation
for a given dialect string.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .models import TableConfig

logger = logging.getLogger(__name__)

PrimaryKeyMap = dict[str, list[str]]
"""Per-table primary key columns.

Keys are normalised ``SCHEMA.TABLE``.  Values are column names in
key-ordinal order.  Tables without PKs are omitted.
"""

ColumnMetadata = dict[str, dict[str, list[str]]]
"""Per-table column metadata.

Keys are normalised ``SCHEMA.TABLE``.  Values contain:

* ``platform_managed_columns`` — temporal + computed columns
* ``identity_columns`` — auto-increment identity columns
"""


class SourceIntrospector(ABC):
    """Strategy interface for source-platform–specific introspection."""

    @abstractmethod
    def normalize_case(self, name: str) -> str:
        """Normalize an identifier to the platform's storage convention."""

    @abstractmethod
    def introspect_columns(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> ColumnMetadata:
        """Query the source catalog for platform-managed columns.

        Args:
            connection: Raw database connection.
            table_configs: :class:`TableConfig` objects identifying the
                tables to inspect.

        Returns:
            Per-table metadata dict.  Empty when no special columns
            are found or the platform has none.
        """

    def introspect_primary_keys(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> PrimaryKeyMap:
        """Discover primary key columns by querying the source catalog.

        This is a fallback for tables where CUR metadata does not
        include PK information.  The default implementation returns
        an empty dict; dialect-specific subclasses override with
        catalog queries.

        Args:
            connection: Raw database connection.
            table_configs: :class:`TableConfig` objects identifying the
                tables to inspect (typically only those lacking PKs).

        Returns:
            Mapping of ``SCHEMA.TABLE`` → list of PK column names
            in key-ordinal order.  Tables without PKs are omitted.
        """
        return {}

    def hash_row_expression(self, columns: list[str]) -> str | None:
        """Return a SQL expression that hashes *columns* into a single value.

        Used by the two-pass fetch optimization to detect row changes
        without transferring full row data.  The expression must be
        NULL-safe and deterministic for the same input on the same
        database engine.

        Returns ``None`` when the dialect does not support two-pass
        (caller falls back to one-pass ``SELECT *``).
        """
        return None


# ---------------------------------------------------------------------------
# SQL Server
# ---------------------------------------------------------------------------


class SqlServerIntrospector(SourceIntrospector):
    """SQL Server: preserves identifier case, introspects ``sys.columns``."""

    _QUERY = """\
SELECT
    s.name   AS schema_name,
    t.name   AS table_name,
    c.name   AS column_name,
    c.generated_always_type,
    c.is_identity,
    c.is_computed
FROM sys.columns c
JOIN sys.tables  t ON c.object_id = t.object_id
JOIN sys.schemas s ON t.schema_id = s.schema_id
WHERE (c.generated_always_type <> 0
       OR c.is_identity = 1
       OR c.is_computed = 1)
  AND ({table_filter})
"""

    _PK_QUERY = """\
SELECT
    s.name          AS schema_name,
    t.name          AS table_name,
    c.name          AS column_name,
    ic.key_ordinal
FROM sys.indexes i
JOIN sys.index_columns ic ON i.object_id = ic.object_id
                         AND i.index_id  = ic.index_id
JOIN sys.columns c        ON ic.object_id = c.object_id
                         AND ic.column_id = c.column_id
JOIN sys.tables  t        ON i.object_id  = t.object_id
JOIN sys.schemas s        ON t.schema_id  = s.schema_id
WHERE i.is_primary_key = 1
  AND ({table_filter})
ORDER BY s.name, t.name, ic.key_ordinal
"""

    def normalize_case(self, name: str) -> str:
        return name

    def introspect_columns(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> ColumnMetadata:
        if not table_configs:
            return {}

        table_filter = " OR ".join(
            f"(s.name = '{tc.schema_name}' AND t.name = '{tc.table_name}')"
            for tc in table_configs
        )
        sql = self._QUERY.format(table_filter=table_filter)

        metadata: ColumnMetadata = {}
        cursor = connection.cursor()
        try:
            cursor.execute(sql)
            for row in cursor.fetchall():
                schema_name = row[0].upper()
                table_name = row[1].upper()
                column_name = row[2].upper()
                generated_always_type = row[3]
                is_identity = row[4]
                is_computed = row[5]

                fqn = f"{schema_name}.{table_name}"
                entry = metadata.setdefault(fqn, {
                    "platform_managed_columns": [],
                    "identity_columns": [],
                })

                if generated_always_type != 0 or is_computed:
                    if column_name not in entry["platform_managed_columns"]:
                        entry["platform_managed_columns"].append(column_name)

                if is_identity:
                    if column_name not in entry["identity_columns"]:
                        entry["identity_columns"].append(column_name)

        except Exception as exc:
            logger.warning("SQL Server column introspection failed: %s", exc)
        finally:
            cursor.close()

        return metadata

    def introspect_primary_keys(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> PrimaryKeyMap:
        if not table_configs:
            return {}

        table_filter = " OR ".join(
            f"(s.name = '{tc.schema_name}' AND t.name = '{tc.table_name}')"
            for tc in table_configs
        )
        sql = self._PK_QUERY.format(table_filter=table_filter)

        pk_map: PrimaryKeyMap = {}
        cursor = connection.cursor()
        try:
            cursor.execute(sql)
            for row in cursor.fetchall():
                schema_name = row[0].upper()
                table_name = row[1].upper()
                column_name = row[2].upper()

                fqn = f"{schema_name}.{table_name}"
                pk_map.setdefault(fqn, []).append(column_name)
        except Exception as exc:
            logger.warning("SQL Server PK introspection failed: %s", exc)
        finally:
            cursor.close()

        return pk_map

    def hash_row_expression(self, columns: list[str]) -> str | None:
        """SHA-256 via ``HASHBYTES`` with NULL-safe encoding.

        Uses ``+`` concatenation (compatible with SQL Server 2012+)
        rather than ``CONCAT_WS`` (2017+ only).  Returns ``varbinary(32)``.
        """
        if not columns:
            return None
        parts = [
            f"""CASE WHEN "{c}" IS NULL THEN CHAR(0) """
            f"""ELSE CHAR(1) + CAST("{c}" AS NVARCHAR(MAX)) END"""
            for c in columns
        ]
        joined = " + CHAR(31) + ".join(parts)
        return f"HASHBYTES('SHA2_256', {joined})"


# ---------------------------------------------------------------------------
# Redshift
# ---------------------------------------------------------------------------


class RedshiftIntrospector(SourceIntrospector):
    """Redshift/PostgreSQL: lowercases identifiers, introspects identity columns."""

    _QUERY = """\
SELECT
    c.table_schema  AS schema_name,
    c.table_name    AS table_name,
    c.column_name   AS column_name,
    c.column_default
FROM information_schema.columns c
WHERE c.column_default LIKE '%%identity%%'
  AND ({table_filter})
"""

    _PK_QUERY = """\
SELECT
    tc.table_schema    AS schema_name,
    tc.table_name      AS table_name,
    kcu.column_name    AS column_name,
    kcu.ordinal_position
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name
 AND tc.table_schema    = kcu.table_schema
 AND tc.table_name      = kcu.table_name
WHERE tc.constraint_type = 'PRIMARY KEY'
  AND ({table_filter})
ORDER BY tc.table_schema, tc.table_name, kcu.ordinal_position
"""

    def normalize_case(self, name: str) -> str:
        return name.lower()

    def introspect_columns(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> ColumnMetadata:
        if not table_configs:
            return {}

        table_filter = " OR ".join(
            f"(c.table_schema = '{tc.schema_name}' AND c.table_name = '{tc.table_name}')"
            for tc in table_configs
        )
        sql = self._QUERY.format(table_filter=table_filter)

        metadata: ColumnMetadata = {}
        cursor = connection.cursor()
        try:
            cursor.execute(sql)
            for row in cursor.fetchall():
                schema_name = row[0].upper()
                table_name = row[1].upper()
                column_name = row[2].upper()

                fqn = f"{schema_name}.{table_name}"
                entry = metadata.setdefault(fqn, {
                    "platform_managed_columns": [],
                    "identity_columns": [],
                })

                if column_name not in entry["identity_columns"]:
                    entry["identity_columns"].append(column_name)
                if column_name not in entry["platform_managed_columns"]:
                    entry["platform_managed_columns"].append(column_name)

        except Exception as exc:
            logger.warning("Redshift column introspection failed: %s", exc)
        finally:
            cursor.close()

        return metadata

    def introspect_primary_keys(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> PrimaryKeyMap:
        if not table_configs:
            return {}

        table_filter = " OR ".join(
            f"(tc.table_schema = '{tc.schema_name}' AND tc.table_name = '{tc.table_name}')"
            for tc in table_configs
        )
        sql = self._PK_QUERY.format(table_filter=table_filter)

        pk_map: PrimaryKeyMap = {}
        cursor = connection.cursor()
        try:
            cursor.execute(sql)
            for row in cursor.fetchall():
                schema_name = row[0].upper()
                table_name = row[1].upper()
                column_name = row[2].upper()

                fqn = f"{schema_name}.{table_name}"
                pk_map.setdefault(fqn, []).append(column_name)
        except Exception as exc:
            logger.warning("Redshift PK introspection failed: %s", exc)
        finally:
            cursor.close()

        return pk_map

    def hash_row_expression(self, columns: list[str]) -> str | None:
        """MD5 hash with NULL-safe encoding (returns ``varchar(32)``).

        Uses ``||`` concatenation which is native to PostgreSQL/Redshift.
        ``VARCHAR(65535)`` is used instead of bare ``VARCHAR`` because
        Redshift defaults to ``VARCHAR(256)`` which silently truncates
        longer values and can cause false hash matches.
        """
        if not columns:
            return None
        parts = [
            f"""CASE WHEN "{c}" IS NULL THEN CHR(0) """
            f"""ELSE CHR(1) || CAST("{c}" AS VARCHAR(65535)) END"""
            for c in columns
        ]
        joined = " || CHR(31) || ".join(parts)
        return f"MD5({joined})"


# ---------------------------------------------------------------------------
# Teradata
# ---------------------------------------------------------------------------


class TeradataIntrospector(SourceIntrospector):
    """Teradata: uppercases identifiers, introspects ``DBC.ColumnsV`` for identity columns.

    Introspection is best-effort: if the connected user lacks SELECT
    access on ``DBC.ColumnsV`` the method returns empty metadata so that
    baseline capture can proceed without interruption.
    """

    # TODO: The user may need SELECT access on ``DBC.ColumnsV``.
    _QUERY = """\
SELECT
    c.DatabaseName  AS schema_name,
    c.TableName     AS table_name,
    c.ColumnName    AS column_name,
    c.IdColType
FROM DBC.ColumnsV c
WHERE c.IdColType IN ('GA', 'GD')
  AND ({table_filter})
"""

    _PK_QUERY = """\
SELECT
    DatabaseName    AS schema_name,
    TableName       AS table_name,
    ColumnName      AS column_name,
    ColumnPosition
FROM DBC.IndicesV
WHERE IndexType = 'K'
  AND ({table_filter})
ORDER BY DatabaseName, TableName, ColumnPosition
"""

    def normalize_case(self, name: str) -> str:
        return name.upper()

    def introspect_columns(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> ColumnMetadata:
        if not table_configs:
            return {}

        table_filter = " OR ".join(
            f"(c.DatabaseName = '{tc.schema_name}' AND c.TableName = '{tc.table_name}')"
            for tc in table_configs
        )
        sql = self._QUERY.format(table_filter=table_filter)

        metadata: ColumnMetadata = {}
        try:
            cursor = connection.cursor()
        except Exception as exc:
            logger.warning("Teradata column introspection skipped (cursor error): %s", exc)
            return metadata

        try:
            cursor.execute(sql)
            for row in cursor.fetchall():
                schema_name = row[0].strip().upper()
                table_name = row[1].strip().upper()
                column_name = row[2].strip().upper()

                fqn = f"{schema_name}.{table_name}"
                entry = metadata.setdefault(fqn, {
                    "platform_managed_columns": [],
                    "identity_columns": [],
                })

                if column_name not in entry["identity_columns"]:
                    entry["identity_columns"].append(column_name)
                if column_name not in entry["platform_managed_columns"]:
                    entry["platform_managed_columns"].append(column_name)

        except Exception as exc:
            logger.warning("Teradata column introspection failed: %s", exc)
        finally:
            try:
                cursor.close()
            except Exception:
                pass

        return metadata

    def introspect_primary_keys(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> PrimaryKeyMap:
        if not table_configs:
            return {}

        table_filter = " OR ".join(
            f"(DatabaseName = '{tc.schema_name}' AND TableName = '{tc.table_name}')"
            for tc in table_configs
        )
        sql = self._PK_QUERY.format(table_filter=table_filter)

        pk_map: PrimaryKeyMap = {}
        try:
            cursor = connection.cursor()
        except Exception as exc:
            logger.warning("Teradata PK introspection skipped (cursor error): %s", exc)
            return pk_map

        try:
            cursor.execute(sql)
            for row in cursor.fetchall():
                schema_name = row[0].strip().upper()
                table_name = row[1].strip().upper()
                column_name = row[2].strip().upper()

                fqn = f"{schema_name}.{table_name}"
                pk_map.setdefault(fqn, []).append(column_name)
        except Exception as exc:
            logger.warning("Teradata PK introspection failed: %s", exc)
        finally:
            try:
                cursor.close()
            except Exception:
                pass

        return pk_map

    def hash_row_expression(self, columns: list[str]) -> str | None:
        """Row hash via ``HASHROW`` with NULL-safe encoding.

        Uses ``||`` concatenation and ``HASHROW()`` which is available
        on all Teradata versions.  Returns ``BYTE(4)`` (32-bit hash).

        The 32-bit hash space is adequate for two-pass change detection
        where delta sizes are small.  For TD 16.20+ environments,
        ``HASH_MD5`` (128-bit) could be a future upgrade (SNOW-3413240).

        ``VARCHAR(64000)`` is the Teradata maximum; an explicit length
        avoids silent truncation from a shorter default.  LOB columns
        (CLOB, BLOB) cannot be cast to VARCHAR and will error at runtime
        (SNOW-3413242).
        """
        if not columns:
            return None
        parts = [
            f"""CASE WHEN "{column}" IS NULL THEN CHR(0) """
            f"""ELSE CHR(1) || CAST("{column}" AS VARCHAR(64000)) END"""
            for column in columns
        ]
        joined = " || CHR(31) || ".join(parts)
        return f"HASHROW({joined})"


# ---------------------------------------------------------------------------
# Default (fallback for unsupported dialects)
# ---------------------------------------------------------------------------

class DefaultIntrospector(SourceIntrospector):
    """Fallback: uppercases identifiers, no column introspection."""

    def normalize_case(self, name: str) -> str:
        return name.upper()

    def introspect_columns(
        self,
        connection: Any,
        table_configs: list[TableConfig],
    ) -> ColumnMetadata:
        return {}
