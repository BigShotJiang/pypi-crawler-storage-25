"""IsolationProvider abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class IsolationProvider(ABC):
    """Context-manager interface for execution isolation.

    Every method is meaningful for every implementor (ISP).  Backup
    table creation is handled inside ``setup()`` for providers that
    need it (via ``table_configs``).  Delta-based undo is passed
    through ``teardown()`` so providers can reverse changes without
    the caller needing to know the provider type.
    """

    @abstractmethod
    def setup(
        self, connection: Any, table_configs: list[Any] | None = None,
    ) -> None:
        """Prepare the isolated environment.

        *table_configs* is provided on the capture path so backup/restore
        providers can create table copies.  Transaction and clone
        providers ignore it.
        """

    @abstractmethod
    def teardown(
        self, connection: Any,
        deltas: dict[str, dict] | None = None,
        table_configs: list[Any] | None = None,
    ) -> None:
        """Roll back / clean up the isolated environment.

        *deltas* and *table_configs* are provided on the capture path
        so backup/restore providers can apply delta-based undo.
        Transaction and clone providers ignore them.
        """

    @abstractmethod
    def cleanup(self, connection: Any) -> None:
        """Force-clean any resources left behind (for test/debug recovery).

        Idempotent — safe to call even if setup was never called.
        """

    def __enter__(self) -> IsolationProvider:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        pass
