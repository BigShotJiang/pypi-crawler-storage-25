"""Composite isolation provider that routes tables by PK presence."""

from __future__ import annotations

from typing import Any

from .isolation import IsolationProvider


class CompositeIsolation(IsolationProvider):
    """Routes tables to the appropriate undo strategy based on PK presence.

    Tables WITH primary keys are handled by ``delta_undo``
    (reverses changes using captured deltas).  Tables WITHOUT primary
    keys are handled by ``backup`` (full backup/restore).

    ``setup()`` partitions ``table_configs`` and delegates to each
    inner provider.  ``teardown()`` delegates to both.
    """

    def __init__(
        self,
        backup: IsolationProvider,
        delta_undo: IsolationProvider,
    ) -> None:
        self._backup = backup
        self._delta_undo = delta_undo

    def setup(
        self, connection: Any, table_configs: list[Any] | None = None,
    ) -> None:
        if not table_configs:
            self._backup.setup(connection)
            self._delta_undo.setup(connection)
            return

        pk_tables: list[Any] = []
        non_pk_tables: list[Any] = []
        for tc in table_configs:
            (pk_tables if tc.primary_key_columns else non_pk_tables).append(tc)

        self._backup.setup(connection, non_pk_tables or None)
        self._delta_undo.setup(connection, pk_tables or None)

    def teardown(
        self, connection: Any,
        deltas: dict[str, dict] | None = None,
        table_configs: list[Any] | None = None,
    ) -> None:
        self._delta_undo.teardown(connection, deltas=deltas, table_configs=table_configs)
        self._backup.teardown(connection)

    def cleanup(self, connection: Any) -> None:
        self._backup.cleanup(connection)
        self._delta_undo.cleanup(connection)
