"""Clone-based isolation provider (Snowflake validate side)."""

from __future__ import annotations

import logging
from typing import Any

from .isolation import IsolationProvider

logger = logging.getLogger(__name__)


class SnowflakeCloneIsolation(IsolationProvider):
    """Isolation via Snowflake zero-copy clone.

    Creates ``<database>_REPLAY_<procedure>_<params_hash>`` from
    *source_database*, runs the procedure there, then drops the clone.

    Pass *procedure* and *params_hash* so parallel validation runs for
    different procs/cases don't collide.
    """

    # TODO: Add a `retain_clone` flag (default False) so that during
    # debugging we can keep the cloned database for manual inspection
    # rather than dropping it immediately.  When retained, log the
    # clone name so the user knows what to clean up.  Only drop on
    # the next run or via an explicit `cleanup()` call.

    def __init__(
        self,
        source_database: str,
        procedure: str = "",
        params_hash: str = "",
    ) -> None:
        safe_proc = procedure.replace(".", "_").replace(" ", "_")[:30].upper()
        suffix = f"{safe_proc}_{params_hash}".strip("_").upper()
        self._source = source_database
        self._clone_name = f"{source_database}_REPLAY_{suffix}" if suffix else f"{source_database}_REPLAY"
        self._created = False

    @property
    def clone_database(self) -> str:
        return self._clone_name

    def setup(
        self, connection: Any, table_configs: list[Any] | None = None,
    ) -> None:
        cursor = connection.cursor()
        try:
            cursor.execute(
                f"CREATE OR REPLACE DATABASE {self._clone_name} "
                f"CLONE {self._source}"
            )
            self._created = True
            # CREATE DATABASE switches the session to the new DB;
            # restore the original so that stage references, baseline
            # queries, and cross-database table clones resolve correctly.
            cursor.execute(f"USE DATABASE {self._source}")
            logger.info(
                "SnowflakeCloneIsolation: cloned %s -> %s",
                self._source, self._clone_name,
            )
        finally:
            cursor.close()

    def teardown(
        self, connection: Any,
        deltas: dict[str, dict] | None = None,
        table_configs: list[Any] | None = None,
    ) -> None:
        if not self._created:
            return
        cursor = connection.cursor()
        try:
            cursor.execute(f"DROP DATABASE IF EXISTS {self._clone_name}")
            self._created = False
            logger.info(
                "SnowflakeCloneIsolation: dropped clone %s",
                self._clone_name,
            )
        finally:
            cursor.close()

    def revert_tables(self, connection: Any, tables: list[str]) -> None:
        """Revert specific tables in the clone from the source database.

        Each entry in *tables* should be ``SCHEMA.TABLE``.  Executes::

            CREATE OR REPLACE TABLE <clone>.SCHEMA.TABLE
                CLONE <source>.SCHEMA.TABLE

        This is dramatically faster than re-cloning the entire database
        (~0.1-0.3 s per table vs ~9-10 s for a full DB clone).
        """
        if not tables or not self._created:
            return
        cursor = connection.cursor()
        try:
            for fqn in tables:
                sql = (
                    f"CREATE OR REPLACE TABLE {self._clone_name}.{fqn} "
                    f"CLONE {self._source}.{fqn}"
                )
                try:
                    cursor.execute(sql)
                except Exception:
                    logger.error(
                        "SnowflakeCloneIsolation: revert failed — %s", sql,
                    )
                    raise
                logger.debug(
                    "SnowflakeCloneIsolation: reverted %s.%s from %s",
                    self._clone_name, fqn, self._source,
                )
            logger.info(
                "SnowflakeCloneIsolation: reverted %d table(s) in %s",
                len(tables), self._clone_name,
            )
        finally:
            cursor.close()

    def cleanup(self, connection: Any) -> None:
        """Force-drop the clone database regardless of creation state."""
        cursor = connection.cursor()
        try:
            cursor.execute(f"DROP DATABASE IF EXISTS {self._clone_name}")
            self._created = False
            logger.info(
                "SnowflakeCloneIsolation: cleanup dropped %s",
                self._clone_name,
            )
        finally:
            cursor.close()
