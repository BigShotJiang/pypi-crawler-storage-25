"""Transaction-based isolation providers (BEGIN / ROLLBACK)."""

from __future__ import annotations

import logging
from typing import Any

from .isolation import IsolationProvider

logger = logging.getLogger(__name__)


class SqlServerTransactionIsolation(IsolationProvider):
    """Isolation via ``BEGIN TRANSACTION`` / ``ROLLBACK``.

    The caller is responsible for passing the *same* connection to
    :meth:`setup`, the procedure CALL, and :meth:`teardown`.

    pyodbc connections default to ``autocommit=False``, which causes the
    ODBC driver to manage transactions at the driver level.  SQL-level
    ``BEGIN TRANSACTION`` / ``ROLLBACK`` are ignored in that mode and
    data persists despite ROLLBACK.  To guarantee proper isolation, we
    temporarily switch to ``autocommit=True`` so that SQL Server itself
    honours the explicit transaction boundary.
    """

    def __init__(self) -> None:
        self._active = False
        self._prev_autocommit: bool | None = None

    def setup(
        self, connection: Any, table_configs: list[Any] | None = None,
    ) -> None:
        self._prev_autocommit = getattr(connection, "autocommit", None)
        if self._prev_autocommit is not None:
            connection.autocommit = True
        cursor = connection.cursor()
        try:
            cursor.execute("BEGIN TRANSACTION")
            self._active = True
            logger.debug("SqlServerTransactionIsolation: BEGIN TRANSACTION issued (autocommit forced True)")
        finally:
            cursor.close()

    def teardown(
        self, connection: Any,
        deltas: dict[str, dict] | None = None,
        table_configs: list[Any] | None = None,
    ) -> None:
        if not self._active:
            return
        cursor = connection.cursor()
        try:
            cursor.execute("ROLLBACK")
            self._active = False
            logger.debug("SqlServerTransactionIsolation: ROLLBACK issued")
        finally:
            cursor.close()
        if self._prev_autocommit is not None:
            connection.autocommit = self._prev_autocommit
            self._prev_autocommit = None

    def cleanup(self, connection: Any) -> None:
        self.teardown(connection)


class RedshiftTransactionIsolation(IsolationProvider):
    """Isolation via ``BEGIN`` / ``ROLLBACK`` for Redshift (PostgreSQL wire protocol).

    ``redshift_connector`` defaults to ``autocommit=False``, but the
    ``RedshiftExecutor`` sets ``autocommit=True`` at init time so that
    individual failed statements don't poison the connection.

    For isolation we need the opposite: ``autocommit=False`` so that
    ``BEGIN`` opens a real transaction block and ``ROLLBACK`` undoes all
    changes made within it.
    """

    def __init__(self) -> None:
        self._active = False
        self._prev_autocommit: bool | None = None

    def setup(
        self, connection: Any, table_configs: list[Any] | None = None,
    ) -> None:
        self._prev_autocommit = getattr(connection, "autocommit", None)
        if self._prev_autocommit is None:
            raise RuntimeError(
                "RedshiftTransactionIsolation requires a connection with an "
                "'autocommit' attribute. Cannot guarantee isolation without "
                "explicit autocommit control."
            )
        connection.autocommit = False
        cursor = connection.cursor()
        try:
            cursor.execute("BEGIN")
            self._active = True
            logger.debug("RedshiftTransactionIsolation: BEGIN issued (autocommit forced False)")
        finally:
            cursor.close()

    def teardown(
        self, connection: Any,
        deltas: dict[str, dict] | None = None,
        table_configs: list[Any] | None = None,
    ) -> None:
        if not self._active:
            return
        cursor = connection.cursor()
        try:
            cursor.execute("ROLLBACK")
            self._active = False
            logger.debug("RedshiftTransactionIsolation: ROLLBACK issued")
        finally:
            cursor.close()
        if self._prev_autocommit is not None:
            connection.autocommit = self._prev_autocommit
            self._prev_autocommit = None

    def cleanup(self, connection: Any) -> None:
        self.teardown(connection)
