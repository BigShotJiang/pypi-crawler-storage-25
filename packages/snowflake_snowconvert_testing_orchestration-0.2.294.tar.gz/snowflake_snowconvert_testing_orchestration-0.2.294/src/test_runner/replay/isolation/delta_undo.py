"""Delta-based undo isolation provider for tables with primary keys."""

from __future__ import annotations

import logging
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any

from .isolation import IsolationProvider

logger = logging.getLogger(__name__)


class DeltaUndoIsolation(IsolationProvider):
    """Reverses procedure side-effects using captured deltas and PK targeting.

    No backups are created.  In ``teardown()``, each table's captured
    delta is used to generate reversal SQL:

    - Inserted rows are DELETEd by PK.
    - Deleted rows are re-INSERTed.
    - Updated rows are SET back to their before values.

    Only processes tables that have PK columns and a corresponding delta.
    Tables without PKs are ignored (they should be handled by a
    ``BackupRestoreIsolation`` via ``CompositeIsolation``).
    """

    def setup(
        self, connection: Any, table_configs: list[Any] | None = None,
    ) -> None:
        pass

    def teardown(
        self, connection: Any,
        deltas: dict[str, dict] | None = None,
        table_configs: list[Any] | None = None,
    ) -> None:
        if not deltas or not table_configs:
            return

        pk_configs = {tc.fqn: tc for tc in table_configs if tc.primary_key_columns}
        if not pk_configs:
            return

        for fqn, table_config in pk_configs.items():
            delta = deltas.get(fqn)
            if delta is None:
                continue

            schema = table_config.schema_name
            table = table_config.table_name
            pk_cols_upper = [col.upper() for col in table_config.primary_key_columns]
            cursor = connection.cursor()
            try:
                for row in delta.get("inserts", []):
                    where = _pk_where_clause(pk_cols_upper, row)
                    cursor.execute(
                        f'DELETE FROM "{schema}"."{table}" WHERE {where}'
                    )

                for row in delta.get("deletes", []):
                    cols = ", ".join(col for col in row.keys())
                    vals = ", ".join(_format_sql_value(val) for val in row.values())
                    cursor.execute(
                        f'INSERT INTO "{schema}"."{table}" ({cols}) VALUES ({vals})'
                    )

                for update_entry in delta.get("updates", []):
                    key = update_entry["key"]
                    before = update_entry["before"]
                    changed = update_entry["changed_columns"]
                    set_clause = ", ".join(
                        f'{col} = {_format_sql_value(before[col])}' for col in changed
                    )
                    where = _pk_where_clause(pk_cols_upper, key)
                    cursor.execute(
                        f'UPDATE "{schema}"."{table}" SET {set_clause} WHERE {where}'
                    )

                undo_count = (
                    len(delta.get("inserts", []))
                    + len(delta.get("deletes", []))
                    + len(delta.get("updates", []))
                )
                if undo_count:
                    logger.debug(
                        "Delta-based undo for %s: reversed %d change(s)",
                        fqn, undo_count,
                    )
            except Exception:
                logger.error("Delta-based undo failed for %s", fqn)
                raise
            finally:
                cursor.close()
        connection.commit()

    def cleanup(self, connection: Any) -> None:
        pass


def _format_sql_value(value: Any) -> str:
    """Format a Python value as a SQL literal for undo statements."""
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float, Decimal)):
        return str(value)
    if isinstance(value, datetime):
        return f"'{value.isoformat()}'"
    if isinstance(value, date):
        return f"'{value.isoformat()}'"
    if isinstance(value, time):
        return f"'{value.isoformat()}'"
    if isinstance(value, bytes):
        raise TypeError(
            f"Cannot format bytes value as SQL literal: {value!r}"
        )
    if isinstance(value, str):
        escaped = value.replace("'", "''")
        return f"'{escaped}'"
    escaped = str(value).replace("'", "''")
    return f"'{escaped}'"


def _pk_where_clause(pk_columns: list[str], row: dict[str, Any]) -> str:
    """Build a WHERE clause matching on PK columns.

    Column names are NOT quoted so they are treated
    case-insensitively across all dialects.
    """
    parts = []
    for col in pk_columns:
        val = row.get(col)
        if val is None:
            parts.append(f"{col} IS NULL")
        else:
            parts.append(f"{col} = {_format_sql_value(val)}")
    return " AND ".join(parts)
