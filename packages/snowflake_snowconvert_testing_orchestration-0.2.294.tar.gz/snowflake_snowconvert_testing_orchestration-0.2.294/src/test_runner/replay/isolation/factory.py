"""Isolation factories -- select the correct provider per dialect."""

from __future__ import annotations

from abc import ABC, abstractmethod

from .isolation import IsolationProvider
from .transaction import SqlServerTransactionIsolation, RedshiftTransactionIsolation
from .backup import (
    SqlServerBackupRestoreIsolation,
    RedshiftBackupRestoreIsolation,
    TeradataBackupRestoreIsolation,
)
from .delta_undo import DeltaUndoIsolation
from .composite import CompositeIsolation
from .snapshot import SqlServerSnapshotIsolation


class IsolationFactory(ABC):
    """Selects the appropriate isolation strategy for a dialect."""

    @abstractmethod
    def create(self, contains_commit: bool = False) -> IsolationProvider:
        """Return the correct provider based on the ``contains_commit`` flag."""


class SqlServerIsolationFactory(IsolationFactory):
    """SQL Server: transaction rollback by default, composite
    backup/restore + delta undo when the procedure contains COMMIT.
    When *use_snapshot* is True the database-snapshot strategy is used
    instead of composite backup/restore."""

    def create(
        self,
        contains_commit: bool = False,
        use_snapshot: bool = False,
    ) -> IsolationProvider:
        if use_snapshot:
            return SqlServerSnapshotIsolation()
        if contains_commit:
            return CompositeIsolation(
                backup=SqlServerBackupRestoreIsolation(),
                delta_undo=DeltaUndoIsolation(),
            )
        return SqlServerTransactionIsolation()


class RedshiftIsolationFactory(IsolationFactory):
    """Redshift: transaction rollback by default, composite
    backup/restore + delta undo when the procedure contains COMMIT."""

    def create(self, contains_commit: bool = False) -> IsolationProvider:
        if contains_commit:
            return CompositeIsolation(
                backup=RedshiftBackupRestoreIsolation(),
                delta_undo=DeltaUndoIsolation(),
            )
        return RedshiftTransactionIsolation()


class TeradataIsolationFactory(IsolationFactory):
    """Teradata: always uses composite backup/restore + delta undo
    because Teradata sub-transaction semantics prevent transaction
    rollback from working correctly."""

    def create(self, contains_commit: bool = False) -> IsolationProvider:
        return CompositeIsolation(
            backup=TeradataBackupRestoreIsolation(),
            delta_undo=DeltaUndoIsolation(),
        )
