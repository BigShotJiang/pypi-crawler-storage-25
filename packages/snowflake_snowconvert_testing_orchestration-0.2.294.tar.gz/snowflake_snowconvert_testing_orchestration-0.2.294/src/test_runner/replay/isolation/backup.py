"""Backup/restore isolation providers for procedures containing COMMIT."""

from __future__ import annotations

import logging
from abc import abstractmethod
from typing import Any

from .isolation import IsolationProvider

logger = logging.getLogger(__name__)


class BackupRestoreIsolation(IsolationProvider):
    """Abstract base for backup/restore isolation providers.

    Subclasses provide ``_make_backup_sql()`` for dialect-specific
    backup DDL.

    ``setup()`` creates backup copies of ALL affected tables.
    ``teardown()`` restores ALL tables from backup.
    """

    _BACKUP_SUFFIX = "__SCAI_BKP"

    def __init__(self) -> None:
        self._backups: list[tuple[str, str, str]] = []

    @abstractmethod
    def _make_backup_sql(self, schema: str, table: str, backup: str) -> str:
        """Return the dialect-specific SQL to create a backup table."""

    def _drop_backup_sql(self, schema: str, backup: str) -> str:
        """Return SQL to drop a backup table if it exists.

        Default uses ``IF EXISTS`` (SQL Server, Redshift).  Teradata
        overrides without ``IF EXISTS`` since it is not supported.
        """
        return f'DROP TABLE IF EXISTS "{schema}"."{backup}"'

    def setup(
        self, connection: Any, table_configs: list[Any] | None = None,
    ) -> None:
        if table_configs:
            self._create_backups(connection, table_configs)

    def _create_backups(
        self, connection: Any, table_configs: list[Any],
    ) -> None:
        for table_config in table_configs:
            schema = table_config.schema_name
            table = table_config.table_name
            backup = f"{table}{self._BACKUP_SUFFIX}"
            cursor = connection.cursor()
            try:
                try:
                    cursor.execute(self._drop_backup_sql(schema, backup))
                except Exception:
                    pass
                cursor.execute(self._make_backup_sql(schema, table, backup))
                self._backups.append((schema, table, backup))
                logger.debug(
                    "%s: backed up %s.%s -> %s.%s",
                    type(self).__name__, schema, table, schema, backup,
                )
            except Exception:
                logger.error(
                    "%s: failed to backup %s.%s",
                    type(self).__name__, schema, table,
                )
                raise
            finally:
                cursor.close()

    def teardown(
        self, connection: Any,
        deltas: dict[str, dict] | None = None,
        table_configs: list[Any] | None = None,
    ) -> None:
        if not self._backups:
            return
        for schema, table, backup in self._backups:

            cursor = connection.cursor()
            try:
                cursor.execute(f'DELETE FROM "{schema}"."{table}"')
                cursor.execute(
                    f'INSERT INTO "{schema}"."{table}" '
                    f'SELECT * FROM "{schema}"."{backup}"'
                )
                cursor.execute(f'DROP TABLE "{schema}"."{backup}"')
                logger.debug(
                    "%s: restored %s.%s from backup",
                    type(self).__name__, schema, table,
                )
            except Exception:
                logger.error(
                    "%s: failed to restore %s.%s "
                    "— backup table %s.%s may still exist",
                    type(self).__name__, schema, table, schema, backup,
                )
                raise
            finally:
                cursor.close()
        self._backups.clear()
        connection.commit()

    def cleanup(self, connection: Any) -> None:
        """Drop any leftover backup tables (idempotent)."""
        for schema, _table, backup in self._backups:
            cursor = connection.cursor()
            try:
                cursor.execute(self._drop_backup_sql(schema, backup))
            except Exception:
                pass
            finally:
                cursor.close()
        self._backups.clear()


class SqlServerBackupRestoreIsolation(BackupRestoreIsolation):
    """Backup/restore isolation for SQL Server procedures containing COMMIT.

    Uses ``SELECT * INTO`` to create table backups.
    """

    def _make_backup_sql(self, schema: str, table: str, backup: str) -> str:
        return f'SELECT * INTO "{schema}"."{backup}" FROM "{schema}"."{table}"'


class RedshiftBackupRestoreIsolation(BackupRestoreIsolation):
    """Backup/restore isolation for Redshift procedures containing COMMIT.

    Uses ``CREATE TABLE AS SELECT`` to create table backups.
    """

    def _make_backup_sql(self, schema: str, table: str, backup: str) -> str:
        return (
            f'CREATE TABLE "{schema}"."{backup}" AS '
            f'SELECT * FROM "{schema}"."{table}"'
        )


class TeradataBackupRestoreIsolation(BackupRestoreIsolation):
    """Backup/restore isolation for Teradata delta capture.

    Teradata stored procedures execute DML in their own internal
    sub-transactions.  When wrapped in ``BT`` / ``ROLLBACK``, the
    outer transaction uses read-repeatable semantics: ``SELECT *``
    snapshots see data as of ``BT`` time, **not** the procedure's
    committed changes.  This makes before/after snapshots identical
    and delta capture silently produces zero changes.

    ``setup()`` ensures autocommit is on (no ``BT``), then creates
    backup copies of affected tables.
    """

    def setup(
        self, connection: Any, table_configs: list[Any] | None = None,
    ) -> None:
        prev = getattr(connection, "autocommit", None)
        if prev is not None and not prev:
            connection.autocommit = True
            logger.debug(
                "%s: autocommit was %s, forced True",
                type(self).__name__, prev,
            )
        logger.debug("%s: setup (no BT, backup/restore mode)", type(self).__name__)
        super().setup(connection, table_configs)

    def _make_backup_sql(self, schema: str, table: str, backup: str) -> str:
        return (
            f'CREATE TABLE "{schema}"."{backup}" AS '
            f'(SELECT * FROM "{schema}"."{table}") WITH DATA'
        )

    def _drop_backup_sql(self, schema: str, backup: str) -> str:
        return f'DROP TABLE "{schema}"."{backup}"'
