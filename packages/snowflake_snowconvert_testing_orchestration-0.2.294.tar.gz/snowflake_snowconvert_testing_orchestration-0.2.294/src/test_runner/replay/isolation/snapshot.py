"""SQL Server database-snapshot isolation provider."""

from __future__ import annotations

import logging
from typing import Any

from .isolation import IsolationProvider

logger = logging.getLogger(__name__)


def _snapshot_file_path(physical_name: str) -> str:
    """Derive a snapshot file path from a data file's physical name.

    Strips the file extension and appends ``_SCAI_SNAP.ss``.
    Uses only string operations so it works for paths on the SQL Server
    host regardless of the client OS (Linux client, Windows server).

    Examples::

        "C:\\Data\\MyDB.mdf"              -> "C:\\Data\\MyDB_SCAI_SNAP.ss"
        "/var/opt/mssql/data/TestDB.mdf" -> "/var/opt/mssql/data/TestDB_SCAI_SNAP.ss"
        "C:\\Data\\MyDB_2.ndf"           -> "C:\\Data\\MyDB_2_SCAI_SNAP.ss"
    """
    dot_pos = physical_name.rfind(".")
    sep_pos = max(physical_name.rfind("\\"), physical_name.rfind("/"))
    if dot_pos != -1 and dot_pos > sep_pos:
        return physical_name[:dot_pos] + "_SCAI_SNAP.ss"
    return physical_name + "_SCAI_SNAP.ss"


class SqlServerSnapshotIsolation(IsolationProvider):
    """Database-level isolation via ``CREATE DATABASE SNAPSHOT`` / ``RESTORE``.

    Used when the stored procedure issues its own ``COMMIT``, making
    transaction-based rollback ineffective.  Because a database snapshot
    is stored at the *page* level (copy-on-write), it captures the
    pre-procedure state even after inner ``COMMIT`` statements.

    Workflow
    --------
    1. ``setup()``:  Query ``sys.database_files`` for data file info, then::

           CREATE DATABASE [<source>__SCAI_SNAP]
           ON (NAME=[…], FILENAME=N'…'), …
           AS SNAPSHOT OF [<source>]

    2. ``teardown()``:  Revert all side-effects by restoring the source
       database from the snapshot::

           USE [master]
           ALTER DATABASE [<source>] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
           RESTORE DATABASE [<source>] FROM DATABASE_SNAPSHOT = N'<snapshot>'
           ALTER DATABASE [<source>] SET MULTI_USER
           DROP DATABASE IF EXISTS [<snapshot>]
           USE [<source>]

    3. ``cleanup()``:  Drop the snapshot if it still exists (idempotent).

    Requires
    --------
    SQL Server 2016 SP1 or later (Standard, Enterprise, or Developer
    edition).  Database snapshots are not supported on Express edition.
    """

    _SNAPSHOT_SUFFIX = "__SCAI_SNAP"

    def __init__(self) -> None:
        self._snapshot_name: str | None = None
        self._source_db: str | None = None

    # ------------------------------------------------------------------
    # IsolationProvider interface
    # ------------------------------------------------------------------

    def setup(
        self,
        connection: Any,
        table_configs: list[Any] | None = None,
    ) -> None:
        """Create a database snapshot of the current connection's database."""
        self._source_db = self._current_db(connection)
        self._snapshot_name = f"{self._source_db}{self._SNAPSHOT_SUFFIX}"

        files = self._query_data_files(connection)
        if not files:
            raise RuntimeError(
                f"No data files found in sys.database_files for database "
                f"'{self._source_db}'; cannot create snapshot."
            )

        self._drop_snapshot(connection)

        on_parts = [
            f"(NAME = [{logical_name}], FILENAME = N'{_snapshot_file_path(physical_name)}')"
            for logical_name, physical_name in files
        ]
        create_sql = (
            f"CREATE DATABASE [{self._snapshot_name}] "
            f"ON {', '.join(on_parts)} "
            f"AS SNAPSHOT OF [{self._source_db}]"
        )

        cursor = connection.cursor()
        try:
            cursor.execute(create_sql)
            logger.debug(
                "SqlServerSnapshotIsolation: snapshot '%s' created from '%s'",
                self._snapshot_name, self._source_db,
            )
        finally:
            cursor.close()

    def teardown(
        self,
        connection: Any,
        deltas: dict[str, dict] | None = None,
        table_configs: list[Any] | None = None,
    ) -> None:
        """Restore the source database from the snapshot and drop it."""
        if not self._snapshot_name or not self._source_db:
            return

        source_db = self._source_db
        snapshot_name = self._snapshot_name

        cursor = connection.cursor()
        try:
            cursor.execute("USE [master]")
        finally:
            cursor.close()

        try:
            cursor = connection.cursor()
            try:
                cursor.execute(
                    f"ALTER DATABASE [{source_db}] "
                    f"SET SINGLE_USER WITH ROLLBACK IMMEDIATE"
                )
                logger.debug(
                    "SqlServerSnapshotIsolation: '%s' set to SINGLE_USER",
                    source_db,
                )
            finally:
                cursor.close()

            cursor = connection.cursor()
            try:
                cursor.execute(
                    f"RESTORE DATABASE [{source_db}] "
                    f"FROM DATABASE_SNAPSHOT = N'{snapshot_name}'"
                )
                logger.debug(
                    "SqlServerSnapshotIsolation: '%s' restored from snapshot '%s'",
                    source_db, snapshot_name,
                )
            finally:
                cursor.close()

        finally:
            cursor = connection.cursor()
            try:
                cursor.execute(f"ALTER DATABASE [{source_db}] SET MULTI_USER")
            except Exception:
                logger.warning(
                    "SqlServerSnapshotIsolation: failed to restore MULTI_USER on '%s'",
                    source_db,
                )
            finally:
                cursor.close()

            self._drop_snapshot_by_name(connection, snapshot_name)
            self._snapshot_name = None
            self._source_db = None

            cursor = connection.cursor()
            try:
                cursor.execute(f"USE [{source_db}]")
            except Exception:
                logger.warning(
                    "SqlServerSnapshotIsolation: failed to switch back to '%s'",
                    source_db,
                )
            finally:
                cursor.close()

    def cleanup(self, connection: Any) -> None:
        """Drop the snapshot if it still exists (idempotent)."""
        if not self._snapshot_name:
            return
        snapshot_name = self._snapshot_name
        self._snapshot_name = None
        self._source_db = None
        self._drop_snapshot_by_name(connection, snapshot_name)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _current_db(connection: Any) -> str:
        """Return the name of the current database on *connection*."""
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT DB_NAME()")
            row = cursor.fetchone()
            return row[0]
        finally:
            cursor.close()

    @staticmethod
    def _query_data_files(connection: Any) -> list[tuple[str, str]]:
        """Return ``(logical_name, physical_name)`` pairs for all data files."""
        cursor = connection.cursor()
        try:
            cursor.execute(
                "SELECT name, physical_name "
                "FROM sys.database_files "
                "WHERE type = 0"  # 0 = ROWS (data files); excludes log/FILESTREAM
            )
            return [(row[0], row[1]) for row in cursor.fetchall()]
        finally:
            cursor.close()

    def _drop_snapshot(self, connection: Any) -> None:
        if self._snapshot_name:
            self._drop_snapshot_by_name(connection, self._snapshot_name)

    @staticmethod
    def _drop_snapshot_by_name(connection: Any, snapshot_name: str) -> None:
        cursor = connection.cursor()
        try:
            cursor.execute(f"DROP DATABASE IF EXISTS [{snapshot_name}]")
            logger.debug(
                "SqlServerSnapshotIsolation: snapshot '%s' dropped", snapshot_name,
            )
        except Exception:
            logger.warning(
                "SqlServerSnapshotIsolation: failed to drop snapshot '%s'",
                snapshot_name,
            )
        finally:
            cursor.close()
