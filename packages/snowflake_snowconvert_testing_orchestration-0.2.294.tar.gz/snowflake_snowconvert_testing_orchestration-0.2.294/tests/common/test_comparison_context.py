"""Tests for common.comparison_context — ComparisonContext construction and queries."""

from __future__ import annotations

from test_runner.common.comparison_context import ComparisonContext
from test_runner.common.models.test_file import TestFile
from test_runner.common.models.validation_steps import ValidationSteps


def _make_test_file(
    set_tables: list[str] | None = None,
    affected_tables: list[str] | None = None,
    read_tables: list[str] | None = None,
) -> TestFile:
    return TestFile(
        file_path="/tmp/test.yaml",
        source=ValidationSteps(run="SELECT 1"),
        test_cases=[],
        set_tables=set_tables or [],
        affected_tables=affected_tables,
        read_tables=read_tables,
    )


class TestFromTestFile:
    def test_empty_set_tables_produces_empty_frozenset(self):
        cmp_ctx = ComparisonContext.from_test_file(_make_test_file())
        assert cmp_ctx.set_tables == frozenset()
        assert not cmp_ctx.set_tables

    def test_populates_set_tables_uppercase(self):
        cmp_ctx = ComparisonContext.from_test_file(
            _make_test_file(set_tables=["db.schema.MyTable"])
        )
        assert cmp_ctx.set_tables == frozenset({"DB.SCHEMA.MYTABLE"})
        assert cmp_ctx.set_tables

    def test_multiple_set_tables_all_uppercased(self):
        cmp_ctx = ComparisonContext.from_test_file(
            _make_test_file(set_tables=["a.b.c", "d.e.f"])
        )
        assert len(cmp_ctx.set_tables) == 2


class TestReadsSetTable:
    def test_true_when_affected_table_is_set(self):
        cmp_ctx = ComparisonContext.from_test_file(_make_test_file(
            set_tables=["db.schema.t1"],
            affected_tables=["db.schema.t1"],
        ))
        assert cmp_ctx.reads_set_table

    def test_true_when_read_table_is_set(self):
        cmp_ctx = ComparisonContext.from_test_file(_make_test_file(
            set_tables=["db.schema.t1"],
            read_tables=["db.schema.t1"],
        ))
        assert cmp_ctx.reads_set_table

    def test_false_when_no_overlap(self):
        cmp_ctx = ComparisonContext.from_test_file(_make_test_file(
            set_tables=["db.schema.t1"],
            affected_tables=["db.schema.t2"],
        ))
        assert not cmp_ctx.reads_set_table

    def test_false_when_no_set_tables(self):
        cmp_ctx = ComparisonContext.from_test_file(
            _make_test_file(affected_tables=["db.schema.t1"])
        )
        assert not cmp_ctx.reads_set_table
