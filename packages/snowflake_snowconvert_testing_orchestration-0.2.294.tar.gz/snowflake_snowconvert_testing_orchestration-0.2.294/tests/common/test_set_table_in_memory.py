"""Tests for adjust_in_memory_result with a real DuckDB connection."""

from __future__ import annotations

from dataclasses import dataclass

import duckdb
import pandas as pd

from test_runner.common.set_table import (
    RISK_CONFIRMED,
    RISK_POSSIBLE,
    adjust_in_memory_result,
)


@dataclass
class _FakeValidationResult:
    """Minimal stand-in for SDV ValidationResult (only ``is_valid`` used)."""
    is_valid: bool


def _make_conn(
    baseline_rows: list[dict],
    actual_rows: list[dict],
    columns: list[str],
) -> duckdb.DuckDBPyConnection:
    """Create a real DuckDB connection with baseline/actual tables registered."""
    conn = duckdb.connect()
    for name, rows in [("baseline", baseline_rows), ("actual", actual_rows)]:
        if rows:
            dataframe = pd.DataFrame(rows, columns=columns)
        else:
            dataframe = pd.DataFrame(columns=columns)
        dataframe.insert(0, "_row", range(1, len(dataframe) + 1))
        conn.register(name, dataframe)
    return conn


def _make_result(
    baseline_count: int,
    actual_count: int,
    row_match: bool = False,
) -> dict:
    return {
        "match": False,
        "row_counts": {
            "baseline": baseline_count,
            "actual": actual_count,
            "match": row_match,
        },
        "summary_stats": {"match": True},
        "cell_diffs": [],
    }


COLUMNS = ["ID", "V"]


class TestAdjustInMemoryResult:
    """Exercise adjust_in_memory_result against a real DuckDB engine."""

    def test_row_counts_already_match_returns_early(self):
        baseline = [{"ID": 1, "V": "a"}]
        actual = [{"ID": 1, "V": "a"}]
        conn = _make_conn(baseline, actual, COLUMNS)

        result = _make_result(1, 1, row_match=True)
        adjust_in_memory_result(
            result,
            conn=conn,
            columns=COLUMNS,
            baseline_rows=baseline,
            validate_cell_fn=lambda **kw: _FakeValidationResult(is_valid=True),
            cell_level_kwargs={},
        )
        conn.close()
        assert "set_table_risk" not in result["row_counts"]

    def test_confirmed_when_distinct_matches_and_cells_valid(self):
        baseline = [{"ID": 1, "V": "a"}, {"ID": 2, "V": "b"}]
        actual = [{"ID": 1, "V": "a"}, {"ID": 1, "V": "a"}, {"ID": 2, "V": "b"}]
        conn = _make_conn(baseline, actual, COLUMNS)

        result = _make_result(2, 3)
        adjust_in_memory_result(
            result,
            conn=conn,
            columns=COLUMNS,
            baseline_rows=baseline,
            validate_cell_fn=lambda **kw: _FakeValidationResult(is_valid=True),
            cell_level_kwargs={},
        )
        conn.close()
        assert result["row_counts"]["set_table_risk"] == RISK_CONFIRMED
        assert result["row_counts"]["match"] is True
        assert result["match"] is True
        assert result["row_counts"]["distinct_actual"] == 2
        assert result["row_counts"]["duplicate_rows"] == 1

    def test_possible_when_distinct_count_differs_from_baseline(self):
        baseline = [{"ID": 1, "V": "a"}]
        actual = [{"ID": 1, "V": "a"}, {"ID": 2, "V": "b"}, {"ID": 2, "V": "b"}]
        conn = _make_conn(baseline, actual, COLUMNS)

        result = _make_result(1, 3)
        adjust_in_memory_result(
            result,
            conn=conn,
            columns=COLUMNS,
            baseline_rows=baseline,
            validate_cell_fn=lambda **kw: _FakeValidationResult(is_valid=True),
            cell_level_kwargs={},
        )
        conn.close()
        assert result["row_counts"]["set_table_risk"] == RISK_POSSIBLE
        assert result["row_counts"]["distinct_actual"] == 2
        assert result["match"] is False

    def test_confirmed_with_special_character_column_names(self):
        """Column names with spaces and embedded double-quotes are escaped correctly."""
        cols = ["col one", 'col"two']
        baseline = [{"col one": 1, 'col"two': "a"}, {"col one": 2, 'col"two': "b"}]
        actual = [
            {"col one": 1, 'col"two': "a"},
            {"col one": 1, 'col"two': "a"},
            {"col one": 2, 'col"two': "b"},
        ]
        conn = _make_conn(baseline, actual, cols)

        result = _make_result(2, 3)
        adjust_in_memory_result(
            result,
            conn=conn,
            columns=cols,
            baseline_rows=baseline,
            validate_cell_fn=lambda **kw: _FakeValidationResult(is_valid=True),
            cell_level_kwargs={},
        )
        conn.close()
        assert result["row_counts"]["set_table_risk"] == RISK_CONFIRMED
        assert result["row_counts"]["match"] is True
        assert result["match"] is True
        assert result["row_counts"]["distinct_actual"] == 2
        assert result["row_counts"]["duplicate_rows"] == 1

    def test_possible_when_distinct_matches_but_cells_invalid(self):
        baseline = [{"ID": 1, "V": "a"}, {"ID": 2, "V": "b"}]
        actual = [{"ID": 1, "V": "a"}, {"ID": 1, "V": "a"}, {"ID": 2, "V": "DIFFERENT"}]
        conn = _make_conn(baseline, actual, COLUMNS)

        result = _make_result(2, 3)
        adjust_in_memory_result(
            result,
            conn=conn,
            columns=COLUMNS,
            baseline_rows=baseline,
            validate_cell_fn=lambda **kw: _FakeValidationResult(is_valid=False),
            cell_level_kwargs={},
        )
        conn.close()
        assert result["row_counts"]["set_table_risk"] == RISK_POSSIBLE
        assert result["match"] is False
