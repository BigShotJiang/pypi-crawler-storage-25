"""Tests for common.set_table — SET table dedup classifier."""

from __future__ import annotations

import pytest

from test_runner.common.set_table import (
    RISK_CONFIRMED,
    RISK_POSSIBLE,
    _dedup_rows,
    adjust_delta_diff,
)


class TestDedupRows:
    def test_empty_input_returns_empty_list(self):
        assert _dedup_rows([]) == []

    def test_no_duplicates(self):
        rows = [{"a": 1}, {"a": 2}]
        assert _dedup_rows(rows) == rows

    def test_removes_exact_duplicates(self):
        rows = [{"a": 1, "b": "x"}, {"a": 1, "b": "x"}, {"a": 2, "b": "y"}]
        result = _dedup_rows(rows)
        assert len(result) == 2
        assert result[0] == {"a": 1, "b": "x"}
        assert result[1] == {"a": 2, "b": "y"}

    def test_preserves_order(self):
        rows = [{"a": 3}, {"a": 1}, {"a": 3}, {"a": 2}]
        result = _dedup_rows(rows)
        assert [r["a"] for r in result] == [3, 1, 2]


class TestAdjustDeltaDiff:
    """Tests for adjust_delta_diff annotation and match-flipping."""

    SET_TABLES = frozenset({"DB.SCHEMA.MY_TABLE"})

    def _make_diff(self, diff_type: str, baseline: int, actual: int) -> dict:
        return {"type": diff_type, "baseline": baseline, "actual": actual}

    def test_noop_when_table_not_in_set_tables(self):
        diff = self._make_diff("insert_count_mismatch", 3, 5)
        adjust_delta_diff(
            diff, "DB.SCHEMA.OTHER_TABLE", self.SET_TABLES,
            baseline_rows=[{"a": 1}] * 3,
            actual_rows=[{"a": 1}] * 5,
            compare_fn=lambda *_a, **_kw: [],
            max_cell_diffs=10,
        )
        assert "set_table_risk" not in diff

    @pytest.mark.parametrize(
        ("table_fqn", "baseline", "actual", "expected_distinct", "expected_dupes"),
        [
            pytest.param(
                "DB.SCHEMA.MY_TABLE",
                [{"id": 1, "v": "a"}, {"id": 2, "v": "b"}, {"id": 3, "v": "c"}],
                [{"id": 1, "v": "a"}, {"id": 1, "v": "a"}, {"id": 2, "v": "b"}, {"id": 3, "v": "c"}],
                3, 1,
                id="exact-case",
            ),
            pytest.param(
                "db.schema.my_table",
                [{"a": 1}],
                [{"a": 1}, {"a": 1}],
                1, 1,
                id="case-insensitive",
            ),
        ],
    )
    def test_confirmed_when_dedup_matches_and_cells_match(
        self, table_fqn, baseline, actual, expected_distinct, expected_dupes,
    ):
        diff = self._make_diff("insert_count_mismatch", len(baseline), len(actual))
        adjust_delta_diff(
            diff, table_fqn, self.SET_TABLES,
            baseline_rows=baseline,
            actual_rows=actual,
            compare_fn=lambda *_a, **_kw: [],
            max_cell_diffs=10,
        )
        assert diff["set_table_risk"] == RISK_CONFIRMED
        assert diff["distinct_actual"] == expected_distinct
        assert diff["duplicate_rows"] == expected_dupes

    def test_possible_when_dedup_count_still_differs(self):
        baseline = [{"id": 1}]
        actual = [{"id": 1}, {"id": 2}, {"id": 2}]

        diff = self._make_diff("insert_count_mismatch", 1, 3)
        adjust_delta_diff(
            diff, "DB.SCHEMA.MY_TABLE", self.SET_TABLES,
            baseline_rows=baseline,
            actual_rows=actual,
            compare_fn=lambda *_a, **_kw: [],
            max_cell_diffs=10,
        )
        assert diff["set_table_risk"] == RISK_POSSIBLE
        assert diff["distinct_actual"] == 2

    def test_possible_when_count_matches_but_cells_differ(self):
        baseline = [{"id": 1, "v": "a"}, {"id": 2, "v": "b"}]
        actual = [
            {"id": 1, "v": "a"}, {"id": 1, "v": "a"},
            {"id": 2, "v": "DIFFERENT"},
        ]

        cell_diffs = [{"row": 1, "column": "v", "baseline": "b", "actual": "DIFFERENT"}]

        diff = self._make_diff("insert_count_mismatch", 2, 3)
        adjust_delta_diff(
            diff, "DB.SCHEMA.MY_TABLE", self.SET_TABLES,
            baseline_rows=baseline,
            actual_rows=actual,
            compare_fn=lambda *_a, **_kw: cell_diffs,
            max_cell_diffs=10,
        )
        assert diff["set_table_risk"] == RISK_POSSIBLE

