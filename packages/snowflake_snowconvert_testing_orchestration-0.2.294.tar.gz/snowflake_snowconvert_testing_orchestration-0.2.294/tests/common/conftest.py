"""Shared test helpers for common/ tests."""

from __future__ import annotations

from types import SimpleNamespace


def _col_with_cs(
    name: str,
    col_type: str,
    *,
    is_case_specific: bool | None = None,
) -> SimpleNamespace:
    """Build a CUR-like column SimpleNamespace with optional isCaseSpecific."""
    ns = SimpleNamespace(name=name, type=col_type, isPrimaryKey=False)
    if is_case_specific is not None:
        ns.isCaseSpecific = is_case_specific
    return ns
