"""Tests for the Redshift step-based SQL builder."""

from __future__ import annotations

import pytest

from test_runner.common.builders.redshift import build_redshift_sql
from test_runner.common.models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    TableStep,
    ValidateTable,
)


class TestSimpleProcedure:
    """Example 1b: simple Redshift CALL."""

    def test_single_call(self):
        steps = [
            QueryStep(
                source_query="CALL reports.get_sales_by_category({0}, {1})",
                target_query="CALL Reports.GetSalesByCategory({0}, {1})",
            ),
        ]
        result = build_redshift_sql(steps, ["2025-02-05", "2026-02-05"])

        assert result.main_sql == {
            0: "CALL reports.get_sales_by_category('2025-02-05', '2026-02-05')",
        }
        assert result.validated_step_indices == [0]


class TestOutputParameters:
    """Example 2b: Redshift INOUT params."""

    def test_target_only_step_skipped(self):
        steps = [
            QueryStep(
                target_query="LET PRODUCTNAME VARCHAR := {1}; LET UNITPRICE DECIMAL := {2}",
                validate=False,
            ),
            QueryStep(
                source_query="CALL get_product_details({0}, {1}, {2})",
                target_query="CALL GET_PRODUCT_DETAILS({0}, :PRODUCTNAME, :UNITPRICE)",
                validate=False,
            ),
            ParamStep(
                source_params=["productname", "unitprice"],
                target_params=["PRODUCTNAME", "UNITPRICE"],
            ),
        ]
        result = build_redshift_sql(steps, [3, "", 0])

        assert 0 not in result.main_sql  # target-only step skipped
        assert result.main_sql[1] == "CALL get_product_details(3, '', 0)"
        assert 2 not in result.main_sql  # ParamStep has no SQL
        assert result.validated_step_indices == [2]  # ParamStep still validated


class TestTableStep:
    """Example 3b: table output."""

    def test_table_select(self):
        steps = [
            QueryStep(target_query="LET NAME VARCHAR := {1}", validate=False),
            QueryStep(
                source_query="CALL get_product({0}, {1})",
                target_query="CALL GET_PRODUCT({0}, :NAME)",
                validate=False,
            ),
            ParamStep(
                source_params=["name"],
                target_params=["NAME"],
            ),
            TableStep(source_table="#temp_results", target_table="#temp_results"),
        ]
        result = build_redshift_sql(steps, [3, ""])

        assert result.main_sql[3] == "SELECT * FROM #temp_results"
        assert result.validated_step_indices == [2, 3]


class TestCursorStep:
    """Example 4: cursor FETCH ALL."""

    def test_cursor_fetch(self):
        steps = [
            QueryStep(target_query="LET TOTAL_SALES INT := {1}", validate=False),
            QueryStep(
                source_query="CALL get_sales_summary({0}, {1}, '{2}')",
                target_query="CALL GET_SALES_SUMMARY({0}, :TOTAL_SALES, '{2}')",
                validate=False,
            ),
            ParamStep(
                source_params=["total_sales"],
                target_params=["TOTAL_SALES"],
            ),
            CursorStep(source_cursor="{2}", target_cursor="{2}"),
        ]
        result = build_redshift_sql(steps, ["North", 0, "sales_cursor"])

        assert result.main_sql[3] == "FETCH ALL FROM sales_cursor"
        assert result.validated_step_indices == [2, 3]


class TestDmlProcedure:
    """Example 6b: DML with validate: false."""

    def test_validate_false_excluded(self):
        steps = [
            QueryStep(
                source_query="CALL insert_color({0})",
                target_query="CALL INSERT_COLOR({0})",
                validate=False,
            ),
            QueryStep(
                source_query="SELECT * FROM colors WHERE color_name = {0}",
                target_query="SELECT * FROM colors WHERE color_name = {0}",
            ),
        ]
        result = build_redshift_sql(steps, ["Crimson"])

        assert result.main_sql[0] == "CALL insert_color('Crimson')"
        assert result.main_sql[1] == "SELECT * FROM colors WHERE color_name = 'Crimson'"
        assert result.validated_step_indices == [1]


class TestOneSidedSteps:
    def test_target_only_step_skipped(self):
        steps = [
            QueryStep(target_query="LET X VARCHAR := {0}", validate=False),
            QueryStep(
                source_query="CALL proc({0})",
                target_query="CALL PROC({0})",
            ),
        ]
        result = build_redshift_sql(steps, [1])

        assert 0 not in result.main_sql
        assert result.main_sql[1] == "CALL proc(1)"
        assert result.validated_step_indices == [1]


class TestValidateListRaises:
    def test_validate_list_raises(self):
        steps = [
            QueryStep(
                source_query="CALL proc({0})",
                validate=[ValidateTable(table="#T")],
            ),
        ]
        with pytest.raises(ValueError, match="validate.*list.*not supported for Redshift"):
            build_redshift_sql(steps, [1])


class TestValidateFalseOnShorthands:
    @pytest.mark.parametrize(
        "step",
        [
            ParamStep(source_params=["x"], validate=False),
            TableStep(source_table="#Temp", validate=False),
            CursorStep(source_cursor="mycursor", validate=False),
        ],
        ids=["ParamStep", "TableStep", "CursorStep"],
    )
    def test_validate_false_raises(self, step):
        with pytest.raises(ValueError, match="does not support validate: false"):
            build_redshift_sql([step], [])
