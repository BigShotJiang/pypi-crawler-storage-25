"""Tests for the Teradata step-based SQL builder."""

from __future__ import annotations

import pytest

from test_runner.common.builders.teradata import build_teradata_sql
from test_runner.common.models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    TableStep,
    ValidateCursor,
    ValidateQuery,
    ValidateResult,
    ValidateSkip,
    ValidateTable,
)


class TestSimpleProcedure:
    """Proc with no output params → CALL is validated, no other steps."""

    def test_single_call(self):
        steps = [
            QueryStep(
                source_query="CALL reports.get_sales_by_category({0}, {1})",
                target_query="CALL Reports.GetSalesByCategory({0}, {1})",
            ),
        ]
        result = build_teradata_sql(steps, ["2025-02-05", "2026-02-05"])

        assert result.main_sql == {
            0: "CALL reports.get_sales_by_category('2025-02-05', '2026-02-05')",
        }
        assert result.validated_step_indices == [0]


class TestOutputParameters:
    """Proc with INOUT scalars: CALL(false) + ParamStep(true)."""

    def test_param_step_emits_no_sql(self):
        steps = [
            QueryStep(
                source_query="CALL get_product_details({0}, {1}, {2})",
                target_query="CALL GET_PRODUCT_DETAILS({0}, :PRODUCTNAME, :UNITPRICE)",
                validate=False,
            ),
            ParamStep(
                source_params=["productname", "unitprice"],
                target_params=["PRODUCTNAME", "UNITPRICE"],
            ),
        ]
        result = build_teradata_sql(steps, [3, "", 0])

        assert result.main_sql[0] == "CALL get_product_details(3, '', 0)"
        assert 1 not in result.main_sql  # ParamStep emits no SQL
        assert result.validated_step_indices == [1]


class TestTableStep:
    """Proc with temp-table output: CALL(false) + TableStep(true)."""

    def test_table_select(self):
        steps = [
            QueryStep(
                source_query="CALL load_results({0}, {1})",
                target_query="CALL LOAD_RESULTS({0}, {1})",
                validate=False,
            ),
            TableStep(source_table="{1}", target_table="{1}"),
        ]
        result = build_teradata_sql(steps, [3, "vt_results"])

        assert result.main_sql[0] == "CALL load_results(3, 'vt_results')"
        assert result.main_sql[1] == "SELECT * FROM vt_results"
        assert result.validated_step_indices == [1]


class TestCursorStep:
    """Proc with REFCURSOR output: CALL(false) + CursorStep(true).

    Teradata cursors come back as ``cursor.nextset()`` payloads on the
    CALL cursor — there is no FETCH ALL syntax — so the builder emits no
    SQL for the CursorStep.  The executor pops from the queue of
    collected dynamic result sets.
    """

    def test_cursor_step_emits_no_sql(self):
        steps = [
            QueryStep(
                source_query="CALL get_sales_summary({0}, {1}, {2})",
                target_query="CALL GET_SALES_SUMMARY({0}, :TOTAL_SALES, {2})",
                validate=False,
            ),
            ParamStep(
                source_params=["total_sales"],
                target_params=["TOTAL_SALES"],
            ),
            CursorStep(source_cursor="{2}", target_cursor="{2}"),
        ]
        result = build_teradata_sql(steps, ["North", 0, "sales_cursor"])

        assert result.main_sql[0] == "CALL get_sales_summary('North', 0, 'sales_cursor')"
        assert 1 not in result.main_sql  # ParamStep
        assert 2 not in result.main_sql  # CursorStep on Teradata
        assert result.validated_step_indices == [1, 2]


class TestDmlProcedure:
    """DML CALL with validate: false followed by a SELECT verification."""

    def test_validate_false_excluded(self):
        steps = [
            QueryStep(
                source_query="CALL insert_color({0})",
                target_query="CALL INSERT_COLOR({0})",
                validate=False,
            ),
            QueryStep(
                source_query="SELECT * FROM colors WHERE color_name = {0}",
                target_query="SELECT * FROM COLORS WHERE COLOR_NAME = {0}",
            ),
        ]
        result = build_teradata_sql(steps, ["Crimson"])

        assert result.main_sql[0] == "CALL insert_color('Crimson')"
        assert result.main_sql[1] == "SELECT * FROM colors WHERE color_name = 'Crimson'"
        assert result.validated_step_indices == [1]


class TestOneSidedSteps:
    def test_target_only_step_skipped(self):
        steps = [
            QueryStep(target_query="LET X VARCHAR := {0}", validate=False),
            QueryStep(
                source_query="CALL proc({0})",
                target_query="CALL PROC({0})",
            ),
        ]
        result = build_teradata_sql(steps, [1])

        assert 0 not in result.main_sql
        assert result.main_sql[1] == "CALL proc(1)"
        assert result.validated_step_indices == [1]


class TestBooleanLiterals:
    """Teradata booleans render as 1/0, not TRUE/FALSE."""

    def test_bool_true(self):
        steps = [QueryStep(source_query="CALL set_flag({0})")]
        result = build_teradata_sql(steps, [True])
        assert result.main_sql[0] == "CALL set_flag(1)"

    def test_bool_false(self):
        steps = [QueryStep(source_query="CALL set_flag({0})")]
        result = build_teradata_sql(steps, [False])
        assert result.main_sql[0] == "CALL set_flag(0)"


class TestValidateListAccepted:
    """``validate: [list]`` on a CALL ``QueryStep`` is the multi-RS path."""

    def test_call_with_validate_list_renders_sql_and_validates_index(self):
        steps = [
            QueryStep(
                source_query="CALL get_dashboard({0})",
                target_query="CALL GET_DASHBOARD({0})",
                validate=[ValidateResult(), ValidateResult()],
            ),
        ]
        result = build_teradata_sql(steps, ["R"])

        assert result.main_sql[0] == "CALL get_dashboard('R')"
        assert result.validated_step_indices == [0]

    def test_call_with_validate_list_allows_skip_and_query_entries(self):
        steps = [
            QueryStep(
                source_query="CALL multi_rs({0})",
                target_query="CALL MULTI_RS({0})",
                validate=[
                    ValidateSkip(),
                    ValidateQuery(target_query="SELECT 1 AS x"),
                ],
            ),
        ]
        result = build_teradata_sql(steps, [1])

        assert result.main_sql[0] == "CALL multi_rs(1)"
        assert result.validated_step_indices == [0]


class TestValidateListRejections:
    """The builder rejects validate: [list] in unsupported positions."""

    def test_non_call_query_raises(self):
        steps = [
            QueryStep(
                source_query="SELECT * FROM t WHERE id = {0}",
                validate=[ValidateResult()],
            ),
        ]
        with pytest.raises(ValueError, match="requires a CALL statement"):
            build_teradata_sql(steps, [1])

    def test_param_step_raises(self):
        steps = [
            ParamStep(
                source_params=["x"],
                validate=[ValidateResult()],
            ),
        ]
        with pytest.raises(ValueError, match="only supported on a CALL"):
            build_teradata_sql(steps, [])

    def test_table_step_raises(self):
        steps = [
            TableStep(
                source_table="t1",
                validate=[ValidateTable(table="t2")],
            ),
        ]
        with pytest.raises(ValueError, match="only supported on a CALL"):
            build_teradata_sql(steps, [])

    def test_cursor_step_raises(self):
        steps = [
            CursorStep(
                source_cursor="c",
                validate=[ValidateCursor(cursor="c2")],
            ),
        ]
        with pytest.raises(ValueError, match="only supported on a CALL"):
            build_teradata_sql(steps, [])

    def test_call_with_downstream_cursor_step_raises(self):
        steps = [
            QueryStep(
                source_query="CALL multi({0})",
                validate=[ValidateResult()],
            ),
            CursorStep(source_cursor="c"),
        ]
        with pytest.raises(ValueError, match="mutually exclusive with a downstream CursorStep"):
            build_teradata_sql(steps, [1])

    def test_call_with_downstream_cursor_after_next_call_is_allowed(self):
        steps = [
            QueryStep(
                source_query="CALL multi({0})",
                validate=[ValidateResult()],
            ),
            QueryStep(
                source_query="CALL other({0})",
                validate=False,
            ),
            CursorStep(source_cursor="c"),
        ]
        result = build_teradata_sql(steps, [1])

        assert result.main_sql[0] == "CALL multi(1)"
        assert result.main_sql[1] == "CALL other(1)"
        assert 2 not in result.main_sql
        assert result.validated_step_indices == [0, 2]


class TestValidateFalseOnShorthands:
    @pytest.mark.parametrize(
        "step",
        [
            ParamStep(source_params=["x"], validate=False),
            TableStep(source_table="t1", validate=False),
            CursorStep(source_cursor="mycursor", validate=False),
        ],
        ids=["ParamStep", "TableStep", "CursorStep"],
    )
    def test_validate_false_raises(self, step):
        with pytest.raises(ValueError, match="does not support validate: false"):
            build_teradata_sql([step], [])
