"""Tests for the Snowflake step-based SQL builder."""

from __future__ import annotations

import pytest

from test_runner.common.builders.snowflake import build_snowflake_sql
from test_runner.common.models.step_types import (
    VALIDATE_SKIP,
    CursorStep,
    ParamStep,
    QueryStep,
    TableStep,
    ValidateCursor,
    ValidateQuery,
    ValidateResult,
    ValidateTable,
)


class TestSimpleProcedure:
    """Example 1a target: simple CALL."""

    def test_call_with_resultset_capture(self):
        steps = [
            QueryStep(
                source_query="EXECUTE [Reports].[GetSalesByCategory] @StartDate = {0}, @EndDate = {1}",
                target_query="CALL Reports.GetSalesByCategory({0}, {1})",
            ),
        ]
        result = build_snowflake_sql(steps, ["2025-02-05", "2026-02-05"])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL Reports.GetSalesByCategory('2025-02-05', '2026-02-05');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "END;\n"
        )
        assert result.result_stmts == ["SELECT * FROM _step_0"]
        assert result.validated_step_indices == [0]


class TestOutputParameters:
    """Example 2a target: LET declarations + CALL + param SELECT."""

    def test_let_call_params(self):
        steps = [
            QueryStep(
                source_query="DECLARE @productName VARCHAR(100) = {1}; DECLARE @unitPrice DECIMAL(38,18) = {2}",
                target_query="LET PRODUCTNAME VARCHAR := {1}; LET UNITPRICE DECIMAL := {2}",
                validate=False,
            ),
            QueryStep(
                source_query="EXECUTE dbo.GetProductDetails @productId = {0}",
                target_query="CALL DBO.GETPRODUCTDETAILS({0}, :PRODUCTNAME, :UNITPRICE)",
            ),
            ParamStep(
                source_params=["@productName", "@unitPrice"],
                target_params=["PRODUCTNAME", "UNITPRICE"],
            ),
        ]
        result = build_snowflake_sql(steps, [3, "", 0])

        assert result.main_sql == (
            "BEGIN\n"
            "  LET PRODUCTNAME VARCHAR := ''; LET UNITPRICE DECIMAL := 0;\n"
            "  CALL DBO.GETPRODUCTDETAILS(3, :PRODUCTNAME, :UNITPRICE);\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_1 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_2 AS\n"
            '    SELECT :PRODUCTNAME AS "PRODUCTNAME", :UNITPRICE AS "UNITPRICE";\n'
            "END;\n"
        )
        assert result.result_stmts == ["SELECT * FROM _step_1", "SELECT * FROM _step_2"]
        assert result.validated_step_indices == [1, 2]


class TestTableStep:
    """Example 3a target: table shorthand."""

    def test_table_uses_identifier(self):
        steps = [
            QueryStep(
                source_query="DECLARE @name VARCHAR(100) = {1}",
                target_query="LET NAME VARCHAR := {1}",
                validate=False,
            ),
            QueryStep(
                source_query="EXECUTE dbo.GetProduct @id = {0}",
                target_query="CALL DBO.GETPRODUCT({0}, :NAME)",
            ),
            ParamStep(
                source_params=["@name"],
                target_params=["NAME"],
            ),
            TableStep(source_table="#TempResults", target_table="#TempResults"),
        ]
        result = build_snowflake_sql(steps, [3, ""])

        assert result.main_sql == (
            "BEGIN\n"
            "  LET NAME VARCHAR := '';\n"
            "  CALL DBO.GETPRODUCT(3, :NAME);\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_1 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_2 AS\n"
            '    SELECT :NAME AS "NAME";\n'
            "  CREATE OR REPLACE TEMPORARY TABLE _step_3 AS\n"
            "    SELECT * FROM IDENTIFIER('#TempResults');\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_1",
            "SELECT * FROM _step_2",
            "SELECT * FROM _step_3",
        ]
        assert result.validated_step_indices == [1, 2, 3]


class TestCursorStep:
    """Example 4 target: cursor shorthand."""

    def test_cursor_uses_identifier(self):
        steps = [
            QueryStep(
                target_query="LET TOTAL_SALES INT := {1}",
                validate=False,
            ),
            QueryStep(
                source_query="CALL get_sales_summary({0}, {1}, {2})",
                target_query="CALL GET_SALES_SUMMARY({0}, :TOTAL_SALES, {2})",
                validate=False,
            ),
            ParamStep(
                source_params=["total_sales"],
                target_params=["TOTAL_SALES"],
            ),
            CursorStep(source_cursor="{2}", target_cursor="{2}"),
        ]
        result = build_snowflake_sql(steps, ["North", 0, "sales_cursor"])

        assert result.main_sql == (
            "BEGIN\n"
            "  LET TOTAL_SALES INT := 0;\n"
            "  CALL GET_SALES_SUMMARY('North', :TOTAL_SALES, 'sales_cursor');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_2 AS\n"
            '    SELECT :TOTAL_SALES AS "TOTAL_SALES";\n'
            "  CREATE OR REPLACE TEMPORARY TABLE _step_3 AS\n"
            "    SELECT * FROM IDENTIFIER('sales_cursor');\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_2",
            "SELECT * FROM _step_3",
        ]
        assert result.validated_step_indices == [2, 3]


class TestCustomValidationQueries:
    """Example 5a target: SELECT wrapped in CREATE TABLE AS."""

    def test_select_creates_temp_table(self):
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.ProcessOrders @region = {0}",
                target_query="CALL DBO.PROCESSORDERS({0})",
            ),
            TableStep(source_table="#OrderSummary", target_table="#OrderSummary"),
            QueryStep(
                source_query="SELECT COUNT(*) AS total FROM orders WHERE region = {0}",
                target_query="SELECT COUNT(*) AS total FROM orders WHERE region = {0}",
            ),
        ]
        result = build_snowflake_sql(steps, ["West"])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL DBO.PROCESSORDERS('West');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_1 AS\n"
            "    SELECT * FROM IDENTIFIER('#OrderSummary');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_2 AS\n"
            "    SELECT COUNT(*) AS total FROM orders WHERE region = 'West';\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_0",
            "SELECT * FROM _step_1",
            "SELECT * FROM _step_2",
        ]
        assert result.validated_step_indices == [0, 1, 2]


class TestDmlProcedure:
    """Example 6a target: validate: false on CALL."""

    def test_validate_false_no_temp_table(self):
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.InsertColor @ColorName = {0}",
                target_query="CALL INSERTCOLOR({0})",
                validate=False,
            ),
            QueryStep(
                source_query="SELECT * FROM Colors WHERE ColorName = {0}",
                target_query="SELECT * FROM Colors WHERE ColorName = {0}",
            ),
        ]
        result = build_snowflake_sql(steps, ["Crimson"])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL INSERTCOLOR('Crimson');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_1 AS\n"
            "    SELECT * FROM Colors WHERE ColorName = 'Crimson';\n"
            "END;\n"
        )
        assert result.result_stmts == ["SELECT * FROM _step_1"]
        assert result.validated_step_indices == [1]


class TestMultiResultSet:
    """Example 7: validate: [list]."""

    def test_all_tables_no_result_entry(self):
        """7a: bare CALL, all result sets to temp tables."""
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.Dashboard @region = {0}",
                target_query="CALL DASHBOARD({0})",
                validate=[
                    ValidateTable(table="#Orders"),
                    ValidateTable(table="#Products"),
                    ValidateTable(table="#Summary"),
                ],
            ),
        ]
        result = build_snowflake_sql(steps, ["West"])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL DASHBOARD('West');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v0 AS\n"
            "    SELECT * FROM IDENTIFIER('#Orders');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v1 AS\n"
            "    SELECT * FROM IDENTIFIER('#Products');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v2 AS\n"
            "    SELECT * FROM IDENTIFIER('#Summary');\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_0_v0",
            "SELECT * FROM _step_0_v1",
            "SELECT * FROM _step_0_v2",
        ]
        assert result.validated_step_indices == [0]

    def test_result_entry_with_tables(self):
        """7b: RESULTSET capture for first result set, tables for others."""
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.Dashboard @region = {0}",
                target_query="CALL DASHBOARD({0})",
                validate=[
                    ValidateResult(),
                    ValidateTable(table="#Products"),
                    ValidateTable(table="#Summary"),
                ],
            ),
        ]
        result = build_snowflake_sql(steps, ["West"])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL DASHBOARD('West');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _rs_0 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v0 AS\n"
            "    SELECT * FROM _rs_0;\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v1 AS\n"
            "    SELECT * FROM IDENTIFIER('#Products');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v2 AS\n"
            "    SELECT * FROM IDENTIFIER('#Summary');\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_0_v0",
            "SELECT * FROM _step_0_v1",
            "SELECT * FROM _step_0_v2",
        ]
        assert result.validated_step_indices == [0]

    def test_skip_preserves_index_gap(self):
        """7c: false entry skips index."""
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.Dashboard @region = {0}",
                target_query="CALL DASHBOARD({0})",
                validate=[
                    ValidateResult(),
                    VALIDATE_SKIP,
                    ValidateTable(table="#Summary"),
                ],
            ),
        ]
        result = build_snowflake_sql(steps, ["West"])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL DASHBOARD('West');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _rs_0 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v0 AS\n"
            "    SELECT * FROM _rs_0;\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v2 AS\n"
            "    SELECT * FROM IDENTIFIER('#Summary');\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_0_v0",
            "SELECT * FROM _step_0_v2",
        ]
        assert result.validated_step_indices == [0]

    def test_validate_query_entry(self):
        """target_query entry generates CREATE TABLE AS (query)."""
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.Report @id = {0}",
                target_query="CALL REPORT({0})",
                validate=[
                    ValidateResult(),
                    ValidateQuery(target_query="SELECT COUNT(*) AS n FROM audit_log WHERE report_id = {0}"),
                ],
            ),
        ]
        result = build_snowflake_sql(steps, [42])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL REPORT(42);\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _rs_0 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v0 AS\n"
            "    SELECT * FROM _rs_0;\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v1 AS\n"
            "    SELECT COUNT(*) AS n FROM audit_log WHERE report_id = 42;\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_0_v0",
            "SELECT * FROM _step_0_v1",
        ]
        assert result.validated_step_indices == [0]

    def test_validate_cursor_entry(self):
        """cursor entry generates SELECT * FROM IDENTIFIER(cursor_name)."""
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.GetData @region = {0}",
                target_query="CALL GET_DATA({0})",
                validate=[
                    ValidateTable(table="#Results"),
                    ValidateCursor(cursor="data_cursor"),
                ],
            ),
        ]
        result = build_snowflake_sql(steps, ["West"])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL GET_DATA('West');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v0 AS\n"
            "    SELECT * FROM IDENTIFIER('#Results');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v1 AS\n"
            "    SELECT * FROM IDENTIFIER('data_cursor');\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_0_v0",
            "SELECT * FROM _step_0_v1",
        ]
        assert result.validated_step_indices == [0]

    def test_mixed_validate_list_all_entry_types(self):
        """All entry types in one validate list."""
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.Dashboard @region = {0}",
                target_query="CALL DASHBOARD({0})",
                validate=[
                    ValidateResult(),
                    VALIDATE_SKIP,
                    ValidateTable(table="#Summary"),
                    ValidateCursor(cursor="detail_cursor"),
                    ValidateQuery(target_query="SELECT 1 AS ok"),
                ],
            ),
        ]
        result = build_snowflake_sql(steps, ["East"])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL DASHBOARD('East');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _rs_0 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v0 AS\n"
            "    SELECT * FROM _rs_0;\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v2 AS\n"
            "    SELECT * FROM IDENTIFIER('#Summary');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v3 AS\n"
            "    SELECT * FROM IDENTIFIER('detail_cursor');\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_0_v4 AS\n"
            "    SELECT 1 AS ok;\n"
            "END;\n"
        )
        assert result.result_stmts == [
            "SELECT * FROM _step_0_v0",
            "SELECT * FROM _step_0_v2",
            "SELECT * FROM _step_0_v3",
            "SELECT * FROM _step_0_v4",
        ]
        assert result.validated_step_indices == [0]


class TestOneSidedSteps:
    def test_source_only_step_skipped(self):
        steps = [
            QueryStep(source_query="DECLARE @out VARCHAR = {0}", validate=False),
            QueryStep(
                source_query="EXEC P @id = {0}",
                target_query="CALL P({0})",
            ),
        ]
        result = build_snowflake_sql(steps, [1])

        assert result.main_sql == (
            "BEGIN\n"
            "  CALL P(1);\n"
            "  CREATE OR REPLACE TEMPORARY TABLE _step_1 AS\n"
            "    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            "END;\n"
        )
        assert result.result_stmts == ["SELECT * FROM _step_1"]
        assert result.validated_step_indices == [1]


class TestValidateFalseOnShorthands:
    @pytest.mark.parametrize(
        "step",
        [
            ParamStep(target_params=["X"], validate=False),
            TableStep(target_table="#Temp", validate=False),
            CursorStep(target_cursor="mycursor", validate=False),
        ],
        ids=["ParamStep", "TableStep", "CursorStep"],
    )
    def test_validate_false_raises(self, step):
        with pytest.raises(ValueError, match="does not support validate: false"):
            build_snowflake_sql([step], [])
