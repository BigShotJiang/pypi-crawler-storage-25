"""Tests for shared builder helpers."""

from __future__ import annotations

import pytest

from test_runner.common.builders.common import (
    ensure_semicolon,
    format_sqlserver_literal,
    is_call,
    substitute_placeholders,
    substitute_raw_placeholders,
)


class TestSubstitutePlaceholders:
    def test_basic_substitution(self):
        result = substitute_placeholders(
            "EXEC P @a = {0}, @b = {1}", [42, "hello"], format_sqlserver_literal
        )
        assert result == "EXEC P @a = 42, @b = 'hello'"

    def test_null_value(self):
        result = substitute_placeholders("SELECT {0}", [None], format_sqlserver_literal)
        assert result == "SELECT NULL"

    def test_bool_value(self):
        result = substitute_placeholders("SELECT {0}", [True], format_sqlserver_literal)
        assert result == "SELECT 1"

    def test_string_escaping(self):
        result = substitute_placeholders("SELECT {0}", ["it's"], format_sqlserver_literal)
        assert result == "SELECT 'it''s'"

    def test_out_of_range_index_preserved(self):
        result = substitute_placeholders("SELECT {0}, {5}", [1], format_sqlserver_literal)
        assert result == "SELECT 1, {5}"

    def test_no_placeholders(self):
        result = substitute_placeholders("SELECT 1", [42], format_sqlserver_literal)
        assert result == "SELECT 1"

    def test_repeated_placeholder(self):
        result = substitute_placeholders(
            "SELECT {0}, {0}", ["x"], format_sqlserver_literal
        )
        assert result == "SELECT 'x', 'x'"


class TestSubstituteRawPlaceholders:
    def test_basic_substitution(self):
        result = substitute_raw_placeholders("#Table_{0}", ["temp"])
        assert result == "#Table_temp"

    def test_cursor_name(self):
        result = substitute_raw_placeholders("{1}", ["North", "mycursor"])
        assert result == "mycursor"

    def test_out_of_range_preserved(self):
        result = substitute_raw_placeholders("{3}", ["a"])
        assert result == "{3}"

    def test_no_placeholders(self):
        result = substitute_raw_placeholders("#TempResults", ["x"])
        assert result == "#TempResults"


class TestEnsureSemicolon:
    def test_adds_semicolon(self):
        assert ensure_semicolon("SELECT 1") == "SELECT 1;"

    def test_idempotent_with_semicolon(self):
        assert ensure_semicolon("SELECT 1;") == "SELECT 1;"

    def test_strips_trailing_whitespace(self):
        assert ensure_semicolon("SELECT 1  ") == "SELECT 1;"

    def test_strips_whitespace_and_semicolon(self):
        assert ensure_semicolon("SELECT 1 ;  ") == "SELECT 1;"

    def test_multiple_semicolons(self):
        assert ensure_semicolon("SELECT 1;;") == "SELECT 1;"


class TestIsCall:
    @pytest.mark.parametrize(
        "sql",
        [
            "CALL proc()",
            "call proc()",
            "  CALL proc()",
            "\nCALL proc('x')",
            "CALL\tproc()",
            "CALL schema.proc()",
        ],
    )
    def test_recognized(self, sql):
        assert is_call(sql) is True

    @pytest.mark.parametrize(
        "sql",
        [
            "SELECT 1",
            "EXEC proc",
            "CALLBACK foo",
            "CALL",
            "",
            "  ",
            "-- CALL proc()",
        ],
    )
    def test_rejected(self, sql):
        assert is_call(sql) is False
