"""Tests for test_runner.common.collation — annotate_count_mismatch."""

from __future__ import annotations

from test_runner.common.collation import CollationClassifier


# ---------------------------------------------------------------------------
# CollationClassifier.annotate_count_mismatch
# ---------------------------------------------------------------------------


class TestAnnotateCountMismatchInactive:
    """An inactive classifier must be a no-op."""

    def test_no_annotation_when_inactive(self):
        classifier = CollationClassifier()
        diff = {"type": "insert_count_mismatch", "baseline": 10, "actual": 7}
        classifier.annotate_count_mismatch(diff)
        assert "collation_risk" not in diff
        assert "fdm_code" not in diff

    def test_no_annotation_when_inactive_with_table_fqn(self):
        classifier = CollationClassifier()
        diff = {"type": "insert_count_mismatch", "baseline": 3, "actual": 1}
        classifier.annotate_count_mismatch(diff, table_fqn="S.T")
        assert "collation_risk" not in diff


class TestAnnotateCountMismatchFdmOnly:
    """Active via FDM but no CI columns."""

    def test_stamps_possible_and_fdm_code(self):
        classifier = CollationClassifier(
            has_collation_fdm=True,
            fdm_code="SSC-FDM-TD0032",
        )
        diff = {"type": "insert_count_mismatch", "baseline": 5, "actual": 3}
        classifier.annotate_count_mismatch(diff)
        assert diff["collation_risk"] == "possible"
        assert diff["fdm_code"] == "SSC-FDM-TD0032"

    def test_stamps_possible_without_fdm_code_string(self):
        classifier = CollationClassifier(has_collation_fdm=True)
        diff = {"type": "delete_count_mismatch", "baseline": 2, "actual": 0}
        classifier.annotate_count_mismatch(diff)
        assert diff["collation_risk"] == "possible"
        assert "fdm_code" not in diff


class TestAnnotateCountMismatchCIColumnsOnly:
    """Active via CI columns but no FDM."""

    def test_stamps_possible_no_fdm_code(self):
        classifier = CollationClassifier(
            case_insensitive_columns_by_table={"S.T": ["NAME"]},
        )
        diff = {"type": "insert_count_mismatch", "baseline": 10, "actual": 7}
        classifier.annotate_count_mismatch(diff)
        assert diff["collation_risk"] == "possible"
        assert "fdm_code" not in diff


class TestAnnotateCountMismatchTableScoped:
    """Table-scoped annotation: only annotates when that table is relevant."""

    def test_annotates_when_table_has_ci_columns(self):
        classifier = CollationClassifier(
            case_insensitive_columns_by_table={"S.T": ["NAME"]},
        )
        diff = {"type": "insert_count_mismatch", "baseline": 5, "actual": 3}
        classifier.annotate_count_mismatch(diff, table_fqn="S.T")
        assert diff["collation_risk"] == "possible"

    def test_no_annotation_when_table_has_no_ci_columns(self):
        classifier = CollationClassifier(
            case_insensitive_columns_by_table={"S.OTHER": ["NAME"]},
        )
        diff = {"type": "insert_count_mismatch", "baseline": 5, "actual": 3}
        classifier.annotate_count_mismatch(diff, table_fqn="S.T")
        assert "collation_risk" not in diff

    def test_annotates_when_table_has_no_ci_columns_but_fdm_present(self):
        classifier = CollationClassifier(
            has_collation_fdm=True,
            fdm_code="SSC-FDM-TD0039",
            case_insensitive_columns_by_table={"S.OTHER": ["NAME"]},
        )
        diff = {"type": "delete_count_mismatch", "baseline": 4, "actual": 2}
        classifier.annotate_count_mismatch(diff, table_fqn="S.T")
        assert diff["collation_risk"] == "possible"
        assert diff["fdm_code"] == "SSC-FDM-TD0039"


class TestAnnotateCountMismatchBothSignals:
    """Both FDM and CI columns present."""

    def test_stamps_possible_with_fdm_code(self):
        classifier = CollationClassifier(
            has_collation_fdm=True,
            fdm_code="SSC-FDM-TD0032",
            case_insensitive_columns_by_table={"S.T": ["NAME"]},
        )
        diff = {"type": "update_count_mismatch", "baseline": 3, "actual": 1}
        classifier.annotate_count_mismatch(diff, table_fqn="S.T")
        assert diff["collation_risk"] == "possible"
        assert diff["fdm_code"] == "SSC-FDM-TD0032"
