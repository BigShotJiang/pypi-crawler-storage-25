"""Tests for test_runner.common.teradata_collation."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from test_runner.common.collation import CollationBuilder, CollationClassifier
from test_runner.common.dependency_classifier import _format_name
from test_runner.common.teradata_collation import (
    TeradataCollationBuilder,
    _extract_case_insensitive_columns,
    _find_collation_fdm,
    _has_collation_fdm,
    _is_char_type,
    build_collation_classifier,
)

from .conftest import _col_with_cs


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _unit(
    uid: str,
    *,
    schema: str = "dbo",
    database: str = "DB",
    columns: list | None = None,
) -> SimpleNamespace:
    sig = SimpleNamespace(columns=columns) if columns else None
    return SimpleNamespace(
        id=uid,
        source=SimpleNamespace(name=uid, schema_=schema, database=database),
        dependencies=SimpleNamespace(dependsOn=[]),
        target=None,
        codeStatus=None,
        issues=[],
        signature=sig,
    )


# ---------------------------------------------------------------------------
# _find_collation_fdm / _has_collation_fdm
# ---------------------------------------------------------------------------

class TestFindCollationFdm:
    def test_returns_td0032_when_present(self):
        unit = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0032")])
        assert _find_collation_fdm(unit) == "SSC-FDM-TD0032"

    def test_returns_td0039_when_present(self):
        unit = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0039")])
        assert _find_collation_fdm(unit) == "SSC-FDM-TD0039"

    def test_returns_first_match_when_both_present(self):
        unit = SimpleNamespace(issues=[
            SimpleNamespace(code="SSC-FDM-TD0032"),
            SimpleNamespace(code="SSC-FDM-TD0039"),
        ])
        assert _find_collation_fdm(unit) == "SSC-FDM-TD0032"

    def test_returns_none_for_unrelated_fdm(self):
        unit = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0001")])
        assert _find_collation_fdm(unit) is None

    def test_returns_none_when_issues_empty(self):
        unit = SimpleNamespace(issues=[])
        assert _find_collation_fdm(unit) is None

    def test_returns_none_when_issues_none(self):
        unit = SimpleNamespace(issues=None)
        assert _find_collation_fdm(unit) is None

    def test_returns_none_when_no_issues_attr(self):
        unit = SimpleNamespace()
        assert _find_collation_fdm(unit) is None


class TestHasCollationFdm:
    def test_returns_true_for_td0032(self):
        unit = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0032")])
        assert _has_collation_fdm(unit) is True

    def test_returns_true_for_td0039(self):
        unit = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0039")])
        assert _has_collation_fdm(unit) is True

    def test_returns_false_when_no_fdm(self):
        unit = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0001")])
        assert _has_collation_fdm(unit) is False

    def test_returns_false_when_issues_empty(self):
        unit = SimpleNamespace(issues=[])
        assert _has_collation_fdm(unit) is False

    def test_returns_false_when_issues_none(self):
        unit = SimpleNamespace(issues=None)
        assert _has_collation_fdm(unit) is False

    def test_returns_false_when_no_issues_attr(self):
        unit = SimpleNamespace()
        assert _has_collation_fdm(unit) is False


# ---------------------------------------------------------------------------
# _is_char_type
# ---------------------------------------------------------------------------

class TestIsCharType:
    @pytest.mark.parametrize("type_str", [
        "CHAR", "VARCHAR", "NCHAR", "NVARCHAR", "CHARACTER", "TEXT", "STRING",
        "char(10)", "VARCHAR(255)", "NVARCHAR(MAX)", "Character Varying",
    ])
    def test_char_types_detected(self, type_str):
        assert _is_char_type(type_str) is True

    @pytest.mark.parametrize("type_str", [
        "INTEGER", "NUMBER", "DECIMAL", "DATE", "TIMESTAMP", "BOOLEAN", "BINARY",
    ])
    def test_non_char_types_rejected(self, type_str):
        assert _is_char_type(type_str) is False

    def test_none_and_empty(self):
        assert _is_char_type(None) is False
        assert _is_char_type("") is False


# ---------------------------------------------------------------------------
# _extract_case_insensitive_columns
# ---------------------------------------------------------------------------

class TestExtractCaseInsensitiveColumns:
    def test_varchar_without_ics_treated_as_not_casespecific(self):
        table = _unit("t1", columns=[_col_with_cs("Name", "VARCHAR")])
        result = _extract_case_insensitive_columns(
            frozenset({"t1"}), {"t1": table}, _format_name,
        )
        assert result == {"DB.dbo.t1": ["Name"]}

    def test_varchar_with_ics_true_excluded(self):
        table = _unit("t1", columns=[_col_with_cs("Name", "VARCHAR", is_case_specific=True)])
        result = _extract_case_insensitive_columns(
            frozenset({"t1"}), {"t1": table}, _format_name,
        )
        assert result == {}

    def test_varchar_with_ics_false_included(self):
        table = _unit("t1", columns=[_col_with_cs("Name", "VARCHAR", is_case_specific=False)])
        result = _extract_case_insensitive_columns(
            frozenset({"t1"}), {"t1": table}, _format_name,
        )
        assert result == {"DB.dbo.t1": ["Name"]}

    def test_integer_column_excluded(self):
        table = _unit("t1", columns=[_col_with_cs("Id", "INTEGER")])
        result = _extract_case_insensitive_columns(
            frozenset({"t1"}), {"t1": table}, _format_name,
        )
        assert result == {}

    def test_mixed_columns(self):
        table = _unit("t1", columns=[
            _col_with_cs("Id", "INTEGER"),
            _col_with_cs("Name", "VARCHAR"),
            _col_with_cs("Code", "CHAR(5)", is_case_specific=True),
            _col_with_cs("Description", "NVARCHAR(100)"),
        ])
        result = _extract_case_insensitive_columns(
            frozenset({"t1"}), {"t1": table}, _format_name,
        )
        assert result == {"DB.dbo.t1": ["Name", "Description"]}

    def test_missing_unit_in_index_skipped(self):
        result = _extract_case_insensitive_columns(
            frozenset({"missing"}), {}, _format_name,
        )
        assert result == {}


# ---------------------------------------------------------------------------
# build_collation_classifier
# ---------------------------------------------------------------------------

class TestBuildCollationClassifier:
    def test_returns_classifier_with_td0032(self):
        proc = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0032")])
        table = _unit("t1", columns=[_col_with_cs("Name", "VARCHAR")])

        classifier = build_collation_classifier(
            proc, frozenset({"t1"}), {"t1": table}, _format_name,
        )

        assert isinstance(classifier, CollationClassifier)
        assert classifier.has_collation_fdm is True
        assert classifier.fdm_code == "SSC-FDM-TD0032"
        assert classifier.case_insensitive_columns_by_table == {"DB.dbo.t1": ["Name"]}

    def test_returns_classifier_with_td0039(self):
        proc = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0039")])
        table = _unit("t1", columns=[_col_with_cs("Name", "VARCHAR")])

        classifier = build_collation_classifier(
            proc, frozenset({"t1"}), {"t1": table}, _format_name,
        )

        assert classifier.has_collation_fdm is True
        assert classifier.fdm_code == "SSC-FDM-TD0039"

    def test_returns_classifier_without_fdm(self):
        proc = SimpleNamespace(issues=[])
        table = _unit("t1", columns=[_col_with_cs("Name", "VARCHAR")])

        classifier = build_collation_classifier(
            proc, frozenset({"t1"}), {"t1": table}, _format_name,
        )

        assert classifier.has_collation_fdm is False
        assert classifier.fdm_code == ""
        assert classifier.case_insensitive_columns_by_table == {"DB.dbo.t1": ["Name"]}

    def test_empty_when_no_tables(self):
        proc = SimpleNamespace(issues=[])

        classifier = build_collation_classifier(
            proc, frozenset(), {}, _format_name,
        )

        assert classifier.is_active is False


# ---------------------------------------------------------------------------
# TeradataCollationBuilder
# ---------------------------------------------------------------------------

class TestTeradataCollationBuilder:
    def test_is_collation_builder_subclass(self):
        assert issubclass(TeradataCollationBuilder, CollationBuilder)

    def test_build_delegates_to_build_collation_classifier(self):
        builder = TeradataCollationBuilder()
        proc = SimpleNamespace(issues=[SimpleNamespace(code="SSC-FDM-TD0032")])
        table = _unit("t1", columns=[_col_with_cs("Name", "VARCHAR")])

        classifier = builder.build(
            proc, frozenset({"t1"}), {"t1": table}, _format_name,
        )

        assert isinstance(classifier, CollationClassifier)
        assert classifier.has_collation_fdm is True
        assert classifier.fdm_code == "SSC-FDM-TD0032"
        assert classifier.case_insensitive_columns_by_table == {"DB.dbo.t1": ["Name"]}
