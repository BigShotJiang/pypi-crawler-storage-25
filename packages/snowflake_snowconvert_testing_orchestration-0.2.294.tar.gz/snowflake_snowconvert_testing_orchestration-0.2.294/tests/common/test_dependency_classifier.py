"""Tests for test_runner.common.dependency_classifier."""

from __future__ import annotations

from types import SimpleNamespace

import pytest
from snowflake_code_unit_registry.types import ObjectType

from test_runner.common.collation import CollationClassifier
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.dependency_classifier import (
    _compute_checksums,
    _extract_pk_columns,
    _format_name,
    _is_tabular,
    classify,
    enrich_test_files,
    extract_code_unit_id,
)

FAKE_REGISTRY = object()
from .conftest import _col_with_cs


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dep(target_id: str, *relation_types: str) -> SimpleNamespace:
    return SimpleNamespace(id=target_id, relationTypes=list(relation_types))


def _col(name: str, *, is_pk: bool = False) -> SimpleNamespace:
    return SimpleNamespace(name=name, isPrimaryKey=is_pk)


def _unit(
    uid: str,
    schema: str = "dbo",
    database: str = "DB",
    *,
    deps: list[SimpleNamespace] | None = None,
    columns: list[SimpleNamespace] | None = None,
    object_type: ObjectType | None = None,
) -> SimpleNamespace:
    source = SimpleNamespace(name=uid, schema_=schema, database=database)
    if object_type is not None:
        source.objectType = object_type
    ns = SimpleNamespace(
        id=uid,
        source=source,
        dependencies=SimpleNamespace(dependsOn=deps or []),
    )
    if columns is not None:
        ns.signature = SimpleNamespace(columns=columns)
    return ns


def _test_file(**overrides) -> SimpleNamespace:
    defaults = dict(
        file_path="artifacts/db/dbo/procedure/p/test/cu-1.yml",
        code_unit_id="cu-1",
        modifies_data=None,
        affected_tables=[],
        read_tables=[],
        pk_columns_by_table={},
        source_checksum=None,
        converted_checksum=None,
        contains_commit=False,
        target_database=None,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _build_index(*units: SimpleNamespace) -> dict[str, SimpleNamespace]:
    return {u.id: u for u in units}


def _ids(units: tuple) -> set[str]:
    """Extract IDs from a tuple of units for test assertions."""
    return {u.id for u in units}


# ---------------------------------------------------------------------------
# Direct relations
# ---------------------------------------------------------------------------

class TestDirectRelations:
    def test_direct_insert(self):
        index = _build_index(
            _unit("proc1", deps=[_dep("table1", "INSERT")]),
            _unit("table1"),
        )
        result = classify("proc1", index)
        assert result.modifies_data is True
        assert _ids(result.affected) == {"table1"}

    def test_pure_select(self):
        index = _build_index(
            _unit("proc1", deps=[_dep("table1", "SELECT - JOIN")]),
            _unit("table1"),
        )
        result = classify("proc1", index)
        assert result.modifies_data is False
        assert result.affected == ()

    def test_mixed_execute_and_insert(self):
        index = _build_index(
            _unit("proc1", deps=[_dep("proc2", "EXECUTE", "INSERT")]),
            _unit("proc2"),
        )
        result = classify("proc1", index)
        assert result.modifies_data is True
        assert "proc2" in _ids(result.affected)


# ---------------------------------------------------------------------------
# Transitive via closure
# ---------------------------------------------------------------------------

class TestTransitive:
    def test_execute_then_insert(self):
        index = _build_index(
            _unit("proc1", deps=[_dep("proc2", "EXECUTE")]),
            _unit("proc2", deps=[_dep("table1", "INSERT")]),
            _unit("table1"),
        )
        result = classify("proc1", index)
        assert result.modifies_data is True
        assert "table1" in _ids(result.affected)

    def test_multi_level_chain(self):
        index = _build_index(
            _unit("A", deps=[_dep("B", "EXECUTE")]),
            _unit("B", deps=[_dep("C", "EXECUTE")]),
            _unit("C", deps=[_dep("table1", "UPDATE")]),
            _unit("table1"),
        )
        result = classify("A", index)
        assert result.modifies_data is True
        assert "table1" in _ids(result.affected)

    def test_transitive_pure_read(self):
        index = _build_index(
            _unit("proc1", deps=[_dep("proc2", "EXECUTE")]),
            _unit("proc2", deps=[_dep("table1", "SELECT - FROM")]),
            _unit("table1"),
        )
        result = classify("proc1", index)
        assert result.modifies_data is False
        assert result.affected == ()


# ---------------------------------------------------------------------------
# Cycles (flat scan — no infinite-loop risk)
# ---------------------------------------------------------------------------

class TestCycles:
    def test_mutual_recursion_read_only(self):
        index = _build_index(
            _unit("A", deps=[_dep("B", "EXECUTE")]),
            _unit("B", deps=[_dep("A", "EXECUTE")]),
        )
        assert classify("A", index).modifies_data is False

    def test_mutual_recursion_with_write(self):
        index = _build_index(
            _unit("A", deps=[_dep("B", "EXECUTE")]),
            _unit("B", deps=[_dep("A", "EXECUTE"), _dep("table1", "INSERT")]),
            _unit("table1"),
        )
        assert classify("A", index).modifies_data is True
        assert classify("B", index).modifies_data is True

    def test_self_recursion(self):
        index = _build_index(
            _unit("A", deps=[_dep("A", "EXECUTE"), _dep("table1", "SELECT - FROM")]),
            _unit("table1"),
        )
        assert classify("A", index).modifies_data is False

    def test_triangle_with_write(self):
        index = _build_index(
            _unit("A", deps=[_dep("B", "EXECUTE")]),
            _unit("B", deps=[_dep("C", "EXECUTE")]),
            _unit("C", deps=[_dep("A", "EXECUTE"), _dep("table1", "DELETE")]),
            _unit("table1"),
        )
        assert classify("A", index).modifies_data is True
        assert classify("B", index).modifies_data is True
        assert classify("C", index).modifies_data is True


# ---------------------------------------------------------------------------
# Diamond (shared subgraph)
# ---------------------------------------------------------------------------

class TestDiamond:
    def test_deduplicates_affected(self):
        index = _build_index(
            _unit("A", deps=[_dep("B", "EXECUTE"), _dep("C", "EXECUTE")]),
            _unit("B", deps=[_dep("D", "EXECUTE")]),
            _unit("C", deps=[_dep("D", "EXECUTE")]),
            _unit("D", deps=[_dep("table1", "UPDATE")]),
            _unit("table1"),
        )
        result = classify("A", index)
        assert result.modifies_data is True
        assert _ids(result.affected) == {"table1"}


# ---------------------------------------------------------------------------
# _format_name (always source)
# ---------------------------------------------------------------------------

class TestFormatName:
    def test_returns_fqn(self):
        unit = _unit("t1", schema="dbo", database="SrcDB")
        assert _format_name(unit) == "SrcDB.dbo.t1"

    def test_partial_name_no_database(self):
        unit = SimpleNamespace(
            source=SimpleNamespace(name="Orders", schema_="dbo", database=None),
        )
        assert _format_name(unit) == "dbo.Orders"

    def test_missing_source_returns_none(self):
        unit = SimpleNamespace(source=None)
        assert _format_name(unit) is None


# ---------------------------------------------------------------------------
# _is_tabular
# ---------------------------------------------------------------------------

class TestIsTabular:
    @pytest.mark.parametrize("object_type", [
        ObjectType.table, ObjectType.view, ObjectType.materializedView,
    ], ids=["table", "view", "materializedView"])
    def test_tabular_types_included(self, object_type):
        unit = _unit("t1", object_type=object_type)
        assert _is_tabular(unit) is True

    @pytest.mark.parametrize("object_type", [
        ObjectType.function, ObjectType.procedure,
        ObjectType.sequence, ObjectType.trigger,
    ], ids=["function", "procedure", "sequence", "trigger"])
    def test_non_tabular_types_excluded(self, object_type):
        unit = _unit("fn1", object_type=object_type)
        assert _is_tabular(unit) is False

    def test_macro_object_type_excluded(self):
        """Teradata macros (objectType="macro") are non-tabular."""
        unit = _unit("m1")
        unit.source.objectType = "macro"
        assert _is_tabular(unit) is False

    def test_missing_object_type_defaults_to_true(self):
        unit = _unit("t1")  # no object_type → no objectType attr on source
        assert _is_tabular(unit) is True

    def test_missing_source_defaults_to_true(self):
        unit = SimpleNamespace(source=None)
        assert _is_tabular(unit) is True


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_empty_dependencies(self):
        result = classify("proc1", _build_index(_unit("proc1")))
        assert result.modifies_data is False
        assert result.affected == ()

    def test_null_dependencies(self):
        unit = SimpleNamespace(
            id="proc1",
            source=SimpleNamespace(name="proc1", schema_="dbo", database="DB"),
            dependencies=None,
        )
        result = classify("proc1", {"proc1": unit})
        assert result.modifies_data is False
        assert result.affected == ()

    def test_missing_target_graceful(self):
        index = _build_index(_unit("proc1", deps=[_dep("nonexistent", "EXECUTE")]))
        result = classify("proc1", index)
        assert result.modifies_data is False
        assert result.affected == ()

    def test_unknown_start_id(self):
        result = classify("nonexistent", {})
        assert result.modifies_data is False
        assert result.affected == ()

    def test_all_write_relation_types(self):
        for wt in ("INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE", "ALTER", "DROP"):
            index = _build_index(
                _unit("proc1", deps=[_dep("table1", wt)]),
                _unit("table1"),
            )
            assert classify("proc1", index).modifies_data is True, f"{wt} should be a write"

    def test_case_insensitive_relation_types(self):
        index = _build_index(
            _unit("proc1", deps=[_dep("table1", "insert")]),
            _unit("table1"),
        )
        assert classify("proc1", index).modifies_data is True


# ---------------------------------------------------------------------------
# extract_code_unit_id
# ---------------------------------------------------------------------------

class TestExtractCodeUnitId:
    def test_typical_path(self):
        path = "/project/artifacts/testdb/dbo/procedure/myproc/test/cu-abc-123.yml"
        assert extract_code_unit_id(path) == "cu-abc-123"

    def test_relative_path(self):
        path = "artifacts/db/dbo/procedure/p/test/unit-id.yml"
        assert extract_code_unit_id(path) == "unit-id"


# ---------------------------------------------------------------------------
# CUR integration
# ---------------------------------------------------------------------------

class TestCurIntegration:
    def test_build_closure_index_options(self):
        captured = {}
        from test_runner.common import dependency_classifier as mod

        class FakeRegistry:
            def find_all(self, options):
                captured["filter"] = options.filter
                captured["fields"] = list(options.fields or [])
                captured["include_deps"] = options.include_dependencies
                return [SimpleNamespace(id="a"), SimpleNamespace(id="b")]

        index = mod._build_closure_index(FakeRegistry(), "some-uuid")
        assert sorted(index.keys()) == ["a", "b"]
        assert captured["include_deps"] is True
        assert captured["fields"] == ["id", "source", "target", "dependencies", "files", "signature", "codeStatus", "issues"]
        assert captured["filter"] == "id = 'some-uuid'"

    def test_enrich_respects_yaml_override(self, monkeypatch):
        """Classification is skipped for YAML-overridden files, but checksums are still computed."""
        root = _unit("cu-1", deps=[_dep("table1", "INSERT")])
        tf = _test_file(
            modifies_data=False,  # YAML override — would be True from CUR deps
            affected_tables=["manual.override"],
        )

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(mod, "_build_closure_index", lambda _r, _id: {"cu-1": root})
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: ("s", "c"))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.modifies_data is False          # not overwritten by CUR
        assert tf.affected_tables == ["manual.override"]  # not overwritten
        assert tf.source_checksum == "s"          # checksum is still populated
        assert tf.converted_checksum == "c"

    def test_enrich_populates_source_names(self, monkeypatch):
        root = _unit("cu-1", deps=[_dep("table1", "INSERT")])
        table = _unit("table1", schema="dbo", database="DB")

        tf = _test_file()

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(
            mod, "_build_closure_index",
            lambda _r, _id: {u.id: u for u in (root, table)},
        )
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: ("srcsha", "convsha"))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.modifies_data is True
        assert tf.affected_tables == ["DB.dbo.table1"]
        assert tf.pk_columns_by_table == {}
        assert tf.source_checksum == "srcsha"
        assert tf.converted_checksum == "convsha"

    def test_enrich_populates_pk_columns(self, monkeypatch):
        root = _unit("cu-1", deps=[_dep("table1", "INSERT")])
        table = _unit(
            "table1", schema="dbo", database="DB",
            columns=[_col("Id", is_pk=True), _col("Name")],
        )

        tf = _test_file()

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(
            mod, "_build_closure_index",
            lambda _r, _id: {u.id: u for u in (root, table)},
        )
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.modifies_data is True
        assert tf.pk_columns_by_table == {"DB.dbo.table1": ["Id"]}

    def test_enrich_sets_contains_commit_true_when_cur_flag_set(self, monkeypatch):
        root = SimpleNamespace(
            id="cu-1",
            source=SimpleNamespace(name="cu-1", schema_="dbo", database="DB"),
            dependencies=SimpleNamespace(dependsOn=[]),
            target=None,
            codeStatus=SimpleNamespace(
                assessment=SimpleNamespace(containsCommit=True),
            ),
        )

        tf = _test_file()

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(mod, "_build_closure_index", lambda _r, _id: {"cu-1": root})
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.contains_commit is True

    def test_enrich_sets_contains_commit_false_when_cur_flag_absent(self, monkeypatch):
        root = SimpleNamespace(
            id="cu-1",
            source=SimpleNamespace(name="cu-1", schema_="dbo", database="DB"),
            dependencies=SimpleNamespace(dependsOn=[]),
            target=None,
            codeStatus=None,
        )

        tf = _test_file()

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(mod, "_build_closure_index", lambda _r, _id: {"cu-1": root})
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.contains_commit is False

    def test_enrich_uses_code_unit_id_from_model(self, monkeypatch):
        """code_unit_id set on the model is used as the CUR lookup key."""
        captured_ids: list[str] = []

        root = _unit("uuid-from-cur")

        tf = _test_file(
            code_unit_id="uuid-from-cur",
            file_path="artifacts/db/dbo/procedure/p/test/wrong-id.yml",
        )

        from test_runner.common import dependency_classifier as mod

        def _fake_closure_index(_registry, cu_id):
            captured_ids.append(cu_id)
            return {"uuid-from-cur": root}

        monkeypatch.setattr(mod, "_build_closure_index", _fake_closure_index)
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)

        assert captured_ids == ["uuid-from-cur"]

    def test_enrich_asserts_when_code_unit_id_is_none(self):
        """When code_unit_id is None, an AssertionError is raised."""
        tf = _test_file(code_unit_id=None)

        with pytest.raises(AssertionError, match="code_unit_id must not be None"):
            enrich_test_files([tf], "/project", FAKE_REGISTRY)

    def test_enrich_excludes_scalar_udf_from_affected_tables(self, monkeypatch):
        """Scalar UDFs with a write relation in CUR must not appear in affected_tables.

        Reproduces SNOW-3375945: dbo.getTimeZoneAdjustedUTCDate is a scalar
        function that CUR incorrectly marks with an UPDATE relation, causing
        the capture handler to run SELECT COUNT(*) against it as if it were
        a table.
        """
        units = [
            _unit("cu-1", deps=[_dep("table1", "INSERT"), _dep("fn1", "UPDATE")]),
            _unit("table1", schema="dbo", database="DB", object_type=ObjectType.table),
            _unit("fn1", schema="dbo", database="DB", object_type=ObjectType.function),
        ]
        tf = _test_file()

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(
            mod, "_build_closure_index",
            lambda _r, _id: {u.id: u for u in units},
        )
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.modifies_data is True
        assert tf.affected_tables == ["DB.dbo.table1"]
        assert "DB.dbo.fn1" not in tf.affected_tables

    def test_enrich_excludes_procedure_from_read_tables(self, monkeypatch):
        """Procedures referenced as read dependencies should not appear in read_tables."""
        units = [
            _unit("cu-1", deps=[_dep("table1", "SELECT - FROM"), _dep("proc2", "EXECUTE")]),
            _unit("table1", schema="dbo", database="DB", object_type=ObjectType.table),
            _unit("proc2", schema="dbo", database="DB", object_type=ObjectType.procedure),
        ]
        tf = _test_file()

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(
            mod, "_build_closure_index",
            lambda _r, _id: {u.id: u for u in units},
        )
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.read_tables == ["DB.dbo.table1"]
        assert "DB.dbo.proc2" not in tf.read_tables

    def test_enrich_excludes_macro_from_affected_tables(self, monkeypatch):
        """Macros (objectType="macro") must not appear in affected_tables.

        Macros are non-tabular like procedures — only tables, views, and
        materialized views should be listed as affected tables.
        """
        root = _unit("cu-1", deps=[_dep("table1", "INSERT"), _dep("macro1", "EXECUTE")])
        table = _unit("table1", schema="dbo", database="DB", object_type=ObjectType.table)
        macro = _unit("macro1", schema="dbo", database="DB")
        macro.source.objectType = "macro"

        tf = _test_file()

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(
            mod, "_build_closure_index",
            lambda _r, _id: {u.id: u for u in (root, table, macro)},
        )
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.modifies_data is True
        assert tf.affected_tables == ["DB.dbo.table1"]
        assert "DB.dbo.macro1" not in tf.affected_tables

    def test_enrich_includes_deps_without_object_type_for_backward_compat(self, monkeypatch):
        """When CUR data lacks objectType, all write deps appear in affected_tables."""
        root = _unit("cu-1", deps=[_dep("table1", "INSERT")])
        table = _unit("table1", schema="dbo", database="DB")  # no object_type

        tf = _test_file()

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(
            mod, "_build_closure_index",
            lambda _r, _id: {u.id: u for u in (root, table)},
        )
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY)
        assert tf.affected_tables == ["DB.dbo.table1"]


# ---------------------------------------------------------------------------
# _extract_pk_columns
# ---------------------------------------------------------------------------

class TestExtractPkColumns:
    def test_extracts_pk_from_signature_columns(self):
        table = _unit(
            "t1", schema="dbo", database="DB",
            columns=[_col("Id", is_pk=True), _col("Name")],
        )
        result = _extract_pk_columns((table,))

        assert result == {"DB.dbo.t1": ["Id"]}

    def test_composite_pk(self):
        table = _unit(
            "t1", schema="dbo", database="DB",
            columns=[
                _col("OrderId", is_pk=True),
                _col("LineId", is_pk=True),
                _col("Qty"),
            ],
        )
        result = _extract_pk_columns((table,))

        assert result == {"DB.dbo.t1": ["OrderId", "LineId"]}

    def test_no_pk_columns_omits_table(self):
        table = _unit(
            "t1", schema="dbo", database="DB",
            columns=[_col("Name"), _col("Age")],
        )
        result = _extract_pk_columns((table,))

        assert result == {}

    def test_no_signature_omits_table(self):
        table = _unit("t1")  # no columns= → no signature attr
        result = _extract_pk_columns((table,))

        assert result == {}

    def test_empty_units(self):
        result = _extract_pk_columns(())

        assert result == {}

    def test_empty_columns_list_omits_table(self):
        table = _unit("t1", columns=[])
        result = _extract_pk_columns((table,))

        assert result == {}

    def test_old_cur_columns_without_isPrimaryKey_attr(self):
        """Older CUR versions have columns without isPrimaryKey — should gracefully return nothing."""
        old_col = SimpleNamespace(name="Id")  # no isPrimaryKey attribute
        table = _unit("t1", schema="dbo", database="DB")
        table.signature = SimpleNamespace(columns=[old_col])

        result = _extract_pk_columns((table,))

        assert result == {}

    def test_multiple_tables_mixed_pk(self):
        with_pk = _unit(
            "t1", schema="dbo", database="DB",
            columns=[_col("Id", is_pk=True), _col("Val")],
        )
        without_pk = _unit(
            "t2", schema="dbo", database="DB",
            columns=[_col("Name")],
        )
        result = _extract_pk_columns((with_pk, without_pk))

        assert result == {"DB.dbo.t1": ["Id"]}


# ---------------------------------------------------------------------------
# _compute_checksums
# ---------------------------------------------------------------------------

class TestComputeChecksums:
    def _unit_with_files(self, src_path: str | None, conv_path: str | None) -> SimpleNamespace:
        src = SimpleNamespace(path=src_path) if src_path is not None else None
        conv = SimpleNamespace(path=conv_path) if conv_path is not None else None
        return SimpleNamespace(files=SimpleNamespace(source=src, converted=conv))

    def test_returns_checksums_for_existing_files(self, tmp_path, monkeypatch):
        src_file = tmp_path / "src.sql"
        conv_file = tmp_path / "conv.sql"
        src_file.write_text("SELECT 1")
        conv_file.write_text("SELECT 2")

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(mod, "compute_file_checksum", lambda p: f"hash:{p}")

        unit = self._unit_with_files("src.sql", "conv.sql")
        src_cs, conv_cs = _compute_checksums(unit, tmp_path)
        assert src_cs == f"hash:{tmp_path / 'src.sql'}"
        assert conv_cs == f"hash:{tmp_path / 'conv.sql'}"

    @pytest.mark.parametrize("unit,case", [
        (SimpleNamespace(files=None), "files_is_none"),
        (SimpleNamespace(files=SimpleNamespace(source=None, converted=None)), "paths_are_none"),
    ])
    def test_returns_none_when_no_useful_files(self, unit, case, tmp_path):
        src_cs, conv_cs = _compute_checksums(unit, tmp_path)
        assert (src_cs, conv_cs) == (None, None)

    def test_returns_none_on_compute_error(self, tmp_path, monkeypatch):
        def _bad_compute(p):
            raise OSError("file not found")

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(mod, "compute_file_checksum", _bad_compute)

        unit = self._unit_with_files("missing.sql", None)
        src_cs, conv_cs = _compute_checksums(unit, tmp_path)
        assert src_cs is None
        assert conv_cs is None


class TestEnrichCollationMetadata:
    def test_enrich_populates_collation_fdm(self, monkeypatch):
        root = SimpleNamespace(
            id="cu-1",
            source=SimpleNamespace(name="cu-1", schema_="dbo", database="DB"),
            dependencies=SimpleNamespace(dependsOn=[]),
            target=None,
            codeStatus=None,
            issues=[SimpleNamespace(code="SSC-FDM-TD0032")],
        )

        tf = SimpleNamespace(
            file_path="artifacts/db/dbo/procedure/p/test/cu-1.yml",
            code_unit_id="cu-1",
            modifies_data=None,
            affected_tables=[],
            read_tables=[],
            pk_columns_by_table={},
            source_checksum=None,
            converted_checksum=None,
            contains_commit=False,
            target_database=None,
            has_collation_fdm=False,
            case_insensitive_columns_by_table={},
            collation=None,
        )

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(mod, "_build_closure_index", lambda _r, _id: {"cu-1": root})
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY, source_dialect=DatabaseDialect.TERADATA)
        assert tf.has_collation_fdm is True
        assert isinstance(tf.collation, CollationClassifier)
        assert tf.collation.has_collation_fdm is True
        assert tf.collation.fdm_code == "SSC-FDM-TD0032"

    def test_enrich_populates_case_insensitive_columns_for_teradata(self, monkeypatch):
        root = SimpleNamespace(
            id="cu-1",
            source=SimpleNamespace(name="cu-1", schema_="dbo", database="DB"),
            dependencies=SimpleNamespace(dependsOn=[_dep("t1", "INSERT")]),
            target=None,
            codeStatus=None,
            issues=[],
        )
        table = SimpleNamespace(
            id="t1",
            source=SimpleNamespace(name="t1", schema_="dbo", database="DB"),
            dependencies=SimpleNamespace(dependsOn=[]),
            target=None,
            codeStatus=None,
            issues=[],
            signature=SimpleNamespace(columns=[
                _col_with_cs("Name", "VARCHAR"),
                _col_with_cs("Id", "INTEGER"),
            ]),
        )

        tf = SimpleNamespace(
            file_path="artifacts/db/dbo/procedure/p/test/cu-1.yml",
            code_unit_id="cu-1",
            modifies_data=None,
            affected_tables=[],
            read_tables=[],
            pk_columns_by_table={},
            source_checksum=None,
            converted_checksum=None,
            contains_commit=False,
            target_database=None,
            has_collation_fdm=False,
            case_insensitive_columns_by_table={},
            collation=None,
        )

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(
            mod, "_build_closure_index",
            lambda _r, _id: {"cu-1": root, "t1": table},
        )
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY, source_dialect=DatabaseDialect.TERADATA)
        assert tf.case_insensitive_columns_by_table == {"DB.dbo.t1": ["Name"]}
        assert tf.collation.case_insensitive_columns_by_table == {"DB.dbo.t1": ["Name"]}

    def test_enrich_empty_for_non_teradata(self, monkeypatch):
        root = SimpleNamespace(
            id="cu-1",
            source=SimpleNamespace(name="cu-1", schema_="dbo", database="DB"),
            dependencies=SimpleNamespace(dependsOn=[_dep("t1", "INSERT")]),
            target=None,
            codeStatus=None,
            issues=[],
        )
        table = SimpleNamespace(
            id="t1",
            source=SimpleNamespace(name="t1", schema_="dbo", database="DB"),
            dependencies=SimpleNamespace(dependsOn=[]),
            target=None,
            codeStatus=None,
            issues=[],
            signature=SimpleNamespace(columns=[
                _col_with_cs("Name", "VARCHAR"),
            ]),
        )

        tf = SimpleNamespace(
            file_path="artifacts/db/dbo/procedure/p/test/cu-1.yml",
            code_unit_id="cu-1",
            modifies_data=None,
            affected_tables=[],
            read_tables=[],
            pk_columns_by_table={},
            source_checksum=None,
            converted_checksum=None,
            contains_commit=False,
            target_database=None,
            has_collation_fdm=False,
            case_insensitive_columns_by_table={},
            collation=None,
        )

        from test_runner.common import dependency_classifier as mod
        monkeypatch.setattr(
            mod, "_build_closure_index",
            lambda _r, _id: {"cu-1": root, "t1": table},
        )
        monkeypatch.setattr(mod, "_compute_checksums", lambda _unit, _root: (None, None))

        enrich_test_files([tf], "/project", FAKE_REGISTRY, source_dialect=DatabaseDialect.SQL_SERVER)
        assert tf.case_insensitive_columns_by_table == {}
        assert tf.collation.case_insensitive_columns_by_table == {}
