"""Shared fixtures for test-runner tests."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from snowflake_code_unit_registry import CodeUnit, CodeUnitRegistry
from snowflake_code_unit_registry.types import ArtifactsEntry, Files, ObjectType, SourceMetadata, TargetMetadata

FIXTURES_DIR = Path(__file__).parent / "fixtures"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_settings(project_root: Path, source_platform: str) -> None:
    settings_dir = project_root / "settings"
    settings_dir.mkdir()
    (settings_dir / "test_config.yaml").write_text(
        f"source_platform: {source_platform}\ntarget_platform: snowflake\n"
    )


def _add_code_unit(
    project_root: Path,
    registry: CodeUnitRegistry,
    fixture_yml: str,
    cur_id: str,
    database: str,
    schema: str,
    object_type: str,
    name: str,
) -> None:
    artifacts_path = f"artifacts/{database}/{schema}/{object_type}/{name}"
    test_dir = project_root / artifacts_path / "test"
    test_dir.mkdir(parents=True)
    shutil.copy(FIXTURES_DIR / fixture_yml, test_dir / f"{cur_id}.yml")
    registry.create(CodeUnit(
        id=cur_id,
        files=Files(artifacts=ArtifactsEntry(path=artifacts_path)),
        target=TargetMetadata.model_validate(
            {"database": database, "schema": schema, "name": name},
        ),
    ))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def tmp_project(tmp_path: Path) -> Path:
    """Create a minimal SCAI project with CUR registry in *tmp_path*.

    Layout::

        tmp_path/
            settings/test_config.yaml
            registry/...
            artifacts/master/dbo/procedure/GetProducts/test/getproducts.a1b2c3d4.yml
            artifacts/master/dbo/procedure/GetCustomerOrders/test/getcustomerorders.b2c3d4e5.yml
    """
    _write_settings(tmp_path, "sqlserver")
    registry = CodeUnitRegistry.init(str(tmp_path))
    _add_code_unit(tmp_path, registry, "simple_procedure.yml",
                   "getproducts.a1b2c3d4", "master", "dbo", "procedure", "GetProducts")
    _add_code_unit(tmp_path, registry, "parameterized_procedure.yml",
                   "getcustomerorders.b2c3d4e5", "master", "dbo", "procedure", "GetCustomerOrders")
    return tmp_path


@pytest.fixture()
def tmp_project_with_dml(tmp_project: Path) -> Path:
    """Extend *tmp_project* with a DML procedure that has modifies_data/affected_tables."""
    registry = CodeUnitRegistry.open(str(tmp_project))
    _add_code_unit(tmp_project, registry, "dml_procedure.yml",
                   "insertcolor.e5f6g7h8", "master", "dbo", "procedure", "InsertColor")
    return tmp_project


@pytest.fixture()
def tmp_project_with_rpt(tmp_project: Path) -> Path:
    """Extend *tmp_project* with an RPT-schema test YAML file."""
    registry = CodeUnitRegistry.open(str(tmp_project))
    _add_code_unit(tmp_project, registry, "rpt_procedure.yml",
                   "getproducts.c3d4e5f6", "master", "rpt", "procedure", "GetProducts")
    return tmp_project


@pytest.fixture()
def tmp_project_with_output_params(tmp_project: Path) -> Path:
    """Extend *tmp_project* with a procedure that has output parameters."""
    registry = CodeUnitRegistry.open(str(tmp_project))
    _add_code_unit(tmp_project, registry, "output_parameters_procedure.yml",
                   "getproductdetails.d4e5f6g7", "master", "dbo", "procedure", "GetProductDetails")
    return tmp_project


@pytest.fixture()
def tmp_project_with_redshift_cursor_output(tmp_path: Path) -> Path:
    """Create a minimal Redshift project with a REFCURSOR INOUT parameter test file.

    Uses ``redshift_cursor_output.yml`` (get_sales_by_region with ``rs_out``
    INOUT REFCURSOR).  Source platform is set to ``redshift`` so the capture
    runner renders fetch statements via ``fetch_cursor_redshift.sql.j2``.
    """
    _write_settings(tmp_path, "redshift")
    registry = CodeUnitRegistry.init(str(tmp_path))
    _add_code_unit(tmp_path, registry, "redshift_cursor_output.yml",
                   "get_sales_by_region.a1b2c3d4", "dev", "public", "procedure", "get_sales_by_region")
    return tmp_path


@pytest.fixture()
def tmp_project_with_redshift_output_params(tmp_path: Path) -> Path:
    """Create a minimal Redshift project with a scalar OUT parameter test file.

    Uses ``redshift_scalar_output.yml`` (fibonacci with ``result`` OUT param).
    Source platform is set to ``redshift`` so the capture runner uses the
    Redshift dialect template and routes through ``_extract_output_params``.
    """
    _write_settings(tmp_path, "redshift")
    registry = CodeUnitRegistry.init(str(tmp_path))
    _add_code_unit(tmp_path, registry, "redshift_scalar_output.yml",
                   "fibonacci.a1b2c3d4", "dev", "public", "procedure", "fibonacci")
    return tmp_path


@pytest.fixture()
def tmp_project_with_step_based(tmp_path: Path) -> Path:
    """Create a project with step-based (v2) YAML test files.

    Layout::

        tmp_path/
            settings/test_config.yaml
            registry/...
            artifacts/master/dbo/procedure/GetProducts/test/getproducts.s1s2s3s4.yml
            artifacts/master/dbo/procedure/BuildReport/test/buildreport.s5s6s7s8.yml
            artifacts/master/dbo/procedure/GetProductDetails/test/getproductdetails.s9s0s1s2.yml
            artifacts/master/dbo/procedure/get_sales_by_region/test/getsalesbyregion.s3s4s5s6.yml
            artifacts/master/dbo/procedure/Dashboard/test/dashboard.s7s8s9s0.yml
    """
    _write_settings(tmp_path, "sqlserver")
    registry = CodeUnitRegistry.init(str(tmp_path))
    _add_code_unit(tmp_path, registry, "step_simple_procedure.yml",
                   "getproducts.s1s2s3s4", "master", "dbo", "procedure", "GetProducts")
    _add_code_unit(tmp_path, registry, "step_table_output.yml",
                   "buildreport.s5s6s7s8", "master", "dbo", "procedure", "BuildReport")
    _add_code_unit(tmp_path, registry, "step_output_params.yml",
                   "getproductdetails.s9s0s1s2", "master", "dbo", "procedure", "GetProductDetails")
    _add_code_unit(tmp_path, registry, "step_cursor_output.yml",
                   "getsalesbyregion.s3s4s5s6", "master", "dbo", "procedure", "get_sales_by_region")
    _add_code_unit(tmp_path, registry, "step_multi_result_set.yml",
                   "dashboard.s7s8s9s0", "master", "dbo", "procedure", "Dashboard")
    return tmp_path


@pytest.fixture()
def tmp_project_with_teradata_macro(tmp_path: Path) -> Path:
    """Create a minimal Teradata project with macro CURs.

    Layout::

        tmp_path/
            settings/test_config.yaml
            registry/...
            artifacts/mydb/dbo/macro/GetSalesSummary/test/getsalessummary.m1m2m3m4.yml
            artifacts/mydb/dbo/macro/GetRegionReport/test/getregionreport.m5m6m7m8.yml
    """
    _write_settings(tmp_path, "teradata")
    registry = CodeUnitRegistry.init(str(tmp_path))
    _add_code_unit(tmp_path, registry, "teradata_macro.yml",
                   "getsalessummary.m1m2m3m4", "mydb", "dbo", "macro", "GetSalesSummary")
    _add_code_unit(tmp_path, registry, "teradata_macro_parameterized.yml",
                   "getregionreport.m5m6m7m8", "mydb", "dbo", "macro", "GetRegionReport")
    return tmp_path


@pytest.fixture()
def tmp_project_with_no_artifacts_path(tmp_path: Path) -> Path:
    """Project where a code unit has no ``files.artifacts.path``.

    Discovery should fall back to deriving the path from ``source`` metadata::

        artifacts/{source.schema_}/{source.objectType}/{source.name}/test/

    Layout::

        tmp_path/
            settings/test_config.yaml
            registry/...
            artifacts/dbo/procedure/FallbackProc/test/fallbackproc.yml
    """
    _write_settings(tmp_path, "sqlserver")
    registry = CodeUnitRegistry.init(str(tmp_path))

    # Place YAML at the path discovery will derive from source metadata
    test_dir = tmp_path / "artifacts" / "dbo" / "procedure" / "FallbackProc" / "test"
    test_dir.mkdir(parents=True)
    shutil.copy(FIXTURES_DIR / "simple_procedure.yml", test_dir / "fallbackproc.yml")

    registry.create(CodeUnit(
        id="fallbackproc.a1b2c3d4",
        files=None,  # no artifacts path — forces discovery fallback
        source=SourceMetadata.model_validate({
            "schema": "dbo",
            "name": "FallbackProc",
            "objectType": "procedure",
        }),
        target=TargetMetadata.model_validate({
            "database": "master",
            "schema": "dbo",
            "name": "FallbackProc",
        }),
    ))
    return tmp_path


@pytest.fixture()
def tmp_project_mixed(tmp_project: Path) -> Path:
    """Extend *tmp_project* (v1) with a step-based (v2) YAML file.

    The resulting project contains both v1 and v2 files, ensuring discovery
    handles mixed formats.
    """
    registry = CodeUnitRegistry.open(str(tmp_project))
    _add_code_unit(tmp_project, registry, "step_dml_procedure.yml",
                   "insertcolor.s1s2s3s4", "master", "dbo", "procedure", "InsertColor")
    return tmp_project
