"""Tests for step-based validation routing in the validate runner."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from test_runner.common.models import (
    BaselineData,
    ComparisonResult,
    QueryStep,
    StepBasedValidation,
    TestFile,
    ValidationCaseResult,
    ValidationDifference,
    ValidationSteps,
)
from test_runner.validate.runner import _validate_case


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_config() -> MagicMock:
    cfg = MagicMock()
    cfg.validation_database = "TESTDB"
    cfg.validation_configuration = None
    cfg.replay_configuration = None
    return cfg


def _make_step_test_file() -> TestFile:
    """Create a step-based TestFile."""
    steps = [
        QueryStep(
            source_query="SELECT 1 AS id",
            target_query="SELECT 1 AS id",
        ),
    ]
    return TestFile(
        file_path="/test/step_based.yml",
        source=ValidationSteps(run="<step-based>"),
        test_cases=[[1]],
        code_unit_name="db.dbo.TestProc",
        parameter_names=["p1"],
        step_validation=StepBasedValidation(
            steps=steps,
            test_cases=[[1]],
        ),
    )


def _make_v1_test_file() -> TestFile:
    """Create a v1 (non-step-based) TestFile."""
    return TestFile(
        file_path="/test/v1.yml",
        source=ValidationSteps(run="EXEC dbo.TestProc @p1"),
        test_cases=[[1]],
        code_unit_name="db.dbo.TestProc",
        parameter_names=["p1"],
        target=ValidationSteps(run="CALL db.dbo.TestProc(:1)"),
    )


def _make_baseline(success: bool = True, num_result_sets: int = 1) -> BaselineData:
    return BaselineData(
        procedure="db.dbo.TestProc",
        parameters={"p1": 1},
        captured_at=datetime.now(timezone.utc).isoformat(),
        result_sets=[[{"ID": 1}] for _ in range(num_result_sets)],
        row_counts=[1] * num_result_sets,
        success=success,
        error="SQL error" if not success else None,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestValidateCaseStepRouting:
    """Verify that _validate_case routes step-based files to the step handler."""

    @patch("test_runner.validate.runner._validate_step_based_case")
    def test_step_based_file_routes_to_step_handler(self, mock_step_handler):
        """Step-based test files should route to _validate_step_based_case."""
        mock_step_handler.return_value = ValidationCaseResult(
            procedure="db.dbo.TestProc",
            params_hash="abcd1234",
            params={"p1": 1},
            status="PASS",
            match_type="data_match",
            executed_at=datetime.now(timezone.utc).isoformat(),
        )
        tf = _make_step_test_file()
        baseline = _make_baseline()
        baseline_index = {("db.dbo.TestProc", baseline.params_hash): baseline}

        result = _validate_case(
            test_file=tf,
            test_case=[1],
            baseline_index=baseline_index,
            connector=MagicMock(),
            executor=MagicMock(),
            format_literal=str,
            config=_make_config(),
        )
        mock_step_handler.assert_called_once()
        assert result.status == "PASS"

    @patch("test_runner.validate.runner.compare_results")
    def test_v1_file_does_not_route_to_step_handler(self, mock_compare):
        """v1 test files should NOT route to the step handler."""
        mock_compare.return_value = ComparisonResult(match=True, match_type="data_match")
        tf = _make_v1_test_file()
        baseline = _make_baseline()
        baseline_index = {("db.dbo.TestProc", baseline.params_hash): baseline}

        result = _validate_case(
            test_file=tf,
            test_case=[1],
            baseline_index=baseline_index,
            connector=MagicMock(),
            executor=MagicMock(),
            format_literal=str,
            config=_make_config(),
        )
        assert result.status == "PASS"


class TestV2FilterIncludesStepBased:
    """Verify the v2 test file filter includes step-based files."""

    def test_step_only_file_not_filtered_out(self):
        """A file with step_validation but no target should not be filtered."""
        tf = _make_step_test_file()
        assert tf.target is None
        assert tf.step_validation is not None
        # Simulating the filter logic from run_validate
        filtered = [f for f in [tf] if f.target is not None or f.step_validation is not None]
        assert len(filtered) == 1
