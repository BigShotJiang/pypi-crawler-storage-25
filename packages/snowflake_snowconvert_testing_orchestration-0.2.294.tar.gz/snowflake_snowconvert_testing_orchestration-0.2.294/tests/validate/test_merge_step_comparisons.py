"""Tests for _merge_step_comparisons in the validate runner."""

from __future__ import annotations

from test_runner.common.models import ComparisonResult, ValidationDifference
from test_runner.validate.runner import _merge_step_comparisons


class TestMergeStepComparisons:
    def test_empty_list_returns_pass(self):
        result = _merge_step_comparisons([])
        assert result.match is True
        assert result.match_type == "no_data"

    def test_all_steps_match(self):
        steps = [
            ComparisonResult(match=True, match_type="data_match", match_level="in_memory"),
            ComparisonResult(match=True, match_type="data_match", match_level="row_validation"),
        ]
        result = _merge_step_comparisons(steps)
        assert result.match is True
        assert result.match_type == "data_match"
        assert result.match_level in ("row_validation", "in_memory")

    def test_single_step_match(self):
        steps = [
            ComparisonResult(match=True, match_type="data_match", match_level="in_memory"),
        ]
        result = _merge_step_comparisons(steps)
        assert result.match is True
        assert result.match_type == "data_match"

    def test_one_step_fails(self):
        steps = [
            ComparisonResult(match=True, match_type="data_match", match_level="in_memory"),
            ComparisonResult(
                match=False,
                match_type="data_mismatch",
                match_level="row_validation",
                differences=[
                    ValidationDifference(type="ROW", detail="col X differs"),
                ],
            ),
        ]
        result = _merge_step_comparisons(steps)
        assert result.match is False
        assert result.match_type == "data_mismatch"
        assert len(result.differences) == 1
        diff = result.differences[0]
        assert isinstance(diff, ValidationDifference)
        assert diff.detail.startswith("step_1:")

    def test_multiple_steps_fail(self):
        steps = [
            ComparisonResult(
                match=False,
                match_type="row_count_mismatch",
                match_level="in_memory",
                differences=["row mismatch"],
            ),
            ComparisonResult(
                match=False,
                match_type="data_mismatch",
                match_level="row_validation",
                differences=[
                    ValidationDifference(type="ROW", detail="col differs"),
                ],
            ),
            ComparisonResult(match=True, match_type="data_match", match_level="in_memory"),
        ]
        result = _merge_step_comparisons(steps)
        assert result.match is False
        assert result.match_type == "row_count_mismatch"
        assert len(result.differences) == 2
        assert isinstance(result.differences[0], str)
        assert result.differences[0].startswith("step_0:")
        assert isinstance(result.differences[1], ValidationDifference)
        assert result.differences[1].detail.startswith("step_1:")

    def test_deepest_match_level_schema(self):
        steps = [
            ComparisonResult(match=True, match_type="data_match", match_level="schema_validation"),
        ]
        result = _merge_step_comparisons(steps)
        assert result.match_level == "schema_validation"

    def test_deepest_match_level_mixed(self):
        steps = [
            ComparisonResult(match=True, match_type="data_match", match_level=""),
            ComparisonResult(match=True, match_type="data_match", match_level="metrics_validation"),
            ComparisonResult(match=True, match_type="data_match", match_level="schema_validation"),
        ]
        result = _merge_step_comparisons(steps)
        assert result.match_level == "metrics_validation"
