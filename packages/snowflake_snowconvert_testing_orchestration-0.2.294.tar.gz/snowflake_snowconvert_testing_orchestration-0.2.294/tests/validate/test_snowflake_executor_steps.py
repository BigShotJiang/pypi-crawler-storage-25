"""Tests for SnowflakeExecutor.execute_steps() with mocked cursors."""

from __future__ import annotations

from unittest.mock import MagicMock

from test_runner.validate.targets.snowflake import SnowflakeExecutor
from test_runner.common.builders.models import SnowflakeBuiltSQL
from test_runner.common.models.capture_result import StepOrigin
from test_runner.common.models.step_types import QueryStep, TableStep


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_executor(
    *,
    execute_statement_error: Exception | None = None,
    fetch_results: list[dict] | None = None,
) -> tuple[SnowflakeExecutor, MagicMock]:
    """Build a SnowflakeExecutor with mocked connector.

    *fetch_results* is a list of dicts, one per result_stmt, each with:
        description: list[tuple] | None
        rows: list[dict]
    """
    connector = MagicMock()

    if execute_statement_error:
        connector.execute_statement.side_effect = execute_statement_error
    else:
        connector.execute_statement.return_value = None

    cursor_idx = {"i": 0}
    fetch_results = fetch_results or []

    def _cursor_factory(cursor_class):
        cursor = MagicMock()
        idx = cursor_idx["i"]
        if idx < len(fetch_results):
            fr = fetch_results[idx]
            cursor.description = fr.get("description")
            cursor.fetchall.return_value = fr.get("rows", [])
        else:
            cursor.description = None
            cursor.fetchall.return_value = []
        cursor_idx["i"] += 1
        return cursor

    connector.connection.cursor.side_effect = _cursor_factory

    executor = SnowflakeExecutor(connector)
    return executor, connector


# ---------------------------------------------------------------------------
# Basic execution
# ---------------------------------------------------------------------------

class TestExecuteStepsBasic:
    def test_single_result_stmt(self):
        """Execute BEGIN/END block then fetch single result_stmt."""
        executor, connector = _make_executor(
            fetch_results=[
                {
                    "description": [("ID", 0), ("NAME", 2)],
                    "rows": [{"ID": 1, "NAME": "Widget"}],
                },
            ],
        )

        steps = [QueryStep(target_query="CALL MY_PROC(1)")]
        built = SnowflakeBuiltSQL(
            main_sql="BEGIN\n  LET _rs_0 RESULTSET := (CALL MY_PROC(1));\n  CREATE OR REPLACE TEMPORARY TABLE _step_0 AS TABLE(_rs_0);\nEND;\n",
            result_stmts=["SELECT * FROM _step_0"],
            validated_step_indices=[0],
            result_step_origins=[StepOrigin(step_index=0)],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        connector.execute_statement.assert_called_once_with(built.main_sql)
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"ID": 1, "NAME": "Widget"}]
        assert result.row_counts == [1]
        assert result.step_origins == [StepOrigin(step_index=0)]

    def test_multiple_result_stmts(self):
        """Multiple result_stmts produce multiple result_sets entries in order."""
        executor, _ = _make_executor(
            fetch_results=[
                {
                    "description": [("A", 0)],
                    "rows": [{"A": 1}],
                },
                {
                    "description": [("B", 2)],
                    "rows": [{"B": "hello"}],
                },
            ],
        )

        steps = [
            QueryStep(target_query="CALL P1()"),
            TableStep(target_table="TEMP1"),
        ]
        built = SnowflakeBuiltSQL(
            main_sql="BEGIN\n...\nEND;\n",
            result_stmts=[
                "SELECT * FROM _step_0",
                "SELECT * FROM _step_1",
            ],
            validated_step_indices=[0, 1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == [{"A": 1}]
        assert result.result_sets[1] == [{"B": "hello"}]


# ---------------------------------------------------------------------------
# Validate list — _step_N_vM tables
# ---------------------------------------------------------------------------

class TestValidateList:
    def test_multiple_temp_tables_fetched(self):
        """validate: [list] with _step_N_vM tables — multiple temp tables fetched."""
        executor, _ = _make_executor(
            fetch_results=[
                {
                    "description": [("X", 0)],
                    "rows": [{"X": 10}],
                },
                {
                    "description": [("Y", 0)],
                    "rows": [{"Y": 20}],
                },
            ],
        )

        steps = [QueryStep(target_query="CALL MULTI()")]
        built = SnowflakeBuiltSQL(
            main_sql="BEGIN\n...\nEND;\n",
            result_stmts=[
                "SELECT * FROM _step_0_v0",
                "SELECT * FROM _step_0_v1",
            ],
            validated_step_indices=[0],
            result_step_origins=[
                StepOrigin(step_index=0, validate_entry=0),
                StepOrigin(step_index=0, validate_entry=1),
            ],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == [{"X": 10}]
        assert result.result_sets[1] == [{"Y": 20}]
        assert result.step_origins == [
            StepOrigin(step_index=0, validate_entry=0),
            StepOrigin(step_index=0, validate_entry=1),
        ]


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_error_in_main_block_no_fetches(self):
        """Error in execute_statement → success=False, no fetches attempted."""
        executor, connector = _make_executor(
            execute_statement_error=RuntimeError("Compilation error"),
        )

        steps = [QueryStep(target_query="CALL BAD()")]
        built = SnowflakeBuiltSQL(
            main_sql="BEGIN\n...\nEND;\n",
            result_stmts=["SELECT * FROM _step_0"],
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "Compilation error" in result.error
        assert result.result_sets == []
        connector.connection.cursor.assert_not_called()

    def test_error_in_fetch_returns_partial(self):
        """Error in one result_stmt returns partial results collected before failure."""
        connector = MagicMock()
        connector.execute_statement.return_value = None

        call_count = {"i": 0}

        def _cursor_factory(cursor_class):
            cursor = MagicMock()
            if call_count["i"] == 0:
                cursor.description = [("A", 0)]
                cursor.fetchall.return_value = [{"A": 1}]
            else:
                cursor.execute.side_effect = RuntimeError("Table not found")
            call_count["i"] += 1
            return cursor

        connector.connection.cursor.side_effect = _cursor_factory
        executor = SnowflakeExecutor(connector)

        steps = [
            QueryStep(target_query="CALL P1()"),
            TableStep(target_table="MISSING"),
        ]
        built = SnowflakeBuiltSQL(
            main_sql="BEGIN\n...\nEND;\n",
            result_stmts=[
                "SELECT * FROM _step_0",
                "SELECT * FROM _step_1",
            ],
            validated_step_indices=[0, 1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "Table not found" in result.error
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"A": 1}]


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_empty_result_stmts(self):
        """No result_stmts (all validate: false) → empty result_sets."""
        executor, connector = _make_executor()

        steps = [QueryStep(target_query="CALL SETUP()", validate=False)]
        built = SnowflakeBuiltSQL(
            main_sql="BEGIN\n  CALL SETUP();\nEND;\n",
            result_stmts=[],
            validated_step_indices=[],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == []
        assert result.row_counts == []

    def test_empty_result_set_fetched(self):
        """Empty result set (0 rows) fetched correctly."""
        executor, _ = _make_executor(
            fetch_results=[
                {
                    "description": [("ID", 0)],
                    "rows": [],
                },
            ],
        )

        steps = [QueryStep(target_query="CALL EMPTY()")]
        built = SnowflakeBuiltSQL(
            main_sql="BEGIN\n...\nEND;\n",
            result_stmts=["SELECT * FROM _step_0"],
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[]]
        assert result.row_counts == [0]
