"""Tests for step_origins in BaselineData and result_set_index in compare_results."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from test_runner.common.models import ComparisonResult
from test_runner.common.models.baseline_data import BaselineData
from test_runner.common.models.capture_result import StepOrigin, TestCaseResult
from test_runner.common.config import ValidationConfiguration
from test_runner.validate.comparator import compare_results


# ---------------------------------------------------------------------------
# BaselineData.step_origins
# ---------------------------------------------------------------------------

class TestBaselineDataStepOrigins:
    def test_from_capture_with_step_origins(self):
        result = TestCaseResult(
            result_sets=[[{"ID": 1}], [{"NAME": "a"}]],
            row_counts=[1, 1],
            column_types=[{"ID": "INTEGER"}, {"NAME": "VARCHAR"}],
            step_origins=[StepOrigin(0, None), StepOrigin(1, 0)],
        )
        bl = BaselineData.from_capture("dbo.Proc", {"p": 1}, result)
        assert bl.step_origins == [[0, None], [1, 0]]

    def test_from_capture_without_step_origins(self):
        result = TestCaseResult(
            result_sets=[[{"ID": 1}]],
            row_counts=[1],
            column_types=[{"ID": "INTEGER"}],
        )
        bl = BaselineData.from_capture("dbo.Proc", {"p": 1}, result)
        assert bl.step_origins is None

    def test_to_dict_includes_step_origins(self):
        bl = BaselineData(
            procedure="dbo.Proc",
            parameters={"p": 1},
            captured_at="2026-01-01T00:00:00",
            result_sets=[[{"ID": 1}]],
            row_counts=[1],
            success=True,
            step_origins=[[0, None]],
        )
        d = bl.to_dict()
        assert "step_origins" in d
        assert d["step_origins"] == [[0, None]]

    def test_to_dict_excludes_step_origins_when_none(self):
        bl = BaselineData(
            procedure="dbo.Proc",
            parameters={"p": 1},
            captured_at="2026-01-01T00:00:00",
            result_sets=[[{"ID": 1}]],
            row_counts=[1],
            success=True,
        )
        d = bl.to_dict()
        assert "step_origins" not in d

    def test_round_trip_json(self):
        """step_origins survives dict -> BaselineData construction."""
        data = {
            "procedure": "dbo.Proc",
            "parameters": {"p": 1},
            "captured_at": "2026-01-01T00:00:00",
            "result_sets": [[{"ID": 1}], [{"NAME": "a"}]],
            "row_counts": [1, 1],
            "success": True,
            "step_origins": [[0, None], [1, 0]],
        }
        bl = BaselineData(**data)
        assert bl.step_origins == [[0, None], [1, 0]]


# ---------------------------------------------------------------------------
# compare_results with result_set_index
# ---------------------------------------------------------------------------

def _make_config(threshold: int = 10_000) -> MagicMock:
    cfg = MagicMock()
    cfg.validation_database = "TESTDB"
    vc = ValidationConfiguration(in_memory_row_threshold=threshold)
    cfg.validation_configuration = vc
    return cfg


def _make_baseline(row_counts: list[int]) -> MagicMock:
    bl = MagicMock()
    bl.row_counts = row_counts
    return bl


class TestCompareResultsSetIndex:
    @patch("test_runner.validate.comparator.InMemoryResultComparator")
    def test_result_set_index_default_uses_last(self, MockInMemory):
        """Default result_set_index=-1 uses last row_count."""
        MockInMemory.return_value.compare.return_value = ComparisonResult(
            match=True, match_type="data_match",
        )
        cfg = _make_config(threshold=10_000)
        bl = _make_baseline(row_counts=[5, 100])
        compare_results(cfg, MagicMock(), "SELECT 1", "h", "P", baseline=bl)
        MockInMemory.assert_called_once()

    @patch("test_runner.validate.comparator.InMemoryResultComparator")
    def test_result_set_index_selects_specific_set(self, MockInMemory):
        """result_set_index=0 uses row_counts[0]."""
        MockInMemory.return_value.compare.return_value = ComparisonResult(
            match=True, match_type="data_match",
        )
        cfg = _make_config(threshold=10_000)
        bl = _make_baseline(row_counts=[5, 20_000])
        compare_results(
            cfg, MagicMock(), "SELECT 1", "h", "P",
            baseline=bl, result_set_index=0,
        )
        MockInMemory.assert_called_once()
        call_kwargs = MockInMemory.return_value.compare.call_args
        assert call_kwargs.kwargs.get("result_set_index") == 0

    @patch("test_runner.validate.comparator.ResultComparator")
    @patch("test_runner.validate.comparator.InMemoryResultComparator")
    def test_result_set_index_routes_to_transient_when_above_threshold(
        self, MockInMemory, MockResult,
    ):
        """result_set_index=1 with high row count routes to transient."""
        MockResult.return_value.compare.return_value = ComparisonResult(
            match=True, match_type="data_match",
        )
        cfg = _make_config(threshold=100)
        bl = _make_baseline(row_counts=[5, 200])
        compare_results(
            cfg, MagicMock(), "SELECT 1", "h", "P",
            baseline=bl, result_set_index=1,
        )
        MockResult.assert_called_once()
        MockInMemory.assert_not_called()
        call_kwargs = MockResult.return_value.compare.call_args
        assert call_kwargs.kwargs.get("result_set_index") == 1
