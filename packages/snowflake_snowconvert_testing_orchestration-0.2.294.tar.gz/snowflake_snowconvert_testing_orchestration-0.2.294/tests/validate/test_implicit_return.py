"""Unit tests for ``test_runner.validate.implicit_return``."""

from __future__ import annotations

import pytest

from test_runner.validate.implicit_return import is_implicit_snowflake_return


class TestIsImplicitSnowflakeReturn:
    """Verify the precise observable matches Snowflake's CALL status payload
    and never aliases real result-set data."""

    @pytest.mark.parametrize(
        ("col_names", "row_count", "procedure"),
        [
            (["DELETE_CUSTOMER_REVIEW"], 1, "ecommerce_e2e.delete_customer_review"),
            (["delete_customer_review"], 1, "ecommerce_e2e.delete_customer_review"),
            (["GET_PRODUCTS_BY_CATEGORY"], 1, "ecommerce_e2e.get_products_by_category"),
            (["UPDATE_CUSTOMER_REVIEW"], 1, "db.schema.update_customer_review"),
            (["UPDATE_CUSTOMER_REVIEW"], 1, "update_customer_review"),
            (["ANONYMOUS BLOCK"], 1, "db.schema.any_proc"),
            (["anonymous block"], 1, "db.schema.any_proc"),
            # V1 fixtures preserved from prior runner-level tests:
            (["INSERTCOLOR"], 1, "master.dbo.InsertColor"),
            (["ACTIVATEWEBSITELOGON"], 1,
             "WideWorldImporters.Website.ActivateWebsiteLogon"),
            (["anonymous block"], 1, "test.get_top_products"),
        ],
    )
    def test_matches_implicit_payload(self, col_names, row_count, procedure):
        assert is_implicit_snowflake_return(col_names, row_count, procedure) is True

    @pytest.mark.parametrize(
        ("col_names", "row_count", "procedure"),
        [
            ([], 0, "schema.delete_customer_review"),
            (["DELETE_CUSTOMER_REVIEW"], 0, "schema.delete_customer_review"),
            (["DELETE_CUSTOMER_REVIEW"], 2, "schema.delete_customer_review"),
            (["ROWS_AFFECTED"], 1, "schema.delete_customer_review"),
            (["DELETE_CUSTOMER_REVIEW", "EXTRA"], 1, "schema.delete_customer_review"),
            (["PRODUCT_ID", "PRODUCT_NAME"], 1, "schema.get_products_by_category"),
            # V1 fixtures preserved from prior runner-level tests:
            (["INSERTCOLOR"], 3, "master.dbo.InsertColor"),
            (["ID", "NAME"], 1, "master.dbo.InsertColor"),
            (["COLORID"], 1, "master.dbo.InsertColor"),
            (["INSERTCOLOR"], 0, "master.dbo.InsertColor"),
        ],
    )
    def test_does_not_match_real_data(self, col_names, row_count, procedure):
        assert is_implicit_snowflake_return(col_names, row_count, procedure) is False
