"""Smoke tests for _run_parallel_validate and _run_parallel_capture.

These tests exercise the top-level orchestration logic — partition,
parallel fan-out, sequential DML fallback — without connecting to
any real database.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from tests.parallel.conftest import make_test_file
from test_runner.validate.runner import _run_parallel_validate
from test_runner.capture.runner import _run_parallel_capture


class TestRunParallelValidateConfig:
    """Guard-rail tests for _run_parallel_validate's preconditions."""

    def test_sf_config_none_with_read_only_cases_raises(self):
        """Read-only parallel path requires sf_config to create per-thread executors."""
        tf = make_test_file("sp_read", modifies_data=False, cases=1)

        with pytest.raises(RuntimeError, match="Snowflake connection config"):
            _run_parallel_validate(
                test_files=[tf],
                baseline_index={},
                connector=MagicMock(),
                sf_factory=MagicMock(),
                sf_config=None,
                format_literal=str,
                config=MagicMock(),
                dump_baseline_and_actual=False,
                workers=2,
            )

    # _validate_case requires a full executor + connector + DB stack;
    # we patch it because this test only verifies the partition-and-dispatch
    # logic, not the per-case validation logic.
    @patch("test_runner.validate.runner._validate_case")
    def test_no_error_when_only_dml_cases_and_sf_config_none(self, mock_validate_case):
        """DML-only cases skip the parallel path, so sf_config=None is fine."""
        tf = make_test_file("sp_write", modifies_data=True, cases=1)

        mock_validate_case.return_value = MagicMock(
            procedure="sp_write", params_hash="h", status="PASS",
        )

        mock_connector = MagicMock()
        mock_factory = MagicMock()
        mock_factory.executor = MagicMock()
        mock_config = MagicMock()
        mock_config.validation_database = ""

        results = _run_parallel_validate(
            test_files=[tf],
            baseline_index={},
            connector=mock_connector,
            sf_factory=mock_factory,
            sf_config=None,
            format_literal=str,
            config=mock_config,
            dump_baseline_and_actual=False,
            workers=2,
        )

        assert len(results) == 1

    def test_empty_test_files_returns_empty(self):
        results = _run_parallel_validate(
            test_files=[],
            baseline_index={},
            connector=MagicMock(),
            sf_factory=MagicMock(),
            sf_config=None,
            format_literal=str,
            config=MagicMock(),
            dump_baseline_and_actual=False,
            workers=2,
        )
        assert results == []


class TestRunParallelCaptureConfig:
    """Guard-rail tests for _run_parallel_capture's preconditions."""

    def test_source_config_none_with_read_only_cases_raises(self):
        tf = make_test_file("sp_read", modifies_data=False, cases=1)

        mock_factory = MagicMock()
        mock_factory.dialect.value = "snowflake"
        mock_factory.format_literal = str

        with pytest.raises(RuntimeError, match="Parallel capture requires"):
            _run_parallel_capture(
                test_files=[tf],
                factory=mock_factory,
                source_config=None,
                capture_date=MagicMock(),
                stats=MagicMock(),
                replay_cfg=None,
                workers=2,
            )

    # _capture_test_file requires a full executor + DB connection;
    # we patch it because this test only verifies the partition-and-dispatch
    # logic, not the per-file capture logic.
    @patch("test_runner.capture.runner._capture_test_file")
    def test_no_error_when_only_dml_cases_and_source_config_none(self, mock_capture_tf):
        """DML-only cases skip the parallel path, so source_config=None is fine."""
        tf = make_test_file("sp_write", modifies_data=True, cases=1)

        mock_factory = MagicMock()
        mock_factory.dialect.value = "snowflake"
        mock_factory.format_literal = str
        mock_stats = MagicMock()

        _run_parallel_capture(
            test_files=[tf],
            factory=mock_factory,
            source_config=None,
            capture_date=MagicMock(),
            stats=mock_stats,
            replay_cfg=None,
            workers=2,
        )

        mock_capture_tf.assert_called_once()
