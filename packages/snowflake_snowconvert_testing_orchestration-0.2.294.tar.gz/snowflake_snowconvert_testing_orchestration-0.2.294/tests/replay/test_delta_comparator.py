"""Tests for replay.delta_comparator — comparison logic and ignore_columns."""

from __future__ import annotations

import pytest

from test_runner.common.collation import CollationClassifier
from test_runner.common.comparison_context import ComparisonContext
from test_runner.common.set_table import RISK_CONFIRMED, RISK_POSSIBLE
from test_runner.replay.delta_comparator import (
    _strip_columns,
    compare_table_deltas,
)


# Default column_types for tests where the type mapping is irrelevant — every
# column gets ``VARCHAR`` so SDV's normalisation pipeline picks the Utf8
# template (a no-op stringification) for both sides.
def _types(*cols: str) -> dict[str, str]:
    return {c: "VARCHAR" for c in cols}


class TestStripColumns:
    def test_strips_matching_columns(self):
        rows = [{"A": 1, "B": 2, "C": 3}]
        result = _strip_columns(rows, {"B"})
        assert result == [{"A": 1, "C": 3}]

    def test_case_insensitive(self):
        rows = [{"ValidFrom": "2024-01-01", "Name": "x"}]
        result = _strip_columns(rows, {"VALIDFROM"})
        assert result == [{"Name": "x"}]

    def test_empty_ignore_returns_original(self):
        rows = [{"A": 1}]
        assert _strip_columns(rows, set()) is rows

    def test_empty_rows_returns_original(self):
        assert _strip_columns([], {"A"}) == []

    def test_multiple_rows(self):
        rows = [
            {"A": 1, "B": 2, "C": 3},
            {"A": 4, "B": 5, "C": 6},
        ]
        result = _strip_columns(rows, {"B", "C"})
        assert result == [{"A": 1}, {"A": 4}]


class TestCompareTableDeltasIgnoreColumns:
    """Verify that ignore_columns strips columns before comparison."""

    def test_match_when_only_ignored_columns_differ(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01", "VALIDTO": "9999-12-31"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2026-03-11", "VALIDTO": "2099-01-01"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("COLOR", "VALIDFROM", "VALIDTO"),
            ignore_columns=["VALIDFROM", "VALIDTO"],
        )
        assert result["match"] is True

    def test_mismatch_on_non_ignored_column(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Red", "VALIDFROM": "2026-03-11"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("COLOR", "VALIDFROM"),
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is False

    def test_no_ignore_columns_compares_everything(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2026-03-11"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("COLOR", "VALIDFROM"),
        )
        assert result["match"] is False

    def test_ignore_columns_applied_to_deletes(self):
        baseline = {
            "inserts": [],
            "deletes": [{"NAME": "X", "VALIDFROM": "old"}],
            "updates": [],
        }
        actual = {
            "inserts": [],
            "deletes": [{"NAME": "X", "VALIDFROM": "new"}],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME", "VALIDFROM"),
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is True

    def test_ignore_columns_applied_to_updates(self):
        baseline = {
            "inserts": [],
            "deletes": [],
            "updates": [{"after": {"NAME": "X", "VALIDFROM": "old"}}],
        }
        actual = {
            "inserts": [],
            "deletes": [],
            "updates": [{"after": {"NAME": "X", "VALIDFROM": "new"}}],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME", "VALIDFROM"),
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is True


# ---------------------------------------------------------------------------
# Count mismatch detection
# ---------------------------------------------------------------------------

class TestCompareTableDeltasCountMismatches:
    """Each mutation category detects count mismatches independently."""

    @pytest.mark.parametrize("category, diff_type", [
        ("inserts", "insert_count_mismatch"),
        ("deletes", "delete_count_mismatch"),
        ("updates", "update_count_mismatch"),
    ], ids=["inserts", "deletes", "updates"])
    def test_count_mismatch_detected(self, category, diff_type):
        baseline = {"inserts": [], "deletes": [], "updates": []}
        actual = {"inserts": [], "deletes": [], "updates": []}
        baseline[category] = [{"ID": 1}]
        actual[category] = [{"ID": 1}, {"ID": 2}]

        result = compare_table_deltas(baseline, actual, "S.T", column_types=_types("ID"))

        assert result["match"] is False
        assert any(d["type"] == diff_type for d in result["differences"])
        mismatch = next(d for d in result["differences"] if d["type"] == diff_type)
        assert mismatch["baseline"] == 1
        assert mismatch["actual"] == 2

    def test_count_mismatch_short_circuits_before_content_comparison(self):
        """When counts differ, no content comparison is attempted."""
        baseline = {"inserts": [{"X": 1}], "deletes": [], "updates": []}
        actual = {"inserts": [{"X": 1}, {"X": 2}], "deletes": [], "updates": []}

        result = compare_table_deltas(baseline, actual, "S.T", column_types=_types("X"))

        assert result["match"] is False
        assert len(result["differences"]) == 1
        assert result["differences"][0]["type"] == "insert_count_mismatch"


# ---------------------------------------------------------------------------
# Content comparison via SDV public API
# ---------------------------------------------------------------------------

class TestCompareTableDeltasContent:
    """Content-level comparison via result_set_cell_level_validation."""

    def test_insert_content_mismatch_detected(self):
        baseline = {"inserts": [{"COLOR": "Blue"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"COLOR": "Red"}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("COLOR"),
        )

        assert result["match"] is False
        assert any(
            d["type"] == "insert_content_mismatch"
            for d in result["differences"]
        )

    def test_delete_content_mismatch_detected(self):
        baseline = {"inserts": [], "deletes": [{"ID": 1}], "updates": []}
        actual = {"inserts": [], "deletes": [{"ID": 2}], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types={"ID": "NUMBER"},
        )

        assert result["match"] is False
        assert any(
            d["type"] == "delete_content_mismatch"
            for d in result["differences"]
        )

    def test_update_after_rows_compared(self):
        """Updates are compared by their 'after' rows."""
        baseline = {
            "inserts": [], "deletes": [],
            "updates": [{"after": {"NAME": "Alice"}}],
        }
        actual = {
            "inserts": [], "deletes": [],
            "updates": [{"after": {"NAME": "Bob"}}],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME"),
        )

        assert result["match"] is False
        assert any(
            d["type"] == "update_content_mismatch"
            for d in result["differences"]
        )

    def test_empty_both_sides_match(self):
        baseline = {"inserts": [], "deletes": [], "updates": []}
        actual = {"inserts": [], "deletes": [], "updates": []}

        result = compare_table_deltas(baseline, actual, "S.T", column_types={})

        assert result["match"] is True
        assert result["differences"] == []


class TestDecimalMismatchEndToEnd:
    """End-to-end: baseline JSON-deserialised values (Decimal-as-string,
    float-from-decimal) compared against actual cursor-typed values
    must produce no spurious diffs once routed through SDV's type-aware
    public API.  Regression for SNOW-3414326 / SNOW-3356602."""

    def test_decimal_string_baseline_matches_float_actual(self):
        """Baseline Decimal-as-string vs actual Float64 — both sides must
        be cast to Float64 by the YAML mapping, then normalised by the
        FLOAT64 string template, and compare equal."""
        baseline = {
            "inserts": [{"ID": 1, "PRICE": "19.99"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"ID": 1, "PRICE": 19.99}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "DB.SCHEMA.PRODUCTS",
            column_types={"ID": "NUMBER", "PRICE": "NUMBER"},
        )

        assert result["match"] is True

    def test_decimal_trailing_zero_difference_normalised(self):
        """Snowflake NUMBER(10,2) ``25.00`` vs JSON-roundtripped ``25.0``
        must compare equal — the FLOAT64 normalisation template rounds
        both sides identically."""
        baseline = {
            "inserts": [{"ID": 1, "PRICE": 25.0}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"ID": 1, "PRICE": 25.00}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "DB.SCHEMA.PRODUCTS",
            column_types={"ID": "NUMBER", "PRICE": "NUMBER"},
        )

        assert result["match"] is True

    def test_decimal_string_baseline_detects_value_mismatch(self):
        baseline = {
            "inserts": [{"ID": 1, "PRICE": "19.99"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"ID": 1, "PRICE": 29.99}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "DB.SCHEMA.PRODUCTS",
            column_types={"ID": "NUMBER", "PRICE": "NUMBER"},
        )

        assert result["match"] is False


# ---------------------------------------------------------------------------
# Collation risk tagging
# ---------------------------------------------------------------------------

class TestCollationCountMismatchTagging:
    """Verify that count-mismatch diffs get collation_risk annotation."""

    def test_insert_count_mismatch_tagged_with_fdm(self):
        baseline = {"inserts": [{"ID": 1}], "deletes": [], "updates": []}
        actual = {"inserts": [{"ID": 1}, {"ID": 2}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("ID"),
            has_collation_fdm=True,
        )

        assert result["match"] is False
        mismatch = result["differences"][0]
        assert mismatch["type"] == "insert_count_mismatch"
        assert mismatch["collation_risk"] == "possible"

    def test_count_mismatch_tagged_with_ci_columns(self):
        baseline = {"inserts": [{"NAME": "A"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"NAME": "A"}, {"NAME": "B"}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME"),
            case_insensitive_columns=["NAME"],
        )

        assert result["match"] is False
        mismatch = result["differences"][0]
        assert mismatch["collation_risk"] == "possible"

    def test_count_mismatch_tagged_with_classifier(self):
        classifier = CollationClassifier(
            has_collation_fdm=True,
            fdm_code="SSC-FDM-TD0032",
            case_insensitive_columns_by_table={"S.T": ["NAME"]},
        )
        baseline = {"inserts": [{"NAME": "A"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"NAME": "A"}, {"NAME": "B"}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME"),
            collation=classifier,
        )

        assert result["match"] is False
        mismatch = result["differences"][0]
        assert mismatch["collation_risk"] == "possible"
        assert mismatch["fdm_code"] == "SSC-FDM-TD0032"

    def test_count_mismatch_not_tagged_without_collation(self):
        baseline = {"inserts": [{"ID": 1}], "deletes": [], "updates": []}
        actual = {"inserts": [{"ID": 1}, {"ID": 2}], "deletes": [], "updates": []}

        result = compare_table_deltas(baseline, actual, "S.T", column_types=_types("ID"))

        assert result["match"] is False
        mismatch = result["differences"][0]
        assert "collation_risk" not in mismatch

    def test_count_mismatch_not_tagged_with_inactive_classifier(self):
        classifier = CollationClassifier()
        baseline = {"inserts": [{"ID": 1}], "deletes": [], "updates": []}
        actual = {"inserts": [{"ID": 1}, {"ID": 2}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("ID"),
            collation=classifier,
        )

        assert result["match"] is False
        mismatch = result["differences"][0]
        assert "collation_risk" not in mismatch

    def test_multiple_count_mismatches_all_tagged(self):
        baseline = {"inserts": [{"ID": 1}], "deletes": [{"ID": 3}], "updates": []}
        actual = {"inserts": [{"ID": 1}, {"ID": 2}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("ID"),
            has_collation_fdm=True,
        )

        assert result["match"] is False
        assert len(result["differences"]) == 2
        for diff in result["differences"]:
            assert diff["collation_risk"] == "possible"

    def test_table_scoped_no_ci_columns_for_table_not_tagged(self):
        """Table-aware: no CI columns for this specific table, no FDM."""
        classifier = CollationClassifier(
            case_insensitive_columns_by_table={"S.OTHER": ["NAME"]},
        )
        baseline = {"inserts": [{"ID": 1}], "deletes": [], "updates": []}
        actual = {"inserts": [{"ID": 1}, {"ID": 2}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("ID"),
            collation=classifier,
        )

        assert result["match"] is False
        mismatch = result["differences"][0]
        assert "collation_risk" not in mismatch


class TestCollationRiskTagging:
    """Verify that collation metadata annotates cell-level diffs."""

    def test_mismatch_on_tagged_column_gets_collation_risk_true(self):
        baseline = {"inserts": [{"NAME": "Alice"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"NAME": "alice"}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME"),
            case_insensitive_columns=["NAME"],
        )

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        assert len(diffs) >= 1
        tagged = [d for d in diffs if d.get("column", "").upper() == "NAME"]
        assert tagged
        assert tagged[0]["collation_risk"] is True

    def test_mismatch_on_untagged_column_with_fdm_gets_possible(self):
        baseline = {"inserts": [{"TITLE": "Hello"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"TITLE": "hello"}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("TITLE"),
            has_collation_fdm=True,
        )

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        tagged = [d for d in diffs if d.get("column", "").upper() == "TITLE"]
        assert tagged
        assert tagged[0]["collation_risk"] == "possible"

    def test_no_tagging_without_collation_metadata(self):
        baseline = {"inserts": [{"NAME": "Alice"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"NAME": "alice"}], "deletes": [], "updates": []}

        result = compare_table_deltas(baseline, actual, "S.T", column_types=_types("NAME"))

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        for d in diffs:
            assert "collation_risk" not in d
            assert "fdm_code" not in d

    def test_numeric_mismatch_not_tagged_with_fdm_only(self):
        """Non-string values should not get collation_risk even with has_collation_fdm."""
        baseline = {"inserts": [{"AMOUNT": 100}], "deletes": [], "updates": []}
        actual = {"inserts": [{"AMOUNT": 200}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types={"AMOUNT": "NUMBER"},
            has_collation_fdm=True,
        )

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        for d in diffs:
            assert "collation_risk" not in d

    def test_tagging_applied_to_updates(self):
        baseline = {
            "inserts": [], "deletes": [],
            "updates": [{"after": {"NAME": "Alice"}}],
        }
        actual = {
            "inserts": [], "deletes": [],
            "updates": [{"after": {"NAME": "alice"}}],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME"),
            case_insensitive_columns=["NAME"],
        )

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        tagged = [d for d in diffs if d.get("collation_risk") is True]
        assert tagged

    def test_tagging_applied_to_deletes(self):
        baseline = {"inserts": [], "deletes": [{"NAME": "Alice"}], "updates": []}
        actual = {"inserts": [], "deletes": [{"NAME": "alice"}], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME"),
            case_insensitive_columns=["NAME"],
        )

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        tagged = [d for d in diffs if d.get("collation_risk") is True]
        assert tagged


class TestCollationClassifierIntegration:
    """Verify that the CollationClassifier API works end-to-end with delta comparator."""

    def test_classifier_with_precise_column(self):
        classifier = CollationClassifier(
            has_collation_fdm=True,
            fdm_code="SSC-FDM-TD0032",
            case_insensitive_columns_by_table={"S.T": ["NAME"]},
        )
        baseline = {"inserts": [{"NAME": "Alice"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"NAME": "alice"}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME"),
            collation=classifier,
        )

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        tagged = [d for d in diffs if d.get("column", "").upper() == "NAME"]
        assert tagged[0]["collation_risk"] is True
        assert tagged[0]["fdm_code"] == "SSC-FDM-TD0032"

    def test_classifier_coarse_signal_for_unknown_column(self):
        classifier = CollationClassifier(has_collation_fdm=True, fdm_code="SSC-FDM-TD0032")
        baseline = {"inserts": [{"TITLE": "Hello"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"TITLE": "hello"}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("TITLE"),
            collation=classifier,
        )

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        tagged = [d for d in diffs if d.get("column", "").upper() == "TITLE"]
        assert tagged[0]["collation_risk"] == "possible"
        assert tagged[0]["fdm_code"] == "SSC-FDM-TD0032"

    def test_inactive_classifier_no_tagging(self):
        classifier = CollationClassifier()
        baseline = {"inserts": [{"NAME": "Alice"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"NAME": "alice"}], "deletes": [], "updates": []}

        result = compare_table_deltas(
            baseline, actual, "S.T",
            column_types=_types("NAME"),
            collation=classifier,
        )

        assert result["match"] is False
        diffs = result["differences"][0]["cell_diffs"]
        for d in diffs:
            assert "collation_risk" not in d


# ---------------------------------------------------------------------------
# SET table integration tests
# ---------------------------------------------------------------------------

class TestSetTableIntegration:
    """Verify SET table dedup annotation and match-flipping via ComparisonContext."""

    SET_CTX = ComparisonContext(set_tables=frozenset({"SCHEMA.TABLE1"}))

    @pytest.mark.parametrize(
        ("baseline", "actual", "expected_dupes"),
        [
            pytest.param(
                {"inserts": [{"ID": 1, "V": "a"}, {"ID": 2, "V": "b"}], "deletes": [], "updates": []},
                {"inserts": [{"ID": 1, "V": "a"}, {"ID": 1, "V": "a"}, {"ID": 2, "V": "b"}], "deletes": [], "updates": []},
                1,
                id="insert-mismatch",
            ),
            pytest.param(
                {"inserts": [], "deletes": [{"ID": 1}, {"ID": 2}], "updates": []},
                {"inserts": [], "deletes": [{"ID": 1}, {"ID": 1}, {"ID": 2}], "updates": []},
                1,
                id="delete-mismatch",
            ),
        ],
    )
    def test_confirmed_mismatch_flips_match(self, baseline, actual, expected_dupes):
        result = compare_table_deltas(
            baseline, actual, "SCHEMA.TABLE1", column_types={}, cmp_ctx=self.SET_CTX,
        )
        assert result["match"] is True
        diffs = result["differences"]
        assert len(diffs) == 1
        assert diffs[0]["set_table_risk"] == RISK_CONFIRMED
        assert diffs[0]["duplicate_rows"] == expected_dupes

    def test_no_ctx_does_not_annotate(self):
        baseline = {
            "inserts": [{"ID": 1}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"ID": 1}, {"ID": 1}],
            "deletes": [],
            "updates": [],
        }
        result = compare_table_deltas(baseline, actual, "SCHEMA.TABLE1", column_types={})
        assert result["match"] is False
        assert "set_table_risk" not in result["differences"][0]

    def test_non_set_table_not_annotated(self):
        baseline = {
            "inserts": [{"ID": 1}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"ID": 1}, {"ID": 1}],
            "deletes": [],
            "updates": [],
        }
        result = compare_table_deltas(
            baseline, actual, "SCHEMA.OTHER_TABLE", column_types={}, cmp_ctx=self.SET_CTX,
        )
        assert result["match"] is False
        assert "set_table_risk" not in result["differences"][0]

    def test_possible_when_dedup_still_mismatches(self):
        baseline = {
            "inserts": [{"ID": 1}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"ID": 1}, {"ID": 2}, {"ID": 2}],
            "deletes": [],
            "updates": [],
        }
        result = compare_table_deltas(
            baseline, actual, "SCHEMA.TABLE1", column_types={}, cmp_ctx=self.SET_CTX,
        )
        assert result["match"] is False
        assert result["differences"][0]["set_table_risk"] == RISK_POSSIBLE
