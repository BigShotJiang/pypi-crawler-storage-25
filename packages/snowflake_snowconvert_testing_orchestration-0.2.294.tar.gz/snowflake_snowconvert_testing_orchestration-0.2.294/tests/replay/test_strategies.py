"""Tests for replay.strategies — unmocked, using real DuckDB.

Exercises FullSnapshotStrategy, PkDiffStrategy, and SyntheticKeyStrategy
with representative row data to verify that inserts, deletes, updates,
ignore_columns, type promotion, and edge cases produce correct results
through the actual DuckDB pipeline.

Also covers select_strategy which routes based on PK availability and
column count.
"""

from __future__ import annotations

import pytest

from test_runner.common.config import ReplayConfiguration
from test_runner.replay.delta_capture import compute_table_delta, select_strategy
from test_runner.replay.models import DeltaStrategy, TableConfig, make_delta
from test_runner.replay.strategies.full_snapshot import (
    FullSnapshotStrategy,
    _register,
    _resolve_columns,
)
from test_runner.replay.strategies.pk_diff import PkDiffStrategy
from test_runner.replay.strategies.synthetic_key import SyntheticKeyStrategy


# ---------------------------------------------------------------------------
# FullSnapshotStrategy.compute_delta — real DuckDB
# ---------------------------------------------------------------------------

class TestFullSnapshotStrategy:
    """Tests run real DuckDB EXCEPT queries — no mocks."""

    def _make_cfg(self, schema="S", table="T", ignore=None):
        return TableConfig(
            schema_name=schema,
            table_name=table,
            ignore_columns=ignore or [],
        )

    def _strategy(self):
        return FullSnapshotStrategy()

    def test_inserts_detected(self):
        before: list[dict] = []
        after = [{"COLOR": "Blue", "ID": 1}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["strategy_used"] == "full_snapshot"
        assert delta["inserts"] == [{"COLOR": "Blue", "ID": 1}]
        assert delta["deletes"] == []

    def test_deletes_detected(self):
        before = [{"COLOR": "Blue", "ID": 1}]
        after: list[dict] = []
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["deletes"] == [{"COLOR": "Blue", "ID": 1}]
        assert delta["inserts"] == []

    def test_no_changes_produces_empty_delta(self):
        rows = [{"COLOR": "Blue", "ID": 1}, {"COLOR": "Red", "ID": 2}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(rows, list(rows), cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_mixed_mutations(self):
        before = [{"COLOR": "Blue", "ID": 1}, {"COLOR": "Red", "ID": 2}]
        after = [{"COLOR": "Blue", "ID": 1}, {"COLOR": "Green", "ID": 3}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["COLOR"] == "Green"
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["COLOR"] == "Red"

    def test_ignore_columns_excluded_from_diff(self):
        before = [{"COLOR": "Blue", "VALIDFROM": "2024-01-01"}]
        after = [{"COLOR": "Blue", "VALIDFROM": "2026-03-11"}]
        cfg = self._make_cfg(ignore=["VALIDFROM"])

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_ignore_columns_case_insensitive(self):
        before = [{"Color": "Blue", "ValidFrom": "old"}]
        after = [{"Color": "Blue", "ValidFrom": "new"}]
        cfg = self._make_cfg(ignore=["VALIDFROM"])

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_float_to_int64_promotion(self):
        """Float columns that contain only integer values should be
        promoted to Int64 so that DuckDB comparisons are exact."""
        before = [{"ID": 1.0, "QTY": 10.0}]
        after = [{"ID": 1.0, "QTY": 10.0}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_float_with_fractional_not_promoted(self):
        """Float columns with fractional values stay as float64."""
        before = [{"PRICE": 10.5}]
        after = [{"PRICE": 10.7}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1

    def test_bytes_values_hex_encoded(self):
        """Binary data should be hex-encoded in _register before DuckDB."""
        before = [{"DATA": b"\x01\x02", "ID": 1}]
        after = [{"DATA": b"\x03\x04", "ID": 1}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["DATA"] == "0304"
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["DATA"] == "0102"

    def test_empty_both_sides(self):
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta([], [], cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert delta["table"] == "S.T"

    def test_large_row_set(self):
        """Verify correctness at 1000+ rows."""
        before = [{"ID": i, "VAL": f"v{i}"} for i in range(1000)]
        after = [{"ID": i, "VAL": f"v{i}"} for i in range(1, 1001)]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["ID"] == 1000
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["ID"] == 0

    def test_none_values_handled(self):
        before = [{"ID": 1, "NAME": None}]
        after = [{"ID": 1, "NAME": "Alice"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1

    def test_delta_table_field_matches_fqn(self):
        cfg = self._make_cfg(schema="WAREHOUSE", table="COLORS")

        delta = self._strategy().compute_delta([], [], cfg)

        assert delta["table"] == "WAREHOUSE.COLORS"

    def test_metadata_present_with_correct_counts(self):
        before = [{"ID": 1, "COLOR": "Blue"}]
        after = [{"ID": 2, "COLOR": "Red"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        meta = delta["metadata"]
        assert meta["rows_affected"] == len(delta["inserts"]) + len(delta["deletes"])
        assert meta["capture_duration_ms"] == 0
        assert meta["warnings"] == []

    def test_strategy_name_is_full_snapshot(self):
        assert self._strategy().name == DeltaStrategy.FULL_SNAPSHOT


# ---------------------------------------------------------------------------
# _resolve_columns
# ---------------------------------------------------------------------------

class TestResolveColumns:
    def test_returns_sorted_column_names(self):
        rows = [{"C": 3, "A": 1, "B": 2}]
        cfg = TableConfig(schema_name="S", table_name="T")
        assert _resolve_columns(rows, cfg) == ["A", "B", "C"]

    def test_excludes_ignored_columns(self):
        rows = [{"A": 1, "B": 2, "C": 3}]
        cfg = TableConfig(schema_name="S", table_name="T", ignore_columns=["B"])
        assert _resolve_columns(rows, cfg) == ["A", "C"]

    def test_empty_rows_returns_empty(self):
        cfg = TableConfig(schema_name="S", table_name="T")
        assert _resolve_columns([], cfg) == []

    def test_ignore_is_case_insensitive(self):
        rows = [{"ValidFrom": "x", "Name": "y"}]
        cfg = TableConfig(schema_name="S", table_name="T", ignore_columns=["VALIDFROM"])
        assert _resolve_columns(rows, cfg) == ["Name"]


# ---------------------------------------------------------------------------
# _register — DuckDB DataFrame registration
# ---------------------------------------------------------------------------

class TestRegister:
    def test_registers_dataframe_readable_by_duckdb(self):
        import duckdb
        conn = duckdb.connect()
        try:
            _register(conn, "test_tbl", [{"A": 1, "B": "x"}], ["A", "B"])
            result = conn.execute("SELECT * FROM test_tbl").fetchdf()
            assert len(result) == 1
            assert list(result.columns) == ["A", "B"]
        finally:
            conn.close()

    def test_empty_rows_creates_empty_frame(self):
        import duckdb
        conn = duckdb.connect()
        try:
            _register(conn, "empty_tbl", [], ["A", "B"])
            result = conn.execute("SELECT * FROM empty_tbl").fetchdf()
            assert len(result) == 0
            assert list(result.columns) == ["A", "B"]
        finally:
            conn.close()

    def test_hex_encodes_bytes(self):
        import duckdb
        conn = duckdb.connect()
        try:
            _register(conn, "bin_tbl", [{"DATA": b"\xff\x00"}], ["DATA"])
            result = conn.execute("SELECT * FROM bin_tbl").fetchdf()
            assert result["DATA"][0] == "ff00"
        finally:
            conn.close()

    def test_float_integer_promoted_to_int64(self):
        import duckdb
        conn = duckdb.connect()
        try:
            _register(conn, "num_tbl", [{"ID": 1.0, "QTY": 10.0}], ["ID", "QTY"])
            result = conn.execute("SELECT typeof(\"ID\") FROM num_tbl").fetchone()
            assert "INT" in result[0].upper() or "BIGINT" in result[0].upper()
        finally:
            conn.close()


# ---------------------------------------------------------------------------
# PkDiffStrategy.compute_delta — real DuckDB
# ---------------------------------------------------------------------------

class TestPkDiffStrategy:
    """Tests run real DuckDB JOIN queries — no mocks."""

    def _make_cfg(self, schema="S", table="T", pk=None, ignore=None):
        return TableConfig(
            schema_name=schema,
            table_name=table,
            primary_key_columns=pk or ["ID"],
            ignore_columns=ignore or [],
        )

    def _strategy(self):
        return PkDiffStrategy()

    def test_inserts_detected(self):
        before: list[dict] = []
        after = [{"ID": 1, "COLOR": "Blue"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["strategy_used"] == "pk_diff"
        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["COLOR"] == "Blue"
        assert delta["deletes"] == []
        assert delta["updates"] == []

    def test_deletes_detected(self):
        before = [{"ID": 1, "COLOR": "Blue"}]
        after: list[dict] = []
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["COLOR"] == "Blue"
        assert delta["inserts"] == []
        assert delta["updates"] == []

    def test_updates_detected(self):
        before = [{"ID": 1, "COLOR": "Blue", "QTY": 10}]
        after = [{"ID": 1, "COLOR": "Red", "QTY": 10}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert len(delta["updates"]) == 1

        upd = delta["updates"][0]
        assert upd["key"] == {"ID": 1}
        assert upd["before"]["COLOR"] == "Blue"
        assert upd["after"]["COLOR"] == "Red"
        assert "COLOR" in upd["changed_columns"]
        assert "QTY" not in upd["changed_columns"]

    def test_mixed_mutations(self):
        before = [
            {"ID": 1, "COLOR": "Blue"},
            {"ID": 2, "COLOR": "Red"},
            {"ID": 3, "COLOR": "Green"},
        ]
        after = [
            {"ID": 1, "COLOR": "Blue"},
            {"ID": 2, "COLOR": "Yellow"},
            {"ID": 4, "COLOR": "White"},
        ]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["ID"] == 4
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["ID"] == 3
        assert len(delta["updates"]) == 1
        assert delta["updates"][0]["key"] == {"ID": 2}
        assert delta["updates"][0]["after"]["COLOR"] == "Yellow"

    def test_no_changes_produces_empty_delta(self):
        rows = [{"ID": 1, "COLOR": "Blue"}, {"ID": 2, "COLOR": "Red"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(rows, list(rows), cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert delta["updates"] == []

    def test_composite_pk(self):
        before = [{"K1": 1, "K2": "A", "VAL": "old"}]
        after = [{"K1": 1, "K2": "A", "VAL": "new"}]
        cfg = self._make_cfg(pk=["K1", "K2"])

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["updates"]) == 1
        assert delta["updates"][0]["key"] == {"K1": 1, "K2": "A"}
        assert delta["updates"][0]["changed_columns"] == ["VAL"]

    def test_ignore_columns_excluded(self):
        before = [{"ID": 1, "COLOR": "Blue", "MODIFIED_AT": "old"}]
        after = [{"ID": 1, "COLOR": "Blue", "MODIFIED_AT": "new"}]
        cfg = self._make_cfg(ignore=["MODIFIED_AT"])

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert delta["updates"] == []

    def test_none_to_value_detected_as_update(self):
        before = [{"ID": 1, "NAME": None}]
        after = [{"ID": 1, "NAME": "Alice"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["updates"]) == 1
        assert "NAME" in delta["updates"][0]["changed_columns"]

    def test_raises_without_pk_columns(self):
        cfg = TableConfig(
            schema_name="S", table_name="T",
            primary_key_columns=[],
        )
        with pytest.raises(ValueError, match="primary_key_columns"):
            self._strategy().compute_delta([], [], cfg)

    def test_empty_both_sides(self):
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta([], [], cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert delta["updates"] == []

    def test_metadata_present_with_correct_counts(self):
        before = [{"ID": 1, "COLOR": "Blue"}]
        after = [{"ID": 1, "COLOR": "Red"}, {"ID": 2, "COLOR": "Green"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        meta = delta["metadata"]
        expected = len(delta["inserts"]) + len(delta["deletes"]) + len(delta["updates"])
        assert meta["rows_affected"] == expected
        assert meta["capture_duration_ms"] == 0
        assert meta["warnings"] == []

    def test_strategy_name_is_pk_diff(self):
        assert self._strategy().name == DeltaStrategy.PK_DIFF

    def test_multiple_columns_changed(self):
        before = [{"ID": 1, "A": 1, "B": 2, "C": 3}]
        after = [{"ID": 1, "A": 10, "B": 20, "C": 3}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["updates"]) == 1
        changed = sorted(delta["updates"][0]["changed_columns"])
        assert changed == ["A", "B"]

    def test_bytes_values_handled(self):
        before = [{"ID": 1, "DATA": b"\x01\x02"}]
        after = [{"ID": 1, "DATA": b"\x03\x04"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["updates"]) == 1
        assert delta["updates"][0]["after"]["DATA"] == "0304"
        assert delta["updates"][0]["before"]["DATA"] == "0102"

    def test_pd_na_values_handled(self):
        """pd.NA in nullable columns must not crash _values_equal."""
        import pandas as _pd
        before = [{"ID": 1, "VAL": _pd.NA}]
        after = [{"ID": 1, "VAL": _pd.NA}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["updates"] == []

    def test_pd_na_to_value_detected_as_update(self):
        import pandas as _pd
        before = [{"ID": 1, "VAL": _pd.NA}]
        after = [{"ID": 1, "VAL": 42}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["updates"]) == 1
        assert "VAL" in delta["updates"][0]["changed_columns"]

    def test_pk_column_case_mismatch_does_not_leak_into_changed_columns(self):
        """PK col named 'Id' in CUR but 'ID' in snapshot must not appear in changed_columns."""
        before = [{"ID": 1, "COLOR": "Blue"}]
        after = [{"ID": 1, "COLOR": "Red"}]
        cfg = self._make_cfg(pk=["Id"])

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["updates"]) == 1
        assert "ID" not in delta["updates"][0]["changed_columns"]
        assert delta["updates"][0]["changed_columns"] == ["COLOR"]

    @pytest.mark.parametrize("pk_cols", [
        ["NONEXISTENT_COL"],
        ["ID", "MISSING_COL"],
    ], ids=[
        "all_pk_cols_missing",
        "partial_pk_col_missing",
    ])
    def test_missing_pk_columns_fall_back_to_full_snapshot(self, pk_cols):
        """When any PK column from CUR doesn't exist in the snapshot, fall back."""
        before = [{"ID": 1, "COLOR": "Blue"}]
        after = [{"ID": 2, "COLOR": "Red"}]
        cfg = self._make_cfg(pk=pk_cols)

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["strategy_used"] == "full_snapshot"

    def test_fallback_emits_warning_in_metadata(self):
        before = [{"ID": 1, "COLOR": "Blue"}]
        after = [{"ID": 2, "COLOR": "Red"}]
        cfg = self._make_cfg(pk=["NONEXISTENT"])

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["metadata"]["warnings"]) == 1
        assert "fell back to FULL_SNAPSHOT" in delta["metadata"]["warnings"][0]


# ---------------------------------------------------------------------------
# SyntheticKeyStrategy.compute_delta — real DuckDB
# ---------------------------------------------------------------------------

class TestSyntheticKeyStrategy:
    """Tests run real DuckDB hash + join queries — no mocks."""

    def _make_cfg(self, schema="S", table="T", ignore=None):
        return TableConfig(
            schema_name=schema,
            table_name=table,
            ignore_columns=ignore or [],
        )

    def _strategy(self):
        return SyntheticKeyStrategy()

    def test_strategy_name_is_synthetic_key(self):
        assert self._strategy().name == DeltaStrategy.SYNTHETIC_KEY

    def test_inserts_detected(self):
        before: list[dict] = []
        after = [{"COLOR": "Blue", "ID": 1}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["strategy_used"] == "synthetic_key"
        assert delta["inserts"] == [{"COLOR": "Blue", "ID": 1}]
        assert delta["deletes"] == []

    def test_deletes_detected(self):
        before = [{"COLOR": "Blue", "ID": 1}]
        after: list[dict] = []
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["deletes"] == [{"COLOR": "Blue", "ID": 1}]
        assert delta["inserts"] == []

    def test_no_changes_produces_empty_delta(self):
        rows = [{"COLOR": "Blue", "ID": 1}, {"COLOR": "Red", "ID": 2}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(rows, list(rows), cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_mixed_mutations(self):
        before = [{"COLOR": "Blue", "ID": 1}, {"COLOR": "Red", "ID": 2}]
        after = [{"COLOR": "Blue", "ID": 1}, {"COLOR": "Green", "ID": 3}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["COLOR"] == "Green"
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["COLOR"] == "Red"

    def test_row_value_change_produces_delete_and_insert(self):
        """Synthetic key is a hash of all columns, so any column change
        produces a different hash — appearing as a delete + insert pair
        rather than an update."""
        before = [{"ID": 1, "COLOR": "Blue"}]
        after = [{"ID": 1, "COLOR": "Red"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["COLOR"] == "Red"
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["COLOR"] == "Blue"

    def test_duplicate_rows_tracked_individually(self):
        """Duplicate rows (identical content) must be counted individually.
        Adding a third copy of an existing row should show as one insert."""
        before = [{"ID": 1, "VAL": "A"}, {"ID": 1, "VAL": "A"}]
        after = [{"ID": 1, "VAL": "A"}, {"ID": 1, "VAL": "A"}, {"ID": 1, "VAL": "A"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0] == {"ID": 1, "VAL": "A"}
        assert delta["deletes"] == []

    def test_duplicate_row_removal_detected(self):
        """Removing one copy of a duplicate row should show as one delete."""
        before = [{"ID": 1, "VAL": "A"}, {"ID": 1, "VAL": "A"}, {"ID": 1, "VAL": "A"}]
        after = [{"ID": 1, "VAL": "A"}, {"ID": 1, "VAL": "A"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0] == {"ID": 1, "VAL": "A"}

    def test_ignore_columns_excluded_from_diff(self):
        before = [{"COLOR": "Blue", "VALIDFROM": "2024-01-01"}]
        after = [{"COLOR": "Blue", "VALIDFROM": "2026-03-11"}]
        cfg = self._make_cfg(ignore=["VALIDFROM"])

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_ignore_columns_case_insensitive(self):
        before = [{"Color": "Blue", "ValidFrom": "old"}]
        after = [{"Color": "Blue", "ValidFrom": "new"}]
        cfg = self._make_cfg(ignore=["VALIDFROM"])

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_float_to_int64_promotion(self):
        before = [{"ID": 1.0, "QTY": 10.0}]
        after = [{"ID": 1.0, "QTY": 10.0}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_bytes_values_hex_encoded(self):
        before = [{"DATA": b"\x01\x02", "ID": 1}]
        after = [{"DATA": b"\x03\x04", "ID": 1}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["DATA"] == "0304"
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["DATA"] == "0102"

    def test_empty_both_sides(self):
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta([], [], cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert delta["table"] == "S.T"

    def test_none_values_handled(self):
        before = [{"ID": 1, "NAME": None}]
        after = [{"ID": 1, "NAME": "Alice"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1

    def test_none_to_none_no_change(self):
        before = [{"ID": 1, "NAME": None}]
        after = [{"ID": 1, "NAME": None}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_delta_table_field_matches_fqn(self):
        cfg = self._make_cfg(schema="WAREHOUSE", table="COLORS")

        delta = self._strategy().compute_delta([], [], cfg)

        assert delta["table"] == "WAREHOUSE.COLORS"

    def test_large_row_set(self):
        before = [{"ID": i, "VAL": f"v{i}"} for i in range(1000)]
        after = [{"ID": i, "VAL": f"v{i}"} for i in range(1, 1001)]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["ID"] == 1000
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["ID"] == 0

    def test_metadata_present_with_correct_counts(self):
        before = [{"ID": 1, "COLOR": "Blue"}]
        after = [{"ID": 1, "COLOR": "Red"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        meta = delta["metadata"]
        expected = len(delta["inserts"]) + len(delta["deletes"])
        assert meta["rows_affected"] == expected
        assert meta["capture_duration_ms"] == 0
        assert meta["warnings"] == []

    def test_single_column_change_inferred_as_update(self):
        """When one column changes and others stay the same, the
        delete+insert pair should be promoted to an update."""
        before = [{"ID": 1, "NAME": "Alice", "COLOR": "Blue"}]
        after = [{"ID": 1, "NAME": "Alice", "COLOR": "Red"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert len(delta["updates"]) == 1
        upd = delta["updates"][0]
        assert upd["before"]["COLOR"] == "Blue"
        assert upd["after"]["COLOR"] == "Red"
        assert upd["changed_columns"] == ["COLOR"]
        assert upd["key"]["ID"] == 1
        assert upd["key"]["NAME"] == "Alice"

    def test_all_columns_changed_stays_as_insert_delete(self):
        """When every column differs, inference cannot match the pair
        (0 unchanged < changed) so it remains as insert + delete."""
        before = [{"A": 1, "B": 2}]
        after = [{"A": 99, "B": 88}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1
        assert delta["updates"] == []

    def test_half_columns_changed_stays_as_insert_delete(self):
        """When exactly half the columns change, unchanged == changed,
        so the pair is NOT promoted (requires strictly more unchanged)."""
        before = [{"A": 1, "B": 2, "C": 3, "D": 4}]
        after = [{"A": 1, "B": 2, "C": 99, "D": 88}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1
        assert delta["updates"] == []

    def test_minority_columns_changed_inferred_as_update(self):
        """When changed columns are a strict minority, pair is promoted."""
        before = [{"A": 1, "B": 2, "C": 3, "D": 4, "E": 5}]
        after = [{"A": 1, "B": 2, "C": 3, "D": 4, "E": 99}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert len(delta["updates"]) == 1
        assert delta["updates"][0]["changed_columns"] == ["E"]

    def test_multiple_updates_inferred(self):
        """Multiple delete+insert pairs can each be promoted."""
        before = [
            {"ID": 1, "NAME": "Alice", "SCORE": 10},
            {"ID": 2, "NAME": "Bob", "SCORE": 20},
        ]
        after = [
            {"ID": 1, "NAME": "Alice", "SCORE": 99},
            {"ID": 2, "NAME": "Bob", "SCORE": 88},
        ]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []
        assert len(delta["updates"]) == 2
        scores = sorted(u["after"]["SCORE"] for u in delta["updates"])
        assert scores == [88, 99]

    def test_mixed_update_and_pure_insert_delete(self):
        """An update pair coexists with a pure insert and pure delete."""
        before = [
            {"ID": 1, "NAME": "Alice", "VAL": 10},
            {"ID": 2, "NAME": "Bob", "VAL": 20},
        ]
        after = [
            {"ID": 1, "NAME": "Alice", "VAL": 99},
            {"ID": 3, "NAME": "Charlie", "VAL": 30},
        ]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["updates"]) == 1
        assert delta["updates"][0]["after"]["VAL"] == 99
        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["NAME"] == "Charlie"
        assert len(delta["deletes"]) == 1
        assert delta["deletes"][0]["NAME"] == "Bob"

    def test_greedy_matching_picks_best_pair(self):
        """When multiple pairings are possible, the closest match wins."""
        before = [
            {"A": 1, "B": 2, "C": 3},
        ]
        after = [
            {"A": 1, "B": 2, "C": 99},
            {"A": 77, "B": 88, "C": 99},
        ]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["updates"]) == 1
        assert delta["updates"][0]["after"]["C"] == 99
        assert delta["updates"][0]["after"]["A"] == 1
        assert len(delta["inserts"]) == 1
        assert delta["inserts"][0]["A"] == 77

    def test_update_key_contains_unchanged_columns(self):
        """The ``key`` field should contain the unchanged columns."""
        before = [{"X": 1, "Y": 2, "Z": 3}]
        after = [{"X": 1, "Y": 2, "Z": 99}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        upd = delta["updates"][0]
        assert "X" in upd["key"]
        assert "Y" in upd["key"]
        assert "Z" not in upd["key"]

    def test_update_metadata_rows_affected_includes_updates(self):
        """rows_affected should count updates."""
        before = [{"ID": 1, "COLOR": "Blue", "SIZE": "S"}]
        after = [{"ID": 1, "COLOR": "Red", "SIZE": "S"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert delta["metadata"]["rows_affected"] == 1

    def test_null_literal_distinguished_from_sql_null(self):
        """The string ``"NULL"`` must not hash identically to SQL NULL."""
        before = [{"ID": 1, "VAL": None}]
        after = [{"ID": 1, "VAL": "NULL"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1

    def test_delimiter_in_value_does_not_cause_collision(self):
        """Values containing the old pipe delimiter must not collide
        across column boundaries."""
        before = [{"A": "x|y", "B": "z"}]
        after = [{"A": "x", "B": "y|z"}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1

    def test_empty_string_vs_null_distinguished(self):
        """Empty string and SQL NULL must hash differently."""
        before = [{"ID": 1, "VAL": ""}]
        after = [{"ID": 1, "VAL": None}]
        cfg = self._make_cfg()

        delta = self._strategy().compute_delta(before, after, cfg)

        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1


# ---------------------------------------------------------------------------
# compute_table_delta — metadata / timing
# ---------------------------------------------------------------------------

class TestComputeTableDelta:
    """Verifies that the orchestrator layer populates metadata.capture_duration_ms."""

    def test_capture_duration_populated(self):
        before = [{"ID": i, "VAL": f"v{i}"} for i in range(100)]
        after = [{"ID": i, "VAL": f"v{i}"} for i in range(1, 101)]
        cfg = TableConfig(schema_name="S", table_name="T")

        delta = compute_table_delta(before, after, cfg, ReplayConfiguration())

        assert delta["metadata"]["capture_duration_ms"] >= 0

    def test_metadata_rows_affected_matches_content(self):
        before = [{"ID": 1, "COLOR": "Blue"}]
        after = [{"ID": 2, "COLOR": "Red"}]
        cfg = TableConfig(schema_name="S", table_name="T")

        delta = compute_table_delta(before, after, cfg, ReplayConfiguration())

        total = len(delta["inserts"]) + len(delta["deletes"]) + len(delta["updates"])
        assert delta["metadata"]["rows_affected"] == total


# ---------------------------------------------------------------------------
# select_strategy
# ---------------------------------------------------------------------------

class TestSelectStrategy:
    """Routes based on PK availability, row count, and column count."""

    @pytest.mark.parametrize("pk_cols, row_count, col_count, expected", [
        (["ID"], 0, 0, DeltaStrategy.PK_DIFF),
        (["ID"], 0, 5, DeltaStrategy.PK_DIFF),
        (["K1", "K2"], 0, 80, DeltaStrategy.PK_DIFF),
        ([], 0, 0, DeltaStrategy.FULL_SNAPSHOT),
        ([], 0, 5, DeltaStrategy.FULL_SNAPSHOT),
        ([], 0, 19, DeltaStrategy.FULL_SNAPSHOT),
        ([], 0, 20, DeltaStrategy.SYNTHETIC_KEY),
        ([], 0, 80, DeltaStrategy.SYNTHETIC_KEY),
        ([], 50_000, 80, DeltaStrategy.FULL_SNAPSHOT),
        ([], 99_999, 80, DeltaStrategy.FULL_SNAPSHOT),
        ([], 100_000, 80, DeltaStrategy.SYNTHETIC_KEY),
        ([], 500_000, 80, DeltaStrategy.SYNTHETIC_KEY),
    ], ids=[
        "pk_no_cols",
        "pk_narrow",
        "composite_pk_wide",
        "no_pk_no_cols",
        "no_pk_narrow",
        "no_pk_below_col_threshold",
        "no_pk_at_col_threshold",
        "no_pk_wide_unknown_rows",
        "no_pk_wide_small_table",
        "no_pk_wide_just_below_row_threshold",
        "no_pk_wide_at_row_threshold",
        "no_pk_wide_large_table",
    ])
    def test_strategy_selection(self, pk_cols, row_count, col_count, expected):
        cfg = TableConfig(
            schema_name="S", table_name="T",
            primary_key_columns=pk_cols,
            estimated_row_count=row_count,
        )

        strategy = select_strategy(
            cfg, ReplayConfiguration(), column_count=col_count,
        )

        assert strategy.name == expected

    def test_custom_column_threshold_respected(self):
        cfg = TableConfig(schema_name="S", table_name="T")
        replay_cfg = ReplayConfiguration(synthetic_key_column_threshold=50)

        assert select_strategy(
            cfg, replay_cfg, column_count=49,
        ).name == DeltaStrategy.FULL_SNAPSHOT
        assert select_strategy(
            cfg, replay_cfg, column_count=50,
        ).name == DeltaStrategy.SYNTHETIC_KEY

    def test_custom_small_table_threshold_respected(self):
        cfg = TableConfig(
            schema_name="S", table_name="T",
            estimated_row_count=500,
        )
        replay_cfg = ReplayConfiguration(small_table_threshold=1000)

        assert select_strategy(
            cfg, replay_cfg, column_count=80,
        ).name == DeltaStrategy.FULL_SNAPSHOT

        cfg_above = TableConfig(
            schema_name="S", table_name="T",
            estimated_row_count=1000,
        )
        assert select_strategy(
            cfg_above, replay_cfg, column_count=80,
        ).name == DeltaStrategy.SYNTHETIC_KEY
