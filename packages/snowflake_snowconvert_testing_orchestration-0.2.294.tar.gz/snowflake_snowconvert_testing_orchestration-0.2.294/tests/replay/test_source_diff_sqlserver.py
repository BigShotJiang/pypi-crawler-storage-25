"""Unit tests for ``replay.source_diff.sqlserver_diff.SqlServerDiffer``.

Tests follow the principles in ``test-runner/AGENTS.md``:

- No ``@patch`` of internal functions — only the cursor boundary is
  faked via ``_RecordingConnection`` (for SQL emission assertions) or
  ``_FakeConnection`` with FIFO cursors (for tests that need to
  reconstruct delta dicts from canned row data).
- Synth-PK correctness is verified by running ``SyntheticKeyStrategy``
  on the same fixture and asserting byte-identical output. This is the
  test that closes the gap from the killed Stage 1 no-PK validation.
- 3-part FQN requirement is asserted explicitly: every emitted SQL
  string must contain ``[database].[schema].[table]`` form for tables
  the differ touches.
"""

from __future__ import annotations

from typing import Any

import pytest

from test_runner.capture.sources.sqlserver import SqlServerExecutorFactory
from test_runner.capture.sources.redshift import RedshiftExecutorFactory
from test_runner.capture.sources.teradata import TeradataExecutorFactory
from test_runner.replay.models import DeltaStrategy, TableConfig, make_update_pair
from test_runner.replay.source_diff.sqlserver_diff import (
    DIFF_BEFORE_SUFFIX,
    SYNTH_DUP_SEQ_COL,
    SYNTH_KEY_COL,
    SqlServerDiffer,
    _drop_table_if_exists_sql,
    _qualified_name,
    _replace_is_distinct_from,
)
from test_runner.replay.source_introspector import SqlServerIntrospector
from test_runner.replay.strategies.synthetic_key import SyntheticKeyStrategy


# ---------------------------------------------------------------------------
# Fake DB boundary objects (mirrors the patterns in test_isolation.py
# and test_capture_handler_integration.py)
# ---------------------------------------------------------------------------

class _RecordingCursor:
    """Cursor that records every SQL string executed.

    Always returns an empty result set so the differ's per-query fetch
    completes without IndexError. SQL emission tests assert on
    ``executed_sql`` and don't care about row data.
    """

    description: list[tuple] = []

    def __init__(self, sql_log: list[str]):
        self._log = sql_log
        self._error: Exception | None = None

    def execute(self, sql: str) -> None:
        self._log.append(sql)
        if self._error:
            raise self._error

    def fetchall(self) -> list[tuple]:
        return []

    def close(self) -> None:
        pass


class _RecordingConnection:
    """Connection that tracks all SQL statements across cursors."""

    def __init__(self):
        self.executed_sql: list[str] = []
        self.next_cursor_error: Exception | None = None

    def cursor(self) -> _RecordingCursor:
        c = _RecordingCursor(self.executed_sql)
        if self.next_cursor_error is not None:
            c._error = self.next_cursor_error
            self.next_cursor_error = None
        return c

    def commit(self) -> None:
        pass


class _FetchCursor:
    """Cursor that returns canned ``description`` + rows on fetchall."""

    def __init__(self, description: list[tuple], rows: list[tuple]):
        self.description = description
        self._rows = rows
        self.executed: list[str] = []

    def execute(self, sql: str) -> None:
        self.executed.append(sql)

    def fetchall(self):
        return self._rows

    def close(self) -> None:
        pass


class _FetchConnection:
    """Returns pre-built ``_FetchCursor``s in FIFO order."""

    def __init__(self, cursors: list[_FetchCursor]):
        self._cursors = list(cursors)
        self._idx = 0

    def cursor(self) -> _FetchCursor:
        c = self._cursors[self._idx]
        self._idx += 1
        return c

    def commit(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Helpers used in multiple test classes
# ---------------------------------------------------------------------------

def _description(cols: list[str]) -> list[tuple]:
    """Build a minimal pyodbc-style ``cursor.description``."""
    return [(c, None, None, None, None, None, None) for c in cols]


# ---------------------------------------------------------------------------
# 1. SQL emission — assert exact strings (10 cases)
# ---------------------------------------------------------------------------

class TestSnapshotToDiffTableSql:

    def test_pk_case_emits_select_into_with_3_part_fqn(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.snapshot_to_diff_table(
            conn, database="MYDB", schema="dbo", table="ORDERS",
            all_columns=["ID", "CUSTOMER", "TOTAL"], has_pk=True,
        )
        assert conn.executed_sql == [
            "IF OBJECT_ID('MYDB.dbo.ORDERS__SCAI_DIFF_BEFORE', 'U') "
            "IS NOT NULL DROP TABLE [MYDB].[dbo].[ORDERS__SCAI_DIFF_BEFORE]",
            "SELECT * INTO [MYDB].[dbo].[ORDERS__SCAI_DIFF_BEFORE] "
            "FROM [MYDB].[dbo].[ORDERS]",
        ]

    def test_no_pk_case_projects_synth_key_and_dup_seq_inline(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.snapshot_to_diff_table(
            conn, database="MYDB", schema="dbo", table="EVENTS",
            all_columns=["A", "B"], has_pk=False,
        )
        # Drop comes first
        assert conn.executed_sql[0].startswith("IF OBJECT_ID(")
        # Snapshot statement contains both synth markers
        snapshot = conn.executed_sql[1]
        assert SYNTH_KEY_COL in snapshot
        assert SYNTH_DUP_SEQ_COL in snapshot
        assert "ROW_NUMBER() OVER" in snapshot
        assert "PARTITION BY" in snapshot
        assert "INTO [MYDB].[dbo].[EVENTS__SCAI_DIFF_BEFORE]" in snapshot
        assert "FROM [MYDB].[dbo].[EVENTS]" in snapshot

    def test_quotes_identifiers_with_special_chars(self):
        # Brackets in identifiers are unusual but possible. We only verify
        # the identifier reaches the SQL verbatim — sanitization is the
        # caller's responsibility.
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.snapshot_to_diff_table(
            conn, database="MY DB", schema="weird-schema", table="t.with.dots",
            all_columns=["X"], has_pk=True,
        )
        select_into = conn.executed_sql[1]
        assert "[MY DB]" in select_into
        assert "[weird-schema]" in select_into
        assert "[t.with.dots]" in select_into


class TestDiffWithPkSqlEmission:

    @pytest.mark.parametrize("pk_columns,non_pk_cols,expected_pk_predicates", [
        (["ID"], ["NAME", "QTY"], ["a.[ID] = b.[ID]"]),
        (["ID", "REGION"], ["NAME"],
         ["a.[ID] = b.[ID]", "a.[REGION] = b.[REGION]"]),
    ], ids=["single_pk", "composite_pk"])
    def test_anti_join_on_pk(self, pk_columns, non_pk_cols, expected_pk_predicates):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.diff_with_pk(
            conn,
            before_fqn="[DB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[DB].[dbo].[T]",
            pk_columns=pk_columns,
            all_columns=pk_columns + non_pk_cols,
        )
        # The first three statements are: inserts query, deletes query, updates query.
        inserts_sql = conn.executed_sql[0]
        deletes_sql = conn.executed_sql[1]
        for predicate in expected_pk_predicates:
            assert predicate in inserts_sql
            assert predicate in deletes_sql

    def test_updates_use_three_nullable_projections_per_non_pk_col(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.diff_with_pk(
            conn,
            before_fqn="[DB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[DB].[dbo].[T]",
            pk_columns=["ID"],
            all_columns=["ID", "NAME", "QTY"],
        )
        updates_sql = conn.executed_sql[2]
        for col in ("NAME", "QTY"):
            assert f"[{col}__B]" in updates_sql, f"{col}__B alias missing"
            assert f"[{col}__A]" in updates_sql, f"{col}__A alias missing"
            assert f"[{col}__U]" in updates_sql, f"{col}__U alias missing"

    def test_updates_hash_expression_byte_identical_to_introspector(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        non_pk = ["NAME", "QTY"]
        differ.diff_with_pk(
            conn,
            before_fqn="[DB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[DB].[dbo].[T]",
            pk_columns=["ID"],
            all_columns=["ID"] + non_pk,
        )
        # Reconstruct the introspector's hash expression and verify the
        # identifier-only form (the differ rewrites "col" -> alias.[col]).
        original = SqlServerIntrospector().hash_row_expression(non_pk)
        assert original is not None
        # The differ replaces "col" with b.[col] / a.[col]; verify both
        # alias rewrites are present.
        updates_sql = conn.executed_sql[2]
        assert "HASHBYTES('SHA2_256'" in updates_sql
        for col in non_pk:
            assert f'b.[{col}]' in updates_sql
            assert f'a.[{col}]' in updates_sql
        # PK column must NOT appear inside the HASHBYTES expression
        # (only non-PK columns should hash). Bound the slice to the part
        # between WHERE and the trailing ORDER BY so the slice doesn't
        # include the ORDER BY clause's reference to the PK column.
        where_start = updates_sql.find("WHERE ")
        order_start = updates_sql.find(" ORDER BY ")
        hash_clause = updates_sql[where_start:order_start]
        assert "b.[ID]" not in hash_clause
        assert "a.[ID]" not in hash_clause

    def test_is_distinct_from_is_rewritten_for_sql_server_pre_2022(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.diff_with_pk(
            conn,
            before_fqn="[DB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[DB].[dbo].[T]",
            pk_columns=["ID"],
            all_columns=["ID", "NAME"],
        )
        updates_sql = conn.executed_sql[2]
        # The literal phrase must NOT appear; the rewrite must.
        assert "IS DISTINCT FROM" not in updates_sql.upper()
        assert "IS NULL" in updates_sql
        assert "<>" in updates_sql

    def test_orders_results_by_pk(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.diff_with_pk(
            conn,
            before_fqn="[DB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[DB].[dbo].[T]",
            pk_columns=["ID"],
            all_columns=["ID", "NAME"],
        )
        for sql in conn.executed_sql:
            assert "ORDER BY" in sql, f"ORDER BY missing in: {sql[:80]}..."


class TestThreePartFqnEverywhere:
    """Per the plan's load-bearing requirement: every SQL emitted by the
    differ must use ``[database].[schema].[table]`` form. No bare
    ``[schema].[table]`` references."""

    def test_diff_with_pk_emits_only_3_part_fqns(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.diff_with_pk(
            conn,
            before_fqn="[MYDB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[MYDB].[dbo].[T]",
            pk_columns=["ID"],
            all_columns=["ID", "NAME"],
        )
        for sql in conn.executed_sql:
            assert "[MYDB].[dbo].[T]" in sql or "[MYDB].[dbo].[T__SCAI_DIFF_BEFORE]" in sql, (
                f"3-part FQN missing in: {sql[:200]}"
            )


class TestDiffWithSyntheticPkSqlEmission:

    def test_projects_synth_cols_inline_in_cte_on_live_table(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.diff_with_synthetic_pk(
            conn,
            before_fqn="[DB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[DB].[dbo].[T]",
            all_columns=["A", "B"],
        )
        joined = " | ".join(conn.executed_sql)
        assert "WITH after_keyed AS" in joined
        assert SYNTH_KEY_COL in joined
        assert SYNTH_DUP_SEQ_COL in joined
        assert "ROW_NUMBER() OVER" in joined
        assert "FROM [DB].[dbo].[T]" in joined


class TestDropDiffTableSql:

    def test_emits_if_object_id_then_drop_with_3_part_name(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        differ.drop_diff_table(conn, "[MYDB].[dbo].[ORDERS__SCAI_DIFF_BEFORE]")
        assert conn.executed_sql == [
            "IF OBJECT_ID('MYDB.dbo.ORDERS__SCAI_DIFF_BEFORE', 'U') "
            "IS NOT NULL DROP TABLE [MYDB].[dbo].[ORDERS__SCAI_DIFF_BEFORE]",
        ]


# ---------------------------------------------------------------------------
# 2. Python reconstruction — Variant B's three-projection decoding (5 cases)
# ---------------------------------------------------------------------------

class TestVariantBReconstruction:
    """Verify that the Python side correctly reconstructs full ``before`` /
    ``after`` dicts from the three nullable projections per non-PK column.
    """

    def _run_diff(
        self,
        update_rows: list[tuple],
        all_columns: list[str],
        pk_columns: list[str],
    ) -> dict[str, Any]:
        """Run ``diff_with_pk`` with empty inserts/deletes and the given
        update_rows, returning the resulting ``updates`` list.
        """
        differ = SqlServerDiffer()
        non_pk = [c for c in all_columns if c not in pk_columns]
        update_desc_cols: list[str] = list(pk_columns)
        for c in non_pk:
            update_desc_cols.extend([f"{c}__B", f"{c}__A", f"{c}__U"])

        cursors = [
            _FetchCursor(_description(all_columns), []),       # inserts
            _FetchCursor(_description(all_columns), []),       # deletes
            _FetchCursor(_description(update_desc_cols), update_rows),  # updates
        ]
        conn = _FetchConnection(cursors)
        ins, dels, updates = differ.diff_with_pk(
            conn,
            before_fqn="[DB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[DB].[dbo].[T]",
            pk_columns=pk_columns,
            all_columns=all_columns,
        )
        return {"inserts": ins, "deletes": dels, "updates": updates}

    def test_one_changed_col_populates_before_after_separately(self):
        # Schema: ID, NAME, QTY. Update row: ID=1, NAME changed
        # (b='Alice', a='Bob'), QTY unchanged ('U' value = 42).
        # Projection columns: [ID, NAME__B, NAME__A, NAME__U, QTY__B, QTY__A, QTY__U]
        result = self._run_diff(
            update_rows=[(1, "Alice", "Bob", None, None, None, 42)],
            all_columns=["ID", "NAME", "QTY"],
            pk_columns=["ID"],
        )
        assert len(result["updates"]) == 1
        upd = result["updates"][0]
        assert upd["key"] == {"ID": 1}
        assert upd["before"] == {"ID": 1, "NAME": "Alice", "QTY": 42}
        assert upd["after"] == {"ID": 1, "NAME": "Bob", "QTY": 42}
        assert upd["changed_columns"] == ["NAME"]

    def test_all_changed_cols_no_unchanged_field_set(self):
        # All non-PK cols changed. col__U should be NULL for each, and
        # changed_columns should list all of them.
        result = self._run_diff(
            update_rows=[(1, "Alice", "Bob", None, 10, 20, None)],
            all_columns=["ID", "NAME", "QTY"],
            pk_columns=["ID"],
        )
        upd = result["updates"][0]
        assert upd["before"] == {"ID": 1, "NAME": "Alice", "QTY": 10}
        assert upd["after"] == {"ID": 1, "NAME": "Bob", "QTY": 20}
        assert set(upd["changed_columns"]) == {"NAME", "QTY"}

    def test_unchanged_cols_use_single_value_for_both_before_and_after(self):
        # A row where 1 of 3 cols changed, the other 2 unchanged. Both
        # unchanged values appear once in __U projection and must be
        # written to BOTH before[col] and after[col] in the dict.
        result = self._run_diff(
            update_rows=[(
                1,
                "Alice", "Bob", None,         # NAME changed
                None, None, 42,               # QTY unchanged, __U = 42
                None, None, 3.14,             # PRICE unchanged, __U = 3.14
            )],
            all_columns=["ID", "NAME", "QTY", "PRICE"],
            pk_columns=["ID"],
        )
        upd = result["updates"][0]
        assert upd["before"]["QTY"] == 42
        assert upd["after"]["QTY"] == 42
        assert upd["before"]["PRICE"] == 3.14
        assert upd["after"]["PRICE"] == 3.14
        assert upd["changed_columns"] == ["NAME"]

    def test_unchanged_null_value_not_marked_as_changed(self):
        # Regression: when an unchanged column's value is NULL, all three
        # projections (col__B, col__A, col__U) are NULL. The reconstructor
        # must still classify the column as unchanged — checking only
        # col__U for non-NULL would falsely mark it as changed.
        # Schema: ID, NAME, QTY. NAME changed Alice -> Bob; QTY unchanged
        # with value NULL.
        result = self._run_diff(
            update_rows=[(1, "Alice", "Bob", None,  None, None, None)],
            all_columns=["ID", "NAME", "QTY"],
            pk_columns=["ID"],
        )
        upd = result["updates"][0]
        assert upd["before"] == {"ID": 1, "NAME": "Alice", "QTY": None}
        assert upd["after"] == {"ID": 1, "NAME": "Bob", "QTY": None}
        assert upd["changed_columns"] == ["NAME"]

    def test_key_equals_pk_subset_of_after(self):
        result = self._run_diff(
            update_rows=[(7, 99, "Alice", "Bob", None)],
            all_columns=["ID", "REGION", "NAME"],
            pk_columns=["ID", "REGION"],
        )
        upd = result["updates"][0]
        assert upd["key"] == {"ID": 7, "REGION": 99}
        assert upd["after"]["ID"] == upd["key"]["ID"]
        assert upd["after"]["REGION"] == upd["key"]["REGION"]

    def test_no_updates_returns_empty_list(self):
        # Updates query returns zero rows.
        result = self._run_diff(
            update_rows=[],
            all_columns=["ID", "NAME"],
            pk_columns=["ID"],
        )
        assert result["updates"] == []
        assert result["inserts"] == []
        assert result["deletes"] == []


# ---------------------------------------------------------------------------
# 3. Synth-PK correctness (6 cases) — closes the Stage 1 gap
# ---------------------------------------------------------------------------

class TestSyntheticPkCorrectness:
    """Verify ``diff_with_synthetic_pk`` matches production
    ``SyntheticKeyStrategy`` byte-for-byte on shared inputs.

    Strategy: generate a small fixture, run ``SyntheticKeyStrategy`` to
    get the baseline, then simulate the differ's server-side behavior
    (the differ's anti-join on synth_key + dup_seq is what
    SyntheticKeyStrategy does in DuckDB) by feeding the differ canned
    inserts/deletes that ``SyntheticKeyStrategy`` would have computed,
    then asserting the differ's call to ``_infer_updates_from_pairs``
    produces the same updates list.
    """

    def _build_fetch_conn(
        self,
        all_columns: list[str],
        ins_rows: list[tuple],
        del_rows: list[tuple],
    ) -> _FetchConnection:
        synth_cols = list(all_columns) + [SYNTH_KEY_COL, SYNTH_DUP_SEQ_COL]
        # Each canned row has all_columns + dummy synth columns.
        # The differ strips synth cols; synth values don't matter.
        ins_padded = [r + (b"hash", 1) for r in ins_rows]
        del_padded = [r + (b"hash", 1) for r in del_rows]
        return _FetchConnection([
            _FetchCursor(_description(synth_cols), ins_padded),
            _FetchCursor(_description(synth_cols), del_padded),
        ])

    def test_synth_pk_output_equals_synthetic_key_strategy(self):
        # Fixture: 5-col rows. Some unchanged, some changed (= delete+insert
        # pair that should be inferred as update).
        cols = ["A", "B", "C", "D", "E"]
        before_rows = [
            {"A": 1, "B": 2, "C": 3, "D": 4, "E": 5},   # unchanged
            {"A": 10, "B": 20, "C": 30, "D": 40, "E": 50},  # will be updated
            {"A": 100, "B": 200, "C": 300, "D": 400, "E": 500},  # will be deleted
        ]
        after_rows = [
            {"A": 1, "B": 2, "C": 3, "D": 4, "E": 5},   # unchanged
            {"A": 10, "B": 20, "C": 30, "D": 40, "E": 999},  # E changed
            {"A": 999, "B": 999, "C": 999, "D": 999, "E": 999},  # net new insert
        ]
        # Run production SyntheticKeyStrategy as the source of truth.
        baseline_delta = SyntheticKeyStrategy().compute_delta(
            before_rows, after_rows,
            TableConfig(schema_name="dbo", table_name="T"),
        )

        # Now feed the differ canned (insert, delete) lists that match what
        # the server-side anti-join would have returned. The differ strips
        # synth cols and calls _infer_updates_from_pairs internally; the
        # final updates list should equal the baseline.
        differ = SqlServerDiffer()
        diff_ins_tuples = [tuple(r.values()) for r in baseline_delta["inserts"]]
        diff_del_tuples = [tuple(r.values()) for r in baseline_delta["deletes"]]
        # Add the would-be-update rows that the server-side anti-join would
        # have returned (they appear in both inserts and deletes from the
        # anti-join's perspective; _infer_updates_from_pairs promotes them).
        for upd in baseline_delta.get("updates", []):
            diff_ins_tuples.append(tuple(upd["after"][c] for c in cols))
            diff_del_tuples.append(tuple(upd["before"][c] for c in cols))

        conn = self._build_fetch_conn(cols, diff_ins_tuples, diff_del_tuples)
        final_inserts, final_deletes, final_updates = differ.diff_with_synthetic_pk(
            conn,
            before_fqn="[DB].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[DB].[dbo].[T]",
            all_columns=cols,
        )

        # Compare against baseline. Sort both sides for stable comparison.
        def _sort_rows(rows):
            return sorted(rows, key=lambda r: tuple(sorted(r.items())))

        assert _sort_rows(final_inserts) == _sort_rows(baseline_delta["inserts"])
        assert _sort_rows(final_deletes) == _sort_rows(baseline_delta["deletes"])
        assert len(final_updates) == len(baseline_delta.get("updates", []))

    def test_synth_cols_stripped_from_output_rows(self):
        differ = SqlServerDiffer()
        conn = self._build_fetch_conn(
            all_columns=["X"],
            ins_rows=[(1,)],
            del_rows=[(2,)],
        )
        inserts, deletes, _ = differ.diff_with_synthetic_pk(
            conn, before_fqn="[D].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[D].[dbo].[T]", all_columns=["X"],
        )
        for row in inserts + deletes:
            assert SYNTH_KEY_COL not in row
            assert SYNTH_DUP_SEQ_COL not in row

    def test_empty_inputs_return_empty_lists(self):
        differ = SqlServerDiffer()
        conn = self._build_fetch_conn(["X"], [], [])
        inserts, deletes, updates = differ.diff_with_synthetic_pk(
            conn, before_fqn="[D].[dbo].[T__SCAI_DIFF_BEFORE]",
            after_fqn="[D].[dbo].[T]", all_columns=["X"],
        )
        assert inserts == []
        assert deletes == []
        assert updates == []


# ---------------------------------------------------------------------------
# 4. Error paths (3 cases)
# ---------------------------------------------------------------------------

class TestErrorPaths:

    def test_diff_with_pk_raises_on_empty_pk_columns(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        with pytest.raises(ValueError, match="diff_with_pk requires at least one PK column"):
            differ.diff_with_pk(
                conn,
                before_fqn="[D].[dbo].[T__SCAI_DIFF_BEFORE]",
                after_fqn="[D].[dbo].[T]",
                pk_columns=[],
                all_columns=["NAME"],
            )
        # No SQL should have been emitted before the validation error.
        assert conn.executed_sql == []

    def test_diff_with_synthetic_pk_raises_on_empty_columns(self):
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        with pytest.raises(ValueError, match="requires at least one column"):
            differ.diff_with_synthetic_pk(
                conn, before_fqn="[D].[dbo].[T__SCAI_DIFF_BEFORE]",
                after_fqn="[D].[dbo].[T]", all_columns=[],
            )
        assert conn.executed_sql == []

    def test_drop_diff_table_propagates_cursor_errors(self):
        # Cursor errors should propagate. (DROP IF EXISTS itself doesn't
        # raise on missing table at the SQL Server level — that's the
        # OBJECT_ID guard's job; if pyodbc raises something else we want
        # to know about it.)
        differ = SqlServerDiffer()
        conn = _RecordingConnection()
        conn.next_cursor_error = RuntimeError("connection closed")
        with pytest.raises(RuntimeError, match="connection closed"):
            differ.drop_diff_table(conn, "[D].[dbo].[T__SCAI_DIFF_BEFORE]")


# ---------------------------------------------------------------------------
# 5. Factory wiring (3 cases)
# ---------------------------------------------------------------------------

class TestFactoryWiring:

    def test_sqlserver_factory_returns_sqlserver_differ(self):
        factory = SqlServerExecutorFactory()
        differ = factory.create_source_differ()
        assert isinstance(differ, SqlServerDiffer)

    @pytest.mark.parametrize("factory_cls", [
        RedshiftExecutorFactory,
        TeradataExecutorFactory,
    ], ids=["redshift", "teradata"])
    def test_other_dialects_return_none(self, factory_cls):
        factory = factory_cls()
        assert factory.create_source_differ() is None


# ---------------------------------------------------------------------------
# 6. diff() contract (2 cases — dispatch + delta dict shape)
# ---------------------------------------------------------------------------

class TestDiffContract:
    """Exercise ``diff()`` itself: dispatch + returned delta dict shape."""

    def _build_conn(self, all_columns, pk_columns):
        if pk_columns:
            non_pk = [c for c in all_columns if c not in pk_columns]
            update_desc = list(pk_columns) + [
                f"{c}{s}" for c in non_pk for s in ("__B", "__A", "__U")
            ]
            return _FetchConnection([
                _FetchCursor(_description(all_columns), []),
                _FetchCursor(_description(all_columns), []),
                _FetchCursor(_description(update_desc), []),
            ])
        synth_desc = list(all_columns) + [SYNTH_KEY_COL, SYNTH_DUP_SEQ_COL]
        return _FetchConnection([
            _FetchCursor(_description(synth_desc), []),
            _FetchCursor(_description(synth_desc), []),
        ])

    @pytest.mark.parametrize("pk_columns,all_columns,table_name,expected_strategy", [
        (["ID"], ["ID", "NAME"], "ORDERS", DeltaStrategy.PK_DIFF.value),
        ([],     ["A", "B"],     "EVENTS", DeltaStrategy.SYNTHETIC_KEY.value),
    ], ids=["pk_table", "no_pk_table"])
    def test_diff_returns_strategy_and_fqn(
        self, pk_columns, all_columns, table_name, expected_strategy,
    ):
        differ = SqlServerDiffer()
        table_cfg = TableConfig(
            schema_name="dbo", table_name=table_name,
            primary_key_columns=pk_columns,
        )
        conn = self._build_conn(all_columns, pk_columns)

        result = differ.diff(
            conn, table_cfg, database="MYDB", all_columns=all_columns,
        )

        assert result["strategy_used"] == expected_strategy
        assert result["table"] == table_cfg.fqn
        assert result["inserts"] == []
        assert result["deletes"] == []
        assert result["updates"] == []


# ---------------------------------------------------------------------------
# 7. Module-level helpers (smoke checks not duplicated above)
# ---------------------------------------------------------------------------

class TestHelperFunctions:

    def test_qualified_name_brackets_all_three_parts(self):
        assert _qualified_name("DB", "dbo", "T") == "[DB].[dbo].[T]"

    def test_drop_table_if_exists_uses_unquoted_form_in_object_id(self):
        sql = _drop_table_if_exists_sql("[MYDB].[dbo].[ORDERS]")
        assert "OBJECT_ID('MYDB.dbo.ORDERS', 'U')" in sql
        assert "DROP TABLE [MYDB].[dbo].[ORDERS]" in sql

    def test_drop_table_if_exists_escapes_single_quotes_in_identifier(self):
        sql = _drop_table_if_exists_sql("[MYDB].[dbo].[O'BRIEN_LOG]")
        assert "OBJECT_ID('MYDB.dbo.O''BRIEN_LOG', 'U')" in sql
        assert "DROP TABLE [MYDB].[dbo].[O'BRIEN_LOG]" in sql

    def test_replace_is_distinct_from_rewrite(self):
        rewritten = _replace_is_distinct_from(
            "SELECT * FROM t WHERE a.[X] IS DISTINCT FROM b.[X]"
        )
        assert "IS DISTINCT FROM" not in rewritten.upper()
        # Both sides of the rewrite expression must mention both columns.
        assert "a.[X] <> b.[X]" in rewritten
        assert "a.[X] IS NULL" in rewritten
        assert "b.[X] IS NULL" in rewritten

    def test_replace_is_distinct_from_idempotent(self):
        original = "WHERE a.[X] IS DISTINCT FROM b.[X]"
        once = _replace_is_distinct_from(original)
        twice = _replace_is_distinct_from(once)
        assert once == twice
