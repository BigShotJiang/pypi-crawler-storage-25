"""Tests for replay.isolation — isolation providers."""

from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal
from unittest.mock import MagicMock

import pytest

from test_runner.replay.isolation.isolation import IsolationProvider
from test_runner.replay.isolation.transaction import (
    RedshiftTransactionIsolation,
    SqlServerTransactionIsolation,
)
from test_runner.replay.isolation.backup import (
    BackupRestoreIsolation,
    SqlServerBackupRestoreIsolation,
    RedshiftBackupRestoreIsolation,
    TeradataBackupRestoreIsolation,
)
from test_runner.replay.isolation.delta_undo import (
    DeltaUndoIsolation,
    _format_sql_value,
)
from test_runner.replay.isolation.composite import CompositeIsolation
from test_runner.replay.isolation.clone import SnowflakeCloneIsolation
from test_runner.replay.isolation.snapshot import (
    SqlServerSnapshotIsolation,
    _snapshot_file_path,
)
from test_runner.replay.isolation.factory import (
    SqlServerIsolationFactory,
    RedshiftIsolationFactory,
    TeradataIsolationFactory,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_connection(autocommit: bool | None = None) -> MagicMock:
    conn = MagicMock()
    if autocommit is not None:
        conn.autocommit = autocommit
    else:
        del conn.autocommit
    return conn


# ---------------------------------------------------------------------------
# SqlServerTransactionIsolation
# ---------------------------------------------------------------------------

class TestSqlServerTransactionIsolation:

    def test_setup_begins_transaction_and_forces_autocommit_true(self):
        conn = _mock_connection(autocommit=False)
        iso = SqlServerTransactionIsolation()
        iso.setup(conn)

        assert conn.autocommit is True
        conn.cursor().execute.assert_called_once_with("BEGIN TRANSACTION")

    def test_teardown_issues_rollback_and_restores_autocommit(self):
        conn = _mock_connection(autocommit=False)
        iso = SqlServerTransactionIsolation()
        iso.setup(conn)

        iso.teardown(conn)

        conn.cursor().execute.assert_called_with("ROLLBACK")
        assert conn.autocommit is False

    def test_teardown_noop_when_not_active(self):
        conn = _mock_connection(autocommit=False)
        iso = SqlServerTransactionIsolation()

        iso.teardown(conn)
        conn.cursor().execute.assert_not_called()

    def test_cleanup_delegates_to_teardown(self):
        conn = _mock_connection(autocommit=False)
        iso = SqlServerTransactionIsolation()
        iso.setup(conn)

        iso.cleanup(conn)

        conn.cursor().execute.assert_called_with("ROLLBACK")

    def test_setup_without_autocommit_attr(self):
        conn = _mock_connection(autocommit=None)
        iso = SqlServerTransactionIsolation()
        iso.setup(conn)
        conn.cursor().execute.assert_called_once_with("BEGIN TRANSACTION")


# ---------------------------------------------------------------------------
# RedshiftTransactionIsolation
# ---------------------------------------------------------------------------

class TestRedshiftTransactionIsolation:

    def test_setup_begins_and_forces_autocommit_false(self):
        conn = _mock_connection(autocommit=True)
        iso = RedshiftTransactionIsolation()
        iso.setup(conn)

        assert conn.autocommit is False
        conn.cursor().execute.assert_called_once_with("BEGIN")

    def test_teardown_issues_rollback_and_restores_autocommit(self):
        conn = _mock_connection(autocommit=True)
        iso = RedshiftTransactionIsolation()
        iso.setup(conn)

        iso.teardown(conn)

        conn.cursor().execute.assert_called_with("ROLLBACK")
        assert conn.autocommit is True

    def test_teardown_noop_when_not_active(self):
        conn = _mock_connection(autocommit=True)
        iso = RedshiftTransactionIsolation()

        iso.teardown(conn)
        conn.cursor().execute.assert_not_called()

    def test_cleanup_delegates_to_teardown(self):
        conn = _mock_connection(autocommit=True)
        iso = RedshiftTransactionIsolation()
        iso.setup(conn)

        iso.cleanup(conn)

        conn.cursor().execute.assert_called_with("ROLLBACK")

    def test_setup_without_autocommit_attr_raises(self):
        conn = _mock_connection(autocommit=None)
        iso = RedshiftTransactionIsolation()
        with pytest.raises(RuntimeError, match="autocommit"):
            iso.setup(conn)


# ---------------------------------------------------------------------------
# SnowflakeCloneIsolation
# ---------------------------------------------------------------------------

class _RecordingCursor:
    """Cursor that records executed SQL into a shared log."""

    def __init__(self, sql_log: list[str]):
        self._log = sql_log
        self._error: Exception | None = None

    def execute(self, sql: str) -> None:
        if self._error:
            raise self._error
        self._log.append(sql)

    def close(self) -> None:
        pass


class _RecordingConnection:
    """Connection that tracks all SQL statements across cursors.

    Set *next_cursor_error* to make the next ``cursor()`` call return
    a cursor that raises on ``execute()``, without monkey-patching.
    """

    def __init__(self):
        self.executed_sql: list[str] = []
        self.next_cursor_error: Exception | None = None

    def cursor(self) -> _RecordingCursor:
        c = _RecordingCursor(self.executed_sql)
        if self.next_cursor_error is not None:
            c._error = self.next_cursor_error
            self.next_cursor_error = None
        return c

    def commit(self) -> None:
        pass


class TestSnowflakeCloneIsolation:

    @pytest.mark.parametrize("source, procedure, params_hash, expected", [
        ("MYDB", "dbo.MyProc", "abc123", "MYDB_REPLAY_DBO_MYPROC_ABC123"),
        ("MYDB", "", "", "MYDB_REPLAY"),
        ("DB", "dbo.MyProc", "abc", "DB_REPLAY_DBO_MYPROC_ABC"),
        ("DB", "schema with spaces.Proc", "", "DB_REPLAY_SCHEMA_WITH_SPACES_PROC"),
    ], ids=["full_format", "bare_no_proc", "dots_and_hash", "spaces_no_hash"])
    def test_clone_database_naming(self, source, procedure, params_hash, expected):
        iso = SnowflakeCloneIsolation(
            source_database=source,
            procedure=procedure,
            params_hash=params_hash,
        )

        assert iso.clone_database == expected

    def test_setup_creates_clone_and_restores_original_db(self):
        """setup() issues CREATE CLONE then USE to restore original DB."""
        conn = _RecordingConnection()
        iso = SnowflakeCloneIsolation(
            source_database="PROD", procedure="dbo.P", params_hash="x",
        )

        iso.setup(conn)

        assert conn.executed_sql == [
            f"CREATE OR REPLACE DATABASE {iso.clone_database} CLONE PROD",
            "USE DATABASE PROD",
        ]

    def test_teardown_drops_clone_after_setup(self):
        """teardown() drops the clone database."""
        conn = _RecordingConnection()
        iso = SnowflakeCloneIsolation(source_database="PROD")
        iso.setup(conn)
        conn.executed_sql.clear()

        iso.teardown(conn)

        assert conn.executed_sql == [
            f"DROP DATABASE IF EXISTS {iso.clone_database}",
        ]

    def test_teardown_noop_when_not_created(self):
        """teardown() before setup() issues no SQL."""
        conn = _RecordingConnection()
        iso = SnowflakeCloneIsolation(source_database="PROD")

        iso.teardown(conn)

        assert conn.executed_sql == []

    def test_revert_tables_clones_individual_tables(self):
        """revert_tables() re-clones each listed table from source."""
        conn = _RecordingConnection()
        iso = SnowflakeCloneIsolation(source_database="PROD")
        iso.setup(conn)
        conn.executed_sql.clear()

        iso.revert_tables(conn, ["WAREHOUSE.COLORS", "DBO.ORDERS"])

        clone = iso.clone_database
        assert conn.executed_sql == [
            f"CREATE OR REPLACE TABLE {clone}.WAREHOUSE.COLORS CLONE PROD.WAREHOUSE.COLORS",
            f"CREATE OR REPLACE TABLE {clone}.DBO.ORDERS CLONE PROD.DBO.ORDERS",
        ]

    def test_revert_tables_noop_when_empty_list(self):
        """revert_tables([]) issues no SQL."""
        conn = _RecordingConnection()
        iso = SnowflakeCloneIsolation(source_database="PROD")
        iso.setup(conn)
        conn.executed_sql.clear()

        iso.revert_tables(conn, [])

        assert conn.executed_sql == []

    def test_revert_tables_noop_when_not_created(self):
        """revert_tables() before setup() issues no SQL."""
        conn = _RecordingConnection()
        iso = SnowflakeCloneIsolation(source_database="PROD")

        iso.revert_tables(conn, ["WAREHOUSE.COLORS"])

        assert conn.executed_sql == []

    def test_revert_tables_failure_reraises(self):
        """Inner cursor error during revert is re-raised."""
        conn = _RecordingConnection()
        iso = SnowflakeCloneIsolation(source_database="PROD")
        iso.setup(conn)

        conn.next_cursor_error = RuntimeError("permission denied")

        with pytest.raises(RuntimeError, match="permission denied"):
            iso.revert_tables(conn, ["S.T"])

    def test_cleanup_always_drops_even_without_setup(self):
        """cleanup() drops the clone regardless of _created state."""
        conn = _RecordingConnection()
        iso = SnowflakeCloneIsolation(source_database="PROD")

        iso.cleanup(conn)

        assert conn.executed_sql == [
            f"DROP DATABASE IF EXISTS {iso.clone_database}",
        ]


# ---------------------------------------------------------------------------
# BackupRestoreIsolation
# ---------------------------------------------------------------------------

def _make_table_config(schema, table, pk_columns=None):
    from test_runner.replay.models import TableConfig
    return TableConfig(schema_name=schema, table_name=table, primary_key_columns=pk_columns or [])


class TestBackupRestoreIsolation:

    @pytest.mark.parametrize("cls, expected_sql", [
        (SqlServerBackupRestoreIsolation, 'SELECT * INTO "s"."t__SCAI_BKP" FROM "s"."t"'),
        (RedshiftBackupRestoreIsolation, 'CREATE TABLE "s"."t__SCAI_BKP" AS SELECT * FROM "s"."t"'),
        (TeradataBackupRestoreIsolation, 'CREATE TABLE "s"."t__SCAI_BKP" AS (SELECT * FROM "s"."t") WITH DATA'),
    ], ids=["sqlserver", "redshift", "teradata"])
    def test_setup_creates_backup_with_dialect_sql(self, cls, expected_sql):
        conn = _RecordingConnection()
        iso = cls()
        tc = _make_table_config("s", "t")
        iso.setup(conn, [tc])

        assert expected_sql in conn.executed_sql

    @pytest.mark.parametrize("cls", [
        SqlServerBackupRestoreIsolation,
        RedshiftBackupRestoreIsolation,
    ], ids=["sqlserver", "redshift"])
    def test_setup_drops_stale_backup_before_create(self, cls):
        conn = _RecordingConnection()
        iso = cls()
        tc = _make_table_config("s", "t")
        iso.setup(conn, [tc])

        assert 'DROP TABLE IF EXISTS "s"."t__SCAI_BKP"' in conn.executed_sql
        drop_idx = conn.executed_sql.index('DROP TABLE IF EXISTS "s"."t__SCAI_BKP"')
        create_idx = next(i for i, sql in enumerate(conn.executed_sql) if "SELECT" in sql and "t__SCAI_BKP" in sql)
        assert drop_idx < create_idx

    def test_teradata_drops_without_if_exists(self):
        conn = _RecordingConnection()
        iso = TeradataBackupRestoreIsolation()
        tc = _make_table_config("s", "t")
        iso.setup(conn, [tc])

        assert 'DROP TABLE "s"."t__SCAI_BKP"' in conn.executed_sql
        assert not any("IF EXISTS" in sql for sql in conn.executed_sql)

    def test_teardown_restores_from_backup(self):
        conn = _RecordingConnection()
        iso = SqlServerBackupRestoreIsolation()
        tc = _make_table_config("s", "t")
        iso.setup(conn, [tc])
        conn.executed_sql.clear()

        iso.teardown(conn)

        assert conn.executed_sql == [
            'DELETE FROM "s"."t"',
            'INSERT INTO "s"."t" SELECT * FROM "s"."t__SCAI_BKP"',
            'DROP TABLE "s"."t__SCAI_BKP"',
        ]

    def test_teardown_noop_when_no_backups(self):
        conn = _RecordingConnection()
        iso = SqlServerBackupRestoreIsolation()

        iso.teardown(conn)

        assert conn.executed_sql == []

    def test_cleanup_drops_backup_tables(self):
        conn = _RecordingConnection()
        iso = RedshiftBackupRestoreIsolation()
        tc = _make_table_config("s", "t")
        iso.setup(conn, [tc])
        conn.executed_sql.clear()

        iso.cleanup(conn)

        assert 'DROP TABLE IF EXISTS "s"."t__SCAI_BKP"' in conn.executed_sql

    def test_setup_without_table_configs_is_noop(self):
        conn = _RecordingConnection()
        iso = SqlServerBackupRestoreIsolation()

        iso.setup(conn)

        assert conn.executed_sql == []

    def test_multiple_tables_backed_up(self):
        conn = _RecordingConnection()
        iso = RedshiftBackupRestoreIsolation()
        configs = [_make_table_config("s", "a"), _make_table_config("s", "b")]
        iso.setup(conn, configs)

        backup_sqls = [sql for sql in conn.executed_sql if "AS SELECT" in sql]
        assert len(backup_sqls) == 2


# ---------------------------------------------------------------------------
# TeradataBackupRestoreIsolation
# ---------------------------------------------------------------------------

class TestTeradataBackupRestoreIsolation:

    def test_setup_forces_autocommit_true(self):
        conn = _RecordingConnection()
        conn.autocommit = False
        iso = TeradataBackupRestoreIsolation()

        iso.setup(conn)

        assert conn.autocommit is True

    def test_setup_preserves_autocommit_when_already_true(self):
        conn = _RecordingConnection()
        conn.autocommit = True
        iso = TeradataBackupRestoreIsolation()

        iso.setup(conn)

        assert conn.autocommit is True


# ---------------------------------------------------------------------------
# DeltaUndoIsolation
# ---------------------------------------------------------------------------

class TestDeltaUndoIsolation:

    def test_setup_is_noop(self):
        conn = _RecordingConnection()
        iso = DeltaUndoIsolation()

        iso.setup(conn, [_make_table_config("s", "t", ["id"])])

        assert conn.executed_sql == []

    def test_teardown_reverses_inserts_via_delete(self):
        conn = _RecordingConnection()
        iso = DeltaUndoIsolation()
        tc = _make_table_config("s", "orders", ["ORDER_ID"])
        deltas = {"s.orders": {"inserts": [{"ORDER_ID": 6, "NAME": "X"}], "deletes": [], "updates": []}}

        iso.teardown(conn, deltas=deltas, table_configs=[tc])

        assert any("DELETE FROM" in sql and "ORDER_ID = 6" in sql for sql in conn.executed_sql)

    def test_teardown_reverses_deletes_via_insert(self):
        conn = _RecordingConnection()
        iso = DeltaUndoIsolation()
        tc = _make_table_config("s", "orders", ["ORDER_ID"])
        deltas = {"s.orders": {"inserts": [], "deletes": [{"ORDER_ID": 3, "NAME": "Y"}], "updates": []}}

        iso.teardown(conn, deltas=deltas, table_configs=[tc])

        assert any("INSERT INTO" in sql and "'Y'" in sql for sql in conn.executed_sql)

    def test_teardown_reverses_updates(self):
        conn = _RecordingConnection()
        iso = DeltaUndoIsolation()
        tc = _make_table_config("s", "orders", ["ORDER_ID"])
        deltas = {"s.orders": {
            "inserts": [], "deletes": [],
            "updates": [{"key": {"ORDER_ID": 1}, "before": {"ORDER_ID": 1, "NAME": "Old"}, "after": {"ORDER_ID": 1, "NAME": "New"}, "changed_columns": ["NAME"]}],
        }}

        iso.teardown(conn, deltas=deltas, table_configs=[tc])

        assert any("UPDATE" in sql and "NAME = 'Old'" in sql and "ORDER_ID = 1" in sql for sql in conn.executed_sql)

    def test_teardown_noop_when_no_deltas(self):
        conn = _RecordingConnection()
        iso = DeltaUndoIsolation()

        iso.teardown(conn, deltas=None, table_configs=None)

        assert conn.executed_sql == []

    def test_teardown_skips_tables_without_pk(self):
        conn = _RecordingConnection()
        iso = DeltaUndoIsolation()
        tc = _make_table_config("s", "logs")
        deltas = {"s.logs": {"inserts": [{"MSG": "hello"}], "deletes": [], "updates": []}}

        iso.teardown(conn, deltas=deltas, table_configs=[tc])

        assert conn.executed_sql == []

    def test_cleanup_is_noop(self):
        conn = _RecordingConnection()
        iso = DeltaUndoIsolation()

        iso.cleanup(conn)

        assert conn.executed_sql == []


# ---------------------------------------------------------------------------
# _format_sql_value
# ---------------------------------------------------------------------------

class TestFormatSqlValue:

    @pytest.mark.parametrize("value, expected", [
        (None, "NULL"),
        (True, "1"),
        (False, "0"),
        (42, "42"),
        (3.14, "3.14"),
        (Decimal("10.50"), "10.50"),
        (Decimal("0"), "0"),
        ("hello", "'hello'"),
        ("it's", "'it''s'"),
        (datetime(2024, 1, 15, 12, 30, 45), "'2024-01-15T12:30:45'"),
        (date(2024, 1, 15), "'2024-01-15'"),
        (time(12, 30, 45), "'12:30:45'"),
    ], ids=[
        "none", "bool_true", "bool_false",
        "int", "float",
        "decimal", "decimal_zero",
        "string", "string_with_quote",
        "datetime", "date", "time",
    ])
    def test_supported_types(self, value, expected):
        assert _format_sql_value(value) == expected

    def test_bytes_raises_type_error(self):
        with pytest.raises(TypeError, match="Cannot format bytes"):
            _format_sql_value(b"\x01\x02")


# ---------------------------------------------------------------------------
# IsolationProvider contract
# ---------------------------------------------------------------------------

class TestIsolationProviderContract:

    @pytest.mark.parametrize("cls", [
        SqlServerTransactionIsolation,
        RedshiftTransactionIsolation,
        SnowflakeCloneIsolation,
        SqlServerBackupRestoreIsolation,
        RedshiftBackupRestoreIsolation,
        TeradataBackupRestoreIsolation,
        DeltaUndoIsolation,
        CompositeIsolation,
        SqlServerSnapshotIsolation,
    ], ids=lambda c: c.__name__)
    def test_is_isolation_provider(self, cls):
        assert issubclass(cls, IsolationProvider)


# ---------------------------------------------------------------------------
# SqlServerSnapshotIsolation
# ---------------------------------------------------------------------------

class _SnapshotCursor:
    """Cursor that records SQL and returns canned data for snapshot queries."""

    def __init__(self, sql_log: list[str], db_name: str, data_files: list):
        self._log = sql_log
        self._db_name = db_name
        self._data_files = data_files
        self._last_sql = ""

    def execute(self, sql: str) -> None:
        self._log.append(sql)
        self._last_sql = sql

    def fetchone(self):
        if "DB_NAME()" in self._last_sql:
            return (self._db_name,)
        return None

    def fetchall(self):
        if "sys.database_files" in self._last_sql:
            return self._data_files
        return []

    def close(self) -> None:
        pass


class _SnapshotRecordingConnection:
    """Recording connection that supports fetchone/fetchall for snapshot queries."""

    def __init__(self, db_name: str = "TestDB", data_files=None):
        self.executed_sql: list[str] = []
        self._db_name = db_name
        self._data_files = data_files if data_files is not None else [("TestDB_data", r"C:\Data\TestDB.mdf")]

    def cursor(self) -> _SnapshotCursor:
        return _SnapshotCursor(self.executed_sql, self._db_name, self._data_files)

    def commit(self) -> None:
        pass


class TestSqlServerSnapshotIsolation:

    def test_setup_creates_snapshot_with_correct_sql(self):
        conn = _SnapshotRecordingConnection(
            db_name="MyDB",
            data_files=[("MyDB_data", r"C:\Data\MyDB.mdf")],
        )
        iso = SqlServerSnapshotIsolation()

        iso.setup(conn)

        assert "SELECT DB_NAME()" in conn.executed_sql
        assert any("sys.database_files" in s for s in conn.executed_sql)
        assert "DROP DATABASE IF EXISTS [MyDB__SCAI_SNAP]" in conn.executed_sql
        create_stmts = [s for s in conn.executed_sql if s.startswith("CREATE DATABASE")]
        assert len(create_stmts) == 1
        assert "MyDB__SCAI_SNAP" in create_stmts[0]
        assert "AS SNAPSHOT OF [MyDB]" in create_stmts[0]
        assert r"C:\Data\MyDB_SCAI_SNAP.ss" in create_stmts[0]

    def test_setup_multi_file_database(self):
        conn = _SnapshotRecordingConnection(
            db_name="BigDB",
            data_files=[
                ("BigDB_data", r"C:\Data\BigDB.mdf"),
                ("BigDB_data2", r"C:\Data\BigDB_2.ndf"),
            ],
        )
        iso = SqlServerSnapshotIsolation()

        iso.setup(conn)

        create_stmts = [s for s in conn.executed_sql if s.startswith("CREATE DATABASE")]
        assert len(create_stmts) == 1
        assert r"C:\Data\BigDB_SCAI_SNAP.ss" in create_stmts[0]
        assert r"C:\Data\BigDB_2_SCAI_SNAP.ss" in create_stmts[0]

    def test_setup_raises_when_no_data_files(self):
        conn = _SnapshotRecordingConnection(data_files=[])
        iso = SqlServerSnapshotIsolation()

        with pytest.raises(RuntimeError, match="No data files found"):
            iso.setup(conn)

    def test_teardown_issues_correct_sql_sequence(self):
        conn = _SnapshotRecordingConnection(db_name="TestDB")
        iso = SqlServerSnapshotIsolation()
        iso.setup(conn)
        conn.executed_sql.clear()

        iso.teardown(conn)

        sql = conn.executed_sql
        assert sql[0] == "USE [master]"
        assert any("SET SINGLE_USER WITH ROLLBACK IMMEDIATE" in s for s in sql)
        assert any("RESTORE DATABASE [TestDB] FROM DATABASE_SNAPSHOT" in s for s in sql)
        assert any("SET MULTI_USER" in s for s in sql)
        assert any("DROP DATABASE IF EXISTS [TestDB__SCAI_SNAP]" in s for s in sql)
        assert sql[-1] == "USE [TestDB]"

    def test_teardown_sql_order(self):
        conn = _SnapshotRecordingConnection(db_name="TestDB")
        iso = SqlServerSnapshotIsolation()
        iso.setup(conn)
        conn.executed_sql.clear()

        iso.teardown(conn)

        sql = conn.executed_sql
        idx_use_master = sql.index("USE [master]")
        idx_single = next(i for i, s in enumerate(sql) if "SET SINGLE_USER" in s)
        idx_restore = next(i for i, s in enumerate(sql) if "RESTORE DATABASE" in s)
        idx_multi = next(i for i, s in enumerate(sql) if "SET MULTI_USER" in s)
        idx_drop = next(i for i, s in enumerate(sql) if "DROP DATABASE IF EXISTS" in s)
        idx_use_db = sql.index("USE [TestDB]")

        assert idx_use_master < idx_single < idx_restore < idx_multi < idx_drop < idx_use_db

    def test_teardown_noop_when_not_set_up(self):
        conn = _SnapshotRecordingConnection()
        iso = SqlServerSnapshotIsolation()

        iso.teardown(conn)

        assert conn.executed_sql == []

    def test_teardown_clears_state(self):
        conn = _SnapshotRecordingConnection(db_name="TestDB")
        iso = SqlServerSnapshotIsolation()
        iso.setup(conn)

        iso.teardown(conn)

        assert iso._snapshot_name is None
        assert iso._source_db is None

    def test_cleanup_drops_snapshot_after_setup(self):
        conn = _SnapshotRecordingConnection(db_name="TestDB")
        iso = SqlServerSnapshotIsolation()
        iso.setup(conn)
        conn.executed_sql.clear()

        iso.cleanup(conn)

        assert conn.executed_sql == ["DROP DATABASE IF EXISTS [TestDB__SCAI_SNAP]"]

    def test_cleanup_noop_when_not_set_up(self):
        conn = _SnapshotRecordingConnection()
        iso = SqlServerSnapshotIsolation()

        iso.cleanup(conn)

        assert conn.executed_sql == []


# ---------------------------------------------------------------------------
# _snapshot_file_path
# ---------------------------------------------------------------------------

class TestSnapshotFilePath:

    @pytest.mark.parametrize("physical_name, expected", [
        (r"C:\Data\MyDB.mdf", r"C:\Data\MyDB_SCAI_SNAP.ss"),
        (r"C:\Data\MyDB_2.ndf", r"C:\Data\MyDB_2_SCAI_SNAP.ss"),
        ("/var/opt/mssql/data/TestDB.mdf", "/var/opt/mssql/data/TestDB_SCAI_SNAP.ss"),
        (r"C:\Data\MyDB", r"C:\Data\MyDB_SCAI_SNAP.ss"),
    ], ids=["windows_mdf", "windows_ndf", "linux_mdf", "no_extension"])
    def test_snapshot_file_path(self, physical_name, expected):
        assert _snapshot_file_path(physical_name) == expected


# ---------------------------------------------------------------------------
# Factory strategy selection
# ---------------------------------------------------------------------------

class TestFactoryStrategySelection:

    @pytest.mark.parametrize("factory_cls, expected_transaction_cls", [
        (SqlServerIsolationFactory, SqlServerTransactionIsolation),
        (RedshiftIsolationFactory, RedshiftTransactionIsolation),
    ], ids=["sqlserver", "redshift"])
    def test_no_commit_returns_transaction_isolation(self, factory_cls, expected_transaction_cls):
        provider = factory_cls().create(contains_commit=False)
        assert isinstance(provider, expected_transaction_cls)

    @pytest.mark.parametrize("factory_cls, expected_transaction_cls", [
        (SqlServerIsolationFactory, SqlServerTransactionIsolation),
        (RedshiftIsolationFactory, RedshiftTransactionIsolation),
    ], ids=["sqlserver", "redshift"])
    def test_default_returns_transaction_isolation(self, factory_cls, expected_transaction_cls):
        provider = factory_cls().create()
        assert isinstance(provider, expected_transaction_cls)

    @pytest.mark.parametrize("factory_cls, expected_backup_cls", [
        (SqlServerIsolationFactory, SqlServerBackupRestoreIsolation),
        (RedshiftIsolationFactory, RedshiftBackupRestoreIsolation),
        (TeradataIsolationFactory, TeradataBackupRestoreIsolation),
    ], ids=["sqlserver", "redshift", "teradata"])
    def test_contains_commit_returns_composite_with_correct_backup(self, factory_cls, expected_backup_cls):
        provider = factory_cls().create(contains_commit=True)
        assert isinstance(provider, CompositeIsolation)
        assert isinstance(provider._backup, expected_backup_cls)
        assert isinstance(provider._delta_undo, DeltaUndoIsolation)

    def test_sqlserver_use_snapshot_returns_snapshot_isolation(self):
        provider = SqlServerIsolationFactory().create(contains_commit=True, use_snapshot=True)
        assert isinstance(provider, SqlServerSnapshotIsolation)

    def test_sqlserver_use_snapshot_without_contains_commit_returns_snapshot(self):
        provider = SqlServerIsolationFactory().create(contains_commit=False, use_snapshot=True)
        assert isinstance(provider, SqlServerSnapshotIsolation)

    def test_teradata_always_returns_composite_regardless_of_flag(self):
        for flag in (True, False):
            provider = TeradataIsolationFactory().create(contains_commit=flag)
            assert isinstance(provider, CompositeIsolation)
            assert isinstance(provider._backup, TeradataBackupRestoreIsolation)


# ---------------------------------------------------------------------------
# Composite isolation routing
# ---------------------------------------------------------------------------

class TestCompositeIsolationRouting:

    @staticmethod
    def _make_table_config(schema, table, pk_columns=None):
        from test_runner.replay.models import TableConfig
        return TableConfig(
            schema_name=schema,
            table_name=table,
            primary_key_columns=pk_columns or [],
        )

    def test_setup_routes_pk_tables_to_delta_undo(self):
        backup = MagicMock(spec=BackupRestoreIsolation)
        delta_undo = MagicMock(spec=DeltaUndoIsolation)
        composite = CompositeIsolation(backup=backup, delta_undo=delta_undo)
        conn = MagicMock()

        pk_table = self._make_table_config("s", "orders", ["order_id"])
        composite.setup(conn, [pk_table])

        delta_undo.setup.assert_called_once_with(conn, [pk_table])
        backup.setup.assert_called_once_with(conn, None)

    def test_setup_routes_non_pk_tables_to_backup(self):
        backup = MagicMock(spec=BackupRestoreIsolation)
        delta_undo = MagicMock(spec=DeltaUndoIsolation)
        composite = CompositeIsolation(backup=backup, delta_undo=delta_undo)
        conn = MagicMock()

        no_pk_table = self._make_table_config("s", "event_log")
        composite.setup(conn, [no_pk_table])

        backup.setup.assert_called_once_with(conn, [no_pk_table])
        delta_undo.setup.assert_called_once_with(conn, None)

    def test_setup_routes_mixed_tables_to_both(self):
        backup = MagicMock(spec=BackupRestoreIsolation)
        delta_undo = MagicMock(spec=DeltaUndoIsolation)
        composite = CompositeIsolation(backup=backup, delta_undo=delta_undo)
        conn = MagicMock()

        pk_table = self._make_table_config("s", "orders", ["id"])
        no_pk_table = self._make_table_config("s", "logs")
        composite.setup(conn, [pk_table, no_pk_table])

        backup.setup.assert_called_once_with(conn, [no_pk_table])
        delta_undo.setup.assert_called_once_with(conn, [pk_table])

    def test_teardown_delegates_to_both(self):
        backup = MagicMock(spec=BackupRestoreIsolation)
        delta_undo = MagicMock(spec=DeltaUndoIsolation)
        composite = CompositeIsolation(backup=backup, delta_undo=delta_undo)
        conn = MagicMock()

        deltas = {"S.ORDERS": {"inserts": [{"ID": 1}]}}
        configs = [self._make_table_config("s", "orders", ["id"])]
        composite.teardown(conn, deltas=deltas, table_configs=configs)

        delta_undo.teardown.assert_called_once_with(conn, deltas=deltas, table_configs=configs)
        backup.teardown.assert_called_once_with(conn)

    def test_cleanup_delegates_to_both(self):
        backup = MagicMock(spec=BackupRestoreIsolation)
        delta_undo = MagicMock(spec=DeltaUndoIsolation)
        composite = CompositeIsolation(backup=backup, delta_undo=delta_undo)
        conn = MagicMock()

        composite.cleanup(conn)

        backup.cleanup.assert_called_once_with(conn)
        delta_undo.cleanup.assert_called_once_with(conn)
