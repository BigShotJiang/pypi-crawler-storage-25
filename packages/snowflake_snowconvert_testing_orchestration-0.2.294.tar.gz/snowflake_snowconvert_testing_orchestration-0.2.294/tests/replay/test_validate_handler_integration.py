"""Integration tests for validate_handler.validate_deltas.

Exercises the full chain: snapshot_table → compute_table_delta →
compare_table_deltas using fake connection objects.  No patches on
inner functions — only the outermost DB boundary (the connection
object) is replaced with a fake.
"""

from __future__ import annotations

from decimal import Decimal
from unittest.mock import MagicMock, PropertyMock

from test_runner.common.config import ReplayConfiguration
from test_runner.common.models.baseline_data import BaselineData
from test_runner.replay.isolation.clone import SnowflakeCloneIsolation
from test_runner.replay.validate_handler import (
    DeltaComparisonResult,
    validate_deltas,
)


# ---------------------------------------------------------------------------
# Fake DB boundary objects
# ---------------------------------------------------------------------------

class _FakeCursor:
    """Minimal DB-API cursor returning canned description + rows."""

    def __init__(self, description=None, rows=None):
        self.description = description
        self._rows = rows or []
        self.executed: list[str] = []
        self._closed = False

    def execute(self, sql: str) -> None:
        self.executed.append(sql)

    def fetchall(self):
        return self._rows

    def close(self) -> None:
        self._closed = True


class _FakeConnection:
    """Returns pre-built cursors in FIFO order."""

    def __init__(self, cursors: list[_FakeCursor]):
        self._cursors = list(cursors)
        self._idx = 0

    def cursor(self) -> _FakeCursor:
        c = self._cursors[self._idx]
        self._idx += 1
        return c


def _snapshot_cursor(description, rows):
    """Cursor that satisfies ``snapshot_table_with_types``'s protocol.

    Each description entry may be a 1-tuple ``(name,)`` or a 2-tuple
    ``(name, type_code)``.  Snowflake connector type code 2 = ``TEXT``
    (which the shared helper remaps to ``VARCHAR``) — a sensible default
    for tests where the column type is irrelevant.
    """
    full_desc = [
        d if len(d) >= 2 else (d[0], 2) for d in description
    ]
    return _FakeCursor(description=full_desc, rows=rows)


def _table_cursors(description, before_rows, after_rows):
    """Build the two cursors ``validate_handler`` opens per table.

    The before-snapshot now also yields column types from its own
    ``cursor.description`` (no separate zero-row query is needed).
    """
    return [
        _snapshot_cursor(description, before_rows),
        _snapshot_cursor(description, after_rows),
    ]


def _baseline(**overrides) -> BaselineData:
    """Build a minimal BaselineData with sensible defaults."""
    defaults = dict(
        procedure="dbo.MyProc",
        parameters={},
        captured_at="2025-01-01T00:00:00Z",
        result_sets=[],
        row_counts=[],
        success=True,
    )
    defaults.update(overrides)
    return BaselineData(**defaults)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestValidateDeltasIntegration:

    def test_matching_deltas_return_match(self):
        """Baseline insert matches actual insert → delta_match."""
        conn = _FakeConnection(_table_cursors(
            [("color",)], before_rows=[], after_rows=[("Blue",)],
        ))
        baseline = _baseline(table_deltas={
            "WAREHOUSE.COLORS": {
                "table": "WAREHOUSE.COLORS",
                "strategy_used": "full_snapshot",
                "inserts": [{"COLOR": "Blue"}],
                "deletes": [],
                "updates": [],
            },
        })

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is True
        assert result.match_type == "delta_match"
        assert result.details["WAREHOUSE.COLORS"]["match"] is True

    def test_mismatched_insert_values_return_content_mismatch(self):
        """Baseline expects Blue but actual produces Red → content mismatch."""
        conn = _FakeConnection(_table_cursors(
            [("color",)], before_rows=[], after_rows=[("Red",)],
        ))
        baseline = _baseline(table_deltas={
            "WAREHOUSE.COLORS": {
                "table": "WAREHOUSE.COLORS",
                "strategy_used": "full_snapshot",
                "inserts": [{"COLOR": "Blue"}],
                "deletes": [],
                "updates": [],
            },
        })

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is False
        assert result.match_type == "delta_mismatch"
        detail = result.details["WAREHOUSE.COLORS"]
        assert detail["match"] is False
        assert any(
            d["type"] == "insert_content_mismatch"
            for d in detail["differences"]
        )

    def test_extra_inserts_return_count_mismatch(self):
        """Baseline has 1 insert, actual produces 2 → insert_count_mismatch."""
        conn = _FakeConnection(_table_cursors(
            [("id",)], before_rows=[], after_rows=[(1,), (2,)],
        ))
        baseline = _baseline(table_deltas={
            "WAREHOUSE.T": {
                "table": "WAREHOUSE.T",
                "strategy_used": "full_snapshot",
                "inserts": [{"ID": 1}],
                "deletes": [],
                "updates": [],
            },
        })

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is False
        diffs = result.details["WAREHOUSE.T"]["differences"]
        assert any(d["type"] == "insert_count_mismatch" for d in diffs)
        mismatch = next(d for d in diffs if d["type"] == "insert_count_mismatch")
        assert mismatch["baseline"] == 1
        assert mismatch["actual"] == 2

    def test_ignore_columns_from_column_metadata_flow_through(self):
        """Platform-managed columns in column_metadata are excluded end-to-end.

        The chain: column_metadata → _merge_column_metadata → tc.ignore_columns
        → FullSnapshotStrategy._resolve_columns → compare_table_deltas._strip_columns.
        """
        conn = _FakeConnection(_table_cursors(
            [("id",), ("validfrom",)], before_rows=[], after_rows=[(1, "2025-01-01")],
        ))
        baseline = _baseline(
            table_deltas={
                "DBO.ORDERS": {
                    "table": "DBO.ORDERS",
                    "strategy_used": "full_snapshot",
                    "inserts": [{"ID": 1, "VALIDFROM": "2024-01-01"}],
                    "deletes": [],
                    "updates": [],
                },
            },
            column_metadata={
                "DBO.ORDERS": {
                    "platform_managed_columns": ["VALIDFROM"],
                },
            },
        )

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is True
        assert result.match_type == "delta_match"

    def test_normalize_fqn_strips_database_prefix(self):
        """3-part baseline key 'DB.Schema.Table' normalizes to 'SCHEMA.TABLE'."""
        conn = _FakeConnection(_table_cursors(
            [("id",)], before_rows=[], after_rows=[(1,)],
        ))
        baseline = _baseline(table_deltas={
            "WideWorldImporters.Warehouse.Colors": {
                "table": "WideWorldImporters.Warehouse.Colors",
                "strategy_used": "full_snapshot",
                "inserts": [{"ID": 1}],
                "deletes": [],
                "updates": [],
            },
        })

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is True
        assert result.details["WAREHOUSE.COLORS"]["match"] is True

    def test_no_baseline_deltas_with_affected_tables_detects_mutations(self):
        """Empty baseline + affected_tables + actual has changes → mismatch.

        Even when the source procedure produced no deltas, if the CUR says
        the procedure modifies_data and Snowflake produces unexpected inserts,
        we detect it.
        """
        conn = _FakeConnection(_table_cursors(
            [("id",)], before_rows=[], after_rows=[(1,)],
        ))
        baseline = _baseline(table_deltas=None)

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            affected_tables=["Warehouse.Colors"],
            clone_db="CLONE",
        )

        assert result.match is False
        assert result.match_type == "delta_mismatch"
        diffs = result.details["WAREHOUSE.COLORS"]["differences"]
        assert any(d["type"] == "insert_count_mismatch" for d in diffs)

    def test_no_tables_returns_no_deltas(self):
        """No baseline deltas + no affected_tables → early-exit no_deltas."""
        conn = _FakeConnection([])
        baseline = _baseline(table_deltas=None)

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is True
        assert result.match_type == "no_deltas"
        assert result.details == {}

    def test_owns_isolation_setup_and_teardown_called(self):
        """clone_db=None → executor_factory.create_isolation() invoked;
        isolation.setup() and teardown() bracket the snapshot+execute cycle.

        Isolation is an infrastructure boundary, so mocking it is justified —
        we are NOT mocking any of the snapshot/delta/compare inner functions.
        We verify call ordering via a recording list rather than mock counts.
        """
        call_order: list[str] = []

        mock_isolation = MagicMock(spec=SnowflakeCloneIsolation)
        type(mock_isolation).clone_database = PropertyMock(
            return_value="AUTO_CLONE",
        )
        mock_isolation.setup.side_effect = lambda c: call_order.append("setup")
        mock_isolation.teardown.side_effect = lambda c: call_order.append("teardown")

        mock_factory = MagicMock()
        mock_factory.create_isolation.return_value = mock_isolation

        conn = _FakeConnection(_table_cursors(
            [("id",)], before_rows=[], after_rows=[],
        ))
        baseline = _baseline(table_deltas={
            "DBO.T": {
                "table": "DBO.T",
                "strategy_used": "full_snapshot",
                "inserts": [],
                "deletes": [],
                "updates": [],
            },
        })
        execute_calls: list[str | None] = []

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: (execute_calls.append(db), call_order.append("execute")),
            database="MYDB",
            procedure="dbo.MyProc",
            params_hash="abc123",
            executor_factory=mock_factory,
        )

        assert call_order == ["setup", "execute", "teardown"]
        assert execute_calls == ["AUTO_CLONE"]
        assert result.match is True

    def test_caller_provided_clone_db_skips_isolation(self):
        """clone_db='PRE_CLONE' → no executor_factory needed, no isolation."""
        conn = _FakeConnection(_table_cursors(
            [("id",)], before_rows=[], after_rows=[],
        ))
        baseline = _baseline(table_deltas={
            "DBO.T": {
                "table": "DBO.T",
                "strategy_used": "full_snapshot",
                "inserts": [],
                "deletes": [],
                "updates": [],
            },
        })
        execute_calls: list[str | None] = []

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: execute_calls.append(db),
            clone_db="PRE_CLONE",
        )

        assert execute_calls == ["PRE_CLONE"]
        assert result.match is True


# ---------------------------------------------------------------------------
# PK propagation from baseline
# ---------------------------------------------------------------------------


class TestBaselinePkPropagation:

    def test_baseline_pk_columns_used_for_validate_strategy(self):
        """When baseline delta has pk_columns, validate side uses PK_DIFF.

        Capture discovered PKs via introspection and stored them in
        delta['pk_columns'].  On the validate side, these should
        propagate to TableConfig so PK_DIFF is used for comparison.
        """
        conn = _FakeConnection(_table_cursors(
            [("id", 0), ("name", 2)],
            before_rows=[(1, "Red")],
            after_rows=[(1, "Red"), (2, "Blue")],
        ))
        baseline = _baseline(table_deltas={
            "DBO.COLORS": {
                "table": "DBO.COLORS",
                "strategy_used": "pk_diff",
                "pk_columns": ["ID"],
                "inserts": [{"ID": 2, "NAME": "Blue"}],
                "deletes": [],
                "updates": [],
            },
        })

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is True
        assert result.match_type == "delta_match"

    def test_cur_pks_take_precedence_over_baseline(self):
        """CUR-supplied pk_columns_by_table should be used even if baseline
        also has pk_columns (CUR is the more authoritative source).
        """
        conn = _FakeConnection(_table_cursors(
            [("id", 0), ("name", 2)],
            before_rows=[(1, "Red")],
            after_rows=[(1, "Red"), (2, "Blue")],
        ))
        baseline = _baseline(table_deltas={
            "DBO.COLORS": {
                "table": "DBO.COLORS",
                "strategy_used": "pk_diff",
                "pk_columns": ["WRONG_COL"],
                "inserts": [{"ID": 2, "NAME": "Blue"}],
                "deletes": [],
                "updates": [],
            },
        })

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
            pk_columns_by_table={"DBO.COLORS": ["ID"]},
        )

        assert result.match is True

    def test_no_pk_columns_in_baseline_uses_full_snapshot(self):
        """Old baseline without pk_columns → FULL_SNAPSHOT on validate."""
        conn = _FakeConnection(_table_cursors(
            [("name",)], before_rows=[], after_rows=[("Blue",)],
        ))
        baseline = _baseline(table_deltas={
            "DBO.COLORS": {
                "table": "DBO.COLORS",
                "strategy_used": "full_snapshot",
                "inserts": [{"NAME": "Blue"}],
                "deletes": [],
                "updates": [],
            },
        })

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is True
        assert result.match_type == "delta_match"


# ---------------------------------------------------------------------------
# SDV column-type plumbing — Decimal vs. Float canonicalisation
# ---------------------------------------------------------------------------


class TestColumnTypePlumbing:
    """End-to-end verification of the SNOW-3414326 root cause.

    The connector returns ``NUMBER(p,s)`` columns as ``Decimal`` (e.g.
    ``Decimal('45.50')``) while JSON-deserialised baselines come back as
    ``float`` (``45.5``).  Stringifying naively yields a spurious
    ``"45.50"`` vs ``"45.5"`` cell diff.  By plumbing the Snowflake
    ``FIXED → NUMBER`` DDL type through to SDV's ``ResultSet`` API, both
    sides normalise to the same canonical value and the diff disappears.
    """

    def test_decimal_vs_float_on_number_column_passes(self):
        """``Decimal('45.50')`` baseline vs. ``45.5`` actual on a NUMBER
        column should match end-to-end (no spurious diff)."""
        # Type code 0 == FIXED — the shared snowflake_types helper remaps
        # it to ``NUMBER`` so SDV's normalisation pipeline kicks in.
        conn = _FakeConnection(_table_cursors(
            [("price", 0)],
            before_rows=[],
            after_rows=[(45.5,)],
        ))
        baseline = _baseline(table_deltas={
            "DBO.PRODUCTS": {
                "table": "DBO.PRODUCTS",
                "strategy_used": "full_snapshot",
                "inserts": [{"PRICE": Decimal("45.50")}],
                "deletes": [],
                "updates": [],
            },
        })

        result = validate_deltas(
            connection=conn,
            baseline=baseline,
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda db: None,
            clone_db="CLONE",
        )

        assert result.match is True, result.details
        assert result.match_type == "delta_match"
        assert result.details["DBO.PRODUCTS"]["match"] is True
