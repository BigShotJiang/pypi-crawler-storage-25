"""Tests for test_runner.parallel.executor (ParallelExecutor)."""

from __future__ import annotations

import threading
import time
from typing import Any

import pytest

from test_runner.common.database_executor import DatabaseExecutor, DatabaseExecutorFactory
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.models import TestFile
from test_runner.parallel.executor import ParallelExecutor

from .conftest import make_case_item as _case, make_test_file as _make_tf


# ---------------------------------------------------------------------------
# Fake executor / factory for execute_with_factory tests
# ---------------------------------------------------------------------------

class _FakeExecutor(DatabaseExecutor):
    """Minimal executor that records creation and close calls."""

    def __init__(self, executor_id: int, log: list[str]) -> None:
        self._id = executor_id
        self._log = log
        self._log.append(f"create:{self._id}")

    def close(self) -> None:
        self._log.append(f"close:{self._id}")

    def execute(self, sql: str, steps: Any = None, fetch_stmts: Any = None) -> Any:
        raise NotImplementedError


class _FakeFactory(DatabaseExecutorFactory):
    """Factory that produces _FakeExecutors and records lifecycle events."""

    def __init__(self) -> None:
        self.log: list[str] = []
        self._counter = 0
        self._lock = threading.Lock()

    @property
    def dialect(self) -> DatabaseDialect:
        return DatabaseDialect.SNOWFLAKE

    def build_config(self, raw: dict[str, Any]) -> Any:
        return raw

    def create_executor(self, config: Any) -> _FakeExecutor:
        with self._lock:
            self._counter += 1
            eid = self._counter
        return _FakeExecutor(eid, self.log)

    def create_literal_formatter(self) -> Any:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# execute_read_only
# ---------------------------------------------------------------------------

class TestExecuteReadOnly:
    def test_returns_results_in_original_order(self):
        """Results must be returned in submission order, not completion order."""
        pe = ParallelExecutor(max_workers=4)
        tf = _make_tf("sp_a", cases=5)
        cases = [_case(tf, i) for i in range(5)]

        def fn(test_file: TestFile, case_idx: int, test_case: list) -> str:
            return f"{test_file.code_unit_name}:{case_idx}"

        results = pe.execute_read_only(cases, fn)
        assert results == [f"sp_a:{i}" for i in range(5)]

    def test_empty_cases(self):
        pe = ParallelExecutor(max_workers=2)
        results = pe.execute_read_only([], lambda *_: None)
        assert results == []

    def test_each_thread_gets_its_own_thread(self):
        """Verify that work is distributed across threads."""
        pe = ParallelExecutor(max_workers=4)
        tf = _make_tf("sp_a", cases=8)
        cases = [_case(tf, i) for i in range(8)]

        thread_ids: list[int] = []
        lock = threading.Lock()

        def fn(test_file: TestFile, case_idx: int, test_case: list) -> int:
            tid = threading.current_thread().ident
            with lock:
                thread_ids.append(tid)
            time.sleep(0.01)
            return tid

        pe.execute_read_only(cases, fn)
        unique_threads = set(thread_ids)
        assert len(unique_threads) > 1

    def test_exception_propagates(self):
        pe = ParallelExecutor(max_workers=2)
        tf = _make_tf("sp_a", cases=2)
        cases = [_case(tf, i) for i in range(2)]

        def fn(test_file: TestFile, case_idx: int, test_case: list):
            if case_idx == 1:
                raise ValueError("boom")
            return "ok"

        with pytest.raises(ValueError, match="boom"):
            pe.execute_read_only(cases, fn)


# ---------------------------------------------------------------------------
# execute_with_factory
# ---------------------------------------------------------------------------

class TestExecuteWithFactory:
    def test_results_in_original_order(self):
        factory = _FakeFactory()
        pe = ParallelExecutor(max_workers=2)
        tf = _make_tf("sp_a", cases=4)
        cases = [_case(tf, i) for i in range(4)]

        def fn(executor: _FakeExecutor, test_file: TestFile, case_idx: int, test_case: list) -> str:
            return f"{test_file.code_unit_name}:{case_idx}"

        results = pe.execute_with_factory(cases, factory, {}, fn)

        assert results == [f"sp_a:{i}" for i in range(4)]

    def test_creates_one_executor_per_thread(self):
        factory = _FakeFactory()
        pe = ParallelExecutor(max_workers=4)
        tf = _make_tf("sp_a", cases=8)
        cases = [_case(tf, i) for i in range(8)]

        executor_ids_per_thread: dict[int, int] = {}
        lock = threading.Lock()

        def fn(executor: _FakeExecutor, test_file: TestFile, case_idx: int, test_case: list) -> int:
            tid = threading.current_thread().ident
            with lock:
                if tid in executor_ids_per_thread:
                    assert executor_ids_per_thread[tid] == executor._id
                else:
                    executor_ids_per_thread[tid] = executor._id
            time.sleep(0.01)
            return executor._id

        pe.execute_with_factory(cases, factory, {}, fn)

        create_events = [e for e in factory.log if e.startswith("create:")]
        assert len(create_events) == len(executor_ids_per_thread)

    def test_closes_all_executors_after_completion(self):
        factory = _FakeFactory()
        pe = ParallelExecutor(max_workers=2)
        tf = _make_tf("sp_a", cases=3)
        cases = [_case(tf, i) for i in range(3)]

        def fn(executor: _FakeExecutor, test_file: TestFile, case_idx: int, test_case: list) -> str:
            return "ok"

        pe.execute_with_factory(cases, factory, {}, fn)

        create_count = sum(1 for e in factory.log if e.startswith("create:"))
        close_count = sum(1 for e in factory.log if e.startswith("close:"))
        assert close_count == create_count
        assert close_count > 0

    def test_closes_executors_on_worker_exception(self):
        factory = _FakeFactory()
        pe = ParallelExecutor(max_workers=1)
        tf = _make_tf("sp_a", cases=2)
        cases = [_case(tf, i) for i in range(2)]

        def fn(executor: _FakeExecutor, test_file: TestFile, case_idx: int, test_case: list) -> str:
            if case_idx == 1:
                raise RuntimeError("worker failure")
            return "ok"

        with pytest.raises(RuntimeError, match="worker failure"):
            pe.execute_with_factory(cases, factory, {}, fn)

        close_count = sum(1 for e in factory.log if e.startswith("close:"))
        create_count = sum(1 for e in factory.log if e.startswith("create:"))
        assert close_count == create_count

    def test_empty_cases_creates_no_executors(self):
        factory = _FakeFactory()
        pe = ParallelExecutor(max_workers=2)

        results = pe.execute_with_factory([], factory, {}, lambda *_: None)

        assert results == []
        assert factory.log == []


# ---------------------------------------------------------------------------
# Constructor validation
# ---------------------------------------------------------------------------

class TestConstructor:
    def test_max_workers_must_be_positive(self):
        with pytest.raises(ValueError, match="max_workers must be >= 1"):
            ParallelExecutor(max_workers=0)
