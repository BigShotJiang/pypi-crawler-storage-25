"""Tests for TeradataExecutor.execute_steps() with mocked cursors."""

from __future__ import annotations

import datetime
import decimal
import logging
from unittest.mock import MagicMock

from test_runner.capture.sources.teradata import TeradataExecutor
from test_runner.common.builders.models import TeradataBuiltSQL
from test_runner.common.models.capture_result import StepOrigin
from test_runner.common.models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    TableStep,
    ValidateQuery,
    ValidateResult,
    ValidateSkip,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# teradatasql uses Python type classes as type codes.  These get mapped to
# Teradata type names internally and then through the YAML mapping.
_YAML_MAPPING = {
    "INTEGER": "NUMBER",
    "VARCHAR": "VARCHAR",
    "DECIMAL": "NUMBER",
    "TIMESTAMP": "TIMESTAMP_NTZ",
    "DATE": "DATE",
    "FLOAT": "FLOAT",
}


def _desc(*cols: tuple[str, type]) -> list[tuple]:
    """Build a cursor.description list from (name, python_type) tuples."""
    return [(name, type_code, None, None, None, None, None) for name, type_code in cols]


def _make_multi_step_connector(
    steps: list[dict],
) -> tuple[MagicMock, MagicMock]:
    """Create a mock connector where sequential ``cursor.execute`` calls
    swap ``description``/``rows``/``nextset_returns`` per *steps*.

    Each step dict may carry:

    - ``description``: cursor.description after this execute (list[tuple] | None)
    - ``rows``: rows for fetchone/fetchall on the *first* result set
    - ``nextset_returns``: list[bool] for sequential ``cursor.nextset()``
      calls — defaults to ``[False]`` (no additional result sets)
    - ``nextset_descriptions``: list[list[tuple] | None] — cursor.description
      values *after* each nextset() that returns True
    - ``nextset_rows``: list[list[tuple]] — rows fetched via fetchall on
      each post-nextset() result set
    """
    call_idx = {"i": 0}
    main_cursor = MagicMock()

    def _execute_side_effect(sql):
        idx = call_idx["i"]
        call_idx["i"] += 1
        if idx >= len(steps):
            main_cursor.description = None
            main_cursor.fetchall.return_value = []
            main_cursor.fetchone.return_value = None
            main_cursor.nextset.side_effect = [False]
            return

        step = steps[idx]

        # Build a per-execute fetch sequence: first execute, then any
        # nextset() result sets.  Each fetch returns the matching rows.
        result_descriptions = [step.get("description")] + list(
            step.get("nextset_descriptions", [])
        )
        result_rows = [step.get("rows", [])] + list(step.get("nextset_rows", []))

        cursor_idx = {"i": 0}

        def _set_state_for(i: int) -> None:
            if i < len(result_descriptions):
                main_cursor.description = result_descriptions[i]
            else:
                main_cursor.description = None
            rows = result_rows[i] if i < len(result_rows) else []
            main_cursor.fetchall.return_value = rows
            main_cursor.fetchone.return_value = rows[0] if rows else None

        _set_state_for(0)

        nextset_returns = step.get("nextset_returns")
        if nextset_returns is None:
            nextset_returns = [True] * (len(result_descriptions) - 1) + [False]

        def _nextset_side_effect():
            cursor_idx["i"] += 1
            _set_state_for(cursor_idx["i"])
            i = cursor_idx["i"] - 1
            if i < len(nextset_returns):
                return nextset_returns[i]
            return False

        main_cursor.nextset.side_effect = _nextset_side_effect

    main_cursor.execute = MagicMock(side_effect=_execute_side_effect)
    main_cursor.close = MagicMock()

    connection = MagicMock()
    connection.cursor.return_value = main_cursor

    connector = MagicMock()
    connector.connection = connection
    return connector, main_cursor


# ---------------------------------------------------------------------------
# Validated CALL with no params (proc returns DYNAMIC RESULT SETS only)
# ---------------------------------------------------------------------------

class TestValidatedCallNoParams:
    def test_first_dynamic_result_set_captured(self):
        """A validated CALL captures the first non-empty result set."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": _desc(("id", int), ("name", str)),
                    "rows": [(1, "alpha"), (2, "beta")],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [QueryStep(source_query="CALL get_items()")]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL get_items()"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"id": 1, "name": "alpha"}, {"id": 2, "name": "beta"}]
        assert result.row_counts == [2]
        assert result.step_origins == [StepOrigin(step_index=0)]

    def test_empty_first_set_then_dynamic_result_set(self):
        """CALL with empty first set + nextset() rows → captures the rows."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    # First result set: empty (no description) — Teradata
                    # sometimes reports empty bookkeeping payloads here.
                    "description": None,
                    "rows": [],
                    "nextset_descriptions": [_desc(("v", int))],
                    "nextset_rows": [[(42,)]],
                    "nextset_returns": [True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [QueryStep(source_query="CALL get_value()")]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL get_value()"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[{"v": 42}]]


# ---------------------------------------------------------------------------
# CALL(false) + ParamStep(true) — INOUT extraction
# ---------------------------------------------------------------------------

class TestParamStepFromInoutRow:
    def test_inout_extraction(self):
        """ParamStep extracts INOUT params from the preceding CALL row."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": _desc(("result", int), ("status", str)),
                    "rows": [(21, "ok")],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL fibonacci(8, result)", validate=False),
            ParamStep(source_params=["result"]),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL fibonacci(8, result)"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"result": 21}]
        assert result.step_origins == [StepOrigin(step_index=1)]

    def test_param_step_no_prior_call_raises(self):
        connector, main_cursor = _make_multi_step_connector([])

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [ParamStep(source_params=["result"])]
        built = TeradataBuiltSQL(main_sql={}, validated_step_indices=[0])

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "no CALL was executed" in result.error


# ---------------------------------------------------------------------------
# CALL(false) + CursorStep(true) — DYNAMIC RESULT SETS via nextset()
# ---------------------------------------------------------------------------

class TestCursorStepFromDynamicResultSets:
    def test_single_cursor(self):
        """CursorStep captures the first nextset() result set after the CALL."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    # CALL row: INOUT param 'cursor_name' (placeholder)
                    "description": _desc(("cursor_name", str)),
                    "rows": [("c1",)],
                    # Then one DYNAMIC RESULT SET via nextset()
                    "nextset_descriptions": [_desc(("sellerid", int))],
                    "nextset_rows": [[(1,), (2,)]],
                    "nextset_returns": [True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(
                source_query="CALL get_sales('North', 'c1')",
                validate=False,
            ),
            CursorStep(source_cursor="c1"),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL get_sales('North', 'c1')"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"sellerid": 1}, {"sellerid": 2}]
        assert result.step_origins == [StepOrigin(step_index=1)]

    def test_multiple_cursors_consumed_in_order(self):
        """Multiple CursorSteps pop from the queue in order."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": _desc(("c1", str), ("c2", str)),
                    "rows": [("c1", "c2")],
                    "nextset_descriptions": [
                        _desc(("a", int)),
                        _desc(("b", int)),
                    ],
                    "nextset_rows": [
                        [(10,), (20,)],
                        [(99,)],
                    ],
                    "nextset_returns": [True, True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL p('c1', 'c2')", validate=False),
            CursorStep(source_cursor="c1"),
            CursorStep(source_cursor="c2"),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL p('c1', 'c2')"},
            validated_step_indices=[1, 2],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [
            [{"a": 10}, {"a": 20}],
            [{"b": 99}],
        ]
        assert result.step_origins == [
            StepOrigin(step_index=1),
            StepOrigin(step_index=2),
        ]

    def test_missing_cursor_data_yields_empty_result_set(self):
        """Fewer dynamic result sets than CursorSteps → empty result set, no crash."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": _desc(("c1", str)),
                    "rows": [("c1",)],
                    # No nextset() results.
                    "nextset_returns": [False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL p('c1')", validate=False),
            CursorStep(source_cursor="c1"),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL p('c1')"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[]]
        assert result.row_counts == [0]


# ---------------------------------------------------------------------------
# Combined: CALL + ParamStep + CursorStep
# ---------------------------------------------------------------------------

class TestCombined:
    def test_call_param_cursor(self):
        """Full chain: CALL(false) + ParamStep(true) + CursorStep(true)."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    # CALL row carries INOUT total_sales + cursor name
                    "description": _desc(
                        ("total_sales", int), ("cursor_name", str),
                    ),
                    "rows": [(42000, "sales_cursor")],
                    # One dynamic result set: cursor data
                    "nextset_descriptions": [
                        _desc(("sellerid", int), ("amount", int)),
                    ],
                    "nextset_rows": [[(1, 500)]],
                    "nextset_returns": [True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(
                source_query="CALL get_summary('North', total_sales, 'sales_cursor')",
                validate=False,
            ),
            ParamStep(source_params=["total_sales"]),
            CursorStep(source_cursor="sales_cursor"),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL get_summary('North', total_sales, 'sales_cursor')"},
            validated_step_indices=[1, 2],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == [{"total_sales": 42000}]
        assert result.result_sets[1] == [{"sellerid": 1, "amount": 500}]
        assert result.step_origins == [
            StepOrigin(step_index=1),
            StepOrigin(step_index=2),
        ]


# ---------------------------------------------------------------------------
# TableStep
# ---------------------------------------------------------------------------

class TestTableStep:
    def test_select_captured(self):
        connector, main_cursor = _make_multi_step_connector(
            [
                # Step 0: CALL (no validate, no params)
                {
                    "description": None,
                    "rows": [],
                },
                # Step 1: SELECT * FROM vt_results
                {
                    "description": _desc(("id", int)),
                    "rows": [(10,), (20,)],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL load()", validate=False),
            TableStep(source_table="vt_results"),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL load()", 1: "SELECT * FROM vt_results"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[{"id": 10}, {"id": 20}]]


# ---------------------------------------------------------------------------
# Transaction semantics
# ---------------------------------------------------------------------------

class TestTransactionSemantics:
    def test_no_inner_transaction_wrapper(self):
        """execute_steps does NOT wrap in BEGIN/ROLLBACK.

        Atomicity for multi-step batches is owned by the caller's
        isolation provider (TeradataIsolationFactory via capture_deltas).
        Wrapping here would nest inside that outer transaction.
        """
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [QueryStep(source_query="CALL setup()", validate=False)]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL setup()"},
            validated_step_indices=[],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        executed = [c[0][0] for c in main_cursor.execute.call_args_list]
        for marker in ("BEGIN", "BT", "ET", "ROLLBACK", "COMMIT"):
            assert marker not in executed, f"{marker} should not be issued"
        assert executed == ["CALL setup()"]

    def test_error_recorded_without_rollback(self):
        connector = MagicMock()
        connection = MagicMock()
        cursor = MagicMock()
        cursor.execute = MagicMock(side_effect=RuntimeError("DB error"))
        cursor.close = MagicMock()
        connection.cursor.return_value = cursor
        connector.connection = connection

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [QueryStep(source_query="SELECT 1")]
        built = TeradataBuiltSQL(
            main_sql={0: "SELECT 1"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "DB error" in result.error
        executed = [c[0][0] for c in cursor.execute.call_args_list]
        assert "ROLLBACK" not in executed


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_target_only_step_skipped(self):
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": _desc(("v", int)),
                    "rows": [(42,)],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(target_query="LET x VARCHAR := '1'", validate=False),
            QueryStep(source_query="SELECT 42 AS v"),
        ]
        built = TeradataBuiltSQL(
            main_sql={1: "SELECT 42 AS v"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[{"v": 42}]]

    def test_no_validated_steps(self):
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [QueryStep(source_query="CALL setup()", validate=False)]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL setup()"},
            validated_step_indices=[],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == []

    def test_decimal_inout_round_trip(self):
        """INOUT extraction preserves Decimal types from teradatasql."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": _desc(("price", decimal.Decimal)),
                    "rows": [(decimal.Decimal("19.99"),)],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL get_price(price)", validate=False),
            ParamStep(source_params=["price"]),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL get_price(price)"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[{"price": decimal.Decimal("19.99")}]]


class TestValidateList:
    """``validate: [list]`` paths: multi-RS mapping, errors.

    ``teradatasql`` positions the cursor on RS#0 after a CALL — that
    slot is always either the synthesized INOUT-parameter row or an
    empty bookkeeping payload, never a DYNAMIC RESULT SET.  These
    fixtures model RS#0 explicitly so the executor's "always discard
    RS#0" contract is exercised.
    """

    def test_no_inout_maps_each_result_set(self):
        # RS#0 = empty CALL ack (no INOUT params); DRSes start at RS#1.
        connector, _ = _make_multi_step_connector(
            [
                {
                    "description": None,
                    "rows": [],
                    "nextset_descriptions": [
                        _desc(("a", int)),
                        _desc(("b", int)),
                    ],
                    "nextset_rows": [[(1,)], [(2,)]],
                    "nextset_returns": [True, True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(
                source_query="CALL multi_rs()",
                validate=[ValidateResult(), ValidateResult()],
            ),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL multi_rs()"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[{"a": 1}], [{"b": 2}]]
        assert result.step_origins == [
            StepOrigin(step_index=0, validate_entry=0),
            StepOrigin(step_index=0, validate_entry=1),
        ]

    def test_with_inout_first_set_discarded(self):
        # RS#0 = synthesized INOUT row (status='ok'); discarded. DRSes follow.
        connector, _ = _make_multi_step_connector(
            [
                {
                    "description": _desc(("status", str)),
                    "rows": [("ok",)],
                    "nextset_descriptions": [
                        _desc(("a", int)),
                        _desc(("b", int)),
                    ],
                    "nextset_rows": [[(10,)], [(20,)]],
                    "nextset_returns": [True, True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(
                source_query="CALL multi_rs(status)",
                validate=[ValidateResult(), ValidateResult()],
            ),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL multi_rs(status)"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[{"a": 10}], [{"b": 20}]]

    def test_validate_skip_advances_past_a_result_set(self):
        connector, _ = _make_multi_step_connector(
            [
                {
                    "description": None,
                    "rows": [],
                    "nextset_descriptions": [
                        _desc(("a", int)),
                        _desc(("b", int)),
                    ],
                    "nextset_rows": [[(1,)], [(2,)]],
                    "nextset_returns": [True, True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(
                source_query="CALL multi_rs()",
                validate=[ValidateSkip(), ValidateResult()],
            ),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL multi_rs()"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[{"b": 2}]]
        assert result.step_origins == [
            StepOrigin(step_index=0, validate_entry=1),
        ]

    def test_too_few_result_sets_raises(self):
        # RS#0 = CALL ack, then a single DRS — short by one for a 2-entry list.
        connector, _ = _make_multi_step_connector(
            [
                {
                    "description": None,
                    "rows": [],
                    "nextset_descriptions": [_desc(("a", int))],
                    "nextset_rows": [[(1,)]],
                    "nextset_returns": [True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(
                source_query="CALL multi_rs()",
                validate=[ValidateResult(), ValidateResult()],
            ),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL multi_rs()"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "expects at least 2" in result.error

    def test_empty_result_set_preserved_for_mapping(self):
        # First DRS is a legitimate empty result set (description present,
        # zero rows) — must be preserved so the second entry maps to RS#2.
        connector, _ = _make_multi_step_connector(
            [
                {
                    "description": None,
                    "rows": [],
                    "nextset_descriptions": [
                        _desc(("a", int)),
                        _desc(("b", int)),
                    ],
                    "nextset_rows": [[], [(99,)]],
                    "nextset_returns": [True, True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(
                source_query="CALL multi_rs()",
                validate=[
                    ValidateResult(),
                    ValidateQuery(target_query="SELECT 1"),
                ],
            ),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL multi_rs()"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[], [{"b": 99}]]

    def test_extra_source_result_sets_dropped_with_warning_log(self, caplog):
        # RS#0 = empty CALL ack; then 3 DRSes but validate list only
        # consumes 2.  The trailing DRS is dropped with a WARNING log so
        # the YAML author sees the asymmetry and can decide whether to
        # add validate entries or use ValidateSkip explicitly.
        connector, _ = _make_multi_step_connector(
            [
                {
                    "description": None,
                    "rows": [],
                    "nextset_descriptions": [
                        _desc(("a", int)),
                        _desc(("b", int)),
                        _desc(("c", int)),
                    ],
                    "nextset_rows": [[(1,)], [(2,)], [(3,)]],
                    "nextset_returns": [True, True, True, False],
                },
            ],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(
                source_query="CALL multi_rs()",
                validate=[ValidateResult(), ValidateResult()],
            ),
        ]
        built = TeradataBuiltSQL(
            main_sql={0: "CALL multi_rs()"},
            validated_step_indices=[0],
        )

        with caplog.at_level(
            logging.WARNING,
            logger="test_runner.capture.sources.teradata",
        ):
            result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[{"a": 1}], [{"b": 2}]]
        matching = [
            rec for rec in caplog.records
            if "validate list only consumes 2" in rec.message
            and "dropping the trailing 1" in rec.message
        ]
        assert matching, [rec.message for rec in caplog.records]
        assert matching[0].levelname == "WARNING"


