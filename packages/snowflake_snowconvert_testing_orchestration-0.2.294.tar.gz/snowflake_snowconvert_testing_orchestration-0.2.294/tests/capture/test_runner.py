"""Integration tests for test_runner.capture.runner (with mocked executor)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from snowflake_code_unit_registry import CodeUnitRegistry

from test_runner.common.config import TestRunnerConfig
from test_runner.common.container import TestRunnerContainer
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import DatabaseExecutor
from test_runner.common.models import TestCaseResult
from test_runner.capture.runner import run_capture


class _FakeExecutor(DatabaseExecutor):
    """A fake executor that returns canned results instead of hitting a real DB."""

    def __init__(self, result: TestCaseResult | None = None) -> None:
        self._result = result or TestCaseResult(
            result_sets=[[{"Id": 1, "Name": "Widget"}]],
            row_counts=[1],
            success=True,
        )

    def close(self) -> None:
        pass

    def execute(self, sql: str, steps=None, fetch_stmts=None) -> TestCaseResult:
        return self._result


def _make_config(**overrides) -> TestRunnerConfig:
    defaults = dict(
        source_dialect=DatabaseDialect.SQL_SERVER,
        source_connection_raw={
            "host": "localhost",
            "database": "TestDB",
            "username": "sa",
            "password": "secret",
        },
    )
    defaults.update(overrides)
    return TestRunnerConfig(**defaults)


def _make_registry(executor=None):
    """Build a factory registry, optionally mocking the source executor."""
    container = TestRunnerContainer()
    registry = container.factory_registry()
    if executor is not None:
        factory = registry[DatabaseDialect.SQL_SERVER]
        factory.build_config = MagicMock(return_value=MagicMock())
        factory.create_executor = MagicMock(return_value=executor)
    return registry


def _stub_snowflake_factory(registry) -> None:
    """Replace the Snowflake factory with a stub whose executor has no connector.

    Lets ``run_capture`` satisfy its "Snowflake connection available" preflight
    check without actually talking to Snowflake.  The upload path short-circuits
    because ``sf_executor.connector is None``.
    """
    snowflake_factory = registry[DatabaseDialect.SNOWFLAKE]
    snowflake_factory.build_config = MagicMock(return_value=MagicMock())
    snowflake_executor = MagicMock()
    snowflake_executor.connector = None
    snowflake_factory.create_executor = MagicMock(return_value=snowflake_executor)


class TestRunCapture:
    def test_end_to_end_with_fake_executor(self, tmp_project: Path):
        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(_FakeExecutor()),
            project_root=tmp_project,
            keep_baselines=True,
        )

        assert stats.total == 4
        assert stats.succeeded == 4
        assert stats.failed == 0
        assert len(stats.baseline_files) == 4

        for path_str in stats.baseline_files:
            p = Path(path_str)
            assert p.exists()
            data = json.loads(p.read_text())
            assert "procedure" in data
            assert data["success"] is True

    def test_failed_execution_tracked(self, tmp_project: Path):
        fake = _FakeExecutor(TestCaseResult(
            result_sets=[], row_counts=[], success=False, error="Procedure not found",
        ))

        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(fake),
            project_root=tmp_project,
            keep_baselines=True,
        )

        assert stats.total == 4
        assert stats.succeeded == 0
        assert stats.failed == 4

        for path_str in stats.baseline_files:
            data = json.loads(Path(path_str).read_text())
            assert data["success"] is False

    def test_parameters_in_baseline(self, tmp_project: Path):
        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(_FakeExecutor()),
            project_root=tmp_project,
            keep_baselines=True,
        )

        orders_baselines = [p for p in stats.baseline_files if "GetCustomerOrders" in p]
        assert len(orders_baselines) == 3

        data = json.loads(Path(orders_baselines[0]).read_text())
        assert "customerId" in data["parameters"]
        assert "status" in data["parameters"]

    @pytest.mark.no_default_keep_baselines
    def test_default_requires_snowflake_connection(self, tmp_project: Path):
        """Without ``-c`` / ``--keep-baselines`` / ``--baseline-dir`` capture
        refuses to run because it has no place to put the baselines."""
        with pytest.raises(ValueError, match="--keep-baselines"):
            run_capture(
                config=_make_config(),
                factory_registry=_make_registry(_FakeExecutor()),
                project_root=tmp_project,
            )

    @pytest.mark.no_default_keep_baselines
    def test_default_uses_target_connection_from_config(self, tmp_project: Path):
        """If ``target_connection.name`` is configured, the default mode is OK."""
        registry = _make_registry(_FakeExecutor())
        _stub_snowflake_factory(registry)

        config = _make_config(target_connection_raw={"name": "my_sf", "mode": "name"})

        stats = run_capture(
            config=config,
            factory_registry=registry,
            project_root=tmp_project,
        )

        assert stats.total == 4
        for path_str in stats.baseline_files:
            assert not Path(path_str).exists(), (
                f"Baseline file should be deleted by default: {path_str}"
            )

    @pytest.mark.no_default_keep_baselines
    def test_default_cleans_up_tempdir(self, tmp_project: Path):
        """The default mode writes into an ephemeral tempdir and removes it
        before returning, so no baseline file survives ``run_capture``.
        """
        registry = _make_registry(_FakeExecutor())
        _stub_snowflake_factory(registry)

        stats = run_capture(
            config=_make_config(),
            factory_registry=registry,
            project_root=tmp_project,
            snowflake_connection="fake",
        )

        assert stats.total == 4
        assert stats.succeeded == 4
        for path_str in stats.baseline_files:
            assert not Path(path_str).exists(), (
                f"Baseline file should be deleted after default-mode capture: {path_str}"
            )

        artifacts_dir = tmp_project / "artifacts"
        leftover_baselines = list(artifacts_dir.glob("**/baselines/**/*.json"))
        assert leftover_baselines == [], (
            f"No baselines should be written under artifacts/ in default mode: "
            f"{leftover_baselines}"
        )

    @pytest.mark.no_default_keep_baselines
    def test_default_tempdir_name_encodes_pid(self, tmp_project: Path):
        """The ephemeral baseline dir name carries our PID so the sweeper
        can recognise crashed-run leftovers owned by this process."""
        import os

        from test_runner.capture.tempdir_sweeper import build_tempdir_prefix

        registry = _make_registry(_FakeExecutor())
        _stub_snowflake_factory(registry)

        stats = run_capture(
            config=_make_config(),
            factory_registry=registry,
            project_root=tmp_project,
            snowflake_connection="fake",
        )

        # Files are already deleted by this point, so assert on the path
        # string rather than on ``Path.resolve()`` (which would reach
        # out to the filesystem).
        expected_prefix = build_tempdir_prefix()
        assert expected_prefix == f"mto-baselines-{os.getpid()}-"
        for path_str in stats.baseline_files:
            assert expected_prefix in path_str, (
                f"Baseline path {path_str} not in a pid-tagged tempdir "
                f"(expected to contain {expected_prefix!r})"
            )

    def test_keep_baselines_writes_per_object_layout(self, tmp_project: Path):
        """``keep_baselines=True`` produces the legacy
        ``artifacts/**/baselines/`` layout, and files survive the call."""
        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(_FakeExecutor()),
            project_root=tmp_project,
            keep_baselines=True,
        )

        assert stats.total == 4
        assert len(stats.baseline_files) == 4
        artifacts_dir = tmp_project / "artifacts"
        written = list(artifacts_dir.glob("**/baselines/**/*.json"))
        assert written, "Expected baselines under artifacts/**/baselines/"
        for path_str in stats.baseline_files:
            assert Path(path_str).exists()
            assert str(artifacts_dir) in str(Path(path_str).resolve())

    def test_no_test_files_returns_empty_stats(self, tmp_path: Path):
        settings = tmp_path / "settings"
        settings.mkdir()
        (settings / "test_config.yaml").write_text(
            "source_platform: sqlserver\ntarget_platform: snowflake\n"
        )
        CodeUnitRegistry.init(str(tmp_path))

        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(_FakeExecutor()),
            project_root=tmp_path,
            keep_baselines=True,
        )

        assert stats.total == 0
        assert stats.baseline_files == []
