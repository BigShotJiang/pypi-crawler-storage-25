"""Tests for test_runner.capture.sources.teradata (mocked connector)."""

from __future__ import annotations

import decimal
import datetime
from typing import Any
from unittest.mock import MagicMock

import pytest

from test_runner.capture.sources.teradata import (
    TeradataExecutor,
    TeradataExecutorFactory,
    TeradataLiteralFormatter,
    _normalize_period_value,
    _build_row_dicts,
    _period_cols_from_cursor,
)
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.models import ValidationSteps


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_YAML_MAPPING = {
    "INTEGER": "NUMBER",
    "VARCHAR": "VARCHAR",
    "FLOAT": "FLOAT",
    "DECIMAL": "NUMBER",
    "TIMESTAMP": "TIMESTAMP_NTZ",
    "DATE": "DATE",
    "TIME": "TIME",
}


def _make_mock_connector(
    query_description: list[tuple] | None,
    query_rows: list[tuple],
    *,
    fetchone_value: tuple | None = None,
) -> MagicMock:
    """Create a mock Teradata connector.

    teradatasql uses Python type classes as type codes in cursor.description,
    e.g. (col_name, int, ...) instead of integer OIDs.
    """
    cursor = MagicMock()
    cursor.description = query_description
    cursor.fetchall.return_value = query_rows
    cursor.fetchone.return_value = fetchone_value
    cursor.nextset.return_value = False

    connection = MagicMock()
    connection.cursor.return_value = cursor

    connector = MagicMock()
    connector.connection = connection
    return connector


def _make_multi_step_connector(
    steps: list[dict],
) -> tuple[MagicMock, MagicMock]:
    """Create a mock connector where sequential cursor.execute calls
    change description/rows per *steps*.

    Each step dict may have:
      description: cursor.description after this execute
      rows: rows for fetchall / fetchone
      nextset_returns: list of bools for sequential nextset() calls (optional)
    """
    call_idx = {"i": 0}
    main_cursor = MagicMock()

    def _execute_side_effect(sql):
        idx = call_idx["i"]
        if idx < len(steps):
            step = steps[idx]
            main_cursor.description = step.get("description")
            main_cursor.columntypename = step.get("columntypename")
            main_cursor.fetchall.return_value = step.get("rows", [])
            main_cursor.fetchone.return_value = (
                step["rows"][0] if step.get("rows") else None
            )
            nextset_returns = step.get("nextset_returns")
            if nextset_returns is not None:
                main_cursor.nextset.side_effect = list(nextset_returns)
            else:
                main_cursor.nextset.return_value = False
        else:
            main_cursor.description = None
            main_cursor.columntypename = None
            main_cursor.fetchall.return_value = []
            main_cursor.fetchone.return_value = None
        call_idx["i"] += 1

    main_cursor.execute = MagicMock(side_effect=_execute_side_effect)
    main_cursor.close = MagicMock()

    connection = MagicMock()
    connection.cursor.return_value = main_cursor

    connector = MagicMock()
    connector.connection = connection
    return connector, main_cursor


# ---------------------------------------------------------------------------
# TeradataLiteralFormatter
# ---------------------------------------------------------------------------

class TestTeradataLiteralFormatter:
    def test_null(self):
        fmt = TeradataLiteralFormatter()
        assert fmt.format_literal(None) == "NULL"

    def test_bool_true_renders_as_1(self):
        fmt = TeradataLiteralFormatter()
        assert fmt.format_literal(True) == "1"

    def test_bool_false_renders_as_0(self):
        fmt = TeradataLiteralFormatter()
        assert fmt.format_literal(False) == "0"

    def test_integer(self):
        fmt = TeradataLiteralFormatter()
        assert fmt.format_literal(42) == "42"

    def test_float(self):
        fmt = TeradataLiteralFormatter()
        assert fmt.format_literal(3.14) == "3.14"

    def test_string(self):
        fmt = TeradataLiteralFormatter()
        assert fmt.format_literal("hello") == "'hello'"

    def test_string_with_single_quotes(self):
        fmt = TeradataLiteralFormatter()
        assert fmt.format_literal("it's") == "'it''s'"

    def test_non_string_non_numeric_value(self):
        fmt = TeradataLiteralFormatter()
        result = fmt.format_literal(datetime.date(2026, 1, 1))
        assert result == "'2026-01-01'"


# ---------------------------------------------------------------------------
# TeradataExecutorFactory
# ---------------------------------------------------------------------------

class TestTeradataExecutorFactory:
    def test_dialect(self):
        factory = TeradataExecutorFactory()
        assert factory.dialect == DatabaseDialect.TERADATA

    def test_build_config_defaults(self):
        factory = TeradataExecutorFactory()
        cfg = factory.build_config({})
        assert cfg.host == "localhost"
        assert cfg.database == ""

    def test_build_config_custom(self):
        factory = TeradataExecutorFactory()
        cfg = factory.build_config({
            "host": "td-server.example.com",
            "database": "mydb",
            "username": "admin",
            "password": "s3cret",
        })
        assert cfg.host == "td-server.example.com"
        assert cfg.database == "mydb"
        assert cfg.username == "admin"
        assert cfg.password == "s3cret"

    def test_build_config_scai_keys(self):
        """SCAI writes 'user' and 'server_url' -- build_config must accept them."""
        factory = TeradataExecutorFactory()
        cfg = factory.build_config({
            "server_url": "td-server.example.com",
            "database": "mydb",
            "user": "admin",
            "password": "s3cret",
        })
        assert cfg.host == "td-server.example.com"
        assert cfg.username == "admin"

    def test_build_config_canonical_keys_take_precedence(self):
        """When both SCAI and canonical keys are present, canonical wins."""
        factory = TeradataExecutorFactory()
        cfg = factory.build_config({
            "host": "canonical-host",
            "server_url": "scai-host",
            "username": "canonical-user",
            "user": "scai-user",
        })
        assert cfg.host == "canonical-host"
        assert cfg.username == "canonical-user"

    def test_create_literal_formatter_returns_teradata_formatter(self):
        factory = TeradataExecutorFactory()
        fmt = factory.create_literal_formatter()
        assert isinstance(fmt, TeradataLiteralFormatter)


# ---------------------------------------------------------------------------
# TeradataExecutor - basic execution
# ---------------------------------------------------------------------------

class TestTeradataExecutor:
    def test_execute_returns_rows_via_collect_all(self):
        """Without outputs, _collect_all_result_sets is used."""
        desc = [("product_id", int, None, None, None, None), ("name", str, None, None, None, None)]
        rows = [(1, "Widget"), (2, "Gadget")]
        connector = _make_mock_connector(desc, rows)

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL get_products('Electronics')")

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [
            {"product_id": 1, "name": "Widget"},
            {"product_id": 2, "name": "Gadget"},
        ]
        assert result.row_counts == [2]

    def test_execute_returns_column_types_via_python_type_codes(self):
        desc = [("id", int, None, None, None, None), ("name", str, None, None, None, None)]
        rows = [(1, "Widget")]
        connector = _make_mock_connector(desc, rows)

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("SELECT 1")

        assert result.column_types[0]["ID"] == "NUMBER"
        assert result.column_types[0]["NAME"] == "VARCHAR"

    def test_execute_skips_empty_result_sets(self):
        """_collect_all_result_sets only appends result sets that have rows."""
        connector = _make_mock_connector(
            [("status", str, None, None, None, None)], [],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL empty_proc()")

        assert result.success is True
        assert result.result_sets == []
        assert result.row_counts == []

    def test_execute_handles_error(self):
        connector = MagicMock()
        connection = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = RuntimeError("Connection refused")
        connection.cursor.return_value = cursor
        connector.connection = connection

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL boom()")

        assert result.success is False
        assert "Connection refused" in result.error

    def test_execute_no_description_collects_nothing(self):
        connector = _make_mock_connector(None, [])

        executor = TeradataExecutor(connector)
        result = executor.execute("CALL dml_proc()")

        assert result.success is True
        assert result.result_sets == []

    def test_close_delegates_to_connector(self):
        connector = MagicMock()
        executor = TeradataExecutor(connector)
        executor.close()
        connector.close.assert_called_once()

    def test_connector_property(self):
        connector = MagicMock()
        executor = TeradataExecutor(connector)
        assert executor.connector is connector

    def test_no_datatypes_mapping_uses_raw_base_type(self):
        desc = [("col", int, None, None, None, None)]
        rows = [(1,)]
        connector = _make_mock_connector(desc, rows)

        executor = TeradataExecutor(connector, datatypes_mappings=None)
        result = executor.execute("SELECT 1")
        assert result.column_types[0]["COL"] == "INTEGER"

    def test_decimal_type_mapped(self):
        desc = [("amount", decimal.Decimal, None, None, None, None)]
        rows = [(decimal.Decimal("123.45"),)]
        connector = _make_mock_connector(desc, rows)

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("SELECT 123.45")
        assert result.column_types[0]["AMOUNT"] == "NUMBER"

    def test_unknown_type_code_falls_back_to_varchar(self):
        desc = [("col", object, None, None, None, None)]
        rows = [("x",)]
        connector = _make_mock_connector(desc, rows)

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("SELECT 'x'")
        assert result.column_types[0]["COL"] == "VARCHAR"

    def test_collect_all_with_nextset(self):
        """_collect_all_result_sets walks nextset() to gather multiple result sets."""
        cursor = MagicMock()
        call_idx = {"i": 0}
        result_sets_data = [
            {
                "description": None,
                "rows": [],
            },
            {
                "description": [("id", int, None, None, None, None), ("name", str, None, None, None, None)],
                "rows": [(1, "Alpha"), (2, "Beta")],
            },
        ]

        def _nextset():
            call_idx["i"] += 1
            if call_idx["i"] < len(result_sets_data):
                rs = result_sets_data[call_idx["i"]]
                cursor.description = rs["description"]
                cursor.fetchall.return_value = rs["rows"]
                return True
            return False

        initial = result_sets_data[0]
        cursor.description = initial["description"]
        cursor.fetchall.return_value = initial["rows"]
        cursor.nextset = MagicMock(side_effect=_nextset)
        cursor.close = MagicMock()

        connection = MagicMock()
        connection.cursor.return_value = cursor
        connector = MagicMock()
        connector.connection = connection

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL multi_result_proc()")

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [
            {"id": 1, "name": "Alpha"},
            {"id": 2, "name": "Beta"},
        ]
        assert result.column_types[0]["ID"] == "NUMBER"


# ---------------------------------------------------------------------------
# TeradataExecutor - template-driven output capture
# ---------------------------------------------------------------------------

class TestTeradataExecutorOutputParams:
    """Scalar OUT/INOUT parameters via output_parameters + fetch_stmts."""

    def test_scalar_output_params_extracted(self):
        """output_parameters extracts named columns from CALL result into output_params."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": [
                        ("p_review_count", int, None, None, None, None),
                        ("p_rating_sum", int, None, None, None, None),
                    ],
                    "rows": [(3, 12)],
                },
            ],
        )

        steps = ValidationSteps(
            run="CALL get_review_stats(101, p_review_count, p_rating_sum)",
            output_parameters=["p_review_count", "p_rating_sum"],
        )
        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute(
            "CALL get_review_stats(101, p_review_count, p_rating_sum)",
            steps=steps,
            fetch_stmts=[],
        )

        assert result.success is True
        assert result.output_params == {"p_review_count": 3, "p_rating_sum": 12}
        assert result.output_param_types["p_review_count"] == "NUMBER"
        assert result.output_param_types["p_rating_sum"] == "NUMBER"
        assert result.result_sets == []

    def test_scalar_params_case_insensitive(self):
        """Column name matching is case-insensitive."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": [("P_REVIEW_COUNT", int, None, None, None, None)],
                    "rows": [(42,)],
                },
            ],
        )

        steps = ValidationSteps(
            run="CALL proc(101, p_review_count)",
            output_parameters=["p_review_count"],
        )
        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute(
            "CALL proc(101, p_review_count)", steps=steps, fetch_stmts=[],
        )

        assert result.output_params == {"p_review_count": 42}

    def test_no_description_extracts_nothing(self):
        """When cursor.description is None, no output params are extracted."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},
            ],
        )

        steps = ValidationSteps(
            run="CALL proc()",
            output_parameters=["result"],
        )
        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL proc()", steps=steps, fetch_stmts=[])

        assert result.success is True
        assert result.output_params is None

    def test_no_row_extracts_nothing(self):
        """When fetchone returns None, no output params are extracted."""
        connector, _ = _make_multi_step_connector(
            [
                {
                    "description": [("result", int, None, None, None, None)],
                    "rows": [],
                },
            ],
        )

        steps = ValidationSteps(
            run="CALL proc()",
            output_parameters=["result"],
        )
        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL proc()", steps=steps, fetch_stmts=[])

        assert result.success is True
        assert result.output_params is None


class TestTeradataExecutorFetchStmts:
    """Template-driven fetch statements (output.tables)."""

    def test_table_fetch_captured(self):
        """A SELECT * FROM table statement captures the table result set."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},
                {
                    "description": [("id", int, None, None, None, None)],
                    "rows": [(10,), (20,)],
                },
            ],
        )

        steps = ValidationSteps(
            run="CALL proc_with_temp()",
            output_tables=["volatile_results"],
        )
        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute(
            "CALL proc_with_temp()",
            steps=steps,
            fetch_stmts=["SELECT * FROM volatile_results"],
        )

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.row_counts == [2]

    def test_scalar_params_plus_table_fetch(self):
        """Combined: scalar output params + table fetch in one call."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {
                    "description": [
                        ("p_count", int, None, None, None, None),
                        ("p_total", decimal.Decimal, None, None, None, None),
                    ],
                    "rows": [(5, decimal.Decimal("250.00"))],
                },
                {
                    "description": [
                        ("order_id", int, None, None, None, None),
                        ("amount", decimal.Decimal, None, None, None, None),
                    ],
                    "rows": [(1, decimal.Decimal("50.00"))],
                },
            ],
        )

        steps = ValidationSteps(
            run="CALL get_order_summary(101, p_count, p_total)",
            output_parameters=["p_count", "p_total"],
            output_tables=["order_details"],
        )
        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute(
            "CALL get_order_summary(101, p_count, p_total)",
            steps=steps,
            fetch_stmts=["SELECT * FROM order_details"],
        )

        assert result.success is True
        assert result.output_params == {"p_count": 5, "p_total": decimal.Decimal("250.00")}
        assert result.output_param_types["p_count"] == "NUMBER"
        assert result.output_param_types["p_total"] == "NUMBER"
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [
            {"order_id": 1, "amount": decimal.Decimal("50.00")},
        ]

    def test_no_fetch_stmts_no_output_params_uses_collect_all(self):
        """Without fetch_stmts or output_parameters, _collect_all_result_sets is used."""
        connector, _ = _make_multi_step_connector([
            {
                "description": [("total", int, None, None, None, None)],
                "rows": [(100,)],
            },
        ])

        executor = TeradataExecutor(connector)
        result = executor.execute("SELECT COUNT(*) AS total")

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.output_params is None

    def test_empty_table_result(self):
        """A table with no rows still produces an empty result set."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},
                {
                    "description": [("id", int, None, None, None, None)],
                    "rows": [],
                },
            ],
        )

        steps = ValidationSteps(
            run="CALL proc()",
            output_tables=["volatile_results"],
        )
        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute(
            "CALL proc()", steps=steps,
            fetch_stmts=["SELECT * FROM volatile_results"],
        )

        assert result.success is True
        assert result.result_sets == [[]]
        assert result.row_counts == [0]


# ---------------------------------------------------------------------------
# render_output_fetch_statements for Teradata
# ---------------------------------------------------------------------------

class TestRenderOutputFetchStatements:
    """Tests for template-driven rendering of fetch statements."""

    def test_teradata_table(self):
        from test_runner.common.template import render_output_fetch_statements
        steps = ValidationSteps(
            run="CALL proc()",
            output_tables=["volatile_results"],
        )
        stmts = render_output_fetch_statements(steps, [], "teradata")
        assert stmts == ["SELECT * FROM volatile_results"]

    def test_teradata_table_with_placeholder(self):
        from test_runner.common.template import render_output_fetch_statements
        steps = ValidationSteps(
            run="CALL proc({0})",
            output_tables=["{0}"],
        )
        stmts = render_output_fetch_statements(steps, ["my_table"], "teradata")
        assert stmts == ["SELECT * FROM my_table"]

    def test_no_outputs_returns_empty(self):
        from test_runner.common.template import render_output_fetch_statements
        steps = ValidationSteps(run="CALL proc()")
        stmts = render_output_fetch_statements(steps, [], "teradata")
        assert stmts == []


# ---------------------------------------------------------------------------
# render_capture_sql / render_outputs_sql for Teradata
# ---------------------------------------------------------------------------

class TestRenderCaptureSql:
    """Tests for the capture_outputs_teradata.sql.j2 template."""

    def test_capture_sql_with_output_params_uses_template(self):
        from test_runner.common.template import render_capture_sql
        steps = ValidationSteps(
            run="CALL get_review_stats({0}, {1}, {2})",
            output_parameters=["p_review_count", "p_rating_sum"],
        )
        sql = render_capture_sql(steps, [101, 0, 0], "teradata")
        assert sql.strip() == "CALL get_review_stats(101, 0, 0)"

    def test_capture_sql_with_pre_execute(self):
        from test_runner.common.template import render_capture_sql
        steps = ValidationSteps(
            pre_execute="SET SESSION DATEFORM = ANSIDATE;",
            run="CALL get_review_stats({0}, {1}, {2})",
            output_parameters=["p_review_count", "p_rating_sum"],
        )
        sql = render_capture_sql(steps, [101, 0, 0], "teradata")
        assert "SET SESSION DATEFORM = ANSIDATE;" in sql
        assert "CALL get_review_stats(101, 0, 0)" in sql

    def test_capture_sql_without_output_params_uses_full_sql(self):
        from test_runner.common.template import render_capture_sql
        steps = ValidationSteps(
            run="CALL get_products({0})",
        )
        sql = render_capture_sql(steps, ["Electronics"], "teradata")
        assert "CALL get_products('Electronics')" in sql

    def test_capture_sql_macro_execute_no_params(self):
        from test_runner.common.template import render_capture_sql
        steps = ValidationSteps(run="EXECUTE mydb.dbo.GetSalesSummary")
        sql = render_capture_sql(steps, [], "teradata")
        assert sql.strip() == "EXECUTE mydb.dbo.GetSalesSummary"

    def test_capture_sql_macro_execute_with_params(self):
        from test_runner.common.template import render_capture_sql
        steps = ValidationSteps(run="EXECUTE mydb.dbo.GetRegionReport({0}, {1})")
        sql = render_capture_sql(steps, [100, "2025-01-01"], "teradata")
        assert "EXECUTE mydb.dbo.GetRegionReport(100, '2025-01-01')" in sql

    def test_capture_sql_macro_execute_with_pre_execute(self):
        from test_runner.common.template import render_capture_sql
        steps = ValidationSteps(
            pre_execute="SET SESSION DATEFORM = ANSIDATE;",
            run="EXECUTE mydb.dbo.GetSalesSummary",
        )
        sql = render_capture_sql(steps, [], "teradata")
        assert "SET SESSION DATEFORM = ANSIDATE;" in sql
        assert "EXECUTE mydb.dbo.GetSalesSummary" in sql


# ---------------------------------------------------------------------------
# TeradataExecutor - macro execution (EXECUTE instead of CALL)
# ---------------------------------------------------------------------------

class TestTeradataExecutorMacro:
    """Teradata macros use EXECUTE and return result sets directly
    (no empty first set like DYNAMIC RESULT SETS procedures)."""

    def test_macro_execute_returns_rows(self):
        desc = [
            ("region", str, None, None, None, None),
            ("total_sales", int, None, None, None, None),
        ]
        rows = [("North", 5000), ("South", 3200)]
        connector = _make_mock_connector(desc, rows)

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("EXECUTE mydb.dbo.GetSalesSummary")

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [
            {"region": "North", "total_sales": 5000},
            {"region": "South", "total_sales": 3200},
        ]
        assert result.row_counts == [2]

    def test_macro_execute_with_parameters(self):
        desc = [
            ("product_id", int, None, None, None, None),
            ("quantity", int, None, None, None, None),
        ]
        rows = [(1, 42), (2, 17)]
        connector = _make_mock_connector(desc, rows)

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("EXECUTE mydb.dbo.GetRegionReport(100, '2025-01-01')")

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.row_counts == [2]

    def test_macro_execute_empty_result(self):
        connector = _make_mock_connector(
            [("status", str, None, None, None, None)], [],
        )

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("EXECUTE mydb.dbo.EmptyMacro")

        assert result.success is True
        assert result.result_sets == []

    def test_macro_execute_multiple_result_sets(self):
        """Macros can contain multiple SELECT statements producing multiple result sets."""
        cursor = MagicMock()
        call_idx = {"i": 0}
        result_sets_data = [
            {
                "description": [("id", int, None, None, None, None)],
                "rows": [(1,), (2,)],
            },
            {
                "description": [("name", str, None, None, None, None)],
                "rows": [("Alpha",), ("Beta",)],
            },
        ]

        def _nextset():
            call_idx["i"] += 1
            if call_idx["i"] < len(result_sets_data):
                rs = result_sets_data[call_idx["i"]]
                cursor.description = rs["description"]
                cursor.fetchall.return_value = rs["rows"]
                return True
            return False

        initial = result_sets_data[0]
        cursor.description = initial["description"]
        cursor.fetchall.return_value = initial["rows"]
        cursor.nextset = MagicMock(side_effect=_nextset)
        cursor.close = MagicMock()

        connection = MagicMock()
        connection.cursor.return_value = cursor

        connector = MagicMock()
        connector.connection = connection

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("EXECUTE mydb.dbo.MultiResultMacro")

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == [{"id": 1}, {"id": 2}]
        assert result.result_sets[1] == [{"name": "Alpha"}, {"name": "Beta"}]

    def test_macro_execute_error_handling(self):
        connector = MagicMock()
        connection = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = RuntimeError("Macro not found")
        connection.cursor.return_value = cursor
        connector.connection = connection

        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute("EXECUTE mydb.dbo.NonexistentMacro")

        assert result.success is False
        assert "Macro not found" in result.error

    def test_macro_execute_with_fetch_stmts(self):
        """Macros that populate volatile tables can use fetch_stmts to read them."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},
                {
                    "description": [("id", int, None, None, None, None)],
                    "rows": [(10,), (20,)],
                },
            ],
        )

        steps = ValidationSteps(
            run="EXECUTE mydb.dbo.PopulateTempMacro",
            output_tables=["volatile_results"],
        )
        executor = TeradataExecutor(connector, _YAML_MAPPING)
        result = executor.execute(
            "EXECUTE mydb.dbo.PopulateTempMacro",
            steps=steps,
            fetch_stmts=["SELECT * FROM volatile_results"],
        )

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.row_counts == [2]

# ---------------------------------------------------------------------------
# PERIOD value normalization
# ---------------------------------------------------------------------------

class TestPeriodColsFromCursor:
    def test_detects_period_date_column(self):
        cursor = MagicMock()
        cursor.columntypename = ["INTEGER", "PERIOD(DATE)"]
        cols = _period_cols_from_cursor(cursor, ["product_id", "sale_period"])
        assert cols == {"sale_period"}

    def test_detects_period_timestamp_column(self):
        cursor = MagicMock()
        cursor.columntypename = ["PERIOD(TIMESTAMP)", "VARCHAR"]
        cols = _period_cols_from_cursor(cursor, ["ts_range", "name"])
        assert cols == {"ts_range"}

    def test_detects_period_time_column(self):
        cursor = MagicMock()
        cursor.columntypename = ["PERIOD(TIME)", "INTEGER"]
        cols = _period_cols_from_cursor(cursor, ["shift", "id"])
        assert cols == {"shift"}

    def test_no_period_columns(self):
        cursor = MagicMock()
        cursor.columntypename = ["INTEGER", "VARCHAR", "DATE"]
        cols = _period_cols_from_cursor(cursor, ["id", "name", "created"])
        assert cols == set()

    def test_missing_columntypename_returns_empty(self):
        """Plain MagicMock without columntypename configured → empty set."""
        cursor = MagicMock(spec=[])  # no columntypename attribute
        cols = _period_cols_from_cursor(cursor, ["id", "period_col"])
        assert cols == set()

    def test_non_list_columntypename_returns_empty(self):
        cursor = MagicMock()
        cursor.columntypename = None
        cols = _period_cols_from_cursor(cursor, ["col"])
        assert cols == set()


class TestNormalizePeriodValue:
    def test_date_period(self):
        assert _normalize_period_value("2024-01-01,2024-06-30") == "2024-01-01*2024-06-30"

    def test_timestamp_period(self):
        result = _normalize_period_value("2024-01-01 10:00:00,2024-06-30 18:00:00")
        assert result == "2024-01-01 10:00:00*2024-06-30 18:00:00"

    def test_time_period(self):
        assert _normalize_period_value("10:00:00,18:00:00") == "10:00:00*18:00:00"

    def test_no_comma_returns_unchanged(self):
        assert _normalize_period_value("no-comma-value") == "no-comma-value"

    def test_whitespace_around_comma_is_stripped(self):
        assert _normalize_period_value("2024-01-01, 2024-06-30") == "2024-01-01*2024-06-30"


class TestBuildRowDicts:
    def test_normalizes_period_column(self):
        rows = [(1, "2024-01-01,2024-06-30"), (2, "2024-07-01,2024-12-31")]
        result = _build_row_dicts(["id", "sale_period"], rows, {"sale_period"})
        assert result[0]["sale_period"] == "2024-01-01*2024-06-30"
        assert result[1]["sale_period"] == "2024-07-01*2024-12-31"

    def test_non_period_columns_unchanged(self):
        rows = [(1, "Widget", "2024-01-01,2024-06-30")]
        result = _build_row_dicts(["id", "name", "sale_period"], rows, {"sale_period"})
        assert result[0]["id"] == 1
        assert result[0]["name"] == "Widget"

    def test_empty_period_cols_plain_zip(self):
        rows = [(1, "Widget")]
        result = _build_row_dicts(["id", "name"], rows, set())
        assert result == [{"id": 1, "name": "Widget"}]

    def test_empty_rows_returns_empty(self):
        assert _build_row_dicts(["col"], [], {"col"}) == []

    def test_none_value_in_period_column_skipped(self):
        rows = [(1, "2024-01-01,2024-06-30"), (2, None)]
        result = _build_row_dicts(["id", "period_col"], rows, {"period_col"})
        assert result[0]["period_col"] == "2024-01-01*2024-06-30"
        assert result[1]["period_col"] is None


class TestTeradataExecutorPeriodNormalization:
    """Integration: PERIOD strings are normalized when collected via execute()."""

    def _make_connector_with_period(self, desc, rows, columntypenames):
        cursor = MagicMock()
        cursor.description = desc
        cursor.columntypename = columntypenames
        cursor.fetchall.return_value = rows
        cursor.nextset.return_value = False
        cursor.close = MagicMock()
        conn = MagicMock()
        conn.cursor.return_value = cursor
        connector = MagicMock()
        connector.connection = conn
        return connector

    def test_period_date_normalized_in_collect_all(self):
        desc = [
            ("product_id", int, None, None, None, None),
            ("sale_period", str, None, None, None, None),
        ]
        rows = [(1, "2024-01-01,2024-06-30"), (2, "2024-07-01,2024-12-31")]
        connector = self._make_connector_with_period(
            desc, rows, ["INTEGER", "PERIOD(DATE)"]
        )
        result = TeradataExecutor(connector, _YAML_MAPPING).execute("CALL get_products_on_sale()")
        assert result.result_sets[0][0]["sale_period"] == "2024-01-01*2024-06-30"
        assert result.result_sets[0][1]["sale_period"] == "2024-07-01*2024-12-31"

    def test_period_timestamp_normalized(self):
        desc = [("ts_period", str, None, None, None, None)]
        rows = [("2024-01-01 08:00:00,2024-01-01 17:00:00",)]
        connector = self._make_connector_with_period(
            desc, rows, ["PERIOD(TIMESTAMP)"]
        )
        result = TeradataExecutor(connector, _YAML_MAPPING).execute("CALL get_shift()")
        assert result.result_sets[0][0]["ts_period"] == "2024-01-01 08:00:00*2024-01-01 17:00:00"

    def test_non_period_varchar_unchanged(self):
        desc = [("name", str, None, None, None, None)]
        rows = [("Widget",)]
        connector = self._make_connector_with_period(desc, rows, ["VARCHAR"])
        result = TeradataExecutor(connector, _YAML_MAPPING).execute("SELECT name FROM products")
        assert result.result_sets[0][0]["name"] == "Widget"

    def test_period_normalized_in_append_result_set(self):
        """Period normalization also applies to fetch_stmts result sets."""
        connector, _ = _make_multi_step_connector([
            {"description": None, "rows": []},
            {
                "description": [
                    ("product_id", int, None, None, None, None),
                    ("avail_period", str, None, None, None, None),
                ],
                "rows": [(10, "2024-01-01,2024-12-31")],
                "columntypename": ["INTEGER", "PERIOD(DATE)"],
            },
        ])

        steps = ValidationSteps(run="CALL proc()", output_tables=["availability"])
        result = TeradataExecutor(connector, _YAML_MAPPING).execute(
            "CALL proc()", steps=steps, fetch_stmts=["SELECT * FROM availability"],
        )
        assert result.result_sets[0][0]["avail_period"] == "2024-01-01*2024-12-31"
