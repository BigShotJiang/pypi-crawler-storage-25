"""Per-directory fixtures for capture tests."""

from __future__ import annotations

import functools

import pytest


@pytest.fixture(autouse=True)
def _default_keep_baselines(request: pytest.FixtureRequest, monkeypatch: pytest.MonkeyPatch) -> None:
    """Default ``run_capture`` calls in capture tests to ``keep_baselines=True``.

    The production default for ``run_capture`` is Snowflake-only (ephemeral
    tempdir), which requires a live Snowflake connector.  The bulk of
    capture tests run with fake executors and assert that baseline JSON
    survives on disk so they can inspect it.  Rather than thread
    ``keep_baselines=True`` through every call site, this fixture preserves
    the legacy on-disk behavior for any capture-test call that does not
    explicitly opt out.

    The wrapper is installed on the ``run_capture`` symbol that each test
    module imported (``from test_runner.capture.runner import run_capture``),
    so ``monkeypatch.setattr`` on the test module's namespace is what makes
    the override visible.

    Tests that want to exercise the new default (ephemeral mode) should not
    use the ``run_capture`` module symbol -- call ``real_run_capture`` from
    this fixture, or import via a different alias.
    """
    # Skip wrapping for tests that explicitly opt out by marker, so they can
    # exercise the new default behavior.
    if request.node.get_closest_marker("no_default_keep_baselines"):
        return

    from test_runner.capture import runner as _capture_runner

    real_run_capture = _capture_runner.run_capture

    @functools.wraps(real_run_capture)
    def _wrapped(*args, **kwargs):
        kwargs.setdefault("keep_baselines", True)
        return real_run_capture(*args, **kwargs)

    # Patch the symbol in each capture-test module that imported it.  Doing
    # this on the test module's namespace catches the ``from ... import
    # run_capture`` pattern, which a ``setattr`` on the source module would
    # miss (the name was already bound at import time).
    module = request.module
    if hasattr(module, "run_capture"):
        monkeypatch.setattr(module, "run_capture", _wrapped)
