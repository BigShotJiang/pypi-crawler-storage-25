"""Tests for RedshiftExecutor.execute_steps() with mocked cursors."""

from __future__ import annotations

from unittest.mock import MagicMock

from test_runner.capture.sources.redshift import RedshiftExecutor
from test_runner.common.builders.models import RedshiftBuiltSQL
from test_runner.common.models.capture_result import StepOrigin
from test_runner.common.models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    TableStep,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_YAML_MAPPING = {
    "INT4": "NUMBER",
    "INT8": "NUMBER",
    "VARCHAR": "VARCHAR",
    "NUMERIC": "NUMBER",
    "FLOAT8": "FLOAT",
    "BOOL": "BOOLEAN",
}


def _make_multi_step_connector(
    steps: list[dict],
    pg_type_rows: list[tuple] | None = None,
) -> tuple[MagicMock, MagicMock]:
    """Create a mock connector where sequential cursor.execute calls
    change description/rows per *steps*.

    The first ``connection.cursor()`` call returns the main cursor;
    subsequent calls return a separate meta cursor for
    ``_describe_types`` pg_catalog lookups.
    """
    call_idx = {"i": 0}
    main_cursor = MagicMock()

    def _execute_side_effect(sql):
        idx = call_idx["i"]
        if idx < len(steps):
            step = steps[idx]
            main_cursor.description = step.get("description")
            main_cursor.fetchall.return_value = step.get("rows", [])
            main_cursor.fetchone.return_value = (
                step["rows"][0] if step.get("rows") else None
            )
        else:
            main_cursor.description = None
            main_cursor.fetchall.return_value = []
            main_cursor.fetchone.return_value = None
        call_idx["i"] += 1

    main_cursor.execute = MagicMock(side_effect=_execute_side_effect)
    main_cursor.close = MagicMock()

    meta_cursor = MagicMock()
    meta_cursor.fetchall.return_value = pg_type_rows or []

    cursor_call_idx = {"i": 0}

    def _cursor_side_effect():
        idx = cursor_call_idx["i"]
        cursor_call_idx["i"] += 1
        return main_cursor if idx == 0 else meta_cursor

    connection = MagicMock()
    connection.cursor = MagicMock(side_effect=_cursor_side_effect)
    connection.autocommit = True

    connector = MagicMock()
    connector.connection = connection
    return connector, main_cursor


# ---------------------------------------------------------------------------
# Basic execution
# ---------------------------------------------------------------------------

class TestExecuteStepsBasic:
    def test_sequential_execution(self):
        """Sequential execution of main_sql dict entries with results captured."""
        connector, main_cursor = _make_multi_step_connector(
            [
                # Step 0: SELECT * FROM table
                {
                    "description": [("id", 23, None, None, None, None)],
                    "rows": [(1,), (2,)],
                },
            ],
            pg_type_rows=[(23, "int4")],
        )

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        steps = [TableStep(source_table="#temp")]
        built = RedshiftBuiltSQL(
            main_sql={0: "SELECT * FROM #temp"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"id": 1}, {"id": 2}]
        assert result.row_counts == [2]

    def test_target_only_step_skipped(self):
        """A step not in main_sql (target-only) is not executed."""
        connector, main_cursor = _make_multi_step_connector(
            [
                # Step 1: query (step 0 is target-only, not in main_sql)
                {
                    "description": [("val", 23, None, None, None, None)],
                    "rows": [(42,)],
                },
            ],
            pg_type_rows=[(23, "int4")],
        )

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(target_query="LET x := 1", validate=False),  # target-only
            QueryStep(source_query="SELECT 42 AS val"),
        ]
        built = RedshiftBuiltSQL(
            main_sql={1: "SELECT 42 AS val"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"val": 42}]


# ---------------------------------------------------------------------------
# Step type coverage
# ---------------------------------------------------------------------------

class TestParamStep:
    def test_inout_extraction(self):
        """ParamStep extracts INOUT params from previous CALL result."""
        connector, main_cursor = _make_multi_step_connector(
            [
                # Step 0: CALL returns INOUT
                {
                    "description": [
                        ("result", 23, None, None, None, None),
                        ("status", 1043, None, None, None, None),
                    ],
                    "rows": [(21, "ok")],
                },
                # Step 1 is ParamStep — no SQL executed
            ],
            pg_type_rows=[(23, "int4"), (1043, "varchar")],
        )

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL fibonacci(8)", validate=False),
            ParamStep(source_params=["result"]),
        ]
        built = RedshiftBuiltSQL(
            main_sql={0: "CALL fibonacci(8)"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"result": 21}]


class TestCursorStep:
    def test_fetch_all_captured(self):
        """CursorStep FETCH ALL captured independently."""
        connector, main_cursor = _make_multi_step_connector(
            [
                # Step 0: CALL (no validate)
                {"description": None, "rows": []},
                # Step 1: FETCH ALL FROM cursor
                {
                    "description": [("sellerid", 23, None, None, None, None)],
                    "rows": [(1,), (2,)],
                },
            ],
            pg_type_rows=[(23, "int4")],
        )

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL get_sales('North', 'mycursor')", validate=False),
            CursorStep(source_cursor="mycursor"),
        ]
        built = RedshiftBuiltSQL(
            main_sql={0: "CALL get_sales('North', 'mycursor')", 1: "FETCH ALL FROM mycursor"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"sellerid": 1}, {"sellerid": 2}]


class TestTableStep:
    def test_select_captured(self):
        """TableStep SELECT * FROM captured independently."""
        connector, main_cursor = _make_multi_step_connector(
            [
                # Step 0: CALL (no validate)
                {"description": None, "rows": []},
                # Step 1: SELECT * FROM #temp
                {
                    "description": [("id", 23, None, None, None, None)],
                    "rows": [(10,), (20,)],
                },
            ],
            pg_type_rows=[(23, "int4")],
        )

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL proc()", validate=False),
            TableStep(source_table="#temp"),
        ]
        built = RedshiftBuiltSQL(
            main_sql={0: "CALL proc()", 1: "SELECT * FROM #temp"},
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"id": 10}, {"id": 20}]


class TestCombined:
    def test_call_param_cursor(self):
        """Combined: CALL + ParamStep + CursorStep in sequence."""
        connector, main_cursor = _make_multi_step_connector(
            [
                # Step 0: CALL returns INOUT params
                {
                    "description": [
                        ("total_sales", 23, None, None, None, None),
                        ("cursor_name", 1043, None, None, None, None),
                    ],
                    "rows": [(42000, "sales_cursor")],
                },
                # Step 1: ParamStep — no SQL
                # Step 2: FETCH ALL FROM cursor
                {
                    "description": [
                        ("sellerid", 23, None, None, None, None),
                        ("amount", 23, None, None, None, None),
                    ],
                    "rows": [(1, 500)],
                },
            ],
            pg_type_rows=[(23, "int4"), (1043, "varchar")],
        )

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        steps = [
            QueryStep(source_query="CALL get_summary('North', 0, 'sales_cursor')", validate=False),
            ParamStep(source_params=["total_sales"]),
            CursorStep(source_cursor="sales_cursor"),
        ]
        built = RedshiftBuiltSQL(
            main_sql={
                0: "CALL get_summary('North', 0, 'sales_cursor')",
                2: "FETCH ALL FROM sales_cursor",
            },
            validated_step_indices=[1, 2],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        # ParamStep synthesized result
        assert result.result_sets[0] == [{"total_sales": 42000}]
        # CursorStep result
        assert result.result_sets[1] == [{"sellerid": 1, "amount": 500}]
        assert result.step_origins == [
            StepOrigin(step_index=1),
            StepOrigin(step_index=2),
        ]


# ---------------------------------------------------------------------------
# Transaction semantics
# ---------------------------------------------------------------------------

class TestTransactionSemantics:
    def test_no_inner_transaction_wrapper(self):
        """execute_steps does NOT wrap steps in BEGIN/ROLLBACK.

        Atomicity for multi-step batches is the caller's responsibility
        (e.g. capture_deltas opens its own transaction via the isolation
        provider). Wrapping here would nest inside that outer transaction
        and rollback effects the caller needs to observe (e.g. inserts
        captured by an after-snapshot during delta capture).
        """
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},  # step 0
            ],
        )

        executor = RedshiftExecutor(connector)
        steps = [QueryStep(source_query="CALL setup()", validate=False)]
        built = RedshiftBuiltSQL(
            main_sql={0: "CALL setup()"},
            validated_step_indices=[],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        calls = [c[0][0] for c in main_cursor.execute.call_args_list]
        assert "BEGIN" not in calls
        assert "ROLLBACK" not in calls
        assert calls == ["CALL setup()"]

    def test_error_recorded_without_rollback(self):
        """When a step errors, success=False is set and no ROLLBACK is issued."""
        connector = MagicMock()
        connection = MagicMock()
        connection.autocommit = True
        cursor = MagicMock()

        def _execute(sql):
            raise RuntimeError("DB error")

        cursor.execute = MagicMock(side_effect=_execute)
        cursor.close = MagicMock()
        connection.cursor.return_value = cursor
        connector.connection = connection

        executor = RedshiftExecutor(connector)
        steps = [QueryStep(source_query="SELECT 1")]
        built = RedshiftBuiltSQL(
            main_sql={0: "SELECT 1"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "DB error" in result.error
        calls = [c[0][0] for c in cursor.execute.call_args_list]
        assert "ROLLBACK" not in calls


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_no_description_handled(self):
        """DML call returning nothing (no description) handled gracefully."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},  # Step 0: DML call
            ],
        )

        executor = RedshiftExecutor(connector)
        steps = [QueryStep(source_query="CALL dml_proc()")]
        built = RedshiftBuiltSQL(
            main_sql={0: "CALL dml_proc()"},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        # CALL with no description and validated: returns empty result set
        assert len(result.result_sets) == 1


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_no_validated_steps(self):
        """No validated steps -> empty result_sets."""
        connector, main_cursor = _make_multi_step_connector(
            [
                {"description": None, "rows": []},  # Step 0
            ],
        )

        executor = RedshiftExecutor(connector)
        steps = [QueryStep(source_query="CALL setup()", validate=False)]
        built = RedshiftBuiltSQL(
            main_sql={0: "CALL setup()"},
            validated_step_indices=[],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == []

    def test_param_step_no_prior_call_raises(self):
        """ParamStep with no prior CALL result -> error."""
        connector, main_cursor = _make_multi_step_connector(
            [
                # Step 0 is ParamStep — no CALL before it
            ],
        )

        executor = RedshiftExecutor(connector)
        steps = [ParamStep(source_params=["result"])]
        built = RedshiftBuiltSQL(
            main_sql={},
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "no CALL was executed" in result.error
