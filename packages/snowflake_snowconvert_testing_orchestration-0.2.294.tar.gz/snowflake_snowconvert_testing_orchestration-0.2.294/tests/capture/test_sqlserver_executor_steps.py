"""Tests for SqlServerExecutor.execute_steps() with mocked cursors."""

from __future__ import annotations

from unittest.mock import MagicMock

from test_runner.capture.sources.sqlserver import SqlServerExecutor
from test_runner.common.builders.models import SqlServerBuiltSQL
from test_runner.common.models.capture_result import StepOrigin
from test_runner.common.models.step_types import (
    QueryStep,
    TableStep,
    ValidateSkip,
    ValidateTable,
    VALIDATE_SKIP,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_result_set(
    description: list[tuple] | None,
    rows: list[tuple],
) -> dict:
    return {"description": description, "rows": rows}


def _make_boundary(step_index: int) -> dict:
    return {
        "description": [("_boundary", str)],
        "rows": [(f"__STEP_{step_index}__",)],
    }


def _make_row_count_message() -> dict:
    """Simulates SQL Server row-count messages (no description)."""
    return {"description": None, "rows": []}


def _build_cursor_from_result_sets(result_sets: list[dict]) -> MagicMock:
    """Build a mock cursor that iterates through result sets via nextset()."""
    cursor = MagicMock()
    idx = {"i": 0}

    def _set_current():
        if idx["i"] < len(result_sets):
            rs = result_sets[idx["i"]]
            cursor.description = rs["description"]
            rows = rs["rows"]
            cursor.fetchall.return_value = rows
            cursor.fetchone.return_value = rows[0] if rows else None
        else:
            cursor.description = None
            cursor.fetchall.return_value = []
            cursor.fetchone.return_value = None

    def _execute(sql):
        _set_current()

    def _nextset():
        idx["i"] += 1
        if idx["i"] < len(result_sets):
            _set_current()
            return True
        cursor.description = None
        return False

    cursor.execute = MagicMock(side_effect=_execute)
    cursor.nextset = MagicMock(side_effect=_nextset)
    return cursor


def _make_executor(cursor: MagicMock) -> SqlServerExecutor:
    connector = MagicMock()
    connector.connection.cursor.return_value = cursor
    connector.connection.cursor.return_value.__enter__ = MagicMock(return_value=cursor)
    connector.connection.cursor.return_value.__exit__ = MagicMock(return_value=False)
    return SqlServerExecutor(connector)


# ---------------------------------------------------------------------------
# Basic execution
# ---------------------------------------------------------------------------

class TestExecuteStepsBasic:
    def test_two_validated_steps(self):
        """CALL + table SELECT, both validated — boundary parsing and result mapping."""
        result_sets = [
            _make_boundary(0),
            # Step 0: CALL result
            _make_result_set(
                [("id", int), ("name", str)],
                [(1, "Widget"), (2, "Gadget")],
            ),
            _make_boundary(1),
            # Step 1: SELECT * FROM #temp
            _make_result_set(
                [("total", int)],
                [(42,)],
            ),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [
            QueryStep(source_query="EXEC dbo.Proc @id = 1"),
            TableStep(source_table="#temp"),
        ]
        built = SqlServerBuiltSQL(
            main_sql="EXEC dbo.Proc @id = 1;\nSELECT '__STEP_0__' AS _boundary;\nSELECT * FROM #temp;\nSELECT '__STEP_1__' AS _boundary;\n",
            validated_step_indices=[0, 1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == [
            {"id": 1, "name": "Widget"},
            {"id": 2, "name": "Gadget"},
        ]
        assert result.result_sets[1] == [{"total": 42}]
        assert result.row_counts == [2, 1]
        assert result.step_origins == [
            StepOrigin(step_index=0),
            StepOrigin(step_index=1),
        ]

    def test_validate_false_step_skipped(self):
        """A step with validate: false has boundary markers but is not in result_sets."""
        result_sets = [
            # Step 0 (validate: false): DECLARE — no result set
            _make_boundary(0),
            _make_boundary(1),
            # Step 1: CALL result
            _make_result_set(
                [("status", str)],
                [("ok",)],
            ),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [
            QueryStep(source_query="DECLARE @x INT = 1", validate=False),
            QueryStep(source_query="EXEC dbo.Proc"),
        ]
        built = SqlServerBuiltSQL(
            main_sql="...",
            validated_step_indices=[1],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"status": "ok"}]

    def test_no_validated_steps_returns_empty(self):
        """All steps have validate: false → empty result_sets."""
        result_sets = [
            _make_boundary(0),
            _make_boundary(1),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [
            QueryStep(source_query="DECLARE @x INT = 1", validate=False),
            QueryStep(source_query="EXEC dbo.Setup", validate=False),
        ]
        built = SqlServerBuiltSQL(
            main_sql="...",
            validated_step_indices=[],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == []
        assert result.row_counts == []


# ---------------------------------------------------------------------------
# Row-count / SET NOCOUNT behavior
# ---------------------------------------------------------------------------

class TestRowCountMessages:
    def test_none_description_skipped(self):
        """Result sets with cursor.description=None (row-count messages) are silently skipped."""
        result_sets = [
            _make_boundary(0),
            _make_row_count_message(),  # rows-affected message
            _make_result_set(
                [("id", int)],
                [(1,), (2,)],
            ),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [QueryStep(source_query="EXEC dbo.Proc")]
        built = SqlServerBuiltSQL(
            main_sql="...",
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"id": 1}, {"id": 2}]

    def test_multiple_result_sets_with_validate_true_warns(self, caplog):
        """validate: true with multiple result sets logs a warning and takes the first."""
        result_sets = [
            _make_boundary(0),
            _make_result_set([("a", int)], [(1,)]),
            _make_result_set([("b", int)], [(2,)]),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [QueryStep(source_query="EXEC dbo.MultiRS")]
        built = SqlServerBuiltSQL(
            main_sql="...",
            validated_step_indices=[0],
        )

        import logging
        with caplog.at_level(logging.WARNING):
            result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [{"a": 1}]
        assert any("validate: [list]" in msg for msg in caplog.messages)


# ---------------------------------------------------------------------------
# Multi-result-set (validate: [list])
# ---------------------------------------------------------------------------

class TestValidateList:
    def test_multiple_result_sets_mapped(self):
        """validate: [list] maps multiple result sets between boundaries to entries."""
        result_sets = [
            _make_boundary(0),
            # Step 0: EXEC returns 2 result sets
            _make_result_set([("a", int)], [(1,)]),
            _make_result_set([("b", str)], [("hello",)]),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [
            QueryStep(
                source_query="EXEC dbo.Multi",
                validate=[ValidateTable(table="#t1"), ValidateTable(table="#t2")],
            ),
        ]
        built = SqlServerBuiltSQL(
            main_sql="...",
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == [{"a": 1}]
        assert result.result_sets[1] == [{"b": "hello"}]
        assert result.step_origins == [
            StepOrigin(step_index=0, validate_entry=0),
            StepOrigin(step_index=0, validate_entry=1),
        ]

    def test_validate_skip_not_captured(self):
        """ValidateSkip positions are not captured; other positions are."""
        result_sets = [
            _make_boundary(0),
            # Step 0: EXEC returns 3 result sets
            _make_result_set([("a", int)], [(1,)]),
            _make_result_set([("skipped", str)], [("x",)]),
            _make_result_set([("c", int)], [(3,)]),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [
            QueryStep(
                source_query="EXEC dbo.Multi",
                validate=[
                    ValidateTable(table="#t1"),
                    VALIDATE_SKIP,
                    ValidateTable(table="#t3"),
                ],
            ),
        ]
        built = SqlServerBuiltSQL(
            main_sql="...",
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == [{"a": 1}]
        assert result.result_sets[1] == [{"c": 3}]
        assert result.step_origins == [
            StepOrigin(step_index=0, validate_entry=0),
            StepOrigin(step_index=0, validate_entry=2),
        ]

    def test_fewer_result_sets_than_list_errors(self):
        """Source returns fewer result sets than validate list length → error."""
        result_sets = [
            _make_boundary(0),
            # Step 0: EXEC returns only 1 result set but list expects 2
            _make_result_set([("a", int)], [(1,)]),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [
            QueryStep(
                source_query="EXEC dbo.Multi",
                validate=[ValidateTable(table="#t1"), ValidateTable(table="#t2")],
            ),
        ]
        built = SqlServerBuiltSQL(
            main_sql="...",
            validated_step_indices=[0],
        )

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "result set" in result.error


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_execution_error(self):
        """Error during execution → success=False with error message."""
        cursor = MagicMock()
        cursor.execute.side_effect = RuntimeError("Connection lost")
        cursor.__enter__ = MagicMock(return_value=cursor)
        cursor.__exit__ = MagicMock(return_value=False)
        executor = _make_executor(cursor)

        steps = [QueryStep(source_query="EXEC dbo.Proc")]
        built = SqlServerBuiltSQL(main_sql="...", validated_step_indices=[0])

        result = executor.execute_steps(built, steps)

        assert result.success is False
        assert "Connection lost" in result.error

    def test_empty_result_set(self):
        """Empty result set (0 rows, valid description) captured as []."""
        result_sets = [
            _make_boundary(0),
            _make_result_set([("id", int)], []),
        ]
        cursor = _build_cursor_from_result_sets(result_sets)
        executor = _make_executor(cursor)

        steps = [QueryStep(source_query="EXEC dbo.Empty")]
        built = SqlServerBuiltSQL(main_sql="...", validated_step_indices=[0])

        result = executor.execute_steps(built, steps)

        assert result.success is True
        assert result.result_sets == [[]]
        assert result.row_counts == [0]
