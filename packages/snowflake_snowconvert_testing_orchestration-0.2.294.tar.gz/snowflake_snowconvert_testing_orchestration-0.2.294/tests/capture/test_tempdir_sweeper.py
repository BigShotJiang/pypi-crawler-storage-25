"""Unit tests for test_runner.capture.tempdir_sweeper."""

from __future__ import annotations

import os
import shutil
import time
from pathlib import Path

import pytest

from test_runner.capture import tempdir_sweeper
from test_runner.capture.tempdir_sweeper import sweep_stranded_tempdirs


# Arbitrary sentinel PID used only for directory naming.  Tests that
# rely on this PID being "dead" mock ``os.kill`` via ``_force_dead_pid``
# so the result is deterministic regardless of the actual PID state on
# the host (Linux supports 64-bit PIDs, so no numeric value is reliably
# unused).
_DEAD_PID = 0x7FFFFFFF


@pytest.fixture
def _force_dead_pid(monkeypatch: pytest.MonkeyPatch):
    """Make ``_DEAD_PID`` look dead to the sweeper's live-PID probe.

    Patches ``os.kill`` inside ``tempdir_sweeper`` so probing
    ``_DEAD_PID`` always raises ``ProcessLookupError`` (the "no such
    process" branch of ``_pid_alive``).  Any other PID is delegated to
    the real ``os.kill``.
    """
    real_kill = os.kill

    def _fake_kill(pid: int, sig: int) -> None:
        if pid == _DEAD_PID:
            raise ProcessLookupError(pid)
        real_kill(pid, sig)

    monkeypatch.setattr(tempdir_sweeper.os, "kill", _fake_kill)


def _make_tempdir(root: Path, pid: int, suffix: str = "abc123") -> Path:
    directory = root / f"mto-baselines-{pid}-{suffix}"
    directory.mkdir()
    (directory / "case_000.json").write_text("{}")
    return directory


def _set_old_mtime(directory: Path) -> None:
    """Backdate the directory and its contents beyond the stale threshold."""
    old = time.time() - (tempdir_sweeper.STALE_THRESHOLD_SEC + 60)
    for path in [directory, *directory.rglob("*")]:
        os.utime(path, (old, old))


def test_removes_dead_pid_dir(tmp_path: Path, _force_dead_pid):
    stranded = _make_tempdir(tmp_path, _DEAD_PID)
    _set_old_mtime(stranded)

    deleted = sweep_stranded_tempdirs(tempdir_root=tmp_path)

    assert deleted == 1
    assert not stranded.exists()


def test_preserves_alive_pid_dir(tmp_path: Path):
    alive_pid = os.getppid()  # the test runner's parent is definitely alive
    # Ensure we don't accidentally hit the "own pid" branch instead
    assert alive_pid != os.getpid()

    directory = _make_tempdir(tmp_path, alive_pid)
    _set_old_mtime(directory)

    deleted = sweep_stranded_tempdirs(tempdir_root=tmp_path)

    assert deleted == 0
    assert directory.exists(), "Sweeper must not touch live-process tempdirs"


def test_preserves_own_pid_dir(tmp_path: Path):
    directory = _make_tempdir(tmp_path, os.getpid())
    _set_old_mtime(directory)

    deleted = sweep_stranded_tempdirs(tempdir_root=tmp_path)

    assert deleted == 0
    assert directory.exists()


def test_honors_stale_threshold(tmp_path: Path, _force_dead_pid):
    """Fresh mtime must block deletion even for a dead PID, guarding against
    PID reuse races on a tempdir we just created."""
    directory = _make_tempdir(tmp_path, _DEAD_PID)
    # Leave mtime at "now" -- below the threshold.

    deleted = sweep_stranded_tempdirs(tempdir_root=tmp_path)

    assert deleted == 0
    assert directory.exists()


def test_ignores_unrelated_entries(tmp_path: Path):
    # Wrong prefix
    (tmp_path / "other-prefix-123-bar").mkdir()
    # Right prefix, but no PID segment
    (tmp_path / "mto-baselines-foo").mkdir()
    # Regular file with matching prefix
    (tmp_path / f"mto-baselines-{_DEAD_PID}-notadir").write_text("{}")

    deleted = sweep_stranded_tempdirs(tempdir_root=tmp_path)

    assert deleted == 0
    assert (tmp_path / "other-prefix-123-bar").exists()
    assert (tmp_path / "mto-baselines-foo").exists()
    assert (tmp_path / f"mto-baselines-{_DEAD_PID}-notadir").exists()


def test_swallows_rmtree_errors(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _force_dead_pid
):
    """Sweeper must not propagate OS errors; capture/validate rely on this."""
    directory = _make_tempdir(tmp_path, _DEAD_PID)
    _set_old_mtime(directory)

    def _raise(*args, **kwargs):
        raise PermissionError("simulated")

    monkeypatch.setattr(shutil, "rmtree", _raise)

    deleted = sweep_stranded_tempdirs(tempdir_root=tmp_path)

    assert deleted == 0
    assert directory.exists()


def test_missing_tempdir_is_noop(tmp_path: Path):
    """A non-existent root must not raise."""
    missing = tmp_path / "does-not-exist"
    assert sweep_stranded_tempdirs(tempdir_root=missing) == 0


def test_multiple_siblings_handled_independently(tmp_path: Path, _force_dead_pid):
    """Dead-PID dir is removed while alive-PID sibling is preserved."""
    stranded = _make_tempdir(tmp_path, _DEAD_PID, suffix="stranded")
    alive = _make_tempdir(tmp_path, os.getppid(), suffix="alive")
    _set_old_mtime(stranded)
    _set_old_mtime(alive)

    deleted = sweep_stranded_tempdirs(tempdir_root=tmp_path)

    assert deleted == 1
    assert not stranded.exists()
    assert alive.exists()
