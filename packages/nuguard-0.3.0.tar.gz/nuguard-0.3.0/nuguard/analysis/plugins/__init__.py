"""nuguard analysis plugins."""
