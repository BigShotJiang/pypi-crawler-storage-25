"""Static SBOM analysis pipeline."""
