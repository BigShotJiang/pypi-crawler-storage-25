from functools import wraps
from gc import get_referrers
from inspect import currentframe, getouterframes, signature
from logging import getLogger
from operator import attrgetter
from pathlib import Path
from textwrap import indent
import sys
from types import FunctionType


# Full Qualified Name od obj
def fqn(obj):
    mod = getattr(obj, '__module__', None)
    cls = obj.__class__.__name__
    if 'builtin' in cls:
        mod = cls = None
    elif cls in ('type', 'function', 'method'):
        cls = None
    name = getattr(obj, '__name__', None)
    return '.'.join(n for n in (mod, cls, name) if n)


# caller's caller
def caller():
    frame = getouterframes(currentframe(), 2)[2]
    module = Path(frame.filename).stem
    function = frame.function
    lineno = frame.lineno
    return f'{module}.{function}:{lineno}'


# Default implementation for abstract methods
def todo(self):
    cls = self.__class__.__name__
    mth = getouterframes(currentframe())[1][3]
    raise NotImplementedError(
        f'\n ! {mth} missing in {cls} !\n'
    )


# Memoizing property decorator
def memo(fct):
    name = '_memo_' + fct.__name__
    get_val = attrgetter(name)
    @property
    def wrapper(self):
        try:
            return get_val(self)
        except AttributeError:
            val = fct(self)
            setattr(self, name, val)
            return val
    return wrapper


def singleton(cls):
    '''Singleton class decorator.

    Make cls a Singleton class.
    '''
    @wraps(cls)
    def wrapper(*args, **kwargs):
        if wrapper.instance is None:
            wrapper.instance = cls(*args, **kwargs)
        return wrapper.instance
    wrapper.instance = None
    return wrapper


def cache(func):
    '''Cache decorator.

    Functools should be used instead.
    '''
    @wraps(func)
    def wrapper(*args, **kwargs):
        cache_key = args + tuple(kwargs.items())
        if cache_key not in wrapper.cache:
            wrapper.cache[cache_key] = func(*args, **kwargs)
        return wrapper.cache[cache_key]
    wrapper.cache = {}
    return wrapper


def trace(func):
    '''Trace decorator.

    Log func calls and return values.
    '''
    @wraps(func)
    def wrapper(*args, **kwargs):
        debug = getLogger('trace').debug
        args_repr = [repr(a) for a in args]
        kwargs_repr = [f"{k}={repr(v)}" for k, v in kwargs.items()]
        signature = ", ".join(args_repr + kwargs_repr)
        debug(f"{func.__name__}({signature})")
        value = func(*args, **kwargs)
        debug(f"{func.__name__}() returned {repr(value)}")
        return value
    return wrapper


def get_func_from_tbk(tbk):
    frame = tbk.tb_frame
    code = frame.f_code
    referrers = get_referrers(code)
    for ref in referrers:
        if isinstance(ref, FunctionType):
            if ref.__code__ is code:
                return ref


def get_args_from_tbk(tbk):
    frame = tbk.tb_frame
    code = frame.f_code
    locals_map = frame.f_locals
    arg_count = code.co_argcount + code.co_kwonlyargcount
    arg_names = list(code.co_varnames[:arg_count])
    next_idx = arg_count
    if code.co_flags & 0x04:
        arg_names.append(code.co_varnames[next_idx])
        next_idx += 1
    if code.co_flags & 0x08:
        arg_names.append(code.co_varnames[next_idx])
    args = {name : locals_map.get(name) for name in arg_names if name !='self'}
    args = {key : f'"{val}"' if isinstance(val, str) else val for key, val in args.items()}
    args = ', '.join((f'{key}={val}' for key, val in args.items()))
    return args


def trace_exc(exc):
    '''Display and Dump Error and Traceback for Exc.
    '''
    msg = f' ! {fqn(exc)} ! {'\n'.join(exc.args)}'
    tbk = exc.__traceback__
    calls = []
    while tbk is not None:
        lineno = tbk.tb_lineno
        frame = tbk.tb_frame
        code = frame.f_code
        filename = code.co_filename
        function = get_func_from_tbk(tbk)
        args = get_args_from_tbk(tbk)
        call = f'{function.__name__}({args})'
        location = f'{filename}:{lineno}'
        calls.append((call, location))
        tbk = tbk.tb_next
    size = max(len(c) for c, l in calls) + 5
    traces = [f'{call:{size}}{location}' for call, location in calls]
    trc = '\n'.join(traces)
    sig = f'{function.__name__}{signature(function)}:'
    doc = indent(function.__doc__ or '! no doc', '    ')
    with open('traceback.log', 'w') as out:
        out.write(f'{trc}\n\n')
        out.write(f'{sig}\n')
        out.write(f'{doc}\n')
        out.write(f'{msg}\n')
    print(f'\n{sig}\n{doc}\n{msg}\n')


def except_hook(exc_typ, exc_obj, exc_tbk):
    trace_exc(exc_obj)


def set_except_hook():
    sys.excepthook = except_hook
