"""
wechat_build 工具：构建与发布。

合并原 wechat_compile_check、wechat_preview、wechat_upload、
wechat_build_npm、wechat_cache_clean。
"""
import json
import os
import tempfile
from typing import TYPE_CHECKING

from ..core.cli import _run_cli, _resolve_project_path
from ..core.errors import ErrorCode
from ..models.schemas import WechatBuildInput
from ..utils.response import _ok, _fail

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


# 编译 stderr 行跳过模式（进度指示器）
_COMPILE_SKIP_PREFIXES = (
    "- initialize", "✔", "- preparing", "- Fetching", "- Preview",
    "- compile", "- pack",
)

# 行分类关键词
_ERROR_KEYWORDS = ["error", "错误", "fail", "异常", "[error]"]
_WARNING_KEYWORDS = ["warning", "warn", "警告"]
_STATUS_KEYWORDS = ["✓", "√", "started", "success", "完成", "done"]


def _classify_compile_line(line: str) -> str | None:
    """将 compile stderr 的单行分类为 error/warning/status，或 None（跳过行）。"""
    line = line.strip()
    if not line or line.startswith(_COMPILE_SKIP_PREFIXES):
        return None
    lower = line.lower()
    if any(kw in lower for kw in _ERROR_KEYWORDS):
        return "error"
    if any(kw in lower for kw in _WARNING_KEYWORDS):
        return "warning"
    if any(kw in lower for kw in _STATUS_KEYWORDS):
        return "status"
    return "status"


def register_build(mcp: "FastMCP") -> None:
    """将 wechat_build 工具注册到 FastMCP 实例。"""
    mcp.tool(
        name="wechat_build",
        annotations={
            "title": "构建与发布",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )(wechat_build)


async def wechat_build(params: WechatBuildInput) -> str:
    """构建、预览、上传小程序及 npm 管理。
    支持 action: compile(编译检查), preview(预览), upload(上传),
    build_npm(构建NPM), cache_clean(清缓存)。
    返回 JSON: {success, data, message, error_code?}。
    """
    try:
        if params.action == "compile":
            return await _action_compile(params)
        elif params.action == "preview":
            return await _action_preview(params)
        elif params.action == "upload":
            return await _action_upload(params)
        elif params.action == "build_npm":
            return await _action_build_npm(params)
        elif params.action == "cache_clean":
            return await _action_cache_clean(params)
        else:
            return _fail(ErrorCode.UNKNOWN_ERROR, f"未知 action: {params.action}")
    except ValueError as e:
        return _fail(ErrorCode.PROJECT_PATH_MISSING, str(e))
    except Exception as e:
        return _fail(ErrorCode.UNKNOWN_ERROR, f"执行失败：{type(e).__name__}: {e}")


async def _action_compile(params: WechatBuildInput) -> str:
    """触发编译并捕获错误和警告信息。"""
    proj = _resolve_project_path(params.project_path)
    info_path = params.info_output or os.path.join(tempfile.gettempdir(), "wechat_compile_info.json")

    args = ["preview", "--project", proj, "--info-output", info_path]
    if params.port is not None:
        args.extend(["--port", str(params.port)])

    result = await _run_cli(*args, timeout=120)

    errors: list[str] = []
    warnings: list[str] = []
    status: list[str] = []
    compile_info: dict = {}

    stderr = result.get("stderr", "")
    if stderr:
        for line in stderr.split("\n"):
            category = _classify_compile_line(line)
            if category is None:
                continue
            elif category == "error":
                errors.append(line.strip())
            elif category == "warning":
                warnings.append(line.strip())
            else:
                status.append(line.strip())

    if os.path.exists(info_path):
        try:
            with open(info_path, "r", encoding="utf-8") as f:
                compile_info = json.load(f)
        except Exception:
            pass

    data = {
        "compiled": result["success"],
        "errors": errors,
        "warnings": warnings,
        "status": status,
        "compile_info": compile_info,
        "project": proj,
        "automator_invalidated": True,
    }
    if result["success"]:
        msg = "编译成功。注意：编译会重置运行时，需重新调用 wechat_automator(action='start') 恢复自动化连接。"
        return _ok(data, message=msg)
    msg = f"编译失败，发现 {len(errors)} 个错误。"
    return _fail(ErrorCode.UNKNOWN_ERROR, msg, hint="; ".join(errors[:3]) if errors else "")


async def _action_preview(params: WechatBuildInput) -> str:
    """生成预览二维码。"""
    proj = _resolve_project_path(params.project_path)
    args = ["preview", "--project", proj]
    if params.qr_format:
        args.extend(["--qr-format", params.qr_format])
    if params.qr_output:
        args.extend(["--qr-output", params.qr_output])
    if params.info_output:
        args.extend(["--info-output", params.info_output])
    if params.compile_condition:
        args.extend(["--compile-condition", params.compile_condition])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    if params.lang:
        args.extend(["--lang", params.lang])

    result = await _run_cli(*args, timeout=120)
    if result["success"]:
        return _ok({"stdout": result["stdout"]}, message="预览二维码已生成。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "预览失败")


async def _action_upload(params: WechatBuildInput) -> str:
    """上传小程序代码到微信后台。"""
    if not params.version:
        return _fail(
            ErrorCode.PARAM_MISSING,
            "action='upload' 缺少必填参数: version",
            hint="请提供版本号，例如 version='1.0.0'",
        )
    proj = _resolve_project_path(params.project_path)
    args = ["upload", "--project", proj, "--version", params.version]
    if params.desc:
        args.extend(["--desc", params.desc])
    if params.info_output:
        args.extend(["--info-output", params.info_output])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    if params.lang:
        args.extend(["--lang", params.lang])

    result = await _run_cli(*args, timeout=120)
    if result["success"]:
        return _ok({"version": params.version, "stdout": result["stdout"]}, message=f"版本 {params.version} 上传成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "上传失败")


async def _action_build_npm(params: WechatBuildInput) -> str:
    """构建小程序 NPM 依赖。"""
    proj = _resolve_project_path(params.project_path)
    args = ["build-npm", "--project", proj]
    if params.compile_type:
        args.extend(["--compile-type", params.compile_type])
    if params.port is not None:
        args.extend(["--port", str(params.port)])

    result = await _run_cli(*args, timeout=120)
    if result["success"]:
        return _ok({}, message="NPM 构建成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "NPM 构建失败")


async def _action_cache_clean(params: WechatBuildInput) -> str:
    """清除指定类型的工具缓存。"""
    proj = _resolve_project_path(params.project_path)
    args = ["cache", "--clean", params.clean_type, "--project", proj]
    if params.port is not None:
        args.extend(["--port", str(params.port)])

    result = await _run_cli(*args)
    if result["success"]:
        return _ok({"clean_type": params.clean_type}, message=f"已清除 {params.clean_type} 缓存。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "清缓存失败")
