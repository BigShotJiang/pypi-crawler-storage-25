"""Tests for atulya-embed."""
