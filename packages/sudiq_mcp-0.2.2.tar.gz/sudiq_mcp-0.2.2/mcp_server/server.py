"""
SudIQ MCP Server — Model Context Protocol server for AI agent access.

Exposes 8 semantic tools backed by the SudIQ public API. The server runs
on the customer's machine (typically via uvx + Claude Desktop's stdio
transport) and forwards every tool invocation to api.sudiq.com using
the customer's own API key. No direct database access; all auth, rate
limiting, tier checks, and usage tracking happen at the API gateway.

Usage:
    sudiq-mcp                           # reads SUDIQ_API_KEY from env / .env
    sudiq-mcp --api-key sk_live_...     # explicit key
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from mcp_server.api_client import APIError, get_api_client
from mcp_server.auth import configure_api_key

server = Server("sudiq")


# ─────────────────────────────────────────────────────────────────────
# Tool definitions
# ─────────────────────────────────────────────────────────────────────

TOOLS = [
    Tool(
        name="get_product_ingredients",
        description=(
            "Search for a supplement product by name and return its full "
            "structured ingredient list. Each ingredient includes amount, "
            "unit, and form. Use this when an agent needs to know what's "
            "inside a specific named product."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "product_name": {
                    "type": "string",
                    "description": "Product name or partial name to search for (e.g. 'BULK Pre-Workout', 'Gorilla Mode').",
                },
            },
            "required": ["product_name"],
        },
    ),
    Tool(
        name="search_products",
        description=(
            "Search the SudIQ catalog by keyword and optional category. "
            "Returns matching products with brand, category, and a stable "
            "product_id you can pass to other tools. Use this to discover "
            "products before fetching detailed ingredient data."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Keyword to search for in product names.",
                },
                "category": {
                    "type": "string",
                    "description": "Optional category filter (e.g. pre_workout, protein, creatine).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max results to return (default: 10, max: 20).",
                    "default": 10,
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="get_ingredient_info",
        description=(
            "Look up an ingredient in the SudIQ clinical ingredient library. "
            "Returns clinical dose ranges, best forms, safety notes, aliases, "
            "and research quality. Use this for factual reference data about "
            "any supplement ingredient."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ingredient_name": {
                    "type": "string",
                    "description": "Ingredient name to look up (e.g. 'L-Citrulline', 'Caffeine').",
                },
            },
            "required": ["ingredient_name"],
        },
    ),
    Tool(
        name="find_products_by_ingredient",
        description=(
            "Find supplement products that contain a specific ingredient, "
            "optionally filtered by minimum dose and category. Returns "
            "products ranked by dose amount. Use the optional `category` "
            "filter when the user wants only products in a specific category."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ingredient_name": {
                    "type": "string",
                    "description": "Ingredient name to search for.",
                },
                "min_dose_mg": {
                    "type": "number",
                    "description": "Optional minimum dose in milligrams. Products dosed below this are excluded.",
                },
                "category": {
                    "type": "string",
                    "description": "Optional category filter (e.g. creatine, pre_workout, protein).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max products to return (default: 20, max: 50).",
                    "default": 20,
                },
            },
            "required": ["ingredient_name"],
        },
    ),
    Tool(
        name="compare_products",
        description=(
            "Compare 2-5 supplement products and return an aligned competitive "
            "panel. Output includes: each product's full ingredient list with "
            "canonical ingredient IDs; a matrix[] with one row per unique "
            "ingredient showing which products contain it and at what dose; "
            "and a summary of shared vs unique ingredients per product. Call "
            "this directly to answer 'how do these formulations differ' "
            "without aligning data client-side."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "product_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of 2-5 product UUIDs to compare.",
                    "minItems": 2,
                    "maxItems": 5,
                },
            },
            "required": ["product_ids"],
        },
    ),
    Tool(
        name="check_dose_safety",
        description=(
            "Check whether a specific dose of a supplement ingredient falls "
            "within the clinically studied range. Returns whether the dose is "
            "below, within, or above the clinical range, plus safety notes. "
            "Use this when evaluating if a product's dosing is effective."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ingredient_name": {"type": "string"},
                "dose_amount": {"type": "number"},
                "dose_unit": {
                    "type": "string",
                    "description": "Unit: mg, g, mcg. Defaults to mg.",
                    "default": "mg",
                },
            },
            "required": ["ingredient_name", "dose_amount"],
        },
    ),
    Tool(
        name="get_product_label_status",
        description=(
            "Check the verification status of a product's label data. Returns "
            "whether the product has been label-verified (OCR-extracted from "
            "physical product image) and how complete its ingredient data is. "
            "Use this to assess data reliability before making health-related "
            "recommendations."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "product_name": {"type": "string"},
            },
            "required": ["product_name"],
        },
    ),
    Tool(
        name="find_alternatives",
        description=(
            "Find alternative supplement products in the same category as a "
            "given product. Returns products with similar formulations, ranked "
            "by ingredient overlap. Use this to suggest substitutes or compare "
            "options within a category."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "product_name": {"type": "string"},
                "limit": {
                    "type": "integer",
                    "description": "Max alternatives to return (default: 10, max: 20).",
                    "default": 10,
                },
            },
            "required": ["product_name"],
        },
    ),
]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    handlers = {
        "get_product_ingredients": _handle_get_product_ingredients,
        "search_products": _handle_search_products,
        "get_ingredient_info": _handle_get_ingredient_info,
        "find_products_by_ingredient": _handle_find_products_by_ingredient,
        "compare_products": _handle_compare_products,
        "check_dose_safety": _handle_check_dose_safety,
        "get_product_label_status": _handle_get_product_label_status,
        "find_alternatives": _handle_find_alternatives,
    }

    handler = handlers.get(name)
    if not handler:
        return [TextContent(type="text", text=json.dumps({"error": f"Unknown tool: {name}"}))]

    try:
        result = handler(arguments)
        return [TextContent(type="text", text=json.dumps(result, default=str))]
    except APIError as e:
        return [TextContent(type="text", text=json.dumps({"error": e.message, "status": e.status}))]
    except PermissionError as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


# ─────────────────────────────────────────────────────────────────────
# Tool implementations
# ─────────────────────────────────────────────────────────────────────

def _handle_get_product_ingredients(args: dict) -> dict:
    """Search for a product by name and return its full ingredient profile."""
    product_name = args["product_name"]
    client = get_api_client()

    # Search to resolve the name → product_id
    matches = client.get("/v1/products", {"q": product_name, "per_page": 5})
    items = _items(matches)
    if not items:
        return {
            "error": f"No product found matching '{product_name}'.",
            "suggestion": "Try a broader search with search_products first.",
        }

    # Pick the closest match — exact case-insensitive match preferred, else first
    chosen = _pick_best_match(items, product_name)

    detail = client.get(f"/v1/products/{chosen['id']}")
    raw_ingredients = detail.get("ingredients") or detail.get("product_ingredients") or []
    ingredients = [
        i for i in raw_ingredients
        if not _is_allergen_disclaimer(i.get("raw_name") or i.get("name"))
    ]

    return {
        "product": _product_context(detail),
        "label_verification": _label_verification_context(detail, ingredients),
        "data_quality": _data_quality_context(detail, ingredients),
        "ingredients": [_format_ingredient(i) for i in ingredients],
        "ingredient_count": len(ingredients),
    }


def _handle_search_products(args: dict) -> dict:
    """Keyword search across the catalog."""
    query = args["query"]
    category = args.get("category")
    limit = min(int(args.get("limit") or 10), 20)
    client = get_api_client()

    response = client.get(
        "/v1/products",
        {"q": query, "category": category, "per_page": limit},
    )
    items = _items(response)

    return {
        "query": query,
        "category": category,
        "results_count": len(items),
        "products": [
            {
                "id": p.get("id"),
                "name": p.get("name"),
                "slug": p.get("slug"),
                "brand_name": p.get("brand_name") or _brand_name(p),
                "category": p.get("category"),
            }
            for p in items
        ],
    }


def _handle_get_ingredient_info(args: dict) -> dict:
    """Look up an ingredient and return clinical reference data."""
    ingredient_name = args["ingredient_name"]
    client = get_api_client()

    matches = client.get("/v1/ingredients", {"q": ingredient_name, "per_page": 5})
    items = _items(matches)
    if not items:
        return {
            "error": f"No ingredient found matching '{ingredient_name}'.",
            "suggestion": "Try a more general term or a known alias.",
        }

    chosen = _pick_best_match(items, ingredient_name)
    detail = client.get(f"/v1/ingredients/{chosen['id']}")

    return {
        "ingredient": {
            "id": detail.get("id"),
            "name": detail.get("name"),
            "slug": detail.get("slug"),
            "category": detail.get("category"),
            "aliases": detail.get("aliases") or [],
            "common_forms": detail.get("common_forms") or [],
            "best_form": detail.get("best_form"),
            "clinical_dose_range": {
                "min": detail.get("clinical_dose_min"),
                "max": detail.get("clinical_dose_max"),
                "unit": detail.get("clinical_dose_unit"),
            },
            "research_summary": detail.get("research_summary"),
            "research_quality": detail.get("research_quality"),
            "safety_notes": detail.get("safety_notes"),
            "is_branded": detail.get("is_branded"),
            "brand_owner": detail.get("brand_owner"),
            "is_banned_substance": detail.get("is_banned_substance"),
        }
    }


def _handle_find_products_by_ingredient(args: dict) -> dict:
    """Find products containing a given ingredient at or above a minimum dose."""
    ingredient_name = args["ingredient_name"]
    min_dose_mg = args.get("min_dose_mg")
    category_filter = (args.get("category") or "").strip().lower() or None
    limit = min(int(args.get("limit") or 20), 50)
    client = get_api_client()

    # Resolve ingredient → id
    matches = client.get("/v1/ingredients", {"q": ingredient_name, "per_page": 20})
    items = _items(matches)
    if not items:
        return {"error": f"No ingredient found matching '{ingredient_name}'."}

    ingredient = _pick_canonical_ingredient(items, ingredient_name)

    # Pull products carrying this ingredient (Pro tier endpoint — fine since MCP is paid-only)
    products = []
    seen_rows: set[tuple[str | None, str | None]] = set()
    per_page = min(max(limit * 2, 1), 20)
    for matched_ingredient in items:
        ingredient_id = matched_ingredient.get("id")
        if not ingredient_id:
            continue
        response = client.get(
            f"/v1/ingredients/{ingredient_id}/products",
            {"per_page": per_page},
        )
        for product_row in _items(response):
            row_key = (
                product_row.get("product_id")
                or (product_row.get("products") or {}).get("id")
                or product_row.get("id"),
                ingredient_id,
            )
            if row_key in seen_rows:
                continue
            seen_rows.add(row_key)
            products.append(product_row)

    formatted = []
    for p in products:
        nested_product = p.get("products") if isinstance(p.get("products"), dict) else {}
        nested_brand = nested_product.get("brands") if isinstance(nested_product.get("brands"), dict) else {}
        category = p.get("category") or nested_product.get("category")
        if category_filter and (category or "").lower() != category_filter:
            continue

        amount_mg = _to_mg(p.get("amount"), p.get("unit"))
        if min_dose_mg is not None and amount_mg is not None and amount_mg < min_dose_mg:
            continue
        formatted.append({
            "product_id": p.get("product_id") or nested_product.get("id") or p.get("id"),
            "name": p.get("product_name") or p.get("name") or nested_product.get("name") or p.get("raw_name"),
            "slug": p.get("slug") or nested_product.get("slug"),
            "category": category,
            "brand_name": p.get("brand_name") or _brand_name(p) or nested_brand.get("name"),
            "brand_slug": p.get("brand_slug") or nested_brand.get("slug"),
            "amount": p.get("amount"),
            "unit": p.get("unit"),
            "form": p.get("form"),
            "amount_mg_normalized": amount_mg,
        })
        if len(formatted) >= limit:
            break

    formatted.sort(key=lambda x: (x.get("amount_mg_normalized") or 0), reverse=True)

    return {
        "ingredient": {
            "id": ingredient.get("id"),
            "name": ingredient.get("name"),
        },
        "ingredient_forms_searched": [i.get("name") for i in items if i.get("name")],
        "category_filter": category_filter,
        "min_dose_mg": min_dose_mg,
        "results_count": len(formatted),
        "products": formatted,
    }


def _pick_canonical_ingredient(items: list[dict], query: str) -> dict:
    """Pick the most generic matching ingredient for display."""
    q = (query or "").strip().lower()
    if not q:
        return items[0]
    for item in items:
        if (item.get("name") or "").strip().lower() == q:
            return item
    prefix_matches = [
        i for i in items
        if (i.get("name") or "").strip().lower().startswith(q)
    ]
    if prefix_matches:
        return min(prefix_matches, key=lambda i: len(i.get("name") or ""))
    return min(items, key=lambda i: len(i.get("name") or ""))


def _handle_compare_products(args: dict) -> dict:
    """
    Compare 2-5 products side by side and return an aligned diff matrix.

    Output structure:
      - products[]: per-product data with canonical ingredient_id on every row
      - matrix[]:   one row per unique ingredient across all products,
                    with each product's amount/unit/form in that row.
                    Use this directly to render a competitive panel without
                    re-aligning client-side.
    """
    product_ids = args["product_ids"]
    if len(product_ids) < 2:
        return {"error": "Provide at least 2 product IDs to compare."}
    if len(product_ids) > 5:
        return {"error": "Maximum 5 products per comparison."}

    client = get_api_client()
    products = []
    not_found = []

    for pid in product_ids:
        try:
            detail = client.get(f"/v1/products/{pid}")
        except APIError as e:
            if e.status == 404:
                not_found.append(pid)
                continue
            raise

        raw_ingredients = detail.get("ingredients") or detail.get("product_ingredients") or []
        ingredients = [
            i for i in raw_ingredients
            if not _is_allergen_disclaimer(i.get("raw_name") or i.get("name"))
        ]
        prices = detail.get("prices") or []

        products.append({
            "id": detail.get("id"),
            "name": detail.get("name"),
            "slug": detail.get("slug"),
            "category": detail.get("category"),
            "brand_name": detail.get("brand_name") or _brand_name(detail),
            "serving_size": detail.get("serving_size"),
            "servings_per_container": detail.get("servings_per_container"),
            "is_proprietary_blend": detail.get("is_proprietary_blend"),
            "has_third_party_testing": detail.get("has_third_party_testing"),
            "ingredients": [_format_ingredient(i) for i in ingredients],
            "ingredient_count": len(ingredients),
            "prices": prices,
        })

    matrix = _build_comparison_matrix(products)

    return {
        "comparison": {
            "product_count": len(products),
            "not_found": not_found,
            "products": products,
            "matrix": matrix,
            "summary": _summarize_matrix(matrix, products),
        },
    }


def _handle_check_dose_safety(args: dict) -> dict:
    """Check if a dose falls within the clinically studied range."""
    ingredient_name = args["ingredient_name"]
    dose_amount = float(args["dose_amount"])
    dose_unit = (args.get("dose_unit") or "mg").lower()
    client = get_api_client()

    matches = client.get("/v1/ingredients", {"q": ingredient_name, "per_page": 1})
    items = _items(matches)
    if not items:
        return {"error": f"No ingredient found matching '{ingredient_name}'."}

    detail = client.get(f"/v1/ingredients/{items[0]['id']}")

    if detail.get("is_banned_substance"):
        return {
            "ingredient": detail.get("name"),
            "dose": {"amount": dose_amount, "unit": dose_unit},
            "status": "banned",
            "assessment": "This substance is flagged as banned by major sport authorities.",
            "safety_notes": detail.get("safety_notes"),
        }

    clinical_min = detail.get("clinical_dose_min")
    clinical_max = detail.get("clinical_dose_max")
    clinical_unit = detail.get("clinical_dose_unit")

    if clinical_min is None or clinical_max is None or clinical_unit is None:
        return {
            "ingredient": detail.get("name"),
            "dose": {"amount": dose_amount, "unit": dose_unit},
            "status": "insufficient_data",
            "assessment": "No clinical dose range on file for this ingredient.",
        }

    # Normalize to a common unit (mg) so the comparison is meaningful
    dose_mg = _to_mg(dose_amount, dose_unit)
    min_mg = _to_mg(clinical_min, clinical_unit)
    max_mg = _to_mg(clinical_max, clinical_unit)

    if dose_mg is None or min_mg is None or max_mg is None:
        return {
            "ingredient": detail.get("name"),
            "dose": {"amount": dose_amount, "unit": dose_unit},
            "status": "unit_mismatch",
            "assessment": "Could not normalize units for comparison.",
        }

    if dose_mg < min_mg:
        status = "below_clinical_range"
        assessment = (
            f"{dose_amount}{dose_unit} is below the clinically effective range "
            f"({clinical_min}–{clinical_max} {clinical_unit})."
        )
    elif dose_mg > max_mg:
        status = "above_clinical_range"
        assessment = (
            f"{dose_amount}{dose_unit} exceeds the typical studied range "
            f"({clinical_min}–{clinical_max} {clinical_unit}). Verify safety considerations."
        )
    else:
        status = "within_clinical_range"
        assessment = (
            f"{dose_amount}{dose_unit} falls within the clinically studied range "
            f"({clinical_min}–{clinical_max} {clinical_unit})."
        )

    return {
        "ingredient": detail.get("name"),
        "dose": {"amount": dose_amount, "unit": dose_unit, "amount_mg_normalized": dose_mg},
        "clinical_range": {
            "min": clinical_min,
            "max": clinical_max,
            "unit": clinical_unit,
        },
        "status": status,
        "assessment": assessment,
        "best_form": detail.get("best_form"),
        "safety_notes": detail.get("safety_notes"),
    }


def _handle_get_product_label_status(args: dict) -> dict:
    """Return verification information for a product."""
    product_name = args["product_name"]
    client = get_api_client()

    matches = client.get("/v1/products", {"q": product_name, "per_page": 1})
    items = _items(matches)
    if not items:
        return {"error": f"No product found matching '{product_name}'."}

    chosen = items[0]
    detail = client.get(f"/v1/products/{chosen['id']}")
    raw_ingredients = detail.get("ingredients") or detail.get("product_ingredients") or []
    ingredients = [
        i for i in raw_ingredients
        if not _is_allergen_disclaimer(i.get("raw_name") or i.get("name"))
    ]

    # Public surface doesn't expose raw OCR confidence — derive a verification
    # level from publicly visible signals (status, ingredient completeness,
    # third-party testing flag).
    status = detail.get("status") or "unknown"
    ingredient_count = len(ingredients)
    has_serving = detail.get("serving_size") is not None
    has_third_party = bool(detail.get("has_third_party_testing"))
    has_label_evidence = bool(detail.get("label_verified"))

    if has_label_evidence and status == "approved" and ingredient_count > 0 and has_serving:
        verification_level = "label_verified"
        detail_msg = (
            "Label data has passed SudIQ's verification checks and is "
            "considered reliable for clinical comparison."
        )
    elif status == "approved" and ingredient_count > 0:
        verification_level = "partial"
        detail_msg = (
            "Structured ingredient data is available, but this product does "
            "not currently have label verification evidence attached."
        )
    else:
        verification_level = "unverified"
        detail_msg = "This product has not yet completed SudIQ's label verification checks."

    return {
        "product": {
            "id": detail.get("id"),
            "name": detail.get("name"),
            "brand_name": detail.get("brand_name") or _brand_name(detail),
            "status": status,
        },
        "label_verification": {
            "verification_level": verification_level,
            "detail": detail_msg,
            "label_type": detail.get("label_type"),
            "confidence_score": detail.get("confidence_score"),
            "third_party_tested": has_third_party,
        },
        "data_completeness": {
            "ingredient_count": ingredient_count,
            "has_serving_info": has_serving,
        },
        "data_quality": _data_quality_context(detail, ingredients),
    }


def _handle_find_alternatives(args: dict) -> dict:
    """Find alternative products in the same category."""
    product_name = args["product_name"]
    limit = min(int(args.get("limit") or 10), 20)
    client = get_api_client()

    # Resolve the source product
    matches = client.get("/v1/products", {"q": product_name, "per_page": 1})
    items = _items(matches)
    if not items:
        return {"error": f"No product found matching '{product_name}'."}

    source = items[0]

    # Fetch alternatives from the dedicated endpoint
    alternatives = client.get(f"/v1/products/{source['id']}/alternatives")
    alt_items = _items(alternatives)

    return {
        "source_product": {
            "id": source.get("id"),
            "name": source.get("name"),
            "brand_name": source.get("brand_name") or _brand_name(source),
            "category": source.get("category"),
        },
        "alternatives_found": len(alt_items),
        "alternatives": [
            {
                "product_id": a.get("id"),
                "name": a.get("name"),
                "slug": a.get("slug"),
                "brand_name": a.get("brand_name") or _brand_name(a),
                "category": a.get("category"),
                "serving_size": a.get("serving_size"),
            }
            for a in alt_items[:limit]
        ],
    }


# ─────────────────────────────────────────────────────────────────────
# Comparison matrix logic (local — keeps the agent-useful diff alignment
# in the MCP layer rather than asking the API to compute it)
# ─────────────────────────────────────────────────────────────────────

def _build_comparison_matrix(products: list[dict]) -> list[dict]:
    """
    Align ingredients across products into a single matrix.

    Each row represents one unique ingredient (keyed by ingredient_id when
    available, falling back to a normalized raw_name). Each row carries
    per-product cells so a caller can render a side-by-side panel directly.
    """
    rows: dict[str, dict] = {}

    for product in products:
        product_id = product["id"]
        for ing in product.get("ingredients", []):
            ingredient_id = ing.get("ingredient_id")
            if ingredient_id:
                key = f"id:{ingredient_id}"
                display_name = ing.get("canonical_name") or ing.get("name") or ing.get("raw_name")
            else:
                raw = (ing.get("raw_name") or ing.get("name") or "").strip().lower()
                if not raw:
                    continue
                key = f"raw:{raw}"
                display_name = ing.get("raw_name") or ing.get("name")

            if key not in rows:
                rows[key] = {
                    "ingredient_id": ingredient_id,
                    "name": display_name,
                    "is_canonical": bool(ingredient_id),
                    "by_product": {},
                }

            rows[key]["by_product"][product_id] = {
                "raw_name": ing.get("raw_name") or ing.get("name"),
                "amount": ing.get("amount"),
                "unit": ing.get("unit"),
                "form": ing.get("form"),
                "is_proprietary_blend": ing.get("is_proprietary_blend"),
            }

    product_ids = [p["id"] for p in products]
    matrix = []
    for row in rows.values():
        present_in = [pid for pid in product_ids if pid in row["by_product"]]
        row["present_in"] = present_in
        row["missing_from"] = [pid for pid in product_ids if pid not in row["by_product"]]
        row["shared"] = len(present_in) == len(product_ids)
        row["unique_to"] = present_in[0] if len(present_in) == 1 else None
        matrix.append(row)

    matrix.sort(key=lambda r: (not r["shared"], (r["name"] or "").lower()))
    return matrix


def _summarize_matrix(matrix: list[dict], products: list[dict]) -> dict:
    """Quick rollup so an agent can answer 'how do these differ' in one pass."""
    shared = [r["name"] for r in matrix if r["shared"]]
    unique_by_product: dict[str, list[str]] = {p["id"]: [] for p in products}
    for r in matrix:
        if r.get("unique_to"):
            unique_by_product[r["unique_to"]].append(r["name"])

    return {
        "total_distinct_ingredients": len(matrix),
        "shared_count": len(shared),
        "shared_ingredients": shared,
        "unique_by_product": [
            {
                "product_id": p["id"],
                "product_name": p["name"],
                "unique_ingredients": unique_by_product.get(p["id"], []),
            }
            for p in products
        ],
    }


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def _items(response: Any) -> list[dict]:
    """
    Extract the list of items from an API response, regardless of whether
    it's a bare list, a paginated `{items, page, ...}` envelope, or a dict
    with a single embedded list.
    """
    if isinstance(response, list):
        return response
    if isinstance(response, dict):
        for key in ("items", "products", "results", "ingredients", "alternatives", "data"):
            value = response.get(key)
            if isinstance(value, list):
                return value
    return []


def _pick_best_match(items: list[dict], query: str) -> dict:
    """Prefer an exact case-insensitive name match, otherwise return the first item."""
    q = query.strip().lower()
    for item in items:
        name = (item.get("name") or "").strip().lower()
        if name == q:
            return item
    return items[0]


def _brand_name(record: dict) -> str | None:
    """Extract a brand name from a record that may have it nested under `brands` or `brand`."""
    brand = record.get("brands") or record.get("brand")
    if isinstance(brand, dict):
        return brand.get("name")
    if isinstance(brand, str):
        return brand
    return None


def _product_context(detail: dict) -> dict:
    """Return the product fields an LLM needs for formulation analysis."""
    return {
        "id": detail.get("id"),
        "name": detail.get("name"),
        "slug": detail.get("slug"),
        "brand_name": detail.get("brand_name") or _brand_name(detail),
        "brand_slug": detail.get("brand_slug"),
        "category": detail.get("category"),
        "subcategory": detail.get("subcategory"),
        "serving_size": detail.get("serving_size"),
        "servings_per_container": detail.get("servings_per_container"),
        "is_proprietary_blend": detail.get("is_proprietary_blend"),
        "has_third_party_testing": detail.get("has_third_party_testing"),
        "allergens": detail.get("allergens"),
        "certifications": detail.get("certifications"),
        "macros": {
            "calories": detail.get("calories"),
            "protein_g": detail.get("protein_g"),
            "total_carbs_g": detail.get("total_carbs_g"),
            "total_sugars_g": detail.get("total_sugars_g"),
            "added_sugars_g": detail.get("added_sugars_g"),
            "total_fat_g": detail.get("total_fat_g"),
            "sodium_mg": detail.get("sodium_mg"),
        },
    }


def _label_verification_context(detail: dict, ingredients: list[dict]) -> dict:
    """Return label trust signals alongside product ingredient payloads."""
    has_label_evidence = bool(detail.get("label_verified"))
    has_serving = detail.get("serving_size") is not None
    ingredient_count = len(ingredients)
    status = detail.get("status") or "unknown"

    if has_label_evidence and status == "approved" and ingredient_count > 0 and has_serving:
        verification_level = "label_verified"
        detail_msg = (
            "Label data has passed SudIQ's verification checks and is "
            "considered reliable for clinical comparison."
        )
    elif status == "approved" and ingredient_count > 0:
        verification_level = "partial"
        detail_msg = (
            "Structured ingredient data is available, but this product does "
            "not currently have label verification evidence attached."
        )
    else:
        verification_level = "unverified"
        detail_msg = "This product has not yet completed SudIQ's label verification checks."

    return {
        "verification_level": verification_level,
        "detail": detail_msg,
        "label_type": detail.get("label_type"),
        "confidence_score": detail.get("confidence_score"),
        "third_party_tested": bool(detail.get("has_third_party_testing")),
    }


def _data_quality_context(detail: dict, ingredients: list[dict]) -> dict:
    """Give agents explicit completeness signals so they do not overstate data."""
    category = (detail.get("category") or "").lower()
    ingredient_count = len(ingredients)
    warnings = []

    if not detail.get("label_verified"):
        warnings.append("missing_label_verification_evidence")
    if ingredient_count == 0:
        warnings.append("no_structured_ingredients")
    if detail.get("serving_size") is None:
        warnings.append("missing_serving_size")
    if category == "pre_workout" and 0 < ingredient_count < 5:
        warnings.append("ingredient_count_unusually_low_for_pre_workout")

    analysis_guidance = (
        "Use only the structured ingredients returned here. If warnings are "
        "present, state the limitation and do not infer missing ingredients."
        if warnings
        else "Structured ingredient data is suitable for analysis."
    )

    return {
        "ingredient_count": ingredient_count,
        "has_serving_info": detail.get("serving_size") is not None,
        "warnings": warnings,
        "analysis_guidance": analysis_guidance,
    }


_ALLERGEN_DISCLAIMER_PHRASES = (
    "contains:", "may contain", "free from", "free of",
    "manufactured in", "manufactured with", "not manufactured",
    "produced in", "produced with",
    "shared facility", "shared equipment", "same facility",
    "allergen", "warning", "caution",
)

_BARE_ALLERGEN_NAMES = {
    "peanuts", "peanut", "wheat", "soy", "soybean", "soybeans",
    "milk", "dairy", "eggs", "egg",
    "fish", "shellfish", "tree nuts", "tree nut", "nuts",
    "sesame", "gluten", "lactose",
}


def _is_allergen_disclaimer(raw_name: str | None) -> bool:
    """Return True for allergen/facility text captured as ingredient rows."""
    if not raw_name:
        return False
    text = raw_name.strip().lower()
    if not text:
        return False
    if text in _BARE_ALLERGEN_NAMES:
        return True
    return any(phrase in text for phrase in _ALLERGEN_DISCLAIMER_PHRASES)


def _format_ingredient(ing: dict) -> dict:
    """Normalize the ingredient shape across detail / list / comparison endpoints."""
    return {
        "ingredient_id": ing.get("ingredient_id") or ing.get("canonical_ingredient_id"),
        "name": ing.get("name") or ing.get("canonical_name") or ing.get("raw_name"),
        "raw_name": ing.get("raw_name"),
        "amount": ing.get("amount"),
        "unit": ing.get("unit"),
        "form": ing.get("form"),
        "is_proprietary_blend": ing.get("is_proprietary_blend"),
        "blend_name": ing.get("blend_name"),
        "amount_mg_normalized": _to_mg(ing.get("amount"), ing.get("unit")),
    }


def _to_mg(amount: Any, unit: str | None) -> float | None:
    """Normalize a (amount, unit) pair to milligrams. Returns None if not convertible."""
    if amount is None or unit is None:
        return None
    try:
        amt = float(amount)
    except (TypeError, ValueError):
        return None
    u = unit.strip().lower()
    if u in ("mg", "mg."):
        return amt
    if u in ("g", "g.", "gram", "grams"):
        return amt * 1000.0
    if u in ("mcg", "ug", "µg"):
        return amt / 1000.0
    if u in ("iu",):
        # IU is ingredient-specific; we don't try to convert
        return None
    return None


# ─────────────────────────────────────────────────────────────────────
# Server startup
# ─────────────────────────────────────────────────────────────────────

async def run(api_key: str | None = None):
    """Start the MCP server with stdio transport."""
    configure_api_key(api_key)

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )
