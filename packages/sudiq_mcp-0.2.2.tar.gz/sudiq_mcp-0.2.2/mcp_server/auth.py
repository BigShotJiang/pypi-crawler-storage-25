"""
MCP authentication.

The MCP server is a thin client of the SudIQ public API. Validating the
key, checking the tier, enforcing rate limits, and tracking usage all
happen at the API gateway. This module just resolves which key to use
and forwards a friendly error if none is configured.
"""

from mcp_server.api_client import get_api_client, set_api_key
from mcp_server.config import get_mcp_settings


def configure_api_key(api_key: str | None) -> None:
    """
    Set the API key for the lifetime of this server process.

    Resolution order:
        1. Explicit `--api-key` CLI flag
        2. SUDIQ_API_KEY environment variable
        3. .env file in the current working directory

    Raises:
        PermissionError: when no key can be resolved.
    """
    if api_key:
        set_api_key(api_key)
        return

    settings = get_mcp_settings()
    if not settings.sudiq_api_key:
        raise PermissionError(
            "No SudIQ API key configured. Pass --api-key, set SUDIQ_API_KEY, "
            "or add it to your MCP server config. Get a key at https://sudiq.com/signup."
        )

    # Force the singleton to instantiate now so we fail fast on bad config.
    get_api_client()
