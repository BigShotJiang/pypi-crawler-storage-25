"""
Entry point for the SudIQ MCP server.

Usage (after `pip install sudiq-mcp` or via uvx):
    sudiq-mcp
    sudiq-mcp --api-key sk_live_...
    SUDIQ_API_KEY=sk_live_... sudiq-mcp

Usage (from source checkout):
    python -m mcp_server
"""

import argparse
import asyncio
import sys

from mcp_server.server import run


def _maybe_load_dotenv() -> None:
    """Load a .env file if one is present in CWD. Silent no-op otherwise."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    load_dotenv()


def main():
    _maybe_load_dotenv()

    parser = argparse.ArgumentParser(description="SudIQ MCP Server")
    parser.add_argument(
        "--api-key",
        type=str,
        default=None,
        help="SudIQ API key (or set SUDIQ_API_KEY env var). Available on every paid tier.",
    )
    args = parser.parse_args()

    try:
        asyncio.run(run(api_key=args.api_key))
    except PermissionError as e:
        print(f"Authentication failed: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
