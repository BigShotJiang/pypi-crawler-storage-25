"""
SudIQ public-API HTTP client for the MCP server.

The MCP server runs on the customer's machine. It does NOT talk to
Supabase directly — that would require leaking the service-role key.
Instead it calls the same public REST API every other SudIQ customer
uses, authenticating with the customer's own API key.

All auth, rate limits, tier checks, and usage tracking happen at the
API gateway. The MCP server is a thin tool-call → HTTP shim plus
local logic for things like the comparison diff matrix.
"""

from __future__ import annotations

from typing import Any

import httpx

from mcp_server.config import get_mcp_settings


class APIError(Exception):
    """Wraps non-2xx responses from the SudIQ API in a way tools can return."""

    def __init__(self, status: int, message: str, detail: Any = None):
        self.status = status
        self.message = message
        self.detail = detail
        super().__init__(f"[{status}] {message}")


class SudIQClient:
    """Single persistent httpx.Client targeting api.sudiq.com (or override)."""

    def __init__(self, api_key: str, base_url: str | None = None, timeout: float = 30.0):
        if not api_key:
            raise ValueError("SUDIQ_API_KEY is required")
        settings = get_mcp_settings()
        self._base_url = (base_url or settings.sudiq_api_base).rstrip("/")
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={
                "X-API-Key": api_key,
                "User-Agent": "sudiq-mcp/0.2.2",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        self._http.close()

    # ── HTTP verbs ────────────────────────────────────────────────────────

    def get(self, path: str, params: dict | None = None) -> dict:
        return self._unwrap(self._http.get(path, params=_clean_params(params)))

    def post(self, path: str, json: dict | None = None) -> dict:
        return self._unwrap(self._http.post(path, json=json))

    # ── Response handling ─────────────────────────────────────────────────

    def _unwrap(self, resp: httpx.Response) -> dict:
        """
        Returns the `data` field of `{"success": true, "data": ...}` envelopes.
        Raises APIError on any non-2xx so tools can format the error to the agent.
        """
        if resp.is_success:
            try:
                body = resp.json()
            except ValueError:
                return {}
            if isinstance(body, dict) and "data" in body:
                return body["data"]
            return body  # already a list/dict, no envelope

        # Surface useful detail on 4xx/5xx
        try:
            payload = resp.json()
            detail = payload.get("detail") if isinstance(payload, dict) else payload
        except ValueError:
            detail = resp.text
        raise APIError(resp.status_code, _humanize_error(resp.status_code, detail), detail)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _clean_params(params: dict | None) -> dict | None:
    """Drop keys whose value is None so they don't show up as ?key= in the URL."""
    if not params:
        return None
    return {k: v for k, v in params.items() if v is not None}


def _humanize_error(status: int, detail: Any) -> str:
    """Convert API errors into messages that make sense to an agent's caller."""
    detail_str = str(detail) if detail is not None else ""
    if status == 401:
        return "Authentication failed. Check your SUDIQ_API_KEY is valid and active."
    if status == 402:
        return f"Subscription required: {detail_str}"
    if status == 403:
        return f"Access denied: {detail_str}"
    if status == 404:
        return "Not found."
    if status == 429:
        return "Rate limit exceeded. Wait a moment and try again."
    if 500 <= status:
        return "SudIQ API error. Try again in a moment."
    return detail_str or f"Request failed with status {status}"


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_client: SudIQClient | None = None


def get_api_client() -> SudIQClient:
    """Return a process-wide SudIQClient using the configured API key."""
    global _client
    if _client is None:
        settings = get_mcp_settings()
        if not settings.sudiq_api_key:
            raise PermissionError(
                "SUDIQ_API_KEY is not set. Get one at https://sudiq.com/signup "
                "and add it to your MCP config or environment."
            )
        _client = SudIQClient(api_key=settings.sudiq_api_key, base_url=settings.sudiq_api_base)
    return _client


def set_api_key(api_key: str) -> None:
    """Override the API key at runtime (used when --api-key is passed via CLI)."""
    global _client
    if _client is not None:
        _client.close()
    settings = get_mcp_settings()
    _client = SudIQClient(api_key=api_key, base_url=settings.sudiq_api_base)
