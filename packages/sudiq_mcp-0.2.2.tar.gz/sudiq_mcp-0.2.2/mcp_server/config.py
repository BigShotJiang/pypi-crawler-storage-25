"""
MCP server configuration.

Customers running the server only need SUDIQ_API_KEY. The server talks
to the SudIQ public API (X-API-Key auth), not to Supabase directly —
no service-role secret ever leaves SudIQ infrastructure.
"""

from functools import lru_cache

from pydantic_settings import BaseSettings


class MCPSettings(BaseSettings):
    sudiq_api_key: str = ""
    sudiq_api_base: str = "https://api.sudiq.com"

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }


@lru_cache()
def get_mcp_settings() -> MCPSettings:
    return MCPSettings()
