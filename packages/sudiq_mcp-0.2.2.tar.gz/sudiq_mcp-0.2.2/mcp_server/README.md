# sudiq-mcp

**Model Context Protocol server for [SudIQ](https://sudiq.com)** — connects your AI agent to label-verified ingredient panels, clinical dose context, and competitive intelligence across 6,200+ supplement products.

## Install

The recommended way to use this server is through [uvx](https://docs.astral.sh/uv/) directly from your agent's MCP config — no manual install required.

### Claude Desktop

Edit `claude_desktop_config.json`:

- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "sudiq": {
      "command": "uvx",
      "args": ["--from", "sudiq-mcp", "sudiq-mcp"],
      "env": {
        "SUDIQ_API_KEY": "sk_live_your_key_here"
      }
    }
  }
}
```

Restart Claude Desktop. Try a query: *"Compare the caffeine dosing in Ghost Legend vs C4 Original — which is closer to clinically effective range?"*

### Other agents / manual install

```bash
pip install sudiq-mcp
SUDIQ_API_KEY=sk_live_... sudiq-mcp
```

## Get an API key

Available on every paid SudIQ tier (starting at $99/mo). [Sign up at sudiq.com](https://sudiq.com).

## Tools exposed

| Tool | Purpose |
|------|---------|
| `compare_products` | Aligned diff matrix for 2–5 products: shared, missing, and differently-dosed ingredients |
| `check_dose_safety` | Verify a dose falls within the clinically studied range |
| `find_products_by_ingredient` | Find products containing an ingredient at or above a minimum dose |
| `get_ingredient_info` | Clinical dose ranges, forms, aliases, safety notes for any of 3,180 indexed ingredients |
| `get_product_ingredients` | Full structured ingredient list for a product by name |
| `get_product_label_status` | Verification confidence and label type for a product |
| `find_alternatives` | Alternative products in the same category, ranked by ingredient overlap |
| `search_products` | Keyword search across the catalog |

## License

Proprietary. Licensed for use with valid SudIQ API credentials. See [sudiq.com/terms](https://sudiq.com/terms).
