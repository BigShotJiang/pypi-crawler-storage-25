# gogkeep

Google Keep CLI matching the style and interface of [gogcli](https://github.com/steipete/gogcli).

## Installation

```bash
pip install .
```

Or for `pipx`:
```bash
pipx install .
```

## Authentication (Master Token Auth workflow)

Google Keep API access via `gkeepapi` requires a Master Token. To obtain it, use the `login` command:

```bash
gogkeep login --account your-email@gmail.com
```

Follow the instructions:
1. Visit [https://accounts.google.com/EmbeddedSetup](https://accounts.google.com/EmbeddedSetup) in your browser.
2. Log in to your Google account.
3. Open Developer Tools (F12) -> Application/Storage -> Cookies.
4. Find the `oauth_token` cookie (it starts with `oauth2_4/`).
5. Copy its value and paste it into the prompt.

The Master Token will be saved to `REDACTED_CREDS_DIR/google_oauth_master_token` for future use.

## Usage

### Root Flags
- `-a, --account EMAIL`: Set the account email (also can be set via `GOG_ACCOUNT` env var).
- `-j, --json`: Output as JSON.
- `-p, --plain`: Output as tab-separated values.
- `-n, --dry-run`: Do not make changes (mostly for `create` and `delete`).

### Commands

#### List Notes
```bash
gogkeep list --account your-email@gmail.com
```

#### Get Note
```bash
gogkeep get <note_id> --account your-email@gmail.com
```

#### Search Notes
```bash
gogkeep search "query text" --account your-email@gmail.com
```

#### Create Note
```bash
gogkeep create --title "My Title" --text "My body text" --account your-email@gmail.com
```

#### Delete Note
```bash
gogkeep delete <note_id> --account your-email@gmail.com
```

#### Download Attachment
```bash
gogkeep attachment <attachment_name> --out local_filename.jpg --account your-email@gmail.com
```
Attachment names are in the format `notes/<note_id>/attachments/<attachment_id>`.
