import json
import os
import sys

import click
from tabulate import tabulate

from .auth import login_flow
from .keep import create_note, delete_note, get_keep, get_note, list_notes, search_notes


def resolve_account(account):
    final_account = account or os.getenv("GOGKEEP_ACCOUNT")
    if not final_account:
        try:
            from .store import get_default_account

            final_account = get_default_account("default")
        except Exception:
            final_account = None
    return final_account


class RootFlags:
    def __init__(self, account, output_json=False, plain=False, verbose=False, dry_run=False):
        self.account = account
        self.output_json = output_json
        self.plain = plain
        self.verbose = verbose
        self.dry_run = dry_run


@click.group()
@click.option("--account", "-a", help="Account email for Keep API")
@click.option("--json", "-j", "output_json", is_flag=True, help="Output JSON to stdout")
@click.option("--plain", "-p", is_flag=True, help="Output stable, parseable text to stdout")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.option("--dry-run", "-n", is_flag=True, help="Do not make changes")
@click.pass_context
def main(ctx, account, output_json, plain, verbose, dry_run):
    """Google Keep CLI matching gog style."""
    final_account = resolve_account(account)
    ctx.obj = RootFlags(final_account, output_json, plain, verbose, dry_run)


@main.command()
@click.pass_obj
def login(root_flags):
    """Obtain a Master Token for Keep API access."""
    login_flow(root_flags.account)


def format_date(dt):
    # Match gogcli's time format if possible.
    # Usually it's RFC3339-ish.
    return dt.isoformat()


def note_snippet(note):
    text = getattr(note, "text", "")
    if not text and hasattr(note, "items"):
        text = " ".join([f"- {i.text}" for i in note.items[:3]])
    text = text.replace("\n", " ").strip()
    if len(text) > 50:
        text = text[:50] + "..."
    return text or "(no content)"


def print_notes(notes, output_json, plain):
    if output_json:
        data = {
            "notes": [
                {
                    "id": n.id,
                    "name": f"notes/{n.id}",
                    "title": n.title,
                    "updated": format_date(n.timestamps.updated),
                    "created": format_date(n.timestamps.created),
                    "text": getattr(n, "text", None),
                    "trashed": n.trashed,
                }
                for n in notes
            ]
        }
        click.echo(json.dumps(data, indent=2))
        return

    if not notes:
        click.echo("No notes", err=True)
        return

    table_data = []
    for n in notes:
        title = n.title or note_snippet(n)
        table_data.append([f"notes/{n.id}", title, format_date(n.timestamps.updated)])

    if plain:
        for row in table_data:
            click.echo("\t".join(map(str, row)))
    else:
        click.echo(tabulate(table_data, headers=["NAME", "TITLE", "UPDATED"], tablefmt="plain", disable_numparse=True))


@main.command(name="list")
@click.option("--max", "limit", default=100, help="Max results")
@click.pass_obj
def list_cmd(root_flags, limit):
    """List notes."""
    if not root_flags.account:
        click.echo("Error: --account is required.", err=True)
        sys.exit(1)

    try:
        keep = get_keep(root_flags.account)
        notes = list_notes(keep, max_results=limit)
        print_notes(notes, root_flags.output_json, root_flags.plain)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("query")
@click.pass_obj
def search(root_flags, query):
    """Search notes by text."""
    if not root_flags.account:
        click.echo("Error: --account is required.", err=True)
        sys.exit(1)

    try:
        keep = get_keep(root_flags.account)
        notes = search_notes(keep, query)
        print_notes(notes, root_flags.output_json, root_flags.plain)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("note_id")
@click.pass_obj
def get(root_flags, note_id):
    """Get a note's details."""
    if not root_flags.account:
        click.echo("Error: --account is required.", err=True)
        sys.exit(1)

    try:
        keep = get_keep(root_flags.account)
        note = get_note(keep, note_id)
        if not note:
            click.echo(f"Note not found: {note_id}", err=True)
            sys.exit(1)

        if root_flags.output_json:
            click.echo(
                json.dumps(
                    {
                        "id": note.id,
                        "name": f"notes/{note.id}",
                        "title": note.title,
                        "created": format_date(note.timestamps.created),
                        "updated": format_date(note.timestamps.updated),
                        "text": getattr(note, "text", None),
                        "items": [{"text": i.text, "checked": i.checked} for i in note.items]
                        if hasattr(note, "items")
                        else None,
                        "trashed": note.trashed,
                    },
                    indent=2,
                )
            )
            return

        click.echo(f"name\tnotes/{note.id}")
        click.echo(f"title\t{note.title}")
        click.echo(f"created\t{format_date(note.timestamps.created)}")
        click.echo(f"updated\t{format_date(note.timestamps.updated)}")
        click.echo(f"trashed\t{note.trashed}")

        click.echo("")
        if hasattr(note, "text") and note.text:
            click.echo(note.text)
        elif hasattr(note, "items"):
            for item in note.items:
                status = "[x]" if item.checked else "[ ]"
                click.echo(f"{status} {item.text}")

        # Attachments (images, audio, etc)
        blobs = []
        if hasattr(note, "images"):
            blobs.extend(note.images)
        if hasattr(note, "drawings"):
            blobs.extend(note.drawings)
        if hasattr(note, "audio"):
            blobs.extend(note.audio)
        if blobs:
            click.echo("")
            click.echo(f"attachments\t{len(blobs)}")
            for b in blobs:
                click.echo(f"  notes/{note.id}/attachments/{b.id}\t{getattr(b, 'type', 'blob')}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.option("--title", help="Note title")
@click.option("--text", help="Note body text")
@click.option("--item", "items", multiple=True, help="List item text (repeatable)")
@click.pass_obj
def create(root_flags, title, text, items):
    """Create a new note."""
    if not root_flags.account:
        click.echo("Error: --account is required for login.", err=True)
        sys.exit(1)

    if not text and not items:
        click.echo("Error: provide --text or at least one --item", err=True)
        sys.exit(1)

    try:
        keep = get_keep(root_flags.account)
        note = create_note(keep, title or "", text=text, items=items)
        if root_flags.output_json:
            click.echo(
                json.dumps(
                    {
                        "id": note.id,
                        "name": f"notes/{note.id}",
                        "title": note.title,
                        "created": format_date(note.timestamps.created),
                    },
                    indent=2,
                )
            )
        else:
            click.echo(f"name\tnotes/{note.id}")
            click.echo(f"title\t{note.title}")
            click.echo(f"created\t{format_date(note.timestamps.created)}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("note_id")
@click.pass_obj
def delete(root_flags, note_id):
    """Delete a note."""
    if not root_flags.account:
        click.echo("Error: --account is required.", err=True)
        sys.exit(1)

    try:
        keep = get_keep(root_flags.account)
        if delete_note(keep, note_id):
            if root_flags.output_json:
                click.echo(json.dumps({"deleted": True, "name": f"notes/{note_id}"}))
            else:
                click.echo("deleted\tTrue")
                click.echo(f"name\tnotes/{note_id}")
        else:
            click.echo(f"Error: Note not found: {note_id}", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("attachment_name")
@click.option("--out", help="Output file path")
@click.pass_obj
def attachment(root_flags, attachment_name, out):
    """Download an attachment."""
    if not root_flags.account:
        click.echo("Error: --account is required.", err=True)
        sys.exit(1)

    out_path = out
    if not out_path:
        parts = attachment_name.split("/")
        out_path = parts[-1]

    try:
        keep = get_keep(root_flags.account)
        from .keep import download_attachment

        bytes_written = download_attachment(keep, attachment_name, out_path)
        if bytes_written > 0:
            if root_flags.output_json:
                click.echo(json.dumps({"downloaded": True, "path": out_path, "bytes": bytes_written}))
            else:
                click.echo(f"path\t{out_path}")
                click.echo(f"bytes\t{bytes_written}")
        else:
            click.echo(f"Error: Attachment not found: {attachment_name}", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
