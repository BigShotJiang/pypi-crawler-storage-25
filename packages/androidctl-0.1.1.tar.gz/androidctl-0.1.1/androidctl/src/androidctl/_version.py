from __future__ import annotations

from androidctl_contracts._version_source import resolve_release_version

__version__ = resolve_release_version()
