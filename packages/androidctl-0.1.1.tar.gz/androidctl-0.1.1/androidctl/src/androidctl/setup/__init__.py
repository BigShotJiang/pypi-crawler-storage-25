"""Host-side setup helpers."""
