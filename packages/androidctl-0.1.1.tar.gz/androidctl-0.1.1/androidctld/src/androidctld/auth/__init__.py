"""Authentication helpers for androidctld."""
