"""Wait helpers for androidctld."""
