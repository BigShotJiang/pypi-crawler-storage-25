"""Command handling for androidctld."""
