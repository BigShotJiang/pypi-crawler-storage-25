"""Artifact writers for androidctld."""
