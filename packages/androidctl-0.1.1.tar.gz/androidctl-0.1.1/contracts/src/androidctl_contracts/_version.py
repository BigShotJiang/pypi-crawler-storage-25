from __future__ import annotations

from ._version_source import resolve_release_version

__version__ = resolve_release_version()
