"""Network + console observation. Subscribes to CDP events via the daemon's
event drain and groups them for LLM consumption."""
from __future__ import annotations

import time
from typing import Optional

from . import helpers as H


def network_requests(*, last_seconds: float = 30.0, limit: int = 100) -> list[dict]:
    """Recently-seen network requests. Filters chrome-internals out."""
    evs = H.peek_events() or []
    out = []
    cutoff = time.time() - last_seconds
    for ev in evs:
        if ev.get("ts", 0) < cutoff:
            continue
        m = ev.get("method", "")
        if not m.startswith("Network."):
            continue
        params = ev.get("params", {})
        if m == "Network.requestWillBeSent":
            req = params.get("request", {})
            url = req.get("url", "")
            if url.startswith(("chrome:", "chrome-extension:", "devtools:")):
                continue
            out.append({
                "id": params.get("requestId"),
                "url": url[:300],
                "method": req.get("method"),
                "type": params.get("type"),
                "ts": ev.get("ts"),
            })
        elif m == "Network.responseReceived":
            resp = params.get("response", {})
            url = resp.get("url", "")
            if url.startswith(("chrome:", "chrome-extension:", "devtools:")):
                continue
            out.append({
                "id": params.get("requestId"),
                "status": resp.get("status"),
                "url": url[:300],
                "mime_type": resp.get("mimeType"),
                "ts": ev.get("ts"),
            })
    return out[-limit:]


def console_logs(*, last_seconds: float = 30.0, limit: int = 100) -> list[dict]:
    """Recent console.log / warning / error from page."""
    evs = H.peek_events() or []
    out = []
    cutoff = time.time() - last_seconds
    for ev in evs:
        if ev.get("ts", 0) < cutoff:
            continue
        m = ev.get("method", "")
        if m not in ("Runtime.consoleAPICalled", "Log.entryAdded", "Runtime.exceptionThrown"):
            continue
        p = ev.get("params", {})
        if m == "Runtime.consoleAPICalled":
            args = p.get("args", [])
            text = " ".join(str(a.get("value") or a.get("description") or "") for a in args)
            out.append({"level": p.get("type", "log"), "text": text[:500], "ts": ev.get("ts")})
        elif m == "Log.entryAdded":
            entry = p.get("entry", {})
            out.append({"level": entry.get("level"), "text": (entry.get("text") or "")[:500], "ts": ev.get("ts")})
        elif m == "Runtime.exceptionThrown":
            exc = p.get("exceptionDetails", {})
            out.append({"level": "error", "text": (exc.get("text") or "")[:500], "ts": ev.get("ts")})
    return out[-limit:]
