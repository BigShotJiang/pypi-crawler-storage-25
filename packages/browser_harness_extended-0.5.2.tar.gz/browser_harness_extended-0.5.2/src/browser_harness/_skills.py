"""Skill registry: validate, package, publish, discover.

Bridges Layer 2 (per-user codified .py) to Layer 3 (cross-user public registry).

Workflow:
  1. After 3 successful runs (1 record + 2 replays at default threshold),
     _codify auto-promotes a trace to
     agent-workspace/domain-skills/<host>/<intent>.py (Sprint 3).
  2. User runs `browser-harness -c "publish_skill('<host>', '<intent>')"`
     which validates, sanitizes user-paths, packages, and either:
       - dry_run=True (default): prints manual git steps + package dir
       - dry_run=False: forks/pushes/opens-PR via `gh` CLI
  3. The registry repo's CI runs sandbox replay on the PR and gates merge.

Defaults to dry_run=True so we never accidentally push to a misconfigured
registry. The actual registry URL is configurable via BH_SKILLS_REGISTRY env
var or [skills] registry = "..." in bh-policy.toml.
"""
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def _registry_repo():
    """Resolve registry slug. Env var > policy > None (forces dry_run)."""
    env = os.environ.get("BH_SKILLS_REGISTRY")
    if env:
        return env
    try:
        from . import _policy
        return ((_policy._policy().get("skills") or {}).get("registry")) or None
    except Exception:
        return None


_SKILL_BANNER_CACHE = {"checked_today": False, "summary": None, "ts": 0}


def skills_banner():
    """v0.5.0: returns a one-line summary of local + registry skills the
    agent might find useful, based on locally-installed and recently-visited
    hosts. Designed to be printed on daemon startup or on first invocation
    of the day. Returns None when nothing notable to surface.

    Best-effort + cached for 24h: never blocks the daemon, never raises."""
    import time as _t
    try:
        now = _t.time()
        if _SKILL_BANNER_CACHE["checked_today"] and (now - _SKILL_BANNER_CACHE["ts"]) < 86400:
            return _SKILL_BANNER_CACHE["summary"]
        local = list_skills()
        local_hosts = sorted({s["host"] for s in local})
        local_count = len(local)
        auto_count = sum(1 for s in local if s.get("auto_codified"))
        repo = _registry_repo()
        parts = [f"{local_count} local skills across {len(local_hosts)} hosts"]
        if auto_count:
            parts.append(f"{auto_count} auto-codified")
        if repo:
            parts.append(f"registry: {repo}")
        else:
            parts.append("registry: unset (set BH_SKILLS_REGISTRY to enable publish)")
        summary = "[skills] " + " · ".join(parts)
        _SKILL_BANNER_CACHE.update(checked_today=True, summary=summary, ts=now)
        return summary
    except Exception:
        return None


def _agent_workspace():
    repo_root = Path(__file__).resolve().parents[2]
    return Path(os.environ.get("BH_AGENT_WORKSPACE", repo_root / "agent-workspace")).expanduser()


def _learn_dir():
    return Path(os.environ.get("BH_LEARN_DIR", Path.home() / ".browser-harness" / "learn")).expanduser()


# Secret detectors — pre-publish scan to catch credentials sneaking into source.
# Conservative — better a false-block here than a leaked token in a public PR.
# Audit (2026-05-09) expanded the pattern set after gaps surfaced in code review:
# Anthropic sk-ant-, Firebase AIzaSy, Google OAuth ya29, Slack tokens, GCP private
# key blocks, additional GitHub token formats, and fill_input on password-shaped
# fields with positional-arg secret values.
SECRET_PATTERNS = [
    (re.compile(r'BROWSER_USE_API_KEY\s*=\s*["\'][a-zA-Z0-9_\-]+["\']'), "BROWSER_USE_API_KEY literal"),
    (re.compile(r'(?i)(?:password|passwd|pwd|pass|auth|credential)s?\s*=\s*["\'][^"\']{4,}["\']'), "password-shaped literal"),
    (re.compile(r'(?i)api[_-]?key\s*=\s*["\'][^"\']{8,}["\']'), "api_key= literal"),
    (re.compile(r'(?i)secret\s*=\s*["\'][^"\']{8,}["\']'), "secret= literal"),
    (re.compile(r'(?i)access[_-]?token\s*=\s*["\'][^"\']{8,}["\']'), "access_token= literal"),
    (re.compile(r'Bearer\s+[a-zA-Z0-9_\-\.]{20,}'), "Bearer token"),
    (re.compile(r'sk-ant-(?:api|sid)[a-zA-Z0-9_\-]{20,}'), "Anthropic sk-ant-"),
    (re.compile(r'sk-[a-zA-Z0-9]{20,}'), "OpenAI-style sk-"),
    (re.compile(r'eyJ[a-zA-Z0-9_\-]{20,}\.[a-zA-Z0-9_\-]+\.[a-zA-Z0-9_\-]+'), "JWT"),
    (re.compile(r'AKIA[0-9A-Z]{16}'), "AWS access key"),
    (re.compile(r'(?:ghp|gho|ghu|ghs|ghr)_[a-zA-Z0-9]{36}'), "GitHub token"),
    (re.compile(r'github_pat_[A-Z0-9_]{82}'), "GitHub fine-grained PAT"),
    (re.compile(r'AIza[0-9A-Za-z_\-]{35}'), "Google API key (Firebase/GCP)"),
    (re.compile(r'ya29\.[0-9A-Za-z_\-]+'), "Google OAuth token"),
    (re.compile(r'xox[abprsoau]-[0-9A-Za-z_\-]{10,}'), "Slack token"),
    (re.compile(r'-----BEGIN\s+(?:RSA\s+|EC\s+|OPENSSH\s+|DSA\s+)?PRIVATE\s+KEY-----'), "Private key block"),
    (re.compile(r'fill_input\s*\(\s*["\'](?:#|\.)?(?:password|passwd|pwd|pass|secret|otp|2fa)[^"\']*["\']\s*,\s*["\'][^"\']{4,}["\']'), "fill_input with literal secret value"),
    (re.compile(r'\bSK[a-f0-9]{32}\b'), "Twilio API key"),
    (re.compile(r'\b(?:sk|pk|rk)_(?:live|test)_[a-zA-Z0-9]{24,}'), "Stripe API key"),
]


REQUIRED_FRONTMATTER_KEYS = ("host", "intent", "steps_skipped", "last_verified")


def _extract_frontmatter(src, *, strict=False):
    """Extract the YAML-subset frontmatter from a skill .py.

    Format: a `\"\"\"---\\n...---` block near the top of the file. Searches
    the first 2KB so leading shebang / encoding cookie / `from __future__`
    are tolerated.

    SCOPE: this is intentionally NOT a full YAML parser. It supports only
    `key: value` lines where the value is a string, int, or bool. Lists,
    nested mappings, multi-line strings, anchors, tags, and `&`/`*`
    references are NOT supported — they raise ValueError when strict=True
    or are silently dropped when strict=False (default).

    Colons inside values (URLs, paths, "topic:42") survive because we
    partition on the first colon only.

    Returns dict or {}.
    """
    m = re.search(r'"""---\n(.*?)\n---', src[:2000], re.DOTALL)
    if not m:
        return {}
    out = {}
    for line in m.group(1).splitlines():
        if not line or line.startswith("#"):
            continue
        # v0.5.0: strict mode flags unsupported YAML constructs explicitly
        # rather than silently mis-parsing them. Common cases:
        #   - List items: `  - item` or `- item`
        #   - Continuation lines: `    indented`
        if line.startswith(("-", " ", "\t")):
            if strict:
                raise ValueError(
                    f"frontmatter line {line!r} uses an unsupported YAML "
                    "construct (list / multi-line / continuation). This "
                    "parser supports only flat key:value pairs."
                )
            continue
        if ":" not in line:
            if strict:
                raise ValueError(f"frontmatter line {line!r} has no key:value separator")
            continue
        k, _, v = line.partition(":")
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if not k:
            if strict:
                raise ValueError(f"frontmatter line {line!r} has empty key")
            continue
        # Reject obvious nested-mapping flag in strict mode
        if strict and v.startswith(("[", "{", "&", "*", "!")):
            raise ValueError(
                f"frontmatter value for {k!r} starts with {v[0]!r} — "
                "lists/maps/anchors not supported."
            )
        try:
            out[k] = int(v)
        except ValueError:
            if v.lower() in ("true", "false"):
                out[k] = v.lower() == "true"
            else:
                out[k] = v
    return out


def list_skills():
    """List all locally codified skills under agent-workspace/domain-skills/.
    Returns list of {host, intent, path, ext, size, modified, auto_codified}."""
    base = _agent_workspace() / "domain-skills"
    if not base.is_dir():
        return []
    out = []
    for host_dir in sorted(base.iterdir()):
        if not host_dir.is_dir():
            continue
        for f in sorted(host_dir.iterdir()):
            if f.suffix not in (".py", ".md"):
                continue
            entry = {
                "host": host_dir.name,
                "intent": f.stem,
                "path": str(f),
                "ext": f.suffix,
                "size": f.stat().st_size,
                "modified": datetime.fromtimestamp(f.stat().st_mtime, tz=timezone.utc).isoformat(),
                "auto_codified": False,
            }
            if f.suffix == ".py":
                try:
                    fm = _extract_frontmatter(f.read_text())
                    entry["auto_codified"] = bool(fm.get("auto_codified"))
                    entry["steps_skipped"] = fm.get("steps_skipped")
                    entry["last_verified"] = fm.get("last_verified")
                except Exception:
                    pass
            out.append(entry)
    return out


def _verify_imports_resolve(src):
    """v0.5.0: parse a skill's `from browser_harness.helpers import X, Y, Z`
    line and confirm every named primitive exists in the current helpers
    module with the recorded arity. Catches version-drift where a codified
    skill from harness vN tries to call a primitive that vN+1 renamed.
    Returns list of error strings (empty = all imports resolve)."""
    import ast
    errors = []
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return errors  # syntax errors are reported separately
    imported = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == "browser_harness.helpers":
            imported.extend(alias.name for alias in node.names)
    if not imported:
        return errors
    try:
        from . import helpers
    except Exception as e:
        errors.append(f"could not import browser_harness.helpers for verification: {e}")
        return errors
    for name in imported:
        if not hasattr(helpers, name):
            errors.append(
                f"codified skill imports {name!r} from browser_harness.helpers, "
                "but the current harness version does not define it. Skill may "
                "have been written against an older harness; re-record needed."
            )
    return errors


def validate_skill(host, intent):
    """Pre-publish validation. Returns {ok, errors, warnings, path, frontmatter}."""
    errors, warnings = [], []
    skill_path = _agent_workspace() / "domain-skills" / host / f"{intent}.py"
    if not skill_path.exists():
        return {"ok": False, "errors": ["skill not found"], "warnings": [], "path": str(skill_path), "frontmatter": {}}
    src = skill_path.read_text()

    # Frontmatter check
    fm = _extract_frontmatter(src)
    if not fm:
        errors.append("missing or malformed YAML frontmatter at top of file")
    else:
        for key in REQUIRED_FRONTMATTER_KEYS:
            if key not in fm:
                errors.append(f"frontmatter missing required key: {key}")

    # Syntax
    try:
        ast.parse(src)
    except SyntaxError as e:
        errors.append(f"syntax error: {e}")
    # v0.5.0: verify every imported primitive still exists in helpers
    errors.extend(_verify_imports_resolve(src))

    # Secret scan
    for pat, label in SECRET_PATTERNS:
        if pat.search(src):
            errors.append(f"potential secret detected ({label}) — refusing to publish")

    # Size sanity
    if len(src) > 50_000:
        warnings.append(f"skill is {len(src)} bytes — consider trimming")
    if len(src) < 80:
        warnings.append("skill is suspiciously short")

    # User-home leak warning
    home = str(Path.home())
    if home in src and home != "/":
        warnings.append(f"absolute home path {home!r} present in source — package_skill will sanitize")

    return {"ok": not errors, "errors": errors, "warnings": warnings,
            "path": str(skill_path), "frontmatter": fm}


def package_skill(host, intent, *, output_dir=None):
    """Produce a publish-ready package directory.
    Sanitizes absolute home paths from source. Returns {ok, package_dir, manifest, errors, warnings}."""
    val = validate_skill(host, intent)
    if not val["ok"]:
        return {"ok": False, "errors": val["errors"], "warnings": val["warnings"],
                "package_dir": None, "manifest": None}

    skill_path = Path(val["path"])
    src = skill_path.read_text()
    home = str(Path.home())
    src_sanitized = src.replace(home, "~") if home != "/" else src

    sha256 = hashlib.sha256(src_sanitized.encode()).hexdigest()[:16]

    trace_path = _learn_dir() / host / f"{intent}.json"
    trace_data = None
    if trace_path.exists():
        try:
            trace_data = json.loads(trace_path.read_text())
            # Sanitize user-specific fields
            trace_data.pop("codified_path", None)
            if "source_trace" in trace_data:
                trace_data["source_trace"] = trace_data["source_trace"].replace(home, "~")
            # P0-2 (Hermes audit): trace step args/kwargs can carry secrets
            # (e.g. fill_input password values, type_text passphrases). The
            # validate_skill scanner only sees skill.py, not trace.json. Run
            # the same SECRET_PATTERNS over a flattened JSON dump of the
            # trace before letting it leave this machine.
            trace_blob = json.dumps(trace_data, default=str)
            for pat, label in SECRET_PATTERNS:
                if pat.search(trace_blob):
                    return {"ok": False, "errors": [f"trace.json contains potential secret ({label}) — refusing to publish"],
                            "warnings": val["warnings"], "package_dir": None, "manifest": None}
        except json.JSONDecodeError:
            trace_data = None
        except Exception:
            trace_data = None

    pkg_dir = Path(output_dir) if output_dir else Path(tempfile.gettempdir()) / f"bh-skill-{host}-{intent}"
    if pkg_dir.exists():
        shutil.rmtree(pkg_dir)
    pkg_dir.mkdir(parents=True)

    (pkg_dir / "skill.py").write_text(src_sanitized)
    if trace_data is not None:
        (pkg_dir / "trace.json").write_text(json.dumps(trace_data, indent=2))

    # Sanitize frontmatter values too — source_trace path commonly carries $HOME
    sanitized_fm = {
        k: (v.replace(home, "~") if isinstance(v, str) and home != "/" and home in v else v)
        for k, v in val["frontmatter"].items()
    }
    manifest = {
        "host": host,
        "intent": intent,
        "sha256": sha256,
        "skill_bytes": len(src_sanitized),
        "skill_lines": len(src_sanitized.splitlines()),
        "step_count": len(trace_data.get("steps", [])) if trace_data else 0,
        "packaged_at": datetime.now(timezone.utc).isoformat(),
        "frontmatter": sanitized_fm,
    }
    (pkg_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return {"ok": True, "package_dir": str(pkg_dir), "manifest": manifest,
            "errors": [], "warnings": val["warnings"]}


def publish_skill(host, intent, *, registry_repo=None, dry_run=True, branch=None):
    """Publish a packaged skill to the registry repo.
    Defaults to dry_run=True — prints manual steps without touching git/network.

    With dry_run=False, requires `gh` CLI installed and authenticated AND that
    you have push access to the registry repo (or its default branch is
    permissive). The function does NOT call `gh repo fork` — it does
    `gh repo clone <repo>` then pushes a branch back to the same origin and
    opens a PR. If you lack push access, fork the registry manually first
    and pass the fork as `registry_repo`.

    Returns {ok, dry_run, package_dir, manifest, instructions|pr_url, errors}.
    """
    pkg = package_skill(host, intent)
    if not pkg["ok"]:
        return {"ok": False, "step": "package", "errors": pkg["errors"], "warnings": pkg["warnings"]}

    repo = registry_repo or _registry_repo()
    branch = branch or f"skill/{host}-{intent}"

    # Local-only mode forces dry-run even when caller asked for live publish.
    # The contract is "no harness-initiated network egress under BH_LOCAL_ONLY=1".
    from . import _egress
    if not dry_run and _egress.is_local_only():
        dry_run = True

    if dry_run or repo is None or shutil.which("gh") is None:
        reason = "dry_run" if dry_run else ("no_registry_configured" if repo is None else "gh_not_installed")
        if _egress.is_local_only():
            reason = "local_only_forced_dry_run"
        return {
            "ok": True,
            "dry_run": True,
            "reason": reason,
            "package_dir": pkg["package_dir"],
            "manifest": pkg["manifest"],
            "warnings": pkg["warnings"],
            "instructions": [
                f"Manual publish steps for {host}/{intent}:",
                f"  1. Set BH_SKILLS_REGISTRY=<owner>/<repo> (or [skills] registry in bh-policy.toml)" if repo is None else f"  1. Registry: {repo}",
                f"  2. Fork {repo or '<your registry>'} on GitHub",
                f"  3. git clone your fork && cd into it",
                f"  4. git checkout -b {branch}",
                f"  5. mkdir -p skills/{host}/{intent}",
                f"  6. cp {pkg['package_dir']}/* skills/{host}/{intent}/",
                f"  7. git add skills/{host}/{intent}/ && git commit -m 'add {host}/{intent} skill'",
                f"  8. git push -u origin {branch}",
                f"  9. Open PR against {repo or '<registry>'}",
            ],
        }

    # Live publish
    try:
        clone_dir = Path(tempfile.gettempdir()) / f"bh-registry-{host}-{intent}"
        if clone_dir.exists():
            shutil.rmtree(clone_dir)
        subprocess.run(["gh", "repo", "clone", repo, str(clone_dir)],
                       check=True, capture_output=True, text=True)
        skill_dir = clone_dir / "skills" / host / intent
        skill_dir.mkdir(parents=True, exist_ok=True)
        for f in Path(pkg["package_dir"]).iterdir():
            shutil.copy(f, skill_dir / f.name)
        subprocess.run(["git", "-C", str(clone_dir), "checkout", "-b", branch],
                       check=True, capture_output=True, text=True)
        subprocess.run(["git", "-C", str(clone_dir), "add", "."],
                       check=True, capture_output=True, text=True)
        subprocess.run(["git", "-C", str(clone_dir), "commit", "-m", f"add {host}/{intent} skill"],
                       check=True, capture_output=True, text=True)
        subprocess.run(["git", "-C", str(clone_dir), "push", "-u", "origin", branch],
                       check=True, capture_output=True, text=True)
        result = subprocess.run(
            ["gh", "pr", "create", "--title", f"add {host}/{intent} skill",
             "--body", f"Auto-codified skill for {host}/{intent}.\n\n"
                       f"Manifest: ```json\n{json.dumps(pkg['manifest'], indent=2)}\n```"],
            cwd=str(clone_dir), check=True, capture_output=True, text=True
        )
        return {"ok": True, "dry_run": False, "pr_url": result.stdout.strip(),
                "package_dir": pkg["package_dir"], "manifest": pkg["manifest"],
                "warnings": pkg["warnings"]}
    except subprocess.CalledProcessError as e:
        return {"ok": False, "step": "gh_publish",
                "errors": [f"{e.cmd}: {e.stderr or e.stdout or str(e)}"]}
    except Exception as e:
        return {"ok": False, "step": "gh_publish", "errors": [repr(e)]}
