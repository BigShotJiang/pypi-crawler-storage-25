"""Trust-layer policy file. Lives at one of:
  1. $BH_POLICY_FILE
  2. ./bh-policy.toml         (project-local)
  3. ~/.browser-harness/policy.toml  (user-global)
First match wins. If none exist, defaults are used (matches today's behavior:
strict same-origin enforcement).

Schema (all sections + keys are optional):

  [http_get]
  allow_cross_origin_to = ["api.github.com", "*.amazonaws.com"]
  # Glob patterns (fnmatch). When http_get(url) target host matches one of
  # these, the cross-origin block is bypassed regardless of page origin.

  [js]
  allow_sensitive_on = ["docs.example.com", "*.internal.corp"]
  # Glob patterns of CURRENT PAGE hostnames where document.cookie /
  # localStorage / cross-origin fetch in js() are permitted.

  [auth_walls]
  domains = ["accounts.google.com", "login.microsoftonline.com"]
  # Hostnames (or hostname/path prefixes) where the agent should refuse
  # to type credentials. Currently advisory — surfaced via is_auth_wall().

  [skills]
  require_signed = false
  require_verified_within_days = 30
  # Reserved for Sprint 4 (skill registry trust tiers). Loaded but not enforced yet.
"""
import fnmatch
import os
import sys
import tomllib
from pathlib import Path

DEFAULT_AUTH_WALLS = [
    "accounts.google.com",
    "login.microsoftonline.com",
    "appleid.apple.com",
    "github.com/login",
    "login.live.com",
    "login.yahoo.com",
]


def _candidate_paths():
    """Resolution order: env override -> project-local -> user-global."""
    env = os.environ.get("BH_POLICY_FILE")
    if env:
        yield Path(env).expanduser()
    yield Path.cwd() / "bh-policy.toml"
    yield Path.home() / ".browser-harness" / "policy.toml"


_cached = None
_cached_path = None
_cached_mtime = None


def reload_policy():
    """Force-reload the policy file. Returns (policy_dict, path_or_None)."""
    global _cached, _cached_path, _cached_mtime
    _cached = None
    _cached_path = None
    _cached_mtime = None
    for path in _candidate_paths():
        if path.is_file():
            try:
                with open(path, "rb") as f:
                    _cached = tomllib.load(f)
                _cached_path = path
                try: _cached_mtime = path.stat().st_mtime
                except Exception: _cached_mtime = None
                return _cached, _cached_path
            except Exception as e:
                print(f"[browser-harness] policy file {path} unreadable: {e}", file=sys.stderr)
                continue
    _cached = {}
    _cached_path = None
    _cached_mtime = None
    return _cached, _cached_path


def _policy():
    """Lazy load + mtime-based invalidation. If the policy file on disk has
    been edited since we cached it — OR if no policy was loaded but one has
    since been CREATED on disk — transparently reload."""
    global _cached
    if _cached is None:
        reload_policy()
        return _cached or {}
    # Auto-invalidate on file mtime change (long-running daemons + edits)
    if _cached_path and _cached_mtime is not None:
        try:
            current_mtime = _cached_path.stat().st_mtime
            if current_mtime != _cached_mtime:
                reload_policy()
        except Exception: pass
    elif _cached_path is None:
        # P1-3 (Hermes audit): we previously had no policy file. Check if one
        # has been created since (e.g., user wrote ./bh-policy.toml after
        # the daemon started). Cheap probe — just stat the candidate paths.
        for path in _candidate_paths():
            if path.is_file():
                reload_policy()
                break
    return _cached or {}


def policy_path():
    """Return the loaded policy file path, or None if defaults are in use."""
    if _cached is None:
        reload_policy()
    return _cached_path


def http_get_cross_origin_allowed(target_host):
    """Is this target host on the http_get cross-origin allowlist?"""
    if not target_host:
        return False
    patterns = (_policy().get("http_get", {}) or {}).get("allow_cross_origin_to", []) or []
    return any(fnmatch.fnmatch(target_host.lower(), p.lower()) for p in patterns)


def js_sensitive_allowed_on(page_host):
    """Is the current page host on the js() sensitive-call allowlist?"""
    if not page_host:
        return False
    patterns = (_policy().get("js", {}) or {}).get("allow_sensitive_on", []) or []
    return any(fnmatch.fnmatch(page_host.lower(), p.lower()) for p in patterns)


def is_auth_wall(host_or_url):
    """Return True if the given host (or full URL) is on the auth-wall list."""
    if not host_or_url:
        return False
    h = host_or_url
    if "://" in h:
        from urllib.parse import urlparse
        p = urlparse(h)
        h = (p.hostname or "") + (p.path or "")
    h = h.lower()
    walls = (_policy().get("auth_walls", {}) or {}).get("domains", None)
    if walls is None:
        walls = DEFAULT_AUTH_WALLS
    return any(w.lower() in h for w in walls)
