"""Auto-codification: promote a successful trace into a committable .py skill.

After a trace's success_count crosses CODIFY_THRESHOLD (default 3 — note
this counts the initial autotrace recording, so the trigger is 1 record +
2 replays, not 3 separate replays), the next successful replay calls
auto_codify_if_ready() which generates a deterministic Python skill at
agent-workspace/domain-skills/<host>/<intent>.py.

The generated skill is *literal replay* — every recorded step becomes one
Python call with the recorded args. The user can then hand-edit to add
parameters, error handling, or branching. v1 is intentionally dumb;
the smart parameterization is v2 (multiple-trace merge) or v3 (LLM polish).

Storage:
  Source trace: ~/.browser-harness/learn/<host>/<intent>.json (managed by _trace)
  Output skill: BH_AGENT_WORKSPACE/domain-skills/<host>/<intent>.py
"""
import json, os, re
from datetime import datetime, timezone
from pathlib import Path

CODIFY_THRESHOLD = int(os.environ.get("BH_CODIFY_THRESHOLD", "3"))


def _agent_workspace():
    repo_root = Path(__file__).resolve().parents[2]
    return Path(os.environ.get("BH_AGENT_WORKSPACE", repo_root / "agent-workspace")).expanduser()


def _learn_dir():
    return Path(os.environ.get("BH_LEARN_DIR", Path.home() / ".browser-harness" / "learn")).expanduser()


def _now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_intent_for_filename(intent):
    """Sanity-check the intent slug. Must be Python-identifier-safe so the
    generated function name doesn't collide with keywords or fail to import."""
    if not re.match(r"^[a-z][a-z0-9_]*$", intent):
        raise ValueError(f"intent {intent!r} must be lowercase, start with a letter, "
                         "and contain only [a-z0-9_]. Rename via the autotrace() call.")
    return intent


def _render_arg(v):
    """Render a recorded JSON-safe value as a Python literal."""
    if v is None or isinstance(v, (bool, int, float)):
        return repr(v)
    if isinstance(v, str):
        return repr(v)
    if isinstance(v, list):
        return "[" + ", ".join(_render_arg(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ", ".join(f"{k!r}: {_render_arg(val)}" for k, val in v.items()) + "}"
    return repr(v)


def _render_call(step):
    fn = step["fn"]
    args = step.get("args", [])
    kwargs = step.get("kwargs", {})
    parts = [_render_arg(a) for a in args]
    parts += [f"{k}={_render_arg(v)}" for k, v in kwargs.items()]
    return f"    {fn}({', '.join(parts)})"


def codify_trace(host, intent, *, force=False):
    """Generate a .py skill from the trace at <learn>/<host>/<intent>.json.
    Writes to <workspace>/domain-skills/<host>/<intent>.py.
    Returns {ok, path, reason, fn_count, step_count}.
    Will not overwrite an existing .py unless force=True."""
    # P2-2 (Hermes audit): host validation matches _trace's regex
    from . import _trace
    _trace._validate_host_intent(host, intent)
    _safe_intent_for_filename(intent)
    trace_path = _learn_dir() / host / f"{intent}.json"
    if not trace_path.exists():
        return {"ok": False, "reason": "no_trace", "path": None}
    try:
        trace = json.loads(trace_path.read_text())
    except Exception as e:
        return {"ok": False, "reason": f"trace_unreadable: {e}", "path": None}

    out_dir = _agent_workspace() / "domain-skills" / host
    out_path = out_dir / f"{intent}.py"
    if out_path.exists() and not force:
        return {"ok": False, "reason": "skill_exists_use_force", "path": str(out_path)}

    steps = trace.get("steps", [])
    fns_used = sorted({s["fn"] for s in steps})
    if not fns_used:
        return {"ok": False, "reason": "trace_empty", "path": None}

    fm = (
        '"""---\n'
        f"host: {host}\n"
        f"intent: {intent}\n"
        f"steps_skipped: {len(steps)}\n"
        f"last_verified: {datetime.now(timezone.utc).date().isoformat()}\n"
        f"success_count: {trace.get('success_count', 0)}\n"
        f"source_trace: {trace_path}\n"
        f"auto_codified: true\n"
        "---\n\n"
        f"Auto-codified from {trace.get('success_count', '?')} successful replays of "
        f"trace {host}/{intent}.\n\n"
        "v1 is literal replay. Hand-edit to parameterize, branch, or add error handling.\n"
        '"""\n'
    )
    imports = f"from browser_harness.helpers import {', '.join(fns_used)}\n\n\n"
    sig = f"def {intent}():\n    \"\"\"Replay the recorded {host}/{intent} flow.\"\"\"\n"
    body = "\n".join(_render_call(s) for s in steps) + "\n"
    src = fm + imports + sig + body

    out_dir.mkdir(parents=True, exist_ok=True)
    out_path.write_text(src)

    try:
        trace["codified_at"] = _now_iso()
        trace["codified_path"] = str(out_path)
        trace_path.write_text(json.dumps(trace, indent=2))
    except Exception:
        pass

    return {"ok": True, "path": str(out_path), "fn_count": len(fns_used),
            "step_count": len(steps), "reason": None}


def auto_codify_if_ready(host, intent, *, threshold=None):
    """Check if a trace has been replayed enough times to deserve codification.
    Called automatically by replay_skill() on every successful replay.
    Idempotent — silently no-ops if already codified or below threshold."""
    threshold = threshold if threshold is not None else CODIFY_THRESHOLD
    trace_path = _learn_dir() / host / f"{intent}.json"
    if not trace_path.exists():
        return {"ok": False, "reason": "no_trace"}
    try:
        trace = json.loads(trace_path.read_text())
    except Exception:
        return {"ok": False, "reason": "trace_unreadable"}
    if trace.get("success_count", 0) < threshold:
        return {"ok": False, "reason": "below_threshold",
                "success_count": trace.get("success_count", 0), "threshold": threshold}
    if trace.get("codified_path"):
        return {"ok": False, "reason": "already_codified", "path": trace["codified_path"]}
    out_path = _agent_workspace() / "domain-skills" / host / f"{intent}.py"
    if out_path.exists():
        return {"ok": False, "reason": "skill_file_already_exists", "path": str(out_path)}
    return codify_trace(host, intent, force=False)
