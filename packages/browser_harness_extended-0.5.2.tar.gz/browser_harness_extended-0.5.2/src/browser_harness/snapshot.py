"""Page accessibility snapshot — Playwright MCP's killer feature, for our daemon.

Walk the DevTools `Accessibility.getFullAXTree` and emit a compact JSON view.
Each node gets a stable `ref` you can pass to `click_ref` / `type_in_ref`.

This is FAR cheaper than screenshot+vision: a typical page is 3-15 KB of JSON
vs 200-800 KB of base64 image data, AND the LLM can reason structurally
("click the button labeled 'Sign in'") without doing computer vision.
"""
from __future__ import annotations

import threading
from typing import Optional

from . import helpers as H


# Stable ref → backendDOMNodeId (or AX nodeId)
_REFS: dict[str, dict] = {}
_LOCK = threading.Lock()
_NEXT = 0


def _register(node: dict) -> str:
    global _NEXT
    with _LOCK:
        _NEXT += 1
        ref = f"r{_NEXT}"
        _REFS[ref] = node
        return ref


def lookup_ref(ref: str) -> Optional[dict]:
    return _REFS.get(ref)


def clear_refs() -> int:
    with _LOCK:
        n = len(_REFS)
        _REFS.clear()
        return n


# ARIA roles considered actionable / important
ACTIONABLE = frozenset({
    "button", "link", "checkbox", "textbox", "combobox", "menuitem", "menu",
    "menuitemcheckbox", "menuitemradio", "option", "radio", "searchbox",
    "slider", "spinbutton", "switch", "tab", "treeitem",
})

INFORMATIONAL = frozenset({
    "heading", "paragraph", "list", "listitem", "table", "row", "cell",
    "img", "figure", "form", "search", "navigation", "main", "article",
    "section", "dialog", "alertdialog", "alert", "status",
})


def _ax_value(prop_dict: dict | None) -> str | None:
    if not prop_dict:
        return None
    v = prop_dict.get("value")
    if v is None:
        return None
    return str(v)


def _node_summary(node: dict) -> dict:
    """Compact dict for one AX node. Skip if not informative."""
    role = _ax_value(node.get("role")) or ""
    name = _ax_value(node.get("name")) or ""
    value = _ax_value(node.get("value")) or ""
    description = _ax_value(node.get("description")) or ""

    if role in ("none", "presentation", "generic", "InlineTextBox", "StaticText", "RootWebArea") and not name:
        return {}
    if not role and not name:
        return {}

    out: dict = {}
    if role:
        out["role"] = role
    if name:
        out["name"] = name[:120]
    if value:
        out["value"] = value[:120]
    if description and description != name:
        out["desc"] = description[:120]

    # Useful properties
    for prop in node.get("properties", []) or []:
        pname = prop.get("name", "")
        pval = prop.get("value", {}).get("value")
        if pname == "focusable" and pval is False:
            continue
        if pname in ("disabled", "expanded", "checked", "selected", "required",
                     "invalid", "level") and pval is not None:
            out[pname] = pval

    return out


def _walk(nodes_by_id: dict, root_id: str, depth: int, max_depth: int,
          counters: dict, max_nodes: int) -> Optional[dict]:
    if counters["seen"] >= max_nodes:
        return None
    counters["seen"] += 1

    node = nodes_by_id.get(root_id)
    if node is None:
        return None
    summary = _node_summary(node)

    kids: list[dict] = []
    if depth < max_depth:
        for cid in node.get("childIds", []) or []:
            child = _walk(nodes_by_id, cid, depth + 1, max_depth, counters, max_nodes)
            if child:
                kids.append(child)

    role = summary.get("role", "")
    keep_self = bool(summary.get("name") or summary.get("value")
                     or role in ACTIONABLE or role in INFORMATIONAL)

    if not keep_self and not kids:
        return None
    if not keep_self and len(kids) == 1:
        return kids[0]

    if keep_self:
        summary["ref"] = _register({"backendDOMNodeId": node.get("backendDOMNodeId"),
                                     "nodeId": node.get("nodeId"), "role": role})
        if role in ACTIONABLE:
            counters["actionable"] += 1

    if kids:
        summary["children"] = kids
    return summary


def accessibility_snapshot(*, max_nodes: int = 800, max_depth: int = 30,
                           target_id: str | None = None) -> dict:
    """ONE CDP roundtrip → compact LLM-ready JSON of the page's a11y tree.

    Each clickable element gets a stable `ref` like "r42" you can pass to
    `click_ref` / `type_in_ref` / `read_ref`.
    """
    res = H.cdp("Accessibility.getFullAXTree", session_id=target_id) or {}
    nodes = res.get("nodes", [])
    by_id = {n["nodeId"]: n for n in nodes}
    if not nodes:
        return {"summary": {"actionable": 0, "total_seen": 0}, "tree": []}
    root_id = nodes[0]["nodeId"]
    counters = {"seen": 0, "actionable": 0}
    tree = _walk(by_id, root_id, 0, max_depth, counters, max_nodes)
    return {
        "summary": {
            "actionable": counters["actionable"],
            "total_seen": counters["seen"],
            "truncated": counters["seen"] >= max_nodes,
        },
        "tree": [tree] if tree else [],
    }


def _resolve_ref_to_object_id(ref: str, target_id: str | None = None) -> str | None:
    info = lookup_ref(ref)
    if info is None:
        return None
    backend_id = info.get("backendDOMNodeId")
    if backend_id is None:
        return None
    res = H.cdp("DOM.resolveNode", session_id=target_id, backendNodeId=backend_id)
    return (res or {}).get("object", {}).get("objectId")


def click_ref(ref: str, target_id: str | None = None) -> dict:
    """Click the element identified by `ref` (from accessibility_snapshot)."""
    obj_id = _resolve_ref_to_object_id(ref, target_id)
    if obj_id is None:
        return {"ok": False, "error": f"unknown or stale ref: {ref}"}
    # Get the bounding box and click the center.
    res = H.cdp("Runtime.callFunctionOn", session_id=target_id,
                objectId=obj_id, returnByValue=True,
                functionDeclaration="""
                    function() {
                      this.scrollIntoView({block:'center', inline:'center'});
                      const r = this.getBoundingClientRect();
                      return {x: r.left + r.width/2, y: r.top + r.height/2};
                    }
                """)
    coords = (res or {}).get("result", {}).get("value")
    if not coords:
        return {"ok": False, "error": "could not compute element bounds"}
    H.click_at_xy(int(coords["x"]), int(coords["y"]))
    return {"ok": True, "x": coords["x"], "y": coords["y"]}


def type_in_ref(ref: str, text: str, *, clear_first: bool = False,
                target_id: str | None = None) -> dict:
    """Focus an input ref and type text into it."""
    obj_id = _resolve_ref_to_object_id(ref, target_id)
    if obj_id is None:
        return {"ok": False, "error": f"unknown or stale ref: {ref}"}
    H.cdp("Runtime.callFunctionOn", session_id=target_id, objectId=obj_id,
          functionDeclaration="""function(){this.focus();}""")
    if clear_first:
        H.press_key("a", modifiers=4)  # cmd+a (macOS)
        H.press_key("Backspace")
    H.type_text(text)
    return {"ok": True, "typed": len(text)}


def read_ref(ref: str, *, target_id: str | None = None) -> dict:
    """Read .value or .innerText of an element by ref."""
    obj_id = _resolve_ref_to_object_id(ref, target_id)
    if obj_id is None:
        return {"ok": False, "error": f"unknown or stale ref: {ref}"}
    res = H.cdp("Runtime.callFunctionOn", session_id=target_id, objectId=obj_id,
                returnByValue=True,
                functionDeclaration="""
                    function(){ return this.value !== undefined ? this.value : this.innerText; }
                """)
    return {"ok": True, "value": (res or {}).get("result", {}).get("value")}
