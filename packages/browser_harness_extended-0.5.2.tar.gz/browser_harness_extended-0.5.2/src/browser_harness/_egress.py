"""Local-only egress gate (EU-friendly mode).

When BH_LOCAL_ONLY=1 (or [network] local_only = true in bh-policy.toml):
  • http_get refuses to route through the fetch-use proxy (no traffic leaves
    via Browser-Use Cloud); falls back to direct urllib.
  • start_remote_daemon refuses (cloud session creation forbidden).
  • The auto-update check in run.py is skipped (no GitHub ping).

Local-only does NOT block the user's own page navigations — those are
inherent to driving a browser. It blocks every HARNESS-initiated network
egress beyond what's strictly needed to control the local Chrome process.

This is the EU/GDPR wedge. Codex routes everything through OpenAI's cloud;
they structurally cannot offer this mode."""
import os


def is_local_only():
    """True iff local-only egress is enforced.
    Checked at every harness-initiated egress point."""
    if os.environ.get("BH_LOCAL_ONLY") == "1":
        return True
    try:
        from . import _policy
        net = _policy._policy().get("network") or {}
        return bool(net.get("local_only"))
    except Exception:
        return False


class LocalOnlyError(Exception):
    """Raised when an egress that would leave the device is attempted under
    local-only mode. Use the message to instruct the user how to opt out."""

    def __init__(self, action, hint=""):
        msg = f"local-only mode: {action} blocked"
        if hint:
            msg += f" — {hint}"
        msg += " (unset BH_LOCAL_ONLY or set [network] local_only = false in bh-policy.toml to allow)"
        super().__init__(msg)


def assert_local_egress_allowed(action, *, hint=""):
    """Convenience: raise LocalOnlyError if the harness is in local-only mode."""
    if is_local_only():
        raise LocalOnlyError(action, hint=hint)
