"""Per-user shadow cache: record successful agent flows, replay them deterministically.

After the first successful run + 2 replays (default), the trace is a
candidate for codification into a .py skill (Sprint 3 / _codify.py).
Note: the threshold counts the initial recording — so 1 record + 2 replays
is the codification trigger, not 3 separate replays.

Storage: ~/.browser-harness/learn/<host>/<intent>.json"""
import functools, json, os, re, threading, time
from datetime import datetime, timezone
from pathlib import Path

# P2-2 (Hermes audit): guard against path-traversal via untrusted host/intent.
# Both come from autotrace() arguments; if those are ever supplied from
# an external source (skill PR, agent prompt), `host="../../etc"` would
# write outside the learn dir. Validate at the IPC boundary.
_SAFE_HOST = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9.\-_]{0,253}$")
_SAFE_INTENT = re.compile(r"^[a-z][a-z0-9_]{0,127}$")


def _validate_host_intent(host, intent):
    if not isinstance(host, str) or not _SAFE_HOST.match(host):
        raise ValueError(f"host {host!r} must be a hostname-safe string [a-zA-Z0-9.\\-_]")
    if not isinstance(intent, str) or not _SAFE_INTENT.match(intent):
        raise ValueError(f"intent {intent!r} must be a Python-identifier-safe slug [a-z][a-z0-9_]*")


def _learn_dir():
    return Path(os.environ.get("BH_LEARN_DIR", Path.home() / ".browser-harness" / "learn")).expanduser()


# Thread-local current recorder (one trace recording active per thread max)
_state = threading.local()


def _now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_jsonable(x):
    """Coerce args/kwargs to JSON-safe values.

    Default: falls back to repr() for unknown types — replay then passes the
    repr-string to the target function which will fail with a wrong-type error.

    Strict mode (BH_TRACE_STRICT_JSON=1): raises TypeError on unknown types
    instead of silently producing a string. Catches type-drift bugs at record
    time rather than at replay time."""
    if x is None or isinstance(x, (bool, int, float, str)): return x
    if isinstance(x, (list, tuple)): return [_safe_jsonable(v) for v in x]
    if isinstance(x, dict): return {str(k): _safe_jsonable(v) for k, v in x.items()}
    if os.environ.get("BH_TRACE_STRICT_JSON") == "1":
        raise TypeError(
            f"trace arg of type {type(x).__name__} is not JSON-safe. "
            "Set BH_TRACE_STRICT_JSON=0 (or unset) to allow repr() fallback."
        )
    return repr(x)


class Recorder:
    def __init__(self, host, intent):
        _validate_host_intent(host, intent)
        self.host = host
        self.intent = intent
        self.steps = []
        self.started_at = _now_iso()

    def append(self, fn_name, args, kwargs, elapsed):
        self.steps.append({
            "i": len(self.steps),
            "fn": fn_name,
            "args": _safe_jsonable(list(args)),
            "kwargs": _safe_jsonable(kwargs),
            "elapsed": round(elapsed, 3),
        })

    def save(self):
        path = _learn_dir() / self.host / f"{self.intent}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        prior = {}
        if path.exists():
            try: prior = json.loads(path.read_text())
            except Exception: prior = {}
        trace = {
            "version": 1,
            "host": self.host,
            "intent": self.intent,
            "created_at": prior.get("created_at", self.started_at),
            "last_used_at": _now_iso(),
            "success_count": prior.get("success_count", 0) + 1,
            "steps": self.steps,
        }
        path.write_text(json.dumps(trace, indent=2))
        return path


class autotrace:
    """Context manager: records every @_trace.record-decorated call until exit.

    On normal __exit__, saves the trace to disk. On exception exit, discards.

    Usage:
        with autotrace(host="example.com", intent="visit_homepage"):
            new_tab("https://example.com")
            wait_for_load()
        # → ~/.browser-harness/learn/example.com/visit_homepage.json
    """
    def __init__(self, host, intent):
        # P2-2 (Hermes audit): fail fast — don't wait for __enter__ to surface
        # an invalid host/intent.
        _validate_host_intent(host, intent)
        self.host = host
        self.intent = intent
        self._prev = None

    def __enter__(self):
        self._prev = getattr(_state, "current", None)
        _state.current = Recorder(self.host, self.intent)
        return _state.current

    def __exit__(self, exc_type, exc_val, exc_tb):
        rec = _state.current
        _state.current = self._prev
        if exc_type is None and rec is not None:
            try:
                rec.save()
            except Exception as e:
                # Don't break the agent on save failure, but DON'T be silent
                # about it either — disk-full / perm-denied is the kind of
                # thing the agent needs to know about to decide what's next.
                import sys
                print(f"[browser-harness] WARNING: failed to save trace for "
                      f"{self.host}/{self.intent}: {e}", file=sys.stderr)
        return False


def record(fn):
    """Decorator: when an autotrace() recorder is active, append (fn, args, kwargs, elapsed) to it.

    Nested calls (a decorated function calling another decorated function) are
    suppressed — only the OUTER call is recorded. This prevents new_tab→goto_url
    from double-recording, and protects replay from double-executing.

    No overhead when no recorder is active beyond one attribute lookup."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        rec = getattr(_state, "current", None)
        if rec is None:
            return fn(*args, **kwargs)
        depth = getattr(_state, "depth", 0)
        if depth > 0:
            # Inside another recorded call — execute but don't record
            return fn(*args, **kwargs)
        _state.depth = depth + 1
        t0 = time.time()
        try:
            result = fn(*args, **kwargs)
        finally:
            _state.depth = depth
        try: rec.append(fn.__name__, args, kwargs, time.time() - t0)
        except Exception: pass
        return result
    return wrapper


def list_traces(host=None):
    """List available traces. Returns list of {host, intent, success_count, last_used_at, step_count}."""
    base = _learn_dir()
    if not base.exists(): return []
    out = []
    hosts = [host] if host else [p.name for p in base.iterdir() if p.is_dir()]
    for h in hosts:
        d = base / h
        if not d.is_dir(): continue
        for jf in sorted(d.glob("*.json")):
            try:
                t = json.loads(jf.read_text())
                out.append({
                    "host": h,
                    "intent": jf.stem,
                    "success_count": t.get("success_count", 0),
                    "last_used_at": t.get("last_used_at"),
                    "step_count": len(t.get("steps", [])),
                })
            except Exception: continue
    return out


def replay_skill(host, intent, helpers_module=None):
    """Replay the recorded trace for (host, intent). Returns:
      {ok: bool, completed_steps: int, total_steps: int, failure: str|None,
       host, intent, elapsed: float}.
    helpers_module: defaults to importing browser_harness.helpers."""
    _validate_host_intent(host, intent)
    path = _learn_dir() / host / f"{intent}.json"
    if not path.exists():
        return {"ok": False, "completed_steps": 0, "total_steps": 0,
                "failure": "no_trace_for_host_intent", "host": host, "intent": intent, "elapsed": 0.0}
    if helpers_module is None:
        from . import helpers as helpers_module
    try: trace = json.loads(path.read_text())
    except Exception as e:
        return {"ok": False, "completed_steps": 0, "total_steps": 0,
                "failure": f"trace_unreadable: {e}", "host": host, "intent": intent, "elapsed": 0.0}
    steps = trace.get("steps", [])
    completed = 0
    failure = None
    t0 = time.time()
    for step in steps:
        fn_name = step.get("fn")
        fn = getattr(helpers_module, fn_name, None)
        if fn is None:
            failure = f"step {step.get('i')}: unknown function {fn_name!r}"
            break
        try:
            fn(*step.get("args", []), **step.get("kwargs", {}))
            completed += 1
        except Exception as e:
            failure = f"step {step.get('i')} ({fn_name}): {type(e).__name__}: {e}"
            break
    elapsed = round(time.time() - t0, 3)
    if failure is None:
        try:
            trace["last_used_at"] = _now_iso()
            trace["success_count"] = trace.get("success_count", 0) + 1
            path.write_text(json.dumps(trace, indent=2))
            try:
                from . import _codify
                _codify.auto_codify_if_ready(host, intent)
            except Exception:
                pass
        except Exception: pass
    return {"ok": failure is None, "completed_steps": completed, "total_steps": len(steps),
            "failure": failure, "host": host, "intent": intent, "elapsed": elapsed}
