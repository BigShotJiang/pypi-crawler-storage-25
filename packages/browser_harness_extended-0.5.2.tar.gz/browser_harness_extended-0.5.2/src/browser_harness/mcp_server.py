"""MCP server for browser-harness — exposes the CDP harness over JSON-RPC stdio.

Run with:  browser-harness mcp

Add to Claude Code:
    claude mcp add browser-harness -- browser-harness mcp

The Playwright MCP / browser-use approach in one binary, with our DAEMON as the
backbone (so we connect to your REAL Chrome with your REAL logins, not a
sandboxed headless one).
"""
from __future__ import annotations

import json
import logging
import sys
from typing import Any, Callable

# helpers brings _version


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", stream=sys.stderr)
log = logging.getLogger("browser_harness.mcp")


SUPPORTED_PROTOCOL_VERSIONS = ["2025-06-18", "2025-03-26", "2024-11-05"]


TOOLS: dict[str, dict] = {}


def tool(name: str, description: str, schema: dict | None = None):
    def deco(fn: Callable):
        TOOLS[name] = {
            "description": description.strip(),
            "input_schema": schema or {"type": "object", "properties": {}},
            "handler": fn,
        }
        return fn
    return deco


def _ok(data: Any) -> dict:
    return {"ok": True, "result": data}


def _err(msg: str, *, hint: str = "") -> dict:
    out = {"ok": False, "error": msg}
    if hint:
        out["hint"] = hint
    return out


# --- navigation + page state ---


@tool(
    "goto_url",
    "Navigate the active tab to a URL. Waits for load.",
    {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]},
)
def t_goto_url(url: str):
    from . import helpers as H
    H.goto_url(url)
    H.wait_for_load(timeout=20.0)
    return _ok(H.page_info())


@tool(
    "page_info",
    "URL, title, viewport, scroll, and (by default) AX-tree refs — all in one call. "
    "Pass r1/r2/... refs to click_ref / type_in_ref. "
    "Set refs=false to skip the AX snapshot, console=true for recent errors, "
    "screenshot=true to include a screenshot path.",
    {"type": "object", "properties": {
        "refs": {"type": "boolean"},
        "console": {"type": "boolean"},
        "screenshot": {"type": "boolean"},
        "max_nodes": {"type": "integer"},
    }},
)
def t_page_info(refs: bool = True, console: bool = False,
                screenshot: bool = False, max_nodes: int = 200):
    from . import helpers as H
    return _ok(H.page_info(refs=refs, console=console,
                           screenshot=screenshot, max_nodes=max_nodes))


@tool(
    "wait_for_load",
    "Wait until the page reports load complete (or timeout).",
    {"type": "object", "properties": {"timeout": {"type": "number"}}},
)
def t_wait_for_load(timeout: float = 15.0):
    from . import helpers as H
    return _ok({"loaded": H.wait_for_load(timeout=timeout)})


# --- accessibility snapshot — the killer feature ---


@tool(
    "accessibility_snapshot",
    "ONE CDP roundtrip → compact LLM-ready JSON of the page's a11y tree. "
    "Every actionable element gets a stable `ref` (e.g. r42). Pass refs to "
    "click_ref / type_in_ref / read_ref. Far cheaper than screenshot+vision.",
    {"type": "object", "properties": {
        "max_nodes": {"type": "integer"},
        "max_depth": {"type": "integer"},
    }},
)
def t_accessibility_snapshot(max_nodes: int = 800, max_depth: int = 30):
    from .snapshot import accessibility_snapshot
    return _ok(accessibility_snapshot(max_nodes=max_nodes, max_depth=max_depth))


@tool(
    "click_ref",
    "Click the element identified by a ref from accessibility_snapshot.",
    {"type": "object", "properties": {"ref": {"type": "string"}}, "required": ["ref"]},
)
def t_click_ref(ref: str):
    from .snapshot import click_ref
    return _ok(click_ref(ref))


@tool(
    "type_in_ref",
    "Focus an input ref and type text. Set clear_first=true to wipe the field first.",
    {"type": "object", "properties": {
        "ref": {"type": "string"}, "text": {"type": "string"},
        "clear_first": {"type": "boolean"},
    }, "required": ["ref", "text"]},
)
def t_type_in_ref(ref: str, text: str, clear_first: bool = False):
    from .snapshot import type_in_ref
    return _ok(type_in_ref(ref, text, clear_first=clear_first))


@tool(
    "read_ref",
    "Read .value or .innerText of an element by ref.",
    {"type": "object", "properties": {"ref": {"type": "string"}}, "required": ["ref"]},
)
def t_read_ref(ref: str):
    from .snapshot import read_ref
    return _ok(read_ref(ref))


# --- input ---


@tool(
    "click_at_xy",
    "Click at viewport pixel coords.",
    {"type": "object", "properties": {
        "x": {"type": "integer"}, "y": {"type": "integer"},
        "button": {"type": "string"}, "clicks": {"type": "integer"},
    }, "required": ["x", "y"]},
)
def t_click_at_xy(x: int, y: int, button: str = "left", clicks: int = 1):
    from . import helpers as H
    H.click_at_xy(x, y, button=button, clicks=clicks)
    return _ok({"clicked": [x, y]})


@tool(
    "type_text",
    "Type text at the current keyboard focus.",
    {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]},
)
def t_type_text(text: str):
    from . import helpers as H
    H.type_text(text)
    return _ok({"typed": len(text)})


@tool(
    "press_key",
    "Press a single key. modifiers is a CDP modifier bitmask (1=alt, 2=ctrl, 4=meta, 8=shift).",
    {"type": "object", "properties": {
        "key": {"type": "string"}, "modifiers": {"type": "integer"},
    }, "required": ["key"]},
)
def t_press_key(key: str, modifiers: int = 0):
    from . import helpers as H
    H.press_key(key, modifiers=modifiers)
    return _ok({"pressed": key})


@tool(
    "scroll",
    "Scroll at viewport coords. Negative dy = scroll up.",
    {"type": "object", "properties": {
        "x": {"type": "integer"}, "y": {"type": "integer"},
        "dy": {"type": "integer"}, "dx": {"type": "integer"},
    }},
)
def t_scroll(x: int = 400, y: int = 300, dy: int = -300, dx: int = 0):
    from . import helpers as H
    H.scroll(x, y, dy=dy, dx=dx)
    return _ok({"scrolled": [dy, dx]})


# --- tabs ---


@tool("list_tabs", "All open tabs (excluding chrome internals by default).",
      {"type": "object", "properties": {"include_chrome": {"type": "boolean"}}})
def t_list_tabs(include_chrome: bool = False):
    from . import helpers as H
    return _ok(H.list_tabs(include_chrome=include_chrome))


@tool("current_tab", "Active tab info.")
def t_current_tab():
    from . import helpers as H
    return _ok(H.current_tab())


@tool(
    "switch_tab",
    "Activate the tab with the given CDP targetId (the 'targetId' field of "
    "list_tabs / current_tab). Pass the dict from those calls or the bare ID "
    "string. URL/title substring matching is NOT supported here — list_tabs first.",
    {"type": "object", "properties": {"target": {"type": "string"}}, "required": ["target"]},
)
def t_switch_tab(target: str):
    from . import helpers as H
    return _ok({"switched": H.switch_tab(target)})


@tool("new_tab", "Open a new tab. Optional URL.",
      {"type": "object", "properties": {"url": {"type": "string"}}})
def t_new_tab(url: str = "about:blank"):
    from . import helpers as H
    return _ok(H.new_tab(url))


# --- screenshot + JS ---


@tool(
    "screenshot",
    "Capture a screenshot of the active tab.",
    {"type": "object", "properties": {
        "path": {"type": "string"}, "full_page": {"type": "boolean"},
        "max_dim": {"type": "integer"},
    }},
)
def t_screenshot(path: str | None = None, full_page: bool = False, max_dim: int | None = None):
    from . import helpers as H
    p = H.capture_screenshot(path=path, full=full_page, max_dim=max_dim)
    return _ok({"path": p})


@tool(
    "evaluate_js",
    "Run JavaScript in the active tab and return the result.",
    {"type": "object", "properties": {"expression": {"type": "string"}}, "required": ["expression"]},
)
def t_evaluate_js(expression: str):
    from . import helpers as H
    res = H.js(expression)
    return _ok({"result": res})


# --- file ops ---


@tool(
    "upload_file",
    "Set a file input (CSS selector) to a local path.",
    {"type": "object", "properties": {
        "selector": {"type": "string"}, "path": {"type": "string"},
    }, "required": ["selector", "path"]},
)
def t_upload_file(selector: str, path: str):
    from . import helpers as H
    return _ok({"uploaded": H.upload_file(selector, path)})


@tool(
    "http_get",
    "Pure-HTTP fetch — does NOT go through the browser, so it does NOT carry "
    "the user's session cookies. Uses urllib (or fetch-use proxy if "
    "BROWSER_USE_API_KEY is set and BH_LOCAL_ONLY is not). Cross-origin "
    "calls from the page's origin are blocked unless allowlisted in "
    "bh-policy.toml [http_get] allow_cross_origin_to. Returns text body.",
    {"type": "object", "properties": {
        "url": {"type": "string"}, "timeout": {"type": "number"},
    }, "required": ["url"]},
)
def t_http_get(url: str, timeout: float = 20.0):
    from . import helpers as H
    return _ok({"body": H.http_get(url, timeout=timeout)})


# --- network + console (Playwright MCP parity) ---


@tool(
    "network_requests",
    "Recent network activity (last_seconds window). Useful for debugging XHR.",
    {"type": "object", "properties": {
        "last_seconds": {"type": "number"}, "limit": {"type": "integer"},
    }},
)
def t_network_requests(last_seconds: float = 30.0, limit: int = 100):
    from .observation import network_requests
    return _ok({"requests": network_requests(last_seconds=last_seconds, limit=limit)})


@tool(
    "console_logs",
    "Recent console.log / error / warning entries from the page.",
    {"type": "object", "properties": {
        "last_seconds": {"type": "number"}, "limit": {"type": "integer"},
    }},
)
def t_console_logs(last_seconds: float = 30.0, limit: int = 100):
    from .observation import console_logs
    return _ok({"logs": console_logs(last_seconds=last_seconds, limit=limit)})


# --- v0.4: shadow cache + auto-codify + skill registry + multi-browser + egress ---


@tool(
    "replay_skill",
    "Re-run a previously recorded (host,intent) trace deterministically — zero "
    "LLM calls for navigation. Returns {ok, completed_steps, total_steps, "
    "failure, elapsed}. Use list_traces first to see what's been learned.",
    {"type": "object", "properties": {
        "host": {"type": "string"}, "intent": {"type": "string"},
    }, "required": ["host", "intent"]},
)
def t_replay_skill(host: str, intent: str):
    from . import helpers as H
    return _ok(H.replay_skill(host, intent))


@tool(
    "list_traces",
    "Enumerate recorded traces for one host or all hosts. Returns list of "
    "{host, intent, success_count, last_used_at, step_count}.",
    {"type": "object", "properties": {"host": {"type": "string"}}},
)
def t_list_traces(host: str = None):
    from . import helpers as H
    return _ok({"traces": H.list_traces(host=host)})


@tool(
    "list_skills",
    "Enumerate codified skills under agent-workspace/domain-skills/ (both "
    "auto-codified .py and hand-authored .md). Returns list with metadata.",
)
def t_list_skills():
    from . import helpers as H
    return _ok({"skills": H.list_skills()})


@tool(
    "validate_skill",
    "Run pre-publish validation on a skill (frontmatter present, ast.parse, "
    "18-pattern secret scan). Returns {ok, errors, warnings, frontmatter}.",
    {"type": "object", "properties": {
        "host": {"type": "string"}, "intent": {"type": "string"},
    }, "required": ["host", "intent"]},
)
def t_validate_skill(host: str, intent: str):
    from . import helpers as H
    return _ok(H.validate_skill(host, intent))


@tool(
    "publish_skill",
    "Publish a packaged skill to the configured registry (BH_SKILLS_REGISTRY "
    "or [skills] registry in bh-policy.toml). Defaults to dry_run=True. With "
    "dry_run=False, requires gh CLI + push access to the registry repo.",
    {"type": "object", "properties": {
        "host": {"type": "string"}, "intent": {"type": "string"},
        "dry_run": {"type": "boolean"},
    }, "required": ["host", "intent"]},
)
def t_publish_skill(host: str, intent: str, dry_run: bool = True):
    from . import helpers as H
    return _ok(H.publish_skill(host, intent, dry_run=dry_run))


@tool(
    "detect_browsers",
    "Enumerate Chromium variants installed on this machine (Chrome, Brave, "
    "Edge, Arc, Chromium, etc.). Returns {name: {binary, profile, installed}}.",
)
def t_detect_browsers():
    from . import helpers as H
    return _ok({"browsers": H.detect_browsers()})


@tool(
    "launch_browser",
    "Spawn a fresh Chromium-variant instance with --remote-debugging-port. "
    "Returns {pid, port, name, binary, profile_dir, cdp_url, warning?}. Use "
    "fresh_profile=True to avoid the default-profile single-instance lock.",
    {"type": "object", "properties": {
        "name": {"type": "string"},
        "port": {"type": "integer"},
        "headless": {"type": "boolean"},
        "fresh_profile": {"type": "boolean"},
    }, "required": ["name"]},
)
def t_launch_browser(name: str, port: int = None, headless: bool = False,
                     fresh_profile: bool = False):
    from . import helpers as H
    return _ok(H.launch_browser(name, port=port, headless=headless,
                                fresh_profile=fresh_profile))


@tool(
    "is_local_only",
    "Returns whether BH_LOCAL_ONLY=1 (or [network] local_only = true in "
    "bh-policy.toml) is currently in effect — i.e., harness-initiated egress "
    "to non-page hosts is blocked.",
)
def t_is_local_only():
    from . import helpers as H
    return _ok({"local_only": H.is_local_only()})


# --- meta ---


@tool("doctor", "Daemon + browser status. Use first when something fails.")
def t_doctor():
    from .admin import _version
    from . import helpers as H
    info = {"version": _version()}
    try:
        info["page"] = H.page_info()
        info["tabs"] = len(H.list_tabs(include_chrome=False))
        info["healthy"] = True
    except Exception as e:  # noqa: BLE001
        info["healthy"] = False
        info["error"] = str(e)
        info["hint"] = "Run: browser-harness --doctor   (then --setup if disconnected)"
    return _ok(info)


@tool("version", "Server version + tool count.")
def t_version():
    from .admin import _version
    return _ok({"version": _version(), "tool_count": len(TOOLS)})


# --- JSON-RPC dispatcher (same shape as desktop-harness) ---


def _handle_request(req: dict) -> dict | None:
    method = req.get("method") or ""
    rid = req.get("id")
    params = req.get("params") or {}

    if method == "initialize":
        client_v = params.get("protocolVersion", SUPPORTED_PROTOCOL_VERSIONS[0])
        negotiated = client_v if client_v in SUPPORTED_PROTOCOL_VERSIONS else SUPPORTED_PROTOCOL_VERSIONS[0]
        from .admin import _version
        return {"jsonrpc": "2.0", "id": rid,
                "result": {"protocolVersion": negotiated, "capabilities": {"tools": {}},
                           "serverInfo": {"name": "browser-harness", "version": _version()}}}
    if method == "ping":
        return {"jsonrpc": "2.0", "id": rid, "result": {}}
    if method.startswith("notifications/"):
        return None
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": rid,
                "result": {"tools": [
                    {"name": n, "description": t["description"], "inputSchema": t["input_schema"]}
                    for n, t in TOOLS.items()
                ]}}
    if method == "tools/call":
        name = params.get("name")
        args = params.get("arguments") or {}
        spec = TOOLS.get(name)
        if spec is None:
            return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": f"Unknown tool: {name}"}}
        try:
            result = spec["handler"](**args)
        except TypeError as e:
            return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32602, "message": f"Bad arguments for {name}: {e}"}}
        except Exception as e:  # noqa: BLE001
            log.exception("tool %s failed", name)
            return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32000, "message": str(e)}}
        return {"jsonrpc": "2.0", "id": rid,
                "result": {"content": [{"type": "text", "text": json.dumps(result, indent=2, default=str)}]}}
    if rid is None:
        return None
    return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": f"Unknown method: {method}"}}


def main() -> int:
    from .admin import _version, ensure_daemon
    log.info("browser-harness %s MCP server starting (%d tools)", _version(), len(TOOLS))
    try:
        ensure_daemon()
    except Exception as e:  # noqa: BLE001
        log.warning("daemon ensure failed (will retry on first call): %s", e)
    while True:
        try:
            line = sys.stdin.readline()
            if not line:
                log.info("stdin EOF — exiting")
                break
            line = line.strip()
            if not line:
                continue
            try:
                req = json.loads(line)
            except json.JSONDecodeError as e:
                log.warning("bad JSON: %s", e)
                continue
            resp = _handle_request(req)
            if resp is not None:
                sys.stdout.write(json.dumps(resp) + "\n")
                sys.stdout.flush()
        except KeyboardInterrupt:
            break
        except Exception as e:  # noqa: BLE001
            log.exception("server error: %s", e)
    return 0


if __name__ == "__main__":
    sys.exit(main())
