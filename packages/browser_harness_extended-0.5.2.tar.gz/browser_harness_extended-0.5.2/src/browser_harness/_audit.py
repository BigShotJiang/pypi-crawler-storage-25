"""Append-only NDJSON audit log for security-sensitive harness calls.

Best-effort: never raises; failures are silently dropped so auditing can't break
the harness. Path resolves at call time (BH_AUDIT_LOG env override) so tests
and daemons can redirect without re-importing the module."""
import json, os, time
from pathlib import Path


def _log_path():
    """Resolved at call time — supports BH_AUDIT_LOG override + tests that
    monkeypatch HOME without re-importing."""
    env = os.environ.get("BH_AUDIT_LOG")
    if env:
        return Path(env).expanduser()
    return Path.home() / ".browser-harness" / "audit.log"


def audit(event, **fields):
    """Append one NDJSON line to the audit log (default ~/.browser-harness/audit.log)."""
    try:
        path = _log_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        rec = {"ts": time.time(), "event": event, "pid": os.getpid(),
               "bu_name": os.environ.get("BU_NAME", "default"), **fields}
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, default=str) + "\n")
    except Exception:
        pass


# Backwards-compat aliases (some tests / callers reference the constants).
# These resolve at import time to the default path; for path overrides at
# runtime, the function `_log_path()` is the source of truth.
LOG_PATH = _log_path()
LOG_DIR = LOG_PATH.parent
