"""Multi-Chromium browser support.

Today browser-harness defaults to Chrome on port 9222. This module makes it
practical to attach the harness to other Chromium variants (Brave / Edge /
Arc / Chromium / Comet) and to run multiple sessions in parallel without
port conflicts.

The harness's core attach logic lives in daemon.py and is browser-agnostic
already (it just speaks CDP). What was missing — and ships here — is:

  detect_browsers()   discover which Chromium variants are installed
  find_free_port()    pick a remote-debugging port that isn't in use
  launch_browser()    spawn a fresh instance with --remote-debugging-port
                      and a chosen --user-data-dir

Pattern for parallel sessions:
    info = launch_browser("brave", port=9223)
    os.environ["BU_NAME"] = "brave-job-1"
    os.environ["BU_CDP_URL"] = f"http://127.0.0.1:{info['port']}"
    # subsequent `browser-harness -c ...` calls drive that session

Codex's Chrome extension targets real Chrome only; this is the parity wedge."""
import atexit
import os
import platform
import shutil
import signal
import socket
import subprocess
from pathlib import Path

# (canonical_name) → ([binary_paths], [profile_paths]) — first existing wins.
_MACOS_BROWSERS = {
    "chrome": (
        ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"],
        [Path.home() / "Library/Application Support/Google/Chrome"],
    ),
    "brave": (
        ["/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"],
        [Path.home() / "Library/Application Support/BraveSoftware/Brave-Browser"],
    ),
    "edge": (
        ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"],
        [Path.home() / "Library/Application Support/Microsoft Edge"],
    ),
    "arc": (
        ["/Applications/Arc.app/Contents/MacOS/Arc"],
        [Path.home() / "Library/Application Support/Arc/User Data"],
    ),
    "chromium": (
        ["/Applications/Chromium.app/Contents/MacOS/Chromium"],
        [Path.home() / "Library/Application Support/Chromium"],
    ),
    "comet": (
        ["/Applications/Comet.app/Contents/MacOS/Comet"],
        [Path.home() / "Library/Application Support/Comet"],
    ),
    "dia": (
        ["/Applications/Dia.app/Contents/MacOS/Dia"],
        [Path.home() / "Library/Application Support/Dia/User Data"],
    ),
}

_LINUX_BROWSERS = {
    "chrome": (
        ["google-chrome", "google-chrome-stable", "/usr/bin/google-chrome"],
        [Path.home() / ".config/google-chrome"],
    ),
    "brave": (
        ["brave-browser", "/usr/bin/brave-browser"],
        [Path.home() / ".config/BraveSoftware/Brave-Browser"],
    ),
    "edge": (
        ["microsoft-edge", "microsoft-edge-stable"],
        [Path.home() / ".config/microsoft-edge"],
    ),
    "chromium": (
        ["chromium", "chromium-browser"],
        [Path.home() / ".config/chromium"],
    ),
}

_WINDOWS_BROWSERS = {
    "chrome": (
        [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ],
        [Path.home() / "AppData/Local/Google/Chrome/User Data"],
    ),
    "brave": (
        [r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"],
        [Path.home() / "AppData/Local/BraveSoftware/Brave-Browser/User Data"],
    ),
    "edge": (
        [r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"],
        [Path.home() / "AppData/Local/Microsoft/Edge/User Data"],
    ),
}


def _table_for_platform():
    sysname = platform.system()
    if sysname == "Darwin":
        return _MACOS_BROWSERS
    if sysname == "Linux":
        return _LINUX_BROWSERS
    if sysname == "Windows":
        return _WINDOWS_BROWSERS
    return {}


def _resolve_binary(candidates):
    """First candidate that exists as a path OR resolves on PATH wins."""
    for c in candidates:
        if "/" in c or "\\" in c:
            if Path(c).exists():
                return c
        else:
            w = shutil.which(c)
            if w:
                return w
    return None


def detect_browsers():
    """Enumerate Chromium variants on this OS.
    Returns {name: {binary, profile, installed}}."""
    table = _table_for_platform()
    out = {}
    for name, (bins, profiles) in table.items():
        binary = _resolve_binary(bins)
        profile = next((str(p) for p in profiles if p.exists()), None)
        out[name] = {
            "binary": binary,
            "profile": profile,
            "installed": binary is not None,
        }
    return out


# Track tempdirs and pids that this process owns so we can clean them up.
# Long-lived agent processes that spawn many browsers would otherwise leak
# user-data-dirs and orphan Chrome PIDs.
_TEMP_PROFILES = []   # paths to remove on exit
_OWNED_PIDS = []      # pids to terminate on exit


def _cleanup_owned_browsers():
    """atexit hook: best-effort SIGTERM all PIDs we spawned + rm tempdirs."""
    for pid in list(_OWNED_PIDS):
        try: os.kill(pid, signal.SIGTERM)
        except Exception: pass
    for path in list(_TEMP_PROFILES):
        try: shutil.rmtree(path, ignore_errors=True)
        except Exception: pass


atexit.register(_cleanup_owned_browsers)


def kill_browser(pid, *, timeout=2.0, force=False):
    """Terminate a launch_browser-spawned Chromium PID. Returns True if the
    process actually went away within timeout, False otherwise. Idempotent.

    P2-1 (Hermes audit): refuses to kill PIDs this process didn't spawn via
    launch_browser, unless force=True is passed. Prevents accidental SIGTERM
    of unrelated local processes if the caller passes a wrong PID."""
    if pid not in _OWNED_PIDS and not force:
        return False
    import time
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        if pid in _OWNED_PIDS: _OWNED_PIDS.remove(pid)
        return True
    except Exception:
        return False
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            os.kill(pid, 0)  # signal 0 = does it exist?
        except ProcessLookupError:
            if pid in _OWNED_PIDS: _OWNED_PIDS.remove(pid)
            return True
        time.sleep(0.05)
    # Hard kill
    try: os.kill(pid, signal.SIGKILL)
    except Exception: pass
    if pid in _OWNED_PIDS: _OWNED_PIDS.remove(pid)
    return False


def find_free_port(start=9222, end=9322):
    """Pick a TCP port that isn't bound on 127.0.0.1 in [start, end).

    NOTE — race window: this binds + immediately closes the socket, so a
    brief window exists between picking the port and the caller using it.
    For launch_browser the window is closed by `verify_browser_ready()`
    which polls /json/version after spawn and raises if the port turns
    out to be unreachable. Pure callers of find_free_port still face
    the race; for a hard guarantee use `claim_port()` instead which
    holds the binding open via SO_REUSEADDR=0 until released."""
    for port in range(start, end):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"no free port in [{start}, {end})")


def claim_port(start=9222, end=9322):
    """Atomic port claim: returns (port, claim_socket).
    The caller MUST close the claim_socket BEFORE the spawned browser
    binds to it (browser-harness's launch_browser does this internally).
    Closes the TOCTOU race that find_free_port has."""
    for port in range(start, end):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # SO_REUSEADDR off so a parallel claim can't race-win the port
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
            s.bind(("127.0.0.1", port))
            s.listen(1)
            return port, s
        except OSError:
            try: s.close()
            except Exception: pass
            continue
    raise RuntimeError(f"no free port in [{start}, {end})")


def verify_browser_ready(cdp_url, *, timeout=10.0):
    """Poll {cdp_url}/json/version until it responds or timeout. Returns
    {'ready': bool, 'browser': str|None, 'elapsed': float}."""
    import time as _t
    import urllib.request, urllib.error
    deadline = _t.time() + timeout
    while _t.time() < deadline:
        try:
            with urllib.request.urlopen(f"{cdp_url}/json/version", timeout=1) as r:
                import json
                data = json.loads(r.read())
                return {"ready": True, "browser": data.get("Browser"),
                        "elapsed": round(_t.time() - (deadline - timeout), 2)}
        except (urllib.error.URLError, ConnectionError, OSError, ValueError):
            _t.sleep(0.2)
    return {"ready": False, "browser": None, "elapsed": timeout}


def launch_browser(name, *, port=None, profile_dir=None, headless=False,
                   extra_args=None, fresh_profile=False):
    """Launch a fresh Chromium-variant instance with remote debugging on.

    Args:
      name:         one of detect_browsers() keys (chrome|brave|edge|arc|chromium|comet|dia)
      port:         override; defaults to find_free_port()
      profile_dir:  override; defaults to the variant's standard profile path,
                    OR a fresh tempdir when fresh_profile=True
      headless:     pass --headless=new when True
      extra_args:   extra CLI flags to append
      fresh_profile: if True, use a fresh empty user-data-dir under tempfile.gettempdir()

    Returns {pid, port, name, binary, profile_dir, cdp_url, warning?}. Does NOT
    block — caller polls the cdp_url + /json/version to know when the browser
    is ready.

    KNOWN GOTCHA — default profile single-instance lock:
        Chromium variants enforce single-instance per --user-data-dir. If you
        launch_browser without fresh_profile=True AND your existing browser is
        already running against the standard profile, the new process attaches
        to the existing window (delivering the URL there) and exits silently.
        --remote-debugging-port is then NOT bound to the new PID; cdp_url won't
        respond. This function emits warning="default_profile_already_in_use"
        when it detects the standard profile is in use; pass fresh_profile=True
        to avoid the lock entirely (recommended for parallel sessions).
    """
    table = _table_for_platform()
    if name not in table:
        raise ValueError(f"unknown browser {name!r}; valid: {sorted(table.keys())}")
    info = detect_browsers()[name]
    if not info["installed"]:
        raise RuntimeError(
            f"browser {name!r} not installed; tried: {table[name][0]}"
        )
    port = port or find_free_port()
    if fresh_profile:
        import tempfile
        profile = profile_dir or os.path.join(tempfile.gettempdir(), f"bh-{name}-{port}-profile")
        Path(profile).mkdir(parents=True, exist_ok=True)
    else:
        profile = profile_dir or info["profile"]

    cmd = [info["binary"], f"--remote-debugging-port={port}"]
    if profile:
        cmd.append(f"--user-data-dir={profile}")
    if headless:
        cmd.append("--headless=new")
    if extra_args:
        cmd.extend(extra_args)

    # Detect the single-instance lock footgun BEFORE launching: if we're about
    # to use the standard profile path AND another browser is currently running
    # against it, the launch will silently no-op. Best-effort detection.
    warning = None
    if not fresh_profile and profile and profile == info.get("profile"):
        # Check for the SingletonLock file Chromium drops in its profile dir
        for marker in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
            if (Path(profile) / marker).exists():
                warning = "default_profile_already_in_use"
                break

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    # Track PID + tempdir for atexit cleanup so this process doesn't leak
    # browser instances or 50-500MB user-data-dirs on disk.
    _OWNED_PIDS.append(proc.pid)
    if fresh_profile and not profile_dir:
        _TEMP_PROFILES.append(profile)
    result = {
        "pid": proc.pid,
        "port": port,
        "name": name,
        "binary": info["binary"],
        "profile_dir": profile or "(none)",
        "cdp_url": f"http://127.0.0.1:{port}",
    }
    if warning:
        result["warning"] = warning
    return result
