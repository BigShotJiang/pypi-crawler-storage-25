"""Databricks filesystem package — :class:`Path` subclasses for
``/dbfs``, ``/Volumes``, and ``/Workspace``.

Importing this package wires every concrete subclass into the
:class:`yggdrasil.io.holder.Holder` scheme registry so
``Holder(url="dbfs://...")`` / ``volumes://...`` / ``workspace://...``
all dispatch to the right Path class.
"""

from __future__ import annotations

from .dbfs_path import DBFSPath
from .path import DatabricksPath
from .volume_path import VolumePath
from .workspace_path import WorkspacePath


__all__ = [
    "DatabricksPath",
    "DBFSPath",
    "VolumePath",
    "WorkspacePath",
]
