from fasr_lid_firered.models.lid import FireRedForLID

__all__ = [
    "FireRedForLID",
]
