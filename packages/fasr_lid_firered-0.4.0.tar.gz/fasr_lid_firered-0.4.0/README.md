# fasr-lid-firered

基于 FireRedLID 的语种识别模型插件，为 fasr 提供音频语种自动识别能力。

## 安装

```bash
pip install fasr-lid-firered
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `firered` | `FireRedForLID` | `xukaituo/FireRedLID` | 语种识别，返回语言标识（如 `"zh"`、`"en"`） |

模型权重默认从 ModelScope 自动下载。

## 使用方式

### 单独使用模型

```python
from fasr.config import registry
from fasr.data import Waveform

model = registry.lid_models.get("firered")()
model.from_checkpoint(use_gpu=True, use_half=True)

waveform = Waveform.from_file("example.wav")
lang = model.identify(waveform)
print(lang)  # e.g. "zh"
```

## `from_checkpoint` 参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint_dir` | `str \| Path \| None` | `None`（自动下载） | 模型权重目录 |
| `use_gpu` | `bool` | `True` | 是否使用 GPU 推理 |
| `use_half` | `bool` | `True` | 是否使用 FP16 推理加速 |

## 依赖

- `fasr`
- `torch >= 2.0.0`
- `kaldiio >= 2.18.0`、`kaldi-native-fbank >= 1.19.0`
- Python 3.10–3.12
