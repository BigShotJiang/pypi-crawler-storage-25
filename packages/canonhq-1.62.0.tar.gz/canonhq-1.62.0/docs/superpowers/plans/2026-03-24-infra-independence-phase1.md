# Infrastructure Independence — Phase 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Stand up Canon's own Terraform project, DOKS cluster, and container registry so Canon can be deployed independently of gv-infra.

**Architecture:** Create an `infra/` directory with modular Terraform configuration using DigitalOcean Spaces as the state backend. A flat root configuration calls into focused modules for DOKS and DOCR. CI workflows run `terraform plan` on PRs and `terraform apply` on merge to main, matching the proven pattern from gv-infra.

**Tech Stack:** Terraform >= 1.0, DigitalOcean provider (~> 2.0), time provider (~> 0.12). Additional providers (AWS, Google, Auth0, Stripe, PostHog, Helm, Kubernetes, kubectl) added in later phases when their modules are introduced.

**Spec:** `docs/specs/infrastructure-independence.md` — Sections 1, 2, 3

**Scope boundary:** This plan covers Sections 1-3 only (Terraform Foundation, DOKS Cluster, Container Registry). DNS, bootstrap services, Auth0, GCP, Stripe, PostHog, CI/CD updates, and migration are covered in subsequent phase plans.

---

## File Structure

```
infra/
  main.tf              # Backend config, provider blocks, module calls
  variables.tf         # All input variables (DO creds, cluster config, registry config)
  outputs.tf           # Cluster endpoint, kubeconfig, registry URL
  terraform.tfvars     # Non-secret production values (committed)
  staging.tfvars       # Non-secret staging values (smaller nodes, committed)
  versions.tf          # Terraform + provider version constraints
  modules/
    doks/
      main.tf          # DOKS cluster + node pool + DOCR integration
      variables.tf     # Cluster name, region, node size, node count, registry integration
      outputs.tf       # Cluster endpoint, kubeconfig, CA cert, token, cluster ID
    docr/
      main.tf          # Container registry
      variables.tf     # Registry name, subscription tier
      outputs.tf       # Registry endpoint, registry name
  README.md            # How to init, plan, apply (required by AC)

.github/workflows/
  infra-plan.yml       # terraform plan on PRs touching infra/
  infra-apply.yml      # terraform apply on merge to main (with environment approval gate)
```

**Design decisions:**
- Provider declarations live in root `main.tf` (not modules) — modules receive provider config implicitly. This matches the gv-infra pattern.
- `versions.tf` is separated from `main.tf` for readability — common Terraform convention.
- Modules are minimal (DOKS, DOCR) — no over-abstraction. Later phases add modules for dns, bootstrap, auth0, gcp, stripe, posthog.
- `terraform.tfvars` contains only non-secret values. Secrets come from `TF_VAR_*` environment variables set by GitHub Actions secrets (fetched from Doppler in CI, or set locally from Doppler CLI).
- State bucket is `canon-terraform-state` (not `gv-terraform-state`) — Canon's own bucket.

---

## Task 1: Terraform version constraints

**Files:**
- Create: `infra/versions.tf`

- [ ] **Step 1: Create versions.tf with Phase 1 providers**

Only declare providers actually used in Phase 1. Additional providers (aws, google, auth0, stripe, posthog, kubernetes, helm, kubectl) will be added in later phases when their modules are introduced — this avoids needing placeholder secrets in CI.

```hcl
# infra/versions.tf
#
# Provider version constraints. Only declare providers with active
# resources — add new providers as their modules are introduced.

terraform {
  required_version = ">= 1.0"

  required_providers {
    digitalocean = {
      source  = "digitalocean/digitalocean"
      version = "~> 2.0"
    }
    time = {
      source  = "hashicorp/time"
      version = "~> 0.12"
    }
  }
}
```

- [ ] **Step 2: Commit**

```bash
git add infra/versions.tf
git commit -m "infra: add Terraform version constraints for all providers"
```

---

## Task 2: Backend, providers, and root configuration

**Files:**
- Create: `infra/main.tf`
- Create: `infra/variables.tf`
- Create: `infra/terraform.tfvars`

- [ ] **Step 1: Create variables.tf with Phase 1 input variables**

Only declare variables for Phase 1 resources. Additional provider variables (AWS, Auth0, GCP, Stripe, PostHog) will be added in later phases alongside their modules.

```hcl
# infra/variables.tf
#
# Input variables for Phase 1: DO account, DOKS cluster, DOCR registry.
# Additional variables added in later phases with their modules.

# ─── DigitalOcean ──────────────────────────────────────────────────────
variable "do_token" {
  description = "DigitalOcean personal access token"
  type        = string
  sensitive   = true
}

# ─── DOKS Cluster ──────────────────────────────────────────────────────
variable "cluster_name" {
  description = "Name of the DOKS cluster"
  type        = string
  default     = "canon"
}

variable "cluster_region" {
  description = "DigitalOcean region for the cluster"
  type        = string
  default     = "nyc1"
}

variable "node_size" {
  description = "Droplet size for cluster nodes"
  type        = string
  default     = "s-2vcpu-4gb"
}

variable "node_count" {
  description = "Number of nodes in the default pool"
  type        = number
  default     = 2
}

# ─── Container Registry ───────────────────────────────────────────────
variable "registry_name" {
  description = "Name of the DOCR registry"
  type        = string
  default     = "canon"
}

variable "registry_subscription_tier" {
  description = "DOCR subscription tier (starter, basic, professional)"
  type        = string
  default     = "basic"
}
```

- [ ] **Step 2: Create main.tf with backend, providers, and module calls**

```hcl
# infra/main.tf
#
# Canon infrastructure — root configuration.
# State stored in DigitalOcean Spaces (S3-compatible).

terraform {
  backend "s3" {
    endpoints                   = { s3 = "https://nyc3.digitaloceanspaces.com" }
    bucket                      = "canon-terraform-state"
    key                         = "production/terraform.tfstate"
    region                      = "us-east-1" # required but ignored by DO Spaces
    skip_credentials_validation = true
    skip_metadata_api_check     = true
    skip_requesting_account_id  = true
    skip_s3_checksum            = true
  }
}

# ─── Providers ─────────────────────────────────────────────────────────
# Add new providers as their modules are introduced in later phases.

provider "digitalocean" {
  token = var.do_token
}

# ─── Modules ──────────────────────────────────────────────────────────

module "docr" {
  source = "./modules/docr"

  registry_name     = var.registry_name
  subscription_tier = var.registry_subscription_tier
}

module "doks" {
  source = "./modules/doks"

  cluster_name         = var.cluster_name
  region               = var.cluster_region
  node_size            = var.node_size
  node_count           = var.node_count
  registry_integration = true

  depends_on = [module.docr]
}
```

Note: `module.docr` is declared before `module.doks` and the DOKS module has an explicit `depends_on` to ensure the registry exists before the cluster tries to integrate with it. The `registry_integration = true` flag on the DOKS cluster tells DigitalOcean to create K8s pull secrets for the account's DOCR registry automatically.

- [ ] **Step 3: Create terraform.tfvars with non-secret production values**

```hcl
# infra/terraform.tfvars
#
# Production values — committed to repo.
# Secrets are injected via TF_VAR_* environment variables
# (from Doppler locally, from GitHub Secrets in CI).

cluster_name   = "canon"
cluster_region = "nyc1"
node_size      = "s-2vcpu-4gb"
node_count     = 2

registry_name              = "canon"
registry_subscription_tier = "basic"
```

- [ ] **Step 4: Create staging.tfvars with smaller staging values**

```hcl
# infra/staging.tfvars
#
# Staging environment overrides. Use with:
#   terraform plan -var-file=staging.tfvars

cluster_name = "canon-staging"
node_size    = "s-1vcpu-2gb"
node_count   = 1
```

- [ ] **Step 5: Commit**

```bash
git add infra/main.tf infra/variables.tf infra/terraform.tfvars infra/staging.tfvars
git commit -m "infra: add root configuration with backend, providers, and variables"
```

---

## Task 3: DOKS cluster module

**Files:**
- Create: `infra/modules/doks/main.tf`
- Create: `infra/modules/doks/variables.tf`
- Create: `infra/modules/doks/outputs.tf`

- [ ] **Step 1: Create the DOKS module variables**

```hcl
# infra/modules/doks/variables.tf

variable "cluster_name" {
  description = "Name of the DOKS cluster"
  type        = string
}

variable "region" {
  description = "DigitalOcean region"
  type        = string
}

variable "node_size" {
  description = "Droplet size for cluster nodes"
  type        = string
}

variable "node_count" {
  description = "Number of nodes in the default pool"
  type        = number
}

variable "registry_integration" {
  description = "Enable DOCR registry integration (creates K8s pull secrets automatically)"
  type        = bool
  default     = false
}
```

- [ ] **Step 2: Create the DOKS module main.tf**

Mirrors the pattern from `gv-infra/core/doks.tf` but with Canon-specific naming and tags.

```hcl
# infra/modules/doks/main.tf

data "digitalocean_kubernetes_versions" "current" {
  version_prefix = "1."
}

resource "digitalocean_kubernetes_cluster" "this" {
  name    = var.cluster_name
  region  = var.region
  version = data.digitalocean_kubernetes_versions.current.latest_version

  node_pool {
    name       = "default"
    size       = var.node_size
    node_count = var.node_count
    auto_scale = false

    tags = ["project:canon"]
  }

  auto_upgrade         = true
  surge_upgrade        = true
  registry_integration = var.registry_integration

  tags = ["project:canon"]
}

# DOKS API endpoint isn't immediately stable after cluster creation.
# Wait before deploying Helm releases to avoid EOF errors.
resource "time_sleep" "wait_for_cluster" {
  depends_on      = [digitalocean_kubernetes_cluster.this]
  create_duration = "60s"
}
```

- [ ] **Step 3: Create the DOKS module outputs**

```hcl
# infra/modules/doks/outputs.tf

output "cluster_id" {
  description = "DOKS cluster ID (used by DOCR integration)"
  value       = digitalocean_kubernetes_cluster.this.id
}

output "cluster_endpoint" {
  description = "DOKS cluster API endpoint"
  value       = digitalocean_kubernetes_cluster.this.endpoint
}

output "cluster_token" {
  description = "Auth token for the DOKS cluster"
  value       = digitalocean_kubernetes_cluster.this.kube_config[0].token
  sensitive   = true
}

output "cluster_ca_certificate" {
  description = "Base64-decoded CA certificate for the DOKS cluster"
  value       = base64decode(digitalocean_kubernetes_cluster.this.kube_config[0].cluster_ca_certificate)
  sensitive   = true
}

output "cluster_name" {
  description = "Name of the DOKS cluster (for doctl kubeconfig save)"
  value       = digitalocean_kubernetes_cluster.this.name
}

output "cluster_ready" {
  description = "Signals that the cluster API is stable (depends on time_sleep)"
  value       = time_sleep.wait_for_cluster.id
}
```

- [ ] **Step 4: Commit**

```bash
git add infra/modules/doks/
git commit -m "infra: add DOKS cluster module"
```

---

## Task 4: Container registry module

**Files:**
- Create: `infra/modules/docr/main.tf`
- Create: `infra/modules/docr/variables.tf`
- Create: `infra/modules/docr/outputs.tf`

- [ ] **Step 1: Create the DOCR module variables**

```hcl
# infra/modules/docr/variables.tf

variable "registry_name" {
  description = "Name of the DOCR registry"
  type        = string
}

variable "subscription_tier" {
  description = "DOCR subscription tier (starter, basic, professional)"
  type        = string
}
```

- [ ] **Step 2: Create the DOCR module main.tf**

The registry itself is simple — pull access is handled by `registry_integration = true` on the DOKS cluster (Task 3), which tells DigitalOcean to create K8s pull secrets automatically. The existing deploy.yml also creates pull secrets via `doctl registry kubernetes-manifest` as a belt-and-suspenders measure.

```hcl
# infra/modules/docr/main.tf

resource "digitalocean_container_registry" "this" {
  name                   = var.registry_name
  subscription_tier_slug = var.subscription_tier
  region                 = "nyc3"
}
```

- [ ] **Step 3: Create the DOCR module outputs**

```hcl
# infra/modules/docr/outputs.tf

output "registry_endpoint" {
  description = "Full registry endpoint (e.g. registry.digitalocean.com/canon)"
  value       = digitalocean_container_registry.this.endpoint
}

output "registry_name" {
  description = "Registry name (for doctl registry login)"
  value       = digitalocean_container_registry.this.name
}

output "registry_server_url" {
  description = "Registry server URL (for K8s imagePullSecrets)"
  value       = digitalocean_container_registry.this.server_url
}
```

- [ ] **Step 4: Commit**

```bash
git add infra/modules/docr/
git commit -m "infra: add container registry module"
```

---

## Task 5: Root outputs

**Files:**
- Create: `infra/outputs.tf`

- [ ] **Step 1: Create root outputs.tf**

Aggregates module outputs for CI/CD consumption and Doppler storage.

```hcl
# infra/outputs.tf
#
# Root outputs — reference these in CI/CD workflows and store
# relevant values in Doppler after terraform apply.

# ─── DOKS ──────────────────────────────────────────────────────────────

output "doks_cluster_name" {
  description = "DOKS cluster name (set as DOKS_CLUSTER_NAME in Doppler)"
  value       = module.doks.cluster_name
}

output "doks_cluster_endpoint" {
  description = "DOKS cluster API endpoint"
  value       = module.doks.cluster_endpoint
}

# ─── DOCR ──────────────────────────────────────────────────────────────

output "docr_registry_name" {
  description = "DOCR registry name (set as DOCR_REGISTRY_NAME in Doppler)"
  value       = module.docr.registry_name
}

output "docr_registry_endpoint" {
  description = "DOCR registry endpoint (e.g. registry.digitalocean.com/canon)"
  value       = module.docr.registry_endpoint
}
```

- [ ] **Step 2: Commit**

```bash
git add infra/outputs.tf
git commit -m "infra: add root outputs for DOKS and DOCR"
```

---

## Task 6: README documentation

**Files:**
- Create: `infra/README.md`

- [ ] **Step 1: Create infra/README.md**

```markdown
# Canon Infrastructure

Terraform configuration for Canon's dedicated infrastructure on DigitalOcean.

## Prerequisites

- [Terraform](https://developer.hashicorp.com/terraform/downloads) >= 1.0
- [Doppler CLI](https://docs.doppler.com/docs/install-cli) (for local secret injection)
- DigitalOcean account with API token
- Access to the `canon-terraform-state` Spaces bucket

## Quick Start

```bash
# Inject secrets from Doppler and initialize
cd infra/
doppler run -- terraform init \
  -backend-config="access_key=$DO_SPACES_ACCESS_KEY" \
  -backend-config="secret_key=$DO_SPACES_SECRET_KEY"

# Preview changes
doppler run -- terraform plan

# Apply changes (requires approval for production)
doppler run -- terraform apply
```

## State Backend

State is stored in DigitalOcean Spaces (S3-compatible):
- **Bucket:** `canon-terraform-state`
- **Key:** `production/terraform.tfstate`
- **Region:** nyc3

## Secrets

All sensitive values are injected via `TF_VAR_*` environment variables:

| Variable | Source | Description |
|---|---|---|
| `TF_VAR_do_token` | Doppler `DIGITALOCEAN_ACCESS_TOKEN` | DigitalOcean API token |
| `TF_VAR_do_spaces_access_key` | Doppler `DO_SPACES_ACCESS_KEY` | Spaces access key |
| `TF_VAR_do_spaces_secret_key` | Doppler `DO_SPACES_SECRET_KEY` | Spaces secret key |

## CI/CD

- **PRs touching `infra/`:** Runs `terraform plan` and posts output as a PR comment
- **Merge to main:** Runs `terraform apply` with GitHub environment approval gate

## Module Structure

| Module | Description |
|---|---|
| `modules/doks/` | DigitalOcean Kubernetes cluster |
| `modules/docr/` | DigitalOcean Container Registry |

Future modules: `dns/`, `bootstrap/`, `auth0/`, `gcp/`, `stripe/`, `posthog/`
```

- [ ] **Step 2: Commit**

```bash
git add infra/README.md
git commit -m "infra: add README with setup and usage documentation"
```

---

## Task 7: CI workflow — terraform plan on PRs

**Files:**
- Create: `.github/workflows/infra-plan.yml`

- [ ] **Step 1: Create the plan workflow**

Adapted from gv-infra's `experiment-plan.yml` but simplified — Canon has a single `infra/` directory, no matrix detection needed.

```yaml
# .github/workflows/infra-plan.yml
name: Infrastructure — Terraform Plan

on:
  pull_request:
    paths: ['infra/**']

permissions:
  contents: read
  pull-requests: write

jobs:
  plan:
    name: Terraform Plan
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: infra
    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3

      - name: Terraform Init
        run: |
          terraform init \
            -backend-config="access_key=${{ secrets.DO_SPACES_ACCESS_KEY }}" \
            -backend-config="secret_key=${{ secrets.DO_SPACES_SECRET_KEY }}"

      - name: Terraform Validate
        run: terraform validate

      - name: Terraform Plan
        id: plan
        run: terraform plan -no-color -out=tfplan 2>&1 | tee plan.txt
        env:
          TF_VAR_do_token: ${{ secrets.DIGITALOCEAN_ACCESS_TOKEN }}

      - name: Post Plan to PR
        uses: actions/github-script@v7
        if: always()
        with:
          script: |
            const fs = require('fs');
            let plan = '';
            try {
              plan = fs.readFileSync('infra/plan.txt', 'utf8');
            } catch {
              plan = 'Plan output not available (step may have failed).';
            }
            const truncated = plan.length > 60000
              ? plan.substring(0, 60000) + '\n\n... (truncated)'
              : plan;

            const marker = '<!-- terraform-plan-infra -->';
            const body = [
              marker,
              '### Terraform Plan — infra',
              '',
              '<details>',
              '<summary>Show Plan Output</summary>',
              '',
              '```',
              truncated,
              '```',
              '',
              '</details>',
              '',
              `*Triggered by commit ${context.sha.substring(0, 8)}*`,
            ].join('\n');

            const { data: comments } = await github.rest.issues.listComments({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: context.issue.number,
            });
            const existing = comments.find(c => c.body.includes(marker));

            if (existing) {
              await github.rest.issues.updateComment({
                owner: context.repo.owner,
                repo: context.repo.repo,
                comment_id: existing.id,
                body,
              });
            } else {
              await github.rest.issues.createComment({
                owner: context.repo.owner,
                repo: context.repo.repo,
                issue_number: context.issue.number,
                body,
              });
            }
```

- [ ] **Step 2: Commit**

```bash
git add .github/workflows/infra-plan.yml
git commit -m "ci: add terraform plan workflow for infra/ PRs"
```

---

## Task 8: CI workflow — terraform apply on merge

**Files:**
- Create: `.github/workflows/infra-apply.yml`

- [ ] **Step 1: Create the apply workflow**

Runs on merge to main with a GitHub environment approval gate (`production` environment).

```yaml
# .github/workflows/infra-apply.yml
name: Infrastructure — Terraform Apply

on:
  push:
    branches: [main]
    paths: ['infra/**']

permissions:
  contents: read

jobs:
  apply:
    name: Terraform Apply
    runs-on: ubuntu-latest
    environment: production
    defaults:
      run:
        working-directory: infra
    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_wrapper: false

      - name: Terraform Init
        run: |
          terraform init \
            -backend-config="access_key=${{ secrets.DO_SPACES_ACCESS_KEY }}" \
            -backend-config="secret_key=${{ secrets.DO_SPACES_SECRET_KEY }}"

      - name: Check state
        run: |
          COUNT=$(terraform state list 2>/dev/null | wc -l || echo 0)
          if [ "$COUNT" -eq 0 ]; then
            echo "::warning::State is empty — this will be a first-time apply."
          else
            echo "State has $COUNT resources."
          fi

      - name: Terraform Apply
        run: terraform apply -auto-approve
        env:
          TF_VAR_do_token: ${{ secrets.DIGITALOCEAN_ACCESS_TOKEN }}
```

- [ ] **Step 2: Commit**

```bash
git add .github/workflows/infra-apply.yml
git commit -m "ci: add terraform apply workflow with production approval gate"
```

---

## Task 9: Terraform validate smoke test

**Files:**
- Modify: `.github/workflows/ci.yml` (add a `terraform-validate` job)

Since we can't run `terraform plan` without credentials in the basic CI, we add `terraform validate` as a syntax/config check.

- [ ] **Step 1: Add terraform-validate job to ci.yml**

Add this job after the existing `helm-lint` job:

```yaml
  terraform-validate:
    runs-on: ubuntu-latest
    permissions:
      contents: read
    defaults:
      run:
        working-directory: infra
    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3

      - name: Terraform Init (no backend)
        run: terraform init -backend=false

      - name: Terraform Validate
        run: terraform validate
```

- [ ] **Step 2: Commit**

```bash
git add .github/workflows/ci.yml
git commit -m "ci: add terraform validate job to CI pipeline"
```

---

## Task 10: Local validation

- [ ] **Step 1: Run terraform init -backend=false to validate configuration**

```bash
cd infra && terraform init -backend=false
```

Expected: successful initialization, all providers downloaded.

- [ ] **Step 2: Run terraform validate**

```bash
terraform validate
```

Expected: `Success! The configuration is valid.`

- [ ] **Step 3: Run terraform fmt -check**

```bash
terraform fmt -check -recursive
```

Expected: no formatting issues (exit 0).

---

## Post-Apply Checklist (Manual — After First Deploy)

These steps require actual infrastructure access and can't be automated in the plan:

1. **Create the DO Spaces bucket** `canon-terraform-state` in nyc3 region
2. **Add GitHub Secrets** to the canon-private repo:
   - `DIGITALOCEAN_ACCESS_TOKEN` — DO API token for Canon's account
   - `DO_SPACES_ACCESS_KEY` / `DO_SPACES_SECRET_KEY` — for state backend
3. **First `terraform apply`** — provisions DOCR registry + DOKS cluster
4. **Update Doppler** with new values:
   - `DOKS_CLUSTER_NAME` = output `doks_cluster_name`
   - `DOCR_REGISTRY_NAME` = output `docr_registry_name`
5. **Verify cluster** — `doctl kubernetes cluster kubeconfig save canon && kubectl get nodes`
6. **Verify registry** — `doctl registry login && docker push registry.digitalocean.com/canon/test:latest`

---

## Spec AC Coverage

| AC | Task |
|---|---|
| `infra/` directory with Terraform modules for each concern | Tasks 1-5 |
| Terraform state stored in DigitalOcean Spaces | Task 2 (backend block) |
| `infra/README.md` documenting how to init, plan, apply | Task 6 |
| CI workflow for `terraform plan` on PRs touching `infra/` | Task 7 |
| CI workflow for `terraform apply` on merge to main (with approval gate) | Task 8 |
| Provider versions pinned | Task 1 |
| Variables file with environment-specific tfvars (production, staging) | Task 2 (terraform.tfvars + staging.tfvars) |
| Terraform module for DOKS cluster | Task 3 |
| Node pool sized appropriately (2-3 nodes, s-2vcpu-4gb) | Task 3 |
| Auto-upgrade enabled for minor K8s versions | Task 3 |
| Cluster tagged for cost tracking (`project:canon`) | Task 3 |
| kubeconfig output available for CI/CD workflows | Task 3 + 5 |
| Doppler updated with new `DOKS_CLUSTER_NAME` | Post-apply checklist |
| Terraform resource for DOCR registry | Task 4 |
| Registry credentials available to the DOKS cluster | Task 3 (registry_integration on DOKS cluster) |
| CI/CD workflows updated to push to new registry | Phase 2 (Section 8) |
| Doppler updated with new `DOCR_REGISTRY_NAME` | Post-apply checklist |
| Old images in `gv-shared` registry cleaned up | Phase 4 (Section 9) |
| `values-production.yaml` updated with new registry path | Phase 2 (Section 8) |
