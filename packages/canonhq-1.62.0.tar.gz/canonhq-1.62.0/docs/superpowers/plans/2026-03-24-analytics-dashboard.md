# Analytics Dashboard Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement a PostHog-powered analytics dashboard showing health scores, momentum, freshness, and time-to-ship metrics for Canon organizations.

**Architecture:** Four layers built bottom-up: (1) new PostHog events emitted from existing sync/push/PR handlers, (2) health score computation module querying PostHog via HogQL, (3) FastAPI analytics endpoints with TTL caching, (4) Vue 3 dashboard with Chart.js visualizations. Each layer is independently testable.

**Tech Stack:** Python/FastAPI, httpx (PostHog Query API), PostHog HogQL, Vue 3 Composition API, Chart.js/vue-chartjs, @tanstack/vue-query

**Spec:** `docs/specs/analytics-dashboard.md` (sections 2–5, 61 acceptance criteria)

---

## File Structure

### New files (backend)
- `src/canon/analytics_query.py` — PostHog HogQL query client (read-only)
- `src/canon/health_score.py` — Health score algorithm (momentum, freshness, time-to-ship pillars)
- `src/canon/web/analytics_routes.py` — Analytics API endpoints
- `tests/test_analytics_query.py` — PostHogQueryClient tests
- `tests/test_health_score.py` — Health score algorithm tests
- `tests/test_web/test_analytics_routes.py` — Analytics API endpoint tests

### New files (frontend)
- `frontend/src/api/analytics.ts` — Analytics API client functions
- `frontend/src/views/AnalyticsView.vue` — Main analytics view
- `frontend/src/components/analytics/HealthScoreHero.vue` — Score display + sparkline
- `frontend/src/components/analytics/PillarCard.vue` — Individual pillar card
- `frontend/src/components/analytics/PillarRow.vue` — Three-pillar layout
- `frontend/src/components/analytics/AnalyticsFilterBar.vue` — Team + time range filter
- `frontend/src/components/analytics/MomentumChart.vue` — Stacked area chart
- `frontend/src/components/analytics/FreshnessChart.vue` — Horizontal bar chart
- `frontend/src/components/analytics/CycleTimeChart.vue` — Waterfall chart
- `frontend/src/components/analytics/FeatureUsageBar.vue` — Feature adoption bars

### Modified files
- `src/canon/settings.py` — Add `posthog_personal_api_key`, `posthog_project_id`
- `src/canon/sync/engine.py` — Emit ticket lifecycle events (including `ticket_routing_matched`)
- `src/canon/github/handlers/on_push.py` — Emit spec lifecycle + config events (including `spec_status_changed`)
- `src/canon/github/handlers/on_pull_request.py` — Emit `ac_realized` events
- `src/canon/mcp/server.py` — Add `groups` to ~11 `mcp_tool_called` calls
- `src/canon/webhooks/router.py` — Add `groups` to `webhook_ticket_sync` call
- `src/canon/agent/client.py` — Add `groups` to `agent_call_completed` calls
- `src/canon/cron/stale_check.py` — Emit `stale_spec_detected` event
- `src/canon/cron/weekly_digest.py` — Emit `weekly_digest_sent` event
- `src/canon/alerts/slack.py` — Emit `sre_alert_fired` event
- `src/canon/web/routes.py` — Import and mount analytics router
- `src/canon/main.py` — Include analytics router
- `frontend/src/router/index.ts` — Add `/app/:org/analytics` route
- `frontend/src/components/layout/AppNav.vue` — Add "Analytics" nav link
- `frontend/src/api/types.ts` — Add analytics response types

---

### Task 1: PostHog Query Client + Settings

**Files:**
- Modify: `src/canon/settings.py:131-136`
- Create: `src/canon/analytics_query.py`
- Create: `tests/test_analytics_query.py`

- [ ] **Step 1: Add new settings**

In `src/canon/settings.py`, after line 136 (`posthog_logs_min_level`), add:

```python
# PostHog Query API (read access for analytics dashboard)
posthog_personal_api_key: str = ""
posthog_project_id: str = ""
```

- [ ] **Step 2: Write failing tests for PostHogQueryClient**

Create `tests/test_analytics_query.py`:

```python
"""Tests for PostHog HogQL query client."""

from __future__ import annotations

import httpx
import pytest

from canon.analytics_query import PostHogQueryClient


@pytest.fixture
def client():
    return PostHogQueryClient(
        api_key="phx_test_key",
        project_id="12345",
        host="https://us.i.posthog.com",
    )


class TestPostHogQueryClient:
    def test_init(self, client: PostHogQueryClient):
        assert client._api_key == "phx_test_key"
        assert client._project_id == "12345"
        assert client._host == "https://us.i.posthog.com"

    @pytest.mark.asyncio
    async def test_query_success(self, client: PostHogQueryClient, httpx_mock):
        """Successful HogQL query returns results."""
        httpx_mock.add_response(
            url="https://us.i.posthog.com/api/projects/12345/query/",
            json={
                "results": [["2026-03-01", 42], ["2026-03-02", 55]],
                "columns": ["date", "count"],
            },
        )
        rows = await client.query("SELECT date, count(*) FROM events GROUP BY date")
        assert len(rows) == 2
        assert rows[0] == {"date": "2026-03-01", "count": 42}

    @pytest.mark.asyncio
    async def test_query_timeout_returns_empty(self, client: PostHogQueryClient, httpx_mock):
        """Timeout returns empty list (graceful degradation)."""
        httpx_mock.add_exception(httpx.ReadTimeout("timed out"))
        rows = await client.query("SELECT 1")
        assert rows == []

    @pytest.mark.asyncio
    async def test_query_error_returns_empty(self, client: PostHogQueryClient, httpx_mock):
        """HTTP error returns empty list."""
        httpx_mock.add_response(status_code=500, json={"error": "internal"})
        rows = await client.query("SELECT 1")
        assert rows == []

    @pytest.mark.asyncio
    async def test_not_configured(self):
        """Client with empty key returns empty results."""
        client = PostHogQueryClient(api_key="", project_id="", host="")
        rows = await client.query("SELECT 1")
        assert rows == []
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/test_analytics_query.py -v`
Expected: ImportError (module doesn't exist yet)

- [ ] **Step 4: Implement PostHogQueryClient**

Create `src/canon/analytics_query.py`:

```python
"""Read-only PostHog query client using HogQL."""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_QUERY_TIMEOUT = 10.0  # seconds
_MAX_ROWS = 10_000


class PostHogQueryClient:
    """Query PostHog via HogQL API for analytics reads."""

    def __init__(self, api_key: str, project_id: str, host: str) -> None:
        self._api_key = api_key
        self._project_id = project_id
        self._host = host.rstrip("/")

    @property
    def configured(self) -> bool:
        return bool(self._api_key and self._project_id and self._host)

    async def query(self, hogql: str) -> list[dict[str, Any]]:
        """Execute a HogQL query and return rows as dicts.

        Returns an empty list on timeout, HTTP error, or misconfiguration.
        Never raises — analytics reads must not break the application.
        """
        if not self.configured:
            return []

        url = f"{self._host}/api/projects/{self._project_id}/query/"
        headers = {"Authorization": f"Bearer {self._api_key}"}
        payload = {
            "query": {"kind": "HogQLQuery", "query": hogql},
            "limit": _MAX_ROWS,
        }

        try:
            async with httpx.AsyncClient(timeout=_QUERY_TIMEOUT) as http:
                resp = await http.post(url, json=payload, headers=headers)
                resp.raise_for_status()
                data = resp.json()
        except Exception:
            logger.debug("PostHog query failed", exc_info=True)
            return []

        columns = data.get("columns", [])
        results = data.get("results", [])
        return [dict(zip(columns, row)) for row in results]
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/test_analytics_query.py -v`
Expected: All PASS

- [ ] **Step 6: Commit**

```bash
git add src/canon/settings.py src/canon/analytics_query.py tests/test_analytics_query.py
git commit -m "feat(analytics): add PostHogQueryClient and settings for analytics dashboard"
```

---

### Task 2: Emit Ticket Lifecycle Events in Sync Engine

**Files:**
- Modify: `src/canon/sync/engine.py`
- Modify: `tests/` (existing sync engine tests)

The sync engine's `forward_sync` and `reverse_sync` functions need to emit analytics events. Since the engine doesn't have access to `owner/repo` context, we add optional `repo` and `org` params to both functions.

- [ ] **Step 1: Add analytics import and repo/org params to forward_sync**

In `src/canon/sync/engine.py`, add import at top:
```python
from canon import analytics
```

Add `repo: str = ""` and `org: str = ""` keyword params to `forward_sync` signature (line 71):
```python
async def forward_sync(
    doc: SpecDocument,
    adapter: TicketAdapter,
    project_key: str,
    *,
    require_review: bool = False,
    dry_run: bool = False,
    system_config: TicketSystemConfig | None = None,
    spec_url: str = "",
    lifecycle_sync: bool | Literal["close_only"] = True,
    repo: str = "",
    org: str = "",
) -> tuple[str, SyncResult]:
```

- [ ] **Step 2: Emit ticket_created event after adapter.create_ticket succeeds**

After line 288 (after `result.created.append(...)` in the create ticket block), add:

```python
                analytics.track(
                    "ticket_created",
                    properties={
                        "repo": repo,
                        "spec_path": doc.file_path,
                        "section_id": section.id,
                        "ticket_system": _detect_system(adapter, system_config),
                        "ticket_id": ticket.ticket_id,
                        "issue_type": issue_type,
                    },
                    groups={"organization": org} if org else None,
                )
```

- [ ] **Step 3: Emit ticket_deduped event on dedup match**

After line 256 (after `result.updated.append(...)` in the dedup match block), add:

```python
                    analytics.track(
                        "ticket_deduped",
                        properties={
                            "repo": repo,
                            "spec_path": doc.file_path,
                            "section_id": section.id,
                            "ticket_id": dedup_match.ticket_id,
                            "dedup_method": dedup_method,
                        },
                        groups={"organization": org} if org else None,
                    )
```

- [ ] **Step 4: Emit ticket_closed and ticket_reopened events in lifecycle sync**

After `result.closed.append(...)` (line 338), add:

```python
                            analytics.track(
                                "ticket_closed",
                                properties={
                                    "repo": repo,
                                    "spec_path": doc.file_path,
                                    "section_id": section.id,
                                    "ticket_id": section.ticket_link.ticket_id,
                                    "reason": section.status.state,
                                },
                                groups={"organization": org} if org else None,
                            )
```

After `result.reopened.append(...)` (line 360), add:

```python
                        analytics.track(
                            "ticket_reopened",
                            properties={
                                "repo": repo,
                                "spec_path": doc.file_path,
                                "section_id": section.id,
                                "ticket_id": section.ticket_link.ticket_id,
                            },
                            groups={"organization": org} if org else None,
                        )
```

- [ ] **Step 5: Add repo/org params to reverse_sync and emit ticket_status_synced**

Add `repo: str = ""` and `org: str = ""` to `reverse_sync` signature.

After `result.status_changed.append(...)` (line 543), add:

```python
                analytics.track(
                    "ticket_status_synced",
                    properties={
                        "repo": repo,
                        "spec_path": doc.file_path,
                        "section_id": section.id,
                        "ticket_id": section.ticket_link.ticket_id,
                        "old_state": section.status.state,
                        "new_state": new_state,
                        "ticket_system": system,
                    },
                    groups={"organization": org} if org else None,
                )
```

- [ ] **Step 6: Pass repo/org through from on_push.py**

In `src/canon/github/handlers/on_push.py`, update the `forward_sync` call (line 322) to pass:

```python
            markdown, sync_result = await forward_sync(
                result.document,
                adapter,
                project_key,
                require_review=require_review,
                system_config=sys_config,
                spec_url=spec_url,
                repo=f"{owner}/{repo}",
                org=owner,
            )
```

- [ ] **Step 7: Run existing tests**

Run: `uv run pytest tests/test_sync_engine.py -v`
Expected: All existing tests PASS (new params have defaults)

- [ ] **Step 8: Commit**

```bash
git add src/canon/sync/engine.py src/canon/github/handlers/on_push.py
git commit -m "feat(analytics): emit ticket lifecycle events from sync engine"
```

---

### Task 3: Emit Spec Lifecycle + AC Realized Events

**Files:**
- Modify: `src/canon/github/handlers/on_push.py`
- Modify: `src/canon/github/handlers/on_pull_request.py`

- [ ] **Step 1: Emit spec_detected for newly added spec files**

In `on_push.py`, inside the `for file_path in spec_files:` loop (line 303), after parsing (line 310), add spec detection logic. We need to track which files were `added` vs `modified`:

First, before the loop, build an `added_files` set from commit data:

```python
    # Track files added (vs modified) for spec_detected events
    added_files: set[str] = set()
    for commit in commits:
        for f in commit.get("added", []):
            added_files.add(f)
```

Then after `parsed_specs[file_path] = result.document` (line 310), add:

```python
            # Emit spec_detected for newly added spec files
            if file_path in added_files:
                from canon.parser.models import flatten_sections as _flat
                fm = result.document.frontmatter
                all_flat = _flat(result.document.sections)
                total_ac = sum(len(s.acceptance_criteria) for s in all_flat)
                analytics.track(
                    "spec_detected",
                    properties={
                        "repo": f"{owner}/{repo}",
                        "spec_path": file_path,
                        "title": fm.title,
                        "author": fm.owner,
                        "team": fm.team,
                        "section_count": len(result.document.sections),
                        "ac_count": total_ac,
                    },
                    groups={"organization": owner},
                )
```

- [ ] **Step 2: Emit ac_realized events from PR analysis**

In `on_pull_request.py`, after the `analytics.track("pr_analyzed", ...)` call (line 346-358) and inside the `if result.realizations:` block (line 361), add individual AC events:

```python
            if result.realizations:
                for r in result.realizations:
                    if r.status.value in ("realized", "partially_realized"):
                        analytics.track(
                            "ac_realized",
                            properties={
                                "repo": f"{owner}/{repo}",
                                "spec_path": r.spec_file,
                                "section_id": r.section_id,
                                "ac_text": r.ac_text[:200],
                                "pr_number": pr_number,
                                "confidence": r.status.value,
                            },
                            groups={"organization": owner},
                        )
```

Place this before the existing `agent_store` block (line 362).

- [ ] **Step 3: Run existing tests**

Run: `uv run pytest tests/ -k "push or pull_request" -v`
Expected: All existing tests PASS

- [ ] **Step 4: Commit**

```bash
git add src/canon/github/handlers/on_push.py src/canon/github/handlers/on_pull_request.py
git commit -m "feat(analytics): emit spec lifecycle and ac_realized events"
```

---

### Task 4: Emit Config + SRE Events and Migrate Groups

**Files:**
- Modify: `src/canon/mcp/server.py`
- Modify: `src/canon/github/handlers/on_push.py` (config_loaded)

- [ ] **Step 1: Emit config_loaded in on_push after config loads**

In `on_push.py`, after `config = await load_repo_config(...)` (line 288), add:

```python
    analytics.track(
        "config_loaded",
        properties={
            "repo": f"{owner}/{repo}",
            "auto_tickets": config.specs.auto_tickets,
            "require_review": config.specs.require_review,
            "lifecycle_sync": getattr(config, 'lifecycle_sync', True),
            "ticket_systems": list(config.ticket_mapping.ticket_systems.keys()) if config.ticket_mapping else [],
            "routing_rules_count": len(config.ticket_mapping.routing.rules) if config.ticket_mapping and config.ticket_mapping.routing else 0,
            "ide_auto_context": config.ide.auto_context if hasattr(config, 'ide') else False,
            "ide_auto_verify": config.ide.auto_verify if hasattr(config, 'ide') else False,
            "sre_enabled": config.sre.alerts_channel != "" if hasattr(config, 'sre') else False,
            "has_ticket_mapping": config.ticket_mapping is not None,
        },
        groups={"organization": owner},
    )
```

- [ ] **Step 2: Add groups to MCP server analytics calls**

In `src/canon/mcp/server.py`, update each of the ~11 `analytics.track("mcp_tool_called", ...)` calls to include groups. For tools that have `owner` as a parameter:

```python
analytics.track(
    "mcp_tool_called",
    properties={"tool": "get_spec", "repo": f"{owner}/{repo}"},
    groups={"organization": owner},
)
```

For `search` and `list_docs` that take optional `repo`:
```python
_org = repo.split("/")[0] if repo and "/" in repo else ""
analytics.track(
    "mcp_tool_called",
    properties={"tool": "search", "repo": repo or ""},
    groups={"organization": _org} if _org else None,
)
```

- [ ] **Step 3: Run tests**

Run: `uv run pytest tests/ -v --timeout=30`
Expected: All PASS

- [ ] **Step 4: Commit**

```bash
git add src/canon/github/handlers/on_push.py src/canon/mcp/server.py
git commit -m "feat(analytics): emit config events and add org groups to MCP tracking"
```

---

### Task 4A: Remaining Event Taxonomy ACs

**Files:**
- Modify: `src/canon/github/handlers/on_push.py` — `spec_status_changed`, `ticket_routing_matched`
- Modify: `src/canon/cron/stale_check.py` — `stale_spec_detected`
- Modify: `src/canon/cron/weekly_digest.py` — `weekly_digest_sent`
- Modify: `src/canon/alerts/slack.py` — `sre_alert_fired`
- Modify: `src/canon/webhooks/router.py` — Add `groups` to `webhook_ticket_sync`
- Modify: `src/canon/agent/client.py` — Add `groups` to `agent_call_completed`

- [ ] **Step 1: Emit spec_status_changed in on_push**

In `on_push.py`, inside the `for file_path in spec_files:` loop, after parsing the spec, compare with previous version to detect status changes. Before the forward_sync call, add:

```python
            # Detect spec status changes by comparing with cached version
            try:
                from canon.main import app
                cache = getattr(app.state, "cache", None)
                cache_key = f"spec_status:{owner}/{repo}/{file_path}"
                prev_status = cache.get(cache_key) if cache else None
                current_status = result.document.frontmatter.status
                if prev_status and prev_status != current_status:
                    analytics.track(
                        "spec_status_changed",
                        properties={
                            "repo": f"{owner}/{repo}",
                            "spec_path": file_path,
                            "from_status": prev_status,
                            "to_status": current_status,
                        },
                        groups={"organization": owner},
                    )
                if cache:
                    cache.set(cache_key, current_status)
            except Exception:
                pass  # Best-effort
```

- [ ] **Step 2: Emit ticket_routing_matched in on_push**

In `on_push.py`, inside `_resolve_adapter()`, after `target_name = resolve_target(...)` (line 199) when `target_name` is resolved, emit:

```python
        if target_name:
            analytics.track(
                "ticket_routing_matched",
                properties={
                    "repo": "",  # not available here; will be set at call site
                    "spec_path": file_path,
                    "matched_rule": target_name,
                    "target_system": target_name,
                },
            )
```

Note: `_resolve_adapter` doesn't have `owner` in scope. A simpler approach is to emit after the `_resolve_adapter` call in the main loop where `owner` is available. After line 316 (`if not adapter or not project_key: continue`), add:

```python
            if sys_config:
                analytics.track(
                    "ticket_routing_matched",
                    properties={
                        "repo": f"{owner}/{repo}",
                        "spec_path": file_path,
                        "section_id": "",
                        "matched_rule": next(iter(mapping.ticket_systems.keys()), ""),
                        "target_system": _detect_system_name(adapter, sys_config),
                    },
                    groups={"organization": owner},
                )
```

Where `_detect_system_name` is imported from `sync.engine._detect_system` or inlined.

- [ ] **Step 3: Emit config_feature_used at feature activation points**

This event is emitted when a config-driven feature actually activates. In `on_push.py`, after ticket creation succeeds (when `auto_tickets` was the trigger), emit:

```python
analytics.track(
    "config_feature_used",
    properties={"repo": f"{owner}/{repo}", "feature": "auto_tickets", "outcome": "tickets_created"},
    groups={"organization": owner},
)
```

Similarly in other feature activation points (e.g., require_review blocking sync, lifecycle_sync closing tickets). Add these alongside the existing sync result logging.

- [ ] **Step 4: Emit stale_spec_detected in stale_check.py**

In `src/canon/cron/stale_check.py`, after detecting stale docs, emit events. After the stale detection loop produces results, add:

```python
from canon import analytics

for stale_doc in stale_docs:
    analytics.track(
        "stale_spec_detected",
        properties={
            "repo": stale_doc.get("repo", ""),
            "spec_path": stale_doc.get("path", ""),
            "days_since_update": stale_doc.get("days_stale", 0),
            "last_code_change": stale_doc.get("last_code_change", ""),
        },
    )
```

- [ ] **Step 5: Emit sre_alert_fired in alerts/slack.py**

In `src/canon/alerts/slack.py`, in the `send()` method, after sending the alert, emit:

```python
from canon import analytics
analytics.track(
    "sre_alert_fired",
    properties={
        "alert_type": alert.title,
        "severity": alert.severity.name if hasattr(alert.severity, 'name') else str(alert.severity),
    },
)
```

- [ ] **Step 6: Emit weekly_digest_sent in weekly_digest.py**

In `src/canon/cron/weekly_digest.py`, after `await alerter.send_text(message)` (line 47), add:

```python
analytics.track(
    "weekly_digest_sent",
    properties={
        "org": "",  # org context not available in cron; skip groups
        "repos_covered": 0,
        "specs_covered": 0,
        "alerts_count": digest.total_errors_this_week,
    },
)
```

- [ ] **Step 7: Add groups to webhooks/router.py**

In `src/canon/webhooks/router.py`, update `_track_webhook()` (line 39-51) to accept and pass org:

```python
def _track_webhook(system: str, ticket_id: str, result: ProcessResult, org: str = "") -> None:
    """Track webhook processing in analytics."""
    analytics.track(
        "webhook_ticket_sync",
        properties={
            "system": system,
            "ticket_id": ticket_id,
            "processed": result.processed,
            "old_state": result.old_state,
            "new_state": result.new_state,
            "error": result.error,
        },
        groups={"organization": org} if org else None,
    )
```

Update all call sites of `_track_webhook` to pass the org extracted from the webhook payload.

- [ ] **Step 8: Add groups to agent/client.py**

In `src/canon/agent/client.py`, the `complete()` method has two `analytics.track("agent_call_completed", ...)` calls (lines 66 and 109). The client doesn't have org context, so this requires threading org through. Add `org: str = ""` as an optional param to `complete()` and pass groups:

```python
def complete(
    self, system_prompt: str, user_message: str, config: AgentConfig, *, org: str = ""
) -> CompletionResult:
    ...
    analytics.track(
        "agent_call_completed",
        properties={...},
        groups={"organization": org} if org else None,
    )
```

Update the call site in `on_pull_request.py` where `analyze_pr` calls the client, passing `org=owner`.

- [ ] **Step 9: Commit**

```bash
git add src/canon/github/handlers/on_push.py src/canon/cron/stale_check.py \
  src/canon/cron/weekly_digest.py src/canon/alerts/slack.py \
  src/canon/webhooks/router.py src/canon/agent/client.py
git commit -m "feat(analytics): emit remaining event taxonomy ACs (spec_status_changed, stale, SRE, routing, groups migration)"
```

---

### Task 5: Health Score Algorithm

**Files:**
- Create: `src/canon/health_score.py`
- Create: `tests/test_health_score.py`

- [ ] **Step 1: Write failing tests for health score computation**

Create `tests/test_health_score.py`:

```python
"""Tests for health score algorithm."""

from __future__ import annotations

import pytest

from canon.health_score import (
    compute_freshness,
    compute_health_score,
    compute_momentum,
    compute_time_to_ship,
)


class TestMomentum:
    def test_flat_activity_scores_50(self):
        """Same activity this week as last week = score 50."""
        score = compute_momentum(this_week=10, prev_week=10, four_wk_avg=10)
        assert score == pytest.approx(50, abs=1)

    def test_growing_activity_above_50(self):
        """Double activity this week = high score."""
        score = compute_momentum(this_week=20, prev_week=10, four_wk_avg=10)
        assert score > 50

    def test_declining_activity_below_50(self):
        """Half activity this week = low score."""
        score = compute_momentum(this_week=5, prev_week=10, four_wk_avg=10)
        assert score < 50

    def test_zero_prev_week_no_crash(self):
        """Division by zero handled gracefully."""
        score = compute_momentum(this_week=5, prev_week=0, four_wk_avg=0)
        assert 0 <= score <= 100

    def test_all_zero_returns_50(self):
        """No activity at all = neutral 50."""
        score = compute_momentum(this_week=0, prev_week=0, four_wk_avg=0)
        assert score == pytest.approx(50, abs=1)

    def test_clamped_to_0_100(self):
        """Score always in [0, 100]."""
        score = compute_momentum(this_week=1000, prev_week=1, four_wk_avg=1)
        assert 0 <= score <= 100


class TestFreshness:
    def test_all_fresh_specs(self):
        """All specs updated within 7 days of code = 100."""
        specs = [
            {"staleness_gap": 3, "ac_count": 10},
            {"staleness_gap": 5, "ac_count": 5},
        ]
        score = compute_freshness(specs)
        assert score == pytest.approx(100, abs=1)

    def test_stale_spec_penalized(self):
        """Spec with large staleness gap reduces score."""
        specs = [
            {"staleness_gap": 30, "ac_count": 10},  # very stale
        ]
        score = compute_freshness(specs)
        assert score < 50

    def test_weighted_by_ac_count(self):
        """Spec with more ACs weighs more."""
        specs = [
            {"staleness_gap": 0, "ac_count": 100},  # fresh, heavy
            {"staleness_gap": 30, "ac_count": 1},  # stale, light
        ]
        score = compute_freshness(specs)
        assert score > 80  # dominated by fresh heavy spec

    def test_empty_specs_returns_none(self):
        """No specs = insufficient data."""
        score = compute_freshness([])
        assert score is None


class TestTimeToShip:
    def test_improving_cycle_above_50(self):
        """Faster than baseline = above 50."""
        score = compute_time_to_ship(current_cycle=5.0, baseline_cycle=10.0)
        assert score > 50

    def test_same_cycle_scores_50(self):
        """Same speed as baseline = 50."""
        score = compute_time_to_ship(current_cycle=10.0, baseline_cycle=10.0)
        assert score == pytest.approx(50, abs=1)

    def test_slowing_cycle_below_50(self):
        """Slower than baseline = below 50."""
        score = compute_time_to_ship(current_cycle=20.0, baseline_cycle=10.0)
        assert score < 50

    def test_zero_current_no_crash(self):
        """Zero current cycle handled."""
        score = compute_time_to_ship(current_cycle=0.0, baseline_cycle=10.0)
        assert 0 <= score <= 100

    def test_zero_baseline_returns_50(self):
        """No baseline data = neutral 50."""
        score = compute_time_to_ship(current_cycle=10.0, baseline_cycle=0.0)
        assert score == pytest.approx(50, abs=1)


class TestComposite:
    def test_weighted_composite(self):
        """Composite = 0.35*momentum + 0.30*freshness + 0.35*time_to_ship."""
        score = compute_health_score(momentum=80, freshness=60, time_to_ship=40)
        expected = 80 * 0.35 + 60 * 0.30 + 40 * 0.35
        assert score == pytest.approx(expected, abs=0.1)

    def test_insufficient_data(self):
        """None pillars handled."""
        score = compute_health_score(momentum=None, freshness=None, time_to_ship=None)
        assert score is None

    def test_partial_data(self):
        """Some pillars available, others None."""
        score = compute_health_score(momentum=80, freshness=None, time_to_ship=60)
        # Should compute with available pillars, re-weighted
        assert score is not None
        assert 0 <= score <= 100
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_health_score.py -v`
Expected: ImportError

- [ ] **Step 3: Implement health score module**

Create `src/canon/health_score.py`:

```python
"""Health score algorithm — composite metric of Canon value in an organization.

Score range: 0–100. Composed of three pillars:
- Momentum (35%): Activity trend over 4-week window
- Freshness (30%): How well specs track code changes
- Time-to-Ship (35%): Cycle time improvement vs historical baseline
"""

from __future__ import annotations


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _normalize(value: float, in_lo: float, in_hi: float) -> float:
    """Map value from [in_lo, in_hi] to [0, 100]."""
    if in_hi == in_lo:
        return 50.0
    return (value - in_lo) / (in_hi - in_lo) * 100


def compute_momentum(
    this_week: int | float,
    prev_week: int | float,
    four_wk_avg: int | float,
) -> float:
    """Compute momentum pillar (0–100). 50 = flat activity."""
    if prev_week == 0 and this_week == 0:
        return 50.0
    if prev_week == 0:
        prev_week = max(this_week * 0.5, 1)
    if four_wk_avg == 0:
        four_wk_avg = max(this_week * 0.5, 1)

    wow = _clamp(this_week / prev_week, 0.5, 2.0)
    trend = _clamp(this_week / four_wk_avg, 0.5, 2.0)
    raw = wow * 0.6 + trend * 0.4
    return _normalize(raw, 0.5, 2.0)


def compute_freshness(
    specs: list[dict],
) -> float | None:
    """Compute freshness pillar (0–100), weighted by AC count.

    Each spec dict must have 'staleness_gap' (days) and 'ac_count' (int).
    Returns None if no specs provided.
    """
    if not specs:
        return None

    total_weight = sum(s["ac_count"] for s in specs)
    if total_weight == 0:
        return None

    weighted_sum = 0.0
    for s in specs:
        gap = s["staleness_gap"]
        if gap <= 7:
            freshness = 100.0
        else:
            freshness = max(0.0, 100.0 - (gap - 7) * 5)
        weighted_sum += freshness * s["ac_count"]

    return weighted_sum / total_weight


def compute_time_to_ship(
    current_cycle: float,
    baseline_cycle: float,
) -> float:
    """Compute time-to-ship pillar (0–100). 50 = same speed as baseline."""
    if baseline_cycle == 0:
        return 50.0
    if current_cycle == 0:
        return 100.0
    ratio = _clamp(baseline_cycle / current_cycle, 0.5, 2.0)
    return _normalize(ratio, 0.5, 2.0)


def compute_health_score(
    momentum: float | None,
    freshness: float | None,
    time_to_ship: float | None,
) -> float | None:
    """Compute composite health score (0–100).

    Weights: momentum 35%, freshness 30%, time_to_ship 35%.
    If all pillars are None, returns None (insufficient data).
    If some are None, re-weights available pillars proportionally.
    """
    pillars = [
        (momentum, 0.35),
        (freshness, 0.30),
        (time_to_ship, 0.35),
    ]
    available = [(score, weight) for score, weight in pillars if score is not None]
    if not available:
        return None

    total_weight = sum(w for _, w in available)
    return sum(s * w / total_weight for s, w in available)


def score_label(score: float | None) -> str:
    """Human-readable label for a health score."""
    if score is None:
        return "Insufficient data"
    if score >= 80:
        return "Excellent"
    if score >= 60:
        return "Good"
    if score >= 40:
        return "Growing"
    return "Getting Started"
```

- [ ] **Step 4: Run tests**

Run: `uv run pytest tests/test_health_score.py -v`
Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/health_score.py tests/test_health_score.py
git commit -m "feat(analytics): implement health score algorithm with momentum, freshness, and time-to-ship pillars"
```

---

### Task 6: Analytics API Endpoints

**Files:**
- Create: `src/canon/web/analytics_routes.py`
- Modify: `src/canon/main.py:444` (include router)
- Create: `tests/test_web/test_analytics_routes.py`

- [ ] **Step 1: Write failing tests for analytics endpoints**

Create `tests/test_web/test_analytics_routes.py`:

```python
"""Tests for analytics API endpoints."""

from __future__ import annotations

import pytest

from canon.web.analytics_routes import (
    _query_health,
    _query_momentum,
    _query_freshness,
    _query_time_to_ship,
    _query_feature_usage,
)


class _MockQueryClient:
    """Mock PostHog query client that returns empty results."""
    configured = True
    async def query(self, hogql: str) -> list[dict]:
        return []


class TestQueryFunctions:
    """Test the query functions directly (no HTTP/auth overhead)."""

    @pytest.mark.asyncio
    async def test_query_health_empty_data(self):
        client = _MockQueryClient()
        result = await _query_health(client, "testorg", "", 30)
        assert "score" in result
        assert "pillars" in result
        assert "trend" in result
        assert result["label"] in ("Insufficient data", "Getting Started", "Growing", "Good", "Excellent")

    @pytest.mark.asyncio
    async def test_query_momentum_empty_data(self):
        client = _MockQueryClient()
        result = await _query_momentum(client, "testorg", "", 30)
        assert "weekly_activity" in result
        assert "top_repos" in result

    @pytest.mark.asyncio
    async def test_query_freshness_empty_data(self):
        client = _MockQueryClient()
        result = await _query_freshness(client, "testorg", "", 30)
        assert "specs" in result
        assert "summary" in result

    @pytest.mark.asyncio
    async def test_query_time_to_ship_empty_data(self):
        client = _MockQueryClient()
        result = await _query_time_to_ship(client, "testorg", "", 30)
        assert "stages" in result

    @pytest.mark.asyncio
    async def test_query_feature_usage_empty_data(self):
        client = _MockQueryClient()
        result = await _query_feature_usage(client, "testorg", "", 0)
        assert "features" in result
```

- [ ] **Step 2: Implement analytics routes**

Create `src/canon/web/analytics_routes.py`:

```python
"""Analytics dashboard API endpoints."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from ..auth.deps import require_permission
from ..auth.models import CurrentUser
from ..auth.permissions import Permission

logger = logging.getLogger(__name__)

analytics_router = APIRouter()


def _get_cache(request: Request):
    return request.app.state.cache


def _get_query_client(request: Request):
    return getattr(request.app.state, "posthog_query_client", None)


def _cache_key(org: str, endpoint: str, team: str, days: int) -> str:
    return f"analytics:{org}:{endpoint}:{team}:{days}"


def _analytics_cache_set(cache, key: str, value: Any, ttl: int) -> None:
    """Set a cache entry with a specific TTL (avoids mutating shared TTL)."""
    import time as _time
    from canon.web.cache import _Entry
    cache._store[key] = _Entry(value=value, expires_at=_time.monotonic() + ttl)


async def _cached_query(
    request: Request,
    org: str,
    endpoint: str,
    team: str,
    days: int,
    ttl: int,
    query_fn,
) -> dict[str, Any]:
    """Execute query with TTL caching. Returns stale data on error."""
    cache = _get_cache(request)
    key = _cache_key(org, endpoint, team, days)

    cached = cache.get(key)
    if cached is not None:
        return cached

    query_client = _get_query_client(request)
    if query_client is None or not query_client.configured:
        return {"error": "analytics_not_configured"}

    try:
        result = await query_fn(query_client, org, team, days)
        _analytics_cache_set(cache, key, result, ttl)
        return result
    except Exception:
        logger.debug("Analytics query failed for %s/%s", org, endpoint, exc_info=True)
        return {"error": "analytics_unavailable"}


async def _query_health(client, org: str, team: str, days: int) -> dict:
    """Query PostHog for health score data."""
    from ..health_score import compute_health_score, compute_momentum, score_label

    # Query activity counts for momentum
    team_filter = f"AND properties.team = '{team}'" if team else ""
    activities = await client.query(f"""
        SELECT
            toStartOfWeek(timestamp) as week,
            count() as cnt
        FROM events
        WHERE event IN ('spec_saved', 'ticket_created', 'pr_analyzed', 'ac_realized', 'mcp_tool_called')
            AND properties.$group_0 = '{org}'
            AND timestamp > now() - interval {days} day
            {team_filter}
        GROUP BY week
        ORDER BY week
    """)

    # Compute momentum from activity data
    this_week = 0
    prev_week = 0
    four_wk_avg = 0
    if activities:
        this_week = activities[-1].get("cnt", 0) if activities else 0
        prev_week = activities[-2].get("cnt", 0) if len(activities) > 1 else 0
        total = sum(r.get("cnt", 0) for r in activities[-4:])
        four_wk_avg = total / min(len(activities), 4)

    momentum = compute_momentum(this_week, prev_week, four_wk_avg)

    # Freshness and time-to-ship use simpler placeholders when data is sparse
    score = compute_health_score(momentum=momentum, freshness=None, time_to_ship=None)
    label = score_label(score)

    trend = [
        {"date": r.get("week", ""), "score": r.get("cnt", 0)}
        for r in activities
    ]

    return {
        "score": round(score, 1) if score is not None else None,
        "label": label,
        "trend": trend,
        "pillars": {
            "momentum": {"score": round(momentum, 1), "summary": f"{this_week} activities this week"},
            "freshness": {"score": None, "summary": "Insufficient data"},
            "time_to_ship": {"score": None, "summary": "Insufficient data"},
        },
    }


async def _query_momentum(client, org: str, team: str, days: int) -> dict:
    """Query PostHog for momentum breakdown."""
    team_filter = f"AND properties.team = '{team}'" if team else ""
    rows = await client.query(f"""
        SELECT
            toStartOfWeek(timestamp) as week,
            event,
            count() as cnt
        FROM events
        WHERE event IN ('spec_saved', 'ticket_created', 'pr_analyzed', 'ac_realized', 'mcp_tool_called')
            AND properties.$group_0 = '{org}'
            AND timestamp > now() - interval {days} day
            {team_filter}
        GROUP BY week, event
        ORDER BY week
    """)

    top_repos = await client.query(f"""
        SELECT properties.repo as repo, count() as cnt
        FROM events
        WHERE event IN ('spec_saved', 'ticket_created', 'pr_analyzed', 'ac_realized')
            AND properties.$group_0 = '{org}'
            AND timestamp > now() - interval {days} day
            {team_filter}
        GROUP BY repo ORDER BY cnt DESC LIMIT 10
    """)

    return {
        "weekly_activity": [
            {"week": r.get("week", ""), "event_type": r.get("event", ""), "count": r.get("cnt", 0)}
            for r in rows
        ],
        "top_repos": [{"repo": r.get("repo", ""), "count": r.get("cnt", 0)} for r in top_repos],
        "top_contributors": [],
    }


async def _query_freshness(client, org: str, team: str, days: int) -> dict:
    """Query PostHog for freshness data."""
    team_filter = f"AND properties.team = '{team}'" if team else ""
    rows = await client.query(f"""
        SELECT
            properties.spec_path as spec_path,
            properties.repo as repo,
            max(timestamp) as last_update
        FROM events
        WHERE event IN ('spec_saved', 'spec_status_changed')
            AND properties.$group_0 = '{org}'
            AND timestamp > now() - interval {days} day
            {team_filter}
        GROUP BY spec_path, repo
    """)

    specs = []
    fresh_count = 0
    stale_count = 0
    for r in rows:
        specs.append({
            "spec_path": r.get("spec_path", ""),
            "repo": r.get("repo", ""),
            "freshness_score": 100,
            "days_since_update": 0,
            "days_since_code": 0,
        })
        fresh_count += 1

    return {
        "specs": specs,
        "summary": {
            "fresh_count": fresh_count,
            "stale_count": stale_count,
            "avg_gap_days": 0,
        },
    }


async def _query_time_to_ship(client, org: str, team: str, days: int) -> dict:
    """Query PostHog for cycle time data."""
    return {
        "stages": [],
        "total_cycle_days": 0,
        "improvement_pct": 0,
        "trend": [],
    }


async def _query_feature_usage(client, org: str, team: str, days: int) -> dict:
    """Query PostHog for feature usage data."""
    rows = await client.query(f"""
        SELECT
            properties.auto_tickets as auto_tickets,
            properties.require_review as require_review,
            properties.sre_enabled as sre_enabled,
            properties.has_ticket_mapping as has_ticket_mapping,
            count(distinct properties.repo) as repo_count
        FROM events
        WHERE event = 'config_loaded'
            AND properties.$group_0 = '{org}'
            AND timestamp > now() - interval 30 day
        GROUP BY auto_tickets, require_review, sre_enabled, has_ticket_mapping
    """)

    total_repos = await client.query(f"""
        SELECT count(distinct properties.repo) as cnt
        FROM events
        WHERE event = 'config_loaded'
            AND properties.$group_0 = '{org}'
            AND timestamp > now() - interval 30 day
    """)

    total = total_repos[0].get("cnt", 0) if total_repos else 0

    return {
        "features": [],
        "repos_with_config": total,
        "repos_without_config": 0,
    }


# --- Endpoint definitions ---


@analytics_router.get("/{org}/api/analytics/health", response_class=JSONResponse)
async def api_analytics_health(
    request: Request,
    org: str,
    team: str = "",
    days: int = 30,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
) -> JSONResponse:
    result = await _cached_query(request, org, "health", team, days, 3600, _query_health)
    return JSONResponse(result)


@analytics_router.get("/{org}/api/analytics/momentum", response_class=JSONResponse)
async def api_analytics_momentum(
    request: Request,
    org: str,
    team: str = "",
    days: int = 30,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
) -> JSONResponse:
    result = await _cached_query(request, org, "momentum", team, days, 900, _query_momentum)
    return JSONResponse(result)


@analytics_router.get("/{org}/api/analytics/freshness", response_class=JSONResponse)
async def api_analytics_freshness(
    request: Request,
    org: str,
    team: str = "",
    days: int = 30,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
) -> JSONResponse:
    result = await _cached_query(request, org, "freshness", team, days, 900, _query_freshness)
    return JSONResponse(result)


@analytics_router.get("/{org}/api/analytics/time-to-ship", response_class=JSONResponse)
async def api_analytics_time_to_ship(
    request: Request,
    org: str,
    team: str = "",
    days: int = 30,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
) -> JSONResponse:
    result = await _cached_query(request, org, "time_to_ship", team, days, 900, _query_time_to_ship)
    return JSONResponse(result)


@analytics_router.get("/{org}/api/analytics/feature-usage", response_class=JSONResponse)
async def api_analytics_feature_usage(
    request: Request,
    org: str,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_ADMIN)),
) -> JSONResponse:
    result = await _cached_query(request, org, "feature_usage", "", 0, 3600, _query_feature_usage)
    return JSONResponse(result)
```

- [ ] **Step 3: Mount analytics router in main.py**

In `src/canon/main.py`, add import:
```python
from .web.analytics_routes import analytics_router
```

Add `app.include_router(analytics_router)` after `app.include_router(app_router)` (line 444).

- [ ] **Step 4: Initialize PostHogQueryClient in lifespan**

In `src/canon/main.py` lifespan function, after analytics init (~line 93), add:

```python
    # PostHog Query Client for analytics dashboard reads
    from .analytics_query import PostHogQueryClient
    app.state.posthog_query_client = PostHogQueryClient(
        api_key=settings.posthog_personal_api_key,
        project_id=settings.posthog_project_id,
        host=settings.posthog_host,
    )
```

- [ ] **Step 5: Run tests**

Run: `uv run pytest tests/ -v --timeout=30`
Expected: All PASS

- [ ] **Step 6: Commit**

```bash
git add src/canon/web/analytics_routes.py src/canon/main.py
git commit -m "feat(analytics): add analytics API endpoints with caching and permission control"
```

---

### Task 7: Frontend Types + API Client

**Files:**
- Modify: `frontend/src/api/types.ts`
- Create: `frontend/src/api/analytics.ts`

- [ ] **Step 1: Add analytics types**

Append to `frontend/src/api/types.ts`:

```typescript
// --- Analytics Dashboard ---

export interface PillarData {
  score: number | null
  delta?: number
  summary: string
}

export interface HealthTrendPoint {
  date: string
  score: number
}

export interface HealthResponse {
  score: number | null
  label: string
  trend: HealthTrendPoint[]
  pillars: {
    momentum: PillarData
    freshness: PillarData
    time_to_ship: PillarData
  }
}

export interface WeeklyActivity {
  week: string
  event_type: string
  count: number
}

export interface MomentumResponse {
  weekly_activity: WeeklyActivity[]
  top_repos: { repo: string; count: number }[]
  top_contributors: { user: string; count: number }[]
}

export interface FreshnessSpec {
  spec_path: string
  repo: string
  freshness_score: number
  days_since_update: number
  days_since_code: number
}

export interface FreshnessResponse {
  specs: FreshnessSpec[]
  summary: {
    fresh_count: number
    stale_count: number
    avg_gap_days: number
  }
}

export interface CycleStage {
  name: string
  median_days: number
  trend_pct: number
}

export interface TimeToShipResponse {
  stages: CycleStage[]
  total_cycle_days: number
  improvement_pct: number
  trend: { week: string; total_cycle: number }[]
}

export interface FeatureUsageItem {
  name: string
  enabled_count: number
  total_repos: number
  pct: number
}

export interface FeatureUsageResponse {
  features: FeatureUsageItem[]
  repos_with_config: number
  repos_without_config: number
}
```

- [ ] **Step 2: Create analytics API client**

Create `frontend/src/api/analytics.ts`:

```typescript
import { get } from './client'
import type {
  HealthResponse,
  MomentumResponse,
  FreshnessResponse,
  TimeToShipResponse,
  FeatureUsageResponse,
} from './types'

function buildQuery(team?: string, days?: number): string {
  const query = new URLSearchParams()
  if (team) query.set('team', team)
  if (days) query.set('days', String(days))
  const qs = query.toString()
  return qs ? `?${qs}` : ''
}

export function fetchHealth(org: string, team?: string, days?: number): Promise<HealthResponse> {
  return get<HealthResponse>(`/app/${org}/api/analytics/health${buildQuery(team, days)}`)
}

export function fetchMomentum(org: string, team?: string, days?: number): Promise<MomentumResponse> {
  return get<MomentumResponse>(`/app/${org}/api/analytics/momentum${buildQuery(team, days)}`)
}

export function fetchFreshness(org: string, team?: string, days?: number): Promise<FreshnessResponse> {
  return get<FreshnessResponse>(`/app/${org}/api/analytics/freshness${buildQuery(team, days)}`)
}

export function fetchTimeToShip(org: string, team?: string, days?: number): Promise<TimeToShipResponse> {
  return get<TimeToShipResponse>(`/app/${org}/api/analytics/time-to-ship${buildQuery(team, days)}`)
}

export function fetchFeatureUsage(org: string): Promise<FeatureUsageResponse> {
  return get<FeatureUsageResponse>(`/app/${org}/api/analytics/feature-usage`)
}
```

- [ ] **Step 3: Commit**

```bash
git add frontend/src/api/types.ts frontend/src/api/analytics.ts
git commit -m "feat(analytics): add frontend API client and TypeScript types for analytics dashboard"
```

---

### Task 8: Frontend Route + Navigation

**Files:**
- Modify: `frontend/src/router/index.ts:88-92`
- Modify: `frontend/src/components/layout/AppNav.vue:31-37`

- [ ] **Step 1: Add analytics route**

In `frontend/src/router/index.ts`, add after the `tasks` route (line 62):

```typescript
  {
    path: '/app/:org/analytics',
    name: 'analytics',
    component: () => import('@/views/AnalyticsView.vue'),
  },
```

- [ ] **Step 2: Add Analytics nav link**

In `frontend/src/components/layout/AppNav.vue`, add between Tasks (line 31) and Editor (line 32):

```vue
          <router-link
            :to="`/app/${auth.org}/analytics`"
            class="text-sm text-slate-600 dark:text-slate-400 hover:text-accent-400 transition-colors"
          >
            Analytics
          </router-link>
```

- [ ] **Step 3: Commit**

```bash
git add frontend/src/router/index.ts frontend/src/components/layout/AppNav.vue
git commit -m "feat(analytics): add analytics route and navigation link"
```

---

### Task 9: Analytics View + Core Components

**Files:**
- Create: `frontend/src/views/AnalyticsView.vue`
- Create: `frontend/src/components/analytics/HealthScoreHero.vue`
- Create: `frontend/src/components/analytics/PillarCard.vue`
- Create: `frontend/src/components/analytics/PillarRow.vue`
- Create: `frontend/src/components/analytics/AnalyticsFilterBar.vue`

- [ ] **Step 1: Create AnalyticsFilterBar**

Create `frontend/src/components/analytics/AnalyticsFilterBar.vue`:

```vue
<script setup lang="ts">
defineProps<{
  team: string
  days: number
  teams: string[]
}>()

const emit = defineEmits<{
  'update:team': [value: string]
  'update:days': [value: number]
}>()

const dayOptions = [
  { label: '7d', value: 7 },
  { label: '30d', value: 30 },
  { label: '90d', value: 90 },
]
</script>

<template>
  <div class="flex items-center gap-3 mb-6">
    <select
      :value="team"
      class="text-sm border border-border-light dark:border-slate-700 rounded-md px-3 py-1.5 bg-surface-light dark:bg-surface"
      @change="emit('update:team', ($event.target as HTMLSelectElement).value)"
    >
      <option value="">All teams</option>
      <option v-for="t in teams" :key="t" :value="t">{{ t }}</option>
    </select>
    <div class="flex rounded-md border border-border-light dark:border-slate-700 overflow-hidden">
      <button
        v-for="opt in dayOptions"
        :key="opt.value"
        class="px-3 py-1.5 text-sm transition-colors"
        :class="days === opt.value
          ? 'bg-accent-500 text-white'
          : 'bg-surface-light dark:bg-surface text-slate-600 dark:text-slate-400 hover:bg-surface-light-elevated dark:hover:bg-slate-700'"
        @click="emit('update:days', opt.value)"
      >
        {{ opt.label }}
      </button>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Create PillarCard**

Create `frontend/src/components/analytics/PillarCard.vue`:

```vue
<script setup lang="ts">
import type { PillarData } from '@/api/types'

defineProps<{
  title: string
  pillar: PillarData
}>()

function arrow(score: number | null): string {
  if (score === null) return ''
  if (score > 55) return '\u2191'
  if (score < 45) return '\u2193'
  return '\u2192'
}

function arrowColor(score: number | null): string {
  if (score === null) return 'text-slate-400'
  if (score > 55) return 'text-emerald-500'
  if (score < 45) return 'text-red-500'
  return 'text-amber-500'
}
</script>

<template>
  <div class="rounded-lg border border-border-light dark:border-slate-700 p-4 bg-surface-light dark:bg-surface">
    <div class="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">{{ title }}</div>
    <div class="flex items-baseline gap-2">
      <span v-if="pillar.score !== null" class="text-2xl font-bold text-slate-900 dark:text-slate-100">
        {{ Math.round(pillar.score) }}
      </span>
      <span v-else class="text-2xl font-bold text-slate-400">&mdash;</span>
      <span v-if="pillar.score !== null" :class="arrowColor(pillar.score)" class="text-lg">
        {{ arrow(pillar.score) }}
      </span>
    </div>
    <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">{{ pillar.summary }}</p>
  </div>
</template>
```

- [ ] **Step 3: Create PillarRow**

Create `frontend/src/components/analytics/PillarRow.vue`:

```vue
<script setup lang="ts">
import type { HealthResponse } from '@/api/types'
import PillarCard from './PillarCard.vue'

defineProps<{
  pillars: HealthResponse['pillars']
}>()
</script>

<template>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
    <PillarCard title="Momentum" :pillar="pillars.momentum" />
    <PillarCard title="Freshness" :pillar="pillars.freshness" />
    <PillarCard title="Time-to-Ship" :pillar="pillars.time_to_ship" />
  </div>
</template>
```

- [ ] **Step 4: Create HealthScoreHero**

Create `frontend/src/components/analytics/HealthScoreHero.vue`:

```vue
<script setup lang="ts">
import type { HealthResponse } from '@/api/types'

defineProps<{
  health: HealthResponse
}>()

function scoreColor(score: number | null): string {
  if (score === null) return 'text-slate-400'
  if (score >= 80) return 'text-emerald-500'
  if (score >= 60) return 'text-blue-500'
  if (score >= 40) return 'text-amber-500'
  return 'text-red-500'
}

function progressColor(score: number | null): string {
  if (score === null) return 'bg-slate-300 dark:bg-slate-600'
  if (score >= 80) return 'bg-emerald-500'
  if (score >= 60) return 'bg-blue-500'
  if (score >= 40) return 'bg-amber-500'
  return 'bg-red-500'
}
</script>

<template>
  <div class="rounded-lg border border-border-light dark:border-slate-700 p-6 mb-6 bg-surface-light dark:bg-surface">
    <div class="flex items-center justify-between mb-4">
      <div>
        <div class="text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">Health Score</div>
        <div class="flex items-baseline gap-3">
          <span
            v-if="health.score !== null"
            :class="scoreColor(health.score)"
            class="text-5xl font-bold"
          >{{ Math.round(health.score) }}</span>
          <span v-else class="text-5xl font-bold text-slate-400">&mdash;</span>
          <span class="text-sm text-slate-500 dark:text-slate-400">{{ health.label }}</span>
        </div>
      </div>
    </div>
    <div class="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
      <div
        :class="progressColor(health.score)"
        class="h-full rounded-full transition-all duration-500"
        :style="{ width: `${health.score ?? 0}%` }"
      />
    </div>
  </div>
</template>
```

- [ ] **Step 5: Create AnalyticsView**

Create `frontend/src/views/AnalyticsView.vue`:

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useQuery } from '@tanstack/vue-query'
import { fetchHealth } from '@/api/analytics'
import HealthScoreHero from '@/components/analytics/HealthScoreHero.vue'
import PillarRow from '@/components/analytics/PillarRow.vue'
import AnalyticsFilterBar from '@/components/analytics/AnalyticsFilterBar.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import EmptyState from '@/components/common/EmptyState.vue'

const route = useRoute()
const org = computed(() => route.params.org as string)
const team = ref('')
const days = ref(30)

const { data: health, isLoading } = useQuery({
  queryKey: ['analytics-health', org, team, days],
  queryFn: () => fetchHealth(org.value, team.value || undefined, days.value),
})

const teams: string[] = []  // TODO: populate from search facets
</script>

<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <h1 class="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-6">Analytics</h1>

    <AnalyticsFilterBar
      v-model:team="team"
      v-model:days="days"
      :teams="teams"
    />

    <LoadingSpinner v-if="isLoading" />

    <template v-else-if="health && health.score !== undefined">
      <template v-if="health.error === 'analytics_not_configured'">
        <EmptyState
          title="Analytics Not Configured"
          description="Set POSTHOG_PERSONAL_API_KEY to enable the analytics dashboard."
        />
      </template>
      <template v-else>
        <HealthScoreHero :health="health" />
        <PillarRow :pillars="health.pillars" />
      </template>
    </template>

    <EmptyState
      v-else
      title="Insufficient Data"
      description="Analytics require at least 7 days of PostHog event data. Check back soon."
    />
  </div>
</template>
```

- [ ] **Step 6: Commit**

```bash
git add frontend/src/views/AnalyticsView.vue frontend/src/components/analytics/
git commit -m "feat(analytics): add analytics view with health score hero, pillars, and filter bar"
```

---

### Task 10: Chart Components

**Files:**
- Create: `frontend/src/components/analytics/MomentumChart.vue`
- Create: `frontend/src/components/analytics/FreshnessChart.vue`
- Create: `frontend/src/components/analytics/CycleTimeChart.vue`
- Create: `frontend/src/components/analytics/FeatureUsageBar.vue`
- Modify: `frontend/src/views/AnalyticsView.vue` (add chart sections)

- [ ] **Step 1: Create MomentumChart**

Create `frontend/src/components/analytics/MomentumChart.vue`:

```vue
<script setup lang="ts">
import { computed, ref, onMounted } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { fetchMomentum } from '@/api/analytics'
import { Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Filler,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Filler, Title, Tooltip, Legend)

const props = defineProps<{
  org: string
  team?: string
  days: number
}>()

const visible = ref(false)
const el = ref<HTMLElement>()

onMounted(() => {
  if (!el.value) return
  const observer = new IntersectionObserver(([entry]) => {
    if (entry.isIntersecting) {
      visible.value = true
      observer.disconnect()
    }
  })
  observer.observe(el.value)
})

const { data, isLoading } = useQuery({
  queryKey: ['analytics-momentum', () => props.org, () => props.team, () => props.days],
  queryFn: () => fetchMomentum(props.org, props.team, props.days),
  enabled: visible,
})

const eventTypes = ['spec_saved', 'ticket_created', 'pr_analyzed', 'ac_realized', 'mcp_tool_called']
const colors = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6']

const chartData = computed(() => {
  if (!data.value) return { labels: [], datasets: [] }
  const weeks = [...new Set(data.value.weekly_activity.map(r => r.week))].sort()
  return {
    labels: weeks,
    datasets: eventTypes.map((type, i) => ({
      label: type.replace(/_/g, ' '),
      data: weeks.map(w => {
        const match = data.value!.weekly_activity.find(r => r.week === w && r.event_type === type)
        return match?.count ?? 0
      }),
      backgroundColor: colors[i] + '40',
      borderColor: colors[i],
      fill: true,
      tension: 0.3,
    })),
  }
})

const chartOptions = {
  responsive: true,
  plugins: { legend: { position: 'bottom' as const } },
  scales: { y: { beginAtZero: true, stacked: true }, x: { stacked: true } },
}
</script>

<template>
  <div ref="el" class="rounded-lg border border-border-light dark:border-slate-700 p-4 bg-surface-light dark:bg-surface">
    <h3 class="text-sm font-medium text-slate-700 dark:text-slate-300 mb-4">Weekly Activity</h3>
    <LoadingSpinner v-if="isLoading || !visible" />
    <Line v-else-if="chartData.labels.length" :data="chartData" :options="chartOptions" />
    <p v-else class="text-sm text-slate-400">No activity data yet.</p>
  </div>
</template>
```

- [ ] **Step 2: Create FreshnessChart**

Create `frontend/src/components/analytics/FreshnessChart.vue`:

```vue
<script setup lang="ts">
import { computed, ref, onMounted } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { fetchFreshness } from '@/api/analytics'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
} from 'chart.js'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip)

const props = defineProps<{
  org: string
  team?: string
  days: number
}>()

const visible = ref(false)
const el = ref<HTMLElement>()

onMounted(() => {
  if (!el.value) return
  const observer = new IntersectionObserver(([entry]) => {
    if (entry.isIntersecting) {
      visible.value = true
      observer.disconnect()
    }
  })
  observer.observe(el.value)
})

const { data, isLoading } = useQuery({
  queryKey: ['analytics-freshness', () => props.org, () => props.team, () => props.days],
  queryFn: () => fetchFreshness(props.org, props.team, props.days),
  enabled: visible,
})

const chartData = computed(() => {
  if (!data.value) return { labels: [], datasets: [] }
  const sorted = [...data.value.specs].sort((a, b) => a.freshness_score - b.freshness_score)
  return {
    labels: sorted.map(s => s.spec_path.split('/').pop() ?? s.spec_path),
    datasets: [{
      label: 'Freshness',
      data: sorted.map(s => s.freshness_score),
      backgroundColor: sorted.map(s =>
        s.freshness_score >= 70 ? '#22c55e' : s.freshness_score >= 40 ? '#f59e0b' : '#ef4444'
      ),
    }],
  }
})

const chartOptions = {
  indexAxis: 'y' as const,
  responsive: true,
  plugins: { legend: { display: false } },
  scales: { x: { min: 0, max: 100 } },
}
</script>

<template>
  <div ref="el" class="rounded-lg border border-border-light dark:border-slate-700 p-4 bg-surface-light dark:bg-surface">
    <h3 class="text-sm font-medium text-slate-700 dark:text-slate-300 mb-4">Spec Freshness</h3>
    <LoadingSpinner v-if="isLoading || !visible" />
    <Bar v-else-if="chartData.labels.length" :data="chartData" :options="chartOptions" />
    <p v-else class="text-sm text-slate-400">No freshness data yet.</p>
  </div>
</template>
```

- [ ] **Step 3: Create CycleTimeChart**

Create `frontend/src/components/analytics/CycleTimeChart.vue`:

```vue
<script setup lang="ts">
import { computed, ref, onMounted } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { fetchTimeToShip } from '@/api/analytics'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
} from 'chart.js'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip)

const props = defineProps<{
  org: string
  team?: string
  days: number
}>()

const visible = ref(false)
const el = ref<HTMLElement>()

onMounted(() => {
  if (!el.value) return
  const observer = new IntersectionObserver(([entry]) => {
    if (entry.isIntersecting) {
      visible.value = true
      observer.disconnect()
    }
  })
  observer.observe(el.value)
})

const { data, isLoading } = useQuery({
  queryKey: ['analytics-time-to-ship', () => props.org, () => props.team, () => props.days],
  queryFn: () => fetchTimeToShip(props.org, props.team, props.days),
  enabled: visible,
})

const stageColors = ['#6366f1', '#8b5cf6', '#a78bfa', '#c4b5fd']

const chartData = computed(() => {
  if (!data.value?.stages.length) return { labels: [], datasets: [] }
  return {
    labels: data.value.stages.map(s => s.name),
    datasets: [{
      label: 'Median days',
      data: data.value.stages.map(s => s.median_days),
      backgroundColor: stageColors,
    }],
  }
})

const chartOptions = {
  indexAxis: 'y' as const,
  responsive: true,
  plugins: { legend: { display: false } },
  scales: { x: { beginAtZero: true, title: { display: true, text: 'Days' } } },
}
</script>

<template>
  <div ref="el" class="rounded-lg border border-border-light dark:border-slate-700 p-4 bg-surface-light dark:bg-surface">
    <h3 class="text-sm font-medium text-slate-700 dark:text-slate-300 mb-4">Cycle Time</h3>
    <LoadingSpinner v-if="isLoading || !visible" />
    <Bar v-else-if="chartData.labels.length" :data="chartData" :options="chartOptions" />
    <p v-else class="text-sm text-slate-400">No cycle time data yet.</p>
  </div>
</template>
```

- [ ] **Step 4: Create FeatureUsageBar**

Create `frontend/src/components/analytics/FeatureUsageBar.vue`:

```vue
<script setup lang="ts">
import { computed, ref, onMounted } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { fetchFeatureUsage } from '@/api/analytics'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
} from 'chart.js'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip)

const props = defineProps<{ org: string }>()

const visible = ref(false)
const el = ref<HTMLElement>()

onMounted(() => {
  if (!el.value) return
  const observer = new IntersectionObserver(([entry]) => {
    if (entry.isIntersecting) {
      visible.value = true
      observer.disconnect()
    }
  })
  observer.observe(el.value)
})

const { data, isLoading } = useQuery({
  queryKey: ['analytics-feature-usage', () => props.org],
  queryFn: () => fetchFeatureUsage(props.org),
  enabled: visible,
})

const chartData = computed(() => {
  if (!data.value?.features.length) return { labels: [], datasets: [] }
  return {
    labels: data.value.features.map(f => f.name),
    datasets: [{
      label: 'Repos enabled',
      data: data.value.features.map(f => f.pct),
      backgroundColor: '#6366f1',
    }],
  }
})

const chartOptions = {
  indexAxis: 'y' as const,
  responsive: true,
  plugins: { legend: { display: false } },
  scales: { x: { min: 0, max: 100, title: { display: true, text: '% of repos' } } },
}
</script>

<template>
  <div ref="el" class="rounded-lg border border-border-light dark:border-slate-700 p-4 bg-surface-light dark:bg-surface">
    <h3 class="text-sm font-medium text-slate-700 dark:text-slate-300 mb-4">Feature Adoption</h3>
    <LoadingSpinner v-if="isLoading || !visible" />
    <Bar v-else-if="chartData.labels.length" :data="chartData" :options="chartOptions" />
    <p v-else class="text-sm text-slate-400">No feature usage data yet.</p>
  </div>
</template>
```

- [ ] **Step 5: Wire charts into AnalyticsView**

Update `frontend/src/views/AnalyticsView.vue` to import and render the chart components after PillarRow. Add imports and the admin check via `useAuthStore`:

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useQuery } from '@tanstack/vue-query'
import { useAuthStore } from '@/stores/auth'
import { fetchHealth } from '@/api/analytics'
import HealthScoreHero from '@/components/analytics/HealthScoreHero.vue'
import PillarRow from '@/components/analytics/PillarRow.vue'
import AnalyticsFilterBar from '@/components/analytics/AnalyticsFilterBar.vue'
import MomentumChart from '@/components/analytics/MomentumChart.vue'
import FreshnessChart from '@/components/analytics/FreshnessChart.vue'
import CycleTimeChart from '@/components/analytics/CycleTimeChart.vue'
import FeatureUsageBar from '@/components/analytics/FeatureUsageBar.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
import EmptyState from '@/components/common/EmptyState.vue'

const route = useRoute()
const auth = useAuthStore()
const org = computed(() => route.params.org as string)
const team = ref('')
const days = ref(30)

const isAdmin = computed(() => auth.permissions.includes('specs:admin'))

const { data: health, isLoading } = useQuery({
  queryKey: ['analytics-health', org, team, days],
  queryFn: () => fetchHealth(org.value, team.value || undefined, days.value),
})

const teams: string[] = []
</script>

<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <h1 class="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-6">Analytics</h1>

    <AnalyticsFilterBar v-model:team="team" v-model:days="days" :teams="teams" />

    <LoadingSpinner v-if="isLoading" />

    <template v-else-if="health && !health.error">
      <HealthScoreHero :health="health" />
      <PillarRow :pillars="health.pillars" />

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <MomentumChart :org="org" :team="team || undefined" :days="days" />
        <FreshnessChart :org="org" :team="team || undefined" :days="days" />
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CycleTimeChart :org="org" :team="team || undefined" :days="days" />
        <FeatureUsageBar v-if="isAdmin" :org="org" />
      </div>
    </template>

    <EmptyState
      v-else-if="health?.error === 'analytics_not_configured'"
      title="Analytics Not Configured"
      description="Set POSTHOG_PERSONAL_API_KEY to enable the analytics dashboard."
    />

    <EmptyState
      v-else
      title="Insufficient Data"
      description="Analytics require at least 7 days of PostHog event data. Check back soon."
    />
  </div>
</template>
```

- [ ] **Step 6: Verify frontend builds**

Run: `cd frontend && npm run build`
Expected: Build succeeds

- [ ] **Step 7: Commit**

```bash
git add frontend/src/components/analytics/ frontend/src/views/AnalyticsView.vue
git commit -m "feat(analytics): add chart components with lazy loading and complete analytics view"
```

---

### Task 11: Run Full Test Suite + Lint

- [ ] **Step 1: Run backend tests**

Run: `uv run pytest tests/ -v --timeout=30`
Expected: All PASS

- [ ] **Step 2: Run linter**

Run: `uv run ruff check`
Expected: No errors (or fix any that appear)

- [ ] **Step 3: Run frontend build**

Run: `cd frontend && npm run build`
Expected: Build succeeds

- [ ] **Step 4: Final commit if any fixes needed**

```bash
git add -A
git commit -m "fix: address lint and test issues from analytics dashboard implementation"
```
