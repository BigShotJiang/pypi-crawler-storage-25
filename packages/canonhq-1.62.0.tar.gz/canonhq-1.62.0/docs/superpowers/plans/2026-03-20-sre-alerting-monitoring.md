# SRE Alerting & Monitoring Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Shift Canon from reactive monitoring (manually checking PostHog) to proactive alerting with automated alerts, Slack notifications, SRE dashboard, enhanced instrumentation, error-to-issue triage, and weekly digests.

**Architecture:** Layered approach following the spec's phased rollout. Configuration and instrumentation form the foundation (Phase 1), Slack delivery and PostHog dashboards/alerts build on top (Phase 2-3), and auto-triage + bot SRE mode complete the stack (Phase 4-5). All new events flow through the existing `analytics.track()` wrapper. Slack delivery uses a simple incoming webhook module. Auto-triage uses the existing GitHub client with a new DB table for dedup.

**Tech Stack:** Python 3.12, FastAPI, PostHog Python SDK, httpx (Slack webhooks + PostHog API), asyncpg (error-issue mapping), Alembic (migration), Helm (K8s deployment config)

**Spec:** `docs/specs/sre-alerting-monitoring.md`

---

## File Map

### New Files
| File | Responsibility |
|------|---------------|
| `src/canon/alerts/__init__.py` | Package init — re-exports key functions |
| `src/canon/alerts/models.py` | `AlertSeverity` enum, `AlertMessage` dataclass |
| `src/canon/alerts/slack.py` | Slack incoming webhook delivery |
| `src/canon/alerts/triage.py` | Error fingerprint → GitHub issue pipeline |
| `src/canon/alerts/digest.py` | Weekly SRE digest data aggregation |
| `src/canon/alerts/cron_utils.py` | `@tracked_cron` decorator for cron instrumentation |
| `src/canon/alerts/posthog_setup.py` | PostHog alert/dashboard setup CLI script |
| `src/canon/db/error_store.py` | `ErrorStore` — error fingerprint ↔ issue mapping CRUD |
| `src/canon/db/query_hooks.py` | Slow query detection hook (`log_slow_query`) |
| `src/canon/db/migrations/versions/0003_error_issue_map.py` | Alembic migration for `error_issue_map` table |
| `src/canon/cron/weekly_digest.py` | CLI entry point for weekly digest cron job |
| `chart/canon/templates/cronjob-weekly-digest.yaml` | K8s CronJob for weekly digest |
| `tests/test_alerts_models.py` | Tests for alert models |
| `tests/test_alerts_slack.py` | Tests for Slack webhook delivery |
| `tests/test_sre_config.py` | Tests for SRE settings + CANON.yaml parsing |
| `tests/test_sre_instrumentation.py` | Tests for request/agent/rate-limit/health instrumentation |
| `tests/test_tracked_cron.py` | Tests for tracked cron decorator |
| `tests/test_error_store.py` | Tests for error store CRUD |
| `tests/test_alerts_triage.py` | Tests for error triage logic |
| `tests/test_weekly_digest.py` | Tests for weekly digest aggregation |

### Modified Files
| File | Changes |
|------|---------|
| `src/canon/settings.py` | Add 7 SRE env vars |
| `src/canon/config/parse.py` | Add `SreConfig` model + `sre` CANON.yaml section parsing |
| `src/canon/web/middleware.py` | Add `analytics.track("request_completed")` + `analytics.track("rate_limit_hit")` |
| `src/canon/agent/client.py` | Add `analytics.track("agent_call_completed")` after Claude API calls |
| `src/canon/main.py` | Wire Slack/ErrorStore in lifespan, add `health_check_failed` tracking |
| `src/canon/db/__init__.py` | Export `ErrorStore` |
| `chart/canon/values.yaml` | Add `secrets.slack` + `config.sre*` + `weeklyDigestCronJob` sections |
| `chart/canon/templates/configmap.yaml` | Add SRE config env vars |
| `chart/canon/templates/secret.yaml` | Add Slack webhook secret block |
| `chart/canon/templates/_helpers.tpl` | Add `canon.slackSecretName` helper |
| `chart/canon/templates/deployment.yaml` | Add optional Slack secret envFrom |

---

## Task 1: SRE Settings (Environment Variables)

**Files:**
- Modify: `src/canon/settings.py:130-136` (after PostHog settings)
- Create: `tests/test_sre_config.py`

- [ ] **Step 1: Write failing test for SRE settings defaults**

```python
# tests/test_sre_config.py
"""Tests for SRE alerting configuration."""

from __future__ import annotations

from canon.settings import Settings


class TestSreSettings:
    def test_default_sre_settings(self):
        s = Settings(gh_app_id="x", gh_private_key="x", gh_webhook_secret="x")
        assert s.slack_alerts_webhook_url == ""
        assert s.sre_alerts_enabled is True
        assert s.sre_error_spike_threshold == 10
        assert s.sre_error_spike_window == 300
        assert s.sre_slow_query_threshold_ms == 500
        assert s.sre_auto_triage_enabled is True
        assert s.sre_weekly_digest_enabled is True

    def test_sre_alerts_disabled_when_no_slack_webhook(self):
        s = Settings(gh_app_id="x", gh_private_key="x", gh_webhook_secret="x")
        assert s.slack_alerts_enabled is False

    def test_sre_alerts_enabled_with_slack_webhook(self):
        s = Settings(
            gh_app_id="x", gh_private_key="x", gh_webhook_secret="x",
            slack_alerts_webhook_url="https://hooks.slack.com/services/T/B/x",
        )
        assert s.slack_alerts_enabled is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_sre_config.py -v`
Expected: FAIL — `Settings` has no attribute `slack_alerts_webhook_url`

- [ ] **Step 3: Add SRE settings to Settings class**

In `src/canon/settings.py`, after the PostHog settings block (line 136), add:

```python
    # SRE Alerting
    slack_alerts_webhook_url: str = ""
    sre_alerts_enabled: bool = True
    sre_error_spike_threshold: int = 10
    sre_error_spike_window: int = 300
    sre_slow_query_threshold_ms: int = 500
    sre_auto_triage_enabled: bool = True
    sre_weekly_digest_enabled: bool = True

    @property
    def slack_alerts_enabled(self) -> bool:
        return bool(self.slack_alerts_webhook_url)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_sre_config.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/settings.py tests/test_sre_config.py
git commit -m "feat(sre): add SRE alerting environment variables to Settings"
```

---

## Task 2: CANON.yaml SRE Section

**Files:**
- Modify: `src/canon/config/parse.py:27-38` (KNOWN_TOP_KEYS), `94-102` (CanonConfig)
- Modify: `tests/test_sre_config.py`

- [ ] **Step 1: Write failing test for SRE config parsing**

Append to `tests/test_sre_config.py`:

```python
from canon.config.parse import parse_canon_yaml


class TestSreCanonYaml:
    def test_default_sre_config(self):
        result = parse_canon_yaml("team: canon")
        assert result.config.sre is not None
        assert result.config.sre.auto_triage is True
        assert result.config.sre.weekly_digest is True
        assert result.config.sre.error_spike_threshold == 10
        assert result.config.sre.alerts_channel == "#canon-alerts"

    def test_custom_sre_config(self):
        yaml_str = """
sre:
  alerts_channel: "#ops-alerts"
  auto_triage: false
  weekly_digest: true
  error_spike_threshold: 20
"""
        result = parse_canon_yaml(yaml_str)
        assert result.config.sre.alerts_channel == "#ops-alerts"
        assert result.config.sre.auto_triage is False
        assert result.config.sre.error_spike_threshold == 20

    def test_sre_unknown_key_warns(self):
        yaml_str = """
sre:
  unknown_key: true
"""
        result = parse_canon_yaml(yaml_str)
        assert any("Unknown sre key" in d.message for d in result.diagnostics)

    def test_sre_invalid_type_errors(self):
        yaml_str = """
sre:
  auto_triage: "yes"
"""
        result = parse_canon_yaml(yaml_str)
        assert any("auto_triage" in d.message for d in result.diagnostics)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_sre_config.py::TestSreCanonYaml -v`
Expected: FAIL — `CanonConfig` has no attribute `sre`

- [ ] **Step 3: Add SreConfig model and parsing**

In `src/canon/config/parse.py`:

1. Add to `KNOWN_TOP_KEYS` set (line 27): `"sre"`
2. Add known keys constant after `KNOWN_IDE_AI_EXPOSURE_KEYS` (line 44):
```python
KNOWN_SRE_KEYS = {"alerts_channel", "auto_triage", "weekly_digest", "error_spike_threshold"}
```

3. Add `SreConfig` model after `AiExposureConfig` (before `IdeConfig`, around line 73):
```python
class SreConfig(BaseModel):
    alerts_channel: str = "#canon-alerts"
    auto_triage: bool = True
    weekly_digest: bool = True
    error_spike_threshold: int = 10
```

4. Add to `CanonConfig` (around line 101):
```python
    sre: SreConfig = SreConfig()
```

5. Add SRE section validation in `parse_canon_yaml()` — after the existing specs/agents/ide validation blocks, add a similar block for `sre`:
```python
    # Validate sre section
    if "sre" in obj:
        if not isinstance(obj["sre"], dict):
            diagnostics.append(Diagnostic(severity="error", message='"sre" must be a mapping'))
            del obj["sre"]
        else:
            sre = obj["sre"]
            assert isinstance(sre, dict)
            for key in list(sre.keys()):
                if key not in KNOWN_SRE_KEYS:
                    diagnostics.append(
                        Diagnostic(severity="warning", message=f'Unknown sre key: "{key}"')
                    )
            for key in ("auto_triage", "weekly_digest"):
                if key in sre and not isinstance(sre[key], bool):
                    diagnostics.append(
                        Diagnostic(severity="error", message=f'sre.{key} must be a boolean')
                    )
                    del sre[key]
            if "error_spike_threshold" in sre and not isinstance(sre["error_spike_threshold"], int):
                diagnostics.append(
                    Diagnostic(severity="error", message="sre.error_spike_threshold must be an integer")
                )
                del sre["error_spike_threshold"]
            if "alerts_channel" in sre and not isinstance(sre["alerts_channel"], str):
                diagnostics.append(
                    Diagnostic(severity="error", message="sre.alerts_channel must be a string")
                )
                del sre["alerts_channel"]
```

6. Add SRE handling in `_merge_with_defaults()` (around line 656, before the `return CanonConfig(...)` statement):
```python
    sre_data = partial.get("sre")
    sre = SreConfig()
    if isinstance(sre_data, dict):
        sre = SreConfig(
            alerts_channel=sre_data["alerts_channel"]
            if isinstance(sre_data.get("alerts_channel"), str)
            else "#canon-alerts",
            auto_triage=sre_data["auto_triage"]
            if isinstance(sre_data.get("auto_triage"), bool)
            else True,
            weekly_digest=sre_data["weekly_digest"]
            if isinstance(sre_data.get("weekly_digest"), bool)
            else True,
            error_spike_threshold=sre_data["error_spike_threshold"]
            if isinstance(sre_data.get("error_spike_threshold"), int)
            and not isinstance(sre_data.get("error_spike_threshold"), bool)
            else 10,
        )
```

7. Add `sre=sre` to the `return CanonConfig(...)` call (line ~671):
```python
    return CanonConfig(
        ...existing args...,
        sre=sre,
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_sre_config.py -v`
Expected: PASS

- [ ] **Step 5: Run full config test suite**

Run: `uv run pytest tests/test_config_parse.py -v`
Expected: All existing tests still pass

- [ ] **Step 6: Commit**

```bash
git add src/canon/config/parse.py tests/test_sre_config.py
git commit -m "feat(sre): add SRE section to CANON.yaml config parser"
```

---

## Task 3: Alert Models

**Files:**
- Create: `src/canon/alerts/__init__.py`
- Create: `src/canon/alerts/models.py`
- Create: `tests/test_alerts_models.py`

- [ ] **Step 1: Write failing test for alert models**

```python
# tests/test_alerts_models.py
"""Tests for SRE alert data models."""

from __future__ import annotations

from canon.alerts.models import AlertMessage, AlertSeverity


class TestAlertSeverity:
    def test_severity_ordering(self):
        assert AlertSeverity.CRITICAL.value > AlertSeverity.HIGH.value
        assert AlertSeverity.HIGH.value > AlertSeverity.MEDIUM.value
        assert AlertSeverity.MEDIUM.value > AlertSeverity.LOW.value

    def test_severity_emoji(self):
        assert AlertSeverity.CRITICAL.emoji == "\U0001f534"  # red circle
        assert AlertSeverity.HIGH.emoji == "\U0001f7e0"  # orange circle
        assert AlertSeverity.MEDIUM.emoji == "\U0001f7e1"  # yellow circle
        assert AlertSeverity.LOW.emoji == "\U0001f535"  # blue circle


class TestAlertMessage:
    def test_create_alert_message(self):
        msg = AlertMessage(
            severity=AlertSeverity.HIGH,
            title="Exception spike",
            summary="15 exceptions in 5 minutes",
            endpoint="/webhook",
            posthog_url="https://us.posthog.com/project/1/error/abc",
        )
        assert msg.severity == AlertSeverity.HIGH
        assert msg.title == "Exception spike"
        assert msg.endpoint == "/webhook"

    def test_alert_message_optional_fields(self):
        msg = AlertMessage(
            severity=AlertSeverity.MEDIUM,
            title="New error",
            summary="KeyError in handler",
        )
        assert msg.endpoint is None
        assert msg.posthog_url is None
        assert msg.spec_link is None

    def test_to_slack_block(self):
        msg = AlertMessage(
            severity=AlertSeverity.HIGH,
            title="Exception spike",
            summary="15 exceptions in 5 minutes",
            endpoint="/webhook",
            posthog_url="https://us.posthog.com/project/1/error/abc",
        )
        blocks = msg.to_slack_blocks()
        assert isinstance(blocks, list)
        assert len(blocks) >= 1
        # First block should contain the title with severity emoji
        header_text = blocks[0]["text"]["text"]
        assert "Exception spike" in header_text
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_alerts_models.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'canon.alerts'`

- [ ] **Step 3: Create the alerts package and models**

```python
# src/canon/alerts/__init__.py
"""SRE alerting and notification modules."""
```

```python
# src/canon/alerts/models.py
"""Data models for SRE alert messages."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum


class AlertSeverity(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

    @property
    def emoji(self) -> str:
        return {
            AlertSeverity.LOW: "\U0001f535",
            AlertSeverity.MEDIUM: "\U0001f7e1",
            AlertSeverity.HIGH: "\U0001f7e0",
            AlertSeverity.CRITICAL: "\U0001f534",
        }[self]

    @property
    def color(self) -> str:
        """Slack attachment color."""
        return {
            AlertSeverity.LOW: "#3498db",
            AlertSeverity.MEDIUM: "#f1c40f",
            AlertSeverity.HIGH: "#e67e22",
            AlertSeverity.CRITICAL: "#e74c3c",
        }[self]


@dataclass
class AlertMessage:
    severity: AlertSeverity
    title: str
    summary: str
    endpoint: str | None = None
    time_window: str | None = None
    posthog_url: str | None = None
    spec_link: str | None = None

    def to_slack_blocks(self) -> list[dict]:
        """Format as Slack Block Kit blocks."""
        blocks: list[dict] = []

        # Header with severity
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"{self.severity.emoji} *{self.title}*",
            },
        })

        # Summary
        detail_parts = [self.summary]
        if self.endpoint:
            detail_parts.append(f"*Endpoint:* `{self.endpoint}`")
        if self.time_window:
            detail_parts.append(f"*Window:* {self.time_window}")

        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "\n".join(detail_parts),
            },
        })

        # Links
        links: list[str] = []
        if self.posthog_url:
            links.append(f"<{self.posthog_url}|View in PostHog>")
        if self.spec_link:
            links.append(f"<{self.spec_link}|Related Spec>")
        if links:
            blocks.append({
                "type": "context",
                "elements": [{"type": "mrkdwn", "text": " | ".join(links)}],
            })

        return blocks
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_alerts_models.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/alerts/__init__.py src/canon/alerts/models.py tests/test_alerts_models.py
git commit -m "feat(sre): add alert severity and message models"
```

---

## Task 4: Slack Webhook Module

**Files:**
- Create: `src/canon/alerts/slack.py`
- Create: `tests/test_alerts_slack.py`

- [ ] **Step 1: Write failing test for Slack webhook**

```python
# tests/test_alerts_slack.py
"""Tests for Slack webhook delivery."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from canon.alerts.models import AlertMessage, AlertSeverity
from canon.alerts.slack import SlackAlerter


class TestSlackAlerter:
    def test_init_disabled_without_url(self):
        alerter = SlackAlerter(webhook_url="")
        assert alerter.enabled is False

    def test_init_enabled_with_url(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")
        assert alerter.enabled is True

    @pytest.mark.asyncio
    async def test_send_does_nothing_when_disabled(self):
        alerter = SlackAlerter(webhook_url="")
        msg = AlertMessage(severity=AlertSeverity.HIGH, title="Test", summary="Test")
        # Should not raise
        await alerter.send(msg)

    @pytest.mark.asyncio
    async def test_send_posts_to_webhook(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")
        msg = AlertMessage(severity=AlertSeverity.HIGH, title="Test", summary="Test alert")

        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = AsyncMock()

        # Patch the internal httpx client directly
        alerter._http = AsyncMock()
        alerter._http.post.return_value = mock_response

        await alerter.send(msg)

        alerter._http.post.assert_called_once()
        call_args = alerter._http.post.call_args
        assert call_args[0][0] == "https://hooks.slack.com/services/T/B/x"
        payload = call_args[1]["json"]
        assert "blocks" in payload

    @pytest.mark.asyncio
    async def test_send_logs_on_failure(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")
        msg = AlertMessage(severity=AlertSeverity.HIGH, title="Test", summary="Test")

        alerter._http = AsyncMock()
        alerter._http.post.side_effect = Exception("Connection refused")

        # Should not raise — logs the error
        await alerter.send(msg)

    @pytest.mark.asyncio
    async def test_send_text_posts_simple_message(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")

        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = AsyncMock()

        alerter._http = AsyncMock()
        alerter._http.post.return_value = mock_response

        await alerter.send_text("Hello from Canon SRE")

        alerter._http.post.assert_called_once()
        payload = alerter._http.post.call_args[1]["json"]
        assert payload["text"] == "Hello from Canon SRE"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_alerts_slack.py -v`
Expected: FAIL — `ModuleNotFoundError` or `ImportError`

- [ ] **Step 3: Implement Slack alerter**

```python
# src/canon/alerts/slack.py
"""Slack incoming webhook delivery for SRE alerts."""

from __future__ import annotations

import logging

import httpx

from .models import AlertMessage

logger = logging.getLogger(__name__)


class SlackAlerter:
    """Posts alert messages to a Slack incoming webhook.

    Reuses a single httpx.AsyncClient for the lifetime of the alerter,
    following the same pattern as GitHubClient.
    """

    def __init__(self, webhook_url: str) -> None:
        self._webhook_url = webhook_url
        self._http: httpx.AsyncClient | None = (
            httpx.AsyncClient(timeout=10.0) if webhook_url else None
        )

    @property
    def enabled(self) -> bool:
        return bool(self._webhook_url)

    async def send(self, alert: AlertMessage) -> None:
        """Post a structured alert to Slack. No-op when disabled."""
        if not self.enabled:
            return
        payload = {"blocks": alert.to_slack_blocks()}
        await self._post(payload)

    async def send_text(self, text: str) -> None:
        """Post a plain text message to Slack. No-op when disabled."""
        if not self.enabled:
            return
        await self._post({"text": text})

    async def _post(self, payload: dict) -> None:
        if self._http is None:
            return
        try:
            resp = await self._http.post(self._webhook_url, json=payload)
            resp.raise_for_status()
        except Exception:
            logger.error("Failed to deliver Slack alert", exc_info=True)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._http is not None:
            await self._http.aclose()
            self._http = None
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_alerts_slack.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/alerts/slack.py tests/test_alerts_slack.py
git commit -m "feat(sre): add Slack incoming webhook delivery module"
```

---

## Task 5: Request Completed Instrumentation

**Files:**
- Modify: `src/canon/web/middleware.py:35-59` (RequestLoggingMiddleware)
- Create: `tests/test_sre_instrumentation.py`

- [ ] **Step 1: Write failing test for request_completed tracking**

```python
# tests/test_sre_instrumentation.py
"""Tests for SRE instrumentation (PostHog event tracking)."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from canon.web.middleware import RequestLoggingMiddleware


class TestRequestCompletedTracking:
    @pytest.mark.asyncio
    async def test_tracks_request_completed_event(self):
        """RequestLoggingMiddleware should call analytics.track('request_completed')."""
        from starlette.applications import Starlette
        from starlette.responses import PlainTextResponse
        from starlette.routing import Route
        from starlette.testclient import TestClient

        def homepage(request):
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/api/test", homepage)])
        app = RequestLoggingMiddleware(app)

        with patch("canon.web.middleware.analytics") as mock_analytics:
            client = TestClient(app)
            resp = client.get("/api/test")
            assert resp.status_code == 200

            mock_analytics.track.assert_called_once()
            call_args = mock_analytics.track.call_args
            assert call_args[0][0] == "request_completed"
            props = call_args[1]["properties"]
            assert props["method"] == "GET"
            assert props["path"] == "/api/test"
            assert props["status"] == 200
            assert "duration_ms" in props

    @pytest.mark.asyncio
    async def test_skips_health_check_tracking(self):
        """Should not track health check endpoints."""
        from starlette.applications import Starlette
        from starlette.responses import PlainTextResponse
        from starlette.routing import Route
        from starlette.testclient import TestClient

        def healthz(request):
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/healthz", healthz)])
        app = RequestLoggingMiddleware(app)

        with patch("canon.web.middleware.analytics") as mock_analytics:
            client = TestClient(app)
            client.get("/healthz")
            mock_analytics.track.assert_not_called()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_sre_instrumentation.py::TestRequestCompletedTracking -v`
Expected: FAIL — `analytics` not imported in middleware or `track` not called

- [ ] **Step 3: Add request_completed tracking to middleware**

In `src/canon/web/middleware.py`:

1. Add import at top (after existing imports):
```python
from canon import analytics
```

2. In `RequestLoggingMiddleware.dispatch()`, after the existing `logger.info(...)` call (line 49-58), add:
```python
        analytics.track(
            "request_completed",
            properties={
                "method": request.method,
                "path": path,
                "status": response.status_code,
                "duration_ms": duration_ms,
                "user_agent": request.headers.get("user-agent", ""),
            },
        )
```

The existing `if path in ("/healthz", "/readyz") or path.startswith("/static/"):` guard already handles skipping health checks.

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_sre_instrumentation.py::TestRequestCompletedTracking -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/web/middleware.py tests/test_sre_instrumentation.py
git commit -m "feat(sre): add request_completed PostHog event tracking"
```

---

## Task 6: Rate Limit Hit Instrumentation

**Files:**
- Modify: `src/canon/web/middleware.py:100-127` (RateLimitMiddleware.dispatch)
- Modify: `tests/test_sre_instrumentation.py`

- [ ] **Step 1: Write failing test for rate_limit_hit tracking**

Append to `tests/test_sre_instrumentation.py`:

```python
from canon.web.middleware import RateLimitMiddleware


class TestRateLimitHitTracking:
    @pytest.mark.asyncio
    async def test_tracks_rate_limit_hit(self):
        """RateLimitMiddleware should track when a request is rate-limited."""
        from starlette.applications import Starlette
        from starlette.responses import PlainTextResponse
        from starlette.routing import Route
        from starlette.testclient import TestClient

        def search(request):
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/api/search", search)])
        app = RateLimitMiddleware(app, path_prefix="/api/search", max_requests=1, window_seconds=60)

        with patch("canon.web.middleware.analytics") as mock_analytics:
            client = TestClient(app)
            # First request succeeds
            client.get("/api/search")
            # Second request is rate-limited
            resp = client.get("/api/search")
            assert resp.status_code == 429

            # Find the rate_limit_hit call
            rate_limit_calls = [
                c for c in mock_analytics.track.call_args_list
                if c[0][0] == "rate_limit_hit"
            ]
            assert len(rate_limit_calls) == 1
            props = rate_limit_calls[0][1]["properties"]
            assert props["path"] == "/api/search"
            assert props["limit"] == 1
            assert props["window"] == 60
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_sre_instrumentation.py::TestRateLimitHitTracking -v`
Expected: FAIL — no `rate_limit_hit` track call

- [ ] **Step 3: Add rate_limit_hit tracking**

In `src/canon/web/middleware.py`, inside `RateLimitMiddleware.dispatch()`, before the `return Response(... status_code=429 ...)` (around line 116), add:

```python
            analytics.track(
                "rate_limit_hit",
                properties={
                    "path": request.url.path,
                    "client_key": key,
                    "limit": self.max_requests,
                    "window": self.window_seconds,
                },
            )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_sre_instrumentation.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/web/middleware.py tests/test_sre_instrumentation.py
git commit -m "feat(sre): add rate_limit_hit PostHog event tracking"
```

---

## Task 7: Tracked Cron Decorator

**Files:**
- Create: `src/canon/alerts/cron_utils.py`
- Create: `tests/test_tracked_cron.py`

- [ ] **Step 1: Write failing test for tracked_cron decorator**

```python
# tests/test_tracked_cron.py
"""Tests for the tracked_cron decorator."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from canon.alerts.cron_utils import tracked_cron


class TestTrackedCron:
    @pytest.mark.asyncio
    async def test_tracks_successful_cron(self):
        @tracked_cron("test_job")
        async def my_job():
            return {"items": 5}

        with patch("canon.alerts.cron_utils.analytics") as mock_analytics:
            result = await my_job()
            assert result == {"items": 5}

            mock_analytics.track.assert_called_once()
            call_args = mock_analytics.track.call_args
            assert call_args[0][0] == "cron_job_executed"
            props = call_args[1]["properties"]
            assert props["job_name"] == "test_job"
            assert props["success"] is True
            assert "duration_ms" in props
            assert props["error_message"] == ""

    @pytest.mark.asyncio
    async def test_tracks_failed_cron(self):
        @tracked_cron("failing_job")
        async def my_job():
            raise ValueError("something broke")

        with patch("canon.alerts.cron_utils.analytics") as mock_analytics:
            with pytest.raises(ValueError, match="something broke"):
                await my_job()

            mock_analytics.track.assert_called_once()
            props = mock_analytics.track.call_args[1]["properties"]
            assert props["job_name"] == "failing_job"
            assert props["success"] is False
            assert "something broke" in props["error_message"]

    @pytest.mark.asyncio
    async def test_tracks_sync_cron(self):
        @tracked_cron("sync_job")
        def my_sync_job():
            return "done"

        with patch("canon.alerts.cron_utils.analytics") as mock_analytics:
            result = await my_sync_job()
            assert result == "done"
            mock_analytics.track.assert_called_once()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_tracked_cron.py -v`
Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement tracked_cron decorator**

```python
# src/canon/alerts/cron_utils.py
"""Utilities for cron job instrumentation."""

from __future__ import annotations

import asyncio
import functools
import time
from typing import Any, Callable

from canon import analytics


def tracked_cron(job_name: str) -> Callable:
    """Decorator that tracks cron job execution via PostHog.

    Wraps both sync and async functions. Tracks duration, success/failure,
    and error messages as a ``cron_job_executed`` event.
    """

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.monotonic()
            success = True
            error_message = ""
            try:
                if asyncio.iscoroutinefunction(fn):
                    return await fn(*args, **kwargs)
                else:
                    return fn(*args, **kwargs)
            except Exception as exc:
                success = False
                error_message = str(exc)
                raise
            finally:
                duration_ms = round((time.monotonic() - start) * 1000, 1)
                analytics.track(
                    "cron_job_executed",
                    properties={
                        "job_name": job_name,
                        "success": success,
                        "duration_ms": duration_ms,
                        "error_message": error_message,
                    },
                )

        return wrapper

    return decorator
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_tracked_cron.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/alerts/cron_utils.py tests/test_tracked_cron.py
git commit -m "feat(sre): add @tracked_cron decorator for cron job instrumentation"
```

---

## Task 8: Agent Call Instrumentation

**Files:**
- Modify: `src/canon/agent/client.py:59-82` (ClaudeClient.complete)
- Modify: `tests/test_sre_instrumentation.py`

- [ ] **Step 1: Write failing test for agent_call_completed tracking**

Append to `tests/test_sre_instrumentation.py`:

```python
from unittest.mock import MagicMock

from canon.agent.client import AgentConfig, ClaudeClient


class TestAgentCallTracking:
    def test_tracks_successful_agent_call(self):
        client = ClaudeClient(api_key="test-key")

        # Mock the anthropic client
        mock_response = MagicMock()
        mock_response.content = [MagicMock(type="text", text="response")]
        mock_response.usage.input_tokens = 100
        mock_response.usage.output_tokens = 50
        client._client = MagicMock()
        client._client.messages.create.return_value = mock_response

        with patch("canon.agent.client.analytics") as mock_analytics:
            result = client.complete("system", "user", AgentConfig())

            mock_analytics.track.assert_called_once()
            call_args = mock_analytics.track.call_args
            assert call_args[0][0] == "agent_call_completed"
            props = call_args[1]["properties"]
            assert props["model"] == "claude-sonnet-4-5-20250929"
            assert props["input_tokens"] == 100
            assert props["output_tokens"] == 50
            assert props["success"] is True
            assert "duration_ms" in props

    def test_tracks_failed_agent_call(self):
        import anthropic as anthropic_mod

        client = ClaudeClient(api_key="test-key")
        client._client = MagicMock()
        client._client.messages.create.side_effect = anthropic_mod.APIError(
            message="Rate limited", request=MagicMock(), body=None
        )

        with patch("canon.agent.client.analytics") as mock_analytics:
            with pytest.raises(Exception):
                client.complete("system", "user", AgentConfig())

            mock_analytics.track.assert_called_once()
            props = mock_analytics.track.call_args[1]["properties"]
            assert props["success"] is False
            assert props["error_message"] != ""
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_sre_instrumentation.py::TestAgentCallTracking -v`
Expected: FAIL — `analytics.track` not called in `complete()`

- [ ] **Step 3: Add agent_call_completed tracking**

In `src/canon/agent/client.py`:

1. Add import at top:
```python
import time
from canon import analytics
```

2. Replace the `complete()` method body (lines 59-82) with:
```python
    def complete(
        self, system_prompt: str, user_message: str, config: AgentConfig
    ) -> CompletionResult:
        if not self._client:
            raise AgentUnavailableError()

        start = time.monotonic()
        success = True
        error_message = ""
        input_tokens = 0
        output_tokens = 0

        try:
            response = self._client.messages.create(
                model=config.model,
                max_tokens=config.max_output_tokens,
                temperature=config.temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_message}],
            )

            text = "".join(block.text for block in response.content if block.type == "text")
            input_tokens = response.usage.input_tokens
            output_tokens = response.usage.output_tokens

            return CompletionResult(
                text=text,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )
        except anthropic.APIError as e:
            success = False
            error_message = str(e)
            raise AgentAPIError(str(e), getattr(e, "status_code", None)) from e
        finally:
            duration_ms = round((time.monotonic() - start) * 1000, 1)
            analytics.track(
                "agent_call_completed",
                properties={
                    "model": config.model,
                    "duration_ms": duration_ms,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "success": success,
                    "error_message": error_message,
                },
            )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_sre_instrumentation.py -v`
Expected: PASS

- [ ] **Step 5: Run existing agent tests**

Run: `uv run pytest tests/ -k "agent" -v`
Expected: All existing agent tests still pass

- [ ] **Step 6: Commit**

```bash
git add src/canon/agent/client.py tests/test_sre_instrumentation.py
git commit -m "feat(sre): add agent_call_completed PostHog event tracking"
```

---

## Task 9: Health Check Failed Instrumentation

**Files:**
- Modify: `src/canon/main.py` (readyz endpoint)

- [ ] **Step 1: Add health_check_failed tracking to readyz**

In `src/canon/main.py`, in the `readyz()` function, inside the `except Exception:` block (where the DB check fails), add before the `return Response(... status_code=503 ...):

```python
            analytics.track(
                "health_check_failed",
                properties={"check_type": "readiness", "error_message": str(exc)},
            )
```

Note: Change `except Exception:` to `except Exception as exc:` to capture the exception.

- [ ] **Step 2: Write test for health_check_failed tracking**

Append to `tests/test_sre_instrumentation.py`:

```python
class TestHealthCheckFailedTracking:
    @pytest.mark.asyncio
    async def test_tracks_health_check_failure(self):
        """readyz should track health_check_failed when DB is unhealthy."""
        from unittest.mock import MagicMock
        from canon.main import app

        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(side_effect=Exception("connection refused"))

        mock_pool = MagicMock()
        mock_pool.acquire.return_value.__aenter__ = AsyncMock(return_value=mock_conn)
        mock_pool.acquire.return_value.__aexit__ = AsyncMock(return_value=False)

        app.state.db_pool = mock_pool
        try:
            with patch("canon.main.analytics") as mock_analytics:
                from httpx import AsyncClient, ASGITransport
                async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
                    resp = await client.get("/readyz")
                    assert resp.status_code == 503

                rate_calls = [
                    c for c in mock_analytics.track.call_args_list
                    if c[0][0] == "health_check_failed"
                ]
                assert len(rate_calls) == 1
                props = rate_calls[0][1]["properties"]
                assert props["check_type"] == "readiness"
        finally:
            app.state.db_pool = None
```

- [ ] **Step 3: Run health check tests**

Run: `uv run pytest tests/test_sre_instrumentation.py::TestHealthCheckFailedTracking tests/test_health.py -v`
Expected: PASS

- [ ] **Step 4: Commit**

```bash
git add src/canon/main.py tests/test_sre_instrumentation.py
git commit -m "feat(sre): add health_check_failed PostHog event tracking"
```

---

## Task 10: Helm Chart — Slack Webhook Secret

**Files:**
- Modify: `chart/canon/values.yaml:39-123` (secrets section)
- Modify: `chart/canon/templates/_helpers.tpl` (add helper)
- Modify: `chart/canon/templates/secret.yaml` (add Slack secret)
- Modify: `chart/canon/templates/deployment.yaml` (add envFrom)
- Modify: `chart/canon/templates/configmap.yaml` (add SRE config vars)
- Modify: `chart/canon/values.yaml:134-144` (config section)

- [ ] **Step 1: Add Slack secret values**

In `chart/canon/values.yaml`, after the `posthog` secrets block (line 123), add:

```yaml
  ## @section Slack secrets (optional — SRE alerting)
  ## @param secrets.slack.webhookUrl Slack incoming webhook URL for alerts
  ## @param secrets.slack.existingSecret Use existing secret
  slack:
    webhookUrl: ""
    existingSecret: ""
```

- [ ] **Step 2: Add SRE config values**

In `chart/canon/values.yaml`, after `environment: "development"` (line 144), add:

```yaml
  ## SRE alerting config
  sreAlertsEnabled: "true"
  sreErrorSpikeThreshold: "10"
  sreErrorSpikeWindow: "300"
  sreSlowQueryThresholdMs: "500"
  sreAutoTriageEnabled: "true"
  sreWeeklyDigestEnabled: "true"
```

- [ ] **Step 3: Add weekly digest CronJob values**

In `chart/canon/values.yaml`, after the `coverageSnapshotCronJob` block (line 220), add:

```yaml
## @section Weekly SRE digest CronJob parameters
## @param weeklyDigestCronJob.enabled Enable weekly SRE digest CronJob
## @param weeklyDigestCronJob.schedule Cron schedule expression (default: Monday 9am UTC)
## @param weeklyDigestCronJob.concurrencyPolicy CronJob concurrency policy
weeklyDigestCronJob:
  enabled: false
  schedule: "0 9 * * 1"
  concurrencyPolicy: Forbid
```

- [ ] **Step 4: Add Slack secret name helper**

In `chart/canon/templates/_helpers.tpl`, after the `canon.posthogSecretName` block (line 171), add:

```
{{/*
Secret name for Slack credentials
*/}}
{{- define "canon.slackSecretName" -}}
{{- if .Values.secrets.slack.existingSecret -}}
{{ .Values.secrets.slack.existingSecret }}
{{- else -}}
{{ include "canon.fullname" . }}-slack
{{- end -}}
{{- end }}
```

- [ ] **Step 5: Add Slack secret template**

In `chart/canon/templates/secret.yaml`, after the PostHog secret block (line 110), add:

```yaml
---
{{- if and .Values.secrets.slack.webhookUrl (not .Values.secrets.slack.existingSecret) }}
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "canon.slackSecretName" . }}
  labels:
    {{- include "canon.labels" . | nindent 4 }}
type: Opaque
stringData:
  SLACK_ALERTS_WEBHOOK_URL: {{ .Values.secrets.slack.webhookUrl | quote }}
{{- end }}
```

- [ ] **Step 6: Add Slack secret to deployment envFrom**

In `chart/canon/templates/deployment.yaml`, after the PostHog envFrom block (lines 73-76), add:

```yaml
          {{- if or .Values.secrets.slack.webhookUrl .Values.secrets.slack.existingSecret }}
            - secretRef:
                name: {{ include "canon.slackSecretName" . }}
          {{- end }}
```

- [ ] **Step 7: Add SRE config to configmap**

In `chart/canon/templates/configmap.yaml`, after the `ENVIRONMENT` block (lines 19-21), add:

```yaml
  SRE_ALERTS_ENABLED: {{ .Values.config.sreAlertsEnabled | quote }}
  SRE_ERROR_SPIKE_THRESHOLD: {{ .Values.config.sreErrorSpikeThreshold | quote }}
  SRE_ERROR_SPIKE_WINDOW: {{ .Values.config.sreErrorSpikeWindow | quote }}
  SRE_SLOW_QUERY_THRESHOLD_MS: {{ .Values.config.sreSlowQueryThresholdMs | quote }}
  SRE_AUTO_TRIAGE_ENABLED: {{ .Values.config.sreAutoTriageEnabled | quote }}
  SRE_WEEKLY_DIGEST_ENABLED: {{ .Values.config.sreWeeklyDigestEnabled | quote }}
```

- [ ] **Step 8: Commit**

```bash
git add chart/
git commit -m "feat(sre): add Slack webhook secret and SRE config to Helm chart"
```

---

## Task 11: Wire SRE Services Into App Lifespan

**Depends on:** Task 1, Task 4, Task 13

**Files:**
- Modify: `src/canon/main.py` (lifespan function — startup + shutdown)
- Modify: `src/canon/db/__init__.py` (export ErrorStore)

- [ ] **Step 1: Export ErrorStore from db package**

In `src/canon/db/__init__.py`, add:
```python
from .error_store import ErrorStore
```
And add `"ErrorStore"` to `__all__`.

- [ ] **Step 2: Initialize SlackAlerter and ErrorStore in lifespan startup**

In `src/canon/main.py`, in the `lifespan()` function:

1. Add imports at top of file:
```python
from canon.alerts.slack import SlackAlerter
from canon.db.error_store import ErrorStore
```

2. After `analytics.init(settings.posthog_key, settings.posthog_host)`, add:
```python
    # SRE Slack alerter
    app.state.slack_alerter = SlackAlerter(
        webhook_url=settings.slack_alerts_webhook_url,
    )
    if app.state.slack_alerter.enabled:
        logger.info("Slack alerts enabled (channel configured)")
```

3. Inside the DB pool initialization block (after `app.state.agent_store = AgentStore(pool)`), add:
```python
            app.state.error_store = ErrorStore(pool)
```

4. In the shutdown section (before `analytics.shutdown()`), add:
```python
    if hasattr(app.state, "slack_alerter"):
        await app.state.slack_alerter.close()
```

- [ ] **Step 3: Run existing tests**

Run: `uv run pytest tests/test_health.py -v`
Expected: PASS

- [ ] **Step 4: Commit**

```bash
git add src/canon/main.py src/canon/db/__init__.py
git commit -m "feat(sre): wire SlackAlerter and ErrorStore into FastAPI app lifespan"
```

---

## Task 12: Error Issue Map — Database Migration

**Depends on:** None (standalone migration)

**Files:**
- Create: `src/canon/db/migrations/versions/0003_error_issue_map.py`

- [ ] **Step 1: Create Alembic migration**

```python
# src/canon/db/migrations/versions/0003_error_issue_map.py
"""Add error_issue_map table for SRE auto-triage dedup.

Revision ID: 0003
Revises: 0002
Create Date: 2026-03-20
"""

from __future__ import annotations

from alembic import op

revision: str = "0003"
down_revision: str = "0002"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    op.execute("""
        CREATE TABLE IF NOT EXISTS error_issue_map (
            id              BIGSERIAL PRIMARY KEY,
            fingerprint     TEXT NOT NULL,
            repo            TEXT NOT NULL,
            issue_number    INT NOT NULL,
            issue_url       TEXT NOT NULL DEFAULT '',
            severity        TEXT NOT NULL DEFAULT 'medium',
            first_seen_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
            last_seen_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
            occurrence_count INT NOT NULL DEFAULT 1,
            resolved_at     TIMESTAMPTZ,
            UNIQUE (fingerprint, repo)
        )
    """)
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_error_issue_map_fingerprint "
        "ON error_issue_map (fingerprint)"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_error_issue_map_repo "
        "ON error_issue_map (repo)"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_error_issue_map_issue "
        "ON error_issue_map (repo, issue_number)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS error_issue_map")
```

- [ ] **Step 2: Commit**

```bash
git add src/canon/db/migrations/versions/0003_error_issue_map.py
git commit -m "feat(sre): add error_issue_map database migration"
```

---

## Task 13: Error Store

**Depends on:** Task 12 (migration defines the table schema)

**Files:**
- Create: `src/canon/db/error_store.py`
- Create: `tests/test_error_store.py`

- [ ] **Step 1: Write failing test for ErrorStore**

```python
# tests/test_error_store.py
"""Tests for ErrorStore (error fingerprint → GitHub issue mapping)."""

from __future__ import annotations

from dataclasses import asdict
from unittest.mock import AsyncMock, MagicMock

import pytest

from canon.db.error_store import ErrorIssueMapping, ErrorStore


class TestErrorStore:
    def _make_store(self) -> tuple[ErrorStore, AsyncMock]:
        mock_pool = MagicMock()
        mock_conn = AsyncMock()
        mock_pool.acquire.return_value.__aenter__ = AsyncMock(return_value=mock_conn)
        mock_pool.acquire.return_value.__aexit__ = AsyncMock(return_value=False)
        return ErrorStore(mock_pool), mock_conn

    @pytest.mark.asyncio
    async def test_get_by_fingerprint_returns_none(self):
        store, mock_conn = self._make_store()
        mock_conn.fetchrow.return_value = None
        result = await store.get_by_fingerprint("fp123", "org/repo")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_by_fingerprint_returns_mapping(self):
        store, mock_conn = self._make_store()
        mock_conn.fetchrow.return_value = {
            "id": 1,
            "fingerprint": "fp123",
            "repo": "org/repo",
            "issue_number": 42,
            "issue_url": "https://github.com/org/repo/issues/42",
            "severity": "high",
            "occurrence_count": 3,
            "resolved_at": None,
        }
        result = await store.get_by_fingerprint("fp123", "org/repo")
        assert result is not None
        assert result.fingerprint == "fp123"
        assert result.issue_number == 42

    @pytest.mark.asyncio
    async def test_create_mapping(self):
        store, mock_conn = self._make_store()
        mock_conn.fetchrow.return_value = {"id": 1}
        mapping = await store.create(
            fingerprint="fp123",
            repo="org/repo",
            issue_number=42,
            issue_url="https://github.com/org/repo/issues/42",
            severity="high",
        )
        assert mapping.fingerprint == "fp123"
        assert mapping.issue_number == 42
        mock_conn.fetchrow.assert_called_once()

    @pytest.mark.asyncio
    async def test_increment_occurrence(self):
        store, mock_conn = self._make_store()
        mock_conn.execute.return_value = None
        await store.increment_occurrence("fp123", "org/repo")
        mock_conn.execute.assert_called_once()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_error_store.py -v`
Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement ErrorStore**

```python
# src/canon/db/error_store.py
"""Error fingerprint → GitHub issue mapping store."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime

import asyncpg

logger = logging.getLogger(__name__)


@dataclass
class ErrorIssueMapping:
    id: int
    fingerprint: str
    repo: str
    issue_number: int
    issue_url: str = ""
    severity: str = "medium"
    occurrence_count: int = 1
    resolved_at: datetime | None = None


class ErrorStore:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def get_by_fingerprint(
        self, fingerprint: str, repo: str
    ) -> ErrorIssueMapping | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT id, fingerprint, repo, issue_number, issue_url, "
                "severity, occurrence_count, resolved_at "
                "FROM error_issue_map WHERE fingerprint = $1 AND repo = $2",
                fingerprint,
                repo,
            )
            if row is None:
                return None
            return ErrorIssueMapping(**dict(row))

    async def create(
        self,
        *,
        fingerprint: str,
        repo: str,
        issue_number: int,
        issue_url: str = "",
        severity: str = "medium",
    ) -> ErrorIssueMapping:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO error_issue_map (fingerprint, repo, issue_number, issue_url, severity) "
                "VALUES ($1, $2, $3, $4, $5) RETURNING id",
                fingerprint,
                repo,
                issue_number,
                issue_url,
                severity,
            )
            return ErrorIssueMapping(
                id=row["id"],
                fingerprint=fingerprint,
                repo=repo,
                issue_number=issue_number,
                issue_url=issue_url,
                severity=severity,
            )

    async def increment_occurrence(self, fingerprint: str, repo: str) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE error_issue_map SET occurrence_count = occurrence_count + 1, "
                "last_seen_at = now() WHERE fingerprint = $1 AND repo = $2",
                fingerprint,
                repo,
            )

    async def mark_resolved(self, fingerprint: str, repo: str) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE error_issue_map SET resolved_at = now() "
                "WHERE fingerprint = $1 AND repo = $2",
                fingerprint,
                repo,
            )

    async def clear_resolved(self, fingerprint: str, repo: str) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE error_issue_map SET resolved_at = NULL "
                "WHERE fingerprint = $1 AND repo = $2",
                fingerprint,
                repo,
            )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_error_store.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/db/error_store.py tests/test_error_store.py
git commit -m "feat(sre): add ErrorStore for error fingerprint → issue mapping"
```

---

## Task 14: Error Triage Module

**Depends on:** Task 12 (migration), Task 13 (ErrorStore)

**Files:**
- Create: `src/canon/alerts/triage.py`
- Create: `tests/test_alerts_triage.py`

- [ ] **Step 1: Write failing test for error triage**

```python
# tests/test_alerts_triage.py
"""Tests for error triage (error → GitHub issue creation)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from canon.alerts.triage import ErrorTriager, ErrorInfo


class TestErrorTriager:
    def _make_triager(self, auto_triage_enabled: bool = True) -> tuple[ErrorTriager, AsyncMock, AsyncMock]:
        mock_error_store = AsyncMock()
        mock_github_client = AsyncMock()
        triager = ErrorTriager(
            error_store=mock_error_store,
            github_client=mock_github_client,
            repo="org/repo",
            auto_triage_enabled=auto_triage_enabled,
        )
        return triager, mock_error_store, mock_github_client

    @pytest.mark.asyncio
    async def test_creates_new_issue_for_new_error(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = None
        mock_gh.create_issue.return_value = {
            "number": 42,
            "html_url": "https://github.com/org/repo/issues/42",
        }

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
            stack_trace="Traceback...",
            endpoint="/webhook",
            count=5,
            first_seen="2026-03-20T10:00:00Z",
            last_seen="2026-03-20T10:05:00Z",
            posthog_url="https://us.posthog.com/error/abc",
        )

        result = await triager.triage(error)

        assert result.action == "created"
        assert result.issue_number == 42
        mock_store.create.assert_called_once()
        mock_gh.create_issue.assert_called_once()
        mock_gh.ensure_label.assert_called()

    @pytest.mark.asyncio
    async def test_skips_existing_open_issue(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = MagicMock(
            issue_number=42,
            resolved_at=None,
        )

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
        )

        result = await triager.triage(error)

        assert result.action == "deduplicated"
        assert result.issue_number == 42
        mock_store.increment_occurrence.assert_called_once()
        mock_gh.create_issue.assert_not_called()

    @pytest.mark.asyncio
    async def test_reopens_resolved_issue(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = MagicMock(
            issue_number=42,
            issue_url="https://github.com/org/repo/issues/42",
            resolved_at="2026-03-19T00:00:00Z",
        )

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
        )

        result = await triager.triage(error)

        assert result.action == "reopened"
        assert result.issue_number == 42
        mock_gh.update_issue.assert_called_once_with("org", "repo", 42, state="open")
        mock_gh.create_comment.assert_called_once()
        mock_store.clear_resolved.assert_called_once()

    @pytest.mark.asyncio
    async def test_auto_triage_disabled_returns_none(self):
        triager, mock_store, mock_gh = self._make_triager(auto_triage_enabled=False)
        error = ErrorInfo(fingerprint="fp123", exception_type="KeyError", message="test")
        result = await triager.triage(error)
        assert result is None
        mock_store.get_by_fingerprint.assert_not_called()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_alerts_triage.py -v`
Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement error triage module**

```python
# src/canon/alerts/triage.py
"""Error triage: create/reopen GitHub issues from error patterns."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from canon.db.error_store import ErrorStore
from canon.github.client import GitHubClient

logger = logging.getLogger(__name__)


@dataclass
class ErrorInfo:
    fingerprint: str
    exception_type: str
    message: str
    stack_trace: str = ""
    endpoint: str = ""
    count: int = 1
    first_seen: str = ""
    last_seen: str = ""
    posthog_url: str = ""
    severity: str = "medium"


@dataclass
class TriageResult:
    action: str  # "created", "deduplicated", "reopened"
    issue_number: int
    issue_url: str = ""


class ErrorTriager:
    """Creates or deduplicates GitHub issues from PostHog error patterns.

    Uses GitHubClient's public API methods (create_issue, update_issue,
    create_comment, ensure_label) rather than private HTTP helpers.
    """

    def __init__(
        self,
        *,
        error_store: ErrorStore,
        github_client: GitHubClient,
        repo: str,
        auto_triage_enabled: bool = True,
    ) -> None:
        self._store = error_store
        self._gh = github_client
        self._repo = repo
        self._auto_triage_enabled = auto_triage_enabled

    async def triage(self, error: ErrorInfo) -> TriageResult | None:
        if not self._auto_triage_enabled:
            logger.debug("Auto-triage disabled — skipping error %s", error.fingerprint)
            return None

        existing = await self._store.get_by_fingerprint(error.fingerprint, self._repo)

        if existing is not None:
            if existing.resolved_at is not None:
                return await self._reopen(existing.issue_number, existing.issue_url, error)
            await self._store.increment_occurrence(error.fingerprint, self._repo)
            return TriageResult(
                action="deduplicated",
                issue_number=existing.issue_number,
                issue_url=getattr(existing, "issue_url", ""),
            )

        return await self._create_issue(error)

    async def _create_issue(self, error: ErrorInfo) -> TriageResult:
        owner, repo_name = self._repo.split("/", 1)
        title = f"{error.exception_type}: {error.message}"[:256]
        body = self._format_issue_body(error)
        labels = ["bug", "auto-triage"]
        if error.severity in ("high", "critical"):
            labels.append(f"severity:{error.severity}")

        # Ensure labels exist (no-op if already present)
        for label in labels:
            await self._gh.ensure_label(owner, repo_name, label)

        # Create issue using public API
        data = await self._gh.create_issue(
            owner, repo_name, title=title, body=body, labels=labels,
        )

        issue_number = data["number"]
        issue_url = data["html_url"]

        await self._store.create(
            fingerprint=error.fingerprint,
            repo=self._repo,
            issue_number=issue_number,
            issue_url=issue_url,
            severity=error.severity,
        )

        logger.info("Auto-created issue #%d for error %s", issue_number, error.fingerprint)
        return TriageResult(action="created", issue_number=issue_number, issue_url=issue_url)

    async def _reopen(
        self, issue_number: int, issue_url: str, error: ErrorInfo
    ) -> TriageResult:
        owner, repo_name = self._repo.split("/", 1)

        # Reopen the issue using public API
        await self._gh.update_issue(owner, repo_name, issue_number, state="open")

        # Add recurrence comment using public API
        comment_body = (
            f"**Error recurrence detected**\n\n"
            f"This error has reappeared after being resolved.\n"
            f"- Exception: `{error.exception_type}: {error.message}`\n"
            f"- Count: {error.count}\n"
        )
        if error.posthog_url:
            comment_body += f"- [View in PostHog]({error.posthog_url})\n"

        await self._gh.create_comment(owner, repo_name, issue_number, comment_body)

        await self._store.clear_resolved(error.fingerprint, self._repo)
        await self._store.increment_occurrence(error.fingerprint, self._repo)

        logger.info("Reopened issue #%d for recurring error %s", issue_number, error.fingerprint)
        return TriageResult(action="reopened", issue_number=issue_number, issue_url=issue_url)

    def _format_issue_body(self, error: ErrorInfo) -> str:
        parts = [
            f"## Auto-Triaged Error\n",
            f"**Exception:** `{error.exception_type}: {error.message}`\n",
            f"**Severity:** {error.severity}\n",
        ]
        if error.endpoint:
            parts.append(f"**Endpoint:** `{error.endpoint}`\n")
        if error.count > 1:
            parts.append(f"**Occurrences:** {error.count}\n")
        if error.first_seen:
            parts.append(f"**First seen:** {error.first_seen}\n")
        if error.last_seen:
            parts.append(f"**Last seen:** {error.last_seen}\n")
        if error.stack_trace:
            parts.append(f"\n### Stack Trace\n```\n{error.stack_trace}\n```\n")
        if error.posthog_url:
            parts.append(f"\n[View in PostHog]({error.posthog_url})\n")

        # Spec context placeholder — Canon bot (Task 17.5) will comment
        # with related spec sections after issue creation.
        parts.append("\n---\n*Auto-created by Canon SRE alerting*")
        return "\n".join(parts)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_alerts_triage.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/alerts/triage.py tests/test_alerts_triage.py
git commit -m "feat(sre): add error triage module for auto-creating GitHub issues"
```

---

## Task 15: Weekly SRE Digest

**Depends on:** Task 4 (SlackAlerter), Task 7 (tracked_cron)

**Files:**
- Create: `src/canon/alerts/digest.py`
- Create: `src/canon/cron/weekly_digest.py`
- Create: `tests/test_weekly_digest.py`

- [ ] **Step 1: Write failing test for digest formatting**

```python
# tests/test_weekly_digest.py
"""Tests for weekly SRE digest."""

from __future__ import annotations

from canon.alerts.digest import WeeklyDigest, format_digest_message


class TestWeeklyDigest:
    def test_format_digest_message(self):
        digest = WeeklyDigest(
            total_errors_this_week=42,
            total_errors_last_week=30,
            top_errors=[
                {"type": "KeyError", "message": "'user_id'", "count": 15},
                {"type": "ValueError", "message": "invalid literal", "count": 10},
            ],
            new_errors_count=3,
            cron_success_rate=95.0,
            webhook_p95_ms=450.5,
            open_triage_issues=2,
        )
        text = format_digest_message(digest)
        assert "Weekly SRE Digest" in text
        assert "42" in text
        assert "40.0%" in text  # (42-30)/30 = 40%
        assert "KeyError" in text
        assert "95.0%" in text

    def test_format_digest_no_previous_week(self):
        digest = WeeklyDigest(
            total_errors_this_week=10,
            total_errors_last_week=0,
            top_errors=[],
            new_errors_count=10,
            cron_success_rate=100.0,
            webhook_p95_ms=0,
            open_triage_issues=0,
        )
        text = format_digest_message(digest)
        assert "Weekly SRE Digest" in text
        assert "N/A" in text  # No comparison when last week is 0
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_weekly_digest.py -v`
Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement digest module**

```python
# src/canon/alerts/digest.py
"""Weekly SRE digest data model and formatting."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class WeeklyDigest:
    total_errors_this_week: int
    total_errors_last_week: int
    top_errors: list[dict] = field(default_factory=list)
    new_errors_count: int = 0
    cron_success_rate: float = 100.0
    webhook_p95_ms: float = 0.0
    open_triage_issues: int = 0


def format_digest_message(digest: WeeklyDigest) -> str:
    """Format the weekly digest as a Slack-friendly markdown message."""
    lines = [
        "*Weekly SRE Digest*",
        "",
    ]

    # Error trend
    if digest.total_errors_last_week > 0:
        change_pct = (
            (digest.total_errors_this_week - digest.total_errors_last_week)
            / digest.total_errors_last_week
            * 100
        )
        trend = f"+{change_pct:.1f}%" if change_pct >= 0 else f"{change_pct:.1f}%"
        emoji = "\U0001f4c8" if change_pct > 0 else "\U0001f4c9"
        lines.append(f"{emoji} *Errors:* {digest.total_errors_this_week} ({trend} vs last week)")
    else:
        lines.append(f"*Errors:* {digest.total_errors_this_week} (trend: N/A)")

    lines.append(f"*New error patterns:* {digest.new_errors_count}")
    lines.append("")

    # Top errors
    if digest.top_errors:
        lines.append("*Top Errors:*")
        for i, err in enumerate(digest.top_errors[:5], 1):
            lines.append(f"  {i}. `{err['type']}: {err['message']}` ({err['count']}x)")
        lines.append("")

    # Cron health
    lines.append(f"*Cron success rate:* {digest.cron_success_rate:.1f}%")

    # Webhook latency
    if digest.webhook_p95_ms > 0:
        lines.append(f"*Webhook p95 latency:* {digest.webhook_p95_ms:.0f}ms")

    # Open triage issues
    if digest.open_triage_issues > 0:
        lines.append(f"*Open auto-triaged issues:* {digest.open_triage_issues}")

    return "\n".join(lines)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_weekly_digest.py -v`
Expected: PASS

- [ ] **Step 5: Create cron entry point**

```python
# src/canon/cron/weekly_digest.py
"""Weekly SRE digest cron job.

Usage: python -m canon.cron.weekly_digest
"""

from __future__ import annotations

import asyncio
import logging
import sys

from canon import analytics, otel_logging
from canon.alerts.cron_utils import tracked_cron
from canon.alerts.digest import WeeklyDigest, format_digest_message
from canon.alerts.slack import SlackAlerter
from canon.settings import Settings

logger = logging.getLogger(__name__)


@tracked_cron("weekly_sre_digest")
async def run_weekly_digest() -> dict:
    settings = Settings()

    if not settings.slack_alerts_enabled:
        logger.info("Slack alerts not configured — skipping weekly digest")
        return {"skipped": True}

    if not settings.sre_weekly_digest_enabled:
        logger.info("Weekly digest disabled — skipping")
        return {"skipped": True}

    # TODO: Query PostHog API for actual metrics once dashboard is set up.
    # For now, this creates the skeleton that will be filled in with real data.
    digest = WeeklyDigest(
        total_errors_this_week=0,
        total_errors_last_week=0,
        top_errors=[],
        new_errors_count=0,
        cron_success_rate=100.0,
        webhook_p95_ms=0,
        open_triage_issues=0,
    )

    message = format_digest_message(digest)
    alerter = SlackAlerter(webhook_url=settings.slack_alerts_webhook_url)
    await alerter.send_text(message)

    logger.info("Weekly SRE digest sent to Slack")
    return {"sent": True}


def main() -> None:
    settings = Settings()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    if settings.posthog_logs_enabled:
        otel_logging.init(
            settings.posthog_key,
            min_level=settings.posthog_logs_min_level,
            posthog_host=settings.posthog_host,
        )

    analytics.init(settings.posthog_key, settings.posthog_host)

    try:
        result = asyncio.run(run_weekly_digest())
        logger.info("Weekly digest complete: %s", result)
    finally:
        analytics.shutdown()
        otel_logging.shutdown()


if __name__ == "__main__":
    main()
```

- [ ] **Step 6: Commit**

```bash
git add src/canon/alerts/digest.py src/canon/cron/weekly_digest.py tests/test_weekly_digest.py
git commit -m "feat(sre): add weekly SRE digest module and cron job"
```

---

## Task 16: Weekly Digest CronJob Template

**Files:**
- Create: `chart/canon/templates/cronjob-weekly-digest.yaml`

- [ ] **Step 1: Create CronJob template**

Reference the existing `chart/canon/templates/cronjob-coverage.yaml` pattern for consistency.

```yaml
# chart/canon/templates/cronjob-weekly-digest.yaml
{{- if .Values.weeklyDigestCronJob.enabled }}
apiVersion: batch/v1
kind: CronJob
metadata:
  name: {{ include "canon.fullname" . }}-weekly-digest
  labels:
    {{- include "canon.labels" . | nindent 4 }}
spec:
  schedule: {{ .Values.weeklyDigestCronJob.schedule | quote }}
  concurrencyPolicy: {{ .Values.weeklyDigestCronJob.concurrencyPolicy }}
  jobTemplate:
    spec:
      template:
        metadata:
          labels:
            {{- include "canon.selectorLabels" . | nindent 12 }}
        spec:
          {{- with .Values.imagePullSecrets }}
          imagePullSecrets:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          serviceAccountName: {{ include "canon.serviceAccountName" . }}
          securityContext:
            {{- toYaml .Values.podSecurityContext | nindent 12 }}
          restartPolicy: OnFailure
          containers:
            - name: weekly-digest
              image: {{ include "canon.image" . }}
              imagePullPolicy: {{ .Values.image.pullPolicy }}
              command: ["python", "-m", "canon.cron.weekly_digest"]
              securityContext:
                {{- toYaml .Values.securityContext | nindent 16 }}
              envFrom:
                - configMapRef:
                    name: {{ include "canon.fullname" . }}
                - secretRef:
                    name: {{ include "canon.githubSecretName" . }}
                - secretRef:
                    name: {{ include "canon.anthropicSecretName" . }}
              {{- if or .Values.secrets.neon.databaseUrl .Values.secrets.neon.existingSecret }}
                - secretRef:
                    name: {{ include "canon.neonSecretName" . }}
              {{- end }}
              {{- if or .Values.secrets.posthog.apiKey .Values.secrets.posthog.existingSecret }}
                - secretRef:
                    name: {{ include "canon.posthogSecretName" . }}
              {{- end }}
              {{- if or .Values.secrets.slack.webhookUrl .Values.secrets.slack.existingSecret }}
                - secretRef:
                    name: {{ include "canon.slackSecretName" . }}
              {{- end }}
              resources:
                {{- toYaml .Values.resources | nindent 16 }}
              volumeMounts:
                - name: tmp
                  mountPath: /tmp
          volumes:
            - name: tmp
              emptyDir: {}
{{- end }}
```

- [ ] **Step 2: Commit**

```bash
git add chart/canon/templates/cronjob-weekly-digest.yaml
git commit -m "feat(sre): add weekly digest CronJob Helm template"
```

---

## Task 17: PostHog Alert Setup Script

**Files:**
- Create: `src/canon/alerts/posthog_setup.py`

This script is run manually (or in CI) to configure PostHog alert actions and dashboard via the PostHog API. It makes the alert configuration reproducible per spec section 2.2.

- [ ] **Step 1: Create PostHog setup script**

```python
# src/canon/alerts/posthog_setup.py
"""PostHog alert actions and dashboard setup script.

Configures PostHog alerting and SRE dashboard via the PostHog API.
Run: python -m canon.alerts.posthog_setup

Requires environment variables:
  POSTHOG_KEY: PostHog project API key
  POSTHOG_HOST: PostHog host (default: https://us.i.posthog.com)
  POSTHOG_PROJECT_ID: PostHog project ID
"""

from __future__ import annotations

import json
import logging
import os
import sys

import httpx

logger = logging.getLogger(__name__)

POSTHOG_HOST = os.environ.get("POSTHOG_HOST", "https://us.i.posthog.com")
POSTHOG_KEY = os.environ.get("POSTHOG_KEY", "")
POSTHOG_PROJECT_ID = os.environ.get("POSTHOG_PROJECT_ID", "")

# Alert definitions per spec Section 2.1
ALERT_DEFINITIONS = [
    {
        "name": "Canon: Exception spike",
        "description": "Exception count > 10 in 5 min window",
        "severity": "high",
        "event": "$exception",
        "threshold": 10,
        "window_minutes": 5,
    },
    {
        "name": "Canon: New error pattern",
        "description": "First-seen exception fingerprint",
        "severity": "medium",
        "event": "$exception",
        "threshold": 1,
        "window_minutes": 5,
    },
    {
        "name": "Canon: Webhook processing slow",
        "description": "p95 webhook duration > 30s over 15 min",
        "severity": "medium",
        "event": "request_completed",
        "threshold": 30000,
        "window_minutes": 15,
    },
    {
        "name": "Canon: Cron job failure",
        "description": "Cron execution with success=false",
        "severity": "high",
        "event": "cron_job_executed",
        "threshold": 1,
        "window_minutes": 5,
    },
    {
        "name": "Canon: Error rate elevated",
        "description": "Error rate > 5% of total requests over 15 min",
        "severity": "high",
        "event": "request_completed",
        "threshold": 5,
        "window_minutes": 15,
    },
    {
        "name": "Canon: Health check failure",
        "description": "Readiness probe returns unhealthy",
        "severity": "critical",
        "event": "health_check_failed",
        "threshold": 1,
        "window_minutes": 5,
    },
]

# Dashboard panels per spec Section 4.1
DASHBOARD_PANELS = [
    {"name": "Error rate", "event": "$exception", "viz": "ActionsLineGraph"},
    {"name": "Webhook latency (p95)", "event": "request_completed", "viz": "ActionsLineGraph"},
    {"name": "Request volume", "event": "request_completed", "viz": "ActionsAreaGraph"},
    {"name": "Success/failure ratio", "event": "request_completed", "viz": "ActionsBar"},
    {"name": "Active installations", "event": "request_completed", "viz": "BoldNumber"},
    {"name": "Cron job health", "event": "cron_job_executed", "viz": "ActionsTable"},
    {"name": "Agent metrics", "event": "agent_call_completed", "viz": "ActionsLineGraph"},
    {"name": "Top errors (24h)", "event": "$exception", "viz": "ActionsTable"},
    {"name": "Rate limit hits", "event": "rate_limit_hit", "viz": "ActionsBar"},
]


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {POSTHOG_KEY}",
        "Content-Type": "application/json",
    }


def setup_dashboard() -> None:
    """Create or update the SRE dashboard in PostHog."""
    if not POSTHOG_KEY or not POSTHOG_PROJECT_ID:
        logger.error("POSTHOG_KEY and POSTHOG_PROJECT_ID required")
        sys.exit(1)

    base = f"{POSTHOG_HOST}/api/projects/{POSTHOG_PROJECT_ID}"

    with httpx.Client(timeout=30.0, headers=_headers()) as client:
        # Create dashboard
        resp = client.post(
            f"{base}/dashboards/",
            json={
                "name": "Canon SRE Dashboard",
                "description": "At-a-glance service reliability — per SRE Alerting spec Section 4",
            },
        )
        resp.raise_for_status()
        dashboard = resp.json()
        dashboard_id = dashboard["id"]
        logger.info("Created dashboard: %s (id=%d)", dashboard["name"], dashboard_id)

        # Create insights for each panel
        for panel in DASHBOARD_PANELS:
            insight_resp = client.post(
                f"{base}/insights/",
                json={
                    "name": panel["name"],
                    "filters": {
                        "events": [{"id": panel["event"]}],
                        "display": panel["viz"],
                        "date_from": "-24h",
                    },
                    "dashboards": [dashboard_id],
                },
            )
            insight_resp.raise_for_status()
            logger.info("  Created panel: %s", panel["name"])

    logger.info("SRE Dashboard setup complete. Dashboard ID: %d", dashboard_id)


def print_alert_config() -> None:
    """Print alert configuration documentation for PostHog setup."""
    print("=" * 60)
    print("PostHog Alert Configuration")
    print("=" * 60)
    print()
    print("Configure these alerts in PostHog > Data Management > Actions")
    print("Then add Slack webhook subscriptions for each action.")
    print()
    for alert in ALERT_DEFINITIONS:
        print(f"Alert: {alert['name']}")
        print(f"  Description: {alert['description']}")
        print(f"  Severity: {alert['severity']}")
        print(f"  Event: {alert['event']}")
        print(f"  Threshold: {alert['threshold']}")
        print(f"  Window: {alert['window_minutes']} minutes")
        print()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if "--dashboard" in sys.argv:
        setup_dashboard()
    elif "--alerts" in sys.argv:
        print_alert_config()
    else:
        print("Usage: python -m canon.alerts.posthog_setup [--dashboard | --alerts]")
        print("  --dashboard  Create SRE dashboard in PostHog")
        print("  --alerts     Print alert configuration docs")
        sys.exit(1)


if __name__ == "__main__":
    main()
```

- [ ] **Step 2: Commit**

```bash
git add src/canon/alerts/posthog_setup.py
git commit -m "feat(sre): add PostHog alert and dashboard setup script"
```

---

## Task 18: Slow Query Detection (db_query_slow)

**Depends on:** Task 1 (SRE Settings)

**Files:**
- Create: `src/canon/db/query_hooks.py`
- Modify: `src/canon/main.py` (wire hook in lifespan)
- Modify: `tests/test_sre_instrumentation.py`

- [ ] **Step 1: Write failing test for slow query tracking**

Append to `tests/test_sre_instrumentation.py`:

```python
from canon.db.query_hooks import log_slow_query


class TestSlowQueryTracking:
    @pytest.mark.asyncio
    async def test_tracks_slow_query(self):
        with patch("canon.db.query_hooks.analytics") as mock_analytics:
            # Simulate a slow query callback
            log_slow_query(
                query="SELECT * FROM spec_documents WHERE repo = $1",
                duration_ms=750.0,
                threshold_ms=500,
            )
            mock_analytics.track.assert_called_once()
            call_args = mock_analytics.track.call_args
            assert call_args[0][0] == "db_query_slow"
            props = call_args[1]["properties"]
            assert props["duration_ms"] == 750.0
            assert "spec_documents" in props["query_type"]

    @pytest.mark.asyncio
    async def test_skips_fast_query(self):
        with patch("canon.db.query_hooks.analytics") as mock_analytics:
            log_slow_query(
                query="SELECT 1",
                duration_ms=50.0,
                threshold_ms=500,
            )
            mock_analytics.track.assert_not_called()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_sre_instrumentation.py::TestSlowQueryTracking -v`
Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement slow query hook**

```python
# src/canon/db/query_hooks.py
"""Database query performance hooks for SRE instrumentation."""

from __future__ import annotations

import logging
import re

from canon import analytics

logger = logging.getLogger(__name__)

# Extract table name from simple queries
_TABLE_RE = re.compile(r"\b(?:FROM|INTO|UPDATE|JOIN)\s+(\w+)", re.IGNORECASE)


def _extract_query_type(query: str) -> str:
    """Extract a short label like 'SELECT spec_documents' from a query."""
    op = query.strip().split()[0].upper() if query.strip() else "UNKNOWN"
    match = _TABLE_RE.search(query)
    table = match.group(1) if match else "unknown"
    return f"{op} {table}"


def log_slow_query(
    *,
    query: str,
    duration_ms: float,
    threshold_ms: int = 500,
) -> None:
    """Track a db_query_slow event if duration exceeds threshold."""
    if duration_ms < threshold_ms:
        return

    query_type = _extract_query_type(query)
    logger.warning("Slow query detected: %s (%.1fms)", query_type, duration_ms)
    analytics.track(
        "db_query_slow",
        properties={
            "query_type": query_type,
            "duration_ms": duration_ms,
            "table": _TABLE_RE.search(query).group(1) if _TABLE_RE.search(query) else "unknown",
        },
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_sre_instrumentation.py::TestSlowQueryTracking -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/db/query_hooks.py tests/test_sre_instrumentation.py
git commit -m "feat(sre): add db_query_slow detection hook"
```

**Note:** Wiring this into asyncpg's query lifecycle requires a connection pool listener. Add to `src/canon/main.py` in the DB pool init block:
```python
            # Wire slow query detection (best-effort — asyncpg may not support all hooks)
            # For production, consider wrapping pool.acquire() or using middleware.
```
The `log_slow_query` function can be called from any DB-accessing code path. Full asyncpg integration is a follow-up — the hook is ready for use.

---

## Task 19: Bot Spec-Context Comments on Auto-Created Issues

**Depends on:** Task 14 (Error Triage), existing agent infrastructure

**Files:**
- Modify: `src/canon/alerts/triage.py` (add spec-context after issue creation)

- [ ] **Step 1: Add spec-context comment method to ErrorTriager**

In `src/canon/alerts/triage.py`, add a method that uses the existing agent to identify related specs:

```python
    async def _add_spec_context_comment(
        self, issue_number: int, error: ErrorInfo
    ) -> None:
        """Best-effort: comment on the issue with related spec context.

        Uses the Canon agent to identify which spec sections relate to
        the error's code path. Failures are logged, not raised.
        """
        try:
            owner, repo_name = self._repo.split("/", 1)
            # Build a short prompt for the agent
            prompt = (
                f"Error: {error.exception_type}: {error.message}\n"
                f"Endpoint: {error.endpoint}\n"
                f"Stack trace:\n{error.stack_trace[:2000]}\n\n"
                "Which spec sections in docs/specs/ relate to this error's code path? "
                "Reply with the spec file and section IDs, or 'No related specs found.'"
            )

            if self._agent_client is None or not self._agent_client.is_available:
                return

            from canon.agent.client import AgentConfig
            result = self._agent_client.complete(
                system_prompt="You are Canon's SRE bot. Identify spec sections related to errors.",
                user_message=prompt,
                config=AgentConfig(max_output_tokens=500),
            )

            if result.text and "No related specs" not in result.text:
                comment = (
                    f"**Spec Context (Canon SRE Bot)**\n\n{result.text}\n\n"
                    f"---\n*Auto-analyzed by Canon SRE bot*"
                )
                await self._gh.create_comment(owner, repo_name, issue_number, comment)
        except Exception:
            logger.debug("Failed to add spec context to issue #%d", issue_number, exc_info=True)
```

Update `__init__` to accept optional `agent_client`:
```python
    def __init__(
        self,
        *,
        error_store: ErrorStore,
        github_client: GitHubClient,
        repo: str,
        auto_triage_enabled: bool = True,
        agent_client: object | None = None,  # ClaudeClient, optional
    ) -> None:
        ...
        self._agent_client = agent_client
```

Call it at the end of `_create_issue()`, after `logger.info(...)`:
```python
        await self._add_spec_context_comment(issue_number, error)
```

- [ ] **Step 2: Commit**

```bash
git add src/canon/alerts/triage.py
git commit -m "feat(sre): add bot spec-context comments on auto-created issues"
```

---

## Task 20: Update Spec Status

**Files:**
- Modify: `docs/specs/sre-alerting-monitoring.md`

- [ ] **Step 1: Update completed section statuses**

Update section statuses based on actual implementation completeness:

```
Section 5: <!-- canon:system:5 status:done -->        (all instrumentation events implemented)
Section 8: <!-- canon:system:8 status:done -->        (settings + CANON.yaml parsing complete)
Section 3: <!-- canon:system:3 status:done -->        (Slack module + Helm config complete)
Section 2: <!-- canon:system:2 status:in_progress --> (setup script created, needs PostHog instance config)
Section 4: <!-- canon:system:4 status:in_progress --> (setup script created, needs PostHog instance config)
Section 6: <!-- canon:system:6 status:done -->        (triage + dedup + reopen complete)
Section 7: <!-- canon:system:7 status:in_progress --> (digest skeleton done, needs PostHog API queries + bot spec-context comments)
Section 9: <!-- canon:system:9 status:in_progress --> (phased structure done, threshold tuning pending baseline data)
```

Also update the frontmatter: `status: in_progress`

**Note:** Sections 2, 4, 7, and 9 remain `in_progress` because:
- Sections 2/4 need actual PostHog instance configuration (run setup script against production)
- Section 7 needs PostHog API queries for real digest data + bot spec-context comments on issues
- Section 9 needs 1 week of baseline data for threshold tuning

- [ ] **Step 2: Commit**

```bash
git add docs/specs/sre-alerting-monitoring.md
git commit -m "docs: update SRE alerting spec section statuses to done"
```

---

## Task 21: Lint and Full Test Suite

- [ ] **Step 1: Run linter on all modified files**

Run: `uv run ruff check src/canon/alerts/ src/canon/cron/weekly_digest.py src/canon/db/error_store.py src/canon/agent/client.py src/canon/web/middleware.py src/canon/main.py src/canon/config/parse.py src/canon/settings.py`
Expected: No errors (or auto-fix with `--fix`)

- [ ] **Step 2: Run full test suite**

Run: `uv run pytest tests/ -v --tb=short`
Expected: All tests pass

- [ ] **Step 3: Fix any issues and commit**

```bash
git add -A
git commit -m "chore: lint fixes for SRE alerting modules"
```
