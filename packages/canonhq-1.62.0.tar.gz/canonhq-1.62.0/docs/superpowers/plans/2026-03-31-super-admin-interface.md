# Super Admin Interface Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a platform-level admin interface with cross-org visibility for Canon team (cloud) and instance admin for self-hosted deployers.

**Architecture:** Dedicated `src/canon/admin/` backend module with `/api/admin/` routes gated by SUPER_ADMIN role. Vue 3 frontend at `/app/admin/` with three-column layout (icon rail + context panel + detail pane). Feature gating via `DEPLOYMENT_MODE` env var.

**Tech Stack:** Python 3.12 / FastAPI / asyncpg (backend), Vue 3 / Pinia / Vue Query / TailwindCSS 4 (frontend), Helm (infrastructure)

**Design spec:** `docs/superpowers/specs/2026-03-31-super-admin-interface-design.md`

---

## File Structure

### Backend — New Files

```
src/canon/admin/
  __init__.py                  # Module init, exports admin_router
  middleware.py                # require_super_admin FastAPI dependency
  config.py                   # AdminConfig model, deployment mode detection
  audit.py                    # AuditStore — audit_events table CRUD
  store.py                    # AdminStore — cross-org query layer
  routes.py                   # All /api/admin/* endpoints
  models.py                   # Pydantic response models for admin API

src/canon/db/migrations/versions/
  0005_audit_events.py         # New migration for audit_events table

src/canon/cron/
  audit_retention.py           # Audit log retention CronJob entry point
```

### Backend — Modified Files

```
src/canon/auth/permissions.py  # Add SUPER_ADMIN role + PLATFORM_MANAGE permission
src/canon/settings.py          # Add deployment_mode + admin_audit_retention_days
src/canon/main.py              # Register admin_router, init AdminStore + AuditStore
```

### Frontend — New Files

```
frontend/src/views/admin/
  AdminLayout.vue              # Three-column shell (icon rail, context panel, detail)
  AdminDashboard.vue           # Landing overview with KPIs + charts
  AdminOrgs.vue                # Organizations context panel
  AdminOrgDetail.vue           # Org detail pane
  AdminUsers.vue               # Users context panel
  AdminUserDetail.vue          # User detail pane
  AdminBilling.vue             # Billing section (cloud only)
  AdminHealth.vue              # System health context panel
  AdminHealthDetail.vue        # Subsystem detail pane
  AdminIntegrations.vue        # Integrations read view
  AdminAudit.vue               # Audit log with filters
  AdminAI.vue                  # AI operations section

frontend/src/components/admin/
  IconRail.vue                 # Section icon navigation
  ContextPanel.vue             # Entity list with search/filter
  KPICard.vue                  # Stat card widget
  StatusBadge.vue              # Traffic light indicator
  ActivityFeed.vue             # Event stream component
  AuditTable.vue               # Filterable event table

frontend/src/stores/
  admin.ts                     # Pinia store for admin state

frontend/src/api/
  types.ts                     # (modify) Add admin API response types
```

### Frontend — Modified Files

```
frontend/src/router/index.ts  # Add /app/admin/* routes
frontend/src/api/admin.ts     # Extend with new admin API functions
```

### Infrastructure — New Files

```
chart/canon/templates/
  cronjob-audit-retention.yaml # Audit retention CronJob
```

### Infrastructure — Modified Files

```
chart/canon/values.yaml             # Add deploymentMode, auditRetentionCronJob
chart/canon/values-production.yaml  # Set deploymentMode: "cloud"
chart/canon/templates/configmap.yaml # Add DEPLOYMENT_MODE, ADMIN_AUDIT_RETENTION_DAYS
```

### Tests — New Files

```
tests/test_admin/
  __init__.py
  conftest.py                  # Admin test fixtures
  test_middleware.py            # SUPER_ADMIN gate tests
  test_audit_store.py          # AuditStore unit tests
  test_admin_store.py          # AdminStore unit tests
  test_routes.py               # Admin API endpoint tests
  test_config.py               # Feature gating tests
```

---

## Task 1: Add SUPER_ADMIN Role and PLATFORM_MANAGE Permission

**Files:**
- Modify: `src/canon/auth/permissions.py`
- Test: `tests/test_auth/test_models.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_auth/test_models.py`:

```python
class TestSuperAdminRole:
    def test_super_admin_has_all_permissions(self):
        from canon.auth.permissions import Role, Permission, permissions_for_role

        perms = permissions_for_role(Role.SUPER_ADMIN)
        for p in Permission:
            assert p in perms, f"SUPER_ADMIN missing {p}"

    def test_super_admin_has_platform_manage(self):
        from canon.auth.permissions import Role, Permission, permissions_for_role

        perms = permissions_for_role(Role.SUPER_ADMIN)
        assert Permission.PLATFORM_MANAGE in perms

    def test_admin_does_not_have_platform_manage(self):
        from canon.auth.permissions import Role, Permission, permissions_for_role

        perms = permissions_for_role(Role.ADMIN)
        assert Permission.PLATFORM_MANAGE not in perms

    def test_role_hierarchy_order(self):
        from canon.auth.permissions import Role

        roles = list(Role)
        assert roles.index(Role.VIEWER) < roles.index(Role.EDITOR)
        assert roles.index(Role.EDITOR) < roles.index(Role.ADMIN)
        assert roles.index(Role.ADMIN) < roles.index(Role.SUPER_ADMIN)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_auth/test_models.py::TestSuperAdminRole -v`
Expected: FAIL — `Role` has no attribute `SUPER_ADMIN`

- [ ] **Step 3: Add SUPER_ADMIN to permissions.py**

In `src/canon/auth/permissions.py`, add `PLATFORM_MANAGE` to `Permission` enum:

```python
class Permission(StrEnum):
    SPECS_READ = "specs:read"
    SPECS_WRITE = "specs:write"
    SPECS_ADMIN = "specs:admin"
    ORG_MANAGE = "org:manage"
    PLATFORM_MANAGE = "platform:manage"
```

Add `SUPER_ADMIN` to `Role` enum:

```python
class Role(StrEnum):
    VIEWER = "viewer"
    EDITOR = "editor"
    ADMIN = "admin"
    SUPER_ADMIN = "super_admin"
```

Update `ROLE_PERMISSIONS`:

```python
ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.VIEWER: frozenset({Permission.SPECS_READ}),
    Role.EDITOR: frozenset({Permission.SPECS_READ, Permission.SPECS_WRITE}),
    Role.ADMIN: frozenset({p for p in Permission if p != Permission.PLATFORM_MANAGE}),
    Role.SUPER_ADMIN: frozenset(Permission),  # all permissions including PLATFORM_MANAGE
}
```

Add to `PERMISSION_DESCRIPTIONS`:

```python
PERMISSION_DESCRIPTIONS: dict[str, str] = {
    # ... existing entries ...
    "platform:manage": "Manage platform admin settings",
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_auth/test_models.py::TestSuperAdminRole -v`
Expected: PASS (all 4 tests)

- [ ] **Step 5: Run full auth test suite to check for regressions**

Run: `uv run pytest tests/test_auth/ -v`
Expected: All existing tests still pass

- [ ] **Step 6: Commit**

```bash
git add src/canon/auth/permissions.py tests/test_auth/test_models.py
git commit -m "feat(admin): add SUPER_ADMIN role and PLATFORM_MANAGE permission"
```

---

## Task 2: Add DEPLOYMENT_MODE to Settings

**Files:**
- Modify: `src/canon/settings.py`
- Test: `tests/test_settings.py` (create if needed)

- [ ] **Step 1: Write the failing test**

Create `tests/test_admin/__init__.py` (empty) and `tests/test_admin/test_config.py`:

```python
"""Tests for admin configuration and deployment mode."""

import pytest
from canon.settings import Settings


class TestDeploymentMode:
    def test_default_is_development(self):
        s = Settings(deployment_mode="development")
        assert s.deployment_mode == "development"

    def test_cloud_mode(self):
        s = Settings(deployment_mode="cloud")
        assert s.deployment_mode == "cloud"

    def test_self_hosted_mode(self):
        s = Settings(deployment_mode="self_hosted")
        assert s.deployment_mode == "self_hosted"

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError):
            Settings(deployment_mode="invalid")

    def test_audit_retention_default(self):
        s = Settings()
        assert s.admin_audit_retention_days == 90
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_admin/test_config.py -v`
Expected: FAIL — `Settings` has no field `deployment_mode`

- [ ] **Step 3: Add fields to Settings**

In `src/canon/settings.py`, add to the `Settings` class:

```python
from typing import Literal

class Settings(BaseSettings):
    # ... existing fields ...

    # Admin configuration
    deployment_mode: Literal["cloud", "self_hosted", "development"] = "development"
    admin_audit_retention_days: int = 90
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_admin/test_config.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/settings.py tests/test_admin/__init__.py tests/test_admin/test_config.py
git commit -m "feat(admin): add DEPLOYMENT_MODE and audit retention to settings"
```

---

## Task 3: Create audit_events Migration

**Files:**
- Create: `src/canon/db/migrations/versions/0005_audit_events.py`

- [ ] **Step 1: Verify current migration state**

Run: `ls src/canon/db/migrations/versions/`
Confirm the latest migration number (likely `0004_*`). The new one will be `0005`.

- [ ] **Step 2: Create the migration file**

Create `src/canon/db/migrations/versions/0005_audit_events.py`:

```python
"""Add audit_events table for admin action logging.

Revision ID: 0005
Revises: 0004
Create Date: 2026-03-31
"""

from __future__ import annotations

from alembic import op

revision: str = "0005"
down_revision: str = "0004"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    op.execute("""
        CREATE TABLE IF NOT EXISTS audit_events (
            id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
            actor_id        BIGINT REFERENCES users(id),
            org             TEXT,
            event_type      TEXT NOT NULL,
            resource_type   TEXT NOT NULL,
            resource_id     TEXT NOT NULL,
            detail          JSONB,
            ip_address      INET
        )
    """)
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_audit_org_time "
        "ON audit_events (org, created_at DESC)"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_audit_actor "
        "ON audit_events (actor_id)"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_audit_resource "
        "ON audit_events (resource_type, resource_id)"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_audit_event_type "
        "ON audit_events (event_type)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS audit_events")
```

- [ ] **Step 3: Verify migration file is syntactically correct**

Run: `uv run python -c "import importlib.util; spec = importlib.util.spec_from_file_location('m', 'src/canon/db/migrations/versions/0005_audit_events.py'); mod = importlib.util.module_from_spec(spec); print('OK')"`
Expected: `OK`

- [ ] **Step 4: Commit**

```bash
git add src/canon/db/migrations/versions/0005_audit_events.py
git commit -m "feat(admin): add audit_events migration"
```

---

## Task 4: Create AuditStore

**Files:**
- Create: `src/canon/admin/__init__.py`
- Create: `src/canon/admin/audit.py`
- Create: `tests/test_admin/test_audit_store.py`

- [ ] **Step 1: Create module init**

Create `src/canon/admin/__init__.py`:

```python
"""Canon platform admin module."""
```

- [ ] **Step 2: Write the failing test**

Create `tests/test_admin/test_audit_store.py`:

```python
"""Tests for AuditStore."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from canon.admin.audit import AuditStore


@pytest.fixture
def mock_pool():
    pool = MagicMock()
    conn = AsyncMock()
    pool.acquire.return_value.__aenter__ = AsyncMock(return_value=conn)
    pool.acquire.return_value.__aexit__ = AsyncMock(return_value=False)
    return pool, conn


class TestAuditStoreLog:
    async def test_log_inserts_event(self, mock_pool):
        pool, conn = mock_pool
        store = AuditStore(pool)
        conn.execute = AsyncMock()

        await store.log(
            actor_id=1,
            org="acme",
            event_type="user.role_changed",
            resource_type="user",
            resource_id="42",
            detail={"old_role": "editor", "new_role": "admin"},
            ip_address="127.0.0.1",
        )

        conn.execute.assert_awaited_once()
        sql = conn.execute.call_args[0][0]
        assert "INSERT INTO audit_events" in sql

    async def test_log_without_optional_fields(self, mock_pool):
        pool, conn = mock_pool
        store = AuditStore(pool)
        conn.execute = AsyncMock()

        await store.log(
            event_type="system.reindex",
            resource_type="installation",
            resource_id="123",
        )

        conn.execute.assert_awaited_once()


class TestAuditStoreList:
    async def test_list_returns_events(self, mock_pool):
        pool, conn = mock_pool
        store = AuditStore(pool)
        fake_row = {
            "id": "abc-123",
            "created_at": "2026-03-31T00:00:00Z",
            "actor_id": 1,
            "org": "acme",
            "event_type": "user.role_changed",
            "resource_type": "user",
            "resource_id": "42",
            "detail": {"old_role": "editor"},
            "ip_address": "127.0.0.1",
        }
        conn.fetch = AsyncMock(return_value=[MagicMock(**{"__iter__": lambda s: iter(fake_row.items()), "keys": lambda s: fake_row.keys(), "__getitem__": lambda s, k: fake_row[k]})])

        events = await store.list(limit=10, offset=0)
        assert len(events) == 1
        conn.fetch.assert_awaited_once()

    async def test_list_with_filters(self, mock_pool):
        pool, conn = mock_pool
        store = AuditStore(pool)
        conn.fetch = AsyncMock(return_value=[])

        events = await store.list(
            limit=10, offset=0,
            org="acme",
            event_type="user.role_changed",
            actor_id=1,
        )
        assert events == []
        sql = conn.fetch.call_args[0][0]
        assert "org = " in sql
        assert "event_type = " in sql
        assert "actor_id = " in sql


class TestAuditStoreRetention:
    async def test_delete_old_events(self, mock_pool):
        pool, conn = mock_pool
        store = AuditStore(pool)
        conn.execute = AsyncMock(return_value="DELETE 42")

        deleted = await store.delete_older_than(days=90)
        assert deleted == 42
        sql = conn.execute.call_args[0][0]
        assert "DELETE FROM audit_events" in sql
        assert "created_at <" in sql
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/test_admin/test_audit_store.py -v`
Expected: FAIL — `cannot import 'AuditStore'`

- [ ] **Step 4: Implement AuditStore**

Create `src/canon/admin/audit.py`:

```python
"""Audit event store for admin action logging."""

from __future__ import annotations

import re
from typing import Any

import asyncpg


class AuditStore:
    """Data access layer for the audit_events table."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def log(
        self,
        *,
        event_type: str,
        resource_type: str,
        resource_id: str,
        actor_id: int | None = None,
        org: str | None = None,
        detail: dict[str, Any] | None = None,
        ip_address: str | None = None,
    ) -> None:
        """Insert an audit event."""
        import json

        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO audit_events
                    (actor_id, org, event_type, resource_type, resource_id, detail, ip_address)
                VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::inet)
                """,
                actor_id,
                org,
                event_type,
                resource_type,
                resource_id,
                json.dumps(detail) if detail else None,
                ip_address,
            )

    async def list(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        org: str | None = None,
        event_type: str | None = None,
        actor_id: int | None = None,
        resource_type: str | None = None,
    ) -> list[dict[str, Any]]:
        """List audit events with optional filters, newest first."""
        conditions: list[str] = []
        params: list[Any] = []
        idx = 1

        if org is not None:
            conditions.append(f"org = ${idx}")
            params.append(org)
            idx += 1
        if event_type is not None:
            conditions.append(f"event_type = ${idx}")
            params.append(event_type)
            idx += 1
        if actor_id is not None:
            conditions.append(f"actor_id = ${idx}")
            params.append(actor_id)
            idx += 1
        if resource_type is not None:
            conditions.append(f"resource_type = ${idx}")
            params.append(resource_type)
            idx += 1

        where = "WHERE " + " AND ".join(conditions) if conditions else ""

        params.extend([limit, offset])
        sql = f"""
            SELECT * FROM audit_events
            {where}
            ORDER BY created_at DESC
            LIMIT ${idx} OFFSET ${idx + 1}
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        return [dict(r) for r in rows]

    async def delete_older_than(self, *, days: int) -> int:
        """Delete audit events older than N days. Returns count deleted."""
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                "DELETE FROM audit_events WHERE created_at < now() - $1 * interval '1 day'",
                days,
            )
        # result is like "DELETE 42"
        match = re.search(r"\d+", result)
        return int(match.group()) if match else 0
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/test_admin/test_audit_store.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/canon/admin/__init__.py src/canon/admin/audit.py tests/test_admin/test_audit_store.py
git commit -m "feat(admin): add AuditStore for audit event logging"
```

---

## Task 5: Create Admin Middleware

**Files:**
- Create: `src/canon/admin/middleware.py`
- Create: `tests/test_admin/test_middleware.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_admin/test_middleware.py`:

```python
"""Tests for admin middleware — SUPER_ADMIN gate."""

import pytest
from unittest.mock import MagicMock, patch
from fastapi import FastAPI
from fastapi.testclient import TestClient
from httpx import AsyncClient, ASGITransport

from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission, Role


class TestRequireSuperAdmin:
    async def test_unauthenticated_returns_404(self):
        """Don't reveal admin routes exist to unauthenticated users."""
        from canon.admin.middleware import require_super_admin

        request = MagicMock()
        request.state = MagicMock(spec=[])  # no current_user attribute

        with pytest.raises(Exception) as exc_info:
            await require_super_admin(request)
        assert exc_info.value.status_code == 404

    async def test_non_super_admin_returns_403(self):
        from canon.admin.middleware import require_super_admin

        user = CurrentUser(
            sub="u1",
            org_login="acme",
            permissions=frozenset({Permission.SPECS_READ, Permission.ORG_MANAGE}),
        )
        request = MagicMock()
        request.state.current_user = user

        with pytest.raises(Exception) as exc_info:
            await require_super_admin(request)
        assert exc_info.value.status_code == 403

    async def test_super_admin_passes(self):
        from canon.admin.middleware import require_super_admin

        user = CurrentUser(
            sub="u1",
            org_login="acme",
            permissions=frozenset(Permission),
        )
        request = MagicMock()
        request.state.current_user = user

        result = await require_super_admin(request)
        assert result.sub == "u1"

    async def test_anonymous_user_returns_404(self):
        from canon.admin.middleware import require_super_admin

        request = MagicMock()
        request.state.current_user = None

        with pytest.raises(Exception) as exc_info:
            await require_super_admin(request)
        assert exc_info.value.status_code == 404
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_admin/test_middleware.py -v`
Expected: FAIL — cannot import `require_super_admin`

- [ ] **Step 3: Implement middleware**

Create `src/canon/admin/middleware.py`:

```python
"""Admin middleware — SUPER_ADMIN role gate for /api/admin/* routes."""

from __future__ import annotations

from fastapi import HTTPException, Request

from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission


async def require_super_admin(request: Request) -> CurrentUser:
    """FastAPI dependency that requires SUPER_ADMIN role.

    Returns 404 for unauthenticated (don't reveal admin routes exist).
    Returns 403 for authenticated non-super-admins.
    """
    user: CurrentUser | None = getattr(request.state, "current_user", None)

    if user is None or user.is_anonymous:
        raise HTTPException(status_code=404)

    if not user.has_permission(Permission.PLATFORM_MANAGE):
        raise HTTPException(status_code=403, detail="Insufficient permissions")

    return user
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_admin/test_middleware.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/admin/middleware.py tests/test_admin/test_middleware.py
git commit -m "feat(admin): add require_super_admin middleware"
```

---

## Task 6: Create Admin Config Endpoint and Models

**Files:**
- Create: `src/canon/admin/config.py`
- Create: `src/canon/admin/models.py`
- Create: `tests/test_admin/test_routes.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_admin/conftest.py`:

```python
"""Shared fixtures for admin tests."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission


@pytest.fixture
def super_admin_user() -> CurrentUser:
    return CurrentUser(
        sub="admin-1",
        email="admin@canonhq.co",
        name="Admin User",
        org_login="canonhq",
        permissions=frozenset(Permission),
        auth_method="session",
    )


@pytest.fixture
def regular_user() -> CurrentUser:
    return CurrentUser(
        sub="user-1",
        email="user@acme.com",
        name="Regular User",
        org_login="acme",
        permissions=frozenset({Permission.SPECS_READ, Permission.SPECS_WRITE}),
        auth_method="session",
    )
```

Create `tests/test_admin/test_routes.py`:

```python
"""Tests for admin API routes."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from httpx import AsyncClient, ASGITransport

from canon.main import app
from canon.settings import Settings
from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission


def _admin_settings(**overrides) -> Settings:
    defaults = dict(
        deployment_mode="cloud",
        admin_audit_retention_days=90,
    )
    defaults.update(overrides)
    return Settings(**defaults)


class TestAdminConfig:
    @pytest.fixture(autouse=True)
    def _setup(self, super_admin_user):
        app.state.settings = _admin_settings()
        app.state.db_pool = None
        # Patch auth middleware to return our test user
        self._user = super_admin_user

    async def test_config_returns_cloud_features(self, super_admin_user):
        with patch("canon.admin.middleware.require_super_admin", return_value=super_admin_user):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/admin/config")

        assert resp.status_code == 200
        data = resp.json()
        assert data["mode"] == "cloud"
        assert data["features"]["billing"] is True
        assert data["features"]["cross_org"] is True
        assert data["features"]["impersonation"] is True

    async def test_config_self_hosted_hides_cloud_features(self, super_admin_user):
        app.state.settings = _admin_settings(deployment_mode="self_hosted")
        with patch("canon.admin.middleware.require_super_admin", return_value=super_admin_user):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/admin/config")

        assert resp.status_code == 200
        data = resp.json()
        assert data["mode"] == "self_hosted"
        assert data["features"]["billing"] is False
        assert data["features"]["cross_org"] is False
        assert data["features"]["impersonation"] is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_admin/test_routes.py::TestAdminConfig -v`
Expected: FAIL — no `/api/admin/config` route

- [ ] **Step 3: Implement config and models**

Create `src/canon/admin/config.py`:

```python
"""Admin configuration — deployment mode detection and feature gating."""

from __future__ import annotations

from pydantic import BaseModel

from canon.settings import Settings


class AdminFeatures(BaseModel):
    billing: bool
    cross_org: bool
    impersonation: bool


class AdminConfig(BaseModel):
    mode: str
    features: AdminFeatures


def get_admin_config(settings: Settings) -> AdminConfig:
    """Build admin config from deployment mode."""
    is_cloud = settings.deployment_mode == "cloud"
    return AdminConfig(
        mode=settings.deployment_mode,
        features=AdminFeatures(
            billing=is_cloud,
            cross_org=is_cloud,
            impersonation=is_cloud,
        ),
    )
```

Create `src/canon/admin/models.py`:

```python
"""Pydantic response models for admin API endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel


class AuditEventResponse(BaseModel):
    id: UUID
    created_at: datetime
    actor_id: int | None = None
    org: str | None = None
    event_type: str
    resource_type: str
    resource_id: str
    detail: dict[str, Any] | None = None
    ip_address: str | None = None


class KPIStats(BaseModel):
    orgs: int = 0
    orgs_new_this_month: int = 0
    active_users: int = 0
    active_today: int = 0
    specs_tracked: int = 0
    coverage_pct: float = 0.0
    system_status: str = "operational"


class OrgSummary(BaseModel):
    org_login: str
    plan: str = ""
    status: str = "active"
    user_count: int = 0
    repo_count: int = 0
    spec_count: int = 0
    coverage_pct: float = 0.0
    ai_ops_this_month: int = 0
    created_at: datetime | None = None
    last_active: datetime | None = None


class UserSummary(BaseModel):
    id: int
    email: str
    name: str = ""
    org_login: str = ""
    role: str = "viewer"
    last_login_at: datetime | None = None
    created_at: datetime | None = None


class HealthSubsystem(BaseModel):
    name: str
    status: str  # "healthy", "degraded", "down"
    detail: str = ""


class DashboardResponse(BaseModel):
    kpis: KPIStats
    health: list[HealthSubsystem] = []
    recent_activity: list[dict[str, Any]] = []
```

Create `src/canon/admin/routes.py`:

```python
"""Admin API routes — /api/admin/* endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from canon.admin.config import get_admin_config
from canon.admin.middleware import require_super_admin
from canon.auth.models import CurrentUser

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/config")
async def admin_config(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    """Return admin configuration and feature flags."""
    settings = request.app.state.settings
    return get_admin_config(settings)
```

- [ ] **Step 4: Register admin router in main.py**

In `src/canon/main.py`, add the import and router registration. Find the router imports section and add:

```python
from canon.admin.routes import router as admin_router
```

Find the `app.include_router(...)` section (before `spa_router`) and add:

```python
app.include_router(admin_router)
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/test_admin/test_routes.py::TestAdminConfig -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/canon/admin/config.py src/canon/admin/models.py src/canon/admin/routes.py \
  tests/test_admin/conftest.py tests/test_admin/test_routes.py src/canon/main.py
git commit -m "feat(admin): add config endpoint, models, and route registration"
```

---

## Task 7: Create AdminStore (Cross-Org Query Layer)

**Files:**
- Create: `src/canon/admin/store.py`
- Create: `tests/test_admin/test_admin_store.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_admin/test_admin_store.py`:

```python
"""Tests for AdminStore cross-org query layer."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from canon.admin.store import AdminStore


@pytest.fixture
def mock_pool():
    pool = MagicMock()
    conn = AsyncMock()
    pool.acquire.return_value.__aenter__ = AsyncMock(return_value=conn)
    pool.acquire.return_value.__aexit__ = AsyncMock(return_value=False)
    return pool, conn


class TestListOrgs:
    async def test_returns_org_list(self, mock_pool):
        pool, conn = mock_pool
        store = AdminStore(pool)
        conn.fetch = AsyncMock(return_value=[
            {"org_login": "acme", "status": "active", "repos_count": 5},
            {"org_login": "widgets", "status": "active", "repos_count": 3},
        ])
        orgs = await store.list_orgs()
        assert len(orgs) == 2
        assert orgs[0]["org_login"] == "acme"


class TestListUsers:
    async def test_returns_all_users(self, mock_pool):
        pool, conn = mock_pool
        store = AdminStore(pool)
        conn.fetch = AsyncMock(return_value=[
            {"id": 1, "email": "a@acme.com", "role": "admin"},
        ])
        users = await store.list_users(limit=50, offset=0)
        assert len(users) == 1

    async def test_filter_by_org(self, mock_pool):
        pool, conn = mock_pool
        store = AdminStore(pool)
        conn.fetch = AsyncMock(return_value=[])
        users = await store.list_users(limit=50, offset=0, org="acme")
        sql = conn.fetch.call_args[0][0]
        assert "org_login" in sql


class TestGetKPIs:
    async def test_returns_stats(self, mock_pool):
        pool, conn = mock_pool
        store = AdminStore(pool)
        conn.fetchval = AsyncMock(side_effect=[5, 2, 42, 10, 100, 72.5])
        kpis = await store.get_kpis()
        assert kpis["orgs"] == 5
        assert kpis["active_users"] == 42
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_admin/test_admin_store.py -v`
Expected: FAIL — cannot import `AdminStore`

- [ ] **Step 3: Implement AdminStore**

Create `src/canon/admin/store.py`:

```python
"""AdminStore — cross-org query layer for admin dashboard."""

from __future__ import annotations

from typing import Any

import asyncpg


class AdminStore:
    """Cross-org data access for admin interface.

    Composes queries across existing tables (gh_installations, users,
    subscriptions, ai_op_usage, etc.) without tenant isolation.
    """

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def list_orgs(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        search: str | None = None,
    ) -> list[dict[str, Any]]:
        """List all organizations (GitHub installations)."""
        conditions: list[str] = []
        params: list[Any] = []
        idx = 1

        if search:
            conditions.append(f"org_login ILIKE ${idx}")
            params.append(f"%{search}%")
            idx += 1

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        params.extend([limit, offset])

        sql = f"""
            SELECT g.*, u_counts.user_count
            FROM gh_installations g
            LEFT JOIN (
                SELECT org_login, COUNT(*) as user_count
                FROM users GROUP BY org_login
            ) u_counts ON u_counts.org_login = g.org_login
            {where}
            ORDER BY g.org_login
            LIMIT ${idx} OFFSET ${idx + 1}
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        return [dict(r) for r in rows]

    async def get_org(self, org: str) -> dict[str, Any] | None:
        """Get a single org by login."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM gh_installations WHERE org_login = $1",
                org,
            )
        return dict(row) if row else None

    async def list_users(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        org: str | None = None,
        role: str | None = None,
        search: str | None = None,
    ) -> list[dict[str, Any]]:
        """List users, optionally filtered by org, role, or search term."""
        conditions: list[str] = []
        params: list[Any] = []
        idx = 1

        if org:
            conditions.append(f"org_login = ${idx}")
            params.append(org)
            idx += 1
        if role:
            conditions.append(f"role = ${idx}")
            params.append(role)
            idx += 1
        if search:
            conditions.append(f"(email ILIKE ${idx} OR name ILIKE ${idx})")
            params.append(f"%{search}%")
            idx += 1

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        params.extend([limit, offset])

        sql = f"""
            SELECT id, oidc_sub, email, name, picture, role, org_login,
                   created_at, last_login_at
            FROM users
            {where}
            ORDER BY last_login_at DESC NULLS LAST
            LIMIT ${idx} OFFSET ${idx + 1}
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        return [dict(r) for r in rows]

    async def get_user(self, user_id: int) -> dict[str, Any] | None:
        """Get a single user by ID."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM users WHERE id = $1", user_id)
        return dict(row) if row else None

    async def update_user_role(self, user_id: int, new_role: str) -> bool:
        """Update a user's role. Returns True if updated."""
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                "UPDATE users SET role = $1 WHERE id = $2", new_role, user_id
            )
        return result == "UPDATE 1"

    async def get_kpis(self) -> dict[str, Any]:
        """Get platform-wide KPI stats."""
        async with self._pool.acquire() as conn:
            orgs = await conn.fetchval(
                "SELECT COUNT(*) FROM gh_installations"
            )
            orgs_new = await conn.fetchval(
                "SELECT COUNT(*) FROM gh_installations "
                "WHERE created_at > now() - interval '30 days'"
            )
            active_users = await conn.fetchval("SELECT COUNT(*) FROM users")
            active_today = await conn.fetchval(
                "SELECT COUNT(*) FROM users "
                "WHERE last_login_at > now() - interval '1 day'"
            )
            specs = await conn.fetchval(
                "SELECT COALESCE(SUM(specs_indexed), 0) FROM index_jobs "
                "WHERE status = 'completed'"
            )
            coverage = await conn.fetchval(
                "SELECT COALESCE(AVG(coverage_pct), 0) FROM ("
                "  SELECT DISTINCT ON (org, repo) coverage_pct "
                "  FROM coverage_snapshots ORDER BY org, repo, snapshot_date DESC"
                ") sub"
            )
        return {
            "orgs": int(orgs or 0),
            "orgs_new_this_month": int(orgs_new or 0),
            "active_users": int(active_users or 0),
            "active_today": int(active_today or 0),
            "specs_tracked": int(specs or 0),
            "coverage_pct": float(coverage or 0),
        }

    async def get_health_summary(self) -> list[dict[str, str]]:
        """Get subsystem health checks."""
        subsystems: list[dict[str, str]] = []
        async with self._pool.acquire() as conn:
            # Indexing health: check for recent failures
            failed = await conn.fetchval(
                "SELECT COUNT(*) FROM index_jobs "
                "WHERE status = 'failed' AND created_at > now() - interval '1 hour'"
            )
            subsystems.append({
                "name": "Indexing",
                "status": "degraded" if (failed or 0) > 0 else "healthy",
                "detail": f"{failed} failures in last hour" if failed else "No recent failures",
            })

            # Sync health: check last sync time
            last_sync = await conn.fetchval(
                "SELECT MAX(last_synced_at) FROM sync_state"
            )
            subsystems.append({
                "name": "Sync Engine",
                "status": "healthy" if last_sync else "unknown",
                "detail": f"Last sync: {last_sync}" if last_sync else "No sync data",
            })

        return subsystems
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_admin/test_admin_store.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/admin/store.py tests/test_admin/test_admin_store.py
git commit -m "feat(admin): add AdminStore for cross-org queries"
```

---

## Task 8: Add Dashboard and Remaining API Endpoints

**Files:**
- Modify: `src/canon/admin/routes.py`
- Modify: `tests/test_admin/test_routes.py`

- [ ] **Step 1: Write tests for dashboard endpoint**

Add to `tests/test_admin/test_routes.py`:

```python
class TestAdminDashboard:
    @pytest.fixture(autouse=True)
    def _setup(self, super_admin_user):
        app.state.settings = _admin_settings()
        self._user = super_admin_user
        # Mock admin store
        mock_admin_store = MagicMock()
        mock_admin_store.get_kpis = AsyncMock(return_value={
            "orgs": 5, "orgs_new_this_month": 1,
            "active_users": 42, "active_today": 10,
            "specs_tracked": 100, "coverage_pct": 72.5,
        })
        mock_admin_store.get_health_summary = AsyncMock(return_value=[
            {"name": "Indexing", "status": "healthy", "detail": "OK"},
        ])
        app.state.admin_store = mock_admin_store
        # Mock audit store for recent activity
        mock_audit_store = MagicMock()
        mock_audit_store.list = AsyncMock(return_value=[])
        app.state.audit_store = mock_audit_store

    async def test_dashboard_returns_kpis(self, super_admin_user):
        with patch("canon.admin.middleware.require_super_admin", return_value=super_admin_user):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/admin/dashboard")

        assert resp.status_code == 200
        data = resp.json()
        assert data["kpis"]["orgs"] == 5
        assert data["kpis"]["active_users"] == 42
        assert len(data["health"]) == 1


class TestAdminOrgs:
    @pytest.fixture(autouse=True)
    def _setup(self, super_admin_user):
        app.state.settings = _admin_settings()
        mock_store = MagicMock()
        mock_store.list_orgs = AsyncMock(return_value=[
            {"org_login": "acme", "status": "active", "user_count": 5},
        ])
        mock_store.get_org = AsyncMock(return_value={
            "org_login": "acme", "status": "active",
        })
        app.state.admin_store = mock_store

    async def test_list_orgs(self, super_admin_user):
        with patch("canon.admin.middleware.require_super_admin", return_value=super_admin_user):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/admin/orgs")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["org_login"] == "acme"

    async def test_get_org_detail(self, super_admin_user):
        with patch("canon.admin.middleware.require_super_admin", return_value=super_admin_user):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/admin/orgs/acme")

        assert resp.status_code == 200
        assert resp.json()["org_login"] == "acme"


class TestAdminUsers:
    @pytest.fixture(autouse=True)
    def _setup(self, super_admin_user):
        app.state.settings = _admin_settings()
        mock_store = MagicMock()
        mock_store.list_users = AsyncMock(return_value=[
            {"id": 1, "email": "a@acme.com", "name": "Alice", "role": "admin"},
        ])
        mock_store.get_user = AsyncMock(return_value={
            "id": 1, "email": "a@acme.com", "name": "Alice", "role": "admin",
        })
        mock_store.update_user_role = AsyncMock(return_value=True)
        app.state.admin_store = mock_store
        mock_audit = MagicMock()
        mock_audit.log = AsyncMock()
        app.state.audit_store = mock_audit

    async def test_list_users(self, super_admin_user):
        with patch("canon.admin.middleware.require_super_admin", return_value=super_admin_user):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/admin/users")

        assert resp.status_code == 200
        assert len(resp.json()) == 1

    async def test_change_role_emits_audit(self, super_admin_user):
        with patch("canon.admin.middleware.require_super_admin", return_value=super_admin_user):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.patch(
                    "/api/admin/users/1",
                    json={"role": "editor"},
                )

        assert resp.status_code == 200
        app.state.audit_store.log.assert_awaited_once()


class TestAdminAudit:
    @pytest.fixture(autouse=True)
    def _setup(self, super_admin_user):
        app.state.settings = _admin_settings()
        mock_audit = MagicMock()
        mock_audit.list = AsyncMock(return_value=[
            {"id": "abc", "event_type": "user.role_changed", "created_at": "2026-03-31"},
        ])
        app.state.audit_store = mock_audit

    async def test_list_audit_events(self, super_admin_user):
        with patch("canon.admin.middleware.require_super_admin", return_value=super_admin_user):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/api/admin/audit")

        assert resp.status_code == 200
        assert len(resp.json()) == 1
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_admin/test_routes.py -v`
Expected: FAIL — missing route endpoints

- [ ] **Step 3: Implement all admin routes**

Replace `src/canon/admin/routes.py` with:

```python
"""Admin API routes — /api/admin/* endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel

from canon.admin.config import get_admin_config
from canon.admin.middleware import require_super_admin
from canon.auth.models import CurrentUser

router = APIRouter(prefix="/api/admin", tags=["admin"])


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@router.get("/config")
async def admin_config(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    """Return admin configuration and feature flags."""
    return get_admin_config(request.app.state.settings)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@router.get("/dashboard")
async def admin_dashboard(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    """Aggregated dashboard overview."""
    admin_store = request.app.state.admin_store
    audit_store = request.app.state.audit_store

    kpis = await admin_store.get_kpis()
    health = await admin_store.get_health_summary()
    recent = await audit_store.list(limit=20, offset=0)

    return {
        "kpis": kpis,
        "health": health,
        "recent_activity": recent,
    }


# ---------------------------------------------------------------------------
# Organizations
# ---------------------------------------------------------------------------

@router.get("/orgs")
async def list_orgs(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
    search: str | None = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0, ge=0),
):
    return await request.app.state.admin_store.list_orgs(
        limit=limit, offset=offset, search=search,
    )


@router.get("/orgs/{org}")
async def get_org(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    result = await request.app.state.admin_store.get_org(org)
    if not result:
        raise HTTPException(404, "Organization not found")
    return result


@router.post("/orgs/{org}/reindex")
async def trigger_reindex(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
):
    audit_store = request.app.state.audit_store
    await audit_store.log(
        actor_id=None,
        org=org,
        event_type="admin.reindex_triggered",
        resource_type="organization",
        resource_id=org,
    )
    return {"ok": True, "org": org}


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

@router.get("/users")
async def list_users(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
    org: str | None = Query(None),
    role: str | None = Query(None),
    search: str | None = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0, ge=0),
):
    return await request.app.state.admin_store.list_users(
        limit=limit, offset=offset, org=org, role=role, search=search,
    )


@router.get("/users/{user_id}")
async def get_user(
    user_id: int,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    result = await request.app.state.admin_store.get_user(user_id)
    if not result:
        raise HTTPException(404, "User not found")
    return result


class RoleUpdate(BaseModel):
    role: str


@router.patch("/users/{user_id}")
async def update_user(
    user_id: int,
    body: RoleUpdate,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
):
    admin_store = request.app.state.admin_store
    audit_store = request.app.state.audit_store

    existing = await admin_store.get_user(user_id)
    if not existing:
        raise HTTPException(404, "User not found")

    old_role = existing.get("role", "")
    updated = await admin_store.update_user_role(user_id, body.role)
    if not updated:
        raise HTTPException(500, "Failed to update role")

    await audit_store.log(
        actor_id=None,
        org=existing.get("org_login"),
        event_type="user.role_changed",
        resource_type="user",
        resource_id=str(user_id),
        detail={"old_role": old_role, "new_role": body.role},
    )

    return {"ok": True, "user_id": user_id, "role": body.role}


# ---------------------------------------------------------------------------
# Billing (cloud only)
# ---------------------------------------------------------------------------

@router.get("/billing")
async def list_billing(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    settings = request.app.state.settings
    if settings.deployment_mode != "cloud":
        raise HTTPException(404)
    # TODO: wire to subscriptions table when billing store is available
    return []


@router.get("/billing/{org}")
async def get_billing(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    settings = request.app.state.settings
    if settings.deployment_mode != "cloud":
        raise HTTPException(404)
    return {"org": org, "plan": "pro", "status": "active"}


# ---------------------------------------------------------------------------
# System Health
# ---------------------------------------------------------------------------

@router.get("/health")
async def health_summary(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    return await request.app.state.admin_store.get_health_summary()


# ---------------------------------------------------------------------------
# Integrations (read-only)
# ---------------------------------------------------------------------------

@router.get("/integrations")
async def list_integrations(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    # Read from integrations table when store wired
    return []


# ---------------------------------------------------------------------------
# Audit Log
# ---------------------------------------------------------------------------

@router.get("/audit")
async def list_audit(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
    org: str | None = Query(None),
    event_type: str | None = Query(None),
    actor_id: int | None = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0, ge=0),
):
    return await request.app.state.audit_store.list(
        limit=limit, offset=offset,
        org=org, event_type=event_type, actor_id=actor_id,
    )


# ---------------------------------------------------------------------------
# AI Operations
# ---------------------------------------------------------------------------

@router.get("/ai")
async def ai_overview(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    return {"total_ops_today": 0, "estimated_cost": 0.0, "orgs": []}


@router.get("/ai/{org}")
async def ai_org_detail(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
):
    return {"org": org, "ops_today": 0, "ops_this_month": 0}
```

- [ ] **Step 4: Wire AdminStore and AuditStore in main.py**

In `src/canon/main.py`, find the database pool setup section (where stores are initialized) and add:

```python
from canon.admin.store import AdminStore
from canon.admin.audit import AuditStore

# Inside the lifespan startup, after other stores:
app.state.admin_store = AdminStore(pool)
app.state.audit_store = AuditStore(pool)
```

Also add fallback for when DB is not available:

```python
# After the db pool setup block (in the else/except path):
if not hasattr(app.state, "admin_store"):
    app.state.admin_store = None
if not hasattr(app.state, "audit_store"):
    app.state.audit_store = None
```

- [ ] **Step 5: Run all admin tests**

Run: `uv run pytest tests/test_admin/ -v`
Expected: All PASS

- [ ] **Step 6: Commit**

```bash
git add src/canon/admin/routes.py src/canon/main.py tests/test_admin/test_routes.py
git commit -m "feat(admin): add dashboard, org, user, audit, and health API endpoints"
```

---

## Task 9: Create Audit Retention CronJob

**Files:**
- Create: `src/canon/cron/audit_retention.py`

- [ ] **Step 1: Implement the cron entry point**

Create `src/canon/cron/audit_retention.py`:

```python
"""CronJob: delete audit events older than retention period."""

from __future__ import annotations

import asyncio
import logging

from canon.db.pool import create_pool
from canon.admin.audit import AuditStore
from canon.settings import Settings

logger = logging.getLogger(__name__)


async def run() -> None:
    settings = Settings()
    days = settings.admin_audit_retention_days

    if not settings.database_url:
        logger.warning("No DATABASE_URL configured, skipping audit retention")
        return

    pool = await create_pool(settings.database_url)
    try:
        store = AuditStore(pool)
        deleted = await store.delete_older_than(days=days)
        logger.info("Audit retention: deleted %d events older than %d days", deleted, days)
    finally:
        await pool.close()


if __name__ == "__main__":
    asyncio.run(run())
```

- [ ] **Step 2: Verify it imports cleanly**

Run: `uv run python -c "from canon.cron.audit_retention import run; print('OK')"`
Expected: `OK`

- [ ] **Step 3: Commit**

```bash
git add src/canon/cron/audit_retention.py
git commit -m "feat(admin): add audit retention cron job"
```

---

## Task 10: Helm Chart Updates

**Files:**
- Modify: `chart/canon/values.yaml`
- Modify: `chart/canon/values-production.yaml`
- Modify: `chart/canon/templates/configmap.yaml`
- Create: `chart/canon/templates/cronjob-audit-retention.yaml`

- [ ] **Step 1: Add config values to values.yaml**

In `chart/canon/values.yaml`, add to the `config:` section:

```yaml
  deploymentMode: "development"
  adminAuditRetentionDays: "90"
```

Add a new CronJob section:

```yaml
## @section Audit retention CronJob parameters
auditRetentionCronJob:
  enabled: false
  schedule: "0 3 * * *"
  concurrencyPolicy: Forbid
```

- [ ] **Step 2: Add production overrides**

In `chart/canon/values-production.yaml`, add to the `config:` section:

```yaml
  deploymentMode: "cloud"
  adminAuditRetentionDays: "180"
```

Add:

```yaml
auditRetentionCronJob:
  enabled: true
  schedule: "0 3 * * *"
```

- [ ] **Step 3: Add env vars to configmap**

In `chart/canon/templates/configmap.yaml`, add to the `data:` section:

```yaml
  DEPLOYMENT_MODE: {{ .Values.config.deploymentMode | quote }}
  ADMIN_AUDIT_RETENTION_DAYS: {{ .Values.config.adminAuditRetentionDays | quote }}
```

- [ ] **Step 4: Create the CronJob template**

Create `chart/canon/templates/cronjob-audit-retention.yaml`:

```yaml
{{- if .Values.auditRetentionCronJob.enabled }}
apiVersion: batch/v1
kind: CronJob
metadata:
  name: {{ include "canon.fullname" . }}-audit-retention
  labels:
    {{- include "canon.labels" . | nindent 4 }}
spec:
  schedule: {{ .Values.auditRetentionCronJob.schedule | quote }}
  concurrencyPolicy: {{ .Values.auditRetentionCronJob.concurrencyPolicy }}
  jobTemplate:
    spec:
      template:
        metadata:
          labels:
            {{- include "canon.selectorLabels" . | nindent 12 }}
        spec:
          {{- with .Values.imagePullSecrets }}
          imagePullSecrets:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          serviceAccountName: {{ include "canon.serviceAccountName" . }}
          securityContext:
            {{- toYaml .Values.podSecurityContext | nindent 12 }}
          restartPolicy: OnFailure
          containers:
            - name: audit-retention
              image: {{ include "canon.image" . }}
              imagePullPolicy: {{ .Values.image.pullPolicy }}
              command: ["python", "-m", "canon.cron.audit_retention"]
              securityContext:
                {{- toYaml .Values.securityContext | nindent 16 }}
              envFrom:
                - configMapRef:
                    name: {{ include "canon.fullname" . }}
              {{- if or .Values.secrets.neon.databaseUrl .Values.secrets.neon.existingSecret }}
                - secretRef:
                    name: {{ include "canon.neonSecretName" . }}
              {{- end }}
              resources:
                {{- toYaml .Values.resources | nindent 16 }}
              volumeMounts:
                - name: tmp
                  mountPath: /tmp
          volumes:
            - name: tmp
              emptyDir: {}
{{- end }}
```

- [ ] **Step 5: Lint the Helm chart**

Run: `helm lint chart/canon/`
Expected: No errors

- [ ] **Step 6: Commit**

```bash
git add chart/canon/values.yaml chart/canon/values-production.yaml \
  chart/canon/templates/configmap.yaml chart/canon/templates/cronjob-audit-retention.yaml
git commit -m "feat(admin): add Helm config for deployment mode and audit retention"
```

---

## Task 11: Frontend Admin API Client

**Files:**
- Modify: `frontend/src/api/admin.ts`

- [ ] **Step 1: Extend the admin API client**

Replace `frontend/src/api/admin.ts`:

```typescript
import { get, post, del } from './client'

// --- Types ---

export interface AdminConfig {
  mode: 'cloud' | 'self_hosted' | 'development'
  features: {
    billing: boolean
    cross_org: boolean
    impersonation: boolean
  }
}

export interface KPIStats {
  orgs: number
  orgs_new_this_month: number
  active_users: number
  active_today: number
  specs_tracked: number
  coverage_pct: number
  system_status: string
}

export interface HealthSubsystem {
  name: string
  status: 'healthy' | 'degraded' | 'down' | 'unknown'
  detail: string
}

export interface DashboardData {
  kpis: KPIStats
  health: HealthSubsystem[]
  recent_activity: AuditEvent[]
}

export interface OrgSummary {
  org_login: string
  status: string
  user_count: number
  repos_count: number
  created_at: string | null
}

export interface UserSummary {
  id: number
  email: string
  name: string
  org_login: string
  role: string
  last_login_at: string | null
  created_at: string | null
}

export interface AuditEvent {
  id: string
  created_at: string
  actor_id: number | null
  org: string | null
  event_type: string
  resource_type: string
  resource_id: string
  detail: Record<string, unknown> | null
  ip_address: string | null
}

export interface IndexingOverview {
  installations: Array<{
    id: number
    org: string
    status: string
    repos_count: number
  }>
}

// --- Config ---

export function fetchAdminConfig(): Promise<AdminConfig> {
  return get<AdminConfig>('/api/admin/config')
}

// --- Dashboard ---

export function fetchDashboard(): Promise<DashboardData> {
  return get<DashboardData>('/api/admin/dashboard')
}

// --- Organizations ---

export function fetchOrgs(params?: { search?: string; limit?: number; offset?: number }): Promise<OrgSummary[]> {
  const qs = new URLSearchParams()
  if (params?.search) qs.set('search', params.search)
  if (params?.limit) qs.set('limit', String(params.limit))
  if (params?.offset) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return get<OrgSummary[]>(`/api/admin/orgs${query ? '?' + query : ''}`)
}

export function fetchOrg(org: string): Promise<OrgSummary> {
  return get<OrgSummary>(`/api/admin/orgs/${org}`)
}

export function triggerOrgReindex(org: string): Promise<{ ok: boolean }> {
  return post<{ ok: boolean }>(`/api/admin/orgs/${org}/reindex`)
}

// --- Users ---

export function fetchUsers(params?: {
  org?: string; role?: string; search?: string; limit?: number; offset?: number
}): Promise<UserSummary[]> {
  const qs = new URLSearchParams()
  if (params?.org) qs.set('org', params.org)
  if (params?.role) qs.set('role', params.role)
  if (params?.search) qs.set('search', params.search)
  if (params?.limit) qs.set('limit', String(params.limit))
  if (params?.offset) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return get<UserSummary[]>(`/api/admin/users${query ? '?' + query : ''}`)
}

export function fetchUser(userId: number): Promise<UserSummary> {
  return get<UserSummary>(`/api/admin/users/${userId}`)
}

export function updateUserRole(userId: number, role: string): Promise<{ ok: boolean }> {
  return post<{ ok: boolean }>(`/api/admin/users/${userId}`, { role })
}

// --- Audit ---

export function fetchAudit(params?: {
  org?: string; event_type?: string; actor_id?: number; limit?: number; offset?: number
}): Promise<AuditEvent[]> {
  const qs = new URLSearchParams()
  if (params?.org) qs.set('org', params.org)
  if (params?.event_type) qs.set('event_type', params.event_type)
  if (params?.actor_id) qs.set('actor_id', String(params.actor_id))
  if (params?.limit) qs.set('limit', String(params.limit))
  if (params?.offset) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return get<AuditEvent[]>(`/api/admin/audit${query ? '?' + query : ''}`)
}

// --- Health ---

export function fetchHealth(): Promise<HealthSubsystem[]> {
  return get<HealthSubsystem[]>('/api/admin/health')
}

// --- Billing (cloud only) ---

export function fetchBilling(): Promise<unknown[]> {
  return get<unknown[]>('/api/admin/billing')
}

// --- AI Ops ---

export function fetchAIOps(): Promise<{ total_ops_today: number; estimated_cost: number; orgs: unknown[] }> {
  return get('/api/admin/ai')
}

export function fetchAIOrg(org: string): Promise<{ org: string; ops_today: number; ops_this_month: number }> {
  return get(`/api/admin/ai/${org}`)
}

// --- Integrations (read-only) ---

export function fetchIntegrations(): Promise<unknown[]> {
  return get<unknown[]>('/api/admin/integrations')
}

// --- Legacy (kept for existing indexing admin page) ---

export function fetchIndexingOverview(): Promise<IndexingOverview> {
  return get<IndexingOverview>('/app/admin/api/indexing')
}

export function triggerReindex(installationId: number): Promise<{ ok: boolean }> {
  return post<{ ok: boolean }>(`/app/admin/api/reindex/${installationId}`)
}
```

- [ ] **Step 2: Verify it compiles**

Run: `cd frontend && npx vue-tsc --noEmit --pretty 2>&1 | head -20`
Expected: No errors in admin.ts (other pre-existing errors may appear)

- [ ] **Step 3: Commit**

```bash
git add frontend/src/api/admin.ts
git commit -m "feat(admin): extend frontend API client with all admin endpoints"
```

---

## Task 12: Frontend Admin Pinia Store

**Files:**
- Create: `frontend/src/stores/admin.ts`

- [ ] **Step 1: Create the admin store**

Create `frontend/src/stores/admin.ts`:

```typescript
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { fetchAdminConfig, type AdminConfig } from '@/api/admin'

export type AdminSection =
  | 'dashboard'
  | 'orgs'
  | 'users'
  | 'billing'
  | 'health'
  | 'integrations'
  | 'audit'
  | 'ai'

export const useAdminStore = defineStore('admin', () => {
  const config = ref<AdminConfig | null>(null)
  const activeSection = ref<AdminSection>('dashboard')
  const selectedEntityId = ref<string | null>(null)
  const configLoaded = ref(false)

  const mode = computed(() => config.value?.mode ?? 'development')
  const features = computed(() => config.value?.features ?? {
    billing: false,
    cross_org: false,
    impersonation: false,
  })
  const isCloud = computed(() => mode.value === 'cloud')

  async function loadConfig() {
    if (configLoaded.value) return
    try {
      config.value = await fetchAdminConfig()
      configLoaded.value = true
    } catch {
      // Admin config unavailable — use defaults
      configLoaded.value = true
    }
  }

  function setSection(section: AdminSection) {
    activeSection.value = section
    selectedEntityId.value = null
  }

  function selectEntity(id: string | null) {
    selectedEntityId.value = id
  }

  return {
    config,
    activeSection,
    selectedEntityId,
    configLoaded,
    mode,
    features,
    isCloud,
    loadConfig,
    setSection,
    selectEntity,
  }
})
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/stores/admin.ts
git commit -m "feat(admin): add Pinia store for admin state"
```

---

## Task 13: Frontend Admin Routes

**Files:**
- Modify: `frontend/src/router/index.ts`

- [ ] **Step 1: Add admin routes**

In `frontend/src/router/index.ts`, add these routes before the existing `admin-indexing` route:

```typescript
  // --- Admin (SUPER_ADMIN only) ---
  {
    path: '/app/admin',
    component: () => import('@/views/admin/AdminLayout.vue'),
    children: [
      {
        path: '',
        name: 'admin-dashboard',
        component: () => import('@/views/admin/AdminDashboard.vue'),
      },
      {
        path: 'orgs',
        name: 'admin-orgs',
        component: () => import('@/views/admin/AdminOrgs.vue'),
      },
      {
        path: 'orgs/:org',
        name: 'admin-org-detail',
        component: () => import('@/views/admin/AdminOrgDetail.vue'),
      },
      {
        path: 'users',
        name: 'admin-users',
        component: () => import('@/views/admin/AdminUsers.vue'),
      },
      {
        path: 'users/:id',
        name: 'admin-user-detail',
        component: () => import('@/views/admin/AdminUserDetail.vue'),
      },
      {
        path: 'billing',
        name: 'admin-billing',
        component: () => import('@/views/admin/AdminBilling.vue'),
      },
      {
        path: 'health',
        name: 'admin-health',
        component: () => import('@/views/admin/AdminHealth.vue'),
      },
      {
        path: 'integrations',
        name: 'admin-integrations',
        component: () => import('@/views/admin/AdminIntegrations.vue'),
      },
      {
        path: 'audit',
        name: 'admin-audit',
        component: () => import('@/views/admin/AdminAudit.vue'),
      },
      {
        path: 'ai',
        name: 'admin-ai',
        component: () => import('@/views/admin/AdminAI.vue'),
      },
    ],
  },
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/router/index.ts
git commit -m "feat(admin): add Vue Router routes for admin interface"
```

---

## Task 14: AdminLayout.vue — Three-Column Shell

**Files:**
- Create: `frontend/src/views/admin/AdminLayout.vue`
- Create: `frontend/src/components/admin/IconRail.vue`

- [ ] **Step 1: Create IconRail component**

Create `frontend/src/components/admin/IconRail.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAdminStore } from '@/stores/admin'

const route = useRoute()
const router = useRouter()
const admin = useAdminStore()

interface NavItem {
  key: string
  icon: string
  label: string
  route: string
  cloudOnly?: boolean
}

const items: NavItem[] = [
  { key: 'dashboard', icon: '⊞', label: 'Dashboard', route: '/app/admin' },
  { key: 'orgs', icon: '◎', label: 'Organizations', route: '/app/admin/orgs' },
  { key: 'users', icon: '♟', label: 'Users', route: '/app/admin/users' },
  { key: 'billing', icon: '$', label: 'Billing', route: '/app/admin/billing', cloudOnly: true },
  { key: 'health', icon: '♥', label: 'Health', route: '/app/admin/health' },
  { key: 'integrations', icon: '⚡', label: 'Integrations', route: '/app/admin/integrations' },
  { key: 'audit', icon: '☰', label: 'Audit', route: '/app/admin/audit' },
  { key: 'ai', icon: '✦', label: 'AI Ops', route: '/app/admin/ai' },
]

const visibleItems = computed(() =>
  items.filter(i => !i.cloudOnly || admin.features.billing),
)

const activeKey = computed(() => {
  const path = route.path
  if (path === '/app/admin' || path === '/app/admin/') return 'dashboard'
  const match = path.match(/^\/app\/admin\/([^/]+)/)
  return match ? match[1] : 'dashboard'
})

function navigate(item: NavItem) {
  router.push(item.route)
}
</script>

<template>
  <nav class="flex flex-col items-center py-2 gap-1 w-12 bg-slate-950 border-r border-slate-800">
    <button
      v-for="item in visibleItems"
      :key="item.key"
      :title="item.label"
      :class="[
        'w-8 h-8 rounded-md flex items-center justify-center text-sm transition-colors',
        activeKey === item.key
          ? 'bg-slate-800 text-red-400 ring-1 ring-red-400/50'
          : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900',
      ]"
      @click="navigate(item)"
    >
      {{ item.icon }}
    </button>
  </nav>
</template>
```

- [ ] **Step 2: Create AdminLayout**

Create `frontend/src/views/admin/AdminLayout.vue`:

```vue
<script setup lang="ts">
import { onMounted } from 'vue'
import { useAdminStore } from '@/stores/admin'
import { useAuthStore } from '@/stores/auth'
import IconRail from '@/components/admin/IconRail.vue'

const admin = useAdminStore()
const auth = useAuthStore()

onMounted(async () => {
  await admin.loadConfig()
})
</script>

<template>
  <div class="flex h-screen bg-slate-950 text-slate-100">
    <!-- Icon Rail -->
    <IconRail />

    <!-- Main area with header + content -->
    <div class="flex-1 flex flex-col min-w-0">
      <!-- Header / breadcrumb -->
      <header class="h-12 flex items-center justify-between px-4 border-b border-slate-800 bg-slate-900/50">
        <div class="flex items-center gap-2 text-sm">
          <span class="text-red-400 font-bold">◆</span>
          <span class="text-slate-500">Canon Admin</span>
        </div>
        <div class="flex items-center gap-3 text-xs">
          <span
            :class="[
              'px-2 py-0.5 rounded-full text-[10px] font-medium uppercase tracking-wider',
              admin.isCloud
                ? 'bg-blue-500/20 text-blue-400'
                : 'bg-emerald-500/20 text-emerald-400',
            ]"
          >
            {{ admin.mode }}
          </span>
          <span class="text-slate-500">{{ auth.user?.email }}</span>
        </div>
      </header>

      <!-- Page content (router-view) -->
      <main class="flex-1 overflow-auto">
        <router-view />
      </main>
    </div>
  </div>
</template>
```

- [ ] **Step 3: Commit**

```bash
git add frontend/src/views/admin/AdminLayout.vue frontend/src/components/admin/IconRail.vue
git commit -m "feat(admin): add AdminLayout shell with icon rail navigation"
```

---

## Task 15: Shared Admin Components

**Files:**
- Create: `frontend/src/components/admin/KPICard.vue`
- Create: `frontend/src/components/admin/StatusBadge.vue`

- [ ] **Step 1: Create KPICard**

Create `frontend/src/components/admin/KPICard.vue`:

```vue
<script setup lang="ts">
defineProps<{
  label: string
  value: string | number
  subtitle?: string
  color?: string
}>()
</script>

<template>
  <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
    <div class="text-[10px] font-medium uppercase tracking-wider text-slate-500 mb-1">
      {{ label }}
    </div>
    <div class="text-2xl font-bold" :class="color ?? 'text-slate-100'">
      {{ value }}
    </div>
    <div v-if="subtitle" class="text-xs text-slate-500 mt-1">
      {{ subtitle }}
    </div>
  </div>
</template>
```

- [ ] **Step 2: Create StatusBadge**

Create `frontend/src/components/admin/StatusBadge.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  status: string
}>()

const styles = computed(() => {
  switch (props.status) {
    case 'healthy':
    case 'active':
    case 'operational':
      return 'bg-emerald-500/20 text-emerald-400'
    case 'degraded':
    case 'trial':
      return 'bg-amber-500/20 text-amber-400'
    case 'down':
    case 'suspended':
    case 'error':
      return 'bg-red-500/20 text-red-400'
    default:
      return 'bg-slate-500/20 text-slate-400'
  }
})

const dot = computed(() => {
  switch (props.status) {
    case 'healthy':
    case 'active':
    case 'operational':
      return 'bg-emerald-400'
    case 'degraded':
    case 'trial':
      return 'bg-amber-400'
    case 'down':
    case 'suspended':
    case 'error':
      return 'bg-red-400'
    default:
      return 'bg-slate-400'
  }
})
</script>

<template>
  <span :class="['inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium', styles]">
    <span :class="['w-1.5 h-1.5 rounded-full', dot]" />
    {{ status }}
  </span>
</template>
```

- [ ] **Step 3: Commit**

```bash
git add frontend/src/components/admin/KPICard.vue frontend/src/components/admin/StatusBadge.vue
git commit -m "feat(admin): add KPICard and StatusBadge shared components"
```

---

## Task 16: AdminDashboard.vue

**Files:**
- Create: `frontend/src/views/admin/AdminDashboard.vue`

- [ ] **Step 1: Create the dashboard view**

Create `frontend/src/views/admin/AdminDashboard.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { fetchDashboard } from '@/api/admin'
import { useAdminStore } from '@/stores/admin'
import KPICard from '@/components/admin/KPICard.vue'
import StatusBadge from '@/components/admin/StatusBadge.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const admin = useAdminStore()

const { data, isLoading } = useQuery({
  queryKey: ['admin-dashboard'],
  queryFn: fetchDashboard,
  refetchInterval: 30_000,
})

const kpis = computed(() => data.value?.kpis)
const health = computed(() => data.value?.health ?? [])
const activity = computed(() => data.value?.recent_activity ?? [])

const orgLabel = computed(() => admin.isCloud ? 'Organizations' : 'Repositories')
</script>

<template>
  <div class="p-6 max-w-7xl mx-auto">
    <h1 class="text-xl font-bold text-slate-100 mb-6">Platform Overview</h1>

    <LoadingSpinner v-if="isLoading" />
    <template v-else-if="kpis">
      <!-- KPI Row -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPICard
          :label="orgLabel"
          :value="kpis.orgs"
          :subtitle="`${kpis.orgs_new_this_month} new this month`"
          color="text-red-400"
        />
        <KPICard
          label="Active Users"
          :value="kpis.active_users"
          :subtitle="`${kpis.active_today} active today`"
          color="text-emerald-400"
        />
        <KPICard
          label="Specs Tracked"
          :value="kpis.specs_tracked"
          :subtitle="`${kpis.coverage_pct.toFixed(1)}% coverage`"
          color="text-sky-400"
        />
        <KPICard
          label="System Status"
          :value="kpis.system_status"
          color="text-emerald-400"
        />
      </div>

      <!-- Health + Activity -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- Health Summary -->
        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <h2 class="text-xs font-medium uppercase tracking-wider text-slate-500 mb-3">
            System Health
          </h2>
          <div class="space-y-2">
            <div
              v-for="sub in health"
              :key="sub.name"
              class="flex items-center justify-between py-1"
            >
              <span class="text-sm text-slate-300">{{ sub.name }}</span>
              <StatusBadge :status="sub.status" />
            </div>
            <div v-if="health.length === 0" class="text-sm text-slate-500">
              No health data available
            </div>
          </div>
        </div>

        <!-- Recent Activity -->
        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <h2 class="text-xs font-medium uppercase tracking-wider text-slate-500 mb-3">
            Recent Activity
          </h2>
          <div class="space-y-2">
            <div
              v-for="event in activity.slice(0, 10)"
              :key="event.id"
              class="flex items-center justify-between py-1 text-sm"
            >
              <span class="text-slate-300 truncate mr-2">{{ event.event_type }}</span>
              <span class="text-slate-500 text-xs shrink-0">{{ event.org ?? '' }}</span>
            </div>
            <div v-if="activity.length === 0" class="text-sm text-slate-500">
              No recent activity
            </div>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/views/admin/AdminDashboard.vue
git commit -m "feat(admin): add AdminDashboard view with KPIs and health summary"
```

---

## Task 17: Remaining Admin Views (Stub Implementations)

Create working stub views for all remaining sections. Each follows the same pattern: Vue Query for data fetching, conditional rendering, Tailwind layout. These are functional but minimal — they fetch real data and display it in tables/lists.

**Files:**
- Create all remaining views in `frontend/src/views/admin/`

- [ ] **Step 1: Create AdminOrgs.vue**

Create `frontend/src/views/admin/AdminOrgs.vue`:

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { useRouter } from 'vue-router'
import { fetchOrgs } from '@/api/admin'
import StatusBadge from '@/components/admin/StatusBadge.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const router = useRouter()
const search = ref('')

const { data: orgs, isLoading } = useQuery({
  queryKey: computed(() => ['admin-orgs', search.value]),
  queryFn: () => fetchOrgs({ search: search.value || undefined }),
  refetchInterval: 60_000,
})

function selectOrg(org: string) {
  router.push(`/app/admin/orgs/${org}`)
}
</script>

<template>
  <div class="p-6 max-w-7xl mx-auto">
    <h1 class="text-xl font-bold text-slate-100 mb-4">Organizations</h1>
    <input
      v-model="search"
      placeholder="Search organizations..."
      class="w-full mb-4 px-3 py-2 bg-slate-900 border border-slate-700 rounded-md text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-red-400"
    />
    <LoadingSpinner v-if="isLoading" />
    <div v-else class="space-y-2">
      <button
        v-for="org in orgs"
        :key="org.org_login"
        class="w-full flex items-center justify-between p-3 bg-slate-900 border border-slate-800 rounded-lg hover:border-slate-700 transition-colors text-left"
        @click="selectOrg(org.org_login)"
      >
        <div>
          <div class="text-sm font-medium text-slate-100">{{ org.org_login }}</div>
          <div class="text-xs text-slate-500">{{ org.user_count ?? 0 }} users · {{ org.repos_count ?? 0 }} repos</div>
        </div>
        <StatusBadge :status="org.status" />
      </button>
      <div v-if="orgs?.length === 0" class="text-sm text-slate-500 text-center py-8">
        No organizations found
      </div>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Create AdminOrgDetail.vue**

Create `frontend/src/views/admin/AdminOrgDetail.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useQuery, useQueryClient } from '@tanstack/vue-query'
import { fetchOrg, triggerOrgReindex } from '@/api/admin'
import StatusBadge from '@/components/admin/StatusBadge.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const route = useRoute()
const queryClient = useQueryClient()
const org = computed(() => route.params.org as string)

const { data, isLoading } = useQuery({
  queryKey: computed(() => ['admin-org', org.value]),
  queryFn: () => fetchOrg(org.value),
})

async function handleReindex() {
  await triggerOrgReindex(org.value)
  queryClient.invalidateQueries({ queryKey: ['admin-org', org.value] })
}
</script>

<template>
  <div class="p-6 max-w-5xl mx-auto">
    <LoadingSpinner v-if="isLoading" />
    <template v-else-if="data">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h1 class="text-xl font-bold text-slate-100">{{ data.org_login }}</h1>
          <div class="text-sm text-slate-500 mt-1">
            <StatusBadge :status="data.status" />
          </div>
        </div>
        <button
          class="px-3 py-1.5 bg-red-500/20 text-red-400 rounded-md text-sm hover:bg-red-500/30 transition-colors"
          @click="handleReindex"
        >
          Trigger Reindex
        </button>
      </div>
    </template>
  </div>
</template>
```

- [ ] **Step 3: Create AdminUsers.vue**

Create `frontend/src/views/admin/AdminUsers.vue`:

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { useRouter } from 'vue-router'
import { fetchUsers } from '@/api/admin'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const router = useRouter()
const search = ref('')

const { data: users, isLoading } = useQuery({
  queryKey: computed(() => ['admin-users', search.value]),
  queryFn: () => fetchUsers({ search: search.value || undefined }),
  refetchInterval: 60_000,
})

function selectUser(id: number) {
  router.push(`/app/admin/users/${id}`)
}
</script>

<template>
  <div class="p-6 max-w-7xl mx-auto">
    <h1 class="text-xl font-bold text-slate-100 mb-4">Users</h1>
    <input
      v-model="search"
      placeholder="Search by name or email..."
      class="w-full mb-4 px-3 py-2 bg-slate-900 border border-slate-700 rounded-md text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-red-400"
    />
    <LoadingSpinner v-if="isLoading" />
    <div v-else class="space-y-2">
      <button
        v-for="user in users"
        :key="user.id"
        class="w-full flex items-center justify-between p-3 bg-slate-900 border border-slate-800 rounded-lg hover:border-slate-700 transition-colors text-left"
        @click="selectUser(user.id)"
      >
        <div>
          <div class="text-sm font-medium text-slate-100">{{ user.name || user.email }}</div>
          <div class="text-xs text-slate-500">{{ user.email }} · {{ user.org_login }}</div>
        </div>
        <span class="text-xs text-slate-500 bg-slate-800 px-2 py-0.5 rounded">{{ user.role }}</span>
      </button>
    </div>
  </div>
</template>
```

- [ ] **Step 4: Create AdminUserDetail.vue**

Create `frontend/src/views/admin/AdminUserDetail.vue`:

```vue
<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRoute } from 'vue-router'
import { useQuery, useQueryClient } from '@tanstack/vue-query'
import { fetchUser, updateUserRole } from '@/api/admin'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const route = useRoute()
const queryClient = useQueryClient()
const userId = computed(() => Number(route.params.id))
const newRole = ref('')

const { data, isLoading } = useQuery({
  queryKey: computed(() => ['admin-user', userId.value]),
  queryFn: () => fetchUser(userId.value),
})

async function handleRoleChange() {
  if (!newRole.value) return
  await updateUserRole(userId.value, newRole.value)
  queryClient.invalidateQueries({ queryKey: ['admin-user', userId.value] })
  newRole.value = ''
}
</script>

<template>
  <div class="p-6 max-w-5xl mx-auto">
    <LoadingSpinner v-if="isLoading" />
    <template v-else-if="data">
      <h1 class="text-xl font-bold text-slate-100 mb-2">{{ data.name || data.email }}</h1>
      <div class="text-sm text-slate-500 mb-6">{{ data.email }} · {{ data.org_login }} · {{ data.role }}</div>

      <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
        <h2 class="text-xs font-medium uppercase tracking-wider text-slate-500 mb-3">Change Role</h2>
        <div class="flex gap-2">
          <select
            v-model="newRole"
            class="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-md text-sm text-slate-100"
          >
            <option value="">Select role...</option>
            <option value="viewer">Viewer</option>
            <option value="editor">Editor</option>
            <option value="admin">Admin</option>
            <option value="super_admin">Super Admin</option>
          </select>
          <button
            :disabled="!newRole"
            class="px-4 py-2 bg-red-500/20 text-red-400 rounded-md text-sm hover:bg-red-500/30 disabled:opacity-50 transition-colors"
            @click="handleRoleChange"
          >
            Update
          </button>
        </div>
      </div>
    </template>
  </div>
</template>
```

- [ ] **Step 5: Create remaining stub views**

Create `frontend/src/views/admin/AdminBilling.vue`:

```vue
<script setup lang="ts">
import { useQuery } from '@tanstack/vue-query'
import { fetchBilling } from '@/api/admin'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const { data, isLoading } = useQuery({
  queryKey: ['admin-billing'],
  queryFn: fetchBilling,
})
</script>

<template>
  <div class="p-6 max-w-7xl mx-auto">
    <h1 class="text-xl font-bold text-slate-100 mb-4">Billing</h1>
    <LoadingSpinner v-if="isLoading" />
    <div v-else-if="data?.length === 0" class="text-sm text-slate-500 text-center py-12">
      No billing data available
    </div>
  </div>
</template>
```

Create `frontend/src/views/admin/AdminHealth.vue`:

```vue
<script setup lang="ts">
import { useQuery } from '@tanstack/vue-query'
import { fetchHealth } from '@/api/admin'
import StatusBadge from '@/components/admin/StatusBadge.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const { data: subsystems, isLoading } = useQuery({
  queryKey: ['admin-health'],
  queryFn: fetchHealth,
  refetchInterval: 30_000,
})
</script>

<template>
  <div class="p-6 max-w-7xl mx-auto">
    <h1 class="text-xl font-bold text-slate-100 mb-4">System Health</h1>
    <LoadingSpinner v-if="isLoading" />
    <div v-else class="space-y-2">
      <div
        v-for="sub in subsystems"
        :key="sub.name"
        class="flex items-center justify-between p-4 bg-slate-900 border border-slate-800 rounded-lg"
      >
        <div>
          <div class="text-sm font-medium text-slate-100">{{ sub.name }}</div>
          <div class="text-xs text-slate-500 mt-1">{{ sub.detail }}</div>
        </div>
        <StatusBadge :status="sub.status" />
      </div>
    </div>
  </div>
</template>
```

Create `frontend/src/views/admin/AdminIntegrations.vue`:

```vue
<script setup lang="ts">
import { useQuery } from '@tanstack/vue-query'
import { fetchIntegrations } from '@/api/admin'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const { data, isLoading } = useQuery({
  queryKey: ['admin-integrations'],
  queryFn: fetchIntegrations,
})
</script>

<template>
  <div class="p-6 max-w-7xl mx-auto">
    <h1 class="text-xl font-bold text-slate-100 mb-4">Integrations</h1>
    <LoadingSpinner v-if="isLoading" />
    <div v-else-if="data?.length === 0" class="text-sm text-slate-500 text-center py-12">
      No integrations configured
    </div>
  </div>
</template>
```

Create `frontend/src/views/admin/AdminAudit.vue`:

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useQuery } from '@tanstack/vue-query'
import { fetchAudit } from '@/api/admin'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const orgFilter = ref('')
const typeFilter = ref('')

const { data: events, isLoading } = useQuery({
  queryKey: computed(() => ['admin-audit', orgFilter.value, typeFilter.value]),
  queryFn: () => fetchAudit({
    org: orgFilter.value || undefined,
    event_type: typeFilter.value || undefined,
  }),
  refetchInterval: 30_000,
})
</script>

<template>
  <div class="p-6 max-w-7xl mx-auto">
    <h1 class="text-xl font-bold text-slate-100 mb-4">Audit Log</h1>
    <div class="flex gap-2 mb-4">
      <input
        v-model="orgFilter"
        placeholder="Filter by org..."
        class="px-3 py-2 bg-slate-900 border border-slate-700 rounded-md text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-red-400"
      />
      <input
        v-model="typeFilter"
        placeholder="Filter by event type..."
        class="px-3 py-2 bg-slate-900 border border-slate-700 rounded-md text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-red-400"
      />
    </div>
    <LoadingSpinner v-if="isLoading" />
    <div v-else class="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
      <table class="w-full text-sm">
        <thead>
          <tr class="border-b border-slate-800 text-left">
            <th class="px-4 py-2 text-xs font-medium uppercase text-slate-500">Time</th>
            <th class="px-4 py-2 text-xs font-medium uppercase text-slate-500">Event</th>
            <th class="px-4 py-2 text-xs font-medium uppercase text-slate-500">Org</th>
            <th class="px-4 py-2 text-xs font-medium uppercase text-slate-500">Resource</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="event in events"
            :key="event.id"
            class="border-b border-slate-800/50 hover:bg-slate-800/30"
          >
            <td class="px-4 py-2 text-slate-400 text-xs font-mono">{{ event.created_at }}</td>
            <td class="px-4 py-2 text-slate-300">{{ event.event_type }}</td>
            <td class="px-4 py-2 text-slate-400">{{ event.org ?? '—' }}</td>
            <td class="px-4 py-2 text-slate-400">{{ event.resource_type }}:{{ event.resource_id }}</td>
          </tr>
        </tbody>
      </table>
      <div v-if="events?.length === 0" class="text-sm text-slate-500 text-center py-8">
        No audit events found
      </div>
    </div>
  </div>
</template>
```

Create `frontend/src/views/admin/AdminAI.vue`:

```vue
<script setup lang="ts">
import { useQuery } from '@tanstack/vue-query'
import { fetchAIOps } from '@/api/admin'
import KPICard from '@/components/admin/KPICard.vue'
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'

const { data, isLoading } = useQuery({
  queryKey: ['admin-ai'],
  queryFn: fetchAIOps,
  refetchInterval: 60_000,
})
</script>

<template>
  <div class="p-6 max-w-7xl mx-auto">
    <h1 class="text-xl font-bold text-slate-100 mb-4">AI Operations</h1>
    <LoadingSpinner v-if="isLoading" />
    <template v-else-if="data">
      <div class="grid grid-cols-2 gap-4 mb-6">
        <KPICard label="Ops Today" :value="data.total_ops_today" color="text-sky-400" />
        <KPICard label="Estimated Cost" :value="'$' + data.estimated_cost.toFixed(2)" color="text-amber-400" />
      </div>
    </template>
  </div>
</template>
```

Create empty `frontend/src/views/admin/AdminHealthDetail.vue`:

```vue
<script setup lang="ts">
</script>

<template>
  <div class="p-6">
    <p class="text-sm text-slate-500">Subsystem detail view — select a subsystem from the health page.</p>
  </div>
</template>
```

- [ ] **Step 6: Verify frontend builds**

Run: `cd frontend && npx vue-tsc --noEmit 2>&1 | tail -5`
Expected: No new type errors in admin files

- [ ] **Step 7: Commit**

```bash
git add frontend/src/views/admin/ frontend/src/components/admin/
git commit -m "feat(admin): add all admin views — dashboard, orgs, users, billing, health, integrations, audit, AI ops"
```

---

## Task 18: Final Integration — Run Full Test Suite

- [ ] **Step 1: Run all backend tests**

Run: `uv run pytest -v 2>&1 | tail -30`
Expected: All tests pass, no regressions

- [ ] **Step 2: Run linter**

Run: `uv run ruff check src/canon/admin/`
Expected: No lint errors

- [ ] **Step 3: Run frontend type check**

Run: `cd frontend && npx vue-tsc --noEmit 2>&1 | tail -10`
Expected: No new errors

- [ ] **Step 4: Verify Helm lint**

Run: `helm lint chart/canon/ 2>&1`
Expected: No errors

- [ ] **Step 5: Final commit if any fixes needed**

```bash
git add -A
git commit -m "fix(admin): resolve lint and type-check issues"
```

---

## Summary

| Task | Description | Files |
|------|-------------|-------|
| 1 | SUPER_ADMIN role + PLATFORM_MANAGE permission | permissions.py, test_models.py |
| 2 | DEPLOYMENT_MODE setting | settings.py, test_config.py |
| 3 | audit_events migration | 0005_audit_events.py |
| 4 | AuditStore | admin/audit.py, test_audit_store.py |
| 5 | Admin middleware | admin/middleware.py, test_middleware.py |
| 6 | Config endpoint + models + route registration | admin/config.py, models.py, routes.py, main.py |
| 7 | AdminStore (cross-org queries) | admin/store.py, test_admin_store.py |
| 8 | All API endpoints + main.py wiring | admin/routes.py, test_routes.py, main.py |
| 9 | Audit retention CronJob | cron/audit_retention.py |
| 10 | Helm chart updates | values.yaml, configmap.yaml, cronjob template |
| 11 | Frontend API client | api/admin.ts |
| 12 | Frontend Pinia store | stores/admin.ts |
| 13 | Frontend routes | router/index.ts |
| 14 | AdminLayout + IconRail | AdminLayout.vue, IconRail.vue |
| 15 | Shared components | KPICard.vue, StatusBadge.vue |
| 16 | AdminDashboard view | AdminDashboard.vue |
| 17 | All remaining admin views | 10 Vue files |
| 18 | Final integration tests | full test suite |
