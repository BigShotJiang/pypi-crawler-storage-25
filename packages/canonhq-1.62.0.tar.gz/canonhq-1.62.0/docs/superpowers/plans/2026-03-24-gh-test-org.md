# GitHub Test Org Setup — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Create a GitHub test org with demo repos that exercise Canon's full integration surface — onboarding, push sync, PR analysis, merge doc updates, reverse sync, and @canon commands.

**Architecture:** A single shell script (`scripts/setup-test-org.sh`) creates a GitHub org, 3 repos with realistic content, and prepares test branches. The script is idempotent (skips existing repos), templates the org name into all config/spec files, and prints a test playbook at the end.

**Tech Stack:** `gh` CLI, bash, git

---

## File Structure

| File | Purpose |
|------|---------|
| `scripts/setup-test-org.sh` | Main setup script — creates org, repos, populates content |
| `scripts/teardown-test-org.sh` | Cleanup script — deletes repos and org |
| `scripts/test-org-content/` | Directory containing template files for demo repos |
| `scripts/test-org-content/demo-backend/` | Backend repo template files |
| `scripts/test-org-content/demo-frontend/` | Frontend repo template files |
| `scripts/test-org-content/demo-docs/` | Docs repo template files |

## Repo Design

### demo-backend (has existing specs + source code)

Tests: onboarding summary issue, push sync (ticket creation), PR analysis (realizations), merge doc updates, reverse sync, @canon commands

**Content:**
- `CANON.yaml` — GitHub Issues as ticket system, auto_tickets enabled
- `docs/specs/auth.md` — Authentication spec with 3 sections, ACs in todo/in_progress states
- `docs/specs/api-design.md` — API design spec with 2 sections, ACs in draft state
- `src/auth.py` — Partial auth implementation (matches some ACs in auth spec)
- `src/api.py` — API routes (matches some ACs in api-design spec)
- `README.md` — Project overview
- Test branch `feat/add-oauth` with changes to `src/auth.py` that realize spec ACs

### demo-frontend (no specs — triggers setup PR)

Tests: onboarding setup PR, fresh spec creation, ticket auto-creation on first push

**Content:**
- `src/App.tsx` — Simple React component
- `src/index.tsx` — Entry point
- `package.json` — Project manifest
- `README.md` — Project overview
- No CANON.yaml, no specs (triggers full onboarding)

### demo-docs (custom config + non-standard paths)

Tests: custom CANON.yaml config, non-standard doc_paths, CANON.yaml diagnostics

**Content:**
- `CANON.yaml` — Custom doc_paths pointing to `specifications/**/*.md`
- `specifications/platform/data-model.md` — Spec in non-standard location
- `specifications/platform/api-contract.md` — Another spec
- `README.md` — Project overview

---

### Task 1: Create the template content directory structure

**Files:**
- Create: `scripts/test-org-content/demo-backend/CANON.yaml`
- Create: `scripts/test-org-content/demo-backend/docs/specs/auth.md`
- Create: `scripts/test-org-content/demo-backend/docs/specs/api-design.md`
- Create: `scripts/test-org-content/demo-backend/src/auth.py`
- Create: `scripts/test-org-content/demo-backend/src/api.py`
- Create: `scripts/test-org-content/demo-backend/README.md`

- [ ] **Step 1: Create demo-backend directory structure**

```bash
mkdir -p scripts/test-org-content/demo-backend/{docs/specs,src}
```

- [ ] **Step 2: Create demo-backend CANON.yaml**

```yaml
# Canon configuration — https://canonhq.co/docs/config
team: test-org

ticket_systems:
  primary:
    system: github
    project: "__ORG__/demo-backend"
    status_map:
      forward:
        draft: "Backlog"
        todo: "To Do"
        in_progress: "In Progress"
        done: "Done"
        blocked: "Blocked"
        deprecated: "Won't Do"

specs:
  auto_tickets: true
  require_review: false
  lifecycle_sync: true
  doc_paths:
    - "docs/specs/*.md"

agents:
  doc_updates: true
  pr_analysis: true
  stale_detection: "30d"
  realization_check: true
```

> **Note:** `__ORG__` is a placeholder. The setup script substitutes it with the actual org name.

- [ ] **Step 3: Create auth spec with mixed statuses**

File: `scripts/test-org-content/demo-backend/docs/specs/auth.md`

```markdown
---
title: "Authentication System"
status: in_progress
owner: test-user
team: test-org
ticket_project: "__ORG__/demo-backend"
created: 2026-03-24
updated: 2026-03-24
tags: [auth, security]
---

# Authentication System

This spec covers the authentication and authorization system for the demo backend service.

## 1. Background

The backend needs secure authentication supporting multiple providers (email/password, OAuth) with session management and role-based access control.

## 2. Session Management

<!-- canon:system:2 status:in_progress -->

### Acceptance Criteria

- [ ] Users can log in with email and password
- [ ] Login returns a JWT access token with 15-minute expiry
- [ ] Refresh tokens are stored server-side with 7-day expiry
- [ ] Invalid credentials return 401 with a generic error message

## 3. OAuth Integration

<!-- canon:system:3 status:todo -->

### Acceptance Criteria

- [ ] Users can authenticate via GitHub OAuth
- [ ] Users can authenticate via Google OAuth
- [ ] First-time OAuth users get an account auto-created
- [ ] OAuth tokens are encrypted at rest

## 4. Role-Based Access Control

<!-- canon:system:4 status:draft -->

### Acceptance Criteria

- [ ] Three roles exist: viewer, editor, admin
- [ ] Viewers can read all resources
- [ ] Editors can create and modify resources they own
- [ ] Admins can manage users and all resources
```

- [ ] **Step 4: Create api-design spec**

File: `scripts/test-org-content/demo-backend/docs/specs/api-design.md`

```markdown
---
title: "API Design"
status: draft
owner: test-user
team: test-org
ticket_project: "__ORG__/demo-backend"
created: 2026-03-24
updated: 2026-03-24
tags: [api, rest]
---

# API Design

RESTful API conventions and endpoint specifications for the demo backend.

## 1. REST Conventions

<!-- canon:system:1 status:draft -->

### Acceptance Criteria

- [ ] All endpoints follow REST naming conventions (plural nouns, no verbs)
- [ ] Responses use consistent JSON envelope: `{ data, error, meta }`
- [ ] Pagination uses cursor-based approach with `?cursor=` and `?limit=`
- [ ] Error responses include error code, message, and request ID

## 2. Health and Monitoring

<!-- canon:system:2 status:todo -->

### Acceptance Criteria

- [ ] GET /health returns 200 with service status
- [ ] GET /health includes database connectivity check
- [ ] GET /metrics returns Prometheus-compatible metrics
```

- [ ] **Step 5: Create source files that partially implement specs**

File: `scripts/test-org-content/demo-backend/src/auth.py`

```python
"""Authentication module — session management and JWT handling."""

from datetime import datetime, timedelta
from typing import Optional

# JWT token configuration
ACCESS_TOKEN_EXPIRY = timedelta(minutes=15)
REFRESH_TOKEN_EXPIRY = timedelta(days=7)


def login(email: str, password: str) -> dict:
    """Authenticate user with email and password.

    Returns JWT access token and refresh token on success.
    Returns 401 error dict on failure.
    """
    user = _find_user_by_email(email)
    if not user or not _verify_password(password, user["password_hash"]):
        return {"error": "Invalid credentials", "status": 401}

    access_token = _create_jwt(user["id"], ACCESS_TOKEN_EXPIRY)
    refresh_token = _create_refresh_token(user["id"], REFRESH_TOKEN_EXPIRY)

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": int(ACCESS_TOKEN_EXPIRY.total_seconds()),
    }


def _create_jwt(user_id: str, expiry: timedelta) -> str:
    """Create a signed JWT token."""
    # TODO: implement actual JWT signing
    return f"jwt.{user_id}.{datetime.utcnow().isoformat()}"


def _create_refresh_token(user_id: str, expiry: timedelta) -> str:
    """Create and store a refresh token."""
    # TODO: implement server-side storage
    return f"refresh.{user_id}.{datetime.utcnow().isoformat()}"


def _find_user_by_email(email: str) -> Optional[dict]:
    """Look up user by email address."""
    # TODO: implement database lookup
    return None


def _verify_password(password: str, password_hash: str) -> bool:
    """Verify password against stored hash."""
    # TODO: implement bcrypt verification
    return False
```

File: `scripts/test-org-content/demo-backend/src/api.py`

```python
"""API routes — RESTful endpoints for the demo backend."""


def health_check() -> dict:
    """GET /health — returns service status."""
    return {
        "data": {
            "status": "healthy",
            "version": "0.1.0",
        },
        "error": None,
        "meta": {"request_id": "stub"},
    }


def list_users(cursor: str = "", limit: int = 20) -> dict:
    """GET /users — list users with cursor pagination."""
    return {
        "data": [],
        "error": None,
        "meta": {
            "cursor": cursor,
            "limit": limit,
            "has_more": False,
        },
    }
```

File: `scripts/test-org-content/demo-backend/README.md`

```markdown
# Demo Backend

A sample Python backend service used for testing Canon integrations.

## Features

- JWT authentication with email/password login
- OAuth integration (GitHub, Google)
- RESTful API with cursor pagination
- Role-based access control

## Getting Started

```bash
pip install -r requirements.txt
python -m src.api
```
```

- [ ] **Step 6: Commit template content**

```bash
git add scripts/test-org-content/demo-backend/
git commit -m "feat: add demo-backend template content for test org"
```

---

### Task 2: Create demo-frontend and demo-docs template content

**Files:**
- Create: `scripts/test-org-content/demo-frontend/src/App.tsx`
- Create: `scripts/test-org-content/demo-frontend/src/index.tsx`
- Create: `scripts/test-org-content/demo-frontend/package.json`
- Create: `scripts/test-org-content/demo-frontend/README.md`
- Create: `scripts/test-org-content/demo-docs/CANON.yaml`
- Create: `scripts/test-org-content/demo-docs/specifications/platform/data-model.md`
- Create: `scripts/test-org-content/demo-docs/specifications/platform/api-contract.md`
- Create: `scripts/test-org-content/demo-docs/README.md`

- [ ] **Step 1: Create demo-frontend directory structure and files**

```bash
mkdir -p scripts/test-org-content/demo-frontend/src
```

File: `scripts/test-org-content/demo-frontend/package.json`

```json
{
  "name": "demo-frontend",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  }
}
```

File: `scripts/test-org-content/demo-frontend/src/App.tsx`

```tsx
import { useState } from "react";

export default function App() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h1>Demo Frontend</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
    </div>
  );
}
```

File: `scripts/test-org-content/demo-frontend/src/index.tsx`

```tsx
import { createRoot } from "react-dom/client";
import App from "./App";

const root = createRoot(document.getElementById("root")!);
root.render(<App />);
```

File: `scripts/test-org-content/demo-frontend/README.md`

```markdown
# Demo Frontend

A sample React frontend used for testing Canon integrations.

This repo has no specs or CANON.yaml — Canon's onboarding will create a setup PR with starter files.
```

- [ ] **Step 2: Create demo-docs directory structure and files**

```bash
mkdir -p scripts/test-org-content/demo-docs/specifications/platform
```

File: `scripts/test-org-content/demo-docs/CANON.yaml`

```yaml
# Canon configuration — custom doc_paths example
team: test-org

ticket_systems:
  primary:
    system: github
    project: "__ORG__/demo-docs"

specs:
  auto_tickets: true
  require_review: false
  doc_paths:
    - "specifications/**/*.md"

agents:
  doc_updates: true
  pr_analysis: true
```

File: `scripts/test-org-content/demo-docs/specifications/platform/data-model.md`

```markdown
---
title: "Data Model"
status: draft
owner: test-user
team: test-org
ticket_project: "__ORG__/demo-docs"
created: 2026-03-24
updated: 2026-03-24
tags: [data, architecture]
---

# Data Model

Core data model for the platform.

## 1. Entity Design

<!-- canon:system:1 status:todo -->

### Acceptance Criteria

- [ ] All entities have UUID primary keys
- [ ] Timestamps use ISO 8601 with timezone
- [ ] Soft deletes via `deleted_at` column
- [ ] Audit trail tracks who changed what and when
```

File: `scripts/test-org-content/demo-docs/specifications/platform/api-contract.md`

```markdown
---
title: "API Contract"
status: draft
owner: test-user
team: test-org
ticket_project: "__ORG__/demo-docs"
created: 2026-03-24
updated: 2026-03-24
tags: [api, contract]
---

# API Contract

External API contract and versioning strategy.

## 1. Versioning

<!-- canon:system:1 status:draft -->

### Acceptance Criteria

- [ ] API uses URL-based versioning (e.g., /v1/resources)
- [ ] Breaking changes require a new major version
- [ ] Old versions are supported for at least 6 months after deprecation
```

File: `scripts/test-org-content/demo-docs/README.md`

```markdown
# Demo Docs

A documentation-heavy repository used for testing Canon's custom `doc_paths` configuration.

Specs live in `specifications/` instead of the default `docs/specs/`.
```

- [ ] **Step 3: Commit template content**

```bash
git add scripts/test-org-content/demo-frontend/ scripts/test-org-content/demo-docs/
git commit -m "feat: add demo-frontend and demo-docs template content"
```

---

### Task 3: Write the setup script

**Files:**
- Create: `scripts/setup-test-org.sh`

- [ ] **Step 1: Write the setup script**

File: `scripts/setup-test-org.sh`

The script should:

1. Accept `ORG_NAME` as first argument (default: `canon-test-org`)
2. Validate `gh` CLI is authenticated
3. Try to create the org via API; if it fails, print the manual URL and wait for user confirmation
4. Create each repo if it doesn't already exist
5. For each repo: clone to a temp dir, copy template content, commit, push
6. For demo-backend: create a `feat/add-oauth` branch with changes to `src/auth.py` that implement OAuth stubs, then open a draft PR
7. Print a test playbook at the end

```bash
#!/usr/bin/env bash
set -euo pipefail

# --- Configuration ---
ORG="${1:-canon-test-org}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONTENT_DIR="$SCRIPT_DIR/test-org-content"
TMPDIR_BASE="$(mktemp -d)"
REPOS=("demo-backend" "demo-frontend" "demo-docs")

trap 'rm -rf "$TMPDIR_BASE"' EXIT

echo "=== Canon Test Org Setup ==="
echo "Org: $ORG"
echo ""

# --- Verify gh CLI ---
if ! gh auth status &>/dev/null; then
  echo "ERROR: gh CLI not authenticated. Run 'gh auth login' first."
  exit 1
fi

# --- Create Org ---
echo "--- Step 1: Organization ---"
if gh api "/orgs/$ORG" &>/dev/null 2>&1; then
  echo "Org '$ORG' already exists. Continuing."
else
  echo "Org '$ORG' not found."
  echo ""
  echo "GitHub doesn't support creating free orgs via API."
  echo "Please create it manually:"
  echo "  https://github.com/organizations/plan"
  echo ""
  echo "Use name: $ORG"
  echo ""
  read -rp "Press Enter once the org is created (or Ctrl+C to abort)..."

  if ! gh api "/orgs/$ORG" &>/dev/null 2>&1; then
    echo "ERROR: Org '$ORG' still not found. Please create it and re-run."
    exit 1
  fi
  echo "Org '$ORG' found."
fi
echo ""

# --- Create Repos ---
echo "--- Step 2: Repositories ---"
for REPO in "${REPOS[@]}"; do
  FULL="$ORG/$REPO"
  if gh repo view "$FULL" &>/dev/null 2>&1; then
    echo "Repo '$FULL' already exists. Skipping."
    continue
  fi

  echo "Creating repo: $FULL"
  gh repo create "$FULL" \
    --public \
    --description "Canon integration test repo" \
    --clone=false

  # Clone, populate, push
  CLONE_DIR="$TMPDIR_BASE/$REPO"
  gh repo clone "$FULL" "$CLONE_DIR" -- --quiet 2>/dev/null || \
    git clone "https://github.com/$FULL.git" "$CLONE_DIR" --quiet

  # Copy template content and substitute org name
  if [ -d "$CONTENT_DIR/$REPO" ]; then
    cp -r "$CONTENT_DIR/$REPO/"* "$CLONE_DIR/" 2>/dev/null || true
    cp -r "$CONTENT_DIR/$REPO/".[!.]* "$CLONE_DIR/" 2>/dev/null || true
    # Replace __ORG__ placeholder with actual org name in all text files
    find "$CLONE_DIR" -type f \( -name "*.yaml" -o -name "*.md" \) \
      -exec sed -i "s|__ORG__|$ORG|g" {} +
  fi

  # Initial commit + push
  cd "$CLONE_DIR"
  git add -A
  git commit -m "chore: initial setup for Canon integration testing" --quiet
  git branch -M main
  git push origin main --quiet
  cd -
  echo "  Pushed initial content to $FULL"
done
echo ""

# --- Create test branch + PR for demo-backend ---
echo "--- Step 3: Test PR for demo-backend ---"
BACKEND_FULL="$ORG/demo-backend"
BACKEND_DIR="$TMPDIR_BASE/demo-backend"

# Clone fresh if not already cloned
if [ ! -d "$BACKEND_DIR" ]; then
  gh repo clone "$BACKEND_FULL" "$BACKEND_DIR" -- --quiet 2>/dev/null || \
    git clone "https://github.com/$BACKEND_FULL.git" "$BACKEND_DIR" --quiet
fi

cd "$BACKEND_DIR"

# Check if branch already exists on remote
if git ls-remote --heads origin feat/add-oauth | grep -q feat/add-oauth; then
  echo "Branch feat/add-oauth already exists. Skipping PR creation."
else
  git checkout -b feat/add-oauth

  # Add OAuth stubs that realize spec ACs
  cat > src/oauth.py << 'PYEOF'
"""OAuth integration — GitHub and Google providers."""

from typing import Optional


def github_oauth_callback(code: str) -> dict:
    """Handle GitHub OAuth callback.

    Exchanges authorization code for access token,
    fetches user profile, and creates/links account.
    """
    token = _exchange_github_code(code)
    profile = _fetch_github_profile(token)

    user = _find_or_create_user(
        provider="github",
        provider_id=profile["id"],
        email=profile["email"],
        name=profile["name"],
    )

    return {"user": user, "access_token": _create_session(user["id"])}


def google_oauth_callback(code: str) -> dict:
    """Handle Google OAuth callback.

    Exchanges authorization code for access token,
    fetches user profile, and creates/links account.
    """
    token = _exchange_google_code(code)
    profile = _fetch_google_profile(token)

    user = _find_or_create_user(
        provider="google",
        provider_id=profile["sub"],
        email=profile["email"],
        name=profile["name"],
    )

    return {"user": user, "access_token": _create_session(user["id"])}


def _exchange_github_code(code: str) -> str:
    """Exchange GitHub OAuth code for access token."""
    # TODO: implement with httpx
    return f"ghp_{code}"


def _exchange_google_code(code: str) -> str:
    """Exchange Google OAuth code for access token."""
    # TODO: implement with httpx
    return f"goog_{code}"


def _fetch_github_profile(token: str) -> dict:
    """Fetch GitHub user profile."""
    # TODO: implement
    return {"id": "gh-123", "email": "user@example.com", "name": "Test User"}


def _fetch_google_profile(token: str) -> dict:
    """Fetch Google user profile."""
    # TODO: implement
    return {"sub": "goog-456", "email": "user@example.com", "name": "Test User"}


def _find_or_create_user(
    provider: str, provider_id: str, email: str, name: str
) -> dict:
    """Find existing user by OAuth provider or create new account."""
    # Auto-create account for first-time OAuth users
    return {
        "id": f"user-{provider}-{provider_id}",
        "email": email,
        "name": name,
        "provider": provider,
    }


def _create_session(user_id: str) -> str:
    """Create a new session for the user."""
    return f"session.{user_id}"
PYEOF

  git add -A
  git commit -m "feat: add OAuth integration for GitHub and Google" --quiet
  git push origin feat/add-oauth --quiet

  # Create draft PR
  gh pr create \
    --repo "$BACKEND_FULL" \
    --base main \
    --head feat/add-oauth \
    --title "feat: add OAuth integration for GitHub and Google" \
    --body "## Summary

Adds OAuth callback handlers for GitHub and Google providers.

- Implements \`github_oauth_callback\` and \`google_oauth_callback\`
- Auto-creates accounts for first-time OAuth users
- Exchanges authorization codes for access tokens

## Related Specs

This should realize acceptance criteria in \`docs/specs/auth.md\` section 3 (OAuth Integration):
- Users can authenticate via GitHub OAuth
- Users can authenticate via Google OAuth
- First-time OAuth users get an account auto-created

## Test Plan

- [ ] Verify Canon posts a PR analysis comment
- [ ] Check that realizations are detected for auth spec section 3
- [ ] Merge and verify doc-update PR is created" \
    --draft

  echo "  Created draft PR: feat/add-oauth → main"
fi
cd "$SCRIPT_DIR"
echo ""

# --- Print playbook ---
echo "=== Setup Complete ==="
echo ""
echo "GitHub App Installation:"
echo "  https://github.com/apps/canon-hq/installations/new/permissions?target_id=$ORG"
echo "  (Or: https://github.com/apps/canon-hq)"
echo ""
echo "=== Test Playbook ==="
echo ""
echo "1. ONBOARDING (after installing Canon GitHub App):"
echo "   - demo-backend: Expect a 'Canon: Welcome — spec summary' issue (has specs)"
echo "   - demo-frontend: Expect a 'chore: add Canon starter files' PR (no specs)"
echo "   - demo-docs: Expect a 'Canon: Welcome — spec summary' issue (has specs)"
echo ""
echo "2. PR ANALYSIS:"
echo "   - Go to: https://github.com/$ORG/demo-backend/pulls"
echo "   - Canon may have already analyzed the draft PR at creation time"
echo "   - Mark the PR as ready for review to trigger a fresh analysis"
echo "   - Verify Canon posts/updates a spec analysis comment detecting"
echo "     realizations against docs/specs/auth.md section 3 (OAuth Integration)"
echo ""
echo "3. @CANON COMMANDS:"
echo "   - On the OAuth PR, comment: @canon reanalyze"
echo "   - Verify Canon re-runs analysis and updates its comment"
echo "   - Comment: @canon dismiss"
echo "   - Verify Canon removes its analysis comment"
echo ""
echo "4. PUSH SYNC (ticket creation):"
echo "   - Push a change to docs/specs/auth.md in demo-backend"
echo "   - Verify GitHub Issues are created for each spec section"
echo "   - Verify ticket links are added back to the spec file"
echo ""
echo "5. MERGE DOC UPDATES:"
echo "   - Merge the OAuth PR in demo-backend"
echo "   - Verify Canon creates a doc-update PR that:"
echo "     - Checks off realized ACs in docs/specs/auth.md"
echo "     - Adds realization evidence comments"
echo "     - Advances section 3 status if all ACs realized"
echo ""
echo "6. REVERSE SYNC:"
echo "   - Close a GitHub Issue created by forward sync"
echo "   - Verify the corresponding spec section status updates"
echo ""
echo "7. CUSTOM CONFIG (demo-docs):"
echo "   - Verify Canon found specs in specifications/**/*.md"
echo "   - Push a change to a spec in demo-docs"
echo "   - Verify ticket creation works with custom doc_paths"
echo ""
echo "Cleanup: scripts/teardown-test-org.sh $ORG"
```

- [ ] **Step 2: Make script executable**

```bash
chmod +x scripts/setup-test-org.sh
```

- [ ] **Step 3: Commit setup script**

```bash
git add scripts/setup-test-org.sh
git commit -m "feat: add test org setup script"
```

---

### Task 4: Write the teardown script

**Files:**
- Create: `scripts/teardown-test-org.sh`

- [ ] **Step 1: Write the teardown script**

File: `scripts/teardown-test-org.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

ORG="${1:-canon-test-org}"
REPOS=("demo-backend" "demo-frontend" "demo-docs")

echo "=== Canon Test Org Teardown ==="
echo "Org: $ORG"
echo ""
echo "This will DELETE the following repos:"
for REPO in "${REPOS[@]}"; do
  echo "  - $ORG/$REPO"
done
echo ""
read -rp "Are you sure? Type 'yes' to confirm: " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
  echo "Aborted."
  exit 0
fi

for REPO in "${REPOS[@]}"; do
  FULL="$ORG/$REPO"
  if gh repo view "$FULL" &>/dev/null 2>&1; then
    echo "Deleting $FULL..."
    gh repo delete "$FULL" --yes
  else
    echo "$FULL not found, skipping."
  fi
done

echo ""
echo "Repos deleted. To delete the org itself, visit:"
echo "  https://github.com/organizations/$ORG/settings/profile"
echo ""
echo "Done."
```

- [ ] **Step 2: Make script executable and commit**

```bash
chmod +x scripts/teardown-test-org.sh
git add scripts/teardown-test-org.sh
git commit -m "feat: add test org teardown script"
```

---

### Task 5: Run the setup script

- [ ] **Step 1: Create the GitHub org manually**

Go to https://github.com/organizations/plan and create the free org named `canon-test-org` (or preferred name).

- [ ] **Step 2: Run the setup script**

```bash
./scripts/setup-test-org.sh canon-test-org
```

Expected output:
- 3 repos created and populated
- Draft PR created on demo-backend
- Test playbook printed

- [ ] **Step 3: Install Canon GitHub App on the new org**

Go to https://github.com/apps/canon-hq and install on the new org, selecting all 3 repos.

- [ ] **Step 4: Verify onboarding**

Within 30 seconds of installation:
- `demo-backend`: should have a "Canon: Welcome — spec summary" issue listing 2 specs
- `demo-frontend`: should have a "chore: add Canon starter files" PR with template + CANON.yaml
- `demo-docs`: should have a "Canon: Welcome — spec summary" issue listing 2 specs

- [ ] **Step 5: Walk through the test playbook**

Follow the printed playbook to test each integration flow.
