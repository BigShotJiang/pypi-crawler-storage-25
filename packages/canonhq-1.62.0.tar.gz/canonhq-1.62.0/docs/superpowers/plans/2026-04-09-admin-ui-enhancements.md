# Admin UI Enhancements: User Deactivation & Org Suspension

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add user deactivation and org suspension to the super admin interface, plus fix the profile CORS bug.

**Architecture:** Phase 1 adds a `status` column to users + deactivation/reactivation endpoints with session/key revocation. Phase 2 adds org suspend/reactivate endpoints leveraging existing `gh_installations.status`. Both phases add frontend action buttons, status badges, and confirmation dialogs. The CORS fix (already applied) is included in the PR.

**Tech Stack:** Python/FastAPI (backend), Vue 3 + TanStack Query (frontend), Alembic + raw SQL (migrations), asyncpg (DB), pytest + AsyncMock (tests)

---

### Task 1: DB Migration — Add `users.status` Column

**Files:**
- Create: `src/canon/db/migrations/versions/0006_user_status.py`

- [ ] **Step 1: Create the migration file**

```python
"""Add status column to users table.

Revision ID: 0006
Revises: 0005
"""

from alembic import op

revision = "0006_user_status"
down_revision = "0005_audit_events"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'active'"
    )
    op.execute("CREATE INDEX IF NOT EXISTS idx_users_status ON users(status)")


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS idx_users_status")
    op.execute("ALTER TABLE users DROP COLUMN IF EXISTS status")
```

- [ ] **Step 2: Verify migration applies cleanly**

Run: `uv run alembic upgrade head` (or if alembic isn't wired, verify SQL syntax is valid)

- [ ] **Step 3: Commit**

```bash
git add src/canon/db/migrations/versions/0006_user_status.py
git commit -m "feat(db): add users.status column for deactivation support"
```

---

### Task 2: Backend — UserStore Bulk Revocation Methods

**Files:**
- Modify: `src/canon/db/user_store.py` (add `revoke_all_api_keys` method after line 218)

- [ ] **Step 1: Write the test**

Create `tests/test_db/test_user_store_revoke.py`:

```python
"""Tests for bulk API key revocation in UserStore."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock
from contextlib import asynccontextmanager

import pytest

from canon.db.user_store import UserStore


def _mock_pool(conn: AsyncMock) -> MagicMock:
    pool = MagicMock()

    @asynccontextmanager
    async def _acquire():
        yield conn

    pool.acquire = _acquire
    return pool


class TestRevokeAllApiKeys:
    async def test_revokes_active_keys_returns_count(self):
        conn = AsyncMock()
        conn.execute = AsyncMock(return_value="UPDATE 3")
        store = UserStore(_mock_pool(conn))

        count = await store.revoke_all_api_keys(user_id=42)

        assert count == 3
        sql = conn.execute.call_args[0][0]
        assert "UPDATE api_keys" in sql
        assert "revoked_at" in sql
        assert conn.execute.call_args[0][1] == 42

    async def test_returns_zero_when_no_active_keys(self):
        conn = AsyncMock()
        conn.execute = AsyncMock(return_value="UPDATE 0")
        store = UserStore(_mock_pool(conn))

        count = await store.revoke_all_api_keys(user_id=99)

        assert count == 0
```

- [ ] **Step 2: Run test — verify it fails**

Run: `uv run pytest tests/test_db/test_user_store_revoke.py -v`
Expected: FAIL — `AttributeError: 'UserStore' object has no attribute 'revoke_all_api_keys'`

- [ ] **Step 3: Implement `revoke_all_api_keys` in UserStore**

Add after `revoke_api_key` method (after line 218 in `src/canon/db/user_store.py`):

```python
    async def revoke_all_api_keys(self, *, user_id: int) -> int:
        """Revoke all active API keys for a user.  Returns count revoked."""
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE api_keys
                SET revoked_at = now()
                WHERE user_id = $1 AND revoked_at IS NULL
                """,
                user_id,
            )
        try:
            return int(result.split()[-1])
        except (ValueError, IndexError):
            return 0
```

- [ ] **Step 4: Run test — verify it passes**

Run: `uv run pytest tests/test_db/test_user_store_revoke.py -v`
Expected: 2 passed

- [ ] **Step 5: Commit**

```bash
git add src/canon/db/user_store.py tests/test_db/test_user_store_revoke.py
git commit -m "feat(user-store): add revoke_all_api_keys for bulk revocation"
```

---

### Task 3: Backend — AdminStore Deactivation & Suspension Methods

**Files:**
- Modify: `src/canon/admin/store.py` (add methods after `update_user_role` at line 301)

- [ ] **Step 1: Write tests for deactivation methods**

Create `tests/test_admin/test_admin_store_actions.py`:

```python
"""Tests for admin deactivation and suspension store methods."""

from __future__ import annotations

from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock

import pytest

from canon.admin.store import AdminStore


def _mock_pool(conn: AsyncMock) -> MagicMock:
    pool = MagicMock()

    @asynccontextmanager
    async def _acquire():
        yield conn

    pool.acquire = _acquire
    return pool


class TestDeactivateUser:
    async def test_sets_status_to_deactivated(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|1",
                "email": "a@b.com",
                "name": "Test",
                "role": "editor",
                "status": "deactivated",
                "created_at": None,
                "last_login_at": None,
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.deactivate_user(1)

        assert result is not None
        assert result["status"] == "deactivated"
        sql = conn.fetchrow.call_args[0][0]
        assert "status = 'deactivated'" in sql

    async def test_returns_none_if_user_not_found(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value=None)
        store = AdminStore(_mock_pool(conn))

        result = await store.deactivate_user(999)

        assert result is None


class TestReactivateUser:
    async def test_sets_status_to_active(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|1",
                "email": "a@b.com",
                "name": "Test",
                "role": "editor",
                "status": "active",
                "created_at": None,
                "last_login_at": None,
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.reactivate_user(1)

        assert result is not None
        assert result["status"] == "active"


class TestSuspendOrg:
    async def test_sets_status_to_suspended(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "installation_id": 123,
                "org_login": "acme",
                "status": "suspended",
                "installed_at": None,
                "repos_count": 5,
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.suspend_org("acme")

        assert result is not None
        assert result["status"] == "suspended"

    async def test_returns_none_if_org_not_found(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value=None)
        store = AdminStore(_mock_pool(conn))

        result = await store.suspend_org("nonexistent")

        assert result is None


class TestReactivateOrg:
    async def test_sets_status_to_active(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "installation_id": 123,
                "org_login": "acme",
                "status": "active",
                "installed_at": None,
                "repos_count": 5,
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.reactivate_org("acme")

        assert result is not None
        assert result["status"] == "active"
```

- [ ] **Step 2: Run tests — verify they fail**

Run: `uv run pytest tests/test_admin/test_admin_store_actions.py -v`
Expected: FAIL — `AttributeError: 'AdminStore' object has no attribute 'deactivate_user'`

- [ ] **Step 3: Implement the four AdminStore methods**

Add to `src/canon/admin/store.py` after `update_user_role` (line 301):

```python
    async def deactivate_user(self, user_id: int) -> dict | None:
        """Set user status to deactivated.  Returns updated record or None."""
        sql = """
            UPDATE users
            SET status = 'deactivated'
            WHERE id = $1 AND status = 'active'
            RETURNING id, oidc_sub, email, name, role, status, created_at, last_login_at
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, user_id)
        if row is None:
            return None
        return {
            "id": row["id"],
            "login": row["name"] or row["email"],
            "email": row["email"],
            "role": row["role"],
            "status": row["status"],
            "org_login": "",
            "created_at": row["created_at"],
        }

    async def reactivate_user(self, user_id: int) -> dict | None:
        """Set user status back to active.  Returns updated record or None."""
        sql = """
            UPDATE users
            SET status = 'active'
            WHERE id = $1 AND status = 'deactivated'
            RETURNING id, oidc_sub, email, name, role, status, created_at, last_login_at
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, user_id)
        if row is None:
            return None
        return {
            "id": row["id"],
            "login": row["name"] or row["email"],
            "email": row["email"],
            "role": row["role"],
            "status": row["status"],
            "org_login": "",
            "created_at": row["created_at"],
        }

    async def suspend_org(self, org: str) -> dict | None:
        """Suspend an org.  Returns updated record or None."""
        sql = """
            UPDATE gh_installations
            SET status = 'suspended'
            WHERE org_login = $1 AND status = 'active'
            RETURNING installation_id, org_login, status, installed_at, repos_count
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, org)
        if row is None:
            return None
        return dict(row)

    async def reactivate_org(self, org: str) -> dict | None:
        """Reactivate a suspended org.  Returns updated record or None."""
        sql = """
            UPDATE gh_installations
            SET status = 'active'
            WHERE org_login = $1 AND status = 'suspended'
            RETURNING installation_id, org_login, status, installed_at, repos_count
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, org)
        if row is None:
            return None
        return dict(row)
```

- [ ] **Step 4: Run tests — verify they pass**

Run: `uv run pytest tests/test_admin/test_admin_store_actions.py -v`
Expected: All passed

- [ ] **Step 5: Commit**

```bash
git add src/canon/admin/store.py tests/test_admin/test_admin_store_actions.py
git commit -m "feat(admin-store): add deactivate/reactivate user and suspend/reactivate org"
```

---

### Task 4: Backend — Response Models + Status Fields

**Files:**
- Modify: `src/canon/admin/models.py` (add `status` to UserSummary and OrgSummary)
- Modify: `src/canon/admin/routes.py` (add `status` to `_coerce_user` and `_coerce_org`)

- [ ] **Step 1: Add `status` field to models**

In `src/canon/admin/models.py`, add `status` to both models:

In `OrgSummary` (after line 36):
```python
    status: str = "active"
```

In `UserSummary` (after line 44):
```python
    status: str = "active"
```

- [ ] **Step 2: Add `status` to coerce helpers**

In `src/canon/admin/routes.py`, update `_coerce_org` (line 424-438) to include:
```python
        "status": row.get("status", "active"),
```

Update `_coerce_user` (line 441-455) to include:
```python
        "status": row.get("status", "active"),
```

- [ ] **Step 3: Run existing tests to verify no regressions**

Run: `uv run pytest tests/test_admin/ -v`
Expected: All existing tests pass

- [ ] **Step 4: Commit**

```bash
git add src/canon/admin/models.py src/canon/admin/routes.py
git commit -m "feat(admin): add status field to UserSummary and OrgSummary models"
```

---

### Task 5: Backend — Admin Action Endpoints

**Files:**
- Modify: `src/canon/admin/routes.py` (add 4 new endpoints after `update_user` at line 238)

- [ ] **Step 1: Write route tests**

Add to `tests/test_admin/test_routes.py` (or create `tests/test_admin/test_action_routes.py`):

```python
"""Tests for admin action endpoints (deactivation, suspension)."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from httpx import ASGITransport, AsyncClient

from canon.admin.middleware import require_super_admin
from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission
from canon.main import app
from canon.settings import Settings


def _super_admin() -> CurrentUser:
    return CurrentUser(
        sub="admin-1",
        email="admin@canonhq.co",
        name="Admin",
        org_login="canonhq",
        permissions=frozenset(Permission),
        auth_method="session",
    )


@pytest.fixture
def client():
    return AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test", follow_redirects=False
    )


@pytest.fixture(autouse=True)
def _setup():
    user = _super_admin()
    app.dependency_overrides[require_super_admin] = lambda: user
    app.state.settings = Settings(deployment_mode="cloud")
    app.state.admin_store = AsyncMock()
    app.state.audit_store = AsyncMock()
    app.state.session_store = AsyncMock()
    app.state.user_store = AsyncMock()
    app.state.db_pool = None
    yield
    app.dependency_overrides.pop(require_super_admin, None)


class TestDeactivateUser:
    async def test_deactivates_and_revokes(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "status": "active", "email": "u@b.com"}
        )
        app.state.admin_store.deactivate_user = AsyncMock(
            return_value={"id": 1, "login": "u", "email": "u@b.com", "role": "editor", "status": "deactivated", "org_login": "", "created_at": None}
        )
        app.state.session_store.revoke_all_sessions = AsyncMock(return_value=2)
        app.state.user_store.revoke_all_api_keys = AsyncMock(return_value=1)

        resp = await client.post("/api/admin/users/1/deactivate")

        assert resp.status_code == 200
        body = resp.json()
        assert body["status"] == "deactivated"
        assert body["sessions_revoked"] == 2
        assert body["keys_revoked"] == 1
        app.state.audit_store.log.assert_awaited_once()

    async def test_cannot_deactivate_super_admin(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 2, "role": "super_admin", "status": "active"}
        )

        resp = await client.post("/api/admin/users/2/deactivate")

        assert resp.status_code == 400

    async def test_404_if_user_not_found(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)

        resp = await client.post("/api/admin/users/999/deactivate")

        assert resp.status_code == 404


class TestReactivateUser:
    async def test_reactivates_user(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "status": "deactivated", "email": "u@b.com"}
        )
        app.state.admin_store.reactivate_user = AsyncMock(
            return_value={"id": 1, "login": "u", "email": "u@b.com", "role": "editor", "status": "active", "org_login": "", "created_at": None}
        )

        resp = await client.post("/api/admin/users/1/reactivate")

        assert resp.status_code == 200
        assert resp.json()["status"] == "active"


class TestSuspendOrg:
    async def test_suspends_and_clears_sessions(self, client: AsyncClient):
        app.state.admin_store.suspend_org = AsyncMock(
            return_value={"installation_id": 123, "org_login": "acme", "status": "suspended"}
        )

        resp = await client.post("/api/admin/orgs/acme/suspend")

        assert resp.status_code == 200
        assert resp.json()["status"] == "suspended"
        app.state.audit_store.log.assert_awaited_once()

    async def test_404_if_org_not_found(self, client: AsyncClient):
        app.state.admin_store.suspend_org = AsyncMock(return_value=None)

        resp = await client.post("/api/admin/orgs/nonexistent/suspend")

        assert resp.status_code == 404


class TestReactivateOrg:
    async def test_reactivates_org(self, client: AsyncClient):
        app.state.admin_store.reactivate_org = AsyncMock(
            return_value={"installation_id": 123, "org_login": "acme", "status": "active"}
        )

        resp = await client.post("/api/admin/orgs/acme/reactivate")

        assert resp.status_code == 200
        assert resp.json()["status"] == "active"
```

- [ ] **Step 2: Run tests — verify they fail**

Run: `uv run pytest tests/test_admin/test_action_routes.py -v`
Expected: FAIL — 405 Method Not Allowed (routes don't exist yet)

- [ ] **Step 3: Implement the 4 action endpoints**

Add to `src/canon/admin/routes.py` after the `update_user` endpoint (line 238):

```python
@router.post("/users/{user_id}/deactivate")
async def deactivate_user(
    user_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Deactivate a user: set status, revoke all sessions and API keys."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("role") == "super_admin":
        raise HTTPException(status_code=400, detail="Cannot deactivate a super admin")
    if existing.get("status") == "deactivated":
        raise HTTPException(status_code=400, detail="User is already deactivated")

    updated = await admin_store.deactivate_user(user_id)
    if updated is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Revoke all sessions and API keys
    sessions_revoked = 0
    keys_revoked = 0
    session_store = getattr(request.app.state, "session_store", None)
    if session_store:
        sessions_revoked = await session_store.revoke_all_sessions(user_id=user_id)
    user_store = getattr(request.app.state, "user_store", None)
    if user_store:
        keys_revoked = await user_store.revoke_all_api_keys(user_id=user_id)

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store:
        try:
            await audit_store.log(
                event_type="user.deactivated",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                org=existing.get("org_login"),
                detail={
                    "email": existing.get("email"),
                    "sessions_revoked": sessions_revoked,
                    "keys_revoked": keys_revoked,
                    "deactivated_by": user.sub,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log deactivation audit event", exc_info=True)

    result = UserSummary(**_coerce_user(updated)).model_dump()
    result["sessions_revoked"] = sessions_revoked
    result["keys_revoked"] = keys_revoked
    return result


@router.post("/users/{user_id}/reactivate")
async def reactivate_user(
    user_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Reactivate a deactivated user."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("status") != "deactivated":
        raise HTTPException(status_code=400, detail="User is not deactivated")

    updated = await admin_store.reactivate_user(user_id)
    if updated is None:
        raise HTTPException(status_code=404, detail="User not found")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store:
        try:
            await audit_store.log(
                event_type="user.reactivated",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                org=existing.get("org_login"),
                detail={"email": existing.get("email"), "reactivated_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log reactivation audit event", exc_info=True)

    return UserSummary(**_coerce_user(updated)).model_dump()


@router.post("/orgs/{org}/suspend")
async def suspend_org(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Suspend an org: freeze webhooks, cron, and sync."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    updated = await admin_store.suspend_org(org)
    if updated is None:
        raise HTTPException(status_code=404, detail="Org not found or not active")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store:
        try:
            await audit_store.log(
                event_type="org.suspended",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                org=org,
                detail={"suspended_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log org suspension audit event", exc_info=True)

    return {"login": org, "status": "suspended", **updated}


@router.post("/orgs/{org}/reactivate")
async def reactivate_org(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Reactivate a suspended org."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    updated = await admin_store.reactivate_org(org)
    if updated is None:
        raise HTTPException(status_code=404, detail="Org not found or not suspended")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store:
        try:
            await audit_store.log(
                event_type="org.reactivated",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                org=org,
                detail={"reactivated_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log org reactivation audit event", exc_info=True)

    return {"login": org, "status": "active", **updated}
```

- [ ] **Step 4: Run tests — verify they pass**

Run: `uv run pytest tests/test_admin/test_action_routes.py -v`
Expected: All passed

- [ ] **Step 5: Run full admin test suite for regressions**

Run: `uv run pytest tests/test_admin/ -v`
Expected: All passed

- [ ] **Step 6: Commit**

```bash
git add src/canon/admin/routes.py tests/test_admin/test_action_routes.py
git commit -m "feat(admin): add deactivate/reactivate user and suspend/reactivate org endpoints"
```

---

### Task 6: Backend — Auth Middleware Deactivation Check

**Files:**
- Modify: `src/canon/auth/deps.py` (add status check in `_session_to_current_user` and `_resolve_api_key`)

- [ ] **Step 1: Write the test**

Add to `tests/test_auth/test_middleware.py` in `TestAuthMiddlewareEnabled`:

```python
    async def test_deactivated_user_gets_403_on_api_request(self, client: AsyncClient):
        """Deactivated users should be blocked from API access."""
        from unittest.mock import AsyncMock, patch

        mock_user_store = AsyncMock()
        mock_user_store.get_api_key_by_hash = AsyncMock(
            return_value={
                "user_sub": "auth0|deactivated",
                "user_email": "deactivated@example.com",
                "user_name": "Deactivated",
                "org_login": "test-org",
                "scopes": ["specs:read"],
                "revoked_at": None,
                "expires_at": None,
                "user_id": 42,
                "user_status": "deactivated",
            }
        )
        app.state.user_store = mock_user_store

        resp = await client.get(
            "/app/test-org/api/profile",
            headers={
                "Authorization": "Bearer sw_testkey",
                "Accept": "application/json",
            },
        )
        # Should be blocked — either 401 or 403
        assert resp.status_code in (401, 403)
        app.state.user_store = None
```

- [ ] **Step 2: Implement the deactivation check**

In `src/canon/db/user_store.py`, update `get_api_key_by_hash` SQL (line 154-166) to also select `u.status AS user_status`:

```sql
SELECT
    ak.*,
    u.oidc_sub AS user_sub,
    u.email AS user_email,
    u.name AS user_name,
    u.status AS user_status
FROM api_keys ak
JOIN users u ON u.id = ak.user_id
WHERE ak.key_hash = $1
```

In `src/canon/auth/deps.py`, in `_resolve_api_key` (after the revocation check), add:

```python
    if api_key.get("user_status") == "deactivated":
        raise HTTPException(status_code=403, detail="Account has been deactivated")
```

- [ ] **Step 3: Run test — verify it passes**

Run: `uv run pytest tests/test_auth/test_middleware.py -v`
Expected: All passed (including the new test)

- [ ] **Step 4: Commit**

```bash
git add src/canon/auth/deps.py src/canon/db/user_store.py tests/test_auth/test_middleware.py
git commit -m "feat(auth): block deactivated users from API key access"
```

---

### Task 7: Frontend — API Client + Type Updates

**Files:**
- Modify: `frontend/src/api/admin.ts`

- [ ] **Step 1: Add `status` to TypeScript interfaces**

In `OrgSummary` (after line 52):
```typescript
  status: string                    // active | suspended
```

In `UserSummary` (after line 69):
```typescript
  status: string                    // active | deactivated
```

- [ ] **Step 2: Add action API functions**

Add after `updateUserRole` (line 167):

```typescript
export function deactivateUser(userId: string): Promise<UserSummary & { sessions_revoked: number; keys_revoked: number }> {
  return post(`/api/admin/users/${encodeURIComponent(userId)}/deactivate`)
}

export function reactivateUser(userId: string): Promise<UserSummary> {
  return post(`/api/admin/users/${encodeURIComponent(userId)}/reactivate`)
}

export function suspendOrg(org: string): Promise<OrgSummary> {
  return post(`/api/admin/orgs/${encodeURIComponent(org)}/suspend`)
}

export function reactivateOrg(org: string): Promise<OrgSummary> {
  return post(`/api/admin/orgs/${encodeURIComponent(org)}/reactivate`)
}
```

- [ ] **Step 3: Commit**

```bash
git add frontend/src/api/admin.ts
git commit -m "feat(frontend): add admin action API functions and status fields"
```

---

### Task 8: Frontend — User Detail: Deactivation UI

**Files:**
- Modify: `frontend/src/views/admin/AdminUserDetail.vue`

- [ ] **Step 1: Add imports and state**

Update the script section to import the new API functions and add deactivation state:

```typescript
import { fetchUser, updateUserRole, deactivateUser, reactivateUser } from '@/api/admin'
import AdminStatusBadge from '@/components/admin/AdminStatusBadge.vue'

const deactivating = ref(false)
const reactivating = ref(false)
const showDeactivateConfirm = ref(false)
```

- [ ] **Step 2: Add action handlers**

```typescript
async function handleDeactivate() {
  if (!data.value) return
  deactivating.value = true
  try {
    await deactivateUser(userId.value)
    queryClient.invalidateQueries({ queryKey: ['admin-user', userId.value] })
  } finally {
    deactivating.value = false
    showDeactivateConfirm.value = false
  }
}

async function handleReactivate() {
  if (!data.value) return
  reactivating.value = true
  try {
    await reactivateUser(userId.value)
    queryClient.invalidateQueries({ queryKey: ['admin-user', userId.value] })
  } finally {
    reactivating.value = false
  }
}
```

- [ ] **Step 3: Add status badge next to user email**

In the header section (after the email h1, line 49), add:

```html
<AdminStatusBadge v-if="data.status && data.status !== 'active'" :status="data.status" />
```

- [ ] **Step 4: Add deactivation section to template**

After the Role change section (after line 114), add:

```html
      <!-- Account Actions -->
      <div class="bg-white dark:bg-surface-elevated border border-border-light dark:border-slate-700 rounded-lg p-4 mt-4">
        <h2 class="text-xs font-semibold uppercase tracking-widest text-slate-500 mb-3">Account Actions</h2>
        <template v-if="data.status === 'deactivated'">
          <p class="text-sm text-slate-500 mb-3">This account is deactivated. All sessions and API keys were revoked.</p>
          <button
            class="px-3 py-1.5 text-sm rounded bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 transition-colors disabled:opacity-50"
            :disabled="reactivating"
            @click="handleReactivate"
          >
            {{ reactivating ? 'Reactivating...' : 'Reactivate Account' }}
          </button>
        </template>
        <template v-else-if="data.role !== 'super_admin'">
          <template v-if="!showDeactivateConfirm">
            <button
              class="px-3 py-1.5 text-sm rounded bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-colors"
              @click="showDeactivateConfirm = true"
            >
              Deactivate Account
            </button>
          </template>
          <template v-else>
            <div class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded p-3">
              <p class="text-sm text-red-600 dark:text-red-400 mb-3">
                This will immediately revoke all sessions and API keys for <strong>{{ data.email }}</strong>.
              </p>
              <div class="flex gap-2">
                <button
                  class="px-3 py-1.5 text-sm rounded bg-red-500 text-white hover:bg-red-600 transition-colors disabled:opacity-50"
                  :disabled="deactivating"
                  @click="handleDeactivate"
                >
                  {{ deactivating ? 'Deactivating...' : 'Confirm Deactivate' }}
                </button>
                <button
                  class="px-3 py-1.5 text-sm rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  @click="showDeactivateConfirm = false"
                >
                  Cancel
                </button>
              </div>
            </div>
          </template>
        </template>
        <p v-else class="text-sm text-slate-400">Super admin accounts cannot be deactivated.</p>
      </div>
```

- [ ] **Step 5: Commit**

```bash
git add frontend/src/views/admin/AdminUserDetail.vue
git commit -m "feat(frontend): add deactivation/reactivation UI to user detail page"
```

---

### Task 9: Frontend — Org Detail: Suspension UI

**Files:**
- Modify: `frontend/src/views/admin/AdminOrgDetail.vue`

- [ ] **Step 1: Add imports and state**

Update imports:
```typescript
import { fetchOrg, triggerOrgReindex, suspendOrg, reactivateOrg } from '@/api/admin'
import AdminStatusBadge from '@/components/admin/AdminStatusBadge.vue'

const suspending = ref(false)
const reactivatingOrg = ref(false)
const showSuspendConfirm = ref(false)
```

- [ ] **Step 2: Add action handlers**

```typescript
async function handleSuspend() {
  suspending.value = true
  try {
    await suspendOrg(org.value)
    queryClient.invalidateQueries({ queryKey: ['admin-org', org.value] })
  } finally {
    suspending.value = false
    showSuspendConfirm.value = false
  }
}

async function handleReactivateOrg() {
  reactivatingOrg.value = true
  try {
    await reactivateOrg(org.value)
    queryClient.invalidateQueries({ queryKey: ['admin-org', org.value] })
  } finally {
    reactivatingOrg.value = false
  }
}
```

- [ ] **Step 3: Add status badge next to org name**

After the h1 (line 37), add:
```html
<AdminStatusBadge v-if="data.status && data.status !== 'active'" :status="data.status" />
```

- [ ] **Step 4: Add suspension section**

After the member list section (before `</template>` on line 88), add:

```html
      <!-- Org Actions -->
      <div class="bg-white dark:bg-surface-elevated border border-border-light dark:border-slate-700 rounded-lg p-4 mt-4">
        <h2 class="text-xs font-semibold uppercase tracking-widest text-slate-500 mb-3">Organization Actions</h2>
        <template v-if="data.status === 'suspended'">
          <p class="text-sm text-slate-500 mb-3">This organization is suspended. Webhooks, sync, and cron jobs are paused.</p>
          <button
            class="px-3 py-1.5 text-sm rounded bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 transition-colors disabled:opacity-50"
            :disabled="reactivatingOrg"
            @click="handleReactivateOrg"
          >
            {{ reactivatingOrg ? 'Reactivating...' : 'Reactivate Organization' }}
          </button>
        </template>
        <template v-else>
          <template v-if="!showSuspendConfirm">
            <button
              class="px-3 py-1.5 text-sm rounded bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-colors"
              @click="showSuspendConfirm = true"
            >
              Suspend Organization
            </button>
          </template>
          <template v-else>
            <div class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded p-3">
              <p class="text-sm text-red-600 dark:text-red-400 mb-3">
                Suspending <strong>{{ data.display_name || data.login }}</strong> will freeze all webhooks, sync, and cron jobs.
              </p>
              <div class="flex gap-2">
                <button
                  class="px-3 py-1.5 text-sm rounded bg-red-500 text-white hover:bg-red-600 transition-colors disabled:opacity-50"
                  :disabled="suspending"
                  @click="handleSuspend"
                >
                  {{ suspending ? 'Suspending...' : 'Confirm Suspend' }}
                </button>
                <button
                  class="px-3 py-1.5 text-sm rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  @click="showSuspendConfirm = false"
                >
                  Cancel
                </button>
              </div>
            </div>
          </template>
        </template>
      </div>
```

- [ ] **Step 5: Commit**

```bash
git add frontend/src/views/admin/AdminOrgDetail.vue
git commit -m "feat(frontend): add suspension/reactivation UI to org detail page"
```

---

### Task 10: Frontend — Status Badges on List Pages

**Files:**
- Modify: `frontend/src/views/admin/AdminUsers.vue`
- Modify: `frontend/src/views/admin/AdminOrgs.vue`

- [ ] **Step 1: Add status badges to AdminUsers.vue**

Import `AdminStatusBadge` and add it next to each user's role display. In the user card template, after the role display, add:

```html
<AdminStatusBadge v-if="u.status === 'deactivated'" :status="u.status" />
```

- [ ] **Step 2: Add status badges to AdminOrgs.vue**

Import `AdminStatusBadge` and add it next to each org name. In the org card template, add:

```html
<AdminStatusBadge v-if="o.status === 'suspended'" :status="o.status" />
```

- [ ] **Step 3: Commit**

```bash
git add frontend/src/views/admin/AdminUsers.vue frontend/src/views/admin/AdminOrgs.vue
git commit -m "feat(frontend): add status badges to user and org list pages"
```

---

### Task 11: Lint, Full Test, Final Verification

- [ ] **Step 1: Run linter on all changed Python files**

```bash
uv run ruff check src/canon/admin/ src/canon/auth/ src/canon/db/ tests/test_admin/ tests/test_auth/ tests/test_db/
uv run ruff format --check src/canon/admin/ src/canon/auth/ src/canon/db/ tests/test_admin/ tests/test_auth/ tests/test_db/
```

- [ ] **Step 2: Fix any lint issues**

```bash
uv run ruff check --fix src/canon/admin/ src/canon/auth/ src/canon/db/
uv run ruff format src/canon/admin/ src/canon/auth/ src/canon/db/ tests/
```

- [ ] **Step 3: Run the full test suite**

```bash
uv run pytest tests/ -v --timeout=60
```

- [ ] **Step 4: Verify the CORS fix is still in place**

```bash
git diff main -- src/canon/auth/middleware.py | head -20
```
Should show the `_is_api_request` check returning 401 for JSON requests.

- [ ] **Step 5: Commit any lint fixes**

```bash
git add -A
git commit -m "style: fix lint and formatting issues"
```

---

## Verification

1. **Unit tests**: `uv run pytest tests/test_admin/ tests/test_auth/ tests/test_db/ -v`
2. **Full suite**: `uv run pytest tests/ -v`
3. **Lint**: `uv run ruff check src/ tests/`
4. **Manual check**: The CORS fix (middleware.py returns 401 for API requests) + GitHub OAuth scope fix (github_oauth.py includes read:org) are included in the diff
5. **Frontend**: Build with `cd frontend && npm run build` to catch TypeScript errors

## Files Modified Summary

| File | Change |
|------|--------|
| `src/canon/db/migrations/versions/0006_user_status.py` | New: users.status column |
| `src/canon/db/user_store.py` | Add: `revoke_all_api_keys`, update SQL to include `user_status` |
| `src/canon/db/session_store.py` | (unchanged — `revoke_all_sessions` already exists) |
| `src/canon/admin/store.py` | Add: deactivate_user, reactivate_user, suspend_org, reactivate_org |
| `src/canon/admin/models.py` | Add: `status` field to UserSummary and OrgSummary |
| `src/canon/admin/routes.py` | Add: 4 action endpoints + status in coerce helpers |
| `src/canon/auth/deps.py` | Add: deactivated user check for API keys |
| `src/canon/auth/middleware.py` | (already done: return 401 for API requests) |
| `src/canon/auth/github_oauth.py` | (already done: add read:org scope) |
| `frontend/src/api/admin.ts` | Add: status fields, 4 action functions |
| `frontend/src/views/admin/AdminUserDetail.vue` | Add: deactivation UI with confirmation |
| `frontend/src/views/admin/AdminOrgDetail.vue` | Add: suspension UI with confirmation |
| `frontend/src/views/admin/AdminUsers.vue` | Add: status badges |
| `frontend/src/views/admin/AdminOrgs.vue` | Add: status badges |
| Tests: 3 new test files | test_user_store_revoke, test_admin_store_actions, test_action_routes |
