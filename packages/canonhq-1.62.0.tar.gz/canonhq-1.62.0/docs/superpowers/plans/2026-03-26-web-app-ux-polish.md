# Web App UX Polish Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Improve the Canon web app across Tasks, Explorer, Navigation, Editor, and global UX patterns — filling gaps not covered by existing specs.

**Architecture:** Pure frontend work (Vue 3 + Tailwind CSS v4 + TanStack Query) except for one backend API enhancement. Follows existing patterns: `<script setup>`, Pinia stores, composables for shared logic, typed API wrappers. No frontend test framework is installed, so verification is via dev server manual checks and `vue-tsc --noEmit` type checking.

**Tech Stack:** Vue 3.5, TypeScript 5.7, Tailwind CSS v4, @tanstack/vue-query 5, Pinia 2, Chart.js 4, FastAPI (Python backend), Pydantic v2

**Spec:** `docs/specs/web-app-ux-polish.md`

---

## File Structure

### New files to create

| File | Responsibility |
|------|---------------|
| `frontend/src/composables/useToast.ts` | Toast state management via provide/inject |
| `frontend/src/composables/useViewPreference.ts` | Persist view toggles to localStorage |
| `frontend/src/components/common/ToastContainer.vue` | Global toast notification container |
| `frontend/src/components/common/SkeletonTable.vue` | Skeleton loader for table layouts |
| `frontend/src/components/common/SkeletonCard.vue` | Skeleton loader for card layouts |
| `frontend/src/components/common/ShortcutsModal.vue` | Keyboard shortcuts help modal |
| `frontend/src/components/common/TicketBadge.vue` | Clickable ticket link badge |
| `frontend/src/components/tasks/TasksGroupedView.vue` | Spec-grouped task list |
| `frontend/src/components/tasks/TasksBoardView.vue` | Kanban column layout |
| `frontend/src/components/tasks/TaskDetailPanel.vue` | Inline AC expansion panel |
| `frontend/src/components/dashboard/SpecCardExpanded.vue` | Expandable spec card detail |
| `frontend/src/components/editor/ValidationPanel.vue` | Spec validation warnings panel |
| `frontend/src/components/editor/RepoPickerModal.vue` | Repo picker for quick-create flow |
| `tests/test_web/test_tasks_expand.py` | Backend test for ?expand=acs param |

### Existing files to modify

| File | Change |
|------|--------|
| `frontend/src/App.vue` | Mount ToastContainer globally |
| `frontend/src/components/layout/AppNav.vue` | Active page indicator via route matching |
| `frontend/src/components/layout/Breadcrumb.vue` | Add route-aware auto-generation mode |
| `frontend/src/components/dashboard/FilterBar.vue` | Sticky positioning |
| `frontend/src/components/dashboard/SpecList.vue` | Expandable cards, progress bar, hover actions |
| `frontend/src/components/dashboard/OrgDashboard.vue` | Quick-create button with repo picker |
| `frontend/src/components/common/EmptyState.vue` | Add icon slot, CTA button support |
| `frontend/src/components/editor/EditorList.vue` | Actionable empty states |
| `frontend/src/components/editor/EditorToolbar.vue` | Autosave indicator, validation count |
| `frontend/src/components/editor/EditorLayout.vue` | Validation panel, beforeunload |
| `frontend/src/composables/useKeyboardShortcuts.ts` | Two-key combos, input suppression |
| `frontend/src/views/TasksView.vue` | View toggle, grouped/board views, inline expansion |
| `frontend/src/views/SpecView.vue` | Cross-links, spec-level sub-nav tabs |
| `frontend/src/views/DashboardView.vue` | Skeleton loader instead of spinner |
| `frontend/src/views/EditorView.vue` | Skeleton loader, enhanced empty state |
| `frontend/src/api/tasks.ts` | Add expand=acs query param support |
| `frontend/src/api/types.ts` | Add acceptance_criteria to TaskItem |
| `src/canon/web/models.py` | Add acceptance_criteria field to TaskItem |
| `src/canon/web/services.py` | Include ACs when expand=acs requested |
| `src/canon/web/routes.py` | Pass expand param to get_tasks |

**Already done (no tasks needed):**
- §5.3 Markdown Preview Pane — `EditorLayout.vue` already has split-pane live preview with `MarkdownPreview.vue`, resizable drag handle via `useResizablePane`, and responsive source-only default on narrow screens.

---

## Phase 1: Foundation (Global UX)

### Task 1: Toast Notification System (§6.4)

**Files:**
- Create: `frontend/src/composables/useToast.ts`
- Create: `frontend/src/components/common/ToastContainer.vue`
- Modify: `frontend/src/App.vue`

- [ ] **Step 1: Create the useToast composable**

Create `frontend/src/composables/useToast.ts`:

```typescript
import { ref, type InjectionKey, inject, provide } from 'vue'

export type ToastType = 'success' | 'error' | 'info' | 'warning'

export interface Toast {
  id: number
  message: string
  type: ToastType
  createdAt: number
}

const TOAST_KEY: InjectionKey<ReturnType<typeof createToastState>> = Symbol('toast')
const MAX_VISIBLE = 3
const AUTO_DISMISS_MS = 5000

let nextId = 0

function createToastState() {
  const toasts = ref<Toast[]>([])

  function add(message: string, type: ToastType) {
    const id = nextId++
    toasts.value.push({ id, message, type, createdAt: Date.now() })
    // Evict oldest if over max
    while (toasts.value.length > MAX_VISIBLE) {
      toasts.value.shift()
    }
    // Auto-dismiss
    setTimeout(() => dismiss(id), AUTO_DISMISS_MS)
  }

  function dismiss(id: number) {
    toasts.value = toasts.value.filter(t => t.id !== id)
  }

  return {
    toasts,
    success: (msg: string) => add(msg, 'success'),
    error: (msg: string) => add(msg, 'error'),
    info: (msg: string) => add(msg, 'info'),
    warning: (msg: string) => add(msg, 'warning'),
    dismiss,
  }
}

export function provideToast() {
  const state = createToastState()
  provide(TOAST_KEY, state)
  return state
}

export function useToast() {
  const state = inject(TOAST_KEY)
  if (!state) throw new Error('useToast() requires provideToast() in a parent component')
  return state
}
```

- [ ] **Step 2: Create the ToastContainer component**

Create `frontend/src/components/common/ToastContainer.vue`:

```vue
<script setup lang="ts">
import { useToast, type ToastType } from '@/composables/useToast'

const { toasts, dismiss } = useToast()

const AUTO_DISMISS_MS = 5000

function typeClasses(type: ToastType): string {
  const map: Record<ToastType, string> = {
    success: 'bg-green-600 text-white',
    error: 'bg-red-600 text-white',
    info: 'bg-blue-600 text-white',
    warning: 'bg-amber-500 text-white',
  }
  return map[type]
}

function progressColor(type: ToastType): string {
  const map: Record<ToastType, string> = {
    success: 'bg-green-300',
    error: 'bg-red-300',
    info: 'bg-blue-300',
    warning: 'bg-amber-300',
  }
  return map[type]
}
</script>

<template>
  <div class="fixed top-4 right-4 z-[100] flex flex-col gap-2 pointer-events-none">
    <div
      v-for="toast in toasts"
      :key="toast.id"
      class="pointer-events-auto flex items-center gap-2 px-4 py-2.5 rounded-lg shadow-lg text-sm min-w-[280px] max-w-[400px] animate-slide-in"
      :class="typeClasses(toast.type)"
    >
      <span class="flex-1">{{ toast.message }}</span>
      <button
        class="shrink-0 opacity-70 hover:opacity-100 transition-opacity"
        @click="dismiss(toast.id)"
      >&times;</button>
      <!-- Progress bar -->
      <div class="absolute bottom-0 left-0 right-0 h-0.5 overflow-hidden rounded-b-lg">
        <div
          class="h-full animate-shrink"
          :class="progressColor(toast.type)"
          :style="{ animationDuration: `${AUTO_DISMISS_MS}ms` }"
        ></div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@keyframes slide-in {
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}
@keyframes shrink {
  from { width: 100%; }
  to { width: 0%; }
}
.animate-slide-in { animation: slide-in 0.2s ease-out; }
.animate-shrink { animation: shrink linear forwards; }
div { position: relative; }
</style>
```

- [ ] **Step 3: Mount ToastContainer in App.vue**

In `frontend/src/App.vue`, import and mount the toast system:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import AppNav from '@/components/layout/AppNav.vue'
import AppFooter from '@/components/layout/AppFooter.vue'
import ToastContainer from '@/components/common/ToastContainer.vue'
import { provideToast } from '@/composables/useToast'

const route = useRoute()
const isPublic = computed(() => route.meta.public === true)

provideToast()
</script>

<template>
  <!-- Marketing pages render their own layout -->
  <router-view v-if="isPublic" />

  <!-- App pages use the shared chrome -->
  <template v-else>
    <div class="h-0.5 bg-accent-500"></div>
    <AppNav />
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <router-view />
    </main>
    <AppFooter />
  </template>

  <ToastContainer />
</template>
```

- [ ] **Step 4: Verify toast system works**

Run: `cd frontend && npx vue-tsc --noEmit`
Expected: No type errors.

Start dev server and verify toast appears by temporarily calling `useToast().success('Test')` in any component.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/composables/useToast.ts frontend/src/components/common/ToastContainer.vue frontend/src/App.vue
git commit -m "feat(frontend): add toast notification system with composable and container

Implements §6.4 of web-app-ux-polish spec. Global provide/inject pattern,
auto-dismiss after 5s with progress bar, max 3 visible toasts."
```

---

### Task 2: Skeleton Loading States (§6.1)

**Files:**
- Create: `frontend/src/components/common/SkeletonTable.vue`
- Create: `frontend/src/components/common/SkeletonCard.vue`
- Modify: `frontend/src/views/TasksView.vue`
- Modify: `frontend/src/views/DashboardView.vue`

- [ ] **Step 1: Create SkeletonTable component**

Create `frontend/src/components/common/SkeletonTable.vue`:

```vue
<script setup lang="ts">
defineProps<{
  rows?: number
  columns?: number
}>()
</script>

<template>
  <div class="bg-surface-light dark:bg-slate-800 rounded-lg border border-border-light dark:border-slate-700 overflow-hidden">
    <!-- Header -->
    <div class="flex gap-4 px-4 py-3 bg-surface-light-alt dark:bg-slate-900/50 border-b border-border-light dark:border-slate-700">
      <div
        v-for="c in (columns ?? 5)"
        :key="c"
        class="h-3 rounded bg-slate-200 dark:bg-slate-700 animate-pulse"
        :class="c === 1 ? 'w-40' : 'w-20'"
      ></div>
    </div>
    <!-- Rows -->
    <div v-for="r in (rows ?? 6)" :key="r" class="flex items-center gap-4 px-4 py-3.5 border-b border-border-light/60 dark:border-slate-700/50 last:border-b-0">
      <div class="h-3 w-36 rounded bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
      <div class="h-3 w-24 rounded bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
      <div class="h-5 w-16 rounded-full bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
      <div class="h-1.5 w-16 rounded-full bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
      <div class="h-3 w-12 rounded bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Create SkeletonCard component**

Create `frontend/src/components/common/SkeletonCard.vue`:

```vue
<script setup lang="ts">
defineProps<{ count?: number }>()
</script>

<template>
  <div class="space-y-2">
    <div
      v-for="i in (count ?? 4)"
      :key="i"
      class="p-3 border border-border-light/60 dark:border-slate-800 rounded-lg"
    >
      <div class="flex items-center gap-2 mb-2">
        <div class="h-4 w-40 rounded bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
        <div class="h-5 w-16 rounded-full bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
      </div>
      <div class="flex items-center gap-3">
        <div class="h-3 w-16 rounded bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
        <div class="h-1.5 w-24 rounded-full bg-slate-200 dark:bg-slate-700 animate-pulse"></div>
      </div>
    </div>
  </div>
</template>
```

- [ ] **Step 3: Replace LoadingSpinner in TasksView**

In `frontend/src/views/TasksView.vue`, replace the `LoadingSpinner` import and usage:

Replace:
```typescript
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
```
With:
```typescript
import SkeletonTable from '@/components/common/SkeletonTable.vue'
```

Replace:
```html
<LoadingSpinner v-if="isLoading" />
```
With:
```html
<SkeletonTable v-if="isLoading" :rows="6" :columns="5" />
```

- [ ] **Step 4: Replace LoadingSpinner in DashboardView**

In `frontend/src/views/DashboardView.vue`, replace the spinner:

Replace:
```typescript
import LoadingSpinner from '@/components/common/LoadingSpinner.vue'
```
With:
```typescript
import SkeletonCard from '@/components/common/SkeletonCard.vue'
```

Replace:
```html
<LoadingSpinner v-if="overviewLoading" />
```
With:
```html
<SkeletonCard v-if="overviewLoading" :count="4" />
```

- [ ] **Step 5: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/common/SkeletonTable.vue frontend/src/components/common/SkeletonCard.vue frontend/src/views/TasksView.vue frontend/src/views/DashboardView.vue
git commit -m "feat(frontend): add skeleton loaders for tasks and dashboard

Replaces LoadingSpinner with contextual SkeletonTable and SkeletonCard
components that match final rendered layouts. Implements §6.1."
```

---

### Task 3: Enhanced Empty States (§6.2)

**Files:**
- Modify: `frontend/src/components/common/EmptyState.vue`
- Modify: `frontend/src/views/TasksView.vue`

- [ ] **Step 1: Enhance EmptyState component**

Replace the entire `frontend/src/components/common/EmptyState.vue`:

```vue
<script setup lang="ts">
defineProps<{
  heading: string
  description?: string
  ctaText?: string
  ctaHref?: string
  icon?: 'document' | 'check' | 'search' | 'chart' | 'code'
}>()

defineEmits<{ 'cta-click': [] }>()
</script>

<template>
  <div class="text-center py-16">
    <!-- Icons -->
    <svg v-if="icon === 'check' || !icon" class="mx-auto h-12 w-12 text-slate-300 dark:text-slate-600 mb-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
    <svg v-else-if="icon === 'document'" class="mx-auto h-12 w-12 text-slate-300 dark:text-slate-600 mb-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
    </svg>
    <svg v-else-if="icon === 'search'" class="mx-auto h-12 w-12 text-slate-300 dark:text-slate-600 mb-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
    </svg>
    <svg v-else-if="icon === 'chart'" class="mx-auto h-12 w-12 text-slate-300 dark:text-slate-600 mb-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" />
    </svg>
    <svg v-else-if="icon === 'code'" class="mx-auto h-12 w-12 text-slate-300 dark:text-slate-600 mb-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 6.75 22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3-4.5 16.5" />
    </svg>

    <h3 class="text-lg font-medium text-slate-700 dark:text-slate-300 mb-2">{{ heading }}</h3>
    <p v-if="description" class="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">{{ description }}</p>
    <a
      v-if="ctaText && ctaHref"
      :href="ctaHref"
      class="inline-flex items-center gap-1.5 mt-4 px-4 py-2 text-sm rounded-md bg-accent-500 text-white hover:bg-accent-600 transition-colors"
    >{{ ctaText }}</a>
    <button
      v-else-if="ctaText"
      class="inline-flex items-center gap-1.5 mt-4 px-4 py-2 text-sm rounded-md bg-accent-500 text-white hover:bg-accent-600 transition-colors"
      @click="$emit('cta-click')"
    >{{ ctaText }}</button>
  </div>
</template>
```

- [ ] **Step 2: Update Tasks empty state**

In `frontend/src/views/TasksView.vue`, add the EmptyState import and update the empty section:

Add import:
```typescript
import EmptyState from '@/components/common/EmptyState.vue'
```

Replace the empty state div:
```html
    <!-- Empty state -->
    <div v-else class="text-center py-12 text-slate-500">
      <p class="text-lg font-medium">No tasks found</p>
      <p class="text-sm mt-1">All spec sections are done, or no specs have been created yet.</p>
    </div>
```
With:
```html
    <!-- Empty state -->
    <EmptyState
      v-else
      icon="check"
      :heading="statusFilter || repoFilter ? 'All caught up — no open tasks' : 'Create your first spec to generate tasks'"
      :description="statusFilter || repoFilter ? 'Try changing your filters to see more tasks.' : 'Specs define features with acceptance criteria that become trackable tasks.'"
      :cta-text="statusFilter || repoFilter ? 'Clear filters' : undefined"
      @cta-click="statusFilter = ''; repoFilter = ''"
    />
```

- [ ] **Step 3: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/common/EmptyState.vue frontend/src/views/TasksView.vue
git commit -m "feat(frontend): enhance empty states with icons and CTA buttons

Updates EmptyState component with icon variants and button support.
Tasks page gets contextual empty state based on active filters. Implements §6.2."
```

---

### Task 4: Enhanced Keyboard Shortcuts (§6.5)

**Files:**
- Modify: `frontend/src/composables/useKeyboardShortcuts.ts`
- Create: `frontend/src/components/common/ShortcutsModal.vue`
- Modify: `frontend/src/App.vue`

- [ ] **Step 1: Rewrite useKeyboardShortcuts with two-key combos and input suppression**

Replace `frontend/src/composables/useKeyboardShortcuts.ts`:

```typescript
import { onMounted, onUnmounted, ref } from 'vue'

type ShortcutHandler = (e: KeyboardEvent) => void

export interface Shortcut {
  /** Single key like 'k' or '/' or 'Escape' */
  key: string
  /** Require Cmd/Ctrl */
  meta?: boolean
  /** Require Shift */
  shift?: boolean
  handler: ShortcutHandler
  /** Human-readable label for the shortcuts modal */
  label?: string
}

export interface TwoKeyShortcut {
  /** First key (e.g., 'g') */
  first: string
  /** Second key (e.g., 't') */
  second: string
  handler: ShortcutHandler
  label?: string
}

function isInputFocused(): boolean {
  const el = document.activeElement
  if (!el) return false
  const tag = el.tagName.toLowerCase()
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return true
  if ((el as HTMLElement).contentEditable === 'true') return true
  // Monaco editor detection
  if (el.closest('.monaco-editor')) return true
  return false
}

const pendingFirstKey = ref<string | null>(null)
let pendingTimeout: ReturnType<typeof setTimeout> | null = null

export function useKeyboardShortcuts(
  shortcuts: Shortcut[],
  twoKey?: TwoKeyShortcut[],
) {
  function onKeydown(e: KeyboardEvent) {
    // Suppress all shortcuts when inside text inputs
    if (isInputFocused()) return

    // Handle two-key combos
    if (twoKey?.length) {
      if (pendingFirstKey.value) {
        const first = pendingFirstKey.value
        pendingFirstKey.value = null
        if (pendingTimeout) clearTimeout(pendingTimeout)
        const match = twoKey.find(s => s.first === first && s.second === e.key)
        if (match) {
          e.preventDefault()
          match.handler(e)
          return
        }
      }

      const hasFirst = twoKey.some(s => s.first === e.key)
      if (hasFirst && !e.metaKey && !e.ctrlKey && !e.shiftKey) {
        pendingFirstKey.value = e.key
        if (pendingTimeout) clearTimeout(pendingTimeout)
        pendingTimeout = setTimeout(() => { pendingFirstKey.value = null }, 500)
        return
      }
    }

    // Handle single-key shortcuts
    for (const s of shortcuts) {
      const metaMatch = s.meta ? (e.metaKey || e.ctrlKey) : !(e.metaKey || e.ctrlKey)
      const shiftMatch = s.shift ? e.shiftKey : !e.shiftKey
      if (e.key === s.key && metaMatch && shiftMatch) {
        e.preventDefault()
        s.handler(e)
        return
      }
    }
  }

  onMounted(() => document.addEventListener('keydown', onKeydown))
  onUnmounted(() => document.removeEventListener('keydown', onKeydown))
}
```

- [ ] **Step 2: Create ShortcutsModal component**

Create `frontend/src/components/common/ShortcutsModal.vue`:

```vue
<script setup lang="ts">
defineEmits<{ close: [] }>()

const shortcuts = [
  { keys: ['/', 'Cmd+K'], description: 'Focus search' },
  { keys: ['g t'], description: 'Go to Tasks' },
  { keys: ['g a'], description: 'Go to Analytics' },
  { keys: ['g e'], description: 'Go to Editor' },
  { keys: ['Escape'], description: 'Close modal / panel' },
  { keys: ['?'], description: 'Show this help' },
]
</script>

<template>
  <div class="fixed inset-0 z-50 flex items-center justify-center">
    <div class="absolute inset-0 bg-black/50" @click="$emit('close')"></div>
    <div class="relative bg-surface-light dark:bg-slate-800 rounded-lg shadow-xl border border-border-light dark:border-slate-700 w-full max-w-md mx-4 p-6">
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-bold font-display text-slate-800 dark:text-slate-100">Keyboard Shortcuts</h2>
        <button class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300" @click="$emit('close')">&times;</button>
      </div>
      <div class="space-y-3">
        <div v-for="s in shortcuts" :key="s.description" class="flex items-center justify-between">
          <span class="text-sm text-slate-600 dark:text-slate-300">{{ s.description }}</span>
          <div class="flex gap-1">
            <kbd
              v-for="k in s.keys"
              :key="k"
              class="px-2 py-0.5 text-xs font-mono rounded border border-slate-300 dark:border-slate-600 bg-surface-light-alt dark:bg-slate-900 text-slate-600 dark:text-slate-300"
            >{{ k }}</kbd>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
```

- [ ] **Step 3: Wire up global shortcuts in App.vue**

In `frontend/src/App.vue`, add the global keyboard shortcuts:

```vue
<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import AppNav from '@/components/layout/AppNav.vue'
import AppFooter from '@/components/layout/AppFooter.vue'
import ToastContainer from '@/components/common/ToastContainer.vue'
import ShortcutsModal from '@/components/common/ShortcutsModal.vue'
import { provideToast } from '@/composables/useToast'
import { useKeyboardShortcuts } from '@/composables/useKeyboardShortcuts'
import { useAuthStore } from '@/stores/auth'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const isPublic = computed(() => route.meta.public === true)
const showShortcuts = ref(false)

provideToast()

useKeyboardShortcuts(
  [
    {
      key: '/',
      handler: () => {
        const el = document.querySelector<HTMLInputElement>('[data-search-input]')
        el?.focus()
      },
    },
    {
      key: 'k',
      meta: true,
      handler: () => {
        const el = document.querySelector<HTMLInputElement>('[data-search-input]')
        el?.focus()
      },
    },
    {
      key: 'Escape',
      handler: () => { showShortcuts.value = false },
    },
    {
      key: '?',
      handler: () => { showShortcuts.value = !showShortcuts.value },
    },
  ],
  [
    { first: 'g', second: 't', handler: () => router.push(`/app/${auth.org}/tasks`) },
    { first: 'g', second: 'a', handler: () => router.push(`/app/${auth.org}/analytics`) },
    { first: 'g', second: 'e', handler: () => router.push(`/app/${auth.org}/editor`) },
  ],
)
</script>

<template>
  <!-- Marketing pages render their own layout -->
  <router-view v-if="isPublic" />

  <!-- App pages use the shared chrome -->
  <template v-else>
    <div class="h-0.5 bg-accent-500"></div>
    <AppNav />
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <router-view />
    </main>
    <AppFooter />
  </template>

  <ToastContainer />
  <ShortcutsModal v-if="showShortcuts" @close="showShortcuts = false" />
</template>
```

- [ ] **Step 4: Add data-search-input attribute to SearchBar**

In `frontend/src/components/layout/SearchBar.vue`, add `data-search-input` to the search input element so the `/` shortcut can find it.

- [ ] **Step 5: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/composables/useKeyboardShortcuts.ts frontend/src/components/common/ShortcutsModal.vue frontend/src/App.vue frontend/src/components/layout/SearchBar.vue
git commit -m "feat(frontend): enhanced keyboard shortcuts with two-key combos and help modal

Adds vim-style g+t/a/e navigation, / and Cmd+K for search focus,
? for shortcuts modal, Escape to close modals. Input suppression
prevents shortcuts from firing inside text fields. Implements §6.5."
```

---

## Phase 2: Navigation

### Task 5: Active Page Indicator (§4.2)

**Files:**
- Modify: `frontend/src/components/layout/AppNav.vue`

- [ ] **Step 1: Add active state styling to nav links**

In `frontend/src/components/layout/AppNav.vue`, add route-based active state:

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import OrgSwitcher from './OrgSwitcher.vue'
import SearchBar from './SearchBar.vue'
import ThemeToggle from './ThemeToggle.vue'
import MobileMenu from './MobileMenu.vue'

const auth = useAuthStore()
const route = useRoute()
const mobileMenuOpen = ref(false)

const navItems = computed(() => [
  { label: 'Tasks', to: `/app/${auth.org}/tasks`, match: 'tasks' },
  { label: 'Analytics', to: `/app/${auth.org}/analytics`, match: 'analytics' },
  { label: 'Editor', to: `/app/${auth.org}/editor`, match: 'editor' },
  { label: 'Billing', to: `/app/${auth.org}/billing`, match: 'billing' },
])

function isActive(match: string): boolean {
  const name = route.name as string | undefined
  if (!name) return false
  return name.startsWith(match) || name === match
}
</script>

<template>
  <nav class="bg-surface-light-alt/80 dark:bg-surface/90 backdrop-blur border-b border-border-light dark:border-slate-800">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between h-14 items-center">
        <div class="flex items-center gap-5">
          <router-link to="/" class="text-lg font-bold font-display text-accent-500 tracking-[-0.03em]">
            Canon
          </router-link>
          <router-link
            :to="`/app/${auth.org}/`"
            class="text-xs font-mono uppercase tracking-wider hidden sm:inline transition-colors"
            :class="route.name === 'dashboard' ? 'text-accent-500' : 'text-slate-400 dark:text-slate-500 hover:text-accent-400'"
          >Explorer</router-link>
        </div>

        <!-- Desktop nav -->
        <div class="hidden sm:flex items-center gap-4">
          <router-link
            v-for="item in navItems"
            :key="item.match"
            :to="item.to"
            class="text-sm transition-colors relative py-1"
            :class="isActive(item.match) ? 'text-accent-500 font-medium' : 'text-slate-600 dark:text-slate-400 hover:text-accent-400'"
          >
            {{ item.label }}
            <span
              v-if="isActive(item.match)"
              class="absolute -bottom-[17px] left-0 right-0 h-0.5 bg-accent-500 rounded-full"
            ></span>
          </router-link>
          <OrgSwitcher v-if="auth.orgs.length > 1" />
          <SearchBar />
          <template v-if="auth.user">
            <router-link
              :to="`/app/${auth.org}/profile`"
              class="text-sm text-slate-600 dark:text-slate-400 hover:text-accent-400 transition-colors"
            >
              {{ auth.user.email }}
            </router-link>
            <a v-if="!auth.hasGitHub" href="/auth/github/login" class="text-sm text-accent-400 hover:text-accent-300 transition-colors">Connect GitHub</a>
            <a href="/auth/logout" class="text-sm text-slate-500 hover:text-accent-400 transition-colors">Logout</a>
          </template>
          <ThemeToggle />
        </div>

        <!-- Hamburger (mobile) -->
        <button
          type="button"
          class="sm:hidden p-1.5 rounded-md text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-surface-light-elevated dark:hover:bg-slate-700 transition-colors"
          @click="mobileMenuOpen = !mobileMenuOpen"
        >
          <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
          </svg>
        </button>
      </div>
    </div>

    <MobileMenu v-if="mobileMenuOpen" @close="mobileMenuOpen = false" />
  </nav>
</template>
```

- [ ] **Step 2: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/layout/AppNav.vue
git commit -m "feat(frontend): add active page indicator to nav bar

Current page gets accent color text and underline indicator derived
from route name matching. Profile/Logout excluded. Implements §4.2."
```

---

### Task 6: Route-Aware Breadcrumbs (§4.1)

**Files:**
- Modify: `frontend/src/components/layout/Breadcrumb.vue`
- Modify: `frontend/src/views/TasksView.vue`
- Modify: `frontend/src/views/DashboardView.vue`

- [ ] **Step 1: Extend Breadcrumb to support auto-generation mode**

Replace `frontend/src/components/layout/Breadcrumb.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

export interface BreadcrumbItem {
  label: string
  to?: string
}

const props = defineProps<{
  /** Manual items override auto-generation */
  items?: BreadcrumbItem[]
}>()

const route = useRoute()
const auth = useAuthStore()

function truncate(s: string, max: number): string {
  return s.length > max ? s.slice(0, max) + '…' : s
}

const autoItems = computed<BreadcrumbItem[]>(() => {
  if (props.items) return props.items

  const org = auth.org
  const base: BreadcrumbItem[] = [{ label: org, to: `/app/${org}/` }]
  const name = route.name as string | undefined

  if (name === 'dashboard') return base
  if (name === 'tasks') return [...base, { label: 'Tasks' }]
  if (name === 'analytics') return [...base, { label: 'Analytics' }]
  if (name === 'billing') return [...base, { label: 'Billing' }]
  if (name === 'profile') return [...base, { label: 'Profile' }]
  if (name === 'search') return [...base, { label: 'Search' }]

  if (name === 'repo') {
    const owner = route.params.owner as string
    const repo = route.params.repo as string
    return [...base, { label: `${owner}/${repo}` }]
  }

  if (name === 'spec') {
    const owner = route.params.owner as string
    const repo = route.params.repo as string
    const path = route.params.path as string
    const specName = truncate(path.split('/').pop()?.replace('.md', '') ?? path, 40)
    return [
      ...base,
      { label: `${owner}/${repo}`, to: `/app/${org}/repos/${owner}/${repo}` },
      { label: specName },
    ]
  }

  if (name?.startsWith('editor')) {
    const owner = route.params.owner as string | undefined
    const repo = route.params.repo as string | undefined
    if (owner && repo) {
      return [
        ...base,
        { label: 'Editor', to: `/app/${org}/editor` },
        { label: `${owner}/${repo}` },
      ]
    }
    return [...base, { label: 'Editor' }]
  }

  return base
})

const displayItems = computed(() => props.items ?? autoItems.value)
</script>

<template>
  <nav class="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400 mb-6">
    <template v-for="(item, i) in displayItems" :key="i">
      <span v-if="i > 0" class="text-slate-300 dark:text-slate-600">/</span>
      <router-link v-if="item.to" :to="item.to" class="hover:text-accent-500 transition-colors">{{ item.label }}</router-link>
      <span v-else class="text-slate-800 dark:text-slate-200 font-medium">{{ item.label }}</span>
    </template>
  </nav>
</template>
```

- [ ] **Step 2: Add auto breadcrumbs to TasksView**

In `frontend/src/views/TasksView.vue`, add the breadcrumb at the top of the template:

Add import:
```typescript
import Breadcrumb from '@/components/layout/Breadcrumb.vue'
```

Add `<Breadcrumb />` as the first child inside the root `<div>` in the template (before the flex header).

- [ ] **Step 3: Add auto breadcrumbs to DashboardView**

In `frontend/src/views/DashboardView.vue`, add:

Add import:
```typescript
import Breadcrumb from '@/components/layout/Breadcrumb.vue'
```

Wrap the template content and add `<Breadcrumb />` at the top.

- [ ] **Step 4: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/layout/Breadcrumb.vue frontend/src/views/TasksView.vue frontend/src/views/DashboardView.vue
git commit -m "feat(frontend): route-aware auto-generating breadcrumbs

Breadcrumb component now auto-generates segments from route name and
params when no manual items prop is passed. Truncates long spec titles
at 40 chars. Added to Tasks and Dashboard views. Implements §4.1."
```

---

### Task 7: Cross-linking Between Views (§4.3)

**Files:**
- Create: `frontend/src/components/common/TicketBadge.vue`
- Modify: `frontend/src/views/TasksView.vue`
- Modify: `frontend/src/components/editor/EditorList.vue`

- [ ] **Step 1: Create TicketBadge component**

Create `frontend/src/components/common/TicketBadge.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  system: string
  ticketId: string
  ticketProject?: string
}>()

const url = computed(() => {
  if (props.system === 'github' && props.ticketProject) {
    return `https://github.com/${props.ticketProject}/issues/${props.ticketId}`
  }
  return null
})

const label = computed(() => `${props.system}#${props.ticketId}`)
</script>

<template>
  <a
    v-if="url"
    :href="url"
    target="_blank"
    rel="noopener noreferrer"
    class="inline-flex items-center gap-1 px-1.5 py-0.5 text-xs rounded border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-accent-500 hover:text-accent-500 transition-colors"
  >
    <!-- GitHub icon -->
    <svg v-if="system === 'github'" class="w-3 h-3" viewBox="0 0 16 16" fill="currentColor">
      <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/>
    </svg>
    {{ label }}
  </a>
  <span v-else class="text-xs text-slate-400">{{ label }}</span>
</template>
```

- [ ] **Step 2: Update TasksView to use TicketBadge and add spec view links**

In `frontend/src/views/TasksView.vue`, replace the ticket column cell:

Replace:
```html
            <td class="px-4 py-3 text-xs text-slate-400">
              <span v-if="task.ticket_id">
                {{ task.ticket_system }}#{{ task.ticket_id }}
              </span>
              <span v-else class="text-slate-300 dark:text-slate-600">&mdash;</span>
            </td>
```
With:
```html
            <td class="px-4 py-3 text-xs text-slate-400">
              <TicketBadge
                v-if="task.ticket_id && task.ticket_system"
                :system="task.ticket_system"
                :ticket-id="task.ticket_id"
                ticket-project="canonhq/canon"
              />
              <span v-else class="text-slate-300 dark:text-slate-600">&mdash;</span>
            </td>
```

Add import: `import TicketBadge from '@/components/common/TicketBadge.vue'`

- [ ] **Step 3: Add "View" links to EditorList repo cards**

In `frontend/src/components/editor/EditorList.vue`, add a link to view specs for each repo:

After the `+ New Spec` router-link, add:
```html
        <router-link
          :to="`/app/${auth.org}/repos/${repo.owner.login}/${repo.name}`"
          class="text-xs text-slate-400 hover:text-accent-400 ml-3"
        >
          View specs
        </router-link>
```

- [ ] **Step 4: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/common/TicketBadge.vue frontend/src/views/TasksView.vue frontend/src/components/editor/EditorList.vue
git commit -m "feat(frontend): add ticket link badges and cross-view links

TicketBadge renders github#N as clickable links to GitHub Issues.
Editor repo list gets 'View specs' link. Implements §2.4 and §4.3."
```

---

## Phase 3: Tasks Board

### Task 8: Backend — Expand ACs in Tasks API (§7.2)

**Files:**
- Modify: `src/canon/web/models.py`
- Modify: `src/canon/web/services.py`
- Modify: `src/canon/web/routes.py`
- Modify: `frontend/src/api/types.ts`
- Modify: `frontend/src/api/tasks.ts`
- Create: `tests/test_web/test_tasks_expand.py`

- [ ] **Step 1: Write failing test for expand=acs**

Create `tests/test_web/test_tasks_expand.py`:

```python
"""Tests for the Tasks API ?expand=acs parameter."""

from canon.web.models import TaskItem


def test_task_item_has_acceptance_criteria_field():
    """TaskItem should have an optional acceptance_criteria field."""
    item = TaskItem(
        section_id="1",
        title="Test",
        status="todo",
        acceptance_criteria=[
            {"text": "AC one", "checked": False},
            {"text": "AC two", "checked": True},
        ],
    )
    assert len(item.acceptance_criteria) == 2
    assert item.acceptance_criteria[0]["text"] == "AC one"
    assert item.acceptance_criteria[0]["checked"] is False
    assert item.acceptance_criteria[1]["checked"] is True


def test_task_item_acceptance_criteria_defaults_empty():
    """When not provided, acceptance_criteria should default to empty list."""
    item = TaskItem(section_id="1", title="Test", status="todo")
    assert item.acceptance_criteria == []
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_web/test_tasks_expand.py -v`
Expected: FAIL — `TaskItem` doesn't have `acceptance_criteria` field.

- [ ] **Step 3: Add acceptance_criteria field to TaskItem model**

In `src/canon/web/models.py`, add to the `TaskItem` class:

After `repo_name: str = ""` add:
```python
    acceptance_criteria: list[dict[str, object]] = []
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_web/test_tasks_expand.py -v`
Expected: PASS

- [ ] **Step 5: Update services.py to populate ACs when expand=acs**

In `src/canon/web/services.py`, modify `get_tasks` to accept and use an `expand` parameter:

Change the function signature to add `expand: str | None = None`:
```python
async def get_tasks(
    client: GitHubClient,
    org: str,
    cache: TTLCache,
    *,
    status: str | None = None,
    repo_filter: str | None = None,
    search_index: object | None = None,
    expand: str | None = None,
) -> TasksApiResponse:
```

In the `tasks.append(TaskItem(...))` call, add:
```python
                        acceptance_criteria=[
                            {"text": ac.text, "checked": ac.checked}
                            for ac in section.acceptance_criteria
                        ] if expand == "acs" else [],
```

- [ ] **Step 6: Update routes.py to pass expand param**

In `src/canon/web/routes.py`, at the `api_tasks` function, add the expand query parameter:

```python
@app_router.get("/{org}/api/tasks", response_class=JSONResponse)
async def api_tasks(
    request: Request,
    org: str,
    status: str | None = None,
    repo: str | None = None,
    expand: str | None = None,
) -> JSONResponse:
```

And pass it to `get_tasks`:
```python
    result = await get_tasks(
        client, org, cache, status=status, repo_filter=repo, search_index=search_index, expand=expand
    )
```

- [ ] **Step 7: Update frontend types and API**

In `frontend/src/api/types.ts`, add to `TaskItem`:
```typescript
  acceptance_criteria: { text: string; checked: boolean }[]
```

In `frontend/src/api/tasks.ts`, add expand support:
```typescript
export function fetchTasks(
  org: string,
  opts?: { status?: string; repo?: string; expand?: string },
): Promise<TasksApiResponse> {
  const query = new URLSearchParams()
  if (opts?.status) query.set('status', opts.status)
  if (opts?.repo) query.set('repo', opts.repo)
  if (opts?.expand) query.set('expand', opts.expand)
  const qs = query.toString()
  return get<TasksApiResponse>(`/app/${org}/api/tasks${qs ? `?${qs}` : ''}`)
}
```

- [ ] **Step 8: Run full test suite and commit**

Run: `uv run pytest tests/test_web/test_tasks_expand.py -v`
Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add src/canon/web/models.py src/canon/web/services.py src/canon/web/routes.py frontend/src/api/types.ts frontend/src/api/tasks.ts tests/test_web/test_tasks_expand.py
git commit -m "feat(api): add expand=acs param to tasks API for inline AC expansion

TaskItem model now has an optional acceptance_criteria field, populated
when ?expand=acs is passed. Avoids fetching full specs on the frontend
for AC display. Implements §7.2."
```

---

### Task 9: View Toggle + useViewPreference (§2.2)

**Files:**
- Create: `frontend/src/composables/useViewPreference.ts`
- Modify: `frontend/src/views/TasksView.vue`

- [ ] **Step 1: Create useViewPreference composable**

Create `frontend/src/composables/useViewPreference.ts`:

```typescript
import { ref, watch } from 'vue'

export function useViewPreference<T extends string>(key: string, defaultValue: T) {
  const stored = localStorage.getItem(key) as T | null
  const value = ref<T>(stored ?? defaultValue) as import('vue').Ref<T>

  watch(value, (v) => {
    localStorage.setItem(key, v)
  })

  return value
}
```

- [ ] **Step 2: Add view toggle UI to TasksView**

In `frontend/src/views/TasksView.vue`, add the view toggle buttons in the page header:

Add imports:
```typescript
import { useViewPreference } from '@/composables/useViewPreference'

type TasksViewMode = 'list' | 'board' | 'grouped'
const viewMode = useViewPreference<TasksViewMode>('tasks-view-mode', 'grouped')
```

Add toggle buttons in the header section (after the subtitle `<p>` tag):

```html
      <div class="flex items-center gap-1 bg-surface-light-alt dark:bg-slate-900/50 rounded-lg p-0.5 border border-border-light dark:border-slate-700">
        <button
          v-for="mode in (['grouped', 'list', 'board'] as TasksViewMode[])"
          :key="mode"
          class="px-3 py-1 text-xs font-medium rounded-md transition-colors capitalize"
          :class="viewMode === mode ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'"
          @click="viewMode = mode"
        >{{ mode }}</button>
      </div>
```

- [ ] **Step 3: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/composables/useViewPreference.ts frontend/src/views/TasksView.vue
git commit -m "feat(frontend): add tasks view toggle with localStorage persistence

Adds List / Board / Grouped toggle to tasks page header. View
preference persisted via useViewPreference composable. Implements §2.2."
```

---

### Task 10: Tasks Grouped View (§2.1)

**Files:**
- Create: `frontend/src/components/tasks/TasksGroupedView.vue`
- Modify: `frontend/src/views/TasksView.vue`

- [ ] **Step 1: Create TasksGroupedView component**

Create `frontend/src/components/tasks/TasksGroupedView.vue`:

```vue
<script setup lang="ts">
import { computed, ref } from 'vue'
import type { TaskItem } from '@/api/types'
import { useAuthStore } from '@/stores/auth'
import StatusBadge from '@/components/common/StatusBadge.vue'
import TicketBadge from '@/components/common/TicketBadge.vue'

const props = defineProps<{ tasks: TaskItem[] }>()
defineEmits<{ 'select-task': [task: TaskItem] }>()

const auth = useAuthStore()
const expandedGroups = ref<Set<string>>(new Set())

interface SpecGroup {
  key: string
  specTitle: string
  repoOwner: string
  repoName: string
  specFilePath: string
  tasks: TaskItem[]
  totalAc: number
  doneAc: number
  statusCounts: Record<string, number>
}

const groups = computed<SpecGroup[]>(() => {
  const map = new Map<string, SpecGroup>()

  for (const task of props.tasks) {
    const key = `${task.repo_owner}/${task.repo_name}/${task.spec_file_path}`
    let group = map.get(key)
    if (!group) {
      group = {
        key,
        specTitle: task.spec_title,
        repoOwner: task.repo_owner,
        repoName: task.repo_name,
        specFilePath: task.spec_file_path,
        tasks: [],
        totalAc: 0,
        doneAc: 0,
        statusCounts: {},
      }
      map.set(key, group)
    }
    group.tasks.push(task)
    group.totalAc += task.total_ac
    group.doneAc += task.done_ac
    group.statusCounts[task.status] = (group.statusCounts[task.status] ?? 0) + 1
  }

  // Sort: in_progress first, then todo, then blocked
  const priority: Record<string, number> = { in_progress: 0, todo: 1, blocked: 2 }
  return [...map.values()].sort((a, b) => {
    const aMin = Math.min(...Object.keys(a.statusCounts).map(s => priority[s] ?? 3))
    const bMin = Math.min(...Object.keys(b.statusCounts).map(s => priority[s] ?? 3))
    return aMin - bMin
  })
})

function toggleGroup(key: string) {
  if (expandedGroups.value.has(key)) {
    expandedGroups.value.delete(key)
  } else {
    expandedGroups.value.add(key)
  }
}

function acPercent(done: number, total: number): number {
  return total > 0 ? Math.round((done / total) * 100) : 0
}
</script>

<template>
  <div class="space-y-3">
    <div
      v-for="group in groups"
      :key="group.key"
      class="bg-surface-light dark:bg-slate-800 rounded-lg border border-border-light dark:border-slate-700 overflow-hidden"
    >
      <!-- Group header -->
      <button
        class="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-surface-light-alt dark:hover:bg-slate-700/30 transition-colors"
        @click="toggleGroup(group.key)"
      >
        <svg
          class="w-4 h-4 text-slate-400 transition-transform shrink-0"
          :class="expandedGroups.has(group.key) ? 'rotate-90' : ''"
          fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
        >
          <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
        </svg>
        <router-link
          :to="`/app/${auth.org}/specs/${group.repoOwner}/${group.repoName}/${group.specFilePath}`"
          class="font-medium text-sm text-slate-800 dark:text-slate-100 hover:text-accent-500"
          @click.stop
        >{{ group.specTitle }}</router-link>
        <span class="text-xs text-slate-400">{{ group.repoOwner }}/{{ group.repoName }}</span>
        <div class="flex-1"></div>
        <!-- Status counts -->
        <span v-if="group.statusCounts.in_progress" class="text-xs text-blue-500">{{ group.statusCounts.in_progress }} in progress</span>
        <span v-if="group.statusCounts.todo" class="text-xs text-yellow-500">{{ group.statusCounts.todo }} todo</span>
        <span v-if="group.statusCounts.blocked" class="text-xs text-red-500">{{ group.statusCounts.blocked }} blocked</span>
        <!-- Progress bar -->
        <div class="w-20 h-1.5 bg-border-light dark:bg-slate-600 rounded-full overflow-hidden">
          <div
            class="h-full rounded-full bg-accent-500"
            :style="{ width: `${acPercent(group.doneAc, group.totalAc)}%` }"
          ></div>
        </div>
        <span class="text-xs text-slate-400">{{ group.doneAc }}/{{ group.totalAc }}</span>
      </button>

      <!-- Expanded tasks -->
      <div v-if="expandedGroups.has(group.key)" class="border-t border-border-light dark:border-slate-700">
        <div
          v-for="task in group.tasks"
          :key="task.section_id"
          class="flex items-center gap-3 px-4 py-2.5 pl-10 hover:bg-surface-light-alt dark:hover:bg-slate-700/30 transition-colors cursor-pointer border-b border-border-light/40 dark:border-slate-700/30 last:border-b-0"
          @click="$emit('select-task', task)"
        >
          <span v-if="task.section_number" class="text-xs text-slate-400 w-6 text-right">{{ task.section_number }}</span>
          <span class="text-sm text-slate-700 dark:text-slate-200 flex-1">{{ task.title }}</span>
          <StatusBadge :status="task.status" />
          <div class="w-16 h-1.5 bg-border-light dark:bg-slate-600 rounded-full overflow-hidden">
            <div
              class="h-full rounded-full"
              :class="acPercent(task.done_ac, task.total_ac) === 100 ? 'bg-green-500' : 'bg-accent-500'"
              :style="{ width: `${acPercent(task.done_ac, task.total_ac)}%` }"
            ></div>
          </div>
          <span class="text-xs text-slate-400 w-10">{{ task.done_ac }}/{{ task.total_ac }}</span>
          <TicketBadge
            v-if="task.ticket_id && task.ticket_system"
            :system="task.ticket_system"
            :ticket-id="task.ticket_id"
            ticket-project="canonhq/canon"
          />
        </div>
      </div>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Wire grouped view into TasksView**

In `frontend/src/views/TasksView.vue`, import and conditionally render the grouped view:

Add import:
```typescript
import TasksGroupedView from '@/components/tasks/TasksGroupedView.vue'
```

Replace the tasks table section (the `v-else-if="tasks.length > 0"` div containing the `<table>`) with a conditional that checks `viewMode`:

```html
    <!-- Tasks views -->
    <template v-else-if="tasks.length > 0">
      <!-- Grouped view -->
      <TasksGroupedView v-if="viewMode === 'grouped'" :tasks="tasks" @select-task="selectedTask = $event" />

      <!-- List view (existing table) -->
      <div v-else-if="viewMode === 'list'" class="bg-surface-light dark:bg-slate-800 rounded-lg border border-border-light dark:border-slate-700 overflow-hidden">
        <!-- ... existing table code ... -->
      </div>
    </template>
```

Add a `selectedTask` ref:
```typescript
const selectedTask = ref<TaskItem | null>(null)
```

- [ ] **Step 3: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/tasks/TasksGroupedView.vue frontend/src/views/TasksView.vue
git commit -m "feat(frontend): add grouped view for tasks board

Tasks are grouped by parent spec with collapsible sections showing
status counts, AC progress, and ticket links. Groups sorted by
priority (in_progress > todo > blocked). Implements §2.1."
```

---

### Task 11: Tasks Board View (§2.2)

**Files:**
- Create: `frontend/src/components/tasks/TasksBoardView.vue`
- Modify: `frontend/src/views/TasksView.vue`

- [ ] **Step 1: Create TasksBoardView component**

Create `frontend/src/components/tasks/TasksBoardView.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'
import type { TaskItem } from '@/api/types'
import StatusBadge from '@/components/common/StatusBadge.vue'

const props = defineProps<{ tasks: TaskItem[] }>()
defineEmits<{ 'select-task': [task: TaskItem] }>()

const columns = computed(() => {
  const todo = props.tasks.filter(t => t.status === 'todo')
  const inProgress = props.tasks.filter(t => t.status === 'in_progress')
  const blocked = props.tasks.filter(t => t.status === 'blocked')
  return [
    { label: 'Todo', status: 'todo', tasks: todo, color: 'border-yellow-400' },
    { label: 'In Progress', status: 'in_progress', tasks: inProgress, color: 'border-blue-400' },
    { label: 'Blocked', status: 'blocked', tasks: blocked, color: 'border-red-400' },
  ]
})

function acPercent(task: TaskItem): number {
  return task.total_ac > 0 ? Math.round((task.done_ac / task.total_ac) * 100) : 0
}
</script>

<template>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <div v-for="col in columns" :key="col.status">
      <div class="flex items-center gap-2 mb-3">
        <div class="w-1 h-4 rounded-full" :class="col.color.replace('border-', 'bg-')"></div>
        <h3 class="text-sm font-medium text-slate-700 dark:text-slate-300">{{ col.label }}</h3>
        <span class="text-xs text-slate-400">({{ col.tasks.length }})</span>
      </div>
      <div class="space-y-2">
        <div
          v-for="task in col.tasks"
          :key="task.section_id"
          class="p-3 bg-surface-light dark:bg-slate-800 rounded-lg border border-border-light dark:border-slate-700 hover:border-accent-500 dark:hover:border-accent-600 transition-colors cursor-pointer"
          @click="$emit('select-task', task)"
        >
          <div class="flex items-center gap-2 mb-1">
            <span v-if="task.section_number" class="text-xs text-slate-400">§{{ task.section_number }}</span>
            <span class="text-sm font-medium text-slate-800 dark:text-slate-100">{{ task.title }}</span>
          </div>
          <div class="text-xs text-slate-400 mb-2">{{ task.spec_title }}</div>
          <div class="flex items-center gap-2">
            <div class="flex-1 h-1.5 bg-border-light dark:bg-slate-600 rounded-full overflow-hidden">
              <div
                class="h-full rounded-full"
                :class="acPercent(task) === 100 ? 'bg-green-500' : 'bg-accent-500'"
                :style="{ width: `${acPercent(task)}%` }"
              ></div>
            </div>
            <span class="text-xs text-slate-400">{{ task.done_ac }}/{{ task.total_ac }}</span>
          </div>
        </div>
        <div v-if="col.tasks.length === 0" class="text-center py-8 text-xs text-slate-400">
          No {{ col.label.toLowerCase() }} tasks
        </div>
      </div>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Wire board view into TasksView**

In `frontend/src/views/TasksView.vue`, import and add the board view:

Add import:
```typescript
import TasksBoardView from '@/components/tasks/TasksBoardView.vue'
```

Add after the grouped view conditional:
```html
      <!-- Board view -->
      <TasksBoardView v-else-if="viewMode === 'board'" :tasks="tasks" @select-task="selectedTask = $event" />
```

- [ ] **Step 3: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/tasks/TasksBoardView.vue frontend/src/views/TasksView.vue
git commit -m "feat(frontend): add Kanban board view for tasks

Three-column layout (Todo, In Progress, Blocked) with cards showing
section title, spec name, and AC progress. Cards are read-only (no
drag-and-drop). Implements §2.2 board view."
```

---

### Task 12: Inline AC Expansion (§2.3)

**Files:**
- Create: `frontend/src/components/tasks/TaskDetailPanel.vue`
- Modify: `frontend/src/views/TasksView.vue`

- [ ] **Step 1: Create TaskDetailPanel component**

Create `frontend/src/components/tasks/TaskDetailPanel.vue`:

```vue
<script setup lang="ts">
import { useAuthStore } from '@/stores/auth'
import type { TaskItem } from '@/api/types'
import TicketBadge from '@/components/common/TicketBadge.vue'

defineProps<{ task: TaskItem }>()
defineEmits<{ close: [] }>()

const auth = useAuthStore()
</script>

<template>
  <div class="bg-surface-light-alt dark:bg-slate-900/50 border border-border-light dark:border-slate-700 rounded-lg p-4 mt-2">
    <div class="flex items-center justify-between mb-3">
      <h4 class="text-sm font-medium text-slate-800 dark:text-slate-100">
        <span v-if="task.section_number" class="text-slate-400 mr-1">§{{ task.section_number }}</span>
        {{ task.title }}
      </h4>
      <div class="flex items-center gap-2">
        <TicketBadge
          v-if="task.ticket_id && task.ticket_system"
          :system="task.ticket_system"
          :ticket-id="task.ticket_id"
          ticket-project="canonhq/canon"
        />
        <router-link
          :to="`/app/${auth.org}/specs/${task.repo_owner}/${task.repo_name}/${task.spec_file_path}`"
          class="text-xs text-accent-500 hover:text-accent-400"
        >View in spec</router-link>
        <button class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 text-sm" @click="$emit('close')">&times;</button>
      </div>
    </div>

    <!-- Acceptance criteria checklist -->
    <div v-if="task.acceptance_criteria && task.acceptance_criteria.length > 0" class="space-y-1.5">
      <div
        v-for="(ac, i) in task.acceptance_criteria"
        :key="i"
        class="flex items-start gap-2 text-sm"
      >
        <input type="checkbox" :checked="ac.checked" disabled class="mt-0.5 rounded border-slate-300 dark:border-slate-600" />
        <span :class="ac.checked ? 'line-through text-slate-400' : 'text-slate-700 dark:text-slate-300'">{{ ac.text }}</span>
      </div>
    </div>
    <p v-else class="text-xs text-slate-400">No acceptance criteria defined for this section.</p>
  </div>
</template>
```

- [ ] **Step 2: Wire TaskDetailPanel into TasksView**

In `frontend/src/views/TasksView.vue`:

Add import:
```typescript
import TaskDetailPanel from '@/components/tasks/TaskDetailPanel.vue'
```

Update the `fetchTasks` call to include `expand: 'acs'`:
```typescript
const { data, isLoading } = useQuery({
  queryKey: ['tasks', org, statusFilter, repoFilter],
  queryFn: () =>
    fetchTasks(org.value, {
      status: statusFilter.value || undefined,
      repo: repoFilter.value || undefined,
      expand: 'acs',
    }),
})
```

Add a handler for selecting/deselecting tasks:
```typescript
function handleSelectTask(task: TaskItem) {
  selectedTask.value = selectedTask.value?.section_id === task.section_id ? null : task
}
```

After the main tasks views block, add the detail panel:
```html
    <!-- Inline detail panel -->
    <TaskDetailPanel
      v-if="selectedTask"
      :task="selectedTask"
      @close="selectedTask = null"
    />
```

Wire the `select-task` events in each view to `handleSelectTask`.

- [ ] **Step 3: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/tasks/TaskDetailPanel.vue frontend/src/views/TasksView.vue
git commit -m "feat(frontend): add inline AC expansion panel for tasks

Clicking a task row shows acceptance criteria as a read-only checklist
below. Checked ACs get strikethrough styling. Includes 'View in spec'
link and ticket badge. Auto-collapses when selecting another task.
Implements §2.3."
```

---

## Phase 4: Explorer & Editor

### Task 13: Expandable Spec Cards + Enhancements (§3.1, §3.2)

**Files:**
- Create: `frontend/src/components/dashboard/SpecCardExpanded.vue`
- Modify: `frontend/src/components/dashboard/SpecList.vue`

- [ ] **Step 1: Create SpecCardExpanded component**

Create `frontend/src/components/dashboard/SpecCardExpanded.vue`:

```vue
<script setup lang="ts">
import { useQuery } from '@tanstack/vue-query'
import { useAuthStore } from '@/stores/auth'
import { fetchSpecDetail } from '@/api/specs'
import StatusBadge from '@/components/common/StatusBadge.vue'
import TicketBadge from '@/components/common/TicketBadge.vue'
import type { SpecSection } from '@/api/types'

const props = defineProps<{
  owner: string
  repo: string
  filePath: string
}>()

const auth = useAuthStore()

const { data: spec, isLoading } = useQuery({
  queryKey: ['spec-expanded', props.owner, props.repo, props.filePath],
  queryFn: () => fetchSpecDetail(auth.org, props.owner, props.repo, props.filePath),
})

function flattenSections(sections: SpecSection[]): SpecSection[] {
  const result: SpecSection[] = []
  for (const s of sections) {
    if (s.depth <= 2) result.push(s)
    if (s.children.length) result.push(...flattenSections(s.children))
  }
  return result
}

function statusDotColor(status: string): string {
  const map: Record<string, string> = {
    done: 'bg-green-500',
    in_progress: 'bg-blue-500',
    todo: 'bg-yellow-500',
    blocked: 'bg-red-500',
    draft: 'bg-slate-400',
  }
  return map[status] ?? 'bg-slate-400'
}

function acPercent(done: number, total: number): number {
  return total > 0 ? Math.round((done / total) * 100) : 0
}
</script>

<template>
  <div class="px-3 pb-3 pt-1 border-t border-border-light/60 dark:border-slate-700/50">
    <div v-if="isLoading" class="py-4 text-xs text-slate-400 text-center">Loading sections...</div>
    <div v-else-if="spec" class="space-y-1.5">
      <div
        v-for="section in flattenSections(spec.document.sections)"
        :key="section.id"
        class="flex items-center gap-2 text-xs py-1"
      >
        <span
          class="w-2 h-2 rounded-full shrink-0"
          :class="statusDotColor(typeof section.status === 'string' ? section.status : section.status.state)"
        ></span>
        <span v-if="section.section_number" class="text-slate-400 w-6 text-right">{{ section.section_number }}</span>
        <span class="text-slate-700 dark:text-slate-300 flex-1">{{ section.title }}</span>
        <div v-if="section.acceptance_criteria.length > 0" class="w-16 h-1 bg-border-light dark:bg-slate-600 rounded-full overflow-hidden">
          <div
            class="h-full rounded-full bg-accent-500"
            :style="{ width: `${acPercent(section.acceptance_criteria.filter(a => a.checked).length, section.acceptance_criteria.length)}%` }"
          ></div>
        </div>
        <span v-if="section.acceptance_criteria.length > 0" class="text-slate-400">
          {{ section.acceptance_criteria.filter(a => a.checked).length }}/{{ section.acceptance_criteria.length }}
        </span>
        <TicketBadge
          v-if="section.ticket_link"
          :system="section.ticket_link.system"
          :ticket-id="section.ticket_link.ticket_id"
          ticket-project="canonhq/canon"
        />
      </div>
    </div>
    <!-- Quick actions -->
    <div v-if="spec" class="flex items-center gap-3 mt-3 pt-2 border-t border-border-light/40 dark:border-slate-700/30">
      <router-link :to="`/app/${auth.org}/specs/${owner}/${repo}/${filePath}`" class="text-xs text-accent-500 hover:text-accent-400">View</router-link>
      <router-link :to="`/app/${auth.org}/editor/${owner}/${repo}/${filePath}`" class="text-xs text-accent-500 hover:text-accent-400">Edit</router-link>
      <router-link :to="`/app/${auth.org}/tasks?repo=${owner}/${repo}`" class="text-xs text-accent-500 hover:text-accent-400">Tasks</router-link>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Modify SpecList to support expandable cards with progress bars**

In `frontend/src/components/dashboard/SpecList.vue`:

Add imports:
```typescript
import { ref } from 'vue'
import SpecCardExpanded from './SpecCardExpanded.vue'
```

Add state:
```typescript
const expandedSpec = ref<string | null>(null)

function toggleExpand(key: string) {
  expandedSpec.value = expandedSpec.value === key ? null : key
}

function acPercent(done: number, total: number): number {
  return total > 0 ? Math.round((done / total) * 100) : 0
}

function progressColor(pct: number): string {
  if (pct > 80) return 'bg-green-500'
  if (pct >= 40) return 'bg-amber-500'
  return 'bg-red-500'
}

function daysAgo(dateStr: string): string {
  const days = Math.floor((Date.now() - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24))
  if (days === 0) return 'today'
  if (days === 1) return 'yesterday'
  return `${days}d ago`
}
```

Update each spec card to add expand chevron, mini progress bar, and expanded panel. Replace the spec `<router-link>` block with a `<div>` that contains a clickable header and an expandable detail:

```html
      <div
        v-for="spec in repo.specs"
        :key="spec.file_path"
        class="border border-border-light/60 dark:border-slate-800 rounded-lg hover:border-accent-500 dark:hover:border-accent-600 transition-colors overflow-hidden"
      >
        <router-link
          :to="`/app/${auth.org}/specs/${repo.owner}/${repo.repo}/${spec.file_path}`"
          class="block p-3"
        >
          <!-- Mini progress bar -->
          <div
            v-if="spec.total_ac > 0"
            class="h-0.5 rounded-full mb-2 bg-border-light dark:bg-slate-700 overflow-hidden"
          >
            <div
              class="h-full rounded-full"
              :class="progressColor(acPercent(spec.done_ac, spec.total_ac))"
              :style="{ width: `${acPercent(spec.done_ac, spec.total_ac)}%` }"
            ></div>
          </div>
          <div class="flex items-center gap-2 flex-wrap">
            <span class="font-medium text-sm text-slate-800 dark:text-slate-200">{{ spec.title }}</span>
            <StatusBadge :status="spec.status" />
            <span v-if="spec.is_indexed" class="text-xs px-1.5 py-0.5 rounded bg-blue-50 text-brand-600 dark:bg-blue-900/50 dark:text-blue-400">indexed</span>
            <span v-for="tag in spec.tags" :key="tag" class="text-xs px-1.5 py-0.5 rounded bg-surface-light-elevated text-gray-600 dark:bg-slate-800 dark:text-slate-400">{{ tag }}</span>
          </div>
          <div class="flex items-center gap-4 mt-2 text-xs text-slate-400">
            <span v-if="spec.owner">{{ spec.owner }}</span>
            <span v-if="spec.last_doc_change_at" class="text-slate-400">Updated {{ daysAgo(spec.last_doc_change_at) }}</span>
            <SpecProgressIndicator
              :status="spec.status"
              :total-sections="spec.total_sections"
              :done-sections="spec.done_sections"
              :total-ac="spec.total_ac"
              :done-ac="spec.done_ac"
              :is-stale="spec.is_stale"
              :stale-since="spec.stale_since"
            />
          </div>
        </router-link>
        <!-- Expand button -->
        <button
          class="w-full flex items-center justify-center py-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-surface-light-alt dark:hover:bg-slate-700/30 transition-colors"
          @click="toggleExpand(`${repo.owner}/${repo.repo}/${spec.file_path}`)"
        >
          <svg
            class="w-4 h-4 transition-transform"
            :class="expandedSpec === `${repo.owner}/${repo.repo}/${spec.file_path}` ? 'rotate-180' : ''"
            fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
          </svg>
        </button>
        <!-- Expanded detail -->
        <SpecCardExpanded
          v-if="expandedSpec === `${repo.owner}/${repo.repo}/${spec.file_path}`"
          :owner="repo.owner"
          :repo="repo.repo"
          :file-path="spec.file_path"
        />
      </div>
```

- [ ] **Step 3: Check if fetchSpecDetail exists in api/specs.ts**

Read `frontend/src/api/specs.ts` to verify the function exists. If not, add it:

```typescript
import { get } from './client'
import type { SpecDetail } from './types'

export function fetchSpecDetail(org: string, owner: string, repo: string, path: string): Promise<SpecDetail> {
  return get<SpecDetail>(`/app/${org}/api/specs/${owner}/${repo}/${path}`)
}
```

- [ ] **Step 4: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/dashboard/SpecCardExpanded.vue frontend/src/components/dashboard/SpecList.vue frontend/src/api/specs.ts
git commit -m "feat(frontend): add expandable spec cards with section detail and progress bars

Spec cards on the Explorer show mini progress bar (color-coded by
completion %), expand chevron revealing per-section breakdown with
status dots, AC progress, and ticket links. Quick-action links for
View/Edit/Tasks. Implements §3.1 and §3.2."
```

---

### Task 14: Sticky Filter Bar (§3.3)

**Files:**
- Modify: `frontend/src/components/dashboard/FilterBar.vue`

- [ ] **Step 1: Add sticky positioning to FilterBar**

In `frontend/src/components/dashboard/FilterBar.vue`, update the root div:

Replace:
```html
  <div id="filters" class="flex flex-wrap gap-3 mb-6">
```
With:
```html
  <div id="filters" class="flex flex-wrap gap-3 mb-6 sticky top-14 z-10 bg-white/95 dark:bg-slate-900/95 backdrop-blur -mx-4 px-4 py-3 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8 md:sticky md:relative">
```

Note: `top-14` matches the AppNav height (h-14). On mobile (`md:relative` → remove sticky on small screens), filters scroll normally.

- [ ] **Step 2: Commit**

```bash
git add frontend/src/components/dashboard/FilterBar.vue
git commit -m "feat(frontend): sticky filter bar on Explorer dashboard

Filters stick below the nav when scrolling, with backdrop blur.
Disabled on mobile where filters scroll normally. Implements §3.3."
```

---

### Task 15: Editor Empty State Fix (§5.1)

**Files:**
- Modify: `frontend/src/components/editor/EditorList.vue`

- [ ] **Step 1: Add actionable empty states to EditorList**

Replace `frontend/src/components/editor/EditorList.vue`:

```vue
<script setup lang="ts">
import { useAuthStore } from '@/stores/auth'
import type { EditorRepo } from '@/api/types'
import EmptyState from '@/components/common/EmptyState.vue'

defineProps<{ repos: EditorRepo[] }>()
const auth = useAuthStore()
</script>

<template>
  <div>
    <div class="flex items-center justify-between mb-6">
      <h1 class="text-2xl font-bold font-display text-slate-800 dark:text-slate-100">Editor</h1>
    </div>

    <!-- No GitHub connected -->
    <template v-if="!auth.hasGitHub">
      <EmptyState
        icon="code"
        heading="Connect your GitHub account to edit specs"
        description="The Editor lets you create and edit spec files directly via the GitHub API. Connect your GitHub account to get started."
        cta-text="Connect GitHub"
        cta-href="/auth/github/login"
      />
    </template>

    <!-- GitHub connected but no repos -->
    <template v-else-if="repos.length === 0">
      <EmptyState
        icon="document"
        heading="No repositories with Canon installed"
        description="Install the Canon GitHub App on your repositories to start editing specs."
        cta-text="Install Canon GitHub App"
        cta-href="https://github.com/apps/canonhq"
      />
    </template>

    <!-- Repos found -->
    <div v-else class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      <div
        v-for="repo in repos"
        :key="repo.full_name"
        class="p-4 border border-border-light dark:border-slate-700 rounded-lg"
      >
        <div class="flex items-center justify-between mb-2">
          <span class="font-medium text-slate-800 dark:text-slate-200">{{ repo.name }}</span>
        </div>
        <p v-if="repo.description" class="text-xs text-slate-500 mb-3 line-clamp-2">{{ repo.description }}</p>
        <div class="flex items-center gap-3">
          <router-link
            :to="`/app/${auth.org}/editor/${repo.owner.login}/${repo.name}/new`"
            class="text-xs text-accent-500 hover:text-accent-400"
          >
            + New Spec
          </router-link>
          <router-link
            :to="`/app/${auth.org}/repos/${repo.owner.login}/${repo.name}`"
            class="text-xs text-slate-400 hover:text-accent-400"
          >
            View specs
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/editor/EditorList.vue
git commit -m "feat(frontend): actionable empty states for Editor page

Shows 'Connect GitHub' CTA when OAuth not connected, and 'Install
Canon GitHub App' when connected but no repos found. Both include
explanatory description text. Implements §5.1."
```

---

### Task 16: Autosave Indicator (§5.2)

**Files:**
- Modify: `frontend/src/components/editor/EditorToolbar.vue`
- Modify: `frontend/src/components/editor/EditorLayout.vue`

- [ ] **Step 1: Read EditorToolbar to understand current structure**

Read `frontend/src/components/editor/EditorToolbar.vue` to understand its props and layout.

- [ ] **Step 2: Add save status indicator to EditorToolbar**

Add a `saveStatus` prop to EditorToolbar and display it:

Add prop:
```typescript
saveStatus?: 'saved' | 'unsaved' | 'saving'
```

Add to the toolbar template (left side, after mode toggle):
```html
      <div v-if="saveStatus" class="flex items-center gap-1.5 text-xs">
        <span v-if="saveStatus === 'saved'" class="w-2 h-2 rounded-full bg-green-500"></span>
        <span v-else-if="saveStatus === 'unsaved'" class="w-2 h-2 rounded-full bg-amber-500"></span>
        <svg v-else class="w-3 h-3 animate-spin text-slate-400" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>
        <span class="text-slate-500 dark:text-slate-400">
          {{ saveStatus === 'saved' ? 'Saved' : saveStatus === 'unsaved' ? 'Unsaved changes' : 'Saving...' }}
        </span>
      </div>
```

- [ ] **Step 3: Add beforeunload warning in EditorLayout**

In `frontend/src/components/editor/EditorLayout.vue`, add:

```typescript
import { onMounted, onUnmounted } from 'vue'

// ... existing code ...

const saveStatus = computed<'saved' | 'unsaved' | 'saving'>(() => {
  if (saving.value) return 'saving'
  if (dirty.value) return 'unsaved'
  return 'saved'
})

function onBeforeUnload(e: BeforeUnloadEvent) {
  if (dirty.value) {
    e.preventDefault()
    e.returnValue = ''
  }
}

onMounted(() => window.addEventListener('beforeunload', onBeforeUnload))
onUnmounted(() => window.removeEventListener('beforeunload', onBeforeUnload))
```

Pass `saveStatus` to `EditorToolbar`:
```html
<EditorToolbar :save-status="saveStatus" ... />
```

- [ ] **Step 4: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/editor/EditorToolbar.vue frontend/src/components/editor/EditorLayout.vue
git commit -m "feat(frontend): autosave indicator and beforeunload warning

Editor toolbar shows save status with colored dot (green=saved,
amber=unsaved, spinner=saving). Browser warns before navigating
away with unsaved changes. Implements §5.2."
```

---

### Task 17: Spec Validation Warnings (§5.4)

**Files:**
- Create: `frontend/src/components/editor/ValidationPanel.vue`
- Modify: `frontend/src/components/editor/EditorLayout.vue`
- Modify: `frontend/src/components/editor/EditorToolbar.vue`

- [ ] **Step 1: Create ValidationPanel component**

Create `frontend/src/components/editor/ValidationPanel.vue`:

```vue
<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{ content: string }>()

interface Warning {
  type: 'missing-status' | 'unchecked-done' | 'missing-frontmatter'
  message: string
  line?: number
}

const warnings = computed<Warning[]>(() => {
  const w: Warning[] = []
  const lines = props.content.split('\n')

  // Check frontmatter
  const fmMatch = props.content.match(/^---\n([\s\S]*?)\n---/)
  if (fmMatch) {
    const fm = fmMatch[1]
    if (!fm.includes('title:')) w.push({ type: 'missing-frontmatter', message: 'Frontmatter missing required field: title' })
    if (!fm.includes('status:')) w.push({ type: 'missing-frontmatter', message: 'Frontmatter missing required field: status' })
  } else if (props.content.trim()) {
    w.push({ type: 'missing-frontmatter', message: 'No frontmatter found (expected --- delimiters)' })
  }

  // Check for sections without status comments
  let inDoneSection = false
  let hasUncheckedInDone = false

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]

    // Detect section headers (## or ###)
    if (/^#{2,3}\s/.test(line)) {
      // Check if previous done section had unchecked ACs
      if (inDoneSection && hasUncheckedInDone) {
        w.push({ type: 'unchecked-done', message: `Section marked 'done' has unchecked acceptance criteria`, line: i })
      }
      inDoneSection = false
      hasUncheckedInDone = false

      // Look for status comment in next few lines
      const nextLines = lines.slice(i + 1, i + 4).join('\n')
      if (/^#{2}\s/.test(line) && !nextLines.includes('canon:system:')) {
        const title = line.replace(/^#+\s*/, '').trim()
        // Skip certain section titles
        if (!['Background', 'Open Questions', 'Technical Design', 'Rollout Plan'].includes(title)) {
          w.push({ type: 'missing-status', message: `Section "${title}" missing canon:system status comment`, line: i + 1 })
        }
      }

      if (nextLines.includes('status:done')) {
        inDoneSection = true
      }
    }

    // Check for unchecked ACs in done sections
    if (inDoneSection && /^- \[ \]/.test(line)) {
      hasUncheckedInDone = true
    }
  }

  return w
})
</script>

<template>
  <div v-if="warnings.length > 0" class="mt-3 rounded-lg border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-900/20 p-3">
    <div class="flex items-center gap-2 mb-2">
      <svg class="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
      </svg>
      <span class="text-xs font-medium text-amber-800 dark:text-amber-300">{{ warnings.length }} warning{{ warnings.length !== 1 ? 's' : '' }}</span>
    </div>
    <div class="space-y-1">
      <div v-for="(w, i) in warnings" :key="i" class="flex items-start gap-2 text-xs">
        <span class="text-amber-600 dark:text-amber-400">{{ w.line ? `L${w.line}:` : '•' }}</span>
        <span class="text-amber-700 dark:text-amber-300">{{ w.message }}</span>
      </div>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Mount ValidationPanel in EditorLayout**

In `frontend/src/components/editor/EditorLayout.vue`:

Add import:
```typescript
import ValidationPanel from './ValidationPanel.vue'
```

Add below the source editor section (after the SourceModeAi component):
```html
      <ValidationPanel v-if="!props.configMode" :content="sourceContent" />
```

- [ ] **Step 3: Add warning count to EditorToolbar**

Add a `warningCount` prop to EditorToolbar and display it next to the save status:

```html
      <span v-if="warningCount > 0" class="text-xs text-amber-500 flex items-center gap-1">
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" /></svg>
        {{ warningCount }}
      </span>
```

- [ ] **Step 4: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/editor/ValidationPanel.vue frontend/src/components/editor/EditorLayout.vue frontend/src/components/editor/EditorToolbar.vue
git commit -m "feat(frontend): spec validation warnings panel in editor

Client-side validation checks for missing canon:system status comments,
unchecked ACs in done sections, and missing frontmatter fields. Warnings
displayed below editor with count in toolbar. Non-blocking. Implements §5.4."
```

---

### Task 18: Quick-Create from Dashboard (§5.5)

**Files:**
- Create: `frontend/src/components/editor/RepoPickerModal.vue`
- Modify: `frontend/src/components/dashboard/OrgDashboard.vue`

- [ ] **Step 1: Create RepoPickerModal**

Create `frontend/src/components/editor/RepoPickerModal.vue`:

```vue
<script setup lang="ts">
import type { RepoSummary } from '@/api/types'

defineProps<{ repos: RepoSummary[] }>()
defineEmits<{
  select: [repo: RepoSummary]
  close: []
}>()
</script>

<template>
  <div class="fixed inset-0 z-50 flex items-center justify-center">
    <div class="absolute inset-0 bg-black/50" @click="$emit('close')"></div>
    <div class="relative bg-surface-light dark:bg-slate-800 rounded-lg shadow-xl border border-border-light dark:border-slate-700 w-full max-w-md mx-4 p-6">
      <h2 class="text-lg font-bold font-display text-slate-800 dark:text-slate-100 mb-4">Choose a repository</h2>
      <div class="space-y-2 max-h-64 overflow-y-auto">
        <button
          v-for="repo in repos"
          :key="repo.full_name"
          class="w-full text-left p-3 rounded-lg border border-border-light dark:border-slate-700 hover:border-accent-500 dark:hover:border-accent-600 transition-colors"
          @click="$emit('select', repo)"
        >
          <div class="font-medium text-sm text-slate-800 dark:text-slate-200">{{ repo.full_name }}</div>
          <div v-if="repo.description" class="text-xs text-slate-500 mt-0.5">{{ repo.description }}</div>
        </button>
      </div>
      <button class="mt-4 text-sm text-slate-500 hover:text-slate-700 dark:hover:text-slate-300" @click="$emit('close')">Cancel</button>
    </div>
  </div>
</template>
```

- [ ] **Step 2: Wire quick-create in OrgDashboard**

In `frontend/src/components/dashboard/OrgDashboard.vue`:

Add imports:
```typescript
import { useRouter } from 'vue-router'
import RepoPickerModal from '@/components/editor/RepoPickerModal.vue'
```

Add state:
```typescript
const router = useRouter()
const showRepoPicker = ref(false)

function handleNewSpec() {
  const repos = props.overview.repos_with_specs
  if (repos.length === 1) {
    router.push(`/app/${props.overview.org}/editor/${repos[0].owner}/${repos[0].repo}/new`)
  } else if (repos.length > 1) {
    showRepoPicker.value = true
  }
}

function handleRepoSelect(repo: { owner: string; repo: string }) {
  showRepoPicker.value = false
  router.push(`/app/${props.overview.org}/editor/${repo.owner}/${repo.repo}/new`)
}
```

Update the "+ New Spec" button to call `handleNewSpec()`:
```html
        <button
          class="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md bg-accent-500 text-white hover:bg-accent-600 transition-colors"
          @click="handleNewSpec"
        >
          <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>
          New Spec
        </button>
```

Add the modal at the end of the template:
```html
    <RepoPickerModal
      v-if="showRepoPicker"
      :repos="overview.repos_with_specs"
      @select="handleRepoSelect"
      @close="showRepoPicker = false"
    />
```

- [ ] **Step 3: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/components/editor/RepoPickerModal.vue frontend/src/components/dashboard/OrgDashboard.vue
git commit -m "feat(frontend): quick-create spec flow from dashboard

'+ New Spec' button on Explorer navigates directly to editor if one
repo, or shows repo picker modal if multiple repos. Implements §5.5."
```

---

## Phase 5: Polish

### Task 19: Spec-Level Sub-Navigation (§4.4)

**Files:**
- Modify: `frontend/src/views/SpecView.vue`

- [ ] **Step 1: Read current SpecView**

Read `frontend/src/views/SpecView.vue` to understand its current structure.

- [ ] **Step 2: Add tab navigation to SpecView**

Add a tab bar below the breadcrumb with Overview | Tasks tabs. Use a `tab` ref driven by URL query parameter:

```typescript
const tab = computed({
  get: () => (route.query.tab as string) ?? 'overview',
  set: (v: string) => router.replace({ query: { ...route.query, tab: v } }),
})
```

Add tab bar:
```html
    <!-- Spec sub-navigation -->
    <div class="flex items-center gap-1 mb-6 border-b border-border-light dark:border-slate-700">
      <button
        class="px-4 py-2 text-sm font-medium transition-colors relative"
        :class="tab === 'overview' ? 'text-accent-500' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'"
        @click="tab = 'overview'"
      >
        Overview
        <span v-if="tab === 'overview'" class="absolute bottom-0 left-0 right-0 h-0.5 bg-accent-500 rounded-full"></span>
      </button>
      <button
        class="px-4 py-2 text-sm font-medium transition-colors relative"
        :class="tab === 'tasks' ? 'text-accent-500' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'"
        @click="tab = 'tasks'"
      >
        Tasks
        <span v-if="tab === 'tasks'" class="absolute bottom-0 left-0 right-0 h-0.5 bg-accent-500 rounded-full"></span>
      </button>
      <span class="px-4 py-2 text-sm text-slate-300 dark:text-slate-600 cursor-default" title="Coming soon">History</span>
      <span class="px-4 py-2 text-sm text-slate-300 dark:text-slate-600 cursor-default" title="Coming soon">Analytics</span>
    </div>
```

Conditionally render content based on `tab`:
- `overview`: existing spec detail view
- `tasks`: inline `TasksView`-like component filtered to this spec

For the tasks tab, use TanStack Query to fetch tasks filtered by repo:
```typescript
const { data: specTasks, isLoading: tasksLoading } = useQuery({
  queryKey: ['spec-tasks', org, owner, repo, specPath],
  queryFn: () => fetchTasks(org.value, { repo: `${owner.value}/${repo.value}`, expand: 'acs' }),
  enabled: computed(() => tab.value === 'tasks'),
})
```

- [ ] **Step 3: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/views/SpecView.vue
git commit -m "feat(frontend): spec-level sub-navigation with Overview and Tasks tabs

Tab bar below breadcrumb shows Overview (existing spec view) and Tasks
(filtered task list for this spec). History and Analytics tabs shown
as disabled 'Coming soon'. Active tab persisted in URL query param.
Implements §4.4."
```

---

### Task 20: Responsive Layout (§6.3)

**Files:**
- Modify: `frontend/src/views/TasksView.vue`
- Modify: `frontend/src/components/dashboard/FilterBar.vue`

- [ ] **Step 1: Add responsive card layout to TasksView list view**

In the list view table within `TasksView.vue`, add responsive classes:

Wrap the `<table>` in a `<div class="hidden md:block">` and add a mobile card layout:

```html
      <!-- Desktop table (hidden on mobile) -->
      <div class="hidden md:block">
        <!-- ... existing table ... -->
      </div>
      <!-- Mobile card layout -->
      <div class="md:hidden space-y-2">
        <div
          v-for="task in tasks"
          :key="`mobile-${task.section_id}`"
          class="p-3 bg-surface-light dark:bg-slate-800 rounded-lg border border-border-light dark:border-slate-700"
          @click="handleSelectTask(task)"
        >
          <div class="flex items-center gap-2 mb-1">
            <span class="font-medium text-sm text-slate-800 dark:text-slate-100">{{ task.title }}</span>
            <span
              class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
              :class="statusBadgeClass(task.status)"
            >{{ task.status.replace('_', ' ') }}</span>
          </div>
          <div class="text-xs text-slate-500">{{ task.spec_title }}</div>
          <div class="flex items-center gap-2 mt-2">
            <div class="flex-1 h-1.5 bg-border-light dark:bg-slate-600 rounded-full overflow-hidden">
              <div
                class="h-full rounded-full bg-accent-500"
                :style="{ width: `${acPercent(task)}%` }"
              ></div>
            </div>
            <span class="text-xs text-slate-400">{{ task.done_ac }}/{{ task.total_ac }}</span>
          </div>
        </div>
      </div>
```

- [ ] **Step 2: Stack filters vertically on mobile**

In `FilterBar.vue`, update the flex container to stack on mobile:

Replace:
```html
  <div id="filters" class="flex flex-wrap gap-3 mb-6 sticky ...">
```
With:
```html
  <div id="filters" class="flex flex-col sm:flex-row flex-wrap gap-3 mb-6 sticky top-14 z-10 bg-white/95 dark:bg-slate-900/95 backdrop-blur -mx-4 px-4 py-3 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8 md:sticky">
```

- [ ] **Step 3: Type check and commit**

Run: `cd frontend && npx vue-tsc --noEmit`

```bash
git add frontend/src/views/TasksView.vue frontend/src/components/dashboard/FilterBar.vue
git commit -m "feat(frontend): responsive layout for tasks and filters

Tasks table collapses to stacked card layout on screens <768px.
Filter dropdowns stack vertically on mobile. Implements §6.3."
```

---

## Post-Implementation

### Task 21: Final Type Check + Lint

- [ ] **Step 1: Run full type check**

```bash
cd frontend && npx vue-tsc --noEmit
```

- [ ] **Step 2: Run lint**

```bash
cd frontend && npx eslint src/ --fix
```

- [ ] **Step 3: Build check**

```bash
cd frontend && npx vite build
```

- [ ] **Step 4: Run backend tests**

```bash
uv run pytest tests/test_web/ -v
```

- [ ] **Step 5: Commit any lint fixes**

```bash
git add -A && git commit -m "chore: lint and type fixes after web-app-ux-polish implementation"
```
