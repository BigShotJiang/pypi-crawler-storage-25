# OIDC Migration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace Canon's Auth0 dependency with a generic OIDC provider abstraction. Cloud stays on Auth0. OSS ships with bring-your-own OIDC support and an optional bundled Zitadel instance.

**Architecture:** Introduce an `OIDCProvider` protocol that all auth code programs against. Auth0 becomes one implementation. A `GenericOIDCProvider` uses standard `.well-known/openid-configuration` discovery. Settings auto-detect which provider to use. Database columns rename from `auth0_*` to `oidc_*`. Helm chart adds OIDC secret support. OSS export includes the auth module (minus cloud-only files).

**Tech Stack:** Python 3.12+ / FastAPI / Pydantic v2 / Authlib / PyJWT / httpx / Helm / Vue 3

**Spec:** `docs/specs/oidc-migration.md`

---

## Phase 1: Provider Abstraction (no behavior change)

### Task 1: Define OIDCProvider protocol and data models

**Files:**
- Create: `src/canon/auth/providers/__init__.py`
- Create: `src/canon/auth/providers/protocol.py`
- Create: `tests/test_auth/test_providers/__init__.py`
- Create: `tests/test_auth/test_providers/test_protocol.py`

- [ ] **Step 1: Write failing test for TokenSet and DeviceCodeResponse models**

```python
# tests/test_auth/test_providers/test_protocol.py
"""Tests for OIDC provider protocol models."""
from __future__ import annotations

from canon.auth.providers.protocol import DeviceCodeResponse, Pending, TokenSet


class TestTokenSet:
    def test_create(self):
        ts = TokenSet(
            access_token="at",
            id_token="it",
            refresh_token="rt",
            expires_in=3600,
        )
        assert ts.access_token == "at"
        assert ts.expires_in == 3600

    def test_optional_fields(self):
        ts = TokenSet(access_token="at")
        assert ts.id_token == ""
        assert ts.refresh_token == ""
        assert ts.expires_in == 0


class TestDeviceCodeResponse:
    def test_create(self):
        dcr = DeviceCodeResponse(
            device_code="dc",
            user_code="UC-1234",
            verification_uri="https://example.com/activate",
            interval=5,
            expires_in=900,
        )
        assert dcr.device_code == "dc"
        assert dcr.interval == 5

    def test_verification_uri_complete_optional(self):
        dcr = DeviceCodeResponse(
            device_code="dc",
            user_code="UC",
            verification_uri="https://example.com",
        )
        assert dcr.verification_uri_complete == ""


class TestPending:
    def test_is_distinct_from_token_set(self):
        p = Pending()
        assert not isinstance(p, TokenSet)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_auth/test_providers/test_protocol.py -v`
Expected: FAIL (import errors — module doesn't exist)

- [ ] **Step 3: Implement protocol and models**

```python
# src/canon/auth/providers/protocol.py
"""OIDC provider protocol — defines the interface all auth providers implement."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@dataclass(frozen=True)
class TokenSet:
    """Tokens returned from code exchange or refresh."""
    access_token: str = ""
    id_token: str = ""
    refresh_token: str = ""
    expires_in: int = 0


@dataclass(frozen=True)
class DeviceCodeResponse:
    """Response from starting a device authorization flow."""
    device_code: str = ""
    user_code: str = ""
    verification_uri: str = ""
    verification_uri_complete: str = ""
    interval: int = 5
    expires_in: int = 900


@dataclass(frozen=True)
class OrgInfo:
    """Organization membership info from a management API."""
    id: str = ""
    name: str = ""
    display_name: str = ""


@dataclass(frozen=True)
class Pending:
    """Sentinel returned by poll_device_token when authorization is still pending."""
    pass


@runtime_checkable
class OIDCProvider(Protocol):
    """Minimal interface for any OIDC-compliant auth provider."""

    async def get_login_url(self, *, redirect_uri: str, state: str,
                            org_hint: str = "") -> str: ...

    async def exchange_code(self, *, code: str,
                            redirect_uri: str) -> TokenSet: ...

    async def refresh_tokens(self, *, refresh_token: str) -> TokenSet: ...

    async def get_jwks_uri(self) -> str: ...

    async def get_logout_url(self, *, return_to: str) -> str | None: ...

    async def get_device_code(self, *, audience: str = "",
                              scope: str = "") -> DeviceCodeResponse | None: ...

    async def poll_device_token(self, device_code: str) -> TokenSet | Pending: ...

    async def get_user_orgs(self, user_id: str) -> list[OrgInfo]: ...
```

```python
# src/canon/auth/providers/__init__.py
"""OIDC provider factory — selects implementation based on settings."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...settings import Settings
    from .protocol import OIDCProvider


def create_provider(settings: "Settings") -> "OIDCProvider | None":
    """Create the appropriate OIDC provider based on settings.

    Returns None if no auth provider is configured (dev mode).
    """
    # Explicit provider selection
    provider_type = settings.auth_provider

    if not provider_type:
        # Auto-detect from available settings
        if settings.auth0_enabled:
            provider_type = "auth0"
        elif settings.oidc_issuer and settings.oidc_client_id and settings.oidc_client_secret:
            provider_type = "oidc"
        else:
            return None

    if provider_type == "auth0":
        from .auth0 import Auth0Provider
        return Auth0Provider(settings=settings)

    if provider_type == "oidc":
        from .generic_oidc import GenericOIDCProvider
        return GenericOIDCProvider(settings=settings)

    raise ValueError(f"Unknown auth_provider: {provider_type!r}. Must be 'auth0' or 'oidc'.")
```

```python
# tests/test_auth/test_providers/__init__.py
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_auth/test_providers/test_protocol.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/auth/providers/ tests/test_auth/test_providers/
git commit -m "feat(auth): add OIDCProvider protocol and data models"
```

---

### Task 2: Implement Auth0Provider wrapping existing auth logic

**Files:**
- Create: `src/canon/auth/providers/auth0.py`
- Create: `tests/test_auth/test_providers/test_auth0.py`

- [ ] **Step 1: Write failing test for Auth0Provider**

```python
# tests/test_auth/test_providers/test_auth0.py
"""Tests for Auth0 OIDC provider implementation."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from canon.auth.providers.auth0 import Auth0Provider
from canon.auth.providers.protocol import (
    DeviceCodeResponse,
    OIDCProvider,
    Pending,
    TokenSet,
)
from canon.settings import Settings


def _settings(**overrides) -> Settings:
    defaults = dict(
        auth0_domain="test.us.auth0.com",
        auth0_client_id="client-id",
        auth0_client_secret="client-secret",
        auth0_audience="https://api.example.com",
        auth0_device_client_id="device-client-id",
    )
    defaults.update(overrides)
    return Settings(**defaults)


class TestAuth0ProviderProtocol:
    def test_implements_protocol(self):
        provider = Auth0Provider(settings=_settings())
        assert isinstance(provider, OIDCProvider)


class TestGetLoginUrl:
    async def test_returns_authorize_url(self):
        provider = Auth0Provider(settings=_settings())
        url = await provider.get_login_url(
            redirect_uri="https://example.com/callback",
            state="abc",
        )
        assert "test.us.auth0.com" in url
        assert "authorize" in url
        assert "client-id" in url

    async def test_includes_org_hint(self):
        provider = Auth0Provider(settings=_settings())
        url = await provider.get_login_url(
            redirect_uri="https://example.com/callback",
            state="abc",
            org_hint="org_123",
        )
        assert "organization=org_123" in url


class TestExchangeCode:
    async def test_returns_token_set(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "access_token": "at",
            "id_token": "it",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        result = await provider.exchange_code(
            code="auth-code",
            redirect_uri="https://example.com/callback",
        )
        assert isinstance(result, TokenSet)
        assert result.access_token == "at"


class TestGetJwksUri:
    async def test_returns_auth0_jwks_url(self):
        provider = Auth0Provider(settings=_settings())
        url = await provider.get_jwks_uri()
        assert url == "https://test.us.auth0.com/.well-known/jwks.json"


class TestGetLogoutUrl:
    async def test_returns_auth0_logout_url(self):
        provider = Auth0Provider(settings=_settings())
        url = await provider.get_logout_url(return_to="https://example.com")
        assert "test.us.auth0.com" in url
        assert "v2/logout" in url
        assert "returnTo=https" in url


class TestGetDeviceCode:
    async def test_returns_device_code_response(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "device_code": "dc-123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://test.us.auth0.com/activate",
            "verification_uri_complete": "https://test.us.auth0.com/activate?user_code=ABCD-1234",
            "interval": 5,
            "expires_in": 900,
        }
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        result = await provider.get_device_code(
            audience="https://api.example.com",
            scope="openid profile email offline_access",
        )
        assert isinstance(result, DeviceCodeResponse)
        assert result.device_code == "dc-123"


class TestPollDeviceToken:
    async def test_returns_pending(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 403
        mock_resp.json.return_value = {"error": "authorization_pending"}
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        result = await provider.poll_device_token("dc-123")
        assert isinstance(result, Pending)

    async def test_returns_token_set_on_approval(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "access_token": "at",
            "id_token": "it",
            "refresh_token": "rt",
            "expires_in": 86400,
        }
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        result = await provider.poll_device_token("dc-123")
        assert isinstance(result, TokenSet)
        assert result.access_token == "at"


class TestGetUserOrgs:
    async def test_returns_org_list(self):
        provider = Auth0Provider(settings=_settings(
            auth0_m2m_client_id="m2m-id",
            auth0_m2m_client_secret="m2m-secret",
        ))
        mock_http = AsyncMock()
        # Token request
        token_resp = MagicMock()
        token_resp.status_code = 200
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        # Orgs request
        orgs_resp = MagicMock()
        orgs_resp.status_code = 200
        orgs_resp.json.return_value = [{"id": "org_1", "name": "my-org", "display_name": "My Org"}]
        orgs_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(return_value=token_resp)
        mock_http.get = AsyncMock(return_value=orgs_resp)
        provider._http = mock_http

        orgs = await provider.get_user_orgs("auth0|123")
        assert len(orgs) == 1
        assert orgs[0].id == "org_1"

    async def test_returns_empty_without_m2m_credentials(self):
        provider = Auth0Provider(settings=_settings())
        orgs = await provider.get_user_orgs("auth0|123")
        assert orgs == []
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_auth/test_providers/test_auth0.py -v`
Expected: FAIL (module doesn't exist)

- [ ] **Step 3: Implement Auth0Provider**

```python
# src/canon/auth/providers/auth0.py
"""Auth0 OIDC provider implementation — cloud-only, excluded from OSS export."""
from __future__ import annotations

import logging
import time
from urllib.parse import quote, urlencode

import httpx

from ...settings import Settings
from .protocol import DeviceCodeResponse, OIDCProvider, OrgInfo, Pending, TokenSet

logger = logging.getLogger(__name__)


class Auth0Provider:
    """Auth0-specific OIDC provider with Organizations and Management API support."""

    def __init__(self, *, settings: Settings, http_client: httpx.AsyncClient | None = None) -> None:
        self._settings = settings
        self._http = http_client or httpx.AsyncClient(timeout=30)
        self._domain = settings.auth0_domain
        self._client_id = settings.auth0_client_id
        self._client_secret = settings.auth0_client_secret
        self._audience = settings.auth0_audience
        self._device_client_id = settings.auth0_device_client_id or settings.auth0_client_id
        # M2M credentials for Management API
        self._m2m_client_id = settings.auth0_m2m_client_id
        self._m2m_client_secret = settings.auth0_m2m_client_secret
        self._mgmt_token: str = ""
        self._mgmt_token_expires: float = 0

    async def get_login_url(self, *, redirect_uri: str, state: str,
                            org_hint: str = "") -> str:
        params = {
            "response_type": "code",
            "client_id": self._client_id,
            "redirect_uri": redirect_uri,
            "scope": "openid email profile",
            "state": state,
        }
        if self._audience:
            params["audience"] = self._audience
        if org_hint:
            params["organization"] = org_hint
        return f"https://{self._domain}/authorize?{urlencode(params)}"

    async def exchange_code(self, *, code: str, redirect_uri: str) -> TokenSet:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            json={
                "grant_type": "authorization_code",
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "code": code,
                "redirect_uri": redirect_uri,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        return TokenSet(
            access_token=data.get("access_token", ""),
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_in=data.get("expires_in", 0),
        )

    async def refresh_tokens(self, *, refresh_token: str) -> TokenSet:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            data={
                "grant_type": "refresh_token",
                "client_id": self._device_client_id,
                "refresh_token": refresh_token,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        return TokenSet(
            access_token=data.get("access_token", ""),
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", refresh_token),
            expires_in=data.get("expires_in", 0),
        )

    async def get_jwks_uri(self) -> str:
        return f"https://{self._domain}/.well-known/jwks.json"

    async def get_logout_url(self, *, return_to: str) -> str | None:
        params = urlencode({"client_id": self._client_id, "returnTo": return_to})
        return f"https://{self._domain}/v2/logout?{params}"

    async def get_device_code(self, *, audience: str = "",
                              scope: str = "") -> DeviceCodeResponse | None:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/device/code",
            data={
                "client_id": self._device_client_id,
                "scope": scope or "openid profile email offline_access",
                "audience": audience or self._audience,
            },
        )
        if resp.status_code != 200:
            return None
        data = resp.json()
        return DeviceCodeResponse(
            device_code=data["device_code"],
            user_code=data["user_code"],
            verification_uri=data.get("verification_uri", ""),
            verification_uri_complete=data.get("verification_uri_complete", ""),
            interval=data.get("interval", 5),
            expires_in=data.get("expires_in", 900),
        )

    async def poll_device_token(self, device_code: str) -> TokenSet | Pending:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "client_id": self._device_client_id,
                "device_code": device_code,
            },
        )
        if resp.status_code == 403:
            error = resp.json().get("error", "")
            if error in ("authorization_pending", "slow_down"):
                return Pending()
            raise RuntimeError(f"Device auth error: {error}")
        if resp.status_code != 200:
            raise RuntimeError(f"Device token request failed: {resp.status_code}")
        data = resp.json()
        return TokenSet(
            access_token=data.get("access_token", ""),
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_in=data.get("expires_in", 0),
        )

    async def get_user_orgs(self, user_id: str) -> list[OrgInfo]:
        if not self._m2m_client_id or not self._m2m_client_secret:
            return []
        token = await self._get_mgmt_token()
        encoded_id = quote(user_id, safe="")
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/users/{encoded_id}/organizations",
            headers={"Authorization": f"Bearer {token}"},
            params={"per_page": "100"},
        )
        resp.raise_for_status()
        return [
            OrgInfo(id=o.get("id", ""), name=o.get("name", ""), display_name=o.get("display_name", ""))
            for o in resp.json()
        ]

    async def _get_mgmt_token(self) -> str:
        if self._mgmt_token and time.time() < self._mgmt_token_expires:
            return self._mgmt_token
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": self._m2m_client_id,
                "client_secret": self._m2m_client_secret,
                "audience": f"https://{self._domain}/api/v2/",
            },
        )
        resp.raise_for_status()
        data = resp.json()
        self._mgmt_token = data["access_token"]
        self._mgmt_token_expires = time.time() + data.get("expires_in", 86400) - 60
        return self._mgmt_token
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_auth/test_providers/ -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/auth/providers/auth0.py tests/test_auth/test_providers/test_auth0.py
git commit -m "feat(auth): implement Auth0Provider wrapping existing auth logic"
```

---

### Task 3: Add new OIDC settings to Settings class (spec section 4)

**Files:**
- Modify: `src/canon/settings.py`
- Create: `tests/test_auth/test_providers/test_factory.py`

- [ ] **Step 1: Write failing test for new settings and factory**

```python
# tests/test_auth/test_providers/test_factory.py
"""Tests for provider auto-detection and factory."""
from __future__ import annotations

from canon.auth.providers import create_provider
from canon.auth.providers.auth0 import Auth0Provider
from canon.settings import Settings


class TestCreateProvider:
    def test_returns_none_when_no_auth(self):
        s = Settings()
        assert create_provider(s) is None

    def test_auto_detects_auth0(self):
        s = Settings(
            auth0_domain="test.auth0.com",
            auth0_client_id="cid",
            auth0_client_secret="csec",
        )
        p = create_provider(s)
        assert isinstance(p, Auth0Provider)

    def test_auto_detects_oidc(self):
        from canon.auth.providers.generic_oidc import GenericOIDCProvider
        s = Settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="cid",
            oidc_client_secret="csec",
        )
        p = create_provider(s)
        assert isinstance(p, GenericOIDCProvider)

    def test_explicit_auth_provider_overrides(self):
        s = Settings(
            auth_provider="auth0",
            auth0_domain="test.auth0.com",
            auth0_client_id="cid",
            auth0_client_secret="csec",
            oidc_issuer="https://idp.example.com",
            oidc_client_id="oidc-cid",
            oidc_client_secret="oidc-csec",
        )
        p = create_provider(s)
        assert isinstance(p, Auth0Provider)

    def test_auth_enabled_with_oidc(self):
        s = Settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="cid",
            oidc_client_secret="csec",
        )
        assert s.auth_enabled is True

    def test_auth_enabled_with_auth0(self):
        s = Settings(
            auth0_domain="test.auth0.com",
            auth0_client_id="cid",
            auth0_client_secret="csec",
        )
        assert s.auth_enabled is True

    def test_auth_enabled_false_when_empty(self):
        s = Settings()
        assert s.auth_enabled is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_auth/test_providers/test_factory.py -v`
Expected: FAIL (Settings doesn't have `auth_provider`, `oidc_*` fields)

- [ ] **Step 3: Add new settings fields**

In `src/canon/settings.py`, add after the `auth0_orgs_enabled` line (around line 72):

```python
    # Generic OIDC (OSS — bring-your-own identity provider)
    auth_provider: str = ""  # "oidc", "auth0", or "" (auto-detect)
    oidc_issuer: str = ""  # https://your-idp.example.com
    oidc_client_id: str = ""
    oidc_client_secret: str = ""
    oidc_audience: str = ""
    oidc_scopes: str = "openid email profile"
```

And replace the `auth0_enabled` property with a broader `auth_enabled`:

```python
    @property
    def auth0_enabled(self) -> bool:
        return bool(self.auth0_domain and self.auth0_client_id and self.auth0_client_secret)

    @property
    def auth_enabled(self) -> bool:
        """True if any auth provider is configured."""
        return self.auth0_enabled or bool(
            self.oidc_issuer and self.oidc_client_id and self.oidc_client_secret
        )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_auth/test_providers/test_factory.py -v`
Expected: Some tests fail (GenericOIDCProvider doesn't exist yet). The settings tests should pass.

Note: The `auto_detects_oidc` test will fail until Task 4. Mark it `@pytest.mark.skip("requires GenericOIDCProvider")` for now.

- [ ] **Step 5: Run all existing tests to ensure nothing breaks**

Run: `uv run pytest tests/ -x -q`
Expected: All existing tests PASS (new settings have defaults, nothing changes)

- [ ] **Step 6: Commit**

```bash
git add src/canon/settings.py tests/test_auth/test_providers/test_factory.py
git commit -m "feat(auth): add OIDC settings and provider factory with auto-detection"
```

---

### Task 4: Implement GenericOIDCProvider (spec section 3)

**Files:**
- Create: `src/canon/auth/providers/generic_oidc.py`
- Create: `tests/test_auth/test_providers/test_generic_oidc.py`

- [ ] **Step 1: Write failing test for GenericOIDCProvider**

```python
# tests/test_auth/test_providers/test_generic_oidc.py
"""Tests for generic OIDC provider (discovery-based)."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from canon.auth.providers.generic_oidc import GenericOIDCProvider
from canon.auth.providers.protocol import (
    DeviceCodeResponse,
    OIDCProvider,
    Pending,
    TokenSet,
)
from canon.settings import Settings

_DISCOVERY_DOC = {
    "issuer": "https://idp.example.com",
    "authorization_endpoint": "https://idp.example.com/authorize",
    "token_endpoint": "https://idp.example.com/token",
    "jwks_uri": "https://idp.example.com/.well-known/jwks.json",
    "end_session_endpoint": "https://idp.example.com/logout",
    "device_authorization_endpoint": "https://idp.example.com/device/authorize",
    "userinfo_endpoint": "https://idp.example.com/userinfo",
}


def _settings(**overrides) -> Settings:
    defaults = dict(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="client-id",
        oidc_client_secret="client-secret",
    )
    defaults.update(overrides)
    return Settings(**defaults)


def _mock_discovery_http() -> AsyncMock:
    """Create a mock httpx client that serves the discovery document."""
    http = AsyncMock()
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = _DISCOVERY_DOC
    resp.raise_for_status = MagicMock()
    http.get = AsyncMock(return_value=resp)
    return http


class TestImplementsProtocol:
    def test_implements_oidc_provider(self):
        provider = GenericOIDCProvider(settings=_settings())
        assert isinstance(provider, OIDCProvider)


class TestDiscovery:
    async def test_fetches_discovery_document(self):
        http = _mock_discovery_http()
        provider = GenericOIDCProvider(settings=_settings(), http_client=http)
        await provider._ensure_discovered()
        http.get.assert_awaited_once()
        assert "openid-configuration" in http.get.call_args[0][0]


class TestGetLoginUrl:
    async def test_returns_authorization_url(self):
        http = _mock_discovery_http()
        provider = GenericOIDCProvider(settings=_settings(), http_client=http)
        url = await provider.get_login_url(
            redirect_uri="https://example.com/callback",
            state="abc",
        )
        assert "idp.example.com/authorize" in url
        assert "client-id" in url
        assert "state=abc" in url


class TestExchangeCode:
    async def test_returns_token_set(self):
        http = _mock_discovery_http()
        token_resp = MagicMock()
        token_resp.status_code = 200
        token_resp.json.return_value = {
            "access_token": "at",
            "id_token": "it",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        token_resp.raise_for_status = MagicMock()
        # First call is discovery, second is token exchange
        http.get = AsyncMock(side_effect=[
            MagicMock(status_code=200, json=MagicMock(return_value=_DISCOVERY_DOC), raise_for_status=MagicMock()),
        ])
        http.post = AsyncMock(return_value=token_resp)
        provider = GenericOIDCProvider(settings=_settings(), http_client=http)
        result = await provider.exchange_code(code="code", redirect_uri="https://example.com/cb")
        assert isinstance(result, TokenSet)
        assert result.access_token == "at"


class TestGetJwksUri:
    async def test_returns_discovered_jwks_uri(self):
        http = _mock_discovery_http()
        provider = GenericOIDCProvider(settings=_settings(), http_client=http)
        uri = await provider.get_jwks_uri()
        assert uri == "https://idp.example.com/.well-known/jwks.json"


class TestGetLogoutUrl:
    async def test_returns_end_session_endpoint(self):
        http = _mock_discovery_http()
        provider = GenericOIDCProvider(settings=_settings(), http_client=http)
        url = await provider.get_logout_url(return_to="https://example.com")
        assert "idp.example.com/logout" in url

    async def test_returns_none_when_no_end_session(self):
        http = AsyncMock()
        discovery_no_logout = {**_DISCOVERY_DOC}
        del discovery_no_logout["end_session_endpoint"]
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = discovery_no_logout
        resp.raise_for_status = MagicMock()
        http.get = AsyncMock(return_value=resp)
        provider = GenericOIDCProvider(settings=_settings(), http_client=http)
        url = await provider.get_logout_url(return_to="https://example.com")
        assert url is None


class TestDeviceCode:
    async def test_returns_device_code_response(self):
        http = _mock_discovery_http()
        device_resp = MagicMock()
        device_resp.status_code = 200
        device_resp.json.return_value = {
            "device_code": "dc",
            "user_code": "UC",
            "verification_uri": "https://idp.example.com/activate",
            "interval": 5,
            "expires_in": 600,
        }
        http.post = AsyncMock(return_value=device_resp)
        provider = GenericOIDCProvider(settings=_settings(), http_client=http)
        result = await provider.get_device_code()
        assert isinstance(result, DeviceCodeResponse)

    async def test_returns_none_when_no_device_endpoint(self):
        http = AsyncMock()
        discovery_no_device = {**_DISCOVERY_DOC}
        del discovery_no_device["device_authorization_endpoint"]
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = discovery_no_device
        resp.raise_for_status = MagicMock()
        http.get = AsyncMock(return_value=resp)
        provider = GenericOIDCProvider(settings=_settings(), http_client=http)
        result = await provider.get_device_code()
        assert result is None


class TestGetUserOrgs:
    async def test_always_returns_empty(self):
        """Generic OIDC has no management API — always returns empty."""
        provider = GenericOIDCProvider(settings=_settings())
        orgs = await provider.get_user_orgs("sub123")
        assert orgs == []
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_auth/test_providers/test_generic_oidc.py -v`
Expected: FAIL (module doesn't exist)

- [ ] **Step 3: Implement GenericOIDCProvider**

```python
# src/canon/auth/providers/generic_oidc.py
"""Generic OIDC provider — discovery-based, works with any compliant IDP."""
from __future__ import annotations

import logging
from urllib.parse import urlencode

import httpx

from ...settings import Settings
from .protocol import DeviceCodeResponse, OrgInfo, Pending, TokenSet

logger = logging.getLogger(__name__)


class GenericOIDCProvider:
    """Discovery-based OIDC provider for OSS bring-your-own-IDP deployments."""

    def __init__(self, *, settings: Settings, http_client: httpx.AsyncClient | None = None) -> None:
        self._settings = settings
        self._http = http_client or httpx.AsyncClient(timeout=30)
        self._issuer = settings.oidc_issuer.rstrip("/")
        self._client_id = settings.oidc_client_id
        self._client_secret = settings.oidc_client_secret
        self._audience = settings.oidc_audience
        self._scopes = settings.oidc_scopes
        # Discovered endpoints (populated lazily)
        self._discovered = False
        self._authorization_endpoint = ""
        self._token_endpoint = ""
        self._jwks_uri = ""
        self._end_session_endpoint: str | None = None
        self._device_authorization_endpoint: str | None = None
        self._userinfo_endpoint = ""

    async def _ensure_discovered(self) -> None:
        """Fetch and cache the discovery document."""
        if self._discovered:
            return
        url = f"{self._issuer}/.well-known/openid-configuration"
        resp = await self._http.get(url)
        resp.raise_for_status()
        doc = resp.json()
        self._authorization_endpoint = doc["authorization_endpoint"]
        self._token_endpoint = doc["token_endpoint"]
        self._jwks_uri = doc["jwks_uri"]
        self._end_session_endpoint = doc.get("end_session_endpoint")
        self._device_authorization_endpoint = doc.get("device_authorization_endpoint")
        self._userinfo_endpoint = doc.get("userinfo_endpoint", "")
        self._discovered = True

    async def get_login_url(self, *, redirect_uri: str, state: str,
                            org_hint: str = "") -> str:
        await self._ensure_discovered()
        params = {
            "response_type": "code",
            "client_id": self._client_id,
            "redirect_uri": redirect_uri,
            "scope": self._scopes,
            "state": state,
        }
        if self._audience:
            params["audience"] = self._audience
        return f"{self._authorization_endpoint}?{urlencode(params)}"

    async def exchange_code(self, *, code: str, redirect_uri: str) -> TokenSet:
        await self._ensure_discovered()
        resp = await self._http.post(
            self._token_endpoint,
            data={
                "grant_type": "authorization_code",
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "code": code,
                "redirect_uri": redirect_uri,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        return TokenSet(
            access_token=data.get("access_token", ""),
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_in=data.get("expires_in", 0),
        )

    async def refresh_tokens(self, *, refresh_token: str) -> TokenSet:
        await self._ensure_discovered()
        resp = await self._http.post(
            self._token_endpoint,
            data={
                "grant_type": "refresh_token",
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "refresh_token": refresh_token,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        return TokenSet(
            access_token=data.get("access_token", ""),
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", refresh_token),
            expires_in=data.get("expires_in", 0),
        )

    async def get_jwks_uri(self) -> str:
        await self._ensure_discovered()
        return self._jwks_uri

    async def get_logout_url(self, *, return_to: str) -> str | None:
        await self._ensure_discovered()
        if not self._end_session_endpoint:
            return None
        params = urlencode({
            "client_id": self._client_id,
            "post_logout_redirect_uri": return_to,
        })
        return f"{self._end_session_endpoint}?{params}"

    async def get_device_code(self, *, audience: str = "",
                              scope: str = "") -> DeviceCodeResponse | None:
        await self._ensure_discovered()
        if not self._device_authorization_endpoint:
            return None
        resp = await self._http.post(
            self._device_authorization_endpoint,
            data={
                "client_id": self._client_id,
                "scope": scope or self._scopes + " offline_access",
                **({"audience": audience or self._audience} if (audience or self._audience) else {}),
            },
        )
        if resp.status_code != 200:
            return None
        data = resp.json()
        return DeviceCodeResponse(
            device_code=data["device_code"],
            user_code=data["user_code"],
            verification_uri=data.get("verification_uri", ""),
            verification_uri_complete=data.get("verification_uri_complete", ""),
            interval=data.get("interval", 5),
            expires_in=data.get("expires_in", 900),
        )

    async def poll_device_token(self, device_code: str) -> TokenSet | Pending:
        await self._ensure_discovered()
        resp = await self._http.post(
            self._token_endpoint,
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "client_id": self._client_id,
                "device_code": device_code,
            },
        )
        data = resp.json()
        if resp.status_code == 400:
            error = data.get("error", "")
            if error in ("authorization_pending", "slow_down"):
                return Pending()
            raise RuntimeError(f"Device auth error: {error}")
        if resp.status_code != 200:
            raise RuntimeError(f"Device token request failed: {resp.status_code}")
        return TokenSet(
            access_token=data.get("access_token", ""),
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_in=data.get("expires_in", 0),
        )

    async def get_user_orgs(self, user_id: str) -> list[OrgInfo]:
        """Generic OIDC has no management API — always returns empty."""
        return []
```

- [ ] **Step 4: Run all provider tests**

Run: `uv run pytest tests/test_auth/test_providers/ -v`
Expected: PASS (unskip the factory test for OIDC detection too)

- [ ] **Step 5: Commit**

```bash
git add src/canon/auth/providers/generic_oidc.py tests/test_auth/test_providers/test_generic_oidc.py
git commit -m "feat(auth): implement GenericOIDCProvider with discovery-based OIDC"
```

---

### Task 5: Database migration — rename auth0 columns to oidc (spec section 5)

**Files:**
- Create: `src/canon/db/migrations/versions/0002_oidc_rename.py`
- Modify: `src/canon/db/migrations/versions/0001_baseline.py`
- Modify: `src/canon/db/user_store.py`
- Modify: `src/canon/db/registry.py`
- Modify: `src/canon/db/session_store.py`
- Modify: `src/canon/db/migrate.py`
- Modify: `tests/test_db/test_user_store.py`
- Modify: `tests/test_db/test_registry.py`

- [ ] **Step 1: Create the migration file**

```python
# src/canon/db/migrations/versions/0002_oidc_rename.py
"""Rename Auth0-specific columns to generic OIDC terminology.

Revision ID: 0002
Revises: 0001
Create Date: 2026-03-18
"""
from __future__ import annotations

from alembic import op

revision: str = "0002"
down_revision: str = "0001"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    # users table: rename subject identifier
    op.execute("ALTER TABLE users RENAME COLUMN auth0_sub TO oidc_sub")

    # gh_installations table: rename org identifier
    op.execute("ALTER TABLE gh_installations RENAME COLUMN auth0_org_id TO oidc_org_id")
    op.execute("DROP INDEX IF EXISTS idx_gh_installations_auth0_org_id")
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_gh_installations_oidc_org_id "
        "ON gh_installations (oidc_org_id) WHERE oidc_org_id != ''"
    )

    # users table: add role for server-side RBAC (single-tenant OSS)
    op.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'editor'")


def downgrade() -> None:
    op.execute("ALTER TABLE users DROP COLUMN IF EXISTS role")
    op.execute("DROP INDEX IF EXISTS idx_gh_installations_oidc_org_id")
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_gh_installations_auth0_org_id "
        "ON gh_installations (auth0_org_id)"
    )
    op.execute("ALTER TABLE gh_installations RENAME COLUMN oidc_org_id TO auth0_org_id")
    op.execute("ALTER TABLE users RENAME COLUMN oidc_sub TO auth0_sub")
```

- [ ] **Step 2: Update baseline migration for new installs**

In `0001_baseline.py`, change:
- `auth0_sub TEXT NOT NULL UNIQUE` → `oidc_sub TEXT NOT NULL UNIQUE`
- `auth0_org_id TEXT NOT NULL DEFAULT ''` → `oidc_org_id TEXT NOT NULL DEFAULT ''`
- `idx_gh_installations_auth0_org_id` → `idx_gh_installations_oidc_org_id`
- Add `role TEXT NOT NULL DEFAULT 'editor'` to users table

- [ ] **Step 3: Update UserStore — rename `auth0_sub` to `oidc_sub`**

In `src/canon/db/user_store.py`:
- `upsert_user()`: parameter `auth0_sub` → `oidc_sub`, SQL column `auth0_sub` → `oidc_sub`
- `get_user_by_sub()`: parameter `auth0_sub` → `oidc_sub`, SQL `WHERE auth0_sub` → `WHERE oidc_sub`
- `get_api_key_by_hash()`: SQL alias `u.auth0_sub AS user_sub` → `u.oidc_sub AS user_sub`

- [ ] **Step 4: Update SessionStore — rename auth0_sub alias**

In `src/canon/db/session_store.py`, line 55:
- Change `u.auth0_sub AS user_sub` → `u.oidc_sub AS user_sub`

- [ ] **Step 5: Update `migrate.py` legacy schema patch**

In `src/canon/db/migrate.py`, lines 198-206:
- Change the legacy schema patch comment and column name from `auth0_org_id` to `oidc_org_id`
- Update the `IF NOT EXISTS` check to reference `oidc_org_id`
- Update the `ALTER TABLE` to add `oidc_org_id` instead of `auth0_org_id`

```python
        # schema_installations.sql: add oidc_org_id
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_name = 'gh_installations' AND column_name = 'oidc_org_id'
            ) THEN
                ALTER TABLE gh_installations ADD COLUMN oidc_org_id TEXT NOT NULL DEFAULT '';
            END IF;
        END
        $$
        """,
```

- [ ] **Step 6: Update InstallationRegistry — rename auth0_org methods**

In `src/canon/db/registry.py`:
- `Installation` dataclass: `auth0_org_id` → `oidc_org_id`
- `set_auth0_org_id()` → `set_oidc_org_id()`, SQL column rename
- `get_installation_by_auth0_org()` → `get_installation_by_oidc_org()`, SQL column rename
- `_row_to_installation()`: `auth0_org_id` → `oidc_org_id`

- [ ] **Step 7: Update test fixtures**

In `tests/test_db/test_user_store.py`:
- All `"auth0_sub"` keys in test dicts → `"oidc_sub"`
- All `auth0_sub=` kwargs → `oidc_sub=`

In `tests/test_db/test_registry.py`:
- `"auth0_org_id"` in `_make_install_row()` → `"oidc_org_id"`

- [ ] **Step 8: Update all callers of renamed DB methods (prevent broken intermediate state)**

These callers use the old method names and must be updated **in the same commit** as the DB renames to keep the codebase compiling:

In `src/canon/auth/routes.py`:
- Line 109: `registry.get_installation_by_auth0_org()` → `registry.get_installation_by_oidc_org()`
- Line 125: `auth0_sub=userinfo["sub"]` → `oidc_sub=userinfo["sub"]`
- Lines 147-168: `registry.set_auth0_org_id()` → `registry.set_oidc_org_id()`

In `src/canon/auth/jwt.py`:
- `resolve_org_login()`: `registry.get_installation_by_auth0_org()` → `registry.get_installation_by_oidc_org()`

In `src/canon/auth/device_routes.py`:
- Line 159: `auth0_sub=sub` → `oidc_sub=sub`

In `src/canon/web/routes.py`:
- Line 183: `settings.auth0_enabled` → `settings.auth_enabled`
- Line 633: `settings.auth0_enabled` → `settings.auth_enabled`

In `src/canon/auth/deps.py`:
- `settings.auth0_enabled` → `settings.auth_enabled`

In `src/canon/auth/middleware.py`:
- Line 82: `settings.auth0_enabled` → `settings.auth_enabled`

In `src/canon/main.py`:
- Line 361: `secret_key=settings.auth0_client_secret or "dev-not-secret"` → `secret_key=settings.auth0_client_secret or settings.oidc_client_secret or "dev-not-secret"`

Update test files that reference old column names:
- `tests/test_auth/test_middleware.py`: `auth0_enabled` checks in mock Settings
- `tests/test_auth/test_device_routes.py`: `auth0_sub` references
- `tests/test_db/test_session_store.py` (if exists): `auth0_sub` references
- `tests/test_web/test_profile_routes.py`: line 113 `"auth0_sub": "anonymous"` → `"oidc_sub": "anonymous"`

**Important:** This step is combined with the DB renames to ensure no broken intermediate state. Task 6 will then focus on the deeper provider abstraction refactor.

- [ ] **Step 9: Run tests**

Run: `uv run pytest tests/test_db/ tests/test_auth/ -v`
Expected: PASS

- [ ] **Step 10: Commit**

```bash
git add src/canon/db/ src/canon/auth/ src/canon/web/ src/canon/main.py tests/
git commit -m "feat(db): rename auth0_sub/auth0_org_id to oidc_sub/oidc_org_id, add users.role

Renames database columns and all callers in a single atomic commit
to prevent broken intermediate state. Updates auth0_enabled → auth_enabled
references throughout. Fixes SessionMiddleware secret key to fall back
to oidc_client_secret for OIDC-only deployments."
```

---

### Task 6: Refactor auth module to use provider abstraction (spec section 6)

This task refactors auth files to use the OIDCProvider protocol instead of direct Auth0 calls. Note: DB column renames and `auth0_enabled` → `auth_enabled` were already done in Task 5. This task focuses on the provider abstraction.

**Files:**
- Modify: `src/canon/auth/oauth.py`
- Modify: `src/canon/auth/routes.py`
- Modify: `src/canon/auth/jwt.py`
- Modify: `src/canon/auth/device_routes.py`
- Modify: `src/canon/auth/refresh_routes.py`
- Modify: `src/canon/auth/deps.py`
- Modify: `src/canon/main.py`
- Delete: `src/canon/auth/management.py` (absorbed into Auth0Provider)
- Modify: `tests/test_auth/test_middleware.py`
- Modify: `tests/test_auth/test_device_routes.py`
- Modify: `tests/test_auth/test_refresh_routes.py`
- Modify: `tests/test_auth/test_deps.py`
- Modify: `tests/test_auth/test_routes.py`
- Modify: `tests/test_auth/test_api_key_routes.py`
- Modify: `tests/test_web/test_routes.py`
- Modify: `tests/test_web/test_profile_routes.py`
- Modify: `tests/test_db/test_session_store.py`

- [ ] **Step 1: Refactor `oauth.py` to be provider-agnostic**

Replace `oauth.py` with a provider-configured registration. The `configure_oauth()` function should use the provider's discovery URL instead of hardcoded Auth0:

```python
# src/canon/auth/oauth.py
"""OAuth client configuration — registers the OIDC provider via authlib."""
from __future__ import annotations

from authlib.integrations.starlette_client import OAuth

from ..settings import Settings

oauth = OAuth()


def configure_oauth(settings: Settings) -> None:
    """Register the OIDC provider for authlib. Call during app startup."""
    client_kwargs: dict = {"scope": settings.oidc_scopes or "openid email profile"}

    if settings.auth0_enabled and (not settings.auth_provider or settings.auth_provider == "auth0"):
        # Auth0 path (backward compatible)
        if settings.auth0_audience:
            client_kwargs["audience"] = settings.auth0_audience
        oauth.register(
            name="auth0",
            client_id=settings.auth0_client_id,
            client_secret=settings.auth0_client_secret,
            server_metadata_url=f"https://{settings.auth0_domain}/.well-known/openid-configuration",
            client_kwargs=client_kwargs,
        )
    elif settings.oidc_issuer:
        # Generic OIDC path
        if settings.oidc_audience:
            client_kwargs["audience"] = settings.oidc_audience
        oauth.register(
            name="oidc",
            client_id=settings.oidc_client_id,
            client_secret=settings.oidc_client_secret,
            server_metadata_url=f"{settings.oidc_issuer.rstrip('/')}/.well-known/openid-configuration",
            client_kwargs=client_kwargs,
        )
```

- [ ] **Step 2: Refactor `main.py` lifespan to initialize provider**

In `src/canon/main.py`, update the lifespan to:
1. Create `app.state.oidc_provider` via `create_provider(settings)`
2. Replace `configure_oauth()` call path
3. Store the shared HTTP client as `app.state.auth_http` (renamed from `auth0_http`)
4. Pass HTTP client to provider
5. Remove direct `Auth0ManagementClient` init (now inside Auth0Provider)

Key changes (conceptual — implement the actual edits):

```python
# In lifespan:
from .auth.providers import create_provider

# Create shared HTTP client for auth
import httpx as _httpx
app.state.auth_http = _httpx.AsyncClient(timeout=30)

# Create OIDC provider
provider = create_provider(settings)
if provider is not None:
    # Inject HTTP client if provider supports it
    if hasattr(provider, '_http'):
        provider._http = app.state.auth_http
app.state.oidc_provider = provider

# Still call configure_oauth for authlib (used by routes.py callback flow)
if settings.auth_enabled:
    from .auth.oauth import configure_oauth
    configure_oauth(settings)

# Remove auth0_mgmt setup — now handled by Auth0Provider.get_user_orgs()
```

- [ ] **Step 3: Refactor `routes.py` to use provider**

Note: DB method renames (`oidc_sub=`, `get_installation_by_oidc_org()`) and `auth_enabled` were done in Task 5. This step handles the provider abstraction changes.

Major changes to `routes.py`:
- `login()`: Use `provider.get_login_url()` for generating the redirect URL (or keep authlib for the CSRF-protected flow, since authlib handles state/nonce)
- `callback()`: Keep authlib's `authorize_access_token()` for CSRF-safe code exchange. Extract claims generically.
- `callback()`: Use `provider.get_user_orgs()` instead of direct `auth0_mgmt.get_user_organizations()`
- `logout()`: Use `provider.get_logout_url()` with fallback to local-only clear

- [ ] **Step 4: Refactor `jwt.py` to use provider JWKS URI**

Note: `resolve_org_login()` rename was done in Task 5.

Changes to `jwt.py`:
- `validate_access_token()`: Accept a `jwks_uri` parameter or look up from provider. For backward compatibility, keep the `settings.auth0_domain`-based path but add a `jwks_uri` override.

- [ ] **Step 5: Refactor `device_routes.py` to use provider**

Note: `oidc_sub=` rename was done in Task 5.

Replace direct Auth0 HTTP calls with provider methods:
- `request_device_code()`: Use `provider.get_device_code()`, return 501 if `None`
- `poll_device_token()`: Use `provider.poll_device_token()`, handle `Pending` vs `TokenSet`

- [ ] **Step 6: Refactor `refresh_routes.py` to use provider**

Replace direct Auth0 token endpoint calls:
- `refresh_token()`: Use `provider.refresh_tokens()` instead of hardcoded Auth0 URL
- Replace `auth0_http` references with `auth_http` or provider method

- [ ] **Step 7: Refactor `deps.py` for server-side RBAC**

Note: `auth_enabled` and `get_installation_by_oidc_org()` renames were done in Task 5.

Add permission resolution from `users.role` for single-tenant:
- Add `_resolve_permissions()` helper that checks `settings.auth0_orgs_enabled` to decide between JWT claims and server-side role
- When `auth0_orgs_enabled` is False (single-tenant/OSS), look up `users.role` and map via `ROLE_PERMISSIONS`

- [ ] **Step 8: Skip — middleware already updated in Task 5**

`middleware.py` `auth0_enabled` → `auth_enabled` was done in Task 5. No provider-specific changes needed here.

- [ ] **Step 9: Add first-user-bootstrap logic to callback**

In `routes.py` callback, after upserting user:
- If `is_new` and user store reports zero existing users (add `count_users()` to UserStore), set role to `admin`
- Otherwise default role from DB (`editor`)

- [ ] **Step 10: Update all auth tests for provider-based patterns**

Update test files:
- `test_device_routes.py`: Mock provider instead of direct Auth0 HTTP calls
- `test_refresh_routes.py`: Mock provider instead of direct Auth0 token endpoint
- `test_deps.py`: Add test for `_resolve_permissions()` with server-side RBAC
- `test_routes.py`: Update to use provider.get_user_orgs() and provider.get_logout_url()
- `test_api_key_routes.py`: Update any `auth0_sub` references
- `test_web/test_routes.py`: Verify `auth_enabled` is injected correctly
- `test_web/test_profile_routes.py`: Update any Auth0-specific references

- [ ] **Step 10a: Add first-user-bootstrap test**

Add a test to `tests/test_auth/test_routes.py` that verifies:
- First user to log in gets `role='admin'`
- Subsequent users get `role='editor'`

```python
async def test_first_user_gets_admin_role(mock_user_store, mock_registry):
    """When no users exist, first login should assign admin role."""
    mock_user_store.upsert_user.return_value = {"id": 1, "oidc_sub": "sub1", "is_new": True}
    mock_user_store.count_users.return_value = 1  # just this user
    # ... simulate callback flow
    # Assert role set to 'admin'

async def test_subsequent_user_gets_editor_role(mock_user_store, mock_registry):
    """Subsequent users should get editor role."""
    mock_user_store.upsert_user.return_value = {"id": 2, "oidc_sub": "sub2", "is_new": True}
    mock_user_store.count_users.return_value = 2  # not the first user
    # ... simulate callback flow
    # Assert role stays 'editor'
```

- [ ] **Step 10b: Add server-side RBAC test**

Add a test to `tests/test_auth/test_deps.py` that verifies:
- When `auth0_orgs_enabled=False`, permissions come from `users.role` via `ROLE_PERMISSIONS`
- Admin role gets all permissions
- Editor role gets read + write but not admin permissions

- [ ] **Step 10c: Add parametrized dual-provider tests**

Create `tests/test_auth/test_providers/test_factory.py`:
```python
import pytest
from canon.auth.providers import create_provider
from canon.auth.providers.auth0 import Auth0Provider
from canon.auth.providers.generic_oidc import GenericOIDCProvider

@pytest.mark.parametrize("auth_provider,expected_type", [
    ("auth0", Auth0Provider),
    ("oidc", GenericOIDCProvider),
])
def test_factory_creates_correct_provider(auth_provider, expected_type, settings_factory):
    settings = settings_factory(auth_provider=auth_provider)
    provider = create_provider(settings)
    assert isinstance(provider, expected_type)

def test_factory_raises_on_unknown_provider(settings_factory):
    settings = settings_factory(auth_provider="unknown")
    with pytest.raises(ValueError, match="Unknown auth_provider"):
        create_provider(settings)
```

- [ ] **Step 11: Run all tests**

Run: `uv run pytest tests/ -x -q`
Expected: ALL PASS

- [ ] **Step 12: Run linter**

Run: `uv run ruff check src/canon/auth/ --fix`
Expected: Clean

- [ ] **Step 13: Commit**

```bash
git add src/canon/auth/ src/canon/main.py src/canon/db/ tests/
git commit -m "refactor(auth): use OIDCProvider abstraction across all auth modules

All auth route handlers now use the provider protocol instead of direct
Auth0 calls. Existing Auth0 behavior preserved when auth_provider=auth0.
Generic OIDC path works for OSS bring-your-own-IDP deployments."
```

---

## Phase 3: Helm Chart + OSS Export

### Task 7: Helm chart OIDC support (spec section 7)

**Files:**
- Modify: `chart/canon/values.yaml`
- Create: `chart/canon/templates/secret-oidc.yaml`
- Modify: `chart/canon/templates/_helpers.tpl`
- Modify: `chart/canon/templates/deployment.yaml`

- [ ] **Step 1: Add `secrets.oidc.*` to values.yaml**

After the `secrets.auth0` section (~line 85), add:

```yaml
  ## @section OIDC secrets (alternative to Auth0 — for generic OIDC providers)
  ## @param secrets.oidc.issuer OIDC provider issuer URL
  ## @param secrets.oidc.clientId OIDC application client ID
  ## @param secrets.oidc.clientSecret OIDC application client secret
  ## @param secrets.oidc.audience OIDC API audience (optional)
  ## @param secrets.oidc.existingSecret Use existing secret
  oidc:
    issuer: ""
    clientId: ""
    clientSecret: ""
    audience: ""
    existingSecret: ""
```

- [ ] **Step 2: Add `canon.oidcSecretName` helper**

In `chart/canon/templates/_helpers.tpl`, add after the Auth0 secret helper:

```
{{/*
Secret name for OIDC credentials
*/}}
{{- define "canon.oidcSecretName" -}}
{{- if .Values.secrets.oidc.existingSecret -}}
{{ .Values.secrets.oidc.existingSecret }}
{{- else -}}
{{ include "canon.fullname" . }}-oidc
{{- end -}}
{{- end }}
```

- [ ] **Step 3: Create `secret-oidc.yaml` template**

```yaml
# chart/canon/templates/secret-oidc.yaml
{{- if and .Values.secrets.oidc.issuer (not .Values.secrets.oidc.existingSecret) }}
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "canon.oidcSecretName" . }}
  labels:
    {{- include "canon.labels" . | nindent 4 }}
type: Opaque
stringData:
  OIDC_ISSUER: {{ .Values.secrets.oidc.issuer | quote }}
  OIDC_CLIENT_ID: {{ .Values.secrets.oidc.clientId | quote }}
  OIDC_CLIENT_SECRET: {{ .Values.secrets.oidc.clientSecret | quote }}
  {{- if .Values.secrets.oidc.audience }}
  OIDC_AUDIENCE: {{ .Values.secrets.oidc.audience | quote }}
  {{- end }}
{{- end }}
```

- [ ] **Step 4: Add OIDC secret mount to deployment.yaml**

After the Auth0 `secretRef` block (~line 64), add:

```yaml
          {{- if or .Values.secrets.oidc.issuer .Values.secrets.oidc.existingSecret }}
            - secretRef:
                name: {{ include "canon.oidcSecretName" . }}
          {{- end }}
```

- [ ] **Step 5: Commit**

```bash
git add chart/
git commit -m "feat(helm): add OIDC secret support alongside Auth0"
```

---

### Task 8: Update OSS export script and assets (spec section 9)

**Files:**
- Modify: `.github/scripts/export-oss.sh`
- Modify: `Dockerfile` (OSS Dockerfile if separate, or the export includes it)

- [ ] **Step 0: Update OSS Dockerfile and .env.example**

In `oss/Dockerfile`, line 28, change:
```dockerfile
RUN pip install --no-cache-dir /tmp/*.whl && rm -rf /tmp/*.whl
```
to:
```dockerfile
RUN pip install --no-cache-dir "/tmp/*.whl[server]" && rm -rf /tmp/*.whl
```

This requires a `[server]` optional-dependency group in `pyproject.toml` that includes `authlib`, `PyJWT`, and `itsdangerous`. If the existing `[cloud]` extra already covers these, use `[cloud]` instead. Check `pyproject.toml` and add/adjust as needed.

In the OSS export, ensure `.env.example` includes OIDC configuration:

```bash
# .env.example (added to OSS export)
# OIDC Configuration (required for web auth)
# OIDC_ISSUER=https://your-idp.example.com
# OIDC_CLIENT_ID=your-client-id
# OIDC_CLIENT_SECRET=your-client-secret
# OIDC_AUDIENCE=  # optional
# OIDC_SCOPES=openid email profile  # optional, defaults shown
```

- [ ] **Step 1: Add auth module to Python source rsync block**

In the `# ── Python source (OSS modules only)` rsync block, add before the `--exclude='*'` line:

```bash
    --include='auth/__init__.py' \
    --include='auth/providers/***' \
    --exclude='auth/providers/auth0.py' \
    --include='auth/oauth.py' \
    --include='auth/routes.py' \
    --include='auth/jwt.py' \
    --include='auth/middleware.py' \
    --include='auth/deps.py' \
    --include='auth/device_routes.py' \
    --include='auth/refresh_routes.py' \
    --include='auth/api_key_routes.py' \
    --include='auth/github_oauth.py' \
    --include='auth/github_routes.py' \
    --include='auth/permissions.py' \
    --include='auth/models.py' \
    --include='db/***' \
    --include='main.py' \
    --include='web/***' \
    --include='cron/***' \
    --include='billing/__init__.py' \
```

Note: `auth/management.py` is deliberately excluded (cloud-only), and `auth/providers/auth0.py` is explicitly excluded.

- [ ] **Step 2: Add auth test files to test rsync block**

In the `# ── Tests (OSS modules only)` rsync block, add:

```bash
    --include='test_auth/***' \
    --exclude='test_auth/test_providers/test_auth0.py' \
    --include='test_db/***' \
    --include='test_web/***' \
    --include='test_cron/***' \
```

- [ ] **Step 3: Commit**

```bash
git add .github/scripts/export-oss.sh
git commit -m "feat(oss): include auth module in OSS export (excluding cloud-only files)"
```

---

### Task 9: Frontend updates (spec section 12)

**Files:**
- Modify: `frontend/src/components/profile/ProfileCard.vue`
- Modify: `frontend/src/views/LoginView.vue`

- [ ] **Step 1: Update ProfileCard.vue — rename Auth0 Session label**

In `ProfileCard.vue`, line 50, change:
```typescript
    case 'session':
      return 'Auth0 Session'
```
to:
```typescript
    case 'session':
      return 'OIDC Session'
```

Also at line 156, change the permission hint text:
```
Permissions are assigned via Auth0 roles. Contact your org admin to change access.
```
to:
```
Permissions are assigned by your identity provider. Contact your org admin to change access.
```

- [ ] **Step 2: Update LoginView.vue — add generic OIDC sign-in**

The login view currently shows GitHub/Google/Email buttons that pass `connection` to Auth0. For generic OIDC, we need a single "Sign in" button. The server-side routes will handle the redirect.

We'll add a computed property to detect auth mode from a server-injected variable and conditionally render buttons:

This is a frontend change that depends on the backend injecting the auth provider type. For now, update the login view to show a single "Sign in" button when no Auth0 connections are available. The `/auth/login` endpoint (already refactored) handles the redirect correctly for both providers.

Add after `const loading = ref(false)`:
```typescript
// Auth mode injected by server. 'auth0' shows provider buttons, 'oidc' shows single button.
const authMode = computed(() => (window as any).__CANON__?.auth_mode || 'auth0')
```

Wrap the existing buttons with `v-if="authMode === 'auth0'"` and add a generic button:
```html
<div v-if="authMode === 'oidc'" class="login-buttons">
  <button class="login-btn" :disabled="loading" @click="loginWith('')">
    Sign in
  </button>
</div>
<div v-else class="login-buttons">
  <!-- existing GitHub/Google/Email buttons -->
</div>
```

- [ ] **Step 3: Commit**

```bash
git add frontend/
git commit -m "feat(frontend): update auth labels and add generic OIDC login view"
```

---

## Phase 4: Bundled Zitadel

### Task 10: Add Zitadel subchart (spec section 8)

**Files:**
- Modify: `chart/canon/Chart.yaml`
- Modify: `chart/canon/values.yaml`
- Create: `chart/canon/templates/job-zitadel-setup.yaml`

- [ ] **Step 1: Add Zitadel dependency to Chart.yaml**

Read `chart/canon/Chart.yaml` and add:

```yaml
dependencies:
  - name: zitadel
    version: "8.x.x"  # Check https://github.com/zitadel/zitadel-charts for latest
    repository: https://charts.zitadel.com
    condition: zitadel.enabled
```

- [ ] **Step 2: Add Zitadel values to values.yaml**

At the end of values.yaml, add:

```yaml
## @section Zitadel (optional — bundled identity provider for self-hosting)
## @param zitadel.enabled Deploy Zitadel alongside Canon
zitadel:
  enabled: false
  # Upstream Zitadel Helm chart values pass through here
  # See: https://github.com/zitadel/zitadel-charts
```

- [ ] **Step 3: Create Zitadel setup Job**

```yaml
# chart/canon/templates/job-zitadel-setup.yaml
{{- if .Values.zitadel.enabled }}
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ include "canon.fullname" . }}-zitadel-setup
  labels:
    {{- include "canon.labels" . | nindent 4 }}
  annotations:
    "helm.sh/hook": post-install,post-upgrade
    "helm.sh/hook-weight": "10"
    "helm.sh/hook-delete-policy": before-hook-creation
spec:
  backoffLimit: 3
  template:
    metadata:
      labels:
        {{- include "canon.selectorLabels" . | nindent 8 }}
    spec:
      restartPolicy: OnFailure
      containers:
        - name: setup
          image: curlimages/curl:latest
          command: ["/bin/sh", "-c"]
          args:
            - |
              echo "Zitadel setup job placeholder"
              echo "TODO: Create Canon project, web app, device app"
              echo "TODO: Write client credentials to K8s secret"
              # This will be implemented with Zitadel's Admin API
              # once we have the specifics of the Zitadel chart configuration
{{- end }}
```

- [ ] **Step 4: Commit**

```bash
git add chart/
git commit -m "feat(helm): add optional Zitadel subchart for self-hosted auth"
```

---

## Phase 5: Documentation

### Task 11: Update spec statuses

**Files:**
- Modify: `docs/specs/oidc-migration.md`

- [ ] **Step 1: Update all section statuses to reflect implementation**

After implementing each phase, update the spec status comments from `status:todo` to `status:done` for completed sections. For sections partially done (like section 8 — Zitadel setup Job is a placeholder), use `status:in_progress`.

- [ ] **Step 2: Commit**

```bash
git add docs/specs/oidc-migration.md
git commit -m "docs: update OIDC migration spec statuses to reflect implementation"
```

---

### Task 12: Final verification

- [ ] **Step 1: Run full test suite**

Run: `uv run pytest tests/ -v`
Expected: ALL PASS

- [ ] **Step 2: Run linter**

Run: `uv run ruff check src/ tests/ --fix`
Expected: Clean

- [ ] **Step 3: Verify Auth0 backward compatibility**

Ensure Settings with only `auth0_*` fields work exactly as before:
- `auth0_enabled` returns True
- `auth_enabled` returns True
- `create_provider()` returns Auth0Provider
- All auth routes behave identically

- [ ] **Step 4: Verify generic OIDC path**

Ensure Settings with only `oidc_*` fields create the right provider:
- `auth_enabled` returns True
- `create_provider()` returns GenericOIDCProvider
- Login redirects to discovered authorization_endpoint
- Logout uses discovered end_session_endpoint or falls back

---

## Deferred Items (not in this plan)

These items from the spec are deferred for future work:

1. **Section 10: CI/CD Updates** — Cloud deploy.yml and preview.yml are unchanged. OSS CI test with OIDC config is deferred until the OSS repo is updated.
2. **Section 11: Documentation Updates** — Full self-hosting docs rewrite and provider-specific guides are deferred to a follow-up PR.
3. **Zitadel setup Job implementation** — The Job template is a placeholder. Full Zitadel API automation deferred until Zitadel chart is tested.
4. **`canon login --browser`** — Authorization code with localhost redirect deferred per spec open questions.
5. **Integration tests against real IDPs** — Spec AC requires testing against Zitadel, Keycloak, and one commercial provider. Deferred to manual QA.
