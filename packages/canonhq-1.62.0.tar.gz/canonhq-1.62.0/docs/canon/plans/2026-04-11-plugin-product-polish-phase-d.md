# Implementation Plan: Plugin Product Polish — Phase D (Workflow Closure)

**Spec:** `docs/specs/plugin-product-polish.md`
**Sections covered:** §7 canon-reviewer auto-dispatch, §8 e2e integration test, §9 companion-skill opportunism
**Dependencies:** Phase C complete (commit `50be0c06`)
**Setup commands:** none

## Critical findings

1. **`canon verify --gate` doesn't exist in the CLI.** The `canon-verify` skill documents it (`canon-verify/SKILL.md:36-37`), and `superpowers-parity.md` §8 marks the AC as done with realization to that skill — but the CLI itself only has `--section`. Same kind of latent bug as the `canon status --json` we fixed in Phase C: skill instructs Claude to run a flag the CLI doesn't have. Phase D fixes it because §8's e2e test needs `--gate` to assert pass/fail behavior.

2. **The "e2e test" cannot literally run canon-implement** because that's a Claude Code skill, not a CLI command. A realistic e2e test exercises the CLI dependencies the skill orchestrates: `canon plan` → `canon verify --gate` → simulated edits → `canon verify --gate` again. That catches real regressions in the workflow's plumbing without needing a Claude Code session.

---

## Self-Review

- [x] Every task has exact file paths
- [x] Every Phase D AC is covered (or marked appropriately)
- [x] Dependencies between tasks identified
- [x] No placeholder language
- [x] Latent CLI gap surfaced before any test work

---

## Task 1: Add `--gate` flag to `canon verify`

**Why first:** §8's e2e test needs gate semantics. Also closes the documentation/CLI gap where `canon-verify/SKILL.md` instructs Claude to invoke a flag that doesn't exist.

**Complexity:** S | **Files:**
- `src/canon/cli/verify.py` — add `--gate` argparse flag and gate exit semantics
- `src/canon/cli/__init__.py` — pass `gate` through to `run_verify`

**Gate semantics (minimal):**
- For each unchecked AC in scope (filtered by `--section` if provided), the gate fails
- Exit code: `0` if all in-scope ACs are checked, `1` otherwise
- Stdout: same report as today plus a `PASS:` or `FAIL:` summary line
- The gate does NOT run tests; the canon-verify skill orchestrates test running. CLI gate is AC-coverage-only.

**Why CLI doesn't run tests:** keeping `canon verify --gate` pure AC-coverage avoids assuming a test runner shape. The skill body still tells Claude to run tests separately as part of gate-mode workflows.

**Acceptance check:**
```bash
# Toy repo with one unchecked AC:
uv run canon verify --gate; echo "exit=$?"  # → FAIL, exit=1
# After marking AC checked:
uv run canon verify --gate; echo "exit=$?"  # → PASS, exit=0
```

---

## Task 2: canon-reviewer auto-dispatch in canon-implement

**Spec ref:** `plugin-product-polish.md` §7

**Complexity:** M | **Files:**
- `plugin/skills/canon-implement/SKILL.md` — explicit canon-reviewer dispatch step
- `plugin/skills/canon-review/SKILL.md` — document the standalone path

**What to change in canon-implement:**

After Step 3f (Verify gate) and before Step 3g (Commit), insert a new step "3f.5: Spec-Aware Review" that:
1. Dispatches the `canon-reviewer` agent via the Agent tool with: the diff of the just-completed task, the spec section ID, and a request to focus on Spec Gaps and Spec Conflicts
2. If the reviewer reports Spec Gaps or Spec Conflicts → stop the plan, present findings, options: fix now / skip task / abort
3. Quality Issues and Suggestions are printed but don't stop execution

**Why between gate and commit:** the gate confirms ACs *say* they're realized; the reviewer confirms the *code actually satisfies* the AC. Two layers of verification.

**What to change in canon-review:**

Add a "Standalone Use" section to canon-review/SKILL.md noting that this skill can dispatch `canon-reviewer` directly when the user runs `/canon-review` outside of a canon-implement loop.

---

## Task 3: Companion-skill suggest on failure (canon-implement + canon-task)

**Spec ref:** `plugin-product-polish.md` §9, deferred from `superpowers-parity.md` §9

**Complexity:** S | **Files:**
- `plugin/skills/canon-implement/SKILL.md` — add suggest pattern to failure path
- `plugin/skills/canon-task/SKILL.md` — same pattern for single-task path

**What to add:**

In each skill's failure-handling section, add a check:

> If a debugging skill is available in the session (e.g., `superpowers:systematic-debugging`), suggest invoking it before retrying the failed task. Detection is opportunistic — never hard-depend on external plugins.

This is text-only — no code, no agent dispatch logic. The suggestion lives in the skill body so when Claude reads the skill it knows to look around and offer.

---

## Task 4: E2E integration test for the plan→verify→edit→verify workflow

**Spec ref:** `plugin-product-polish.md` §8 (and also closes `superpowers-parity.md` §5 trailing gap)

**Complexity:** M | **Files:**
- `tests/test_plugin/__init__.py` (new)
- `tests/test_plugin/test_implement_workflow_e2e.py` (new)
- `tests/fixtures/toy_spec/CANON.yaml` (new — minimal Canon project)
- `tests/fixtures/toy_spec/docs/specs/toy.md` (new — 2 sections, 4 ACs)
- `tests/fixtures/toy_spec/src/toy.py` (new — stub source the test edits)

**Test workflow:**

```python
def test_plan_then_gate_fail_then_realize_then_gate_pass(tmp_path):
    # 1. Copy fixture into tmp_path
    # 2. Run `canon plan toy.md` → assert plan file is generated
    # 3. Run `canon verify --gate` → assert FAIL (4 unchecked ACs)
    # 4. Edit src/toy.py to add the implementation
    # 5. Edit docs/specs/toy.md to mark all ACs checked + add realization comments
    # 6. Run `canon verify --gate` → assert PASS
    # 7. Run `canon status --json` → assert overall_pct == "100%"
```

**Why this test matters:** it exercises every CLI piece canon-implement orchestrates. If `canon plan` regresses, this fails. If `canon verify --gate` regresses, this fails. If parsing realization comments regresses, this fails. The test takes ~3 seconds and runs in CI alongside other test_cli tests.

**Test does NOT exercise:** the actual Claude Code skill prompts (those are tested by skill content assertions in test_skills_content.py) or the canon-reviewer agent dispatch (that requires a real Claude Code session).

**Acceptance check:**
```bash
uv run pytest tests/test_plugin/test_implement_workflow_e2e.py -v
# → 1 test, passes in <10s
```

---

## Task 5: Spec realization comments

**Complexity:** S | **Files:**
- `docs/specs/plugin-product-polish.md` — mark §7, §8, §9 with realization comments

**What to update:**
- §7 → done with file references
- §8 → done with reference to e2e test
- §9 → done with reference to skill body changes
- Top-level status: stay `draft` until Phase D is committed, then bump to `in_progress` (still has §6 deferred ACs blocking `done`)

---

## Task Dependency Graph

```
Task 1 (canon verify --gate)        ── needed by Task 4
Task 2 (canon-reviewer dispatch)    ── independent
Task 3 (companion-skill suggest)    ── independent
Task 4 (e2e workflow test)          ── needs Task 1
Task 5 (spec realization)           ── after everything
```

**Suggested order:** 1 → [2, 3 in parallel] → 4 → 5

---

## Verification Plan

```bash
uv run canon verify --gate; echo "exit=$?"
uv run pytest tests/test_plugin/test_implement_workflow_e2e.py tests/test_cli/ -v
# → all pass, e2e test under 10s
```

---

## Out of Scope

- Refactoring the canon-implement skill into a CLI command (would be the only way to test the actual orchestration end-to-end without Claude Code)
- A reviewer that runs in a sandbox (auto-dispatch is enough; sandboxing is a separate concern)
- Test runner integration in `canon verify --gate` (skill orchestrates tests, CLI stays pure)
