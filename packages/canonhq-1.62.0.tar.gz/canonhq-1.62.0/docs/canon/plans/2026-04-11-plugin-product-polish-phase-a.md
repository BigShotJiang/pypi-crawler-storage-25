# Implementation Plan: Plugin Product Polish — Phase A (Manifest Hygiene)

**Spec:** `docs/specs/plugin-product-polish.md`
**Sections covered:** §2 Settings & Manifest Hygiene
**Decisions locked in (2026-04-11):**
- Task 1: **delete** `plugin/settings.json` (Option A). Also delete the test that asserts it exists.
- Task 3: **`canonhq/canon`** is the new repo URL (`canonhq/canon-claude-plugin` was archived per memory #3348).
- Task 4: **drop screenshots from Phase A**. Defer to a follow-up after Phase C (slash commands + statusline) ships, so screenshots reflect the polished product. Update spec AC to match.
**Setup commands:** None (pure config file + test edits)
**Estimated complexity:** Phase total ~half-day (5× S, 1× M)

---

## Self-Review Checklist

Before presenting this plan to the user, the agent must confirm:

- [x] Every task has exact file paths
- [x] Every AC in §2 is covered by at least one task
- [x] Dependencies between tasks are identified
- [x] No placeholder language ("TBD", "implement later")
- [x] Open questions are flagged before tasks that depend on them

---

## Task 1: Delete `plugin/settings.json` and the test that asserts it exists

**Spec ref:** `plugin-product-polish.md` §2 — AC: "`plugin/settings.json` is either deleted (in favor of `CANON.yaml ide:` as the single source of truth) or rewritten to match the nested `ide:` schema"

**Complexity:** S | **Dependencies:** None

**Files:**
- `plugin/settings.json` — **delete**
- `tests/test_cli/test_skills_content.py` — remove `TestPluginStructure.test_settings_exists` (lines 41-42)

**Why delete:**
`plugin/settings.json` is not read by any code path in canon. The grep
sweep found references in only:
1. `tests/test_cli/test_skills_content.py:41-42` — asserts existence (will be deleted as part of this task)
2. `docs/plans/2026-03-05-canon-rebrand-implementation.md:362,385` — historical migration plan, no longer active
3. The current spec and this plan

`CANON.yaml` is the real source of truth for Canon config. Keeping a second
flat-schema config file in the plugin source is confusing schema drift.

**What to change in the test file:**

Delete this block from `tests/test_cli/test_skills_content.py`:

```python
    def test_settings_exists(self):
        assert (PLUGIN_DIR / "settings.json").exists()
```

This is the only test that references `plugin/settings.json`. The
`TestPluginStructure` class still has `test_plugin_json_exists` and
`test_mcp_json_exists` so the class doesn't become empty.

**Verification:**
```bash
test ! -e plugin/settings.json && echo "deleted"
uv run pytest tests/test_cli/test_skills_content.py -v 2>&1 | grep -E "(PASSED|FAILED)" | head -20
```

All tests in `TestPluginStructure` should pass (the deleted one is gone, the
other two still pass).

**Acceptance check:** File removed; full plugin test suite passes.

---

## Task 2: Bump plugin version to 0.2.0

**Spec ref:** `plugin-product-polish.md` §2 — AC: "version bumped to `0.2.0`"

**Complexity:** S | **Dependencies:** None

**Files:**
- `plugin/.claude-plugin/plugin.json` — update `version` field
- `.claude-plugin/marketplace.json` — update top-level plugin entry `version` field

**What to change:**

`plugin/.claude-plugin/plugin.json`:
```diff
-  "version": "0.1.0",
+  "version": "0.2.0",
```

`.claude-plugin/marketplace.json`:
```diff
-      "version": "0.1.0",
+      "version": "0.2.0",
```

**Why 0.2.0:** Matches the `ide-integration.md` Phase 2 rollout label which
shipped SessionStart + Stop hooks. The current `plugin/.claude-plugin/plugin.json`
shows `0.1.0` despite all of Phase 2 and Phase 3 being shipped — this is
catching up the version to reality, not a forward-looking bump.

**Acceptance check:**
```bash
jq -r '.version' plugin/.claude-plugin/plugin.json  # → 0.2.0
jq -r '.plugins[0].version' .claude-plugin/marketplace.json  # → 0.2.0
```

---

## Task 3: Update plugin repository URL to canonhq/canon

**Spec ref:** `plugin-product-polish.md` §2 — AC: "`plugin/.claude-plugin/plugin.json` `repository` field updated to point to a non-archived repo; decision recorded in this spec"

**Complexity:** S | **Dependencies:** None

**Files:**
- `plugin/.claude-plugin/plugin.json` — update `repository` field
- `docs/specs/plugin-product-polish.md` — record the decision in §11

**What to change:**

`plugin/.claude-plugin/plugin.json`:
```diff
-  "repository": "https://github.com/canonhq/canon-claude-plugin",
+  "repository": "https://github.com/canonhq/canon",
```

`.claude-plugin/marketplace.json` already has `"homepage": "https://github.com/canonhq/canon"` so it's consistent — no change needed there.

Then in `docs/specs/plugin-product-polish.md` §11, add a "Decisions" subsection
above the open questions:

```markdown
## 11. Decisions and Open Questions

### Decisions (2026-04-11)
- **Repository URL**: `canonhq/canon` (the standalone `canonhq/canon-claude-plugin` repo was archived in March 2026; plugin source lives in `canon-private/plugin/` and is mirrored to the public `canon` repo).
- **`plugin/settings.json`**: deleted entirely. `CANON.yaml ide:` is the single source of truth for Canon config.
- **Marketplace screenshots**: deferred to follow-up after Phase C ships, so screenshots reflect slash commands and statusline.

### Open Questions
...
```

**Acceptance check:**
```bash
jq -r '.repository' plugin/.claude-plugin/plugin.json  # → https://github.com/canonhq/canon
```

---

## Task 4: Polish marketplace listing (no screenshots)

**Spec ref:** `plugin-product-polish.md` §2 — AC: "marketplace.json gains: refined tagline, and `featured: false` is documented as intentional" *(screenshot AC deferred — see Decisions in §11)*

**Complexity:** M | **Dependencies:** None

**Files:**
- `plugin/.claude-plugin/marketplace.json` — refine tagline, leave screenshots empty (deferred), document featured flag
- `.claude-plugin/marketplace.json` — refine top-level description to match

**What to change:**

`plugin/.claude-plugin/marketplace.json`:
```json
{
  "listing": {
    "title": "Canon — Spec-Driven Development",
    "tagline": "Living specs. Verified code. Coverage that updates itself.",
    "icon": "file-text",
    "screenshots": [],
    "_screenshots_note": "Deferred until Phase C ships slash commands and statusline. See plugin-product-polish.md §11 Decisions.",
    "featured": false
  },
  "compatibility": {
    "minClaudeCodeVersion": "1.0.0"
  }
}
```

> **Note on `_screenshots_note`**: Claude Code's marketplace schema may reject
> unknown fields. Verify before committing:
> ```bash
> jq . plugin/.claude-plugin/marketplace.json  # parses?
> # If schema validation is strict, drop _screenshots_note and put the note in a code comment in plugin-product-polish.md instead
> ```

`.claude-plugin/marketplace.json` (top level):
```diff
-  "description": "Canon (formerly Specwright) — AI-native spec-driven development platform with living documentation, code verification, and coverage tracking",
+  "description": "Canon — AI-native spec-driven development. Living specs, verified code, coverage that updates itself. Includes the canon-reviewer agent and 13 skills covering plan, implement, verify, audit, and branch completion.",
```

**Tagline justification:** "Living specs. Verified code. Coverage that
updates itself." mirrors the three Canon promises (spec authoring, code
verification, automatic coverage). Three 4-word phrases scan well in a
marketplace card.

**Why screenshots are deferred:**
1. Real captures require running the polished plugin live. Phases B and C
   ship slash commands, statusline, and inline canon-meta enforcement —
   capturing screenshots before those land would mean recapturing later.
2. Claude Code marketplace schema makes screenshots optional, so the listing
   works fine without them.
3. Generating fake screenshots adds complexity and visual debt for no
   product benefit.

**Acceptance check:**
```bash
jq -r '.listing.tagline' plugin/.claude-plugin/marketplace.json  # → new tagline
jq -r '.listing.screenshots | length' plugin/.claude-plugin/marketplace.json  # → 0
jq -r '.listing.featured' plugin/.claude-plugin/marketplace.json  # → false
```

---

## Task 5: Add installation decision tree to plugin/README.md

**Spec ref:** `plugin-product-polish.md` §2 — AC: "`plugin/README.md` includes the installation decision tree from `setup-ux-improvements.md` §4.2"

**Complexity:** M | **Dependencies:** None

**Files:**
- `plugin/README.md` — replace lines 5-19 (Installation section) with a decision tree

**What to change:**

Replace the current "Installation" section with:

```markdown
## Installation

Canon ships through two paths. Pick the one that matches what you need:

| Use case | Command | What it produces |
|---|---|---|
| **Set up Canon in a repo** (write `CANON.yaml`, install MCP server, scaffold spec template) | `pipx install canonhq && canon setup` | `CANON.yaml`, `.mcp.json`, `docs/specs/_template.md`, optional `.claude/skills/` |
| **Add Canon skills to Claude Code** (slash commands and skills only) | `claude plugin marketplace add canonhq/canon` then `claude plugin install canon` | Plugin installed under `~/.claude/plugins/`, available in every session |
| **Both** (recommended for new repos) | Run `canon setup` first, then `claude plugin install canon` | Full integration: per-repo config + global plugin |

**When to use the CLI path:**
- You're starting a new Canon repo and need `CANON.yaml` written
- You want the MCP server installed automatically
- You want the spec template scaffolded

**When to use the marketplace path:**
- You already have Canon set up in your repos and just want the slash commands
- You're trying Canon out and don't want to install a Python package

`canon setup` writes `.mcp.json` and `.claude/skills/` so the marketplace
install is **not required** if you've already run `canon setup`. The two
paths are additive — installing both is supported and produces no conflicts.
```

**Why the decision tree:** the current README shows two install commands
without explaining when to use which, so users either install both
unnecessarily or skip the CLI step and end up without `CANON.yaml`.

**Acceptance check:** README contains a markdown table with both install
paths and a "When to use" section for each.

---

## Task 6: Add multi-agent setup section to plugin/README.md

**Spec ref:** `plugin-product-polish.md` §2 — AC: "`plugin/README.md` describes the multi-agent setup path"

**Complexity:** S | **Dependencies:** Task 5 (same file, sequential edit safer)

**Files:**
- `plugin/README.md` — append a new section after "Installation"

**What to add** (insert after the Installation section):

```markdown
## Multi-Agent Setup

Canon's spec context works in any AI coding agent that supports MCP or rule
files. Use `canon setup --agent <platform>` to generate the right config
file for each:

| Platform | Command | Output file |
|---|---|---|
| Claude Code | `canon setup --agent claude` | `.claude/CLAUDE.md` |
| Cursor | `canon setup --agent cursor` | `.cursorrules` |
| GitHub Copilot | `canon setup --agent copilot` | `.github/copilot-instructions.md` |
| Codex | `canon setup --agent codex` | `AGENTS.md` |
| Gemini CLI | `canon setup --agent gemini` | `GEMINI.md` |
| All of the above | `canon setup --agent all` | All five files |

Each generated file is ~20 lines. It tells the agent that Canon specs exist,
points at `CANON.yaml`, and explains how to access spec context (via the
Canon MCP tools or the `canon` CLI). The files are committed to the repo and
only need regenerating when Canon ships a new agent-config template.
```

**Why:** the `canon setup --agent` flow shipped via `ide-integration.md` §6
but the plugin README doesn't mention it. Users on non-Claude editors don't
know Canon supports them.

**Acceptance check:** README contains a "Multi-Agent Setup" section with
the table above.

---

## Task Dependency Graph

```
Task 1 (delete settings.json + test)  ──┐
Task 2 (version bump)                   ──┤
Task 3 (repo URL + spec decisions block) ──┤
Task 4 (marketplace tagline)            ──┴── all independent
Task 5 (README install tree)            ──┐
Task 6 (README multi-agent section)     ──┴── sequential (same file)
```

**Suggested order:** 1 → 2 → 3 → 4 → 5 → 6 (linear, all small)
**Parallel order:** [1, 2, 3, 4] in parallel → 5 → 6

---

## Verification Plan

After all 6 tasks:

1. **Manifest sanity:**
   ```bash
   jq . plugin/.claude-plugin/plugin.json
   jq . plugin/.claude-plugin/marketplace.json
   jq . .claude-plugin/marketplace.json
   ```
   All three should parse cleanly and report `version: 0.2.0`.

2. **Repo URL reachable:**
   ```bash
   gh repo view "$(jq -r .repository plugin/.claude-plugin/plugin.json | sed 's|https://github.com/||')" --json isArchived
   ```
   Should report `isArchived: false`.

3. **README rendering:**
   ```bash
   pandoc plugin/README.md -o /tmp/readme.html  # or use a markdown viewer
   ```
   Both new sections (Installation table, Multi-Agent table) should render.

4. **Schema drift gone:**
   ```bash
   ls plugin/settings.json  # → should not exist (Option A) OR match nested ide: schema (Option B)
   ```

5. **Spec verification:**
   ```bash
   canon verify --gate --section 2  # against plugin-product-polish.md
   ```
   Should pass (or report which ACs lack realization comments — we'll add
   `<!-- canon:realized-in: -->` markers when committing).

---

## Commit Strategy

One commit at the end of Phase A:
```
chore(plugin): manifest hygiene + README polish (plugin-product-polish §2)

- Remove plugin/settings.json (or rewrite to nested ide: schema)
- Bump plugin version 0.1.0 → 0.2.0
- Update repository URL to non-archived repo
- Refine marketplace tagline, add 3 screenshot slots
- README: add installation decision tree and multi-agent setup section
```

Spec realization comments added inline as part of the commit so
`superpowers-parity.md` §10 can track Phase A as done.

---

## Out of Scope for Phase A

These belong to Phase B/C/D and explicitly not this plan:

- `canon ide-config --json` CLI subcommand (Phase B, §3)
- Hook YAML parsing refactor (Phase B, §3)
- SessionStart inline meta-skill injection (Phase B, §4)
- Slash commands (Phase C, §5)
- Statusline + output style (Phase C, §6)
- canon-reviewer auto-dispatch (Phase D, §7)
- E2E integration test (Phase D, §8)
- Real screenshot captures (follow-up after Phase C ships)

---

## Open Questions Before Starting

All three Phase A decisions are locked in (see top of plan and §11 of the
spec). No outstanding questions block execution.
