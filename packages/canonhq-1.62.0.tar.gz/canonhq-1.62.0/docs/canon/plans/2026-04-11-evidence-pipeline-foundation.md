# Implementation Plan: Plugin Evidence Pipeline — Foundation (Phases 1 + 2)

**Spec:** `docs/specs/plugin-evidence-pipeline.md`
**Sections covered:** §2 Evidence Schema, §3 Stop Hook Evidence Writer, §4 canon-verify Trail Logging
**Sections deferred to a future PR:** §5 PreToolUse git push, §6 MCP record_session_evidence tool, §7 GitHub App analyzer hint input
**Dependencies:** Phase D complete (commit `6be20e87`); `canon verify --gate` shipped in Phase D

## Scope rationale

The full spec spans plugin code, MCP server, and GitHub App. This PR ships the
**plugin-only foundation**: schema, local capture, opt-in flag, verify trail.
That's independently valuable (the verify trail alone closes a `superpowers-parity.md`
§8 gap) and lets us dogfood the capture before deciding whether the persistence
and GitHub App consumption pieces are worth the complexity.

After this lands, the next PR can pick up §5 (push hook), §6 (MCP), §7
(analyzer) without rework.

---

## Self-Review

- [x] Every task has exact file paths
- [x] Every in-scope AC is covered
- [x] Out-of-scope ACs are explicitly marked with rationale
- [x] No placeholder language
- [x] Plan respects existing patterns (`IdeConfig`, `canon ide-config`, hook fallback)

---

## Task 1: Add `evidence_pipeline` config field

**Spec ref:** `plugin-evidence-pipeline.md` §3.2 — opt-in flag

**Complexity:** S | **Files:**
- `src/canon/config/parse.py` — add `EvidencePipelineConfig` Pydantic model and wire into `IdeConfig`

**What to add:**

```python
class EvidencePipelineConfig(BaseModel):
    enabled: bool = False  # off by default; users opt in per repo
    persist: Literal["file", "mcp", "both"] = "file"
    commit_on_push: Literal["ask", "always", "never"] = "ask"


class IdeConfig(BaseModel):
    auto_context: AutoContextConfig = AutoContextConfig()
    auto_verify: AutoVerifyConfig = AutoVerifyConfig()
    ai_exposure: AiExposureConfig = AiExposureConfig()
    evidence_pipeline: EvidencePipelineConfig = EvidencePipelineConfig()
```

**Acceptance check:**
```bash
uv run canon ide-config --json | jq -r '.evidence_pipeline.enabled'
# → false (default)
```

The existing `canon ide-config --json` automatically picks up the new field via `model_dump()`, no CLI changes needed.

---

## Task 2: SessionEvidence Pydantic models

**Spec ref:** `plugin-evidence-pipeline.md` §2.1, §2.2

**Complexity:** M | **Files:**
- `src/canon/evidence/__init__.py` (new)
- `src/canon/evidence/models.py` (new) — `SessionEvidence`, `SessionRecord`, `SpecTouched`, `AcAddressed`, `VerifyRun`

**What to define:**

```python
from pydantic import BaseModel
from typing import Literal


class SpecTouched(BaseModel):
    spec: str
    sections: list[str]
    loaded_via: list[str] = []  # canon-context, canon-task, canon-implement


class AcAddressed(BaseModel):
    spec: str
    section: str
    ac_text: str
    files: list[str] = []
    line_ranges: list[str] = []
    verify_status: Literal["realized", "partial", "not_started", "unknown"] = "unknown"
    verified_at: str | None = None  # ISO 8601


class VerifyRun(BaseModel):
    at: str  # ISO 8601
    section: str | None = None
    mode: Literal["report", "gate"] = "gate"
    result: Literal["pass", "fail"]
    gaps: int = 0
    conflicts: int = 0


class SessionRecord(BaseModel):
    session_id: str  # YYYYMMDD-HHMMSS-<short-hash>
    started_at: str  # ISO 8601
    ended_at: str  # ISO 8601
    git_branch: str
    git_base: str | None = None
    specs_touched: list[SpecTouched] = []
    acs_addressed: list[AcAddressed] = []
    files_modified: list[str] = []
    verify_runs: list[VerifyRun] = []


class SessionEvidence(BaseModel):
    """Top-level container — multi-session aggregation per branch."""
    version: int = 1
    sessions: list[SessionRecord] = []
```

**Acceptance check:**
```bash
uv run python -c "from canon.evidence.models import SessionEvidence; print(SessionEvidence().model_dump_json(indent=2))"
# → {"version": 1, "sessions": []}
```

---

## Task 3: canon verify --gate trail logging

**Spec ref:** `plugin-evidence-pipeline.md` §4

**Complexity:** S | **Files:**
- `src/canon/cli/verify.py` — append a JSONL record to `.canon/verify-log.jsonl` when `--gate` is used

**What to add:**

After the gate decision is made (PASS or FAIL), append a record to
`.canon/verify-log.jsonl` if the directory exists or the user has
`evidence_pipeline.enabled: true` (auto-create the directory in that case).

Record shape (matches `VerifyRun` schema from Task 2):
```json
{"at": "2026-04-11T20:00:00Z", "section": "2.1", "mode": "gate", "result": "pass", "gaps": 0, "conflicts": 0}
```

**Trail rotation:** when the file exceeds 1 MB, rename to `.jsonl.1` and start fresh. Keeps the file from growing unbounded across many gate runs.

**Acceptance check:**
```bash
# In a Canon repo with evidence_pipeline.enabled: true
uv run canon verify --gate
ls .canon/verify-log.jsonl
tail -1 .canon/verify-log.jsonl | jq .result
```

---

## Task 4: `canon evidence` CLI subcommand group

**Spec ref:** `plugin-evidence-pipeline.md` §3

**Complexity:** M | **Files:**
- `src/canon/cli/evidence.py` (new)
- `src/canon/cli/__init__.py` — register the new subcommand

**Subcommand surface:**

```bash
canon evidence record         # Compose a SessionRecord and append to .canon/session-evidence.json
canon evidence list-verify-runs [--since <iso>]  # Read .canon/verify-log.jsonl
canon evidence show           # Pretty-print .canon/session-evidence.json
```

**`canon evidence record` algorithm:**
1. Read `evidence_pipeline.enabled` from IdeConfig; if false, exit silently
2. Resolve current git branch (`git rev-parse --abbrev-ref HEAD`) and base (`git merge-base HEAD origin/main`, fallback to `main`)
3. Read modified files (`git diff --name-only HEAD`)
4. Read recent verify runs from `.canon/verify-log.jsonl` (since the most recent prior session ended_at, or all if no prior session)
5. Compose a `SessionRecord` with the data above
6. Atomically append to `.canon/session-evidence.json`:
   - Read existing file (or empty list if missing)
   - Append the new record
   - Write to `.session-evidence.json.tmp`
   - Rename to `.session-evidence.json`
7. Print the session_id to stdout

**Why a CLI command (not inline in the hook):** keeps shell scripting minimal,
makes the logic testable from Python, and lets users invoke it manually for
checkpointing.

**Acceptance check:**
```bash
# In a Canon repo with evidence_pipeline.enabled: true and at least one git commit
uv run canon evidence record
# → prints session_id like "20260411-200000-a7b3"
ls .canon/session-evidence.json
cat .canon/session-evidence.json | jq -r '.sessions[0].session_id'
```

---

## Task 5: Stop hook integration

**Spec ref:** `plugin-evidence-pipeline.md` §3.1, §3.2

**Complexity:** S | **Files:**
- `plugin/hooks/stop.sh` — call `canon evidence record` when `evidence_pipeline.enabled` is true

**What to add to stop.sh:**

After the existing "stop suggestion" logic (the part that suggests `/canon:verify` on changed files), add a section that calls `canon evidence record` if the user has opted in. This happens in addition to the suggestion — they're independent features.

```bash
# Evidence pipeline (opt-in)
if command -v jq >/dev/null 2>&1; then
  ev_enabled=$(echo "$ide_config" | jq -r '.evidence_pipeline.enabled // false' 2>/dev/null)
  if [ "$ev_enabled" = "true" ]; then
    (cd "$CLAUDE_PROJECT_DIR" && canon evidence record 2>/dev/null) || true
  fi
fi
```

The existing `read_ide_config` helper from Phase B already supplies `$ide_config`. Just add the new check using the same JSON.

**Note:** The command is wrapped in `|| true` so a failure to record evidence
never breaks the Stop hook flow. Evidence capture is best-effort.

**Acceptance check:** With `evidence_pipeline.enabled: true` in CANON.yaml, ending a Claude Code session should result in a new `.canon/session-evidence.json` (or an appended record). Verified by the integration test in Task 6.

---

## Task 6: Tests

**Complexity:** M | **Files:**
- `tests/test_cli/test_evidence.py` (new)

**What to test:**

1. **Pydantic models** — round-trip JSON for `SessionEvidence`, `SessionRecord`, all sub-types
2. **`canon ide-config --json`** — emits `evidence_pipeline.enabled: false` by default
3. **`canon verify --gate` trail logging** — creates `.canon/verify-log.jsonl` on first gate run when opted in, appends subsequent runs, rotates at 1 MB
4. **`canon evidence record`** — exits silently when disabled, creates session-evidence.json when enabled, appends to existing file on subsequent calls, atomic write under simulated interrupt
5. **`canon evidence list-verify-runs`** — emits records from the trail, supports `--since` filter
6. **`canon evidence show`** — pretty-prints the evidence file

Subprocess-based, following the Phase B/C/D pattern. Use a temp git repo per test (init, single commit, then run commands).

---

## Task 7: Update spec

**Complexity:** S | **Files:**
- `docs/specs/plugin-evidence-pipeline.md` — mark §2, §3, §4 in_progress with realization comments for foundation ACs; leave §5, §6, §7 as todo

---

## Task Dependency Graph

```
Task 1 (config field)              ──┬── needed by Tasks 4, 5
Task 2 (Pydantic models)           ──┘
                                     │
Task 3 (verify trail)              ──── independent of Task 4 conceptually,
                                       but Task 4 reads the trail
Task 4 (canon evidence CLI)        ──── needs Tasks 1, 2, 3
Task 5 (stop.sh integration)       ──── needs Task 4
Task 6 (tests)                     ──── needs everything
Task 7 (spec updates)              ──── after everything
```

**Suggested order:** [1, 2, 3 in parallel] → 4 → 5 → 6 → 7

---

## Verification Plan

```bash
# Default state (no opt-in)
uv run canon ide-config --json | jq .evidence_pipeline.enabled  # → false
uv run canon evidence record  # → silently exits 0

# Opted-in state in tmp repo
uv run pytest tests/test_cli/test_evidence.py -v
# → all pass

# Round-trip
uv run python -c "from canon.evidence.models import SessionEvidence, SessionRecord; r = SessionRecord(session_id='test', started_at='now', ended_at='now', git_branch='main'); ev = SessionEvidence(sessions=[r]); print(ev.model_dump_json())"
```

---

## Out of Scope (deferred to a follow-up PR)

- §5 PreToolUse `git push` persistence prompt — needs decision on commit-vs-MCP ergonomics
- §6 MCP `record_session_evidence` tool — needs database migration and table design
- §7 GitHub App analyzer hint input — needs `src/canon/agent/analyzer.py` changes and telemetry instrumentation
- Schema versioning beyond `version: 1` — only matters when v2 ships
- Multi-machine session aggregation (e.g., laptop + remote session on same branch) — defer until anyone hits it

The foundation we're shipping makes those follow-ups straightforward but they
touch systems beyond the plugin and deserve their own scope.
