# Implementation Plan: Plugin Evidence Pipeline — §6 MCP Tool + §7 Analyzer Hint

**Spec:** `docs/specs/plugin-evidence-pipeline.md`
**Sections covered:** §6 MCP `record_session_evidence` tool, §7 GitHub App analyzer hint input
**Dependencies:** §5 commit `841b9d3a`
**Setup commands:** none

## Scope

This is the strategic finish line: the plugin captures evidence locally (foundation + §5),
the MCP tool persists it to the Canon backend (§6), and the GitHub App's PR analyzer
reads it and shapes the LLM prompt at PR-open time (§7). After this PR, the dev→PR
loop is functionally closed.

## Findings from exploration

- **MCP tool registration**: `@mcp.tool(name=..., description=...)` decorator on async functions inside `create_mcp_server` (`src/canon/mcp/server.py:158-945`). Tools take parameters as function args and return `dict | list[dict]`. Errors return `{"error": "..."}`. Dependencies come via `_get_deps(ctx)` returning `McpDeps`.
- **Database**: `asyncpg.Pool` directly, no ORM. Migrations under `src/canon/db/migrations/versions/000N_*.py` with simple `op.execute("...")` SQL. Latest is `0006`. Stores live as `src/canon/db/<name>_store.py` classes wrapping a pool with async methods.
- **ai_exposure**: Existing pattern at `src/canon/mcp/server.py:114-156` (`_get_ai_exposure_config`, `_resolve_exposure`). Repo-level default + per-spec frontmatter overrides + tag restrictions. The search tool filters at line 219-246.
- **Analyzer plumbing**: `analyze_pr(context: PRAnalysisContext)` at `src/canon/agent/analyzer.py:99` calls `build_user_message(context)` at `prompts.py:148`. Context has `pr.head_branch`, `pr.base_branch`, repo info via `context.specs[0].file_path`. The webhook handler at `src/canon/github/handlers/on_pull_request.py:316` constructs the context.
- **GitHub file fetch**: `client.get_file_content(owner, repo, path, ref)` returns `(content, sha)`; raises on 404 via `_get` (need to wrap in try/except).
- **No rate limiting infrastructure** exists. Build a tiny in-memory rate limiter for §6.

---

## Self-Review

- [x] Every task has exact file paths
- [x] Every in-scope AC is covered
- [x] Dependencies between tasks identified
- [x] No placeholder language

---

## Task 1: Database migration for `session_evidence` table

**Spec ref:** §6 — table indexed by `(repo_id, branch)` for PR-time lookup

**Complexity:** S | **Files:**
- `src/canon/db/migrations/versions/0007_session_evidence.py` (new)

**Schema:**
```sql
CREATE TABLE session_evidence (
    id              BIGSERIAL PRIMARY KEY,
    repo            TEXT NOT NULL,           -- owner/repo
    branch          TEXT NOT NULL,
    session_id      TEXT NOT NULL,
    schema_version  INT  NOT NULL DEFAULT 1,
    payload         JSONB NOT NULL,
    recorded_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (repo, session_id)
);
CREATE INDEX idx_session_evidence_branch ON session_evidence (repo, branch);
CREATE INDEX idx_session_evidence_recorded_at ON session_evidence (recorded_at);
```

The `(repo, session_id)` UNIQUE prevents duplicate ingestion if the plugin retries.
The `(repo, branch)` index supports the §7 analyzer query path.

---

## Task 2: `SessionEvidenceStore` data access layer

**Spec ref:** §6

**Complexity:** S | **Files:**
- `src/canon/db/session_evidence_store.py` (new)

Mirrors `error_store.py` shape:
- `SessionEvidenceRow` dataclass
- `SessionEvidenceStore(pool: asyncpg.Pool)` with:
  - `async def insert(repo, branch, session_id, schema_version, payload) -> int` (returns id; ON CONFLICT DO NOTHING)
  - `async def list_for_branch(repo, branch, *, limit=20) -> list[SessionEvidenceRow]`
  - `async def count_in_window(repo, *, since: datetime) -> int` (for rate limiting)

---

## Task 3: `record_session_evidence` MCP tool

**Spec ref:** §6.1, §6.2

**Complexity:** M | **Files:**
- `src/canon/mcp/server.py` — register new tool, wire store
- `src/canon/mcp/deps.py` — add `session_evidence_store` field
- `src/canon/mcp/__main__.py` (or wherever deps are constructed) — instantiate the store

**Tool signature:**
```python
@mcp.tool(name="record_session_evidence", description=...)
async def record_session_evidence(
    repo: str,           # owner/repo
    branch: str,
    session: dict,       # SessionRecord JSON
    ctx: Context = None,
) -> dict:
    # 1. Validate `session` against SessionRecord Pydantic model → 400 on failure
    # 2. Look up ai_exposure config for the repo via _get_ai_exposure_config
    # 3. If config_default == "none" → return {"error": "ai_exposure: none"}
    # 4. Rate limit: check store.count_in_window(repo, since=now-1h) — max 60
    # 5. Insert via store
    # 6. Return {"recorded": True, "session_id": <session_id>, "id": <db_id>}
```

**Rate limit pattern:** simple DB count + threshold check. No in-memory state, so it
survives MCP server restarts. 60 records per hour per repo is the cap from the spec.

---

## Task 4: Analyzer reads session evidence at PR time

**Spec ref:** §7

**Complexity:** M | **Files:**
- `src/canon/agent/prompts.py` — extend `build_user_message` to render an evidence section
- `src/canon/agent/analyzer.py` — `analyze_pr` loads evidence before calling `build_user_message`
- `src/canon/github/handlers/on_pull_request.py` — pass evidence into context (or load from analyzer)

**Strategy:**
1. Extend `PRAnalysisContext` with an optional `evidence: list[dict] | None = None` field
2. In `on_pull_request.py` after constructing the context, attempt to fetch
   `.canon/session-evidence.json` from the PR head branch tree via
   `client.get_file_content(owner, repo, ".canon/session-evidence.json", ref=head_sha)`.
   On 404 / parse error → leave `evidence` as None (cold analysis fallback).
3. If file missing, fall back to DB query via `SessionEvidenceStore.list_for_branch`
   (only when an `evidence_store` is wired into the deps — initially DB-only mode is
   on the analyzer side too, gated on store availability)
4. `build_user_message` adds a "Dev Session Evidence" section *between* spec docs and
   diffs:
   ```
   ## Dev Session Evidence
   The developer worked on this branch across N session(s). They explicitly
   loaded these spec sections: <list>. They reported the following ACs as
   realized via canon-verify gate runs: <list>. Treat these as high-confidence
   hints when mapping the diff to ACs, but verify against the actual code.
   ```
5. Respect `ai_exposure` filtering: skip evidence sections that reference specs the
   repo restricts (use the same `_get_ai_exposure_config` pattern)

**Token tracking:** add `evidence_used: bool` and `evidence_session_count: int` to
`PRAnalysisResult.tokens_used` extension (or a sibling field). Track via existing
analytics. Skip the strict 15% reduction acceptance — that's a measurement, not a unit
test, and would be observed in dogfood.

---

## Task 5: Tests

**Complexity:** M | **Files:**
- `tests/test_cli/test_evidence.py` (extend) — MCP tool registration check
- `tests/test_db/test_session_evidence_store.py` (new) — store CRUD against a real
  test DB if available, otherwise skip with `pytest.importorskip("asyncpg")`
- `tests/test_agent/test_prompts_evidence.py` (new) — `build_user_message` includes
  the evidence section when context has evidence; respects ai_exposure filtering

**Pragmatic constraint:** the existing test_db files may have the same import-resolution
issue as test_cli/test_verify.py (per the Phase D note about `from canon.X import ...`).
Use subprocess + a smoke-test harness if direct imports fail. Live DB tests can be
skipped if no test DB is available.

---

## Task 6: Spec realization

**Files:**
- `docs/specs/plugin-evidence-pipeline.md` — mark §6, §7 done with realization comments

---

## Task Dependency Graph

```
Task 1 (migration)            ──┐
Task 2 (store)                ──┴── Task 1
Task 3 (MCP tool)             ──── needs Tasks 1, 2
Task 4 (analyzer)             ──── needs Task 2 (uses store from §6)
Task 5 (tests)                ──── needs everything
Task 6 (spec updates)         ──── after everything
```

**Suggested order:** 1 → 2 → [3, 4 in parallel] → 5 → 6

---

## Verification Plan

```bash
# Migration parses
uv run python -c "from canon.db.migrate import upgrade_to_head; print('ok')"

# Store smoke test (requires test DB)
DATABASE_URL=postgresql://... uv run pytest tests/test_db/test_session_evidence_store.py -v

# MCP tool registers
uv run python -c "from canon.mcp.server import create_mcp_server; from canon.mcp.deps import McpDeps; m = create_mcp_server(McpDeps()); print([t.name for t in m._tool_manager.list_tools()])"
# → should include "record_session_evidence"

# Prompt builder includes evidence section
uv run pytest tests/test_agent/test_prompts_evidence.py -v
```

---

## Out of Scope

- Real-DB integration tests (depends on a Postgres test runner; will skip cleanly)
- Telemetry instrumentation (the spec mentions `evidence_used: bool` and per-PR token
  tracking; we'll add the bool and a count, but won't build a comparison dashboard)
- §7 "trust but verify" A/B test — that's a research task, not a unit test
- `_merge_with_defaults` Pydantic refactor — separate cleanup task
- Push hook MCP wire-up (§5's stub) — will land naturally once Task 3 ships, but the
  client-side `canon evidence push` would still need to learn how to talk to the MCP
  server. Defer to a follow-up after dogfood.
