# Implementation Plan: Superpowers Parity

**Spec:** `docs/specs/superpowers-parity.md`
**Sections covered:** 2-9 (all implementation systems)
**Dependencies:** Canon plugin source at `~/.claude/plugins/marketplaces/canon-claude-plugin/plugins/canon/`
**Note:** This plan targets the plugin source repo. All file paths are relative to the Canon plugin root.

---

## Phase 1: Foundation

### Task 1: SessionStart hook script
**Spec:** Section 2 | **Complexity:** S | **Dependencies:** None

**Files:**
- Create `hooks/hooks.json`
- Create `hooks/session-start.sh`

**What to do:**

`hooks/hooks.json` — register the SessionStart hook:
```json
{
  "hooks": {
    "SessionStart": [
      {
        "matcher": "startup|resume|clear|compact",
        "hooks": [
          {
            "type": "command",
            "command": "bash \"${CLAUDE_PLUGIN_ROOT}/hooks/session-start.sh\"",
            "async": false
          }
        ]
      }
    ]
  }
}
```

`hooks/session-start.sh` — emit a concise skill summary as JSON `additionalContext`. The script should:
1. Check if `docs/specs/` exists in the current working directory
2. If yes: emit context listing all Canon skills with one-line trigger descriptions, noting "spec-driven project detected"
3. If no: emit a shorter context suggesting `/canon:new` to get started
4. Keep total output under 2KB

Output format (matching Claude Code hook protocol):
```json
{
  "additionalContext": "# Canon Skills Available\n\n..."
}
```

**ACs covered:** Section 2, bullets 1-5

---

### Task 2: canon-meta skill
**Spec:** Section 2 | **Complexity:** M | **Dependencies:** None

**Files:**
- Create `skills/canon-meta/SKILL.md`

**What to do:**

Create a meta-skill (analogous to superpowers' `using-superpowers`) that documents when each Canon skill should be invoked. Structure:

```yaml
---
name: canon-meta
description: >
  Skill discovery and enforcement for Canon. Documents when each Canon skill
  should be invoked and prevents rationalization of skipping spec-driven workflows.
allowed-tools:
  - Read
  - Glob
  - Grep
---
```

Content sections:
1. **Skill Map** — table of all Canon skills with trigger conditions:
   - canon-context: starting any task, investigating code, reviewing a PR
   - canon-plan: new feature or project, need to break work into tasks
   - canon-new: creating a new spec, proposal, ADR, or design doc
   - canon-task: picking up a single task from a spec
   - canon-implement: executing a multi-task implementation plan
   - canon-worktree: need isolation for spec-driven work
   - canon-branch: done with a development branch, ready to merge/PR
   - canon-verify: checking if code satisfies spec ACs
   - canon-review: reviewing code changes against documentation
   - canon-update: updating spec statuses from code evidence
   - canon-audit: periodic full audit of all specs
   - canon-status: checking overall project coverage

2. **Rationalization Table** — common reasons to skip spec workflows vs. reality:
   - "This is just a quick fix" → Quick fixes drift specs. Use canon-context to check.
   - "The spec doesn't exist yet" → Use canon-new to create one.
   - "I'll update the spec later" → Later never comes. Record realization evidence now.
   - "This isn't covered by a spec" → Use canon-context to check — it probably is.
   - "The spec is outdated" → Use canon-update to fix it, don't ignore it.

3. **Recommended Companion Plugins** — note that TDD, debugging, and generic code review skills are available in plugins like superpowers, and Canon's spec context (via MCP) enriches those workflows.

**ACs covered:** Section 2, bullets 6-7

---

### Task 3: canon-worktree skill
**Spec:** Section 4 | **Complexity:** M | **Dependencies:** None

**Files:**
- Create `skills/canon-worktree/SKILL.md`

**What to do:**

```yaml
---
name: canon-worktree
description: >
  Create an isolated git worktree for spec-driven work. Use when starting feature
  work that needs isolation or before executing implementation plans.
allowed-tools:
  - Read
  - Bash
  - Glob
  - Grep
  - mcp__canon__get_spec
  - mcp__canon__search
---
```

Skill steps:

**Step 1: Determine worktree directory**
Priority order:
1. Check if `.claude/worktrees/` exists in project root → use it
2. Check CLAUDE.md for a worktree directory convention
3. Ask user

**Step 2: Safety verification**
Run `git check-ignore <directory>` to confirm the directory is git-ignored. If not, warn and ask user to add it to `.gitignore` before proceeding.

**Step 3: Determine spec context**
If user provides a spec or section ID, use it for branch naming. Otherwise, ask or infer from recent git changes.

**Step 4: Create worktree**
```bash
git worktree add <dir>/<spec-slug> -b canon/<spec-slug>/<section-id>
```

**Step 5: Project setup**
Auto-detect and run:
- `package.json` → `npm install` or `pnpm install`
- `pyproject.toml` → `uv sync` or `pip install -e .`
- `Cargo.toml` → `cargo build`
- `go.mod` → `go mod download`

**Step 6: Verify baseline**
Run project test suite. Report pass/fail.

**Step 7: Load spec context**
Invoke canon-context skill or load spec via MCP to populate the session with relevant spec context.

**Step 8: Report**
Print worktree location, branch name, and spec context loaded.

Include a **Cleanup** section documenting:
```bash
git worktree remove <path>
git branch -d canon/<spec-slug>/<section-id>
```

**ACs covered:** Section 4, all bullets

---

## Phase 2: Planning + Execution

### Task 4: Enhanced canon-plan Phase 6
**Spec:** Section 3 | **Complexity:** M | **Dependencies:** None

**Files:**
- Modify `skills/canon-plan/SKILL.md`

**What to do:**

Add a new "Phase 6: Implementation Plan" section after the existing Phase 5. This phase generates a file-level implementation plan from the spec tasks identified in Phase 5.

New content to append:

```markdown
## Phase 6: Implementation Plan

Generate a detailed, executable implementation plan. This goes beyond Phase 5's task list — each task must have enough detail for a subagent to execute without additional context.

### Plan File Location

Save to: `docs/canon/plans/YYYY-MM-DD-<spec-slug>.md`

### Plan Header (required)

```
# Implementation Plan: <Feature Name>

**Spec:** `docs/specs/<spec-file>.md`
**Sections covered:** <list of section IDs>
**Dependencies:** <external dependencies or setup needed>
**Setup commands:** <commands to run before starting>
```

### Task Structure (required per task)

Each task must include:
1. **Spec reference** — section ID and specific ACs this task addresses
2. **File paths** — exact files to create or modify
3. **What to change** — concrete description of the implementation approach
4. **Complexity** — S (< 30 min), M (30-60 min), L (> 60 min)
5. **Dependencies** — which other tasks must complete first

### Quality Gates

- NO placeholders: "TBD", "implement later", "add logic here" are forbidden
- Every task must map to at least one spec AC
- Every AC must be covered by at least one task

### Self-Review Checklist

Before presenting the plan:
- [ ] Every task has exact file paths
- [ ] Every AC in scope is covered by a task
- [ ] Dependencies between tasks are identified
- [ ] No placeholder language exists
- [ ] Setup commands are complete and tested
```

Also update the skill description to mention Phase 6:
```yaml
description: >
  Spec-driven planning workflow inspired by OpenSpec. Use when starting a new
  feature or project to go from exploration through spec creation to
  implementation tasks and detailed implementation plans.
```

**ACs covered:** Section 3, all bullets

---

### Task 5: canon-implement skill
**Spec:** Section 5 | **Complexity:** L | **Dependencies:** Task 3 (worktree), Task 4 (plan format)

**Files:**
- Create `skills/canon-implement/SKILL.md`

**What to do:**

```yaml
---
name: canon-implement
description: >
  Execute an implementation plan task-by-task with spec traceability. Orchestrates
  the canon-task inner loop with plan-level automation: worktree setup, commits,
  reviewer dispatch, and branch completion.
allowed-tools:
  - Read
  - Write
  - Edit
  - Glob
  - Grep
  - Bash
  - mcp__canon__get_spec
  - mcp__canon__get_section
  - mcp__canon__search
  - mcp__canon__add_realization
  - mcp__canon__update_section_status
  - mcp__canon__sync_spec_status
---
```

Skill structure:

**Step 1: Load Plan**
- Accept plan file path as argument, or list available plans in `docs/canon/plans/`
- Parse the plan to extract task list with dependencies, spec references, and file paths
- Present task overview to user for confirmation

**Step 2: Setup (optional)**
- If not already in a worktree, suggest invoking `canon-worktree`
- Run any setup commands listed in the plan header

**Step 3: Execute Tasks**

For each task (respecting dependency order):

1. Announce: "Starting Task N: <subject> [spec:<section-id>]"
2. Load linked spec section context (via MCP or file read)
3. Present the task's target ACs
4. **Inner loop** (reuses canon-task pattern):
   - Search codebase for existing relevant code
   - Implement the requirement
   - Verify implementation satisfies ACs
5. Record realization evidence for completed ACs
6. Run `canon verify --gate` for the relevant section (Section 8 gate mode)
7. If gate passes: commit with message `feat(<scope>): <description> [spec:<spec>:<section>]`
8. If gate fails: stop, present diagnostic, ask user how to proceed
9. Mark task as done in the plan file (check the box)

**Parallel Mode (`--parallel`)**:
- Identify independent tasks (no dependency edges between them)
- Dispatch each to a subagent via the Agent tool
- Each subagent receives: task definition, spec section content, project setup instructions
- Collect results, verify all gates, commit sequentially

**Step 4: Completion**
- When all tasks done, invoke `canon-branch` skill
- If any tasks failed, present summary of what succeeded and what needs attention

**Progress Tracking:**
- Update the plan file in-place: `- [x] Task N: ...` as each task completes
- This provides a persistent record even if the session is interrupted

**ACs covered:** Section 5, all bullets

---

## Phase 3: Review + Completion

### Task 6: canon-reviewer agent
**Spec:** Section 6 | **Complexity:** M | **Dependencies:** None

**Files:**
- Create `agents/canon-reviewer/AGENT.md`

**What to do:**

```yaml
---
name: canon-reviewer
description: >
  Reviews code changes against spec acceptance criteria. Categorizes findings as
  Spec Gap, Spec Conflict, Quality Issue, or Suggestion. Use after implementing
  features or as part of canon-implement execution.
tools:
  - Read
  - Glob
  - Grep
  - Bash
  - mcp__canon__get_spec
  - mcp__canon__get_section
  - mcp__canon__search
---
```

Agent prompt template:

```markdown
# Spec-Aware Code Review

You are reviewing code changes against spec acceptance criteria.

## Inputs

- **Git diff**: {diff}
- **Spec sections**: {spec_sections_with_acs}
- **Project conventions**: {claude_md_content}

## Review Process

1. For each AC in the linked spec sections:
   - Search the diff for implementation evidence
   - Classify: Satisfied, Partially Satisfied, Not Addressed, or Conflicting

2. For code quality:
   - Check against project conventions (CLAUDE.md)
   - Identify bugs, security issues, performance problems

## Output Format

### Spec Compliance

| AC | Verdict | Evidence/Gap |
|----|---------|-------------|
| ... | Satisfied / Gap / Conflict | file:line or explanation |

### Code Quality

| Finding | Severity | Location | Detail |
|---------|----------|----------|--------|
| ... | Quality Issue / Suggestion | file:line | ... |

### Summary

- **Spec Gaps:** N (must fix before proceeding)
- **Spec Conflicts:** N (must fix before proceeding)
- **Quality Issues:** N (should fix)
- **Suggestions:** N (optional)
- **Verdict:** All ACs satisfied / N issues to resolve
```

Also update `canon-review` skill to offer dispatching this agent (add a section: "For deeper review, dispatch the canon-reviewer agent").

**ACs covered:** Section 6, all bullets

---

### Task 7: canon-branch skill
**Spec:** Section 7 | **Complexity:** M | **Dependencies:** Task 8 (verify gate)

**Files:**
- Create `skills/canon-branch/SKILL.md`

**What to do:**

```yaml
---
name: canon-branch
description: >
  Complete a development branch: verify specs, update statuses, and merge/PR/cleanup.
  Use when done with a feature branch or after canon-implement finishes.
allowed-tools:
  - Read
  - Write
  - Edit
  - Glob
  - Grep
  - Bash
  - mcp__canon__get_spec
  - mcp__canon__get_section
  - mcp__canon__update_section_status
  - mcp__canon__sync_spec_status
---
```

Skill steps:

**Step 1: Verify**
Run `canon verify` (or `canon verify --gate`) for all spec sections touched on this branch (identify from git log).

If verification fails, present the gaps and ask user to address them before completing.

**Step 2: Update Spec Statuses**
For sections where all ACs are realized, update status to `done`. Commit the spec status changes so they're included in the merge/PR.

**Step 3: Present Options**
```
Branch work complete. Choose an option:
  1. Merge to base branch (fast-forward if possible)
  2. Push and create PR
  3. Keep branch as-is (resume later)
  4. Discard branch and worktree
```

**Step 4: Execute Choice**

Option 1 (Merge):
- `git checkout <base>` → `git merge --ff-only <branch>` (fall back to merge commit)
- Clean up worktree: `git worktree remove <path>` → `git branch -d <branch>`

Option 2 (PR):
- `git push -u origin <branch>`
- Generate PR description from spec sections:
  - Title: from spec title + section
  - Body: "## Spec Coverage" section listing ACs satisfied with realization evidence
  - Body: "## Changes" section from git log
- Create PR via `gh pr create`
- Report PR URL

Option 3 (Keep):
- Report branch name and worktree path for later resumption

Option 4 (Discard):
- Confirm with user (destructive)
- `git worktree remove <path>` → `git branch -D <branch>`

**ACs covered:** Section 7, all bullets

---

### Task 8: Verification gate mode for canon-verify
**Spec:** Section 8 | **Complexity:** S | **Dependencies:** None

**Files:**
- Modify `skills/canon-verify/SKILL.md`

**What to do:**

Add a `--gate` mode section to the existing canon-verify skill. Insert after the existing Step 4.

New content:

```markdown
## Gate Mode

When invoked with `--gate` (or called from another Canon skill), verify acts as a
pass/fail gate rather than a report.

### Gate Checks

1. **AC Coverage** — every linked AC must have realization evidence
2. **Test Suite** — project tests must pass (`uv run pytest`, `npm test`, etc.)
3. **No Conflicts** — no ACs classified as "Conflicting"

### Gate Output

Pass:
```
✓ Gate passed: all ACs realized, tests pass, no conflicts
```

Fail:
```
✗ Gate failed:
  - 2 ACs lack realization evidence: [list]
  - Tests failing: [summary]
  - 1 AC conflict: [detail]
```

### When Called from Other Skills

Gate mode is the default when canon-verify is invoked by:
- `canon-implement` (after each task)
- `canon-branch` (before merge/PR)

Report mode remains the default for direct user invocation.
```

Also add `--gate` to the "Quick Check with CLI" section as an option:
```bash
canon verify --gate          # Pass/fail gate mode
canon verify --gate --section 2.1  # Gate a specific section
```

**ACs covered:** Section 8, all bullets

---

## Phase 4: Integration + Polish

### Task 9: External skill integration detection
**Spec:** Section 9 | **Complexity:** S | **Dependencies:** Task 5 (canon-implement)

**Files:**
- Modify `skills/canon-task/SKILL.md`
- Modify `skills/canon-implement/SKILL.md` (from Task 5)

**What to do:**

Add a short section to both `canon-task` and `canon-implement` SKILL.md files:

In canon-task, add before "## Workflow Tips":
```markdown
## Companion Skill Integration

Before implementing each AC, check if development discipline skills are available:

- **TDD available?** If a skill matching "test-driven" is in the session, suggest
  writing a failing test for the AC before implementing. This is recommended but
  not required — Canon doesn't enforce TDD, but it integrates well.
- **Debugging available?** If implementation fails and a skill matching "debugging"
  or "systematic-debugging" is in the session, suggest invoking it for root cause
  investigation before retrying.

Canon's spec context is available to any skill via the Canon MCP server — external
skills can call `mcp__canon__get_section` to understand what they're implementing.
```

In canon-implement, add a similar note in Step 3 (Execute Tasks).

**ACs covered:** Section 9, bullets 1-4

---

### Task 10: Plugin manifest and documentation updates
**Spec:** Section 9 | **Complexity:** S | **Dependencies:** Tasks 1-9

**Files:**
- Modify `.claude-plugin/plugin.json` (add hooks reference)
- Create or update `README.md` with integration documentation

**What to do:**

Update plugin.json to ensure the hooks directory is recognized (verify Claude Code's plugin hook discovery — hooks.json at plugin root or `.claude-plugin/hooks.json`).

Add a section to the plugin README:

```markdown
## Integration with External Plugins

Canon's spec context is available to any Claude Code skill via the Canon MCP server.
External plugins (like superpowers for TDD/debugging) can query spec context:

- `mcp__canon__get_spec` — load a full spec with all sections and ACs
- `mcp__canon__get_section` — load a specific section by ID
- `mcp__canon__search` — find specs relevant to current work

This means TDD skills can know *what* they're testing (the AC), debugging skills
can know *what should work* (the spec), and code review skills can check *spec
compliance* (not just code style).

### Recommended Companion Plugins

- **superpowers** — TDD, systematic debugging, verification discipline
```

**ACs covered:** Section 9, bullets 5-6

---

## Task Dependency Graph

```
Phase 1 (Foundation):
  Task 1 (hook) ──────────────────────────┐
  Task 2 (canon-meta) ────────────────────┤
  Task 3 (canon-worktree) ────────────────┤
                                          │
Phase 2 (Planning + Execution):          │
  Task 4 (enhanced canon-plan) ───────┐  │
  Task 5 (canon-implement) ◄──────────┤  │
       depends on: Task 3, Task 4     │  │
                                      │  │
Phase 3 (Review + Completion):        │  │
  Task 6 (canon-reviewer agent) ──────┤  │
  Task 7 (canon-branch) ◄────────────┤  │
       depends on: Task 8            │  │
  Task 8 (verify gate) ──────────────┤  │
                                      │  │
Phase 4 (Integration):               │  │
  Task 9 (external integration) ◄────┘  │
       depends on: Task 5               │
  Task 10 (manifest + docs) ◄───────────┘
       depends on: all above
```

## Summary

| Task | System | New/Modify | Complexity | Depends On |
|------|--------|-----------|------------|------------|
| 1 | SessionStart hook | New: hooks/hooks.json, hooks/session-start.sh | S | — |
| 2 | canon-meta skill | New: skills/canon-meta/SKILL.md | M | — |
| 3 | canon-worktree skill | New: skills/canon-worktree/SKILL.md | M | — |
| 4 | Enhanced canon-plan | Modify: skills/canon-plan/SKILL.md | M | — |
| 5 | canon-implement skill | New: skills/canon-implement/SKILL.md | L | 3, 4 |
| 6 | canon-reviewer agent | New: agents/canon-reviewer/AGENT.md | M | — |
| 7 | canon-branch skill | New: skills/canon-branch/SKILL.md | M | 8 |
| 8 | Verify gate mode | Modify: skills/canon-verify/SKILL.md | S | — |
| 9 | External integration | Modify: skills/canon-task/SKILL.md, canon-implement | S | 5 |
| 10 | Manifest + docs | Modify: plugin.json, README.md | S | all |

**Total: 6 new files, 4 modified files, 1 agent, 4 new skills, 1 hook.**
