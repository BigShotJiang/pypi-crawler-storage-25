# Implementation Plan: Plugin Product Polish — Phase C (Discovery Surfaces)

**Spec:** `docs/specs/plugin-product-polish.md`
**Sections covered:** §5 Slash Commands, §6 Statusline & Output Style
**Dependencies:** Phase B complete (commit `081f56cf`)
**Setup commands:** none

## Critical finding (resolved before planning)

Looked up Claude Code's plugin extension surfaces:
- **Slash commands**: `plugin/commands/*.md`, auto-discovered, frontmatter supports `description`, `argument-hint`, `allowed-tools`, `disable-model-invocation`, `user-invocable`. Body becomes the prompt. ✓ ships as planned.
- **Output styles**: `plugin/output-styles/*.md`, auto-discovered, selected via `/config` (not a slash command). Frontmatter: `name`, `description`, `keep-coding-instructions`. ✓ ships as planned.
- **Statusline**: **NOT supported in plugins.** It's user-level only, configured via `~/.claude/settings.json` `statusLine` field pointing to a script. Plugins cannot auto-register a statusline.

**Statusline workaround:** Ship a reference script at `plugin/scripts/canon-statusline.sh` and document in README how users wire it into `~/.claude/settings.json`. The script reads `canon status --json` and emits a single line. Same product value, manual wire-up.

This means §6 ACs about "registering in plugin.json" cannot be satisfied as written; the spec needs a note about the platform limitation.

---

## Self-Review

- [x] Every task has exact file paths
- [x] Every Phase C AC is covered by at least one task (or marked blocked with rationale)
- [x] Dependencies between tasks identified
- [x] No placeholder language
- [x] Statusline platform limitation surfaced before any code

---

## Task 1: Add `--json` flag to `canon status` (latent bug fix)

**Why first:** `session-start.sh:66` already calls `canon status --json` but the flag doesn't exist (silently swallowed by `2>/dev/null`). Phase C's reference statusline script needs the same data, so adding the flag now closes both gaps.

**Complexity:** S | **Files:**
- `src/canon/cli/status_cmd.py` — add `--json` argparse flag and JSON emission path
- `src/canon/cli/__init__.py` — pass `json_output` through to `run_status`

**What to add:** A `--json` flag that emits `{total_specs, total_sections, total_ac, done_ac, overall_pct, in_progress_specs, sections_in_progress, open_acs}` and skips the table render. Reuses the existing aggregation loop.

**Acceptance check:**
```bash
uv run canon status --json | jq -r '.total_specs, .overall_pct'
# → integer, percentage string
```

---

## Task 2: Create 6 slash commands

**Complexity:** S × 6 (mechanical) | **Files (all new):**
- `plugin/commands/canon.md`
- `plugin/commands/canon-context.md`
- `plugin/commands/canon-plan.md`
- `plugin/commands/canon-task.md`
- `plugin/commands/canon-verify.md`
- `plugin/commands/canon-status.md`

**Pattern:** Each is a thin wrapper. Frontmatter has `name`, `description`, optional `argument-hint`. Body tells Claude to invoke the corresponding skill via the Skill tool.

**Why thin wrappers:** Source of truth lives in `plugin/skills/canon-*/SKILL.md`. Commands give users a `/` autocomplete entry but always delegate. No content duplication.

**Acceptance check:**
```bash
ls plugin/commands/*.md | wc -l  # → 6
for f in plugin/commands/*.md; do head -10 "$f"; done | grep -c '^name:'  # → 6
```

---

## Task 3: Create Canon output style

**Complexity:** M | **Files:**
- `plugin/output-styles/canon.md` (new)

**What to write:** Frontmatter (`name: canon`, `description`, `keep-coding-instructions: true`) + body that instructs Claude on Canon-specific formatting:
- AC references format: `[spec:slug:section]`
- Section status changes: emit `<!-- canon:system:N status:X -->`
- Realization evidence: emit `<!-- canon:realized-in:source file:path:lines -->`
- Coverage tables: 5-column format matching `canon status`
- When showing spec content, prefer collapsing to acceptance criteria first

**Why `keep-coding-instructions: true`:** Canon work is software engineering — we want all of Claude Code's default coding guidance, plus Canon's spec-specific overlay.

---

## Task 4: Reference statusline script

**Complexity:** S | **Files:**
- `plugin/scripts/canon-statusline.sh` (new, executable)

**What it does:**
```bash
#!/usr/bin/env bash
# Emit a one-line Canon status for the active project.
# Reads stdin (Claude session JSON) but ignores it; reads CWD instead.
# Wire into ~/.claude/settings.json statusLine field.
set -euo pipefail
cat >/dev/null  # consume stdin
project_dir="${CLAUDE_PROJECT_DIR:-$PWD}"
[ -f "$project_dir/CANON.yaml" ] || { echo ""; exit 0; }
if ! command -v canon >/dev/null 2>&1; then
  echo "canon: cli not found"
  exit 0
fi
stats=$(cd "$project_dir" && canon status --json 2>/dev/null || echo '{}')
if command -v jq >/dev/null 2>&1; then
  specs=$(echo "$stats" | jq -r '.total_specs // 0')
  pct=$(echo "$stats" | jq -r '.overall_pct // "—"')
  in_progress=$(echo "$stats" | jq -r '.in_progress_specs // 0')
  open_acs=$(echo "$stats" | jq -r '.open_acs // 0')
  echo "canon: $specs specs · $pct · $in_progress in_progress · $open_acs open ACs"
else
  echo "canon: stats unavailable (jq missing)"
fi
```

**Wire-up documentation** (added to README in Task 6): copy the script to `~/.claude/canon-statusline.sh`, `chmod +x`, and add to `~/.claude/settings.json`:
```json
{ "statusLine": { "type": "command", "command": "~/.claude/canon-statusline.sh" } }
```

---

## Task 5: Update plugin/README.md

**Complexity:** S | **Files:**
- `plugin/README.md`

**What to add:** Three new sections after "Multi-Agent Setup":
1. **Slash Commands** — table listing the 6 commands
2. **Output Style** — one paragraph: "select Canon output style via `/config` for spec-flavored formatting"
3. **Statusline (optional)** — wire-up instructions for `canon-statusline.sh`

---

## Task 6: Tests for Phase C surfaces

**Complexity:** M | **Files:**
- `tests/test_cli/test_skills_content.py` — add `TestCommandFiles`, `TestOutputStyles`, `TestStatuslineScript`
- `tests/test_cli/test_status_json.py` (new) — test `canon status --json` shape

**What to test:**
- All 6 expected command files exist with valid frontmatter (`name`, `description`)
- `canon` command body delegates to a Canon skill
- Output style file exists, has frontmatter with `name: canon`
- Statusline script exists, is executable, runs without error, emits something containing `canon:` when invoked in this repo
- `canon status --json` emits valid JSON with the expected keys

---

## Task 7: Update spec §5 and §6 with realization comments and statusline note

**Complexity:** S | **Files:**
- `docs/specs/plugin-product-polish.md` — mark §5 done, §6 partial with platform-limitation note

**What to add to §6:** A platform-limitation block before the ACs:
```
> **Platform limitation (2026-04-11):** Claude Code's plugin system does not
> support shipping a statusline script directly from a plugin. Statuslines
> are user-level only via `~/.claude/settings.json statusLine`. Canon ships
> a reference script at `plugin/scripts/canon-statusline.sh` that users can
> wire into their settings manually; see `plugin/README.md` for instructions.
```

Mark statusline ACs as "deferred — blocked by Claude Code limitation". Mark output style ACs as done.

---

## Task Dependency Graph

```
Task 1 (canon status --json)  ──────┬──── needed by Task 4 + Task 6
                                    │
Task 2 (slash commands)       ──────┤  independent
Task 3 (output style)         ──────┤  independent
Task 4 (statusline script)    ──────┘  needs Task 1
                                    │
Task 5 (README update)        ──── needs Tasks 2, 3, 4
Task 6 (tests)                ──── needs Tasks 1, 2, 3, 4
Task 7 (spec update)          ──── after everything
```

**Suggested order:** 1 → [2, 3, 4 in parallel] → 5 → 6 → 7

---

## Verification Plan

```bash
# Sanity
uv run canon status --json | jq .
ls plugin/commands/*.md
ls plugin/output-styles/*.md
test -x plugin/scripts/canon-statusline.sh && echo executable

# Test suite
uv run pytest tests/test_cli/test_skills_content.py tests/test_cli/test_ide_config.py tests/test_cli/test_status_json.py -v

# Statusline smoke test
echo '{}' | bash plugin/scripts/canon-statusline.sh
# → "canon: 44 specs · 53% · 12 in_progress · 902 open ACs"  (or similar)
```

---

## Out of Scope for Phase C

- canon-reviewer auto-dispatch from canon-implement (Phase D, §7)
- E2E integration test for canon-implement (Phase D, §8)
- Companion-skill opportunism on task failure (Phase D, §9)
- Plugin-side statusline integration (waiting on Claude Code platform support)
- Auto-installing the reference statusline script (would require new `canon` CLI command and is out of scope for Phase C)
