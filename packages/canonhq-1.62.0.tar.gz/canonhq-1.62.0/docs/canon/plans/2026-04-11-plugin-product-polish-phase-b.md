# Implementation Plan: Plugin Product Polish — Phase B (Hook Quality)

**Spec:** `docs/specs/plugin-product-polish.md`
**Sections covered:** §3 Hook YAML Parsing, §4 SessionStart Skill Enforcement
**Dependencies:** Phase A complete (commit `948fbd6b`); `IdeConfig` already shipped via `ide-integration.md` §2 in `src/canon/config/parse.py:156-159`
**Setup commands:** `uv sync --extra dev`
**Estimated complexity:** ~1-2 days (4× S, 3× M)

This phase has two related goals:

1. **§3** — Replace fragile `grep` YAML parsing in the three hook scripts with a single CLI subcommand (`canon ide-config --json`) that uses the existing `IdeConfig` Pydantic model. Hooks then `jq` against a known JSON shape.
2. **§4** — Make the SessionStart hook actually enforce skill discipline by injecting the `canon-meta` rationalization rules inline (not just listing skill names).

The §3 work is the precondition for §4 because the SessionStart hook needs to read `auto_context.on_session_start` reliably to decide whether to emit the inline rules.

---

## Self-Review Checklist

- [x] Every task has exact file paths
- [x] Every AC in §3 and §4 is covered by at least one task
- [x] Dependencies between tasks are identified
- [x] No placeholder language ("TBD", "implement later")
- [x] Open questions are flagged before tasks that depend on them
- [x] Plan respects the existing CLI registration pattern (`register(subparsers)` + central dispatch in `cli/__init__.py`)
- [x] Plan respects the existing `load_local_config` helper rather than reimplementing CANON.yaml loading

---

## Task 1: Add `canon ide-config` CLI subcommand

**Spec ref:** `plugin-product-polish.md` §3 — ACs: "`canon ide-config --json` subcommand added", "Subcommand exits 0 even when CANON.yaml is missing", "Subcommand exits 0 even when CANON.yaml has no `ide:` section", "Subcommand reuses `IdeConfig` from `src/canon/config/parse.py`"

**Complexity:** M | **Dependencies:** None

**Files to create:**
- `src/canon/cli/ide_config.py` (new, ~50 lines)

**Files to modify:**
- `src/canon/cli/__init__.py` — register the new subcommand and wire dispatch

**What to create:**

`src/canon/cli/ide_config.py`:
```python
"""canon ide-config — emit IDE config as JSON for hook scripts."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from ._local import load_local_config


def register(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    parser = subparsers.add_parser(
        "ide-config",
        help="Emit IDE config (auto_context, auto_verify, ai_exposure) as JSON for hooks",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit JSON to stdout (default and only output mode today)",
    )


def run_ide_config(*, root: Path | None = None) -> None:
    """Emit the resolved ide: section from CANON.yaml as JSON.

    Always exits 0 — missing CANON.yaml or missing ide: section both produce
    a JSON document with default values, so hook scripts never need to handle
    error cases. Errors only occur on truly malformed YAML.
    """
    try:
        config = load_local_config(root or Path.cwd())
    except Exception as err:
        # Truly malformed YAML — emit defaults to stdout, warning to stderr
        print(f"warning: failed to load CANON.yaml ({err}); using defaults", file=sys.stderr)
        from canon.config.parse import DEFAULT_CONFIG

        config = DEFAULT_CONFIG

    payload = config.ide.model_dump()
    print(json.dumps(payload, indent=2))
```

**What to modify in `src/canon/cli/__init__.py`:**

1. Add the import alongside the others (alphabetically near `audit_register`):
```python
from .ide_config import register as ide_config_register
```

2. Call the registrar in the registration block:
```python
ide_config_register(subparsers)
```

3. Add the dispatch case (alongside the others, before the final `else`):
```python
elif args.command == "ide-config":
    from .ide_config import run_ide_config

    run_ide_config()
```

**JSON shape produced:**
```json
{
  "auto_context": {
    "enabled": true,
    "on_session_start": true,
    "on_prompt": true,
    "max_specs": 5
  },
  "auto_verify": {
    "enabled": true,
    "on_stop": true,
    "on_commit": false,
    "confidence": "medium"
  },
  "ai_exposure": {
    "default": "full",
    "restricted_tags": []
  }
}
```

**Why this shape:** matches `IdeConfig.model_dump()` directly. Hooks never need to know the Python class structure — they read JSON keys.

**Acceptance check:**
```bash
uv run canon ide-config --json
# → JSON document with the three top-level keys above

uv run canon ide-config --json | jq -r '.auto_context.on_session_start'
# → true (or false, depending on CANON.yaml)

# Test against missing CANON.yaml:
( cd /tmp && uv run --project /home/ng/Code/canon-private/.claude/worktrees/claude-plugin-enhancements canon ide-config --json )
# → defaults JSON, exit 0, no error
```

---

## Task 2: Tests for `canon ide-config`

**Spec ref:** `plugin-product-polish.md` §3 — AC: "Hook tests cover: missing CANON.yaml, missing `ide:`, fully populated `ide:`, and `enabled: false` for each setting"

**Complexity:** S | **Dependencies:** Task 1

**Files to create:**
- `tests/test_cli/test_ide_config.py` (new)

**What to test:**

```python
"""Tests for `canon ide-config` CLI subcommand."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest


def run_cmd(cwd: Path) -> tuple[int, str, str]:
    proc = subprocess.run(
        ["uv", "run", "canon", "ide-config", "--json"],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    return proc.returncode, proc.stdout, proc.stderr


class TestIdeConfigDefaults:
    def test_missing_canon_yaml_returns_defaults(self, tmp_path: Path):
        rc, out, err = run_cmd(tmp_path)
        assert rc == 0
        data = json.loads(out)
        assert data["auto_context"]["enabled"] is True
        assert data["auto_context"]["on_session_start"] is True
        assert data["auto_verify"]["enabled"] is True
        assert data["ai_exposure"]["default"] == "full"

    def test_empty_canon_yaml_returns_defaults(self, tmp_path: Path):
        (tmp_path / "CANON.yaml").write_text("")
        rc, out, _ = run_cmd(tmp_path)
        assert rc == 0
        data = json.loads(out)
        assert data["auto_context"]["max_specs"] == 5

    def test_missing_ide_section_returns_defaults(self, tmp_path: Path):
        (tmp_path / "CANON.yaml").write_text(
            "team: alpha\nspecs:\n  doc_paths: [docs/specs/*.md]\n"
        )
        rc, out, _ = run_cmd(tmp_path)
        assert rc == 0
        data = json.loads(out)
        assert data["auto_context"]["on_session_start"] is True


class TestIdeConfigPopulated:
    def test_full_ide_section(self, tmp_path: Path):
        (tmp_path / "CANON.yaml").write_text("""\
ide:
  auto_context:
    enabled: true
    on_session_start: false
    on_prompt: true
    max_specs: 3
  auto_verify:
    enabled: false
    on_stop: false
    on_commit: false
  ai_exposure:
    default: metadata
    restricted_tags: [security, pricing]
""")
        rc, out, _ = run_cmd(tmp_path)
        assert rc == 0
        data = json.loads(out)
        assert data["auto_context"]["on_session_start"] is False
        assert data["auto_context"]["max_specs"] == 3
        assert data["auto_verify"]["enabled"] is False
        assert data["ai_exposure"]["default"] == "metadata"
        assert "security" in data["ai_exposure"]["restricted_tags"]


class TestIdeConfigErrors:
    def test_malformed_yaml_emits_warning_to_stderr_and_defaults(self, tmp_path: Path):
        (tmp_path / "CANON.yaml").write_text("ide: [this is not valid yaml")
        rc, out, err = run_cmd(tmp_path)
        # Either parser tolerates it (rc 0, defaults) or emits warning + defaults
        assert rc == 0
        data = json.loads(out)
        assert "auto_context" in data
```

**Acceptance check:**
```bash
uv run pytest tests/test_cli/test_ide_config.py -v
# → all tests pass
```

**Note:** subprocess-based tests are slower than direct function tests but
they're the most accurate reflection of how hooks will actually invoke the CLI.

---

## Task 3: Refactor `session-start.sh` to use `canon ide-config`

**Spec ref:** `plugin-product-polish.md` §3 — ACs: "`plugin/hooks/session-start.sh` replaces its `grep -q 'on_session_start'` check with a `canon ide-config --json | jq` lookup", "If `canon` CLI is not on PATH, hooks fall back to current grep behavior and emit a one-line warning to stderr"

**Complexity:** M | **Dependencies:** Task 1

**Files to modify:**
- `plugin/hooks/session-start.sh`

**What to change:**

Replace the current naive grep check (lines 19-23 of session-start.sh):
```bash
# Check if on_session_start is disabled in CANON.yaml
# Naive grep — may match outside ide section; acceptable tradeoff for hook speed.
if grep -q 'on_session_start:.*false' "$CANON_YAML" 2>/dev/null; then
  exit 0
fi
```

With a CLI-based check that gracefully falls back to the original grep:

```bash
# Read ide config via canon CLI; fall back to grep on missing CLI.
read_ide_config() {
  if command -v canon >/dev/null 2>&1; then
    (cd "$CLAUDE_PROJECT_DIR" && canon ide-config --json 2>/dev/null) || echo '{}'
  else
    echo "warning: canon CLI not on PATH; falling back to grep" >&2
    echo '{}'
  fi
}

ide_config=$(read_ide_config)

# Check on_session_start (default: true)
on_session_start=$(echo "$ide_config" | jq -r '.auto_context.on_session_start // true' 2>/dev/null)
if [ "$on_session_start" = "false" ]; then
  # Fall back to grep only if jq returned nothing (jq missing or bad JSON)
  if ! command -v jq >/dev/null 2>&1; then
    if grep -q 'on_session_start:.*false' "$CANON_YAML" 2>/dev/null; then
      exit 0
    fi
  else
    exit 0
  fi
fi
```

**Why the double fallback:**
1. If `canon` is missing → use legacy grep (degraded but functional)
2. If `jq` is missing → use legacy grep (most systems have jq, but cheap insurance)
3. If `canon` exists and `jq` exists → use the structured path

**Performance check:**

The original script's target was <2 seconds. `canon ide-config --json` should complete in well under 100ms (it's just YAML parsing + JSON dumping). Add a sanity check at the end of the task:

```bash
time bash plugin/hooks/session-start.sh </dev/null >/dev/null
# → real time well under 2s (target: under 500ms in practice)
```

**Acceptance check:**
- Hook still emits the skill discovery message when CANON.yaml exists with `auto_context.on_session_start: true` (default)
- Hook exits silently when CANON.yaml has `auto_context.on_session_start: false`
- Hook emits a warning to stderr (still exits 0) when `canon` CLI is missing

---

## Task 4: Refactor `stop.sh` to use `canon ide-config`

**Spec ref:** `plugin-product-polish.md` §3 — AC: "`plugin/hooks/stop.sh` replaces its `grep -q 'on_stop'` check the same way"

**Complexity:** S | **Dependencies:** Task 1, Task 3 (reuse the same `read_ide_config` helper pattern)

**Files to modify:**
- `plugin/hooks/stop.sh`

**What to change:**

Replace lines 13-17 of stop.sh:
```bash
# Check if on_stop is disabled
# Naive grep — may match outside ide section; acceptable tradeoff for hook speed.
if grep -q 'on_stop:.*false' "$CANON_YAML" 2>/dev/null; then
  exit 0
fi
```

With:
```bash
# Read ide config via canon CLI; fall back to grep on missing CLI.
read_ide_config() {
  if command -v canon >/dev/null 2>&1; then
    (cd "$CLAUDE_PROJECT_DIR" && canon ide-config --json 2>/dev/null) || echo '{}'
  else
    echo '{}'
  fi
}

ide_config=$(read_ide_config)
on_stop=$(echo "$ide_config" | jq -r '.auto_verify.on_stop // true' 2>/dev/null)
if [ "$on_stop" = "false" ]; then
  if command -v jq >/dev/null 2>&1; then
    exit 0
  elif grep -q 'on_stop:.*false' "$CANON_YAML" 2>/dev/null; then
    exit 0
  fi
fi
```

**Note on duplication:** The `read_ide_config` helper is repeated across hooks. We could factor it into `plugin/hooks/_lib.sh` but with only three hooks the complexity isn't worth it. Revisit in Phase D if a fourth hook is added.

**Acceptance check:**
- Hook still suggests verification on file changes (default behavior)
- Hook exits silently with `auto_verify.on_stop: false` in CANON.yaml

---

## Task 5: Refactor `pre-commit.sh` to use `canon ide-config`

**Spec ref:** `plugin-product-polish.md` §3 — AC: "`plugin/hooks/pre-commit.sh` replaces its `grep -A 20 '^ide:'` check the same way"

**Complexity:** S | **Dependencies:** Task 1

**Files to modify:**
- `plugin/hooks/pre-commit.sh`

**What to change:**

Replace lines 24-30 of pre-commit.sh:
```bash
# Check if on_commit is enabled (default: false).
# When false: advisory only. When true: requires user acknowledgment before commit.
# Scoped to ide: section to avoid matching on_commit in other YAML sections.
on_commit_enabled="false"
if grep -A 20 '^ide:' "$CANON_YAML" 2>/dev/null | grep -q 'on_commit:.*true'; then
  on_commit_enabled="true"
fi
```

With:
```bash
# Check on_commit via canon CLI; fall back to grep.
on_commit_enabled="false"
if command -v canon >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
  ide_config=$(cd "$CLAUDE_PROJECT_DIR" && canon ide-config --json 2>/dev/null || echo '{}')
  if [ "$(echo "$ide_config" | jq -r '.auto_verify.on_commit // false')" = "true" ]; then
    on_commit_enabled="true"
  fi
elif grep -A 20 '^ide:' "$CANON_YAML" 2>/dev/null | grep -q 'on_commit:.*true'; then
  on_commit_enabled="true"
fi
```

**Why this is the smallest change:** the existing pre-commit.sh already had
the most accurate grep (scoped with `-A 20 '^ide:'`), so the structured path
is mainly insurance against future YAML restructuring.

**Acceptance check:**
- Default (no `ide.auto_verify.on_commit`): hook is advisory only
- Explicit `on_commit: true` in CANON.yaml: hook requests acknowledgment
- Both with and without `canon` CLI on PATH

---

## Task 6: SessionStart inline canon-meta injection

**Spec ref:** `plugin-product-polish.md` §4 — ACs: "SessionStart hook injects the canon-meta rationalization table inline (not just the skill list)", "Inline content stays under 1.5 KB", "Injected content includes the four Iron Laws style rules in code-block form", "When `docs/specs/` is empty, the inline rules block is omitted"

**Complexity:** M | **Dependencies:** Task 3 (the rewritten session-start.sh is the file we modify)

**Files to modify:**
- `plugin/hooks/session-start.sh`

**What to add:**

Insert a new "Iron Laws" block in the `has_specs=true` branch (currently lines 60-78 in the post-Task-3 version of session-start.sh). The block should appear **before** the skill list so the user reads the rules first.

Add this content to the `msg` variable when `has_specs=true`:

```bash
msg="$msg

Canon Iron Laws (read before any code change):

  1. Before any non-trivial change, run /canon:context first to load the
     relevant spec. 30 seconds of context saves 30 minutes of rework.

  2. If a spec doesn't exist for what you're building, create one with
     /canon:new before writing code. A 5-minute spec prevents drift.

  3. After implementing an AC, record realization evidence with
     /canon:verify. \"I'll update the spec later\" means never.

  4. Before claiming work is done, run /canon:verify --gate. Tests passing
     is not the same as ACs satisfied.

If you find yourself thinking any of these, STOP and run the right Canon skill:
  - \"This is just a quick fix\"          → /canon:context
  - \"The spec doesn't exist yet\"        → /canon:new
  - \"I'll update the spec later\"        → /canon:verify
  - \"I know what to do, I don't need the spec\" → /canon:context
"
```

Then **after** the rules block, keep the existing skill list (lines 60-78) unchanged.

**Byte budget verification:**

The existing `has_specs=true` block emits ~1.1 KB of skill list. The Iron Laws block above is ~700 bytes. Combined: ~1.8 KB. The spec AC says "under 1.5 KB" for the inline rules block (not the total). Verify with:

```bash
bash plugin/hooks/session-start.sh </dev/null | wc -c
# → should be under 2.5 KB total (skill list ~1.1KB + iron laws ~0.7KB + framing ~0.3KB)
```

If the total exceeds 2 KB and feels noisy, trim the rationalization block to just the four Iron Laws and drop the "If you find yourself thinking" lines.

**Empty-specs branch unchanged:**

The `else` branch (no specs found) at lines 79-85 should NOT include the Iron Laws — they only make sense when there are specs to apply them to.

**Acceptance check:**
```bash
# In a Canon repo with specs:
bash plugin/hooks/session-start.sh </dev/null | grep -c "Iron Law"
# → 1 (header line)
bash plugin/hooks/session-start.sh </dev/null | grep -c "/canon:"
# → multiple (both skill list and iron laws reference skills)
bash plugin/hooks/session-start.sh </dev/null | wc -c
# → under 2500 bytes

# In a no-specs directory:
( mkdir -p /tmp/notcanon && cd /tmp/notcanon && touch CANON.yaml && \
  CLAUDE_PROJECT_DIR=/tmp/notcanon bash plugin/hooks/session-start.sh </dev/null )
# → emits "No specs found yet" message, NO Iron Laws block
```

---

## Task 7: Hook tests

**Spec ref:** `plugin-product-polish.md` §3 — AC: "Each refactored hook still completes in under 2 seconds"; §4 — AC: "Test verifies the injected output is valid markdown and under the byte cap on a typical Canon repo"

**Complexity:** M | **Dependencies:** Tasks 3, 4, 5, 6

**Files to modify:**
- `tests/test_cli/test_skills_content.py` — add hook output tests under `TestHookFiles`

**What to add to `TestHookFiles`:**

```python
import subprocess
import os
import time

class TestHookOutput:
    """Test the actual output of hook scripts under realistic conditions."""

    @pytest.fixture
    def canon_project(self, tmp_path: Path) -> Path:
        """Create a minimal Canon project with one spec."""
        (tmp_path / "CANON.yaml").write_text("specs:\n  doc_paths: [docs/specs/*.md]\n")
        specs_dir = tmp_path / "docs" / "specs"
        specs_dir.mkdir(parents=True)
        (specs_dir / "example.md").write_text(
            "---\ntitle: Example\nstatus: draft\n---\n# Example\n## 1. Background\n"
        )
        return tmp_path

    @pytest.fixture
    def empty_project(self, tmp_path: Path) -> Path:
        """Create a Canon project with CANON.yaml but no specs."""
        (tmp_path / "CANON.yaml").write_text("specs:\n  doc_paths: [docs/specs/*.md]\n")
        return tmp_path

    def _run_hook(self, hook: str, cwd: Path) -> tuple[int, str, str, float]:
        env = os.environ.copy()
        env["CLAUDE_PROJECT_DIR"] = str(cwd)
        env["CLAUDE_ENV_FILE"] = str(cwd / ".env-hook")
        start = time.monotonic()
        proc = subprocess.run(
            ["bash", str(HOOKS_DIR / hook)],
            env=env,
            cwd=cwd,
            capture_output=True,
            text=True,
            input="",
            timeout=5,
        )
        elapsed = time.monotonic() - start
        return proc.returncode, proc.stdout, proc.stderr, elapsed

    def test_session_start_under_2s(self, canon_project: Path):
        rc, _, _, elapsed = self._run_hook("session-start.sh", canon_project)
        assert rc == 0
        assert elapsed < 2.0, f"session-start.sh took {elapsed:.2f}s"

    def test_session_start_emits_iron_laws_with_specs(self, canon_project: Path):
        rc, out, _, _ = self._run_hook("session-start.sh", canon_project)
        assert rc == 0
        assert "Iron Law" in out
        assert "/canon:context" in out
        assert "/canon:verify" in out

    def test_session_start_no_iron_laws_without_specs(self, empty_project: Path):
        rc, out, _, _ = self._run_hook("session-start.sh", empty_project)
        assert rc == 0
        assert "Iron Law" not in out
        assert "No specs found" in out or "no specs" in out.lower()

    def test_session_start_under_byte_cap(self, canon_project: Path):
        rc, out, _, _ = self._run_hook("session-start.sh", canon_project)
        assert rc == 0
        assert len(out.encode()) < 2500, f"output is {len(out.encode())} bytes"

    def test_stop_under_2s(self, canon_project: Path):
        rc, _, _, elapsed = self._run_hook("stop.sh", canon_project)
        # stop.sh may exit 0 with no output if no git changes; that's fine
        assert elapsed < 2.0, f"stop.sh took {elapsed:.2f}s"
```

**Notes on the tests:**
- `pre-commit.sh` is harder to test in isolation because it expects JSON-formatted tool input on stdin and a real git repo with staged files. Skip subprocess testing for it; the JSON-shape test in Task 2 is the main coverage.
- `session-start.sh` uses `command -v canon` — in CI, the test environment must have `uv run canon` on PATH. If this is flaky, the fixture can write a fake `canon` shim that emits the expected JSON.

**Acceptance check:**
```bash
uv run pytest tests/test_cli/test_skills_content.py::TestHookOutput -v
# → all tests pass
```

---

## Task Dependency Graph

```
Task 1 (canon ide-config CLI)         ──┬─────────────────────┐
Task 2 (test_ide_config.py)           ──┘                     │
                                                              ▼
Task 3 (session-start.sh refactor)    ←───────────────── needs Task 1
Task 4 (stop.sh refactor)             ←───────────────── needs Task 1
Task 5 (pre-commit.sh refactor)       ←───────────────── needs Task 1
                                                              ▼
Task 6 (SessionStart Iron Laws)       ←───────────────── needs Task 3
                                                              ▼
Task 7 (hook output tests)            ←──────── needs Tasks 3, 4, 5, 6
```

**Suggested order:** 1 → 2 → [3, 4, 5 in parallel] → 6 → 7
**Sequential safe order:** 1 → 2 → 3 → 4 → 5 → 6 → 7

Tasks 3, 4, 5 modify different files, so they can run in parallel.

---

## Verification Plan

After all 7 tasks:

1. **CLI sanity:**
   ```bash
   uv run canon ide-config --json | jq .
   # → valid JSON with three top-level keys
   ```

2. **Hook output sanity:**
   ```bash
   CLAUDE_PROJECT_DIR=$PWD bash plugin/hooks/session-start.sh </dev/null
   # → skill list + Iron Laws block
   CLAUDE_PROJECT_DIR=$PWD bash plugin/hooks/stop.sh </dev/null
   # → either empty or "you modified spec files..."
   ```

3. **Hook performance:**
   ```bash
   time CLAUDE_PROJECT_DIR=$PWD bash plugin/hooks/session-start.sh </dev/null >/dev/null
   # → real time under 2s (target: under 500ms)
   ```

4. **Test suite:**
   ```bash
   uv run pytest tests/test_cli/test_ide_config.py tests/test_cli/test_skills_content.py -v
   # → all pass
   ```

5. **Spec realization:**
   Add `<!-- canon:realized-in:phase-b ... -->` markers to `plugin-product-polish.md` §3 and §4 ACs as part of the commit. Mark §3 and §4 as `done`.

---

## Commit Strategy

One commit at the end of Phase B:

```
feat(plugin): structured hook config + Iron Laws SessionStart (plugin-product-polish §3, §4)

Phase B of the plugin product polish workstream. Replaces fragile grep-based
YAML parsing in the hook scripts with a single canon ide-config --json
subcommand backed by the existing IdeConfig Pydantic model. SessionStart now
injects the canon-meta rationalization rules inline so skill discipline
activates without a separate skill invocation.

- Add canon ide-config CLI subcommand emitting IdeConfig as JSON
- Refactor session-start.sh, stop.sh, pre-commit.sh to read structured config
  via canon ide-config --json | jq, with grep fallback if canon CLI is missing
- Add Iron Laws block to SessionStart output (only when docs/specs/ is non-empty)
- Add subprocess tests covering ide-config defaults, populated config, and
  hook output (Iron Laws, byte budget, performance)
- Mark plugin-product-polish §3 and §4 as done with realization comments
```

---

## Out of Scope for Phase B

These belong to Phase C/D:

- Slash commands (`plugin/commands/`) — Phase C, §5
- Statusline + output style — Phase C, §6
- canon-reviewer auto-dispatch — Phase D, §7
- E2E integration test — Phase D, §8
- Companion-skill opportunism — Phase D, §9
- Refactoring `read_ide_config` into a shared `plugin/hooks/_lib.sh` — Phase D or later

---

## Open Questions Before Starting

1. **`jq` as a hard dependency** — the refactored hooks rely on `jq` being on
   PATH. Most Linux/macOS dev environments have it, but it's not guaranteed.
   The plan keeps grep as a fallback, so this is not blocking, but worth
   confirming whether we want to document `jq` as a recommended dependency.

2. **Tone of the Iron Laws** — the proposed wording is direct/imperative
   ("STOP", "is not the same as"). Memory note #4174 captured the
   superpowers Iron Laws as aggressive; the original `superpowers-parity`
   spec §11 asked whether that tone fits Canon's brand. The Task 6 wording
   is moderate. Confirm before Task 6 if you want it softer.

3. **Subprocess tests vs unit tests** — Task 7 uses subprocess to run real
   hook scripts. This is slow (~1-2s per test) but accurate. Alternative is
   to refactor hooks into Python and unit-test them, which is a much bigger
   change. Subprocess is the right call for Phase B; revisit later if test
   suite gets slow.
