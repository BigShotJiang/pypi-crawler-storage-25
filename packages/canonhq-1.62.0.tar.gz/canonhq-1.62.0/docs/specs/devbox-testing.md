---
title: "Devbox-Based Testing & Adoption Lifecycle Validation"
status: in_progress
owner: ng
team: canon
ticket_project: canonhq/canon-private
created: 2026-04-24
updated: 2026-04-24
tags: [testing, devbox, ci, integration, e2e, infrastructure, docker]
supersedes: [enhanced-platform-testing, app-integration-test-enhancements]
---

# Devbox-Based Testing & Adoption Lifecycle Validation

Establish a reproducible, scenario-driven testing ecosystem that validates Canon across its entire adoption lifecycle — from first install through mature multi-adapter deployments — using Devbox for environment reproducibility, Docker Compose for service orchestration, and scenario fixtures for lifecycle stage simulation.

## 1. Background

<!-- canon:system:1 status:done -->

Canon has 1,800+ unit tests with strong module-level coverage and 60+ integration tests that hit the real FastAPI app. However, all testing happens *within* the Canon repo against its current state. There is no mechanism to:

- Test a fresh `pip install canon` and verify the CLI works
- Simulate an empty repo running `canon setup` for the first time
- Validate different CANON.yaml configurations against real (or mock) ticket systems
- Test the full adoption lifecycle from initialization through mature spec management
- Reproduce the exact development environment across machines and CI runners

### What this spec supersedes

- **`enhanced-platform-testing.md`** (draft) — config matrix testing, auth integration, Helm rendering, Docker smoke tests, OSS validation, DB migrations. All absorbed here.
- **`app-integration-test-enhancements.md`** (in_progress) — web app route integration tests, admin panel tests, E2E user journeys, error resilience. All absorbed here.
- **`integration-testing.md`** (done) — webhook + GitHub client integration tests. Remains as-is; this spec builds on top of it.

### Gap analysis

| Area | Current State | Risk |
|------|-------------|------|
| **Reproducible dev environment** | No devbox/nix; relies on developer-local Python + uv | "Works on my machine" failures, CI drift |
| **Package install validation** | Not tested | Broken releases ship (see PyPI 400 incident) |
| **Fresh repo experience** | Not tested | Empty-state bugs hit users first |
| **Linear adapter** | No dedicated tests | Sync regressions invisible |
| **CLI commands (db, dedup, extension)** | Untested | Silent breakage |
| **Docker build + run** | Image built in CI but never started | Import errors, missing deps caught only in staging |
| **DB migrations on real Postgres** | Mocked only | Schema drift, failed upgrades |
| **Adapter contract testing** | All HTTP mocked | API changes break sync silently |
| **Configuration matrix** | One hardcoded config | Provider auto-detection bugs ship silently |
| **Multi-adapter scenarios** | Not tested | Jira + Linear + GitHub Issues interactions unknown |

### Deployment profiles to test

| Profile | Auth | Database | Adapters | Use Case |
|---------|------|----------|----------|----------|
| **Production** | Auth0 (multi-tenant, orgs) | Postgres (Neon) | All | Full platform |
| **Preview** | Auth0 (shared) | Postgres (shared) | All | PR environments |
| **OSS** | Generic OIDC / disabled | Self-hosted Postgres | All | Self-hosted users |
| **CLI-only** | Device flow | None (local mode) | File-based | Individual developers |

## 2. Devbox Environment

<!-- canon:system:2 status:in_progress -->

<!-- canon:ticket:github:627 url:https://github.com/canonhq/canon-private/issues/627 -->
Adopt [Devbox](https://github.com/jetify-com/devbox) (Nix-based) to provide a reproducible development environment that ensures every developer and CI runner has identical tooling.

### Acceptance Criteria

- [ ] `devbox.json` at repo root declares all required tools: Python 3.12+, uv, Node.js (for docs-site/plugin), Helm, kubectl, Terraform, Docker, PostgreSQL client libs, and ruff
- [ ] `devbox shell` drops into a working environment where `uv sync --extra dev --extra cloud && uv run pytest` passes
- [ ] `devbox run test` executes the full test suite (unit + integration)
- [ ] `devbox run lint` executes ruff check + ruff format --check
- [ ] `devbox run dev` starts the development server with hot reload
- [ ] CI workflows use `devbox run` instead of manually installing tools
- [ ] `devbox.lock` is committed, ensuring deterministic builds
- [ ] README and CLAUDE.md updated with devbox setup instructions
- [ ] Init hooks in `devbox.json` run `uv sync` automatically on shell entry

## 3. Docker Compose Test Harness

<!-- canon:system:3 status:done -->

A `docker-compose.test.yml` that spins up all service dependencies for integration testing, replacing ad-hoc CI service containers with a consistent, locally-reproducible stack.

### Acceptance Criteria

- [ ] `docker-compose.test.yml` defines: Postgres 16 (with pgvector), mock GitHub API (WireMock or similar), mock Jira API, mock Linear API, optional Keycloak for OIDC testing
- [ ] `devbox run integration` starts the compose stack, runs integration tests, and tears down
- [ ] Mock services are configured via fixture files in `tests/mocks/` (WireMock JSON mappings or similar)
- [ ] Postgres container runs Canon's actual migration scripts on startup
- [ ] Mock services return realistic responses matching real API contracts (recorded from real APIs where possible)
- [ ] Health check script waits for all services before running tests
- [ ] CI integration test job uses the same compose file (no separate service definitions)
- [ ] Compose stack starts in under 30 seconds on CI

## 4. Scenario-Based Lifecycle Testing

<!-- canon:system:4 status:done -->

A `tests/scenarios/` directory containing pre-built repo fixtures that simulate different Canon adoption stages. Each scenario is a minimal, self-contained "customer repo" that exercises Canon from the outside in.

### 4.1 Scenario Definitions

<!-- canon:system:4.1 status:done -->
| Scenario | Description | What It Tests |
|----------|-------------|---------------|
| `fresh-empty` | Empty directory, no CANON.yaml, no specs | `canon setup`, `canon doctor` on virgin repo, error messages for missing config |
| `fresh-configured` | CANON.yaml present, no specs yet | Config parsing, `canon doctor` passes, `canon lint` reports no specs, adapter connectivity |
| `first-spec` | One spec file, configured for GitHub Issues | Spec parsing, forward sync creates ticket, `canon status` shows coverage |
| `mid-adoption` | 5 specs, mixed statuses, Jira adapter | Sync with existing tickets, status mapping, dedup on re-sync, `canon audit` |
| `mature` | 8+ specs, full coverage, multiple adapters | Multi-adapter sync (Jira + Linear), bulk operations, `canon stale` detection |
| `oss-mode` | OSS config, no Auth0, local Postgres | OSS deployment path, generic OIDC, self-hosted features |
| `multi-adapter` | Same spec synced to Jira + GitHub Issues | Cross-adapter dedup, field mapping differences, status reconciliation |
| `broken-config` | Intentionally invalid CANON.yaml variants | Error reporting quality, graceful degradation, helpful messages |

### 4.2 Scenario Structure

Each scenario directory contains:
```
tests/scenarios/<name>/
  __init__.py            # Required for pytest collection
  fixture/               # Isolated repo content
    CANON.yaml           # Repo config for this scenario
    docs/specs/          # Spec files (if applicable)
  test_<name>.py         # Pytest test (unique basename required)
```

### Acceptance Criteria

- [ ] All 8 scenarios above are implemented with fixtures and test scripts
- [ ] Each scenario's `test_scenario.py` runs Canon CLI commands via subprocess against the fixture directory
- [ ] Scenarios that involve ticket sync use the mock services from the Docker Compose harness (§3)
- [ ] `fresh-empty` scenario validates that `canon setup` produces a valid CANON.yaml
- [ ] `fresh-configured` scenario validates that `canon doctor` passes with mock adapter endpoints
- [ ] `first-spec` scenario validates full forward sync lifecycle: parse → plan → create ticket → verify
- [ ] `mid-adoption` scenario validates dedup: running sync twice produces no duplicate tickets
- [ ] `mature` scenario validates multi-adapter sync and `canon audit` accuracy
- [ ] `oss-mode` scenario validates Canon works without Auth0 or cloud features
- [ ] `broken-config` scenario validates all error messages are actionable (no raw tracebacks)
- [ ] Scenarios run in parallel in CI (each gets its own compose namespace)
- [ ] Total scenario suite completes in under 5 minutes on CI

## 5. Adapter Contract Testing

<!-- canon:system:5 status:done -->

Record real API interactions from Jira, Linear, and GitHub Issues, then replay them in tests to validate adapter behavior against actual API contracts — not hand-written mocks.

### Acceptance Criteria

- [ ] Recording harness captures real HTTP request/response pairs from each adapter (one-time setup, committed to repo)
- [ ] Recorded fixtures stored in `tests/contracts/<adapter>/` as JSON or YAML
- [ ] Jira adapter has contract tests for: create issue, update issue, search (JQL), transition, get fields, get project
- [ ] Linear adapter has contract tests for: create issue, update issue, search, get team, get workflow states
- [ ] GitHub Issues adapter has contract tests for: create issue, update issue, search, add labels, close issue
- [ ] Contract tests run against recorded responses (no network calls in CI)
- [ ] A `make record-contracts` target re-records from real APIs (developer-only, requires credentials)
- [ ] Contract tests validate both adapter output AND that the adapter sends correct request shapes

## 6. Missing Test Coverage

<!-- canon:system:6 status:done -->

Fill the specific test gaps identified in the codebase audit.

### 6.1 Linear Adapter Tests

- [ ] Dedicated `tests/test_sync/test_linear_adapter.py` with parity to Jira adapter coverage (40+ tests)
- [ ] Tests cover: create issue, update issue, search, status transitions, label sync, error handling
- [ ] Tests cover Linear-specific behavior: team resolution, workflow state mapping, cycle assignment

### 6.2 Untested CLI Commands

- [ ] `tests/test_cli/test_db_cmd.py` — covers `canon db` subcommands (migrate, status, reset)
- [ ] `tests/test_cli/test_dedup_cmd.py` — covers `canon dedup` (duplicate detection and resolution)
- [ ] `tests/test_cli/test_extension_cmd.py` — covers `canon extension` (list, install, validate)

### 6.3 Package Install Smoke Test

- [ ] CI job builds the wheel, installs it in a clean virtualenv, and runs `canon --version` + `canon doctor --help`
- [ ] Validates that all entry points are registered and importable
- [ ] Catches missing `data_files`, `package_data`, or dependency issues before PyPI release

### 6.4 Docker Build & Run Test

- [ ] CI job builds the Docker image AND starts it with a health check
- [ ] Container starts, binds to port, and `/health` returns 200 within 30 seconds
- [ ] Tests run against the containerized app (basic route checks)

### 6.5 Database Migration Tests

- [ ] Integration tests run Canon's migration scripts against real Postgres (from the compose stack)
- [ ] Tests validate: fresh install (all migrations from zero), upgrade path (apply migrations incrementally), idempotency (running migrations twice is safe)
- [ ] Migration tests run in CI as part of the integration suite

## 7. CI/CD Integration

<!-- canon:system:7 status:done -->

Integrate the new testing layers into the GitHub Actions CI pipeline.

### Acceptance Criteria

- [ ] New workflow `scenario-tests.yml` runs the scenario matrix on every PR
- [ ] Scenarios run in parallel using GitHub Actions matrix strategy
- [ ] Devbox is cached in CI (Nix store caching via `jetify-com/devbox-install-action`)
- [ ] Integration tests use the Docker Compose stack instead of ad-hoc CI service containers
- [ ] Contract tests run as part of the unit test suite (no network required)
- [ ] Package install smoke test runs on every PR that modifies `pyproject.toml` or `src/`
- [ ] Docker build + run test runs on every PR that modifies `Dockerfile` or `src/`
- [ ] Total CI time for new test layers stays under 10 minutes
- [ ] CI caches Docker images and Nix store between runs
- [ ] Existing CI jobs (`ci.yml`) are updated to use `devbox run` where applicable

## 8. Developer Experience

<!-- canon:system:8 status:done -->

Ensure the new testing infrastructure is easy to use locally.

### Acceptance Criteria

- [ ] `devbox shell` → `uv run pytest` works out of the box for unit tests
- [ ] `devbox run integration` works out of the box for integration tests (starts compose, runs tests, tears down)
- [ ] `devbox run scenario <name>` runs a single scenario locally
- [ ] `devbox run scenario --all` runs all scenarios locally
- [ ] `devbox run contracts --record` re-records API contract fixtures (requires credentials)
- [ ] All devbox scripts are documented in `devbox.json` with descriptions
- [ ] Troubleshooting guide in `docs/contributing/testing.md` covers: devbox install, compose issues, scenario debugging
- [ ] First-time setup from clone to running tests takes under 5 minutes with devbox

## 9. Success Metrics

<!-- canon:system:9 status:todo -->

<!-- canon:ticket:github:628 url:https://github.com/canonhq/canon-private/issues/628 -->
### Quantitative

- All 8 adoption scenarios pass in CI on every PR
- Linear adapter has 40+ tests (parity with Jira)
- Zero untested CLI commands
- Docker image starts successfully on every PR
- Package installs cleanly from wheel on every release
- DB migrations validated against real Postgres on every PR

### Qualitative

- Developer can reproduce any CI failure locally with `devbox run`
- New adoption lifecycle bugs are caught in CI before users report them
- Confidence to ship CLI and sync changes without manual testing
- Contributors can onboard with a single `devbox shell` command

---

## Design Details

### D1. devbox.json Structure

Devbox provides Nix-backed reproducible environments. Key design decisions:

- **Let uv manage the virtualenv**, not Devbox's built-in Python plugin. Devbox provides the `python` and `uv` binaries; `init_hook` runs `uv sync` to create `.venv`.
- **Pin packages** via `devbox.lock` (auto-generated, committed to repo).
- **Scripts** provide the standard developer commands.

```json
{
  "$schema": "https://raw.githubusercontent.com/jetify-com/devbox/0.0.0-dev/.schema/devbox.schema.json",
  "packages": [
    "python@3.12",
    "uv@latest",
    "nodejs@20",
    "kubernetes-helm@latest",
    "kubectl@latest",
    "terraform@latest",
    "ruff@latest",
    "libpq@latest"
  ],
  "env": {
    "VIRTUAL_ENV": ".venv",
    "UV_PROJECT_ENVIRONMENT": ".venv"
  },
  "shell": {
    "init_hook": [
      "uv sync --extra dev --extra cloud 2>/dev/null || true"
    ],
    "scripts": {
      "test": "uv run pytest",
      "test:verbose": "uv run pytest -v",
      "lint": "uv run ruff check && uv run ruff format --check",
      "format": "uv run ruff format",
      "dev": "uv run uvicorn canon.main:app --reload",
      "integration": "./scripts/run-integration.sh",
      "scenario": "./scripts/run-scenario.sh",
      "contracts:record": "./scripts/record-contracts.sh"
    }
  }
}
```

**CI integration** uses `jetify-com/devbox-install-action@v0.12.0` with `enable-cache: true` to cache the Nix store.

### D2. Mock Framework: WireMock

**Decision**: Use WireMock as the network-accessible mock server for all adapter endpoints.

**Why WireMock over alternatives**:
- **Record-and-replay**: Built-in proxy recording mode captures real API interactions as JSON stubs. Point WireMock at real Jira/Linear/GitHub, run the scenario once, commit the captured stubs. No manual fixture authoring.
- **Zero Python code**: Stubs are JSON files in `tests/mocks/wiremock/`. No custom mock server to maintain.
- **Docker Compose native**: Single service, volume-mount the stubs directory.
- **Fault injection**: Return 401s to test token refresh, inject delays for timeout handling.
- **CLI-compatible**: Scenario tests run `canon` as a subprocess — in-process mocking (respx) can't intercept those calls. WireMock is a real HTTP server on the Docker network.

**Existing `respx` usage remains** for unit tests — WireMock is only for integration/scenario tests.

**WireMock stub organization**:
```
tests/mocks/wiremock/
  jira/
    mappings/           # Stub definitions (request matching → response)
      create-issue.json
      search-jql.json
      transition.json
      get-fields.json
    __files/            # Response body files
      issue-created.json
      search-results.json
  linear/
    mappings/
      create-issue.json
      get-team.json
      get-workflow-states.json
    __files/
      ...
  github/
    mappings/
      create-issue.json
      list-issues.json
      add-labels.json
    __files/
      ...
```

**Per-adapter WireMock instances** in Docker Compose, so each adapter gets its own port and stub directory. This avoids URL path collisions between APIs.

### D3. Docker Compose Stack

```yaml
# docker-compose.test.yml
services:
  postgres:
    image: pgvector/pgvector:pg16
    environment:
      POSTGRES_DB: canon_test
      POSTGRES_USER: canon
      POSTGRES_PASSWORD: testpass
    ports: ["15432:5432"]
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U canon"]
      interval: 2s
      timeout: 5s
      retries: 10

  mock-jira:
    image: wiremock/wiremock:3.6.0
    volumes:
      - ./tests/mocks/wiremock/jira:/home/wiremock
    ports: ["18080:8080"]

  mock-linear:
    image: wiremock/wiremock:3.6.0
    volumes:
      - ./tests/mocks/wiremock/linear:/home/wiremock
    ports: ["18081:8080"]

  mock-github-api:
    image: wiremock/wiremock:3.6.0
    volumes:
      - ./tests/mocks/wiremock/github:/home/wiremock
    ports: ["18082:8080"]

  keycloak:
    image: quay.io/keycloak/keycloak:24.0
    command: start-dev --import-realm
    environment:
      KC_HEALTH_ENABLED: "true"
      KEYCLOAK_ADMIN: admin
      KEYCLOAK_ADMIN_PASSWORD: admin
    volumes:
      - ./tests/mocks/keycloak/realm-export.json:/opt/keycloak/data/import/realm.json
    ports: ["18083:8080"]
    profiles: ["oidc"]  # Only started when OIDC testing is needed
```

**`scripts/run-integration.sh`**:
```bash
#!/usr/bin/env bash
set -euo pipefail
docker compose -f docker-compose.test.yml up -d --wait
trap 'docker compose -f docker-compose.test.yml down -v' EXIT
export DATABASE_URL="postgresql://canon:testpass@localhost:15432/canon_test"
export JIRA_BASE_URL="http://localhost:18080"
export LINEAR_BASE_URL="http://localhost:18081"
export GITHUB_API_URL="http://localhost:18082"
uv run pytest tests/integration/ -m integration --override-ini "addopts=" -v "$@"
```

### D4. Scenario Runner Architecture

Each scenario is a pytest module that:
1. Copies a fixture directory into a temp dir with a real git repo
2. Points adapter URLs at WireMock containers
3. Runs Canon CLI commands as subprocesses
4. Asserts on CLI output and side effects (WireMock verify API confirms expected API calls)

**Core fixtures** (`tests/scenarios/conftest.py`):

```python
import subprocess, shutil, json, os
from pathlib import Path
import pytest

SCENARIOS_DIR = Path(__file__).parent

@pytest.fixture(scope="session")
def mock_services():
    """Docker Compose mock services (started by run-scenario.sh)."""
    return {
        "jira": os.environ.get("JIRA_BASE_URL", "http://localhost:18080"),
        "linear": os.environ.get("LINEAR_BASE_URL", "http://localhost:18081"),
        "github": os.environ.get("GITHUB_API_URL", "http://localhost:18082"),
    }

@pytest.fixture
def scenario_repo(tmp_path, request):
    """Copy scenario fixture into isolated tmp dir with git repo."""
    name = request.param
    src = SCENARIOS_DIR / name / "fixture"
    dst = tmp_path / "repo"
    shutil.copytree(src, dst)
    subprocess.run(["git", "init", "-b", "main"], cwd=dst, check=True, capture_output=True)
    subprocess.run(["git", "add", "."], cwd=dst, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "init", "--author", "Test <test@test.com>"],
        cwd=dst, check=True, capture_output=True,
    )
    return dst

def run_canon(repo_dir: Path, *args, env_override=None):
    """Run canon CLI as subprocess against a scenario repo."""
    env = {**os.environ, **(env_override or {})}
    return subprocess.run(
        ["uv", "run", "canon", *args],
        cwd=repo_dir, capture_output=True, text=True, timeout=60, env=env,
    )
```

**Example scenario test** (`tests/scenarios/fresh-empty/test_scenario.py`):

```python
import pytest
from tests.scenarios.conftest import run_canon

@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["fresh-empty"], indirect=True)
class TestFreshEmpty:
    def test_doctor_reports_missing_config(self, scenario_repo):
        result = run_canon(scenario_repo, "doctor", "--json")
        assert result.returncode != 0
        assert "CANON.yaml" in result.stdout or "CANON.yaml" in result.stderr

    def test_setup_creates_valid_config(self, scenario_repo):
        result = run_canon(scenario_repo, "setup", "--non-interactive")
        assert result.returncode == 0
        assert (scenario_repo / "CANON.yaml").exists()

    def test_doctor_passes_after_setup(self, scenario_repo):
        run_canon(scenario_repo, "setup", "--non-interactive")
        result = run_canon(scenario_repo, "doctor", "--json")
        assert result.returncode == 0
```

**Parallel execution**: Use `pytest-xdist` with `--dist loadscope` to group tests within the same scenario module onto one worker. Each scenario gets its own `tmp_path`.

### D5. Contract Test Recording

**One-time recording process** (developer-only, requires real API credentials):

```bash
# Start WireMock in recording proxy mode
docker run --rm -p 8080:8080 wiremock/wiremock:3.6.0 \
  --proxy-all="https://your-jira.atlassian.net" \
  --record-mappings

# Run the canon commands that exercise the adapter
JIRA_BASE_URL=http://localhost:8080 uv run canon sync --dry-run

# Captured stubs appear in container's /home/wiremock/mappings/
# Copy out and commit to tests/mocks/wiremock/jira/
```

A `scripts/record-contracts.sh` script automates this for each adapter. Recorded stubs are committed to the repo and replayed in CI without network access.

### D6. CI Workflow Structure

```yaml
# .github/workflows/scenario-tests.yml
name: Scenario Tests
on:
  pull_request:
    paths: [src/**, tests/**, pyproject.toml, devbox.json, docker-compose.test.yml]

jobs:
  scenarios:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        scenario:
          - fresh-empty
          - fresh-configured
          - first-spec
          - mid-adoption
          - mature
          - oss-mode
          - multi-adapter
          - broken-config
      fail-fast: false
    steps:
      - uses: actions/checkout@v4
      - uses: jetify-com/devbox-install-action@v0.12.0
        with:
          enable-cache: true
      - name: Start mock services
        run: devbox run -- docker compose -f docker-compose.test.yml up -d --wait
      - name: Run scenario
        run: |
          devbox run -- uv run pytest tests/scenarios/${{ matrix.scenario }}/ \
            -m scenario --override-ini "addopts=" -v
      - name: Teardown
        if: always()
        run: docker compose -f docker-compose.test.yml down -v
```

Each scenario runs as a separate matrix job for parallelism and independent failure reporting.

---

## Implementation Tasks

Tasks are ordered by dependency. Each task references the spec section it implements.

### Phase A: Foundation (no dependencies)

**T1. Create devbox.json and validate environment** [§2]
- Create `devbox.json` with all packages (Python 3.12, uv, Node 20, Helm, kubectl, Terraform, ruff, libpq)
- Configure `init_hook` with `uv sync`, scripts for `test`, `lint`, `dev`
- Commit `devbox.lock`
- Validate: `devbox shell` → `uv run pytest tests/test_parser/` passes
- Update CLAUDE.md and README with devbox instructions
- Files: `devbox.json`, `devbox.lock`, `CLAUDE.md`, `README.md`

**T2. Create docker-compose.test.yml with Postgres** [§3]
- Postgres 16 with pgvector, health check, test credentials
- `scripts/run-integration.sh` starts compose, runs tests, tears down
- Validate: existing integration tests pass against compose Postgres
- Files: `docker-compose.test.yml`, `scripts/run-integration.sh`

**T3. Add Linear adapter test suite** [§6.1]
- Create `tests/test_sync/test_linear_adapter.py` with 40+ tests
- Cover: create issue, update issue, search, status transitions, label sync, error handling
- Cover Linear-specific: team resolution, workflow state mapping
- Use respx for HTTP mocking (consistent with Jira adapter tests)
- Files: `tests/test_sync/test_linear_adapter.py`

**T4. Add missing CLI command tests** [§6.2]
- `tests/test_cli/test_db_cmd.py` — db subcommands
- `tests/test_cli/test_dedup_cmd.py` — dedup command
- `tests/test_cli/test_extension_cmd.py` — extension command
- Files: `tests/test_cli/test_db_cmd.py`, `tests/test_cli/test_dedup_cmd.py`, `tests/test_cli/test_extension_cmd.py`

### Phase B: Mock Infrastructure (depends on T2)

**T5. Set up WireMock stubs for Jira adapter** [§3, §5]
- Create `tests/mocks/wiremock/jira/mappings/` with stub JSON files
- Cover: create issue, search (JQL), transition, get fields, get project, update issue
- Create `tests/mocks/wiremock/jira/__files/` with response bodies
- Add `mock-jira` service to `docker-compose.test.yml`
- Validate: `curl http://localhost:18080/rest/api/3/issue` returns stub response
- Files: `tests/mocks/wiremock/jira/**`, `docker-compose.test.yml`

**T6. Set up WireMock stubs for Linear adapter** [§3, §5]
- Create `tests/mocks/wiremock/linear/mappings/` with stub JSON files (GraphQL)
- Cover: create issue, search, get team, get workflow states, update issue
- Add `mock-linear` service to `docker-compose.test.yml`
- Files: `tests/mocks/wiremock/linear/**`, `docker-compose.test.yml`

**T7. Set up WireMock stubs for GitHub Issues adapter** [§3, §5]
- Create `tests/mocks/wiremock/github/mappings/` with stub JSON files
- Cover: create issue, list issues, add labels, close issue, search
- Add `mock-github-api` service to `docker-compose.test.yml`
- Files: `tests/mocks/wiremock/github/**`, `docker-compose.test.yml`

### Phase C: Scenario Framework (depends on T2, T5-T7)

**T8. Create scenario runner infrastructure** [§4]
- Create `tests/scenarios/conftest.py` with `scenario_repo`, `mock_services`, and `run_canon` fixtures
- Add `scenario` pytest marker to `pyproject.toml`
- Create `scripts/run-scenario.sh` that starts compose + runs scenario tests
- Add devbox script: `"scenario": "./scripts/run-scenario.sh"`
- Validate: empty scenario directory with minimal test passes
- Files: `tests/scenarios/conftest.py`, `scripts/run-scenario.sh`, `pyproject.toml`, `devbox.json`

**T9. Implement `fresh-empty` scenario** [§4.1]
- Create `tests/scenarios/fresh-empty/fixture/` (empty directory, `.gitkeep` only)
- Create `tests/scenarios/fresh-empty/test_scenario.py`
- Tests: doctor fails with helpful message, setup creates CANON.yaml, doctor passes after setup, lint reports no specs
- Files: `tests/scenarios/fresh-empty/**`

**T10. Implement `fresh-configured` scenario** [§4.1]
- Create fixture with valid CANON.yaml pointing adapters at WireMock URLs
- Tests: doctor passes, lint reports no specs, `canon status` works, adapter connectivity check passes
- Files: `tests/scenarios/fresh-configured/**`

**T11. Implement `first-spec` scenario** [§4.1]
- Fixture: CANON.yaml + one spec file with 3 sections, GitHub Issues adapter
- Tests: parse succeeds, forward sync creates 3 issues (verify via WireMock), status shows coverage, re-sync deduplicates
- Files: `tests/scenarios/first-spec/**`

**T12. Implement `mid-adoption` scenario** [§4.1]
- Fixture: 5 specs, mixed statuses (todo/in_progress/done), Jira adapter
- Tests: sync handles existing tickets, status mapping works, audit reports accurate coverage, stale detection works
- Files: `tests/scenarios/mid-adoption/**`

**T13. Implement `mature` scenario** [§4.1]
- Fixture: 20+ specs, Jira + Linear adapters configured
- Tests: multi-adapter sync, bulk operations, full audit, coverage metrics accurate
- Files: `tests/scenarios/mature/**`

**T14. Implement `oss-mode` scenario** [§4.1]
- Fixture: OSS-compatible config, no Auth0, local Postgres
- Tests: all CLI commands work without cloud features, no auth requirement for local mode
- Files: `tests/scenarios/oss-mode/**`

**T15. Implement `multi-adapter` scenario** [§4.1]
- Fixture: one spec synced to both Jira and GitHub Issues
- Tests: cross-adapter dedup, field mapping differences handled, status reconciliation
- Files: `tests/scenarios/multi-adapter/**`

**T16. Implement `broken-config` scenario** [§4.1]
- Fixture: multiple intentionally invalid CANON.yaml files
- Tests: each produces actionable error message (no raw tracebacks), graceful degradation
- Files: `tests/scenarios/broken-config/**`

### Phase D: Deployment Validation (depends on T1, T2)

**T17. Package install smoke test** [§6.3]
- CI job: build wheel → install in clean virtualenv → run `canon --version` + `canon doctor --help`
- Validate entry points, data files, dependency resolution
- Files: `.github/workflows/ci.yml` (new job) or `scripts/package-smoke-test.sh`

**T18. Docker build & run test** [§6.4]
- Enhance existing `scripts/docker-smoke-test.sh` or add to CI
- Build image → start container → health check → basic route checks → teardown
- Files: `.github/workflows/ci.yml` (ensure smoke test job runs)

**T19. Database migration integration tests** [§6.5]
- Tests run Canon's actual migration scripts against real Postgres from compose stack
- Validate: fresh install (all migrations from zero), idempotency (run twice is safe)
- Files: `tests/integration/test_db_migrations.py`

### Phase E: CI Integration (depends on T1, T8, and at least T9-T11)

**T20. Create scenario-tests.yml workflow** [§7]
- GitHub Actions workflow with 8-element scenario matrix
- Uses `jetify-com/devbox-install-action` with caching
- Starts Docker Compose, runs per-scenario pytest, tears down
- Files: `.github/workflows/scenario-tests.yml`

**T21. Update ci.yml to use devbox** [§7]
- Replace manual tool installation steps with `devbox run`
- Replace ad-hoc CI service containers with Docker Compose references where applicable
- Add package install smoke test and Docker run test as jobs
- Files: `.github/workflows/ci.yml`

### Phase F: Developer Experience (depends on T1, T8)

**T22. Create contract recording scripts** [§5, §8]
- `scripts/record-contracts.sh` — automates WireMock proxy recording for each adapter
- Documented in `devbox.json` as `contracts:record` script
- Files: `scripts/record-contracts.sh`

**T23. Write testing guide** [§8]
- `docs/contributing/testing.md` — covers devbox install, running tests, scenarios, contract recording, troubleshooting
- Files: `docs/contributing/testing.md`

**T24. Mark superseded specs as superseded** [§1]
- Update frontmatter of `enhanced-platform-testing.md` and `app-integration-test-enhancements.md` to `status: superseded` with pointer to this spec
- Files: `docs/specs/enhanced-platform-testing.md`, `docs/specs/app-integration-test-enhancements.md`

### Task Dependency Graph

```
Phase A (parallel):  T1  T2  T3  T4
                      │   │
Phase B (parallel):   │  T5  T6  T7
                      │   │   │   │
Phase C:              │   T8 ─────┘
                      │   │
                      │  T9  T10  T11  T12  T13  T14  T15  T16
                      │
Phase D (parallel):  T17  T18  T19
                      │         │
Phase E:             T20 ──── T21
                      │
Phase F:             T22  T23  T24
```
