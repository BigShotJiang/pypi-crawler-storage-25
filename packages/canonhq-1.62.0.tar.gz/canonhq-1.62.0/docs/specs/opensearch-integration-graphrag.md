---
title: "OpenSearch Integration & GitHub Content Caching"
status: draft
owner: ng
team: canon
ticket_project: canonhq/canon-private
created: 2026-04-25
updated: 2026-04-25
tags: [search, opensearch, performance, caching, github-api, infrastructure]
---

# OpenSearch Integration & GitHub Content Caching

Eliminate GitHub API rate-limit pressure and dashboard latency by caching all
spec content in PostgreSQL, serving reads from the database, and migrating
search to a dedicated OpenSearch cluster with GraphRAG capabilities.

## 1. Background

<!-- canon:system:1 status:done -->

<!-- canon:ticket:github:566 url:https://github.com/canonhq/canon-private/issues/566 -->
Canon's web dashboard, MCP tools, and cron jobs all fetch spec content directly
from the GitHub Contents API on every request. For an organization with 10 repos
and 5 specs each, a single dashboard page load triggers ~81 GitHub API calls
(list repos + per-repo config fetch + directory listing + individual file fetch
per spec). As the spec corpus grows, this pattern produces 503 rate-limit errors
and multi-second page loads.

The search index in PostgreSQL (pgvector + ParadeDB BM25) already stores parsed
spec titles, sections, statuses, and embeddings — but the dashboard and MCP
tools never read from it. Push webhooks already parse and index specs on change.
The indexing pipeline exists; the read path bypasses it.

Meanwhile, the pgvector + ParadeDB search stack works for basic hybrid search
but lacks the tuning, aggregation, and scaling capabilities needed as the spec
corpus grows toward thousands of documents. Moving search to OpenSearch provides
native BM25 relevance tuning, efficient kNN vector search, rich aggregations for
dashboard facets, and a foundation for GraphRAG-style cross-spec retrieval.

### Current Architecture

| Component | Behavior | Impact |
|-----------|----------|--------|
| Web dashboard | Fetches every spec from GitHub live via `load_repo_specs()` | 503s, slow page loads |
| MCP tools | `get_spec`, `get_section`, `list_specs` hit GitHub directly | Rate limit pressure |
| Cron jobs | `sync_status`, `coverage_snapshot`, `reindex` do full GitHub crawls | Compounds API usage |
| Search index | Postgres pgvector + ParadeDB BM25 stores parsed content | Dashboard ignores it |
| Caching | In-memory TTL dict (per-process, lost on restart) | No distributed cache |
| Raw markdown | Not stored anywhere except GitHub | Can't render without GitHub |

### Target Architecture

```
GitHub ──push webhook──▶ Parser ──▶ PostgreSQL (source of truth)
                                        │
                                        ├──▶ Web Dashboard (reads from PG)
                                        ├──▶ MCP Tools (reads from PG)
                                        └──▶ OpenSearch (search index, synced from PG)
                                                ├──▶ Hybrid search (BM25 + kNN)
                                                ├──▶ Dashboard aggregations
                                                └──▶ GraphRAG / semantic queries
```

PostgreSQL is the source of truth for spec content. OpenSearch is a derived
search engine populated from Postgres, handling search queries, faceted
aggregations, and semantic retrieval. GitHub is the canonical source — Postgres
mirrors it via webhook-driven sync + periodic reconciliation.

## 2. Postgres Content Cache — Schema & Sync Engine

<!-- canon:system:2 status:done -->

<!-- canon:ticket:github:631 url:https://github.com/canonhq/canon-private/issues/631 -->
Extend the existing `spec_documents` and `spec_sections` tables to store raw
markdown content, and build a sync engine that keeps Postgres in sync with
GitHub via push webhooks and periodic reconciliation.

### Schema Changes

Add to `spec_documents`:
- `raw_markdown TEXT` — full raw markdown content of the spec file
- `github_etag VARCHAR(128)` — GitHub ETag for conditional fetches
- `synced_at TIMESTAMPTZ` — when this row was last synced from GitHub
- `github_sha VARCHAR(40)` — exact commit SHA this content was fetched at

Add to `spec_sections`:
- `raw_content TEXT` — raw markdown content of just this section (for rendering)

Add new table `repo_configs`:
- `id SERIAL PRIMARY KEY`
- `installation_id BIGINT NOT NULL`
- `owner VARCHAR(255) NOT NULL`
- `repo VARCHAR(255) NOT NULL`
- `config_yaml TEXT` — raw CANON.yaml content
- `parsed_config JSONB` — parsed config as JSON
- `github_etag VARCHAR(128)`
- `synced_at TIMESTAMPTZ`
- `UNIQUE(owner, repo)`

Add new table `repo_sync_state`:
- `id SERIAL PRIMARY KEY`
- `installation_id BIGINT NOT NULL`
- `owner VARCHAR(255) NOT NULL`
- `repo VARCHAR(255) NOT NULL`
- `default_branch VARCHAR(255)`
- `last_full_sync_at TIMESTAMPTZ`
- `last_push_sync_at TIMESTAMPTZ`
- `spec_count INTEGER DEFAULT 0`
- `sync_status VARCHAR(32) DEFAULT 'pending'` — pending, syncing, synced, error
- `error_detail TEXT`
- `UNIQUE(owner, repo)`

### Sync Engine

The sync engine (`src/canon/sync/content_sync.py`) manages the GitHub → Postgres
pipeline with two modes:

**Incremental sync (push webhook):** On `push` events, the existing
`on_push.py` handler already parses changed spec files. Extend it to also
upsert `raw_markdown` into `spec_documents` and update `spec_sections` with
`raw_content`. This is the primary sync path — near-real-time, per-file.

**Full reconciliation (cron):** A new cron job (`cron/content_reconcile.py`)
runs every 30 minutes. For each repo:
1. Fetch the spec directory listing using the Git Trees API (single call)
2. Compare file SHAs against `spec_documents.github_sha`
3. Fetch only changed/new files using conditional requests (ETag)
4. Upsert into Postgres
5. Delete rows for specs that no longer exist in GitHub
6. Update `repo_sync_state.last_full_sync_at`

**Initial bootstrap:** When a new repo is installed, trigger an immediate full
sync before responding with 200. The background indexer already does this for
the search index; extend it to populate the content cache too.

### Acceptance Criteria

- [ ] `spec_documents` table has `raw_markdown`, `github_etag`, `synced_at`, `github_sha` columns
- [ ] `spec_sections` table has `raw_content` column
- [ ] `repo_configs` table stores CANON.yaml content and parsed config
- [ ] `repo_sync_state` table tracks per-repo sync status and timestamps
- [ ] Push webhook handler upserts raw markdown into Postgres alongside existing search indexing
- [ ] Full reconciliation cron job syncs all repos every 30 minutes using Git Trees API + conditional fetches
- [ ] Bootstrap sync runs on new GitHub App installation before returning 200
- [ ] Specs deleted from GitHub are removed from Postgres during reconciliation
- [ ] `synced_at` and `github_sha` are set on every upsert for staleness detection

## 3. Dashboard Read Path — Serve from Postgres

<!-- canon:system:3 status:done -->

<!-- canon:ticket:github:632 url:https://github.com/canonhq/canon-private/issues/632 -->
Rewrite the web dashboard service layer to read spec content from PostgreSQL
instead of GitHub. This is the primary fix for 503 errors and slow page loads.

### Changes to `web/services.py`

Replace `get_org_overview()` implementation:
- Instead of `list_installation_repos()` + per-repo `load_repo_specs()`, query
  `repo_sync_state` joined with `spec_documents` grouped by repo
- Spec counts, statuses, and metadata come from Postgres aggregations
- Repo list comes from `gh_installations` + `repo_sync_state`

Replace `get_spec_detail()`:
- Instead of `github_client.get_file_content()` + `parse_spec()`, query
  `spec_documents` by `(owner, repo, path)` and return cached `raw_markdown`
- Parse on read (or cache parsed result) for rendering

Replace `get_tasks()`:
- Query `spec_sections` with `status IN ('todo', 'in_progress')` filtered by org
- No GitHub calls needed

Replace `search_specs()`:
- Continue using existing search index (Postgres initially, OpenSearch later)
- No change needed here

### Fallback Strategy

If a spec is requested but not yet in Postgres (race condition during initial
sync), fall back to a direct GitHub fetch, cache the result, and return it.
This ensures zero downtime during the migration.

### Cache Invalidation

Push webhooks already trigger reindexing. Extend the push handler to also
invalidate the in-memory TTL cache for the affected repo/spec. The Postgres
content is always fresh (webhook-driven), so the TTL cache becomes a hot-read
optimization layer on top of Postgres, not a correctness concern.

### Acceptance Criteria

- [ ] `get_org_overview()` reads from `repo_sync_state` + `spec_documents` instead of GitHub API
- [ ] `get_spec_detail()` reads `raw_markdown` from `spec_documents` instead of GitHub
- [ ] `get_tasks()` queries `spec_sections` by status instead of fetching from GitHub
- [ ] Dashboard page load triggers zero GitHub API calls for cached repos
- [ ] Fallback to GitHub fetch works when spec is not yet in Postgres
- [ ] Push webhook invalidates in-memory cache for affected repo/spec
- [ ] Page load time for org dashboard with 10+ repos is under 2 seconds (from 10+ seconds)

## 4. MCP & CLI Read Path — Serve from Postgres

<!-- canon:system:4 status:done -->

<!-- canon:ticket:github:633 url:https://github.com/canonhq/canon-private/issues/633 -->
Rewrite MCP tools and CLI commands that read spec content to use the Postgres
content cache instead of direct GitHub API calls.

### MCP Tools to Rewrite

| Tool | Current | Target |
|------|---------|--------|
| `get_spec` | `github_client.get_file_content()` → parse | Query `spec_documents.raw_markdown` → parse |
| `get_section` | Fetch full file from GitHub → parse → find section | Query `spec_sections` by doc_id + heading |
| `get_doc` | `github_client.get_file_content()` | Query `spec_documents.raw_markdown` |
| `list_specs` | `load_repo_specs()` (N+1 calls) | Query `spec_documents` filtered by repo |
| `list_docs` | Already uses search index | No change |
| `search` | Already uses search index | No change (migrates to OpenSearch later) |

### Write Operations

`create_spec`, `update_section_status`, and `sync_spec_status` must continue
writing to GitHub (it's the canonical source). After writing to GitHub, they
should also update the Postgres cache to avoid stale reads.

### Acceptance Criteria

- [ ] `get_spec` MCP tool reads from Postgres, falls back to GitHub on cache miss
- [ ] `get_section` MCP tool queries `spec_sections` directly
- [ ] `get_doc` MCP tool reads from Postgres
- [ ] `list_specs` MCP tool queries `spec_documents` by repo (single query, no N+1)
- [ ] Write operations (`create_spec`, `update_section_status`) update Postgres after GitHub write
- [ ] MCP tool latency for `list_specs` drops from seconds to <100ms

## 5. Cron Job Optimization

<!-- canon:system:5 status:done -->

<!-- canon:ticket:github:634 url:https://github.com/canonhq/canon-private/issues/634 -->
Reduce GitHub API pressure from cron jobs by having them read from the Postgres
content cache instead of fetching from GitHub.

### Cron Jobs to Rewrite

| Cron Job | Current | Target |
|----------|---------|--------|
| `sync_status.py` | Fetches specs from GitHub, updates status in GitHub | Read specs from Postgres, still write status to GitHub |
| `coverage_snapshot.py` | `load_repo_specs()` per repo from GitHub | Query `spec_documents` + `spec_sections` from Postgres |
| `stale_specs.py` | Loads specs via GitHub | Query `spec_documents.synced_at` for staleness |
| `search/reindex.py` | Full GitHub crawl | Read from Postgres, only re-embed changed content |

The content reconciliation cron (Section 2) remains the only cron that fetches
from GitHub. All other crons read from Postgres.

### Acceptance Criteria

- [ ] `coverage_snapshot` cron reads from Postgres, zero GitHub API calls
- [ ] `stale_specs` cron reads from Postgres, zero GitHub API calls
- [ ] `search/reindex.py` reads content from Postgres instead of GitHub
- [ ] `sync_status` reads specs from Postgres (still writes status changes to GitHub)
- [ ] Total GitHub API calls from cron jobs reduced by >90%

## 6. OpenSearch Cluster — Infrastructure & Setup

<!-- canon:system:6 status:done -->

<!-- canon:ticket:github:635 url:https://github.com/canonhq/canon-private/issues/635 -->
Deploy a managed OpenSearch cluster for search, aggregations, and vector
retrieval. This replaces pgvector + ParadeDB BM25 as the search backend.

### Infrastructure

Deploy an OpenSearch Service cluster (AWS or DigitalOcean managed) with:
- 2 data nodes (for redundancy)
- OpenSearch 2.x with k-NN plugin enabled
- Encryption at rest and in transit
- VPC/private networking to the Canon K8s cluster

Terraform module in `infra/opensearch/` for provisioning.

### Index Design

**`canon-specs` index** — one document per spec:
```json
{
  "mappings": {
    "properties": {
      "repo": { "type": "keyword" },
      "owner": { "type": "keyword" },
      "path": { "type": "keyword" },
      "title": { "type": "text", "analyzer": "standard" },
      "status": { "type": "keyword" },
      "team": { "type": "keyword" },
      "tags": { "type": "keyword" },
      "doc_type": { "type": "keyword" },
      "raw_markdown": { "type": "text", "analyzer": "standard" },
      "content_hash": { "type": "keyword" },
      "synced_at": { "type": "date" },
      "embedding": {
        "type": "knn_vector",
        "dimension": 1024,
        "method": { "name": "hnsw", "engine": "nmslib" }
      }
    }
  }
}
```

**`canon-sections` index** — one document per section:
```json
{
  "mappings": {
    "properties": {
      "spec_repo": { "type": "keyword" },
      "spec_path": { "type": "keyword" },
      "spec_title": { "type": "text" },
      "heading": { "type": "text", "analyzer": "standard" },
      "level": { "type": "integer" },
      "body": { "type": "text", "analyzer": "standard" },
      "status": { "type": "keyword" },
      "ticket_ref": { "type": "keyword" },
      "team": { "type": "keyword" },
      "tags": { "type": "keyword" },
      "embedding": {
        "type": "knn_vector",
        "dimension": 1024,
        "method": { "name": "hnsw", "engine": "nmslib" }
      }
    }
  }
}
```

### Configuration

Add to `settings.py`:
- `OPENSEARCH_URL` — cluster endpoint
- `OPENSEARCH_USERNAME` / `OPENSEARCH_PASSWORD` — auth credentials
- `OPENSEARCH_SPECS_INDEX` — index name (default: `canon-specs`)
- `OPENSEARCH_SECTIONS_INDEX` — index name (default: `canon-sections`)
- `OPENSEARCH_ENABLED` — feature flag to toggle (default: `False`)

### Acceptance Criteria

- [ ] Terraform module provisions OpenSearch cluster with k-NN plugin
- [x] `canon-specs` and `canon-sections` indexes created with correct mappings
<!-- canon:realized-in:PR#640 file:src/canon/search/opensearch_client.py -->
- [x] Settings include `OPENSEARCH_URL`, credentials, index names, and feature flag
- [ ] OpenSearch cluster accessible from Canon K8s pods via private networking
- [x] Health check endpoint verifies OpenSearch connectivity
<!-- canon:realized-in:PR#640 file:src/canon/main.py -->

## 7. OpenSearch Sync Pipeline

<!-- canon:system:7 status:done -->

<!-- canon:ticket:github:636 url:https://github.com/canonhq/canon-private/issues/636 -->
Build a pipeline that syncs spec content from PostgreSQL to OpenSearch, keeping
the search index eventually consistent with the source of truth.

### Sync Strategy

**Event-driven (primary):** After the push webhook upserts content into Postgres
(Section 2), dispatch an async task to index the affected spec(s) into
OpenSearch. Use the existing `BackgroundIndexer` pattern — extend it to write to
OpenSearch in addition to (or instead of) Postgres search tables.

**Bulk reconciliation (secondary):** A cron job (`cron/opensearch_reconcile.py`)
runs hourly, compares `spec_documents.content_hash` against OpenSearch
`content_hash` fields, and re-indexes any mismatches.

**Embedding generation:** Continue using Vertex AI `gemini-embedding-001` for
embeddings. During the transition, generate embeddings in the indexing step and
write them directly to OpenSearch — skip writing to pgvector columns. Once
OpenSearch search is stable, drop the pgvector `embedding` columns from
`spec_documents` and `spec_sections` (see Section 8).

**Rationale for dropping pgvector:** Embeddings are purely a search concern.
The Postgres content cache serves raw markdown and parsed sections — it doesn't
need vector columns. Maintaining embeddings in two stores adds complexity and
storage cost with no benefit.

### OpenSearch Client Module

New module `src/canon/search/opensearch_client.py`:
- `OpenSearchClient` class wrapping `opensearch-py`
- Methods: `index_spec()`, `index_sections()`, `delete_spec()`, `bulk_index()`
- Respects `OPENSEARCH_ENABLED` feature flag — no-ops when disabled

### Acceptance Criteria

- [x] Push webhook triggers async OpenSearch indexing after Postgres upsert
<!-- canon:realized-in:PR#640 file:src/canon/github/handlers/on_push.py -->
- [x] Bulk reconciliation cron detects and fixes content_hash mismatches
<!-- canon:realized-in:PR#640 file:src/canon/cron/opensearch_reconcile.py -->
- [x] Embeddings written directly to OpenSearch, skipping pgvector columns
<!-- canon:realized-in:PR#640 file:src/canon/search/indexer.py -->
- [x] `OpenSearchClient` respects `OPENSEARCH_ENABLED` feature flag
- [x] Bulk indexing uses OpenSearch `_bulk` API for efficiency
- [x] Deleted specs are removed from OpenSearch during reconciliation

## 8. Search Migration — Postgres to OpenSearch

<!-- canon:system:8 status:done -->

<!-- canon:ticket:github:637 url:https://github.com/canonhq/canon-private/issues/637 -->
Migrate the search query path from PostgreSQL (pgvector + ParadeDB BM25) to
OpenSearch, with a feature-flag-controlled cutover.

### Search Interface Abstraction

Create `src/canon/search/backend.py` with a `SearchBackend` protocol. Also ships `src/canon/search/parity.py` with `compare_query` / `compare_corpus` helpers and `scripts/search_parity.py` CLI for cutover validation.:
```python
class SearchBackend(Protocol):
    async def hybrid_search(self, query: str, embedding: list[float], ...) -> list[SearchResult]: ...
    async def facet_counts(self, filters: dict) -> dict[str, list[FacetBucket]]: ...
    async def get_related(self, spec_path: str, ...) -> list[SearchResult]: ...
```

Implementations:
- `PostgresSearchBackend` — wraps existing `SearchIndex` (default)
- `OpenSearchBackend` — wraps `OpenSearchClient` (enabled by feature flag)

The web services and MCP tools call the backend protocol, not a specific
implementation. Switching is controlled by `OPENSEARCH_ENABLED`.

### OpenSearch Search Features

- **Hybrid search:** OpenSearch native BM25 + kNN script scoring (no RRF shim)
- **Faceted aggregations:** Status, repo, team, tag facets via OpenSearch `terms` aggregations
- **Highlighting:** Search result snippets with matched terms highlighted
- **Autocomplete:** Prefix/edge-ngram suggestions for spec titles and headings
- **Related specs:** kNN search on spec embeddings for "similar specs" feature

### Acceptance Criteria

- [x] `SearchBackend` protocol abstracts search implementation
<!-- canon:realized-in:PR#640 file:src/canon/search/backend.py -->
- [x] `PostgresSearchBackend` wraps existing `SearchIndex` with no behavior change
- [x] `OpenSearchBackend` implements hybrid search (BM25 + kNN)
- [x] Feature flag `OPENSEARCH_ENABLED` toggles between backends at runtime
- [x] Faceted aggregations return status, repo, team, and tag counts
- [x] Search result highlighting returns matched term snippets
- [x] Related specs feature uses kNN on spec embeddings
- [ ] pgvector `embedding` columns dropped from `spec_documents` and `spec_sections` after OpenSearch cutover
- [ ] ParadeDB BM25 index (`idx_spec_sections_bm25`) dropped after OpenSearch cutover

## 9. GraphRAG Foundation

<!-- canon:system:9 status:done -->

<!-- canon:ticket:github:638 url:https://github.com/canonhq/canon-private/issues/638 -->
Lay the groundwork for GraphRAG-style retrieval by modeling cross-spec
relationships in OpenSearch and enabling multi-hop semantic queries.

### Relationship Extraction

Specs already contain explicit cross-references:
- `depends_on` frontmatter field (list of spec paths)
- `<!-- canon:ticket:{system}:{id} -->` comments linking to tickets
- Section-level `ticket_ref` fields
- `realized_in` references to PRs

Build a relationship extraction step in the indexing pipeline that:
1. Parses `depends_on` to create spec→spec edges
2. Extracts shared tags/team/owner for implicit relationships
3. Stores relationships as nested objects in OpenSearch

### OpenSearch Relationship Model

Add to `canon-specs` index:
```json
{
  "relationships": {
    "type": "nested",
    "properties": {
      "target_path": { "type": "keyword" },
      "rel_type": { "type": "keyword" },
      "strength": { "type": "float" }
    }
  }
}
```

Relationship types: `depends_on`, `depended_by`, `same_team`, `shared_tag`,
`shared_ticket`, `semantically_similar`.

### Semantic Similarity Links

During indexing, compute cosine similarity between spec embeddings. If
similarity exceeds a threshold (e.g., 0.85), create a `semantically_similar`
relationship. This enables multi-hop queries like "find all specs related to
authentication" that follow both explicit and semantic links.

### Graph Query API

New endpoint `GET /api/graph` and MCP tool `get_spec_graph`:
- Input: spec path or search query
- Output: subgraph of related specs (nodes + edges) within N hops
- Filters: relationship type, minimum strength, team, status

### Acceptance Criteria

- [ ] Indexing pipeline extracts `depends_on` relationships from frontmatter
- [ ] Shared tag/team/owner relationships computed during indexing
- [ ] Relationships stored as nested objects in OpenSearch `canon-specs` index
- [ ] Semantic similarity links computed for spec pairs above cosine threshold
- [x] `get_spec_graph` MCP tool returns subgraph of related specs
<!-- canon:realized-in:PR#640 file:src/canon/mcp/server.py -->
- [ ] Graph API endpoint supports hop-depth, relationship type, and strength filters
- [ ] Agent prompts can use graph context for cross-spec reasoning

## 10. Monitoring & Observability

<!-- canon:system:10 status:done -->

<!-- canon:ticket:github:582 url:https://github.com/canonhq/canon-private/issues/582 -->
Ensure the new caching and search infrastructure is observable with metrics,
alerts, and health checks.

### Metrics

- `canon_sync_github_api_calls_total` — counter of GitHub API calls (should decrease dramatically)
- `canon_sync_postgres_cache_hits` / `_misses` — cache effectiveness
- `canon_sync_reconciliation_duration_seconds` — time for full reconciliation cron
- `canon_sync_specs_stale_count` — number of specs with `synced_at` older than 1 hour
- `canon_opensearch_index_latency_seconds` — time to index a spec into OpenSearch
- `canon_opensearch_search_latency_seconds` — search query latency
- `canon_dashboard_load_time_seconds` — end-to-end dashboard page load time

### Health Checks

Extend existing `/health` endpoint:
- Postgres connectivity (already exists)
- OpenSearch connectivity (when enabled)
- Content sync freshness: alert if any repo's `last_full_sync_at` > 2 hours ago
- Search index freshness: alert if OpenSearch doc count diverges from Postgres by >5%

### Acceptance Criteria

- [ ] GitHub API call counter metric tracks actual calls (expect >90% reduction)
- [ ] Postgres cache hit/miss ratio visible in metrics
- [x] OpenSearch health included in `/health` endpoint when enabled
- [ ] Alert fires when content sync staleness exceeds 2 hours for any repo
- [ ] Dashboard load time metric tracks actual improvement

## 11. Migration & Rollout Plan

<!-- canon:system:11 status:done -->

<!-- canon:ticket:github:408 url:https://github.com/canonhq/canon-private/issues/408 -->
Phased rollout to minimize risk and allow incremental validation.

### Phase 1: Postgres Content Cache (Sections 2–5)

**Goal:** Eliminate GitHub API calls from dashboard, MCP, and crons.

1. Run database migration to add new columns/tables
2. Deploy content reconciliation cron — populates Postgres from GitHub
3. Wait for full sync to complete across all orgs
4. Deploy read-path changes behind feature flag `CONTENT_CACHE_ENABLED`
5. Enable for internal org first, monitor GitHub API call metrics
6. Enable for all orgs, remove feature flag

**Rollback:** Disable `CONTENT_CACHE_ENABLED` — reads fall back to GitHub.

### Phase 2: OpenSearch Deployment (Sections 6–8)

**Goal:** Better search quality, faceted aggregations, scalable vector search.

1. Provision OpenSearch cluster via Terraform
2. Deploy sync pipeline — begins populating OpenSearch from Postgres
3. Wait for full index to build
4. Deploy `OpenSearchBackend` behind `OPENSEARCH_ENABLED` flag
5. A/B test search quality: compare result relevance between Postgres and OpenSearch
6. Cut over search to OpenSearch
7. Drop pgvector `embedding` columns and ParadeDB BM25 index from Postgres
8. Remove `opensearch-py` feature flag — OpenSearch becomes the sole search backend

**Rollback:** Disable `OPENSEARCH_ENABLED` — search falls back to Postgres.
Rollback is available until step 7 (pgvector drop). After that, OpenSearch is
the sole search backend.

### Phase 3: GraphRAG (Section 9)

**Goal:** Cross-spec semantic retrieval and relationship navigation.

1. Deploy relationship extraction in indexing pipeline
2. Build and test graph query API
3. Integrate graph context into agent prompts
4. Iterate on relationship types and similarity thresholds

### Acceptance Criteria

- [ ] Phase 1 deployable independently with feature flag rollback
- [x] Phase 2 deployable independently with feature flag rollback
- [ ] Phase 3 deployable independently (additive, no rollback needed)
- [x] Zero-downtime migration — no service interruption during any phase
- [ ] GitHub API call volume drops >90% after Phase 1 rollout
