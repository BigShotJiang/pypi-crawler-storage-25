# Canon Rebrand Phase 2 — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Rename Specwright → Canon across all code, config, CLI, web, MCP, skills, Helm chart, and docs in a single branch.

**Architecture:** This is a mechanical rename executed in dependency order: module rename first (breaks imports), then fix imports, then update user-facing strings, then config/infra files. Each task produces a passing test suite before moving to the next.

**Tech Stack:** Python 3.12, FastAPI, Vue 3, Helm, Claude Code plugin system

**Branch:** `feat/canon-rebrand`

**Important:** After EVERY task, run `uv run ruff check src/ tests/` and `uv run pytest` to verify nothing is broken. Do NOT proceed to the next task if tests fail.

---

### Task 1: Create branch and rename module directory

**Files:**
- Rename: `src/specwright/` → `src/canon/`

**Step 1: Create feature branch**

```bash
git checkout -b feat/canon-rebrand
```

**Step 2: Rename the module directory**

```bash
mv src/specwright src/canon
```

**Step 3: Commit the rename (tests will be broken — that's expected)**

```bash
git add -A
git commit -m "refactor: rename src/specwright/ → src/canon/"
```

---

### Task 2: Update all Python imports

**Files:**
- Modify: Every `.py` file under `src/canon/` and `tests/`

**Step 1: Find-and-replace all imports in src/**

```bash
find src/canon -name '*.py' -exec sed -i 's/from specwright\./from canon./g; s/import specwright\./import canon./g; s/from specwright /from canon /g; s/import specwright$/import canon/g' {} +
```

**Step 2: Find-and-replace all imports in tests/**

```bash
find tests -name '*.py' -exec sed -i 's/from specwright\./from canon./g; s/import specwright\./import canon./g; s/from specwright /from canon /g; s/import specwright$/import canon/g' {} +
```

**Step 3: Fix any remaining "specwright" references in Python string literals that are import paths**

Check for and fix:
- `"specwright.main:app"` → `"canon.main:app"` (Dockerfile, uvicorn command)
- `"specwright.cli:main"` → `"canon.cli:main"` (pyproject.toml)
- Any `importlib` or dynamic imports referencing `specwright`

```bash
grep -rn "specwright" src/canon/ --include='*.py' | grep -v '# ' | head -40
```

Manually fix any remaining references that are module paths (not user-facing strings — those come in Task 5).

**Step 4: Run tests**

```bash
uv run ruff check src/ tests/ --fix
uv run pytest -x
```

**Step 5: Commit**

```bash
git add -A
git commit -m "refactor: update all Python imports specwright → canon"
```

---

### Task 3: Update pyproject.toml and build config

**Files:**
- Modify: `pyproject.toml`
- Modify: `ruff.toml`

**Step 1: Update pyproject.toml**

Changes needed:
```toml
[project]
name = "canonhq"
description = "Canon — spec-driven development platform"

[project.urls]
Homepage = "https://canonhq.co"
Repository = "https://github.com/canonhq/canon"
Issues = "https://github.com/canonhq/canon/issues"

[project.scripts]
canon = "canon.cli:main"
canon-mcp = "canon.mcp.__main__:main"

[tool.hatch.build.targets.wheel]
packages = ["src/canon"]

[tool.hatch.build.targets.wheel.force-include]
"plugin/skills" = "canon/plugin_data/skills"

[tool.coverage.run]
source = ["canon"]

[tool.coverage.paths]
source = ["src/canon", "*/canon"]
```

**Step 2: Update ruff.toml**

```toml
[lint.isort]
known-first-party = ["canon"]
```

**Step 3: Rebuild venv**

```bash
uv sync --extra dev
```

**Step 4: Run tests**

```bash
uv run ruff check src/ tests/
uv run pytest -x
```

**Step 5: Commit**

```bash
git add pyproject.toml ruff.toml uv.lock
git commit -m "refactor: update pyproject.toml and ruff config for canonhq"
```

---

### Task 4: Update Dockerfile

**Files:**
- Modify: `Dockerfile`

**Step 1: Update Dockerfile**

Changes:
- Line 44: `specwright` user/group → `canon`
- Line 69: `specwright.main:app` → `canon.main:app`

```dockerfile
RUN groupadd -r canon -g 1001 && \
    useradd -r -g canon -u 1001 -d /app canon

ENTRYPOINT ["uvicorn", "canon.main:app", "--host", "0.0.0.0", "--port", "3000", "--proxy-headers", "--forwarded-allow-ips", "*"]
```

**Step 2: Commit**

```bash
git add Dockerfile
git commit -m "refactor: update Dockerfile for canon module"
```

---

### Task 5: Update user-facing strings in Python source

**Files:**
- Modify: All files under `src/canon/` that contain user-facing "Specwright" or "specwright" strings

**Step 1: Update CLI description and branding**

Key files and changes:
- `src/canon/cli/__init__.py`: `prog = "canon"`, description = `"Canon — Spec-driven development platform"`
- `src/canon/cli/login.py`: Help text referencing `specwright` → `canon`, URL → `https://canonhq.co`
- `src/canon/cli/_platform.py`: `_DEFAULT_URL = "https://canonhq.co"`
- `src/canon/cli/setup_cmd.py`: References to `SPECWRIGHT.yaml` → `CANON.yaml`
- `src/canon/cli/_local.py`: Config filename references
- `src/canon/cli/sync_cmd.py`: Any user-facing strings

**Step 2: Update config references**

- `src/canon/config/__init__.py`: `SPECWRIGHT_YAML` → `CANON_YAML` constant, add fallback for old name
- `src/canon/config/parse.py`: Config filename references, add backwards compatibility

The config parser should:
1. Look for `CANON.yaml` first
2. Fall back to `SPECWRIGHT.yaml` if found
3. Print a deprecation notice when using the old name

**Step 3: Update spec comment markers**

The parser must handle BOTH old and new formats:
- `src/canon/parser/parse.py`: Parse both `<!-- specwright:system:N -->` and `<!-- canon:system:N -->`
- `src/canon/parser/writer.py`: Write new comments as `<!-- canon:system:N -->` and `<!-- canon:ticket:... -->`
- Keep parsing old format for backwards compatibility

**Step 4: Update agent/bot strings**

- `src/canon/agent/analyzer.py`: `<!-- specwright-bot -->` → `<!-- canon-bot -->`, footer `specwright ·` → `canon ·`
- `src/canon/agent/prompts.py`: Any references to "Specwright" in prompts
- `src/canon/github/client.py`: Bot username references
- `src/canon/github/handlers/on_issue_comment.py`: Bot detection
- `src/canon/github/handlers/on_pull_request.py`: Bot references
- `src/canon/github/handlers/on_pull_request_merged.py`: Bot references

**Step 5: Update web/template strings**

- `src/canon/web/routes.py`: Meta titles, descriptions (`"Specwright"` → `"Canon"`)
- `src/canon/web/render.py`: Any brand references
- `src/canon/github/handlers/onboarding.py`: Specwright docs URL → `https://canonhq.co`
- `src/canon/sync/templates.py`: `Managed by Specwright` → `Managed by Canon`, URL update
- `src/canon/setup.py`: Config URL comment

**Step 6: Update MCP server**

- `src/canon/mcp/server.py`: Server name `"Specwright"` → `"Canon"`, description update

**Step 7: Update remaining references**

```bash
grep -rn "specwright\|Specwright\|SPECWRIGHT" src/canon/ --include='*.py'
```

Fix any remaining references (except backwards-compat parsing of old comment format).

**Step 8: Run tests and fix any broken assertions**

```bash
uv run ruff check src/ tests/ --fix
uv run pytest -x
```

Tests may fail due to hardcoded "specwright" strings in assertions. Update test expectations to match new strings.

**Step 9: Commit**

```bash
git add -A
git commit -m "feat: update all user-facing strings to Canon branding"
```

---

### Task 6: Update test assertions and fixtures

**Files:**
- Modify: Files under `tests/` with hardcoded "specwright" strings in assertions or fixtures

**Step 1: Find all test references**

```bash
grep -rn "specwright\|Specwright\|SPECWRIGHT" tests/ --include='*.py' | grep -v "^.*:.*import "
```

**Step 2: Update test assertions**

Common patterns to update:
- `"specwright-bot"` → `"canon-bot"` in bot detection tests
- `"SPECWRIGHT.yaml"` → `"CANON.yaml"` in config tests (keep old name tests for backwards compat)
- `"specwright:system:"` → handle both old and new in parser tests
- `"specwright.gernerventures.com"` → `"canonhq.co"` in URL tests
- Mock paths like `"specwright.X.Y"` → `"canon.X.Y"`

**Step 3: Run full test suite**

```bash
uv run pytest -v
```

**Step 4: Commit**

```bash
git add -A
git commit -m "test: update test assertions for Canon branding"
```

---

### Task 7: Update Vue SPA marketing components

**Files:**
- Modify: All `.vue` files under `frontend/src/` containing "Specwright" or "specwright"

**Step 1: Find all Vue references**

```bash
grep -rn "specwright\|Specwright\|SPECWRIGHT" frontend/src/ --include='*.vue' --include='*.ts' --include='*.js'
```

**Step 2: Update all components**

Key changes:
- `HeroSection.vue`: Tagline → "The source of truth for what you're building."
- `MarketingNav.vue`: Wordmark → "Canon"
- `MarketingFooter.vue`: "Specwright — an experiment by Gerner Ventures" → "Canon" (or "Canon by Gerner Ventures")
- `CapabilitiesGrid.vue`: "Specwright" → "Canon" in all feature descriptions
- `PricingSection.vue`: "Specwright" → "Canon"
- `CtaSection.vue`: "Specwright" → "Canon"
- All GitHub App URLs: `github.com/apps/gv-specwright` → `github.com/apps/canonhq`

**Step 3: Update any TypeScript/JS files**

```bash
grep -rn "specwright" frontend/src/ --include='*.ts' --include='*.js'
```

**Step 4: Commit**

```bash
git add frontend/
git commit -m "feat: rebrand Vue SPA marketing components to Canon"
```

---

### Task 8: Update HTML templates

**Files:**
- Modify: `templates/base.html`
- Modify: `templates/welcome.html`
- Modify: `templates/landing.html` (or delete)
- Modify: `templates/404.html`
- Modify: `templates/500.html`

**Step 1: Update all templates**

- Replace all "Specwright" → "Canon"
- Replace all `specwright.gernerventures.com` → `canonhq.co`
- Replace `github.com/apps/gv-specwright` → `github.com/apps/canonhq`
- Replace `github.com/Gerner-Ventures/gv-exp-specwright` → `github.com/canonhq/canon`
- Footer: Remove "experiment" language

**Step 2: Commit**

```bash
git add templates/
git commit -m "feat: rebrand HTML templates to Canon"
```

---

### Task 9: Update Claude Code plugin and skills

**Files:**
- Modify: `plugin/.claude-plugin/plugin.json`
- Modify: `plugin/settings.json`
- Rename: `plugin/skills/sw-*` → `plugin/skills/canon-*`
- Modify: All `SKILL.md` files in skills

**Step 1: Update plugin manifest**

`plugin/.claude-plugin/plugin.json`:
```json
{
  "name": "canon",
  "description": "Spec-driven development — verify code against specs, track coverage, maintain living docs",
  "version": "0.1.0",
  "author": { "name": "Gerner Ventures" },
  "repository": "https://github.com/canonhq/canon",
  "license": "MIT",
  "category": "development",
  "keywords": ["specs", "documentation", "verification", "coverage", "sdd"],
  "mcpServers": "../.mcp.json"
}
```

**Step 2: Update settings.json**

`plugin/settings.json` — rename the key from `"specwright"` to `"canon"`:
```json
{
  "canon": {
    "spec_paths": ["docs/specs/*.md"],
    "doc_paths": ["docs/**/*.md", "*.md"],
    "auto_context": true,
    "write_back": true
  }
}
```

**Step 3: Rename skill directories**

```bash
cd plugin/skills
for dir in sw-*; do
  new_name="canon-${dir#sw-}"
  mv "$dir" "$new_name"
done
```

This renames:
- `sw-audit` → `canon-audit`
- `sw-context` → `canon-context`
- `sw-new` → `canon-new`
- `sw-plan` → `canon-plan`
- `sw-review` → `canon-review`
- `sw-status` → `canon-status`
- `sw-task` → `canon-task`
- `sw-update` → `canon-update`
- `sw-verify` → `canon-verify`

**Step 4: Update all SKILL.md files**

In every skill's `SKILL.md`:
- Replace `mcp__specwright__` → `mcp__canon__`
- Replace `specwright:system:` → `canon:system:` (in documentation examples)
- Replace `specwright:ticket:` → `canon:ticket:`
- Replace `/sw:` → `/canon:` (cross-references between skills)
- Replace `specwright plan` → `canon plan` (CLI references)

**Step 5: Update skill CLAUDE.md files if they exist**

**Step 6: Commit**

```bash
git add plugin/
git commit -m "feat: rebrand Claude Code plugin and skills to canon:*"
```

---

### Task 10: Rename and update Helm chart

**Files:**
- Rename: `chart/specwright/` → `chart/canon/`
- Modify: All files under `chart/canon/`

**Step 1: Rename chart directory**

```bash
mv chart/specwright chart/canon
```

**Step 2: Update Chart.yaml**

```yaml
name: canon
description: Canon — spec-driven development platform
```

**Step 3: Update _helpers.tpl**

Replace all `specwright.` template function names with `canon.`:
```bash
sed -i 's/specwright\./canon./g' chart/canon/templates/_helpers.tpl
```

**Step 4: Update all template files**

```bash
find chart/canon/templates -name '*.yaml' -exec sed -i 's/specwright\./canon./g' {} +
```

**Step 5: Update values files**

In `values.yaml` and `values-production.yaml`:
- Secret names: `specwright-*` → `canon-*`
- Hostnames: `specwright.gernerventures.com` → `canonhq.co`
- `platformUrl` → `https://canonhq.co`
- Image repository if referenced

In `values-preview.yaml`:
- Preview URL patterns

**Step 6: Update CI helm-lint references**

In `.github/workflows/ci.yml`:
- `chart/specwright/` → `chart/canon/`
- `specwright.gernerventures.com` → `canonhq.co`

**Step 7: Commit**

```bash
git add chart/ .github/
git commit -m "refactor: rename Helm chart specwright → canon"
```

---

### Task 11: Update CI/CD workflows

**Files:**
- Modify: `.github/workflows/deploy.yml`
- Modify: `.github/workflows/preview.yml`
- Modify: `.github/workflows/ci.yml`
- Modify: `.github/workflows/claude-code-review.yml`

**Step 1: Update deploy.yml**

- Doppler project: `specwright` → `canon`
- Namespace: `specwright` → `canon`
- Secret names: `specwright-*` → `canon-*`
- Helm release name: `specwright` → `canon`
- Docker image name: `specwright` → `canon`

**Step 2: Update preview.yml**

- Same changes as deploy.yml
- Preview namespace: `specwright-preview-N` → `canon-preview-N`
- Preview URL: `pr-N.specwright.gernerventures.com` → `pr-N.canonhq.co`

**Step 3: Update claude-code-review.yml**

- Bot username: `gv-specwright[bot]` → `canonhq[bot]`

**Step 4: Update ci.yml**

- Docker build tag: `specwright:ci` → `canon:ci`
- Helm lint paths

**Step 5: Commit**

```bash
git add .github/
git commit -m "refactor: update CI/CD workflows for canon"
```

---

### Task 12: Update documentation and github-app-manifest.json

**Files:**
- Modify: `README.md`
- Modify: `CLAUDE.md`
- Modify: `github-app-manifest.json`
- Modify: `docs/self-hosting.md`
- Modify: `docs/vision.md`
- Modify: `.claude/CLAUDE.md`

**Step 1: Update github-app-manifest.json**

```json
{
  "name": "Canon",
  "url": "https://github.com/canonhq/canon",
  "hook_attributes": {
    "url": "https://canonhq.co/webhook",
    "active": true
  },
  "redirect_url": "https://github.com/canonhq/canon",
  "description": "Spec-driven development platform — AI agents review PRs against specs, sync tickets, and verify code.",
  "public": true,
  ...
}
```

**Step 2: Rewrite README.md**

Replace the experiment-framed README with a product README:
- Title: "Canon"
- Tagline: "The source of truth for what you're building."
- What it does (3 bullets)
- Quick start (install, setup, first spec)
- Links to docs, GitHub App

**Step 3: Update CLAUDE.md**

Replace "Specwright" with "Canon" throughout. Update project description, commands, structure.

**Step 4: Update docs/**

- `docs/self-hosting.md`: URLs and references
- `docs/vision.md`: Update or add note about rename

**Step 5: Commit**

```bash
git add README.md CLAUDE.md github-app-manifest.json docs/ .claude/
git commit -m "docs: rebrand all documentation to Canon"
```

---

### Task 13: Update spec file frontmatter

**Files:**
- Modify: All `docs/specs/*.md` files

**Step 1: Update ticket_project in all specs**

```bash
find docs/specs -name '*.md' -exec sed -i 's/ticket_project: Gerner-Ventures\/gv-exp-specwright/ticket_project: canonhq\/canon/g' {} +
```

**Step 2: Commit**

```bash
git add docs/specs/
git commit -m "docs: update spec ticket_project fields to canonhq/canon"
```

---

### Task 14: Final verification

**Step 1: Run full lint**

```bash
uv run ruff check src/ tests/
uv run ruff format --check src/ tests/
```

**Step 2: Run full test suite**

```bash
uv run pytest -v
```

**Step 3: Grep for any remaining references**

```bash
grep -rn "specwright" src/ tests/ frontend/src/ chart/ plugin/ templates/ .github/ --include='*.py' --include='*.vue' --include='*.ts' --include='*.yaml' --include='*.yml' --include='*.toml' --include='*.html' --include='*.json' --include='*.md' --include='*.tpl' | grep -v 'canon-rebrand' | grep -v 'node_modules' | grep -v '.venv' | grep -v 'docs/plans/'
```

Any remaining references should be:
- Backwards-compat parsing of `<!-- specwright:system:N -->` in parser
- Config fallback for `SPECWRIGHT.yaml`
- Migration notices

Everything else should be `canon`.

**Step 4: Commit any final fixes**

```bash
git add -A
git commit -m "chore: final cleanup of specwright references"
```

---

## Task Dependency Order

```
Task 1 (rename dir) → Task 2 (fix imports) → Task 3 (pyproject) → Task 4 (Dockerfile)
    → Task 5 (user strings) → Task 6 (test assertions)
    → Task 7 (Vue SPA) [parallel with 5-6]
    → Task 8 (HTML templates) [parallel with 5-6]
    → Task 9 (plugin/skills) [parallel with 5-6]
    → Task 10 (Helm chart) [parallel with 5-6]
    → Task 11 (CI/CD) [after 10]
    → Task 12 (docs) [parallel with 5-6]
    → Task 13 (spec frontmatter)
    → Task 14 (final verification)
```

Tasks 5-10 and 12 can be parallelized across subagents after Tasks 1-4 complete sequentially.
