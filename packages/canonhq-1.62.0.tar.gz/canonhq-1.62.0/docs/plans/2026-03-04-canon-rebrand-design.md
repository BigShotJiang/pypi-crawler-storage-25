# Canon Rebrand & Experience Unification

**Date**: 2026-03-04
**Status**: Draft
**Author**: ng

## Overview

Rebrand Specwright → Canon across all public-facing surfaces. Canon is a spec-driven development platform — the source of truth for what your org is building. AI agents handle PR reviews, ticket sync, and code verification, keeping product, engineering, and business aligned.

## Brand Identity

| Attribute | Value |
|-----------|-------|
| Product name | Canon |
| Tagline | "The source of truth for what you're building." |
| One-liner | Canon is a spec-driven development platform. Write structured specs, and AI agents handle PR reviews, ticket sync, and code verification. |
| Voice | Clean, confident, concise. Product voice, not experiment voice. "Early access" not "experiment". |

## Namespace

| Surface | Old | New |
|---------|-----|-----|
| GitHub org | Gerner-Ventures | canonhq |
| GitHub repo | gv-exp-specwright | canonhq/canon |
| GitHub App slug | gv-specwright | canonhq |
| GitHub App name | Specwright | Canon |
| PyPI package | gv-specwright | canonhq |
| CLI command | specwright | canon |
| Python module | specwright | canon |
| Config file | SPECWRIGHT.yaml | CANON.yaml |
| MCP server | specwright | canon |
| Claude Code skills | sw:* | canon:* |
| Helm chart | specwright | canon |
| Domain | specwright.gernerventures.com | canonhq.co |

## Surface-by-Surface Changes

### 1. GitHub App

Create a new GitHub App under the `canonhq` org:
- Display name: "Canon"
- Slug: `canonhq` → `github.com/apps/canonhq`
- Description: "Spec-driven development platform — AI agents that review PRs against specs, sync tickets bidirectionally, and verify code matches your plan."
- New logo/icon
- Same permissions and events as current app
- Migrate existing installations via re-install flow

### 2. Marketing Website (Vue SPA)

- Update all component copy: "Specwright" → "Canon"
- Hero: "The source of truth for what you're building."
- Eyebrow: "Spec-driven development platform"
- Footer: "Canon" (optionally "by Gerner Ventures" in small print, drop "experiment" language)
- Nav wordmark: "Canon" with updated gradient
- Create OG image (currently referenced but missing at `/static/og-image.png`)
- Remove stale Jinja2 fallback `templates/landing.html`
- Update all GitHub App install URLs to `github.com/apps/canonhq`

### 3. CLI

- Entry point: `canon` (pyproject.toml `[project.scripts]`)
- Help text: `canon — Spec-driven development platform`
- Subcommands unchanged: `canon plan`, `canon verify`, `canon sync`, `canon status`, `canon start`, `canon done`, `canon audit`, `canon login`, `canon setup`
- Default server URL: `https://canonhq.co`
- `canon setup` creates `CANON.yaml`
- Add migration: detect `SPECWRIGHT.yaml`, prompt to rename

### 4. MCP Server

- Server name: `canon`
- Description: "Canon gives you access to your organization's spec documents and knowledge base. Specs are the source of truth — Canon keeps them in sync with code, tickets, and documentation."
- Entry point: `canon-mcp` (rename from `specwright-mcp`)
- Tool names stay generic: `search`, `get_spec`, `get_doc`, etc.

### 5. Claude Code Skills (Plugin)

- Prefix: `canon:` (from `sw:`)
- Skills: `canon:context`, `canon:verify`, `canon:plan`, `canon:status`, `canon:new`, `canon:update`, `canon:review`, `canon:task`, `canon:audit`
- Update all skill descriptions and internal references

### 6. Package & Distribution

- pyproject.toml: name=`canonhq`, update description, URLs, classifiers
- README.md: Complete rewrite as product README (not experiment brief)
- License: Keep MIT
- Helm chart: name=`canon`, update Chart.yaml metadata

### 7. Visual Identity

- Wordmark: "Canon" in Space Grotesk
- Icon: Geometric mark (design TBD — cornerstone/keystone concept)
- Colors: Keep emerald→cyan gradient, rename CSS vars to `--canon-*`
- OG image: Create with new branding

### 8. Onboarding

- Welcome page: Update copy, point to new GitHub App
- `canon setup`: Creates `CANON.yaml`, installs Claude Code skills
- Create `canonhq/example-specs` repo with starter templates
- Fix dead link in current welcome page

### 9. Internal Code Rename

Full rename `src/specwright/` → `src/canon/`:
- All imports: `from specwright.X` → `from canon.X`
- All test imports
- All references in config, Dockerfile, Helm chart, CI/CD

## Migration Strategy

### Phase 1: Foundation (no user impact)
- Register `canonhq` GitHub org
- Register `canonhq.co` domain
- Create new `canonhq` GitHub App
- Design icon/wordmark

### Phase 2: Code Rebrand (single large PR)
- Rename `src/specwright/` → `src/canon/`
- Update all user-facing strings, help text, config file names
- Add `SPECWRIGHT.yaml` → `CANON.yaml` migration support
- Update Vue SPA components
- Update pyproject.toml, Dockerfile, Helm chart
- Update all tests

### Phase 3: Infrastructure Cutover
- Deploy to `canonhq.co`
- Update DNS, TLS certs
- Configure `specwright.gernerventures.com` → redirect to `canonhq.co`
- Publish `canonhq` to PyPI
- Create/migrate to `canonhq/canon` repo

### Phase 4: GitHub App Migration
- Install new `canonhq` app on test org (njgerner)
- Install on Gerner-Ventures org
- Deprecate `gv-specwright` app
- Update all documentation referencing old app

## Availability Check (as of 2026-03-04)

| Resource | Status |
|----------|--------|
| PyPI `canonhq` | Available |
| GitHub org `canonhq` | Available |
| GitHub org `canon-dev` | Available |
| `canonhq.co` | No DNS records (likely available) |
| `canonhq.io` | WHOIS: not found (available) |
| `canonhq.com` | Registered (blockchain domain registrar) |
| PyPI `canon` | Taken (0.0.1 placeholder) |
| GitHub org `usecanon` | Taken (separate project, 0 stars) |

## Risks

1. **GitHub App slug immutability**: Current `gv-specwright` slug cannot be changed. Must create new app and migrate installations.
2. **PyPI package rename**: Existing `gv-specwright` users will need to `pip install canonhq` instead. Can publish a deprecation notice to old package.
3. **Domain**: `canonhq.com` is parked. `.dev` is the target but `.io` is backup.
4. **Canon trademark**: Canon Inc. (cameras) holds trademarks in imaging/electronics. Dev tools is a different class, but worth noting.
5. **Module rename scope**: ~250 Python files reference `specwright` internally. This is a large mechanical change but low risk with good test coverage.
