# Canon Rebrand Completion — Design

**Date**: 2026-03-08
**Status**: Approved

## Context

Infrastructure rebrand (DNS, Auth0, GCP, Helm) is complete. `canonhq.co` is live and serving traffic. This design covers the remaining app-level rebrand: docs site, source code, GitHub App migration, and package consistency.

## Approach

- **Backward compat strategy**: Deprecation path. Keep all dual-format patterns (`specwright|canon` HTML comments, `SPECWRIGHT.yaml` fallback, `specwright:*` status labels, `~/.config/specwright/` creds) but add deprecation warnings. Plan to remove later.
- **Docs site**: Move to `canonhq.co/docs` (already served by the same deployment).
- **GitHub App**: Migrate from `gv-specwright` to `canonhq`.
- **PyPI package**: Already `canonhq` — fix stale `gv-canon` reference in setup.py.

## Changes

### 1. Docs Site Branding (VitePress)

| File | Change |
|------|--------|
| `docs-site/.vitepress/config.ts` | `SITE_URL` → `https://canonhq.co/docs`, `title` → `"Canon"`, sitemap URL, edit links → `canonhq/canon` |
| `docs-site/public/robots.txt` | Update sitemap URL |
| `docs-site/package.json` | `specwright-docs` → `canon-docs` |
| `frontend/package.json` | `specwright-frontend` → `canon-frontend` |
| Nav config | `SPECWRIGHT.yaml` → `CANON.yaml` reference |

### 2. Docs Content

- All `docs-site/**/*.md`: Replace `specwright.gernerventures.com` → `canonhq.co`, `gv-exp-specwright` → `canonhq/canon`, product name refs
- `docs/specs/*.md`: `team: specwright` → `team: canon`, update issue links
- `docs/examples/*.md`: Update HTML comment examples to `canon:` prefix, note legacy support
- `docs-site/reference/config.md`: `SPECWRIGHT.yaml` → `CANON.yaml` as primary, add deprecation note

### 3. Source Code — Hard Renames (broken/wrong)

| File | Change |
|------|--------|
| `Makefile` | Docker image, Helm release/namespace, `specwright.main:app` → `canon.main:app`, `src/specwright` → `src/canon` |
| `Dockerfile.dev` | `src/specwright` → `src/canon`, entrypoint fix |
| `src/canon/setup.py` | `gv-canon` → `canonhq` in MCP config |
| `src/canon/web/routes.py` | GitHub App install URL `gv-canon` → `canonhq` |

### 4. Source Code — Deprecation Warnings

| Area | Approach |
|------|----------|
| `config/parse.py` | Add `CanonConfig` / `parse_canon_yaml` as primary names, keep old names with `warnings.warn(..., DeprecationWarning)` |
| `cli/_credentials.py` | Prefer `~/.config/canon/`, auto-migrate from `~/.config/specwright/` with warning |
| `cli/_platform.py` | Keep `SPECWRIGHT_URL` fallback, log deprecation |
| `sync/status_map.py` | Keep `specwright:*` label mapping, log deprecation when matched |
| `auth/device_routes.py` | Keep `specwright.dev` claim fallback (already done for routes.py) |

### 5. Static Assets & UI

| File | Change |
|------|--------|
| `static/brand.css` | Update header comment |
| `static/editor.js` | Commit messages → `Canon editor`, keep dual HTML comment parsing |
| `scripts/setup-github-app.sh` | Update to Canon branding |

### 6. GitHub App Migration

1. Create `canonhq` GitHub App with same permissions/events as `gv-specwright`
2. Install on Gerner-Ventures org
3. Update K8s secrets: `GH_APP_ID`, `GH_PRIVATE_KEY`, `GH_WEBHOOK_SECRET`
4. Update all install URLs in code → `https://github.com/apps/canonhq/installations/new`
5. Decommission `gv-specwright` app after verification

### 7. Tests

- Update test fixtures using old domain/names where they test new behavior (not backward compat paths)

## Not Changing

- HTML comment parsing regexes (dual `specwright|canon`) — backward compat
- `SPECWRIGHT.yaml` fallback loading — kept with deprecation warning
- Legacy status labels — kept with deprecation logging
- Terraform state key (`experiments/specwright/`) — intentionally preserved
- GCP `account_id` (`specwright-embeddings`) — immutable
