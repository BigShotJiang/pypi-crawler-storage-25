# Preview Deployments for Spec Explorer

**Date:** 2026-03-04
**Spec:** docs/specs/pr-comment-enhancements.md, Section 3
**Branch:** feat/pr-comment-enhancements

## Summary

Deploy ephemeral previews of the Spec Explorer web UI for PRs that modify frontend/template files. Previews run on the existing DOKS cluster in per-PR namespaces, use production data (read-only), and authenticate via the production Auth0 tenant.

## Architecture

```
PR opened/updated (templates/static/frontend/web changes)
  -> GitHub Actions: preview.yml
    -> Build Docker image (same Dockerfile, tag: pr-{number})
    -> Push to DO registry
    -> helm upgrade --install in namespace specwright-preview-{pr_number}
    -> Create GitHub deployment status with preview URL
    -> Post preview_url to Specwright bot comment footer

PR closed/merged
  -> GitHub Actions: preview.yml (pull_request: closed)
    -> kubectl delete namespace specwright-preview-{pr_number}
    -> Delete preview Docker image tag from DOCR
    -> Delete GitHub environment
```

## Key Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Hosting | K8s ephemeral namespace on DOKS | Reuses existing Helm chart and cluster |
| Auth | Production Auth0 tenant | Consistent auth experience; wildcard callback URL |
| Data source | Production DB (read-only) | Web UI is read-only; no write risk |
| DNS | Wildcard subdomain | `*.specwright.gernerventures.com` already needed for DevSpace |
| Cleanup | Delete namespace on PR close | Cascades all resources cleanly |

## Files to Create/Modify

### This repo (gv-exp-specwright)

| File | Action | Purpose |
|------|--------|---------|
| `.github/workflows/preview.yml` | Create | Preview deploy + cleanup workflow |
| `chart/specwright/values-preview.yaml` | Create | Helm override for preview deploys |
| `src/specwright/github/handlers/on_pull_request.py` | Modify | Pass `preview_url` to `format_analysis_comment` |
| `docs/specs/pr-comment-enhancements.md` | Modify | Update section statuses and check ACs |

### gv-infra repo (separate PR)

| Item | Action | Detail |
|------|--------|--------|
| Wildcard DNS | Add/verify | `*.specwright.gernerventures.com -> DOKS ingress IP` |
| Auth0 callback URL | Add | `https://pr-*.specwright.gernerventures.com/auth/callback` to Allowed Callback URLs |
| Wildcard TLS cert | Verify | cert-manager should handle via wildcard ingress or per-preview cert |

## Preview Workflow (`preview.yml`)

### Triggers

```yaml
on:
  pull_request:
    types: [opened, synchronize, reopened, closed]
    paths:
      - 'templates/**'
      - 'static/**'
      - 'frontend/**'
      - 'src/specwright/web/**'
```

> **Note:** Using a single `pull_request` trigger (not `pull_request_target`) ensures
> the `paths` filter applies to both deploy and cleanup jobs. The tradeoff is that if
> matching files are reverted before the PR closes, the cleanup job won't fire and the
> namespace will be orphaned until manually reaped.

### Deploy Steps

1. Checkout code
2. Build Docker image: `specwright:pr-{number}`
3. Push to `registry.digitalocean.com/gv-shared/specwright:pr-{number}`
4. Create GitHub deployment (environment: `preview-pr-{number}`, status: `in_progress`)
5. Create namespace `specwright-preview-{number}` if not exists
6. Pull secrets from Doppler (`specwright/prd`)
7. `helm upgrade --install` with `values-preview.yaml` + `--set ingress.host=pr-{number}.specwright.gernerventures.com` + `--set env.PLATFORM_URL=https://pr-{number}.specwright.gernerventures.com`
8. Wait for rollout
9. Update GitHub deployment status to `success` with `environment_url`

### Cleanup Steps (on PR close)

1. `kubectl delete namespace specwright-preview-{number}` (cascades everything)
2. `doctl registry repository delete-tag specwright pr-{number}` (remove DOCR image)
3. Delete GitHub environment via API

## Values Override (`values-preview.yaml`)

```yaml
replicaCount: 1

ingress:
  host: ""  # set via --set at deploy time
  tls:
    enabled: true
    issuer: letsencrypt-production

resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    memory: 256Mi

cronJob:
  enabled: false
reindexCronJob:
  enabled: false
staleCronJob:
  enabled: false
coverageCronJob:
  enabled: false
```

## Auth0 Configuration

Add wildcard to the Auth0 app's "Allowed Callback URLs":

```
https://pr-*.specwright.gernerventures.com/auth/callback
```

This is a one-time config change in the Auth0 dashboard (or via gv-infra Terraform).

## Preview URL in Bot Comments

The `format_analysis_comment()` function already accepts a `preview_url` parameter and renders it in the footer as `[preview](url)`. The `on_pull_request` handler needs to detect whether a preview exists for the current PR and pass the URL.

Approach: check for an active GitHub deployment with environment `preview-pr-{number}` via the GitHub API. If found, extract the `environment_url` and pass it as `preview_url`.

## Acceptance Criteria Mapping

| AC | Implementation |
|----|----------------|
| PRs modifying templates/static trigger preview | `preview.yml` path filters |
| Preview URL is accessible and shows updated UI | Helm deploy + ingress + DNS |
| Preview connects to production data source | Same `DATABASE_URL` from Doppler |
| Preview deployments cleaned up after merge/close | `pull_request: closed` -> namespace + image delete |
| Preview URL posted as deployment status or PR comment | GitHub Deployments API + bot comment footer |
