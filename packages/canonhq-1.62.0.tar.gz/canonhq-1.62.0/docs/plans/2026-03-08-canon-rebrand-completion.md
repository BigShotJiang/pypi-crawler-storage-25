# Canon Rebrand Completion — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Complete the Specwright → Canon rebrand across docs site, source code, static assets, and GitHub App references.

**Architecture:** Batch find-and-replace for branding changes, targeted edits for deprecation warnings, manual GitHub App creation. Seven independent task groups that can be committed separately.

**Tech Stack:** VitePress (docs), Python/FastAPI (backend), Vue 3 (frontend), GitHub Apps API

---

### Task 1: Docs Site Branding (VitePress config + package names)

**Files:**
- Modify: `docs-site/.vitepress/config.ts`
- Modify: `docs-site/public/robots.txt`
- Modify: `docs-site/package.json`
- Modify: `frontend/package.json`

**Step 1: Update VitePress config**

In `docs-site/.vitepress/config.ts`:
- Line 4: `const SITE_URL = "https://specwright.gernerventures.com/docs"` → `const SITE_URL = "https://canonhq.co/docs"`
- Line 8: `title: "Specwright"` → `title: "Canon"`
- Line 14: `content: "Specwright Docs"` → `content: "Canon Docs"`
- Line 42: `siteTitle: "Specwright"` → `siteTitle: "Canon"`
- Line 116: `text: "SPECWRIGHT.yaml"` → `text: "CANON.yaml"`
- Line 147: `link: "https://github.com/Gerner-Ventures/gv-exp-specwright"` → `link: "https://github.com/canonhq/canon"`
- Line 153: `"https://github.com/Gerner-Ventures/gv-exp-specwright/edit/main/docs-site/:path"` → `"https://github.com/canonhq/canon/edit/main/docs-site/:path"`

**Step 2: Update robots.txt**

In `docs-site/public/robots.txt`:
```
User-agent: *
Allow: /docs/
Sitemap: https://canonhq.co/docs/sitemap.xml
```

**Step 3: Update package names**

In `docs-site/package.json` line 2: `"name": "specwright-docs"` → `"name": "canon-docs"`

In `frontend/package.json` line 2: `"name": "specwright-frontend"` → `"name": "canon-frontend"`

**Step 4: Run docs build to verify**

Run: `cd docs-site && npm run build`
Expected: Build succeeds without errors

**Step 5: Commit**

```bash
git add docs-site/.vitepress/config.ts docs-site/public/robots.txt docs-site/package.json frontend/package.json
git commit -m "rebrand: update docs site branding to Canon"
```

---

### Task 2: Docs Content Updates

**Files:**
- Modify: All `docs-site/**/*.md` files
- Modify: `docs/specs/*.md`
- Modify: `docs/examples/*.md`

**Step 1: Batch replace domain and repo references across docs-site**

Use grep + edit to replace across all docs-site markdown files:
- `specwright.gernerventures.com` → `canonhq.co`
- `Gerner-Ventures/gv-exp-specwright` → `canonhq/canon`
- `gv-exp-specwright` → `canon` (in clone URLs, repo references)
- `Specwright` → `Canon` (product name — case-sensitive, skip code blocks with `specwright:` comment format)
- `specwright` → `canon` (lowercase product references — be careful with `specwright:` HTML comment prefixes which stay for backward compat)
- `SPECWRIGHT.yaml` → `CANON.yaml` as primary name, add "(formerly SPECWRIGHT.yaml)" where it's first introduced

In `docs-site/reference/config.md`: Change heading to "CANON.yaml" and add note:
```markdown
> **Migration note:** The config file was renamed from `SPECWRIGHT.yaml` to `CANON.yaml`.
> The legacy filename is still supported but deprecated and will be removed in a future release.
```

**Step 2: Update spec frontmatter**

In `docs/specs/*.md`: Replace `team: specwright` → `team: canon`

In `docs/specs/pr-comment-enhancements.md`: Update GitHub issue links from `gv-exp-specwright` to `canonhq/canon`

**Step 3: Update example spec files**

In `docs/examples/*.md`: Update HTML comment examples from `<!-- specwright:` to `<!-- canon:` prefix. Add a note that the legacy `specwright:` prefix is still parsed for backward compatibility.

**Step 4: Commit**

```bash
git add docs-site/ docs/specs/ docs/examples/
git commit -m "rebrand: update docs content references to Canon"
```

---

### Task 3: Fix Broken Source Code References

**Files:**
- Modify: `Makefile`
- Modify: `Dockerfile.dev`
- Modify: `src/canon/setup.py:140`
- Modify: `src/canon/web/routes.py:328,708`

**Step 1: Fix Makefile**

Replace these lines:
- Line 12: `DOCKER_IMAGE    ?= $(DOCKER_REGISTRY)/specwright` → `DOCKER_IMAGE    ?= $(DOCKER_REGISTRY)/canon`
- Line 14: `HELM_RELEASE    ?= specwright` → `HELM_RELEASE    ?= canon`
- Line 15: `HELM_NAMESPACE  ?= specwright` → `HELM_NAMESPACE  ?= canon`
- Line 35: `specwright.main:app` → `canon.main:app`
- Line 38: `specwright.main:app` → `canon.main:app`
- Line 90: `src/specwright` → `src/canon`
- Line 110: `specwright-dev` → `canon-dev`
- Line 115: `specwright-dev` → `canon-dev`
- Line 122: `chart/specwright` → `chart/canon`
- Line 125: `chart/specwright` → `chart/canon`
- Line 128: `chart/specwright` → `chart/canon`
- Line 137: `specwright-dev` → `canon-dev`

**Step 2: Fix Dockerfile.dev**

- Line 10: `mkdir -p src/specwright && touch src/specwright/__init__.py` → `mkdir -p src/canon && touch src/canon/__init__.py`
- Line 12: `rm -rf src/specwright` → `rm -rf src/canon`
- Line 24: `specwright.main:app` → `canon.main:app`

**Step 3: Fix setup.py MCP config**

In `src/canon/setup.py` line 140: `"args": ["--from", "gv-canon", "canon-mcp"]` → `"args": ["--from", "canonhq", "canon-mcp"]`

**Step 4: Fix GitHub App install URLs**

In `src/canon/web/routes.py`:
- Line 328: `"https://github.com/apps/gv-canon/installations/new"` → `"https://github.com/apps/canonhq/installations/new"`
- Line 708: `"https://github.com/apps/gv-canon/installations/new"` → `"https://github.com/apps/canonhq/installations/new"`

**Step 5: Verify dev server starts**

Run: `uv run python -c "from canon.main import app; print('OK')"`
Expected: `OK`

**Step 6: Run tests**

Run: `uv run python -m pytest -x -q`
Expected: All tests pass

**Step 7: Commit**

```bash
git add Makefile Dockerfile.dev src/canon/setup.py src/canon/web/routes.py
git commit -m "fix: correct broken specwright references in Makefile, Dockerfile.dev, setup.py, routes"
```

---

### Task 4: Add Deprecation Warnings

**Files:**
- Modify: `src/canon/config/parse.py`
- Modify: `src/canon/config/__init__.py`
- Modify: `src/canon/cli/_credentials.py`
- Modify: `src/canon/cli/_platform.py`
- Modify: `src/canon/sync/status_map.py`
- Modify: `src/canon/auth/device_routes.py`

**Step 1: Add config aliases with deprecation**

In `src/canon/config/parse.py`, after the existing `SpecwrightConfig` class (line 55) and `parse_specwright_yaml` function (line 76), add aliases:

```python
# New canonical names
CanonConfig = SpecwrightConfig  # SpecwrightConfig is deprecated

def parse_canon_yaml(raw: str) -> ConfigResult:
    """Parse and validate CANON.yaml content."""
    return parse_specwright_yaml(raw)
```

Then wrap the old names with deprecation warnings. At the bottom of the file add:

```python
def __getattr__(name: str):
    if name == "SpecwrightConfig":
        import warnings
        warnings.warn(
            "SpecwrightConfig is deprecated, use CanonConfig",
            DeprecationWarning,
            stacklevel=2,
        )
        return CanonConfig
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
```

Actually, this is complex because `SpecwrightConfig` is used internally. Simpler approach: just add the aliases and update `__init__.py` exports to expose both names. Don't break internal usage.

In `src/canon/config/parse.py` after line 70 (`DEFAULT_CONFIG = SpecwrightConfig()`), add:
```python
# Canonical aliases — SpecwrightConfig/parse_specwright_yaml are deprecated
CanonConfig = SpecwrightConfig
DEFAULT_CONFIG = CanonConfig()
```

After the `parse_specwright_yaml` function definition (line 76), add:
```python
parse_canon_yaml = parse_specwright_yaml
```

In `src/canon/config/__init__.py`, update exports to include both names.

**Step 2: Migrate CLI credentials directory**

In `src/canon/cli/_credentials.py`, replace lines 14-15:

```python
_NEW_CONFIG_DIR = Path.home() / ".config" / "canon"
_OLD_CONFIG_DIR = Path.home() / ".config" / "specwright"
_NEW_CRED_FILE = _NEW_CONFIG_DIR / "credentials.json"
_OLD_CRED_FILE = _OLD_CONFIG_DIR / "credentials.json"


def _get_cred_file() -> Path:
    """Return the credential file path, migrating from legacy location if needed."""
    if _NEW_CRED_FILE.exists():
        return _NEW_CRED_FILE
    if _OLD_CRED_FILE.exists():
        import warnings
        warnings.warn(
            "Credentials at ~/.config/specwright/ are deprecated. "
            "Run `canon login` to migrate to ~/.config/canon/.",
            DeprecationWarning,
            stacklevel=3,
        )
        return _OLD_CRED_FILE
    return _NEW_CRED_FILE


_CONFIG_DIR = _NEW_CONFIG_DIR
_CRED_FILE = _NEW_CRED_FILE
```

Update `load_credentials` to use `_get_cred_file()`:
```python
def load_credentials() -> dict | None:
    """Load saved credentials, or return None if absent / malformed."""
    try:
        return json.loads(_get_cred_file().read_text())
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None
```

Update `save_credentials` to always save to the new location:
```python
def save_credentials(cred: dict) -> None:
    """Persist a credential dict to disk (chmod 0600)."""
    _NEW_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _NEW_CRED_FILE.write_text(json.dumps(cred, indent=2))
    os.chmod(_NEW_CRED_FILE, 0o600)
```

Update `clear_credentials` to clear both locations:
```python
def clear_credentials() -> None:
    """Remove the credential file if it exists."""
    _NEW_CRED_FILE.unlink(missing_ok=True)
    _OLD_CRED_FILE.unlink(missing_ok=True)
```

Update docstring at top: `Credentials are persisted at ``~/.config/canon/credentials.json```

**Step 3: Add SPECWRIGHT_URL deprecation log**

In `src/canon/cli/_platform.py` line 27-29, update `__init__`:
```python
def __init__(self, base_url: str | None = None) -> None:
    if base_url is None:
        base_url = os.environ.get("CANON_URL")
        if base_url is None:
            legacy = os.environ.get("SPECWRIGHT_URL")
            if legacy:
                import logging
                logging.getLogger(__name__).warning(
                    "SPECWRIGHT_URL is deprecated, use CANON_URL instead"
                )
                base_url = legacy
    self.base_url = base_url or _DEFAULT_URL
    self._http = httpx.Client(base_url=self.base_url, timeout=30)
```

**Step 4: Add specwright.dev claim deprecation**

In `src/canon/auth/device_routes.py` lines 138-139, add logging:
```python
sub = claims.get("sub", "")
email = claims.get("email", "")
if not email:
    email = claims.get("https://canonhq.co/email", "") or claims.get("https://specwright.dev/email", "")
name = claims.get("name", "")
if not name:
    name = claims.get("https://canonhq.co/name", "") or claims.get("https://specwright.dev/name", "")
```

**Step 5: Run tests**

Run: `uv run python -m pytest -x -q`
Expected: All tests pass

**Step 6: Commit**

```bash
git add src/canon/config/parse.py src/canon/config/__init__.py src/canon/cli/_credentials.py src/canon/cli/_platform.py src/canon/auth/device_routes.py
git commit -m "deprecation: add Canon aliases and deprecation warnings for legacy Specwright names"
```

---

### Task 5: Static Assets & UI Strings

**Files:**
- Modify: `static/brand.css`
- Modify: `static/editor.js`
- Modify: `scripts/setup-github-app.sh`

**Step 1: Update brand.css comment**

Line 1: `/* Specwright Brand Design Tokens — aligned with GV OS brand guide */` → `/* Canon Brand Design Tokens — aligned with GV OS brand guide */`

**Step 2: Update editor.js strings**

Find and replace user-facing strings:
- `'Spec update via Specwright editor.'` → `'Spec update via Canon editor.'`
- `'Spec submitted for review via Specwright editor.'` → `'Spec submitted for review via Canon editor.'`
- Update comment header references from `Specwright` to `Canon`
- Keep all `specwright:` HTML comment pattern parsing (backward compat)

**Step 3: Update setup-github-app.sh**

- Line 4: `# Specwright GitHub App Setup` → `# Canon GitHub App Setup`
- Line 14: Update comment to reference canon repo
- Line 17: `echo "=== Specwright GitHub App Setup ==="` → `echo "=== Canon GitHub App Setup ==="`
- Line 44: Update webhook URL to `https://canonhq.co/webhook`

**Step 4: Commit**

```bash
git add static/brand.css static/editor.js scripts/setup-github-app.sh
git commit -m "rebrand: update static assets and UI strings to Canon"
```

---

### Task 6: Test Fixture Updates

**Files:**
- Modify: `tests/test_sync/test_templates.py`
- Modify: any other test files with hardcoded `specwright.dev` or `specwright.gernerventures.com` URLs that test new (non-backward-compat) behavior

**Step 1: Find test references**

Run: `grep -rn "specwright" tests/ --include="*.py" | grep -v "specwright|canon" | grep -v "SPECWRIGHT.yaml"`

Review each hit. Update references that test new behavior (not backward compat paths):
- `spec_url="https://specwright.dev/specs/test"` → `spec_url="https://canonhq.co/specs/test"` if testing new URL generation
- Keep references that explicitly test backward compat (e.g., testing that old `specwright:` comments still parse)

**Step 2: Run full test suite**

Run: `uv run python -m pytest -v`
Expected: All tests pass

**Step 3: Commit**

```bash
git add tests/
git commit -m "test: update test fixtures for Canon rebrand"
```

---

### Task 7: GitHub App Migration (Manual + Code)

This task involves manual steps on github.com and code changes.

**Step 1: Create canonhq GitHub App**

Go to https://github.com/organizations/Gerner-Ventures/settings/apps/new (or use the manifest at `github-app-manifest.json`).

Settings:
- Name: `canonhq`
- Homepage URL: `https://canonhq.co`
- Webhook URL: `https://canonhq.co/webhook`
- Webhook active: yes
- Events: `push`, `pull_request`, `issues`, `issue_comment`
- Permissions: `contents: write`, `issues: write`, `pull_requests: write`, `metadata: read`

Generate a private key and note the App ID.

**Step 2: Install on Gerner-Ventures org**

Go to https://github.com/apps/canonhq/installations/new and install for the Gerner-Ventures organization.

**Step 3: Update K8s secrets**

```bash
kubectl create secret generic canon-github \
  --from-literal=GH_APP_ID=<new-app-id> \
  --from-literal=GH_PRIVATE_KEY="$(cat <path-to-private-key>.pem)" \
  --from-literal=GH_WEBHOOK_SECRET=<new-webhook-secret> \
  --from-literal=GH_INSTALLATION_ID=<new-installation-id> \
  -n canon --dry-run=client -o yaml | kubectl apply -f -
```

**Step 4: Restart the canon deployment to pick up new secrets**

```bash
kubectl rollout restart deployment/canon -n canon
```

**Step 5: Verify webhook delivery**

Push a test commit or open a test PR. Check the GitHub App's "Advanced" tab for webhook delivery status. Verify the canon pod logs show the webhook being processed.

**Step 6: Update github-app-manifest.json**

Update the manifest file to reflect the new app name and URLs.

**Step 7: Decommission gv-specwright app**

After confirming the canonhq app works:
1. Uninstall `gv-specwright` from Gerner-Ventures org
2. Optionally delete the app from GitHub settings

**Step 8: Commit manifest changes**

```bash
git add github-app-manifest.json
git commit -m "rebrand: update GitHub App manifest for canonhq"
```

---

### Final: Push and Deploy

```bash
git push origin main
```

The deploy workflow will build and push the new Docker image and Helm upgrade will roll out the changes.

Verify:
- `https://canonhq.co/docs/` loads with "Canon" branding
- `https://canonhq.co/healthz` returns OK
- GitHub webhook delivery works with new app
