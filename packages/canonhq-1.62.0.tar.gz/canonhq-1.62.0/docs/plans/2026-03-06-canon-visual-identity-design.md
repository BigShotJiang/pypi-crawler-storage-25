# Canon Visual Identity: "Warm Machine"

**Date**: 2026-03-06
**Status**: Approved
**Author**: ng + claude
**Supersedes**: Section 7 of `2026-03-04-canon-rebrand-design.md`

## Concept

"Warm Machine" — Precision tooling built from natural materials. Warm surfaces, disciplined saffron, typographic authority through Fraunces, and enough texture to feel real without feeling decorated.

The design signals: sharp & modern with a subtle nod to Canon's literary/scholarly heritage. The audience is engineering orgs broadly — credible to ICs and executives alike.

## Color System

### Light Mode Surfaces

| Token | Value | Usage |
|-------|-------|-------|
| `surface` | `#FAF8F5` | Page background — warm parchment white |
| `surface-alt` | `#F3F0EB` | Cards, panels, sidebar |
| `surface-elevated` | `#FFFFFF` | Modals, dropdowns, hover states |
| `border` | `#E2DDD5` | Warm stone border |
| `border-subtle` | `#EDE9E3` | Dividers, hairlines |

### Dark Mode Surfaces

| Token | Value | Usage |
|-------|-------|-------|
| `surface` | `#1A1816` | Page background — warm near-black |
| `surface-alt` | `#242120` | Cards, panels, sidebar |
| `surface-elevated` | `#2E2B29` | Modals, dropdowns |
| `border` | `#3D3835` | Warm dark border |
| `border-subtle` | `#302C29` | Dividers |

### Text

| Token | Light | Dark |
|-------|-------|------|
| `text-primary` | `#2C2A27` | `#F0EDE8` |
| `text-secondary` | `#6B6560` | `#9B9590` |
| `text-tertiary` | `#9B9590` | `#6B6560` |

### Accent System

| Token | Value | Usage |
|-------|-------|-------|
| `accent` | `#D4880A` | Primary saffron — CTAs, active states, wordmark |
| `accent-hover` | `#B8760A` | Hover/pressed state |
| `accent-subtle` | `#FDF5E6` (light) / `#2A2218` (dark) | Accent backgrounds |
| `accent-text` | `#A06B08` (light) / `#E8A030` (dark) | Accent on-surface |

### Semantic Colors

| Token | Value | Usage |
|-------|-------|-------|
| `success` | `#5C8A4D` | Earthy green — completed, passing |
| `warning` | `#D4880A` | Shares saffron accent — attention needed |
| `error` | `#C4453A` | Warm red — errors, destructive |
| `info` | `#5B7FA5` | Slate blue — informational |

**Principle**: No cold grays anywhere. Every neutral has warm undertones. Saffron accent used with discipline — it pops because it's rare.

## Typography

### Font Stack

| Role | Font | Weight | Usage |
|------|------|--------|-------|
| Display | **Fraunces** (variable) | 600–800 | Wordmark, hero headings, marketing page titles |
| Heading | **DM Sans** (variable) | 500–700 | Section headings, card titles, nav items |
| Body | **DM Sans** (variable) | 400–500 | Paragraphs, UI text, form labels |
| Mono | **IBM Plex Mono** | 400–500 | Code blocks, spec IDs, status labels, metadata |

**Why Fraunces**: Variable serif with optical-size axis. At large sizes: expressive, high contrast, soft terminals. At small sizes: readable. Warm, distinctive, not quirky. Reinforces "warm machine" — precision from natural forms.

**Why DM Sans**: Geometric but not sterile. Slightly rounded terminals pair naturally with Fraunces. Excellent small-size readability. Not overused in dev tools.

### Typographic Scale (Marketing)

| Level | Size | Font | Weight | Tracking |
|-------|------|------|--------|----------|
| Hero | 72px / 4.5rem | Fraunces | 700 | -0.03em |
| H1 | 48px / 3rem | Fraunces | 700 | -0.02em |
| H2 | 36px / 2.25rem | Fraunces | 600 | -0.015em |
| H3 | 24px / 1.5rem | DM Sans | 600 | -0.01em |
| Body lg | 18px / 1.125rem | DM Sans | 400 | 0 |
| Body | 16px / 1rem | DM Sans | 400 | 0 |
| Caption | 13px / 0.8125rem | DM Sans | 500 | 0.01em |
| Mono label | 12px / 0.75rem | IBM Plex Mono | 500 | 0.05em |

### Typographic Scale (App)

Same fonts, tighter: H1 at 28px, H2 at 22px, body 14–16px. App is functional; marketing is expressive.

### Wordmark

"Canon" in Fraunces 700, saffron accent color, tight tracking (-0.03em). The serif letterforms are the subtle nod to literary authority.

### Signature Detail

Section eyebrow labels: `IBM Plex Mono` uppercase, wide tracking (0.15em), `text-secondary`. Technical document feel without overdoing the editorial angle.

## Layout & Spatial Composition

### Marketing Site

- **Max width**: 1200px for content; hero sections bleed wider with background treatments
- **Vertical rhythm**: 120–160px between sections. Let content breathe
- **Grid**: Predominantly single-column for narrative flow; 2-column asymmetric (60/40 or 65/35) for features
- **Hero**: Large Fraunces headline left-aligned, supporting DM Sans line below, CTAs below that. Product screenshot in warm-bordered frame on right or below
- **Section pattern**: Mono eyebrow → Fraunces heading → DM Sans body → visual/demo. Consistent cadence
- **Cards**: 12px rounded corners, warm stone border, `surface-alt` background. Hover: 2px translate-up + warm shadow
- **Signature**: 1px saffron horizontal rule between major sections

### App Layout

- **Structure**: Sidebar (`surface-alt`) + main content. Text-first nav with small monochrome icons
- **Content width**: Max 960px for reading views (spec detail, docs). Full width for tables/dashboards
- **Header**: Minimal — breadcrumb, search, theme toggle, profile. No thick toolbars
- **Density**: 8px base unit. Cards: 16–24px padding. Table rows: 12px vertical padding
- **Spec detail**: Title in Fraunces (the one serif moment in the app), metadata in mono, then clean section cards

### Spatial Principles

1. Left-aligned by default — centered only for short CTAs or single-line captions
2. Asymmetry over symmetry — 2-column sections never 50/50
3. Whitespace is a feature — warm palette makes empty space feel intentional
4. One visual per section — one clear focal point, no clustering

## Motion & Interaction

### Easing

`cubic-bezier(0.25, 0.1, 0.25, 1.0)` — custom ease-out that feels natural and weighted. Defined as `--ease-canon`.

**Philosophy**: Motion feels physical — like precision mechanical parts. Smooth, weighted, purposeful. No bouncing, no elastic overshoot.

### Page Load

- Content fades in + translates up 16px, staggered 40ms between siblings, 500ms duration
- App: 300ms duration, 8px translate — snappier
- No scroll-triggered animations below the fold (exception: interactive demo section, once)

### Hover States

- Cards: Translate up 2px + warm shadow deepens (200ms)
- Buttons: Background to `accent-hover`, no scale transforms
- Nav items: Saffron underline slides in from left (200ms)
- Links: Color to `accent`, underline fades in at 60% opacity

### App Transitions

- Route changes: Crossfade 150ms. No sliding
- Sidebar collapse/expand: Width 250ms, content fades
- Modals: Backdrop 200ms, modal translates up 12px + fades 250ms (50ms delay)
- Dropdowns: Scale 0.95→1.0 + fade, 150ms, origin top
- Toasts: Slide from right 300ms, saffron shrinking progress bar

### Interactive Elements

- Focus rings: 2px saffron outline, 2px offset
- Active/pressed: Background darkens, no scale-down
- Loading: Horizontal saffron pulse line (opacity 0.4→1.0→0.4, 2s). Small 16px spinner for element-level loading
- Drag and drop: 60% opacity ghost, 4px saffron left border, `accent-subtle` drop zone

### Signature Micro-interaction

Spec status change: badge background pulses to `accent-subtle` and back over 600ms. "This document is alive."

### Avoid

- Parallax scrolling
- Elastic/spring animations
- Particle effects, floating shapes, animated gradients
- Skeleton loading screens (use pulse line for page-level; skeletons OK for specific content areas)

## Backgrounds, Texture & Visual Detail

### Noise Grain

- 3–4% opacity noise via SVG `<feTurbulence>` filter (base frequency ~0.65, 1 octave)
- Applied to `surface` backgrounds only (not cards, not modals)
- Dark mode: reduce to 2% opacity
- Effect: tactile, paper-like warmth. Imperceptible consciously, felt as "warmth"

### Marketing Backgrounds

- Hero: Solid `surface` + noise grain. Typography is the visual. Product screenshot below in warm-bordered frame with deep warm shadow
- Feature sections: Alternate `surface` / `surface-alt` for rhythm
- One accent section: `accent-subtle` background for key value prop or social proof. Only place color fills full width — memorable because it's rare
- CTA section: `#2C2A27` background with `#FAF8F5` text. Strong closing beat via inversion

### Cards and Surfaces

- Cards: `surface-alt`, 1px `border`. No gradients. Clean, flat, warm
- Elevated: `surface-elevated` + warm shadow. Light: `rgba(44,42,39,0.06)`. Dark: `rgba(0,0,0,0.25)`
- Code blocks: `#2C2A27` in light mode (inversion), `#141210` in dark. IBM Plex Mono. Saffron for syntax highlight keywords/strings

### Borders and Dividers

- 1px solid `border` for structural separation
- Saffron horizontal rule: 1px `accent` at 40% opacity between major marketing sections
- App: hairline `border-subtle` dividers
- No double borders, dashed lines, or decorative borders

### Iconography

- Lucide icon set. Monochrome, stroke-based, 1.5px stroke weight
- `text-secondary` default, `text-primary` on hover/active
- No filled icons except status indicators (filled circle for active/live)
- Sizes: 18px app, 20px marketing, 16px dense (tables)

### Wordmark and Logo

- Wordmark: "Canon" in Fraunces 700, saffron, tight tracking. Wordmark-only identity
- Favicon: Letter "C" from Fraunces in saffron on `surface` background. Inverted for small sizes
- On dark backgrounds: use `#F0EDE8` instead of saffron

### Dark Mode Specifics

- Not a simple inversion. Slightly more contrast, less grain
- Saffron brightens to `#E8A030` for vibrancy on dark surfaces
- Cards get subtle top border: 1px `rgba(255,255,255,0.04)` — light catching an edge

### Avoid

- Gradient meshes, aurora effects
- Glassmorphism / heavy blur
- Decorative SVG illustrations
- Background/hero images
- Any texture that feels like a Photoshop filter
