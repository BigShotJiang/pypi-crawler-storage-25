# GitHub App Install Flow Design

## Goal

Replace the current "open GitHub in new tab" install pattern with a same-tab flow that redirects back to Canon after installation, giving users a seamless setup experience.

## Current State

- Welcome checklist at `/{org}/welcome` has an "Install on GitHub" button that opens `github.com/apps/canon-hq/installations/new` in a new tab
- Marketing pages link directly to the same GitHub URL
- After installing, the user is stranded on GitHub with no redirect back to Canon
- GitHub's org picker can auto-select an unexpected org

## Design

### Setup URL Redirect

Configure the GitHub App's **Setup URL** to `https://canonhq.co/app/setup/complete`. GitHub redirects here after installation with `installation_id` as a query param.

### New Route: `GET /app/setup/complete`

1. Receives `installation_id` from GitHub's redirect
2. Waits briefly for the installation webhook to register (the webhook may arrive before or after the redirect)
3. Looks up the installation in the registry to get the org login
4. Redirects to `/app/{org}/welcome` where the checklist now shows the app as installed

**Fallback:** If the installation isn't found yet (webhook hasn't arrived), redirect to `/app` with a flash message. The welcome page already polls for installation status.

### Install Button Changes

- Remove `target="_blank"` from install buttons in the welcome checklist — flow stays in the same tab
- Marketing page buttons keep `target="_blank"` since users aren't logged in yet (they'll land on GitHub, install, then get redirected to Canon where they'll need to log in)

### GitHub App Settings Change

Set "Post installation > Setup URL" to `https://canonhq.co/app/setup/complete` in the GitHub App settings UI. Check "Redirect on update" so re-configurations also return to Canon.

## Files to Change

- `src/canon/web/routes.py` — Add `GET /app/setup/complete` route
- `frontend/src/components/welcome/WelcomeChecklist.vue` — Remove `target="_blank"` from install button
- GitHub App settings (manual) — Set Setup URL
