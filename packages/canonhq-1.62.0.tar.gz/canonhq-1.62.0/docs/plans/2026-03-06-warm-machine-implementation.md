# Canon "Warm Machine" Visual Identity — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Implement the complete Warm Machine visual identity across the Vue SPA (marketing site + web app), replacing all color tokens, typography, gradients, and visual treatments.

**Architecture:** Leverages Tailwind v4's `@theme` override capability. By redefining built-in color scales (slate, gray, emerald, blue, red, amber) with warm equivalents, ~70% of visual changes happen automatically — every component using `text-slate-*`, `bg-emerald-*`, etc. gets warm values without class name changes. The remaining ~30% requires explicit changes: gradient→solid replacements, layout adjustments, and new visual elements (noise grain, easing curve).

**Tech Stack:** Vue 3, Tailwind CSS v4 (`@theme` block), Google Fonts (Fraunces, DM Sans, IBM Plex Mono)

**Design Reference:** `docs/plans/2026-03-06-canon-visual-identity-design.md`

---

### Task 1: Replace @theme design tokens in style.css

**Files:**
- Modify: `frontend/src/style.css` (lines 3–38, the `@theme { }` block)

**Step 1: Replace the entire @theme block**

The current `@theme` block defines fonts (Space Grotesk, Inter, JetBrains Mono), a blue brand scale, emerald accent scale, cold surfaces, and cold borders. Replace it completely with warm equivalents.

In `frontend/src/style.css`, replace the `@theme { ... }` block (everything between `@theme {` and its closing `}`) with:

```css
@theme {
  /* --- Typography --- */
  --font-sans: 'DM Sans', system-ui, -apple-system, sans-serif;
  --font-display: 'Fraunces', Georgia, 'Times New Roman', serif;
  --font-mono: 'IBM Plex Mono', ui-monospace, monospace;

  /* --- Warm stone scale (overrides Tailwind's cool slate) --- */
  --color-slate-50: #FAF8F5;
  --color-slate-100: #F3F0EB;
  --color-slate-200: #E8E3DC;
  --color-slate-300: #D4CEC6;
  --color-slate-400: #9B9590;
  --color-slate-500: #6B6560;
  --color-slate-600: #544F49;
  --color-slate-700: #3D3835;
  --color-slate-800: #2C2A27;
  --color-slate-900: #1A1816;

  /* --- Warm gray (overrides Tailwind's cool gray) --- */
  --color-gray-50: #F8F6F3;
  --color-gray-100: #F0EDE8;
  --color-gray-200: #E2DDD5;
  --color-gray-300: #CCC5BB;
  --color-gray-400: #9B9590;
  --color-gray-500: #6B6560;
  --color-gray-600: #544F49;
  --color-gray-700: #3D3835;
  --color-gray-800: #2C2A27;
  --color-gray-900: #1A1816;

  /* --- Saffron accent (replaces emerald accent) --- */
  --color-accent-50: #FDF5E6;
  --color-accent-100: #FAEACC;
  --color-accent-200: #F5D599;
  --color-accent-300: #F0C066;
  --color-accent-400: #E8A030;
  --color-accent-500: #D4880A;
  --color-accent-600: #B8760A;
  --color-accent-700: #9B6308;
  --color-accent-800: #7E5106;
  --color-accent-900: #614005;

  /* --- Slate blue brand (replaces sky-blue brand) --- */
  --color-brand-50: #F0F4F8;
  --color-brand-100: #DCE4EE;
  --color-brand-200: #B9C9DD;
  --color-brand-300: #96AECC;
  --color-brand-400: #7A9DBF;
  --color-brand-500: #5B7FA5;
  --color-brand-600: #4C6A8B;
  --color-brand-700: #3D5571;
  --color-brand-800: #2E4057;
  --color-brand-900: #253445;

  /* --- Earthy green (overrides emerald for success/done) --- */
  --color-emerald-50: #F2F7F0;
  --color-emerald-100: #E0EDDC;
  --color-emerald-200: #C1DBB9;
  --color-emerald-300: #A2C996;
  --color-emerald-400: #7AAD6A;
  --color-emerald-500: #5C8A4D;
  --color-emerald-600: #4A7240;
  --color-emerald-700: #3B5C33;
  --color-emerald-800: #2D4627;
  --color-emerald-900: #1E3018;

  /* --- Slate blue (overrides Tailwind blue for info/in-progress) --- */
  --color-blue-50: #F0F4F8;
  --color-blue-100: #DCE4EE;
  --color-blue-200: #B9C9DD;
  --color-blue-300: #96AECC;
  --color-blue-400: #7A9DBF;
  --color-blue-500: #5B7FA5;
  --color-blue-600: #4C6A8B;
  --color-blue-700: #3D5571;
  --color-blue-800: #2E4057;
  --color-blue-900: #253445;

  /* --- Warm red (overrides Tailwind red for error/blocked) --- */
  --color-red-50: #FEF2F1;
  --color-red-100: #FDE3E1;
  --color-red-200: #F9C4C0;
  --color-red-300: #E8918A;
  --color-red-400: #D4635A;
  --color-red-500: #C4453A;
  --color-red-600: #A83930;
  --color-red-700: #8C2F28;
  --color-red-800: #70261F;
  --color-red-900: #5C1E1A;

  /* --- Warm amber (overrides Tailwind amber for warning/todo) --- */
  --color-amber-50: #FDF8EE;
  --color-amber-100: #FAEECC;
  --color-amber-200: #F5DD99;
  --color-amber-300: #F0CC66;
  --color-amber-400: #E8B830;
  --color-amber-500: #D4A00A;
  --color-amber-600: #B88A0A;
  --color-amber-700: #9B7408;
  --color-amber-800: #7E5E06;
  --color-amber-900: #614805;

  /* --- Cyan (warmed slightly, used in code highlighting) --- */
  --color-cyan-400: #4DB8B0;
  --color-cyan-500: #3A9A93;

  /* --- Dark surfaces (warm near-black) --- */
  --color-surface: #1A1816;
  --color-surface-alt: #242120;
  --color-surface-elevated: #2E2B29;

  /* --- Light surfaces (warm parchment) --- */
  --color-surface-light: #FAF8F5;
  --color-surface-light-alt: #F3F0EB;
  --color-surface-light-elevated: #FFFFFF;

  /* --- Borders --- */
  --color-border-light: #E2DDD5;
  --color-border-dark: #3D3835;
  --color-border-dark-subtle: #302C29;
}
```

**Step 2: Verify the app builds**

Run: `cd frontend && npm run build`
Expected: Build succeeds with no errors (warnings about unused vars are OK).

**Step 3: Commit**

```bash
git add frontend/src/style.css
git commit -m "feat(ui): replace @theme tokens with Warm Machine palette

Swap all color scales to warm equivalents: saffron accent, warm stone
grays, earthy green, slate blue, warm red/amber. Override Tailwind's
built-in slate/gray/emerald/blue/red/amber scales so all existing
utility class usage automatically gets warm values.

Typography tokens: Fraunces (display), DM Sans (body), IBM Plex Mono."
```

---

### Task 2: Update font loading in index.html

**Files:**
- Modify: `frontend/index.html`

**Step 1: Replace the Google Fonts link and update body/title**

In `frontend/index.html`, make three changes:

1. Replace `<title>Specwright</title>` with `<title>Canon</title>`

2. Replace the Google Fonts `<link>` tag:
```html
<!-- OLD -->
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

<!-- NEW -->
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,600;0,9..144,700;0,9..144,800&family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
```

3. Replace the `<body>` tag to use warm surface color:
```html
<!-- OLD -->
<body class="h-full bg-surface-light dark:bg-[#0a0f1a] font-sans text-slate-800 dark:text-slate-200 antialiased">

<!-- NEW -->
<body class="h-full bg-surface-light dark:bg-surface font-sans text-slate-800 dark:text-slate-200 antialiased">
```

Note: The dark mode background changes from hardcoded `dark:bg-[#0a0f1a]` to token `dark:bg-surface` (which now resolves to `#1A1816`). The `text-slate-800` and `dark:text-slate-200` classes automatically pick up the warm stone values from Task 1.

**Step 2: Verify**

Run: `cd frontend && npm run build`
Expected: Build succeeds.

**Step 3: Commit**

```bash
git add frontend/index.html
git commit -m "feat(ui): update font loading to Fraunces/DM Sans/IBM Plex Mono

Replace Google Fonts CDN link. Fix hardcoded dark:bg-[#0a0f1a] to use
dark:bg-surface token. Update page title to Canon."
```

---

### Task 3: Update legacy brand.css tokens

**Files:**
- Modify: `static/brand.css`

**Step 1: Replace all color and font values**

This file is used by Jinja2-rendered pages (not the Vue SPA). Update all values to match the Warm Machine palette. Replace the entire `:root { }` and `html.dark { }` blocks:

In `:root`:
```css
:root {
  /* Primary palette */
  --color-primary: #D4880A;
  --color-primary-light: #E8A030;
  --color-primary-dark: #B8760A;
  --color-accent: #D4880A;
  --color-accent-light: #E8A030;
  --color-accent-dim: #9B6308;

  /* Theme-aware tokens (light defaults) */
  --theme-text: #2C2A27;
  --theme-text-secondary: #6B6560;
  --theme-text-muted: #9B9590;
  --theme-bg: #FAF8F5;
  --theme-bg-alt: #F3F0EB;
  --theme-bg-elevated: #FFFFFF;
  --theme-bg-nav: rgba(250, 248, 245, 0.85);
  --theme-border: #E2DDD5;
  --theme-divider: #EDE9E3;

  /* Gradient — now solid saffron (no gradient needed but keep for compat) */
  --color-gradient-start: #D4880A;
  --color-gradient-end: #E8A030;

  /* Status (semantic) */
  --color-success: #5C8A4D;
  --color-warning: #D4880A;
  --color-error: #C4453A;
  --color-info: #5B7FA5;

  /* Typography */
  --font-display: 'Fraunces', Georgia, 'Times New Roman', serif;
  --font-body: 'DM Sans', system-ui, -apple-system, sans-serif;
  --font-mono: 'IBM Plex Mono', ui-monospace, 'Cascadia Code', monospace;

  /* (spacing, radius, shadows, text sizes unchanged) */
```

In `html.dark`:
```css
html.dark {
  --theme-text: #F0EDE8;
  --theme-text-secondary: #9B9590;
  --theme-text-muted: #6B6560;
  --theme-bg: #1A1816;
  --theme-bg-alt: #242120;
  --theme-bg-elevated: #2E2B29;
  --theme-bg-nav: rgba(26, 24, 22, 0.85);
  --theme-border: #3D3835;
  --theme-divider: rgba(61, 56, 53, 0.5);
}
```

Also update `.gradient-text` in brand.css:
```css
/* OLD */
background: linear-gradient(135deg, var(--color-gradient-start), var(--color-gradient-end));

/* NEW — solid saffron text */
.gradient-text {
  color: var(--color-accent);
  background: none;
  -webkit-background-clip: unset;
  -webkit-text-fill-color: unset;
  background-clip: unset;
}
```

And update `.brand-btn-primary`:
```css
.brand-btn-primary {
  /* ... keep layout properties ... */
  background-color: var(--color-primary); /* now saffron */
}
.brand-btn-primary:hover { background-color: var(--color-primary-dark); }
```

**Step 2: Commit**

```bash
git add static/brand.css
git commit -m "feat(ui): update brand.css tokens to Warm Machine palette"
```

---

### Task 4: Update global utility classes and add noise grain

**Files:**
- Modify: `frontend/src/style.css` (the section after `@theme { }`)

**Step 1: Replace .gradient-text with solid saffron text**

```css
/* OLD */
.gradient-text {
  @apply bg-gradient-to-r from-accent-500 to-cyan-400 bg-clip-text text-transparent;
}

/* NEW */
.gradient-text {
  @apply text-accent-500;
}
```

**Step 2: Update .section-ghost drag overlays**

```css
/* OLD */
.section-ghost      { @apply bg-brand-100/40 border-2 border-dashed border-brand-300 rounded-lg; }
.dark .section-ghost{ @apply bg-brand-900/20 border-brand-700; }
.ac-ghost           { @apply bg-brand-100/30 rounded; }
.dark .ac-ghost     { @apply bg-brand-900/15; }

/* NEW — use accent (saffron) tints */
.section-ghost      { @apply bg-accent-100/40 border-2 border-dashed border-accent-300 rounded-lg; }
.dark .section-ghost{ @apply bg-accent-900/20 border-accent-700; }
.ac-ghost           { @apply bg-accent-100/30 rounded; }
.dark .ac-ghost     { @apply bg-accent-900/15; }
```

**Step 3: Update .section-card-focused ring**

```css
/* OLD */
.section-card-focused { @apply ring-2 ring-accent-500/30; }

/* NEW — same class, accent-500 is now saffron (auto-updated via token), no change needed */
```

(No change needed — `accent-500` is now saffron from Task 1.)

**Step 4: Update .spec-prose link color**

```css
/* OLD */
.spec-prose :where(a) { @apply text-brand-600 dark:text-brand-400 hover:underline; }

/* NEW — brand-600 is now slate blue (auto-updated via token), no change needed */
```

(No change needed — `brand-600` is now warm slate blue from Task 1.)

**Step 5: Add noise grain overlay and easing variable**

Add at the end of `frontend/src/style.css`, after the `mark { }` rule:

```css
/* Warm Machine easing */
:root {
  --ease-canon: cubic-bezier(0.25, 0.1, 0.25, 1.0);
}

/* Noise grain texture — warm parchment feel */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  z-index: 9999;
  pointer-events: none;
  opacity: 0.035;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='1' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E");
  background-repeat: repeat;
  background-size: 256px 256px;
}

html.dark body::before {
  opacity: 0.02;
}

/* Saffron horizontal rule — marketing section divider */
.section-rule {
  height: 1px;
  background: var(--color-accent-500, #D4880A);
  opacity: 0.4;
  border: none;
  margin: 0 auto;
  max-width: 1200px;
}

/* Staggered fade-in animation for marketing sections */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(16px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-fade-in-up {
  animation: fadeInUp 0.5s var(--ease-canon) both;
}

/* Status pulse for spec status changes */
@keyframes statusPulse {
  0%, 100% { background-color: transparent; }
  50% { background-color: var(--color-accent-50, #FDF5E6); }
}

html.dark .status-pulse {
  animation: statusPulseDark 0.6s var(--ease-canon);
}

@keyframes statusPulseDark {
  0%, 100% { background-color: transparent; }
  50% { background-color: rgba(97, 64, 5, 0.3); }
}

.status-pulse {
  animation: statusPulse 0.6s var(--ease-canon);
}

/* Loading pulse line */
@keyframes pulseBar {
  0%, 100% { opacity: 0.4; }
  50% { opacity: 1; }
}

.loading-pulse {
  height: 2px;
  background-color: var(--color-accent-500, #D4880A);
  animation: pulseBar 2s ease-in-out infinite;
}
```

**Step 6: Verify build**

Run: `cd frontend && npm run build`
Expected: Build succeeds.

**Step 7: Commit**

```bash
git add frontend/src/style.css
git commit -m "feat(ui): update utility classes, add noise grain and animations

Replace gradient-text with solid saffron. Update drag ghost colors.
Add noise grain overlay, section divider rule, fade-in animation,
status pulse, and loading pulse bar. Define --ease-canon easing."
```

---

### Task 5: Update App.vue shell

**Files:**
- Modify: `frontend/src/App.vue`

**Step 1: Replace gradient stripe with solid saffron line**

```html
<!-- OLD -->
<div class="h-0.5 bg-gradient-to-r from-accent-500 to-cyan-400"></div>

<!-- NEW -->
<div class="h-0.5 bg-accent-500"></div>
```

**Step 2: Commit**

```bash
git add frontend/src/App.vue
git commit -m "feat(ui): replace gradient accent stripe with solid saffron"
```

---

### Task 6: Update marketing navigation and footer

**Files:**
- Modify: `frontend/src/components/marketing/MarketingNav.vue`
- Modify: `frontend/src/components/marketing/MarketingFooter.vue`

**Step 1: MarketingNav — replace gradient wordmark and button**

In `MarketingNav.vue`, make these replacements:

1. Nav background — replace hardcoded hex:
```html
<!-- OLD -->
<nav class="sticky top-0 z-50 bg-surface-light/90 dark:bg-[#0a0f1a] backdrop-blur-lg border-b border-border-light dark:border-slate-800">

<!-- NEW -->
<nav class="sticky top-0 z-50 bg-surface-light/90 dark:bg-surface/90 backdrop-blur-lg border-b border-border-light dark:border-slate-800">
```

2. Wordmark — replace gradient text with solid saffron + serif tracking:
```html
<!-- OLD -->
<a class="text-lg font-bold font-display bg-gradient-to-r from-accent-500 to-cyan-400 bg-clip-text text-transparent">

<!-- NEW -->
<a class="text-lg font-bold font-display text-accent-500 tracking-[-0.03em]">
```

3. CTA button — replace gradient with solid:
```html
<!-- OLD -->
<a class="inline-flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold text-white bg-gradient-to-r from-accent-500 to-cyan-400 hover:opacity-90 transition-opacity">

<!-- NEW -->
<a class="inline-flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold text-white bg-accent-500 hover:bg-accent-600 transition-colors">
```

4. Mobile menu background — replace hardcoded hex:
```html
<!-- OLD -->
dark:bg-[#0a0f1a]

<!-- NEW -->
dark:bg-surface
```
(in the mobile menu `<div>`)

**Step 2: MarketingFooter — replace gradient wordmark**

In `MarketingFooter.vue`:
```html
<!-- OLD -->
<span class="font-display font-bold bg-gradient-to-r from-accent-500 to-cyan-400 bg-clip-text text-transparent">Canon</span>

<!-- NEW -->
<span class="font-display font-bold text-accent-500 tracking-[-0.03em]">Canon</span>
```

**Step 3: Commit**

```bash
git add frontend/src/components/marketing/MarketingNav.vue frontend/src/components/marketing/MarketingFooter.vue
git commit -m "feat(ui): update marketing nav/footer to solid saffron wordmark

Replace gradient wordmarks and CTA buttons with solid saffron.
Fix hardcoded dark background hex to use token. Add serif tracking."
```

---

### Task 7: Update app navigation and footer

**Files:**
- Modify: `frontend/src/components/layout/AppNav.vue`
- Modify: `frontend/src/components/layout/AppFooter.vue`

**Step 1: AppNav — replace gradient wordmark**

In `AppNav.vue`, find the wordmark element. It likely uses `from-accent-400 to-cyan-400`. Replace:
```html
<!-- OLD (pattern) -->
bg-gradient-to-r from-accent-400 to-cyan-400 bg-clip-text text-transparent

<!-- NEW -->
text-accent-500 tracking-[-0.03em]
```

Also replace any hardcoded `dark:bg-[#0a0f1a]` with `dark:bg-surface`.

**Step 2: AppFooter — replace gradient wordmark**

In `AppFooter.vue`, same pattern:
```html
<!-- OLD -->
bg-gradient-to-r from-accent-500 to-cyan-400 bg-clip-text text-transparent

<!-- NEW -->
text-accent-500 tracking-[-0.03em]
```

**Step 3: Commit**

```bash
git add frontend/src/components/layout/AppNav.vue frontend/src/components/layout/AppFooter.vue
git commit -m "feat(ui): update app nav/footer wordmarks to solid saffron"
```

---

### Task 8: Redesign HeroSection

**Files:**
- Modify: `frontend/src/components/marketing/HeroSection.vue`

This is the most significant layout change. The hero moves from centered to left-aligned, removes the background gradient, and uses Fraunces display typography (automatic via token swap).

**Step 1: Update the template**

Replace the hero section template. Key changes:
- Remove `bg-gradient-to-b from-brand-50/60 via-accent-50/30 to-transparent` background div
- Change `text-center` to left-aligned
- Replace `max-w-4xl mx-auto` centered with `max-w-6xl mx-auto` left-flow
- Replace `flex justify-center` CTA row with `flex` (left-aligned)
- Replace gradient CTA button with solid saffron
- Replace `.gradient-text` span — it now renders solid saffron (auto via Task 4), no changes needed on the class itself
- Remove `max-w-2xl mx-auto` centering from paragraph
- Change hero text scale: keep `text-4xl sm:text-5xl lg:text-6xl` (these are already good sizes for Fraunces)

Specific class changes in the template:

1. Remove or simplify the background gradient div:
```html
<!-- OLD -->
<div class="absolute inset-0 bg-gradient-to-b from-brand-50/60 via-accent-50/30 to-transparent dark:from-transparent ...">

<!-- NEW: remove entirely or replace with empty div -->
```

2. Update the content container:
```html
<!-- OLD -->
<div class="relative max-w-4xl mx-auto px-4 sm:px-6 pt-20 sm:pt-28 pb-16 text-center">

<!-- NEW -->
<div class="relative max-w-6xl mx-auto px-4 sm:px-6 pt-20 sm:pt-28 pb-16">
```

3. Update the eyebrow:
```html
<!-- OLD -->
<p class="font-mono text-xs uppercase tracking-[0.15em] text-accent-500 mb-4">

<!-- NEW (same classes, text-accent-500 is now saffron — keep as-is) -->
<p class="font-mono text-xs uppercase tracking-[0.15em] text-accent-500 mb-4">
```

4. Update paragraph centering:
```html
<!-- OLD -->
<p class="text-lg sm:text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-4">

<!-- NEW — remove mx-auto for left alignment -->
<p class="text-lg sm:text-xl text-slate-600 dark:text-slate-400 max-w-2xl mb-4">
```

Same for the smaller paragraph — remove `mx-auto`.

5. Update CTA button row:
```html
<!-- OLD -->
<div class="flex justify-center gap-4 flex-wrap">

<!-- NEW -->
<div class="flex gap-4 flex-wrap">
```

6. Update primary CTA button:
```html
<!-- OLD -->
<a class="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-base font-semibold text-white bg-gradient-to-r from-accent-500 to-cyan-400 hover:opacity-90 transition-opacity">

<!-- NEW -->
<a class="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-base font-semibold text-white bg-accent-500 hover:bg-accent-600 transition-colors">
```

**Step 2: Verify visually**

Run: `cd frontend && npm run dev`
Check: http://localhost:5173 — hero should be left-aligned with saffron accent, Fraunces headline

**Step 3: Commit**

```bash
git add frontend/src/components/marketing/HeroSection.vue
git commit -m "feat(ui): redesign hero section — left-aligned, solid saffron CTA

Remove centered layout, gradient background, gradient CTA button.
Left-align all content with max-w-6xl container. Fraunces display
font applied automatically via token change."
```

---

### Task 9: Gradient-to-solid sweep across remaining marketing components

**Files:**
- Modify: `frontend/src/components/marketing/ProblemSolution.vue`
- Modify: `frontend/src/components/marketing/FeedbackLoop.vue`
- Modify: `frontend/src/components/marketing/ProductMockup.vue`
- Modify: `frontend/src/components/marketing/PricingSection.vue`
- Modify: `frontend/src/components/marketing/SetupSteps.vue`
- Modify: `frontend/src/components/marketing/CtaSection.vue`
- Modify: `frontend/src/components/marketing/InteractiveDemo.vue`

Apply these mechanical replacements across all files:

**Pattern A — Gradient button → solid saffron button:**
```
OLD: bg-gradient-to-r from-accent-500 to-cyan-400 hover:opacity-90 transition-opacity
NEW: bg-accent-500 hover:bg-accent-600 transition-colors
```
Files: PricingSection (waitlist submit), CtaSection (primary CTA)

**Pattern B — Gradient circle/dot → solid saffron:**
```
OLD: bg-gradient-to-r from-accent-500 to-cyan-400
NEW: bg-accent-500
```
Files: SetupSteps (step number circles), FeedbackLoop (timeline dots), InteractiveDemo (PR avatar circle), ProductMockup (active tab button, avatar)

**Pattern C — Gradient card background → solid saffron:**
In `ProblemSolution.vue`, the "With Canon" solution card:
```html
<!-- OLD -->
<div class="rounded-xl p-6 sm:p-8 bg-gradient-to-br from-accent-500 to-cyan-400 text-white">

<!-- NEW -->
<div class="rounded-xl p-6 sm:p-8 bg-accent-500 text-white">
```

**Pattern D — Gradient tab/bar fills → solid saffron:**
In `ProductMockup.vue`, active tab and coverage bars:
```
OLD: bg-gradient-to-r from-accent-500 to-cyan-400
NEW: bg-accent-500
```

Also in ProductMockup, the inner `.gradient-text` usage is already handled by Task 4 (now renders solid saffron).

**Step 1: Apply all replacements**

Search across `frontend/src/components/marketing/` for:
- `from-accent-500 to-cyan-400` — replace with `accent-500` (removing `bg-gradient-to-r` and `from-`/`to-` prefixes)
- `from-accent-400 to-cyan-400` — same treatment
- `hover:opacity-90 transition-opacity` on gradient buttons → `hover:bg-accent-600 transition-colors`
- `bg-gradient-to-br from-accent-500 to-cyan-400` → `bg-accent-500`
- `bg-gradient-to-r from-accent-500 to-cyan-400` (on non-text elements) → `bg-accent-500`

**Step 2: Verify build**

Run: `cd frontend && npm run build`
Expected: Build succeeds.

**Step 3: Commit**

```bash
git add frontend/src/components/marketing/
git commit -m "feat(ui): replace all marketing gradients with solid saffron

Sweep across ProblemSolution, FeedbackLoop, ProductMockup,
PricingSection, SetupSteps, CtaSection, InteractiveDemo. Convert
gradient buttons, circles, card backgrounds, and tab fills to
solid accent-500 saffron."
```

---

### Task 10: Redesign CtaSection with dark background inversion

**Files:**
- Modify: `frontend/src/components/marketing/CtaSection.vue`

Per the design doc, the bottom CTA section should use a dark background inversion: `#2C2A27` background with light text, creating a strong closing beat.

**Step 1: Update the section wrapper and text colors**

```html
<!-- OLD -->
<section class="max-w-3xl mx-auto px-4 sm:px-6 py-16 sm:py-20 text-center">
  <h2 class="font-display font-bold text-2xl sm:text-3xl text-slate-900 dark:text-white mb-4">
  <p class="text-base text-slate-500 mb-8">

<!-- NEW -->
<section class="bg-slate-800 dark:bg-slate-900">
  <div class="max-w-3xl mx-auto px-4 sm:px-6 py-16 sm:py-20 text-center">
    <h2 class="font-display font-bold text-2xl sm:text-3xl text-slate-50 mb-4">
    <p class="text-base text-slate-400 mb-8">
```

Note: `bg-slate-800` is now `#2C2A27` (warm dark) from our token override. `text-slate-50` is `#FAF8F5` (warm light).

Update the secondary CTA button for inverted context:
```html
<!-- OLD -->
<a class="... text-slate-600 dark:text-slate-400 border border-border-light dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-500 ...">

<!-- NEW -->
<a class="... text-slate-300 border border-slate-600 hover:border-slate-400 ...">
```

Update the primary CTA button text to stay visible:
```html
<!-- OLD -->
<a class="... text-white bg-accent-500 hover:bg-accent-600 transition-colors">

<!-- NEW — keep as-is, saffron on dark bg looks great -->
```

**Step 2: Close the new wrapper div**

Make sure to close the inner `<div>` and outer `<section>` properly.

**Step 3: Commit**

```bash
git add frontend/src/components/marketing/CtaSection.vue
git commit -m "feat(ui): CTA section dark background inversion

Warm dark background (#2C2A27) with light text for strong closing
beat per design doc."
```

---

### Task 11: Update LoginView scoped styles

**Files:**
- Modify: `frontend/src/views/LoginView.vue`

The login page uses scoped CSS with hardcoded dark hex fallbacks. Update to warm palette.

**Step 1: Replace CSS custom property fallbacks**

In the `<style scoped>` block:

```css
/* OLD fallbacks → NEW warm values */
--color-bg-primary, #0a0a0a     → --color-bg-primary, #1A1816
--color-bg-secondary, #141414   → --color-bg-secondary, #242120
--color-border, #262626         → --color-border, #3D3835
--color-text-primary, #fafafa   → --color-text-primary, #F0EDE8
--color-text-secondary, #a3a3a3 → --color-text-secondary, #9B9590
--color-bg-hover, #1a1a1a       → --color-bg-hover, #2E2B29
--color-border-hover, #404040   → --color-border-hover, #544F49
```

**Step 2: Add font family to login card for consistency**

In `.login-title`:
```css
/* ADD */
font-family: 'Fraunces', Georgia, serif;
```

**Step 3: Commit**

```bash
git add frontend/src/views/LoginView.vue
git commit -m "feat(ui): update LoginView scoped styles to warm palette

Replace cold gray fallback hex values with warm stone equivalents.
Add Fraunces font to login title."
```

---

### Task 12: Update WelcomeChecklist and remaining app components

**Files:**
- Modify: `frontend/src/components/welcome/WelcomeChecklist.vue`
- Modify: any other files with gradient patterns

**Step 1: Search for remaining gradient instances**

Run: `grep -r "from-accent" frontend/src/ --include="*.vue" -l`

Expected: Should find WelcomeChecklist.vue and possibly others not yet updated.

For each file found, apply the same Pattern A/B replacements from Task 9:
- `bg-gradient-to-r from-accent-500 to-cyan-400` → `bg-accent-500`
- `hover:opacity-90 transition-opacity` → `hover:bg-accent-600 transition-colors`
- Gradient text: `bg-gradient-to-r from-accent-500 to-cyan-400 bg-clip-text text-transparent` → `text-accent-500`

**Step 2: Search for remaining hardcoded surface hex**

Run: `grep -r "0a0f1a\|0a0a0a\|141414\|111827\|1e293b" frontend/src/ --include="*.vue" -l`

Replace any remaining hardcoded dark hex values with the appropriate token class (`dark:bg-surface`, `dark:bg-surface-alt`, `dark:bg-surface-elevated`).

**Step 3: Commit**

```bash
git add frontend/src/
git commit -m "feat(ui): sweep remaining gradient and hardcoded color instances"
```

---

### Task 13: Update Monaco Editor font references

**Files:**
- Modify: `frontend/src/components/editor/AiDiffReview.vue` (line ~73)
- Modify: `frontend/src/components/editor/MonacoEditor.vue` (line ~44)

**Step 1: Replace JetBrains Mono with IBM Plex Mono**

Both files have hardcoded Monaco editor config:
```javascript
// OLD
fontFamily: 'JetBrains Mono, monospace'

// NEW
fontFamily: 'IBM Plex Mono, monospace'
```

**Step 2: Commit**

```bash
git add frontend/src/components/editor/AiDiffReview.vue frontend/src/components/editor/MonacoEditor.vue
git commit -m "feat(ui): update Monaco editor font to IBM Plex Mono"
```

---

### Task 14: Verification and cleanup

**Step 1: Full build check**

Run: `cd frontend && npm run build`
Expected: Clean build, no errors.

**Step 2: Lint check**

Run: `cd /Users/nickgerner/Code/gv-exp-specwright && uv run ruff check`
Expected: No Python lint errors (frontend changes shouldn't affect Python).

**Step 3: Run tests**

Run: `uv run pytest -v`
Expected: All tests pass (visual-only changes shouldn't break tests).

**Step 4: Visual spot-check list**

Start dev server: `cd frontend && npm run dev`

Check these pages in both light and dark mode:
- [ ] Landing page hero — left-aligned, Fraunces headline, saffron CTA
- [ ] Landing page sections — warm backgrounds, saffron eyebrows, no gradients
- [ ] CTA section — dark inversion at bottom
- [ ] Nav wordmark — saffron Fraunces text, no gradient
- [ ] Footer — saffron wordmark
- [ ] Login page — warm dark card
- [ ] Dashboard — warm surfaces, saffron "New Spec" button
- [ ] Spec detail — Fraunces spec title, warm cards
- [ ] Noise grain — subtle texture on page background (inspect body::before)
- [ ] Dark mode — warm near-black, brighter saffron, card top-edge highlight

**Step 5: Final commit (if any cleanup needed)**

```bash
git add -A
git commit -m "fix(ui): visual identity cleanup and polish"
```

---

## Execution Notes

- **Tasks 1–4** are the foundation — they must be done first and in order.
- **Tasks 5–13** can be done in any order after the foundation.
- **Task 14** must be last.
- Total: ~14 tasks, estimated 45–60 minutes of implementation time.
- The Tailwind v4 `@theme` override strategy (Task 1) does most of the heavy lifting. After Task 1, the app will already look ~70% correct even before explicit component changes.
