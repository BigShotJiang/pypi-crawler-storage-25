"""Integration tests for error resilience and graceful degradation.

Verifies that the app handles store failures, missing dependencies,
and service unavailability without 500 errors.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _make_resilience_client(
    mock_github_client: MagicMock,
    *,
    search_index: AsyncMock | MagicMock | None = None,
    admin_store: AsyncMock | None = None,
    audit_store: AsyncMock | None = None,
):
    settings = _base_settings(web_org=SEED_ORG)
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        search_index=search_index,
        admin_store=admin_store,
        audit_store=audit_store,
    )

    patches = [
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
        patch("canon.web.routes._get_spa_html", return_value=None),
    ]
    for p in patches:
        p.start()

    transport = ASGITransport(app=app, raise_app_exceptions=False)
    client = httpx.AsyncClient(transport=transport, base_url="http://test")
    return client, originals, patches


async def _cleanup(client, originals, patches):
    await client.aclose()
    for p in patches:
        p.stop()
    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# GitHub client failures
# ---------------------------------------------------------------------------


class TestGitHubClientFailures:
    """App handles GitHub client errors gracefully."""

    async def test_dashboard_with_github_api_error(self, mock_github_client: MagicMock):
        """Dashboard returns 500 when GitHub API fails — unhandled exception.

        This documents the current behavior: get_org_overview() doesn't
        catch exceptions from list_installation_repos, so the error
        propagates to FastAPI's default handler → 500.

        A better UX would catch the error and show a degraded dashboard
        or a clear error message.
        """
        child = mock_github_client.for_installation.return_value
        child.list_installation_repos = AsyncMock(side_effect=Exception("GitHub API 500"))

        client, originals, patches = await _make_resilience_client(mock_github_client)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/")
            # Currently returns 500 (unhandled) — not ideal but not a silent failure
            assert resp.status_code in (200, 500)
        finally:
            await _cleanup(client, originals, patches)

    async def test_repo_detail_with_github_timeout(self, mock_github_client: MagicMock):
        """Repo detail handles timeout from GitHub API."""
        child = mock_github_client.for_installation.return_value
        child.list_directory = AsyncMock(side_effect=TimeoutError("request timed out"))
        child.get_file_content = AsyncMock(side_effect=TimeoutError("request timed out"))

        client, originals, patches = await _make_resilience_client(mock_github_client)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/repos/{SEED_ORG}/test-repo")
            assert resp.status_code != 500
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Missing optional services
# ---------------------------------------------------------------------------


class TestMissingOptionalServices:
    """App works when optional services (DB, search, billing) aren't configured."""

    async def test_healthz_without_db(self, mock_github_client: MagicMock):
        """Health check works without database."""
        client, originals, patches = await _make_resilience_client(mock_github_client)
        try:
            resp = await client.get("/healthz")
            assert resp.status_code == 200
            assert resp.json() == {"status": "ok"}
        finally:
            await _cleanup(client, originals, patches)

    async def test_landing_page_without_db(self, mock_github_client: MagicMock):
        """Landing page renders without database."""
        client, originals, patches = await _make_resilience_client(mock_github_client)
        try:
            resp = await client.get("/")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)

    async def test_dashboard_without_search_index(self, mock_github_client: MagicMock):
        """Dashboard renders when search index is None."""
        child = mock_github_client.for_installation.return_value
        child.list_installation_repos = AsyncMock(return_value=[])
        child.get_file_content = AsyncMock(return_value=None)
        child.list_directory = AsyncMock(return_value=[])

        client, originals, patches = await _make_resilience_client(
            mock_github_client, search_index=None
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Admin store failures
# ---------------------------------------------------------------------------


class TestAdminStoreFailures:
    """Admin dashboard handles store exceptions."""

    async def test_dashboard_with_kpi_failure(self, mock_github_client: MagicMock):
        """Admin dashboard renders default KPIs when store.get_kpis() fails."""
        from canon.admin.middleware import require_super_admin
        from canon.auth.models import CurrentUser
        from canon.auth.permissions import Permission

        admin_user = CurrentUser(
            sub="admin-1",
            email="admin@test.com",
            name="Admin",
            org_login="canonhq",
            permissions=frozenset(Permission),
            auth_method="session",
        )

        admin_store = AsyncMock()
        admin_store.get_kpis = AsyncMock(side_effect=Exception("DB connection lost"))
        admin_store.get_health_summary = AsyncMock(side_effect=Exception("DB connection lost"))

        audit_store = AsyncMock()
        audit_store.list = AsyncMock(side_effect=Exception("DB connection lost"))

        client, originals, patches = await _make_resilience_client(
            mock_github_client, admin_store=admin_store, audit_store=audit_store
        )
        app.dependency_overrides[require_super_admin] = lambda: admin_user
        try:
            resp = await client.get("/api/admin/dashboard")
            assert resp.status_code == 200
            data = resp.json()
            # Should return default KPIs, not crash
            assert data["kpis"]["org_count"] == 0
        finally:
            app.dependency_overrides.pop(require_super_admin, None)
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Webhook handlers with broken dependencies
# ---------------------------------------------------------------------------


class TestWebhookResilience:
    """Webhook endpoint handles errors in event handlers gracefully."""

    async def test_push_handler_exception_returns_200(self, app_client: httpx.AsyncClient):
        """Push handler exception → 200 (not 500, to avoid webhook retry storms)."""
        import json

        from .conftest import TEST_WEBHOOK_SECRET, sign_payload, webhook_headers

        payload = json.dumps(
            {
                "ref": "refs/heads/main",
                "repository": {"full_name": f"{SEED_ORG}/test-repo"},
                "installation": {"id": 12345},
                "commits": [],
            }
        ).encode()

        sig = sign_payload(payload, TEST_WEBHOOK_SECRET)
        headers = webhook_headers("push", sig)

        with patch(
            "canon.github.handlers.on_push.on_push",
            new_callable=AsyncMock,
            side_effect=Exception("Unexpected error in handler"),
        ):
            resp = await app_client.post("/webhook", content=payload, headers=headers)

        # Should return 200 even when handler fails — the webhook endpoint
        # catches exceptions to avoid retry storms from GitHub
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Registry failures during org resolution
# ---------------------------------------------------------------------------


class TestRegistryFailures:
    """Registry errors during org-scoped operations."""

    async def test_welcome_page_handles_registry_error(self, mock_github_client: MagicMock):
        """Welcome page renders even when registry.get_installation_by_org fails."""
        registry = AsyncMock()
        registry.get_installation_by_org = AsyncMock(side_effect=Exception("Registry unavailable"))
        registry.get_installation_by_org_any_status = AsyncMock(return_value=None)

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )
        app.state.registry = registry

        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                resp = await client.get(f"/app/{SEED_ORG}/welcome")
                # Should render, not 500
                assert resp.status_code == 200

        _restore_app_state(originals)
