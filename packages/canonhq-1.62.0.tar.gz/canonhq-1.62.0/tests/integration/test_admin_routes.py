"""Integration tests for admin panel routes through the real FastAPI stack.

Uses dependency_overrides for require_super_admin (admin auth requires DB),
but exercises the full route handler → store interaction chain.
"""

from __future__ import annotations

from typing import ClassVar
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.admin.middleware import require_super_admin
from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission
from canon.main import app

from .conftest import (
    _base_settings,
    _restore_app_state,
    _set_app_state,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_ADMIN_USER = CurrentUser(
    sub="admin-1",
    email="admin@canonhq.co",
    name="Admin User",
    org_login="canonhq",
    permissions=frozenset(Permission),
    auth_method="session",
)

_NON_ADMIN_USER = CurrentUser(
    sub="user-1",
    email="user@test.com",
    name="Regular User",
    org_login="test-org",
    permissions=frozenset({Permission.SPECS_READ, Permission.SPECS_WRITE}),
    auth_method="session",
)


@pytest.fixture
async def admin_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """Admin-authenticated client with mock stores."""
    settings = _base_settings(deployment_mode="cloud")
    admin_store = AsyncMock()
    admin_store.get_kpis = AsyncMock(
        return_value={
            "org_count": 5,
            "user_count": 20,
            "spec_count": 10,
            "avg_coverage_pct": 42.5,
        }
    )
    admin_store.get_health_summary = AsyncMock(return_value=[])
    admin_store.list_orgs = AsyncMock(return_value=[])
    admin_store.get_org = AsyncMock(return_value=None)
    admin_store.list_users = AsyncMock(return_value=[])
    admin_store.get_user = AsyncMock(return_value=None)

    audit_store = AsyncMock()
    audit_store.list = AsyncMock(return_value=[])
    audit_store.record = AsyncMock()

    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        admin_store=admin_store,
        audit_store=audit_store,
    )

    app.dependency_overrides[require_super_admin] = lambda: _ADMIN_USER

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            yield client

    app.dependency_overrides.pop(require_super_admin, None)
    _restore_app_state(originals)


@pytest.fixture
async def non_admin_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """Authenticated but non-admin client (for auth enforcement tests)."""
    settings = _base_settings(deployment_mode="cloud")
    originals = _set_app_state(settings, github_client=mock_github_client)

    # Override require_super_admin to simulate a non-admin user
    app.dependency_overrides[require_super_admin] = lambda: (_ for _ in ()).throw(
        __import__("fastapi").HTTPException(status_code=403, detail="Insufficient permissions")
    )

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            yield client

    app.dependency_overrides.pop(require_super_admin, None)
    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Auth enforcement
# ---------------------------------------------------------------------------


class TestAdminAuthEnforcement:
    """Verify admin routes enforce PLATFORM_MANAGE permission."""

    ADMIN_ROUTES: ClassVar[list[str]] = [
        "/api/admin/config",
        "/api/admin/dashboard",
        "/api/admin/orgs",
        "/api/admin/users",
        "/api/admin/health",
        "/api/admin/audit",
    ]

    async def test_non_admin_gets_403(self, non_admin_client: httpx.AsyncClient):
        for route in self.ADMIN_ROUTES:
            resp = await non_admin_client.get(route)
            assert resp.status_code == 403, f"{route} should return 403 for non-admin"


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


class TestAdminConfig:
    async def test_config_returns_cloud_features(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/config")
        assert resp.status_code == 200
        data = resp.json()
        assert data["mode"] == "cloud"
        assert "features" in data

    async def test_config_self_hosted_features(self, admin_client: httpx.AsyncClient):
        app.state.settings = _base_settings(deployment_mode="self_hosted")
        resp = await admin_client.get("/api/admin/config")
        assert resp.status_code == 200
        data = resp.json()
        assert data["mode"] == "self_hosted"


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


class TestAdminDashboard:
    async def test_dashboard_returns_kpis(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/dashboard")
        assert resp.status_code == 200
        data = resp.json()
        assert "kpis" in data
        assert data["kpis"]["org_count"] == 5

    async def test_dashboard_handles_missing_store(self, admin_client: httpx.AsyncClient):
        """Dashboard returns default KPIs when admin_store is None."""
        app.state.admin_store = None
        app.state.audit_store = None
        resp = await admin_client.get("/api/admin/dashboard")
        assert resp.status_code == 200
        data = resp.json()
        assert data["kpis"]["org_count"] == 0


# ---------------------------------------------------------------------------
# Orgs
# ---------------------------------------------------------------------------


class TestOrgManagement:
    async def test_list_orgs(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/orgs")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    async def test_list_orgs_with_search(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/orgs?search=test")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------


class TestUserManagement:
    async def test_list_users(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/users")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    async def test_get_user_not_found(self, admin_client: httpx.AsyncClient):
        # user_id is int — use a numeric ID
        resp = await admin_client.get("/api/admin/users/99999")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Health & Audit
# ---------------------------------------------------------------------------


class TestAdminHealth:
    async def test_health_returns_200(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/health")
        assert resp.status_code == 200


class TestAuditLog:
    async def test_audit_returns_200(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/audit")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Org CRUD — suspend / reactivate
# ---------------------------------------------------------------------------


class TestOrgSuspendReactivate:
    async def test_suspend_org(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.suspend_org = AsyncMock(return_value={"login": "acme", "status": "suspended"})
        resp = await admin_client.post("/api/admin/orgs/acme/suspend")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "suspended"

    async def test_suspend_nonexistent_org(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.suspend_org = AsyncMock(return_value=None)
        resp = await admin_client.post("/api/admin/orgs/unknown/suspend")
        assert resp.status_code == 404

    async def test_reactivate_org(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.reactivate_org = AsyncMock(return_value={"login": "acme", "status": "active"})
        resp = await admin_client.post("/api/admin/orgs/acme/reactivate")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "active"

    async def test_reactivate_nonexistent_org(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.reactivate_org = AsyncMock(return_value=None)
        resp = await admin_client.post("/api/admin/orgs/unknown/reactivate")
        assert resp.status_code == 404

    async def test_reindex_org(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.post("/api/admin/orgs/acme/reindex")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"


# ---------------------------------------------------------------------------
# User CRUD — deactivate / reactivate / role update
# ---------------------------------------------------------------------------


class TestUserCrud:
    _SEED_USER: ClassVar[dict] = {
        "id": 1,
        "login": "alice",
        "email": "alice@test.com",
        "role": "editor",
        "status": "active",
        "org_login": "canonhq",
    }

    async def test_deactivate_user(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.get_user = AsyncMock(return_value=self._SEED_USER)
        admin_store.deactivate_user = AsyncMock(
            return_value={**self._SEED_USER, "status": "deactivated"}
        )
        resp = await admin_client.post("/api/admin/users/1/deactivate")
        assert resp.status_code == 200

    async def test_deactivate_nonexistent_user(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.get_user = AsyncMock(return_value=None)
        resp = await admin_client.post("/api/admin/users/99999/deactivate")
        assert resp.status_code == 404

    async def test_reactivate_user(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.get_user = AsyncMock(return_value={**self._SEED_USER, "status": "deactivated"})
        admin_store.reactivate_user = AsyncMock(return_value=self._SEED_USER)
        resp = await admin_client.post("/api/admin/users/1/reactivate")
        assert resp.status_code == 200

    async def test_update_user_role(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.get_user = AsyncMock(return_value=self._SEED_USER)
        admin_store.update_user_role = AsyncMock(return_value={**self._SEED_USER, "role": "admin"})
        resp = await admin_client.patch(
            "/api/admin/users/1",
            json={"role": "admin"},
        )
        assert resp.status_code == 200

    async def test_delete_user_requires_confirm_body(self, admin_client: httpx.AsyncClient):
        """DELETE /users/{id} requires a confirmation body — 422 without it."""
        resp = await admin_client.delete("/api/admin/users/1")
        assert resp.status_code == 422

    async def test_delete_user_route_wired(self, admin_client: httpx.AsyncClient):
        """DELETE /users/{id} route is wired (not 404)."""
        resp = await admin_client.request(
            "DELETE",
            "/api/admin/users/1",
            json={"confirm": "alice@test.com"},
        )
        # Should not be 404 — route exists. Will be 503 (missing user_store/provider)
        assert resp.status_code != 404


# ---------------------------------------------------------------------------
# Billing (admin view)
# ---------------------------------------------------------------------------


class TestAdminBilling:
    async def test_billing_overview(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/billing")
        assert resp.status_code in (200, 503)

    async def test_billing_for_org(self, admin_client: httpx.AsyncClient):
        admin_store = app.state.admin_store
        admin_store.get_org_billing = AsyncMock(return_value=None)
        resp = await admin_client.get("/api/admin/billing/acme")
        assert resp.status_code in (200, 404)


# ---------------------------------------------------------------------------
# Integrations / AI overview
# ---------------------------------------------------------------------------


class TestAdminIntegrations:
    async def test_integrations_returns_200(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/integrations")
        assert resp.status_code == 200

    async def test_ai_overview_returns_200(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/ai")
        assert resp.status_code == 200

    async def test_ai_org_detail(self, admin_client: httpx.AsyncClient):
        resp = await admin_client.get("/api/admin/ai/acme")
        assert resp.status_code == 200
