"""Shared fixtures for integration tests."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import uuid
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport
from itsdangerous import TimestampSigner
from pydantic import BaseModel

from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission
from canon.main import app
from canon.settings import Settings

TEST_WEBHOOK_SECRET = "test-webhook-secret-for-integration"

# SessionMiddleware signing key — matches the fallback when no OIDC secrets set.
_SESSION_KEY = "dev-not-secret"

# ---------------------------------------------------------------------------
# State attributes managed by the lifespan that we save/restore per fixture
# ---------------------------------------------------------------------------
_STATE_ATTRS = (
    "settings",
    "db_pool",
    "registry",
    "user_store",
    "session_store",
    "agent_store",
    "github_client",
    "cache",
    "oidc_provider",
    "admin_store",
    "audit_store",
    "billing_service",
    "stripe_client",
    "search_index",
    "embed_client",
    "indexer",
    "posthog_query_client",
    "slack_alerter",
)


@pytest.fixture
def webhook_secret() -> str:
    return TEST_WEBHOOK_SECRET


def sign_payload(payload: bytes, secret: str) -> str:
    """Compute a real HMAC-SHA256 signature matching GitHub's format."""
    sig = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    return f"sha256={sig}"


def webhook_headers(event: str, signature: str, delivery: str | None = None) -> dict[str, str]:
    """Build realistic GitHub webhook headers."""
    return {
        "x-github-event": event,
        "x-hub-signature-256": signature,
        "x-github-delivery": delivery or uuid.uuid4().hex,
        "content-type": "application/json",
    }


def make_payload(event: str, **overrides: Any) -> dict:
    """Build a minimal valid webhook payload for the given event type."""
    base: dict[str, Any] = {
        "repository": {"full_name": "test-org/test-repo"},
        "installation": {"id": 12345},
    }

    if event == "push":
        base.update({"ref": "refs/heads/main", "commits": []})
    elif event == "pull_request":
        base.update(
            {
                "action": overrides.pop("action", "opened"),
                "pull_request": {
                    "number": 42,
                    "head": {"sha": "abc123", "ref": "feature"},
                    "base": {"ref": "main"},
                    "merged": overrides.pop("merged", False),
                },
            }
        )
    elif event == "issue_comment":
        base.update(
            {
                "action": overrides.pop("action", "created"),
                "issue": {"number": 10, "pull_request": {"url": "..."}},
                "comment": {"body": "test comment", "user": {"login": "tester"}},
            }
        )
    elif event == "issues":
        base.update(
            {
                "action": overrides.pop("action", "opened"),
                "issue": {"number": 5, "title": "test issue"},
            }
        )
    elif event == "installation":
        base.update({"action": overrides.pop("action", "created")})
    elif event == "installation_repositories":
        base.update(
            {
                "action": overrides.pop("action", "added"),
                "repositories_added": [],
            }
        )

    base.update(overrides)
    return base


@pytest.fixture
def mock_github_client() -> MagicMock:
    """A mock GitHubClient that supports for_installation."""
    client = MagicMock()
    client.installation_id = "99999"
    child = MagicMock()
    child.installation_id = "12345"
    client.for_installation.return_value = child
    return client


@pytest.fixture
async def app_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """httpx.AsyncClient wired to the FastAPI app with test settings.

    Patches:
    - canon.main.settings with a test Settings instance
    - canon.main._get_client to return a mock GitHubClient
    - canon.main.analytics to no-op
    """
    test_settings = Settings(
        gh_webhook_secret=TEST_WEBHOOK_SECRET,
        gh_app_id="test-app-id",
        gh_private_key="test-key",
        gh_installation_id="99999",
    )

    # Set app.state attributes that middleware and handlers expect
    # (normally set during lifespan, which doesn't run in transport-only tests)
    state_attrs = (
        "settings",
        "db_pool",
        "registry",
        "user_store",
        "session_store",
        "agent_store",
        "github_client",
    )
    originals = {attr: getattr(app.state, attr, None) for attr in state_attrs}

    app.state.settings = test_settings
    app.state.db_pool = None
    app.state.registry = None
    app.state.user_store = None
    app.state.session_store = None
    app.state.agent_store = None
    app.state.github_client = mock_github_client

    with (
        patch("canon.main.settings", test_settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            yield client

    # Restore original app.state to avoid leaking between test modules
    for attr, value in originals.items():
        setattr(app.state, attr, value)


# ---------------------------------------------------------------------------
# Session cookie helpers
# ---------------------------------------------------------------------------


def make_session_cookie(data: dict, secret: str = _SESSION_KEY) -> str:
    """Create a signed Starlette session cookie."""
    payload = base64.b64encode(json.dumps(data).encode()).decode()
    return TimestampSigner(secret).sign(payload).decode()


def _session_data_for_user(
    *,
    sub: str = "test-user-1",
    email: str = "user@test.com",
    name: str = "Test User",
    org_login: str = "test-org",
    permissions: list[str] | None = None,
) -> dict:
    """Build a session dict matching what the OAuth callback stores."""
    if permissions is None:
        permissions = [p.value for p in Permission]
    return {
        "user": {
            "sub": sub,
            "email": email,
            "name": name,
            "org_login": org_login,
            "permissions": permissions,
        }
    }


# ---------------------------------------------------------------------------
# Seed data
# ---------------------------------------------------------------------------

SEED_ORG = "test-org"
SEED_REPO = "test-repo"

SEED_SPEC = {
    "path": "docs/specs/auth-migration.md",
    "title": "Auth Migration",
    "status": "in_progress",
    "owner": "alice",
    "team": "platform",
    "sections_total": 5,
    "sections_done": 2,
}

SEED_REPOS = [
    {"full_name": f"{SEED_ORG}/{SEED_REPO}", "name": SEED_REPO},
    {"full_name": f"{SEED_ORG}/docs", "name": "docs"},
]


def _base_settings(**overrides) -> Settings:
    """Settings factory with minimal required fields."""
    defaults = dict(
        gh_app_id="test-app-id",
        gh_private_key="test-key",
        gh_webhook_secret=TEST_WEBHOOK_SECRET,
        gh_installation_id="99999",
        web_org=SEED_ORG,
    )
    defaults.update(overrides)
    return Settings(**defaults)


def _set_app_state(
    settings: Settings,
    *,
    github_client: Any = None,
    oidc_provider: Any = None,
    admin_store: Any = None,
    audit_store: Any = None,
    user_store: Any = None,
    session_store: Any = None,
    billing_service: Any = None,
    stripe_client: Any = None,
    search_index: Any = None,
) -> dict:
    """Populate app.state attributes normally set by the lifespan.

    Returns a dict of original values for restoration.
    """
    originals = {attr: getattr(app.state, attr, None) for attr in _STATE_ATTRS}

    app.state.settings = settings
    app.state.db_pool = None
    _registry = AsyncMock()
    _registry.get_installation_by_org = AsyncMock(return_value=None)
    _registry.get_installation_by_org_any_status = AsyncMock(return_value=None)
    _registry.list_orgs = AsyncMock(return_value=[])
    app.state.registry = _registry
    app.state.user_store = user_store
    app.state.session_store = session_store
    app.state.agent_store = None
    app.state.github_client = github_client or MagicMock()
    app.state.cache = MagicMock()
    app.state.oidc_provider = oidc_provider
    app.state.admin_store = admin_store
    app.state.audit_store = audit_store
    app.state.billing_service = billing_service
    app.state.stripe_client = stripe_client
    app.state.search_index = search_index
    app.state.embed_client = MagicMock(is_available=False)
    app.state.indexer = MagicMock()
    app.state.posthog_query_client = MagicMock(configured=False)
    app.state.slack_alerter = MagicMock(enabled=False)

    return originals


def _restore_app_state(originals: dict) -> None:
    """Restore app.state from a saved dict."""
    for attr, value in originals.items():
        setattr(app.state, attr, value)


# ---------------------------------------------------------------------------
# Authenticated client fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def authed_app_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """httpx.AsyncClient with a valid session cookie (authenticated as test user).

    Auth middleware sees the session cookie and allows /app/* routes.
    The ``get_current_user`` dependency resolves to a user with all permissions.
    """
    settings = _base_settings()
    originals = _set_app_state(settings, github_client=mock_github_client)

    cookie = make_session_cookie(_session_data_for_user())

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
        patch("canon.web.routes._get_spa_html", return_value=None),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(
            transport=transport,
            base_url="http://test",
            cookies={"session": cookie},
        ) as client:
            yield client

    _restore_app_state(originals)


@pytest.fixture
async def noauth_app_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """httpx.AsyncClient with auth disabled (anonymous access)."""
    settings = _base_settings()
    originals = _set_app_state(settings, github_client=mock_github_client)

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
        patch("canon.web.routes._get_spa_html", return_value=None),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(
            transport=transport,
            base_url="http://test",
        ) as client:
            yield client

    _restore_app_state(originals)


@pytest.fixture
async def admin_app_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """httpx.AsyncClient authenticated as a super-admin user.

    Uses dependency_overrides for ``require_super_admin`` so admin routes
    skip the full auth lookup (which needs a real DB) but still exercise
    the route handlers and their store interactions.
    """
    from canon.admin.middleware import require_super_admin

    admin_user = CurrentUser(
        sub="admin-1",
        email="admin@canonhq.co",
        name="Admin User",
        org_login="canonhq",
        permissions=frozenset(Permission),
        auth_method="session",
    )

    settings = _base_settings(deployment_mode="cloud")
    admin_store = AsyncMock()
    audit_store = AsyncMock()
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        admin_store=admin_store,
        audit_store=audit_store,
    )

    app.dependency_overrides[require_super_admin] = lambda: admin_user

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(
            transport=transport,
            base_url="http://test",
        ) as client:
            yield client

    app.dependency_overrides.pop(require_super_admin, None)
    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Assertion helpers
# ---------------------------------------------------------------------------


def assert_html_contains(response: httpx.Response, *fragments: str) -> None:
    """Assert response is 200 HTML and contains all given text fragments."""
    assert response.status_code == 200, (
        f"Expected 200, got {response.status_code}: {response.text[:200]}"
    )
    for frag in fragments:
        assert frag in response.text, f"Expected {frag!r} in response body"


def assert_redirects_to(response: httpx.Response, location: str) -> None:
    """Assert response is a 302/307 redirect to the expected location."""
    assert response.status_code in (302, 307), f"Expected redirect, got {response.status_code}"
    actual = response.headers.get("location", "")
    assert location in actual, f"Expected redirect to {location!r}, got {actual!r}"


def assert_json_matches(response: httpx.Response, model_cls: type[BaseModel]) -> None:
    """Assert response is 200 JSON that validates against a Pydantic model."""
    assert response.status_code == 200, (
        f"Expected 200, got {response.status_code}: {response.text[:200]}"
    )
    model_cls.model_validate(response.json())
