"""Integration tests for the editor routes (/app/{org}/editor/*).

Tests the GitHub-backed web editor through the full FastAPI stack,
covering file listing, file loading, save operations, and auth enforcement.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def editor_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """Authenticated client for editor routes with GitHub OAuth session."""
    settings = _base_settings(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="test-client",
        oidc_client_secret="test-oidc-secret",
        web_org="",
    )
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        oidc_provider=MagicMock(),
    )

    # Session with GitHub OAuth token (needed for editor)
    session = _session_data_for_user(org_login=SEED_ORG)
    session["github_user"] = {
        "login": "testuser",
        "name": "Test User",
        "email": "test@example.com",
        "avatar_url": "",
        "token": "gho_test_github_token",
    }
    cookie = make_session_cookie(session)

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
        patch("canon.web.routes._get_spa_html", return_value=None),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(
            transport=transport,
            base_url="http://test",
            cookies={"session": cookie},
        ) as client:
            yield client

    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Editor index
# ---------------------------------------------------------------------------


class TestEditorIndex:
    async def test_editor_index_returns_200(self, editor_client: httpx.AsyncClient):
        """GET /app/{org}/editor/ returns editor index page."""
        resp = await editor_client.get(f"/app/{SEED_ORG}/editor/")
        # Returns 200 (Jinja template) or redirects
        assert resp.status_code in (200, 302, 307)


# ---------------------------------------------------------------------------
# Editor repos list
# ---------------------------------------------------------------------------


class TestEditorRepos:
    async def test_list_repos_returns_json(self, editor_client: httpx.AsyncClient):
        """GET /app/{org}/editor/repos returns list of repos."""
        gh = app.state.github_client
        child = gh.for_installation.return_value
        child.list_installation_repos = AsyncMock(
            return_value=[
                {"name": "repo-a", "full_name": f"{SEED_ORG}/repo-a", "owner": {"login": SEED_ORG}},
            ]
        )

        resp = await editor_client.get(f"/app/{SEED_ORG}/editor/repos")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)


# ---------------------------------------------------------------------------
# Editor file loading
# ---------------------------------------------------------------------------


class TestEditorFileLoad:
    async def test_load_nonexistent_file(self, editor_client: httpx.AsyncClient):
        """Loading a nonexistent file returns 404."""
        with patch("canon.web.editor_routes.UserGitHubClient") as MockUserClient:
            mock_user_client = AsyncMock()
            mock_user_client.get_file_content = AsyncMock(return_value=None)
            MockUserClient.return_value = mock_user_client

            resp = await editor_client.get(
                f"/app/{SEED_ORG}/editor/{SEED_ORG}/test-repo/nonexistent.md/json"
            )
            assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Editor save
# ---------------------------------------------------------------------------


class TestEditorSave:
    async def test_save_requires_write_permission(self, mock_github_client: MagicMock):
        """Save endpoint requires SPECS_WRITE permission."""
        from canon.auth.permissions import Permission

        # Session with read-only permissions
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        session = _session_data_for_user(
            org_login=SEED_ORG,
            permissions=[Permission.SPECS_READ.value],
        )
        session["github_user"] = {"login": "testuser", "token": "gho_test"}
        cookie = make_session_cookie(session)

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                resp = await client.post(
                    f"/app/{SEED_ORG}/editor/{SEED_ORG}/test-repo/docs/specs/test.md/save",
                    json={"content": "# Updated", "sha": "abc123", "message": "test"},
                )
                assert resp.status_code == 403

        _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Editor parse
# ---------------------------------------------------------------------------


class TestEditorParse:
    async def test_parse_returns_spec_structure(self, editor_client: httpx.AsyncClient):
        """POST /app/{org}/editor/{owner}/{repo}/parse returns parsed spec."""
        resp = await editor_client.post(
            f"/app/{SEED_ORG}/editor/{SEED_ORG}/test-repo/parse",
            json={
                "content": "---\ntitle: Test\nstatus: draft\n---\n\n# Test\n\n## 1. Section\n\n- [ ] AC 1\n",
                "file_path": "docs/specs/test.md",
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "sections" in data or "title" in data


# ---------------------------------------------------------------------------
# Editor new spec template
# ---------------------------------------------------------------------------


class TestEditorNewPage:
    async def test_new_spec_page_returns_200(self, editor_client: httpx.AsyncClient):
        """GET /app/{org}/editor/{owner}/{repo}/new returns the new spec page."""
        resp = await editor_client.get(f"/app/{SEED_ORG}/editor/{SEED_ORG}/test-repo/new")
        # Returns 200 (Jinja/SPA) or 302 redirect
        assert resp.status_code in (200, 302, 307)
