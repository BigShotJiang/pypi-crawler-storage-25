"""Integration tests for ticket proxy routes (/app/{org}/api/tickets/*).

Tests the server-side ticket proxy that lets CLI users manage tickets
through the Canon server without local ticket-system credentials.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
import respx
from httpx import Response

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def ticket_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """Authenticated client with GitHub client that returns installation tokens."""
    settings = _base_settings(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="test-client",
        oidc_client_secret="test-oidc-secret",
        web_org="",
    )
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        oidc_provider=MagicMock(),
    )

    # Mock the GitHub client chain for ticket operations
    child = mock_github_client.for_installation.return_value
    child.get_installation_token = AsyncMock(return_value="ghs_test_token_123")
    child.installation_id = "12345"
    mock_github_client.installation_id = "99999"
    mock_github_client.get_installation_token = AsyncMock(return_value="ghs_test_token_123")

    cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
    ):
        from httpx import ASGITransport

        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(
            transport=transport,
            base_url="http://test",
            cookies={"session": cookie},
        ) as client:
            yield client

    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Create ticket
# ---------------------------------------------------------------------------


class TestCreateTicket:
    @respx.mock
    async def test_create_github_ticket(self, ticket_client: httpx.AsyncClient):
        """Create ticket through GitHub adapter."""
        respx.post(f"https://api.github.com/repos/{SEED_ORG}/test-repo/issues").mock(
            return_value=Response(
                201,
                json={
                    "number": 42,
                    "html_url": f"https://github.com/{SEED_ORG}/test-repo/issues/42",
                    "labels": [],
                },
            )
        )

        resp = await ticket_client.post(
            f"/app/{SEED_ORG}/api/tickets/create",
            json={
                "owner": SEED_ORG,
                "repo": "test-repo",
                "input": {
                    "project_key": "test-repo",
                    "summary": "Test ticket",
                    "description": "Created via integration test",
                    "status": {"state": "todo"},
                },
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ticket_id"] == "42"

    async def test_create_ticket_missing_owner_repo(self, ticket_client: httpx.AsyncClient):
        """GitHub tickets require owner and repo."""
        resp = await ticket_client.post(
            f"/app/{SEED_ORG}/api/tickets/create",
            json={
                "input": {
                    "project_key": "test-repo",
                    "summary": "Test ticket",
                    "description": "",
                    "status": {"state": "todo"},
                },
            },
        )
        assert resp.status_code == 400

    async def test_create_ticket_owner_org_mismatch(self, ticket_client: httpx.AsyncClient):
        """Owner in body must match org in path."""
        resp = await ticket_client.post(
            f"/app/{SEED_ORG}/api/tickets/create",
            json={
                "owner": "other-org",
                "repo": "test-repo",
                "input": {
                    "project_key": "test-repo",
                    "summary": "Test ticket",
                    "description": "",
                    "status": {"state": "todo"},
                },
            },
        )
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Get ticket status
# ---------------------------------------------------------------------------


class TestGetTicketStatus:
    @respx.mock
    async def test_get_status(self, ticket_client: httpx.AsyncClient):
        respx.get(f"https://api.github.com/repos/{SEED_ORG}/test-repo/issues/42").mock(
            return_value=Response(
                200,
                json={
                    "number": 42,
                    "state": "open",
                    "labels": [{"name": "canon:in-progress"}],
                },
            )
        )

        resp = await ticket_client.post(
            f"/app/{SEED_ORG}/api/tickets/status",
            json={
                "owner": SEED_ORG,
                "repo": "test-repo",
                "ticket_id": "42",
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ticket_id"] == "42"
        assert data["status"]["state"] == "in_progress"


# ---------------------------------------------------------------------------
# Batch status
# ---------------------------------------------------------------------------


class TestBatchTicketStatus:
    @respx.mock
    async def test_batch_status(self, ticket_client: httpx.AsyncClient):
        for num in [1, 2]:
            respx.get(f"https://api.github.com/repos/{SEED_ORG}/test-repo/issues/{num}").mock(
                return_value=Response(
                    200,
                    json={
                        "number": num,
                        "state": "open",
                        "labels": [{"name": "canon:todo"}],
                    },
                )
            )

        resp = await ticket_client.post(
            f"/app/{SEED_ORG}/api/tickets/batch-status",
            json={
                "owner": SEED_ORG,
                "repo": "test-repo",
                "ticket_ids": ["1", "2"],
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["results"]) == 2
        assert len(data["errors"]) == 0


# ---------------------------------------------------------------------------
# Search tickets
# ---------------------------------------------------------------------------


class TestSearchTickets:
    @respx.mock
    async def test_search(self, ticket_client: httpx.AsyncClient):
        respx.get("https://api.github.com/search/issues").mock(
            return_value=Response(
                200,
                json={
                    "total_count": 1,
                    "items": [
                        {
                            "number": 10,
                            "title": "Auth Migration",
                            "html_url": f"https://github.com/{SEED_ORG}/test-repo/issues/10",
                            "state": "open",
                        }
                    ],
                },
            )
        )

        resp = await ticket_client.post(
            f"/app/{SEED_ORG}/api/tickets/search",
            json={
                "owner": SEED_ORG,
                "repo": "test-repo",
                "project_key": "test-repo",
                "title_pattern": "Auth",
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1


# ---------------------------------------------------------------------------
# Jira/Linear without integration store → 503
# ---------------------------------------------------------------------------


class TestTicketSystemUnavailable:
    async def test_jira_without_store_returns_503(self, ticket_client: httpx.AsyncClient):
        """Jira ticket operations fail when integration store is unavailable."""
        app.state.integration_store = None
        resp = await ticket_client.post(
            f"/app/{SEED_ORG}/api/tickets/status",
            json={
                "ticket_system": "jira",
                "ticket_id": "PROJ-42",
            },
        )
        assert resp.status_code == 503

    async def test_linear_without_store_returns_503(self, ticket_client: httpx.AsyncClient):
        app.state.integration_store = None
        resp = await ticket_client.post(
            f"/app/{SEED_ORG}/api/tickets/status",
            json={
                "ticket_system": "linear",
                "ticket_id": "ENG-42",
            },
        )
        assert resp.status_code == 503
