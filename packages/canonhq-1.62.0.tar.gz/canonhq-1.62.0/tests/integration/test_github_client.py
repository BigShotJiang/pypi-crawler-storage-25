"""Integration tests for GitHubClient.

Tests the GitHub API client through realistic HTTP-level mocking using respx,
verifying JWT generation, auth header formatting, error handling, and pagination
against the actual client code (not mocked internals).
"""

from __future__ import annotations

import base64
import time

import httpx
import jwt as pyjwt
import pytest
import respx
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from httpx import Response

from canon.github.client import GitHubClient, InstallationNotFound

pytestmark = pytest.mark.integration

# Generate a real RSA key pair for JWT testing
_RSA_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)
TEST_PRIVATE_KEY_PEM = _RSA_KEY.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption(),
).decode()
TEST_PUBLIC_KEY = _RSA_KEY.public_key()

TEST_APP_ID = "12345"
TEST_INSTALLATION_ID = "67890"
GITHUB_API = "https://api.github.com"


@pytest.fixture
def client():
    """Create a GitHubClient with a real RSA key for JWT verification."""
    return GitHubClient(
        app_id=TEST_APP_ID,
        private_key=TEST_PRIVATE_KEY_PEM,
        installation_id=TEST_INSTALLATION_ID,
    )


def mock_token_exchange(router: respx.Router, token: str = "ghs_test_token_abc123") -> None:
    """Set up the installation token exchange endpoint on a respx router."""
    router.post(f"/app/installations/{TEST_INSTALLATION_ID}/access_tokens").mock(
        return_value=Response(200, json={"token": token})
    )


class TestJWTGenerationAndAuthHeaders:
    """AC: JWT generation and header formatting verified end-to-end."""

    def test_jwt_has_correct_claims(self, client):
        """JWT contains iat, exp, iss claims with correct values."""
        now = int(time.time())
        token = client._generate_jwt()

        decoded = pyjwt.decode(
            token,
            TEST_PUBLIC_KEY,
            algorithms=["RS256"],
            options={"verify_exp": False},
        )

        assert decoded["iss"] == TEST_APP_ID
        assert decoded["iat"] <= now
        assert decoded["exp"] > now

    def test_jwt_is_valid_rs256(self, client):
        """JWT can be verified with the corresponding public key."""
        token = client._generate_jwt()

        # Should not raise
        pyjwt.decode(
            token,
            TEST_PUBLIC_KEY,
            algorithms=["RS256"],
            options={"verify_exp": False},
        )

    @respx.mock
    async def test_installation_token_exchange_sends_jwt_bearer(self, client):
        """Token exchange request includes JWT in Bearer header."""
        route = respx.post(
            f"{GITHUB_API}/app/installations/{TEST_INSTALLATION_ID}/access_tokens"
        ).mock(return_value=Response(200, json={"token": "ghs_result"}))

        token = await client._get_installation_token()

        assert token == "ghs_result"
        assert route.called
        auth_header = route.calls[0].request.headers["authorization"]
        assert auth_header.startswith("Bearer ")
        jwt_token = auth_header.split(" ", 1)[1]
        # Verify the JWT is decodable with our public key
        decoded = pyjwt.decode(
            jwt_token, TEST_PUBLIC_KEY, algorithms=["RS256"], options={"verify_exp": False}
        )
        assert decoded["iss"] == TEST_APP_ID

    @respx.mock
    async def test_api_calls_include_installation_token(self, client):
        """API methods send the installation token in Authorization header."""
        respx.post(f"{GITHUB_API}/app/installations/{TEST_INSTALLATION_ID}/access_tokens").mock(
            return_value=Response(200, json={"token": "ghs_install_token"})
        )

        route = respx.get(f"{GITHUB_API}/repos/acme/repo").mock(
            return_value=Response(200, json={"full_name": "acme/repo", "default_branch": "main"})
        )

        result = await client._get("/repos/acme/repo")

        assert result["default_branch"] == "main"
        auth_header = route.calls[0].request.headers["authorization"]
        assert auth_header == "token ghs_install_token"

    @respx.mock
    async def test_token_is_cached_across_calls(self, client):
        """Installation token is reused within its validity window."""
        token_route = respx.post(
            f"{GITHUB_API}/app/installations/{TEST_INSTALLATION_ID}/access_tokens"
        ).mock(return_value=Response(200, json={"token": "ghs_cached"}))

        respx.get(f"{GITHUB_API}/repos/acme/repo").mock(
            return_value=Response(200, json={"full_name": "acme/repo"})
        )
        respx.get(f"{GITHUB_API}/repos/acme/other").mock(
            return_value=Response(200, json={"full_name": "acme/other"})
        )

        await client._get("/repos/acme/repo")
        await client._get("/repos/acme/other")

        # Token exchange should only happen once
        assert token_route.call_count == 1


class TestRealisticResponseFixtures:
    """AC: GitHub API client tested with realistic response fixtures."""

    @respx.mock
    async def test_get_file_content_decodes_base64(self, client):
        """get_file_content correctly decodes base64 content from GitHub API."""
        mock_token_exchange(respx)
        file_content = "# My Spec\n\nThis is a spec document."
        encoded = base64.b64encode(file_content.encode()).decode()

        respx.get(f"{GITHUB_API}/repos/acme/repo/contents/docs/specs/auth.md").mock(
            return_value=Response(
                200,
                json={
                    "name": "auth.md",
                    "path": "docs/specs/auth.md",
                    "sha": "abc123def456",
                    "size": len(file_content),
                    "type": "file",
                    "content": encoded,
                    "encoding": "base64",
                },
            )
        )

        content, sha = await client.get_file_content("acme", "repo", "docs/specs/auth.md")

        assert content == file_content
        assert sha == "abc123def456"

    @respx.mock
    async def test_get_file_content_with_ref(self, client):
        """get_file_content passes ref parameter for branch/commit scoping."""
        mock_token_exchange(respx)
        encoded = base64.b64encode(b"branch content").decode()

        route = respx.get(f"{GITHUB_API}/repos/acme/repo/contents/README.md").mock(
            return_value=Response(200, json={"content": encoded, "sha": "sha789"})
        )

        content, _sha = await client.get_file_content(
            "acme", "repo", "README.md", ref="feature-branch"
        )

        assert content == "branch content"
        assert "ref" in str(route.calls[0].request.url)

    @respx.mock
    async def test_create_comment_sends_correct_payload(self, client):
        """create_comment sends the body in the expected format."""
        mock_token_exchange(respx)
        route = respx.post(f"{GITHUB_API}/repos/acme/repo/issues/42/comments").mock(
            return_value=Response(
                201,
                json={
                    "id": 100,
                    "body": "Great PR!",
                    "user": {"login": "canon-bot[bot]"},
                },
            )
        )

        result = await client.create_comment("acme", "repo", 42, "Great PR!")

        assert result["id"] == 100
        import json

        payload = json.loads(route.calls[0].request.content)
        assert payload == {"body": "Great PR!"}

    @respx.mock
    async def test_list_pull_files_returns_changed_files(self, client):
        """list_pull_files returns file change details from PR."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/repos/acme/repo/pulls/42/files").mock(
            return_value=Response(
                200,
                json=[
                    {
                        "sha": "abc123",
                        "filename": "docs/specs/auth.md",
                        "status": "modified",
                        "additions": 10,
                        "deletions": 2,
                        "changes": 12,
                        "patch": "@@ -1,5 +1,13 @@\n...",
                    },
                    {
                        "sha": "def456",
                        "filename": "src/auth/login.py",
                        "status": "added",
                        "additions": 50,
                        "deletions": 0,
                        "changes": 50,
                    },
                ],
            )
        )

        files = await client.list_pull_files("acme", "repo", 42)

        assert len(files) == 2
        assert files[0]["filename"] == "docs/specs/auth.md"
        assert files[0]["status"] == "modified"
        assert files[1]["status"] == "added"

    @respx.mock
    async def test_create_or_update_file_encodes_content(self, client):
        """create_or_update_file base64-encodes content for the API."""
        mock_token_exchange(respx)
        route = respx.put(f"{GITHUB_API}/repos/acme/repo/contents/docs/new.md").mock(
            return_value=Response(201, json={"content": {"sha": "new_sha"}})
        )

        await client.create_or_update_file(
            "acme", "repo", "docs/new.md", "# New File", "create doc"
        )

        import json

        payload = json.loads(route.calls[0].request.content)
        decoded_content = base64.b64decode(payload["content"]).decode()
        assert decoded_content == "# New File"
        assert payload["message"] == "create doc"
        assert "sha" not in payload  # No sha = new file

    @respx.mock
    async def test_upsert_bot_comment_creates_new(self, client):
        """upsert_bot_comment creates a new comment when none exists."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/repos/acme/repo/issues/10/comments").mock(
            return_value=Response(200, json=[])
        )
        create_route = respx.post(f"{GITHUB_API}/repos/acme/repo/issues/10/comments").mock(
            return_value=Response(201, json={"id": 200, "body": "..."})
        )

        await client.upsert_bot_comment("acme", "repo", 10, "Analysis complete.")

        import json

        payload = json.loads(create_route.calls[0].request.content)
        assert "<!-- canon-bot -->" in payload["body"]
        assert "Analysis complete." in payload["body"]

    @respx.mock
    async def test_upsert_bot_comment_updates_existing(self, client):
        """upsert_bot_comment updates existing bot comment instead of creating new."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/repos/acme/repo/issues/10/comments").mock(
            return_value=Response(
                200,
                json=[
                    {"id": 50, "body": "unrelated comment"},
                    {"id": 99, "body": "<!-- canon-bot -->\nOld analysis."},
                ],
            )
        )
        update_route = respx.patch(f"{GITHUB_API}/repos/acme/repo/issues/comments/99").mock(
            return_value=Response(200, json={"id": 99, "body": "..."})
        )

        await client.upsert_bot_comment("acme", "repo", 10, "New analysis.")

        import json

        payload = json.loads(update_route.calls[0].request.content)
        assert "New analysis." in payload["body"]


class TestErrorHandling:
    """AC: Error handling tested for common GitHub API failures."""

    @respx.mock
    async def test_installation_not_found_raises(self, client):
        """404 on token exchange raises InstallationNotFound."""
        respx.post(f"{GITHUB_API}/app/installations/{TEST_INSTALLATION_ID}/access_tokens").mock(
            return_value=Response(404, json={"message": "Not Found"})
        )

        with pytest.raises(InstallationNotFound) as exc_info:
            await client._get_installation_token()

        assert exc_info.value.installation_id == int(TEST_INSTALLATION_ID)

    @respx.mock
    async def test_500_server_error_raises_http_status_error(self, client):
        """500 responses raise httpx.HTTPStatusError."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/repos/acme/repo").mock(
            return_value=Response(500, json={"message": "Internal Server Error"})
        )

        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await client._get("/repos/acme/repo")

        assert exc_info.value.response.status_code == 500

    @respx.mock
    async def test_403_rate_limit_raises_http_status_error(self, client):
        """403 rate limit responses raise httpx.HTTPStatusError."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/repos/acme/repo/issues").mock(
            return_value=Response(
                403,
                json={"message": "API rate limit exceeded"},
                headers={
                    "x-ratelimit-limit": "5000",
                    "x-ratelimit-remaining": "0",
                    "x-ratelimit-reset": str(int(time.time()) + 3600),
                },
            )
        )

        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await client._get_list("/repos/acme/repo/issues")

        assert exc_info.value.response.status_code == 403

    @respx.mock
    async def test_404_on_api_call_raises_http_status_error(self, client):
        """404 on regular API calls raises httpx.HTTPStatusError."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/repos/acme/nonexistent").mock(
            return_value=Response(404, json={"message": "Not Found"})
        )

        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await client._get("/repos/acme/nonexistent")

        assert exc_info.value.response.status_code == 404

    @respx.mock
    async def test_list_directory_404_returns_empty_list(self, client):
        """list_directory gracefully returns empty list on 404."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/repos/acme/repo/contents/nonexistent").mock(
            return_value=Response(404, json={"message": "Not Found"})
        )

        result = await client.list_directory("acme", "repo", "nonexistent")

        assert result == []

    @respx.mock
    async def test_ensure_label_ignores_422_duplicate(self, client):
        """ensure_label silently handles 422 for existing labels."""
        mock_token_exchange(respx)
        respx.post(f"{GITHUB_API}/repos/acme/repo/labels").mock(
            return_value=Response(
                422,
                json={"message": "Validation Failed", "errors": [{"code": "already_exists"}]},
            )
        )

        # Should not raise
        await client.ensure_label("acme", "repo", "canon-spec")

    @respx.mock
    async def test_get_preview_deployment_returns_none_on_error(self, client):
        """get_preview_deployment_url returns None on API errors."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/repos/acme/repo/deployments").mock(
            return_value=Response(500, json={"message": "Internal Server Error"})
        )

        result = await client.get_preview_deployment_url("acme", "repo", 7)

        assert result is None


class TestPagination:
    """AC: Pagination handling tested with multi-page response fixtures."""

    @respx.mock
    async def test_list_installation_repos_single_page(self, client):
        """Single page of repos returned without extra requests."""
        mock_token_exchange(respx)
        repos = [{"id": i, "name": f"repo-{i}", "full_name": f"acme/repo-{i}"} for i in range(5)]

        route = respx.get(f"{GITHUB_API}/installation/repositories").mock(
            return_value=Response(200, json={"total_count": 5, "repositories": repos})
        )

        result = await client.list_installation_repos()

        assert len(result) == 5
        assert route.call_count == 1

    @respx.mock
    async def test_list_installation_repos_multiple_pages(self, client):
        """Multi-page results are collected into a single list."""
        mock_token_exchange(respx)
        page1_repos = [{"id": i, "name": f"repo-{i}"} for i in range(100)]
        page2_repos = [{"id": i, "name": f"repo-{i}"} for i in range(100, 130)]

        call_count = 0

        def side_effect(request):
            nonlocal call_count
            call_count += 1
            page = request.url.params.get("page", "1")
            if page == "2":
                return Response(200, json={"total_count": 130, "repositories": page2_repos})
            return Response(200, json={"total_count": 130, "repositories": page1_repos})

        respx.get(f"{GITHUB_API}/installation/repositories").mock(side_effect=side_effect)

        result = await client.list_installation_repos()

        assert len(result) == 130
        assert call_count == 2

    @respx.mock
    async def test_list_installation_repos_empty(self, client):
        """Empty installation returns empty list."""
        mock_token_exchange(respx)
        respx.get(f"{GITHUB_API}/installation/repositories").mock(
            return_value=Response(200, json={"total_count": 0, "repositories": []})
        )

        result = await client.list_installation_repos()

        assert result == []

    @respx.mock
    async def test_list_installation_repos_three_pages(self, client):
        """Three pages of results are all collected."""
        mock_token_exchange(respx)

        def side_effect(request):
            page = request.url.params.get("page", "1")
            if page == "3":
                repos = [{"id": i, "name": f"repo-{i}"} for i in range(200, 250)]
            elif page == "2":
                repos = [{"id": i, "name": f"repo-{i}"} for i in range(100, 200)]
            else:
                repos = [{"id": i, "name": f"repo-{i}"} for i in range(100)]
            return Response(200, json={"total_count": 250, "repositories": repos})

        respx.get(f"{GITHUB_API}/installation/repositories").mock(side_effect=side_effect)

        result = await client.list_installation_repos()

        assert len(result) == 250
