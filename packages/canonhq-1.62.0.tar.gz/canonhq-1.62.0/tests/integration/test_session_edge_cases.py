"""Integration tests for session edge cases through the full FastAPI stack.

Tests expired/corrupted sessions, deactivated users, missing permissions,
and DB failure resilience in the get_current_user dependency.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Session with deactivated user
# ---------------------------------------------------------------------------


class TestDeactivatedUserSession:
    """User deactivated after session was created → 403."""

    async def test_deactivated_user_gets_403(self, mock_github_client: MagicMock):
        """Session exists but user is deactivated in DB → 403."""
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(
            return_value={"sub": "user-1", "status": "deactivated"}
        )

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
            user_store=user_store,
        )

        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG, sub="user-1"))

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                resp = await client.get(f"/app/{SEED_ORG}/api/profile")
                assert resp.status_code == 403
                assert "deactivated" in resp.json()["detail"].lower()

        _restore_app_state(originals)

    async def test_active_user_passes(self, mock_github_client: MagicMock):
        """Active user in DB → request proceeds normally."""
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value={"sub": "user-1", "status": "active"})

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
            user_store=user_store,
        )

        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG, sub="user-1"))

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                resp = await client.get(f"/app/{SEED_ORG}/api/profile")
                assert resp.status_code == 200

        _restore_app_state(originals)


# ---------------------------------------------------------------------------
# DB failure during session validation — fail open
# ---------------------------------------------------------------------------


class TestDBFailureDuringAuth:
    """DB errors during deactivation check should fail open, not 500."""

    async def test_db_timeout_fails_open(self, mock_github_client: MagicMock):
        """TimeoutError on user lookup → request proceeds (not 500)."""
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(side_effect=TimeoutError("pool timeout"))

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
            user_store=user_store,
        )

        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                resp = await client.get(f"/app/{SEED_ORG}/api/profile")
                # Should succeed — fails open on DB errors
                assert resp.status_code == 200

        _restore_app_state(originals)

    async def test_os_error_fails_open(self, mock_github_client: MagicMock):
        """OSError on user lookup → request proceeds (not 500)."""
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(side_effect=OSError("connection refused"))

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
            user_store=user_store,
        )

        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                resp = await client.get(f"/app/{SEED_ORG}/api/profile")
                assert resp.status_code == 200

        _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Missing/empty permissions — fallback to read-only
# ---------------------------------------------------------------------------


class TestPermissionFallback:
    """Sessions with no permissions fall back to SPECS_READ."""

    async def test_no_permissions_gets_read_only(self, mock_github_client: MagicMock):
        """Session with empty permissions → SPECS_READ fallback."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        # Session with no permissions
        session = _session_data_for_user(org_login=SEED_ORG, permissions=[])

        cookie = make_session_cookie(session)

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                # Profile requires SPECS_READ — should work with fallback
                resp = await client.get(f"/app/{SEED_ORG}/api/profile")
                assert resp.status_code == 200

        _restore_app_state(originals)

    async def test_write_denied_with_read_only_fallback(self, mock_github_client: MagicMock):
        """Session with only read fallback → write operations denied."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        # Session with no permissions → falls back to SPECS_READ only
        session = _session_data_for_user(org_login=SEED_ORG, permissions=[])
        cookie = make_session_cookie(session)

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                # Admin indexing requires SPECS_ADMIN — should be denied
                resp = await client.get("/app/admin/indexing")
                assert resp.status_code == 403

        _restore_app_state(originals)


# ---------------------------------------------------------------------------
# No session cookie at all
# ---------------------------------------------------------------------------


class TestNoSessionCookie:
    """Requests without any session cookie."""

    async def test_no_cookie_browser_redirects(self, mock_github_client: MagicMock):
        """No session cookie + browser request → redirect to login."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )
        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test", follow_redirects=False
            ) as client:
                resp = await client.get(f"/app/{SEED_ORG}/")
                assert resp.status_code in (302, 307)
                assert "/auth/login" in resp.headers["location"]

        _restore_app_state(originals)

    async def test_no_cookie_api_returns_401(self, mock_github_client: MagicMock):
        """No session cookie + API request → JSON 401."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )
        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get(
                    f"/app/{SEED_ORG}/api/search?q=test",
                    headers={"Accept": "application/json"},
                )
                assert resp.status_code == 401

        _restore_app_state(originals)
