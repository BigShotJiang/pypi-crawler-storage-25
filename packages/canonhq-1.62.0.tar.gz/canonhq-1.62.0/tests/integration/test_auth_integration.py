"""Integration tests for the full authentication request cycle.

Exercises auth middleware, login/logout routes, and device auth endpoints
through the real FastAPI app with httpx.AsyncClient + ASGITransport.
"""

from __future__ import annotations

import base64
import json
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport
from itsdangerous import TimestampSigner
from starlette.responses import RedirectResponse as StarletteRedirect

from canon.auth.providers.protocol import DeviceCodeResponse, Pending
from canon.main import app
from canon.settings import Settings

pytestmark = pytest.mark.integration

# SessionMiddleware is constructed at import time with no OIDC secrets,
# so the actual signing key is the fallback "dev-not-secret".
_SESSION_KEY = "dev-not-secret"

_STATE_ATTRS = (
    "settings",
    "db_pool",
    "registry",
    "user_store",
    "session_store",
    "agent_store",
    "github_client",
    "cache",
    "oidc_provider",
)


def _make_session_cookie(data: dict, secret: str = _SESSION_KEY) -> str:
    """Create a signed Starlette session cookie."""
    payload = base64.b64encode(json.dumps(data).encode()).decode()
    return TimestampSigner(secret).sign(payload).decode()


def _base_settings(**overrides) -> Settings:
    defaults = dict(
        gh_app_id="test-app-id",
        gh_private_key="test-key",
        gh_webhook_secret="test-secret",
        gh_installation_id="99999",
    )
    defaults.update(overrides)
    return Settings(**defaults)


def _set_app_state(settings: Settings, *, oidc_provider=None):
    """Populate app.state attributes normally set by the lifespan."""
    app.state.settings = settings
    app.state.db_pool = None
    app.state.registry = None
    app.state.user_store = None
    app.state.session_store = None
    app.state.agent_store = None
    app.state.github_client = MagicMock()
    app.state.cache = MagicMock()
    app.state.oidc_provider = oidc_provider


def _make_mock_provider() -> MagicMock:
    """Build a mock OIDCProvider with sensible async defaults."""
    p = MagicMock()
    p.get_device_code = AsyncMock(
        return_value=DeviceCodeResponse(
            device_code="test-dc",
            user_code="TEST-1234",
            verification_uri="https://idp.example.com/activate",
            interval=5,
            expires_in=900,
        )
    )
    p.get_jwks_uri = AsyncMock(return_value="https://idp.example.com/.well-known/jwks.json")
    p.get_logout_url = AsyncMock(
        return_value="https://idp.example.com/logout?redirect=http://test",
    )
    p.poll_device_token = AsyncMock(return_value=Pending())
    p.get_user_orgs = AsyncMock(return_value=[])
    return p


@pytest.fixture
async def noauth_client():
    """Client with auth disabled (no OIDC settings)."""
    settings = _base_settings()
    originals = {a: getattr(app.state, a, None) for a in _STATE_ATTRS}
    _set_app_state(settings)
    with patch("canon.main.settings", settings):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
            yield c
    for a, v in originals.items():
        setattr(app.state, a, v)


@pytest.fixture
async def auth_client():
    """Client with OIDC auth enabled but no session set."""
    settings = _base_settings(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="test-client",
        oidc_client_secret="test-oidc-client-secret",
        oidc_audience="https://api.example.com",
    )
    originals = {a: getattr(app.state, a, None) for a in _STATE_ATTRS}
    _set_app_state(settings, oidc_provider=_make_mock_provider())
    with patch("canon.main.settings", settings):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(
            transport=transport,
            base_url="http://test",
            follow_redirects=False,
        ) as c:
            yield c
    for a, v in originals.items():
        setattr(app.state, a, v)


class TestNoAuthMode:
    """When auth is disabled (no auth0/oidc settings)."""

    async def test_healthz_returns_ok(self, noauth_client: httpx.AsyncClient):
        resp = await noauth_client.get("/healthz")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}

    async def test_app_routes_accessible_without_auth(self, noauth_client: httpx.AsyncClient):
        """GET /app/ reaches the route handler (not redirected to /auth/login)."""
        resp = await noauth_client.get("/app/", follow_redirects=False)
        # dashboard_redirect returns 302 to /app/{org}/ -- NOT /auth/login
        assert resp.status_code == 302
        assert "/auth/login" not in resp.headers.get("location", "")

    async def test_auth_login_redirects_home(self, noauth_client: httpx.AsyncClient):
        resp = await noauth_client.get("/auth/login", follow_redirects=False)
        assert resp.status_code == 307
        assert resp.headers["location"] == "/"


class TestAuthMiddleware:
    """When auth IS enabled (OIDC configured)."""

    async def test_unauthenticated_app_redirects_to_login(self, auth_client: httpx.AsyncClient):
        resp = await auth_client.get("/app/")
        assert resp.status_code == 307
        assert resp.headers["location"] == "/auth/login"

    async def test_authenticated_session_passes_through(self, auth_client: httpx.AsyncClient):
        cookie = _make_session_cookie(
            {"user": {"sub": "user|123", "email": "a@b.com", "org_login": ""}},
        )
        resp = await auth_client.get("/app/", headers={"cookie": f"session={cookie}"})
        # Must NOT redirect to /auth/login
        assert resp.headers.get("location") != "/auth/login"

    async def test_non_app_routes_bypass_auth(self, auth_client: httpx.AsyncClient):
        resp = await auth_client.get("/healthz")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}

    async def test_device_auth_endpoint_returns_503_without_provider(
        self,
        auth_client: httpx.AsyncClient,
    ):
        app.state.oidc_provider = None
        try:
            resp = await auth_client.post("/auth/device/code", json={"org": ""})
            assert resp.status_code == 503
        finally:
            app.state.oidc_provider = _make_mock_provider()


class TestLoginFlow:
    """Login/logout flows with OIDC-configured app."""

    async def test_login_redirects_to_provider(self, auth_client: httpx.AsyncClient):
        """GET /auth/login redirects to the OIDC authorization endpoint."""
        mock_authlib = MagicMock()
        mock_authlib.authorize_redirect = AsyncMock(
            return_value=StarletteRedirect(
                url="https://idp.example.com/authorize?client_id=test",
                status_code=302,
            )
        )
        with patch("canon.auth.routes._get_authlib_client", return_value=mock_authlib):
            resp = await auth_client.get("/auth/login")
        assert resp.status_code == 302
        assert "idp.example.com" in resp.headers["location"]

    async def test_logout_clears_session(self, auth_client: httpx.AsyncClient):
        """GET /auth/logout redirects away from /app (to provider or home)."""
        cookie = _make_session_cookie({"user": {"sub": "user|123", "email": "a@b.com"}})
        auth_client.cookies.set("session", cookie, domain="test")
        resp = await auth_client.get("/auth/logout")
        assert resp.status_code == 307
        assert not resp.headers["location"].startswith("/app")


class TestDeviceAuthFlow:
    """Device authorization grant endpoints with a mock provider."""

    async def test_device_code_request(self, auth_client: httpx.AsyncClient):
        resp = await auth_client.post("/auth/device/code", json={"org": ""})
        assert resp.status_code == 200
        data = resp.json()
        assert data["device_code"] == "test-dc"
        assert data["user_code"] == "TEST-1234"
        assert data["verification_uri"] == "https://idp.example.com/activate"

    async def test_device_code_unsupported(self, auth_client: httpx.AsyncClient):
        """Provider returning None means device auth is unsupported (501)."""
        app.state.oidc_provider.get_device_code = AsyncMock(return_value=None)
        resp = await auth_client.post("/auth/device/code", json={"org": ""})
        assert resp.status_code == 501

    async def test_device_token_pending(self, auth_client: httpx.AsyncClient):
        resp = await auth_client.post("/auth/device/token", json={"device_code": "test-dc"})
        assert resp.status_code == 200
        assert resp.json() == {"status": "pending", "slow_down": False}
