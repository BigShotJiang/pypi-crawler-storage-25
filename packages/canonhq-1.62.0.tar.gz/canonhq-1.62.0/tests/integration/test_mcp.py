"""Integration tests for the MCP server mounted on the real FastAPI app.

Tests tool listing, tool execution, and auth through the HTTP transport.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from httpx import ASGITransport

from canon.mcp.auth import McpAuthMiddleware
from canon.mcp.deps import McpDeps
from canon.mcp.server import create_mcp_server

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mcp_app_with_auth():
    """Standalone FastAPI app with MCP + auth middleware for auth tests."""
    deps = McpDeps(
        search_index=None,
        embed_client=MagicMock(is_available=False),
        github_client=AsyncMock(),
    )
    mcp_server = create_mcp_server(deps)
    mcp_http_app = mcp_server.streamable_http_app()
    mcp_http_app.add_middleware(
        McpAuthMiddleware,
        api_key="test-mcp-key",
        user_store=None,
    )

    from fastapi import FastAPI

    test_app = FastAPI()
    test_app.mount("/mcp", mcp_http_app)
    return test_app


@pytest.fixture
def mcp_app_no_auth():
    """Standalone FastAPI app with MCP and no auth middleware."""
    deps = McpDeps(
        search_index=None,
        embed_client=MagicMock(is_available=False),
        github_client=AsyncMock(),
    )
    mcp_server = create_mcp_server(deps)
    mcp_http_app = mcp_server.streamable_http_app()

    from fastapi import FastAPI

    test_app = FastAPI()
    test_app.mount("/mcp", mcp_http_app)
    return test_app


# ---------------------------------------------------------------------------
# Tool listing
# ---------------------------------------------------------------------------


class TestMcpToolListing:
    async def test_initialize_returns_capabilities(self, mcp_app_no_auth):
        """MCP initialize response includes server capabilities."""
        async with httpx.AsyncClient(
            transport=ASGITransport(app=mcp_app_no_auth),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/mcp",
                json={
                    "jsonrpc": "2.0",
                    "method": "initialize",
                    "id": 1,
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {"name": "test", "version": "1.0"},
                    },
                },
                headers={"Content-Type": "application/json"},
            )
        # MCP endpoint should respond — not a 404
        assert resp.status_code != 404

    async def test_get_not_404(self, mcp_app_no_auth):
        """MCP endpoint handles GET requests (used for SSE)."""
        async with httpx.AsyncClient(
            transport=ASGITransport(app=mcp_app_no_auth),
            base_url="http://test",
        ) as client:
            resp = await client.get("/mcp")
        assert resp.status_code != 404


# ---------------------------------------------------------------------------
# Auth middleware
# ---------------------------------------------------------------------------


class TestMcpAuth:
    async def test_valid_api_key_accepted(self, mcp_app_with_auth):
        """A correct API key passes through the middleware."""
        async with httpx.AsyncClient(
            transport=ASGITransport(app=mcp_app_with_auth),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/mcp/",
                json={"jsonrpc": "2.0", "method": "initialize", "id": 1, "params": {}},
                headers={
                    "Content-Type": "application/json",
                    "Authorization": "Bearer test-mcp-key",
                },
            )
        assert resp.status_code != 401

    async def test_invalid_api_key_rejected(self, mcp_app_with_auth):
        """A wrong API key is rejected with 401."""
        async with httpx.AsyncClient(
            transport=ASGITransport(app=mcp_app_with_auth),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/mcp/",
                json={"jsonrpc": "2.0", "method": "initialize", "id": 1, "params": {}},
                headers={
                    "Content-Type": "application/json",
                    "Authorization": "Bearer wrong-key",
                },
            )
        assert resp.status_code == 401

    async def test_missing_auth_rejected(self, mcp_app_with_auth):
        """No auth header is rejected with 401."""
        async with httpx.AsyncClient(
            transport=ASGITransport(app=mcp_app_with_auth),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/mcp/",
                json={"jsonrpc": "2.0", "method": "initialize", "id": 1, "params": {}},
                headers={"Content-Type": "application/json"},
            )
        assert resp.status_code == 401

    async def test_sw_key_with_user_store(self, mcp_app_with_auth):
        """sw_ key is validated against user_store when available."""
        key = "sw_testvalidkey"
        mock_user_store = AsyncMock()
        mock_user_store.get_api_key_by_hash = AsyncMock(
            return_value={
                "revoked_at": None,
                "expires_at": datetime.now(UTC) + timedelta(days=30),
                "org_login": "test-org",
                "scopes": ["specs:read"],
            }
        )

        # Build a fresh app with user_store
        deps = McpDeps(
            search_index=None,
            embed_client=MagicMock(is_available=False),
            github_client=AsyncMock(),
        )
        mcp_server = create_mcp_server(deps)
        mcp_http_app = mcp_server.streamable_http_app()
        mcp_http_app.add_middleware(
            McpAuthMiddleware,
            api_key=None,
            user_store=mock_user_store,
        )
        from fastapi import FastAPI

        test_app = FastAPI()
        test_app.mount("/mcp", mcp_http_app)

        async with httpx.AsyncClient(
            transport=ASGITransport(app=test_app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                "/mcp/",
                json={"jsonrpc": "2.0", "method": "initialize", "id": 1, "params": {}},
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {key}",
                },
            )
        assert resp.status_code != 401
