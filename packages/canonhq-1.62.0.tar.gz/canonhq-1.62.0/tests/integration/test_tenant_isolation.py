"""Integration tests for tenant isolation through the auth middleware.

Verifies that org-scoped routes enforce org matching, handle suspended
orgs, and return appropriate responses for API vs browser requests.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _make_auth_client(
    mock_github_client: MagicMock,
    *,
    org_login: str = SEED_ORG,
    registry: AsyncMock | None = None,
):
    """Create an authenticated client for tenant isolation tests."""
    settings = _base_settings(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="test-client",
        oidc_client_secret="test-oidc-secret",
        web_org="",
    )
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        oidc_provider=MagicMock(),
    )
    if registry is not None:
        app.state.registry = registry

    cookie = make_session_cookie(_session_data_for_user(org_login=org_login))

    patches = [
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
        patch("canon.web.routes._get_spa_html", return_value=None),
    ]
    for p in patches:
        p.start()

    transport = ASGITransport(app=app, raise_app_exceptions=False)
    client = httpx.AsyncClient(
        transport=transport,
        base_url="http://test",
        cookies={"session": cookie},
        follow_redirects=False,
    )

    return client, originals, patches


async def _cleanup(client, originals, patches):
    await client.aclose()
    for p in patches:
        p.stop()
    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Org mismatch — browser requests
# ---------------------------------------------------------------------------


class TestOrgMismatchBrowser:
    """Browser requests to wrong org redirect to login with org hint."""

    async def test_access_other_org_redirects_to_login(self, mock_github_client: MagicMock):
        """User in org-a accessing /app/org-b/ → redirect to login."""
        client, originals, patches = await _make_auth_client(mock_github_client, org_login="org-a")
        try:
            resp = await client.get("/app/org-b/")
            assert resp.status_code in (302, 307)
            location = resp.headers["location"]
            assert "/auth/login" in location
            assert "org=org-b" in location
        finally:
            await _cleanup(client, originals, patches)

    async def test_case_insensitive_org_match(self, mock_github_client: MagicMock):
        """Org matching is case-insensitive."""
        child = mock_github_client.for_installation.return_value
        child.list_installation_repos = AsyncMock(return_value=[])
        child.get_file_content = AsyncMock(return_value=None)
        child.list_directory = AsyncMock(return_value=[])

        client, originals, patches = await _make_auth_client(mock_github_client, org_login="MyOrg")
        try:
            resp = await client.get("/app/myorg/")
            # Should NOT redirect to login — case-insensitive match
            assert resp.status_code == 200 or (
                resp.status_code in (302, 307)
                and "/auth/login" not in resp.headers.get("location", "")
            )
        finally:
            await _cleanup(client, originals, patches)

    async def test_empty_org_login_always_fails_isolation(self, mock_github_client: MagicMock):
        """User with empty org_login can't access any org-scoped route."""
        client, originals, patches = await _make_auth_client(mock_github_client, org_login="")
        try:
            resp = await client.get(f"/app/{SEED_ORG}/")
            assert resp.status_code in (302, 307)
            assert "/auth/login" in resp.headers["location"]
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Org mismatch — API requests (Accept: application/json)
# ---------------------------------------------------------------------------


class TestOrgMismatchApi:
    """API requests to wrong org get JSON 403 instead of redirect."""

    async def test_api_request_wrong_org_returns_json_403(self, mock_github_client: MagicMock):
        """API request with Accept: application/json → JSON 403."""
        client, originals, patches = await _make_auth_client(mock_github_client, org_login="org-a")
        try:
            resp = await client.get(
                "/app/org-b/api/search?q=test",
                headers={"Accept": "application/json"},
            )
            assert resp.status_code == 403
            assert resp.json()["detail"] == "Not authorized for org: org-b"
        finally:
            await _cleanup(client, originals, patches)

    async def test_unauthenticated_api_request_returns_json_401(
        self, mock_github_client: MagicMock
    ):
        """Unauthenticated API request → JSON 401 (not redirect)."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )
        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get(
                    f"/app/{SEED_ORG}/api/search?q=test",
                    headers={"Accept": "application/json"},
                )
                assert resp.status_code == 401
                assert "Not authenticated" in resp.json()["detail"]
        _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Reserved org slugs
# ---------------------------------------------------------------------------


class TestReservedOrgSlugs:
    """Reserved slugs bypass org isolation."""

    async def test_no_org_bypasses_isolation(self, mock_github_client: MagicMock):
        """/app/no-org is accessible regardless of session org."""
        client, originals, patches = await _make_auth_client(
            mock_github_client, org_login="any-org"
        )
        try:
            resp = await client.get("/app/no-org")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)

    async def test_choose_org_bypasses_isolation(self, mock_github_client: MagicMock):
        """/app/choose-org is accessible regardless of session org."""
        client, originals, patches = await _make_auth_client(
            mock_github_client, org_login="any-org"
        )
        try:
            resp = await client.get("/app/choose-org")
            # Redirects to no-org (no pending choices) but NOT to /auth/login
            assert resp.status_code in (200, 302)
            if resp.status_code == 302:
                assert "/auth/login" not in resp.headers["location"]
        finally:
            await _cleanup(client, originals, patches)

    async def test_setup_bypasses_isolation(self, mock_github_client: MagicMock):
        """/app/setup/complete is accessible (setup is reserved)."""
        client, originals, patches = await _make_auth_client(
            mock_github_client, org_login="any-org"
        )
        try:
            resp = await client.get("/app/setup/complete")
            assert resp.status_code in (302, 307)
            assert "/auth/login" not in resp.headers.get("location", "")
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Suspended org
# ---------------------------------------------------------------------------


class TestSuspendedOrg:
    """Suspended orgs are blocked at the middleware level."""

    async def test_suspended_org_redirects_to_no_org(self, mock_github_client: MagicMock):
        """Access to a suspended org → /app/no-org."""
        installation = MagicMock()
        installation.status = "suspended"

        registry = AsyncMock()
        registry.get_installation_by_org_any_status = AsyncMock(return_value=installation)

        client, originals, patches = await _make_auth_client(
            mock_github_client, org_login=SEED_ORG, registry=registry
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/")
            assert resp.status_code in (302, 307)
            assert "/app/no-org" in resp.headers["location"]
        finally:
            await _cleanup(client, originals, patches)

    async def test_suspended_org_api_returns_json_403(self, mock_github_client: MagicMock):
        """API request to suspended org → JSON 403."""
        installation = MagicMock()
        installation.status = "suspended"

        registry = AsyncMock()
        registry.get_installation_by_org_any_status = AsyncMock(return_value=installation)

        client, originals, patches = await _make_auth_client(
            mock_github_client, org_login=SEED_ORG, registry=registry
        )
        try:
            resp = await client.get(
                f"/app/{SEED_ORG}/api/search?q=test",
                headers={"Accept": "application/json"},
            )
            assert resp.status_code == 403
            assert "suspended" in resp.json()["detail"].lower()
        finally:
            await _cleanup(client, originals, patches)

    async def test_active_org_passes_through(self, mock_github_client: MagicMock):
        """Active org is not blocked."""
        installation = MagicMock()
        installation.status = "active"

        registry = AsyncMock()
        registry.get_installation_by_org_any_status = AsyncMock(return_value=installation)

        child = mock_github_client.for_installation.return_value
        child.list_installation_repos = AsyncMock(return_value=[])
        child.get_file_content = AsyncMock(return_value=None)
        child.list_directory = AsyncMock(return_value=[])

        client, originals, patches = await _make_auth_client(
            mock_github_client, org_login=SEED_ORG, registry=registry
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)

    async def test_registry_error_fails_open(self, mock_github_client: MagicMock):
        """Registry error during suspension check → let request through."""
        registry = AsyncMock()
        registry.get_installation_by_org_any_status = AsyncMock(side_effect=Exception("DB timeout"))

        child = mock_github_client.for_installation.return_value
        child.list_installation_repos = AsyncMock(return_value=[])
        child.get_file_content = AsyncMock(return_value=None)
        child.list_directory = AsyncMock(return_value=[])

        client, originals, patches = await _make_auth_client(
            mock_github_client, org_login=SEED_ORG, registry=registry
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/")
            # Should NOT block — fails open on registry errors
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Non-/app routes skip middleware entirely
# ---------------------------------------------------------------------------


class TestNonAppRoutesSkipAuth:
    """Routes not under /app/* bypass auth middleware."""

    async def test_healthz_skips_auth(self, mock_github_client: MagicMock):
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )
        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/healthz")
                assert resp.status_code == 200

        _restore_app_state(originals)

    async def test_webhook_skips_auth(self, mock_github_client: MagicMock):
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )
        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                # GET to /webhook returns 405 (Method Not Allowed) — NOT a login redirect
                resp = await client.get("/webhook")
                assert resp.status_code == 405

        _restore_app_state(originals)
