"""Integration tests for new user onboarding flows.

Tests the critical onboarding paths through the real FastAPI stack:
- New user with org → welcome page
- New user without org → no-org onboarding
- Multi-org user → org picker → dashboard
- GitHub App post-install redirect → welcome
- Logout → session cleared → redirect
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    assert_redirects_to,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_authed_client_ctx(
    mock_github_client: MagicMock,
    *,
    session_data: dict,
    auth_enabled: bool = True,
    oidc_provider: MagicMock | None = None,
    registry: MagicMock | None = None,
    user_store: MagicMock | None = None,
):
    """Context manager helper that yields an httpx client with given session."""
    extra_settings: dict = {}
    if auth_enabled:
        extra_settings.update(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            # Clear web_org so dashboard_redirect uses session org_login
            # (matching production multi-tenant behavior)
            web_org="",
        )

    settings = _base_settings(**extra_settings)
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        oidc_provider=oidc_provider or MagicMock(),
        user_store=user_store,
    )
    if registry is not None:
        app.state.registry = registry

    cookie = make_session_cookie(session_data)

    class _Ctx:
        async def __aenter__(self):
            self._patches = [
                patch("canon.main.settings", settings),
                patch("canon.main._get_client", return_value=mock_github_client),
                patch("canon.main.analytics"),
                patch("canon.web.routes._get_spa_html", return_value=None),
            ]
            for p in self._patches:
                p.start()

            transport = ASGITransport(app=app, raise_app_exceptions=False)
            self._client = httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
                follow_redirects=False,
            )
            return await self._client.__aenter__()

        async def __aexit__(self, *args):
            await self._client.__aexit__(*args)
            for p in self._patches:
                p.stop()
            _restore_app_state(originals)

    return _Ctx()


# ---------------------------------------------------------------------------
# Flow 1: New user with org → welcome page
# ---------------------------------------------------------------------------


class TestNewUserWithOrg:
    """User logs in, has an org, gets redirected to welcome."""

    async def test_app_root_redirects_to_org_dashboard(self, mock_github_client: MagicMock):
        """Authenticated user with org_login → /app/{org}/."""
        session = _session_data_for_user(org_login=SEED_ORG)
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/")
            assert resp.status_code == 302
            assert f"/app/{SEED_ORG}/" in resp.headers["location"]

    async def test_welcome_page_renders(self, mock_github_client: MagicMock):
        """Welcome page loads for a new user's org."""
        registry = AsyncMock()
        registry.get_installation_by_org = AsyncMock(return_value=None)

        session = _session_data_for_user(org_login=SEED_ORG, name="Alice Smith")
        async with _make_authed_client_ctx(
            mock_github_client, session_data=session, registry=registry
        ) as client:
            resp = await client.get(f"/app/{SEED_ORG}/welcome")
            assert resp.status_code == 200
            assert "Welcome" in resp.text or "Canon" in resp.text

    async def test_welcome_page_shows_install_status(self, mock_github_client: MagicMock):
        """Welcome page detects GitHub App installation."""
        installation = MagicMock()
        installation.org_login = SEED_ORG
        installation.installation_id = 12345

        registry = AsyncMock()
        registry.get_installation_by_org = AsyncMock(return_value=installation)

        gh_child = mock_github_client.for_installation.return_value
        gh_child.list_installation_repos = AsyncMock(return_value=[])
        gh_child.list_directory = AsyncMock(return_value=[])
        gh_child.get_file_content = AsyncMock(return_value=None)

        session = _session_data_for_user(org_login=SEED_ORG)
        async with _make_authed_client_ctx(
            mock_github_client, session_data=session, registry=registry
        ) as client:
            resp = await client.get(f"/app/{SEED_ORG}/welcome")
            assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Flow 2: New user without org → no-org onboarding
# ---------------------------------------------------------------------------


class TestNewUserNoOrg:
    """User logs in but has no org association."""

    async def test_no_org_login_redirects_to_no_org_page(self, mock_github_client: MagicMock):
        """/app/ with empty org_login → /app/no-org."""
        session = _session_data_for_user(org_login="")
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/")
            assert resp.status_code == 302
            assert "/app/no-org" in resp.headers["location"]

    async def test_no_org_page_renders_instructions(self, mock_github_client: MagicMock):
        """No-org page shows install instructions."""
        session = _session_data_for_user(org_login="")
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/no-org")
            assert resp.status_code == 200
            assert "Install" in resp.text or "install" in resp.text
            assert "sign out" in resp.text.lower() or "Sign out" in resp.text


# ---------------------------------------------------------------------------
# Flow 3: Multi-org user → org picker
# ---------------------------------------------------------------------------


class TestMultiOrgPicker:
    """User has multiple org matches → choose-org flow."""

    async def test_pending_orgs_redirects_to_choose_org(self, mock_github_client: MagicMock):
        """/app/ with no org_login but pending choices → /app/choose-org."""
        session = _session_data_for_user(org_login="")
        session["pending_org_choices"] = ["org-a", "org-b"]
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/")
            assert resp.status_code == 302
            assert "/app/choose-org" in resp.headers["location"]

    async def test_choose_org_returns_org_list(self, mock_github_client: MagicMock):
        """GET /app/choose-org returns the pending org choices as JSON."""
        session = _session_data_for_user(org_login="")
        session["pending_org_choices"] = ["org-a", "org-b"]
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/choose-org")
            assert resp.status_code == 200
            data = resp.json()
            assert data["orgs"] == ["org-a", "org-b"]

    async def test_choose_org_no_pending_redirects_to_no_org(self, mock_github_client: MagicMock):
        """GET /app/choose-org without pending choices → /app/no-org."""
        session = _session_data_for_user(org_login="")
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/choose-org")
            assert resp.status_code == 302
            assert "/app/no-org" in resp.headers["location"]

    async def test_choose_org_submit_valid_choice(self, mock_github_client: MagicMock):
        """POST /app/choose-org with valid org → redirects to org dashboard."""
        session = _session_data_for_user(org_login="")
        session["pending_org_choices"] = ["org-a", "org-b"]
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.post(
                "/app/choose-org",
                data={"org": "org-a"},
            )
            assert resp.status_code == 302
            assert "/app/org-a/" in resp.headers["location"]

    async def test_choose_org_submit_invalid_choice_rejected(self, mock_github_client: MagicMock):
        """POST /app/choose-org with invalid org → redirect back to picker."""
        session = _session_data_for_user(org_login="")
        session["pending_org_choices"] = ["org-a", "org-b"]
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.post(
                "/app/choose-org",
                data={"org": "evil-org"},
            )
            assert resp.status_code == 302
            assert "/app/choose-org" in resp.headers["location"]


# ---------------------------------------------------------------------------
# Flow 4: GitHub App post-install redirect
# ---------------------------------------------------------------------------


class TestSetupComplete:
    """GitHub redirects here after app installation."""

    async def test_setup_complete_with_known_installation(self, mock_github_client: MagicMock):
        """Known installation_id → redirect to org welcome.

        Fixed: "setup" is now in RESERVED_ORG_SLUGS so the auth middleware
        skips org isolation for /app/setup/complete.
        """
        installation = MagicMock()
        installation.org_login = "acme-corp"

        registry = AsyncMock()
        registry.get_installation_by_id = AsyncMock(return_value=installation)

        session = _session_data_for_user(org_login=SEED_ORG)
        async with _make_authed_client_ctx(
            mock_github_client, session_data=session, registry=registry
        ) as client:
            resp = await client.get("/app/setup/complete?installation_id=12345")
            assert resp.status_code in (302, 307)
            assert "/app/acme-corp/welcome" in resp.headers["location"]

    async def test_setup_complete_unknown_installation(self, mock_github_client: MagicMock):
        """Unknown installation_id → redirect to default org welcome."""
        registry = AsyncMock()
        registry.get_installation_by_id = AsyncMock(return_value=None)

        session = _session_data_for_user(org_login=SEED_ORG)
        async with _make_authed_client_ctx(
            mock_github_client, session_data=session, registry=registry
        ) as client:
            resp = await client.get("/app/setup/complete?installation_id=99999")
            assert resp.status_code in (302, 307)
            assert "/welcome" in resp.headers["location"]

    async def test_setup_complete_no_installation_id(self, mock_github_client: MagicMock):
        """No installation_id param → redirect to default org welcome."""
        session = _session_data_for_user(org_login=SEED_ORG)
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/setup/complete")
            assert resp.status_code in (302, 307)
            assert "/welcome" in resp.headers["location"]


# ---------------------------------------------------------------------------
# Flow 5: Logout
# ---------------------------------------------------------------------------


class TestLogoutFlow:
    """Logout clears session and redirects."""

    async def test_logout_clears_session_and_redirects(self, mock_github_client: MagicMock):
        """GET /auth/logout → session cleared, redirect to / or provider logout."""
        provider = MagicMock()
        provider.get_logout_url = AsyncMock(return_value=None)

        session = _session_data_for_user(org_login=SEED_ORG)
        async with _make_authed_client_ctx(
            mock_github_client,
            session_data=session,
            oidc_provider=provider,
        ) as client:
            resp = await client.get("/auth/logout")
            # Should redirect (to / or provider logout URL)
            assert resp.status_code in (302, 307)

    async def test_logout_with_provider_url(self, mock_github_client: MagicMock):
        """Logout redirects to provider's end_session_endpoint when available."""
        provider = MagicMock()
        provider.get_logout_url = AsyncMock(
            return_value="https://idp.example.com/logout?redirect=http://test/"
        )

        session = _session_data_for_user(org_login=SEED_ORG)
        async with _make_authed_client_ctx(
            mock_github_client,
            session_data=session,
            oidc_provider=provider,
        ) as client:
            resp = await client.get("/auth/logout")
            assert resp.status_code in (302, 307)
            assert "idp.example.com" in resp.headers.get("location", "")


# ---------------------------------------------------------------------------
# Flow 6: Logout → re-login → org_login lost (production bug)
# ---------------------------------------------------------------------------


class TestLogoutReloginOrgLost:
    """Reproduce the production bug where logout → re-login lands on /app/no-org.

    Root cause: the auth callback fetches org_memberships (for the dropdown)
    but doesn't use them to resolve org_login when both org_id (from JWT) and
    GitHub membership lookup fail to produce a match. The session ends up with
    org_login="" but org_memberships=["canonhq", "njgerner"], so the SPA
    dropdown works but the server-side redirect goes to /app/no-org.

    The fix should use org_memberships as a fallback: if org_login is still
    empty after all other resolution attempts but org_memberships has exactly
    one entry (or any entries), pick the first one.
    """

    async def test_user_with_org_memberships_but_no_org_login_uses_first_membership(
        self,
        mock_github_client: MagicMock,
    ):
        """Post-login session with org_memberships but empty org_login uses first membership.

        This is the exact state the callback produces when:
        - Auth0 token has no org_id (user logged in without org context)
        - GitHub membership lookup fails (no token or expired)
        - But provider.get_user_orgs() succeeds and sets org_memberships

        The fix in dashboard_redirect uses org_memberships[0] as fallback.
        """
        session = _session_data_for_user(org_login="")
        session["user"]["org_memberships"] = ["canonhq", "njgerner"]

        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/")
            assert resp.status_code == 302
            location = resp.headers["location"]
            assert "/app/canonhq/" in location

    async def test_user_with_single_org_membership_but_no_org_login(
        self,
        mock_github_client: MagicMock,
    ):
        """Single org membership should be auto-selected."""
        session = _session_data_for_user(org_login="")
        session["user"]["org_memberships"] = ["canonhq"]

        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/")
            assert resp.status_code == 302
            assert "/app/canonhq/" in resp.headers["location"]

    async def test_org_dropdown_switch_works_after_no_org(
        self,
        mock_github_client: MagicMock,
    ):
        """After manually switching org via dropdown, dashboard loads.

        This proves the org data is in the session — the redirect logic
        just doesn't use it.
        """
        # Simulate what happens after user selects org from dropdown:
        # the SPA/org-switcher sets org_login in the session
        session = _session_data_for_user(org_login="njgerner")
        session["user"]["org_memberships"] = ["canonhq", "njgerner"]

        gh = mock_github_client
        child = gh.for_installation.return_value
        child.list_installation_repos = AsyncMock(return_value=[])
        child.get_file_content = AsyncMock(return_value=None)
        child.list_directory = AsyncMock(return_value=[])

        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            # With org_login set, dashboard works fine
            resp = await client.get("/app/")
            assert resp.status_code == 302
            assert "/app/njgerner/" in resp.headers["location"]


# ---------------------------------------------------------------------------
# Flow 7: dashboard_redirect should use org_memberships as fallback
# ---------------------------------------------------------------------------


class TestDashboardRedirectOrgFallback:
    """Tests for the dashboard_redirect logic and org_memberships gap.

    The dashboard_redirect function (routes.py:364) checks
    user.get("org_login") and if empty, sends to /app/no-org. It should
    also check org_memberships as a fallback.
    """

    async def test_redirect_with_org_login_set(self, mock_github_client: MagicMock):
        """Normal case: org_login set → redirect to org dashboard."""
        session = _session_data_for_user(org_login="myorg")
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/")
            assert resp.status_code == 302
            assert "/app/myorg/" in resp.headers["location"]

    async def test_redirect_with_empty_org_login_and_no_memberships(
        self, mock_github_client: MagicMock
    ):
        """No org_login and no memberships → /app/no-org (correct)."""
        session = _session_data_for_user(org_login="")
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/")
            assert resp.status_code == 302
            assert "/app/no-org" in resp.headers["location"]

    async def test_redirect_with_empty_org_login_but_has_memberships(
        self, mock_github_client: MagicMock
    ):
        """No org_login but org_memberships present → uses first membership."""
        session = _session_data_for_user(org_login="")
        session["user"]["org_memberships"] = ["canonhq"]
        async with _make_authed_client_ctx(mock_github_client, session_data=session) as client:
            resp = await client.get("/app/")
            assert resp.status_code == 302
            assert "/app/canonhq/" in resp.headers["location"]


# ---------------------------------------------------------------------------
# Flow 8: Unauthenticated → login redirect
# ---------------------------------------------------------------------------


class TestUnauthenticatedRedirect:
    """Unauthenticated users hit /app/* and get redirected to login."""

    async def test_unauthenticated_app_root(self, mock_github_client: MagicMock):
        """No session cookie → redirect to /auth/login."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                follow_redirects=False,
            ) as client:
                resp = await client.get("/app/")
                assert_redirects_to(resp, "/auth/login")

                # Also verify org-scoped routes redirect
                resp2 = await client.get(f"/app/{SEED_ORG}/")
                assert_redirects_to(resp2, "/auth/login")

        _restore_app_state(originals)

    async def test_healthz_accessible_without_auth(self, mock_github_client: MagicMock):
        """Health check never requires auth."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get("/healthz")
                assert resp.status_code == 200
                assert resp.json() == {"status": "ok"}

        _restore_app_state(originals)
