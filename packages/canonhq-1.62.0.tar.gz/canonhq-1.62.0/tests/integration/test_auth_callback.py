"""Integration tests for the auth login/callback/logout flow.

Tests the actual OAuth callback code path that creates sessions,
resolves org membership, and handles error cases.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Login redirect
# ---------------------------------------------------------------------------


class TestLoginRedirect:
    async def test_login_with_auth_enabled_does_not_404(self, mock_github_client: MagicMock):
        """GET /auth/login when auth is enabled → does not 404 (route is wired)."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test", follow_redirects=False
            ) as client:
                resp = await client.get("/auth/login")
                # Should NOT be 404 — route is wired. May be 302, 307, or 500
                # (authlib not configured for this test), but not 404.
                assert resp.status_code != 404

        _restore_app_state(originals)

    async def test_login_disabled_redirects_home(self, mock_github_client: MagicMock):
        """When auth is disabled, /auth/login redirects to /."""
        settings = _base_settings()  # No OIDC settings = auth disabled
        originals = _set_app_state(settings, github_client=mock_github_client)

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test", follow_redirects=False
            ) as client:
                resp = await client.get("/auth/login")
                assert resp.status_code == 307
                assert resp.headers["location"] == "/"

        _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Callback error handling
# ---------------------------------------------------------------------------


class TestCallbackErrors:
    async def test_callback_with_provider_error(self, mock_github_client: MagicMock):
        """Callback with ?error=access_denied redirects to login."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test", follow_redirects=False
            ) as client:
                resp = await client.get(
                    "/auth/callback?error=access_denied&error_description=User+denied"
                )
                assert resp.status_code in (302, 307)
                assert "/auth/login" in resp.headers["location"]

        _restore_app_state(originals)

    async def test_callback_disabled_auth_redirects_home(self, mock_github_client: MagicMock):
        """Callback with auth disabled redirects to /."""
        settings = _base_settings()
        originals = _set_app_state(settings, github_client=mock_github_client)

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test", follow_redirects=False
            ) as client:
                resp = await client.get("/auth/callback?code=test")
                assert resp.status_code in (302, 307)
                assert resp.headers["location"] == "/"

        _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Device auth endpoints
# ---------------------------------------------------------------------------


class TestDeviceAuth:
    async def test_device_code_route_wired(self, mock_github_client: MagicMock):
        """POST /auth/device/code route is wired (not 404)."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.post("/auth/device/code")
                # Route should be wired — not 404
                assert resp.status_code != 404

        _restore_app_state(originals)

    async def test_device_token_route_wired(self, mock_github_client: MagicMock):
        """POST /auth/device/token route is wired (not 404)."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.post(
                    "/auth/device/token",
                    json={"device_code": "test_dc"},
                )
                assert resp.status_code != 404

        _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Logout
# ---------------------------------------------------------------------------


class TestLogoutIntegration:
    async def test_logout_clears_session(self, mock_github_client: MagicMock):
        """GET /auth/logout clears session and redirects."""
        provider = MagicMock()
        provider.get_logout_url = AsyncMock(return_value=None)

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=provider,
        )

        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
                follow_redirects=False,
            ) as client:
                resp = await client.get("/auth/logout")
                assert resp.status_code in (302, 307)
                # Should redirect to / (no provider logout URL)
                assert resp.headers["location"] in ("/", "http://test/")

        _restore_app_state(originals)

    async def test_logout_provider_error_partial_logout(self, mock_github_client: MagicMock):
        """When provider.get_logout_url raises, redirect to /?partial_logout=1."""
        provider = MagicMock()
        provider.get_logout_url = AsyncMock(side_effect=Exception("Provider unreachable"))

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=provider,
        )

        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
                follow_redirects=False,
            ) as client:
                resp = await client.get("/auth/logout")
                assert resp.status_code in (302, 307)
                assert "partial_logout" in resp.headers["location"]

        _restore_app_state(originals)
