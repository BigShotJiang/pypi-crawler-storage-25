"""Integration tests for analytics dashboard routes (/app/{org}/api/analytics/*).

Tests health score, momentum, freshness, time-to-ship, and feature-usage
endpoints through the full FastAPI stack.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import httpx
import pytest

from canon.main import app

from .conftest import SEED_ORG

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Health score
# ---------------------------------------------------------------------------


class TestHealthScore:
    async def test_health_returns_200_or_not_configured(self, authed_app_client: httpx.AsyncClient):
        """Health score endpoint returns data or not_configured."""
        # Configure PostHog query client to indicate it's not configured
        app.state.posthog_query_client = MagicMock(configured=False)
        resp = await authed_app_client.get(f"/app/{SEED_ORG}/api/analytics/health")
        assert resp.status_code != 404
        data = resp.json()
        assert "error" in data or "score" in data

    async def test_health_with_repo_filter(self, authed_app_client: httpx.AsyncClient):
        app.state.posthog_query_client = MagicMock(configured=False)
        resp = await authed_app_client.get(f"/app/{SEED_ORG}/api/analytics/health?repo=test-repo")
        assert resp.status_code != 404


# ---------------------------------------------------------------------------
# Momentum
# ---------------------------------------------------------------------------


class TestMomentum:
    async def test_momentum_returns_200(self, authed_app_client: httpx.AsyncClient):
        app.state.posthog_query_client = MagicMock(configured=False)
        resp = await authed_app_client.get(f"/app/{SEED_ORG}/api/analytics/momentum")
        assert resp.status_code != 404

    async def test_momentum_with_days_param(self, authed_app_client: httpx.AsyncClient):
        app.state.posthog_query_client = MagicMock(configured=False)
        resp = await authed_app_client.get(f"/app/{SEED_ORG}/api/analytics/momentum?days=30")
        assert resp.status_code != 404


# ---------------------------------------------------------------------------
# Freshness
# ---------------------------------------------------------------------------


class TestFreshness:
    async def test_freshness_returns_200(self, authed_app_client: httpx.AsyncClient):
        app.state.posthog_query_client = MagicMock(configured=False)
        resp = await authed_app_client.get(f"/app/{SEED_ORG}/api/analytics/freshness")
        assert resp.status_code != 404


# ---------------------------------------------------------------------------
# Time to ship
# ---------------------------------------------------------------------------


class TestTimeToShip:
    async def test_time_to_ship_returns_200(self, authed_app_client: httpx.AsyncClient):
        app.state.posthog_query_client = MagicMock(configured=False)
        resp = await authed_app_client.get(f"/app/{SEED_ORG}/api/analytics/time-to-ship")
        assert resp.status_code != 404


# ---------------------------------------------------------------------------
# Feature usage
# ---------------------------------------------------------------------------


class TestFeatureUsage:
    async def test_feature_usage_returns_200(self, authed_app_client: httpx.AsyncClient):
        app.state.posthog_query_client = MagicMock(configured=False)
        resp = await authed_app_client.get(f"/app/{SEED_ORG}/api/analytics/feature-usage")
        assert resp.status_code != 404
