"""End-to-end workflow tests spanning multiple subsystems.

Tests the critical user journeys through the real FastAPI stack:
- Push webhook → spec parsing → ticket creation
- PR webhook → spec context → analysis
- Auth → session → dashboard access
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from canon.main import app

from .conftest import (
    SEED_ORG,
    TEST_WEBHOOK_SECRET,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    assert_redirects_to,
    make_session_cookie,
    sign_payload,
    webhook_headers,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# E2E: Push webhook → handler chain
# ---------------------------------------------------------------------------


class TestPushWebhookFlow:
    """Push webhook flows through signature verification → event routing → handler."""

    async def test_push_event_dispatches_to_handler(self, app_client: httpx.AsyncClient):
        """Full push webhook flow: signed request → routed to on_push handler."""
        payload = json.dumps(
            {
                "ref": "refs/heads/main",
                "repository": {"full_name": f"{SEED_ORG}/test-repo"},
                "installation": {"id": 12345},
                "commits": [
                    {
                        "id": "abc123",
                        "added": ["docs/specs/new-feature.md"],
                        "modified": [],
                        "removed": [],
                    }
                ],
            }
        ).encode()

        sig = sign_payload(payload, TEST_WEBHOOK_SECRET)
        headers = webhook_headers("push", sig)

        with patch("canon.github.handlers.on_push.on_push", new_callable=AsyncMock) as mock_on_push:
            mock_on_push.return_value = None
            resp = await app_client.post("/webhook", content=payload, headers=headers)

        assert resp.status_code == 200
        mock_on_push.assert_called_once()

    async def test_push_with_spec_files_detected(self, app_client: httpx.AsyncClient):
        """Push with spec file changes triggers the handler with spec context."""
        payload_dict = {
            "ref": "refs/heads/main",
            "repository": {"full_name": f"{SEED_ORG}/test-repo"},
            "installation": {"id": 12345},
            "commits": [
                {
                    "id": "def456",
                    "added": [],
                    "modified": ["docs/specs/auth-migration.md"],
                    "removed": [],
                }
            ],
        }
        payload = json.dumps(payload_dict).encode()

        sig = sign_payload(payload, TEST_WEBHOOK_SECRET)
        headers = webhook_headers("push", sig)

        with patch("canon.github.handlers.on_push.on_push", new_callable=AsyncMock) as mock_on_push:
            mock_on_push.return_value = None
            resp = await app_client.post("/webhook", content=payload, headers=headers)

        assert resp.status_code == 200
        # Verify the handler was called with the payload containing spec changes
        call_args = mock_on_push.call_args
        push_payload = call_args[0][1]  # second arg is the payload dict
        modified = push_payload["commits"][0]["modified"]
        assert "docs/specs/auth-migration.md" in modified


# ---------------------------------------------------------------------------
# E2E: PR webhook → analysis flow
# ---------------------------------------------------------------------------


class TestPRAnalysisFlow:
    """PR webhook flows through signature → routing → PR handler."""

    async def test_pr_opened_dispatches_to_handler(self, app_client: httpx.AsyncClient):
        """PR opened event is dispatched to the on_pull_request handler."""
        payload = json.dumps(
            {
                "action": "opened",
                "pull_request": {
                    "number": 99,
                    "head": {"sha": "abc123", "ref": "feature-branch"},
                    "base": {"ref": "main"},
                    "merged": False,
                },
                "repository": {"full_name": f"{SEED_ORG}/test-repo"},
                "installation": {"id": 12345},
            }
        ).encode()

        sig = sign_payload(payload, TEST_WEBHOOK_SECRET)
        headers = webhook_headers("pull_request", sig)

        with patch(
            "canon.github.handlers.on_pull_request.on_pull_request",
            new_callable=AsyncMock,
        ) as mock_on_pr:
            mock_on_pr.return_value = None
            resp = await app_client.post("/webhook", content=payload, headers=headers)

        assert resp.status_code == 200
        mock_on_pr.assert_called_once()

    async def test_pr_merged_dispatches_to_merged_handler(self, app_client: httpx.AsyncClient):
        """Merged PR dispatches to on_pull_request_merged handler."""
        payload = json.dumps(
            {
                "action": "closed",
                "pull_request": {
                    "number": 100,
                    "head": {"sha": "abc123", "ref": "feature"},
                    "base": {"ref": "main"},
                    "merged": True,
                },
                "repository": {"full_name": f"{SEED_ORG}/test-repo"},
                "installation": {"id": 12345},
            }
        ).encode()

        sig = sign_payload(payload, TEST_WEBHOOK_SECRET)
        headers = webhook_headers("pull_request", sig)

        with patch(
            "canon.github.handlers.on_pull_request_merged.on_pull_request_merged",
            new_callable=AsyncMock,
        ) as mock_on_merged:
            mock_on_merged.return_value = None
            resp = await app_client.post("/webhook", content=payload, headers=headers)

        assert resp.status_code == 200
        mock_on_merged.assert_called_once()


# ---------------------------------------------------------------------------
# E2E: Auth → Dashboard
# ---------------------------------------------------------------------------


class TestAuthToDashboardFlow:
    """Login → session → dashboard access flow."""

    async def test_unauthenticated_redirected_then_authenticated_accesses_dashboard(
        self, mock_github_client: MagicMock
    ):
        """Full flow: no session → redirect to login, then with session → dashboard."""
        from httpx import ASGITransport

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)

            # Step 1: Unauthenticated request → redirect to login
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test", follow_redirects=False
            ) as client:
                resp = await client.get("/app/")
                assert_redirects_to(resp, "/auth/login")

            # Step 2: With session cookie → dashboard accessible
            cookie = make_session_cookie(_session_data_for_user())
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
                follow_redirects=False,
            ) as client:
                resp = await client.get("/app/")
                # Should redirect to /app/{org}/ (not to /auth/login)
                assert resp.status_code == 302
                location = resp.headers.get("location", "")
                assert "/auth/login" not in location
                assert f"/app/{SEED_ORG}/" in location or "/app/" in location

        _restore_app_state(originals)

    async def test_session_cookie_grants_org_dashboard_access(
        self, authed_app_client: httpx.AsyncClient
    ):
        """With a valid session, the org dashboard loads successfully."""
        gh = app.state.github_client
        child = gh.for_installation.return_value
        child.list_installation_repos = AsyncMock(return_value=[])
        child.get_file_content = AsyncMock(return_value=None)
        child.list_directory = AsyncMock(return_value=[])

        resp = await authed_app_client.get(f"/app/{SEED_ORG}/")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# E2E: Webhook signature rejection
# ---------------------------------------------------------------------------


class TestWebhookSecurityFlow:
    """Verify the full security chain for webhooks."""

    async def test_tampered_payload_rejected(self, app_client: httpx.AsyncClient):
        """Signature computed for different payload is rejected."""
        original = b'{"ref": "refs/heads/main"}'
        tampered = b'{"ref": "refs/heads/evil"}'

        sig = sign_payload(original, TEST_WEBHOOK_SECRET)
        headers = webhook_headers("push", sig)

        resp = await app_client.post("/webhook", content=tampered, headers=headers)
        assert resp.status_code == 401

    async def test_wrong_secret_rejected(self, app_client: httpx.AsyncClient):
        """Signature with wrong secret is rejected."""
        payload = b'{"ref": "refs/heads/main"}'
        sig = sign_payload(payload, "wrong-secret")
        headers = webhook_headers("push", sig)

        resp = await app_client.post("/webhook", content=payload, headers=headers)
        assert resp.status_code == 401
