"""Integration tests for sw_ API key authentication through the full stack.

Tests the API key resolution path: hash lookup, expiry, revocation,
org isolation, and permission enforcement.
"""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.auth.permissions import Permission
from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _set_app_state,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

TEST_API_KEY = "sw_test_valid_key_12345"
TEST_KEY_HASH = hashlib.sha256(TEST_API_KEY.encode()).hexdigest()


def _make_api_key_record(
    *,
    org_login: str = SEED_ORG,
    revoked_at: datetime | None = None,
    expires_at: datetime | None = None,
    scopes: list[str] | None = None,
    user_status: str = "active",
) -> dict:
    """Build a realistic API key record."""
    if expires_at is None:
        expires_at = datetime.now(UTC) + timedelta(days=30)
    if scopes is None:
        scopes = [p.value for p in Permission]
    return {
        "revoked_at": revoked_at,
        "expires_at": expires_at,
        "org_login": org_login,
        "scopes": scopes,
        "user_sub": "user-1",
        "user_email": "user@test.com",
        "user_name": "Test User",
        "user_status": user_status,
    }


async def _make_api_key_client(
    mock_github_client: MagicMock,
    *,
    api_key_record: dict | None,
    user_store_side_effect: Exception | None = None,
):
    """Create a client with API key auth configured."""
    user_store = AsyncMock()
    if user_store_side_effect:
        user_store.get_api_key_by_hash = AsyncMock(side_effect=user_store_side_effect)
    else:
        user_store.get_api_key_by_hash = AsyncMock(return_value=api_key_record)
    user_store.get_user_by_sub = AsyncMock(return_value=None)

    settings = _base_settings(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="test-client",
        oidc_client_secret="test-oidc-secret",
        web_org="",
    )
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        oidc_provider=MagicMock(),
        user_store=user_store,
    )

    patches = [
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
        patch("canon.web.routes._get_spa_html", return_value=None),
    ]
    for p in patches:
        p.start()

    transport = ASGITransport(app=app, raise_app_exceptions=False)
    client = httpx.AsyncClient(transport=transport, base_url="http://test")

    return client, originals, patches


async def _cleanup(client, originals, patches):
    await client.aclose()
    for p in patches:
        p.stop()
    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Valid API key
# ---------------------------------------------------------------------------


class TestValidApiKey:
    async def test_valid_key_accesses_profile(self, mock_github_client: MagicMock):
        """Valid sw_ key with correct org → 200."""
        record = _make_api_key_record(org_login=SEED_ORG)
        client, originals, patches = await _make_api_key_client(
            mock_github_client, api_key_record=record
        )
        try:
            resp = await client.get(
                f"/app/{SEED_ORG}/api/profile",
                headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            )
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Expired API key
# ---------------------------------------------------------------------------


class TestExpiredApiKey:
    async def test_expired_key_returns_401(self, mock_github_client: MagicMock):
        """Expired sw_ key → 401 or redirect (middleware sees None org)."""
        record = _make_api_key_record(expires_at=datetime.now(UTC) - timedelta(days=1))
        client, originals, patches = await _make_api_key_client(
            mock_github_client, api_key_record=record
        )
        try:
            resp = await client.get(
                f"/app/{SEED_ORG}/api/profile",
                headers={
                    "Authorization": f"Bearer {TEST_API_KEY}",
                    "Accept": "application/json",
                },
            )
            # Middleware org resolution returns None for expired key → org mismatch → 403
            # OR the deps layer catches it and returns 401
            assert resp.status_code in (401, 403)
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Revoked API key
# ---------------------------------------------------------------------------


class TestRevokedApiKey:
    async def test_revoked_key_returns_401(self, mock_github_client: MagicMock):
        """Revoked sw_ key → 401 or 403."""
        record = _make_api_key_record(revoked_at=datetime.now(UTC) - timedelta(hours=1))
        client, originals, patches = await _make_api_key_client(
            mock_github_client, api_key_record=record
        )
        try:
            resp = await client.get(
                f"/app/{SEED_ORG}/api/profile",
                headers={
                    "Authorization": f"Bearer {TEST_API_KEY}",
                    "Accept": "application/json",
                },
            )
            assert resp.status_code in (401, 403)
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Unknown API key
# ---------------------------------------------------------------------------


class TestUnknownApiKey:
    async def test_unknown_key_returns_401(self, mock_github_client: MagicMock):
        """Unknown sw_ key (hash not found) → 401 or 403."""
        client, originals, patches = await _make_api_key_client(
            mock_github_client, api_key_record=None
        )
        try:
            resp = await client.get(
                f"/app/{SEED_ORG}/api/profile",
                headers={
                    "Authorization": "Bearer sw_unknown_key_xyz",
                    "Accept": "application/json",
                },
            )
            assert resp.status_code in (401, 403)
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# API key org mismatch
# ---------------------------------------------------------------------------


class TestApiKeyOrgMismatch:
    async def test_key_for_wrong_org_returns_403(self, mock_github_client: MagicMock):
        """sw_ key scoped to org-a accessing org-b → 403."""
        record = _make_api_key_record(org_login="org-a")
        client, originals, patches = await _make_api_key_client(
            mock_github_client, api_key_record=record
        )
        try:
            resp = await client.get(
                "/app/org-b/api/profile",
                headers={
                    "Authorization": f"Bearer {TEST_API_KEY}",
                    "Accept": "application/json",
                },
            )
            assert resp.status_code == 403
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# API key for deactivated user
# ---------------------------------------------------------------------------


class TestApiKeyDeactivatedUser:
    async def test_deactivated_user_key_returns_403(self, mock_github_client: MagicMock):
        """API key for deactivated user → 403."""
        record = _make_api_key_record(user_status="deactivated")
        client, originals, patches = await _make_api_key_client(
            mock_github_client, api_key_record=record
        )
        try:
            resp = await client.get(
                f"/app/{SEED_ORG}/api/profile",
                headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            )
            assert resp.status_code == 403
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# No user_store available
# ---------------------------------------------------------------------------


class TestApiKeyNoUserStore:
    async def test_no_user_store_returns_401(self, mock_github_client: MagicMock):
        """When user_store is None, API key auth is unavailable → 401."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
            user_store=None,  # No user store
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                resp = await client.get(
                    f"/app/{SEED_ORG}/api/profile",
                    headers={
                        "Authorization": f"Bearer {TEST_API_KEY}",
                        "Accept": "application/json",
                    },
                )
                # Middleware can't resolve org → 403,
                # or deps layer → 401 "API key auth not available"
                assert resp.status_code in (401, 403)

        _restore_app_state(originals)
