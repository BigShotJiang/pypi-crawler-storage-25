"""Integration tests for ticket sync adapters with HTTP-level mocking.

Tests the full adapter → HTTP → parse cycle using respx to mock at
the transport layer, verifying request construction and response parsing.
"""

from __future__ import annotations

import pytest
import respx
from httpx import Response

from canon.parser.models import SectionStatus
from canon.sync.adapters.github_issues import GitHubAdapter
from canon.sync.models import (
    CreateTicketInput,
    CreateTicketResult,
    GitHubConfig,
    TicketStatusResult,
    UpdateTicketInput,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# GitHub Issues Adapter
# ---------------------------------------------------------------------------


@pytest.fixture
def github_config() -> GitHubConfig:
    return GitHubConfig(
        token="ghp_test_token",
        default_owner="test-org",
        default_repo="test-repo",
    )


@pytest.fixture
def github_adapter(github_config: GitHubConfig) -> GitHubAdapter:
    return GitHubAdapter(github_config)


class TestGitHubAdapterCreate:
    @respx.mock
    async def test_create_ticket(self, github_adapter: GitHubAdapter):
        """Create ticket sends correct request and parses response."""
        respx.post("https://api.github.com/repos/test-org/test-repo/issues").mock(
            return_value=Response(
                201,
                json={
                    "number": 42,
                    "html_url": "https://github.com/test-org/test-repo/issues/42",
                    "labels": [],
                },
            )
        )

        result = await github_adapter.create_ticket(
            CreateTicketInput(
                project_key="test-repo",
                summary="Implement auth migration",
                description="Move from session to JWT",
                status=SectionStatus(state="todo"),
            )
        )

        assert isinstance(result, CreateTicketResult)
        assert result.ticket_id == "42"
        assert "test-org/test-repo/issues/42" in result.ticket_url

    @respx.mock
    async def test_create_ticket_with_labels(self, github_adapter: GitHubAdapter):
        """Extra labels are included in the issue creation."""
        route = respx.post("https://api.github.com/repos/test-org/test-repo/issues").mock(
            return_value=Response(
                201,
                json={
                    "number": 43,
                    "html_url": "https://github.com/test-org/test-repo/issues/43",
                    "labels": [],
                },
            )
        )

        await github_adapter.create_ticket(
            CreateTicketInput(
                project_key="test-repo",
                summary="Test",
                description="",
                status=SectionStatus(state="todo"),
                labels=["priority:high"],
            )
        )

        assert route.called
        body = route.calls[0].request.content
        import json

        payload = json.loads(body)
        assert "priority:high" in payload["labels"]


class TestGitHubAdapterGetStatus:
    @respx.mock
    async def test_get_ticket_status_open(self, github_adapter: GitHubAdapter):
        """Open issue with canon:todo label maps to todo status."""
        respx.get("https://api.github.com/repos/test-org/test-repo/issues/42").mock(
            return_value=Response(
                200,
                json={
                    "number": 42,
                    "state": "open",
                    "labels": [{"name": "canon:todo"}],
                },
            )
        )

        result = await github_adapter.get_ticket_status("42")
        assert isinstance(result, TicketStatusResult)
        assert result.status.state == "todo"

    @respx.mock
    async def test_get_ticket_status_closed(self, github_adapter: GitHubAdapter):
        """Closed issue with canon:done label maps to done status."""
        respx.get("https://api.github.com/repos/test-org/test-repo/issues/10").mock(
            return_value=Response(
                200,
                json={
                    "number": 10,
                    "state": "closed",
                    "labels": [{"name": "canon:done"}],
                },
            )
        )

        result = await github_adapter.get_ticket_status("10")
        assert result.status.state == "done"


class TestGitHubAdapterUpdate:
    @respx.mock
    async def test_update_ticket_status(self, github_adapter: GitHubAdapter):
        """Update ticket changes state and labels."""
        # First fetch to get current labels
        respx.get("https://api.github.com/repos/test-org/test-repo/issues/42").mock(
            return_value=Response(
                200,
                json={
                    "number": 42,
                    "state": "open",
                    "labels": [{"name": "canon:todo"}],
                },
            )
        )
        # Then patch
        patch_route = respx.patch("https://api.github.com/repos/test-org/test-repo/issues/42").mock(
            return_value=Response(200, json={"number": 42})
        )

        await github_adapter.update_ticket(
            UpdateTicketInput(
                ticket_id="42",
                status=SectionStatus(state="in_progress"),
            )
        )

        assert patch_route.called


class TestGitHubAdapterSearch:
    @respx.mock
    async def test_search_tickets(self, github_adapter: GitHubAdapter):
        """Search returns parsed results."""
        respx.get("https://api.github.com/search/issues").mock(
            return_value=Response(
                200,
                json={
                    "total_count": 1,
                    "items": [
                        {
                            "number": 42,
                            "title": "Auth Migration",
                            "html_url": "https://github.com/test-org/test-repo/issues/42",
                            "state": "open",
                        }
                    ],
                },
            )
        )

        results = await github_adapter.search_tickets("test-repo", "Auth Migration")
        assert len(results) == 1
        assert results[0].ticket_id == "42"
        assert results[0].title == "Auth Migration"


class TestGitHubAdapterErrors:
    @respx.mock
    async def test_404_raises(self, github_adapter: GitHubAdapter):
        """404 from GitHub API raises an error."""
        import httpx as _httpx

        respx.get("https://api.github.com/repos/test-org/test-repo/issues/999").mock(
            return_value=Response(404, json={"message": "Not Found"})
        )

        with pytest.raises(_httpx.HTTPStatusError):
            await github_adapter.get_ticket_status("999")

    @respx.mock
    async def test_401_raises(self, github_adapter: GitHubAdapter):
        """401 from GitHub API raises an error."""
        import httpx as _httpx

        respx.get("https://api.github.com/repos/test-org/test-repo/issues/1").mock(
            return_value=Response(401, json={"message": "Bad credentials"})
        )

        with pytest.raises(_httpx.HTTPStatusError):
            await github_adapter.get_ticket_status("1")


# ---------------------------------------------------------------------------
# Status Roundtrip
# ---------------------------------------------------------------------------


class TestStatusRoundtrip:
    """Verify status mapping is consistent: spec → GitHub → spec."""

    def test_todo_roundtrip(self):
        from canon.sync.status_map import github_to_spec_status, spec_status_to_github

        target = spec_status_to_github(SectionStatus(state="todo"))
        result = github_to_spec_status(target.state, [target.label])
        assert result.state == "todo"

    def test_done_roundtrip(self):
        from canon.sync.status_map import github_to_spec_status, spec_status_to_github

        target = spec_status_to_github(SectionStatus(state="done"))
        result = github_to_spec_status(target.state, [target.label])
        assert result.state == "done"

    def test_in_progress_roundtrip(self):
        from canon.sync.status_map import github_to_spec_status, spec_status_to_github

        target = spec_status_to_github(SectionStatus(state="in_progress"))
        result = github_to_spec_status(target.state, [target.label])
        assert result.state == "in_progress"
