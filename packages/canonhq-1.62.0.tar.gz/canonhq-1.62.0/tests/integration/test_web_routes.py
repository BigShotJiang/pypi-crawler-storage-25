"""Integration tests for web app routes through the real FastAPI stack.

Tests dashboard, editor, API, and marketing routes with real middleware,
auth chain, and routing — mocking only at the app.state / external service level.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from canon.main import app

from .conftest import (
    SEED_ORG,
    SEED_REPO,
    SEED_REPOS,
    _base_settings,
    _restore_app_state,
    _set_app_state,
    assert_html_contains,
    assert_redirects_to,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Marketing / Public Pages
# ---------------------------------------------------------------------------


class TestMarketingPages:
    """Public pages that don't require auth."""

    async def test_landing_page_returns_200(self, noauth_app_client: httpx.AsyncClient):
        resp = await noauth_app_client.get("/")
        assert resp.status_code == 200

    async def test_landing_page_contains_branding(self, noauth_app_client: httpx.AsyncClient):
        resp = await noauth_app_client.get("/")
        assert_html_contains(resp, "Canon")

    async def test_healthz(self, noauth_app_client: httpx.AsyncClient):
        resp = await noauth_app_client.get("/healthz")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}


class TestWaitlistApi:
    """POST /api/waitlist — public endpoint."""

    async def test_valid_email_returns_201(self, noauth_app_client: httpx.AsyncClient):
        with patch("canon.web.routes.analytics"):
            resp = await noauth_app_client.post(
                "/api/waitlist",
                json={"email": "test@example.com"},
            )
        assert resp.status_code == 201
        assert resp.json()["ok"] is True

    async def test_invalid_email_returns_400(self, noauth_app_client: httpx.AsyncClient):
        resp = await noauth_app_client.post(
            "/api/waitlist",
            json={"email": "not-an-email"},
        )
        assert resp.status_code == 400

    async def test_empty_body_returns_400(self, noauth_app_client: httpx.AsyncClient):
        resp = await noauth_app_client.post(
            "/api/waitlist",
            json={},
        )
        assert resp.status_code == 400

    async def test_malformed_json_returns_400(self, noauth_app_client: httpx.AsyncClient):
        resp = await noauth_app_client.post(
            "/api/waitlist",
            content=b"not json",
            headers={"content-type": "application/json"},
        )
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Dashboard Auth Enforcement
# ---------------------------------------------------------------------------


class TestDashboardAuthEnforcement:
    """Verify that /app/* routes redirect unauthenticated users to login."""

    async def test_app_root_redirects_to_login_when_auth_enabled(
        self, mock_github_client: MagicMock
    ):
        """When auth is enabled, unauthenticated /app/ → /auth/login."""
        from httpx import ASGITransport

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )

        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ):
            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                follow_redirects=False,
            ) as client:
                resp = await client.get("/app/")
                assert_redirects_to(resp, "/auth/login")

        _restore_app_state(originals)

    async def test_app_root_no_redirect_when_auth_disabled(
        self, noauth_app_client: httpx.AsyncClient
    ):
        """When auth is disabled, /app/ does NOT redirect to /auth/login."""
        resp = await noauth_app_client.get("/app/", follow_redirects=False)
        # Should redirect to /app/{org}/, not to /auth/login
        assert resp.status_code == 302
        location = resp.headers.get("location", "")
        assert "/auth/login" not in location


# ---------------------------------------------------------------------------
# Dashboard Routes (authenticated)
# ---------------------------------------------------------------------------


class TestDashboardRoutes:
    """Authenticated access to /app/* routes."""

    async def test_app_root_redirects_to_org(self, authed_app_client: httpx.AsyncClient):
        """GET /app/ redirects to /app/{org}/."""
        resp = await authed_app_client.get("/app/", follow_redirects=False)
        assert resp.status_code == 302
        location = resp.headers.get("location", "")
        assert f"/app/{SEED_ORG}/" in location

    async def test_org_dashboard_returns_200(self, authed_app_client: httpx.AsyncClient):
        """GET /app/{org}/ returns the org dashboard."""
        # Mock the GitHub client to return repo list
        gh = app.state.github_client
        child = gh.for_installation.return_value
        child.list_installation_repos = AsyncMock(return_value=SEED_REPOS)
        child.get_file_content = AsyncMock(return_value=None)
        child.list_directory = AsyncMock(return_value=[])

        resp = await authed_app_client.get(f"/app/{SEED_ORG}/")
        assert resp.status_code == 200

    async def test_repo_detail_returns_200(self, authed_app_client: httpx.AsyncClient):
        """GET /app/{org}/repos/{owner}/{repo} returns repo detail page."""
        gh = app.state.github_client
        child = gh.for_installation.return_value
        child.list_directory = AsyncMock(return_value=[])
        child.get_file_content = AsyncMock(return_value=None)

        resp = await authed_app_client.get(f"/app/{SEED_ORG}/repos/{SEED_ORG}/{SEED_REPO}")
        # 200 if found, 404 if repo not found (both are valid responses from the route)
        assert resp.status_code in (200, 404)

    async def test_no_org_page_returns_200(self, authed_app_client: httpx.AsyncClient):
        """GET /app/no-org returns onboarding page."""
        resp = await authed_app_client.get("/app/no-org")
        assert resp.status_code == 200


class TestSearchRoute:
    """GET /app/{org}/search — search functionality."""

    async def test_search_returns_200(self, authed_app_client: httpx.AsyncClient):
        """Search page renders with query."""
        resp = await authed_app_client.get(f"/app/{SEED_ORG}/search?q=auth")
        # Should return 200 (even if search index is empty/mocked)
        assert resp.status_code == 200
