"""Integration tests for profile and settings routes.

Tests /app/{org}/api/profile and integration/connection settings
through the real FastAPI stack with auth.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


async def _make_profile_client(
    mock_github_client: MagicMock,
    *,
    user_store: AsyncMock | None = None,
    connection_store: AsyncMock | None = None,
    integration_store: AsyncMock | None = None,
):
    settings = _base_settings(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="test-client",
        oidc_client_secret="test-oidc-secret",
        web_org="",
    )
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        oidc_provider=MagicMock(),
        user_store=user_store,
    )
    if connection_store is not None:
        app.state.connection_store = connection_store
    if integration_store is not None:
        app.state.integration_store = integration_store

    cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))

    patches = [
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
        patch("canon.web.routes._get_spa_html", return_value=None),
    ]
    for p in patches:
        p.start()

    transport = ASGITransport(app=app, raise_app_exceptions=False)
    client = httpx.AsyncClient(
        transport=transport,
        base_url="http://test",
        cookies={"session": cookie},
    )
    return client, originals, patches


async def _cleanup(client, originals, patches):
    await client.aclose()
    for p in patches:
        p.stop()
    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Profile route
# ---------------------------------------------------------------------------


class TestProfileRoute:
    async def test_profile_returns_user_info(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/profile returns user profile."""
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value=None)

        client, originals, patches = await _make_profile_client(
            mock_github_client, user_store=user_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile")
            assert resp.status_code == 200
            data = resp.json()
            assert "email" in data
            assert "permissions" in data
        finally:
            await _cleanup(client, originals, patches)

    async def test_profile_includes_last_login(self, mock_github_client: MagicMock):
        """Profile includes last_login_at when available in DB."""
        from datetime import UTC, datetime

        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(
            return_value={
                "sub": "test-user-1",
                "last_login_at": datetime(2026, 4, 1, tzinfo=UTC),
            }
        )

        client, originals, patches = await _make_profile_client(
            mock_github_client, user_store=user_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile")
            assert resp.status_code == 200
            data = resp.json()
            assert data.get("last_login_at") is not None
        finally:
            await _cleanup(client, originals, patches)

    async def test_profile_without_user_store(self, mock_github_client: MagicMock):
        """Profile works when user_store is None."""
        client, originals, patches = await _make_profile_client(mock_github_client, user_store=None)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Connection settings
# ---------------------------------------------------------------------------


class TestConnectionSettings:
    async def test_list_connections_returns_200(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/settings/connections returns connections."""
        connection_store = AsyncMock()
        connection_store.list_connections = AsyncMock(return_value=[])

        client, originals, patches = await _make_profile_client(
            mock_github_client, connection_store=connection_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/settings/connections")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)

    async def test_connections_without_store_returns_empty(self, mock_github_client: MagicMock):
        """Connections endpoint returns empty list when store is None.

        This is intentional: connection_store is only initialized when
        byok_encryption_key is set. Empty list = feature not configured.
        """
        client, originals, patches = await _make_profile_client(
            mock_github_client, connection_store=None
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/settings/connections")
            assert resp.status_code == 200
            assert resp.json() == {"connections": []}
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Integration settings
# ---------------------------------------------------------------------------


class TestIntegrationSettings:
    async def test_list_integrations_returns_200(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/settings/integrations returns integrations."""
        integration_store = AsyncMock()
        integration_store.list_integrations = AsyncMock(return_value=[])

        client, originals, patches = await _make_profile_client(
            mock_github_client, integration_store=integration_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/settings/integrations")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)

    async def test_integration_summary_returns_200(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/settings/integrations/summary returns summary."""
        integration_store = AsyncMock()
        integration_store.list_integrations = AsyncMock(return_value=[])
        integration_store.get_summary = AsyncMock(
            return_value={"total": 0, "connected": 0, "needs_attention": 0}
        )

        client, originals, patches = await _make_profile_client(
            mock_github_client, integration_store=integration_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/settings/integrations/summary")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Session API (SPA bootstrap data)
# ---------------------------------------------------------------------------


class TestSessionApi:
    async def test_session_api_returns_user_data(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/session returns session bootstrap data for SPA."""
        client, originals, patches = await _make_profile_client(mock_github_client)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/session")
            assert resp.status_code == 200
            data = resp.json()
            assert "user" in data
            assert "permissions" in data
        finally:
            await _cleanup(client, originals, patches)
