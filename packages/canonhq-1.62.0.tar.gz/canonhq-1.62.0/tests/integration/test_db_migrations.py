"""Integration tests for database migrations against a real PostgreSQL instance.

These tests validate that Canon's Alembic migration pipeline works correctly
end-to-end: fresh installs, idempotency, and migration state tracking.

Requires a running PostgreSQL server (provided by docker-compose.test.yml):

    postgresql://canon:testpass@localhost:15432/canon_test

Run with::

    uv run pytest -m integration tests/integration/test_db_migrations.py -v

"""

from __future__ import annotations

import asyncio
import os

import asyncpg
import pytest

from canon.db.migrate import run_upgrade

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    "postgresql://canon:testpass@localhost:15432/canon_test",
)


def _can_connect() -> bool:
    """Return True if the test database is reachable."""
    try:
        loop = asyncio.new_event_loop()
        try:

            async def _check() -> None:
                conn = await asyncpg.connect(DATABASE_URL, timeout=5)
                await conn.close()

            loop.run_until_complete(_check())
        finally:
            loop.close()
        return True
    except Exception:
        return False


_DB_AVAILABLE = _can_connect()

skip_no_db = pytest.mark.skipif(
    not _DB_AVAILABLE,
    reason="Test database not available (set DATABASE_URL or start docker-compose.test.yml)",
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _drop_all_tables() -> None:
    """Drop all tables in the public schema to ensure a clean slate."""
    conn = await asyncpg.connect(DATABASE_URL, timeout=5)
    try:
        # Drop alembic_version first (if it exists) to avoid FK issues
        await conn.execute("DROP TABLE IF EXISTS alembic_version CASCADE")
        # Fetch and drop all remaining public tables
        rows = await conn.fetch(
            "SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'"
        )
        for row in rows:
            await conn.execute(f'DROP TABLE IF EXISTS "{row["tablename"]}" CASCADE')
    finally:
        await conn.close()


async def _get_public_tables() -> set[str]:
    """Return the set of table names in the public schema."""
    conn = await asyncpg.connect(DATABASE_URL, timeout=5)
    try:
        rows = await conn.fetch(
            "SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'"
        )
        return {row["tablename"] for row in rows}
    finally:
        await conn.close()


async def _get_alembic_version() -> str | None:
    """Return the current Alembic migration version, or None if untracked."""
    conn = await asyncpg.connect(DATABASE_URL, timeout=5)
    try:
        # Check existence and query on the same connection to avoid race
        row = await conn.fetchrow("SELECT version_num FROM alembic_version LIMIT 1")
        return row["version_num"] if row else None
    except asyncpg.UndefinedTableError:
        return None
    finally:
        await conn.close()


def _run_migrations() -> None:
    """Run all migrations to head using Canon's public API."""
    run_upgrade(DATABASE_URL, revision="head")


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clean_database():
    """Ensure every test starts with a completely empty public schema."""
    if not _DB_AVAILABLE:
        return
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_drop_all_tables())
    finally:
        loop.close()
    yield
    # Cleanup after test as well for good hygiene
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_drop_all_tables())
    finally:
        loop.close()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.integration
@skip_no_db
class TestDatabaseMigrations:
    """Validate Canon's database migration pipeline against real PostgreSQL."""

    # -- 1. Fresh install: all migrations from empty DB ----------------------

    @pytest.mark.asyncio
    async def test_fresh_install_creates_expected_tables(self) -> None:
        """Running all migrations on an empty database creates the expected tables."""
        # Verify we start clean
        tables_before = await _get_public_tables()
        assert len(tables_before) == 0, f"Expected empty DB, found tables: {tables_before}"

        # Run all migrations
        await asyncio.to_thread(_run_migrations)

        tables = await _get_public_tables()

        # Core tables from baseline (0001)
        expected_core = {
            "users",
            "gh_installations",
            "spec_documents",
            "spec_sections",
            "sessions",
            "subscriptions",
        }
        for table in expected_core:
            assert table in tables, f"Expected table '{table}' not found after migration"

        # Alembic tracking table should exist
        assert "alembic_version" in tables

    # -- 2. Idempotency: running twice is a no-op ---------------------------

    def test_idempotency_no_errors_on_second_run(self) -> None:
        """Running migrations twice in a row does not raise errors.

        The second run should detect that all migrations are already applied
        and complete as a no-op.
        """
        _run_migrations()
        # Second run -- should not raise
        _run_migrations()

    @pytest.mark.asyncio
    async def test_idempotency_same_tables_after_second_run(self) -> None:
        """The set of tables is identical after running migrations twice."""
        await asyncio.to_thread(_run_migrations)
        tables_first = await _get_public_tables()

        await asyncio.to_thread(_run_migrations)
        tables_second = await _get_public_tables()

        assert tables_first == tables_second

    # -- 3. Migration state tracking ----------------------------------------

    @pytest.mark.asyncio
    async def test_migration_version_recorded(self) -> None:
        """After running migrations, the alembic_version table has a version."""
        version_before = await _get_alembic_version()
        assert version_before is None, "Expected no version before migration"

        await asyncio.to_thread(_run_migrations)

        version_after = await _get_alembic_version()
        assert version_after is not None, "Expected a version to be recorded after migration"

    @pytest.mark.asyncio
    async def test_migration_version_is_head(self) -> None:
        """The recorded version matches the latest migration revision."""
        await asyncio.to_thread(_run_migrations)

        version = await _get_alembic_version()
        assert version is not None

        # The latest migration file is 0011_sync_history.py -> revision "0011"
        # But Alembic stores the full revision hash. We verify the version
        # table has exactly one row with a non-empty value.
        conn = await asyncpg.connect(DATABASE_URL, timeout=5)
        try:
            rows = await conn.fetch("SELECT version_num FROM alembic_version")
            assert len(rows) == 1, f"Expected exactly 1 version row, got {len(rows)}"
            assert rows[0]["version_num"], "Version should not be empty"
        finally:
            await conn.close()

    @pytest.mark.asyncio
    async def test_migration_version_stable_after_rerun(self) -> None:
        """The recorded version does not change when migrations are re-run."""
        await asyncio.to_thread(_run_migrations)
        version_first = await _get_alembic_version()

        await asyncio.to_thread(_run_migrations)
        version_second = await _get_alembic_version()

        assert version_first == version_second
