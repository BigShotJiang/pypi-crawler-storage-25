"""Live-provider smoke tests for :class:`GenericOIDCProvider`.

These tests exercise the generic OIDC provider against **real** identity
providers to catch real-world compatibility issues that mocked unit tests
cannot detect (non-standard claims, PKCE quirks, token endpoint idiosyncrasies,
end_session behavior, device auth support, etc.).

They satisfy the manual-verification acceptance criterion in
``docs/specs/oidc-migration.md`` §3:

    "Provider tested against at least Zitadel, Keycloak, and one commercial
    provider (Okta or Google Workspace)."

Running the harness
-------------------

All tests in this module are marked ``pytest.mark.integration`` and are
therefore deselected by default (see ``pyproject.toml``: ``addopts =
"-m 'not integration'"``). To run them::

    uv run pytest -m integration tests/integration/test_oidc_providers_live.py

Each provider is independently gated on three environment variables. Tests
for providers whose env vars are not configured are **skipped** rather than
failed, so partial coverage (e.g. only Keycloak locally) is supported::

    OIDC_SMOKE_ZITADEL_ISSUER
    OIDC_SMOKE_ZITADEL_CLIENT_ID
    OIDC_SMOKE_ZITADEL_CLIENT_SECRET

    OIDC_SMOKE_KEYCLOAK_ISSUER
    OIDC_SMOKE_KEYCLOAK_CLIENT_ID
    OIDC_SMOKE_KEYCLOAK_CLIENT_SECRET

    OIDC_SMOKE_OKTA_ISSUER
    OIDC_SMOKE_OKTA_CLIENT_ID
    OIDC_SMOKE_OKTA_CLIENT_SECRET

    OIDC_SMOKE_GOOGLE_ISSUER         # usually https://accounts.google.com
    OIDC_SMOKE_GOOGLE_CLIENT_ID
    OIDC_SMOKE_GOOGLE_CLIENT_SECRET

Optional per-provider variables enable deeper checks:

    OIDC_SMOKE_<NAME>_REFRESH_TOKEN  # exercises refresh_tokens() end-to-end
    OIDC_SMOKE_<NAME>_AUDIENCE       # set if the provider requires `audience`
    OIDC_SMOKE_<NAME>_SCOPES         # override default scopes

What is (and isn't) covered
---------------------------

Automated (runs without human interaction):
  * Discovery document fetch + RFC 8414 §3.3 issuer match
  * Required endpoints present (authorization, token, jwks)
  * JWKS URI returns a valid JWK Set
  * Login URL construction uses discovered endpoints
  * Device authorization endpoint initiation (when advertised)
  * Refresh token exchange (when ``_REFRESH_TOKEN`` env var is provided)

Not automated (requires a human):
  * Interactive login (username/password/MFA)
  * End-to-end code exchange from a browser redirect
  * Logout redirect landing

The workflow for a fully-verified provider is therefore:
  1. Run this harness against the provider → confirms discovery, JWKS,
     device auth, and any pre-minted refresh token still work.
  2. A human performs one interactive login in a browser once, pastes the
     resulting refresh token into ``OIDC_SMOKE_<NAME>_REFRESH_TOKEN``, and
     re-runs the harness to prove refresh works end-to-end.
  3. Record the run in ``docs/specs/oidc-migration.md`` with a
     ``<!-- canon:realized-in:... -->`` comment and flip the AC.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import httpx
import pytest

from canon.auth.providers.generic_oidc import GenericOIDCProvider
from canon.auth.providers.protocol import DeviceCodeResponse, Pending, TokenSet
from canon.settings import Settings

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Provider configuration (env-var driven)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ProviderConfig:
    """Live-provider credentials read from environment variables."""

    name: str
    issuer: str
    client_id: str
    client_secret: str
    audience: str = ""
    scopes: str = "openid email profile"
    refresh_token: str = ""

    @classmethod
    def from_env(cls, name: str) -> ProviderConfig | None:
        """Return a config if all required env vars are set, else ``None``."""
        prefix = f"OIDC_SMOKE_{name.upper()}_"
        issuer = os.environ.get(f"{prefix}ISSUER", "").strip()
        client_id = os.environ.get(f"{prefix}CLIENT_ID", "").strip()
        client_secret = os.environ.get(f"{prefix}CLIENT_SECRET", "").strip()
        if not (issuer and client_id and client_secret):
            return None
        return cls(
            name=name,
            issuer=issuer,
            client_id=client_id,
            client_secret=client_secret,
            audience=os.environ.get(f"{prefix}AUDIENCE", "").strip(),
            scopes=os.environ.get(f"{prefix}SCOPES", "openid email profile").strip(),
            refresh_token=os.environ.get(f"{prefix}REFRESH_TOKEN", "").strip(),
        )


#: Providers listed in the spec acceptance criterion. Each entry becomes a
#: parameterized test case; missing env vars cause the case to skip.
SPEC_PROVIDERS = ("zitadel", "keycloak", "okta", "google")


def _configured_providers() -> list[ProviderConfig]:
    """Return every provider that has complete env-var configuration."""
    return [cfg for name in SPEC_PROVIDERS if (cfg := ProviderConfig.from_env(name))]


def _provider_param(name: str) -> ProviderConfig:
    """Fetch one provider's config or raise ``pytest.skip`` with a clear reason."""
    cfg = ProviderConfig.from_env(name)
    if cfg is None:
        pytest.skip(
            f"Skipping {name}: set OIDC_SMOKE_{name.upper()}_ISSUER, "
            f"OIDC_SMOKE_{name.upper()}_CLIENT_ID, and "
            f"OIDC_SMOKE_{name.upper()}_CLIENT_SECRET to enable this case."
        )
    return cfg


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(params=SPEC_PROVIDERS, ids=lambda n: n)
def provider_cfg(request: pytest.FixtureRequest) -> ProviderConfig:
    """Parameterized fixture that yields one configured provider per case.

    Cases for providers without env-var configuration are skipped (not failed).
    """
    return _provider_param(request.param)


@pytest.fixture
async def live_provider(provider_cfg: ProviderConfig):
    """Instantiate :class:`GenericOIDCProvider` against a real IDP."""
    settings = Settings(
        oidc_issuer=provider_cfg.issuer,
        oidc_client_id=provider_cfg.client_id,
        oidc_client_secret=provider_cfg.client_secret,
        oidc_audience=provider_cfg.audience,
        oidc_scopes=provider_cfg.scopes,
    )
    provider = GenericOIDCProvider(settings=settings)
    try:
        yield provider
    finally:
        await provider.aclose()


# ---------------------------------------------------------------------------
# Coverage reporter
# ---------------------------------------------------------------------------


def test_spec_coverage_report() -> None:
    """Fail loudly if *zero* providers are configured.

    The spec AC requires Zitadel + Keycloak + one commercial provider. This
    test is intentionally *not* a per-provider check — it's a single gate that
    reminds the operator to configure at least one provider before calling
    this harness "run". Individual per-provider coverage is still reported via
    parameterized skips in the tests below.
    """
    configured = [cfg.name for cfg in _configured_providers()]
    if not configured:
        pytest.skip(
            "No OIDC smoke providers configured. Set at least one of: "
            + ", ".join(f"OIDC_SMOKE_{n.upper()}_*" for n in SPEC_PROVIDERS)
        )
    print(f"\n[oidc-smoke] configured providers: {', '.join(configured)}")


# ---------------------------------------------------------------------------
# Discovery + JWKS (fully automated)
# ---------------------------------------------------------------------------


class TestDiscovery:
    """Discovery document and JWKS endpoint reachability."""

    async def test_discovery_document_matches_issuer(
        self, live_provider: GenericOIDCProvider, provider_cfg: ProviderConfig
    ) -> None:
        """Discovery must succeed and the returned ``issuer`` must match (RFC 8414 §3.3)."""
        await live_provider._ensure_discovered()
        # If we got here without raising, discovery succeeded and the issuer
        # comparison passed inside _ensure_discovered. Assert the endpoints
        # actually populated, to catch partial docs.
        assert live_provider._authorization_endpoint, (
            f"{provider_cfg.name}: discovery doc missing authorization_endpoint"
        )
        assert live_provider._token_endpoint, (
            f"{provider_cfg.name}: discovery doc missing token_endpoint"
        )
        assert live_provider._jwks_uri, f"{provider_cfg.name}: discovery doc missing jwks_uri"

    async def test_jwks_endpoint_returns_valid_jwks(
        self, live_provider: GenericOIDCProvider, provider_cfg: ProviderConfig
    ) -> None:
        """The discovered ``jwks_uri`` must serve a JWK Set with at least one key."""
        jwks_uri = await live_provider.get_jwks_uri()
        async with httpx.AsyncClient(timeout=30) as http:
            resp = await http.get(jwks_uri)
        assert resp.status_code == 200, (
            f"{provider_cfg.name}: JWKS fetch failed (status={resp.status_code}, uri={jwks_uri})"
        )
        body = resp.json()
        keys = body.get("keys", [])
        assert isinstance(keys, list) and keys, f"{provider_cfg.name}: JWKS document has no keys"
        # Every JWK must at minimum have ``kty`` and ``kid`` (RFC 7517).
        for i, key in enumerate(keys):
            assert "kty" in key, f"{provider_cfg.name}: JWK[{i}] missing 'kty'"
            assert "kid" in key, f"{provider_cfg.name}: JWK[{i}] missing 'kid'"


# ---------------------------------------------------------------------------
# Login URL construction (automated)
# ---------------------------------------------------------------------------


class TestLoginUrl:
    async def test_login_url_uses_discovered_endpoint(
        self, live_provider: GenericOIDCProvider, provider_cfg: ProviderConfig
    ) -> None:
        """Login URL must be rooted at the discovered ``authorization_endpoint``."""
        url = await live_provider.get_login_url(
            redirect_uri="https://example.com/callback",
            state="smoke-test-state",
        )
        assert url.startswith(live_provider._authorization_endpoint), (
            f"{provider_cfg.name}: login URL does not start with discovered "
            f"authorization_endpoint. got={url!r} "
            f"expected_prefix={live_provider._authorization_endpoint!r}"
        )
        # Sanity: required OAuth2 params are present.
        for required in ("response_type=code", "client_id=", "redirect_uri=", "state="):
            assert required in url, f"{provider_cfg.name}: login URL missing {required!r}: {url}"


# ---------------------------------------------------------------------------
# Device authorization flow (automated initiation only)
# ---------------------------------------------------------------------------


class TestDeviceAuth:
    async def test_device_code_initiation(
        self, live_provider: GenericOIDCProvider, provider_cfg: ProviderConfig
    ) -> None:
        """If the provider advertises a device authorization endpoint, initiating
        a device code request must succeed. If the provider does not advertise
        one, the method returns ``None`` and this test is skipped.

        The provider raises ``RuntimeError`` when an advertised endpoint
        returns a non-200 (bad credentials, provider quirks, etc.) — those
        propagate out of the test so the operator sees the exact HTTP status
        and body, which is usually enough to diagnose the issue.
        """
        # Populate discovery attrs before doing anything else, so we can
        # report "unsupported" cleanly.
        await live_provider._ensure_discovered()
        if not live_provider._device_authorization_endpoint:
            pytest.skip(
                f"{provider_cfg.name} does not advertise device authorization; "
                f"skipping device flow test."
            )
        result = await live_provider.get_device_code()
        assert result is not None, (
            f"{provider_cfg.name}: device_authorization_endpoint is advertised "
            f"but get_device_code() returned None"
        )
        assert isinstance(result, DeviceCodeResponse)
        assert result.device_code, f"{provider_cfg.name}: empty device_code"
        assert result.user_code, f"{provider_cfg.name}: empty user_code"
        assert result.verification_uri or result.verification_uri_complete, (
            f"{provider_cfg.name}: no verification URI returned"
        )


# ---------------------------------------------------------------------------
# Refresh token exchange (gated on OIDC_SMOKE_<NAME>_REFRESH_TOKEN)
# ---------------------------------------------------------------------------


class TestRefreshToken:
    async def test_refresh_token_exchange(
        self, live_provider: GenericOIDCProvider, provider_cfg: ProviderConfig
    ) -> None:
        """Exchange a pre-provisioned refresh token for a fresh access token.

        This is the closest we can get to end-to-end coverage without a human
        in the loop. The operator obtains a refresh token once (via an
        interactive browser login), stores it in
        ``OIDC_SMOKE_<NAME>_REFRESH_TOKEN``, and re-runs this harness.
        """
        if not provider_cfg.refresh_token:
            pytest.skip(
                f"{provider_cfg.name}: set OIDC_SMOKE_{provider_cfg.name.upper()}_"
                f"REFRESH_TOKEN to exercise refresh_tokens() against this provider."
            )
        token_set = await live_provider.refresh_tokens(refresh_token=provider_cfg.refresh_token)
        assert isinstance(token_set, TokenSet)
        assert token_set.access_token, f"{provider_cfg.name}: refresh returned empty access_token"
        assert token_set.expires_in > 0, (
            f"{provider_cfg.name}: refresh returned non-positive expires_in"
        )


# ---------------------------------------------------------------------------
# Pending is re-exported for documentation / IDE hover only
# ---------------------------------------------------------------------------
# (Pending is imported at module top so the import stays next to TokenSet and
#  DeviceCodeResponse in the protocol imports.)
_ = Pending
