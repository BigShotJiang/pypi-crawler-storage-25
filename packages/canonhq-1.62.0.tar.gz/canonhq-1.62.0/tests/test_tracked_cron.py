"""Tests for the tracked_cron decorator."""

from __future__ import annotations

import importlib
from unittest.mock import patch

import pytest

from canon.alerts.cron_utils import tracked_cron

# Every cron in src/canon/cron/ that must be observable in the
# Canon · Cron Jobs dashboard. When adding a new cron, append its
# (module_path, entry_function_name) tuple here and the test below will
# fail until @tracked_cron is applied.
#
# Three crons were already decorated (stale_specs, team_digest,
# weekly_digest) — the other six were added in the instrumentation PR.
_EXPECTED_TRACKED_CRONS: list[tuple[str, str]] = [
    ("canon.cron.audit_retention", "run_audit_retention"),
    ("canon.cron.cleanup_keys", "run_cleanup"),
    ("canon.cron.cleanup_sessions", "run_cleanup"),
    ("canon.cron.coverage_snapshot", "run_coverage_snapshot"),
    # ``stale_check`` and ``stale_specs`` both happen to use the name
    # ``run_stale_check`` — the module path is the disambiguator.
    ("canon.cron.stale_check", "run_stale_check"),
    ("canon.cron.stale_specs", "run_stale_check"),
    ("canon.cron.sync_status", "run_reverse_sync"),
    ("canon.cron.team_digest", "run_team_digest"),
    ("canon.cron.weekly_digest", "run_weekly_digest"),
]


class TestCronInstrumentationCoverage:
    """Every production cron entry function must be wrapped with
    ``@tracked_cron``. Without this test, a new cron added without the
    decorator would be invisible to the Canon · Cron Jobs dashboard
    (no cron_job_executed events) and operators would have no signal
    for job failure or missed runs.
    """

    @pytest.mark.parametrize(
        ("module_path", "function_name"),
        _EXPECTED_TRACKED_CRONS,
        ids=[f"{m}.{fn}" for m, fn in _EXPECTED_TRACKED_CRONS],
    )
    def test_cron_entry_is_tracked(self, module_path: str, function_name: str):
        try:
            module = importlib.import_module(module_path)
        except ModuleNotFoundError as exc:
            pytest.fail(f"cron module {module_path} not importable: {exc}")

        fn = getattr(module, function_name, None)
        if fn is None:
            pytest.fail(
                f"expected async entry function {function_name} in {module_path} — "
                "if the function was renamed, update _EXPECTED_TRACKED_CRONS"
            )

        # tracked_cron uses functools.wraps, so the decorated function
        # exposes a ``__wrapped__`` attribute pointing at the user fn.
        # Missing __wrapped__ means the decorator wasn't applied.
        assert hasattr(fn, "__wrapped__"), (
            f"{module_path}.{function_name} is not decorated with @tracked_cron "
            f"— Canon · Cron Jobs dashboard has no signal for this job"
        )


class TestTrackedCron:
    @pytest.mark.asyncio
    async def test_tracks_successful_cron(self):
        @tracked_cron("test_job")
        async def my_job():
            return {"items": 5}

        with patch("canon.alerts.cron_utils.analytics") as mock_analytics:
            result = await my_job()
            assert result == {"items": 5}

            mock_analytics.track.assert_called_once()
            call_args = mock_analytics.track.call_args
            assert call_args[0][0] == "cron_job_executed"
            props = call_args[1]["properties"]
            assert props["job_name"] == "test_job"
            assert props["success"] is True
            assert "duration_ms" in props
            assert props["error_message"] == ""

    @pytest.mark.asyncio
    async def test_tracks_failed_cron(self):
        @tracked_cron("failing_job")
        async def my_job():
            raise ValueError("something broke")

        with patch("canon.alerts.cron_utils.analytics") as mock_analytics:
            with pytest.raises(ValueError, match="something broke"):
                await my_job()

            mock_analytics.track.assert_called_once()
            props = mock_analytics.track.call_args[1]["properties"]
            assert props["job_name"] == "failing_job"
            assert props["success"] is False
            assert "something broke" in props["error_message"]
