"""Tests for Slack user -> Canon permission mapping."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from canon_slack.permissions import Permission, resolve_permission


class TestResolvePermission:
    @pytest.mark.asyncio
    async def test_unknown_user_gets_read(self):
        registry = AsyncMock()
        registry.get_github_login_for_slack.return_value = None
        perm = await resolve_permission("U123", registry)
        assert perm == Permission.READ

    @pytest.mark.asyncio
    async def test_known_user_gets_write(self):
        registry = AsyncMock()
        registry.get_github_login_for_slack.return_value = "alice"
        registry.get_user_role.return_value = "member"
        perm = await resolve_permission("U123", registry)
        assert perm == Permission.WRITE

    @pytest.mark.asyncio
    async def test_admin_user_gets_admin(self):
        registry = AsyncMock()
        registry.get_github_login_for_slack.return_value = "alice"
        registry.get_user_role.return_value = "admin"
        perm = await resolve_permission("U123", registry)
        assert perm == Permission.ADMIN

    @pytest.mark.asyncio
    async def test_none_registry_gets_read(self):
        perm = await resolve_permission("U123", None)
        assert perm == Permission.READ


class TestIdentityStorePermission:
    """Tests for IdentityStore-based permission resolution with collaborator check."""

    @pytest.mark.asyncio
    async def test_linked_user_with_write_access(self):
        from canon_slack.identity_store import IdentityStore

        store = AsyncMock(spec=IdentityStore)
        store.get_github_login.return_value = "alice"

        gh = AsyncMock()
        gh.get_collaborator_permission.return_value = "write"

        with (
            patch("canon.main._get_client", return_value=gh),
            patch("canon.main.settings") as mock_settings,
        ):
            mock_settings.github_owner = "org"
            mock_settings.github_repo = "repo"
            perm = await resolve_permission("U123", store)

        assert perm == Permission.WRITE

    @pytest.mark.asyncio
    async def test_linked_user_with_admin_access(self):
        from canon_slack.identity_store import IdentityStore

        store = AsyncMock(spec=IdentityStore)
        store.get_github_login.return_value = "alice"

        gh = AsyncMock()
        gh.get_collaborator_permission.return_value = "admin"

        with (
            patch("canon.main._get_client", return_value=gh),
            patch("canon.main.settings") as mock_settings,
        ):
            mock_settings.github_owner = "org"
            mock_settings.github_repo = "repo"
            perm = await resolve_permission("U123", store)

        assert perm == Permission.ADMIN

    @pytest.mark.asyncio
    async def test_linked_user_with_read_only_access(self):
        from canon_slack.identity_store import IdentityStore

        store = AsyncMock(spec=IdentityStore)
        store.get_github_login.return_value = "alice"

        gh = AsyncMock()
        gh.get_collaborator_permission.return_value = "read"

        with (
            patch("canon.main._get_client", return_value=gh),
            patch("canon.main.settings") as mock_settings,
        ):
            mock_settings.github_owner = "org"
            mock_settings.github_repo = "repo"
            perm = await resolve_permission("U123", store)

        assert perm == Permission.READ

    @pytest.mark.asyncio
    async def test_linked_user_collaborator_check_fails_returns_read(self):
        from canon_slack.identity_store import IdentityStore

        store = AsyncMock(spec=IdentityStore)
        store.get_github_login.return_value = "alice"

        with patch(
            "canon.main._get_client",
            side_effect=Exception("network error"),
        ):
            perm = await resolve_permission("U123", store)

        assert perm == Permission.READ

    @pytest.mark.asyncio
    async def test_unlinked_user_gets_read(self):
        from canon_slack.identity_store import IdentityStore

        store = AsyncMock(spec=IdentityStore)
        store.get_github_login.return_value = None

        perm = await resolve_permission("U123", store)
        assert perm == Permission.READ
