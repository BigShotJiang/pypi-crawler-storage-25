"""Helm template rendering helpers for chart tests.

Wraps ``helm template`` so tests can render manifests from values files and
assert on the resulting Kubernetes objects.
"""

from __future__ import annotations

import subprocess

import yaml


def helm_template(
    *values_files: str,
    set_values: dict[str, str] | None = None,
    chart_dir: str = "chart/canon",
) -> list[dict]:
    """Render Helm templates and return parsed manifest dicts.

    Parameters
    ----------
    *values_files:
        Paths to ``-f`` values files passed to ``helm template``.
    set_values:
        ``--set`` key=value pairs.
    chart_dir:
        Path to the Helm chart directory.

    Returns
    -------
    list[dict]
        Each entry is a parsed Kubernetes manifest from the rendered output.

    Raises
    ------
    subprocess.CalledProcessError
        If ``helm template`` exits with a non-zero status.
    """
    cmd: list[str] = ["helm", "template", "canon", chart_dir]

    for vf in values_files:
        cmd.extend(["-f", vf])

    if set_values:
        for key, value in set_values.items():
            cmd.extend(["--set", f"{key}={value}"])

    result = subprocess.run(cmd, capture_output=True, text=True, check=True)

    manifests: list[dict] = []
    for doc in yaml.safe_load_all(result.stdout):
        if doc is not None:
            manifests.append(doc)

    return manifests


def find_manifest(
    manifests: list[dict],
    *,
    kind: str,
    name: str = "",
) -> dict | None:
    """Find the first manifest matching *kind* and optional *name*.

    Parameters
    ----------
    manifests:
        List of parsed Kubernetes manifests.
    kind:
        The ``kind`` field to match (e.g. ``"Deployment"``).
    name:
        If non-empty, also match ``metadata.name``.

    Returns
    -------
    dict | None
        The first matching manifest, or ``None`` if no match is found.
    """
    for m in manifests:
        if m.get("kind") != kind:
            continue
        if name and m.get("metadata", {}).get("name") != name:
            continue
        return m
    return None


def find_all_manifests(manifests: list[dict], *, kind: str) -> list[dict]:
    """Return all manifests matching the given *kind*.

    Parameters
    ----------
    manifests:
        List of parsed Kubernetes manifests.
    kind:
        The ``kind`` field to match (e.g. ``"CronJob"``).

    Returns
    -------
    list[dict]
        All manifests with a matching ``kind``.
    """
    return [m for m in manifests if m.get("kind") == kind]
