"""Mock OIDC provider for integration testing.

Generates real RSA keys and JWTs so tests can exercise token verification
paths without hitting a live identity provider.
"""

from __future__ import annotations

import base64
import time

import jwt
from cryptography.hazmat.primitives.asymmetric import rsa


def _int_to_base64url(n: int) -> str:
    """Encode an integer as an unpadded Base64url string (RFC 7518)."""
    b = n.to_bytes((n.bit_length() + 7) // 8, byteorder="big")
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


class MockOIDCServer:
    """Simulates an OIDC provider for integration tests.

    Generates a 2048-bit RSA key pair at init time and uses it to produce
    signed JWTs and standard OIDC endpoint responses.
    """

    def __init__(self, issuer: str = "https://idp.test.example.com") -> None:
        self._issuer = issuer
        self._kid = "test-key-1"

        # Generate a 2048-bit RSA key pair
        self._private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        self._public_key = self._private_key.public_key()

    # -- OIDC discovery endpoints ------------------------------------------

    def discovery_document(self) -> dict:
        """Return a valid ``.well-known/openid-configuration`` document."""
        return {
            "issuer": self._issuer,
            "authorization_endpoint": f"{self._issuer}/authorize",
            "token_endpoint": f"{self._issuer}/oauth/token",
            "userinfo_endpoint": f"{self._issuer}/userinfo",
            "jwks_uri": f"{self._issuer}/.well-known/jwks.json",
            "end_session_endpoint": f"{self._issuer}/v2/logout",
            "device_authorization_endpoint": f"{self._issuer}/oauth/device/code",
            "response_types_supported": ["code", "token", "id_token"],
            "subject_types_supported": ["public"],
            "id_token_signing_alg_values_supported": ["RS256"],
            "scopes_supported": ["openid", "email", "profile"],
            "token_endpoint_auth_methods_supported": ["client_secret_basic", "client_secret_post"],
            "grant_types_supported": [
                "authorization_code",
                "refresh_token",
                "urn:ietf:params:oauth:grant-type:device_code",
            ],
        }

    def jwks(self) -> dict:
        """Return a JWKS dict containing the public key."""
        pub_numbers = self._public_key.public_numbers()
        return {
            "keys": [
                {
                    "kty": "RSA",
                    "kid": self._kid,
                    "use": "sig",
                    "alg": "RS256",
                    "n": _int_to_base64url(pub_numbers.n),
                    "e": _int_to_base64url(pub_numbers.e),
                },
            ],
        }

    # -- Token helpers -----------------------------------------------------

    def id_token(
        self,
        sub: str,
        email: str = "test@example.com",
        name: str = "Test User",
        **extra_claims: object,
    ) -> str:
        """Return a signed JWT id_token with standard OIDC claims."""
        now = int(time.time())
        payload: dict = {
            "iss": self._issuer,
            "sub": sub,
            "aud": self._issuer,
            "iat": now,
            "exp": now + 3600,  # 1 hour
            "email": email,
            "name": name,
            **extra_claims,
        }
        return jwt.encode(
            payload,
            self._private_key,
            algorithm="RS256",
            headers={"kid": self._kid},
        )

    def token_response(
        self,
        sub: str = "test-user-sub",
        email: str = "test@example.com",
        **extra: object,
    ) -> dict:
        """Return a full token endpoint response dict."""
        return {
            "access_token": f"access-token-for-{sub}",
            "id_token": self.id_token(sub, email=email, **extra),
            "refresh_token": f"refresh-token-for-{sub}",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

    # -- Device authorization helpers --------------------------------------

    def device_code_response(self) -> dict:
        """Return a device authorization endpoint response."""
        return {
            "device_code": "test-device-code",
            "user_code": "ABCD-1234",
            "verification_uri": f"{self._issuer}/activate",
            "verification_uri_complete": f"{self._issuer}/activate?user_code=ABCD-1234",
            "expires_in": 900,
            "interval": 5,
        }

    def authorization_pending_response(self) -> dict:
        """Return a 400-style ``authorization_pending`` error response."""
        return {
            "error": "authorization_pending",
            "error_description": "The user has not yet completed the authorization.",
        }
