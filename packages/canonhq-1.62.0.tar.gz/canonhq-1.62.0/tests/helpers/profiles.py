"""Deployment configuration profiles for testing.

Each profile represents a realistic Canon deployment configuration:

- **production** -- Auth0-backed cloud deployment with all features.
- **oss_oidc** -- Self-hosted with a generic OIDC identity provider.
- **oss_disabled** -- Self-hosted development mode with auth disabled.
- **dev** -- Auth0-backed but minimal (development environment).
"""

from __future__ import annotations

import pytest

from canon.settings import Settings

PROFILES: dict[str, Settings] = {
    "production": Settings(
        auth0_domain="test.auth0.com",
        auth0_client_id="test-cid",
        auth0_client_secret="test-csec",
        auth0_audience="https://api.canonhq.co",
        auth0_orgs_enabled=True,
        auth0_m2m_client_id="m2m-cid",
        auth0_m2m_client_secret="m2m-csec",
        database_url="postgresql://test:test@localhost:5432/canon_test",
        gh_app_id="12345",
        gh_private_key="test-key",
        gh_webhook_secret="test-secret",
        gh_installation_id="99999",
        environment="production",
    ),
    "oss_oidc": Settings(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="canon-app",
        oidc_client_secret="oidc-secret",
        oidc_audience="https://canon.example.com",
        gh_app_id="12345",
        gh_private_key="test-key",
        gh_webhook_secret="test-secret",
        gh_installation_id="99999",
        environment="production",
    ),
    "oss_disabled": Settings(
        gh_app_id="12345",
        gh_private_key="test-key",
        gh_webhook_secret="test-secret",
        gh_installation_id="99999",
        environment="development",
    ),
    "dev": Settings(
        auth0_domain="dev.auth0.com",
        auth0_client_id="dev-cid",
        auth0_client_secret="dev-csec",
        gh_app_id="12345",
        gh_private_key="test-key",
        gh_webhook_secret="test-secret",
        gh_installation_id="99999",
        environment="development",
    ),
}


@pytest.fixture(params=list(PROFILES.keys()))
def config_profile(request: pytest.FixtureRequest) -> Settings:
    """Settings instance matching a real deployment profile."""
    return PROFILES[request.param]
