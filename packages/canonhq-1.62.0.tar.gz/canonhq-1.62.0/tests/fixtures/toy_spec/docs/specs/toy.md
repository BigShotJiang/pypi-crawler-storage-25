---
title: "Toy Feature for E2E Test"
status: in_progress
owner: test
team: canon
created: 2026-04-11
updated: 2026-04-11
tags: [test, fixture]
---

# Toy Feature for E2E Test

A fixture spec used by the plugin workflow integration test. Two sections,
four acceptance criteria total. Do not edit unless you also update
`tests/test_plugin/test_implement_workflow_e2e.py`.

## 1. Greeter

<!-- canon:system:1 status:in_progress -->

The toy module provides a greeter function.

### Acceptance Criteria

- [ ] Greeter accepts a name argument and returns a greeting string
- [ ] Greeter returns "Hello, world" when name is empty

## 2. Echo

<!-- canon:system:2 status:in_progress -->

The toy module provides an echo function.

### Acceptance Criteria

- [ ] Echo returns the input string unchanged
- [ ] Echo raises TypeError when input is not a string
