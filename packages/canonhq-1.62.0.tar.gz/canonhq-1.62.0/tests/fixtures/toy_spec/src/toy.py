"""Toy module for the canon-implement workflow integration test.

The test starts with this stub and edits it to satisfy the acceptance
criteria in `docs/specs/toy.md`.
"""

# Stub: greeter and echo are unimplemented at the start of the test.
