"""Scenario: broken-config — intentionally invalid configurations.

Tests that Canon produces actionable error messages (not raw tracebacks)
when given various types of broken CANON.yaml files.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from tests.scenarios.conftest import run_canon

BROKEN_CONFIGS = [
    "missing-project",
    "invalid-yaml",
    "invalid-adapter",
    "empty",
]


@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["broken-config"], indirect=True)
class TestBrokenConfig:
    """Tests that broken configs produce actionable errors."""

    @pytest.mark.parametrize("config_name", BROKEN_CONFIGS)
    def test_doctor_fails_with_broken_config(self, scenario_repo: Path, config_name: str) -> None:
        """Doctor should fail (not crash) with each broken config."""
        config_src = scenario_repo / "configs" / f"{config_name}.yaml"
        config_dst = scenario_repo / "CANON.yaml"
        shutil.copy(config_src, config_dst)

        result = run_canon(scenario_repo, "doctor")
        assert result.returncode != 0, (
            f"Expected non-zero exit for {config_name}, got 0.\nstdout: {result.stdout[:300]}"
        )
        # Should not produce raw Python tracebacks
        assert "Traceback" not in result.stderr, (
            f"Raw traceback for {config_name}: {result.stderr[:500]}"
        )

    @pytest.mark.parametrize("config_name", BROKEN_CONFIGS)
    def test_no_traceback_on_lint(self, scenario_repo: Path, config_name: str) -> None:
        """Lint should not produce tracebacks with broken configs."""
        config_src = scenario_repo / "configs" / f"{config_name}.yaml"
        config_dst = scenario_repo / "CANON.yaml"
        shutil.copy(config_src, config_dst)

        result = run_canon(scenario_repo, "lint")
        # lint and status don't validate CANON.yaml — they may exit 0 with
        # "No spec files found". The key assertion is no crash/traceback.
        assert "Traceback" not in result.stderr, (
            f"Raw traceback for {config_name}: {result.stderr[:500]}"
        )

    @pytest.mark.parametrize("config_name", BROKEN_CONFIGS)
    def test_no_traceback_on_status(self, scenario_repo: Path, config_name: str) -> None:
        """Status should not produce tracebacks with broken configs."""
        config_src = scenario_repo / "configs" / f"{config_name}.yaml"
        config_dst = scenario_repo / "CANON.yaml"
        shutil.copy(config_src, config_dst)

        result = run_canon(scenario_repo, "status")
        assert "Traceback" not in result.stderr, (
            f"Raw traceback for {config_name}: {result.stderr[:500]}"
        )
