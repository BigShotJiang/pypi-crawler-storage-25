"""Scenario test infrastructure.

Provides fixtures and helpers for running Canon CLI commands against
isolated fixture repos with mock external services.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

SCENARIOS_DIR = Path(__file__).parent


@pytest.fixture(scope="session")
def mock_services() -> dict[str, str]:
    """URLs of Docker Compose mock services.

    These are set by scripts/run-scenario.sh. When running outside
    the script, fall back to default localhost ports.
    """
    return {
        "jira": os.environ.get("JIRA_BASE_URL", "http://localhost:18080"),
        "linear": os.environ.get("LINEAR_BASE_URL", "http://localhost:18081"),
        "github": os.environ.get("GITHUB_API_URL", "http://localhost:18082"),
    }


@pytest.fixture()
def scenario_repo(tmp_path: Path, request: pytest.FixtureRequest) -> Path:
    """Copy a scenario fixture into an isolated tmp dir with a real git repo.

    Usage::

        @pytest.mark.parametrize("scenario_repo", ["fresh-empty"], indirect=True)
        def test_something(scenario_repo):
            ...
    """
    name = request.param
    src = SCENARIOS_DIR / name / "fixture"
    dst = tmp_path / "repo"

    if src.exists():
        shutil.copytree(src, dst)
    else:
        dst.mkdir(parents=True)

    # Initialize a real git repo (some canon commands require it).
    # Configure a local git identity so commits work in CI (where no
    # global user.name / user.email is set).
    subprocess.run(["git", "init", "-b", "main"], cwd=dst, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"], cwd=dst, check=True, capture_output=True
    )
    subprocess.run(["git", "config", "user.name", "Test"], cwd=dst, check=True, capture_output=True)
    subprocess.run(["git", "add", "."], cwd=dst, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "init", "--allow-empty"],
        cwd=dst,
        check=True,
        capture_output=True,
    )
    return dst


def run_canon(
    repo_dir: Path,
    *args: str,
    env_override: dict[str, str] | None = None,
    timeout: int = 60,
) -> subprocess.CompletedProcess[str]:
    """Run canon CLI as a subprocess against a scenario repo.

    Returns the CompletedProcess with stdout/stderr captured as text.
    Does NOT raise on non-zero exit — callers should assert on returncode.
    """
    env = {**os.environ, **(env_override or {})}
    # Ensure canon doesn't try to use real auth or cloud services
    env.setdefault("CANON_LOCAL_MODE", "1")
    return subprocess.run(
        ["uv", "run", "canon", *args],
        cwd=repo_dir,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
    )
