"""Scenario: mature — 8 specs, Jira + Linear adapters, routing rules.

Tests that Canon handles a mature repo with multiple ticket systems,
tag-based routing, and a mix of spec statuses. No sync tests yet
(those need WireMock stubs).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.scenarios.conftest import run_canon


@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["mature"], indirect=True)
class TestMature:
    """Tests for a mature repo with multiple adapters and routing."""

    def test_doctor_passes(self, scenario_repo: Path) -> None:
        """Doctor should pass with valid multi-adapter config."""
        result = run_canon(scenario_repo, "doctor", "--json")
        data = json.loads(result.stdout)
        config_check = next(c for c in data if c["name"] == "CANON.yaml")
        assert config_check["status"] in ("pass", "warn")

    def test_lint_validates_all_specs(self, scenario_repo: Path) -> None:
        """Lint should find and validate all 8 spec files."""
        result = run_canon(scenario_repo, "lint")
        assert "Traceback" not in result.stderr

    def test_status_reports_coverage(self, scenario_repo: Path) -> None:
        """Status should report specs across multiple statuses."""
        result = run_canon(scenario_repo, "status")
        assert result.returncode in (0, 2)
        assert "Traceback" not in result.stderr
