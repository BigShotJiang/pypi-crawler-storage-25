---
title: "User Management"
status: done
owner: alice
team: platform
created: 2025-01-15
tags: [backend, api, auth]
---

# User Management

CRUD operations for user accounts.

## 1. User CRUD API

<!-- canon:system:1 status:done -->

REST endpoints for user lifecycle management.

### Acceptance Criteria

- [x] POST /api/users creates a new user
- [x] GET /api/users/:id returns user profile
- [x] PATCH /api/users/:id updates user fields
- [x] DELETE /api/users/:id soft-deletes the user

## 2. Role-Based Access Control

<!-- canon:system:2 status:done -->

Assign roles and enforce permissions.

### Acceptance Criteria

- [x] Roles: admin, member, viewer
- [x] Permission middleware enforces role checks
- [x] Role changes audited in activity log
