---
title: "Data Export"
status: todo
owner: dave
team: data
created: 2025-10-01
tags: [backend, data, compliance]
---

# Data Export

Bulk data export for compliance and analytics.

## 1. Export API

<!-- canon:system:1 status:todo -->

API endpoint for requesting bulk data exports.

### Acceptance Criteria

- [ ] POST /api/exports creates an export job
- [ ] Export formats: CSV, JSON, Parquet
- [ ] Notification when export is ready for download
