---
title: "Settings UI"
status: in_progress
owner: dave
team: frontend
created: 2025-05-01
tags: [frontend, ui, settings]
---

# Settings UI

User and organization settings pages.

## 1. User Profile Settings

<!-- canon:system:1 status:done -->

Edit personal profile information.

### Acceptance Criteria

- [x] Edit display name, avatar, and email
- [x] Change password with current password verification

## 2. Organization Settings

<!-- canon:system:2 status:todo -->

Manage organization-level configuration.

### Acceptance Criteria

- [ ] Edit organization name and logo
- [ ] Manage billing plan and payment method
- [ ] Configure SSO and security policies
