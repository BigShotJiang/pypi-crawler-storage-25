---
title: "Design System"
status: done
owner: bob
team: frontend
created: 2025-01-01
tags: [frontend, ui, design]
---

# Design System

Shared component library and design tokens.

## 1. Component Library

<!-- canon:system:1 status:done -->

Core UI components used across the application.

### Acceptance Criteria

- [x] Button, Input, Select, Modal components
- [x] Storybook documentation for all components
- [x] Accessibility (WCAG 2.1 AA) compliance
