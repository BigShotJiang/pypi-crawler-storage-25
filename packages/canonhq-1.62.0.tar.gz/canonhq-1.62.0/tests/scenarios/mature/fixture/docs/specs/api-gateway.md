---
title: "API Gateway"
status: done
owner: alice
team: platform
created: 2025-03-01
tags: [backend, api, infrastructure]
---

# API Gateway

Centralized API gateway with rate limiting and authentication.

## 1. Rate Limiting

<!-- canon:system:1 status:done -->

Token bucket rate limiting per API key.

### Acceptance Criteria

- [x] Configurable rate limits per plan tier
- [x] Rate limit headers in API responses
- [x] 429 response with retry-after header

## 2. API Key Management

<!-- canon:system:2 status:done -->

Create and rotate API keys.

### Acceptance Criteria

- [x] Generate API keys from dashboard
- [x] Key rotation without downtime
- [x] Revoke compromised keys immediately
