"""Scenario: fresh-empty — Canon on a brand new, empty repository.

Tests the experience of a user who has just initialized a git repo
and tries to use Canon for the first time, with no CANON.yaml and
no spec files.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.scenarios.conftest import run_canon


@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["fresh-empty"], indirect=True)
class TestFreshEmpty:
    """Tests for Canon behavior on a completely empty repository."""

    def test_doctor_fails_without_config(self, scenario_repo: Path) -> None:
        """canon doctor should fail and mention CANON.yaml is missing."""
        result = run_canon(scenario_repo, "doctor", "--json")
        assert result.returncode != 0, f"Expected non-zero exit, got stdout: {result.stdout}"

        data = json.loads(result.stdout)
        config_check = next((c for c in data if c["name"] == "CANON.yaml"), None)
        assert config_check is not None, "Expected CANON.yaml check in doctor output"
        assert config_check["status"] == "fail"
        assert "Not found" in config_check["message"]

    def test_doctor_error_suggests_fix(self, scenario_repo: Path) -> None:
        """Error message should suggest running canon setup."""
        result = run_canon(scenario_repo, "doctor", "--json")
        data = json.loads(result.stdout)
        config_check = next(c for c in data if c["name"] == "CANON.yaml")
        assert config_check["fix_hint"] is not None
        assert "setup" in config_check["fix_hint"].lower()

    def test_setup_creates_config(self, scenario_repo: Path) -> None:
        """canon setup --non-interactive should create a valid CANON.yaml."""
        result = run_canon(scenario_repo, "setup", "--non-interactive")
        assert result.returncode == 0, f"Setup failed: {result.stderr}"
        assert (scenario_repo / "CANON.yaml").exists()

    def test_setup_config_is_parseable(self, scenario_repo: Path) -> None:
        """The generated CANON.yaml should be valid YAML that canon can parse."""
        run_canon(scenario_repo, "setup", "--non-interactive")
        config_path = scenario_repo / "CANON.yaml"
        content = config_path.read_text()
        assert len(content) > 10, "CANON.yaml is too short to be valid"
        # Verify it parses as YAML
        import yaml

        parsed = yaml.safe_load(content)
        assert isinstance(parsed, dict), "CANON.yaml should parse to a dict"

    def test_doctor_passes_after_setup(self, scenario_repo: Path) -> None:
        """After setup, doctor should pass the CANON.yaml check."""
        run_canon(scenario_repo, "setup", "--non-interactive")
        result = run_canon(scenario_repo, "doctor", "--json")
        data = json.loads(result.stdout)
        config_check = next(c for c in data if c["name"] == "CANON.yaml")
        assert config_check["status"] in ("pass", "warn"), f"Expected pass, got: {config_check}"

    def test_lint_with_no_specs(self, scenario_repo: Path) -> None:
        """canon lint should handle having no spec files gracefully."""
        run_canon(scenario_repo, "setup", "--non-interactive")
        result = run_canon(scenario_repo, "lint")
        # Should not crash — may warn about no specs or exit 0
        assert result.returncode in (0, 2), (
            f"Unexpected exit code: {result.returncode}, stderr: {result.stderr}"
        )
        # Should not contain raw Python tracebacks
        assert "Traceback" not in result.stderr

    def test_status_with_no_specs(self, scenario_repo: Path) -> None:
        """canon status should work with no spec files."""
        run_canon(scenario_repo, "setup", "--non-interactive")
        result = run_canon(scenario_repo, "status", "--json")
        # Should not crash
        assert result.returncode in (0, 2), (
            f"Unexpected exit code: {result.returncode}, stderr: {result.stderr}"
        )
        assert "Traceback" not in result.stderr

    def test_no_raw_tracebacks_on_any_command(self, scenario_repo: Path) -> None:
        """No canon command should produce raw Python tracebacks on an empty repo."""
        commands = [
            ["doctor"],
            ["lint"],
            ["status"],
        ]
        for cmd in commands:
            result = run_canon(scenario_repo, *cmd)
            assert "Traceback" not in result.stderr, (
                f"Raw traceback in `canon {' '.join(cmd)}`: {result.stderr[:500]}"
            )
