"""Scenario: first-spec — one spec file, testing parse and lint flows.

Tests that Canon correctly handles a repo with its very first spec,
validating parsing, linting, and status reporting.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.scenarios.conftest import run_canon


@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["first-spec"], indirect=True)
class TestFirstSpec:
    """Tests for Canon with a single spec file."""

    def test_doctor_passes(self, scenario_repo: Path) -> None:
        """Doctor should pass with valid config and spec."""
        result = run_canon(scenario_repo, "doctor", "--json")
        data = json.loads(result.stdout)
        config_check = next(c for c in data if c["name"] == "CANON.yaml")
        assert config_check["status"] in ("pass", "warn")

    def test_lint_validates_spec(self, scenario_repo: Path) -> None:
        """Lint should find and validate the spec file without errors."""
        result = run_canon(scenario_repo, "lint")
        assert result.returncode in (0, 2), f"Lint failed: {result.stderr}"
        assert "Traceback" not in result.stderr
        # Should mention the spec file
        combined = result.stdout + result.stderr
        assert (
            "user-auth" in combined.lower()
            or "authentication" in combined.lower()
            or result.returncode == 0
        )

    def test_status_reports_spec(self, scenario_repo: Path) -> None:
        """Status should report one spec with sections."""
        result = run_canon(scenario_repo, "status", "--json")
        assert result.returncode in (0, 2), f"Status failed: {result.stderr}"
        assert "Traceback" not in result.stderr
        if result.stdout.strip():
            data = json.loads(result.stdout)
            assert isinstance(data, (dict, list))

    def test_lint_json_output(self, scenario_repo: Path) -> None:
        """Lint --json should produce parseable JSON."""
        result = run_canon(scenario_repo, "lint", "--json")
        assert "Traceback" not in result.stderr
        if result.stdout.strip():
            data = json.loads(result.stdout)
            assert isinstance(data, (dict, list))

    def test_spec_has_three_sections(self, scenario_repo: Path) -> None:
        """The fixture spec should be parseable with 3 sections."""
        result = run_canon(scenario_repo, "status", "--json")
        if result.stdout.strip():
            data = json.loads(result.stdout)
            # The exact structure depends on canon's JSON output format
            # At minimum, it should not error
            assert isinstance(data, (dict, list))
