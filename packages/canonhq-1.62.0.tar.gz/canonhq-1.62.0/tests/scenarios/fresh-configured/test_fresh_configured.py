"""Scenario: fresh-configured — CANON.yaml present but no specs yet.

Tests that Canon works correctly when the repo is configured but
has no spec files to process.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.scenarios.conftest import run_canon


@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["fresh-configured"], indirect=True)
class TestFreshConfigured:
    """Tests for Canon on a configured repo with no specs."""

    def test_doctor_passes(self, scenario_repo: Path) -> None:
        """canon doctor should pass with a valid CANON.yaml."""
        result = run_canon(scenario_repo, "doctor", "--json")
        data = json.loads(result.stdout)
        config_check = next(c for c in data if c["name"] == "CANON.yaml")
        assert config_check["status"] in ("pass", "warn"), f"Expected pass: {config_check}"

    def test_lint_no_specs_no_crash(self, scenario_repo: Path) -> None:
        """canon lint should handle zero specs gracefully."""
        result = run_canon(scenario_repo, "lint")
        assert result.returncode in (0, 2), f"Unexpected exit: {result.returncode}"
        assert "Traceback" not in result.stderr

    def test_status_reports_zero_specs(self, scenario_repo: Path) -> None:
        """canon status --json should return valid JSON with zero specs."""
        result = run_canon(scenario_repo, "status", "--json")
        assert result.returncode in (0, 2), f"Unexpected exit: {result.returncode}"
        assert "Traceback" not in result.stderr
        # If JSON is returned, validate structure
        if result.stdout.strip():
            data = json.loads(result.stdout)
            assert isinstance(data, (dict, list))

    def test_config_is_parseable(self, scenario_repo: Path) -> None:
        """The fixture CANON.yaml should be parseable by canon."""
        result = run_canon(scenario_repo, "doctor", "--json")
        data = json.loads(result.stdout)
        config_check = next(c for c in data if c["name"] == "CANON.yaml")
        assert config_check["status"] in ("pass", "warn"), f"Config should parse: {config_check}"
