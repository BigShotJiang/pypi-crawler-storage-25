---
title: "Example Feature"
status: draft
owner: contributor
---

# Example Feature

A simple feature spec for OSS testing.

## 1. Basic Functionality

<!-- canon:system:1 status:todo -->

### Acceptance Criteria

- [ ] Feature works as described
