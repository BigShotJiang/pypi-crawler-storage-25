"""Scenario: oss-mode — Canon without cloud features.

Tests that Canon core CLI commands work without Auth0, cloud
integrations, or ticket system configuration.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.scenarios.conftest import run_canon


@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["oss-mode"], indirect=True)
class TestOssMode:
    """Tests for Canon in OSS/local mode."""

    def test_doctor_passes_without_auth(self, scenario_repo: Path) -> None:
        """Doctor should pass without Auth0 or cloud config."""
        result = run_canon(scenario_repo, "doctor", "--json")
        data = json.loads(result.stdout)
        config_check = next(c for c in data if c["name"] == "CANON.yaml")
        assert config_check["status"] in ("pass", "warn")

    def test_lint_works(self, scenario_repo: Path) -> None:
        """Lint should work on the spec file."""
        result = run_canon(scenario_repo, "lint")
        assert "Traceback" not in result.stderr

    def test_status_works(self, scenario_repo: Path) -> None:
        """Status should work without cloud features."""
        result = run_canon(scenario_repo, "status")
        assert result.returncode in (0, 2)
        assert "Traceback" not in result.stderr

    def test_no_auth_errors(self, scenario_repo: Path) -> None:
        """No commands should produce auth-related errors."""
        for cmd in [["doctor"], ["lint"], ["status"]]:
            result = run_canon(scenario_repo, *cmd)
            assert "auth" not in result.stderr.lower() or result.returncode in (0, 2)
            assert "Traceback" not in result.stderr
