---
title: "Notification System"
status: in_progress
owner: dave
team: platform
created: 2025-09-01
tags: [notifications, backend, realtime]
---

# Notification System

Multi-channel notification delivery (email, in-app, Slack).

## 1. Email Notifications

<!-- canon:system:1 status:done -->

Transactional email delivery via SendGrid.

### Acceptance Criteria

- [x] Welcome email on signup
- [x] Password reset email with secure token
- [x] Email templates managed in version control

## 2. In-App Notifications

<!-- canon:system:2 status:todo -->

Real-time in-app notification feed.

### Acceptance Criteria

- [ ] Notification bell with unread count
- [ ] Real-time updates via WebSocket
- [ ] Mark as read / mark all as read
