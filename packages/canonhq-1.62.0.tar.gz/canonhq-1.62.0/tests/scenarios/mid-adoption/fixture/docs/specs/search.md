---
title: "Full-Text Search"
status: in_progress
owner: bob
team: platform
created: 2025-08-01
tags: [search, backend, api]
---

# Full-Text Search

Implement full-text search across all document types.

## 1. Search Index

<!-- canon:system:1 status:done -->

Build and maintain a search index for all documents.

### Acceptance Criteria

- [x] Documents indexed on create and update
- [x] Index supports full-text queries with stemming
- [x] Deleted documents removed from index

## 2. Search API

<!-- canon:system:2 status:in_progress -->

REST API endpoint for searching documents.

### Acceptance Criteria

- [x] GET /api/search accepts query parameter
- [ ] Results include relevance score and highlights
- [ ] Pagination with cursor-based navigation

## 3. Search UI

<!-- canon:system:3 status:todo -->

Frontend search interface with instant results.

### Acceptance Criteria

- [ ] Search bar with typeahead suggestions
- [ ] Results page with filters and facets
- [ ] Keyboard navigation for search results
