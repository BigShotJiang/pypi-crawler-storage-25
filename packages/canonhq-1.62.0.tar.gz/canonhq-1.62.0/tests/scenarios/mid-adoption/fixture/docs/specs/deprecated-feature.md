---
title: "Legacy Export API"
status: deprecated
owner: alice
team: platform
created: 2025-03-01
tags: [api, legacy]
---

# Legacy Export API

The v1 CSV export endpoint, replaced by the v2 bulk export system.

## 1. CSV Export Endpoint

<!-- canon:system:1 status:deprecated -->

The /api/v1/export/csv endpoint is deprecated and scheduled for removal.

### Notes

- Replaced by /api/v2/export with format parameter
- Existing integrations should migrate by Q2 2026
