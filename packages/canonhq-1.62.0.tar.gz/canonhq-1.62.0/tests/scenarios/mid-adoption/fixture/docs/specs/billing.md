---
title: "Billing System"
status: draft
owner: carol
team: payments
created: 2025-10-01
tags: [billing, payments, backend]
---

# Billing System

Stripe-based billing with subscription management.

## 1. Subscription Management

<!-- canon:system:1 status:todo -->

Create and manage customer subscriptions via Stripe.

### Acceptance Criteria

- [ ] Create subscription with plan selection
- [ ] Upgrade/downgrade between plans
- [ ] Cancel subscription with prorated refund

## 2. Invoice Generation

<!-- canon:system:2 status:todo -->

Generate and send invoices for billing events.

### Acceptance Criteria

- [ ] Invoices generated on subscription renewal
- [ ] PDF invoice downloadable from dashboard
- [ ] Invoice email sent to billing contact
