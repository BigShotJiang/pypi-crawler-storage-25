"""Scenario: mid-adoption — 5 specs, mixed statuses, Jira adapter.

Tests sync with existing tickets, status mapping, deduplication,
and audit accuracy. Requires WireMock Jira mock.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.scenarios.conftest import run_canon


@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["mid-adoption"], indirect=True)
class TestMidAdoption:
    """Tests for mid-adoption lifecycle stage."""

    def test_doctor_passes(self, scenario_repo: Path, mock_services: dict[str, str]) -> None:
        result = run_canon(
            scenario_repo,
            "doctor",
            env_override={"JIRA_BASE_URL": mock_services["jira"]},
        )
        # Config should be valid even if Jira connectivity fails
        assert "Traceback" not in result.stderr

    def test_lint_validates_all_specs(self, scenario_repo: Path) -> None:
        result = run_canon(scenario_repo, "lint")
        assert "Traceback" not in result.stderr

    def test_status_reports_coverage(self, scenario_repo: Path) -> None:
        result = run_canon(scenario_repo, "status")
        assert result.returncode in (0, 2)
        assert "Traceback" not in result.stderr
