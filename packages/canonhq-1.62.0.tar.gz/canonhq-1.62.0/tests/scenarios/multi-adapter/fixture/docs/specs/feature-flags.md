---
title: "Feature Flags"
status: in_progress
owner: alice
team: platform
created: 2025-07-01
tags: [backend, infrastructure]
---

# Feature Flags

Runtime feature flag system for gradual rollouts.

## 1. Flag Evaluation

<!-- canon:system:1 status:done -->

Evaluate feature flags at runtime with user targeting.

### Acceptance Criteria

- [x] Boolean and percentage-based flag evaluation
- [x] User segment targeting rules
- [x] Flag evaluation cached per request

## 2. Flag Management UI

<!-- canon:system:2 status:todo -->

Dashboard for creating and managing feature flags.

### Acceptance Criteria

- [ ] Create, edit, and archive flags
- [ ] View flag evaluation history
- [ ] Audit log for flag changes
