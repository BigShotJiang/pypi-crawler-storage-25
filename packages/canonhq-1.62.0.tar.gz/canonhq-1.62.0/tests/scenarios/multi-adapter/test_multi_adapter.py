"""Scenario: multi-adapter — GitHub + Jira ticket systems with routing.

Tests that Canon correctly parses multi-adapter configuration and
handles basic operations. No sync tests (those need WireMock stubs).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.scenarios.conftest import run_canon


@pytest.mark.scenario
@pytest.mark.parametrize("scenario_repo", ["multi-adapter"], indirect=True)
class TestMultiAdapter:
    """Tests for multi-adapter configuration."""

    def test_doctor_passes(self, scenario_repo: Path) -> None:
        """Doctor should pass with valid multi-adapter config."""
        result = run_canon(scenario_repo, "doctor", "--json")
        data = json.loads(result.stdout)
        config_check = next(c for c in data if c["name"] == "CANON.yaml")
        assert config_check["status"] in ("pass", "warn")

    def test_lint_validates_spec(self, scenario_repo: Path) -> None:
        """Lint should validate the spec file."""
        result = run_canon(scenario_repo, "lint")
        assert "Traceback" not in result.stderr

    def test_status_reports_coverage(self, scenario_repo: Path) -> None:
        """Status should report spec coverage."""
        result = run_canon(scenario_repo, "status")
        assert result.returncode in (0, 2)
        assert "Traceback" not in result.stderr
