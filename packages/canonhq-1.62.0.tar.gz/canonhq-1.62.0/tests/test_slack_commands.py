"""Tests for /canon slash command handlers."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from canon_slack.commands import (
    handle_canon_command,
    parse_command,
)
from canon_slack.spec_loader import SectionInfo, SpecInfo, SpecLoader


def _make_spec(
    title: str = "Auth Hardening",
    slug: str = "auth-hardening",
    status: str = "active",
    sections_done: int = 2,
    sections_total: int = 5,
    github_url: str = "https://github.com/org/repo/blob/main/docs/specs/auth-hardening.md",
    owner: str = "alice",
    team: str = "platform",
    updated: str = "2026-03-01",
    sections: list[SectionInfo] | None = None,
) -> SpecInfo:
    if sections is None:
        sections = [
            SectionInfo(id="1", title="Background", status="done", acs_done=2, acs_total=2),
            SectionInfo(
                id="2", title="Implementation", status="in_progress", acs_done=1, acs_total=3
            ),
            SectionInfo(id="3", title="Testing", status="todo", acs_done=0, acs_total=2),
        ]
    return SpecInfo(
        title=title,
        slug=slug,
        status=status,
        sections_done=sections_done,
        sections_total=sections_total,
        github_url=github_url,
        owner=owner,
        team=team,
        updated=updated,
        sections=sections,
    )


SAMPLE_SPECS = [
    _make_spec(),
    _make_spec(
        title="Billing Integration",
        slug="billing-integration",
        status="done",
        sections_done=3,
        sections_total=3,
        owner="bob",
        team="backend",
        updated="2026-02-15",
        sections=[
            SectionInfo(id="1", title="Setup", status="done", acs_done=2, acs_total=2),
            SectionInfo(id="2", title="Stripe", status="done", acs_done=3, acs_total=3),
            SectionInfo(id="3", title="Testing", status="done", acs_done=1, acs_total=1),
        ],
    ),
    _make_spec(
        title="Ticket Sync",
        slug="ticket-sync",
        status="draft",
        sections_done=0,
        sections_total=4,
        owner="charlie",
        team="platform",
        updated="2026-03-10",
        sections=[],
    ),
]


def _mock_loader(specs: list[SpecInfo] | None = None) -> SpecLoader:
    """Create a SpecLoader with pre-cached specs."""
    loader = SpecLoader(github_client=AsyncMock(), owner="org", repo="repo")
    loader._cache = specs if specs is not None else list(SAMPLE_SPECS)
    loader._cache_valid = True
    return loader


def _patch_load_specs(loader: SpecLoader):
    """Patch _load_specs to return a pre-built loader."""

    async def _fake_load_specs(respond):
        return loader, True

    return patch("canon_slack.commands._load_specs", side_effect=_fake_load_specs)


class TestParseCommand:
    def test_empty_text(self):
        sub, args = parse_command("")
        assert sub == "help"
        assert args == ""

    def test_help(self):
        sub, _args = parse_command("help")
        assert sub == "help"

    def test_status_with_spec(self):
        sub, args = parse_command("status auth-hardening")
        assert sub == "status"
        assert args == "auth-hardening"

    def test_list_with_flags(self):
        sub, args = parse_command("list --status active")
        assert sub == "list"
        assert args == "--status active"

    def test_unknown_command(self):
        sub, args = parse_command("foobar")
        assert sub == "foobar"
        assert args == ""


class TestHelpResponse:
    @pytest.mark.asyncio
    async def test_help_returns_command_list(self):
        from canon_slack.commands import help_handler

        ack = AsyncMock()
        respond = AsyncMock()
        await help_handler(ack, respond)
        ack.assert_called_once()
        respond.assert_called_once()
        blocks = respond.call_args[1]["blocks"]
        text = str(blocks)
        assert "status" in text
        assert "list" in text
        assert "search" in text
        assert "coverage" in text
        assert "dashboard" in text


class TestUnknownCommand:
    @pytest.mark.asyncio
    async def test_unknown_subcommand_returns_help(self):
        from canon_slack.commands import unknown_handler

        ack = AsyncMock()
        respond = AsyncMock()
        await unknown_handler(ack, respond, "foobar")
        ack.assert_called_once()
        respond.assert_called_once()
        call_kwargs = respond.call_args[1]
        assert call_kwargs.get("response_type") == "ephemeral"
        assert "foobar" in str(call_kwargs["blocks"]) or "foobar" in call_kwargs.get("text", "")


class TestHandleCanonCommand:
    @pytest.mark.asyncio
    async def test_dispatches_help_for_empty_text(self):
        ack = AsyncMock()
        respond = AsyncMock()
        command = {"text": ""}
        client = AsyncMock()

        await handle_canon_command(ack, command, respond, client)
        ack.assert_called_once()
        respond.assert_called_once()
        blocks = respond.call_args[1]["blocks"]
        text = str(blocks)
        assert "status" in text  # help lists commands

    @pytest.mark.asyncio
    async def test_dispatches_unknown_subcommand(self):
        ack = AsyncMock()
        respond = AsyncMock()
        command = {"text": "nonexistent"}
        client = AsyncMock()

        await handle_canon_command(ack, command, respond, client)
        ack.assert_called_once()
        respond.assert_called_once()
        assert "nonexistent" in str(respond.call_args)

    @pytest.mark.asyncio
    async def test_dispatches_status_subcommand(self):
        ack = AsyncMock()
        respond = AsyncMock()
        command = {"text": "status auth-hardening", "team_id": "T123"}
        client = AsyncMock()

        with patch("canon_slack.commands.status_handler", new_callable=AsyncMock) as mock_status:
            await handle_canon_command(ack, command, respond, client)
            mock_status.assert_called_once()


class TestStatusHandler:
    @pytest.mark.asyncio
    async def test_status_no_args_shows_usage(self):
        from canon_slack.commands import status_handler

        ack = AsyncMock()
        respond = AsyncMock()
        await status_handler(ack, respond, AsyncMock(), "", {})
        ack.assert_called_once()
        respond.assert_called_once()
        assert "Usage" in str(respond.call_args)

    @pytest.mark.asyncio
    async def test_status_found_spec(self):
        from canon_slack.commands import status_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await status_handler(ack, respond, AsyncMock(), "auth-hardening", {})

        ack.assert_called_once()
        respond.assert_called_once()
        kwargs = respond.call_args[1]
        assert kwargs["response_type"] == "ephemeral"
        text = str(kwargs["blocks"])
        assert "Auth Hardening" in text
        assert "active" in text
        # Check section breakdown present
        assert "Background" in text
        assert "Implementation" in text

    @pytest.mark.asyncio
    async def test_status_not_found_suggests(self):
        from canon_slack.commands import status_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await status_handler(ack, respond, AsyncMock(), "auth-harden", {})

        ack.assert_called_once()
        respond.assert_called_once()
        text = str(respond.call_args[1]["blocks"])
        assert "not found" in text
        assert "auth-hardening" in text  # suggestion

    @pytest.mark.asyncio
    async def test_status_not_found_no_suggestions(self):
        from canon_slack.commands import status_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await status_handler(ack, respond, AsyncMock(), "zzzzzzzzz", {})

        text = str(respond.call_args[1]["blocks"])
        assert "not found" in text
        assert "Did you mean" not in text


class TestListHandler:
    @pytest.mark.asyncio
    async def test_list_all(self):
        from canon_slack.commands import list_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await list_handler(ack, respond, AsyncMock(), "", {})

        ack.assert_called_once()
        respond.assert_called_once()
        kwargs = respond.call_args[1]
        assert kwargs["response_type"] == "ephemeral"
        text = str(kwargs["blocks"])
        assert "Auth Hardening" in text
        assert "Billing Integration" in text
        assert "Ticket Sync" in text

    @pytest.mark.asyncio
    async def test_list_filter_by_status(self):
        from canon_slack.commands import list_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await list_handler(ack, respond, AsyncMock(), "--status done", {})

        text = str(respond.call_args[1]["blocks"])
        assert "Billing Integration" in text
        assert "Auth Hardening" not in text

    @pytest.mark.asyncio
    async def test_list_no_results(self):
        from canon_slack.commands import list_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await list_handler(ack, respond, AsyncMock(), "--status blocked", {})

        text = str(respond.call_args[1]["blocks"])
        assert "No specs found" in text

    @pytest.mark.asyncio
    async def test_list_truncates_at_10(self):
        from canon_slack.commands import list_handler

        many_specs = [
            _make_spec(title=f"Spec {i}", slug=f"spec-{i}", sections=[]) for i in range(15)
        ]
        loader = _mock_loader(many_specs)
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await list_handler(ack, respond, AsyncMock(), "", {})

        text = str(respond.call_args[1]["blocks"])
        assert "Showing 10 of 15" in text


class TestSearchHandler:
    @pytest.mark.asyncio
    async def test_search_no_query_shows_usage(self):
        from canon_slack.commands import search_handler

        ack = AsyncMock()
        respond = AsyncMock()
        await search_handler(ack, respond, AsyncMock(), "", {})
        assert "Usage" in str(respond.call_args)

    @pytest.mark.asyncio
    async def test_search_finds_results(self):
        from canon_slack.commands import search_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await search_handler(ack, respond, AsyncMock(), "auth", {})

        text = str(respond.call_args[1]["blocks"])
        assert "Auth Hardening" in text
        assert "1 result" in text

    @pytest.mark.asyncio
    async def test_search_no_results(self):
        from canon_slack.commands import search_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await search_handler(ack, respond, AsyncMock(), "nonexistent", {})

        text = str(respond.call_args[1]["blocks"])
        assert "No specs matching" in text

    @pytest.mark.asyncio
    async def test_search_multiple_results(self):
        from canon_slack.commands import search_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            # "ing" matches "Auth Hardening", "Billing Integration"
            await search_handler(ack, respond, AsyncMock(), "ing", {})

        text = str(respond.call_args[1]["blocks"])
        assert "results" in text


class TestCoverageHandler:
    @pytest.mark.asyncio
    async def test_coverage_all(self):
        from canon_slack.commands import coverage_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await coverage_handler(ack, respond, AsyncMock(), "", {})

        kwargs = respond.call_args[1]
        assert kwargs["response_type"] == "ephemeral"
        text = str(kwargs["blocks"])
        assert "Spec Coverage" in text
        assert "Done" in text
        assert "In Progress" in text
        # Team breakdown
        assert "platform" in text
        assert "backend" in text

    @pytest.mark.asyncio
    async def test_coverage_by_team(self):
        from canon_slack.commands import coverage_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await coverage_handler(ack, respond, AsyncMock(), "--team platform", {})

        text = str(respond.call_args[1]["blocks"])
        assert "platform" in text
        # Should NOT show the team breakdown section (already filtered)


class TestDashboardHandler:
    @pytest.mark.asyncio
    async def test_dashboard_posts_in_channel(self):
        from canon_slack.commands import dashboard_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await dashboard_handler(ack, respond, AsyncMock(), "", {})

        kwargs = respond.call_args[1]
        assert kwargs["response_type"] == "in_channel"
        text = str(kwargs["blocks"])
        assert "Dashboard" in text


class TestReviewHandler:
    @pytest.mark.asyncio
    async def test_review_no_args_shows_usage(self):
        from canon_slack.commands import review_handler

        ack = AsyncMock()
        respond = AsyncMock()
        await review_handler(ack, respond, AsyncMock(), "", {})
        assert "Usage" in str(respond.call_args)

    @pytest.mark.asyncio
    async def test_review_found_spec(self):
        from canon_slack.commands import review_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()
        command = {"user_id": "U123"}

        with _patch_load_specs(loader):
            await review_handler(ack, respond, AsyncMock(), "auth-hardening", command)

        kwargs = respond.call_args[1]
        assert kwargs["response_type"] == "in_channel"
        text = str(kwargs["blocks"])
        assert "Auth Hardening" in text
        assert "U123" in text
        assert "approve_spec" in text
        assert "request_changes" in text
        # Button values should use slug (not title) to avoid URL injection
        actions_block = next(b for b in kwargs["blocks"] if b.get("type") == "actions")
        for btn in actions_block["elements"]:
            assert btn["value"] == "auth-hardening"
            assert "url" not in btn

    @pytest.mark.asyncio
    async def test_review_not_found(self):
        from canon_slack.commands import review_handler

        loader = _mock_loader()
        ack = AsyncMock()
        respond = AsyncMock()

        with _patch_load_specs(loader):
            await review_handler(ack, respond, AsyncMock(), "nonexistent", {})

        text = str(respond.call_args[1]["blocks"])
        assert "not found" in text


class TestLoadSpecsErrors:
    @pytest.mark.asyncio
    async def test_load_specs_missing_config(self):
        """_load_specs returns False when owner/repo not configured."""
        from canon_slack.commands import _load_specs

        respond = AsyncMock()
        with patch("canon_slack.commands._get_repo_settings", return_value=("", "")):
            _loader, ok = await _load_specs(respond)

        assert ok is False
        respond.assert_called_once()
        text = str(respond.call_args[1]["blocks"])
        assert "GITHUB_OWNER" in text

    @pytest.mark.asyncio
    async def test_load_specs_load_error(self):
        """_load_specs returns False when loader reports an error."""
        from canon_slack.commands import _load_specs

        respond = AsyncMock()
        mock_loader = _mock_loader()
        mock_loader._load_error = "ConnectionError: timeout"
        mock_loader.load = AsyncMock(return_value=[])  # Don't clear _load_error

        with (
            patch("canon_slack.commands._get_repo_settings", return_value=("org", "repo")),
            patch("canon_slack.commands._get_github_client", return_value=AsyncMock()),
            patch("canon_slack.commands._get_spec_loader", return_value=mock_loader),
        ):
            _loader, ok = await _load_specs(respond)

        assert ok is False
        text = str(respond.call_args[1]["blocks"])
        assert "Failed to load specs" in text
        assert "ConnectionError" in text

    @pytest.mark.asyncio
    async def test_handler_short_circuits_on_load_failure(self):
        """Handlers return early without extra respond calls when _load_specs fails."""
        from canon_slack.commands import status_handler

        ack = AsyncMock()
        respond = AsyncMock()

        async def _failing_load(r):
            await r(
                blocks=[{"type": "section", "text": {"type": "mrkdwn", "text": "error"}}],
                response_type="ephemeral",
            )
            return _mock_loader(), False

        with patch("canon_slack.commands._load_specs", side_effect=_failing_load):
            await status_handler(ack, respond, AsyncMock(), "some-spec", {})

        # respond called exactly once (by _load_specs), not again by handler
        respond.assert_called_once()


class TestDispatcherErrorHandling:
    @pytest.mark.asyncio
    async def test_unhandled_error_sends_user_feedback(self):
        """Dispatcher catches unhandled errors and responds to user."""
        ack = AsyncMock()
        respond = AsyncMock()
        command = {"text": "status some-spec"}
        client = AsyncMock()

        with patch(
            "canon_slack.commands.status_handler",
            new_callable=AsyncMock,
            side_effect=RuntimeError("unexpected"),
        ):
            await handle_canon_command(ack, command, respond, client)

        # The dispatcher's catch block should have called respond
        text = str(respond.call_args[1]["blocks"])
        assert "Something went wrong" in text
        assert "status" in text


class TestSpecLoaderSpecsProperty:
    def test_specs_property_returns_copy(self):
        loader = _mock_loader()
        result = loader.specs
        assert len(result) == len(SAMPLE_SPECS)
        # Verify it's a copy, not the internal list
        result.append(_make_spec(title="Extra", slug="extra", sections=[]))
        assert len(loader.specs) == len(SAMPLE_SPECS)


class TestLinkHandler:
    @pytest.mark.asyncio
    async def test_link_success(self):
        from canon_slack.commands import link_handler

        ack = AsyncMock()
        respond = AsyncMock()
        identity_store = AsyncMock()

        mock_resp = AsyncMock()
        mock_resp.status_code = 200

        with (
            patch("canon_slack.commands._get_identity_store", return_value=identity_store),
            patch("httpx.AsyncClient") as mock_http_cls,
        ):
            mock_http_cls.return_value.__aenter__ = AsyncMock(
                return_value=AsyncMock(get=AsyncMock(return_value=mock_resp))
            )
            mock_http_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            await link_handler(ack, respond, "alice", {"user_id": "U123"})

        ack.assert_called_once()
        identity_store.link.assert_called_once_with("U123", "alice")
        text = str(respond.call_args[1]["blocks"])
        assert "Linked" in text
        assert "alice" in text

    @pytest.mark.asyncio
    async def test_link_no_args_shows_usage(self):
        from canon_slack.commands import link_handler

        ack = AsyncMock()
        respond = AsyncMock()
        await link_handler(ack, respond, "", {"user_id": "U123"})
        ack.assert_called_once()
        text = str(respond.call_args[1]["blocks"])
        assert "Usage" in text

    @pytest.mark.asyncio
    async def test_link_no_identity_store(self):
        from canon_slack.commands import link_handler

        ack = AsyncMock()
        respond = AsyncMock()

        with patch("canon_slack.commands._get_identity_store", return_value=None):
            await link_handler(ack, respond, "alice", {"user_id": "U123"})

        text = str(respond.call_args[1]["blocks"])
        assert "not available" in text

    @pytest.mark.asyncio
    async def test_link_github_user_not_found(self):
        from canon_slack.commands import link_handler

        ack = AsyncMock()
        respond = AsyncMock()
        identity_store = AsyncMock()

        mock_resp = AsyncMock()
        mock_resp.status_code = 404

        with (
            patch("canon_slack.commands._get_identity_store", return_value=identity_store),
            patch("httpx.AsyncClient") as mock_http_cls,
        ):
            mock_http_cls.return_value.__aenter__ = AsyncMock(
                return_value=AsyncMock(get=AsyncMock(return_value=mock_resp))
            )
            mock_http_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            await link_handler(ack, respond, "nonexistent-user-xyz", {"user_id": "U123"})

        identity_store.link.assert_not_called()
        text = str(respond.call_args[1]["blocks"])
        assert "not found" in text

    @pytest.mark.asyncio
    async def test_link_github_api_error_fails_closed(self):
        from canon_slack.commands import link_handler

        ack = AsyncMock()
        respond = AsyncMock()
        identity_store = AsyncMock()

        with (
            patch("canon_slack.commands._get_identity_store", return_value=identity_store),
            patch("httpx.AsyncClient") as mock_http_cls,
        ):
            mock_http_cls.return_value.__aenter__ = AsyncMock(
                return_value=AsyncMock(get=AsyncMock(side_effect=Exception("network error")))
            )
            mock_http_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            await link_handler(ack, respond, "alice", {"user_id": "U123"})

        # Should NOT link — fails closed
        identity_store.link.assert_not_called()
        text = str(respond.call_args[1]["blocks"])
        assert "Could not verify" in text


class TestUnlinkHandler:
    @pytest.mark.asyncio
    async def test_unlink_success(self):
        from canon_slack.commands import unlink_handler

        ack = AsyncMock()
        respond = AsyncMock()
        identity_store = AsyncMock()
        identity_store.unlink = AsyncMock(return_value=True)

        with patch("canon_slack.commands._get_identity_store", return_value=identity_store):
            await unlink_handler(ack, respond, {"user_id": "U123"})

        ack.assert_called_once()
        identity_store.unlink.assert_called_once_with("U123")
        text = str(respond.call_args[1]["blocks"])
        assert "Unlinked" in text

    @pytest.mark.asyncio
    async def test_unlink_no_existing_link(self):
        from canon_slack.commands import unlink_handler

        ack = AsyncMock()
        respond = AsyncMock()
        identity_store = AsyncMock()
        identity_store.unlink = AsyncMock(return_value=False)

        with patch("canon_slack.commands._get_identity_store", return_value=identity_store):
            await unlink_handler(ack, respond, {"user_id": "U123"})

        text = str(respond.call_args[1]["blocks"])
        assert "No GitHub account" in text

    @pytest.mark.asyncio
    async def test_unlink_no_identity_store(self):
        from canon_slack.commands import unlink_handler

        ack = AsyncMock()
        respond = AsyncMock()

        with patch("canon_slack.commands._get_identity_store", return_value=None):
            await unlink_handler(ack, respond, {"user_id": "U123"})

        text = str(respond.call_args[1]["blocks"])
        assert "not available" in text
