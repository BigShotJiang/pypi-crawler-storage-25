"""Tests for @canon mention and DM handlers."""

from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from canon_slack.mentions import (
    RateLimiter,
    _load_spec_context,
    _try_intent_shortcut,
    extract_query,
    handle_dm,
    handle_mention,
)


class TestRateLimiter:
    def test_allows_under_limit(self):
        limiter = RateLimiter(max_per_minute=10)
        for _ in range(10):
            assert limiter.check("U123") is True

    def test_blocks_over_limit(self):
        limiter = RateLimiter(max_per_minute=2)
        assert limiter.check("U123") is True
        assert limiter.check("U123") is True
        assert limiter.check("U123") is False

    def test_different_users_independent(self):
        limiter = RateLimiter(max_per_minute=1)
        assert limiter.check("U1") is True
        assert limiter.check("U2") is True
        assert limiter.check("U1") is False

    def test_resets_after_window(self):
        limiter = RateLimiter(max_per_minute=1)
        assert limiter.check("U1") is True
        assert limiter.check("U1") is False
        # Manually expire
        limiter._windows["U1"] = [time.monotonic() - 120]
        assert limiter.check("U1") is True


class TestExtractQuery:
    def test_strips_mention(self):
        assert extract_query("<@U123BOT> what is auth status?") == "what is auth status?"

    def test_no_mention(self):
        assert extract_query("what is auth status?") == "what is auth status?"


class TestHandleMention:
    @pytest.mark.asyncio
    async def test_adds_processing_reaction(self):
        event = {
            "text": "<@U123> what is auth status?",
            "user": "U456",
            "channel": "C789",
            "ts": "1234567890.123",
        }
        say = AsyncMock()
        client = AsyncMock()
        client.reactions_add = AsyncMock()
        client.reactions_remove = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True, "ts": "111.222"})
        client.chat_update = AsyncMock()

        with (
            patch("canon_slack.mentions._process_nl_query", new_callable=AsyncMock) as mock_process,
            patch(
                "canon_slack.mentions._try_intent_shortcut",
                new_callable=AsyncMock,
                return_value=None,
            ),
        ):
            mock_process.return_value = "Auth hardening is 60% complete."
            await handle_mention(event, say, client)

        client.reactions_add.assert_any_call(
            channel="C789", timestamp="1234567890.123", name="eyes"
        )

    @pytest.mark.asyncio
    async def test_responds_via_deferred_update(self):
        """NL queries use chat_postMessage + chat_update pattern."""
        event = {
            "text": "<@U123> status?",
            "user": "U456",
            "channel": "C789",
            "ts": "1234567890.123",
        }
        say = AsyncMock()
        client = AsyncMock()
        client.reactions_add = AsyncMock()
        client.reactions_remove = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True, "ts": "111.222"})
        client.chat_update = AsyncMock()

        with (
            patch("canon_slack.mentions._process_nl_query", new_callable=AsyncMock) as mock_process,
            patch(
                "canon_slack.mentions._try_intent_shortcut",
                new_callable=AsyncMock,
                return_value=None,
            ),
        ):
            mock_process.return_value = "Here's the status..."
            await handle_mention(event, say, client)

        # Response is sent via chat_update on the thinking message
        client.chat_update.assert_called_once_with(
            channel="C789",
            ts="111.222",
            text="Here's the status...",
        )

    @pytest.mark.asyncio
    async def test_rate_limited_user_gets_error(self):
        event = {
            "text": "<@U123> query",
            "user": "U456",
            "channel": "C789",
            "ts": "123.456",
        }
        say = AsyncMock()
        client = AsyncMock()
        client.reactions_add = AsyncMock()

        with patch("canon_slack.mentions._rate_limiter") as mock_limiter:
            mock_limiter.check.return_value = False
            await handle_mention(event, say, client)

        say.assert_called_once()
        assert "rate limit" in say.call_args[1]["text"].lower()

    @pytest.mark.asyncio
    async def test_dm_ignores_non_im_channels(self):
        event = {
            "text": "hello",
            "user": "U456",
            "channel": "C789",
            "ts": "123.456",
            "channel_type": "channel",
        }
        say = AsyncMock()
        client = AsyncMock()

        await handle_dm(event, say, client)
        say.assert_not_called()

    @pytest.mark.asyncio
    async def test_dm_handles_im_channel(self):
        event = {
            "text": "what is auth status?",
            "user": "U456",
            "channel": "D789",
            "ts": "123.456",
            "channel_type": "im",
        }
        say = AsyncMock()
        client = AsyncMock()
        client.reactions_add = AsyncMock()
        client.reactions_remove = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True, "ts": "111.222"})
        client.chat_update = AsyncMock()

        with (
            patch("canon_slack.mentions._process_nl_query", new_callable=AsyncMock) as mock_process,
            patch(
                "canon_slack.mentions._try_intent_shortcut",
                new_callable=AsyncMock,
                return_value=None,
            ),
        ):
            mock_process.return_value = "Here's the answer."
            await handle_dm(event, say, client)

        client.chat_update.assert_called_once()

    @pytest.mark.asyncio
    async def test_empty_query_prompts_user(self):
        event = {
            "text": "<@U123>",
            "user": "U456",
            "channel": "C789",
            "ts": "123.456",
        }
        say = AsyncMock()
        client = AsyncMock()

        await handle_mention(event, say, client)
        say.assert_called_once()
        assert "question" in say.call_args[1]["text"].lower()

    @pytest.mark.asyncio
    async def test_intent_shortcut_skips_nl_query(self):
        """When intent shortcut matches, skip Claude and respond directly."""
        event = {
            "text": "<@U123> status of auth-hardening",
            "user": "U456",
            "channel": "C789",
            "ts": "123.456",
        }
        say = AsyncMock()
        client = AsyncMock()
        client.reactions_add = AsyncMock()

        with patch(
            "canon_slack.mentions._try_intent_shortcut",
            new_callable=AsyncMock,
            return_value="*Auth Hardening* \u2014 in_progress\nProgress: 3/5 sections done (60%)",
        ):
            await handle_mention(event, say, client)

        # Should use say (direct), not the deferred chat_postMessage path
        say.assert_called_once()
        assert "Auth Hardening" in say.call_args[1]["text"]
        # Should get a zap reaction, not eyes
        client.reactions_add.assert_called_with(channel="C789", timestamp="123.456", name="zap")


class TestIntentShortcut:
    @pytest.mark.asyncio
    async def test_returns_none_for_unrecognized_query(self):
        result = await _try_intent_shortcut("tell me about best practices")
        assert result is None

    @pytest.mark.asyncio
    async def test_status_pattern_with_loaded_spec(self):
        from canon_slack.spec_loader import SpecInfo

        mock_spec = SpecInfo(
            title="Auth Hardening",
            slug="auth-hardening",
            status="in_progress",
            sections_done=3,
            sections_total=5,
            github_url="https://github.com/org/repo/blob/main/docs/specs/auth-hardening.md",
        )
        mock_loader = AsyncMock()
        mock_loader.load = AsyncMock()
        mock_loader.get_by_slug = lambda slug: mock_spec if slug == "auth-hardening" else None

        with (
            patch("canon_slack.commands._get_repo_settings", return_value=("org", "repo")),
            patch("canon_slack.commands._get_github_client", return_value=object()),
            patch("canon_slack.commands._get_spec_loader", return_value=mock_loader),
        ):
            result = await _try_intent_shortcut("status of auth-hardening")

        assert result is not None
        assert "Auth Hardening" in result
        assert "in_progress" in result
        assert "60%" in result


class TestLoadSpecContext:
    @pytest.mark.asyncio
    async def test_returns_spec_summaries(self):
        from canon_slack.spec_loader import SectionInfo, SpecInfo

        mock_loader = MagicMock()
        mock_loader.load = AsyncMock()
        specs = [
            SpecInfo(
                title="Auth Hardening",
                slug="auth-hardening",
                status="in_progress",
                sections_done=2,
                sections_total=5,
                github_url="https://github.com/test/repo",
                owner="alice",
                team="platform",
                sections=[
                    SectionInfo(id="1", title="Login", status="done", acs_done=3, acs_total=3),
                    SectionInfo(
                        id="2", title="OAuth", status="in_progress", acs_done=1, acs_total=4
                    ),
                ],
            ),
        ]
        mock_loader.search.return_value = specs

        with (
            patch("canon_slack.commands._get_repo_settings", return_value=("test", "repo")),
            patch("canon_slack.commands._get_github_client", return_value=MagicMock()),
            patch("canon_slack.commands._get_spec_loader", return_value=mock_loader),
        ):
            result = await _load_spec_context("auth")

        assert "Auth Hardening" in result
        assert "in_progress" in result
        assert "Login" in result
        assert "OAuth" in result

    @pytest.mark.asyncio
    async def test_returns_empty_on_missing_config(self):
        with patch("canon_slack.commands._get_repo_settings", return_value=("", "")):
            result = await _load_spec_context("test")

        assert result == ""

    @pytest.mark.asyncio
    async def test_returns_empty_on_error(self):
        with patch("canon_slack.commands._get_repo_settings", side_effect=Exception("no settings")):
            result = await _load_spec_context("test")

        assert result == ""
