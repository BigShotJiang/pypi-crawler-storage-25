"""Tests for billing Pydantic models."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

from canon.billing.models import (
    AI_OP_OVERAGE_CENTS,
    AI_OPS_PER_SEAT,
    MIN_SEATS,
    STARTER_MAX_REPOS,
    AiOpUsage,
    AnthropicKeyRequest,
    AnthropicKeyStatus,
    BillingCycle,
    CheckoutRequest,
    EnterpriseContactRequest,
    Plan,
    Subscription,
    SubscriptionStatus,
)


class TestPlanEnum:
    def test_values(self):
        assert Plan.STARTER == "starter"
        assert Plan.PRO == "pro"
        assert Plan.ENTERPRISE == "enterprise"

    def test_from_string(self):
        assert Plan("starter") == Plan.STARTER
        assert Plan("pro") == Plan.PRO
        assert Plan("enterprise") == Plan.ENTERPRISE

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            Plan("invalid")


class TestBillingCycleEnum:
    def test_values(self):
        assert BillingCycle.MONTHLY == "monthly"
        assert BillingCycle.ANNUAL == "annual"


class TestSubscriptionStatusEnum:
    def test_values(self):
        assert SubscriptionStatus.ACTIVE == "active"
        assert SubscriptionStatus.PAST_DUE == "past_due"
        assert SubscriptionStatus.CANCELED == "canceled"
        assert SubscriptionStatus.TRIALING == "trialing"


class TestSubscription:
    def test_minimal_construction(self):
        sub = Subscription(
            id="1",
            org_login="test-org",
            stripe_customer_id="cus_123",
            plan=Plan.PRO,
            billing_cycle=BillingCycle.MONTHLY,
        )
        assert sub.id == "1"
        assert sub.org_login == "test-org"
        assert sub.stripe_subscription_id is None
        assert sub.status == SubscriptionStatus.ACTIVE
        assert sub.seat_count == MIN_SEATS

    def test_seat_count_enforces_minimum(self):
        with pytest.raises(ValidationError):
            Subscription(
                id="1",
                org_login="org",
                stripe_customer_id="cus_1",
                plan=Plan.STARTER,
                billing_cycle=BillingCycle.MONTHLY,
                seat_count=2,
            )

    def test_seat_count_at_minimum(self):
        sub = Subscription(
            id="1",
            org_login="org",
            stripe_customer_id="cus_1",
            plan=Plan.STARTER,
            billing_cycle=BillingCycle.MONTHLY,
            seat_count=MIN_SEATS,
        )
        assert sub.seat_count == MIN_SEATS

    def test_seat_count_above_minimum(self):
        sub = Subscription(
            id="1",
            org_login="org",
            stripe_customer_id="cus_1",
            plan=Plan.PRO,
            billing_cycle=BillingCycle.MONTHLY,
            seat_count=20,
        )
        assert sub.seat_count == 20

    def test_ai_ops_included_pro(self):
        sub = Subscription(
            id="1",
            org_login="org",
            stripe_customer_id="cus_1",
            plan=Plan.PRO,
            billing_cycle=BillingCycle.MONTHLY,
            seat_count=5,
        )
        assert sub.ai_ops_included == 5 * AI_OPS_PER_SEAT

    def test_ai_ops_included_starter_is_zero(self):
        sub = Subscription(
            id="1",
            org_login="org",
            stripe_customer_id="cus_1",
            plan=Plan.STARTER,
            billing_cycle=BillingCycle.MONTHLY,
        )
        assert sub.ai_ops_included == 0

    def test_max_repos_starter(self):
        sub = Subscription(
            id="1",
            org_login="org",
            stripe_customer_id="cus_1",
            plan=Plan.STARTER,
            billing_cycle=BillingCycle.MONTHLY,
        )
        assert sub.max_repos == STARTER_MAX_REPOS

    def test_max_repos_pro_unlimited(self):
        sub = Subscription(
            id="1",
            org_login="org",
            stripe_customer_id="cus_1",
            plan=Plan.PRO,
            billing_cycle=BillingCycle.MONTHLY,
        )
        assert sub.max_repos is None

    def test_is_trialing(self):
        sub = Subscription(
            id="1",
            org_login="org",
            stripe_customer_id="cus_1",
            plan=Plan.PRO,
            billing_cycle=BillingCycle.MONTHLY,
            status=SubscriptionStatus.TRIALING,
        )
        assert sub.is_trialing is True

    def test_is_not_trialing(self):
        sub = Subscription(
            id="1",
            org_login="org",
            stripe_customer_id="cus_1",
            plan=Plan.PRO,
            billing_cycle=BillingCycle.MONTHLY,
            status=SubscriptionStatus.ACTIVE,
        )
        assert sub.is_trialing is False

    def test_full_construction_with_dates(self):
        now = datetime.now(UTC)
        sub = Subscription(
            id="uuid-1",
            org_login="acme",
            stripe_customer_id="cus_abc",
            stripe_subscription_id="sub_xyz",
            plan=Plan.ENTERPRISE,
            billing_cycle=BillingCycle.ANNUAL,
            status=SubscriptionStatus.TRIALING,
            seat_count=50,
            current_period_start=now,
            current_period_end=now,
            trial_start=now,
            trial_end=now,
            created_at=now,
            updated_at=now,
        )
        assert sub.stripe_subscription_id == "sub_xyz"
        assert sub.status == SubscriptionStatus.TRIALING
        assert sub.seat_count == 50


class TestCheckoutRequest:
    def test_valid_starter_monthly(self):
        req = CheckoutRequest(
            plan=Plan.STARTER,
            billing_cycle=BillingCycle.MONTHLY,
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )
        assert req.plan == Plan.STARTER
        assert req.billing_cycle == BillingCycle.MONTHLY
        assert req.seat_count == MIN_SEATS

    def test_valid_pro_annual(self):
        req = CheckoutRequest(
            plan=Plan.PRO,
            billing_cycle=BillingCycle.ANNUAL,
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )
        assert req.plan == Plan.PRO

    def test_default_billing_cycle_is_monthly(self):
        req = CheckoutRequest(
            plan=Plan.STARTER,
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )
        assert req.billing_cycle == BillingCycle.MONTHLY

    def test_custom_seat_count(self):
        req = CheckoutRequest(
            plan=Plan.PRO,
            seat_count=10,
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )
        assert req.seat_count == 10

    def test_seat_count_below_minimum_rejected(self):
        with pytest.raises(ValidationError):
            CheckoutRequest(
                plan=Plan.STARTER,
                seat_count=2,
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    def test_enterprise_plan_rejected(self):
        with pytest.raises(ValidationError, match="Enterprise plan requires contacting sales"):
            CheckoutRequest(
                plan=Plan.ENTERPRISE,
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    def test_missing_success_url_rejected(self):
        with pytest.raises(ValidationError):
            CheckoutRequest(
                plan=Plan.STARTER,
                cancel_url="https://example.com/cancel",
            )

    def test_missing_cancel_url_rejected(self):
        with pytest.raises(ValidationError):
            CheckoutRequest(
                plan=Plan.STARTER,
                success_url="https://example.com/success",
            )


class TestEnterpriseContactRequest:
    def test_valid_contact(self):
        req = EnterpriseContactRequest(
            name="Jane Doe",
            email="jane@acme.com",
            company="Acme Inc",
            team_size="51-200",
        )
        assert req.name == "Jane Doe"
        assert req.message == ""
        assert req.honeypot == ""

    def test_with_message(self):
        req = EnterpriseContactRequest(
            name="Jane",
            email="jane@acme.com",
            company="Acme",
            team_size="200+",
            message="We need custom features",
        )
        assert req.message == "We need custom features"

    def test_empty_name_rejected(self):
        with pytest.raises(ValidationError):
            EnterpriseContactRequest(
                name="",
                email="jane@acme.com",
                company="Acme",
                team_size="1-10",
            )

    def test_empty_company_rejected(self):
        with pytest.raises(ValidationError):
            EnterpriseContactRequest(
                name="Jane",
                email="jane@acme.com",
                company="",
                team_size="1-10",
            )

    def test_invalid_team_size_rejected(self):
        with pytest.raises(ValidationError):
            EnterpriseContactRequest(
                name="Jane",
                email="jane@acme.com",
                company="Acme",
                team_size="500+",
            )

    def test_valid_team_sizes(self):
        for size in ["1-10", "11-50", "51-200", "200+"]:
            req = EnterpriseContactRequest(
                name="Jane",
                email="jane@acme.com",
                company="Acme",
                team_size=size,
            )
            assert req.team_size == size


class TestAnthropicKeyRequest:
    def test_valid_key(self):
        req = AnthropicKeyRequest(api_key="sk-ant-api03-1234567890")
        assert req.api_key == "sk-ant-api03-1234567890"

    def test_too_short_rejected(self):
        with pytest.raises(ValidationError):
            AnthropicKeyRequest(api_key="short")

    def test_exactly_10_chars_accepted(self):
        req = AnthropicKeyRequest(api_key="1234567890")
        assert len(req.api_key) == 10

    def test_9_chars_rejected(self):
        with pytest.raises(ValidationError):
            AnthropicKeyRequest(api_key="123456789")


class TestAnthropicKeyStatus:
    def test_no_key(self):
        status = AnthropicKeyStatus(exists=False)
        assert not status.exists
        assert status.suffix == ""
        assert status.status == "none"
        assert status.last_validated_at is None

    def test_with_key(self):
        now = datetime.now(UTC)
        status = AnthropicKeyStatus(
            exists=True,
            suffix="7890",
            status="active",
            last_validated_at=now,
        )
        assert status.exists
        assert status.suffix == "7890"
        assert status.status == "active"


class TestAiOpUsage:
    def test_ops_remaining(self):
        now = datetime.now(UTC)
        usage = AiOpUsage(
            org_login="org",
            period_start=now,
            period_end=now,
            ops_used=100,
            ops_included=500,
        )
        assert usage.ops_remaining == 400

    def test_ops_remaining_at_limit(self):
        now = datetime.now(UTC)
        usage = AiOpUsage(
            org_login="org",
            period_start=now,
            period_end=now,
            ops_used=500,
            ops_included=500,
        )
        assert usage.ops_remaining == 0

    def test_overage_ops(self):
        now = datetime.now(UTC)
        usage = AiOpUsage(
            org_login="org",
            period_start=now,
            period_end=now,
            ops_used=600,
            ops_included=500,
        )
        assert usage.overage_ops == 100
        assert usage.overage_cost_cents == 100 * AI_OP_OVERAGE_CENTS

    def test_no_overage(self):
        now = datetime.now(UTC)
        usage = AiOpUsage(
            org_login="org",
            period_start=now,
            period_end=now,
            ops_used=200,
            ops_included=500,
        )
        assert usage.overage_ops == 0
        assert usage.overage_cost_cents == 0
