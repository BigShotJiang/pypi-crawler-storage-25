"""Tests for StripeClient wrapper."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from canon.billing.stripe_client import StripeClient
from canon.settings import Settings


def _make_settings(**overrides) -> Settings:
    defaults = {
        "stripe_secret_key": "sk_test_xxx",
        "stripe_publishable_key": "pk_test_xxx",
        "stripe_webhook_secret": "whsec_test",
        "stripe_starter_monthly_price_id": "price_starter_m",
        "stripe_starter_annual_price_id": "price_starter_a",
        "stripe_pro_monthly_price_id": "price_pro_m",
        "stripe_pro_annual_price_id": "price_pro_a",
    }
    defaults.update(overrides)
    return Settings(**defaults)


class TestStripeClientInit:
    def test_valid_init(self):
        settings = _make_settings()
        client = StripeClient(settings)
        assert client is not None

    def test_missing_secret_key_raises(self):
        settings = _make_settings(stripe_secret_key="")
        with pytest.raises(ValueError, match="stripe_secret_key is required"):
            StripeClient(settings)


class TestGetPriceId:
    def test_starter_monthly(self):
        client = StripeClient(_make_settings())
        assert client.get_price_id("starter", "monthly") == "price_starter_m"

    def test_starter_annual(self):
        client = StripeClient(_make_settings())
        assert client.get_price_id("starter", "annual") == "price_starter_a"

    def test_pro_monthly(self):
        client = StripeClient(_make_settings())
        assert client.get_price_id("pro", "monthly") == "price_pro_m"

    def test_pro_annual(self):
        client = StripeClient(_make_settings())
        assert client.get_price_id("pro", "annual") == "price_pro_a"

    def test_enterprise_monthly_raises(self):
        client = StripeClient(_make_settings())
        with pytest.raises(ValueError, match="No Stripe Price configured"):
            client.get_price_id("enterprise", "monthly")

    def test_unknown_plan_raises(self):
        client = StripeClient(_make_settings())
        with pytest.raises(ValueError, match="No Stripe Price configured"):
            client.get_price_id("unknown", "monthly")

    def test_unknown_cycle_raises(self):
        client = StripeClient(_make_settings())
        with pytest.raises(ValueError, match="No Stripe Price configured"):
            client.get_price_id("starter", "weekly")

    def test_empty_price_id_raises(self):
        """When a price ID setting is empty string, it should raise."""
        settings = _make_settings(stripe_starter_monthly_price_id="")
        client = StripeClient(settings)
        with pytest.raises(ValueError, match="No Stripe Price configured"):
            client.get_price_id("starter", "monthly")


class TestCreateCheckoutSession:
    @patch("stripe.checkout.Session.create")
    def test_creates_session_with_customer_id(self, mock_create):
        mock_session = MagicMock()
        mock_session.url = "https://checkout.stripe.com/session/123"
        mock_create.return_value = mock_session

        client = StripeClient(_make_settings())
        session = client.create_checkout_session(
            customer_id="cus_123",
            price_id="price_starter_m",
            quantity=5,
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        mock_create.assert_called_once()
        call_kwargs = mock_create.call_args[1]
        assert call_kwargs["customer"] == "cus_123"
        assert call_kwargs["line_items"][0]["quantity"] == 5
        assert "customer_email" not in call_kwargs
        assert session.url == "https://checkout.stripe.com/session/123"

    @patch("stripe.checkout.Session.create")
    def test_creates_session_with_email(self, mock_create):
        mock_create.return_value = MagicMock()

        client = StripeClient(_make_settings())
        client.create_checkout_session(
            customer_email="user@example.com",
            price_id="price_pro_m",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        call_kwargs = mock_create.call_args[1]
        assert call_kwargs["customer_email"] == "user@example.com"
        assert "customer" not in call_kwargs

    @patch("stripe.checkout.Session.create")
    def test_customer_id_takes_precedence_over_email(self, mock_create):
        mock_create.return_value = MagicMock()

        client = StripeClient(_make_settings())
        client.create_checkout_session(
            customer_id="cus_123",
            customer_email="user@example.com",
            price_id="price_pro_m",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        call_kwargs = mock_create.call_args[1]
        assert call_kwargs["customer"] == "cus_123"
        assert "customer_email" not in call_kwargs

    @patch("stripe.checkout.Session.create")
    def test_metadata_included(self, mock_create):
        mock_create.return_value = MagicMock()

        client = StripeClient(_make_settings())
        metadata = {"org_login": "acme", "plan": "starter", "seat_count": "5"}
        client.create_checkout_session(
            price_id="price_starter_m",
            quantity=5,
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            metadata=metadata,
        )

        call_kwargs = mock_create.call_args[1]
        assert call_kwargs["metadata"] == metadata
        assert call_kwargs["subscription_data"]["metadata"] == metadata

    @patch("stripe.checkout.Session.create")
    def test_no_metadata_omits_fields(self, mock_create):
        mock_create.return_value = MagicMock()

        client = StripeClient(_make_settings())
        client.create_checkout_session(
            price_id="price_starter_m",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        call_kwargs = mock_create.call_args[1]
        assert "metadata" not in call_kwargs
        assert "subscription_data" not in call_kwargs

    @patch("stripe.checkout.Session.create")
    def test_trial_period_days(self, mock_create):
        mock_create.return_value = MagicMock()

        client = StripeClient(_make_settings())
        client.create_checkout_session(
            price_id="price_pro_m",
            quantity=3,
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            trial_period_days=14,
        )

        call_kwargs = mock_create.call_args[1]
        assert call_kwargs["subscription_data"]["trial_period_days"] == 14
        assert call_kwargs["payment_method_collection"] == "if_required"

    @patch("stripe.checkout.Session.create")
    def test_default_quantity_is_one(self, mock_create):
        mock_create.return_value = MagicMock()

        client = StripeClient(_make_settings())
        client.create_checkout_session(
            price_id="price_starter_m",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        call_kwargs = mock_create.call_args[1]
        assert call_kwargs["line_items"][0]["quantity"] == 1


class TestCreatePortalSession:
    @patch("stripe.billing_portal.Session.create")
    def test_creates_portal(self, mock_create):
        mock_portal = MagicMock()
        mock_portal.url = "https://billing.stripe.com/portal/123"
        mock_create.return_value = mock_portal

        client = StripeClient(_make_settings())
        portal = client.create_portal_session(
            customer_id="cus_123",
            return_url="https://example.com/settings",
        )

        mock_create.assert_called_once_with(
            customer="cus_123",
            return_url="https://example.com/settings",
        )
        assert portal.url == "https://billing.stripe.com/portal/123"


class TestConstructWebhookEvent:
    @patch("stripe.Webhook.construct_event")
    def test_constructs_event(self, mock_construct):
        mock_event = MagicMock()
        mock_construct.return_value = mock_event

        settings = _make_settings()
        client = StripeClient(settings)
        event = client.construct_webhook_event(b"payload", "sig_header")

        mock_construct.assert_called_once_with(
            b"payload",
            "sig_header",
            settings.stripe_webhook_secret,
        )
        assert event is mock_event


class TestPlanForPriceId:
    def test_known_price_id(self):
        client = StripeClient(_make_settings())
        assert client.plan_for_price_id("price_starter_m") == ("starter", "monthly")
        assert client.plan_for_price_id("price_pro_a") == ("pro", "annual")

    def test_unknown_price_id(self):
        client = StripeClient(_make_settings())
        assert client.plan_for_price_id("price_unknown") is None

    def test_empty_price_id(self):
        client = StripeClient(_make_settings())
        assert client.plan_for_price_id("") is None
