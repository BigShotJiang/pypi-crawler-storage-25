"""Tests for AES-256-GCM encryption of BYOK API keys."""

from __future__ import annotations

import base64
import os

import pytest
from cryptography.exceptions import InvalidTag

from canon.billing.encryption import _get_key, decrypt_api_key, encrypt_api_key


def _make_key() -> str:
    """Generate a valid base64-encoded 256-bit key for testing."""
    return base64.b64encode(os.urandom(32)).decode()


class TestGetKey:
    def test_valid_256_bit_key(self):
        raw = os.urandom(32)
        encoded = base64.b64encode(raw).decode()
        result = _get_key(encoded)
        assert result == raw
        assert len(result) == 32

    def test_rejects_128_bit_key(self):
        short = base64.b64encode(os.urandom(16)).decode()
        with pytest.raises(ValueError, match="256 bits"):
            _get_key(short)

    def test_rejects_512_bit_key(self):
        long_key = base64.b64encode(os.urandom(64)).decode()
        with pytest.raises(ValueError, match="256 bits"):
            _get_key(long_key)

    def test_rejects_invalid_base64(self):
        with pytest.raises((ValueError, base64.binascii.Error)):
            _get_key("not-valid-base64!!!")


class TestEncryptDecryptRoundTrip:
    def test_round_trip_simple(self):
        key = _make_key()
        plaintext = "sk-ant-api03-test-key-1234"
        encrypted = encrypt_api_key(plaintext, key)
        decrypted = decrypt_api_key(encrypted, key)
        assert decrypted == plaintext

    def test_round_trip_long_key(self):
        key = _make_key()
        plaintext = "sk-ant-api03-" + "x" * 200
        encrypted = encrypt_api_key(plaintext, key)
        decrypted = decrypt_api_key(encrypted, key)
        assert decrypted == plaintext

    def test_round_trip_unicode(self):
        key = _make_key()
        plaintext = "sk-test-\u00e9\u00e8\u00ea"
        encrypted = encrypt_api_key(plaintext, key)
        decrypted = decrypt_api_key(encrypted, key)
        assert decrypted == plaintext

    def test_round_trip_empty_string(self):
        key = _make_key()
        plaintext = ""
        encrypted = encrypt_api_key(plaintext, key)
        decrypted = decrypt_api_key(encrypted, key)
        assert decrypted == plaintext

    def test_different_encryptions_produce_different_ciphertext(self):
        """Each encryption uses a random nonce, so ciphertext should differ."""
        key = _make_key()
        plaintext = "sk-ant-api03-test-key"
        enc1 = encrypt_api_key(plaintext, key)
        enc2 = encrypt_api_key(plaintext, key)
        assert enc1 != enc2
        # But both decrypt to the same value
        assert decrypt_api_key(enc1, key) == plaintext
        assert decrypt_api_key(enc2, key) == plaintext

    def test_encrypted_output_starts_with_12_byte_nonce(self):
        key = _make_key()
        encrypted = encrypt_api_key("test", key)
        # nonce (12 bytes) + ciphertext (at least 16 bytes for GCM tag + plaintext)
        assert len(encrypted) >= 12 + 16


class TestDecryptErrors:
    def test_wrong_key_fails(self):
        key1 = _make_key()
        key2 = _make_key()
        encrypted = encrypt_api_key("secret-key", key1)
        with pytest.raises(InvalidTag):
            decrypt_api_key(encrypted, key2)

    def test_corrupted_ciphertext_fails(self):
        key = _make_key()
        encrypted = encrypt_api_key("secret-key", key)
        # Flip a byte in the ciphertext portion (after the 12-byte nonce)
        corrupted = bytearray(encrypted)
        corrupted[15] ^= 0xFF
        with pytest.raises(InvalidTag):
            decrypt_api_key(bytes(corrupted), key)

    def test_truncated_data_raises_value_error(self):
        key = _make_key()
        with pytest.raises(ValueError, match="too short"):
            decrypt_api_key(b"\x00" * 5, key)

    def test_exactly_12_bytes_raises_value_error(self):
        key = _make_key()
        with pytest.raises(ValueError, match="too short"):
            decrypt_api_key(b"\x00" * 12, key)

    def test_13_bytes_fails_decryption(self):
        """13 bytes passes the length check but is invalid ciphertext."""
        key = _make_key()
        with pytest.raises(InvalidTag):
            decrypt_api_key(b"\x00" * 13, key)

    def test_corrupted_nonce_fails(self):
        key = _make_key()
        encrypted = encrypt_api_key("secret", key)
        corrupted = bytearray(encrypted)
        corrupted[0] ^= 0xFF
        with pytest.raises(InvalidTag):
            decrypt_api_key(bytes(corrupted), key)
