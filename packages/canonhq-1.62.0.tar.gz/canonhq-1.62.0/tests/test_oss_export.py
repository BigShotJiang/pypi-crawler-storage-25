"""Tests for the OSS export script (.github/scripts/export-oss.sh).

Validates that the export produces a correct, self-contained repository:
- Core modules are included
- Cloud-only files are excluded
- Auth OIDC provider is included but Auth0-specific provider is excluded
- Overlay files (README, LICENSE, etc.) are present
- Exported Python files have valid syntax and don't reference cloud-only modules
"""

import ast
import subprocess
import tempfile
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
EXPORT_SCRIPT = REPO_ROOT / ".github" / "scripts" / "export-oss.sh"

skip_no_script = pytest.mark.skipif(
    not EXPORT_SCRIPT.exists(),
    reason="Export script not found",
)

CLOUD_ONLY_FILES = [
    "src/canon/auth/providers/auth0.py",
    "src/canon/auth/management.py",
    "docs/specs/canon-rebrand.md",
    "docs/specs/managed-cloud-pricing.md",
    "docs/specs/auth-hardening.md",
    "chart/canon/values-production.yaml",
    "chart/canon/values-dev.yaml",
]

OSS_REQUIRED_FILES = [
    "src/canon/parser/parse.py",
    "src/canon/config/parse.py",
    "src/canon/settings.py",
    "pyproject.toml",
    "chart/canon/values.yaml",
    "chart/canon/Chart.yaml",
]


@pytest.fixture(scope="module")
def oss_export_dir():
    """Run the OSS export to a temp directory (once per module)."""
    if not EXPORT_SCRIPT.exists():
        pytest.skip("Export script not found")
    with tempfile.TemporaryDirectory() as tmpdir:
        result = subprocess.run(
            [str(EXPORT_SCRIPT), str(REPO_ROOT), tmpdir],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            pytest.fail(f"Export script failed: {result.stderr}")
        yield Path(tmpdir)


@pytest.mark.integration
@skip_no_script
class TestOSSExportFiles:
    """Run the actual export script and verify the output structure."""

    def test_export_runs_successfully(self, oss_export_dir: Path) -> None:
        """Export script exits with code 0 and produces output."""
        # If we got here, the fixture already verified exit code 0.
        assert oss_export_dir.exists()
        # Should have produced at least some files.
        assert any(oss_export_dir.iterdir())

    def test_core_modules_present(self, oss_export_dir: Path) -> None:
        """Core OSS modules must be present in the export."""
        expected_dirs = [
            "src/canon/parser",
            "src/canon/config",
            "src/canon/cli",
            "src/canon/sync",
            "src/canon/agent",
        ]
        for d in expected_dirs:
            path = oss_export_dir / d
            assert path.is_dir(), f"Expected directory missing: {d}"

    def test_auth_provider_protocol_present(self, oss_export_dir: Path) -> None:
        """The auth provider protocol file must be exported for OIDC support."""
        path = oss_export_dir / "src/canon/auth/providers/protocol.py"
        assert path.is_file(), "auth/providers/protocol.py missing from export"

    def test_auth_generic_oidc_present(self, oss_export_dir: Path) -> None:
        """The generic OIDC provider must be exported for OSS users."""
        path = oss_export_dir / "src/canon/auth/providers/generic_oidc.py"
        assert path.is_file(), "auth/providers/generic_oidc.py missing from export"

    def test_auth0_provider_excluded(self, oss_export_dir: Path) -> None:
        """Auth0-specific provider is cloud-only and must NOT be exported."""
        path = oss_export_dir / "src/canon/auth/providers/auth0.py"
        assert not path.exists(), "auth/providers/auth0.py should be excluded"

    def test_auth_management_excluded(self, oss_export_dir: Path) -> None:
        """Auth management module is cloud-only and must NOT be exported."""
        path = oss_export_dir / "src/canon/auth/management.py"
        assert not path.exists(), "auth/management.py should be excluded"

    def test_cloud_only_specs_excluded(self, oss_export_dir: Path) -> None:
        """Sensitive/internal spec files must not appear in the export."""
        excluded_specs = [
            "docs/specs/canon-rebrand.md",
            "docs/specs/managed-cloud-pricing.md",
            "docs/specs/auth-hardening.md",
        ]
        for spec in excluded_specs:
            path = oss_export_dir / spec
            assert not path.exists(), f"Cloud-only spec should be excluded: {spec}"

    def test_production_values_excluded(self, oss_export_dir: Path) -> None:
        """Production Helm values contain infra secrets and must NOT be exported."""
        path = oss_export_dir / "chart/canon/values-production.yaml"
        assert not path.exists(), "values-production.yaml should be excluded"

    def test_dev_values_excluded(self, oss_export_dir: Path) -> None:
        """Dev Helm values are internal and must NOT be exported."""
        path = oss_export_dir / "chart/canon/values-dev.yaml"
        assert not path.exists(), "values-dev.yaml should be excluded"

    def test_preview_values_present(self, oss_export_dir: Path) -> None:
        """Preview Helm values are for OSS users and must be present."""
        path = oss_export_dir / "chart/canon/values-preview.yaml"
        assert path.is_file(), "values-preview.yaml should be present for OSS users"

    def test_pyproject_present(self, oss_export_dir: Path) -> None:
        """pyproject.toml is required for the package to be installable."""
        path = oss_export_dir / "pyproject.toml"
        assert path.is_file(), "pyproject.toml missing from export"

    def test_oss_overlay_files_present(self, oss_export_dir: Path) -> None:
        """FOSS overlay files (README, LICENSE, etc.) must be present."""
        overlay_files = [
            "README.md",
            "LICENSE",
            "Makefile",
            "Dockerfile",
            ".env.example",
            "CANON.yaml",
        ]
        for f in overlay_files:
            path = oss_export_dir / f
            assert path.is_file(), f"OSS overlay file missing: {f}"

    def test_tests_present(self, oss_export_dir: Path) -> None:
        """Test directories for OSS modules must be included."""
        expected_dirs = [
            "tests/test_parser",
            "tests/test_config",
            "tests/test_cli",
            "tests/test_sync",
        ]
        for d in expected_dirs:
            path = oss_export_dir / d
            assert path.is_dir(), f"Expected test directory missing: {d}"

    def test_helm_chart_present(self, oss_export_dir: Path) -> None:
        """Helm chart base files must be present for self-hosting."""
        helm_files = [
            "chart/canon/values.yaml",
            "chart/canon/Chart.yaml",
        ]
        for f in helm_files:
            path = oss_export_dir / f
            assert path.is_file(), f"Helm chart file missing: {f}"


@pytest.mark.integration
@skip_no_script
class TestCloudOnlyExclusion:
    """Verify specific cloud-only files are never in the export."""

    @pytest.mark.parametrize("cloud_file", CLOUD_ONLY_FILES)
    def test_cloud_only_file_excluded(self, oss_export_dir: Path, cloud_file: str) -> None:
        """Cloud-only file must not exist in the exported repo."""
        path = oss_export_dir / cloud_file
        assert not path.exists(), (
            f"Cloud-only file should be excluded from OSS export: {cloud_file}"
        )

    @pytest.mark.parametrize("required_file", OSS_REQUIRED_FILES)
    def test_oss_required_file_present(self, oss_export_dir: Path, required_file: str) -> None:
        """Required OSS file must exist in the exported repo."""
        path = oss_export_dir / required_file
        assert path.is_file(), f"Required OSS file missing from export: {required_file}"


@pytest.mark.integration
@skip_no_script
class TestImportIntegrity:
    """Verify exported Python files don't reference cloud-only modules."""

    def test_no_auth0_imports_in_generic_oidc(self, oss_export_dir: Path) -> None:
        """Generic OIDC provider shouldn't import from auth0 module."""
        generic_oidc = oss_export_dir / "src/canon/auth/providers/generic_oidc.py"
        if generic_oidc.exists():
            content = generic_oidc.read_text()
            assert "from .auth0" not in content, (
                "generic_oidc.py imports from .auth0 which is cloud-only"
            )
            assert "from ..management" not in content, (
                "generic_oidc.py imports from ..management which is cloud-only"
            )

    def test_python_files_have_valid_syntax(self, oss_export_dir: Path) -> None:
        """All exported Python files should parse without syntax errors."""
        src_dir = oss_export_dir / "src"
        if not src_dir.exists():
            pytest.skip("No src directory in export")
        for py_file in src_dir.rglob("*.py"):
            try:
                ast.parse(py_file.read_text())
            except SyntaxError as e:
                pytest.fail(f"Syntax error in {py_file.relative_to(oss_export_dir)}: {e}")
