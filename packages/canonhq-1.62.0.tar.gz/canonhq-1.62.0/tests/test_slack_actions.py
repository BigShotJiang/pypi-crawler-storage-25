"""Tests for Slack button/modal interaction handlers."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from canon_slack.actions import (
    _post_feedback_to_github,
    handle_approve,
    handle_refresh,
    handle_request_changes_open,
    handle_request_changes_submit,
    handle_sync_tickets,
)


def _mock_github_client(
    raw_content: str = "---\ntitle: test\n---\n# Test", file_sha: str = "abc123"
):
    """Return a mock GitHubClient with get_file_content and create_or_update_file."""
    gh = AsyncMock()
    gh.get_file_content = AsyncMock(return_value=(raw_content, file_sha))
    gh.create_or_update_file = AsyncMock(return_value={})
    return gh


class TestApproveAction:
    @pytest.mark.asyncio
    async def test_approve_updates_github_frontmatter(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "auth-hardening"}],
            "channel": {"id": "C456"},
            "message": {"ts": "123.456"},
        }
        client = AsyncMock()
        gh = _mock_github_client()

        with (
            patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm,
            patch("canon_slack.actions._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.actions._get_github_client", return_value=gh),
        ):
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.WRITE
            await handle_approve(ack, body, client)

        ack.assert_called_once()
        gh.get_file_content.assert_called_once_with("owner", "repo", "docs/specs/auth-hardening.md")
        gh.create_or_update_file.assert_called_once()
        call_kwargs = gh.create_or_update_file.call_args
        assert call_kwargs[0][2] == "docs/specs/auth-hardening.md"  # path
        assert "approved" in call_kwargs[0][4]  # commit message
        assert call_kwargs[1]["sha"] == "abc123"
        # Posts success message to thread
        client.chat_postMessage.assert_called_once()
        msg = client.chat_postMessage.call_args[1]
        assert "approved" in msg["text"]
        assert "review_status" in msg["text"]

    @pytest.mark.asyncio
    async def test_approve_posts_fallback_on_github_failure(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "auth-hardening"}],
            "channel": {"id": "C456"},
            "message": {"ts": "123.456"},
        }
        client = AsyncMock()

        with (
            patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm,
            patch("canon_slack.actions._get_repo_settings", side_effect=Exception("no settings")),
        ):
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.WRITE
            await handle_approve(ack, body, client)

        # Still posts a message (with failure note)
        client.chat_postMessage.assert_called_once()
        assert "failed" in client.chat_postMessage.call_args[1]["text"].lower()

    @pytest.mark.asyncio
    async def test_approve_without_permission(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "auth-hardening"}],
            "channel": {"id": "C456"},
        }
        client = AsyncMock()

        with patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm:
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.READ
            await handle_approve(ack, body, client)

        ack.assert_called_once()
        client.chat_postEphemeral.assert_called_once()


class TestRequestChangesModal:
    @pytest.mark.asyncio
    async def test_opens_modal_with_message_ts(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "auth-hardening"}],
            "trigger_id": "T123",
            "channel": {"id": "C456"},
            "message": {"ts": "111.222"},
        }
        client = AsyncMock()

        with patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm:
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.WRITE
            await handle_request_changes_open(ack, body, client)

        ack.assert_called_once()
        client.views_open.assert_called_once()
        view = client.views_open.call_args[1]["view"]
        metadata = json.loads(view["private_metadata"])
        assert metadata["spec_title"] == "auth-hardening"
        assert metadata["channel_id"] == "C456"
        assert metadata["message_ts"] == "111.222"


class TestRequestChangesSubmit:
    @pytest.mark.asyncio
    async def test_posts_feedback_to_channel_thread(self):
        ack = AsyncMock()
        view = {
            "private_metadata": json.dumps(
                {
                    "spec_title": "auth-hardening",
                    "channel_id": "C456",
                    "message_ts": "111.222",
                }
            ),
            "state": {
                "values": {
                    "feedback_block": {
                        "feedback_input": {"value": "Needs more detail on auth flow"},
                    }
                }
            },
        }
        body = {"user": {"id": "U123"}}
        client = AsyncMock()
        client.conversations_open = AsyncMock(return_value={"channel": {"id": "D999"}})
        gh = _mock_github_client()

        with (
            patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm,
            patch("canon_slack.actions._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.actions._get_github_client", return_value=gh),
            patch(
                "canon_slack.actions._post_feedback_to_github",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.WRITE
            await handle_request_changes_submit(ack, view, client, body)

        ack.assert_called_once()
        # First call: threaded reply in channel
        calls = client.chat_postMessage.call_args_list
        assert len(calls) >= 2
        thread_call = calls[0][1]
        assert thread_call["channel"] == "C456"
        assert thread_call["thread_ts"] == "111.222"
        assert "requested changes" in thread_call["text"]
        # Second call: DM confirmation
        dm_call = calls[1][1]
        assert dm_call["channel"] == "D999"
        # GitHub frontmatter update
        gh.create_or_update_file.assert_called_once()

    @pytest.mark.asyncio
    async def test_updates_review_status_in_github(self):
        ack = AsyncMock()
        view = {
            "private_metadata": json.dumps(
                {"spec_title": "auth-hardening", "channel_id": "C456", "message_ts": ""}
            ),
            "state": {
                "values": {
                    "feedback_block": {
                        "feedback_input": {"value": "Fix the auth flow"},
                    }
                }
            },
        }
        body = {"user": {"id": "U123"}}
        client = AsyncMock()
        client.conversations_open = AsyncMock(return_value={"channel": {"id": "D999"}})
        gh = _mock_github_client()

        with (
            patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm,
            patch("canon_slack.actions._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.actions._get_github_client", return_value=gh),
            patch(
                "canon_slack.actions._post_feedback_to_github",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.WRITE
            await handle_request_changes_submit(ack, view, client, body)

        gh.get_file_content.assert_called_once_with("owner", "repo", "docs/specs/auth-hardening.md")
        call_args = gh.create_or_update_file.call_args
        assert "changes_requested" in call_args[0][4]  # commit message

    @pytest.mark.asyncio
    async def test_handles_legacy_metadata_format(self):
        """Handles private_metadata that is a plain string (not JSON)."""
        ack = AsyncMock()
        view = {
            "private_metadata": "auth-hardening",
            "state": {"values": {"feedback_block": {"feedback_input": {"value": "ok"}}}},
        }
        body = {"user": {"id": "U123"}}
        client = AsyncMock()
        client.conversations_open = AsyncMock(return_value={"channel": {"id": "D999"}})

        with (
            patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm,
            patch("canon_slack.actions._get_repo_settings", side_effect=Exception("no settings")),
            patch(
                "canon_slack.actions._post_feedback_to_github",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.WRITE
            await handle_request_changes_submit(ack, view, client, body)

        ack.assert_called_once()
        # No channel_id means no threaded reply, but DM still sent
        client.conversations_open.assert_called_once()

    @pytest.mark.asyncio
    async def test_permission_denied_sends_dm(self):
        """Permission denied sends a DM notification."""
        ack = AsyncMock()
        view = {
            "private_metadata": json.dumps(
                {"spec_title": "auth-hardening", "channel_id": "C456", "message_ts": ""}
            ),
            "state": {"values": {"feedback_block": {"feedback_input": {"value": "ok"}}}},
        }
        body = {"user": {"id": "U123"}}
        client = AsyncMock()
        client.conversations_open = AsyncMock(return_value={"channel": {"id": "D999"}})

        with patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm:
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.READ
            await handle_request_changes_submit(ack, view, client, body)

        ack.assert_called_once()
        client.conversations_open.assert_called_once_with(users=["U123"])
        assert "permission" in client.chat_postMessage.call_args[1]["text"].lower()


class TestPostFeedbackToGitHub:
    @pytest.mark.asyncio
    async def test_posts_comment_on_matching_pr(self):
        import sys

        mock_gh = AsyncMock()
        mock_gh._get = AsyncMock(return_value={"items": [{"number": 42, "title": "Auth updates"}]})
        mock_gh.list_pull_files = AsyncMock(
            return_value=[{"filename": "docs/specs/auth-hardening.md"}]
        )
        mock_gh.create_comment = AsyncMock()

        mock_main = MagicMock()
        mock_main._get_client.return_value = mock_gh
        mock_main.settings.github_owner = "test"
        mock_main.settings.github_repo = "repo"

        old_main = sys.modules.get("canon.main")
        sys.modules["canon.main"] = mock_main
        try:
            result = await _post_feedback_to_github("Auth Hardening", "Needs work", "U123")
        finally:
            if old_main is not None:
                sys.modules["canon.main"] = old_main
            else:
                sys.modules.pop("canon.main", None)

        assert result is True
        mock_gh.create_comment.assert_called_once()

    @pytest.mark.asyncio
    async def test_returns_false_when_no_pr_found(self):
        import sys

        mock_gh = AsyncMock()
        mock_gh._get = AsyncMock(return_value={"items": []})

        mock_main = MagicMock()
        mock_main._get_client.return_value = mock_gh
        mock_main.settings.github_owner = "test"
        mock_main.settings.github_repo = "repo"

        old_main = sys.modules.get("canon.main")
        sys.modules["canon.main"] = mock_main
        try:
            result = await _post_feedback_to_github("Unknown Spec", "Feedback", "U123")
        finally:
            if old_main is not None:
                sys.modules["canon.main"] = old_main
            else:
                sys.modules.pop("canon.main", None)

        assert result is False


class TestSyncTickets:
    @pytest.mark.asyncio
    async def test_sync_no_permission(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "auth-hardening"}],
            "channel": {"id": "C456"},
        }
        client = AsyncMock()

        with patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm:
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.WRITE  # Need ADMIN
            await handle_sync_tickets(ack, body, client)

        client.chat_postEphemeral.assert_called_once()
        assert "permission" in client.chat_postEphemeral.call_args[1]["text"].lower()

    @pytest.mark.asyncio
    async def test_sync_no_adapter_configured(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "auth-hardening"}],
            "channel": {"id": "C456"},
            "message": {"ts": "123.456"},
        }
        client = AsyncMock()
        gh = _mock_github_client()

        with (
            patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm,
            patch("canon_slack.actions._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.actions._get_github_client", return_value=gh),
            patch("canon.sync.adapters.factory.create_adapter", return_value=None),
        ):
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.ADMIN
            await handle_sync_tickets(ack, body, client)

        # Progress message + no-adapter warning
        calls = client.chat_postMessage.call_args_list
        assert len(calls) == 2
        assert "No ticket adapter" in calls[1][1]["text"]

    @pytest.mark.asyncio
    async def test_sync_success(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "auth-hardening"}],
            "channel": {"id": "C456"},
            "message": {"ts": "123.456"},
        }
        client = AsyncMock()
        gh = _mock_github_client()

        mock_adapter = MagicMock()
        mock_result = MagicMock()
        mock_result.created = [MagicMock()]
        mock_result.updated = [MagicMock(), MagicMock()]

        with (
            patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm,
            patch("canon_slack.actions._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.actions._get_github_client", return_value=gh),
            patch("canon.sync.adapters.factory.create_adapter", return_value=mock_adapter),
            patch("canon.sync.engine.forward_sync", new_callable=AsyncMock) as mock_sync,
        ):
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.ADMIN
            mock_sync.return_value = ("updated_md", mock_result)
            await handle_sync_tickets(ack, body, client)

        calls = client.chat_postMessage.call_args_list
        assert len(calls) == 2
        assert "1 created, 2 updated" in calls[1][1]["text"]

    @pytest.mark.asyncio
    async def test_sync_failure(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "auth-hardening"}],
            "channel": {"id": "C456"},
            "message": {"ts": "123.456"},
        }
        client = AsyncMock()

        with (
            patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm,
            patch("canon_slack.actions._get_repo_settings", side_effect=Exception("boom")),
        ):
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.ADMIN
            await handle_sync_tickets(ack, body, client)

        calls = client.chat_postMessage.call_args_list
        # Progress msg + error msg
        assert len(calls) == 2
        assert "failed" in calls[1][1]["text"].lower()


class TestDashboardRefresh:
    @pytest.mark.asyncio
    async def test_refresh_updates_message(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "channel": {"id": "C456"},
            "message": {"ts": "123.456"},
        }
        client = AsyncMock()
        mock_loader = MagicMock()
        mock_loader.load = AsyncMock()
        mock_loader.has_load_error = False
        mock_loader.specs = []
        mock_loader.coverage_stats.return_value = {
            "total": 5,
            "done": 3,
            "in_progress": 1,
            "pct_done": 60,
            "pct_in_progress": 20,
            "teams": [],
        }

        with (
            patch("canon_slack.actions._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.actions._get_github_client", return_value=MagicMock()),
            patch("canon_slack.commands.invalidate_spec_cache"),
            patch("canon_slack.commands._get_spec_loader", return_value=mock_loader),
        ):
            await handle_refresh(ack, body, client)

        ack.assert_called_once()
        client.chat_update.assert_called_once()
        update_kwargs = client.chat_update.call_args[1]
        assert update_kwargs["channel"] == "C456"
        assert update_kwargs["ts"] == "123.456"

    @pytest.mark.asyncio
    async def test_refresh_load_error(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "channel": {"id": "C456"},
            "message": {"ts": "123.456"},
        }
        client = AsyncMock()
        mock_loader = MagicMock()
        mock_loader.load = AsyncMock()
        mock_loader.has_load_error = True
        mock_loader.load_error = "ConnectionError: timeout"

        with (
            patch("canon_slack.actions._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.actions._get_github_client", return_value=MagicMock()),
            patch("canon_slack.commands.invalidate_spec_cache"),
            patch("canon_slack.commands._get_spec_loader", return_value=mock_loader),
        ):
            await handle_refresh(ack, body, client)

        client.chat_postEphemeral.assert_called_once()
        assert "Failed to refresh" in client.chat_postEphemeral.call_args[1]["text"]

    @pytest.mark.asyncio
    async def test_refresh_exception(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "channel": {"id": "C456"},
            "message": {"ts": "123.456"},
        }
        client = AsyncMock()

        with patch("canon_slack.actions._get_repo_settings", side_effect=Exception("boom")):
            await handle_refresh(ack, body, client)

        client.chat_postEphemeral.assert_called_once()
        assert "failed" in client.chat_postEphemeral.call_args[1]["text"].lower()


class TestPathTraversalPrevention:
    """Path traversal characters in spec_title are rejected."""

    @pytest.mark.asyncio
    async def test_approve_rejects_dotdot(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "../../etc/passwd"}],
            "channel": {"id": "C456"},
        }
        client = AsyncMock()

        await handle_approve(ack, body, client)

        ack.assert_called_once()
        client.chat_postEphemeral.assert_called_once()
        assert "Invalid" in client.chat_postEphemeral.call_args[1]["text"]

    @pytest.mark.asyncio
    async def test_approve_rejects_slash(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "path/to/spec"}],
            "channel": {"id": "C456"},
        }
        client = AsyncMock()

        await handle_approve(ack, body, client)

        ack.assert_called_once()
        client.chat_postEphemeral.assert_called_once()
        assert "Invalid" in client.chat_postEphemeral.call_args[1]["text"]

    @pytest.mark.asyncio
    async def test_submit_rejects_dotdot(self):
        ack = AsyncMock()
        view = {
            "private_metadata": json.dumps(
                {"spec_title": "../../../etc/passwd", "channel_id": "C456", "message_ts": ""}
            ),
            "state": {"values": {"feedback_block": {"feedback_input": {"value": "ok"}}}},
        }
        body = {"user": {"id": "U123"}}
        client = AsyncMock()

        with patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm:
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.WRITE
            await handle_request_changes_submit(ack, view, client, body)

        # Should return early — no channel posts, no DM
        client.chat_postMessage.assert_not_called()

    @pytest.mark.asyncio
    async def test_sync_rejects_dotdot(self):
        ack = AsyncMock()
        body = {
            "user": {"id": "U123"},
            "actions": [{"value": "../../secrets"}],
            "channel": {"id": "C456"},
        }
        client = AsyncMock()

        with patch("canon_slack.actions.resolve_permission", new_callable=AsyncMock) as mock_perm:
            from canon_slack.permissions import Permission

            mock_perm.return_value = Permission.ADMIN
            await handle_sync_tickets(ack, body, client)

        client.chat_postEphemeral.assert_called_once()
        assert "Invalid" in client.chat_postEphemeral.call_args[1]["text"]
