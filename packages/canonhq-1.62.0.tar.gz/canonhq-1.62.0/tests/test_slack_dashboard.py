"""Tests for dashboard block builder."""

from __future__ import annotations

import pytest
from canon_slack.dashboard import auto_refresh_dashboard, build_dashboard_blocks
from canon_slack.spec_loader import SpecInfo


class TestBuildDashboardBlocks:
    def test_builds_blocks_with_stats(self):
        stats = {
            "pct_done": 60,
            "teams": [],
            "total": 10,
            "done": 6,
            "in_progress": 2,
        }
        blocks = build_dashboard_blocks(specs=[], stats=stats)
        text = str(blocks)
        assert "60%" in text
        assert "Spec Dashboard" in text

    def test_includes_team_coverage(self):
        specs = [
            SpecInfo(
                title="a",
                slug="a",
                status="done",
                sections_done=1,
                sections_total=1,
                github_url="",
                team="platform",
            ),
            SpecInfo(
                title="b",
                slug="b",
                status="active",
                sections_done=0,
                sections_total=3,
                github_url="",
                team="platform",
            ),
        ]
        stats = {
            "pct_done": 50,
            "teams": ["platform"],
            "total": 2,
            "done": 1,
            "in_progress": 1,
        }
        blocks = build_dashboard_blocks(specs=specs, stats=stats)
        text = str(blocks)
        assert "platform" in text

    def test_includes_recently_updated(self):
        specs = [
            SpecInfo(
                title="auth",
                slug="auth",
                status="active",
                sections_done=1,
                sections_total=3,
                github_url="",
                updated="2026-03-25",
            ),
        ]
        stats = {"pct_done": 33, "teams": [], "total": 1, "done": 0, "in_progress": 1}
        blocks = build_dashboard_blocks(specs=specs, stats=stats)
        text = str(blocks)
        assert "auth" in text
        assert "Recently Updated" in text

    def test_includes_refresh_button(self):
        stats = {"pct_done": 0, "teams": [], "total": 0, "done": 0, "in_progress": 0}
        blocks = build_dashboard_blocks(specs=[], stats=stats)
        action_blocks = [b for b in blocks if b["type"] == "actions"]
        assert len(action_blocks) == 1
        assert action_blocks[0]["elements"][0]["text"]["text"] == "Refresh"

    def test_high_coverage_gets_green(self):
        stats = {"pct_done": 85, "teams": [], "total": 10, "done": 8, "in_progress": 1}
        blocks = build_dashboard_blocks(specs=[], stats=stats)
        text = str(blocks)
        assert "large_green_circle" in text

    def test_low_coverage_gets_red(self):
        stats = {"pct_done": 20, "teams": [], "total": 10, "done": 2, "in_progress": 1}
        blocks = build_dashboard_blocks(specs=[], stats=stats)
        text = str(blocks)
        assert "red_circle" in text


class TestAutoRefreshDashboard:
    @pytest.mark.asyncio
    async def test_updates_existing_message(self):
        from unittest.mock import AsyncMock

        client = AsyncMock()
        stats = {"pct_done": 50, "teams": [], "total": 2, "done": 1, "in_progress": 1}

        ts = await auto_refresh_dashboard(client, "#specs", "123.456", [], stats)

        client.chat_update.assert_called_once()
        assert client.chat_update.call_args[1]["ts"] == "123.456"
        assert ts == "123.456"

    @pytest.mark.asyncio
    async def test_posts_new_message_when_no_pinned(self):
        from unittest.mock import AsyncMock

        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ts": "999.000"})
        stats = {"pct_done": 50, "teams": [], "total": 2, "done": 1, "in_progress": 1}

        ts = await auto_refresh_dashboard(client, "#specs", None, [], stats)

        client.chat_postMessage.assert_called_once()
        assert ts == "999.000"

    @pytest.mark.asyncio
    async def test_returns_none_on_error(self):
        from unittest.mock import AsyncMock

        client = AsyncMock()
        client.chat_update = AsyncMock(side_effect=Exception("API error"))
        stats = {"pct_done": 50, "teams": [], "total": 2, "done": 1, "in_progress": 1}

        ts = await auto_refresh_dashboard(client, "#specs", "123.456", [], stats)
        assert ts is None
