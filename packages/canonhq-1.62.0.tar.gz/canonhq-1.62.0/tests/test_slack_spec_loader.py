"""Tests for Slack spec data access layer."""

from __future__ import annotations

from unittest.mock import AsyncMock

from canon_slack.spec_loader import SpecInfo, SpecLoader


class TestSpecLoader:
    def _make_loader(self, specs: list[SpecInfo] | None = None) -> SpecLoader:
        github_client = AsyncMock()
        loader = SpecLoader(github_client=github_client, owner="org", repo="repo")
        if specs is not None:
            loader._cache = specs
            loader._cache_valid = True
        return loader

    def test_filter_by_status(self):
        specs = [
            SpecInfo(
                title="auth",
                slug="auth",
                status="active",
                sections_done=2,
                sections_total=5,
                github_url="",
            ),
            SpecInfo(
                title="billing",
                slug="billing",
                status="draft",
                sections_done=0,
                sections_total=3,
                github_url="",
            ),
        ]
        loader = self._make_loader(specs)
        result = loader.filter_by_status("active")
        assert len(result) == 1
        assert result[0].title == "auth"

    def test_search_by_keyword(self):
        specs = [
            SpecInfo(
                title="auth hardening",
                slug="auth-hardening",
                status="active",
                sections_done=2,
                sections_total=5,
                github_url="",
            ),
            SpecInfo(
                title="billing integration",
                slug="billing-integration",
                status="draft",
                sections_done=0,
                sections_total=3,
                github_url="",
            ),
        ]
        loader = self._make_loader(specs)
        result = loader.search("auth")
        assert len(result) == 1
        assert result[0].title == "auth hardening"

    def test_fuzzy_match(self):
        specs = [
            SpecInfo(
                title="auth-hardening",
                slug="auth-hardening",
                status="active",
                sections_done=0,
                sections_total=5,
                github_url="",
            ),
            SpecInfo(
                title="authentication-flow",
                slug="authentication-flow",
                status="draft",
                sections_done=0,
                sections_total=3,
                github_url="",
            ),
        ]
        loader = self._make_loader(specs)
        suggestions = loader.suggest_similar("auth-harden")
        assert len(suggestions) >= 1
        assert "auth-hardening" in suggestions

    def test_get_spec_by_slug_found(self):
        specs = [
            SpecInfo(
                title="auth-hardening",
                slug="auth-hardening",
                status="active",
                sections_done=2,
                sections_total=5,
                github_url="",
            ),
        ]
        loader = self._make_loader(specs)
        result = loader.get_by_slug("auth-hardening")
        assert result is not None
        assert result.title == "auth-hardening"

    def test_get_spec_by_slug_not_found(self):
        loader = self._make_loader([])
        result = loader.get_by_slug("nonexistent")
        assert result is None

    def test_coverage_stats(self):
        specs = [
            SpecInfo(
                title="a",
                slug="a",
                status="done",
                sections_done=1,
                sections_total=1,
                github_url="",
                team="platform",
            ),
            SpecInfo(
                title="b",
                slug="b",
                status="active",
                sections_done=0,
                sections_total=3,
                github_url="",
                team="platform",
            ),
            SpecInfo(
                title="c",
                slug="c",
                status="draft",
                sections_done=0,
                sections_total=2,
                github_url="",
                team="backend",
            ),
        ]
        loader = self._make_loader(specs)
        stats = loader.coverage_stats()
        assert stats["total"] == 3
        assert stats["done"] == 1
        assert stats["in_progress"] == 1
        assert stats["teams"] == ["backend", "platform"]

    def test_coverage_stats_by_team(self):
        specs = [
            SpecInfo(
                title="a",
                slug="a",
                status="done",
                sections_done=1,
                sections_total=1,
                github_url="",
                team="platform",
            ),
            SpecInfo(
                title="b",
                slug="b",
                status="draft",
                sections_done=0,
                sections_total=2,
                github_url="",
                team="backend",
            ),
        ]
        loader = self._make_loader(specs)
        stats = loader.coverage_stats(team="platform")
        assert stats["total"] == 1
        assert stats["done"] == 1

    def test_invalidate_cache(self):
        loader = self._make_loader([])
        assert loader._cache_valid is True
        loader.invalidate()
        assert loader._cache_valid is False

    def test_cache_ttl_expiry(self):
        """Cache should expire after CACHE_TTL seconds."""
        loader = self._make_loader([])
        # Simulate cache set in the past (beyond TTL)
        loader._cache_time = 0.0  # epoch — well beyond any TTL
        # Even though _cache_valid is True, the TTL check should force reload
        assert loader._cache_valid is True

    def test_specs_property(self):
        specs = [
            SpecInfo(
                title="a",
                slug="a",
                status="done",
                sections_done=1,
                sections_total=1,
                github_url="",
            ),
        ]
        loader = self._make_loader(specs)
        result = loader.specs
        assert len(result) == 1
        # Should be a copy
        result.clear()
        assert len(loader.specs) == 1
