"""Shared test fixtures for admin tests."""

from __future__ import annotations

import pytest

from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission


@pytest.fixture
def super_admin_user() -> CurrentUser:
    return CurrentUser(
        sub="admin-1",
        email="admin@canonhq.co",
        name="Admin User",
        org_login="canonhq",
        permissions=frozenset(Permission),
        auth_method="session",
    )
