import pytest

from canon.settings import Settings


class TestDeploymentMode:
    def test_default_is_development(self):
        s = Settings(deployment_mode="development")
        assert s.deployment_mode == "development"

    def test_cloud_mode(self):
        s = Settings(deployment_mode="cloud")
        assert s.deployment_mode == "cloud"

    def test_self_hosted_mode(self):
        s = Settings(deployment_mode="self_hosted")
        assert s.deployment_mode == "self_hosted"

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError):
            Settings(deployment_mode="invalid")

    def test_audit_retention_default(self):
        s = Settings()
        assert s.admin_audit_retention_days == 90
