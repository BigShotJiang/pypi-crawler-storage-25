"""Tests for admin action endpoints (deactivation, suspension)."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from canon.admin.middleware import require_super_admin
from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission
from canon.main import app
from canon.settings import Settings


def _super_admin() -> CurrentUser:
    return CurrentUser(
        sub="admin-1",
        email="admin@canonhq.co",
        name="Admin",
        org_login="canonhq",
        permissions=frozenset(Permission),
        auth_method="session",
    )


@pytest.fixture
def client():
    return AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test", follow_redirects=False
    )


@pytest.fixture(autouse=True)
def _setup():
    user = _super_admin()
    app.dependency_overrides[require_super_admin] = lambda: user
    app.state.settings = Settings(deployment_mode="cloud")
    app.state.admin_store = AsyncMock()
    app.state.audit_store = AsyncMock()
    app.state.session_store = AsyncMock()
    app.state.user_store = AsyncMock()
    app.state.db_pool = None
    yield
    app.dependency_overrides.pop(require_super_admin, None)


class TestDeactivateUser:
    async def test_deactivates_and_revokes(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "status": "active", "email": "u@b.com"}
        )
        app.state.admin_store.deactivate_user = AsyncMock(
            return_value={
                "id": 1,
                "login": "u",
                "email": "u@b.com",
                "role": "editor",
                "status": "deactivated",
                "org_login": "",
                "created_at": None,
            }
        )
        app.state.session_store.revoke_all_sessions = AsyncMock(return_value=2)
        app.state.user_store.revoke_all_api_keys = AsyncMock(return_value=1)

        resp = await client.post("/api/admin/users/1/deactivate")

        assert resp.status_code == 200
        body = resp.json()
        assert body["status"] == "deactivated"
        assert body["sessions_revoked"] == 2
        assert body["keys_revoked"] == 1
        app.state.audit_store.log.assert_awaited_once()

    async def test_cannot_deactivate_super_admin(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 2, "role": "super_admin", "status": "active"}
        )

        resp = await client.post("/api/admin/users/2/deactivate")

        assert resp.status_code == 400

    async def test_404_if_user_not_found(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)

        resp = await client.post("/api/admin/users/999/deactivate")

        assert resp.status_code == 404

    async def test_400_if_already_deactivated(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "status": "deactivated"}
        )

        resp = await client.post("/api/admin/users/1/deactivate")

        assert resp.status_code == 400


class TestReactivateUser:
    async def test_reactivates_user(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "status": "deactivated", "email": "u@b.com"}
        )
        app.state.admin_store.reactivate_user = AsyncMock(
            return_value={
                "id": 1,
                "login": "u",
                "email": "u@b.com",
                "role": "editor",
                "status": "active",
                "org_login": "",
                "created_at": None,
            }
        )

        resp = await client.post("/api/admin/users/1/reactivate")

        assert resp.status_code == 200
        assert resp.json()["status"] == "active"
        app.state.audit_store.log.assert_awaited_once()

    async def test_400_if_not_deactivated(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "status": "active"}
        )

        resp = await client.post("/api/admin/users/1/reactivate")

        assert resp.status_code == 400


class TestSuspendOrg:
    async def test_suspends_org(self, client: AsyncClient):
        app.state.admin_store.suspend_org = AsyncMock(
            return_value={"installation_id": 123, "org_login": "acme", "status": "suspended"}
        )

        resp = await client.post("/api/admin/orgs/acme/suspend")

        assert resp.status_code == 200
        assert resp.json()["status"] == "suspended"
        app.state.audit_store.log.assert_awaited_once()

    async def test_404_if_org_not_found(self, client: AsyncClient):
        app.state.admin_store.suspend_org = AsyncMock(return_value=None)

        resp = await client.post("/api/admin/orgs/nonexistent/suspend")

        assert resp.status_code == 404


class TestReactivateOrg:
    async def test_reactivates_org(self, client: AsyncClient):
        app.state.admin_store.reactivate_org = AsyncMock(
            return_value={"installation_id": 123, "org_login": "acme", "status": "active"}
        )

        resp = await client.post("/api/admin/orgs/acme/reactivate")

        assert resp.status_code == 200
        assert resp.json()["status"] == "active"
        app.state.audit_store.log.assert_awaited_once()

    async def test_404_if_org_not_suspended(self, client: AsyncClient):
        app.state.admin_store.reactivate_org = AsyncMock(return_value=None)

        resp = await client.post("/api/admin/orgs/acme/reactivate")

        assert resp.status_code == 404


class TestUserOrgMembership:
    async def test_list_user_orgs(self, client: AsyncClient):
        from canon.auth.providers.protocol import OrgInfo
        from canon.db.registry import Installation

        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "oidc_sub": "auth0|abc", "email": "u@e.com"}
        )
        provider = AsyncMock()
        provider.get_user_orgs = AsyncMock(
            return_value=[
                OrgInfo(id="org_acme", name="acme", display_name="Acme Inc"),
                OrgInfo(id="org_personal", name="njgerner", display_name=""),
            ]
        )
        app.state.oidc_provider = provider
        registry = AsyncMock()
        # acme maps to an installation, personal does not
        registry.get_installation_by_oidc_org = AsyncMock(
            side_effect=[
                Installation(installation_id=1, org_login="acme", oidc_org_id="org_acme"),
                None,
            ]
        )
        app.state.registry = registry

        resp = await client.get("/api/admin/users/1/orgs")

        assert resp.status_code == 200
        body = resp.json()
        assert len(body) == 2
        assert body[0]["oidc_org_id"] == "org_acme"
        assert body[0]["org_login"] == "acme"
        assert body[0]["display_name"] == "Acme Inc"
        assert body[1]["org_login"] is None  # unmapped personal account

    async def test_list_orgs_empty_when_no_oidc_sub(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "oidc_sub": "", "email": "u@e.com"}
        )
        app.state.oidc_provider = AsyncMock()
        app.state.registry = AsyncMock()

        resp = await client.get("/api/admin/users/1/orgs")

        assert resp.status_code == 200
        assert resp.json() == []

    async def test_list_orgs_404_when_user_missing(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)
        app.state.oidc_provider = AsyncMock()
        app.state.registry = AsyncMock()

        resp = await client.get("/api/admin/users/999/orgs")

        assert resp.status_code == 404

    async def test_list_orgs_404_in_self_hosted(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.get("/api/admin/users/1/orgs")

        assert resp.status_code == 404

    async def test_add_user_to_org_by_org_login(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "status": "active",
            }
        )
        app.state.admin_store.get_org = AsyncMock(
            return_value={"login": "acme", "oidc_org_id": "org_acme", "status": "active"}
        )
        provider = AsyncMock()
        provider.add_org_member = AsyncMock()
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/orgs", json={"org_login": "acme"})

        assert resp.status_code == 200
        body = resp.json()
        assert body["added"] is True
        assert body["oidc_org_id"] == "org_acme"
        assert body["org_login"] == "acme"
        provider.add_org_member.assert_awaited_once_with(org_id="org_acme", user_id="auth0|abc")
        audit_call = app.state.audit_store.log.call_args
        assert audit_call.kwargs["event_type"] == "org.member_added"

    async def test_add_user_to_org_by_oidc_org_id(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.add_org_member = AsyncMock()
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/orgs", json={"oidc_org_id": "org_xyz"})

        assert resp.status_code == 200
        assert resp.json()["oidc_org_id"] == "org_xyz"
        provider.add_org_member.assert_awaited_once_with(org_id="org_xyz", user_id="auth0|abc")
        # No admin_store.get_org call when caller passed oidc_org_id directly
        app.state.admin_store.get_org.assert_not_called()

    async def test_add_400_when_no_oidc_sub(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "oidc_sub": "", "email": "u@e.com", "status": "active"}
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/orgs", json={"org_login": "acme"})

        assert resp.status_code == 400
        assert "oidc_sub" in resp.json()["detail"]

    async def test_add_400_when_deactivated(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "status": "deactivated",
            }
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/orgs", json={"org_login": "acme"})

        assert resp.status_code == 400

    async def test_add_422_when_no_body_fields(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "status": "active",
            }
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/orgs", json={})

        assert resp.status_code == 422  # Pydantic model_validator rejects empty body

    async def test_add_400_when_org_missing_oidc_link(self, client: AsyncClient):
        """Canon org exists but has no oidc_org_id — repair-auth0 needed first."""
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "status": "active",
            }
        )
        app.state.admin_store.get_org = AsyncMock(
            return_value={"login": "acme", "oidc_org_id": None, "status": "active"}
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/orgs", json={"org_login": "acme"})

        assert resp.status_code == 400
        assert "repair-auth0" in resp.json()["detail"]

    async def test_add_404_when_canon_org_missing(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "status": "active",
            }
        )
        app.state.admin_store.get_org = AsyncMock(return_value=None)
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/orgs", json={"org_login": "ghost"})

        assert resp.status_code == 404

    async def test_add_404_in_self_hosted(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.post("/api/admin/users/1/orgs", json={"org_login": "acme"})

        assert resp.status_code == 404

    async def test_remove_user_from_org(self, client: AsyncClient):
        from canon.db.registry import Installation

        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "oidc_sub": "auth0|abc", "email": "u@e.com"}
        )
        registry = AsyncMock()
        registry.get_installation_by_oidc_org = AsyncMock(
            return_value=Installation(installation_id=1, org_login="acme", oidc_org_id="org_acme")
        )
        app.state.registry = registry
        provider = AsyncMock()
        provider.remove_org_member = AsyncMock()
        app.state.oidc_provider = provider

        resp = await client.delete("/api/admin/users/1/orgs/org_acme")

        assert resp.status_code == 200
        body = resp.json()
        assert body["removed"] is True
        assert body["oidc_org_id"] == "org_acme"
        assert body["org_login"] == "acme"
        provider.remove_org_member.assert_awaited_once_with(org_id="org_acme", user_id="auth0|abc")
        audit_call = app.state.audit_store.log.call_args
        assert audit_call.kwargs["event_type"] == "org.member_removed"

    async def test_remove_404_when_user_missing(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)
        app.state.registry = AsyncMock()
        app.state.oidc_provider = AsyncMock()

        resp = await client.delete("/api/admin/users/999/orgs/org_acme")

        assert resp.status_code == 404

    async def test_remove_502_on_auth0_failure(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "oidc_sub": "auth0|abc", "email": "u@e.com"}
        )
        registry = AsyncMock()
        registry.get_installation_by_oidc_org = AsyncMock(return_value=None)
        app.state.registry = registry
        provider = AsyncMock()
        provider.remove_org_member = AsyncMock(side_effect=RuntimeError("auth0 down"))
        app.state.oidc_provider = provider

        resp = await client.delete("/api/admin/users/1/orgs/org_acme")

        assert resp.status_code == 502
        # No audit event on failure
        app.state.audit_store.log.assert_not_called()

    async def test_add_502_on_auth0_failure(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "status": "active",
            }
        )
        app.state.admin_store.get_org = AsyncMock(
            return_value={"login": "acme", "oidc_org_id": "org_acme", "status": "active"}
        )
        provider = AsyncMock()
        provider.add_org_member = AsyncMock(side_effect=RuntimeError("auth0 down"))
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/orgs", json={"org_login": "acme"})

        assert resp.status_code == 502
        app.state.audit_store.log.assert_not_called()


class TestDeleteUser:
    def _target(self, **overrides) -> dict:
        base = {
            "id": 1,
            "oidc_sub": "auth0|abc",
            "email": "u@example.com",
            "login": "u@example.com",
            "role": "editor",
            "status": "active",
            "org_login": "acme",
        }
        base.update(overrides)
        return base

    async def test_deletes_user_with_correct_confirm(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=self._target())
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 99})
        app.state.admin_store.delete_user_atomic = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "name": "Test",
                "role": "editor",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.delete_user = AsyncMock()
        app.state.oidc_provider = provider

        resp = await client.request(
            "DELETE", "/api/admin/users/1", json={"confirm": "u@example.com"}
        )

        assert resp.status_code == 200
        body = resp.json()
        assert body["deleted"] is True
        assert body["email"] == "u@example.com"
        # Audit event includes the pre-delete snapshot in the detail
        audit_call = app.state.audit_store.log.call_args
        assert audit_call.kwargs["event_type"] == "user.deleted"
        snap = audit_call.kwargs["detail"]["snapshot"]
        assert snap["email"] == "u@example.com"
        assert snap["oidc_sub"] == "auth0|abc"

    async def test_400_with_wrong_confirm(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=self._target())
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 99})
        app.state.oidc_provider = AsyncMock()

        resp = await client.request("DELETE", "/api/admin/users/1", json={"confirm": "wrong"})

        assert resp.status_code == 400
        assert "u@example.com" in resp.json()["detail"]
        # Atomic delete must NOT have been called
        assert (
            not getattr(app.state.admin_store.delete_user_atomic, "called", False)
            or app.state.admin_store.delete_user_atomic.await_count == 0
        )

    async def test_400_when_deleting_self(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=self._target())
        # Acting admin's user_id matches the target
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 1})
        app.state.oidc_provider = AsyncMock()

        resp = await client.request(
            "DELETE", "/api/admin/users/1", json={"confirm": "u@example.com"}
        )

        assert resp.status_code == 400
        assert "own account" in resp.json()["detail"]

    async def test_400_when_deleting_super_admin(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=self._target(role="super_admin"))
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 99})
        app.state.oidc_provider = AsyncMock()

        resp = await client.request(
            "DELETE", "/api/admin/users/1", json={"confirm": "u@example.com"}
        )

        assert resp.status_code == 400
        assert "super admin" in resp.json()["detail"]

    async def test_404_when_user_missing(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)
        app.state.oidc_provider = AsyncMock()

        resp = await client.request("DELETE", "/api/admin/users/999", json={"confirm": "anything"})

        assert resp.status_code == 404

    async def test_502_on_auth0_failure(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=self._target())
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 99})
        # delete_user_atomic raises because the Auth0 call fails after the
        # DB delete was already committed
        app.state.admin_store.delete_user_atomic = AsyncMock(
            side_effect=RuntimeError("auth0 unreachable")
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.request(
            "DELETE", "/api/admin/users/1", json={"confirm": "u@example.com"}
        )

        assert resp.status_code == 502
        assert "auth0 unreachable" in resp.json()["detail"]

    async def test_confirm_falls_back_to_user_id_for_empty_profile(self, client: AsyncClient):
        """Users with empty email and login require str(user_id) as confirmation."""
        app.state.admin_store.get_user = AsyncMock(
            return_value=self._target(email="", login="", name="")
        )
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 99})
        app.state.admin_store.delete_user_atomic = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "",
                "name": "",
                "role": "editor",
                "status": "active",
            }
        )
        app.state.oidc_provider = AsyncMock()

        # Empty string should NOT work
        resp = await client.request("DELETE", "/api/admin/users/1", json={"confirm": ""})
        assert resp.status_code == 400

        # str(user_id) SHOULD work
        resp = await client.request("DELETE", "/api/admin/users/1", json={"confirm": "1"})
        assert resp.status_code == 200

    async def test_409_on_concurrent_delete(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=self._target())
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 99})
        app.state.admin_store.delete_user_atomic = AsyncMock(return_value=None)
        app.state.oidc_provider = AsyncMock()

        resp = await client.request(
            "DELETE", "/api/admin/users/1", json={"confirm": "u@example.com"}
        )

        assert resp.status_code == 409
        assert "concurrently" in resp.json()["detail"]

    async def test_404_in_self_hosted(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.request("DELETE", "/api/admin/users/1", json={"confirm": "anything"})

        assert resp.status_code == 404


class TestUserSessionsAdmin:
    async def test_lists_sessions_across_orgs(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value={"id": 1, "email": "u@e.com"})
        app.state.session_store.list_sessions_for_admin = AsyncMock(
            return_value=[
                {
                    "id": "sess-1",
                    "user_id": 1,
                    "org_login": "acme",
                    "device_label": "cli",
                    "created_at": None,
                    "last_used_at": None,
                    "expires_at": None,
                },
                {
                    "id": "sess-2",
                    "user_id": 1,
                    "org_login": "personal",
                    "device_label": "browser",
                    "created_at": None,
                    "last_used_at": None,
                    "expires_at": None,
                },
            ]
        )

        resp = await client.get("/api/admin/users/1/sessions")

        assert resp.status_code == 200
        body = resp.json()
        assert len(body) == 2
        assert {row["org_login"] for row in body} == {"acme", "personal"}

    async def test_404_when_user_missing(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)

        resp = await client.get("/api/admin/users/999/sessions")

        assert resp.status_code == 404

    async def test_revoke_single_session(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value={"id": 1, "email": "u@e.com"})
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 99})
        app.state.session_store.revoke_session = AsyncMock(return_value=True)

        resp = await client.delete("/api/admin/users/1/sessions/sess-1")

        assert resp.status_code == 200
        assert resp.json()["revoked"] is True
        app.state.session_store.revoke_session.assert_awaited_once_with(
            session_id="sess-1", user_id=1
        )
        audit_call = app.state.audit_store.log.call_args
        assert audit_call.kwargs["event_type"] == "user.session_revoked"

    async def test_blocks_self_revoke(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value={"id": 1, "email": "u@e.com"})
        # Acting admin's DB user_id matches the target
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 1})

        resp = await client.delete("/api/admin/users/1/sessions/sess-1")

        assert resp.status_code == 400
        assert "own session" in resp.json()["detail"]

    async def test_404_when_session_not_found(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value={"id": 1, "email": "u@e.com"})
        app.state.user_store.get_user_by_sub = AsyncMock(return_value={"id": 99})
        app.state.session_store.revoke_session = AsyncMock(return_value=False)

        resp = await client.delete("/api/admin/users/1/sessions/missing")

        assert resp.status_code == 404


class TestUserApiKeysAdmin:
    async def test_lists_api_keys(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value={"id": 1, "email": "u@e.com"})
        app.state.user_store.list_api_keys_for_admin = AsyncMock(
            return_value=[
                {
                    "id": 7,
                    "label": "ci",
                    "user_id": 1,
                    "org_login": "acme",
                    "scopes": ["read"],
                    "created_at": None,
                    "expires_at": None,
                    "last_used_at": None,
                }
            ]
        )

        resp = await client.get("/api/admin/users/1/api-keys")

        assert resp.status_code == 200
        body = resp.json()
        assert len(body) == 1
        assert body[0]["id"] == 7
        # Secret hash never returned
        assert "key_hash" not in body[0]

    async def test_revoke_single_api_key(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value={"id": 1, "email": "u@e.com"})
        app.state.user_store.revoke_api_key_for_admin = AsyncMock(return_value=True)

        resp = await client.delete("/api/admin/users/1/api-keys/7")

        assert resp.status_code == 200
        app.state.user_store.revoke_api_key_for_admin.assert_awaited_once_with(key_id=7, user_id=1)
        audit_call = app.state.audit_store.log.call_args
        assert audit_call.kwargs["event_type"] == "user.api_key_revoked"

    async def test_404_when_api_key_not_found(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value={"id": 1, "email": "u@e.com"})
        app.state.user_store.revoke_api_key_for_admin = AsyncMock(return_value=False)

        resp = await client.delete("/api/admin/users/1/api-keys/999")

        assert resp.status_code == 404


class TestResendUserInvite:
    async def test_creates_invitation(self, client: AsyncClient):
        from canon.auth.providers.protocol import OrgInfo

        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "active",
                "role": "editor",
            }
        )
        provider = AsyncMock()
        provider.get_user_orgs = AsyncMock(return_value=[OrgInfo(id="org_xyz", name="acme")])
        provider.create_invitation = AsyncMock(
            return_value={
                "invitation_url": "https://example.auth0.com/invite/xyz",
                "expires_at": "2026-04-18T00:00:00Z",
            }
        )
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 200
        body = resp.json()
        assert body["invitation_url"] == "https://example.auth0.com/invite/xyz"
        provider.create_invitation.assert_awaited_once()
        # Audit detail must NOT contain the invitation URL
        audit_call = app.state.audit_store.log.call_args
        assert "invitation_url" not in audit_call.kwargs["detail"]
        assert audit_call.kwargs["event_type"] == "user.invite_sent"

    async def test_400_when_user_has_no_oidc_sub(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": None,
                "email": "u@example.com",
                "status": "active",
            }
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 400

    async def test_400_when_user_deactivated(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "deactivated",
            }
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 400

    async def test_400_when_user_in_no_orgs(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.get_user_orgs = AsyncMock(return_value=[])
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 400

    async def test_404_in_self_hosted(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 404


class TestSendUserPasswordReset:
    async def test_creates_ticket(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.create_password_change_ticket = AsyncMock(
            return_value={"ticket": "https://example.auth0.com/lo/reset?token=abc"}
        )
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/password-reset")

        assert resp.status_code == 200
        body = resp.json()
        assert body["ticket_url"] == "https://example.auth0.com/lo/reset?token=abc"
        provider.create_password_change_ticket.assert_awaited_once_with(user_id="auth0|abc")
        # Audit detail must not include ticket URL
        audit_call = app.state.audit_store.log.call_args
        assert "ticket_url" not in audit_call.kwargs["detail"]
        assert "ticket" not in audit_call.kwargs["detail"]

    async def test_400_when_no_oidc_sub(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "oidc_sub": None, "email": "u@example.com", "status": "active"}
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/password-reset")

        assert resp.status_code == 400

    async def test_400_when_deactivated(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "deactivated",
            }
        )
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/password-reset")

        assert resp.status_code == 400

    async def test_404_in_self_hosted(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.post("/api/admin/users/1/password-reset")

        assert resp.status_code == 404


class TestRepairOrgAuth0:
    def _existing_org(self, **overrides) -> dict:
        base = {
            "login": "acme",
            "installation_id": "123",
            "status": "active",
            "display_name": "Acme",
            "user_count": 0,
            "created_at": None,
        }
        base.update(overrides)
        return base

    async def test_returns_already_provisioned_without_calls(self, client: AsyncClient):
        from canon.github.handlers.on_installation import ProvisionResult

        app.state.admin_store.get_org = AsyncMock(return_value=self._existing_org())
        app.state.registry = AsyncMock()
        app.state.oidc_provider = AsyncMock()

        async def fake_provision(*args, **kwargs):
            return ProvisionResult(oidc_org_id="org_existing", status="already_provisioned")

        with patch(
            "canon.github.handlers.on_installation.provision_auth0_org",
            side_effect=fake_provision,
        ):
            resp = await client.post("/api/admin/orgs/acme/repair-auth0")

        assert resp.status_code == 200
        body = resp.json()
        assert body["status"] == "already_provisioned"
        assert body["oidc_org_id"] == "org_existing"
        # No audit event when nothing changed
        app.state.audit_store.log.assert_not_called()

    async def test_repairs_when_provisioning_fresh(self, client: AsyncClient):
        from canon.github.handlers.on_installation import ProvisionResult

        app.state.admin_store.get_org = AsyncMock(return_value=self._existing_org())
        app.state.registry = AsyncMock()
        app.state.oidc_provider = AsyncMock()

        async def fake_provision(*args, **kwargs):
            return ProvisionResult(oidc_org_id="org_new", status="provisioned")

        with patch(
            "canon.github.handlers.on_installation.provision_auth0_org",
            side_effect=fake_provision,
        ):
            resp = await client.post("/api/admin/orgs/acme/repair-auth0")

        assert resp.status_code == 200
        assert resp.json()["status"] == "provisioned"
        app.state.audit_store.log.assert_awaited_once()
        audit_call = app.state.audit_store.log.call_args
        assert audit_call.kwargs["event_type"] == "org.auth0_repair"
        assert audit_call.kwargs["detail"]["result"] == "provisioned"

    async def test_returns_422_on_provisioning_failure(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(return_value=self._existing_org())
        app.state.registry = AsyncMock()
        app.state.oidc_provider = AsyncMock()

        async def fake_provision(*args, **kwargs):
            raise RuntimeError("auth0 unreachable")

        with patch(
            "canon.github.handlers.on_installation.provision_auth0_org",
            side_effect=fake_provision,
        ):
            resp = await client.post("/api/admin/orgs/acme/repair-auth0")

        assert resp.status_code == 422
        assert "auth0 unreachable" in resp.json()["detail"]
        # Partial repair audit logged so the next attempt has context
        app.state.audit_store.log.assert_awaited_once()
        assert (
            app.state.audit_store.log.call_args.kwargs["event_type"] == "org.auth0_partial_repair"
        )

    async def test_404_in_self_hosted_mode(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.post("/api/admin/orgs/acme/repair-auth0")

        assert resp.status_code == 404

    async def test_404_when_org_missing(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(return_value=None)
        app.state.registry = AsyncMock()
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/orgs/missing/repair-auth0")

        assert resp.status_code == 404


class TestUpdateOrgMetadata:
    def _existing_org(self, **overrides) -> dict:
        base = {
            "login": "acme",
            "installation_id": 123,
            "status": "active",
            "display_name": "Old Name",
            "oidc_org_id": "org_xyz",
            "primary_contact_email": None,
            "primary_contact_name": None,
            "support_notes": None,
            "user_count": 5,
            "created_at": None,
        }
        base.update(overrides)
        return base

    async def test_updates_metadata_only(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(
            side_effect=[
                self._existing_org(),
                self._existing_org(
                    primary_contact_email="ops@acme.com",
                    primary_contact_name="Ops Team",
                    support_notes="Onboarding",
                ),
            ]
        )
        app.state.admin_store.update_org_metadata = AsyncMock(return_value={})

        resp = await client.patch(
            "/api/admin/orgs/acme",
            json={
                "primary_contact_email": "ops@acme.com",
                "primary_contact_name": "Ops Team",
                "support_notes": "Onboarding",
            },
        )

        assert resp.status_code == 200
        body = resp.json()
        assert body["primary_contact_email"] == "ops@acme.com"
        app.state.admin_store.update_org_metadata.assert_awaited_once()
        app.state.audit_store.log.assert_awaited_once()
        # Audit detail should record a field-level diff
        audit_call = app.state.audit_store.log.call_args
        diff = audit_call.kwargs["detail"]["diff"]
        assert "primary_contact_email" in diff
        assert diff["primary_contact_email"]["new"] == "ops@acme.com"

    async def test_updates_display_name_via_auth0(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(
            side_effect=[
                self._existing_org(),
                self._existing_org(display_name="New Name"),
            ]
        )
        provider = AsyncMock()
        provider.update_organization = AsyncMock(return_value={"id": "org_xyz"})
        app.state.oidc_provider = provider
        cache = AsyncMock()
        cache.invalidate = lambda key: None  # synchronous
        app.state.cache = cache

        resp = await client.patch("/api/admin/orgs/acme", json={"display_name": "New Name"})

        assert resp.status_code == 200
        provider.update_organization.assert_awaited_once_with("org_xyz", display_name="New Name")

    async def test_400_when_no_fields_provided(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(return_value=self._existing_org())

        resp = await client.patch("/api/admin/orgs/acme", json={})

        assert resp.status_code == 400

    async def test_400_when_org_suspended(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(
            return_value=self._existing_org(status="suspended")
        )

        resp = await client.patch("/api/admin/orgs/acme", json={"primary_contact_email": "x@y.com"})

        assert resp.status_code == 400

    async def test_400_when_email_invalid(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(return_value=self._existing_org())

        resp = await client.patch(
            "/api/admin/orgs/acme", json={"primary_contact_email": "not-an-email"}
        )

        assert resp.status_code == 400

    async def test_400_when_notes_too_long(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(return_value=self._existing_org())

        resp = await client.patch("/api/admin/orgs/acme", json={"support_notes": "x" * 2001})

        assert resp.status_code == 400

    async def test_404_when_org_missing(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(return_value=None)

        resp = await client.patch(
            "/api/admin/orgs/missing", json={"primary_contact_email": "x@y.com"}
        )

        assert resp.status_code == 404

    async def test_400_display_name_without_oidc_org_id(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(return_value=self._existing_org(oidc_org_id=None))
        app.state.oidc_provider = AsyncMock()

        resp = await client.patch("/api/admin/orgs/acme", json={"display_name": "New Name"})

        assert resp.status_code == 400
