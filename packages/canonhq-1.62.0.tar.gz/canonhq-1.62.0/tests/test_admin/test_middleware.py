"""Tests for admin middleware — require_super_admin dependency."""

from __future__ import annotations

import pytest
from fastapi import HTTPException

from canon.admin.middleware import require_super_admin
from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission


class TestRequireSuperAdmin:
    async def test_anonymous_user_returns_404(self):
        """Anonymous user (is_anonymous=True) → 404."""
        anon = CurrentUser(
            sub="anonymous",
            auth_method="anonymous",
            permissions=frozenset(),
        )

        with pytest.raises(HTTPException) as exc_info:
            await require_super_admin(user=anon)

        assert exc_info.value.status_code == 404

    async def test_regular_user_without_platform_manage_returns_403(self):
        """Authenticated user without PLATFORM_MANAGE → 403."""
        user = CurrentUser(
            sub="auth0|123",
            email="user@example.com",
            auth_method="session",
            permissions=frozenset({Permission.SPECS_READ, Permission.SPECS_WRITE}),
        )

        with pytest.raises(HTTPException) as exc_info:
            await require_super_admin(user=user)

        assert exc_info.value.status_code == 403
        assert "Insufficient permissions" in exc_info.value.detail

    async def test_admin_without_platform_manage_returns_403(self):
        """Admin role (all perms except PLATFORM_MANAGE) → 403."""
        admin_perms = frozenset(p for p in Permission if p != Permission.PLATFORM_MANAGE)
        user = CurrentUser(
            sub="auth0|admin",
            email="admin@example.com",
            auth_method="session",
            permissions=admin_perms,
        )

        with pytest.raises(HTTPException) as exc_info:
            await require_super_admin(user=user)

        assert exc_info.value.status_code == 403

    async def test_super_admin_with_platform_manage_returns_user(self):
        """User with PLATFORM_MANAGE → returns the CurrentUser."""
        super_admin = CurrentUser(
            sub="auth0|superadmin",
            email="super@example.com",
            auth_method="session",
            permissions=frozenset(Permission),
        )

        result = await require_super_admin(user=super_admin)

        assert result is super_admin

    async def test_returns_exact_user_object(self):
        """Verify the returned object is the same instance, not a copy."""
        user = CurrentUser(
            sub="auth0|xyz",
            auth_method="session",
            permissions=frozenset({Permission.PLATFORM_MANAGE}),
        )

        result = await require_super_admin(user=user)

        assert result is user
