"""Tests for AdminStore cross-org query layer."""

from __future__ import annotations

from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock

from canon.admin.store import AdminStore


def _mock_pool_with_conn(mock_conn: AsyncMock) -> MagicMock:
    """Return a mock pool whose acquire() returns an async context manager."""
    mock_pool = MagicMock()

    @asynccontextmanager
    async def _acquire():
        yield mock_conn

    mock_pool.acquire = _acquire
    return mock_pool


class TestListOrgs:
    async def test_returns_list_of_dicts(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(
            return_value=[
                {
                    "login": "acme",
                    "installation_id": "42",
                    "user_count": 3,
                    "created_at": None,
                }
            ]
        )
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.list_orgs()

        assert len(result) == 1
        assert result[0]["login"] == "acme"

    async def test_uses_limit_and_offset(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.list_orgs(limit=10, offset=20)

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "LIMIT" in sql
        assert "OFFSET" in sql
        assert 10 in args
        assert 20 in args

    async def test_applies_search_filter(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.list_orgs(search="acme")

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "ILIKE" in sql
        assert any("acme" in str(a) for a in args)

    async def test_no_search_no_where_clause(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.list_orgs()

        sql = mock_conn.fetch.call_args[0][0]
        assert "WHERE" not in sql

    async def test_selects_from_gh_installations(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.list_orgs()

        sql = mock_conn.fetch.call_args[0][0]
        assert "gh_installations" in sql


class TestListOrgsAuth0Enrichment:
    """Tests for list_orgs with Auth0 provider enrichment (member counts, display_name)."""

    async def test_populates_member_count_from_auth0(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(
            return_value=[
                {
                    "login": "acme",
                    "installation_id": "1",
                    "created_at": None,
                    "status": "active",
                    "repos_count": 5,
                    "oidc_org_id": "org_abc",
                },
            ]
        )
        pool = _mock_pool_with_conn(mock_conn)

        provider = AsyncMock()
        provider.list_organizations = AsyncMock(
            return_value=[{"name": "acme", "id": "org_abc", "display_name": "Acme Corp"}]
        )
        provider.get_org_members = AsyncMock(
            return_value=[{"user_id": "auth0|1"}, {"user_id": "auth0|2"}]
        )
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.list_orgs()

        assert result[0]["member_count"] == 2
        assert result[0]["display_name"] == "Acme Corp"
        provider.get_org_members.assert_awaited_once_with("org_abc")

    async def test_member_count_survives_partial_auth0_failure(self):
        """One org failing get_org_members should not block others."""
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(
            return_value=[
                {
                    "login": "good",
                    "installation_id": "1",
                    "created_at": None,
                    "status": "active",
                    "repos_count": 0,
                    "oidc_org_id": "org_good",
                },
                {
                    "login": "bad",
                    "installation_id": "2",
                    "created_at": None,
                    "status": "active",
                    "repos_count": 0,
                    "oidc_org_id": "org_bad",
                },
            ]
        )
        pool = _mock_pool_with_conn(mock_conn)

        async def _get_members(oid: str) -> list[dict]:
            if oid == "org_bad":
                raise RuntimeError("rate limited")
            return [{"user_id": "auth0|1"}]

        provider = AsyncMock()
        provider.list_organizations = AsyncMock(
            return_value=[
                {"name": "good", "id": "org_good", "display_name": "Good"},
                {"name": "bad", "id": "org_bad", "display_name": "Bad"},
            ]
        )
        provider.get_org_members = AsyncMock(side_effect=_get_members)
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.list_orgs()

        good = next(r for r in result if r["login"] == "good")
        bad = next(r for r in result if r["login"] == "bad")
        assert good["member_count"] == 1
        assert bad["member_count"] is None  # failed, not zero

    async def test_member_count_uses_cache(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(
            return_value=[
                {
                    "login": "acme",
                    "installation_id": "1",
                    "created_at": None,
                    "status": "active",
                    "repos_count": 0,
                    "oidc_org_id": "org_abc",
                },
            ]
        )
        pool = _mock_pool_with_conn(mock_conn)

        provider = AsyncMock()
        provider.list_organizations = AsyncMock(
            return_value=[{"name": "acme", "id": "org_abc", "display_name": "Acme"}]
        )
        cache = MagicMock()
        # Cache hit: return cached members
        cache.get = MagicMock(
            side_effect=lambda k: (
                [{"user_id": "u1"}, {"user_id": "u2"}, {"user_id": "u3"}]
                if "org_members" in k
                else None
            ),
        )

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.list_orgs()

        assert result[0]["member_count"] == 3
        # Provider should NOT be called — cache hit
        provider.get_org_members.assert_not_called()


class TestGetOrg:
    async def test_returns_dict_when_found(self):
        mock_conn = AsyncMock()
        row = {"login": "acme", "installation_id": "1", "user_count": 2, "created_at": None}
        mock_conn.fetchrow = AsyncMock(return_value=row)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_org("acme")

        assert result is not None
        assert result["login"] == "acme"

    async def test_returns_none_when_not_found(self):
        mock_conn = AsyncMock()
        mock_conn.fetchrow = AsyncMock(return_value=None)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_org("nonexistent")

        assert result is None

    async def test_passes_org_as_parameter(self):
        mock_conn = AsyncMock()
        mock_conn.fetchrow = AsyncMock(return_value=None)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.get_org("test-org")

        args = mock_conn.fetchrow.call_args[0]
        assert "test-org" in args


class TestListUsers:
    async def test_returns_list_of_dicts(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(
            return_value=[
                {
                    "id": 1,
                    "oidc_sub": "auth0|123",
                    "name": "alice",
                    "email": "alice@example.com",
                    "role": "editor",
                    "created_at": None,
                    "last_login_at": None,
                }
            ]
        )
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.list_users()

        assert len(result) == 1
        assert result[0]["login"] == "alice"

    async def test_org_filter_is_ignored(self):
        """Users table has no org_login — org param is silently ignored."""
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.list_users(org="acme")

        assert result == []

    async def test_applies_role_filter(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.list_users(role="admin")

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "role" in sql
        assert "admin" in args

    async def test_applies_search_filter(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.list_users(search="alice")

        sql = mock_conn.fetch.call_args[0][0]
        assert "ILIKE" in sql

    async def test_uses_limit_and_offset(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.list_users(limit=25, offset=100)

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "LIMIT" in sql
        assert "OFFSET" in sql
        assert 25 in args
        assert 100 in args

    async def test_selects_from_users(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.list_users()

        sql = mock_conn.fetch.call_args[0][0]
        assert "FROM users" in sql


class TestGetUser:
    async def test_returns_dict_when_found(self):
        mock_conn = AsyncMock()
        row = {
            "id": 7,
            "oidc_sub": "auth0|7",
            "name": "bob",
            "email": "bob@example.com",
            "role": "viewer",
            "created_at": None,
            "last_login_at": None,
        }
        mock_conn.fetchrow = AsyncMock(return_value=row)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_user(7)

        assert result is not None
        assert result["id"] == 7

    async def test_returns_none_when_not_found(self):
        mock_conn = AsyncMock()
        mock_conn.fetchrow = AsyncMock(return_value=None)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_user(9999)

        assert result is None

    async def test_passes_user_id_as_parameter(self):
        mock_conn = AsyncMock()
        mock_conn.fetchrow = AsyncMock(return_value=None)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.get_user(42)

        args = mock_conn.fetchrow.call_args[0]
        assert 42 in args


class TestUpdateUserRole:
    async def test_issues_update_returning(self):
        mock_conn = AsyncMock()
        row = {
            "id": 1,
            "oidc_sub": "auth0|1",
            "name": "alice",
            "email": "alice@example.com",
            "role": "admin",
            "created_at": None,
            "last_login_at": None,
        }
        mock_conn.fetchrow = AsyncMock(return_value=row)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.update_user_role(1, "admin")

        assert result is not None
        assert result["role"] == "admin"

    async def test_passes_new_role_and_user_id(self):
        mock_conn = AsyncMock()
        mock_conn.fetchrow = AsyncMock(return_value=None)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.update_user_role(5, "editor")

        sql = mock_conn.fetchrow.call_args[0][0]
        args = mock_conn.fetchrow.call_args[0][1:]
        assert "UPDATE users" in sql
        assert "SET role" in sql
        assert "editor" in args
        assert 5 in args

    async def test_returns_none_when_not_found(self):
        mock_conn = AsyncMock()
        mock_conn.fetchrow = AsyncMock(return_value=None)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.update_user_role(999, "admin")

        assert result is None


class TestGetKPIs:
    async def test_returns_dict_with_counts(self):
        mock_conn = AsyncMock()
        # get_kpis makes 3 fetchval calls: org_count, user_count, spec_count
        mock_conn.fetchval = AsyncMock(side_effect=[10, 50, 100])
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_kpis()

        assert result["org_count"] == 10
        assert result["user_count"] == 50
        assert result["spec_count"] == 100
        assert result["avg_coverage_pct"] == 0.0  # not yet wired

    async def test_returns_zeros_when_no_data(self):
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=0)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_kpis()

        assert result["org_count"] == 0
        assert result["user_count"] == 0

    async def test_queries_correct_tables(self):
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=0)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        await store.get_kpis()

        # Should have called fetchval at least twice (org_count, user_count)
        assert mock_conn.fetchval.call_count >= 2


class TestGetHealthSummary:
    async def test_returns_list_of_dicts(self):
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=0)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_health_summary()

        assert isinstance(result, list)
        assert all("name" in r and "healthy" in r for r in result)

    async def test_healthy_when_no_errors(self):
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=0)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_health_summary()

        assert all(r["healthy"] for r in result)

    async def test_unhealthy_when_errors_present(self):
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=5)
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_health_summary()

        assert any(not r["healthy"] for r in result)

    async def test_graceful_on_query_error(self):
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(side_effect=Exception("DB error"))
        pool = _mock_pool_with_conn(mock_conn)
        store = AdminStore(pool)

        result = await store.get_health_summary()

        # Should not raise; returns degraded results
        assert isinstance(result, list)
        assert all(not r["healthy"] for r in result)
