"""Tests for admin deactivation and suspension store methods."""

from __future__ import annotations

from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock

from canon.admin.store import AdminStore


def _mock_pool(conn: AsyncMock) -> MagicMock:
    pool = MagicMock()

    @asynccontextmanager
    async def _acquire():
        yield conn

    pool.acquire = _acquire
    return pool


class TestDeactivateUser:
    async def test_sets_status_to_deactivated(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|1",
                "email": "a@b.com",
                "name": "Test",
                "role": "editor",
                "status": "deactivated",
                "created_at": None,
                "last_login_at": None,
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.deactivate_user(1)

        assert result is not None
        assert result["status"] == "deactivated"
        sql = conn.fetchrow.call_args[0][0]
        assert "status = 'deactivated'" in sql

    async def test_returns_none_if_user_not_found(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value=None)
        store = AdminStore(_mock_pool(conn))

        result = await store.deactivate_user(999)

        assert result is None


class TestReactivateUser:
    async def test_sets_status_to_active(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|1",
                "email": "a@b.com",
                "name": "Test",
                "role": "editor",
                "status": "active",
                "created_at": None,
                "last_login_at": None,
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.reactivate_user(1)

        assert result is not None
        assert result["status"] == "active"


class TestSuspendOrg:
    async def test_sets_status_to_suspended(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "installation_id": 123,
                "org_login": "acme",
                "status": "suspended",
                "installed_at": None,
                "repos_count": 5,
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.suspend_org("acme")

        assert result is not None
        assert result["status"] == "suspended"

    async def test_returns_none_if_org_not_found(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value=None)
        store = AdminStore(_mock_pool(conn))

        result = await store.suspend_org("nonexistent")

        assert result is None


class TestReactivateOrg:
    async def test_sets_status_to_active(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "installation_id": 123,
                "org_login": "acme",
                "status": "active",
                "installed_at": None,
                "repos_count": 5,
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.reactivate_org("acme")

        assert result is not None
        assert result["status"] == "active"


class TestDeleteUserAtomic:
    def _txn_pool(self, conn: AsyncMock) -> MagicMock:
        """Pool that exposes ``conn.transaction()`` as an async context manager."""
        pool = _mock_pool(conn)

        @asynccontextmanager
        async def _txn():
            yield None

        conn.transaction = _txn
        return pool

    async def test_deletes_user_and_returns_snapshot(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 42,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "name": "Test User",
                "role": "editor",
                "status": "active",
                "created_at": None,
                "last_login_at": None,
            }
        )
        conn.execute = AsyncMock(return_value="DELETE 1")
        store = AdminStore(self._txn_pool(conn))

        auth0_delete = AsyncMock()
        snapshot = await store.delete_user_atomic(42, auth0_delete=auth0_delete)

        assert snapshot is not None
        assert snapshot["oidc_sub"] == "auth0|abc"
        assert snapshot["email"] == "u@e.com"
        auth0_delete.assert_awaited_once_with("auth0|abc")

    async def test_returns_none_when_user_missing(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value=None)
        conn.execute = AsyncMock()
        store = AdminStore(self._txn_pool(conn))

        result = await store.delete_user_atomic(999, auth0_delete=AsyncMock())

        assert result is None
        conn.execute.assert_not_called()

    async def test_propagates_auth0_failure(self):
        """Auth0 failure must bubble out (DB delete is already committed)."""
        import pytest

        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 42,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "name": "T",
                "role": "editor",
                "status": "active",
                "created_at": None,
                "last_login_at": None,
            }
        )
        conn.execute = AsyncMock(return_value="DELETE 1")
        store = AdminStore(self._txn_pool(conn))

        auth0_delete = AsyncMock(side_effect=RuntimeError("auth0 down"))

        with pytest.raises(RuntimeError, match="auth0 down"):
            await store.delete_user_atomic(42, auth0_delete=auth0_delete)

    async def test_skips_auth0_when_no_oidc_sub(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 42,
                "oidc_sub": "",
                "email": "u@e.com",
                "name": "T",
                "role": "editor",
                "status": "active",
                "created_at": None,
                "last_login_at": None,
            }
        )
        conn.execute = AsyncMock(return_value="DELETE 1")
        store = AdminStore(self._txn_pool(conn))

        auth0_delete = AsyncMock()
        snapshot = await store.delete_user_atomic(42, auth0_delete=auth0_delete)

        assert snapshot is not None
        auth0_delete.assert_not_called()

    async def test_returns_none_on_concurrent_delete(self):
        """If the row vanished between SELECT and DELETE, abort cleanly."""
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 42,
                "oidc_sub": "auth0|abc",
                "email": "u@e.com",
                "name": "T",
                "role": "editor",
                "status": "active",
                "created_at": None,
                "last_login_at": None,
            }
        )
        conn.execute = AsyncMock(return_value="DELETE 0")
        store = AdminStore(self._txn_pool(conn))

        auth0_delete = AsyncMock()
        result = await store.delete_user_atomic(42, auth0_delete=auth0_delete)

        assert result is None
        auth0_delete.assert_not_called()


class TestOrgMetadata:
    async def test_get_org_metadata_returns_row(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "primary_contact_email": "ops@acme.com",
                "primary_contact_name": "Ops Team",
                "support_notes": "Migrating Q2",
                "updated_at": None,
                "updated_by_sub": "auth0|admin",
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.get_org_metadata("acme")

        assert result["primary_contact_email"] == "ops@acme.com"
        assert "organizations_meta" in conn.fetchrow.call_args[0][0]

    async def test_get_org_metadata_returns_empty_when_missing(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value=None)
        store = AdminStore(_mock_pool(conn))

        assert await store.get_org_metadata("acme") == {}

    async def test_update_org_metadata_upserts(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "primary_contact_email": "new@acme.com",
                "primary_contact_name": "New Contact",
                "support_notes": "Updated",
                "updated_at": None,
                "updated_by_sub": "auth0|admin",
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.update_org_metadata(
            "acme",
            primary_contact_email="new@acme.com",
            primary_contact_name="New Contact",
            support_notes="Updated",
            updated_by_sub="auth0|admin",
        )

        assert result["primary_contact_email"] == "new@acme.com"
        sql = conn.fetchrow.call_args[0][0]
        assert "ON CONFLICT" in sql
        assert "COALESCE" in sql
        # All five positional params plus the org name
        assert conn.fetchrow.call_args[0][1] == "acme"

    async def test_update_org_metadata_partial_keeps_other_fields(self):
        """COALESCE means None args don't overwrite existing values."""
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "primary_contact_email": "kept@acme.com",
                "primary_contact_name": "Kept",
                "support_notes": "New notes",
                "updated_at": None,
                "updated_by_sub": "auth0|admin",
            }
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.update_org_metadata(
            "acme",
            support_notes="New notes",
            updated_by_sub="auth0|admin",
        )

        assert result["primary_contact_email"] == "kept@acme.com"
        # Args 2 and 3 (email, name) should be None
        args = conn.fetchrow.call_args[0]
        assert args[2] is None  # primary_contact_email
        assert args[3] is None  # primary_contact_name
        assert args[4] == "New notes"
