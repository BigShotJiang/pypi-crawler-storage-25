"""Tests for SRE alert data models."""

from __future__ import annotations

from canon.alerts.models import AlertMessage, AlertSeverity


class TestAlertSeverity:
    def test_severity_ordering(self):
        assert AlertSeverity.CRITICAL.value > AlertSeverity.HIGH.value
        assert AlertSeverity.HIGH.value > AlertSeverity.MEDIUM.value
        assert AlertSeverity.MEDIUM.value > AlertSeverity.LOW.value

    def test_severity_emoji(self):
        assert AlertSeverity.CRITICAL.emoji == "\U0001f534"
        assert AlertSeverity.HIGH.emoji == "\U0001f7e0"
        assert AlertSeverity.MEDIUM.emoji == "\U0001f7e1"
        assert AlertSeverity.LOW.emoji == "\U0001f535"


class TestAlertMessage:
    def test_create_alert_message(self):
        msg = AlertMessage(
            severity=AlertSeverity.HIGH,
            title="Exception spike",
            summary="15 exceptions in 5 minutes",
            endpoint="/webhook",
            posthog_url="https://us.posthog.com/project/1/error/abc",
        )
        assert msg.severity == AlertSeverity.HIGH
        assert msg.title == "Exception spike"
        assert msg.endpoint == "/webhook"

    def test_alert_message_optional_fields(self):
        msg = AlertMessage(
            severity=AlertSeverity.MEDIUM,
            title="New error",
            summary="KeyError in handler",
        )
        assert msg.endpoint is None
        assert msg.posthog_url is None
        assert msg.spec_link is None

    def test_to_slack_block(self):
        msg = AlertMessage(
            severity=AlertSeverity.HIGH,
            title="Exception spike",
            summary="15 exceptions in 5 minutes",
            endpoint="/webhook",
            posthog_url="https://us.posthog.com/project/1/error/abc",
        )
        blocks = msg.to_slack_blocks()
        assert isinstance(blocks, list)
        assert len(blocks) >= 1
        header_text = blocks[0]["text"]["text"]
        assert "Exception spike" in header_text
