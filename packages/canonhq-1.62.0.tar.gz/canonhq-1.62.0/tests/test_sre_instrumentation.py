"""Tests for SRE instrumentation (PostHog event tracking)."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from canon.agent.client import AgentAPIError, AgentConfig, ClaudeClient
from canon.analytics import estimate_cost
from canon.db.query_hooks import log_slow_query
from canon.web.middleware import (
    RateLimitMiddleware,
    RequestLoggingMiddleware,
    SecurityBlockMiddleware,
)


class TestRequestCompletedTracking:
    def test_tracks_request_completed_event(self):
        from starlette.applications import Starlette
        from starlette.responses import PlainTextResponse
        from starlette.routing import Route
        from starlette.testclient import TestClient

        def homepage(request):
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/api/test", homepage)])
        app = RequestLoggingMiddleware(app)

        with patch("canon.web.middleware.analytics") as mock_analytics:
            client = TestClient(app)
            resp = client.get("/api/test")
            assert resp.status_code == 200

            mock_analytics.track.assert_called_once()
            call_args = mock_analytics.track.call_args
            assert call_args[0][0] == "request_completed"
            props = call_args[1]["properties"]
            assert props["method"] == "GET"
            assert props["path"] == "/api/test"
            assert props["status_code"] == 200
            assert props["is_error"] is False
            assert "duration_ms" in props

    def test_skips_health_check_tracking(self):
        from starlette.applications import Starlette
        from starlette.responses import PlainTextResponse
        from starlette.routing import Route
        from starlette.testclient import TestClient

        def healthz(request):
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/healthz", healthz)])
        app = RequestLoggingMiddleware(app)

        with patch("canon.web.middleware.analytics") as mock_analytics:
            client = TestClient(app)
            client.get("/healthz")
            mock_analytics.track.assert_not_called()


class TestRateLimitHitTracking:
    def test_tracks_rate_limit_hit(self):
        from starlette.applications import Starlette
        from starlette.responses import PlainTextResponse
        from starlette.routing import Route
        from starlette.testclient import TestClient

        def search(request):
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/api/search", search)])
        app = RateLimitMiddleware(app, path_prefix="/api/search", max_requests=1, window_seconds=60)

        with patch("canon.web.middleware.analytics") as mock_analytics:
            client = TestClient(app)
            client.get("/api/search")
            resp = client.get("/api/search")
            assert resp.status_code == 429

            rate_limit_calls = [
                c for c in mock_analytics.track.call_args_list if c[0][0] == "rate_limit_hit"
            ]
            assert len(rate_limit_calls) == 1
            props = rate_limit_calls[0][1]["properties"]
            assert props["path"] == "/api/search"
            assert props["limit"] == 1
            assert props["window"] == 60


class TestAgentCallTracking:
    def test_tracks_successful_agent_call(self):
        from unittest.mock import MagicMock

        client = ClaudeClient(api_key="test-key")

        mock_response = MagicMock()
        mock_response.content = [MagicMock(type="text", text="response")]
        mock_response.usage.input_tokens = 100
        mock_response.usage.output_tokens = 50
        client._client = MagicMock()
        client._client.messages.create.return_value = mock_response

        with patch("canon.agent.client.analytics") as mock_analytics:
            mock_analytics.estimate_cost.return_value = (0.0003, 0.00075)
            client.complete("system", "user", AgentConfig())

            mock_analytics.track.assert_called_once()
            call_args = mock_analytics.track.call_args
            assert call_args[0][0] == "agent_call_completed"
            props = call_args[1]["properties"]
            assert props["model"] == "claude-sonnet-4-6"
            assert props["input_tokens"] == 100
            assert props["output_tokens"] == 50
            assert props["input_cost_usd"] == 0.0003
            assert props["output_cost_usd"] == 0.00075
            assert props["total_cost_usd"] == 0.00105
            assert props["success"] is True
            assert "duration_ms" in props

    def test_tracks_failed_agent_call(self):
        from unittest.mock import MagicMock

        import anthropic as anthropic_mod

        client = ClaudeClient(api_key="test-key")
        client._client = MagicMock()
        client._client.messages.create.side_effect = anthropic_mod.APIError(
            message="Rate limited", request=MagicMock(), body=None
        )

        with patch("canon.agent.client.analytics") as mock_analytics:
            mock_analytics.estimate_cost.return_value = (0.0, 0.0)
            with pytest.raises(AgentAPIError):
                client.complete("system", "user", AgentConfig())

            mock_analytics.track.assert_called_once()
            props = mock_analytics.track.call_args[1]["properties"]
            assert props["success"] is False
            assert props["error_message"] != ""


class TestHealthCheckFailedTracking:
    @pytest.mark.asyncio
    async def test_tracks_health_check_failure(self):
        from unittest.mock import AsyncMock, MagicMock

        from httpx import ASGITransport, AsyncClient

        from canon.main import app
        from canon.settings import Settings

        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(side_effect=Exception("connection refused"))

        mock_pool = MagicMock()
        mock_pool.acquire.return_value.__aenter__ = AsyncMock(return_value=mock_conn)
        mock_pool.acquire.return_value.__aexit__ = AsyncMock(return_value=False)

        # Set up required app state for middleware
        app.state.settings = Settings(gh_app_id="x", gh_private_key="x", gh_webhook_secret="x")
        app.state.db_pool = mock_pool
        try:
            with patch("canon.main.analytics") as mock_analytics:
                async with AsyncClient(
                    transport=ASGITransport(app=app), base_url="http://test"
                ) as client:
                    resp = await client.get("/readyz")
                    assert resp.status_code == 503

                health_calls = [
                    c
                    for c in mock_analytics.track.call_args_list
                    if c[0][0] == "health_check_failed"
                ]
                assert len(health_calls) == 1
                props = health_calls[0][1]["properties"]
                assert props["check_type"] == "readiness"
                assert "connection refused" in props["error_message"]
        finally:
            app.state.db_pool = None


class TestSuperProperties:
    def test_super_properties_merged_into_track(self):
        from unittest.mock import MagicMock

        from canon import analytics

        analytics._client = MagicMock()
        analytics._super_properties = {"environment": "production", "version": "1.26.0"}
        try:
            analytics.track("test_event", properties={"foo": "bar"})
            analytics._client.capture.assert_called_once()
            props = analytics._client.capture.call_args[1]["properties"]
            assert props["environment"] == "production"
            assert props["version"] == "1.26.0"
            assert props["foo"] == "bar"
        finally:
            analytics._client = None
            analytics._super_properties = {}

    def test_event_properties_override_super(self):
        from unittest.mock import MagicMock

        from canon import analytics

        analytics._client = MagicMock()
        analytics._super_properties = {"environment": "production"}
        try:
            analytics.track("test_event", properties={"environment": "test"})
            props = analytics._client.capture.call_args[1]["properties"]
            assert props["environment"] == "test"
        finally:
            analytics._client = None
            analytics._super_properties = {}


class TestSlowQueryTracking:
    def test_tracks_slow_query(self):
        with patch("canon.db.query_hooks.analytics") as mock_analytics:
            log_slow_query(
                query="SELECT * FROM spec_documents WHERE repo = $1",
                duration_ms=750.0,
                threshold_ms=500,
            )
            mock_analytics.track.assert_called_once()
            call_args = mock_analytics.track.call_args
            assert call_args[0][0] == "db_query_slow"
            props = call_args[1]["properties"]
            assert props["duration_ms"] == 750.0
            assert "spec_documents" in props["query_type"]

    def test_skips_fast_query(self):
        with patch("canon.db.query_hooks.analytics") as mock_analytics:
            log_slow_query(
                query="SELECT 1",
                duration_ms=50.0,
                threshold_ms=500,
            )
            mock_analytics.track.assert_not_called()


class TestEstimateCost:
    def test_known_sonnet_model(self):
        input_cost, output_cost = estimate_cost("claude-sonnet-4-6", 1_000_000, 1_000_000)
        assert input_cost == pytest.approx(3.0)
        assert output_cost == pytest.approx(15.0)

    def test_known_opus_model(self):
        input_cost, output_cost = estimate_cost("claude-opus-4-20260301", 100_000, 10_000)
        assert input_cost == pytest.approx(1.5)
        assert output_cost == pytest.approx(0.75)

    def test_known_haiku_35_model(self):
        input_cost, output_cost = estimate_cost("claude-haiku-3.5-20251001", 1_000_000, 1_000_000)
        assert input_cost == pytest.approx(0.80)
        assert output_cost == pytest.approx(4.0)

    def test_longest_prefix_wins(self):
        # "claude-haiku-3.5-xxx" should match "claude-haiku-3.5" not "claude-haiku"
        cost_35 = estimate_cost("claude-haiku-3.5-20251001", 1_000_000, 0)
        cost_plain = estimate_cost("claude-haiku-20240307", 1_000_000, 0)
        assert cost_35[0] == pytest.approx(0.80)
        assert cost_plain[0] == pytest.approx(0.25)

    def test_unknown_model_returns_zero(self):
        assert estimate_cost("gpt-4o", 100_000, 50_000) == (0.0, 0.0)

    def test_zero_tokens_returns_zero(self):
        assert estimate_cost("claude-sonnet-4-6", 0, 0) == (0.0, 0.0)


class TestSecurityBlockMiddleware:
    def _make_app(self):
        from starlette.applications import Starlette
        from starlette.responses import PlainTextResponse
        from starlette.routing import Route
        from starlette.testclient import TestClient

        def homepage(request):
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/", homepage), Route("/api/test", homepage)])
        app = SecurityBlockMiddleware(app)
        return TestClient(app)

    def test_blocks_git_config(self):
        client = self._make_app()
        resp = client.get("/.git/config")
        assert resp.status_code == 404

    def test_blocks_env_file(self):
        client = self._make_app()
        resp = client.get("/.env")
        assert resp.status_code == 404

    def test_blocks_env_variants(self):
        client = self._make_app()
        for path in ["/.env.local", "/.env.production", "/.env.bak"]:
            assert client.get(path).status_code == 404

    def test_blocks_atfs_git(self):
        client = self._make_app()
        assert client.get("/@fs/.git/config").status_code == 404

    def test_blocks_wp_admin(self):
        client = self._make_app()
        assert client.get("/wp-admin/login.php").status_code == 404

    def test_blocks_case_insensitive(self):
        client = self._make_app()
        assert client.get("/.GIT/config").status_code == 404
        assert client.get("/.ENV").status_code == 404

    def test_allows_normal_paths(self):
        client = self._make_app()
        assert client.get("/").status_code == 200
        assert client.get("/api/test").status_code == 200
