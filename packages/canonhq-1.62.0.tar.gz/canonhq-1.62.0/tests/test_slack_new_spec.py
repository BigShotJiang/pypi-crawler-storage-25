"""Tests for the /canon new spec creation modal."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from canon_slack.new_spec import _slugify, handle_new_spec_submit


class TestSlugify:
    def test_basic_slug(self):
        assert _slugify("User Authentication") == "user-authentication"

    def test_special_chars(self):
        assert _slugify("Auth (v2) — JWT") == "auth-v2-jwt"

    def test_extra_spaces(self):
        assert _slugify("  my   spec  ") == "my-spec"

    def test_already_slugged(self):
        assert _slugify("auth-hardening") == "auth-hardening"


class TestNewSpecSubmit:
    @pytest.mark.asyncio
    async def test_creates_spec_in_github(self):
        ack = AsyncMock()
        view = {
            "state": {
                "values": {
                    "title_block": {"title_input": {"value": "auth-hardening"}},
                    "type_block": {
                        "type_select": {
                            "selected_option": {"value": "spec"},
                        }
                    },
                    "team_block": {
                        "team_select": {
                            "selected_option": {"value": "platform"},
                        }
                    },
                    "background_block": {
                        "background_input": {"value": "Improve auth security."},
                    },
                }
            }
        }
        body = {"user": {"id": "U123"}}
        client = AsyncMock()
        client.conversations_open = AsyncMock(return_value={"channel": {"id": "D999"}})

        mock_gh = AsyncMock()
        mock_settings = MagicMock()
        mock_settings.github_owner = "owner"
        mock_settings.github_repo = "repo"

        with (
            patch("canon.main._get_client", return_value=mock_gh),
            patch("canon.main.settings", mock_settings),
            patch("canon.main.app", MagicMock(state=MagicMock(identity_store=None))),
        ):
            await handle_new_spec_submit(ack, view, client, body)

        ack.assert_called_once()
        mock_gh.create_or_update_file.assert_called_once()
        call_args = mock_gh.create_or_update_file.call_args[0]
        assert call_args[0] == "owner"
        assert call_args[1] == "repo"
        assert call_args[2] == "docs/specs/auth-hardening.md"
        content = call_args[3]
        assert 'title: "auth-hardening"' in content
        assert "team: " in content

    @pytest.mark.asyncio
    async def test_handles_github_failure(self):
        ack = AsyncMock()
        view = {
            "state": {
                "values": {
                    "title_block": {"title_input": {"value": "test-spec"}},
                    "type_block": {
                        "type_select": {
                            "selected_option": {"value": "spec"},
                        }
                    },
                    "team_block": {
                        "team_select": {
                            "selected_option": {"value": "default"},
                        }
                    },
                    "background_block": {"background_input": {"value": ""}},
                }
            }
        }
        body = {"user": {"id": "U123"}}
        client = AsyncMock()
        client.conversations_open = AsyncMock(return_value={"channel": {"id": "D999"}})

        mock_gh = AsyncMock()
        mock_gh.create_or_update_file = AsyncMock(side_effect=Exception("API error"))
        mock_settings = MagicMock()
        mock_settings.github_owner = "owner"
        mock_settings.github_repo = "repo"

        with (
            patch("canon.main._get_client", return_value=mock_gh),
            patch("canon.main.settings", mock_settings),
            patch("canon.main.app", MagicMock(state=MagicMock(identity_store=None))),
        ):
            await handle_new_spec_submit(ack, view, client, body)

        ack.assert_called_once()
        # Should DM user with error
        dm_calls = [
            c
            for c in client.chat_postMessage.call_args_list
            if "Failed" in c[1].get("text", "") or "failed" in c[1].get("text", "").lower()
        ]
        assert len(dm_calls) >= 1

    @pytest.mark.asyncio
    async def test_curly_braces_in_background_do_not_crash(self):
        """User input with {curly braces} should not cause a KeyError."""
        ack = AsyncMock()
        view = {
            "state": {
                "values": {
                    "title_block": {"title_input": {"value": "brace-test"}},
                    "type_block": {
                        "type_select": {"selected_option": {"value": "spec"}},
                    },
                    "team_block": {
                        "team_select": {"selected_option": {"value": "platform"}},
                    },
                    "background_block": {
                        "background_input": {"value": "Use {this} pattern for {RFC-1234}."},
                    },
                }
            }
        }
        body = {"user": {"id": "U123"}}
        client = AsyncMock()
        client.conversations_open = AsyncMock(return_value={"channel": {"id": "D999"}})

        mock_gh = AsyncMock()
        mock_settings = MagicMock()
        mock_settings.github_owner = "owner"
        mock_settings.github_repo = "repo"

        with (
            patch("canon.main._get_client", return_value=mock_gh),
            patch("canon.main.settings", mock_settings),
            patch("canon.main.app", MagicMock(state=MagicMock(identity_store=None))),
        ):
            await handle_new_spec_submit(ack, view, client, body)

        mock_gh.create_or_update_file.assert_called_once()
        content = mock_gh.create_or_update_file.call_args[0][3]
        assert "{this}" in content
        assert "{RFC-1234}" in content
