"""Tests for /canon mute and /canon unmute commands."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from canon_slack.commands import get_muted_specs, mute_handler, unmute_handler
from canon_slack.mute_store import MuteStore


@pytest.fixture(autouse=True)
def _mock_mute_store(tmp_path):
    """Use a temp MuteStore for each test."""
    store = MuteStore(tmp_path / "mutes.json")
    with patch("canon_slack.commands._get_mute_store", return_value=store):
        yield store


class TestMuteHandler:
    @pytest.mark.asyncio
    async def test_mute_no_args_shows_usage(self):
        ack = AsyncMock()
        respond = AsyncMock()
        await mute_handler(ack, respond, "", {"user_id": "U123"})
        ack.assert_called_once()
        respond.assert_called_once()
        assert "Usage" in respond.call_args[1]["blocks"][0]["text"]["text"]

    @pytest.mark.asyncio
    async def test_mute_adds_to_store(self):
        ack = AsyncMock()
        respond = AsyncMock()
        await mute_handler(ack, respond, "auth-hardening", {"user_id": "U123"})
        assert "auth-hardening" in get_muted_specs("U123")
        assert "Muted" in respond.call_args[1]["blocks"][0]["text"]["text"]

    @pytest.mark.asyncio
    async def test_mute_multiple_specs(self):
        ack = AsyncMock()
        respond = AsyncMock()
        await mute_handler(ack, respond, "spec-a", {"user_id": "U123"})
        await mute_handler(ack, respond, "spec-b", {"user_id": "U123"})
        assert get_muted_specs("U123") == {"spec-a", "spec-b"}


class TestUnmuteHandler:
    @pytest.mark.asyncio
    async def test_unmute_no_args_shows_usage(self):
        ack = AsyncMock()
        respond = AsyncMock()
        await unmute_handler(ack, respond, "", {"user_id": "U123"})
        ack.assert_called_once()
        assert "Usage" in respond.call_args[1]["blocks"][0]["text"]["text"]

    @pytest.mark.asyncio
    async def test_unmute_removes_from_store(self):
        ack = AsyncMock()
        respond = AsyncMock()
        # First mute, then unmute
        await mute_handler(ack, respond, "auth-hardening", {"user_id": "U123"})
        assert "auth-hardening" in get_muted_specs("U123")
        await unmute_handler(ack, respond, "auth-hardening", {"user_id": "U123"})
        assert "auth-hardening" not in get_muted_specs("U123")

    @pytest.mark.asyncio
    async def test_unmute_nonexistent_is_noop(self):
        ack = AsyncMock()
        respond = AsyncMock()
        await unmute_handler(ack, respond, "nonexistent", {"user_id": "U123"})
        assert get_muted_specs("U123") == set()


class TestGetMutedSpecs:
    def test_returns_empty_for_unknown_user(self):
        assert get_muted_specs("UNKNOWN") == set()
