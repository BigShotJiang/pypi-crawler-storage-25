"""Tests for Auth0 OIDC provider implementation."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

from canon.auth.providers.auth0 import Auth0Provider
from canon.auth.providers.protocol import (
    DeviceCodeResponse,
    OIDCProvider,
    Pending,
    TokenSet,
)
from canon.settings import Settings


def _settings(**overrides) -> Settings:
    defaults = dict(
        auth0_domain="test.us.auth0.com",
        auth0_client_id="client-id",
        auth0_client_secret="client-secret",
        auth0_audience="https://api.example.com",
        auth0_device_client_id="device-client-id",
    )
    defaults.update(overrides)
    return Settings(**defaults)


class TestAuth0ProviderProtocol:
    def test_implements_protocol(self):
        provider = Auth0Provider(settings=_settings())
        assert isinstance(provider, OIDCProvider)


class TestGetLoginUrl:
    async def test_returns_authorize_url(self):
        provider = Auth0Provider(settings=_settings())
        url = await provider.get_login_url(
            redirect_uri="https://example.com/callback",
            state="abc",
        )
        assert "test.us.auth0.com" in url
        assert "authorize" in url
        assert "client-id" in url

    async def test_includes_org_hint(self):
        provider = Auth0Provider(settings=_settings())
        url = await provider.get_login_url(
            redirect_uri="https://example.com/callback",
            state="abc",
            org_hint="org_123",
        )
        assert "organization=org_123" in url


class TestExchangeCode:
    async def test_returns_token_set(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "access_token": "at",
            "id_token": "it",
            "refresh_token": "rt",
            "expires_in": 3600,
        }
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        result = await provider.exchange_code(
            code="auth-code",
            redirect_uri="https://example.com/callback",
        )
        assert isinstance(result, TokenSet)
        assert result.access_token == "at"


class TestGetJwksUri:
    async def test_returns_auth0_jwks_url(self):
        provider = Auth0Provider(settings=_settings())
        url = await provider.get_jwks_uri()
        assert url == "https://test.us.auth0.com/.well-known/jwks.json"


class TestGetLogoutUrl:
    async def test_returns_auth0_logout_url(self):
        provider = Auth0Provider(settings=_settings())
        url = await provider.get_logout_url(return_to="https://example.com")
        assert "test.us.auth0.com" in url
        assert "v2/logout" in url
        assert "returnTo=https" in url


class TestGetDeviceCode:
    async def test_returns_device_code_response(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "device_code": "dc-123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://test.us.auth0.com/activate",
            "verification_uri_complete": "https://test.us.auth0.com/activate?user_code=ABCD-1234",
            "interval": 5,
            "expires_in": 900,
        }
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        result = await provider.get_device_code(
            audience="https://api.example.com",
            scope="openid profile email offline_access",
        )
        assert isinstance(result, DeviceCodeResponse)
        assert result.device_code == "dc-123"
        # Default call should not include the `organization` param.
        posted = mock_http.post.call_args
        assert "organization" not in posted.kwargs["data"]

    async def test_forwards_organization_when_provided(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "device_code": "dc-123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://test.us.auth0.com/activate",
            "verification_uri_complete": "https://test.us.auth0.com/activate?user_code=ABCD-1234",
            "interval": 5,
            "expires_in": 900,
        }
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        await provider.get_device_code(organization="org_abc123")

        posted = mock_http.post.call_args
        assert posted.kwargs["data"]["organization"] == "org_abc123"


class TestPollDeviceToken:
    async def test_returns_pending(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 403
        mock_resp.json.return_value = {"error": "authorization_pending"}
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        result = await provider.poll_device_token("dc-123")
        assert isinstance(result, Pending)

    async def test_returns_token_set_on_approval(self):
        provider = Auth0Provider(settings=_settings())
        mock_http = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "access_token": "at",
            "id_token": "it",
            "refresh_token": "rt",
            "expires_in": 86400,
        }
        mock_http.post = AsyncMock(return_value=mock_resp)
        provider._http = mock_http

        result = await provider.poll_device_token("dc-123")
        assert isinstance(result, TokenSet)
        assert result.access_token == "at"


class TestGetUserOrgs:
    async def test_returns_org_list(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        # Token request
        token_resp = MagicMock()
        token_resp.status_code = 200
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        # Orgs request
        orgs_resp = MagicMock()
        orgs_resp.status_code = 200
        orgs_resp.json.return_value = [{"id": "org_1", "name": "my-org", "display_name": "My Org"}]
        orgs_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(return_value=token_resp)
        mock_http.get = AsyncMock(return_value=orgs_resp)
        provider._http = mock_http

        orgs = await provider.get_user_orgs("auth0|123")
        assert len(orgs) == 1
        assert orgs[0].id == "org_1"

    async def test_returns_empty_without_m2m_credentials(self):
        provider = Auth0Provider(settings=_settings())
        orgs = await provider.get_user_orgs("auth0|123")
        assert orgs == []


class TestGetConnectionByName:
    async def test_returns_connection_id(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        conn_resp = MagicMock()
        conn_resp.json.return_value = [{"id": "con_abc123", "name": "github"}]
        conn_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(return_value=token_resp)
        mock_http.get = AsyncMock(return_value=conn_resp)
        provider._http = mock_http

        result = await provider.get_connection_by_name("github")
        assert result == "con_abc123"
        mock_http.get.assert_awaited_once()
        call_args = mock_http.get.call_args
        assert "/api/v2/connections" in call_args[0][0]
        assert call_args[1]["params"]["name"] == "github"


class TestCreateOrganization:
    async def test_creates_org_and_returns_id(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        org_resp = MagicMock()
        org_resp.json.return_value = {"id": "org_xyz", "name": "my-org"}
        org_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(side_effect=[token_resp, org_resp])
        provider._http = mock_http

        result = await provider.create_organization(name="my-org", display_name="My Org")
        assert result == "org_xyz"
        # Second post call is the create org
        create_call = mock_http.post.call_args_list[1]
        assert "/api/v2/organizations" in create_call[0][0]
        assert create_call[1]["json"]["name"] == "my-org"


class TestUpdateOrganization:
    async def test_patches_display_name(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(return_value=token_resp)
        patch_resp = MagicMock()
        patch_resp.json.return_value = {"id": "org_xyz", "display_name": "New Name"}
        patch_resp.raise_for_status = MagicMock()
        mock_http.patch = AsyncMock(return_value=patch_resp)
        provider._http = mock_http

        result = await provider.update_organization("org_xyz", display_name="New Name")
        assert result["display_name"] == "New Name"
        patch_call = mock_http.patch.call_args
        assert "/api/v2/organizations/org_xyz" in patch_call[0][0]
        assert patch_call[1]["json"] == {"display_name": "New Name"}

    async def test_patches_metadata_only(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(return_value=token_resp)
        patch_resp = MagicMock()
        patch_resp.json.return_value = {"id": "org_xyz"}
        patch_resp.raise_for_status = MagicMock()
        mock_http.patch = AsyncMock(return_value=patch_resp)
        provider._http = mock_http

        await provider.update_organization("org_xyz", metadata={"plan": "enterprise"})
        assert mock_http.patch.call_args[1]["json"] == {"metadata": {"plan": "enterprise"}}

    async def test_empty_patch_returns_current_state(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(return_value=token_resp)
        get_resp = MagicMock()
        get_resp.json.return_value = {"id": "org_xyz", "display_name": "Existing"}
        get_resp.raise_for_status = MagicMock()
        mock_http.get = AsyncMock(return_value=get_resp)
        mock_http.patch = AsyncMock()
        provider._http = mock_http

        result = await provider.update_organization("org_xyz")
        assert result["display_name"] == "Existing"
        mock_http.patch.assert_not_called()

    async def test_requires_m2m_client(self):
        provider = Auth0Provider(settings=_settings())
        import pytest

        with pytest.raises(RuntimeError, match="M2M"):
            await provider.update_organization("org_xyz", display_name="X")


class TestDeleteUser:
    async def test_deletes_user(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        del_resp = MagicMock()
        del_resp.status_code = 204
        del_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(return_value=token_resp)
        mock_http.delete = AsyncMock(return_value=del_resp)
        provider._http = mock_http

        await provider.delete_user("auth0|user_1")

        del_call = mock_http.delete.call_args
        assert "/api/v2/users/auth0%7Cuser_1" in del_call[0][0]

    async def test_treats_404_as_success(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        del_resp = MagicMock()
        del_resp.status_code = 404
        del_resp.raise_for_status = MagicMock(side_effect=Exception("should not be called"))
        mock_http.post = AsyncMock(return_value=token_resp)
        mock_http.delete = AsyncMock(return_value=del_resp)
        provider._http = mock_http

        # Should NOT raise — 404 means already deleted
        await provider.delete_user("auth0|gone")

    async def test_requires_m2m_client(self):
        import pytest

        provider = Auth0Provider(settings=_settings())
        with pytest.raises(RuntimeError, match="M2M"):
            await provider.delete_user("auth0|user_1")


class TestOrgMembership:
    async def test_add_org_member(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        add_resp = MagicMock()
        add_resp.status_code = 201
        add_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(side_effect=[token_resp, add_resp])
        provider._http = mock_http

        await provider.add_org_member(org_id="org_xyz", user_id="auth0|abc")

        add_call = mock_http.post.call_args_list[1]
        assert "/api/v2/organizations/org_xyz/members" in add_call[0][0]
        assert add_call[1]["json"] == {"members": ["auth0|abc"]}

    async def test_add_org_member_treats_409_as_success(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        add_resp = MagicMock()
        add_resp.status_code = 409
        add_resp.raise_for_status = MagicMock(side_effect=Exception("should not be called"))
        mock_http.post = AsyncMock(side_effect=[token_resp, add_resp])
        provider._http = mock_http

        # Already a member — must not raise
        await provider.add_org_member(org_id="org_xyz", user_id="auth0|abc")

    async def test_remove_org_member(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        rm_resp = MagicMock()
        rm_resp.status_code = 204
        rm_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(return_value=token_resp)
        mock_http.request = AsyncMock(return_value=rm_resp)
        provider._http = mock_http

        await provider.remove_org_member(org_id="org_xyz", user_id="auth0|abc")

        rm_call = mock_http.request.call_args
        assert rm_call[0][0] == "DELETE"
        assert "/api/v2/organizations/org_xyz/members" in rm_call[0][1]
        assert rm_call[1]["json"] == {"members": ["auth0|abc"]}

    async def test_remove_org_member_treats_404_as_success(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        rm_resp = MagicMock()
        rm_resp.status_code = 404
        rm_resp.raise_for_status = MagicMock(side_effect=Exception("should not be called"))
        mock_http.post = AsyncMock(return_value=token_resp)
        mock_http.request = AsyncMock(return_value=rm_resp)
        provider._http = mock_http

        # Not a member — must not raise
        await provider.remove_org_member(org_id="org_xyz", user_id="auth0|abc")

    async def test_membership_requires_m2m_client(self):
        import pytest

        provider = Auth0Provider(settings=_settings())
        with pytest.raises(RuntimeError, match="M2M"):
            await provider.add_org_member(org_id="x", user_id="auth0|abc")
        with pytest.raises(RuntimeError, match="M2M"):
            await provider.remove_org_member(org_id="x", user_id="auth0|abc")


class TestCreateInvitation:
    async def test_creates_invitation_with_required_fields(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        invite_resp = MagicMock()
        invite_resp.json.return_value = {
            "id": "invite_xyz",
            "invitation_url": "https://test.us.auth0.com/invite/xyz",
        }
        invite_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(side_effect=[token_resp, invite_resp])
        provider._http = mock_http

        result = await provider.create_invitation(
            org_id="org_xyz",
            inviter_name="Admin",
            invitee_email="user@example.com",
        )

        assert result["invitation_url"].endswith("/invite/xyz")
        invite_call = mock_http.post.call_args_list[1]
        assert "/api/v2/organizations/org_xyz/invitations" in invite_call[0][0]
        body = invite_call[1]["json"]
        assert body["inviter"] == {"name": "Admin"}
        assert body["invitee"] == {"email": "user@example.com"}
        assert body["client_id"] == "client-id"
        assert body["send_invitation_email"] is True

    async def test_passes_optional_connection_id_and_roles(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        invite_resp = MagicMock()
        invite_resp.json.return_value = {"id": "i"}
        invite_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(side_effect=[token_resp, invite_resp])
        provider._http = mock_http

        await provider.create_invitation(
            org_id="org_xyz",
            inviter_name="Admin",
            invitee_email="user@example.com",
            connection_id="conn_db",
            roles=["role_1"],
        )
        body = mock_http.post.call_args_list[1][1]["json"]
        assert body["connection_id"] == "conn_db"
        assert body["roles"] == ["role_1"]

    async def test_requires_m2m_client(self):
        import pytest

        provider = Auth0Provider(settings=_settings())
        with pytest.raises(RuntimeError, match="M2M"):
            await provider.create_invitation(org_id="x", inviter_name="A", invitee_email="u@e.com")


class TestCreatePasswordChangeTicket:
    async def test_creates_ticket(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        ticket_resp = MagicMock()
        ticket_resp.json.return_value = {"ticket": "https://test.us.auth0.com/lo/reset?token=abc"}
        ticket_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(side_effect=[token_resp, ticket_resp])
        provider._http = mock_http

        result = await provider.create_password_change_ticket(user_id="auth0|user_1")

        assert "ticket" in result
        ticket_call = mock_http.post.call_args_list[1]
        assert "/api/v2/tickets/password-change" in ticket_call[0][0]
        assert ticket_call[1]["json"]["user_id"] == "auth0|user_1"
        assert ticket_call[1]["json"]["ttl_sec"] == 24 * 3600


class TestCreateEmailVerificationTicket:
    async def test_creates_ticket(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        ticket_resp = MagicMock()
        ticket_resp.json.return_value = {"ticket": "https://test.us.auth0.com/lo/verify?token=abc"}
        ticket_resp.raise_for_status = MagicMock()
        mock_http.post = AsyncMock(side_effect=[token_resp, ticket_resp])
        provider._http = mock_http

        result = await provider.create_email_verification_ticket(user_id="auth0|user_1")

        assert "ticket" in result
        ticket_call = mock_http.post.call_args_list[1]
        assert "/api/v2/tickets/email-verification" in ticket_call[0][0]
        assert ticket_call[1]["json"]["user_id"] == "auth0|user_1"


class TestEnableOrgConnections:
    async def test_enables_both_connections(self):
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        conn_resp = MagicMock()
        conn_resp.status_code = 201
        conn_resp.raise_for_status = MagicMock()
        # Token request + 2 enable connection requests
        mock_http.post = AsyncMock(side_effect=[token_resp, conn_resp, conn_resp])
        provider._http = mock_http

        await provider.enable_org_connections("org_xyz", "con_github", "con_db")
        # 3 POST calls: token + 2 connections
        assert mock_http.post.call_count == 3
        # GitHub connection: assign_membership_on_login = True
        github_call = mock_http.post.call_args_list[1]
        assert "/enabled_connections" in github_call[0][0]
        assert github_call[1]["json"]["assign_membership_on_login"] is True
        # DB connection: assign_membership_on_login = False
        db_call = mock_http.post.call_args_list[2]
        assert "/enabled_connections" in db_call[0][0]
        assert db_call[1]["json"]["assign_membership_on_login"] is False

    async def test_ignores_409_conflict(self):
        """409 = already enabled — idempotent on reinstall."""
        provider = Auth0Provider(
            settings=_settings(
                auth0_m2m_client_id="m2m-id",
                auth0_m2m_client_secret="m2m-secret",
            )
        )
        mock_http = AsyncMock()
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "mgmt-token", "expires_in": 86400}
        token_resp.raise_for_status = MagicMock()
        conflict_resp = MagicMock()
        conflict_resp.status_code = 409
        mock_http.post = AsyncMock(side_effect=[token_resp, conflict_resp, conflict_resp])
        provider._http = mock_http

        # Should not raise
        await provider.enable_org_connections("org_xyz", "con_github", "con_db")
        assert mock_http.post.call_count == 3
