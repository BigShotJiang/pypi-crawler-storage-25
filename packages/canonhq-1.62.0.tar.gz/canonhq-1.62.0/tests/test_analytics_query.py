"""Tests for PostHog HogQL query client."""

from __future__ import annotations

import httpx
import pytest

from canon.analytics_query import PostHogQueryClient


@pytest.fixture
def client():
    return PostHogQueryClient(
        api_key="phx_test_key",
        project_id="12345",
        host="https://us.i.posthog.com",
    )


class TestPostHogQueryClient:
    def test_init(self, client: PostHogQueryClient):
        assert client._api_key == "phx_test_key"
        assert client._project_id == "12345"
        assert client._host == "https://us.i.posthog.com"

    @pytest.mark.asyncio
    async def test_query_success(self, client: PostHogQueryClient, httpx_mock):
        """Successful HogQL query returns results."""
        httpx_mock.add_response(
            url="https://us.i.posthog.com/api/projects/12345/query/",
            json={
                "results": [["2026-03-01", 42], ["2026-03-02", 55]],
                "columns": ["date", "count"],
            },
        )
        rows = await client.query("SELECT date, count(*) FROM events GROUP BY date")
        assert len(rows) == 2
        assert rows[0] == {"date": "2026-03-01", "count": 42}

    @pytest.mark.asyncio
    async def test_query_timeout_returns_empty(self, client: PostHogQueryClient, httpx_mock):
        """Timeout returns empty list (graceful degradation)."""
        httpx_mock.add_exception(httpx.ReadTimeout("timed out"))
        rows = await client.query("SELECT 1")
        assert rows == []

    @pytest.mark.asyncio
    async def test_query_error_returns_empty(self, client: PostHogQueryClient, httpx_mock):
        """HTTP error returns empty list."""
        httpx_mock.add_response(status_code=500, json={"error": "internal"})
        rows = await client.query("SELECT 1")
        assert rows == []

    @pytest.mark.asyncio
    async def test_not_configured(self):
        """Client with empty key returns empty results."""
        client = PostHogQueryClient(api_key="", project_id="", host="")
        rows = await client.query("SELECT 1")
        assert rows == []
