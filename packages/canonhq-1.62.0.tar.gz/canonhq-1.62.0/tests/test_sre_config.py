"""Tests for SRE alerting configuration."""

from __future__ import annotations

from canon.config.parse import parse_canon_yaml
from canon.settings import Settings


class TestSreSettings:
    def test_default_sre_settings(self):
        s = Settings(gh_app_id="x", gh_private_key="x", gh_webhook_secret="x")
        assert s.slack_alerts_webhook_url == ""
        assert s.sre_alerts_enabled is True
        assert s.sre_error_spike_threshold == 10
        assert s.sre_error_spike_window == 300
        assert s.sre_slow_query_threshold_ms == 500
        assert s.sre_auto_triage_enabled is True
        assert s.sre_weekly_digest_enabled is False

    def test_sre_alerts_disabled_when_no_slack_webhook(self):
        s = Settings(gh_app_id="x", gh_private_key="x", gh_webhook_secret="x")
        assert s.slack_alerts_enabled is False

    def test_sre_alerts_enabled_with_slack_webhook(self):
        s = Settings(
            gh_app_id="x",
            gh_private_key="x",
            gh_webhook_secret="x",
            slack_alerts_webhook_url="https://hooks.slack.com/services/T/B/x",
        )
        assert s.slack_alerts_enabled is True


class TestSreCanonYaml:
    def test_default_sre_config(self):
        result = parse_canon_yaml("team: canon")
        assert result.config.sre is not None
        assert result.config.sre.auto_triage is True
        assert result.config.sre.weekly_digest is True
        assert result.config.sre.error_spike_threshold == 10
        assert result.config.sre.alerts_channel == "#canon-alerts"

    def test_custom_sre_config(self):
        yaml_str = """
sre:
  alerts_channel: "#ops-alerts"
  auto_triage: false
  weekly_digest: true
  error_spike_threshold: 20
"""
        result = parse_canon_yaml(yaml_str)
        assert result.config.sre.alerts_channel == "#ops-alerts"
        assert result.config.sre.auto_triage is False
        assert result.config.sre.error_spike_threshold == 20

    def test_sre_unknown_key_warns(self):
        yaml_str = """
sre:
  unknown_key: true
"""
        result = parse_canon_yaml(yaml_str)
        assert any("Unknown sre key" in d.message for d in result.diagnostics)

    def test_sre_invalid_type_errors(self):
        yaml_str = """
sre:
  auto_triage: "yes"
"""
        result = parse_canon_yaml(yaml_str)
        assert any("auto_triage" in d.message for d in result.diagnostics)
