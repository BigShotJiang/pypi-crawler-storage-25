"""Tests for error triage (error → GitHub issue creation)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from canon.alerts.triage import ErrorInfo, ErrorTriager


class TestErrorTriager:
    def _make_triager(
        self, auto_triage_enabled: bool = True
    ) -> tuple[ErrorTriager, AsyncMock, AsyncMock]:
        mock_error_store = AsyncMock()
        mock_github_client = AsyncMock()
        triager = ErrorTriager(
            error_store=mock_error_store,
            github_client=mock_github_client,
            repo="org/repo",
            auto_triage_enabled=auto_triage_enabled,
        )
        return triager, mock_error_store, mock_github_client

    @pytest.mark.asyncio
    async def test_creates_new_issue_for_new_error(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = None
        mock_gh.create_issue.return_value = {
            "number": 42,
            "html_url": "https://github.com/org/repo/issues/42",
        }

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
            stack_trace="Traceback...",
            endpoint="/webhook",
            count=5,
            first_seen="2026-03-20T10:00:00Z",
            last_seen="2026-03-20T10:05:00Z",
            posthog_url="https://us.posthog.com/error/abc",
        )

        result = await triager.triage(error)

        assert result.action == "created"
        assert result.issue_number == 42
        mock_store.create.assert_called_once()
        mock_gh.create_issue.assert_called_once()
        mock_gh.ensure_label.assert_called()

    @pytest.mark.asyncio
    async def test_skips_existing_open_issue(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = MagicMock(
            issue_number=42,
            resolved_at=None,
        )

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
        )

        result = await triager.triage(error)

        assert result.action == "deduplicated"
        assert result.issue_number == 42
        mock_store.increment_occurrence.assert_called_once()
        mock_gh.create_issue.assert_not_called()

    @pytest.mark.asyncio
    async def test_reopens_resolved_issue(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = MagicMock(
            issue_number=42,
            issue_url="https://github.com/org/repo/issues/42",
            resolved_at="2026-03-19T00:00:00Z",
        )

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
        )

        result = await triager.triage(error)

        assert result.action == "reopened"
        assert result.issue_number == 42
        mock_gh.update_issue.assert_called_once_with("org", "repo", 42, state="open")
        mock_gh.create_comment.assert_called_once()
        mock_store.clear_resolved.assert_called_once()

    @pytest.mark.asyncio
    async def test_creates_issue_with_severity_labels(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = None
        mock_store.create.return_value = MagicMock(id=1)
        mock_gh.create_issue.return_value = {
            "number": 99,
            "html_url": "https://github.com/org/repo/issues/99",
        }

        error = ErrorInfo(
            fingerprint="fp-critical",
            exception_type="DatabaseError",
            message="connection lost",
            severity="critical",
        )

        result = await triager.triage(error)

        assert result.action == "created"
        # Verify severity label was included
        create_call = mock_gh.create_issue.call_args
        labels = create_call[1]["labels"]
        assert "severity:critical" in labels
        # Verify ensure_label was called for the severity label
        ensure_calls = [c[0] for c in mock_gh.ensure_label.call_args_list]
        label_names = [c[2] for c in ensure_calls]
        assert "severity:critical" in label_names

    @pytest.mark.asyncio
    async def test_reopens_with_posthog_url_in_comment(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = MagicMock(
            issue_number=42,
            issue_url="https://github.com/org/repo/issues/42",
            resolved_at="2026-03-19T00:00:00Z",
        )

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
            count=3,
            posthog_url="https://us.posthog.com/error/abc",
        )

        result = await triager.triage(error)

        assert result.action == "reopened"
        comment_body = mock_gh.create_comment.call_args[0][3]
        assert "Error recurrence detected" in comment_body
        assert "KeyError" in comment_body
        assert "View in PostHog" in comment_body
        assert "https://us.posthog.com/error/abc" in comment_body

    @pytest.mark.asyncio
    async def test_create_conflict_returns_deduplicated(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = None
        mock_store.create.return_value = None  # conflict
        mock_gh.create_issue.return_value = {
            "number": 42,
            "html_url": "https://github.com/org/repo/issues/42",
        }

        error = ErrorInfo(
            fingerprint="fp-race",
            exception_type="KeyError",
            message="test",
        )

        result = await triager.triage(error)
        assert result.action == "deduplicated"
        assert result.issue_number == 42

    @pytest.mark.asyncio
    async def test_auto_triage_disabled_returns_none(self):
        triager, mock_store, _mock_gh = self._make_triager(auto_triage_enabled=False)
        error = ErrorInfo(fingerprint="fp123", exception_type="KeyError", message="test")
        result = await triager.triage(error)
        assert result is None
        mock_store.get_by_fingerprint.assert_not_called()
