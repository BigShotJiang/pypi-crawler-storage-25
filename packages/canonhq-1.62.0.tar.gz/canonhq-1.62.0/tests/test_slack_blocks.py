"""Tests for Slack Block Kit builder utilities."""

from __future__ import annotations

from canon_slack.blocks import (
    action_buttons,
    context_block,
    divider,
    header_block,
    progress_bar,
    section_block,
    spec_summary_blocks,
    status_emoji,
)


class TestStatusEmoji:
    def test_done_status(self):
        assert status_emoji("done") == ":white_check_mark:"

    def test_in_progress_status(self):
        assert status_emoji("in_progress") == ":large_blue_circle:"

    def test_todo_status(self):
        assert status_emoji("todo") == ":yellow_circle:"

    def test_draft_status(self):
        assert status_emoji("draft") == ":yellow_circle:"

    def test_unknown_status(self):
        assert status_emoji("unknown") == ":white_circle:"


class TestProgressBar:
    def test_full_progress(self):
        result = progress_bar(10, 10)
        assert "100%" in result
        assert "#" * 10 in result

    def test_zero_progress(self):
        result = progress_bar(0, 10)
        assert "0%" in result

    def test_partial_progress(self):
        result = progress_bar(8, 10)
        assert "80%" in result

    def test_zero_total(self):
        result = progress_bar(0, 0)
        assert "0%" in result


class TestSpecSummaryBlocks:
    def test_builds_summary_with_title_and_status(self):
        blocks = spec_summary_blocks(
            title="auth-hardening",
            status="active",
            sections_done=3,
            sections_total=5,
            github_url="https://github.com/org/repo/blob/main/docs/specs/auth.md",
        )
        assert len(blocks) >= 1
        text = str(blocks)
        assert "auth-hardening" in text


class TestHeaderBlock:
    def test_returns_header_type(self):
        block = header_block("Test Header")
        assert block["type"] == "header"
        assert block["text"]["text"] == "Test Header"


class TestSectionBlock:
    def test_returns_section_type(self):
        block = section_block("Hello world")
        assert block["type"] == "section"
        assert block["text"]["type"] == "mrkdwn"
        assert block["text"]["text"] == "Hello world"

    def test_with_accessory(self):
        acc = {"type": "button", "text": {"type": "plain_text", "text": "Go"}}
        block = section_block("text", accessory=acc)
        assert block["accessory"] == acc


class TestContextBlock:
    def test_returns_context_type(self):
        block = context_block(["element 1", "element 2"])
        assert block["type"] == "context"
        assert len(block["elements"]) == 2
        assert block["elements"][0]["type"] == "mrkdwn"


class TestDivider:
    def test_returns_divider_type(self):
        block = divider()
        assert block["type"] == "divider"


class TestActionButtons:
    def test_builds_buttons(self):
        buttons = action_buttons(
            [
                ("View in Canon", "view_spec", "https://example.com"),
                ("View on GitHub", "view_github", "https://github.com"),
            ]
        )
        assert buttons["type"] == "actions"
        assert len(buttons["elements"]) == 2
        assert buttons["elements"][0]["action_id"] == "view_spec"

    def test_url_buttons_have_url_field(self):
        buttons = action_buttons(
            [
                ("View on GitHub", "view_github", "https://github.com/org/repo"),
                ("Approve", "approve_spec", "auth-hardening"),
            ]
        )
        # URL value gets a url field for link navigation
        assert buttons["elements"][0]["url"] == "https://github.com/org/repo"
        # Non-URL value does not get a url field
        assert "url" not in buttons["elements"][1]
