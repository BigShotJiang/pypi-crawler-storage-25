"""Tests for the Slack App Home Tab handler."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from canon_slack.home_tab import handle_app_home_opened


class TestHomeTabOnboarding:
    @pytest.mark.asyncio
    async def test_shows_onboarding_when_no_identity(self):
        event = {"user": "U123"}
        client = AsyncMock()

        with patch("canon_slack.home_tab._get_identity_store", return_value=None):
            await handle_app_home_opened(event, client)

        client.views_publish.assert_called_once()
        view = client.views_publish.call_args[1]["view"]
        assert view["type"] == "home"
        block_texts = " ".join(
            b.get("text", {}).get("text", "") for b in view["blocks"] if "text" in b
        )
        assert "Link" in block_texts or "link" in block_texts.lower()

    @pytest.mark.asyncio
    async def test_shows_onboarding_when_user_not_linked(self):
        event = {"user": "U123"}
        client = AsyncMock()
        store = MagicMock()
        store.get_github_login = AsyncMock(return_value=None)

        with patch("canon_slack.home_tab._get_identity_store", return_value=store):
            await handle_app_home_opened(event, client)

        client.views_publish.assert_called_once()
        view = client.views_publish.call_args[1]["view"]
        block_texts = " ".join(
            b.get("text", {}).get("text", "") for b in view["blocks"] if "text" in b
        )
        assert "Link" in block_texts or "Welcome" in block_texts


class TestHomeTabDashboard:
    @pytest.mark.asyncio
    async def test_shows_dashboard_when_linked(self):
        event = {"user": "U123"}
        client = AsyncMock()
        store = MagicMock()
        store.get_github_login = AsyncMock(return_value="octocat")

        mock_loader = MagicMock()
        mock_loader.load = AsyncMock(return_value=[])
        mock_loader.coverage_stats.return_value = {
            "total": 0,
            "done": 0,
            "in_progress": 0,
            "pct_done": 0,
            "pct_in_progress": 0,
            "teams": [],
        }

        with (
            patch("canon_slack.home_tab._get_identity_store", return_value=store),
            patch("canon_slack.home_tab._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.home_tab._get_github_client", return_value=MagicMock()),
            patch("canon_slack.commands._get_spec_loader", return_value=mock_loader),
        ):
            await handle_app_home_opened(event, client)

        client.views_publish.assert_called_once()
        view = client.views_publish.call_args[1]["view"]
        assert view["type"] == "home"
        block_texts = " ".join(
            b.get("text", {}).get("text", "") for b in view["blocks"] if "text" in b
        )
        assert "Dashboard" in block_texts or "My Specs" in block_texts

    @pytest.mark.asyncio
    async def test_shows_user_specs(self):
        event = {"user": "U123"}
        client = AsyncMock()
        store = MagicMock()
        store.get_github_login = AsyncMock(return_value="octocat")

        from canon_slack.spec_loader import SpecInfo

        spec = SpecInfo(
            title="Auth Hardening",
            slug="auth-hardening",
            status="in_progress",
            sections_done=3,
            sections_total=5,
            github_url="https://github.com/owner/repo/blob/main/docs/specs/auth-hardening.md",
            owner="octocat",
            team="platform",
        )
        mock_loader = MagicMock()
        mock_loader.load = AsyncMock(return_value=[spec])
        mock_loader.coverage_stats.return_value = {
            "total": 1,
            "done": 0,
            "in_progress": 1,
            "pct_done": 0,
            "pct_in_progress": 100,
            "teams": ["platform"],
        }

        with (
            patch("canon_slack.home_tab._get_identity_store", return_value=store),
            patch("canon_slack.home_tab._get_repo_settings", return_value=("owner", "repo")),
            patch("canon_slack.home_tab._get_github_client", return_value=MagicMock()),
            patch("canon_slack.commands._get_spec_loader", return_value=mock_loader),
        ):
            await handle_app_home_opened(event, client)

        view = client.views_publish.call_args[1]["view"]
        block_texts = " ".join(
            b.get("text", {}).get("text", "") for b in view["blocks"] if "text" in b
        )
        assert "Auth Hardening" in block_texts

    @pytest.mark.asyncio
    async def test_handles_load_failure(self):
        event = {"user": "U123"}
        client = AsyncMock()
        store = MagicMock()
        store.get_github_login = AsyncMock(return_value="octocat")

        with (
            patch("canon_slack.home_tab._get_identity_store", return_value=store),
            patch("canon_slack.home_tab._get_repo_settings", side_effect=Exception("boom")),
        ):
            await handle_app_home_opened(event, client)

        client.views_publish.assert_called_once()
        view = client.views_publish.call_args[1]["view"]
        block_texts = " ".join(
            b.get("text", {}).get("text", "") for b in view["blocks"] if "text" in b
        )
        assert "Failed" in block_texts or "failed" in block_texts.lower()
