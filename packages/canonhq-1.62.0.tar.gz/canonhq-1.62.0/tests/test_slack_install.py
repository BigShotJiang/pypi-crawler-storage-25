"""Tests for Slack OAuth install flow."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from canon_slack.install import SharedChannelGuard, SlackInstallStore, is_self_hosted_mode


class TestSlackInstallStore:
    @pytest.mark.asyncio
    async def test_save_and_find_roundtrip(self):
        registry = AsyncMock()
        store = SlackInstallStore(
            registry=registry, encryption_key="test-key-32bytes-exactly-here!!"
        )

        installation = MagicMock()
        installation.team_id = "T123"
        installation.bot_token = "xoxb-real-token"
        installation.enterprise_id = None
        installation.org_id = "org-abc"

        await store.async_save(installation)
        registry.save_slack_installation.assert_called_once()

        # Verify token was encrypted (not stored as plaintext)
        saved = registry.save_slack_installation.call_args[0][0]
        assert saved["bot_token"] != "xoxb-real-token"
        assert saved["team_id"] == "T123"
        assert saved["org_id"] == "org-abc"

    @pytest.mark.asyncio
    async def test_encrypt_decrypt_roundtrip(self):
        registry = AsyncMock()
        store = SlackInstallStore(
            registry=registry, encryption_key="test-key-32bytes-exactly-here!!"
        )

        original = "xoxb-super-secret-token"
        encrypted = store._encrypt(original)
        assert encrypted != original
        decrypted = store._decrypt(encrypted)
        assert decrypted == original

    @pytest.mark.asyncio
    async def test_find_returns_none_for_missing(self):
        registry = AsyncMock()
        registry.get_slack_installation = AsyncMock(return_value=None)
        store = SlackInstallStore(
            registry=registry, encryption_key="test-key-32bytes-exactly-here!!"
        )

        result = await store.async_find_installation(enterprise_id=None, team_id="T999")
        assert result is None

    @pytest.mark.asyncio
    async def test_find_decrypts_token(self):
        registry = AsyncMock()
        store = SlackInstallStore(
            registry=registry, encryption_key="test-key-32bytes-exactly-here!!"
        )

        encrypted = store._encrypt("xoxb-real-token")
        registry.get_slack_installation = AsyncMock(
            return_value={"team_id": "T123", "bot_token": encrypted}
        )

        result = await store.async_find_installation(enterprise_id=None, team_id="T123")
        assert result["bot_token"] == "xoxb-real-token"

    @pytest.mark.asyncio
    async def test_get_org_for_workspace(self):
        registry = AsyncMock()
        registry.get_slack_installation = AsyncMock(
            return_value={"team_id": "T123", "org_id": "org-abc"}
        )
        store = SlackInstallStore(
            registry=registry, encryption_key="test-key-32bytes-exactly-here!!"
        )

        org = await store.get_org_for_workspace("T123")
        assert org == "org-abc"

    @pytest.mark.asyncio
    async def test_get_org_returns_none_for_missing(self):
        registry = AsyncMock()
        registry.get_slack_installation = AsyncMock(return_value=None)
        store = SlackInstallStore(
            registry=registry, encryption_key="test-key-32bytes-exactly-here!!"
        )

        org = await store.get_org_for_workspace("T999")
        assert org is None


class TestSelfHostedMode:
    def test_self_hosted_skips_oauth(self):
        assert is_self_hosted_mode(bot_token="xoxb-test", app_token="") is True
        assert is_self_hosted_mode(bot_token="", app_token="") is True


class TestSharedChannelGuard:
    def test_allows_normal_channels(self):
        guard = SharedChannelGuard(allow_shared_channels=False)
        assert guard.should_respond({"channel": "C123"}) is True

    def test_blocks_shared_channels_by_default(self):
        guard = SharedChannelGuard(allow_shared_channels=False)
        assert guard.should_respond({"is_ext_shared_channel": True}) is False

    def test_allows_shared_channels_when_enabled(self):
        guard = SharedChannelGuard(allow_shared_channels=True)
        assert guard.should_respond({"is_ext_shared_channel": True}) is True

    def test_org_scope_returns_bot_install_workspace(self):
        guard = SharedChannelGuard()
        # Always returns the bot's installed workspace, not the event sender's
        scope = guard.get_org_scope({"team": "T123"}, "T456")
        assert scope == "T456"

    def test_org_scope_ignores_event_team(self):
        guard = SharedChannelGuard()
        scope = guard.get_org_scope({}, "T456")
        assert scope == "T456"
