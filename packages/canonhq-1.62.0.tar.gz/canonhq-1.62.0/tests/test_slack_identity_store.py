"""Tests for Slack identity store."""

import pytest
from canon_slack.identity_store import IdentityStore


@pytest.fixture
def store():
    """In-memory identity store (no DB)."""
    return IdentityStore(db_pool=None)


@pytest.mark.asyncio
async def test_link_and_get(store):
    await store.link("U123", "octocat")
    assert await store.get_github_login("U123") == "octocat"


@pytest.mark.asyncio
async def test_get_unknown_user(store):
    assert await store.get_github_login("U999") is None


@pytest.mark.asyncio
async def test_unlink_existing(store):
    await store.link("U123", "octocat")
    assert await store.unlink("U123") is True
    assert await store.get_github_login("U123") is None


@pytest.mark.asyncio
async def test_unlink_nonexistent(store):
    assert await store.unlink("U999") is False


@pytest.mark.asyncio
async def test_link_overwrites(store):
    await store.link("U123", "old-user")
    await store.link("U123", "new-user")
    assert await store.get_github_login("U123") == "new-user"


@pytest.mark.asyncio
async def test_alias_method(store):
    await store.link("U123", "octocat")
    assert await store.get_github_login_for_slack("U123") == "octocat"
