"""Tests for Slack app factory and FastAPI mount."""

from __future__ import annotations

from unittest.mock import MagicMock


class TestCreateSlackApp:
    def test_returns_none_when_bot_not_enabled(self):
        from canon_slack.app import create_slack_app

        settings = MagicMock()
        settings.slack_bot_enabled = False
        assert create_slack_app(settings) is None

    def test_returns_app_when_bot_enabled(self):
        from canon_slack.app import create_slack_app

        settings = MagicMock()
        settings.slack_bot_enabled = True
        settings.slack_bot_token = "xoxb-test"
        settings.slack_signing_secret = "test-secret"
        settings.slack_app_token = ""
        result = create_slack_app(settings)
        assert result is not None

    def test_socket_mode_when_app_token_set(self):
        from canon_slack.app import create_slack_app

        settings = MagicMock()
        settings.slack_bot_enabled = True
        settings.slack_bot_token = "xoxb-test"
        settings.slack_signing_secret = "test-secret"
        settings.slack_app_token = "xapp-test"
        result = create_slack_app(settings)
        assert result is not None
        assert result.socket_mode is True


class TestSlackBotEnabled:
    def test_enabled_with_both_tokens(self):
        from canon.settings import Settings

        s = Settings(slack_bot_token="xoxb-test", slack_signing_secret="secret")
        assert s.slack_bot_enabled is True

    def test_disabled_without_token(self):
        from canon.settings import Settings

        s = Settings(slack_signing_secret="secret")
        assert s.slack_bot_enabled is False

    def test_disabled_without_signing_secret(self):
        from canon.settings import Settings

        s = Settings(slack_bot_token="xoxb-test")
        assert s.slack_bot_enabled is False
