"""Tests for per-team weekly digest builder."""

from __future__ import annotations

import pytest
from canon_slack.digest import (
    TeamDigestConfig,
    build_digest_blocks,
    dispatch_team_digests,
    should_send_digest,
)
from canon_slack.spec_loader import SectionInfo, SpecInfo


class TestTeamDigestConfig:
    def test_basic_config(self):
        config = TeamDigestConfig(channel="#platform-specs", schedule="monday 09:00")
        assert config.channel == "#platform-specs"
        assert config.schedule == "monday 09:00"


class TestBuildDigestBlocks:
    def test_builds_digest_with_coverage(self):
        specs = [
            SpecInfo(
                title="auth-hardening",
                slug="auth-hardening",
                status="active",
                sections_done=3,
                sections_total=5,
                github_url="",
                team="platform",
                updated="2026-03-25",
                sections=[
                    SectionInfo(
                        id="1",
                        title="Login",
                        status="done",
                        acs_done=3,
                        acs_total=3,
                    ),
                    SectionInfo(
                        id="2",
                        title="OAuth",
                        status="in_progress",
                        acs_done=1,
                        acs_total=4,
                    ),
                ],
            ),
        ]
        blocks = build_digest_blocks(
            team="platform",
            specs=specs,
            coverage_pct=60,
            coverage_delta=5,
        )
        text = str(blocks)
        assert "platform" in text.lower() or "Platform" in text
        assert "60%" in text

    def test_empty_team_produces_header(self):
        blocks = build_digest_blocks(team="ghost", specs=[], coverage_pct=0, coverage_delta=0)
        assert len(blocks) >= 1  # At least a header

    def test_filters_specs_by_team(self):
        specs = [
            SpecInfo(
                title="a",
                slug="a",
                status="done",
                sections_done=1,
                sections_total=1,
                github_url="",
                team="platform",
            ),
            SpecInfo(
                title="b",
                slug="b",
                status="done",
                sections_done=1,
                sections_total=1,
                github_url="",
                team="backend",
            ),
        ]
        blocks = build_digest_blocks(
            team="platform", specs=specs, coverage_pct=100, coverage_delta=0
        )
        text = str(blocks)
        assert "a" in text


class TestDispatchTeamDigests:
    @pytest.mark.asyncio
    async def test_posts_to_configured_channels(self):
        from unittest.mock import AsyncMock

        client = AsyncMock()
        configs = {
            "platform": TeamDigestConfig(channel="#platform-specs"),
            "backend": TeamDigestConfig(channel="#backend-specs"),
        }
        posted = await dispatch_team_digests(client, configs, specs=[])
        assert "platform" in posted
        assert "backend" in posted
        assert client.chat_postMessage.call_count == 2

    @pytest.mark.asyncio
    async def test_skips_empty_channel(self):
        from unittest.mock import AsyncMock

        client = AsyncMock()
        configs = {
            "platform": TeamDigestConfig(channel=""),
        }
        posted = await dispatch_team_digests(client, configs, specs=[])
        assert posted == []
        client.chat_postMessage.assert_not_called()

    @pytest.mark.asyncio
    async def test_continues_on_error(self):
        from unittest.mock import AsyncMock

        client = AsyncMock()
        client.chat_postMessage = AsyncMock(side_effect=[Exception("fail"), None])
        configs = {
            "platform": TeamDigestConfig(channel="#p"),
            "backend": TeamDigestConfig(channel="#b"),
        }
        posted = await dispatch_team_digests(client, configs, specs=[])
        assert "backend" in posted
        assert "platform" not in posted


class TestShouldSendDigest:
    def test_matching_day_and_time(self):
        from datetime import UTC, datetime
        from unittest.mock import patch

        fake_now = datetime(2026, 3, 23, 9, 0, tzinfo=UTC)  # Monday
        with patch("canon_slack.digest.datetime") as mock_dt:
            mock_dt.now.return_value = fake_now
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            assert should_send_digest("monday 09:00") is True

    def test_wrong_day(self):
        from datetime import UTC, datetime
        from unittest.mock import patch

        fake_now = datetime(2026, 3, 24, 9, 0, tzinfo=UTC)  # Tuesday
        with patch("canon_slack.digest.datetime") as mock_dt:
            mock_dt.now.return_value = fake_now
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            assert should_send_digest("monday 09:00") is False

    def test_wrong_minute(self):
        from datetime import UTC, datetime
        from unittest.mock import patch

        fake_now = datetime(2026, 3, 23, 9, 15, tzinfo=UTC)  # Monday 09:15
        with patch("canon_slack.digest.datetime") as mock_dt:
            mock_dt.now.return_value = fake_now
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            assert should_send_digest("monday 09:00") is False

    def test_wrong_hour(self):
        from datetime import UTC, datetime
        from unittest.mock import patch

        fake_now = datetime(2026, 3, 23, 10, 0, tzinfo=UTC)  # Monday 10:00
        with patch("canon_slack.digest.datetime") as mock_dt:
            mock_dt.now.return_value = fake_now
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            assert should_send_digest("monday 09:00") is False
