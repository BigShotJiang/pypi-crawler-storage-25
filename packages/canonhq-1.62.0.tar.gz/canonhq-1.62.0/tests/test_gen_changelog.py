"""Tests for the changelog generator script."""

import importlib.util
from pathlib import Path

import pytest

# Import gen-changelog.py (hyphenated filename can't use normal import)
SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "docs-site" / ".vitepress" / "scripts"
_spec = importlib.util.spec_from_file_location("gen_changelog", SCRIPTS_DIR / "gen-changelog.py")
gen_changelog = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(gen_changelog)


# ── Fixtures ─────────────────────────────────────────────

SAMPLE_CHANGELOG = """\
# CHANGELOG

## v1.10.0 (2026-03-21)

### Bug Fixes

- Address PR review feedback ([#100](https://github.com/canonhq/canon-private/pull/100),
  [`abc1234`](https://github.com/canonhq/canon-private/commit/abc1234))

- Address round-2 PR feedback ([#100](https://github.com/canonhq/canon-private/pull/100),
  [`abc1234`](https://github.com/canonhq/canon-private/commit/abc1234))

- Fix login redirect for SSO users ([#101](https://github.com/canonhq/canon-private/pull/101),
  [`def5678`](https://github.com/canonhq/canon-private/commit/def5678))

### Chores

- Update uv.lock
  ([`aaa1111`](https://github.com/canonhq/canon-private/commit/aaa1111))

- Regenerate uv.lock for v1.10.0
  ([`bbb2222`](https://github.com/canonhq/canon-private/commit/bbb2222))

### Code Style

- Fix ruff lint issues
  ([`ccc3333`](https://github.com/canonhq/canon-private/commit/ccc3333))

### Features

- Add dark mode toggle
  ([`eee5555`](https://github.com/canonhq/canon-private/commit/eee5555))

- **sre**: Add SRE alerting dashboard
  ([`fff6666`](https://github.com/canonhq/canon-private/commit/fff6666))

- **test**: Add integration test helpers
  ([`ggg7777`](https://github.com/canonhq/canon-private/commit/ggg7777))

## v1.10.1 (2026-03-22)

### Bug Fixes

- Fix dark mode flicker on page load
  ([`hhh8888`](https://github.com/canonhq/canon-private/commit/hhh8888))

### Documentation

- Snapshot v1.10 docs
  ([`iii9999`](https://github.com/canonhq/canon-private/commit/iii9999))

## v1.9.0 (2026-03-20)

### Features

- Add spec coverage dashboard
  ([#90](https://github.com/canonhq/canon-private/pull/90),
  [`jjj0000`](https://github.com/canonhq/canon-private/commit/jjj0000))

### Bug Fixes

- Address code review findings
  ([`kkk1111`](https://github.com/canonhq/canon-private/commit/kkk1111))
"""


# ── Parsing tests ────────────────────────────────────────


class TestParseChangelog:
    def test_parses_versions(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        assert len(versions) == 3
        assert versions[0].version == "v1.10.0"
        assert versions[1].version == "v1.10.1"
        assert versions[2].version == "v1.9.0"

    def test_parses_dates(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        assert versions[0].date == "2026-03-21"
        assert versions[2].date == "2026-03-20"

    def test_parses_sections(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        v1_10_0 = versions[0]
        assert "Bug Fixes" in v1_10_0.sections
        assert "Features" in v1_10_0.sections
        assert "Chores" in v1_10_0.sections
        assert "Code Style" in v1_10_0.sections

    def test_parses_entries(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        features = versions[0].sections["Features"]
        assert len(features) == 3  # dark mode, sre, test

    def test_extracts_pr_numbers(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        bugs = versions[0].sections["Bug Fixes"]
        assert bugs[0].pr_number == "100"
        assert bugs[1].pr_number == "100"

    def test_multiline_entries(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        # Multi-line entries should be joined
        bugs = versions[0].sections["Bug Fixes"]
        assert "Address PR review feedback" in bugs[0].text
        assert "canon-private" in bugs[0].text  # link was on continuation line

    def test_minor_key(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        assert versions[0].minor_key == "v1.10"
        assert versions[1].minor_key == "v1.10"
        assert versions[2].minor_key == "v1.9"


# ── Filtering tests ─────────────────────────────────────


class TestFiltering:
    def test_excludes_chores_section(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        for v in filtered:
            assert "Chores" not in v.sections

    def test_excludes_code_style_section(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        for v in filtered:
            assert "Code Style" not in v.sections

    def test_excludes_cloud_only_scopes(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        for v in filtered:
            for entries in v.sections.values():
                for entry in entries:
                    assert "**sre**:" not in entry.text

    def test_excludes_test_scopes(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        for v in filtered:
            for entries in v.sections.values():
                for entry in entries:
                    assert "**test**:" not in entry.text

    def test_excludes_pr_feedback(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        for v in filtered:
            for entries in v.sections.values():
                for entry in entries:
                    assert "Address PR review feedback" not in entry.text
                    assert "Address round-2" not in entry.text

    def test_excludes_noise(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        for v in filtered:
            for entries in v.sections.values():
                for entry in entries:
                    assert "uv.lock" not in entry.text.lower()

    def test_excludes_snapshot_docs(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        for v in filtered:
            for entries in v.sections.values():
                for entry in entries:
                    assert "snapshot v" not in entry.text.lower()

    def test_excludes_code_review_findings(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        for v in filtered:
            for entries in v.sections.values():
                for entry in entries:
                    assert "code review findings" not in entry.text.lower()

    def test_keeps_real_entries(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        # Should keep: Fix login redirect, Add dark mode, Fix dark mode flicker, Add spec coverage
        all_texts = []
        for v in filtered:
            for entries in v.sections.values():
                all_texts.extend(e.text for e in entries)
        assert any("login redirect" in t.lower() for t in all_texts)
        assert any("dark mode toggle" in t.lower() for t in all_texts)
        assert any("dark mode flicker" in t.lower() for t in all_texts)
        assert any("spec coverage" in t.lower() for t in all_texts)

    def test_drops_empty_versions(self):
        # A version with only chores/noise should be dropped entirely
        only_chores = """\
## v0.1.0 (2026-01-01)

### Chores

- Update uv.lock
  ([`aaa`](https://github.com/canonhq/canon-private/commit/aaa))
"""
        versions = gen_changelog.parse_changelog(only_chores)
        filtered = gen_changelog.filter_entries(versions)
        assert len(filtered) == 0


# ── Deduplication tests ──────────────────────────────────


class TestCollapseDuplicates:
    def test_collapses_same_pr(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        deduped = gen_changelog.collapse_duplicates(filtered)
        for v in deduped:
            for entries in v.sections.values():
                pr_numbers = [e.pr_number for e in entries if e.pr_number]
                assert len(pr_numbers) == len(set(pr_numbers))

    def test_keeps_longer_description(self):
        text = """\
## v1.0.0 (2026-01-01)

### Features

- Add auth ([#50](https://github.com/canonhq/canon-private/pull/50),
  [`aaa`](https://github.com/canonhq/canon-private/commit/aaa))

- Add authentication with OAuth2 and JWT support ([#50](https://github.com/canonhq/canon-private/pull/50),
  [`aaa`](https://github.com/canonhq/canon-private/commit/aaa))
"""
        versions = gen_changelog.parse_changelog(text)
        deduped = gen_changelog.collapse_duplicates(versions)
        features = deduped[0].sections["Features"]
        assert len(features) == 1
        assert "OAuth2" in features[0].text


# ── Grouping tests ───────────────────────────────────────


class TestGroupByMinor:
    def test_groups_patch_versions(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        deduped = gen_changelog.collapse_duplicates(filtered)
        groups = gen_changelog.group_by_minor(deduped)
        keys = [k for k, _ in groups]
        assert "v1.10" in keys
        assert "v1.9" in keys
        # v1.10.0 and v1.10.1 should be merged
        assert keys.count("v1.10") == 1

    def test_merges_sections(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        deduped = gen_changelog.collapse_duplicates(filtered)
        groups = gen_changelog.group_by_minor(deduped)
        v1_10 = next(sections for key, sections in groups if key == "v1.10")
        # Should have entries from both v1.10.0 and v1.10.1
        bugs = v1_10.get("Bug Fixes", [])
        assert any("login redirect" in e.text.lower() for e in bugs)
        assert any("dark mode flicker" in e.text.lower() for e in bugs)


# ── Link rewriting tests ────────────────────────────────


class TestLinkRewriting:
    def test_rewrites_private_to_public(self):
        text = "See https://github.com/canonhq/canon-private/pull/100"
        result = gen_changelog.rewrite_links(text)
        assert "canon-private" not in result
        assert "github.com/canonhq/canon" in result

    def test_strip_entry_links(self):
        text = (
            "Fix login redirect ([#101](https://github.com/canonhq/canon-private/pull/101), "
            "[`def5678`](https://github.com/canonhq/canon-private/commit/def5678))"
        )
        result = gen_changelog.strip_entry_links(text)
        assert result == "Fix login redirect"

    def test_strip_commit_only_link(self):
        text = "Fix bug ([`abc1234`](https://github.com/canonhq/canon-private/commit/abc1234))"
        result = gen_changelog.strip_entry_links(text)
        assert result == "Fix bug"

    def test_clean_scope_prefix(self):
        assert (
            gen_changelog.clean_scope_prefix("**sync**: Fix event loop") == "Fix event loop (sync)"
        )
        assert gen_changelog.clean_scope_prefix("Fix plain bug") == "Fix plain bug"


# ── Rendering tests ──────────────────────────────────────


class TestRendering:
    def test_output_has_frontmatter(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        deduped = gen_changelog.collapse_duplicates(filtered)
        groups = gen_changelog.group_by_minor(deduped)
        output = gen_changelog.render_markdown(groups)
        assert output.startswith("---\ntitle: Changelog\n---")

    def test_output_has_version_headings(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        deduped = gen_changelog.collapse_duplicates(filtered)
        groups = gen_changelog.group_by_minor(deduped)
        output = gen_changelog.render_markdown(groups)
        assert "## v1.10" in output
        assert "## v1.9" in output

    def test_output_has_section_headings(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        deduped = gen_changelog.collapse_duplicates(filtered)
        groups = gen_changelog.group_by_minor(deduped)
        output = gen_changelog.render_markdown(groups)
        assert "### Features" in output
        assert "### Bug Fixes" in output

    def test_output_strips_links(self):
        versions = gen_changelog.parse_changelog(SAMPLE_CHANGELOG)
        filtered = gen_changelog.filter_entries(versions)
        deduped = gen_changelog.collapse_duplicates(filtered)
        groups = gen_changelog.group_by_minor(deduped)
        output = gen_changelog.render_markdown(groups)
        # Should not contain raw commit hashes or PR links
        assert "[`abc1234`]" not in output
        assert "[#100]" not in output

    def test_section_order(self):
        """Breaking Changes should come before Features, Features before Bug Fixes."""
        text = """\
## v2.0.0 (2026-01-01)

### Bug Fixes

- Fix something
  ([`aaa`](https://github.com/canonhq/canon-private/commit/aaa))

### Features

- Add something
  ([`bbb`](https://github.com/canonhq/canon-private/commit/bbb))

### Breaking Changes

- Remove old API
  ([`ccc`](https://github.com/canonhq/canon-private/commit/ccc))
"""
        versions = gen_changelog.parse_changelog(text)
        filtered = gen_changelog.filter_entries(versions)
        groups = gen_changelog.group_by_minor(filtered)
        output = gen_changelog.render_markdown(groups)
        breaking_pos = output.index("### Breaking Changes")
        features_pos = output.index("### Features")
        bugs_pos = output.index("### Bug Fixes")
        assert breaking_pos < features_pos < bugs_pos


# ── Integration test ─────────────────────────────────────


class TestIntegration:
    def test_full_pipeline_with_actual_changelog(self):
        """Run the full pipeline against the repo's actual CHANGELOG.md."""
        if not gen_changelog.CHANGELOG_PATH.exists():
            pytest.skip("CHANGELOG.md not found")

        raw = gen_changelog.CHANGELOG_PATH.read_text(encoding="utf-8")
        versions = gen_changelog.parse_changelog(raw)
        assert len(versions) > 0

        filtered = gen_changelog.filter_entries(versions)
        deduped = gen_changelog.collapse_duplicates(filtered)
        groups = gen_changelog.group_by_minor(deduped)
        output = gen_changelog.render_markdown(groups)
        output = gen_changelog.rewrite_links(output)

        # Should have frontmatter
        assert output.startswith("---\ntitle: Changelog\n---")

        # Should not contain private repo references
        assert "canon-private" not in output

        # Should not contain noise entries
        assert "uv.lock" not in output.lower()
        assert "retrigger ci" not in output.lower()

        # Should have version headings
        assert "## v1." in output
