"""Tests for persistent mute store, activity store, and interest tracker."""

from __future__ import annotations

from pathlib import Path

from canon_slack.activity_store import ActivityStore
from canon_slack.interest_tracker import InterestTracker
from canon_slack.mute_store import MuteStore


class TestMuteStore:
    def test_mute_and_check(self, tmp_path: Path):
        store = MuteStore(tmp_path / "mutes.json")
        store.mute("U1", "auth-hardening")
        assert store.is_muted("U1", "auth-hardening")
        assert not store.is_muted("U1", "other-spec")
        assert not store.is_muted("U2", "auth-hardening")

    def test_unmute(self, tmp_path: Path):
        store = MuteStore(tmp_path / "mutes.json")
        store.mute("U1", "auth-hardening")
        store.unmute("U1", "auth-hardening")
        assert not store.is_muted("U1", "auth-hardening")

    def test_get_muted(self, tmp_path: Path):
        store = MuteStore(tmp_path / "mutes.json")
        store.mute("U1", "spec-a")
        store.mute("U1", "spec-b")
        assert store.get_muted("U1") == {"spec-a", "spec-b"}
        assert store.get_muted("U2") == set()

    def test_persists_to_disk(self, tmp_path: Path):
        path = tmp_path / "mutes.json"
        store = MuteStore(path)
        store.mute("U1", "auth-hardening")
        # Create a new store from the same file
        store2 = MuteStore(path)
        assert store2.is_muted("U1", "auth-hardening")

    def test_handles_missing_file(self, tmp_path: Path):
        store = MuteStore(tmp_path / "nonexistent.json")
        assert store.get_muted("U1") == set()

    def test_handles_corrupt_file(self, tmp_path: Path):
        path = tmp_path / "mutes.json"
        path.write_text("not json")
        store = MuteStore(path)
        assert store.get_muted("U1") == set()


class TestActivityStore:
    def test_record_and_recent(self, tmp_path: Path):
        store = ActivityStore(tmp_path / "activity.json")
        store.record("U1", "Spec approved: auth-hardening", spec_slug="auth-hardening")
        store.record("U1", "Coverage regression: 80% -> 60%", spec_slug="billing")
        entries = store.recent("U1", limit=10)
        assert len(entries) == 2
        # Most recent first
        assert "Coverage" in entries[0].text

    def test_limit_works(self, tmp_path: Path):
        store = ActivityStore(tmp_path / "activity.json")
        for i in range(15):
            store.record("U1", f"Event {i}")
        entries = store.recent("U1", limit=5)
        assert len(entries) == 5

    def test_persists_to_disk(self, tmp_path: Path):
        path = tmp_path / "activity.json"
        store = ActivityStore(path)
        store.record("U1", "Test event")
        store2 = ActivityStore(path)
        assert len(store2.recent("U1")) == 1

    def test_record_for_all(self, tmp_path: Path):
        store = ActivityStore(tmp_path / "activity.json")
        store.record("U1", "setup")
        store.record("U2", "setup")
        store.record_for_all("Broadcast event")
        assert len(store.recent("U1")) == 2
        assert len(store.recent("U2")) == 2


class TestInterestTracker:
    def test_below_threshold_returns_none(self, tmp_path: Path):
        tracker = InterestTracker(tmp_path / "interests.json", threshold=3)
        assert tracker.record_query("U1", "auth") is None
        assert tracker.record_query("U1", "auth") is None

    def test_at_threshold_returns_slug(self, tmp_path: Path):
        tracker = InterestTracker(tmp_path / "interests.json", threshold=3)
        tracker.record_query("U1", "auth")
        tracker.record_query("U1", "auth")
        result = tracker.record_query("U1", "auth")
        assert result == "auth"

    def test_only_suggests_once(self, tmp_path: Path):
        tracker = InterestTracker(tmp_path / "interests.json", threshold=2)
        tracker.record_query("U1", "auth")
        assert tracker.record_query("U1", "auth") == "auth"
        # Subsequent queries don't re-suggest
        assert tracker.record_query("U1", "auth") is None

    def test_get_interests(self, tmp_path: Path):
        tracker = InterestTracker(tmp_path / "interests.json")
        tracker.record_query("U1", "auth")
        tracker.record_query("U1", "auth")
        tracker.record_query("U1", "billing")
        interests = tracker.get_interests("U1")
        assert interests[0] == ("auth", 2)
        assert interests[1] == ("billing", 1)

    def test_persists_to_disk(self, tmp_path: Path):
        path = tmp_path / "interests.json"
        tracker = InterestTracker(path, threshold=2)
        tracker.record_query("U1", "auth")
        tracker.record_query("U1", "auth")
        # New instance should have the data
        tracker2 = InterestTracker(path, threshold=2)
        # Already suggested, so returns None
        assert tracker2.record_query("U1", "auth") is None
        interests = tracker2.get_interests("U1")
        assert interests[0][1] == 3  # 2 + 1 from the new query
