"""Tests for proactive Slack notifications."""

from __future__ import annotations

from datetime import time as dt_time
from unittest.mock import AsyncMock

import pytest
from canon_slack.notifications import (
    NotificationConfig,
    NotificationDispatcher,
    is_quiet_hours,
)


class TestNotificationConfig:
    def test_defaults_all_enabled(self):
        config = NotificationConfig()
        assert config.spec_status_change is True
        assert config.spec_created is True
        assert config.coverage_regression is True

    def test_can_disable_individual(self):
        config = NotificationConfig(spec_created=False)
        assert config.spec_created is False
        assert config.spec_status_change is True


class TestQuietHours:
    def test_outside_quiet_hours(self):
        assert is_quiet_hours(dt_time(12, 0), dt_time(22, 0), dt_time(8, 0)) is False

    def test_inside_quiet_hours(self):
        assert is_quiet_hours(dt_time(23, 0), dt_time(22, 0), dt_time(8, 0)) is True

    def test_inside_quiet_hours_early_morning(self):
        assert is_quiet_hours(dt_time(5, 0), dt_time(22, 0), dt_time(8, 0)) is True

    def test_no_quiet_hours(self):
        assert is_quiet_hours(dt_time(23, 0), None, None) is False


class TestNotificationDispatcher:
    @pytest.mark.asyncio
    async def test_sends_spec_status_change(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})

        dispatcher = NotificationDispatcher(client=client, default_channel="#specs")
        await dispatcher.send_spec_status_change(
            spec_title="auth-hardening",
            old_status="draft",
            new_status="active",
            author="alice",
            github_url="https://github.com/org/repo",
        )

        client.chat_postMessage.assert_called_once()
        kwargs = client.chat_postMessage.call_args[1]
        assert kwargs["channel"] == "#specs"

    @pytest.mark.asyncio
    async def test_skips_when_channel_not_configured(self):
        client = AsyncMock()
        dispatcher = NotificationDispatcher(client=client, default_channel="")
        await dispatcher.send_spec_status_change(
            spec_title="test",
            old_status="a",
            new_status="b",
            author="x",
            github_url="",
        )
        client.chat_postMessage.assert_not_called()

    @pytest.mark.asyncio
    async def test_skips_disabled_notification_type(self):
        client = AsyncMock()
        config = NotificationConfig(spec_status_change=False)
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs", config=config)
        await dispatcher.send_spec_status_change(
            spec_title="test",
            old_status="a",
            new_status="b",
            author="x",
            github_url="",
        )
        client.chat_postMessage.assert_not_called()

    @pytest.mark.asyncio
    async def test_critical_alerts_bypass_quiet_hours(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        config = NotificationConfig()
        dispatcher = NotificationDispatcher(
            client=client,
            default_channel="#specs",
            sre_channel="#alerts",
            config=config,
            quiet_start=dt_time(22, 0),
            quiet_end=dt_time(8, 0),
        )
        # Force quiet hours
        dispatcher._is_quiet = lambda: True

        await dispatcher.send_coverage_regression(
            spec_title="billing",
            coverage_pct=75,
            threshold=80,
            github_url="",
        )
        # Coverage regression is critical — should still send
        client.chat_postMessage.assert_called_once()

    @pytest.mark.asyncio
    async def test_non_critical_suppressed_during_quiet_hours(self):
        client = AsyncMock()
        config = NotificationConfig()
        dispatcher = NotificationDispatcher(
            client=client,
            default_channel="#specs",
            config=config,
            quiet_start=dt_time(22, 0),
            quiet_end=dt_time(8, 0),
        )
        dispatcher._is_quiet = lambda: True

        await dispatcher.send_spec_status_change(
            spec_title="auth",
            old_status="draft",
            new_status="active",
            author="alice",
            github_url="",
        )
        # Non-critical notification should be suppressed during quiet hours
        client.chat_postMessage.assert_not_called()

    @pytest.mark.asyncio
    async def test_critical_delivery_failure_raises(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(side_effect=RuntimeError("API down"))
        config = NotificationConfig()
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs", config=config)

        with pytest.raises(RuntimeError, match="API down"):
            await dispatcher.send_coverage_regression(
                spec_title="billing",
                coverage_pct=75,
                threshold=80,
                github_url="",
            )

    @pytest.mark.asyncio
    async def test_no_channel_logs_warning(self):
        client = AsyncMock()
        dispatcher = NotificationDispatcher(client=client, default_channel="")
        # Should not raise, just log warning and return
        await dispatcher.send_spec_status_change(
            spec_title="test",
            old_status="a",
            new_status="b",
            author="x",
            github_url="",
        )
        client.chat_postMessage.assert_not_called()

    @pytest.mark.asyncio
    async def test_review_requested_sends_with_buttons(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})

        dispatcher = NotificationDispatcher(client=client, default_channel="#specs")
        await dispatcher.send_review_requested(
            spec_title="auth",
            requester="alice",
            github_url="https://github.com/org/repo",
        )
        client.chat_postMessage.assert_called_once()
        blocks = client.chat_postMessage.call_args[1]["blocks"]
        # Should have an actions block with buttons
        action_block = [b for b in blocks if b["type"] == "actions"]
        assert len(action_block) == 1


class TestChannelOverridePriority:
    """Channel resolution: explicit override > per-type CANON.yaml override > default."""

    @pytest.mark.asyncio
    async def test_explicit_override_wins(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(
            client=client,
            default_channel="#default",
            channel_overrides={"spec_created": "#yaml-channel"},
        )
        await dispatcher.send_spec_created(
            spec_title="test",
            owner="alice",
            github_url="",
            channel_override="#explicit",
        )
        assert client.chat_postMessage.call_args[1]["channel"] == "#explicit"

    @pytest.mark.asyncio
    async def test_per_type_override_beats_default(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(
            client=client,
            default_channel="#default",
            channel_overrides={"spec_created": "#yaml-channel"},
        )
        await dispatcher.send_spec_created(spec_title="test", owner="alice", github_url="")
        assert client.chat_postMessage.call_args[1]["channel"] == "#yaml-channel"

    @pytest.mark.asyncio
    async def test_falls_through_to_default(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(
            client=client,
            default_channel="#default",
            channel_overrides={},
        )
        await dispatcher.send_spec_created(spec_title="test", owner="alice", github_url="")
        assert client.chat_postMessage.call_args[1]["channel"] == "#default"


class TestSREChannelRouting:
    """Critical notifications route to sre_channel when configured."""

    @pytest.mark.asyncio
    async def test_coverage_regression_routes_to_sre(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(
            client=client, default_channel="#specs", sre_channel="#sre"
        )
        await dispatcher.send_coverage_regression(
            spec_title="billing", coverage_pct=60, threshold=80, github_url=""
        )
        assert client.chat_postMessage.call_args[1]["channel"] == "#sre"

    @pytest.mark.asyncio
    async def test_ticket_sync_failure_routes_to_sre(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(
            client=client, default_channel="#specs", sre_channel="#sre"
        )
        await dispatcher.send_ticket_sync_failure(system="jira", error="timeout")
        assert client.chat_postMessage.call_args[1]["channel"] == "#sre"

    @pytest.mark.asyncio
    async def test_falls_back_to_default_without_sre(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs", sre_channel="")
        await dispatcher.send_coverage_regression(
            spec_title="billing", coverage_pct=60, threshold=80, github_url=""
        )
        assert client.chat_postMessage.call_args[1]["channel"] == "#specs"


class TestCredentialSanitization:
    """send_ticket_sync_failure strips URLs and tokens before posting to Slack."""

    @pytest.mark.asyncio
    async def test_strips_url_from_error(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs")

        await dispatcher.send_ticket_sync_failure(
            system="jira",
            error="Connection failed: https://jira.internal.corp/api/v2",
        )
        text = client.chat_postMessage.call_args[1]["text"]
        assert "https://" not in text
        assert "jira.internal" not in text

    @pytest.mark.asyncio
    async def test_strips_token_from_error(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs")

        await dispatcher.send_ticket_sync_failure(
            system="linear",
            error="Invalid token: lin_api_abc123xyz",
        )
        blocks = client.chat_postMessage.call_args[1]["blocks"]
        block_text = blocks[0]["text"]["text"]
        assert "lin_api" not in block_text
        assert "server logs" in block_text.lower()

    @pytest.mark.asyncio
    async def test_truncates_long_error(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs")

        long_error = "x" * 200
        await dispatcher.send_ticket_sync_failure(system="jira", error=long_error)
        blocks = client.chat_postMessage.call_args[1]["blocks"]
        block_text = blocks[0]["text"]["text"]
        # Error should be truncated to 80 chars
        assert len(block_text) < 200

    @pytest.mark.asyncio
    async def test_handles_empty_error(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs")

        await dispatcher.send_ticket_sync_failure(system="jira", error="")
        blocks = client.chat_postMessage.call_args[1]["blocks"]
        block_text = blocks[0]["text"]["text"]
        assert "unknown error" in block_text.lower()


class TestTicketSyncFailureCritical:
    """ticket_sync_failure is a critical type — bypasses quiet hours and re-raises on failure."""

    @pytest.mark.asyncio
    async def test_bypasses_quiet_hours(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ok": True})
        dispatcher = NotificationDispatcher(
            client=client,
            default_channel="#specs",
            quiet_start=dt_time(22, 0),
            quiet_end=dt_time(8, 0),
        )
        dispatcher._is_quiet = lambda: True

        await dispatcher.send_ticket_sync_failure(system="jira", error="timeout")
        client.chat_postMessage.assert_called_once()

    @pytest.mark.asyncio
    async def test_delivery_failure_raises(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(side_effect=RuntimeError("Slack down"))
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs")

        with pytest.raises(RuntimeError, match="Slack down"):
            await dispatcher.send_ticket_sync_failure(system="jira", error="timeout")


class TestNonCriticalErrorSuppression:
    """Non-critical delivery errors are logged but not re-raised."""

    @pytest.mark.asyncio
    async def test_non_critical_failure_does_not_raise(self):
        client = AsyncMock()
        client.chat_postMessage = AsyncMock(side_effect=RuntimeError("API error"))
        dispatcher = NotificationDispatcher(client=client, default_channel="#specs")

        # Should not raise — non-critical errors are suppressed
        await dispatcher.send_spec_created(spec_title="test", owner="alice", github_url="")


class TestQuietHoursBoundary:
    """Edge cases for quiet hours time boundaries."""

    def test_at_exact_start_is_quiet(self):
        assert is_quiet_hours(dt_time(22, 0), dt_time(22, 0), dt_time(8, 0)) is True

    def test_at_exact_end_is_not_quiet(self):
        assert is_quiet_hours(dt_time(8, 0), dt_time(22, 0), dt_time(8, 0)) is False

    def test_normal_range_inside(self):
        # Non-wrapping: 9:00-17:00
        assert is_quiet_hours(dt_time(12, 0), dt_time(9, 0), dt_time(17, 0)) is True

    def test_normal_range_outside(self):
        assert is_quiet_hours(dt_time(20, 0), dt_time(9, 0), dt_time(17, 0)) is False

    def test_only_start_is_none(self):
        assert is_quiet_hours(dt_time(12, 0), None, dt_time(17, 0)) is False

    def test_only_end_is_none(self):
        assert is_quiet_hours(dt_time(12, 0), dt_time(9, 0), None) is False
