"""Tests for health score algorithm."""

from __future__ import annotations

import pytest

from canon.health_score import (
    compute_freshness,
    compute_health_score,
    compute_momentum,
    compute_time_to_ship,
)


class TestMomentum:
    def test_flat_activity_scores_50(self):
        score = compute_momentum(this_week=10, prev_week=10, four_wk_avg=10)
        assert score == pytest.approx(50, abs=1)

    def test_growing_activity_above_50(self):
        score = compute_momentum(this_week=20, prev_week=10, four_wk_avg=10)
        assert score > 50

    def test_declining_activity_below_50(self):
        score = compute_momentum(this_week=5, prev_week=10, four_wk_avg=10)
        assert score < 50

    def test_zero_prev_week_no_crash(self):
        score = compute_momentum(this_week=5, prev_week=0, four_wk_avg=0)
        assert 0 <= score <= 100

    def test_all_zero_returns_50(self):
        score = compute_momentum(this_week=0, prev_week=0, four_wk_avg=0)
        assert score == pytest.approx(50, abs=1)

    def test_clamped_to_0_100(self):
        score = compute_momentum(this_week=1000, prev_week=1, four_wk_avg=1)
        assert 0 <= score <= 100


class TestFreshness:
    def test_all_fresh_specs(self):
        specs = [{"staleness_gap": 3, "ac_count": 10}, {"staleness_gap": 5, "ac_count": 5}]
        score = compute_freshness(specs)
        assert score == pytest.approx(100, abs=1)

    def test_stale_spec_penalized(self):
        specs = [{"staleness_gap": 30, "ac_count": 10}]
        score = compute_freshness(specs)
        assert score < 50

    def test_weighted_by_ac_count(self):
        specs = [{"staleness_gap": 0, "ac_count": 100}, {"staleness_gap": 30, "ac_count": 1}]
        score = compute_freshness(specs)
        assert score > 80

    def test_empty_specs_returns_none(self):
        assert compute_freshness([]) is None


class TestTimeToShip:
    def test_improving_cycle_above_50(self):
        score = compute_time_to_ship(current_cycle=5.0, baseline_cycle=10.0)
        assert score > 50

    def test_same_cycle_scores_50(self):
        score = compute_time_to_ship(current_cycle=10.0, baseline_cycle=10.0)
        assert score == pytest.approx(50, abs=1)

    def test_slowing_cycle_below_50(self):
        score = compute_time_to_ship(current_cycle=20.0, baseline_cycle=10.0)
        assert score < 50

    def test_zero_baseline_returns_50(self):
        score = compute_time_to_ship(current_cycle=10.0, baseline_cycle=0.0)
        assert score == pytest.approx(50, abs=1)

    def test_zero_current_cycle_returns_none(self):
        assert compute_time_to_ship(current_cycle=0.0, baseline_cycle=10.0) is None


class TestComposite:
    def test_weighted_composite(self):
        score = compute_health_score(momentum=80, freshness=60, time_to_ship=40)
        expected = 80 * 0.35 + 60 * 0.30 + 40 * 0.35
        assert score == pytest.approx(expected, abs=0.1)

    def test_all_none(self):
        assert compute_health_score(momentum=None, freshness=None, time_to_ship=None) is None

    def test_partial_data(self):
        score = compute_health_score(momentum=80, freshness=None, time_to_ship=60)
        assert score is not None
        assert 0 <= score <= 100
