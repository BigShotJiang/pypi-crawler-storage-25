"""Tests for weekly SRE digest."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from canon.alerts.digest import WeeklyDigest, format_digest_message


class TestWeeklyDigest:
    def test_format_digest_message(self):
        digest = WeeklyDigest(
            total_errors_this_week=42,
            total_errors_last_week=30,
            top_errors=[
                {"type": "KeyError", "message": "'user_id'", "count": 15},
                {"type": "ValueError", "message": "invalid literal", "count": 10},
            ],
            new_errors_count=3,
            cron_success_rate=95.0,
            webhook_p95_ms=450.5,
            open_triage_issues=2,
        )
        text = format_digest_message(digest)
        assert "Weekly SRE Digest" in text
        assert "42" in text
        assert "40.0%" in text  # (42-30)/30 = 40%
        assert "KeyError" in text
        assert "95.0%" in text

    def test_format_digest_no_previous_week(self):
        digest = WeeklyDigest(
            total_errors_this_week=10,
            total_errors_last_week=0,
            top_errors=[],
            new_errors_count=10,
            cron_success_rate=100.0,
            webhook_p95_ms=0,
            open_triage_issues=0,
        )
        text = format_digest_message(digest)
        assert "Weekly SRE Digest" in text
        assert "N/A" in text  # No comparison when last week is 0


class TestRunWeeklyDigest:
    @pytest.mark.asyncio
    async def test_skips_when_slack_not_configured(self):
        with patch("canon.cron.weekly_digest.Settings") as MockSettings:
            MockSettings.return_value = MagicMock(
                slack_alerts_enabled=False,
                slack_alerts_webhook_url="",
            )
            from canon.cron.weekly_digest import run_weekly_digest

            result = await run_weekly_digest.__wrapped__()
            assert result == {"skipped": True}

    @pytest.mark.asyncio
    async def test_skips_when_digest_disabled(self):
        with patch("canon.cron.weekly_digest.Settings") as MockSettings:
            MockSettings.return_value = MagicMock(
                slack_alerts_enabled=True,
                slack_alerts_webhook_url="https://hooks.slack.com/x",
                sre_weekly_digest_enabled=False,
            )
            from canon.cron.weekly_digest import run_weekly_digest

            result = await run_weekly_digest.__wrapped__()
            assert result == {"skipped": True}

    @pytest.mark.asyncio
    async def test_sends_digest_when_enabled(self):
        with (
            patch("canon.cron.weekly_digest.Settings") as MockSettings,
            patch("canon.cron.weekly_digest.SlackAlerter") as MockAlerter,
        ):
            MockSettings.return_value = MagicMock(
                slack_alerts_enabled=True,
                slack_alerts_webhook_url="https://hooks.slack.com/x",
                sre_weekly_digest_enabled=True,
            )
            mock_alerter = AsyncMock()
            MockAlerter.return_value = mock_alerter

            from canon.cron.weekly_digest import run_weekly_digest

            result = await run_weekly_digest.__wrapped__()

            assert result == {"sent": True}
            mock_alerter.send_text.assert_called_once()
            mock_alerter.close.assert_called_once()
