"""Super-admin API routes — prefix /api/admin, gated by PLATFORM_MANAGE."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from canon.admin.config import get_admin_config
from canon.admin.middleware import require_super_admin
from canon.admin.models import (
    AuditEventResponse,
    DashboardResponse,
    HealthSubsystem,
    IntegrationSummary,
    KPIStats,
    OrgMetadataUpdate,
    OrgSummary,
    RoleUpdate,
    SubscriptionSummary,
    UserDeleteConfirm,
    UserOrgMembership,
    UserOrgMembershipAdd,
    UserSummary,
)
from canon.auth.models import CurrentUser

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin", tags=["admin"])


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@router.get("/config")
async def get_config(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return the current AdminConfig (mode + feature flags)."""
    settings = request.app.state.settings
    cfg = get_admin_config(settings)
    return cfg.model_dump()


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


@router.get("/dashboard")
async def get_dashboard(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return KPIs, health summary, and recent audit events."""
    admin_store = getattr(request.app.state, "admin_store", None)
    audit_store = getattr(request.app.state, "audit_store", None)

    kpis = KPIStats()
    health: list[HealthSubsystem] = []
    recent_events: list[AuditEventResponse] = []

    if admin_store is not None:
        try:
            raw_kpis = await admin_store.get_kpis()
            kpis = KPIStats(**raw_kpis)
        except Exception:
            logger.warning("Failed to fetch KPIs", exc_info=True)

        try:
            raw_health = await admin_store.get_health_summary()
            health = [HealthSubsystem(**h) for h in raw_health]
        except Exception:
            logger.warning("Failed to fetch health summary", exc_info=True)

    if audit_store is not None:
        try:
            raw_events = await audit_store.list(limit=10)
            recent_events = [_audit_row_to_response(e) for e in raw_events]
        except Exception:
            logger.warning("Failed to fetch recent audit events", exc_info=True)

    return DashboardResponse(
        kpis=kpis,
        health=health,
        recent_events=recent_events,
    ).model_dump()


# ---------------------------------------------------------------------------
# Orgs
# ---------------------------------------------------------------------------


@router.get("/orgs")
async def list_orgs(
    request: Request,
    search: str | None = None,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return a paginated list of organisations."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    rows = await admin_store.list_orgs(limit=limit, offset=offset, search=search)
    return [OrgSummary(**_coerce_org(r)).model_dump() for r in rows]


@router.get("/orgs/{org}")
async def get_org(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return details for a single org."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")
    row = await admin_store.get_org(org)
    if row is None:
        raise HTTPException(status_code=404, detail="Org not found")
    result = OrgSummary(**_coerce_org(row)).model_dump()
    # Include members list if present (not part of OrgSummary model)
    if "members" in row:
        result["members"] = row["members"]
    return result


@router.post("/orgs/{org}/reindex")
async def reindex_org(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Trigger a reindex for an org (logs an audit event)."""
    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="org.reindex_triggered",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                actor_sub=user.sub,
                org=org,
                detail={"triggered_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for reindex", exc_info=True)

    logger.info("Reindex triggered for org=%s by %s", org, user.sub)
    return {"status": "ok", "org": org}


@router.post("/orgs/{org}/suspend")
async def suspend_org(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Suspend an org (must be currently active)."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    updated = await admin_store.suspend_org(org)
    if updated is None:
        raise HTTPException(status_code=404, detail="Org not found or not active")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="org.suspended",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                actor_sub=user.sub,
                org=org,
                detail={"suspended_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for org suspension", exc_info=True)

    return OrgSummary(**_coerce_org({"login": org, **updated})).model_dump()


@router.post("/orgs/{org}/reactivate")
async def reactivate_org(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Reactivate a suspended org."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    updated = await admin_store.reactivate_org(org)
    if updated is None:
        raise HTTPException(status_code=404, detail="Org not found or not suspended")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="org.reactivated",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                actor_sub=user.sub,
                org=org,
                detail={"reactivated_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for org reactivation", exc_info=True)

    return OrgSummary(**_coerce_org({"login": org, **updated})).model_dump()


@router.post("/orgs/{org}/repair-auth0")
async def repair_org_auth0(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Re-run the idempotent Auth0 provisioning helper for an org.

    Returns 200 with ``status="already_provisioned"`` if the registry already
    has an oidc_org_id (no Auth0 calls made, no audit event), or 200 with the
    fresh status (``provisioned`` / ``reused``) on a successful repair. Cloud
    only — returns 404 in self-hosted mode so the button doesn't appear in
    the wrong context.
    """
    _require_cloud(request)

    admin_store = getattr(request.app.state, "admin_store", None)
    registry = getattr(request.app.state, "registry", None)
    provider = getattr(request.app.state, "oidc_provider", None)
    if admin_store is None or registry is None or provider is None:
        raise HTTPException(status_code=503, detail="Database or auth provider not available")

    existing = await admin_store.get_org(org)
    if existing is None:
        raise HTTPException(status_code=404, detail="Org not found")

    installation_id_raw = existing.get("installation_id")
    if not installation_id_raw:
        raise HTTPException(status_code=400, detail="Org has no GitHub installation to repair")
    try:
        installation_id = int(installation_id_raw)
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=500, detail="Stored installation_id is not numeric"
        ) from exc

    # Local import avoids a circular dependency: github.handlers transitively
    # depends on admin types via observability hooks.
    from canon.github.handlers.on_installation import provision_auth0_org

    try:
        result = await provision_auth0_org(
            provider,
            registry,
            installation_id=installation_id,
            org_login=org,
            skip_if_set=True,
        )
    except Exception as exc:
        logger.warning("Auth0 repair failed for org=%s", org, exc_info=True)
        # Audit the partial-repair attempt so the next call has context
        audit_store = getattr(request.app.state, "audit_store", None)
        if audit_store is not None:
            try:
                await audit_store.log(
                    event_type="org.auth0_partial_repair",
                    resource_type="org",
                    resource_id=org,
                    actor_id=None,
                    actor_sub=user.sub,
                    org=org,
                    detail={"error": str(exc), "attempted_by": user.sub},
                    ip_address=_client_ip(request),
                )
            except Exception:
                logger.warning("Failed to log partial-repair audit event", exc_info=True)
        raise HTTPException(status_code=422, detail=f"Auth0 repair failed: {exc}") from exc

    # Only audit when we actually changed something
    if result.status != "already_provisioned":
        audit_store = getattr(request.app.state, "audit_store", None)
        if audit_store is not None:
            try:
                await audit_store.log(
                    event_type="org.auth0_repair",
                    resource_type="org",
                    resource_id=org,
                    actor_id=None,
                    actor_sub=user.sub,
                    org=org,
                    detail={
                        "oidc_org_id": result.oidc_org_id,
                        "result": result.status,
                        "repaired_by": user.sub,
                    },
                    ip_address=_client_ip(request),
                )
            except Exception:
                logger.warning("Failed to log audit event for Auth0 repair", exc_info=True)

        # Cache invalidation: the org list shows display_name from auth0:orgs,
        # and the new org may not be in the cached list.
        cache = getattr(request.app.state, "cache", None)
        if cache is not None:
            cache.invalidate("auth0:orgs")

    return {
        "status": result.status,
        "oidc_org_id": result.oidc_org_id,
        "org": org,
    }


@router.patch("/orgs/{org}")
async def update_org(
    org: str,
    body: OrgMetadataUpdate,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Update org metadata. Routes display_name to Auth0 and the rest to organizations_meta.

    Returns 400 if the org is suspended (edit blocked while suspended), or
    if no editable fields are provided. Always emits a field-level diff
    audit event with the old and new values.
    """
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    existing = await admin_store.get_org(org)
    if existing is None:
        raise HTTPException(status_code=404, detail="Org not found")
    if existing.get("status") == "suspended":
        raise HTTPException(status_code=400, detail="Cannot edit a suspended organization")

    payload = body.model_dump(exclude_unset=True)
    if not payload:
        raise HTTPException(status_code=400, detail="No fields to update")

    # Validate primary_contact_email if present
    contact_email = payload.get("primary_contact_email")
    if contact_email and "@" not in contact_email:
        raise HTTPException(status_code=400, detail="primary_contact_email is not a valid email")
    notes = payload.get("support_notes")
    if notes is not None and len(notes) > 2000:
        raise HTTPException(status_code=400, detail="support_notes exceeds 2000 character limit")

    diff: dict[str, dict] = {}

    # DB metadata first (idempotent, safely retryable on failure)
    meta_fields = {
        k: payload[k]
        for k in ("primary_contact_email", "primary_contact_name", "support_notes")
        if k in payload and payload[k] is not None
    }
    if meta_fields:
        for k, new_v in meta_fields.items():
            old_v = existing.get(k)
            if new_v != old_v:
                diff[k] = {"old": old_v, "new": new_v}
        await admin_store.update_org_metadata(org, updated_by_sub=user.sub, **meta_fields)

    # Audit the DB changes immediately so they're recorded even if the
    # subsequent Auth0 call fails and raises a 502.
    audit_store = getattr(request.app.state, "audit_store", None)

    async def _emit_audit() -> None:
        if not diff or audit_store is None:
            return
        try:
            await audit_store.log(
                event_type="org.metadata_updated",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                actor_sub=user.sub,
                org=org,
                detail={"diff": diff, "updated_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for org metadata update", exc_info=True)

    # Then route display_name to Auth0 (external call — if this fails the
    # DB write above already committed, and the admin can retry the PATCH)
    new_display_name = payload.get("display_name")
    if new_display_name is not None:
        old_display_name = existing.get("display_name", "") or ""
        auth0_enrichment_failed = existing.get("_auth0_enriched") is False
        if new_display_name != old_display_name or auth0_enrichment_failed:
            settings = request.app.state.settings
            provider = getattr(request.app.state, "oidc_provider", None)
            if provider is None or settings.deployment_mode != "cloud":
                raise HTTPException(
                    status_code=400,
                    detail="display_name updates require an Auth0-backed cloud deployment",
                )
            oidc_org_id = existing.get("oidc_org_id")
            if not oidc_org_id:
                raise HTTPException(
                    status_code=400,
                    detail="Org has no Auth0 organization — run repair-auth0 first",
                )
            try:
                await provider.update_organization(oidc_org_id, display_name=new_display_name)
            except Exception as exc:
                logger.warning("Auth0 update_organization failed for %s", org, exc_info=True)
                # Audit the DB fields that already committed before raising
                await _emit_audit()
                raise HTTPException(
                    status_code=502,
                    detail=f"Auth0 update failed (metadata fields were saved): {exc}",
                ) from exc
            if not auth0_enrichment_failed:
                diff["display_name"] = {"old": old_display_name, "new": new_display_name}
            else:
                diff["display_name"] = {
                    "old": "(unknown — Auth0 was unreachable)",
                    "new": new_display_name,
                }
            # Invalidate cached org list so the new display_name shows up immediately
            cache = getattr(request.app.state, "cache", None)
            if cache is not None:
                cache.invalidate("auth0:orgs")

    await _emit_audit()

    refreshed = await admin_store.get_org(org)
    return OrgSummary(**_coerce_org(refreshed or {"login": org})).model_dump()


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------


@router.get("/users")
async def list_users(
    request: Request,
    org: str | None = None,
    role: str | None = None,
    search: str | None = None,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return a paginated list of users with optional filters."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    rows = await admin_store.list_users(
        limit=limit, offset=offset, org=org, role=role, search=search
    )
    return [UserSummary(**_coerce_user(r)).model_dump() for r in rows]


@router.get("/users/{user_id}")
async def get_user(
    user_id: int,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return details for a single user."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")
    row = await admin_store.get_user(user_id)
    if row is None:
        raise HTTPException(status_code=404, detail="User not found")
    return UserSummary(**_coerce_user(row)).model_dump()


@router.patch("/users/{user_id}")
async def update_user(
    user_id: int,
    body: RoleUpdate,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Update a user's role and emit an audit event."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    # Fetch current state for audit trail
    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")

    updated = await admin_store.update_user_role(user_id, body.role)
    if updated is None:
        raise HTTPException(status_code=404, detail="User not found")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.role_changed",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=existing.get("org_login"),
                detail={
                    "old_role": existing.get("role"),
                    "new_role": body.role,
                    "changed_by": user.sub,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for role change", exc_info=True)

    return UserSummary(**_coerce_user(updated)).model_dump()


@router.post("/users/{user_id}/deactivate")
async def deactivate_user(
    user_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Deactivate a user, revoke all sessions and API keys."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("role") == "super_admin":
        raise HTTPException(status_code=400, detail="Cannot deactivate a super admin")
    if existing.get("status") == "deactivated":
        raise HTTPException(status_code=400, detail="User is already deactivated")

    updated = await admin_store.deactivate_user(user_id)
    if updated is None:
        raise HTTPException(status_code=409, detail="User status changed concurrently")

    session_store = getattr(request.app.state, "session_store", None)
    sessions_revoked = 0
    if session_store is not None:
        sessions_revoked = await session_store.revoke_all_sessions(user_id=user_id)

    user_store = getattr(request.app.state, "user_store", None)
    keys_revoked = 0
    if user_store is not None:
        keys_revoked = await user_store.revoke_all_api_keys(user_id=user_id)

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.deactivated",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=existing.get("org_login"),
                detail={
                    "deactivated_by": user.sub,
                    "sessions_revoked": sessions_revoked,
                    "keys_revoked": keys_revoked,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for user deactivation", exc_info=True)

    result = UserSummary(**_coerce_user(updated)).model_dump()
    result["sessions_revoked"] = sessions_revoked
    result["keys_revoked"] = keys_revoked
    return result


@router.post("/users/{user_id}/reactivate")
async def reactivate_user(
    user_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Reactivate a previously deactivated user."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("status") != "deactivated":
        raise HTTPException(status_code=400, detail="User is not deactivated")

    updated = await admin_store.reactivate_user(user_id)
    if updated is None:
        raise HTTPException(status_code=409, detail="User status changed concurrently")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.reactivated",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=existing.get("org_login"),
                detail={"reactivated_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for user reactivation", exc_info=True)

    return UserSummary(**_coerce_user(updated)).model_dump()


@router.post("/users/{user_id}/resend-invite")
async def resend_user_invite(
    user_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Send a fresh Auth0 organization invitation to an existing user.

    Cloud only. Requires the target user to have an oidc_sub (i.e. they
    have logged in at least once and we know which Auth0 user record to
    invite). Returns the invitation URL — never logged server-side.
    """
    _require_cloud(request)

    admin_store = getattr(request.app.state, "admin_store", None)
    provider = getattr(request.app.state, "oidc_provider", None)
    if admin_store is None or provider is None:
        raise HTTPException(status_code=503, detail="Database or auth provider not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("status") == "deactivated":
        raise HTTPException(status_code=400, detail="Cannot send an invite to a deactivated user")
    oidc_sub = existing.get("oidc_sub")
    if not oidc_sub:
        raise HTTPException(
            status_code=400,
            detail="User has no oidc_sub — cannot resolve Auth0 organization",
        )

    # Resolve which Auth0 org to invite into. We pick the user's first
    # org membership, which matches Canon's single-org-per-user model
    # today (multi-org is tracked separately in multi-org-personal-accounts).
    try:
        orgs = await provider.get_user_orgs(oidc_sub)
    except Exception as exc:
        logger.warning("Auth0 get_user_orgs failed for user %s", user_id, exc_info=True)
        raise HTTPException(status_code=502, detail=f"Auth0 lookup failed: {exc}") from exc
    if not orgs:
        raise HTTPException(
            status_code=400,
            detail="User does not belong to any Auth0 organization",
        )
    org_id = orgs[0].id

    invitee_email = existing.get("email")
    if not invitee_email:
        raise HTTPException(status_code=400, detail="User has no email — cannot send invitation")

    try:
        invite = await provider.create_invitation(
            org_id=org_id,
            inviter_name=user.name or user.email or "Canon Admin",
            invitee_email=invitee_email,
        )
    except Exception as exc:
        logger.warning("Auth0 create_invitation failed for user %s", user_id, exc_info=True)
        raise HTTPException(status_code=502, detail=f"Auth0 invitation failed: {exc}") from exc

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.invite_sent",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=existing.get("org_login"),
                detail={
                    # Never log the invitation_url — it's a single-use credential
                    "oidc_org_id": org_id,
                    "invitee_email": invitee_email,
                    "sent_by": user.sub,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for invite", exc_info=True)

    invitation_url = invite.get("invitation_url")
    if not invitation_url:
        raise HTTPException(
            status_code=502,
            detail="Auth0 returned an invitation without a URL",
        )
    return {
        "invitation_url": invitation_url,
        "expires_at": invite.get("expires_at"),
    }


@router.post("/users/{user_id}/password-reset")
async def send_user_password_reset(
    user_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Generate a password-change ticket for an existing Auth0 user.

    Cloud only. Returns the ticket URL with a 24h TTL — never logged.
    """
    _require_cloud(request)

    admin_store = getattr(request.app.state, "admin_store", None)
    provider = getattr(request.app.state, "oidc_provider", None)
    if admin_store is None or provider is None:
        raise HTTPException(status_code=503, detail="Database or auth provider not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("status") == "deactivated":
        raise HTTPException(
            status_code=400,
            detail="Cannot send a password reset to a deactivated user",
        )
    oidc_sub = existing.get("oidc_sub")
    if not oidc_sub:
        raise HTTPException(
            status_code=400,
            detail="User has no oidc_sub — cannot generate password reset ticket",
        )

    try:
        ticket = await provider.create_password_change_ticket(user_id=oidc_sub)
    except Exception as exc:
        logger.warning(
            "Auth0 create_password_change_ticket failed for user %s",
            user_id,
            exc_info=True,
        )
        raise HTTPException(
            status_code=502, detail=f"Auth0 password reset ticket failed: {exc}"
        ) from exc

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.password_reset_sent",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=existing.get("org_login"),
                detail={
                    # No ticket URL in audit detail — it's a single-use credential
                    "sent_by": user.sub,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for password reset", exc_info=True)

    ticket_url = ticket.get("ticket")
    if not ticket_url:
        raise HTTPException(
            status_code=502,
            detail="Auth0 returned a password reset response without a ticket URL",
        )
    return {"ticket_url": ticket_url}


@router.delete("/users/{user_id}")
async def delete_user(
    user_id: int,
    body: UserDeleteConfirm,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Hard-delete a user from Canon and Auth0 — non-reversible.

    Cloud only. Requires the request body to contain ``confirm`` exactly
    matching the target user's email or login (whichever is non-empty).
    Refuses to delete the acting admin's own user record or any other
    super_admin. The atomic store method rolls back the DB delete if the
    Auth0 call fails.
    """
    _require_cloud(request)

    admin_store = getattr(request.app.state, "admin_store", None)
    user_store = getattr(request.app.state, "user_store", None)
    provider = getattr(request.app.state, "oidc_provider", None)
    if admin_store is None or user_store is None or provider is None:
        raise HTTPException(status_code=503, detail="Database or auth provider not available")

    target = await admin_store.get_user(user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Block deleting another super_admin (no mutual lockout)
    if target.get("role") == "super_admin":
        raise HTTPException(status_code=400, detail="Cannot delete a super admin")

    # Block self-delete by resolving the acting admin's user_id from sub
    if user.sub:
        admin_record = await user_store.get_user_by_sub(user.sub)
        if admin_record and admin_record.get("id") == user_id:
            raise HTTPException(status_code=400, detail="Cannot delete your own account")

    # Typed confirmation must match the target's email OR login
    expected = target.get("email") or target.get("login") or str(user_id)
    if not body.confirm or body.confirm != expected:
        raise HTTPException(
            status_code=400,
            detail=f"confirm must equal '{expected}' to proceed",
        )

    oidc_sub = target.get("oidc_sub", "")
    try:
        snapshot = await admin_store.delete_user_atomic(user_id, auth0_delete=provider.delete_user)
    except Exception as exc:
        logger.warning("GDPR delete failed for user %s", user_id, exc_info=True)
        raise HTTPException(
            status_code=502,
            detail=(
                f"User deleted from Canon but Auth0 deletion failed. "
                f"Manual Auth0 cleanup required — user sub: {oidc_sub}. Error: {exc}"
            ),
        ) from exc

    if snapshot is None:
        raise HTTPException(status_code=409, detail="User changed concurrently — refresh and retry")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            # Pre-delete snapshot stays in the audit detail so the deletion
            # reason is reconstructable even after the row is gone.
            await audit_store.log(
                event_type="user.deleted",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=target.get("org_login"),
                detail={
                    "snapshot": {
                        "id": snapshot.get("id"),
                        "oidc_sub": snapshot.get("oidc_sub"),
                        "email": snapshot.get("email"),
                        "name": snapshot.get("name"),
                        "role": snapshot.get("role"),
                        "status": snapshot.get("status"),
                    },
                    "deleted_by": user.sub,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for user delete", exc_info=True)

    # Cache invalidation: drop the deleted user from the Auth0 enrichment cache
    cache = getattr(request.app.state, "cache", None)
    if cache is not None and snapshot.get("oidc_sub"):
        cache.invalidate(f"auth0:users:{snapshot['oidc_sub']}")

    return {
        "deleted": True,
        "user_id": user_id,
        "email": snapshot.get("email"),
    }


# ---------------------------------------------------------------------------
# Per-user Auth0 org memberships
# ---------------------------------------------------------------------------


@router.get("/users/{user_id}/orgs")
async def list_user_orgs(
    user_id: int,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """List the Auth0 organizations a user currently belongs to.

    Returns each org's ``oidc_org_id``, Auth0 ``name`` / ``display_name``,
    and the matching Canon ``org_login`` when the installation is known.
    Cloud only — self-hosted Canon has no Auth0 to query.
    """
    _require_cloud(request)

    admin_store = getattr(request.app.state, "admin_store", None)
    registry = getattr(request.app.state, "registry", None)
    provider = getattr(request.app.state, "oidc_provider", None)
    if admin_store is None or registry is None or provider is None:
        raise HTTPException(status_code=503, detail="Database or auth provider not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    oidc_sub = existing.get("oidc_sub")
    if not oidc_sub:
        return []

    try:
        orgs = await provider.get_user_orgs(oidc_sub)
    except Exception as exc:
        logger.warning("Auth0 get_user_orgs failed for user %s", user_id, exc_info=True)
        raise HTTPException(status_code=502, detail=f"Auth0 lookup failed: {exc}") from exc

    results: list[dict] = []
    for org in orgs:
        try:
            installation = await registry.get_installation_by_oidc_org(org.id)
        except Exception:
            logger.warning("Registry lookup failed for org %s", org.id, exc_info=True)
            installation = None
        results.append(
            UserOrgMembership(
                oidc_org_id=org.id,
                name=org.name,
                display_name=org.display_name,
                org_login=installation.org_login if installation else None,
            ).model_dump()
        )
    return results


@router.post("/users/{user_id}/orgs")
async def add_user_to_org(
    user_id: int,
    body: UserOrgMembershipAdd,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Add an existing user to an Auth0 organization.

    The request body may specify ``org_login`` (looked up via
    gh_installations to resolve the oidc_org_id) or ``oidc_org_id``
    directly. Emits ``org.member_added`` with the target user_id and the
    resolved org identifiers. Cloud only.
    """
    _require_cloud(request)

    admin_store = getattr(request.app.state, "admin_store", None)
    provider = getattr(request.app.state, "oidc_provider", None)
    if admin_store is None or provider is None:
        raise HTTPException(status_code=503, detail="Database or auth provider not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("status") == "deactivated":
        raise HTTPException(
            status_code=400, detail="Cannot add a deactivated user to an organization"
        )
    oidc_sub = existing.get("oidc_sub")
    if not oidc_sub:
        raise HTTPException(
            status_code=400,
            detail="User has no oidc_sub — they must log in at least once first",
        )

    # Resolve oidc_org_id — either passed directly or mapped from org_login
    oidc_org_id = body.oidc_org_id
    resolved_org_login = None
    if not oidc_org_id:
        # model_validator guarantees at least one field is set
        resolved_org_login = body.org_login
        org_row = await admin_store.get_org(body.org_login)
        if org_row is None:
            raise HTTPException(status_code=404, detail="Canon org not found")
        oidc_org_id = org_row.get("oidc_org_id")
        if not oidc_org_id:
            raise HTTPException(
                status_code=400,
                detail="Canon org has no Auth0 link — run repair-auth0 first",
            )

    try:
        await provider.add_org_member(org_id=oidc_org_id, user_id=oidc_sub)
    except Exception as exc:
        logger.warning(
            "Auth0 add_org_member failed user=%s org=%s",
            user_id,
            oidc_org_id,
            exc_info=True,
        )
        raise HTTPException(status_code=502, detail=f"Auth0 add_org_member failed: {exc}") from exc

    # Invalidate cached member list so the detail page picks up the change
    cache = getattr(request.app.state, "cache", None)
    if cache is not None:
        cache.invalidate(f"auth0:org_members:{oidc_org_id}")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="org.member_added",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=resolved_org_login,
                detail={
                    "oidc_org_id": oidc_org_id,
                    "org_login": resolved_org_login,
                    "added_by": user.sub,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for member add", exc_info=True)

    return {
        "added": True,
        "user_id": user_id,
        "oidc_org_id": oidc_org_id,
        "org_login": resolved_org_login,
    }


@router.delete("/users/{user_id}/orgs/{oidc_org_id}")
async def remove_user_from_org(
    user_id: int,
    oidc_org_id: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Remove a user from an Auth0 organization.

    ``oidc_org_id`` is an Auth0 org ID (e.g. ``org_xYzAbC``).
    Emits ``org.member_removed``. Cloud only.
    """
    _require_cloud(request)

    admin_store = getattr(request.app.state, "admin_store", None)
    registry = getattr(request.app.state, "registry", None)
    provider = getattr(request.app.state, "oidc_provider", None)
    if admin_store is None or registry is None or provider is None:
        raise HTTPException(status_code=503, detail="Database or auth provider not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    oidc_sub = existing.get("oidc_sub")
    if not oidc_sub:
        raise HTTPException(
            status_code=400,
            detail="User has no oidc_sub — nothing to remove",
        )

    # Map oidc_org_id back to Canon org_login for the audit trail (best-effort)
    try:
        installation = await registry.get_installation_by_oidc_org(oidc_org_id)
    except Exception:
        logger.warning("Registry lookup failed for org %s", oidc_org_id, exc_info=True)
        installation = None
    resolved_org_login = installation.org_login if installation else None

    try:
        await provider.remove_org_member(org_id=oidc_org_id, user_id=oidc_sub)
    except Exception as exc:
        logger.warning(
            "Auth0 remove_org_member failed user=%s org=%s",
            user_id,
            oidc_org_id,
            exc_info=True,
        )
        raise HTTPException(
            status_code=502, detail=f"Auth0 remove_org_member failed: {exc}"
        ) from exc

    cache = getattr(request.app.state, "cache", None)
    if cache is not None:
        cache.invalidate(f"auth0:org_members:{oidc_org_id}")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="org.member_removed",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=resolved_org_login,
                detail={
                    "oidc_org_id": oidc_org_id,
                    "org_login": resolved_org_login,
                    "removed_by": user.sub,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for member remove", exc_info=True)

    return {
        "removed": True,
        "user_id": user_id,
        "oidc_org_id": oidc_org_id,
        "org_login": resolved_org_login,
    }


# ---------------------------------------------------------------------------
# Per-user sessions and API keys (cross-org)
# ---------------------------------------------------------------------------


@router.get("/users/{user_id}/sessions")
async def list_user_sessions(
    user_id: int,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """List a user's active refresh-token sessions across all orgs."""
    admin_store = getattr(request.app.state, "admin_store", None)
    session_store = getattr(request.app.state, "session_store", None)
    if admin_store is None or session_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    if await admin_store.get_user(user_id) is None:
        raise HTTPException(status_code=404, detail="User not found")

    rows = await session_store.list_sessions_for_admin(user_id=user_id)
    return [
        {
            "id": r.get("id"),
            "user_id": r.get("user_id"),
            "org_login": r.get("org_login"),
            "device_label": r.get("device_label", ""),
            "created_at": r.get("created_at"),
            "last_used_at": r.get("last_used_at"),
            "expires_at": r.get("expires_at"),
        }
        for r in rows
    ]


@router.delete("/users/{user_id}/sessions/{session_id}")
async def revoke_user_session(
    user_id: int,
    session_id: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Revoke a single refresh-token session.

    Refuses to revoke a session belonging to the acting admin's own user
    record so the admin can't accidentally sign themselves out of the CLI
    while debugging.
    """
    admin_store = getattr(request.app.state, "admin_store", None)
    session_store = getattr(request.app.state, "session_store", None)
    user_store = getattr(request.app.state, "user_store", None)
    if admin_store is None or session_store is None or user_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    target = await admin_store.get_user(user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Block self-revoke: look up the acting admin's DB user_id by sub.
    # If we can't resolve it, we fall through (the admin isn't logged in
    # via a DB-tracked session, so the conflict can't happen).
    if user.sub:
        admin_record = await user_store.get_user_by_sub(user.sub)
        if admin_record and admin_record.get("id") == user_id:
            raise HTTPException(
                status_code=400,
                detail="Cannot revoke your own session via the admin UI",
            )

    revoked = await session_store.revoke_session(session_id=session_id, user_id=user_id)
    if not revoked:
        raise HTTPException(status_code=404, detail="Session not found or already revoked")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.session_revoked",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=target.get("org_login"),
                detail={"session_id": session_id, "revoked_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for session revoke", exc_info=True)

    return {"revoked": True, "session_id": session_id, "user_id": user_id}


@router.get("/users/{user_id}/api-keys")
async def list_user_api_keys(
    user_id: int,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """List a user's active API keys across all orgs (excludes the secret)."""
    admin_store = getattr(request.app.state, "admin_store", None)
    user_store = getattr(request.app.state, "user_store", None)
    if admin_store is None or user_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    if await admin_store.get_user(user_id) is None:
        raise HTTPException(status_code=404, detail="User not found")

    rows = await user_store.list_api_keys_for_admin(user_id=user_id)
    return [
        {
            "id": r.get("id"),
            "label": r.get("label", ""),
            "user_id": r.get("user_id"),
            "org_login": r.get("org_login"),
            "scopes": r.get("scopes") or [],
            "created_at": r.get("created_at"),
            "expires_at": r.get("expires_at"),
            "last_used_at": r.get("last_used_at"),
        }
        for r in rows
    ]


@router.delete("/users/{user_id}/api-keys/{key_id}")
async def revoke_user_api_key(
    user_id: int,
    key_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Revoke a single API key without affecting other keys."""
    admin_store = getattr(request.app.state, "admin_store", None)
    user_store = getattr(request.app.state, "user_store", None)
    if admin_store is None or user_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    target = await admin_store.get_user(user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="User not found")

    revoked = await user_store.revoke_api_key_for_admin(key_id=key_id, user_id=user_id)
    if not revoked:
        raise HTTPException(status_code=404, detail="API key not found or already revoked")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.api_key_revoked",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                actor_sub=user.sub,
                org=target.get("org_login"),
                detail={"key_id": key_id, "revoked_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for api key revoke", exc_info=True)

    return {"revoked": True, "key_id": key_id, "user_id": user_id}


# ---------------------------------------------------------------------------
# Billing (cloud only)
# ---------------------------------------------------------------------------


@router.get("/billing")
async def list_billing(
    request: Request,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return billing overview — cloud deployment only."""
    _require_cloud(request)
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    rows = await admin_store.list_subscriptions(limit=limit, offset=offset)
    return [SubscriptionSummary(**_coerce_subscription(r)).model_dump() for r in rows]


@router.get("/billing/{org}")
async def get_org_billing(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return billing info for a single org — cloud deployment only."""
    _require_cloud(request)
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")
    row = await admin_store.get_org_billing(org)
    if row is None:
        raise HTTPException(status_code=404, detail="Org not found")
    result = SubscriptionSummary(**_coerce_subscription(row)).model_dump()
    # Pass through extra fields from monthly summary
    for extra in ("ai_ops_used", "ai_ops_included"):
        if extra in row:
            result[extra] = row[extra]
    return result


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


@router.get("/health")
async def get_health(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return subsystem health checks."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    try:
        raw = await admin_store.get_health_summary()
        return [HealthSubsystem(**h).model_dump() for h in raw]
    except Exception:
        logger.warning("Health check failed", exc_info=True)
        return []


# ---------------------------------------------------------------------------
# Integrations (read-only stub)
# ---------------------------------------------------------------------------


@router.get("/integrations")
async def list_integrations(
    request: Request,
    provider: str | None = None,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return platform integrations."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    rows = await admin_store.list_integrations(limit=limit, offset=offset, provider=provider)
    return [IntegrationSummary(**_coerce_integration(r)).model_dump() for r in rows]


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------


@router.get("/audit")
async def list_audit_events(
    request: Request,
    org: str | None = None,
    event_type: str | None = None,
    actor_id: int | None = None,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return paginated audit events with optional filters."""
    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is None:
        return []
    rows = await audit_store.list(
        org=org,
        event_type=event_type,
        actor_id=actor_id,
        limit=limit,
        offset=offset,
    )
    return [_audit_row_to_response(r).model_dump() for r in rows]


# ---------------------------------------------------------------------------
# AI ops
# ---------------------------------------------------------------------------


@router.get("/ai")
async def get_ai_overview(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return AI ops overview."""
    _empty: dict = {"ops_today": 0, "ops_this_month": 0, "orgs": []}
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return _empty
    try:
        result = await admin_store.get_ai_ops_summary()
        if not isinstance(result, dict):
            return _empty
        return result
    except Exception:
        logger.warning("Failed to fetch AI ops summary", exc_info=True)
        return _empty


@router.get("/ai/{org}")
async def get_ai_org(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return per-org AI ops metrics."""
    _empty: dict = {"org": org, "ops_today": 0, "ops_this_month": 0}
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return _empty
    try:
        result = await admin_store.get_org_ai_usage(org)
        if not isinstance(result, dict):
            return _empty
        return result
    except Exception:
        logger.warning("Failed to fetch AI ops for org=%s", org, exc_info=True)
        return _empty


# ---------------------------------------------------------------------------
# Search parity (Phase 2 OpenSearch cutover validation)
# ---------------------------------------------------------------------------


@router.get("/search-parity")
async def get_search_parity(
    request: Request,
    q: str = Query(..., min_length=1, description="Query text to compare"),
    repo: str | None = Query(None, description="Restrict to a single repo"),
    status: str | None = Query(None, description="Restrict to a section status"),
    limit: int = Query(20, ge=1, le=50),
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Run a single query against both Postgres and OpenSearch backends.

    Returns top-N results from each plus parity metrics (overlap@5/10/20,
    rank correlation). Used during the Phase 2 cutover to verify that
    OpenSearch returns results comparable to Postgres before flipping
    ``OPENSEARCH_ENABLED`` for all users.
    """
    from canon.search.backend import OpenSearchBackend, PostgresSearchBackend
    from canon.search.parity import compare_query

    search_index = getattr(request.app.state, "search_index", None)
    opensearch_client = getattr(request.app.state, "opensearch_client", None)

    if search_index is None:
        raise HTTPException(status_code=503, detail="Search index not available")
    if opensearch_client is None or not opensearch_client.is_enabled:
        raise HTTPException(status_code=503, detail="OpenSearch not enabled")

    pg_backend = PostgresSearchBackend(search_index)
    os_backend = OpenSearchBackend(opensearch_client)
    embed_client = getattr(request.app.state, "embed_client", None)

    comparison = await compare_query(
        query=q,
        postgres=pg_backend,
        opensearch=os_backend,
        embed_client=embed_client,
        repo=repo,
        status=status,
        limit=limit,
    )
    return comparison.to_dict()


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _require_cloud(request: Request) -> None:
    """Raise 404 if the deployment mode is not cloud."""
    settings = request.app.state.settings
    if settings.deployment_mode != "cloud":
        raise HTTPException(status_code=404, detail="Not available in self-hosted mode")


def _client_ip(request: Request) -> str | None:
    """Extract the originating IP address from the request.

    With a single trusted proxy (nginx-ingress), the client IP is the
    rightmost-minus-one value.  When only one value exists (no upstream
    proxies), it *is* the client IP.  ``X-Real-IP`` set by nginx is
    preferred when available since it's not spoofable.
    """
    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip.strip()
    forwarded_for = request.headers.get("x-forwarded-for")
    if forwarded_for:
        # nginx-ingress appends the real client IP as the rightmost entry
        return forwarded_for.split(",")[-1].strip()
    client = request.client
    return client.host if client else None


def _coerce_org(row: dict) -> dict:
    """Coerce an asyncpg row dict into OrgSummary constructor kwargs."""
    result = {
        "login": row.get("login", ""),
        "installation_id": str(row["installation_id"]) if row.get("installation_id") else None,
        "user_count": row.get("member_count") or 0,
        "created_at": row.get("created_at"),
        "status": row.get("status", "active"),
        "display_name": row.get("display_name", ""),
        "member_count": row.get("member_count"),
        "primary_contact_email": row.get("primary_contact_email"),
        "primary_contact_name": row.get("primary_contact_name"),
        "support_notes": row.get("support_notes"),
        "oidc_org_id": row.get("oidc_org_id"),
    }
    # Derive member_count from members list if present
    members = row.get("members")
    if members is not None and result["member_count"] is None:
        result["member_count"] = len(members)
    return result


def _coerce_user(row: dict) -> dict:
    """Coerce an asyncpg row dict into UserSummary constructor kwargs."""
    return {
        "id": row.get("id", 0),
        "login": row.get("login", ""),
        "email": row.get("email", ""),
        "role": row.get("role", ""),
        "status": row.get("status", "active"),
        "org_login": row.get("org_login", ""),
        "created_at": row.get("created_at"),
        "last_login": row.get("last_login"),
        "login_count": row.get("login_count"),
        "email_verified": row.get("email_verified"),
        "picture": row.get("picture"),
        "identities": row.get("identities"),
    }


def _coerce_subscription(row: dict) -> dict:
    """Coerce a subscriptions row into SubscriptionSummary constructor kwargs."""
    return {
        "org_login": row.get("org_login", ""),
        "plan": row.get("plan", ""),
        "status": row.get("status", ""),
        "seat_count": row.get("seat_count", 0),
        "billing_cycle": row.get("billing_cycle", ""),
        "stripe_customer_id": row.get("stripe_customer_id"),
        "current_period_start": row.get("current_period_start"),
        "current_period_end": row.get("current_period_end"),
    }


def _coerce_integration(row: dict) -> dict:
    """Coerce an org_integrations row into IntegrationSummary constructor kwargs."""
    return {
        "org_login": row.get("org_login", ""),
        "provider": row.get("provider", ""),
        "display_name": row.get("display_name", ""),
        "status": row.get("status", ""),
        "connected_by": row.get("connected_by"),
        "connected_at": row.get("connected_at"),
    }


def _audit_row_to_response(row: dict) -> AuditEventResponse:
    """Convert a raw audit row dict to AuditEventResponse."""
    import json as _json

    detail = row.get("detail")
    if isinstance(detail, str):
        try:
            detail = _json.loads(detail)
        except (ValueError, TypeError):
            detail = None

    return AuditEventResponse(
        id=str(row.get("id", "")),
        event_type=row.get("event_type", ""),
        resource_type=row.get("resource_type", ""),
        resource_id=str(row.get("resource_id", "")),
        actor_id=row.get("actor_id"),
        org=row.get("org"),
        detail=detail,
        ip_address=str(ip) if (ip := row.get("ip_address")) else None,
        created_at=row.get("created_at"),
    )
