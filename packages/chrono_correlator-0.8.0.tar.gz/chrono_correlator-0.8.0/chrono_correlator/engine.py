from datetime import datetime

import numpy as np

from .correlator import analyze
from .models import AlertReport, CorrelationResult, Event, Metric, SignificanceConfig

THRESHOLDS = {"green": (0, 2), "yellow": (3, 4), "red": (5, 7)}


def _apply_correction(
    results: list[CorrelationResult], method: str, cfg: SignificanceConfig
) -> None:
    p_values = np.array([r.p_value for r in results])

    if method == "bonferroni":
        adjusted = np.minimum(p_values * len(p_values), 1.0)
    elif method == "fdr":
        from scipy.stats import false_discovery_control
        adjusted = false_discovery_control(p_values, method="bh")
    else:
        raise ValueError(f"Unknown correction method '{method}'. Use 'bonferroni' or 'fdr'.")

    for r, p_adj in zip(results, adjusted):
        r.adjusted_p_value = float(p_adj)
        r.significant = bool(
            p_adj < cfg.alpha and r.signal_strength in ("strong", "moderate")
        )


def evaluate(
    events: list[Event],
    metrics: list[Metric],
    lookback_hours: int = 48,
    baseline_days: int = 28,
    lag_hours: int = 0,
    correction: str | None = "fdr",
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
) -> AlertReport:
    cfg = config or SignificanceConfig()
    results: list[CorrelationResult] = []

    for metric in metrics:
        try:
            results.append(
                analyze(events, metric, lookback_hours, baseline_days, lag_hours, direction, cfg)
            )
        except ValueError:
            continue

    if correction and results:
        _apply_correction(results, correction, cfg)

    active = sum(1 for r in results if r.significant)

    if active <= 2:
        level = "green"
    elif active <= 4:
        level = "yellow"
    else:
        level = "red"

    return AlertReport(
        level=level,
        active_signals=active,
        total_signals=len(results),
        results=results,
        narrative=None,
    )


def monitor(
    metrics: list[Metric],
    lookback_hours: int = 48,
    baseline_days: int = 28,
    lag_hours: int = 0,
    correction: str | None = "fdr",
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
    provider: str = "groq",
    narrate: bool = True,
) -> AlertReport:
    """Evaluate current state without requiring past events."""
    from .narrator import narrate as _narrate

    now = datetime.now()
    synthetic_event = [Event(timestamp=now, label="monitor")]

    report = evaluate(
        synthetic_event, metrics, lookback_hours, baseline_days, lag_hours,
        correction, direction, config
    )

    if narrate and report.level != "green":
        report = _narrate(report, provider=provider)

    return report
