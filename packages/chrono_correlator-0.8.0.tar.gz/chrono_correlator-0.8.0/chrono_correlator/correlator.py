import numpy as np
from scipy import stats

from .models import CorrelationResult, Event, Metric, SignificanceConfig

_DEFAULT_CONFIG = SignificanceConfig()


def _classify_strength(abs_effect: float, consistency: float, cfg: SignificanceConfig) -> str:
    if abs_effect > cfg.strong_effect and consistency > cfg.strong_consistency:
        return "strong"
    if abs_effect > cfg.moderate_effect and consistency > cfg.moderate_consistency:
        return "moderate"
    if abs_effect > cfg.weak_effect:
        return "weak"
    return "none"


def analyze(
    events: list[Event],
    metric: Metric,
    lookback_hours: int = 48,
    baseline_days: int = 28,
    lag_hours: int = 0,
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
) -> CorrelationResult:
    """Analyze correlation between a metric and events using Mann-Whitney U.

    direction: "two-sided" | "increase" | "decrease"
        "increase" → tests if pre-event values are higher than baseline
        "decrease" → tests if pre-event values are lower than baseline
    """
    if direction not in ("two-sided", "increase", "decrease"):
        raise ValueError(
            f"Invalid direction '{direction}'. Use 'two-sided', 'increase', or 'decrease'."
        )
    cfg = config or _DEFAULT_CONFIG
    alternative = {"two-sided": "two-sided", "increase": "greater", "decrease": "less"}[direction]

    ts = np.array([t.timestamp() for t in metric.timestamps])
    vals = np.array(metric.values)

    pre_event_values: list[float] = []
    baseline_values: list[float] = []
    per_event_pre_medians: list[float] = []

    for event in events:
        t_event = event.timestamp.timestamp()
        t_pre_end = t_event - lag_hours * 3600
        t_pre_start = t_pre_end - lookback_hours * 3600
        t_baseline_start = t_event - baseline_days * 86400

        mask_pre = (ts >= t_pre_start) & (ts < t_pre_end)
        mask_baseline = (ts >= t_baseline_start) & (ts < t_pre_start)

        pre_vals = vals[mask_pre]
        pre_event_values.extend(pre_vals.tolist())
        baseline_values.extend(vals[mask_baseline].tolist())

        if len(pre_vals) >= 1:
            per_event_pre_medians.append(float(np.median(pre_vals)))

    n1, n2 = len(pre_event_values), len(baseline_values)

    if n1 < 3 or n2 < 3:
        raise ValueError(
            f"Datos insuficientes para '{metric.name}'. "
            f"Pre-evento: {n1}, Baseline: {n2}"
        )

    stat, p_value = stats.mannwhitneyu(
        pre_event_values, baseline_values, alternative=alternative
    )
    effect_size = float(1 - (2 * stat) / (n1 * n2))

    overall_pre_median = float(np.median(pre_event_values))
    overall_baseline_median = float(np.median(baseline_values))

    if per_event_pre_medians and overall_pre_median != overall_baseline_median:
        trend = 1 if overall_pre_median > overall_baseline_median else -1
        consistent = sum(
            1 for m in per_event_pre_medians
            if (m - overall_baseline_median) * trend > 0
        )
        consistency = consistent / len(per_event_pre_medians)
    else:
        consistency = 0.0

    abs_effect = abs(effect_size)
    signal_strength = _classify_strength(abs_effect, consistency, cfg)
    causality_score = round(0.5 * min(abs_effect, 1.0) + 0.5 * consistency, 4)
    significant = bool(p_value < cfg.alpha and signal_strength in ("strong", "moderate"))

    return CorrelationResult(
        metric_name=metric.name,
        p_value=float(p_value),
        significant=significant,
        effect_size=effect_size,
        baseline_median=overall_baseline_median,
        pre_event_median=overall_pre_median,
        consistency=round(consistency, 4),
        signal_strength=signal_strength,
        causality_score=causality_score,
        narrative=None,
    )
