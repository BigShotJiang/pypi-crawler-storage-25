from .correlator import analyze
from .engine import evaluate, monitor
from .models import AlertReport, CorrelationResult, Event, Metric, SignificanceConfig
from .monitor_loop import loop
from .narrator import AnthropicNarrator, BaseNarrator, GroqNarrator, OllamaNarrator, narrate
from .synthetic import generate_events, generate_metric, inject_pattern, shift_events, shuffle_metric

__version__ = "0.8.0"

__all__ = [
    "analyze",
    "evaluate",
    "monitor",
    "loop",
    "narrate",
    "BaseNarrator",
    "GroqNarrator",
    "AnthropicNarrator",
    "OllamaNarrator",
    "generate_metric",
    "generate_events",
    "inject_pattern",
    "shuffle_metric",
    "shift_events",
    "Event",
    "Metric",
    "CorrelationResult",
    "AlertReport",
    "SignificanceConfig",
    "__version__",
]
