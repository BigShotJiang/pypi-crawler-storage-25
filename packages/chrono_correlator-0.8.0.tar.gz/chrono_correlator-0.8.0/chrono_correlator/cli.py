"""chrono-correlator CLI — chrono analyze metrics.csv events.csv"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import datetime


def _load_metric(path: str, name: str, timestamp_col: str, value_col: str):
    from .models import Metric

    timestamps, values = [], []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            timestamps.append(datetime.fromisoformat(row[timestamp_col]))
            values.append(float(row[value_col]))
    return Metric(name=name, timestamps=timestamps, values=values)


def _load_events(path: str, timestamp_col: str, label_col: str):
    from .models import Event

    events = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            events.append(
                Event(
                    timestamp=datetime.fromisoformat(row[timestamp_col]),
                    label=row[label_col],
                )
            )
    return events


def _level_icon(level: str) -> str:
    return {"green": "[GREEN]", "yellow": "[YELLOW]", "red": "[RED]"}.get(level, level)


def _report_to_dict(report) -> dict:
    return {
        "level": report.level,
        "active_signals": report.active_signals,
        "total_signals": report.total_signals,
        "narrative": report.narrative,
        "results": [
            {
                "metric_name": r.metric_name,
                "p_value": r.p_value,
                "adjusted_p_value": r.adjusted_p_value,
                "significant": r.significant,
                "effect_size": r.effect_size,
                "baseline_median": r.baseline_median,
                "pre_event_median": r.pre_event_median,
                "consistency": r.consistency,
                "signal_strength": r.signal_strength,
                "causality_score": r.causality_score,
                "narrative": r.narrative,
            }
            for r in report.results
        ],
    }


def _cmd_analyze(args) -> None:
    from .engine import evaluate
    from .narrator import narrate

    metric = _load_metric(
        args.metrics_csv,
        name=args.name,
        timestamp_col=args.timestamp_col,
        value_col=args.value_col,
    )
    events = _load_events(
        args.events_csv,
        timestamp_col=args.event_timestamp_col,
        label_col=args.event_label_col,
    )

    correction = None if args.correction == "none" else args.correction
    report = evaluate(
        events,
        [metric],
        lookback_hours=args.lookback,
        baseline_days=args.baseline,
        lag_hours=args.lag,
        correction=correction,
        direction=args.direction,
    )

    if args.narrate and report.level != "green":
        report = narrate(report, provider=args.provider)

    if args.json:
        print(json.dumps(_report_to_dict(report), indent=2))
        return

    icon = _level_icon(report.level)
    print(f"\n{icon}  Level: {report.level.upper()}")
    print(f"   Signals: {report.active_signals}/{report.total_signals}")

    for r in report.results:
        p = r.adjusted_p_value if r.adjusted_p_value is not None else r.p_value
        sig = "+" if r.significant else "-"
        print(
            f"\n   [{sig}] {r.metric_name}"
            f"\n       p={p:.4f}  effect={r.effect_size:.3f}"
            f"\n       consistency={r.consistency:.2f}  causality={r.causality_score:.2f}"
            f"\n       baseline_median={r.baseline_median:.2f}"
            f"  pre_event_median={r.pre_event_median:.2f}"
        )
        if r.narrative:
            print(f"       {r.narrative}")

    if report.narrative:
        print(f"\n   Narrative:\n   {report.narrative}")

    print()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="chrono",
        description="chrono-correlator — correlate time-series with discrete events",
    )
    sub = parser.add_subparsers(dest="command")

    a = sub.add_parser("analyze", help="Analyze correlations between a metric and events")
    a.add_argument("metrics_csv", help="CSV with metric data")
    a.add_argument("events_csv", help="CSV with event timestamps")
    a.add_argument("--name", default="metric", help="Metric name (default: metric)")
    a.add_argument("--timestamp-col", default="timestamp", dest="timestamp_col")
    a.add_argument("--value-col", default="value", dest="value_col")
    a.add_argument("--event-timestamp-col", default="timestamp", dest="event_timestamp_col")
    a.add_argument("--event-label-col", default="label", dest="event_label_col")
    a.add_argument("--lookback", type=int, default=48, help="Pre-event window in hours")
    a.add_argument("--baseline", type=int, default=28, help="Baseline window in days")
    a.add_argument("--lag", type=int, default=0, help="Lag offset in hours")
    a.add_argument("--correction", default="fdr", choices=["fdr", "bonferroni", "none"])
    a.add_argument(
        "--direction", default="two-sided",
        choices=["two-sided", "increase", "decrease"],
        help="Expected signal direction (default: two-sided)",
    )
    a.add_argument("--narrate", action="store_true", help="Add LLM narration")
    a.add_argument("--provider", default="groq", choices=["groq", "anthropic", "ollama"])
    a.add_argument("--json", action="store_true", dest="json", help="Output results as JSON")

    if len(sys.argv) == 1:
        parser.print_help()
        return

    args = parser.parse_args()

    if args.command == "analyze":
        _cmd_analyze(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
