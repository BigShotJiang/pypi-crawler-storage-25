from datetime import datetime, timedelta

from chrono_correlator.models import Event, Metric, SignificanceConfig
from chrono_correlator.engine import evaluate, monitor

BASE = datetime(2024, 1, 1)
EVENT_DAYS = [10, 20, 30]
EVENTS = [Event(timestamp=BASE + timedelta(days=d), label="test") for d in EVENT_DAYS]


def _flat_metric(name: str, hours: int = 700, value: float = 55.0) -> Metric:
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    return Metric(name=name, timestamps=timestamps, values=[value] * hours)


def _pattern_metric(name: str, hours: int = 700) -> Metric:
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [55.0] * hours
    for day in EVENT_DAYS:
        for h in range(48):
            idx = day * 24 - 48 + h
            if 0 <= idx < hours:
                values[idx] = 30.0
    return Metric(name=name, timestamps=timestamps, values=values)


def test_green_level():
    metrics = [_flat_metric(f"m{i}") for i in range(7)]
    report = evaluate(EVENTS, metrics)
    assert report.level == "green"
    assert report.narrative is None


def test_yellow_level():
    metrics = [_pattern_metric(f"m{i}") for i in range(3)] + [
        _flat_metric(f"flat{i}") for i in range(4)
    ]
    report = evaluate(EVENTS, metrics)
    assert report.level == "yellow"
    assert report.active_signals == 3


def test_red_level():
    metrics = [_pattern_metric(f"m{i}") for i in range(5)] + [
        _flat_metric(f"flat{i}") for i in range(2)
    ]
    report = evaluate(EVENTS, metrics)
    assert report.level == "red"
    assert report.active_signals >= 5


def test_skips_insufficient_metrics():
    tiny = Metric(
        name="tiny",
        timestamps=[BASE + timedelta(hours=h) for h in range(2)],
        values=[55.0, 55.0],
    )
    metrics = [tiny, _flat_metric("good")]
    report = evaluate(EVENTS, metrics)
    assert report.total_signals == 1
    assert report.level == "green"


def test_pattern_metric_is_strong_or_moderate():
    report = evaluate(EVENTS, [_pattern_metric("hrv")], correction=None)
    r = report.results[0]
    assert r.signal_strength in ("strong", "moderate")
    assert r.causality_score > 0.5
    assert r.consistency > 0.6


def test_flat_metric_is_weak_or_none():
    report = evaluate(EVENTS, [_flat_metric("hrv")], correction=None)
    r = report.results[0]
    assert r.signal_strength in ("weak", "none")
    assert r.causality_score < 0.5


def test_fdr_correction_sets_adjusted_p():
    metrics = [_pattern_metric("m0"), _flat_metric("m1")]
    report = evaluate(EVENTS, metrics, correction="fdr")
    for r in report.results:
        assert r.adjusted_p_value is not None


def test_bonferroni_correction():
    metrics = [_pattern_metric("m0"), _flat_metric("m1")]
    report = evaluate(EVENTS, metrics, correction="bonferroni")
    for r in report.results:
        assert r.adjusted_p_value is not None


def test_no_correction():
    metrics = [_pattern_metric("m0"), _flat_metric("m1")]
    report = evaluate(EVENTS, metrics, correction=None)
    for r in report.results:
        assert r.adjusted_p_value is None


def test_lag_hours_shifts_window():
    hours = 700
    timestamps = [BASE + timedelta(hours=h) for h in range(hours)]
    values = [55.0] * hours
    for day in EVENT_DAYS:
        for h in range(48):
            idx = day * 24 - 96 + h
            if 0 <= idx < hours:
                values[idx] = 30.0
    metric = Metric(name="hrv", timestamps=timestamps, values=values)

    result_no_lag = evaluate(EVENTS, [metric], lag_hours=0, correction=None).results[0]
    result_with_lag = evaluate(EVENTS, [metric], lag_hours=48, correction=None).results[0]

    assert result_with_lag.pre_event_median < result_with_lag.baseline_median
    assert result_no_lag.pre_event_median >= result_no_lag.baseline_median


def _now_metric(name: str, hours: int = 700, value: float = 55.0) -> Metric:
    now = datetime.now()
    timestamps = [now - timedelta(hours=hours - h) for h in range(hours)]
    return Metric(name=name, timestamps=timestamps, values=[value] * hours)


def _now_pattern_metric(name: str, hours: int = 700) -> Metric:
    now = datetime.now()
    timestamps = [now - timedelta(hours=hours - h) for h in range(hours)]
    values = [55.0] * hours
    for h in range(48):
        values[hours - 48 + h] = 30.0
    return Metric(name=name, timestamps=timestamps, values=values)


def test_monitor_green_returns_no_narrative():
    metrics = [_now_metric(f"m{i}") for i in range(3)]
    report = monitor(metrics, narrate=False)
    assert report.level == "green"
    assert report.narrative is None


def test_monitor_detects_pattern():
    metrics = [_now_pattern_metric(f"m{i}") for i in range(5)] + [
        _now_metric(f"flat{i}") for i in range(2)
    ]
    report = monitor(metrics, narrate=False)
    assert report.level == "red"
    assert report.active_signals >= 5


def test_monitor_no_narrate_on_green():
    metrics = [_now_metric(f"m{i}") for i in range(3)]
    report = monitor(metrics, narrate=True)
    assert report.narrative is None


def test_direction_parameter_passes_through():
    report = evaluate(EVENTS, [_pattern_metric("hrv")], correction=None, direction="decrease")
    r = report.results[0]
    assert r.significant is True
    assert r.pre_event_median < r.baseline_median


def test_direction_increase_on_drop_not_significant():
    report = evaluate(EVENTS, [_pattern_metric("hrv")], correction=None, direction="increase")
    r = report.results[0]
    assert r.significant is False


def test_significance_config_in_evaluate():
    cfg = SignificanceConfig(alpha=0.0)
    report = evaluate(EVENTS, [_pattern_metric("hrv")], correction=None, config=cfg)
    assert report.results[0].significant is False
    assert report.level == "green"
