# SPDX-License-Identifier: AGPL-3.0-or-later
import click

from nexus.commands.store import _t3
from nexus.corpus import embedding_model_for_collection, index_model_for_collection


@click.group()
def collection() -> None:
    """Manage ChromaDB collections (list, info, verify, delete)."""


@collection.command("list")
def list_cmd() -> None:
    """List all T3 collections with document counts."""
    cols = _t3().list_collections()
    if not cols:
        click.echo("No collections found.")
        return
    width = max(len(c["name"]) for c in cols)
    for c in sorted(cols, key=lambda x: x["name"]):
        click.echo(f"{c['name']:<{width}}  {c['count']:>6} docs")


@collection.command("info")
@click.argument("name")
def info_cmd(name: str) -> None:
    """Show details for a single collection."""
    db = _t3()
    cols = db.list_collections()
    match = next((c for c in cols if c["name"] == name), None)
    if match is None:
        raise click.ClickException(f"collection not found: {name!r} — use: nx collection list")

    query_model = embedding_model_for_collection(name)
    idx_model   = index_model_for_collection(name)

    info = db.collection_info(name)

    col = db.get_or_create_collection(name)
    # Paginate for accurate MAX(indexed_at) timestamp (nexus-j857).
    all_timestamps: list[str] = []
    offset = 0
    while True:
        batch = col.get(limit=300, offset=offset, include=["metadatas"])
        for meta in batch.get("metadatas") or []:
            if meta and "indexed_at" in meta:
                all_timestamps.append(meta["indexed_at"])
        if len(batch.get("ids", [])) < 300:
            break
        offset += 300
    last_indexed = max(all_timestamps) if all_timestamps else "unknown"

    click.echo(f"Collection:  {match['name']}")
    click.echo(f"Documents:   {match['count']}")
    click.echo(f"Index model: {idx_model}")
    click.echo(f"Query model: {query_model}")
    click.echo(f"Indexed:     {last_indexed}")


@collection.command("delete")
@click.argument("name")
@click.option("--yes", "-y", "--confirm", is_flag=True, help="Skip interactive confirmation prompt")
def delete_cmd(name: str, yes: bool) -> None:
    """Delete a T3 collection (irreversible)."""
    if not yes:
        click.confirm(f"Delete collection '{name}'? This cannot be undone.", abort=True)
    _t3().delete_collection(name)
    click.echo(f"Deleted: {name}")


@collection.command("reindex")
@click.argument("name")
@click.option("--force", is_flag=True, help="Force reindex even if sourceless entries exist")
def reindex_cmd(name: str, force: bool) -> None:
    """Delete and re-index a collection from its source files."""
    from pathlib import Path

    from nexus.db.t3 import verify_collection_deep
    from nexus.doc_indexer import batch_index_markdowns, index_markdown, index_pdf

    db = _t3()

    # 1. Check collection exists
    try:
        info = db.collection_info(name)
    except KeyError:
        raise click.ClickException(f"collection not found: {name!r}")

    before_count = info["count"]

    # 2. Pre-delete safety: paginate for sourceless entries (nexus-unyc)
    col = db.get_or_create_collection(name)
    sourceless: list[str] = []
    source_paths: set[str] = set()
    offset = 0
    while True:
        batch = col.get(limit=300, offset=offset, include=["metadatas"])
        for mid, meta in zip(batch["ids"], batch["metadatas"] or []):
            sp = (meta or {}).get("source_path", "")
            if sp:
                source_paths.add(sp)
            else:
                sourceless.append(mid)
        if len(batch["ids"]) < 300:
            break
        offset += 300

    if sourceless and not force:
        raise click.ClickException(
            f"{len(sourceless)} entries lack source_path (manual entries). "
            f"These cannot be re-indexed and will be LOST. Use --force to proceed."
        )

    # 3. Delete collection
    click.echo(f"Deleting collection '{name}' ({before_count} documents)...")
    db.delete_collection(name)

    # 5. Re-index based on collection type
    # Derive corpus from collection name so chunk metadata gets correct provenance.
    # e.g. "rdr__nexus-abc123" → "nexus-abc123", "docs__manual" → "manual"
    corpus = name.split("__", 1)[1] if "__" in name else ""

    indexed = 0
    missing: list[str] = []

    if name.startswith("code__"):
        click.echo(
            f"Re-indexing code collection — use 'nx index repo <path>' for full re-index"
        )
        click.echo(f"Source paths: {len(source_paths)} files")

    elif name.startswith("rdr__"):
        rdr_files = [Path(sp) for sp in source_paths if Path(sp).exists()]
        missing = [sp for sp in source_paths if not Path(sp).exists()]
        if rdr_files:
            click.echo(f"Re-indexing {len(rdr_files)} RDR documents...")
            try:
                batch_index_markdowns(
                    rdr_files, corpus=corpus, collection_name=name, force=True
                )
            except Exception as exc:
                click.echo(
                    f"Re-indexing failed: {exc}\n"
                    f"Collection '{name}' was deleted. Re-run 'nx collection reindex {name}' "
                    f"after resolving the error, or re-index manually.",
                    err=True,
                )
                raise click.exceptions.Exit(1)
            indexed = len(rdr_files)

    elif name.startswith("docs__") or name.startswith("knowledge__"):
        for sp in source_paths:
            p = Path(sp)
            if not p.exists():
                missing.append(sp)
                continue
            try:
                if p.suffix.lower() == ".pdf":
                    index_pdf(p, corpus=corpus, collection_name=name, force=True)
                else:
                    index_markdown(p, corpus=corpus, collection_name=name, force=True)
                indexed += 1
            except Exception as exc:
                click.echo(f"  Warning: failed to re-index {p.name}: {exc}", err=True)

    else:
        click.echo(f"Unknown collection type for '{name}' — no re-index strategy available")

    # 6. Warn about missing source files
    if missing:
        click.echo(f"Warning: {len(missing)} source files not found (moved or deleted)")
        for m in missing[:5]:
            click.echo(f"  - {m}")
        if len(missing) > 5:
            click.echo(f"  ... and {len(missing) - 5} more")

    # 7. Report before/after counts and verify
    try:
        after_info = db.collection_info(name)
        after_count = after_info["count"]
    except KeyError:
        after_count = 0

    click.echo(
        f"Re-indexed: {before_count} -> {after_count} documents ({indexed} sources processed)"
    )

    if after_count >= 2:
        try:
            result = verify_collection_deep(db, name)
            dist_str = (
                f" (distance: {result.distance:.4f})" if result.distance is not None else ""
            )
            click.echo(f"Verify: {result.status}{dist_str}")
        except Exception as exc:
            click.echo(f"Verify failed: {exc}", err=True)


@collection.command("verify")
@click.argument("name")
@click.option("--deep", is_flag=True, help="Run embedding probe query to verify index health")
def verify_cmd(name: str, deep: bool) -> None:
    """Verify a collection exists and report its document count."""
    from nexus.db.t3 import verify_collection_deep

    db = _t3()
    cols = db.list_collections()
    match = next((c for c in cols if c["name"] == name), None)
    if match is None:
        raise click.ClickException(f"collection not found: {name!r} — use: nx collection list")

    if not deep:
        click.echo(f"Collection '{name}': {match['count']} documents — OK")
        return

    try:
        result = verify_collection_deep(db, name)
    except KeyError:
        raise click.ClickException(f"collection not found: {name!r} — use: nx collection list")
    except Exception as exc:
        click.echo(
            f"embedding probe failed for '{name}': {exc} — check voyage_api_key with: nx config get voyage_api_key",
            err=True,
        )
        raise click.exceptions.Exit(1)

    if result.status == "skipped":
        click.echo(
            f"Collection '{name}': {result.doc_count} documents — skipped (too few for probe)"
        )
        return

    dist_str = (
        f" (distance: {result.distance:.4f}, {result.metric})"
        if result.distance is not None
        else ""
    )
    if result.status == "healthy":
        click.echo(f"Collection '{name}': {result.doc_count} documents — embedding health OK{dist_str}")
    elif result.status == "broken":
        click.echo(
            f"Collection '{name}': {result.doc_count} documents — BROKEN: probe document not in top-10{dist_str}",
            err=True,
        )
        raise click.exceptions.Exit(1)
