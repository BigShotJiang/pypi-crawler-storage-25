"""Shared MCP API helper."""

import json
import time
from urllib.request import Request, urlopen
from urllib.error import URLError


def mcp_call(host: str, port: int, tool: str, arguments: dict | None = None) -> dict:
    """Call an MCP tool via the HTTP JSON-RPC endpoint."""
    url = f"http://{host}:{port}/mcp/http"
    payload = {
        "jsonrpc": "2.0",
        "id": int(time.time() * 1000),
        "method": "tools/call",
        "params": {"name": tool, "arguments": arguments or {}},
    }
    req = Request(url, data=json.dumps(payload).encode(),
                  headers={"Content-Type": "application/json"})
    try:
        with urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read())
    except URLError as e:
        return {"error": f"Connection failed: {e}"}

    if "error" in result:
        return result

    try:
        text = result["result"]["content"][0]["text"]
        return json.loads(text)
    except (KeyError, IndexError, json.JSONDecodeError):
        return result


def read_port_from_config(config_path=None):
    """Read http_port from config.yaml."""
    if config_path is None:
        return None
    try:
        import re
        text = config_path.read_text()
        m = re.search(r'http_port:\s*(\d+)', text)
        if m:
            return int(m.group(1))
    except Exception:
        pass
    return None
