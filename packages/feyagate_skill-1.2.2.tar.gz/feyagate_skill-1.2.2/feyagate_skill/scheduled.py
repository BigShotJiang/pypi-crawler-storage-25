"""Scheduled camera snapshot capture with AI analysis preparation."""

import base64
import json
import os
import signal
import sys
import time
from datetime import datetime
from pathlib import Path

from . import MCP_DEFAULT_HOST, MCP_DEFAULT_PORT
from .mcp import mcp_call

_running = True


def _signal_handler(signum, frame):
    global _running
    print("\nShutdown signal received...")
    _running = False


signal.signal(signal.SIGINT, _signal_handler)
signal.signal(signal.SIGTERM, _signal_handler)


def _ensure_connected(host, port, camera_id):
    status = mcp_call(host, port, "xiaomi/camera_status", {"camera_id": camera_id})
    if status.get("status") == "connected" and status.get("buffered_frames", 0) > 0:
        return True
    mcp_call(host, port, "xiaomi/camera_connect", {"camera_id": camera_id})
    time.sleep(3)
    status = mcp_call(host, port, "xiaomi/camera_status", {"camera_id": camera_id})
    return status.get("status") == "connected"


def _capture_and_save(host, port, camera_id, channel, output_dir):
    result = mcp_call(host, port, "xiaomi/camera_snapshot", {
        "camera_id": camera_id, "channel": channel, "count": 1,
    })
    images = result.get("images", [])
    if not images:
        return None

    img = images[0]
    data_url = img.get("data_url", "")
    timestamp = img.get("timestamp", int(time.time()))
    b64_data = data_url.split(",", 1)[1] if "," in data_url else data_url
    jpeg_bytes = base64.b64decode(b64_data)

    dt = datetime.fromtimestamp(timestamp)
    date_dir = output_dir / dt.strftime("%Y-%m-%d")
    date_dir.mkdir(parents=True, exist_ok=True)

    filename = f"{camera_id}_ch{channel}_{dt.strftime('%H%M%S')}.jpg"
    filepath = date_dir / filename
    filepath.write_bytes(jpeg_bytes)

    return {
        "camera_id": camera_id, "channel": channel,
        "timestamp": timestamp, "datetime": dt.isoformat(),
        "image_path": str(filepath), "image_size_bytes": len(jpeg_bytes),
    }


def do_scheduled(host=None, port=None, camera_ids=None, channel=0,
                 interval=300, output_dir=None, prompt="",
                 auto_connect=False, max_runs=0, one_shot=False):
    """Run scheduled camera capture loop."""
    global _running

    host = host or MCP_DEFAULT_HOST
    port = port or MCP_DEFAULT_PORT

    if not camera_ids:
        print("ERROR: --camera-id required")
        return

    if output_dir is None:
        output_dir = Path.home() / ".feyagate" / "data" / "analysis"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=== FeyaGate Scheduled Analysis ===")
    print(f"  Cameras:  {', '.join(camera_ids)}")
    print(f"  Interval: {interval}s")
    print(f"  Output:   {output_dir}")
    print()

    run_count = 0
    total = 0

    while _running:
        run_count += 1
        print(f"--- Cycle {run_count} [{datetime.now().strftime('%H:%M:%S')}] ---")

        for cam_id in camera_ids:
            if auto_connect and not _ensure_connected(host, port, cam_id):
                print(f"  [WARN] Cannot connect {cam_id}")
                continue

            record = _capture_and_save(host, port, cam_id, channel, output_dir)
            if record:
                total += 1
                kb = record["image_size_bytes"] / 1024
                print(f"  [{record['datetime']}] {cam_id}: {kb:.1f} KB")

                if prompt:
                    dt = datetime.fromtimestamp(record["timestamp"])
                    date_dir = output_dir / dt.strftime("%Y-%m-%d")
                    jsonl_path = date_dir / "analysis_queue.jsonl"
                    entry = {
                        "id": f"{cam_id}_{record['timestamp']}",
                        "camera_id": cam_id, "channel": channel,
                        "timestamp": record["timestamp"],
                        "datetime": record["datetime"],
                        "image_path": record["image_path"],
                        "prompt": prompt, "status": "pending",
                    }
                    with open(jsonl_path, "a") as f:
                        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            else:
                print(f"  [{datetime.now().isoformat()}] {cam_id}: no frame")

        if one_shot or (max_runs and run_count >= max_runs):
            break

        if _running:
            wait_until = time.time() + interval
            while _running and time.time() < wait_until:
                time.sleep(min(1, wait_until - time.time()))

    print(f"\nDone: {run_count} cycles, {total} images")
