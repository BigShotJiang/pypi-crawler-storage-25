"""FeyaGate Skill - MCP Smart Home Gateway for AI Agents."""

__version__ = "1.2.2"
__author__ = "panzuji"

DEFAULT_INSTALL_DIR = "~/.feyagate"
FOTA_URL = "https://oneapi.sooncore.com/ota/fota.json"
MCP_DEFAULT_PORT = 38080
MCP_DEFAULT_HOST = "127.0.0.1"
