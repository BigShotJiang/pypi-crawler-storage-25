"""Camera snapshot capture tool."""

import base64
import json
import sys
import time
from datetime import datetime
from pathlib import Path

from . import MCP_DEFAULT_HOST, MCP_DEFAULT_PORT
from .mcp import mcp_call


def do_snapshot(host=None, port=None, camera_id=None, connect=False,
                channel=0, count=1, output_dir=None, list_cameras=False):
    """Capture camera snapshots."""
    host = host or MCP_DEFAULT_HOST
    port = port or MCP_DEFAULT_PORT

    if output_dir is None:
        output_dir = Path.home() / ".feyagate" / "data" / "snapshots"
    output_dir = Path(output_dir)

    if list_cameras:
        result = mcp_call(host, port, "xiaomi/camera_list")
        if "error" in result:
            print(f"Error: {result['error']}")
            return
        cameras = result.get("cameras", [])
        if not cameras:
            print("No cameras found.")
            return
        print(f"Found {len(cameras)} camera(s):\n")
        for cam in cameras:
            status_icon = {"connected": "[ON]", "connecting": "[..]"}.get(
                cam.get("camera_status", ""), "[--]")
            print(f"  {status_icon} {cam.get('name', 'unknown')}")
            print(f"    DID:      {cam.get('did', '?')}")
            print(f"    Model:    {cam.get('model', '?')}")
            print(f"    Location: {cam.get('home_name', '?')} / {cam.get('room_name', '?')}")
            print()
        return

    if not camera_id:
        print("ERROR: --camera-id required (use --list to see cameras)")
        return

    if connect:
        print(f"Connecting to camera {camera_id}...")
        result = mcp_call(host, port, "xiaomi/camera_connect", {"camera_id": camera_id})
        if result.get("success"):
            print("Connected. Waiting for frames...")
            time.sleep(3)
        else:
            print(f"Connection failed: {result}")
            return

    output_dir.mkdir(parents=True, exist_ok=True)
    result = mcp_call(host, port, "xiaomi/camera_snapshot", {
        "camera_id": camera_id, "channel": channel, "count": count,
    })

    if "error" in result:
        print(f"Snapshot error: {result['error']}")
        return

    images = result.get("images", [])
    if not images:
        print("No images returned. Is camera connected?")
        return

    for i, img in enumerate(images):
        data_url = img.get("data_url", "")
        timestamp = img.get("timestamp", int(time.time()))
        b64_data = data_url.split(",", 1)[1] if "," in data_url else data_url
        jpeg_bytes = base64.b64decode(b64_data)

        dt = datetime.fromtimestamp(timestamp)
        filename = f"{camera_id}_ch{channel}_{dt.strftime('%Y%m%d_%H%M%S')}_{i:02d}.jpg"
        filepath = output_dir / filename

        filepath.write_bytes(jpeg_bytes)
        print(f"  Saved: {filepath} ({len(jpeg_bytes)/1024:.1f} KB)")

    print(f"\nCaptured {len(images)} snapshot(s)")
