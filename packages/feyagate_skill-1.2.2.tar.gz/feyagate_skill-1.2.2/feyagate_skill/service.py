"""Start/stop MCP server service."""

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from . import DEFAULT_INSTALL_DIR, MCP_DEFAULT_PORT


def _install_dir():
    return Path(os.path.expanduser(DEFAULT_INSTALL_DIR))


def _read_port():
    config = _install_dir() / "config" / "config.yaml"
    if config.exists():
        import re
        text = config.read_text()
        m = re.search(r'http_port:\s*(\d+)', text)
        if m:
            return int(m.group(1))
    return MCP_DEFAULT_PORT


def _is_running():
    pid_file = _install_dir() / "data" / "miloco-mcp-server.pid"
    if not pid_file.exists():
        return False, None
    try:
        pid = int(pid_file.read_text().strip())
        os.kill(pid, 0)  # check if alive
        return True, pid
    except (ProcessLookupError, ValueError, PermissionError):
        return False, None


def do_start(port=None):
    """Start the MCP server."""
    install_dir = _install_dir()
    binary = install_dir / "bin" / "miloco-mcp-server"
    config = install_dir / "config" / "config.yaml"
    pid_file = install_dir / "data" / "miloco-mcp-server.pid"
    log_file = install_dir / "data" / "miloco-mcp-server.log"
    lib_dir = install_dir / "lib"

    if not binary.exists():
        print("ERROR: MCP server binary not found. Run: feyagate setup")
        return False

    running, pid = _is_running()
    if running:
        print(f"Already running (PID {pid})")
        return True

    if not config.exists():
        print("ERROR: config/config.yaml not found. Run: feyagate setup")
        return False

    (install_dir / "data").mkdir(parents=True, exist_ok=True)

    # Set library path
    env = os.environ.copy()
    if lib_dir.exists():
        key = "DYLD_LIBRARY_PATH" if sys.platform == "darwin" else "LD_LIBRARY_PATH"
        env[key] = str(lib_dir) + os.pathsep + env.get(key, "")

    port = port or _read_port()

    print(f"Starting miloco-mcp-server (port {port})...")
    proc = subprocess.Popen(
        [str(binary), "--config", str(config)],
        cwd=str(install_dir),
        stdout=open(log_file, "w"),
        stderr=subprocess.STDOUT,
        env=env,
        start_new_session=True,
    )
    pid_file.write_text(str(proc.pid))

    # Wait for health check
    from urllib.request import urlopen
    from urllib.error import URLError

    for i in range(10):
        time.sleep(1)
        if proc.poll() is not None:
            print(f"FAILED: Server exited with code {proc.returncode}")
            print("Check log: feyagate log")
            pid_file.unlink(missing_ok=True)
            return False
        try:
            resp = urlopen(f"http://localhost:{port}/health", timeout=2)
            if resp.status == 200:
                print(f"OK (PID {proc.pid}) http://localhost:{port}/mcp/http")
                return True
        except URLError:
            pass

    print(f"Started (PID {proc.pid}), waiting for health check...")
    print(f"  Endpoint: http://localhost:{port}/mcp/http")
    return True


def do_stop():
    """Stop the MCP server."""
    running, pid = _is_running()
    if not running:
        print("Server is not running")
        return True

    print(f"Stopping miloco-mcp-server (PID {pid})...")
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass

    for _ in range(10):
        time.sleep(0.5)
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            pid_file = _install_dir() / "data" / "miloco-mcp-server.pid"
            pid_file.unlink(missing_ok=True)
            print("Stopped")
            return True

    # Force kill
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    pid_file = _install_dir() / "data" / "miloco-mcp-server.pid"
    pid_file.unlink(missing_ok=True)
    print("Force stopped")
    return True


def do_status():
    """Show server status."""
    install_dir = _install_dir()

    # Version
    version_file = install_dir / "data" / "version.json"
    if version_file.exists():
        import json
        info = json.loads(version_file.read_text())
        print(f"Version: {info.get('version', '?')}")
        print(f"Platform: {info.get('platform', '?')}")
    else:
        print("Version: (not installed)")

    print(f"Install dir: {install_dir}")

    # Running?
    running, pid = _is_running()
    if running:
        print(f"Status: RUNNING (PID {pid})")
    else:
        print("Status: STOPPED")
        return

    # Health check
    port = _read_port()
    from urllib.request import urlopen
    from urllib.error import URLError
    try:
        resp = urlopen(f"http://localhost:{port}/health", timeout=3)
        print(f"Health: OK (HTTP {resp.status})")
    except URLError:
        print("Health: NOT RESPONDING")

    print(f"Endpoint: http://localhost:{port}/mcp/http")
    print(f"WebUI:    http://localhost:{port}")


def do_log(lines=30):
    """Show server log."""
    log_file = _install_dir() / "data" / "miloco-mcp-server.log"
    if not log_file.exists():
        print("No log file found")
        return

    import subprocess
    result = subprocess.run(["tail", "-n", str(lines), str(log_file)],
                           capture_output=True, text=True)
    print(result.stdout)
