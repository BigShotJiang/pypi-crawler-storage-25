"""Experiment data models — runtime state for eval experiments."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ExperimentConfig:
    """A single configuration to evaluate (e.g., 'baseline' or 'with-mcp')."""

    label: str
    agent: str = "claude"
    model: str | None = None
    permission_mode: str = "default"
    mcp_config: dict | None = None
    instruction_variant: str | None = None
    preambles: tuple[str, ...] = ()
    reward_type: str = "binary"
    extra: dict = field(default_factory=dict)

    def __repr__(self) -> str:
        # Lazy import: config/__init__.py → loader.py → this module (circular)
        from codeprobe.config.redact import redact_mcp_headers

        redacted_mcp = redact_mcp_headers(self.mcp_config)
        return (
            f"ExperimentConfig(label={self.label!r}, agent={self.agent!r}, "
            f"model={self.model!r}, permission_mode={self.permission_mode!r}, "
            f"mcp_config={redacted_mcp!r}, "
            f"instruction_variant={self.instruction_variant!r}, "
            f"preambles={self.preambles!r}, reward_type={self.reward_type!r}, "
            f"extra={self.extra!r})"
        )


@dataclass(frozen=True)
class CompletedTask:
    """Result of running a single task under a single configuration."""

    task_id: str
    automated_score: float
    repeat_index: int = 0
    status: str = "completed"
    duration_seconds: float = 0.0
    input_tokens: int | None = None
    output_tokens: int | None = None
    cache_read_tokens: int | None = None
    cost_usd: float | None = None
    cost_model: str = "unknown"
    cost_source: str = "unavailable"
    tool_call_count: int | None = None
    error_category: str | None = None
    scoring_details: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)


@dataclass(frozen=True)
class ConfigResults:
    """All results for a single configuration."""

    config: str
    completed: list[CompletedTask] = field(default_factory=list)


@dataclass(frozen=True)
class Experiment:
    """Top-level experiment with metadata and configuration matrix."""

    name: str
    description: str = ""
    configs: list[ExperimentConfig] = field(default_factory=list)
    tasks_dir: str = "tasks"
    task_ids: tuple[str, ...] = ()
