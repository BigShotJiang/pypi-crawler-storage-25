if [ -z "$1" ]
then
DECIMATION_FACTOR=1
else
DECIMATION_FACTOR=$1
fi
echo "Running with df=$DECIMATION_FACTOR"
echo "Timing description:"
python -c "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);print(f'Testing {len(ds):.1e} particles')"

echo "Data resetting"
python -m timeit -s "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);" "ds = timing_tests.reset_data(ds)"

echo "packingcubes.PythonOctree creation"
python -m timeit -s "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);timing_tests.precompile()" "ds = timing_tests.reset_data(ds);timing_tests.python_octree_creation(ds)"

echo "packingcubes.PackedOctree creation"
python -m timeit -s "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);timing_tests.precompile();" "ds = timing_tests.reset_data(ds);timing_tests.packed_octree_creation(ds)"

echo "Cubing"
python -m timeit -s "import timing_tests;setup = timing_tests.cubing_setup();timing_tests.cubing(setup);" "timing_tests.cubing(setup)"

echo "scipy.spatial.kdtree creation"
python -m timeit -s "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);" "ds = timing_tests.reset_data(ds);timing_tests.kdtree_creation(ds)"

echo "packingcubes.PythonOctree search (divide by 100)"
python -m timeit -s "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);timing_tests.precompile();tree = timing_tests.python_octree_creation(ds)" "timing_tests.python_octree_query_ball_point(tree)"

echo "packingcubes.PackedOctree search (divide by 100)"
python -m timeit -s "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);timing_tests.precompile();tree = timing_tests.packed_octree_creation(ds)" "timing_tests.packed_octree_query_ball_point(tree)"

echo "packingcubes.PackedOctree search with indices (divide by 100)"
python -m timeit -s "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);timing_tests.precompile();tree = timing_tests.packed_octree_creation(ds)" "timing_tests.packed_octree_query_ball_point_indices(ds,tree)"

echo "Cubes search (divide by 100)"
python -m timeit -s "import timing_tests;setup = timing_tests.cubing_setup();cubes = timing_tests.cubing(setup);timing_tests.cubes_query_ball_points(cubes);" "timing_tests.cubes_query_ball_points(cubes)"

echo "scipy.spatial.kdtree search (divide by 100)"
python -m timeit -s "import timing_tests;ds = timing_tests.load_data($DECIMATION_FACTOR);tree = timing_tests.scipy_kdtree_creation(ds)" "timing_tests.scipy_kdtree_query_ball_point(tree)"

echo "Tree sizes:"
python -c "import timing_tests;timing_tests.tree_sizes($DECIMATION_FACTOR)"
