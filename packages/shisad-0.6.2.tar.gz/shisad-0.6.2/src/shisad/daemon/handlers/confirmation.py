"""Typed confirmation/action handler group."""

from __future__ import annotations

from shisad.core.api.schema import (
    ActionConfirmResult,
    ActionDecisionParams,
    ActionPendingParams,
    ActionPendingResult,
    ActionRejectResult,
    ConfirmationMetricsParams,
    ConfirmationMetricsResult,
    SignerListParams,
    SignerListResult,
    SignerRegisterParams,
    SignerRegisterResult,
    SignerRevokeParams,
    SignerRevokeResult,
    TwoFactorListParams,
    TwoFactorListResult,
    TwoFactorRegisterBeginParams,
    TwoFactorRegisterBeginResult,
    TwoFactorRegisterConfirmParams,
    TwoFactorRegisterConfirmResult,
    TwoFactorRevokeParams,
    TwoFactorRevokeResult,
)
from shisad.daemon.context import RequestContext
from shisad.daemon.handlers._helpers import build_params_payload
from shisad.daemon.handlers._impl import HandlerImplementation


class ConfirmationHandlers:
    """Pending-action and confirmation handlers."""

    def __init__(self, impl: HandlerImplementation, *, internal_ingress_marker: object) -> None:
        self._impl = impl
        self._internal_ingress_marker = internal_ingress_marker

    async def handle_action_pending(
        self,
        params: ActionPendingParams,
        ctx: RequestContext,
    ) -> ActionPendingResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return ActionPendingResult.model_validate(await self._impl.do_action_pending(payload))

    async def handle_action_confirm(
        self,
        params: ActionDecisionParams,
        ctx: RequestContext,
    ) -> ActionConfirmResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return ActionConfirmResult.model_validate(await self._impl.do_action_confirm(payload))

    async def handle_action_reject(
        self,
        params: ActionDecisionParams,
        ctx: RequestContext,
    ) -> ActionRejectResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return ActionRejectResult.model_validate(await self._impl.do_action_reject(payload))

    async def handle_confirmation_metrics(
        self,
        params: ConfirmationMetricsParams,
        ctx: RequestContext,
    ) -> ConfirmationMetricsResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return ConfirmationMetricsResult.model_validate(
            await self._impl.do_confirmation_metrics(payload)
        )

    async def handle_two_factor_register_begin(
        self,
        params: TwoFactorRegisterBeginParams,
        ctx: RequestContext,
    ) -> TwoFactorRegisterBeginResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return TwoFactorRegisterBeginResult.model_validate(
            await self._impl.do_two_factor_register_begin(payload)
        )

    async def handle_two_factor_register_confirm(
        self,
        params: TwoFactorRegisterConfirmParams,
        ctx: RequestContext,
    ) -> TwoFactorRegisterConfirmResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return TwoFactorRegisterConfirmResult.model_validate(
            await self._impl.do_two_factor_register_confirm(payload)
        )

    async def handle_two_factor_list(
        self,
        params: TwoFactorListParams,
        ctx: RequestContext,
    ) -> TwoFactorListResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return TwoFactorListResult.model_validate(await self._impl.do_two_factor_list(payload))

    async def handle_two_factor_revoke(
        self,
        params: TwoFactorRevokeParams,
        ctx: RequestContext,
    ) -> TwoFactorRevokeResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return TwoFactorRevokeResult.model_validate(await self._impl.do_two_factor_revoke(payload))

    async def handle_signer_register(
        self,
        params: SignerRegisterParams,
        ctx: RequestContext,
    ) -> SignerRegisterResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return SignerRegisterResult.model_validate(await self._impl.do_signer_register(payload))

    async def handle_signer_list(
        self,
        params: SignerListParams,
        ctx: RequestContext,
    ) -> SignerListResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return SignerListResult.model_validate(await self._impl.do_signer_list(payload))

    async def handle_signer_revoke(
        self,
        params: SignerRevokeParams,
        ctx: RequestContext,
    ) -> SignerRevokeResult:
        payload = build_params_payload(
            params,
            ctx,
            internal_ingress_marker=self._internal_ingress_marker,
        )
        return SignerRevokeResult.model_validate(await self._impl.do_signer_revoke(payload))
