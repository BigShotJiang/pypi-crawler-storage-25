"""A simple static site generator for tutorials"""

__version__ = "2.10.0"
