"""
PromptWarden — Prompt injection detection for agentic LLM systems.
"""

from .shield import PromptWarden, ShieldResult, ThreatLevel
from .detectors import (
    ToolCallPoisonDetector,
    IntentDriftDetector,
    PrivilegeEscalationDetector,
)

__version__ = "0.1.0"
__all__ = [
    "PromptWarden",
    "ShieldResult",
    "ThreatLevel",
    "ToolCallPoisonDetector",
    "IntentDriftDetector",
    "PrivilegeEscalationDetector",
]
