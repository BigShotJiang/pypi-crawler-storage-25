"""
PromptWarden core — intercept, score, and validate tool calls before execution.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger("promptwarden")


class ThreatLevel(str, Enum):
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ShieldResult:
    allowed: bool
    threat_level: ThreatLevel
    score: float  # 0.0 (clean) → 1.0 (definite attack)
    signals: list[str] = field(default_factory=list)
    tool_name: str | None = None
    tool_args: dict[str, Any] | None = None
    latency_ms: float = 0.0

    def __repr__(self) -> str:
        status = "✅ ALLOWED" if self.allowed else "🚨 BLOCKED"
        return (
            f"ShieldResult({status} | {self.threat_level.value.upper()} | "
            f"score={self.score:.2f} | signals={self.signals})"
        )


class PromptWarden:
    """
    Middleware that intercepts LLM tool calls before execution,
    scores them for injection/poisoning signals, and blocks or
    flags suspicious requests.

    Usage::

        shield = PromptWarden(block_threshold=ThreatLevel.HIGH)

        result = shield.inspect(
            user_intent="Summarize this document",
            tool_name="execute_code",
            tool_args={"code": "import os; os.system('rm -rf /')"}
        )

        if result.allowed:
            execute_the_tool(...)
    """

    def __init__(
        self,
        block_threshold: ThreatLevel = ThreatLevel.HIGH,
        on_threat: Callable[[ShieldResult], None] | None = None,
        detectors: list | None = None,
    ):
        from .detectors import (
            ToolCallPoisonDetector,
            IntentDriftDetector,
            PrivilegeEscalationDetector,
        )

        self.block_threshold = block_threshold
        self.on_threat = on_threat
        self._detectors = detectors or [
            ToolCallPoisonDetector(),
            IntentDriftDetector(),
            PrivilegeEscalationDetector(),
        ]
        self._threat_order = [t.value for t in ThreatLevel]

    def inspect(
        self,
        user_intent: str,
        tool_name: str,
        tool_args: dict[str, Any],
        context: dict[str, Any] | None = None,
    ) -> ShieldResult:
        """
        Run all detectors against a pending tool call.

        Args:
            user_intent: The original user request / goal.
            tool_name:   The tool the LLM wants to invoke.
            tool_args:   Arguments the LLM is passing to the tool.
            context:     Optional extra context (conversation history, etc.)

        Returns:
            ShieldResult with allow/block decision and full signal breakdown.
        """
        t0 = time.perf_counter()
        all_signals: list[str] = []
        max_score = 0.0
        max_level = ThreatLevel.SAFE

        for detector in self._detectors:
            result = detector.detect(
                user_intent=user_intent,
                tool_name=tool_name,
                tool_args=tool_args,
                context=context or {},
            )
            if result["score"] > max_score:
                max_score = result["score"]
            if self._threat_order.index(result["level"].value) > self._threat_order.index(max_level.value):
                max_level = result["level"]
            all_signals.extend(result["signals"])

        allowed = self._threat_order.index(max_level.value) < self._threat_order.index(self.block_threshold.value)
        latency = (time.perf_counter() - t0) * 1000

        shield_result = ShieldResult(
            allowed=allowed,
            threat_level=max_level,
            score=round(max_score, 4),
            signals=list(dict.fromkeys(all_signals)),  # dedupe, preserve order
            tool_name=tool_name,
            tool_args=tool_args,
            latency_ms=round(latency, 2),
        )

        if not allowed and self.on_threat:
            self.on_threat(shield_result)

        log_level = logging.WARNING if not allowed else logging.DEBUG
        logger.log(log_level, shield_result)

        return shield_result

    def wrap(self, tool_fn: Callable, tool_name: str | None = None):
        """
        Decorator that auto-shields any tool function.

        Usage::

            @shield.wrap
            def execute_code(code: str, user_intent: str):
                ...
        """
        import functools

        name = tool_name or tool_fn.__name__

        @functools.wraps(tool_fn)
        def wrapper(*args, user_intent: str = "", **kwargs):
            result = self.inspect(
                user_intent=user_intent,
                tool_name=name,
                tool_args=kwargs,
            )
            if not result.allowed:
                raise PermissionError(
                    f"PromptWarden blocked tool '{name}': {result.signals}"
                )
            return tool_fn(*args, **kwargs)

        return wrapper
