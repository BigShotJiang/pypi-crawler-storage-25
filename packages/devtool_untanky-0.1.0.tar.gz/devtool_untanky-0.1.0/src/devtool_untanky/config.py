from pathlib import Path
from pydantic import Field, BaseModel
from os import environ
from typing import Optional
import yaml

class TmuxConfig(BaseModel):
    socketName: str = "devtool"


class AppConfig(BaseModel):
    projectPath: Path = Path(environ.get("HOME") or "", "dev")
    tmux: TmuxConfig = Field(default_factory=TmuxConfig)


_config: Optional[AppConfig] = None


def loadConfig(configPath: Optional[Path]) -> AppConfig:
    """Load the configuration from configPath

    When configPath is a directory, it scans for the following well-known names in
    order:
    - devtool.yaml
    - devtool.yml
    - config.yaml
    - config.yml
    When none of these files exists, an error is thrown.

    When configPath is a file, it will read and parse the file.
    """
    global _config
    path = configPath

    if path is None or not path.exists():
        _config = AppConfig()
        return _config

    if path.is_dir():
        path = _resolveConfigFile(path) 

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        
        # Pydantic automatically merges with defaults
        _config = AppConfig(**data)
        return _config
    except Exception as e:
        raise RuntimeError(f"Failed to load config from {path}: {e}")

def _resolveConfigFile(path: Path) -> Path:
    candidates = ["devtool.yaml", "devtool.yml", "config.yaml", "config.yml"]
    for candidate in candidates:
        candidatePath = path / candidate
        if candidatePath.exists():
            return candidatePath

    raise FileNotFoundError()

    

def getConfig() -> AppConfig:
    """Get the currently loaded configuration."""
    if _config is None:
        raise RuntimeError("Configuration not loaded. Call loadConfig() first.")
    return _config
