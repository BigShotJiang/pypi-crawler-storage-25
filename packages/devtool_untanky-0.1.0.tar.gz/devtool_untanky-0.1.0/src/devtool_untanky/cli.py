from typing import Annotated, Optional
from pathlib import Path
from devtool.core import startDeveloperEnvironment, stopDeveloperEnvironment
from devtool.config import loadConfig
import typer

app = typer.Typer()


@app.callback()
def config(
    ctx: typer.Context,
    config_file: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        help="""Specify the configuration file to be used.

        When a directory is specified, it will be searched for the following file names, selecting the
        first found, for reading of the configuration: devtool.y{a}ml, config.y{a}ml
        """,
        exists=True,
        file_okay=True,
        dir_okay=True,
        readable=True,
    ),
) -> None:
    """
    Load configuration before any command runs.
    Stores config in ctx.obj for use by commands.
    """
    ctx.obj = loadConfig(config_file)


@app.command()
def start(
    project: Annotated[str, typer.Argument(help="project identifier")],
):
    startDeveloperEnvironment(project)


@app.command()
def stop(
    project: Annotated[str, typer.Argument(help="project identifier")],
):
    stopDeveloperEnvironment(project)


def main() -> None:
    loadConfig(None)
    app()


if __name__ == "__main__":
    main()
