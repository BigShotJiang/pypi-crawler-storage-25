from pathlib import Path
from tmux import TmuxInstance, Layout, Window, Pane
from devtool.config import getConfig


def __listAllDirectories() -> list[Path]:
    config = getConfig()
    return [p for p in config.projectPath.iterdir() if p.is_dir()]


def startDeveloperEnvironment(
    projectID: str,
):
    config = getConfig()
    tmux = TmuxInstance(socketName=config.tmux.socketName)

    projects = __listAllDirectories()

    project = next((p for p in projects if p.name == projectID), None)
    if project is None:
        print(f"project not found: {projectID}")
        exit(1)

    activeSessions = tmux.listSessions()
    session = next((s for s in activeSessions if s == projectID), None)

    if session is None:
        print("session not found; creating new session")
        
        tmux.createSession(projectID, defaultLayout(project))

    print("attaching to session")
    tmux.attachToSession(projectID)

def stopDeveloperEnvironment(
    project: str,
):
    config = getConfig()
    tmux = TmuxInstance(socketName=config.tmux.socketName)

    sessions = tmux.listSessions()
    session = next((s for s in sessions if s == project), None)

    if session is None:
        print(f"session {project} is not running")
        exit(0)

    print("killing session")
    tmux.killSession(session)


def defaultLayout(project: Path):
    return Layout(
        windows=[
            Window(
                Pane(
                    directory=project,
                    command="nvim ."
                ),
                "editor",
            ),
            Window(
                Pane(directory=project)
            )
        ]
    )

