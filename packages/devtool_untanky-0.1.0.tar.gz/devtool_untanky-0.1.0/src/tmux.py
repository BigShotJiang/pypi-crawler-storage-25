from pathlib import Path
import subprocess
import os


class Pane:
    directory: Path | None
    command: str | None

    def __init__(self, directory = None, command = None):
        self.directory = directory
        self.command = command

class Window:
    name: str | None
    pane: Pane

    def __init__(self, pane = Pane(), name = None):
        self.pane = pane
        self.name = name


class Layout:
    windows: list[Window]

    def __init__(self, windows: list[Window] = [Window()]):
        self.windows = windows

class TmuxInstance:
    socketName: str

    def __init__(self, socketName: str):
        self.socketName = socketName
        self.__ensureServerStart()

    def __ensureServerStart(self):
        subprocess.run(self.__tmux("start-server"), check=True)

    def __tmux(self, *args) -> list[str]:
        return ["tmux", "-L", self.socketName, *args]

    def listSessions(self) -> list[str]:
        result = subprocess.run(
            self.__tmux("list-sessions", "-F#S"),
            capture_output=True,
            text=True,
        )

        if result.returncode == 1:
            if "no server running" in result.stderr:
                return []
            raise RuntimeError(f"tmux errored with status code {result.returncode}", result.stderr)

        sessions = []
        for line in result.stdout.splitlines():
            sessions.append(line)

        return sessions

    def createSession(self, name: str, layout: Layout = Layout()):
        for index, window in enumerate(layout.windows, start=1):
            args = []

            if index == 1:
                args.append("new-session")
                args.append("-s")
                args.append(name)
            else:
                args.append("new-window")
                args.append("-t")
                args.append(f"{name}:{index}")

            args.append("-d")

            if window.name is not None:
                args.append("-n")
                args.append(window.name)

            if window.pane.directory is not None:
                args.append("-c")
                args.append(str(window.pane.directory.absolute()))

            if window.pane.command is not None:
                args.append(window.pane.command)

            subprocess.run(self.__tmux(*args), check=True)



    def attachToSession(self, name: str):
        if "TMUX" in os.environ:
            subprocess.run(self.__tmux("switch-client", "-t", name), check=True)
        else:
            subprocess.run(self.__tmux("attach", "-t", name), check=True)

    def killSession(self, name: str):
        subprocess.run(self.__tmux("kill-session", "-t", name), check=True)

