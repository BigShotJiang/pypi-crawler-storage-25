"""Tests for home-topology."""
