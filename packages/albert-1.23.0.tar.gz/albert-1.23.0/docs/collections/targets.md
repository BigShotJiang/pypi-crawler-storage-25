::: albert.collections.targets.TargetCollection
