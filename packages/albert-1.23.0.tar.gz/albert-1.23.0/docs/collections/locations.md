::: albert.collections.locations.LocationCollection
