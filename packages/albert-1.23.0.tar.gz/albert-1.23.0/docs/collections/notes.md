::: albert.collections.notes.NotesCollection
