import binascii
from queue import Queue

import pyotp

from quantplay.broker.finvasia_utils import finvasia_oauth
from quantplay.broker.finvasia_utils.fa_noren import FA_NorenApi
from quantplay.broker.finvasia_utils.finvasia_oauth import ShoonyaOAuthError
from quantplay.broker.noren import Noren
from quantplay.exception.exceptions import (
    InvalidArgumentException,
    RetryableException,
    TokenException,
)
from quantplay.model.order_event import OrderUpdateEvent


class FinvAsia(Noren):
    def __init__(
        self,
        order_updates: Queue[OrderUpdateEvent] | None = None,
        api_secret: str | None = None,
        imei: str | None = None,
        password: str | None = None,
        totp: str | None = None,
        user_id: str | None = None,
        vendor_code: str | None = None,
        user_token: str | None = None,
        access_token: str | None = None,
        account_id: str | None = None,
        secret_code: str | None = None,
        client_id: str | None = None,
        load_instrument: bool = True,
        proxies: dict[str, str] | None = None,
    ) -> None:
        """Connect to Shoonya/Finvasia.

        Auth precedence:
          1. ``access_token`` (+ ``account_id`` or ``user_id``) -> install
             OAuth session directly.
          2. ``user_id + password + totp + (secret_code or api_secret) +
             (client_id or vendor_code)`` -> Selenium login + GenAcsTok
             exchange (post-Apr-2026 OAuth flow). The fresh access_token
             and account_id are exposed on the instance for the factory
             to persist back to broker_data.
          3. ``user_token + user_id`` -> legacy QuickAuth susertoken path.
             Retained for callers still on the old code; Shoonya's
             upstream rejects this since Apr 2026 but constructor stays
             non-breaking.
        """
        super().__init__(
            order_updates=order_updates,
            load_instrument=load_instrument,
            proxies=proxies,
        )
        self.api = FA_NorenApi(
            "https://api.shoonya.com/NorenWClientAPI/",
            "wss://api.shoonya.com/NorenWSAPI/",
        )
        self.api.proxies = self.proxies

        resolved_secret = secret_code or api_secret
        resolved_client = client_id or vendor_code or (
            f"{user_id}_U" if user_id else None
        )

        try:
            if access_token and (account_id or user_id):
                self.api.set_session(
                    userid=user_id,
                    access_token=access_token,
                    account_id=account_id or user_id,
                )
                self.access_token = access_token
                self.account_id = account_id or user_id
                self.client_id = resolved_client
                response = {
                    "access_token": access_token,
                    "susertoken": access_token,
                    "actid": account_id or user_id,
                    "email": None,
                    "uname": None,
                }
            elif (
                user_id
                and password
                and totp
                and resolved_secret
                and resolved_client
            ):
                tokens = finvasia_oauth.login(
                    user_id=user_id,
                    password=password,
                    totp_secret=totp,
                    secret_code=resolved_secret,
                    client_id=resolved_client,
                    proxies=self.proxies,
                )
                self.api.set_session(
                    userid=user_id,
                    access_token=tokens["access_token"],
                    account_id=tokens["account_id"],
                )
                self.access_token = tokens["access_token"]
                self.refresh_token = tokens.get("refresh_token")
                self.account_id = tokens["account_id"]
                self.client_id = tokens["client_id"]
                self.secret_code = tokens["Secret_Code"]
                response = {
                    "access_token": tokens["access_token"],
                    "susertoken": tokens.get("susertoken") or tokens["access_token"],
                    "actid": tokens["account_id"],
                    "email": None,
                    "uname": tokens.get("uname"),
                }
            elif user_token and user_id:
                self.api.set_session(userid=user_id, usertoken=user_token)
                response = {
                    "susertoken": user_token,
                    "actid": user_id,
                    "email": None,
                    "uname": None,
                }
            else:
                raise TokenException("Missing Args")

        except TokenException:
            raise

        except ShoonyaOAuthError as e:
            raise InvalidArgumentException(str(e))

        except binascii.Error:
            raise TokenException("Invalid TOTP key provided")

        except Exception as e:
            raise RetryableException(str(e))

        self.set_attributes(response)

    def login(
        self,
        user_id: str,
        password: str,
        twoFA: str,
        vendor_code: str,
        api_secret: str,
        imei: str,
    ):
        response = self.api.login(
            userid=user_id,
            password=password,
            twoFA=twoFA,
            vendor_code=vendor_code,
            api_secret=api_secret,
            imei=imei,
        )

        if response is None:
            raise InvalidArgumentException("Invalid API credentials")

        return response
