"""Shoonya/Finvasia OAuth login + token exchange.

Replaces the dead QuickAuth flow. Two-step:

1. Selenium driver opens the trade.shoonya.com OAuth login URL, fills
   user_id / password / TOTP, submits, and captures the ``code`` returned
   in the redirect (typically to ``https://www.google.com/?code=...`` or
   whatever redirect_uri is registered on the API key).

2. POST to ``/NorenWClientAPI/GenAcsTok`` exchanges the auth_code for an
   access_token. This call MUST originate from an IP whitelisted on the
   user's Shoonya API key, so we always route through ``proxies``.

Returns a dict suitable for merging into ``broker_data`` with the new
fields: access_token, refresh_token, account_id, client_id, Secret_Code.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from typing import Any
from urllib.parse import parse_qs, urlparse

import pyotp
import requests

logger = logging.getLogger(__name__)

LOGIN_URL_TEMPLATE = (
    "https://trade.shoonya.com/OAuthlogin/investor-entry-level/login"
    "?api_key={client_id}&route_to={user_id}"
)
TOKEN_EXCHANGE_URL = "https://api.shoonya.com/NorenWClientAPI/GenAcsTok"


class ShoonyaOAuthError(RuntimeError):
    """Raised when the OAuth flow can't complete (invalid creds, blocked IP,
    etc.). Caller should surface to operator since these are typically not
    auto-recoverable."""


def _scan_for_code(driver) -> str | None:
    try:
        cur = driver.current_url
    except Exception:
        cur = ""
    if "code=" in cur:
        code = parse_qs(urlparse(cur).query).get("code", [None])[0]
        if code:
            return code
    try:
        logs = driver.get_log("performance")
    except Exception:
        return None
    for entry in logs:
        try:
            msg = json.loads(entry["message"])["message"]
            if msg.get("method") != "Network.requestWillBeSent":
                continue
            url = msg.get("params", {}).get("request", {}).get("url", "")
            if "code=" in url:
                code = parse_qs(urlparse(url).query).get("code", [None])[0]
                if code:
                    return code
        except Exception:
            continue
    return None


def _fast_fill(element, value: str) -> None:
    element.click()
    time.sleep(0.1)
    element.clear()
    element.send_keys(value)
    time.sleep(0.1)


def get_auth_code(
    user_id: str,
    password: str,
    totp_secret: str,
    client_id: str,
    timeout_seconds: int = 60,
) -> str:
    """Drive the Shoonya OAuth browser login headless and return the
    ``code`` parameter from the post-login redirect URL."""
    # Local imports keep selenium optional for callers that don't trigger login.
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import WebDriverWait

    login_url = LOGIN_URL_TEMPLATE.format(client_id=client_id, user_id=user_id)

    options = webdriver.ChromeOptions()
    options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    options.set_capability("goog:loggingPrefs", {"performance": "ALL"})

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 30)
    try:
        logger.info("Shoonya OAuth: opening %s", login_url)
        driver.get(login_url)
        wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "input[type='password']"))
        )
        time.sleep(1)

        def fresh_inputs():
            return [
                i
                for i in driver.find_elements(
                    By.CSS_SELECTOR,
                    "input:not([type='hidden']):not([type='checkbox']):not([type='radio'])",
                )
                if i.is_displayed()
            ]

        inputs = fresh_inputs()
        if len(inputs) < 3:
            raise ShoonyaOAuthError(
                f"Expected >=3 visible inputs on login form; got {len(inputs)}"
            )

        _fast_fill(inputs[0], user_id)
        _fast_fill(inputs[1], password)
        otp = pyotp.TOTP(totp_secret).now()
        _fast_fill(inputs[2], otp)

        wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, "//button[normalize-space()='LOGIN']")
            )
        ).click()

        start = time.time()
        last_otp = otp
        while True:
            code = _scan_for_code(driver)
            if code:
                logger.info("Shoonya OAuth: captured auth_code (len=%d)", len(code))
                return code
            if time.time() - start > timeout_seconds:
                new_otp = pyotp.TOTP(totp_secret).now()
                if new_otp != last_otp:
                    try:
                        retry_inputs = fresh_inputs()
                        if len(retry_inputs) >= 3:
                            _fast_fill(retry_inputs[2], new_otp)
                            wait.until(
                                EC.element_to_be_clickable(
                                    (By.XPATH, "//button[normalize-space()='LOGIN']")
                                )
                            ).click()
                            start = time.time()
                            last_otp = new_otp
                            continue
                    except Exception:
                        pass
                raise ShoonyaOAuthError(
                    f"Auth code not captured in {timeout_seconds}s. "
                    f"current_url={driver.current_url}"
                )
            time.sleep(0.5)
    finally:
        try:
            driver.quit()
        except Exception:
            pass


def exchange_code(
    auth_code: str,
    secret_code: str,
    client_id: str,
    user_id: str,
    proxies: dict[str, str] | None = None,
) -> dict[str, Any]:
    """POST /GenAcsTok to swap an auth_code for an access_token.

    ``proxies`` is required in practice -- the GenAcsTok endpoint enforces
    static-IP whitelisting on the calling user's API key, so the request
    must originate from a whitelisted IP.
    """
    checksum = hashlib.sha256(
        (client_id + secret_code + auth_code).encode("utf-8")
    ).hexdigest()
    payload = "jData=" + json.dumps(
        {"code": auth_code, "checksum": checksum, "uid": user_id}
    )
    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    res = requests.post(
        TOKEN_EXCHANGE_URL, data=payload, headers=headers, proxies=proxies, timeout=30
    )
    try:
        body = res.json()
    except ValueError:
        raise ShoonyaOAuthError(
            f"GenAcsTok returned non-JSON (status={res.status_code}): "
            f"{res.text[:300]!r}"
        )
    if "access_token" not in body:
        raise ShoonyaOAuthError(
            f"GenAcsTok rejected exchange: {body!r}"
        )
    return {
        "access_token": body["access_token"],
        "refresh_token": body.get("refresh_token"),
        "account_id": body.get("actid", user_id),
        "uname": body.get("uname"),
        "susertoken": body.get("susertoken"),
        "client_id": client_id,
        "Secret_Code": secret_code,
    }


def login(
    user_id: str,
    password: str,
    totp_secret: str,
    secret_code: str,
    client_id: str | None = None,
    proxies: dict[str, str] | None = None,
) -> dict[str, Any]:
    """End-to-end: Selenium login -> auth_code -> /GenAcsTok -> tokens."""
    if not client_id:
        client_id = f"{user_id}_U"
    auth_code = get_auth_code(
        user_id=user_id,
        password=password,
        totp_secret=totp_secret,
        client_id=client_id,
    )
    return exchange_code(
        auth_code=auth_code,
        secret_code=secret_code,
        client_id=client_id,
        user_id=user_id,
        proxies=proxies,
    )
