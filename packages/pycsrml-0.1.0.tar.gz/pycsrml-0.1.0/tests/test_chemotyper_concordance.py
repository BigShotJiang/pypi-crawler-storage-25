"""
Concordance test: compare pyCSRML fingerprinter output against
ChemoTyper reference fingerprints.

Two test suites:
  1. Richard2023 (small ~14 k) — PFASFingerprinter vs TableS2/S5 CSVs
  2. ToxCast TSV (large 9014)  — ToxPrintFingerprinter (729 bits) and
     PFASFingerprinter (129 bits) vs ChemoTyper TSV exports

Reference files (tests/test_data/):
  Richard2023_SI_TableS2.csv  — DTXSID + all 129 TxP_PFAS bits
  Richard2023_SI_TableS5.csv  — DTXSID + SMILES + compound metadata
  toxcast_smiles.smi          — 9014 SMILES (same row order as TSV files)
  toxprint_V2.tsv             — 9014 × 729 ToxPrint ChemoTyper reference
  TxP_PFAS_v1.tsv             — 9014 × 129 TxP_PFAS ChemoTyper reference

Run with:
    pytest tests/test_chemotyper_concordance.py -v -s
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest
from rdkit import Chem

pytestmark = pytest.mark.slow

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pyCSRML import PFASFingerprinter, ToxPrintFingerprinter

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
DATA_DIR = os.path.join(os.path.dirname(__file__), "test_data")
S2_PATH = os.path.join(DATA_DIR, "Richard2023_SI_TableS2.csv")  # reference fp
S5_PATH = os.path.join(DATA_DIR, "Richard2023_SI_TableS5.csv")  # SMILES
SMI_PATH         = os.path.join(DATA_DIR, "toxcast_smiles.smi")
TOXPRINT_TSV     = os.path.join(DATA_DIR, "toxprint_V2.tsv")
TXPPFAS_TSV      = os.path.join(DATA_DIR, "TxP_PFAS_v1.tsv")


# ---------------------------------------------------------------------------
# Fixtures (module-scoped so data is loaded once)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def fp():
    return PFASFingerprinter()


@pytest.fixture(scope="module")
def fp_toxprint():
    return ToxPrintFingerprinter()


@pytest.fixture(scope="module")
def reference_df():
    """Merge reference fingerprints (S2) with SMILES (S5) on DTXSID."""
    s2 = pd.read_csv(S2_PATH, index_col="DTXSID")
    s5 = pd.read_csv(S5_PATH, index_col="DTXSID")[["SMILES"]]
    merged = s2.join(s5, how="inner")
    # Drop rows with missing SMILES
    before = len(merged)
    merged = merged.dropna(subset=["SMILES"])
    after = len(merged)
    if before != after:
        print(f"\n[fixture] Dropped {before - after} rows with missing SMILES")
    return merged


@pytest.fixture(scope="module")
def toxcast_smiles():
    """9014 SMILES from toxcast_smiles.smi (same row order as TSV files)."""
    with open(SMI_PATH) as fh:
        return [line.strip() for line in fh if line.strip()]


@pytest.fixture(scope="module")
def toxprint_tsv_df():
    """9014 × 729 ToxPrint reference; M_READ_ERROR becomes index via index_col=0."""
    return pd.read_csv(TOXPRINT_TSV, sep="\t", index_col=0)


@pytest.fixture(scope="module")
def txppfas_tsv_df():
    """9014 × 129 TxP_PFAS reference; M_READ_ERROR becomes index via index_col=0."""
    return pd.read_csv(TXPPFAS_TSV, sep="\t", index_col=0)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _compute_concordance(fp_obj, reference_df):
    """
    Returns
    -------
    pred_matrix  : (n_valid, n_bits) bool array  — our predictions
    ref_matrix   : (n_valid, n_bits) int array   — ChemoTyper reference
    valid_dtxsids: list of DTXSIDs that were successfully parsed
    bit_names    : list of bit name strings (length n_bits)
    n_failed     : number of compounds whose SMILES could not be parsed
    """
    bit_names = fp_obj.bit_names

    # Check that all our bit names are present in the reference DataFrame
    missing = [b for b in bit_names if b not in reference_df.columns]
    if missing:
        pytest.fail(
            f"{len(missing)} bit name(s) from PFASFingerprinter are absent in "
            f"the reference CSV, e.g. {missing[:3]}"
        )

    smiles_list = reference_df["SMILES"].tolist()
    dtxsids = reference_df.index.tolist()

    # Parse SMILES, keep track of valid indices
    mols, valid_idx = [], []
    for i, smi in enumerate(smiles_list):
        mol = Chem.MolFromSmiles(str(smi))
        if mol is not None:
            mols.append(mol)
            valid_idx.append(i)

    n_failed = len(smiles_list) - len(valid_idx)

    # Batch fingerprint (our implementation)
    pred_matrix = fp_obj.fingerprint_batch(mols).astype(int)          # (n, 129)

    # Reference fingerprint aligned to our bit order
    ref_matrix = reference_df.iloc[valid_idx][bit_names].to_numpy(dtype=int)  # (n, 129)

    valid_dtxsids = [dtxsids[i] for i in valid_idx]
    return pred_matrix, ref_matrix, valid_dtxsids, bit_names, n_failed


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_bit_names_match_reference_columns(fp, reference_df):
    """Every PFASFingerprinter bit name must exist as a column in TableS2."""
    missing = [b for b in fp.bit_names if b not in reference_df.columns]
    assert not missing, (
        f"{len(missing)} bit name(s) not found in reference CSV: {missing}"
    )


def test_n_bits(fp):
    """PFASFingerprinter should produce exactly 129 bits."""
    assert len(fp.bit_names) == 129, f"Expected 129 bits, got {len(fp.bit_names)}"


def test_chemotyper_concordance(fp, reference_df, capsys):
    """
    Compare pyCSRML fingerprints against ChemoTyper reference.

    Prints a full concordance report.  Asserts that:
      - overall bit accuracy >= 90 %
      - per-bit accuracy >= 70 % for at least 90 % of bits
    """
    pred, ref, dtxsids, bit_names, n_failed = _compute_concordance(fp, reference_df)

    n_compounds, n_bits = pred.shape
    match = pred == ref  # (n, 129) bool

    overall_acc = match.mean()
    bit_acc = match.mean(axis=0)           # (129,)
    compound_acc = match.mean(axis=1)      # (n,)

    # -- TP / FP / FN per bit --
    tp = ((pred == 1) & (ref == 1)).sum(axis=0)
    fp_count = ((pred == 1) & (ref == 0)).sum(axis=0)
    fn = ((pred == 0) & (ref == 1)).sum(axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        precision = np.where(tp + fp_count > 0, tp / (tp + fp_count).astype(float), np.nan)
        recall    = np.where(tp + fn > 0,        tp / (tp + fn).astype(float),        np.nan)
        f1_denom  = precision + recall
        f1        = np.where(f1_denom > 0,
                             2 * precision * recall / f1_denom, np.nan)

    # -- Print report --
    with capsys.disabled():
        print(f"\n{'='*65}")
        print(f"  ChemoTyper concordance report - TxP_PFAS (Richard 2023)")
        print(f"{'='*65}")
        print(f"  Compounds processed : {n_compounds}  (SMILES failures: {n_failed})")
        print(f"  Bits compared       : {n_bits}")
        print(f"  Overall accuracy    : {overall_acc:.4f}  ({overall_acc*100:.2f} %)")
        print(f"  Bits >= 90% acc.    : {(bit_acc >= 0.90).sum()} / {n_bits}")
        print(f"  Bits >= 70% acc.    : {(bit_acc >= 0.70).sum()} / {n_bits}")
        print(f"  Cmpds with 100% acc : {(compound_acc == 1).sum()} / {n_compounds}")
        print(f"  Mean cmpd accuracy  : {compound_acc.mean():.4f}")
        print()

        # Per-bit summary sorted by accuracy
        print(f"  {'Bit name':<60} {'acc':>5}  {'prec':>5}  {'rec':>5}  {'f1':>5}")
        print(f"  {'-'*60}  {'-----':>5}  {'-----':>5}  {'-----':>5}  {'-----':>5}")
        order = np.argsort(bit_acc)
        for i in order:
            p = f"{precision[i]:.3f}" if not np.isnan(precision[i]) else "  N/A"
            r = f"{recall[i]:.3f}"    if not np.isnan(recall[i])    else "  N/A"
            f = f"{f1[i]:.3f}"        if not np.isnan(f1[i])        else "  N/A"
            flag = " << WORST" if i == order[0] else ""
            print(f"  {bit_names[i]:<60} {bit_acc[i]:.3f}  {p:>5}  {r:>5}  {f:>5}{flag}")

        print(f"{'='*65}\n")

    # -- Assertions --
    assert overall_acc >= 0.90, (
        f"Overall bit accuracy {overall_acc:.4f} is below the 0.90 threshold. "
        "Check the per-bit table printed above."
    )
    pct_bits_above_70 = (bit_acc >= 0.70).mean()
    assert pct_bits_above_70 >= 0.90, (
        f"Only {pct_bits_above_70*100:.1f}% of bits have >=70% accuracy "
        f"(threshold: 90% of bits)."
    )


def test_known_compounds_spot_check(fp, reference_df):
    """
    Spot-check PFOA and PFOS against the ChemoTyper reference from S2.

    Fetches SMILES from S5 (via reference_df) and expected bits from S2.
    Asserts:
      - key structural bits are correctly set
      - per-compound accuracy >= 95 %
    Note: a handful of bits (e.g. pfas_atom:element_metal_metalloid_CF) are
    known false positives caused by SMARTS approximations of the G/Q pseudo-
    elements; 100% exact match is not expected.
    """
    known = {
        "DTXSID8031865": {           # PFOA, CAS 335-67-1
            "name": "PFOA",
            "must_have": [
                "pfas_bond:C(=O)O_carboxylicAcid_generic_CF",
                "pfas_chain:perF-linear_C7_plus",
            ],
            "must_not_have": [
                "pfas_bond:S(=O)O_sulfonicAcid_acyclic_(chain)_SCF",
            ],
        },
        "DTXSID3031864": {           # PFOS, CAS 1763-23-1
            "name": "PFOS",
            "must_have": [
                "pfas_bond:S(=O)O_sulfonicAcid_acyclic_(chain)_SCF",
                "pfas_chain:perF-linear_C8_plus",
            ],
            "must_not_have": [
                "pfas_bond:C(=O)O_carboxylicAcid_generic_CF",
            ],
        },
    }

    fp_cols = [c for c in fp.bit_names if c in reference_df.columns]

    for dtxsid, spec in known.items():
        name = spec["name"]
        if dtxsid not in reference_df.index:
            pytest.skip(f"{dtxsid} ({name}) not found in reference data")

        row = reference_df.loc[dtxsid]
        mol = Chem.MolFromSmiles(str(row["SMILES"]))
        assert mol is not None, f"Could not parse SMILES for {name} ({dtxsid})"

        arr, bit_names = fp.fingerprint(mol)
        on_bits = {n for n, v in zip(bit_names, arr) if v}

        for b in spec["must_have"]:
            assert b in on_bits, f"{name}: required bit '{b}' not set"
        for b in spec["must_not_have"]:
            assert b not in on_bits, f"{name}: bit '{b}' should NOT be set"

        # Per-compound accuracy against reference
        pred = arr.astype(int)
        ref = row[fp_cols].to_numpy(dtype=int)
        acc = (pred == ref).mean()
        assert acc >= 0.95, (
            f"{name} ({dtxsid}): accuracy {acc:.3f} < 0.95. "
            f"Mismatches: "
            + "; ".join(
                f"{fp_cols[i]}(ref={int(ref[i])},pred={int(pred[i])})"
                for i in range(len(fp_cols))
                if pred[i] != ref[i]
            )
        )

    # Non-PFAS (benzene) should always have zero bits
    benzene = Chem.MolFromSmiles("c1ccccc1")
    arr_benz, _ = fp.fingerprint(benzene)
    assert not arr_benz.any(), "Benzene should have no TxP_PFAS bits"


# ---------------------------------------------------------------------------
# Helpers — large-dataset concordance
# ---------------------------------------------------------------------------

def _compute_concordance_from_arrays(fp_obj, smiles_list, ref_df, row_mask=None):
    """Parse SMILES, run fingerprinter, align to reference DataFrame.

    Parameters
    ----------
    fp_obj      : Fingerprinter with ``bit_names`` and ``fingerprint_batch``
    smiles_list : list[str], length N (same row order as ref_df)
    ref_df      : DataFrame with bit columns; length N
    row_mask    : optional bool array of length N to restrict to a subset

    Returns
    -------
    pred_matrix  : (n_valid, n_bits) int array
    ref_matrix   : (n_valid, n_bits) int array
    bit_names    : list[str]
    n_failed     : int — SMILES that could not be parsed
    """
    bit_names = fp_obj.bit_names

    if row_mask is not None:
        indices = np.where(row_mask)[0]
        smiles_subset = [smiles_list[i] for i in indices]
        ref_subset = ref_df.iloc[indices]
    else:
        smiles_subset = smiles_list
        ref_subset = ref_df

    mols, valid_local_idx = [], []
    for i, smi in enumerate(smiles_subset):
        mol = Chem.MolFromSmiles(str(smi))
        if mol is not None:
            mols.append(mol)
            valid_local_idx.append(i)

    n_failed = len(smiles_subset) - len(mols)
    pred_matrix = fp_obj.fingerprint_batch(mols).astype(int)
    ref_matrix = ref_subset.iloc[valid_local_idx][bit_names].to_numpy(dtype=int)
    return pred_matrix, ref_matrix, bit_names, n_failed


def _print_concordance_report(pred, ref, bit_names, title, capsys):
    """Print a full concordance report and return (overall_acc, bit_acc, precision, recall)."""
    n_compounds, n_bits = pred.shape
    match = pred == ref

    overall_acc = match.mean()
    bit_acc = match.mean(axis=0)
    compound_acc = match.mean(axis=1)

    tp = ((pred == 1) & (ref == 1)).sum(axis=0)
    fp_count = ((pred == 1) & (ref == 0)).sum(axis=0)
    fn = ((pred == 0) & (ref == 1)).sum(axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        precision = np.where(tp + fp_count > 0, tp / (tp + fp_count).astype(float), np.nan)
        recall    = np.where(tp + fn > 0,        tp / (tp + fn).astype(float),        np.nan)
        f1_denom  = precision + recall
        f1        = np.where(f1_denom > 0, 2 * precision * recall / f1_denom, np.nan)

    with capsys.disabled():
        print(f"\n{'='*75}")
        print(f"  {title}")
        print(f"{'='*75}")
        print(f"  Compounds processed : {n_compounds}")
        print(f"  Bits compared       : {n_bits}")
        print(f"  Overall accuracy    : {overall_acc:.4f}  ({overall_acc*100:.2f} %)")
        print(f"  Bits >= 90% acc.    : {(bit_acc >= 0.90).sum()} / {n_bits}")
        print(f"  Bits >= 70% acc.    : {(bit_acc >= 0.70).sum()} / {n_bits}")
        print(f"  Cmpds with 100% acc : {(compound_acc == 1).sum()} / {n_compounds}")
        print(f"  Mean cmpd accuracy  : {compound_acc.mean():.4f}")
        print()

        # Bits sorted worst-first; only print the 30 worst + those below 90%
        order = np.argsort(bit_acc)
        below90 = (bit_acc < 0.90).sum()
        n_show = max(below90, 30)
        print(f"  Showing {n_show} lowest-accuracy bits:")
        print(f"  {'Bit name':<62} {'acc':>5}  {'prec':>5}  {'rec':>5}  {'f1':>5}")
        print(f"  {'-'*62}  {'-----':>5}  {'-----':>5}  {'-----':>5}  {'-----':>5}")
        for rank, i in enumerate(order[:n_show]):
            p = f"{precision[i]:.3f}" if not np.isnan(precision[i]) else "  N/A"
            r = f"{recall[i]:.3f}"    if not np.isnan(recall[i])    else "  N/A"
            f = f"{f1[i]:.3f}"        if not np.isnan(f1[i])        else "  N/A"
            flag = " << WORST" if rank == 0 else ""
            print(f"  {bit_names[i]:<62} {bit_acc[i]:.3f}  {p:>5}  {r:>5}  {f:>5}{flag}")
        print(f"{'='*75}\n")

    return overall_acc, bit_acc, precision, recall


# ---------------------------------------------------------------------------
# New tests — large ToxCast dataset
# ---------------------------------------------------------------------------

def _save_concordance_report(
    dataset_name: str,
    n_compounds: int,
    n_failed: int,
    overall_acc: float,
    bit_acc: "np.ndarray",
    bit_names: list,
    precision: "np.ndarray",
    recall: "np.ndarray",
    f1: "np.ndarray",
    report_path: str,
    append: bool = True,
) -> None:
    """Write (or append) a Markdown concordance-report section to *report_path*.

    Each call writes one section for a single dataset. Call with ``append=False``
    on the first dataset to start a fresh file, then with ``append=True`` for
    subsequent datasets.
    """
    n_bits = len(bit_names)
    mode = "a" if append else "w"
    with open(report_path, mode, encoding="utf-8") as fh:
        if not append:
            fh.write("# pyCSRML ChemoTyper Concordance Report\n\n")
            fh.write(
                "> Generated by `pytest tests/test_chemotyper_concordance.py -v -s`.  \n"
                "> Re-run the test to refresh this file.\n\n"
            )
        fh.write(f"## {dataset_name}\n\n")
        fh.write("### Summary\n\n")
        fh.write(
            "| Metric | Value |\n"
            "|---|---|\n"
            f"| Compounds processed | {n_compounds} |\n"
            f"| SMILES parse failures | {n_failed} |\n"
            f"| Bits compared | {n_bits} |\n"
            f"| **Overall accuracy** | **{overall_acc:.4f} ({overall_acc*100:.2f} %)** |\n"
            f"| Bits ≥ 90 % accuracy | {(bit_acc >= 0.90).sum()} / {n_bits} |\n"
            f"| Bits ≥ 70 % accuracy | {(bit_acc >= 0.70).sum()} / {n_bits} |\n"
            f"| Mean per-bit accuracy | {bit_acc.mean():.4f} |\n"
            "\n"
        )
        # Worst-15 bits table
        order = np.argsort(bit_acc)
        n_show = min(15, n_bits)
        fh.write("### Lowest-accuracy bits (worst first)\n\n")
        fh.write("| Rank | Bit name | Accuracy | Precision | Recall | F1 |\n")
        fh.write("|---|---|---|---|---|---|\n")
        for rank, i in enumerate(order[:n_show], start=1):
            p = f"{precision[i]:.3f}" if not np.isnan(precision[i]) else "N/A"
            r = f"{recall[i]:.3f}" if not np.isnan(recall[i]) else "N/A"
            f_ = f"{f1[i]:.3f}" if not np.isnan(f1[i]) else "N/A"
            fh.write(f"| {rank} | `{bit_names[i]}` | {bit_acc[i]:.3f} | {p} | {r} | {f_} |\n")
        fh.write("\n")


def test_toxprint_concordance_tsv(fp_toxprint, toxcast_smiles, toxprint_tsv_df, capsys):
    """ToxPrintFingerprinter vs toxprint_V2.tsv ChemoTyper reference (9014 mols).

    Writes a performance summary to tests/concordance_report.md.
    """
    pred, ref, bit_names, n_failed = _compute_concordance_from_arrays(
        fp_toxprint, toxcast_smiles, toxprint_tsv_df
    )
    with capsys.disabled():
        print(f"\n[info] SMILES parse failures: {n_failed}")
    overall_acc, bit_acc, precision, recall = _print_concordance_report(
        pred, ref, bit_names,
        "ChemoTyper concordance — ToxPrint V2 (ToxCast, 9014 mols)",
        capsys,
    )

    # Compute F1 for the report
    f1_denom = precision + recall
    f1 = np.where(f1_denom > 0, 2 * precision * recall / f1_denom, np.nan)

    report_path = os.path.join(os.path.dirname(__file__), "concordance_report.md")
    _save_concordance_report(
        dataset_name="ToxPrint V2 — ToxCast full dataset (9 014 compounds)",
        n_compounds=pred.shape[0],
        n_failed=n_failed,
        overall_acc=overall_acc,
        bit_acc=bit_acc,
        bit_names=bit_names,
        precision=precision,
        recall=recall,
        f1=f1,
        report_path=report_path,
        append=False,  # start a fresh file
    )
    with capsys.disabled():
        print(f"[info] Concordance report written to {report_path}")

    assert overall_acc >= 0.90, f"Overall accuracy {overall_acc:.4f} below 0.90"
    pct = (bit_acc >= 0.70).mean()
    assert pct >= 0.85, f"Only {pct*100:.1f}% of bits have >=70% accuracy (threshold: 85%)"


def test_txppfas_concordance_tsv(fp, toxcast_smiles, txppfas_tsv_df, capsys):
    """PFASFingerprinter vs TxP_PFAS_v1.tsv on the CF-containing subset (~808 mols).

    Reports both the CF-only subset (meaningful PFAS accuracy) and the full-9014
    dataset results.  Appends to tests/concordance_report.md.
    """
    report_path = os.path.join(os.path.dirname(__file__), "concordance_report.md")
    cf_mask = (txppfas_tsv_df.values > 0).any(axis=1)
    n_cf = int(cf_mask.sum())
    with capsys.disabled():
        print(f"\n[info] CF-containing compounds: {n_cf} / {len(cf_mask)}")

    # ---- CF-only subset (primary assertion) --------------------------------
    pred_cf, ref_cf, bit_names, n_failed_cf = _compute_concordance_from_arrays(
        fp, toxcast_smiles, txppfas_tsv_df, row_mask=cf_mask
    )
    with capsys.disabled():
        print(f"[info] CF-subset SMILES parse failures: {n_failed_cf}")
    overall_cf, bit_acc_cf, prec_cf, rec_cf = _print_concordance_report(
        pred_cf, ref_cf, bit_names,
        "ChemoTyper concordance — TxP_PFAS v1 (CF-subset, ~808 mols)",
        capsys,
    )
    f1_denom_cf = prec_cf + rec_cf
    f1_cf = np.where(f1_denom_cf > 0, 2 * prec_cf * rec_cf / f1_denom_cf, np.nan)
    _save_concordance_report(
        dataset_name=f"TxP\\_PFAS v1 — CF-containing subset ({n_cf} compounds)",
        n_compounds=pred_cf.shape[0],
        n_failed=n_failed_cf,
        overall_acc=overall_cf,
        bit_acc=bit_acc_cf,
        bit_names=bit_names,
        precision=prec_cf,
        recall=rec_cf,
        f1=f1_cf,
        report_path=report_path,
        append=True,
    )

    # ---- Full dataset (informational) --------------------------------------
    pred_all, ref_all, _bn, n_failed_all = _compute_concordance_from_arrays(
        fp, toxcast_smiles, txppfas_tsv_df
    )
    with capsys.disabled():
        print(f"[info] Full-dataset SMILES parse failures: {n_failed_all}")
    overall_all, bit_acc_all, prec_all, rec_all = _print_concordance_report(
        pred_all, ref_all, bit_names,
        "ChemoTyper concordance — TxP_PFAS v1 (full ToxCast 9014 mols)",
        capsys,
    )
    f1_denom_all = prec_all + rec_all
    f1_all = np.where(f1_denom_all > 0, 2 * prec_all * rec_all / f1_denom_all, np.nan)
    _save_concordance_report(
        dataset_name="TxP\\_PFAS v1 — full ToxCast dataset (9 014 compounds, informational)",
        n_compounds=pred_all.shape[0],
        n_failed=n_failed_all,
        overall_acc=overall_all,
        bit_acc=bit_acc_all,
        bit_names=bit_names,
        precision=prec_all,
        recall=rec_all,
        f1=f1_all,
        report_path=report_path,
        append=True,
    )

    with capsys.disabled():
        print(f"[info] Concordance report updated at {report_path}")

    # Assertions on the stricter CF-subset
    assert overall_cf >= 0.90, f"Overall accuracy {overall_cf:.4f} below 0.90"
    pct = (bit_acc_cf >= 0.70).mean()
    assert pct >= 0.85, f"Only {pct*100:.1f}% of bits have >=70% accuracy (threshold: 85%)"
