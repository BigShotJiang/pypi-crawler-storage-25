---
project: med
type: reference
status: draft
date: 2026-04-08
tags: [med, mcp, prompts, design]
---

# MED MCP — Prompts Design

Pre-built MCP prompt templates that pair with the 4 tools. These give users one-click entry points into common workflows so they don't have to construct queries from scratch.

**Status:** Design only. Implement when user feedback reveals which prompts actually get used. Smithery quality score gets +5pt once any prompts ship.

**Design principles:**
- **Voice match:** Direct, no-fluff, mechanic-friend tone — same as MED brand voice
- **Real moments:** Each prompt anchors to a specific decision point a driver actually faces
- **Multi-tool when valuable:** Single-tool wrappers are fine for quick entry, multi-tool prompts justify their existence by composing tools that are tedious to chain manually
- **Arguments minimal:** Only ask for what's truly required — Claude can infer the rest from conversation

---

## Prompt 1: `fair-price-check`

**Description:** Got a repair quote? Find out if it's fair before you authorize the work.

**When to use:** Standing at the service counter, on the phone with a shop, or staring at a written estimate.

**Arguments:**
| Name | Required | Description |
|---|---|---|
| `repair` | yes | What they're quoting (e.g., "front brake pads and rotors") |
| `vehicle` | yes | Year, make, model (e.g., "2020 Toyota Camry") |
| `quote` | yes | The price they quoted, in dollars |
| `shop_type` | no | "independent" or "dealer" — defaults to independent |

**Template body:**
```
I just got a quote for {repair} on my {vehicle}. They want ${quote} ({shop_type}).

Use check_repair_estimate to tell me:
1. Is this in range, high, or low?
2. What questions should I ask before I authorize the work?
3. Are there any red flags about the price itself I should know?

Be direct. If it's a fair price, say so. If it's not, tell me what a reasonable counter-offer looks like.
```

**Tools used:** `check_repair_estimate`

**Why this is the #1 prompt:** Estimate anxiety is the single biggest pain point in the MED audience. This is the moment people would actually open Claude and ask.

---

## Prompt 2: `whats-due-now`

**Description:** Get a no-BS maintenance checklist for your vehicle at its current mileage.

**When to use:** Just hit a milestone mileage (50K, 100K, 150K), bought a used car, or a shop is telling you "you really need" three things at once.

**Arguments:**
| Name | Required | Description |
|---|---|---|
| `vehicle` | yes | Year, make, model |
| `mileage` | yes | Current odometer reading |

**Template body:**
```
My {vehicle} has {mileage} miles on it. Use get_maintenance_schedule to give me:
1. What maintenance is actually due right now (separated from "would be nice")
2. What's coming in the next 10,000 miles so I can budget for it
3. Common upsells for this vehicle at this mileage that I should push back on
4. Any known issues for this make/model/year I should keep an eye on

I want the truth, not a dealer service department wishlist.
```

**Tools used:** `get_maintenance_schedule`

---

## Prompt 3: `fix-or-walk`

**Description:** Major repair coming and you're not sure if it's worth it. Get a fix-or-replace recommendation grounded in real numbers.

**When to use:** Facing a $1,500+ repair on an older or higher-mileage vehicle, and the "is this car worth saving?" question is on the table.

**Arguments:**
| Name | Required | Description |
|---|---|---|
| `vehicle` | yes | Year, make, model |
| `mileage` | yes | Current odometer reading |
| `repair_cost` | yes | Cost of the repair you're facing in dollars |
| `vehicle_value` | no | Current market value if known (will ask if missing) |
| `recent_repair_spend` | no | What you've spent on non-routine repairs in the past 12 months |

**Template body:**
```
I'm facing a ${repair_cost} repair on my {vehicle} ({mileage} miles).
{vehicle_value ? "It's worth about $" + vehicle_value + " right now." : "I haven't checked the current value yet — help me figure that out first."}
{recent_repair_spend ? "I've spent about $" + recent_repair_spend + " on repairs in the last 12 months." : ""}

Use should_i_fix_or_replace to tell me:
1. Fix it, or walk away?
2. The honest math behind that recommendation
3. The real cost of replacement vs the cost of keeping this one going
4. Any factors I'm not thinking about that should change my decision

I don't want a "depends on your situation" answer. Tell me what you'd do and why.
```

**Tools used:** `should_i_fix_or_replace`

---

## Prompt 4: `shop-visit-debrief` (multi-tool)

**Description:** You just left a shop visit feeling uneasy. Walk through what happened and find out if you got played.

**When to use:** After any shop interaction where something felt off — pressure tactics, vague explanations, surprise add-ons, or a price that seemed high.

**Arguments:**
| Name | Required | Description |
|---|---|---|
| `vehicle` | yes | Year, make, model |
| `repair` | yes | What they said you needed |
| `quote` | yes | The price they quoted |
| `what_happened` | yes | Describe the interaction in your own words — what they said, how they acted, any pressure tactics |

**Template body:**
```
I just left a shop and something feels off. Here's what happened:

{what_happened}

The vehicle is a {vehicle}. They told me I needed {repair} and quoted ${quote}.

Run BOTH of these for me:
1. Use check_repair_estimate to tell me if the price is fair for this work
2. Use check_shop_red_flags to analyze what they said and how they acted

Give me a combined verdict:
- Was the price fair?
- Were any of the red flags from your training present in this interaction?
- What should I do next? (Pay it, get a second opinion, walk away, ask specific follow-up questions?)

Be direct. If they were trying to take me, say so.
```

**Tools used:** `check_repair_estimate` + `check_shop_red_flags`

**Why this matters:** This is the prompt that demonstrates MED MCP's real edge — composing tools that are tedious to chain manually. A debrief workflow is the kind of thing nobody builds themselves but everyone wants when they're rattled after a shop visit.

---

## Prompt 5: `used-car-pre-purchase` (multi-tool)

**Description:** Looking at a used car? Run a structured pre-purchase intelligence check before you make an offer.

**When to use:** Test driving a used car, reviewing a Carfax, or reading a pre-purchase inspection report. Before any money changes hands.

**Arguments:**
| Name | Required | Description |
|---|---|---|
| `vehicle` | yes | Year, make, model of the vehicle you're considering |
| `mileage` | yes | Odometer reading |
| `asking_price` | yes | What the seller wants for it |
| `inspection_notes` | no | Paste any pre-purchase inspection findings, Carfax notes, or things the seller mentioned |
| `seller_quoted_repairs` | no | Any repairs the seller already disclosed and the prices they cited |

**Template body:**
```
I'm considering buying a {vehicle} with {mileage} miles. They're asking ${asking_price}.

{inspection_notes ? "Here's what the inspection (or my own look) found:\n\n" + inspection_notes : ""}

{seller_quoted_repairs ? "The seller mentioned these repairs:\n\n" + seller_quoted_repairs : ""}

Walk me through this purchase decision:
1. Use get_maintenance_schedule to tell me what this vehicle is going to need in the next 10,000-20,000 miles based on its mileage. I need to know what I'm walking into.
{seller_quoted_repairs ? "2. Use check_repair_estimate for each repair the seller mentioned. Are they being honest about prices?" : ""}
{inspection_notes ? "3. Use check_shop_red_flags to scan the inspection notes for anything suspicious or downplayed." : ""}
4. Based on everything above, give me a total cost-of-ownership picture for the next year. What am I really paying?
5. Negotiation leverage: what should I push back on, and what's a fair counter-offer if there's pending work?

I'd rather walk away from a bad deal than buy something I'll regret. Be honest.
```

**Tools used:** `get_maintenance_schedule` + `check_repair_estimate` + `check_shop_red_flags`

**Why this matters:** Pre-purchase due diligence is the highest-ROI moment for a driver. Most people make this decision blind and overpay or buy a money pit. This prompt is the use case Chris should specifically promote to anyone shopping used.

---

## Implementation notes (for later)

When you're ready to ship these, the FastMCP pattern is:

```python
@mcp.prompt()
def fair_price_check(repair: str, vehicle: str, quote: float, shop_type: str = "independent") -> str:
    return f"""I just got a quote for {repair} on my {vehicle}. They want ${quote} ({shop_type}).

Use check_repair_estimate to tell me:
1. Is this in range, high, or low?
2. What questions should I ask before I authorize the work?
3. Are there any red flags about the price itself I should know?

Be direct. If it's a fair price, say so. If it's not, tell me what a reasonable counter-offer looks like."""
```

The decorator auto-generates the MCP prompt schema from the function signature. Type hints become argument types, parameter names become argument names, default values mark arguments as optional, and the docstring becomes the description.

**Also update SERVER_CARD** in server.py — add a `prompts` array mirroring the FastMCP definitions. Smithery reads prompts from the server card just like tools.

---

## Prioritization for first ship

When real feedback comes in, ship in this order based on expected usage frequency × value:

1. **`fair-price-check`** — biggest pain point, simplest prompt, ship first
2. **`shop-visit-debrief`** — demonstrates multi-tool value, highest "wow" factor
3. **`fix-or-walk`** — high stakes, high gratitude when it lands
4. **`whats-due-now`** — proactive use case, lower urgency but builds habit
5. **`used-car-pre-purchase`** — niche but extremely valuable for the right user, biggest organic word-of-mouth potential

Don't ship all 5 at once — ship 1-2, watch what people actually use, then add the next ones based on real demand. Premature optimization for unused prompts is its own form of bloat.

---

## Open design questions

- **Should prompts mention `myeverydaydriver.com` for follow-up advisory bookings?** Probably yes for the high-stakes ones (`fix-or-walk`, `shop-visit-debrief`, `used-car-pre-purchase`) — these are the moments where someone might pay $49-$199 for a real human review. Add a closing line: *"If you want a real person to review this with you, MED Advisory takes appointments at myeverydaydriver.com/advisory."* But ONLY on the high-stakes prompts — don't pollute the simple ones.
- **Internationalization?** All prompts assume USD and US-market vehicle data. Fine for v1, MED is Wake County NC first.
- **Tone calibration:** These drafts are direct/blunt to match MED voice. After Chris's voice profile is fully extracted from transcripts (current draft), revisit and tune the prompt language to match his actual phrasing.
