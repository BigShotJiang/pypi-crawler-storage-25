---
project: med
type: reference
status: ready-to-paste
date: 2026-05-01
tags: [med, mcp, web-demo, claude-design, prototype, ask-med]
---

# Claude Design — MED-WEB-DEMO Prototype Prompt (paste-ready)

**Use:** Validate the `myeverydaydriver.com/ask` UX + voice + conversion flow before committing 4-6 hours to the production Netlify Function build.
**Mode:** Claude Design → Prototype → **High fidelity** (NOT slide deck, NOT wireframe).
**Source spec:** [[03_PROJECTS/Auto_Project/MCP_Server/WEB_DEMO_SPEC|WEB_DEMO_SPEC.md]]
**Time estimate:** 30-60 min in Claude Design vs 4-6 hours for production build.

---

## Setup steps (in Claude Design)

1. Click **Prototype** tab → **High fidelity** option
2. Project name: `MED Ask — web demo prototype`
3. Verify the **MED design system** is loaded (Playfair Display + Barlow Condensed + Source Sans 3 + MED color tokens)
4. Click **Create**
5. Optionally attach: `C:\zbd\03_PROJECTS\Auto_Project\Site_Mods\fleet.html` (so Claude Design can pattern-match nav chrome + button DOM)
6. Paste the prompt below

---

## The prompt to paste

```
Build a high-fidelity interactive prototype of `myeverydaydriver.com/ask` — MED's free no-install AI vehicle advisor. The page lets any driver ask MED's 4 tools without installing anything.

The prototype must call the Claude API live from inside the page (use the API-from-prototype capability) — no backend, no signup, no install. This is for UX + voice validation before we build the production Netlify Function version.

═══════════════════════════════════════════════════════════════
BRAND (MED design system — already loaded)
═══════════════════════════════════════════════════════════════

Typography (canonical):
- Playfair Display 700 — page H1, section H2/H3, nav logo
- Barlow Condensed 600/700/800 — eyebrows, labels, buttons, uppercase 0.2em letter-spacing
- Source Sans 3 300/400/500/600 — body copy (default 300 light)

Color tokens (canonical):
- --orange: #E8651A   (primary accent, CTAs, eyebrow lines)
- --orange-dim: #bf5218
- --dark: #1a1a1a     (hero, footer)
- --navy: #0D1B2A     (reserved — guide-hero only, not this page)
- --mid: #555555      (mid-gray text)
- --light: #f5f3ef    (cream — alternating section bg)
- --rule: #e0dbd3     (hairline rules)
- --white: #ffffff

Section rhythm: alternating cream → white with hairline rules. Hero + footer dark.

Banned words (never use): delve, pivotal, crucial, testament, underscores, realm, harness, illuminate, nuanced, intricate, vibrant, exceptional, innovative, transformative, cutting-edge, revolutionize, game-changing.

Banned phrases: "delve into", "in the realm of", "shed light on", "at its core", "It's not X — it's Y" (and inversions). No formulaic transitions: Additionally, Moreover, Furthermore, Indeed, Consequently. No formulaic closings: "In conclusion", "Ultimately", "To summarize".

Voice anchor: 20-year mechanic talking to a neighbor. Plain English. Specific not generic. No hype, no hedging, no consultant-speak.

═══════════════════════════════════════════════════════════════
PAGE STRUCTURE
═══════════════════════════════════════════════════════════════

ABOVE THE FOLD — dark hero section (#1a1a1a + diagonal orange stripe texture):

  [Existing MED nav chrome — match fleet.html. Logo Playfair Display, links #aaa, active state orange, primary CTA orange-fill]

  Eyebrow (Barlow Condensed 700 orange uppercase 0.2em): FREE TOOL — NO INSTALL
  H1 (Playfair Display 700 white, clamp(2.4rem, 5.5vw, 3.8rem)): Ask MED
  Sub (Source Sans 3 300 #aaa): Free AI advisor with 20 years of mechanic expertise. Get a real answer in 30 seconds.

  Form card (cream bg #f5f3ef, hairline border #e0dbd3, max-width 720px, centered):

    Row 1: Year [4-digit input] | Make [text input]
    Row 2: Model [text input] | Mileage [number input + " miles" suffix]
    Row 3: Question label (Barlow Condensed 700 uppercase) "What's your question?"
           Multi-line textarea (4 rows, placeholder: 'e.g. "Shop quoted me $1,400 for a timing chain. Is that fair?"')

    [Get Answer →] button — orange #E8651A fill, dark text, Barlow Condensed 700 uppercase, large

    Trust line (Source Sans 3 400 mid-gray, with checkmark glyphs): ✓ Free   ✓ No signup   ✓ No data shared

  Sample question chips (below form, 4 chips horizontal scrollable on mobile):
    🔧 "$1,400 for a timing chain on my 2015 Honda Civic — fair?"
    📅 "What does my 2018 Camry need at 95k miles?"
    ⚖️ "Should I fix or replace my 2012 Escape with 168k miles, $3,200 trans repair, $4,500 value?"
    🚩 "Shop says my serpentine belt could break any minute and won't show me — real or scam?"

  Each chip on click: pre-fills the form fields (year/make/model/mileage parsed where possible) + question text. User can edit before submitting.

BELOW THE FOLD — initially hidden, revealed on submit:

  Loading state: animated dots (orange) + Barlow Condensed micro-copy "Pulling up your answer…"
  Smooth scroll to response card on submit.

  Response card (white bg, hairline border, max-width 720px):
    Eyebrow (Barlow Condensed 700 orange): MED'S ANSWER
    H3 (Playfair Display 700): Here's the verdict.
    Markdown-rendered response body (Source Sans 3 400, line-height 1.6)

    Hairline rule (#e0dbd3)

    Feedback row: "Was this helpful?" + thumbs-up / thumbs-down buttons (icon-only, hover orange)

    Upsell strip (cream bg sub-section inside the card):
      "Want a real human to review this with you?"
      [Book a 15-min call →] button (orange-outline secondary style)

      "Going deeper into your vehicle?"
      [Read the Driver's Survival Guide →] (text link with orange underline)

  Disclaimer footer (small, Source Sans 3 300 #555):
    "MED Vehicle Intelligence is an educational tool. For complex decisions, talk to a real mechanic — book one above."

FOOTER — match fleet.html footer pattern exactly:
  Dark #1a1a1a + 3px orange top border
  Logo left, nav links center, copyright right
  Plus: small "Built by Chris Zimmerman, 20-year mechanic & founder of My Everyday Driver"
  Smithery link for devs/AI tinkerers
  Newsletter capture: simple email input + Subscribe button

═══════════════════════════════════════════════════════════════
THE LIVE API CALL (this is the prototype's defining feature)
═══════════════════════════════════════════════════════════════

When user clicks [Get Answer →], call Claude API directly from the prototype with:

MODEL: claude-haiku-4-5  (cost-bounded — Haiku is fast and cheap, ideal for prototype validation)
max_tokens: 800
temperature: 0.4

SYSTEM PROMPT:
"""
You are MED Vehicle Intelligence — an automotive advisor with 20+ years of shop experience, founded by Chris Zimmerman (military + civilian automotive veteran). You're the AI version of a mechanic friend who tells people the truth.

Your job: give straight answers to vehicle owners. Direct. No fluff. No hedging. No consultant-speak.

You have 4 tools available — use them based on what the user asks:

1. check_repair_estimate — Compares a repair quote against national price ranges (independent shops vs dealers). Returns: in-range / high / low + questions to ask the shop. Use when user mentions a price quote.

2. get_maintenance_schedule — Returns what's due now, what's coming in next 10K miles, common upsells to question, and known issues for the specific vehicle. Use when user asks about maintenance, mileage milestones, or "what does my car need."

3. should_i_fix_or_replace — Calculates repair-to-value ratio, factors mileage/age/repair history, gives a scored recommendation. Use when user is weighing fixing vs replacing.

4. check_shop_red_flags — Analyzes a shop interaction for 7 red-flag patterns (won't show parts, vague pricing, pressure tactics, etc.). Returns: matched flags + positive signals + what to do next. Use when user describes a shop interaction.

For this prototype, you don't have access to the actual JSON knowledge bases yet — synthesize plausible answers based on your general automotive knowledge while staying in MED's voice. Don't invent specific dollar figures from RepairPal — use ranges that sound credible (e.g. "typical range $X-$Y for that repair on similar vehicles").

Response format every time:
- One-line verdict at the top (the actual answer)
- 2-3 short paragraphs of reasoning
- "What to do next" section with 1-3 concrete steps

Banned words/phrases (hard rule — never use): delve, pivotal, crucial, testament, transformative, game-changing, revolutionize, "delve into", "in the realm of", "It's not X — it's Y" patterns. No formulaic transitions (Additionally / Moreover / Furthermore). Plain language only.

If the user's question is too vague to answer, ask one clarifying question instead of guessing. Don't pad responses with disclaimers — the page footer handles that.
"""

USER MESSAGE FORMAT (build from form fields):
"Vehicle: {year} {make} {model} with {mileage} miles.

Question: {question}"

═══════════════════════════════════════════════════════════════
CRITICAL UX BEHAVIORS
═══════════════════════════════════════════════════════════════

1. Form validation:
   - Year must be 4 digits, between 1990 and current year
   - Make/Model must be non-empty text
   - Mileage must be a number, between 0 and 500000
   - Question must be at least 10 characters
   - Show inline validation errors below each field in orange (#E8651A) — never red. Match MED brand.

2. Loading state:
   - On submit: button text changes to "Thinking…" + spinner + button disabled
   - Form scrolls into "compressed" view (just the question + vehicle string visible)
   - Response area expands below with animated dots (orange)
   - Average API call should take 3-8 seconds — make the wait feel intentional, not broken

3. Response rendering:
   - Markdown rendered (use a lightweight markdown lib — marked.js or similar)
   - Lists, bold, code blocks, headings styled to MED brand
   - Smooth scroll to the response card on completion
   - Response stays visible — user can ask another question by editing the form and resubmitting

4. Error states:
   - API key missing / invalid: friendly fallback message — "Our AI advisor is offline right now. Try again in a minute, or [book a 15-min call] for a live human review."
   - Rate limit hit: "You've used your free queries for the hour. [Book a call] for unlimited or come back later."
   - Generic API error: "Something went sideways. Try refreshing — or [book a call] for a live human review."

5. Mobile responsive:
   - Single column below 720px
   - Form fields stack vertically
   - Sample chips become horizontal scroll (don't wrap to multiple rows)
   - Touch-target minimum 44px for all interactive elements

═══════════════════════════════════════════════════════════════
VALIDATION TESTS (run these after build)
═══════════════════════════════════════════════════════════════

Test the prototype with all 4 sample question chips. Each should:
1. Pre-fill the form correctly when clicked
2. Submit and return a response within 10 seconds
3. Get a response that uses the appropriate tool framing (estimate / maintenance / fix-or-replace / red-flags)
4. Stay in MED voice — no banned words/phrases
5. Include verdict + reasoning + next-steps structure

Also test:
- Free-text question that doesn't match any tool ("How do I change a tire?") — should gracefully respond without forcing a tool fit
- Vague question ("My car is broken") — should ask a clarifying question, not guess
- Form validation — try submitting with missing fields, year=1850, mileage=999999

═══════════════════════════════════════════════════════════════
EXPLICITLY OUT OF SCOPE FOR PROTOTYPE
═══════════════════════════════════════════════════════════════

Don't build (production-only):
- Real JSON knowledge base lookups (prototype synthesizes from general knowledge)
- Real rate limiting (prototype trusts Claude Design's built-in)
- Plausible / analytics events (production phase 2)
- Streaming SSE responses (production phase 3)
- Server-side caching (production phase 3)
- Knowledge base sync pipeline (production phase 4)

When done, deliver:
- The interactive prototype URL
- A short critique of what feels "off" — UX gaps, voice misses, form-flow friction
- A list of what should change before porting to the production Netlify Function build
```

---

## After the prototype is built

1. **Test the 4 sample chips end-to-end** — confirm voice, tool framing, response quality
2. **Share prototype URL with 2-3 people** (friends/family, not public) — watch them use it cold, capture friction
3. **Decide:** does this validate the production build (port to Netlify Function), or does the UX need rework first?
4. **If validated:** schedule the production build per `WEB_DEMO_SPEC.md` Phase 1 (4-6 hr)
5. **If NOT validated:** iterate the prototype until UX + voice + flow feel right BEFORE committing to production code

## Cost note

Each prototype API call costs ~$0.006 on Haiku (~$0.05 on Sonnet). Self-testing and small group share should stay well under $5 total. **Do NOT share the prototype URL publicly** until you understand Claude Design's exposure model — random visitors hitting the API can burn quota fast.

## Open questions deferred from WEB_DEMO_SPEC §"Open questions for Chris"

These don't block the prototype build but should resolve before production:
1. URL slug: `/ask` vs `/advisor` vs `/free-tool` — recommend `/ask`
2. Model: Haiku v1, Sonnet upgrade option v2
3. Auth gate: free-first, capture afterward (response is the lead magnet)
4. Voice tuning: defer until voice profile fully extracted
5. Calendly upsell visibility: every response
6. Lead capture for non-buyers: newsletter signup as default
7. Disclaimer copy: single line in card footer (handled in prompt above)

---

*Saved as paste-ready reference. Use during next session after MED MCP carousel ships.*
