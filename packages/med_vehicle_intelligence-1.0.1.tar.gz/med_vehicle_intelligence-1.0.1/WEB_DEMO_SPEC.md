---
project: med
type: reference
status: draft
date: 2026-04-08
tags: [med, mcp, web-demo, spec, netlify-functions, anthropic-api]
---

# MED Vehicle Intelligence — No-Install Web Demo Spec

## Why this exists

The MCP server is the engine. Smithery + Claude Desktop is the install path for **devs and AI early adopters**. But the actual MED audience — everyday drivers who feel powerless at the service counter — will not install Claude Desktop, edit a JSON config, or learn what an MCP is.

**They need a webform on myeverydaydriver.com** where they enter their vehicle and a question, click a button, and get back the same straight answer the MCP server gives. No login, no install, no jargon.

This is the version that goes in the Beehiiv email, the Facebook page post, the X reply demos to non-dev users, and the eventual paid ad creative. **The MCP server proves the technology works. The web demo converts drivers into MED customers.**

## Goal

A single page at `myeverydaydriver.com/ask` (or `/advisor`, `/free-tool`, name TBD) that lets any driver ask MED's 4 tools without installing anything.

**Success criteria:**
- A driver with no technical knowledge can land on the page, fill it out, and get a useful response in under 60 seconds
- The response quality matches what the MCP server returns in Claude Desktop (verified against the 4 demo prompts we already tested)
- API costs per query are bounded (<$0.10 per query at expected volume)
- Zero ongoing maintenance unless tools or knowledge base change

## Architecture options

### Option A — Netlify Function calling Anthropic API directly with embedded tool defs ⭐ RECOMMENDED

**Stack:**
- Frontend: Single HTML page in `Site_Mods/` → deployed via existing git-connected Netlify pipeline (zimconsulting-ops/med-site repo)
- Backend: Netlify Function (Node.js) at `netlify/functions/ask-med.js`
- Anthropic API: Direct call from the function with `ANTHROPIC_API_KEY` in Netlify env vars
- Tool execution: Knowledge base JSONs bundled into the function, tool logic ported from Python to JavaScript

**Flow:**
1. User fills HTML form: vehicle year, make, model, mileage, free-text question
2. Form POSTs to `/.netlify/functions/ask-med`
3. Function constructs an Anthropic Messages API call with `tools=[...]` schema mirroring the 4 MED MCP tools
4. Anthropic returns either text or `tool_use` requests
5. If `tool_use`: function executes the tool by reading bundled JSON knowledge bases (mirroring `tools/check_estimate.py` etc), returns `tool_result`
6. Loop until Anthropic returns final text response (typically 1-2 tool calls per query)
7. Function returns response text + metadata to frontend
8. Frontend renders the markdown response

**Why this wins:**
- Zero new infrastructure (Netlify Functions are first-class on the existing setup)
- API key stays server-side
- Bounded cost (one Netlify function invocation + 1-2 Claude API calls per query)
- Self-contained — no dependency on the Railway MCP being up
- Same knowledge base, no drift risk if you keep the JSONs in one place

**Tradeoff:**
- Tool logic duplicated in JS (mirrors the Python in `src/med_vehicle_intelligence/tools/`)
- Mitigated by: knowledge base JSON files are the source of truth, JS tool functions are thin wrappers around the same JSON lookups (not independent algorithms)

### Option B — Netlify Function calling the Railway MCP server via HTTP

**Stack:** Frontend → Netlify Function → Anthropic API with `mcp_servers=[]` parameter pointing to Railway URL → Anthropic does the MCP orchestration

**Status:** Anthropic announced first-class MCP support in the Messages API (`mcp_servers` parameter) in late 2025. If your `mcp` library version supports this and Railway is reachable, this is the cleanest architecture — zero tool logic duplication, single source of truth.

**Tradeoff:**
- Requires Anthropic SDK version that supports `mcp_servers` param (verify before implementing)
- Adds latency (one extra hop)
- Tied to Railway uptime — if Railway is down, the web demo is also down
- More potential failure modes during the critical launch window

**Recommendation:** Start with Option A for launch reliability. Migrate to Option B in v2 once the launch is stable and Anthropic's MCP API is proven in production.

### Option C — Smithery as gateway

**Stack:** Frontend → Netlify Function → Smithery's hosted gateway endpoint → MED MCP

**Status:** Smithery is rolling out hosted gateway features but the API is still maturing. Adds a third party to the stack you'd need to debug if anything breaks during launch.

**Verdict:** Skip for v1. Reconsider in v3 if Smithery's gateway becomes the de facto standard.

---

## File structure (Option A — recommended)

```
Auto_Project/
├── Site_Mods/                                   (or wherever the live site source lives)
│   ├── ask.html                                 ← NEW: the user-facing form page
│   ├── css/ask.css                              ← NEW: page-specific styles (optional, can inline)
│   └── js/ask.js                                ← NEW: form handling + response rendering
└── MCP_Server/                                  (existing — source of truth for tool logic)
    ├── netlify/functions/
    │   ├── ask-med.js                           ← NEW: serverless function entry point
    │   ├── tools/
    │   │   ├── check_estimate.js                ← NEW: JS port of Python tool
    │   │   ├── maintenance.js                   ← NEW
    │   │   ├── repair_replace.js                ← NEW
    │   │   └── red_flags.js                     ← NEW
    │   ├── knowledge_base/
    │   │   ├── repair_costs.json                ← copy from Python knowledge_base/
    │   │   ├── maintenance_schedules.json       ← copy
    │   │   ├── vehicle_issues.json              ← copy
    │   │   └── shop_questions.json              ← copy
    │   └── package.json                         ← Node deps (just @anthropic-ai/sdk)
    └── netlify.toml                             ← NEW: Netlify config
```

**Important:** The JSON knowledge bases should be **copied, not symlinked**. Netlify Functions need the files in their bundle. Add a build step or pre-deploy script that syncs them from `MCP_Server/knowledge_base/` to `MCP_Server/netlify/functions/knowledge_base/` on every deploy. Manual sync is fine for v1.

---

## Frontend spec — `ask.html`

### Layout

Match MED brand: navy `#0D1B2A` background, orange `#E8651A` accents, "My Everyday Driver" header from existing site, Inter or system-ui font stack.

### Above the fold

```
[MED logo / nav (matches existing site header)]

╔══════════════════════════════════════════════════════╗
║  Ask MED                                              ║
║  Free AI advisor with 20 years of mechanic expertise. ║
║  Get a real answer in 30 seconds.                     ║
╚══════════════════════════════════════════════════════╝

[Form]

  Year:      [____]
  Make:      [_______________]
  Model:     [_______________]
  Mileage:   [_____________ miles]

  What's your question?
  ┌───────────────────────────────────────────────────┐
  │  e.g. "Shop quoted me $1,400 for a timing chain.  │
  │       Is that fair?"                              │
  │                                                    │
  │                                                    │
  └───────────────────────────────────────────────────┘

  [   Get Answer   ]

  ✓ Free   ✓ No signup   ✓ No data shared

```

### Below the fold (initially hidden, shown after form submit)

```
[Loading state — animated dots while waiting]

[Response card]
┌─────────────────────────────────────────────────────┐
│  Here's your answer:                                │
│                                                      │
│  [Markdown-rendered response from Claude]           │
│                                                      │
│  ─────────────────────────────────────────────────  │
│  Was this helpful? [👍] [👎]                         │
│                                                      │
│  Want a real human to review this with you?         │
│  [Book a 15-min call →] (Calendly link)             │
└─────────────────────────────────────────────────────┘
```

### Sample questions (clickable chips below the form)

Pre-populate with the 4 demo prompts as one-click examples:
- 🔧 "$1,400 for a timing chain on my 2015 Honda Civic — fair?"
- 📅 "What does my 2018 Camry need at 95k miles?"
- ⚖️ "Should I fix or replace my 2012 Escape with 168k miles, $3,200 trans repair, $4,500 value?"
- 🚩 "Shop says my serpentine belt could break any minute and won't show me — real or scam?"

Click → fills the form with the example → user can edit → submit.

### Bottom of page

- "Built by Christian Zimmerman, 20-year mechanic & founder of My Everyday Driver"
- Link to Smithery listing for devs / AI tinkerers who want the real MCP install
- Link to the Driver's Survival Guide (existing $17 product) — this is the natural upsell
- Link to Advisory booking page
- Subscribe to newsletter form (capture leads from non-buyers)

---

## Backend spec — `netlify/functions/ask-med.js`

### Request payload

```json
POST /.netlify/functions/ask-med
{
  "year": 2015,
  "make": "Honda",
  "model": "Civic",
  "mileage": 145000,
  "question": "Shop quoted me $1,400 for a timing chain. Is that fair?"
}
```

### Function responsibilities

1. **Validate input** — reject if year/make/model/mileage missing or out of sane bounds
2. **Rate limit** — IP-based, e.g. 5 queries per IP per hour. Use Netlify's built-in or Upstash Redis.
3. **Construct system prompt** that frames Claude as the MED advisor with the 4 MED MCP tools available
4. **Construct user message** combining the structured fields + free-text question
5. **Call Anthropic Messages API** with `tools=[...]` matching the MED MCP tool schemas (copy from `SERVER_CARD['tools']` in `server.py`)
6. **Run the agentic loop:**
   - If Claude returns text → return to client
   - If Claude returns `tool_use` → execute the tool locally (read JSON, compute response), send back as `tool_result`, loop
   - Cap at 5 tool calls to prevent runaway loops
7. **Return JSON** with the final response text + token usage + tools called (for analytics)

### Response payload

```json
{
  "ok": true,
  "response_markdown": "Good news and some context worth knowing...",
  "tools_used": ["check_repair_estimate"],
  "input_tokens": 1240,
  "output_tokens": 480,
  "request_id": "req_abc123"
}
```

### Pseudocode

```javascript
import Anthropic from "@anthropic-ai/sdk";
import fs from "fs";
import path from "path";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const TOOLS = [
  // ... copy the 4 tool schemas from SERVER_CARD in server.py, JS-formatted
];

const SYSTEM_PROMPT = `You are MED Vehicle Intelligence — an automotive advisor with 20+ years of shop experience.
Your job is to give straight answers to vehicle owners using the tools available to you.
Voice: direct, no fluff, no hedging, slight humor allowed. Match the tone of a mechanic friend.
When a user asks about their vehicle, use the appropriate tool(s) and synthesize a clear answer.
Always include: a verdict, the reasoning, and what to do next.`;

export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const { year, make, model, mileage, question } = JSON.parse(event.body);

  // Validate
  if (!year || !make || !model || !mileage || !question) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing fields" }) };
  }

  // Rate limit (TODO: implement)

  // Build conversation
  const messages = [{
    role: "user",
    content: `Vehicle: ${year} ${make} ${model} with ${mileage} miles.\n\nQuestion: ${question}`
  }];

  // Agentic loop
  let response;
  let toolsUsed = [];
  for (let i = 0; i < 5; i++) {
    response = await client.messages.create({
      model: "claude-sonnet-4-6",  // or claude-haiku-4-5 for cheaper
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      tools: TOOLS,
      messages: messages
    });

    if (response.stop_reason === "end_turn") {
      break;
    }

    if (response.stop_reason === "tool_use") {
      const toolUseBlocks = response.content.filter(b => b.type === "tool_use");
      messages.push({ role: "assistant", content: response.content });

      const toolResults = await Promise.all(
        toolUseBlocks.map(async (block) => {
          toolsUsed.push(block.name);
          const result = await executeTool(block.name, block.input);
          return {
            type: "tool_result",
            tool_use_id: block.id,
            content: result
          };
        })
      );

      messages.push({ role: "user", content: toolResults });
      continue;
    }

    break;
  }

  const finalText = response.content.find(b => b.type === "text")?.text || "Sorry, I couldn't generate a response.";

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ok: true,
      response_markdown: finalText,
      tools_used: toolsUsed,
      input_tokens: response.usage.input_tokens,
      output_tokens: response.usage.output_tokens
    })
  };
}

async function executeTool(name, input) {
  switch (name) {
    case "check_repair_estimate":
      return require("./tools/check_estimate").run(input);
    case "get_maintenance_schedule":
      return require("./tools/maintenance").run(input);
    case "should_i_fix_or_replace":
      return require("./tools/repair_replace").run(input);
    case "check_shop_red_flags":
      return require("./tools/red_flags").run(input);
    default:
      return "Unknown tool";
  }
}
```

### Tool port — JavaScript versions of Python tools

Each Python tool in `MCP_Server/src/med_vehicle_intelligence/tools/` becomes a JS module. They're thin wrappers — the real intelligence is in the JSON knowledge bases. Example port pattern:

```javascript
// netlify/functions/tools/check_estimate.js
const repairCosts = require("../knowledge_base/repair_costs.json");

function run({ repair_type, vehicle_year, vehicle_make, vehicle_model, quoted_price, shop_type = "independent" }) {
  // Same lookup logic as the Python version
  // Read from repair_costs.json
  // Compute price range
  // Return formatted text response
}

module.exports = { run };
```

The four tools to port: `check_estimate`, `maintenance`, `repair_replace`, `red_flags`. Each is roughly 50-100 lines of JS once knowledge base lookups are wired.

---

## Cost analysis

Per query:
- Anthropic API: ~1,500 input tokens + ~600 output tokens × ~2 round trips
- Sonnet 4.6: ~$0.015 input + ~$0.030 output ≈ **$0.05/query**
- Haiku 4.5: ~$0.001 input + ~$0.005 output ≈ **$0.006/query**

Recommend starting with **Haiku** for cost. Sonnet can be a paid upgrade later for users who want deeper analysis.

At 1,000 queries/day on Haiku: ~$6/day, ~$180/month. Well within MED's stack budget.
At 1,000 queries/day on Sonnet: ~$50/day, ~$1,500/month. Only worth it if those queries convert to advisory bookings.

**Rate limiting is critical** — 5 queries/IP/hour caps abuse and keeps costs predictable.

---

## Implementation phases

### Phase 1 — MVP (4-6 hours)
- [ ] Set up `netlify.toml` with function path config
- [ ] Create `netlify/functions/ask-med.js` with the agentic loop
- [ ] Port the 4 Python tools to JS (knowledge base JSONs are copied verbatim)
- [ ] Build `ask.html` with the form + response card
- [ ] Add `ANTHROPIC_API_KEY` to Netlify env vars
- [ ] Deploy to staging URL
- [ ] Test all 4 demo prompts end-to-end, compare output to MCP server output
- [ ] Add basic IP rate limiting (Netlify Edge Functions or simple in-memory)
- [ ] Push to production at `myeverydaydriver.com/ask`

### Phase 2 — Polish (2-3 hours, day after launch)
- [ ] Add the 4 sample question chips
- [ ] Add markdown rendering on the frontend (marked.js or similar)
- [ ] Add Calendly upsell card on response
- [ ] Add Driver's Survival Guide upsell card on response
- [ ] Add newsletter signup capture below response
- [ ] Add Plausible event tracking (query_submitted, response_returned, calendly_clicked, guide_clicked)

### Phase 3 — Optimization (1-2 hours, week after launch)
- [ ] Add streaming response (Server-Sent Events) for "feels fast" UX
- [ ] Add Sonnet upgrade toggle for power users
- [ ] Add response caching for identical (vehicle + question) inputs to bound costs
- [ ] Add usage dashboard (count queries/day, costs, top tools used)

### Phase 4 — Knowledge base sync (ongoing)
- [ ] Add a CI step that copies `MCP_Server/knowledge_base/*.json` → `MCP_Server/netlify/functions/knowledge_base/*.json` on every commit to main
- [ ] OR symlink at build time via Netlify build script
- [ ] Goal: changes to the knowledge base in one place propagate to both the MCP server and the web demo without manual sync

---

## Open questions for Chris

1. **URL slug:** `/ask`, `/advisor`, `/free-tool`, `/free-mechanic`? Recommend `/ask` for simplicity and SEO.
2. **Model choice for v1:** Haiku (cheap, fast, slightly less nuanced) or Sonnet (more expensive, sharper reasoning)? Recommend Haiku for v1, Sonnet upgrade in v2.
3. **Auth / signup gate:** Do you want users to enter an email before getting a response, or is the response truly free with optional newsletter capture afterward? Recommend free-first, capture afterward — the response IS the lead magnet.
4. **Brand voice match:** The system prompt above mirrors the MED voice you've already locked in. Want me to tune it further once your voice profile is fully extracted? Yes (defer).
5. **Calendly upsell:** Show on every response, or only on high-stakes ones (fix-or-replace, red flags)? Recommend show on every response — it's MED's funnel.
6. **Lead capture for non-buyers:** What's the offer? "Get the next 5 maintenance tips delivered weekly"? Or just newsletter signup?
7. **Response disclaimers:** Need any "this is not professional advice" boilerplate for legal? Recommend a single line in the footer of the response card: "MED Vehicle Intelligence is an educational tool. For complex decisions, talk to a real mechanic — book one with Chris at [link]."

---

## Why this matters

The MCP server is the credibility play — it earns dev respect, gets Smithery placement, generates X/HN buzz, and proves the technology.

**The web demo is the revenue play** — it lets the actual MED audience (drivers who don't know what MCP means) experience the tool, build trust in the brand, and walk down the funnel toward advisory bookings, fleet membership, and the Driver's Survival Guide.

You need both. The MCP server without the web demo is a dev curiosity. The web demo without the MCP server is generic AI. **Together, they're the first complete automotive AI advisory product on the market** — built solo, in a week, by an operator with 20 years of shop experience.

Build it after launch day so launch energy goes into amplification, not new builds. Phase 1 fits in a single 4-6 hour focused session.
