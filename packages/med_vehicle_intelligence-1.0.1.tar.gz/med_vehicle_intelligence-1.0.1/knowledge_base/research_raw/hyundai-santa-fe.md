---
project: med
type: reference
status: draft
date: 2026-04-14
tags: [med, mcp, v2, research-raw, vehicle-profile]
vehicle: Hyundai Santa Fe
generations: "DM (2013-2018), TM (2019-2020); note Sport trim differences"
source: Perplexity research batch 2-5
---

# Hyundai Santa Fe - Research Raw

**Generations in 2010-2020 window:** DM (2013-2018), TM (2019-2020); note Sport trim differences
**Source:** Perplexity research via prompt at 03_PROJECTS/Auto_Project/MCP_Server/2026-04-14__MED__mcp-v2-perplexity-vehicle-research-prompt__REF__v01.md
**Status:** Raw research. Awaits Chris Granola voice layer ('what_chris_would_say') before JSON normalization to vehicle_profiles_schema.json.

---

Hyundai Santa Fe — 3rd Gen DM, 2013–2018
Engines
Santa Fe Sport (2-row, 5-passenger):
2.4L GDI I4 (Theta II) — 190 hp — 6-speed automatic — most common; subject to Theta II engine failure recall
2.0L turbocharged GDI I4 (Theta II) — 264 hp — 6-speed automatic — more powerful option; also subject to Theta II recall
Santa Fe (3-row, 6–7 passenger, "Sport XL" / "Santa Fe" branding):
3.3L V6 (Lambda II) — 290 hp — 6-speed automatic — NOT covered by Theta II recall; separate lambda II failure incidents reported at high mileage (61,000+ miles per owner reports)
Variant-specific notes: The 2.4L and 2.0T Sport models (2013–2014 specifically) are the ones with the most dangerous engine defect — Theta II machining debris causing connecting rod bearing failure, engine seizure, and potential fire. This is the defining issue of this generation. The 3.3L V6 in the full-size Santa Fe is more reliable but not immune to issues. Clarify at purchase: are you buying a Santa Fe Sport (2-row) or Santa Fe (3-row)? They use different engines.
Reliability Rating
Above Average — 4.0 out of 5.0 (ranked 2nd out of 26 midsize SUVs), per RepairPal. Average annual repair cost of $515 vs. segment average of $573. Repair severity of only 10% (vs. 13% segment average) — a strong number on paper. However, this RepairPal rating aggregates all years and does not isolate the catastrophic Theta II engine failures that disproportionately affect 2013–2014 Sport models.
Expected Lifespan (miles)
150,000–200,000 miles for the 3.3L V6 and for Theta II engines that have received the knock sensor software update and had no bearing failure. However, Theta II engines that fail typically do so catastrophically at 60,000–110,000 miles — often with no warning. Engine replacement ($4,800–$7,500) is the only remedy once failure occurs. Engines that survive past 150K with clean oil change history tend to be fine. The extended warranty (15 years/150K miles) from the Hyundai Engine II Settlement materially changes the risk calculation for covered vehicles.
Sweet Spot for Purchase
2016–2018 Santa Fe Sport 2.4L or 2016–2018 Santa Fe 3.3L V6, 40,000–80,000 miles. Post-Theta II recall completion (2013–2014 were the worst), post-KSDS software update period, and with enough years on the extended warranty to still have meaningful coverage remaining.
Best Years
2018 — Only 5 complaints on CarComplaints; DM generation at its most refined; lowest engine failure risk within this gen
2016 — 21 complaints; post-recall period with improved awareness of KSDS update importance; good reliability track record
2017 — 78 complaints — elevated but mostly drivetrain/steering complaints rather than catastrophic engine failure; the KSDS software update had been widely applied by this point
Years to Avoid
2013 — 131 complaints on CarComplaints; engine failure is the #1 complaint (300 NHTSA engine complaints per CarComplaints 2013 data); average engine failure repair cost $3,600 at 90,000 miles; average "violent jerking on acceleration" (pre-seizure symptom) $10,000 at 57,000 miles
2014 — 74 complaints; engine failure still the dominant problem ($7,500 avg at 61,000 miles per CarComplaints); covered under safety recall but check VIN for completion
Common Problems (top 3–5)
Problem 1: Theta II Engine Failure (Connecting Rod Bearing) — 2013–2014 Sport
Severity: Catastrophic — sudden engine seizure; potential fire
Affected years: 2013 Santa Fe Sport (all 2.4L and 2.0T); certain 2014 Santa Fe Sport (2.4L and 2.0T manufactured through September 12, 2014 at Kia Motor Manufacturing Georgia)
Typical mileage onset: 60,000–110,000 miles (earlier in hard-driven or oil-neglected examples); "violent jerking on acceleration" averages 57,000 miles onset per CarComplaints
Symptoms: Engine knock or metallic ticking (may be brief or absent before failure); sudden loss of power; engine seizure; vehicle stalls at speed; check engine light (code P1326 — knock sensor detection); potential engine fire
Repair options: Engine replacement — covered under Hyundai safety recall (inspect and replace if defective) and extended warranty from class action settlements. Out-of-warranty cost: $4,800–$7,500 per CarComplaints. The Hyundai Theta Settlement (for 2013–2014 Santa Fe Sport with 2.0L/2.4L Theta II GDI) extends powertrain warranty to lifetime for original owners who completed the KSDS software update. The Engine II Settlement extends warranty to 15 years/150,000 miles for 2010–2012 Santa Fe with Theta II 2.4L MPI
Owner action: Verify KSDS (Knock Sensor Detection System) software update was completed before buying any 2013–2014 Santa Fe Sport — without it, the extended warranty is voided. Check VIN at autoservice.hyundaiusa.com/campaign162 for recall status. Change oil every 5,000 miles strictly — Theta II engines are oil-change sensitive. Any engine knock at purchase is a deal-breaker
NHTSA complaint count: 300 NHTSA engine complaints for 2013 alone per CarComplaints 2013 data
TSB/recall: Hyundai Safety Recall Campaign 162 (inspect and replace engine); KSDS software update campaign 953; class action settlements covering Theta II GDI engines 2011–2019
Problem 2: Crankshaft Position Sensor Failure
Severity: Moderate–High (can cause stall without warning)
Affected years: 2013–2018 (all DM generation)
Typical mileage onset: 60,000–120,000 miles
Symptoms: Random stall; vehicle won't start; cranks but no start; intermittent no-start in certain temperatures. Per 1A Auto guide for 2013–2018 Santa Fe
Repair options: Crankshaft position sensor replacement $150–$400 (sensor is buried behind engine; labor-intensive — 2–4 hours). DIY cost ~$40–$80 for part
Owner action: Pull codes with an OBD-II scanner before purchase; P0335 indicates CPS issue. Test drive specifically includes sitting at idle and then acceleration to check for stall tendency
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: None specific
Problem 3: Turbocharger Boost Control Actuator Failure (2.0T Sport)
Severity: Moderate
Affected years: 2013–2018 Santa Fe Sport 2.0T
Typical mileage onset: 60,000–100,000 miles
Symptoms: Reduced engine power; sluggish acceleration; Check Engine light with code P2562; wastegate rod may be frozen open
Repair options: Actuator replacement $300–$700 (independent) to $600–$1,200 (dealer); if wastegate is seized on the turbo body, turbo replacement $1,200–$2,500
Owner action: On any 2.0T, verify turbo function during test drive — floor it briefly in second gear and feel for full boost. Check for P2562 with OBD scanner. Confirm oil was changed every 5,000 miles; turbo failure accelerates with sludge
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: None specific
Problem 4: Front Hub Bearing Assembly Failure
Severity: Moderate
Affected years: 2013–2018 (all DM)
Typical mileage onset: 60,000–100,000 miles
Symptoms: Grinding or "helicopter" noise from front wheels; noise pitch changes when steering wheel is turned; wheel play on inspection
Repair options: Hub bearing assembly replacement $300–$600 per side (independent); $500–$900 dealer
Owner action: During test drive, listen for grinding noise and vary steering input — noise that changes pitch indicates the specific failed side. Grab each wheel at 12 and 6 o'clock positions and check for play with wheels off ground at inspection
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: None specific
Maintenance Schedule Highlights
Engine oil/filter — every 5,000 miles strictly — Hyundai-spec 5W-20 (2.4L) or 5W-30 (2.0T, 3.3L V6) synthetic; Theta II engines are extremely sensitive to oil neglect; skip this and risk recall coverage voiding
KSDS knock sensor software update — complete before any engine warranty claim; required for extended warranty coverage
Transmission fluid — every 30,000–60,000 miles — Hyundai SP-IV ATF
Spark plugs — every 60,000 miles (Iridium)
Coolant — every 60,000 miles (Hyundai Blue Coolant)
Air filter — every 15,000–30,000 miles
Brake fluid — every 2–3 years
Typical Annual Ownership Cost
Insurance: $1,200–$1,800 (mid-size SUV averages; Hyundai products typically below segment average for insurance cost)
Fuel (15K mi/yr): $1,800–$2,200 (2.4L EPA 20/27 combined ~23 mpg; 2.0T EPA 19/25 ~22 mpg; 3.3L V6 EPA 18/25 ~21 mpg; at $3.50/gal)
Maintenance: $515/yr average per RepairPal; budget $700–$900/yr with transmission fluid, air filter, and brake fluid included
Depreciation
The Santa Fe DM depreciates at or slightly below segment average. The Theta II engine scandal has pushed 2013–2014 Sport values lower than they'd otherwise be — even with the recall and extended warranty, buyers are wary. A 2013 Santa Fe Sport 2.4L that originally sold for $28,000 may now bring only $6,000–$9,000 at 90,000 miles — steep, and partially justified by the engine risk. The 2016–2018 years hold value better given their clean complaint records. The extended warranty (lifetime for original owners who got the KSDS update, or 15 years/150K for transferable cases) adds real value to properly-documented examples — factor this into price negotiations.
Sources
RepairPal Santa Fe reliability: https://repairpal.com/reliability/hyundai/santa-fe
CarComplaints Santa Fe overview: https://www.carcomplaints.com/Hyundai/Santa_Fe/
CarComplaints 2013 Santa Fe: https://www.carcomplaints.com/Hyundai/Santa_Fe/2013/
Hyundai recall campaign 162: https://autoservice.hyundaiusa.com/campaign162
Hyundai Theta Settlement (lifetime warranty): https://www.hma-thetasettlement.com
Hyundai Engine II Settlement (15yr/150K warranty): https://www.hma-e2settlement.com
1A Auto / YouTube — Top 5 Problems 2013–18 Santa Fe: https://www.youtube.com/watch?v=F2tU2Zsuaxc
HotCars — Theta II engine recall explained: https://www.hotcars.com/hyundais-5-billion-engine-recall-nightmare-explained/
NHTSA recalls lookup: https://www.nhtsa.gov/recalls
