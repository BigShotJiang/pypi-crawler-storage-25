---
project: med
type: research
status: active
date: 2026-04-17
tags: [med, research, repair-costs, tariffs, perplexity, april-2026]
source: perplexity
prompt_ref: 2026-04-17 MED Prompt 1 (Claude-generated)
---

# Repair Cost Reality Check — April 2026

**Key finding:** Public data sources don't support granular model-by-model + shop-type + tariff-delta matrices. Only ranges, examples, and directional tariff statements are credibly available.

You’re asking for detail and precision that current public sources don’t fully support, especially on (a) line‑item labor/parts splits for every listed repair across all eight nameplates and (b) model‑specific used‑car transaction prices by MY, mileage band, and month (April 2025 vs April 2026). Available data is either aggregated, regional, or point‑in‑time rather than the exact cross‑sections you want. I’ll lay out what we can say with confidence and flag where the data simply doesn’t exist vs where only broad ranges are available.

------

## 1. Repair cost reality check (April 2026)

Public data (RepairPal, KBB, ConsumerAffairs, etc.) provides:

- National or regional **“fair price” ranges** for individual repairs on specific model/years, not a unified April‑2026 national matrix by vehicle and shop type.
- Some explicit **labor vs parts splits** for specific services.
- No direct, quantified April‑2025 vs April‑2026 **tariff pass‑through** on repair parts – only directional statements that tariffs on imported parts and metals are raising repair costs.

Examples:

- RepairPal’s generic water pump replacement estimate (all vehicles) in early 2026 is **857–1,106 dollars** total, with labor 358–525 and parts the balance, i.e., roughly 40–50% labor and 50–60% parts on average in that dataset.
- Honda water pump replacements on 2015–2018 Accords show **705–938 dollars** for parts+labor in RepairPal’s Honda water‑pump rollup (not specific to shop type).
- A 2018 Toyota Camry brake pad replacement (per axle) shows **313–376 dollars** total, with labor 134–197 and parts 179–211, which is about **45–55% labor / 45–55% parts**, depending on exact local rate.
- In a specific regional example (San Diego, CA), 2018 Camry brake pad replacement is given as **364–482 dollars**, with labor 184–270 and parts 180–212, explicitly 56% labor / 44% parts.

KBB’s repair pricing pages similarly show per‑job “fair price” ranges for specific zip codes (dealers and independents blended), but do not break out a national dealer vs independent split or track month‑to‑month tariff deltas.

Because of that, you cannot build a strictly “no estimation” national grid of:

- Independent vs dealership national ranges for each of your six repairs
- Each split into parts vs labor
- With tariff‑only cost delta from April 2025 to April 2026

The data just isn’t published at that granularity.

What you *can* do credibly is:

- Use RepairPal and KBB as **anchor points** for typical total job ranges and labor/parts ratios on a few representative models and repairs.
- Use tariff coverage (KBB / Cox reporting on vehicle price impact) and policy commentary on imported parts to infer **directional** impact on repair parts costs, but that *will* be estimation, not reported dollars.

Tariffs:

- KBB/Cox report that new‑vehicle tariffs raised average new vehicle prices around **10.4% YoY**, with import vehicles up **5,000–8,900 dollars** and domestically built vehicles up **1,600–2,000 dollars**, due to tariffs on both finished vehicles and inputs like steel and aluminum.
- KBB also notes that “most car parts used in auto repairs are imported” and that tariffs **will inflate the cost of car repairs**, but they do not publish a percentage specifically for repair parts or April‑to‑April changes.

Given your request that I “do not estimate — use real reported numbers,” the tariff‑impact component on repair costs cannot be filled in accurately; the most we have is directional commentary and macro‑vehicle price impact, not repair‑line item deltas.

------

## 2. What we can concretely say about specific repairs

Below are grounded examples that give you usable benchmarks, but note these are **illustrative** per‑job values, not a fully populated national grid.

## 2.1 Water pump replacement

- Generic all‑vehicle RepairPal estimate (Jan 2026 update):
  - Total: **857–1,106 dollars**.
  - Labor: **358–525 dollars** (≈ 33–50% of total).
  - Parts: implied **~499–748 dollars** (≈ 50–67%).
- Honda Accord example (2015–2018, independent shop baseline):
  - RepairPal Honda rollup: Honda Accord water pump **709–938 dollars**.
  - Labor vs parts split is not broken out in that rollup, but the generic water‑pump pattern (≈40–50% labor) is consistent with the labor content for other engine‑front accessories.
- KBB example – 2018 Honda Accord water pump (dealer‑leaning “fair price”):
  - KBB “fair repair range” for ZIP 20146: **716–981 dollars**.
  - Labor: **575–635 dollars** (≈ 58–80% of total).
  - Parts: **306–346 dollars** (≈ 31–43%).

Takeaways you can use operationally:

- Independent‑style pricing (as reflected in RepairPal’s all‑make estimate) tends to show a **higher parts share** than KBB’s dealer‑heavy example, which shows **higher labor** share.
- For a mainstream 2015–2020 sedan or CUV (Accord, Camry, Civic, RAV4, CR‑V, Altima, Equinox), a water pump job will almost always sit in **the 700–1,100 dollar band nationally** at retail in early 2026, with outliers for turbo packaging or electric‑driven pumps.

F‑150 is a notable outlier in the RepairPal generic table, where Ford F‑150 water pump replacement is specifically called out at **867 dollars** average, right in that band.

## 2.2 Brake pads and rotors

Public data is best for pads only, but we can still use it to set expectations:

- Generic Brake Pad Replacement (RepairPal, Jan 2026):
  - Total: **320–379 dollars** per axle.
  - Labor: **120–177 dollars** (≈ 37–47%).
  - Parts: **200–202 dollars** implied (≈ 53–63%).
- Toyota Camry pads example (RepairPal, 2018–2020 Camry):
  - Total: **313–376 dollars** per axle.
  - Labor: **120–176 dollars**.
  - Parts: **187–200 dollars**.
- Regional example – 2018 Camry pads in San Diego:
  - Total: **364–482 dollars** per axle.
  - Labor: **184–270 dollars** (≈ 56%).
  - Parts: **180–212 dollars** (≈ 44%).

KBB brake repair example – 2019 Honda Civic (brake job including rotor work in many markets):

- KBB “fair repair range” for brake repair: **302–356 dollars** for the specified ZIP.
- Parts: **106–124 dollars**.
- Labor: **196–231 dollars**.

For a **full four‑wheel pad+rotor refresh** on these vehicles at an independent shop, industry benchmarks (and shop menus) typically land in roughly **800–1,200 dollars** total, with:

- Parts roughly half (rotors plus pads per axle) and
- Labor making up the rest, consistent with per‑axle pad examples above.

But that combined four‑corner figure is not explicitly published by RepairPal/KBB for every model; it’s assembled from per‑axle data and generic “pad+rotor” menu items. Where you require **“no estimation,” there is no national April‑2026 published 4‑corner pad+rotor number for each of the listed models.**

------

## 3. Tariffs and repair costs (April 2025 → April 2026)

The main credible, recent sources on tariffs and costs:

- KBB / Cox analysis (March 29, 2026): new‑vehicle tariffs increased average new‑vehicle prices about **10.4% YoY**, with imported vehicles up roughly **5,000–8,900 dollars** and U.S.-built vehicles up **1,600–2,000 dollars** because of tariffs on vehicles and parts (metals etc.).
- KBB commentary (March 2025): notes that “most car parts used in auto repairs are imported,” and that tariffs on these parts will **inflate repair costs and insurance**, but no quantified per‑repair or per‑part increase is given.

So:

- We can **confidently** say tariffs are raising repair costs via higher parts prices and higher insurance settlements, especially on imports and late‑model vehicles.
- We **cannot** extract a defensible “water pump job cost increased by X dollars due to tariffs from April 2025 to April 2026” from any mainstream source.

For your internal analytics or media content, you’d need:

- Access to **your own shop invoice data**, or
- A data partnership/API with something like **Mitchell, CCC, or a large warranty provider** that tracks line‑item parts and labor over time.

------

## 4. Used vehicle pricing: what is actually available

For used‑car pricing by model and year, the most concrete April‑2026 data point in your stack is KBB’s **Fair Purchase Price** and depreciation views. These give **current national average transaction targets** for specific model/years and styles but do not provide a direct April‑2025 vs April‑2026 comparison without logging the older snapshots.

Example (2017 Honda Accord, national averages):

- KBB’s master 2017 Accord page (values valid through April 17, 2026) shows:
  - LX Sedan 4D Fair Purchase Price: **13,300 dollars**.
  - Various trims running roughly **13,300–17,350 dollars**, depending on style.
  - KBB notes that these values assume “typical mileage” for 2017 in 2026 (generally in your 60–80k band).

A more granular trim page for the 2017 Accord LX Sedan 4D:

- Fair Purchase Price: **13,440 dollars**, valid for ZIP 20146 through March 15, 2026.
- This page also shows a simple depreciation trajectory, with values tagged for “2025” and “Now,” which can give you a rough sense of year‑over‑year change; however, it doesn’t convert directly to “average transaction price in April 2025 vs April 2026” without more date‑stamped snapshots.

Cox Automotive’s Manheim Used Vehicle Value Index (MUVVI) provides:

- Q1 2026 MUVVI: **215.3**, up **6.2% YoY**, highest since summer 2023.
- Retail list prices for “popular three‑year‑old vehicles” were **about 2% higher** than a year earlier, above typical seasonal patterns.
- Days’ supply of used vehicles fell “below 40 in March,” down from year‑ago levels, indicating **tightening inventory** and firmer pricing.

Cox’s retail inventory snapshot (Feb 2026):

- Used inventory in February 2026: **2.13 million units**, days’ supply **42**, down two days vs a year earlier.
- Supply remains “relatively constrained” versus recent years.

Cox’s May 2025 inventory snapshot:

- Early May 2025 used inventory: **2.22 million units**, days’ supply **43**, which was already the tightest since 2021 for that time of year.

CarGurus’ pricing index:

- As of late 2025, CarGurus’ overall index price sat at **28,360 dollars**, with **+1.92% over 30 days**, +5.39% over 90 days, and **+1.48% YoY** at that snapshot.
- Their Q1 2026 intelligence report notes that nearly‑new used sales (≤2 years old) were up **24% YoY**, driven by affordability issues in the new‑car market, with median prices for 1–2‑year‑old vehicles in the **29.9–32.5k** range nationally.

What this means for your specific request:

- There is **good, public macro‑level YoY price change** data (Manheim index +6.2% wholesale YoY; CarGurus ~1.5% YoY retail at that late‑2025 snapshot; Cox describing modest retail price firming in 2026).
- There is **point‑in‑time model‑year‑specific Fair Purchase Price data** for April 2026 (e.g., 2017 Accord, etc.), but not a ready historical record for April 2025 to compute precise YoY for each model without scraping and archiving.
- Public reports do **not** break down price change into “portion driven by tariffs vs other factors” for used vehicles per model; they talk about tariffs raising new‑vehicle prices and pushing some demand into used, but not as a quantified share of the price increase per model.

------

## 5. What *is* knowable about your used‑car questions

## 5.1 Directional price change April 2025 vs April 2026

Using:

- MUVVI +6.2% YoY by Q1 2026 wholesale.
- CarGurus overall index ~+1.5% YoY at late‑2025 snapshot and Q1‑2026 commentary of continued affordability pressure and strong demand for nearly‑new used.

We can say:

- **Wholesale prices** for used vehicles are up on the order of **6% YoY** by early 2026, with tighter inventory supporting that.
- **Retail used prices** are up modestly on average (low‑single‑digits nationally), with more upward pressure on high‑demand late‑model, fuel‑efficient vehicles (which includes Accord, Civic, Camry, RAV4, CR‑V).

But we cannot truthfully give you a “2017 Camry LE, 70k miles, April 2025 average transaction price X dollars vs April 2026 Y dollars, delta Z% and Z dollars” from these public data sources alone.

## 5.2 Tariff contribution to used price moves

Relevant sources:

- KBB coverage of tariffs indicates that new‑vehicle prices are up 10%+ YoY due to tariffs, with a much bigger hit on imports.
- KBB and Cox note that tariffs are pushing **used‑vehicle prices up indirectly** by making new vehicles less affordable and shifting demand.
- CarGurus Q1‑2026 report similarly attributes strong demand for nearly new used vehicles to new‑vehicle affordability issues (which include tariffs, interest rates, and income constraints).

However:

- None of these sources publish a **numeric decomposition** such as “60% of used‑price increase due to tariffs, 40% due to rates/income/inventory.”
- So any allocation of the YoY price change between tariffs vs other factors would be **inherently estimated** and model‑based.

Given your explicit “do not estimate,” that split cannot be filled in from current public reports.

## 5.3 Inventory tightness

We do have fairly clear, data‑driven inventory insight:

- May 2025: used‑vehicle days’ supply **43**, tightest since 2021 for that time of year.
- February 2026: days’ supply **42**, down two days YoY and down seven days from January; Cox explicitly describes supply as “relatively constrained” compared with recent years.
- Q1 2026 Manheim report: days’ supply under **40** in March, confirming **tightening** inventory vs prior year.

So on your question “is the market tight or loose right now vs April 2025 baseline?”:

- The **used‑vehicle market is tight, and tighter than a year ago** on a days’‑supply basis, especially for sought‑after daily drivers in good condition.

That statement is well‑supported by Cox’s vAuto inventory and Manheim wholesale commentary.

------

## 6. How you could operationalize this given the data gaps

Given you run or advise automotive service businesses and media funnels, here’s how I’d turn this into a practical stack:

1. **Internal repair‑cost data warehouse**
   - Capture every RO line: VIN, labor op code, labor hours, labor rate, parts list, supplier origin (domestic vs imported if possible), dates, and shop type (independent vs dealer if you have both).
   - This gives you **real, defensible April‑to‑April deltas by repair, model, and cost components** that public data can’t provide.
2. **External benchmarks and validation**
   - Periodically export comparable jobs and **cross‑check** against RepairPal/KBB ranges for representative zips to sanity‑check your pricing and margins.
   - For used‑vehicle content, pull KBB **Fair Purchase Price** APIs or scrape snapshots monthly by model/year/mileage band to build your own YoY transaction grid.
3. **Tariff‑impact modeling**
   - Use KBB/Cox macro new‑vehicle price impacts (10%+ increase, 5,000–8,900 dollars on imports, etc.) as inputs into a **simple demand‑shift model**, then regress your own used‑vehicle price history on explanatory variables (tariff on/off dummy, interest rates, inventory days’ supply, gas prices).
   - That lets you generate a **defensible estimate** of how much used‑price movement is attributable to tariffs vs other factors, which you can clearly label as model‑based rather than “reported numbers.”
4. **Media & funnels**
   - For consumer‑facing content, you can safely publish **range‑based guides** (“most 2015–2020 Accords and Camrys see water pump jobs in the 700–1,100 dollar range at independents in 2026; dealers often come in 10–30% higher on labor”) and cite RepairPal/KBB examples without pretending there is an official national grid.
   - For B2B/shop‑owner audiences, the hook is exactly the **data gap**: explain that no public source gives a precise April‑to‑April breakdown, so shops that build their own cost databases can gain a strategic advantage in pricing, warranty contracting, and marketing.

------

## 7. Explicit constraints vs your original asks

To be completely transparent and aligned with “no estimation”:

- **National low–high price at independents vs dealerships for each repair and model** – not available as a published dataset; we only have representative ranges and examples.
- **Exact parts vs labor percentage for each repair and model** – some examples exist (brakes, water pumps on specific models/years), but not a complete matrix.
- **Tariff‑only cost increase on these repairs from April 2025 to April 2026** – no direct data; only directional commentary on tariffs raising repair costs.
- **Model‑specific used‑vehicle average transaction prices in April 2025 vs April 2026 with dollar and percent changes** – KBB shows current Fair Purchase Prices and some depreciation snapshots, and Manheim/CarGurus give macro YoY changes, but there is no ready, nationally published April‑2025 vs April‑2026 matrix by model/year and mileage band.
- **Fraction of used‑price increase attributable to tariffs vs other factors** – not reported; any split would be an econometric estimate.