---
project: med
type: reference
status: draft
date: 2026-04-14
tags: [med, mcp, v2, research-raw, vehicle-profile]
vehicle: Ford Escape
generations: "3rd gen (2013-2019), 4th gen (2020)"
source: Perplexity research batch 2-5
---

# Ford Escape - Research Raw

**Generations in 2010-2020 window:** 3rd gen (2013-2019), 4th gen (2020)
**Source:** Perplexity research via prompt at 03_PROJECTS/Auto_Project/MCP_Server/2026-04-14__MED__mcp-v2-perplexity-vehicle-research-prompt__REF__v01.md
**Status:** Raw research. Awaits Chris Granola voice layer ('what_chris_would_say') before JSON normalization to vehicle_profiles_schema.json.

---

Ford Escape — 3rd Gen C520, 2013–2019
Engines
1.6L EcoBoost I4 (turbocharged) — 178 hp — 6-speed PowerShift or 6-speed SelectShift automatic — base turbo option 2013–2016; subject to coolant system fire risk recall (13V583) and chronic head gasket/cylinder head cracking issues; avoid
2.0L EcoBoost I4 (turbocharged) — 240 hp — 6-speed SelectShift automatic — available throughout; more power but EcoBoost coolant intrusion risk; revised in 2015 with Mazda partnership ended; 2015+ 2.0L is better but not immune
2.5L naturally aspirated I4 (Duratec) — 168 hp — 6-speed SelectShift automatic — no turbo, no EcoBoost, no coolant drama; significantly more reliable; the only engine worth buying in this generation
1.5L EcoBoost I4 (turbocharged) — 179 hp — 6-speed automatic — replaced 1.6L for 2017–2019; still has EcoBoost coolant intrusion risk (TSB MC-10168739); avoid if possible
Variant-specific notes: This is straightforward: buy the 2.5L naturally aspirated engine if you want peace of mind. Every EcoBoost engine in this generation carries some coolant intrusion, head gasket, or cylinder head cracking risk. The 1.6L is the worst offender and generated multiple NHTSA recalls and a class action lawsuit. The 2.5L S FWD trim is the most reliable Escape in this generation. See Samarins.com analysis.
Reliability Rating
Above Average — 4.0 out of 5.0 (ranked 16th out of 26 compact SUVs), per RepairPal. Average annual repair cost of $600 vs. compact SUV average of $521 — somewhat above average for the class. This rating reflects all trim levels; EcoBoost variants reliably underperform the 2.5L in practice. Consumer Reports rated the 2013 and 2017–2019 Escape below average for reliability, while the 2015 Escape earned above average per Samarins.com.
Expected Lifespan (miles)
150,000–200,000 miles for the 2.5L naturally aspirated engine — a straightforward, well-proven unit. EcoBoost variants: 100,000–160,000 miles is more realistic without engine replacement; coolant intrusion can destroy the short block at any mileage if unaddressed. The class action lawsuit (fordecoboostlawsuit.com) covering 2013–2019 Escape with 1.5L, 1.6L, or 2.0L EcoBoost engines cites ongoing coolant leakage into cylinders as a fundamental defect.
Sweet Spot for Purchase
2015–2016 Escape with 2.5L engine, 50,000–90,000 miles. Consumer Reports rates 2015 above average; 1.6L production mostly ended; 2.5L available throughout; mid-generation quality improvements in place; better than the 2013–2014 launch years. If you must have EcoBoost, the 2015–2016 1.6L is the better of the 1.6L years.
Best Years
2015 — Consumer Reports above-average reliability rating; 147 complaints on CarComplaints vs. 477 for 2013; 1.6L coolant recall fixes largely implemented
2016 — 185 complaints; improved SYNC infotainment; post-1.6L-recall refinements; 2.5L availability throughout
2019 — 31 complaints on CarComplaints; final year of this generation; most bugs sorted but 1.5L EcoBoost coolant issue (TSB MC-10168739) documented
Years to Avoid
2013 — 477 complaints on CarComplaints — worst launch year; 1,485 NHTSA engine complaints alone per CarComplaints 2013 data; multiple coolant/fire-risk recalls issued in the first year; transmission failure #1 complaint ($4,400 avg at 77K miles); power steering failure #2 ($1,500 avg at 64K miles)
2014 — 349 complaints; worst CarComplaints.com year by their weighting (higher repair cost, lower mileage at onset); transmission failure continues; rated below average by Consumer Reports
Common Problems (top 3–5)
Problem 1: 1.6L EcoBoost Coolant Loss / Cylinder Head Cracking / Engine Fire Risk
Severity: Critical — linked to engine fires; subject to multiple federal recalls
Affected years: 2013–2016 with 1.6L EcoBoost
Typical mileage onset: Variable — some failures occur at 30,000–50,000 miles; some at 70,000+. 2013 engine complaints average 51,000 miles onset per CarComplaints
Symptoms: Unexplained coolant loss (check reservoir shrinking between checks); white smoke from exhaust; overheating warning; check engine light with misfire codes (P0300–P0304, P0316, P0217, P1285, P1299); rough running; in severe cases, engine oil shows bubbles or milky appearance; engine compartment fire
Repair options:
NHTSA Recall 12V336 (fuel line splitting — fire risk): Free dealer repair; must be completed
NHTSA Recall 12V431 (cylinder head freeze plug dislodging — coolant loss/fire): Free secondary plug installation
NHTSA Recall 13V583/Safety Recall 13S12 (cylinder head cracking, oil leak, fire risk): Multiple procedures — thermostat, shields, cooling system overhaul; free for 2013 models equipped with 1.6L
Post-recall head gasket/short block failure: $3,000–$6,000 independent; $4,000–$8,000 dealer
Class action lawsuit (fordecoboostlawsuit.com) covers 2013–2019 Escape with 1.6L engines
Owner action: Check NHTSA recall status for every 1.6L EcoBoost Escape before purchase. All three recalls above should be confirmed complete. Then do your own cooling system pressure test. If coolant level is below minimum or has been topped off repeatedly, walk away. The 1.6L's cooling system requires the Ford-spec orange coolant (VC-7-B) and specific degas bottle components — shops that use generic coolant accelerate failure. Ford recall documentation
NHTSA complaint count: 1,485 NHTSA engine complaints for 2013 Escape alone per CarComplaints 2013 data
TSB/recall: Recall 12V336, 12V431, 13V583 (13S12); additional TSBs for 1.5L coolant (TSB MC-10168739 for 2017–2019)
Problem 2: 1.5L EcoBoost Coolant Intrusion / Head Gasket — 2017–2019
Severity: High
Affected years: 2017–2019 Escape with 1.5L EcoBoost (built before April 6, 2019)
Typical mileage onset: 40,000–100,000 miles
Symptoms: Low coolant warning; white exhaust smoke; rough running; misfires; codes P0300, P0301–P0304, P0316, P0217, P1285, P1299 per NHTSA TSB MC-10168739
Repair options: Short block replacement with head gasket — TSB procedure: 19.7–21.2 labor hours per NHTSA TSB; $3,000–$6,000 total cost at independent shop; class action coverage may apply
Owner action: Pull codes before buying any 2017–2019 1.5L Escape. Check coolant level and exhaust for white smoke at startup. The class action at fordecoboostlawsuit.com covers these engines — check for coverage
NHTSA complaint count: 643 NHTSA complaints total for 2019 Escape per VinItel data; engine is the top problem category
TSB/recall: TSB MC-10168739 (short block/head gasket replacement procedure); class action filed
Problem 3: Transmission Failure — 2013–2014
Severity: High
Affected years: 2013–2014 primary; some 2015
Typical mileage onset: 77,000–84,000 miles average per CarComplaints data; worst year is 2014 (stopped working at avg $4,200 repair at 84K miles per CarComplaints overview)
Symptoms: Transmission slipping; refusal to shift; complete failure to engage drive
Repair options: Transmission rebuild $2,500–$4,500 independent; replacement $3,500–$5,500
Owner action: Test all gears during test drive. Watch for any hesitation between 1st–2nd gear. Inspect transmission fluid color (should be pink/red, not brown/black). Verify transmission fluid has been serviced at least once
NHTSA complaint count: 11 NHTSA transmission complaints per CarComplaints 2013 data; broader transmission failure tied to engine-related heat damage in many cases
TSB/recall: No specific transmission recall; multiple transmission-related TSBs
Problem 4: Electric Power Steering Failure — 2013–2015
Severity: High (safety)
Affected years: 2013–2015
Typical mileage onset: 64,000 miles average per CarComplaints 2013 data (#2 worst problem, $1,500 avg repair)
Symptoms: Sudden loss of power steering assist; heavy steering; warning light; may accompany stall event
Repair options: EPS module replacement $800–$1,500; steering rack replacement $1,200–$2,000 in severe cases
Owner action: During test drive, test steering at low speed and at highway speed. Any "clunk" or intermittent resistance is a red flag. Check for steering-related TSBs and recall completions
NHTSA complaint count: 301 NHTSA steering complaints for 2013 Escape per CarComplaints 2013 data
TSB/recall: Check nhtsa.gov/recalls for VIN-specific steering recalls
Maintenance Schedule Highlights
Engine oil/filter — every 5,000–7,500 miles — 5W-20 or 5W-30 per Ford spec; EcoBoost engines should use 5,000-mile intervals to manage heat and carbon buildup
Coolant check — every oil change on EcoBoost engines; use Ford-spec VC-7-B orange coolant only; never mix with green conventional
Transmission fluid — every 30,000–60,000 miles — Mercon LV (PowerShift DCT uses a different fluid — service every 20,000 miles)
Spark plugs — every 60,000 miles (EcoBoost); 100,000 miles (2.5L)
Timing belt (EcoBoost engines) — 150,000 miles per Ford spec (unusually long; many mechanics recommend 100K)
Air filter — every 15,000–30,000 miles
Brake fluid — every 2–3 years
Typical Annual Ownership Cost
Insurance: $1,200–$1,800 (compact SUV segment; Escape below mid-size average due to smaller vehicle)
Fuel (15K mi/yr): $1,800–$2,400 (2.5L EPA 21/28 combined ~24 mpg; 1.6L EcoBoost EPA 22/30 ~25 mpg; 2.0L EcoBoost EPA 20/28 ~23 mpg; at $3.50/gal; 2.5L at 24 mpg = ~$2,188)
Maintenance: $600/yr average per RepairPal; budget $700–$1,000/yr including cooling system vigilance on EcoBoost variants
Depreciation
The 3rd-gen Escape depreciates at or above the compact SUV segment average, hurt by the high volume of EcoBoost complaints and Ford's broader used-market reputation. A 2013 Escape SE 1.6L EcoBoost that originally sold for $26,000 may now trade for $5,000–$8,000 at 90,000–110,000 miles — steep and largely deserved given the engine issues. The 2.5L variants hold value better within the lineup because informed buyers seek them out. The Explorer and Escape both show faster-than-average depreciation compared to Honda or Toyota equivalents. For the used buyer, this means lower entry price but higher ongoing risk — especially on EcoBoost examples without documented recall completion and coolant system maintenance.
Sources
RepairPal Escape reliability: https://repairpal.com/reliability/ford/escape
CarComplaints Escape overview: https://www.carcomplaints.com/Ford/Escape/
CarComplaints 2013 Escape: https://www.carcomplaints.com/Ford/Escape/2013/
Ford recall details for 2013 Escape: https://www.ford.com/support/recalls-details/escape/2013/
NHTSA Safety Recall 13S12 / 13V583 PDF: https://static.nhtsa.gov/odi/rcl/2013/RCRIT-13V583-6837.pdf
NHTSA TSB MC-10168739 (1.5L EcoBoost coolant): https://static.nhtsa.gov/odi/tsbs/2019/MC-10168739-0001.pdf
Ford EcoBoost class action lawsuit site: https://www.fordecoboostlawsuit.com
Samarins.com 2013–2019 Escape analysis: https://www.samarins.com/reviews/escape-2019.html
VinItel 2019 Escape complaints: https://vinitel.com/stats/nhtsa-complaints/ford/escape/2019
NHTSA recalls lookup: https://www.nhtsa.gov/recalls
