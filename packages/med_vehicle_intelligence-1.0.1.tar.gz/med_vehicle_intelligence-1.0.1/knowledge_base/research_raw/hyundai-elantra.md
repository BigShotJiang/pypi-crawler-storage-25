---
project: med
type: reference
status: draft
date: 2026-04-14
tags: [med, mcp, v2, research-raw, vehicle-profile]
vehicle: Hyundai Elantra
generations: "MD (2011-2016), AD (2017-2020)"
source: Perplexity research batch 2-5
---

# Hyundai Elantra - Research Raw

**Generations in 2010-2020 window:** MD (2011-2016), AD (2017-2020)
**Source:** Perplexity research via prompt at 03_PROJECTS/Auto_Project/MCP_Server/2026-04-14__MED__mcp-v2-perplexity-vehicle-research-prompt__REF__v01.md
**Status:** Raw research. Awaits Chris Granola voice layer ('what_chris_would_say') before JSON normalization to vehicle_profiles_schema.json.

---

Hyundai Elantra — 5th Generation, 2011–2016 (MD)
Engines

The 2016 Sport and GT trims used the 2.0L GDI. The base 1.8L is a conventional port-injected engine. Both are interference engines — timing chain failure is catastrophic (1A Auto top 5 problems).
Reliability Rating
Above Average — 4.5 out of 5.0; ranked 8th out of 36 compact cars (RepairPal). Average annual repair cost: $452, the lowest among all compact cars reviewed. Severity of repairs is only 9%, below the 11% compact-car average. This is a genuinely reliable car in most years — the 2013 is the main exception.
Expected Lifespan (miles)
200,000+ miles with proper maintenance. The transmission (manual or automatic) is not a weak point in this generation. Engine longevity is solid when oil is maintained; many 2011–2012 owners report 180,000–250,000 miles without major engine work. The timing chain is a concern if oil changes are neglected — the chain can jump at high mileage, causing severe internal damage.
Sweet Spot for Purchase
2014–2016, 60,000–100,000 miles. The 2013 has the worst complaint record; 2014 onward shows a steep drop in issues (98 complaints vs. 565 for 2013). The 2014–2016 cars offer a more refined interior and better reliability track record while still being affordable.
Best Years
2016 — Only 60 CarComplaints complaints; fewest issues of the generation; exterior and interior refinements; 2.0L Sport trim available (CarComplaints Elantra overview)
2015 — 83 complaints; significant improvement over 2013–2014; good build quality; all major recalls addressed
Years to Avoid
2013 — CarComplaints worst model year; 565 complaints (10x the 2016 level); engine ticking, stalling, MPG failures, brake grinding; "Avoid Like the Plague" context (CarComplaints 2013 Elantra)
2011 — Consumer Reports rates it "less reliable than other cars from the same model year"; coil spring corrosion recall; ABS module fire risk in older examples (Consumer Reports 2011 Elantra)

Common Problems
Problem 1: Engine Tick / Piston Slap / Low Oil Stalling
Severity: High if ignored; manageable if caught early
Affected years: 2011–2014 primarily; 2013 worst
Typical mileage onset: 60,000–100,000 miles for tick; stalling can occur at any mileage if oil is low
Symptoms: Metallic ticking on startup that may diminish when warm; engine stalling without a check engine light (often triggered by low oil level); rough idle; engine runs roughly
Repair options:
Oil level check/top-up: $0 (owner action)
Piston slap repair (ring replacement): $1,500–$3,000 independent
Engine replacement (used): $1,500–$3,500 + $1,000–$1,500 labor
Average cost to fix engine ticking per CarComplaints: $4,900 at avg. 76,000 mi (CarComplaints)
Owner action: Check oil level monthly. On any 2011–2013 Elantra above 60k miles, have a compression test performed before purchase. Keep detailed oil change records — Hyundai has denied warranty claims without them.
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: No engine seizure recall for the 1.8L Elantra (unlike the Sonata's Theta II). The 2.0L GDI Elantra (2014+ Nu engine) is covered under the powertrain extended warranty for connecting rod bearing issues; owners must install the Knock Sensor Detection System (KSDS) update to qualify for 15-year/150,000-mile coverage (Hyundai extended warranty campaign)

Problem 2: Timing Chain Jump / No-Start
Severity: High
Affected years: 2011–2014 primarily; higher risk above 120,000 miles or with missed oil changes
Typical mileage onset: 100,000–150,000 miles (earlier if oil changes were sporadic)
Symptoms: Engine cranks but won't start; rattling noise from engine on startup; check engine light with multiple misfire codes
Repair options:
Timing chain replacement: $800–$1,500 independent if caught before engine damage
Engine replacement if chain jumped and bent valves: $2,500–$5,000+
Owner action: On any Elantra over 100k miles, have the timing chain tension inspected. Ask for oil change records — irregular intervals are the primary cause.
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: None issued for timing chain specifically

Problem 3: 2013 MPG Shortfall vs. EPA Estimates
Severity: Medium (financial, not safety)
Affected years: 2013 primarily
Typical mileage onset: From new
Symptoms: Real-world fuel economy significantly below the 28 city / 38 highway EPA ratings; some owners reported 25–30 mpg combined on vehicles rated 35+ mpg
Repair options: No mechanical fix; Hyundai and Kia settled a class action in 2012 by adjusting EPA labels and offering fuel economy reimbursement cards to affected owners. Average "repair" cost cited at CarComplaints: $3,000 (represents fuel cost difference over time).
Owner action: If buying a 2013, expect real-world highway economy of 32–36 mpg, not the original 38 mpg claim.
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: Hyundai/Kia EPA settlement (2012); revised window stickers; reimbursement debit cards issued to original owners

Problem 4: Coil Spring Fracture (2011)
Severity: High — safety risk (spring can puncture tire)
Affected years: 2011 only
Typical mileage onset: Any mileage; corrosion-accelerated in rust belt states
Symptoms: Front suspension clunk; tire damage; pulling to one side
Repair options: Coil spring replacement: $200–$400 per corner independent; free under recall
Owner action: VIN check at nhtsa.gov for any 2011 Elantra — recall for front coil springs was issued in 2015.
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: NHTSA recall issued 2015 for 2011 Elantra coil springs

Problem 5: ABS Module Fire Risk (2006–2011)
Severity: High — fire while parked
Affected years: 2011 (lower end of the MD generation)
Typical mileage onset: Any mileage; electrical failure
Symptoms: ABS module leaks brake fluid internally; electrical short can cause fire in engine compartment while parked or driving
Repair options: ABS fuse replacement (free under recall) — dealers replace the ABS fuse to interrupt the fire risk circuit
Owner action: Confirm recall completed via VIN check. Hyundai advises parking outside and away from structures until recall is repaired. Recall 251 issued 2024.
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: Recall 251 (Hyundai Campaign) — issued 2024; covers 2006–2011 Elantras; dealers replace ABS fuse free of charge (Consumer Reports 2011 Elantra)

Maintenance Schedule Highlights
Engine oil — every 7,500 miles (synthetic 5W-20 or 5W-30); every 5,000 miles if predominantly city driving — critical for engine longevity; Hyundai denies warranty claims without maintenance records
Spark plugs (iridium) — every 60,000 miles (1.8L MPI); every 30,000 miles (2.0L GDI recommended by some technicians due to carbon buildup)
Timing chain — inspect at 100,000 miles; no replacement interval per factory, but high-mileage inspection is advisable
Transmission fluid — every 30,000 miles on automatic; every 30,000–45,000 miles manual (Hyundai Genuine ATF SP-IV or equivalent)
Coolant flush — every 60,000 miles (Hyundai Long Life Coolant)
Brake fluid — every 30,000 miles or 3 years
Cabin air filter — every 15,000–20,000 miles
Typical Annual Ownership Cost
Insurance: $1,100–$1,500/yr (compact sedan; lower insurance class than midsize)
Fuel (15K mi/yr): $1,300–$1,600 (real-world ~32 mpg combined; at ~$3.30/gal avg)
Maintenance: $350–$500/yr routine (RepairPal annual cost: $452)
Depreciation
The 5th-gen Elantra depreciates heavily by the used market but holds relative value better than the Altima within its compact class. A 2013 Elantra that listed around $18,000–$20,000 new now changes hands privately at $4,000–$7,000. The 2013's complaint record suppresses its price; a clean 2016 Elantra with under 80k miles still fetches $8,000–$11,000 — reflecting its superior reputation. The Elantra's depreciation rate is typical for the compact segment: roughly 60–70% of original MSRP lost over 8–10 years.
Sources
RepairPal Hyundai Elantra Reliability: https://repairpal.com/reliability/hyundai/elantra
CarComplaints Elantra overview: https://www.carcomplaints.com/Hyundai/Elantra/
CarComplaints 2013 Elantra: https://www.carcomplaints.com/Hyundai/Elantra/2013/ (implied from overview data)
Consumer Reports 2011 Elantra: https://www.consumerreports.org/cars/hyundai/elantra/2011/reliability/
CarParts.com Elantra reliability: https://www.carparts.com/blog/hyundai-elantra-reliability-and-common-problems/
Hyundai powertrain extended warranty (KSDS / Nu engine): https://autoservice.hyundaiusa.com/TXXM
Hyundai stop lamp switch stopper pad recall: https://autoservice.hyundaiusa.com/campaign170
1A Auto Nissan Sentra/Elantra problems reference: https://blog.1aauto.com/7th-gen-nissan-sentra-problems/

| Engine | Output | Transmission | Notes |
| --- | --- | --- | --- |
| 1.8L inline-4 (Nu MPI) | 148 hp / 131 lb-ft | 6-speed manual or 6-speed automatic | Standard engine; affected by engine tick/oil consumption on some units |
| 2.0L inline-4 (Nu GDI) | 173 hp / 154 lb-ft | 6-speed manual or 6-speed dual-clutch | Sport/GT/Limited trim; GDI version subject to Hyundai powertrain extended warranty for connecting rod bearing failures |
