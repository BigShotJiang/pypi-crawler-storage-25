---
project: med
type: reference
status: draft
date: 2026-04-14
tags: [med, mcp, v2, research-raw, vehicle-profile]
vehicle: Toyota Corolla
generations: "E140 (2009-2013), E170 (2014-2019), E210 (2020)"
source: Perplexity research batch 2-5
---

# Toyota Corolla - Research Raw

**Generations in 2010-2020 window:** E140 (2009-2013), E170 (2014-2019), E210 (2020)
**Source:** Perplexity research via prompt at 03_PROJECTS/Auto_Project/MCP_Server/2026-04-14__MED__mcp-v2-perplexity-vehicle-research-prompt__REF__v01.md
**Status:** Raw research. Awaits Chris Granola voice layer ('what_chris_would_say') before JSON normalization to vehicle_profiles_schema.json.

---

Toyota Corolla — E140/E170 Generations, 2009–2019
Engines
E140 generation (2009–2013):
1ZR-FE 1.8L 4-cylinder — 132 hp, paired with 4-speed automatic or 5-speed manual. This is the base engine on base/LE trims. The 4-speed auto is noticeably slow to shift and feels dated.
2ZR-FE 1.8L 4-cylinder — same displacement, updated valvetrain, used in S/XRS trims. 132–140 hp depending on tune.
Both engines are non-interference designs with timing chains (not belts) — no scheduled belt replacement.
E170 generation (2014–2019):
1ZR-FE / 2ZR-FE 1.8L 4-cylinder — carried over, 132 hp. Most common engine in the generation.
CVT (Multidrive S) replaces the 4-speed automatic starting in 2014 on most trims; a 6-speed manual remained available on some trims through 2017.
The CVT is Toyota's proprietary unit — more reliable than Nissan's Jatco-sourced transmissions but still requires fluid changes every 60,000 miles.
Fuel economy: 27–29 city / 35–38 highway MPG for the 1.8L automatic (Edmunds).
Variant-specific issues:
2009–2011 only: The 2ZR-FE (and some 1ZR-FE units in the same window) share bore/ring design with the 2AZ-FE engine, which exhibited excessive oil consumption — addressed by Toyota Warranty Enhancement Program ZE7 (NHTSA TSB document).
2009–2010 only: Electric power steering (EPS) module caused drifting/wandering — a class-action lawsuit was settled in 2019 covering ECU replacement (Top Class Actions).
2014–2016: Fuel tank filler neck misalignment triggers P0455/P0456 CEL — TSB T-SB-0086-16 exists for repositioning (samarins.com).
2014–2019 CVT: Generally reliable; fluid overheating possible under sustained highway stress — change CVT fluid at 60k mi per Toyota spec.

Reliability Rating
Excellent — 4.5 out of 5.0 stars, ranked 1st out of 36 compact cars (RepairPal).
Average annual repair cost: $362 vs. $526 compact car average. Severity of repairs rated at 7% (non-urgent) vs. 11% average for compact cars. Repair frequency: 0.3 visits/year, matching the compact car average.
Consumer Reports rates the Corolla above average for reliability across most model years in this range, with 2009 being the outlier due to the oil consumption and EPS issues.

Expected Lifespan (miles)
200,000–300,000 miles with routine maintenance. Multiple documented owner cases exceed 300,000 miles. CarEdge puts 10-year major repair probability at 12.28% — one of the lowest in the segment (CarEdge). Toyota's timing chain design (no belt to replace) eliminates a common high-mileage failure mode present in competitors.

Sweet Spot for Purchase
2015–2017, 40,000–80,000 miles. By 2015, the EPS drift and oil consumption issues of the E140 are gone, the CVT software was refined, and the 2014–2016 filler neck TSB is typically already addressed. Private-party prices in this window run approximately $9,000–$13,000 — enough depreciation to make financial sense without being high enough mileage to worry about suspension wear.

Best Years
2017 — Last year before the 2019 E210 redesign on the sedan; fully sorted E170 platform, lowest complaint count (37 on CarComplaints) of the 2014+ run, EPS software stable, CVT refined, no generation-specific defect campaigns outstanding.
2016 — Nearly identical to 2017; slightly higher complaint count (43) but still well within acceptable range. Strong depreciation — private party values around $10,000–$12,500 at reasonable mileage.
2014 — First year of the E170, but already resolved the E140's oil consumption and EPS issues. The CVT hiccups were real but addressed via software updates. Good value entry point for the newer body style.

Years to Avoid
2009 — Worst year in the generation: 254 CarComplaints entries (CarComplaints), 76 engine complaints + 324 NHTSA engine complaints, 17 steering complaints + 384 NHTSA steering complaints. Excessive oil consumption (avg cost $4,500 at 100,000 mi) and EPS drift both present. Only buy a 2009 if TSB T-SB-0094-11 piston/ring work AND the EPS ECU update have been documented as completed.
2010 — Second-worst: 127 CarComplaints entries, EPS issue still present (370 NHTSA steering complaints), paint chipping widespread (avg cost $1,100 at 56,000 mi), and accelerator pedal recall (sticky pedal — same campaign as the large 2010 Toyota recall). Verify all open recalls are closed before buying.

Common Problems (top 5)
Problem 1: Excessive Engine Oil Consumption (2AZ/2ZR Engines)
Severity: High — can cause engine damage if not monitored
Affected years: 2009–2011 (most severe); some 2012–2013 reports
Typical mileage onset: 60,000–120,000 miles
Symptoms: Oil level drops 1+ quart per 1,000 miles; blue smoke at startup; fouled spark plugs; potential low-oil engine damage
Repair options:
Piston/ring replacement under Warranty Enhancement Program ZE7 (if still within extended coverage): $0 if eligible
Independent shop piston ring replacement: $1,500–$3,500
Dealer short block replacement (documented in some ZE7 cases): $3,000–$5,500
Workaround: Check oil every 1,000 miles, add as needed
Owner action: Pull the VIN and check Toyota's ZE7 warranty enhancement eligibility. If out of coverage, get an oil consumption test (mark the dipstick, drive 1,000 miles, measure). Average reported repair cost on CarComplaints: $4,500 (CarComplaints)
NHTSA complaint count: 324 NHTSA complaints for engine category on 2009 Corolla alone (CarComplaints 2009 data)
TSB/recall: TSB T-SB-0094-11 (2011); Warranty Enhancement Program ZE7 (2014–2015, extended coverage); TSB T-SB-00158-14 (NHTSA ZE7 document)

Problem 2: Electric Power Steering (EPS) Drift / Wandering
Severity: Moderate to High — affects directional control
Affected years: 2009–2010 (primary); some 2011 reports
Typical mileage onset: Can occur at any mileage; first reported shortly after 2009 model launch
Symptoms: Vehicle wanders or drifts side-to-side at highway speeds; steering feels light or uncorrelated; driver must actively correct lane position
Repair options:
EPS ECU replacement/re-tune under TSB: $0 if under warranty or class action eligibility
Out-of-pocket ECU replacement: $400–$800 (independent) / $600–$1,000+ (dealer)
Owner action: Verify the EPS ECU update (TSB-014010 / TSB-1040) has been applied. NHTSA opened investigation in February 2010; settlement reached 2019 allowing up to $695 reimbursement for completed repairs (Top Class Actions)
NHTSA complaint count: 384 NHTSA steering complaints on 2009 Corolla; 370 on 2010 Corolla (CarComplaints 2009 data, CarComplaints 2010 data)
TSB/recall: TSB-014010 (also listed as TSB-1040); class action settled 2019

Problem 3: Water Pump Failure
Severity: Moderate — overheating risk if not caught
Affected years: 2009–2013 (E140 generation most reported)
Typical mileage onset: 55,000–80,000 miles (CarComplaints avg 62,000 mi for 2009)
Symptoms: Coolant loss without obvious external leak; sweet smell from engine bay; temperature gauge creeping up; pink residue around water pump area
Repair options:
Independent shop water pump replacement: $300–$600
Dealer: $500–$900
Owner action: Inspect around the water pump housing for dried pink/white residue at any pre-purchase inspection. Toyota issued TSB T-SB-0103-20 (and earlier bulletins) covering inspection and diagnostic procedure for water pump seepage on 2008–2021 models (NHTSA TSB document)
NHTSA complaint count: 3 NHTSA cooling system complaints on 2009 Corolla (low count, but severity warrants inspection)
TSB/recall: TSB T-SB-0103-20 Rev1 (water pump inspection, not a recall)

Problem 4: Takata Airbag Inflator Recall
Severity: Critical — inflator can rupture and send metal fragments at occupants
Affected years: 2003–2013 Corolla (multiple recall campaigns)
Typical mileage onset: Age-related; applies regardless of mileage
Symptoms: None — this is a latent defect, not a drivability issue
Repair options:
Free dealer replacement — this is a federal safety recall; no cost to owner
Owner action: Run the VIN at nhtsa.gov/recalls before purchasing any 2009–2013 Corolla. Multiple Takata campaigns have been issued. Do not buy an affected vehicle with an open recall. (Center for Auto Safety)
NHTSA complaint count: 565 NHTSA seat belt / airbag complaints on 2009 Corolla — heavily influenced by Takata recall campaigns
TSB/recall: Multiple NHTSA recall campaigns (10V017, G0P, J0A/J0B/J0C among others); check VIN specifically

Problem 5: Sticky Accelerator Pedal (2009–2010)
Severity: High — potential unintended acceleration
Affected years: 2009–2010
Typical mileage onset: Any mileage; condition-related (cold + condensation)
Symptoms: Accelerator pedal becomes harder to depress, slower to return, or in worst case sticks in partially depressed position when operating heater without A/C in cold conditions
Repair options:
Free recall repair: dealer installs reinforcement bar in accelerator pedal assembly
Owner action: Verify recall completion on any 2009–2010 Corolla VIN. Recall campaign 10V017 (announced January 2010, remedy began February 2010). (Center for Auto Safety)
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints for complaint specifics; recall affects approximately 363,000 model year 2009 and 136,000 model year 2010 Corollas
TSB/recall: NHTSA Recall 10V017000; Toyota recall designation 90L

Maintenance Schedule Highlights
Oil change — Every 5,000 miles (0W-20 full synthetic required per Toyota spec; using heavier viscosity in a 2009–2011 with oil consumption issue can mask the problem temporarily but does not fix it)
Tire rotation — Every 5,000 miles (CarEdge)
Cabin air filter — Every 15,000–20,000 miles (~$20–$40 DIY)
Engine air filter — Every 30,000 miles
Spark plugs — Every 120,000 miles (iridium plugs; $170–$220 at a shop) (samarins.com)
CVT fluid (E170 2014+) — Every 60,000 miles; Toyota Genuine ATF WS fluid required; dealer quotes ~$150–$200, independent ~$80–$120. Do not skip — dry CVT clutches accelerate wear significantly
Engine coolant — Inspect at 45,000, replace at 100,000 miles (Toyota Super Long Life Coolant / pink; do not mix with green)
Drive belt inspection — Every 30,000 miles; replacement typically 90,000–120,000 miles ($150–$300 independent)

Typical Annual Ownership Cost
Insurance: $1,200–$1,800/year for a used 2015–2017 Corolla (varies heavily by state, age, and driving history; CarEdge puts the figure at $2,653/year for newer models — used examples with lower stated value will be less) (CarEdge)
Fuel (15K mi/yr): $1,050–$1,350/year based on 28–32 MPG combined and $3.50–$3.80/gal national average
Maintenance: $350–$650/year for a well-maintained example at 50,000–100,000 miles; RepairPal average is $362/year (RepairPal); CarEdge shows years 6–10 averaging $527–$655/year

Depreciation
The Corolla holds value better than most compact cars. CarEdge ranks it first for lowest 5-year depreciation among competitors, retaining approximately 67% of MSRP after five years from new (CarEdge depreciation). In practical terms for a used buyer: a 2015 Corolla LE that originally sold for roughly $19,000 MSRP now fetches approximately $9,000–$11,000 in private-party condition (average mileage ~120,000–130,000 miles), representing a loss of about 45–53% from MSRP over nine years — flatter than the industry curve. The 2017 Corolla in clean condition with 80,000–100,000 miles carries a private party value of roughly $9,700–$11,100 (Edmunds 2017 Corolla appraisal). The flat depreciation curve cuts both ways: you pay more than you would for a comparably-aged Civic or Sentra, but you also lose less money when you eventually sell.

Sources
RepairPal Corolla reliability rating and annual cost: https://repairpal.com/reliability/toyota/corolla
CarComplaints Toyota Corolla summary: https://www.carcomplaints.com/Toyota/Corolla/
CarComplaints 2009 Corolla detail: https://www.carcomplaints.com/Toyota/Corolla/2009/
CarComplaints 2010 Corolla detail: https://www.carcomplaints.com/Toyota/Corolla/2010/
CarComplaints 2009 Corolla excessive oil consumption: https://www.carcomplaints.com/Toyota/Corolla/2009/engine/excessive_oil_consumption.shtml
Toyota ZE7 Warranty Enhancement Program (NHTSA): https://static.nhtsa.gov/odi/tsbs/2015/MC-10134468-9999.pdf
Toyota EPS class action settlement: https://topclassactions.com/lawsuit-settlements/lawsuit-news/toyota-settles-steering-defect-class-action-lawsuit/
Toyota 2009–2010 EPS investigation (ABC News): https://abcnews.com/Blotter/RunawayToyotas/federal-officials-probe-toyota-corolla-steering-problem/story?id=9867318
Choisser Automotive (TSB T-SB-0094-11 detail): https://choisserautorepair.com/what-to-do-about-toyotas-excessive-oil-consumption/
Toyota water pump TSB (NHTSA): https://static.nhtsa.gov/odi/tsbs/2020/MC-10183188-9999.pdf
Center for Auto Safety 2009 Corolla recalls: https://www.autosafety.org/vehicle-safety-check/2009-toyota-corolla/
2014–2019 Corolla common problems (samarins.com): https://www.samarins.com/reviews/corolla.html
CarEdge Corolla maintenance costs: https://caredge.com/toyota/corolla/maintenance
CarEdge Corolla depreciation: https://caredge.com/toyota/corolla/depreciation
Edmunds 2017 Corolla used pricing: https://www.edmunds.com/used-2017-toyota-corolla-houston-tx/
CarComplaints 2010 Corolla TSBs: https://www.carcomplaints.com/Toyota/Corolla/2010/tsbs/
