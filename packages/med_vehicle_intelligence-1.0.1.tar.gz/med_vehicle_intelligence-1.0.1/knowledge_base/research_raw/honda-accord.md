---
project: med
type: reference
status: draft
date: 2026-04-14
tags: [med, mcp, v2, research-raw, vehicle-profile]
vehicle: Honda Accord
generations: "8th gen (2008-2012), 9th gen (2013-2017), 10th gen (2018-2020)"
source: Perplexity research batch 2-5
---

# Honda Accord - Research Raw

**Generations in 2010-2020 window:** 8th gen (2008-2012), 9th gen (2013-2017), 10th gen (2018-2020)
**Source:** Perplexity research via prompt at 03_PROJECTS/Auto_Project/MCP_Server/2026-04-14__MED__mcp-v2-perplexity-vehicle-research-prompt__REF__v01.md
**Status:** Raw research. Awaits Chris Granola voice layer ('what_chris_would_say') before JSON normalization to vehicle_profiles_schema.json.

---

Honda Accord — 8th and 9th Generations, 2008–2017
Engines
8th generation (2008–2012):
K24Z3 2.4L 4-cylinder — 190 hp; paired with 5-speed automatic or 6-speed manual. Generally more reliable than the V6 in this generation.
J35Z2 / J35Z3 3.5L V6 — 268–271 hp; paired with 5-speed automatic. Includes Variable Cylinder Management (VCM) cylinder deactivation on all V6 trims. The VCM system is the single biggest reliability concern for this generation's V6.
No timing belt — both engines use timing chains.
8th gen V6 Accord also offered as a coupe (same drivetrains).
9th generation (2013–2017):
K24W5 / K24W7 2.4L 4-cylinder ("Earth Dreams") — 185–189 hp; paired with CVT (base/Sport) or 6-speed automatic (Sport/EX-L). CVT available from 2013.
J35Y2 3.5L V6 — 278 hp; 6-speed automatic only. VCM carried over but revised. V6 in 9th gen is paired with a 6-speed automatic rather than the 5-speed.
Earth Dreams 4-cylinder engines (2013+) have documented oil consumption and timing chain tensioner issues — separate from the V6/VCM problem.
V6 in both generations uses a timing belt — replacement required at 105,000 miles (~$600–$900 at a shop). This is a critical maintenance item many sellers skip.
Fuel economy: 4-cylinder 27 city / 36 highway (8th gen auto); 27 city / 36 highway (9th gen CVT). V6: 21 city / 34 highway (8th gen).
Variant-specific issues:
V6 8th gen (2008–2012): VCM causes fouled plugs, misfires, oil consumption, and engine mount wear. TSB 11-033 (ECU reflash) addresses the worst VCM cycling behavior. TSB 13-078 extended powertrain warranty to 8 years/unlimited miles for P0301–P0304 misfire codes on VCM engines (BobIsTheOilGuy forum).
4-cylinder 8th gen (2008–2012): Piston ring design causes oil consumption at higher mileage; TSB #12-087 covers piston/ring replacement (MotorBiscuit).
9th gen 4-cylinder (2013–2017): Timing chain tensioner rattle at cold start; TSB 19-019 covers tensioner replacement (~$50 part). PCV valve failure accelerates oil consumption.
All 8th gen (2008–2010): Rear brake pad premature wear — class action settled 2010; improved pads available (Honda/Acura Brake Settlement).
9th gen V6 (2013–2015): Starter motor gear clearance defect — TSB 16-002 covers starter replacement + torque converter rotation (hondaproblems.com).

Reliability Rating
Above Average — 4.5 out of 5.0 stars, ranked 1st out of 24 midsize cars on RepairPal (RepairPal).
Average annual repair cost: $400 vs. $526 midsize car average. Repair severity: 9% (not urgent) vs. 12% average. Frequency: 0.26 visits/year.
Caveat: The 8th and 9th gen Accord's overall RepairPal score reflects the full model range. The specific 2008–2010 and 2013–2014 model years are measurably worse than the overall score implies, with CarComplaints recording 2,496 complaints on the 2008 model alone and 600 on the 2013 (CarComplaints). Buyer should treat this as "above average when the right year/engine is chosen."

Expected Lifespan (miles)
200,000–250,000 miles for the 4-cylinder with proper maintenance. The V6 is capable of similar longevity but requires proactive management of VCM issues (plugs, mounts) and strict adherence to the timing belt interval (105,000 miles — skip this and you risk catastrophic engine failure). Multiple forum-documented cases of 300,000+ mile 4-cylinder Accords. FIXD puts the 40%-depreciated mark at roughly 192,000 miles for 2007 models, consistent with a well-maintained 200k+ lifespan (FIXD depreciation data).

Sweet Spot for Purchase
2015–2017 4-cylinder, 50,000–90,000 miles. By 2015, the starter failure and most electrical issues of the 2013–2014 launch window had been addressed via service bulletins. The 9th gen platform is mature, the Earth Dreams 4-cylinder's main flaw (timing chain tensioner rattle) is a cheap fix if not already done, and pricing is reasonable — 2015 4-cyl examples in the $10,000–$14,000 private-party range represent solid value. Avoid V6 unless you can verify the timing belt was replaced and TSB 11-033 was applied.

Best Years
2016 — 282 CarComplaints entries sounds high, but the LED daytime running light burnout issue (64 complaints) accounts for a large share; it is minor and cheap to fix. Mechanically, the 2016 is the most sorted year of the 9th gen. Starter TSB widely applied, CVT software refined, build quality improved from 2013–2014.
2012 — Last year of 8th gen; 242 CarComplaints entries. Brake pad defect largely resolved (improved pads from class action). VCM issues present on V6 but ECU TSB (11-033) was available by this point. 4-cylinder 2012 is arguably the cleanest 8th gen buy if you want that body style.
2017 — Last year of 9th gen before the 10th gen overhaul. Lowest complaint year of the 9th gen at 124 entries (CarComplaints). Buy the 4-cylinder CVT.

Years to Avoid
2008 — 2,496 CarComplaints complaints; most of any Accord in the data set (CarComplaints). 1,277 brake complaints, 590 engine complaints, class-action lawsuit for premature brake wear. VCM misfire and oil consumption issues active on V6. Uncomfortable seats are a consistent multi-year complaint starting here. Only buy a very clean example where the brake pad issue has been remedied and VCM TSB is documented.
2013 — 600 CarComplaints complaints; worst 9th gen year. 209 electrical complaints (406 NHTSA), 110 starter failure complaints, 53 oil consumption complaints. The starter motor defect (grinding and failure to crank) hit 9th gen V6s hardest in 2013–2015 and was not fully addressed until TSB 16-002. Battery deemed insufficient for V6 demands. CarComplaints awarded this year a "Beware" designation (CarComplaints 2013).
2014 — 381 CarComplaints complaints; starter and electrical issues continued. "Engine won't turn over" was 2014's second-most-complained problem (42 reports, avg cost $800 at 47,000 miles). Largely the same problems as 2013 before mid-cycle corrections took hold (CoPilot).
2009 / 2010 — 988 and 507 CarComplaints complaints respectively. Brake pad defect persists; VCM issues still present. 2009 has not been fully remedied in the resale market. Skip unless you are getting it very cheap with documented brake and VCM history.

Common Problems (top 5)
Problem 1: Variable Cylinder Management (VCM) Misfires and Oil Consumption
Severity: High — leads to fouled plugs, misfires (P0301–P0304), engine mount failure, and long-term oil consumption
Affected years: 2008–2012 V6 (all trims with the J35 V6); 2013–2017 V6 less severe but still VCM-equipped
Typical mileage onset: 60,000–100,000 miles
Symptoms: Rough idle or surging at cruise speed; CEL with misfire codes; blue smoke; engine vibration at highway speed (failed mounts from VCM cycling); 1+ qt oil consumption per 1,000 miles
Repair options:
ECU reflash (TSB 11-033): $75–$150 out of warranty at dealer
Spark plug replacement (required alongside reflash): $150–$250 (6 plugs on V6)
Oil pressure switch replacement: $30–$80 in parts, relatively straightforward DIY
Engine mount replacement (if failed from VCM cycling): $400–$900 per mount, independent
Piston ring replacement if oil consumption is severe: $1,500–$3,500
Aftermarket VCM disabler (VCMTuner II or similar): $100–$200; disables cylinder deactivation without CEL; widely used by owners as a long-term workaround
Owner action: Verify TSB 11-033 was applied before purchasing any V6 8th gen. Also check TSB 13-078 (warranty extension for misfires) — Honda extended powertrain coverage to 8 years/unlimited miles for P0301–P0304 on VCM engines; this may still be active on 2011–2012 models (BobIsTheOilGuy)
NHTSA complaint count: 275 NHTSA engine complaints on 2008 Accord alone (CarComplaints 2008 data); not retrieved for individual years beyond 2008 — verify at nhtsa.gov/complaints
TSB/recall: TSB 11-033 (ECU reflash for VCM cycling); TSB 13-078 (warranty extension for misfires); TSB #12-087 (piston ring replacement for 4-cyl oil consumption)

Problem 2: Premature Rear Brake Pad Wear
Severity: Moderate — expensive if rotors are damaged; class-action settled
Affected years: 2008–2010 (primary); 2010 VIN-specific
Typical mileage onset: 12,000–30,000 miles (rear pads only; front pads normal)
Symptoms: Rear brake pad wear indicator noise at extremely low mileage; squealing from rear; rear pads at 2mm while fronts still have 6mm+
Repair options:
Improved Honda rear brake pads (part #43022-TAO-A40 or A80): $80–$150 for pads installed
If rotors damaged: $350–$650 total for pads + rotors
Class action settlement (2010): reimbursement window has passed; improved pads are the remedy
Owner action: Any 2008–2010 Accord should have the improved pads already installed by now. Ask for brake service records. If buying a low-service-history 2008–2009, budget for rear brake inspection immediately. Honda's Electronic Brake Distribution (EBD) system was the culprit — design defect applying excess force to rear wheels (class action detail)
NHTSA complaint count: 595 NHTSA brake complaints on 2008 Accord; 1,277 CarComplaints brake complaints on 2008 Accord (CarComplaints 2008)
TSB/recall: No federal recall; class action settled July 2010; Honda issued redesigned pads

Problem 3: Starter Motor Failure (9th Gen V6)
Severity: High — leaves vehicle unable to start; can recur if root cause not addressed
Affected years: 2013–2015 (V6 primary); some 4-cylinder reports
Typical mileage onset: 40,000–80,000 miles; disproportionately soon after 36,000-mile warranty expiration
Symptoms: Grinding or whining noise when turning ignition; engine cranks but doesn't start; engine fails to crank at all
Repair options:
Starter replacement (updated Honda part #31200-5G0-A04): $300–$600 independent / $500–$900 dealer
TSB 16-002 procedure also requires rotating torque converter one bolt position — must be done correctly or starter fails again
Battery upgrade to higher CCA rating: $150–$250; addresses secondary cause (undersized OEM battery)
Owner action: If buying 2013–2015 V6, ask for starter replacement history. If not replaced, factor in $500 within the near future. CarComplaints designated 2013 with a "Beware" seal specifically for this issue (CarComplaints 2013 detail)
NHTSA complaint count: 406 NHTSA electrical complaints on 2013 Accord (starter is the dominant driver) (CarComplaints 2013)
TSB/recall: TSB 16-002 (starter replacement + torque converter adjustment); TSBs confirmed via Reddit discussion; no federal recall issued

Problem 4: Timing Chain Tensioner Rattle (9th Gen 4-Cylinder Earth Dreams Engine)
Severity: Moderate — noise is alarming; if ignored, can lead to timing chain damage
Affected years: 2013–2017 (4-cylinder; also affects 2015–2022 CR-V and 2016–2021 Civic with same engine)
Typical mileage onset: 30,000–80,000 miles
Symptoms: Brief metallic rattle on cold start, disappearing within 5–30 seconds; sometimes also described as a ticking; VTC actuator or tensioner check valve failure
Repair options:
Timing chain tensioner replacement (genuine Honda part ~$50): $150–$300 labor at independent shop
VTC actuator replacement (if that is the source): $200–$500 parts + labor
TSB 19-019 covers tensioner; tensioner part number 14510-582-802 (YouTube repair reference)
Owner action: At pre-purchase inspection, start the car cold and listen for a rattle in the first 30 seconds. If present, negotiate the repair cost in. This is a known, documented TSB item — do not let a seller dismiss it.
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: TSB 19-019

Problem 5: Excessive Oil Consumption (4-Cylinder, Both Generations)
Severity: Moderate to High — damages engine if level drops unchecked; class action filed
Affected years: 2008–2012 (8th gen 4-cyl); 2013–2017 (9th gen Earth Dreams 4-cyl)
Typical mileage onset: 60,000–100,000 miles (CarComplaints avg: 67,000 miles for 2008 Accord)
Symptoms: Oil level drops noticeably between oil changes; ticking sound from engine; 0W-20 oil found in a newer vehicle is a red flag per 1A Auto (1A Auto)
Repair options:
PCV valve replacement: $25–$80 — addresses oil consumption caused by PCV system, not piston rings
Oil consumption test (Honda dealers): Multi-step process over 1,000 miles; required to qualify for TSB piston work
Piston ring replacement (8th gen TSB #12-087): $1,500–$3,500
For 9th gen Earth Dreams: Honda faced class action; no comprehensive recall issued; PCV valve replacement is the standard first step
Owner action: Check oil at purchase and every 1,000 miles in the break-in period after buying. If consuming more than 1 qt per 3,000 miles, pursue diagnosis. Verify PCV valve was replaced on any high-mileage 9th gen 4-cylinder. (MotorBiscuit)
NHTSA complaint count: 275 NHTSA engine complaints on 2008 Accord; 229 NHTSA engine complaints on 2013 Accord (CarComplaints 2008, CarComplaints 2013)
TSB/recall: TSB #12-087 (8th gen piston rings); no comprehensive recall on 9th gen Earth Dreams oil consumption

Maintenance Schedule Highlights
Oil change — Every 7,500 miles on Honda Maintenance Minder (0W-20 full synthetic); real-world recommendation for VCM V6 is every 5,000 miles given oil consumption tendencies (CarEdge)
Tire rotation — Every 7,500 miles
Spark plugs — Every 30,000 miles (per Honda maintenance schedule); on the 8th gen V6 with VCM, many mechanics recommend 15,000–20,000 miles to prevent fouling from cylinder deactivation
Air filter — Every 30,000 miles
Timing belt (V6 only) — 105,000 miles — this is not optional. Interference engine; belt failure destroys the engine. At an independent shop, expect $600–$900. Verify this has been done on any V6 with over 100k miles.
Timing chain tensioner (4-cyl 9th gen) — Inspect at any cold-start; TSB 19-019 replacement at first sign of rattle
Transmission fluid — Every 90,000 miles (automatic); every 30,000 miles is a more conservative interval many mechanics recommend for high-mileage VCM V6 units that run hotter
Coolant — Every 45,000 miles (flush and replace); Honda Long Life Coolant Type 2 (blue/green)
Drive belts — Inspect every 30,000 miles; replace every 90,000 miles

Typical Annual Ownership Cost
Insurance: $1,400–$2,100/year for a used 2015–2017 Accord (midsize sedan; higher than Corolla due to size and repair costs)
Fuel (15K mi/yr): $1,450–$1,900/year for V6 at 21–27 MPG combined; $1,200–$1,500/year for 4-cylinder at 27–33 MPG combined (based on $3.50–$3.80/gal national average)
Maintenance: $400–$860/year; RepairPal average is $400/year (RepairPal); CarEdge shows years 6–10 averaging $690–$858/year (CarEdge maintenance); budget higher for V6 due to spark plug frequency and timing belt

Depreciation
The Accord depreciates faster than the Corolla but recovers as a value proposition at the sub-$15,000 mark. A 2013 Accord that originally sold for approximately $22,000–$25,000 MSRP now carries a private-party value of roughly $8,000–$11,000 depending on trim and mileage — roughly 55–65% depreciation from new. The 2017 Accord in clean 4-cylinder form fetches approximately $11,700 in private party sales and $8,950 at trade-in per KBB (KBB 2017 Accord depreciation). FIXD's analysis shows the 2013 model at approximately 34% residual value at 120,000 miles, versus the 2017 at about 53% at 72,000 miles, illustrating how the 9th gen's problem-heavy early years crater resale on the 2013–2014 cohort — giving buyers willing to do their homework a genuine price discount relative to a cleaner 2016–2017 example (FIXD depreciation analysis). The 8th gen (2008–2010) has largely bottomed out: a 2008 Accord is worth approximately $4,200 in private party condition — floor-level prices that only make sense if mechanical issues are already resolved and documented.

Sources
RepairPal Honda Accord reliability: https://repairpal.com/reliability/honda/accord
RepairPal Honda Accord annual repair cost: https://repairpal.com/honda/accord
CarComplaints Honda Accord summary: https://www.carcomplaints.com/Honda/Accord/
CarComplaints 2008 Honda Accord detail: https://www.carcomplaints.com/Honda/Accord/2008/
CarComplaints 2013 Honda Accord detail: https://www.carcomplaints.com/Honda/Accord/2013/
hondaproblems.com 9th gen Accord problems: https://www.hondaproblems.com/models/accord/generations/9/
1A Auto — 9th gen Accord problems: https://blog.1aauto.com/9th-gen-honda-accord-problems/
MotorBiscuit — 8th gen Accord common problems: https://www.motorbiscuit.com/7-common-2008-2012-8th-gen-honda-accord-problems-100000-miles/
BobIsTheOilGuy — VCM TSB 13-078 warranty extension: https://bobistheoilguy.com/forums/threads/2011-honda-accord-v6-vcm-lawsuit-recall-work.293449/
Honda/Acura brake pad class action settlement: https://www.settlement-claims.com/accordsettlement/FAQs.html
Gibbs Mura Honda brake class action: https://www.classlawgroup.com/honda-brakes
Honda rear brake premature wear detail: https://www.hondaproblems.com/accord-brake-wear/
CoPilot — Honda Accord years to avoid: https://www.copilotsearch.com/posts/honda-accord-years-to-avoid/
Reddit 9th gen starter problem: https://www.reddit.com/r/accord/comments/1m919ky/anyone_know_why_the_9th_gen_starter_problem/
Timing chain tensioner TSB 19-019 repair video: https://www.youtube.com/watch?v=HNeKxJA5dTk
FIXD Honda Accord depreciation: https://www.fixdapp.com/car-buying/honda-accord-depreciation-rate-curve-graphed/
KBB 2017 Honda Accord depreciation: https://www.kbb.com/honda/accord/2017/depreciation/
KBB 2008 Honda Accord depreciation: https://www.kbb.com/honda/accord/2008/depreciation/
CarEdge Honda Accord maintenance costs: https://caredge.com/honda/accord/maintenance
CarEdge Honda Accord depreciation: https://caredge.com/honda/accord/depreciation
