---
project: med
type: reference
status: draft
date: 2026-04-14
tags: [med, mcp, v2, research-raw, vehicle-profile]
vehicle: Ford Fusion
generations: "1st gen (2006-2012), 2nd gen (2013-2020)"
source: Perplexity research batch 2-5
---

# Ford Fusion - Research Raw

**Generations in 2010-2020 window:** 1st gen (2006-2012), 2nd gen (2013-2020)
**Source:** Perplexity research via prompt at 03_PROJECTS/Auto_Project/MCP_Server/2026-04-14__MED__mcp-v2-perplexity-vehicle-research-prompt__REF__v01.md
**Status:** Raw research. Awaits Chris Granola voice layer ('what_chris_would_say') before JSON normalization to vehicle_profiles_schema.json.

---

Ford Fusion — 2nd Generation, 2013–2020
Engines

Key rule: The 2.5L non-turbo is the most reliable engine. The 1.5L EcoBoost is the most common but carries the highest risk of the catastrophic coolant intrusion failure.
Reliability Rating
Above Average — 4.0 out of 5.0; ranked 18th out of 24 midsize cars (RepairPal). Average annual repair cost: $581 — above the $526 midsize-car average and the highest among all six vehicles in this batch. The "above average" rating is carried by later model years (2018–2020); the 2013–2014 drags the average down considerably.
Expected Lifespan (miles)
150,000–200,000 miles for EcoBoost engines if coolant issue has not developed; 200,000–250,000+ miles for the 2.5L non-turbo with proper maintenance. The 6F35 transmission, used in most Fusions, can reach 200,000–300,000 miles with regular fluid changes — Ford's "lifetime fill" recommendation is a documented reliability killer; change the fluid every 60,000 miles (YouTube transmission analysis).
Sweet Spot for Purchase
2017–2018, 2.5L or 2.0L EcoBoost, 30,000–70,000 miles. By 2017, SYNC 3 infotainment with Apple CarPlay/Android Auto was added, the worst early build-quality issues were addressed, and the 1.6L EcoBoost (most problematic) was already discontinued. Coolant intrusion risk exists on 1.5L units but is most common on higher-mileage examples. Avoid 2013–2014 EcoBoost models entirely (CarGurus buying guide).
Best Years
2019–2020 — Lowest complaint count in generation; most safety tech standard; fewest major issues; best-equipped from factory (CarBuzz Fusion reliability)
2018 — Significant drop in complaints vs. earlier years; AEB added standard; good reliability record; SYNC 3 standard
Years to Avoid
2013 — 285 CarComplaints complaints; rough shifting (#1 complaint, avg. $3,000 at 40k mi); engine stalling (#3 complaint); 472 NHTSA engine complaints; first year of redesign issues (CarComplaints 2013 Fusion)
2014 — 193 complaints; 19 active recalls including 1.6L EcoBoost fire risk; transmission shifter bushing recall; multiple door latch recalls (Center for Auto Safety 2014 Fusion)
2016 — 116 complaints; the 2016 EcoBoost stalling issue (#2 worst problem for generation) cited at avg. $6,000 at 23,000 miles — highest cost-to-mileage ratio in the lineup (CarComplaints Fusion overview)

Common Problems
Problem 1: 1.5L/1.6L EcoBoost Internal Coolant Intrusion
Severity: Critical
Affected years: 2013–2019 (1.5L); 2013–2014 (1.6L — recall issued)
Typical mileage onset: 60,000–120,000 miles most common; some cases under 40,000 miles
Symptoms: Coolant level dropping with no visible external leak; white or blue exhaust smoke; engine misfires (codes P0316, P0302); rough running; sudden overheating; engine failure without warning
Repair options:
Engine block replacement (Ford): $6,000–$9,000 installed at dealer (updated block design)
Remanufactured engine swap (independent): $3,500–$5,500 installed
Used engine swap: $2,000–$4,000 installed (risk of same failure)
No factory recall issued for 1.5L or 2.0L EcoBoost coolant intrusion (as of 2024); 1.6L EcoBoost had recall 12V-551 and 17V-209
Owner action: If buying a Fusion with the 1.5L EcoBoost, check the coolant reservoir for oil contamination (brown/muddy color) and inspect for white smoke at startup. Ask for coolant change records. If the reservoir is discolored, walk away.
NHTSA complaint count: 472 NHTSA engine complaints for 2013 Fusion per CarComplaints; exact coolant-specific count not retrieved — verify at nhtsa.gov/complaints
TSB/recall: Recall issued for 1.6L EcoBoost only (12V-551 and 17V-209 for 2013–2014 Fusion); no recall for 1.5L or 2.0L EcoBoost coolant intrusion despite class action investigation (Lieff Cabraser class action; LemonLawFirm.com)

Problem 2: Transmission Shifter Cable Bushing Failure
Severity: High — vehicle may not be in Park when driver believes it is
Affected years: 2013–2016 (with 2.5L engine, 6-speed auto)
Typical mileage onset: Any mileage; material degradation over time
Symptoms: Shift lever feels loose; vehicle rolls after placing in Park; gear indicator and actual gear position may not match; key can be removed when not truly in Park
Repair options: Dealer bushing replacement — free under multiple recalls
Owner action: Confirm at least one of Recall 18S20 or 19S16 has been completed on any 2013–2016 Fusion via VIN check. Use the parking brake routinely until confirmed.
NHTSA complaint count: Not retrieved — verify at nhtsa.gov/complaints
TSB/recall: Recall 18S20 (July 2018) — 2013–2016 Fusion with 6-speed; Recall 19S16 (May 2019) — expanded; dealers replace shifter cable bushing and add protective cap free of charge (Center for Auto Safety 2014 Fusion)

Problem 3: 2013 Rough/Hard Shifting
Severity: Medium-High
Affected years: 2013–2014 primarily
Typical mileage onset: Average 40,000 miles
Symptoms: Harsh gear changes, especially 1-2 and 2-3 shifts; clunking on throttle tip-in or tip-out; transmission hesitation
Repair options:
TCM software update: $0–$150 at dealer
Transmission fluid change: $150–$200 independent
Torque converter replacement: $900–$1,500 independent
Full transmission rebuild: $1,500–$3,000 independent / $3,000–$5,000 dealer (avg. CarComplaints: $3,000)
Owner action: On any 2013–2014 Fusion, check transmission service history. The 6F35 needs fluid changes every 60,000 miles regardless of Ford's "lifetime" claim. If it shifts roughly and fluid hasn't been changed, start there before assuming the transmission is toast.
NHTSA complaint count: 12 NHTSA transmission complaints for 2013 Fusion per CarComplaints (CarComplaints 2013 Fusion)
TSB/recall: TSB 14-0085 (transmission fluid leak, RTV sealant); multiple powertrain TSBs for 2013 (TrueDelta TSB list)

Problem 4: Electric Power Steering Corrosion / Failure
Severity: High — loss of steering assist
Affected years: 2013–2016 (rust-belt states specifically)
Typical mileage onset: Any mileage in high-salt environments
Symptoms: Steering requires noticeably more effort; power steering warning; steering pulls or vibrates
Repair options: Steering gear motor bolt replacement with wax sealer — free under recall. Full steering gear replacement if bolts broken: $600–$1,200 independent
Owner action: Critical for cars from northern/salt-belt states. Confirm Recall 19S26 is complete.
NHTSA complaint count: 374 NHTSA steering complaints for 2013 Fusion per CarComplaints (CarComplaints 2013 Fusion)
TSB/recall: Recall 19S26 (Aug. 2019) — 2013–2016 Fusion and MKZ in 22 states; dealers replace EPS motor bolts and apply wax sealer, or replace steering gear if bolts missing/broken, free of charge (Center for Auto Safety)

Problem 5: Front Brake Hose Rupture
Severity: High — brake fluid leak = reduced braking
Affected years: 2013–2018
Typical mileage onset: Any mileage; material degradation
Symptoms: Soft or spongy brake pedal; brake fluid puddle under front of vehicle; brake warning light
Repair options: Front brake hose replacement — free under recall
Owner action: Confirm Recall 23S12 (Oct. 2023) completed via VIN check before purchase.
NHTSA complaint count: 95 NHTSA brake complaints for 2013 Fusion per CarComplaints (CarComplaints 2013 Fusion)
TSB/recall: Recall 23S12 (Oct. 2023) — 2013–2018 Fusion; dealers replace front brake hoses free of charge (Center for Auto Safety)

Maintenance Schedule Highlights
Engine oil — every 7,500–10,000 miles (synthetic 5W-20 or 5W-30 EcoBoost spec) — check coolant reservoir every oil change for contamination
6F35 transmission fluid — every 60,000 miles; do not follow Ford's "lifetime fill" recommendation — skipping fluid changes is directly correlated with premature transmission failure
Spark plugs — every 60,000 miles (EcoBoost); every 100,000 miles (2.5L)
Coolant flush — every 60,000 miles; on EcoBoost engines, inspect for oil contamination at every flush
Brake fluid — every 30,000 miles or 3 years
Power transfer unit fluid (AWD models) — every 60,000 miles; Ford dealers commonly miss this
Cabin air filter — every 15,000–20,000 miles
Typical Annual Ownership Cost
Insurance: $1,200–$1,700/yr (midsize sedan; EcoBoost models slightly higher)
Fuel (15K mi/yr): $1,600–$1,900 (1.5L EcoBoost: ~27 mpg combined; 2.5L: ~26 mpg; at ~$3.30/gal)
Maintenance: $450–$700/yr routine; budget an additional $500–$1,000 for EcoBoost coolant monitoring and potential repairs (RepairPal annual cost: $581)
Depreciation
The 2nd-gen Fusion depreciates steeply. A 2013 Fusion with an original MSRP of $21,500–$28,000 now sells privately for roughly $4,000–$6,500 — a loss of over 70% (KBB 2013 Fusion depreciation). The EcoBoost coolant intrusion reputation accelerated depreciation on 2013–2016 turbocharged models. A 2018 Fusion retained about 59% of its value over three years per KBB, in line with midsize-class averages. The Fusion's discontinuation after 2020 means no new competition from the same nameplate, which slightly supports used values on later models relative to some competitors.
Sources
RepairPal Ford Fusion Reliability: https://repairpal.com/reliability/ford/fusion
CarComplaints Ford Fusion overview: https://www.carcomplaints.com/Ford/Fusion/
CarComplaints 2013 Ford Fusion: https://www.carcomplaints.com/Ford/Fusion/2013/
Center for Auto Safety 2014 Ford Fusion recalls: https://www.autosafety.org/vehicle-safety-check/2014-ford-fusion/
Lieff Cabraser Ford EcoBoost coolant leak class action: https://www.lieffcabraser.com/defect/ford-coolant/
LemonLawFirm.com Ford Fusion coolant leak recall summary: https://lemonlawfirm.com/ford-fusion-coolant-leak-recall/
CarGurus Ford Fusion buying guide: https://www.cargurus.com/Cars/articles/ford-fusion-buying-guide
CarBuzz best Ford Fusion model years: https://carbuzz.com/best-ford-fusion-years-for-reliability/
TrueDelta 2013 Ford Fusion TSBs: https://www.truedelta.com/Ford-Fusion-tsbs-98,2013
KBB 2013 Fusion depreciation: https://www.kbb.com/ford/fusion/2013/depreciation/
KBB 2018 Fusion depreciation: https://www.kbb.com/ford/fusion/2018/depreciation/
YouTube — Ford Fusion transmission analysis: https://www.youtube.com/watch?v=bgKQN8xQOpQ

| Engine | Output | Transmission | Notes |
| --- | --- | --- | --- |
| 2.5L inline-4 (non-turbo) | 175 hp / 175 lb-ft | 6-speed auto (6F35) | Most reliable engine in the lineup; no turbo = no coolant intrusion risk; slightly less fuel-efficient |
| 1.5L EcoBoost inline-4 (turbo) | 181 hp / 185 lb-ft | 6-speed auto (6F35) | Most common; subject to internal coolant intrusion/engine block failure on 2013–2018; accounts for ~60% of used inventory |
| 1.6L EcoBoost inline-4 (turbo) | 178 hp / 184 lb-ft | 6-speed auto | 2013–2014 only; separate recall for coolant/fire risk; avoid |
| 2.0L EcoBoost inline-4 (turbo) | 231–240 hp / 270 lb-ft | 6-speed auto (6F35) | More powerful; same coolant intrusion concern on some units but less widespread; AWD available |
| 2.7L EcoBoost V6 (turbo) | 325 hp / 380 lb-ft | 6-speed auto (6F55) | Fusion Sport only (2017+); most powerful; generally good reliability |
| 2.0L hybrid / 2.0L PHEV | 141–188 hp system | CVT-type eCVT | Hybrid/Energi; avoid 2013–2015 hybrid models; electrical and battery reliability concerns |
