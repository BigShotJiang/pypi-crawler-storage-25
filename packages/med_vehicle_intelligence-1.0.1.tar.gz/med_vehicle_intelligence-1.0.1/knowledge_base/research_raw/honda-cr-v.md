﻿---
project: med
type: reference
status: draft
date: 2026-04-14
tags: [med, mcp, v2, research-raw, vehicle-profile]
vehicle: Honda CR-V
generations: "4th gen (2012-2016), 5th gen (2017-2022)"
source: Perplexity research batch 1
---

# Honda CR-V - Research Raw

**Generations in 2010-2020 window:** 4th gen (2012-2016), 5th gen (2017-2022)
**Source:** Perplexity research via prompt at 03_PROJECTS/Auto_Project/MCP_Server/2026-04-14__MED__mcp-v2-perplexity-vehicle-research-prompt__REF__v01.md
**Status:** Raw research. Awaits Chris Granola voice layer ('what_chris_would_say') before JSON normalization to vehicle_profiles_schema.json.

---
## Engines

2010â€“2011 (3rd gen facelift, still within your range)

- 2.4L inlineâ€‘4 (K24, ~180 hp) with 5â€‘speed automatic only.
  - Generally **durable**, but some owners report excessive oil consumption around 80k+ miles on 2010 models, sometimes requiring rebuilds.

2012â€“2014 (4th gen early)

- 2.4L inlineâ€‘4 (K24, ~185 hp) with 5â€‘speed automatic only.
  - Same basic engine family, chainâ€‘driven cams, no timing belt.
  - Fewer oilâ€‘consumption complaints than 2010 but still occasional reports on CarComplaints.

2015â€“2016 (4th gen refresh)

- 2.4L directâ€‘injected inlineâ€‘4 (Earth Dreams, ~185 hp) with CVT only.
  - Introduced CVT; most are reliable but some owners report idle vibration and driveline harshness in 2015â€“2016.

2017â€“2020 (5th gen)

- 2.4L portâ€‘injected inlineâ€‘4 (~184 hp) with CVT (mainly LX/base trims in early years).
  - Mechanically simple and generally **robust** with far fewer headline issues than the turbo.
- 1.5L turbo directâ€‘injected inlineâ€‘4 (L15B7, ~190 hp) with CVT (EX and up).
  - Wellâ€‘regarded mechanically but has a documented fuelâ€‘inâ€‘oil â€œoil dilutionâ€ issue in 2017â€“2019 CRâ€‘V, especially in cold climates and shortâ€‘trip use, addressed partially by TSB 18â€‘089 (software update) and extended warranty.

All 2010â€“2020 CRâ€‘V use timing chains, not belts.

------

## Reliability Rating

- RepairPal gives the Honda CRâ€‘V an overall reliability rating of 4.5/5, ranking 2nd out of 26 compact SUVs, with an average annual repair cost of about $407 and low severity of repairs.
- Consumer Reports has historically rated 2010â€“2016 CRâ€‘V as aboveâ€‘average to excellent for reliability, with a dip in owner satisfaction around the 2015â€“2016 vibration and 2017â€“2019 oil dilution years.

**Reliability Rating for 2010â€“2020 CRâ€‘V: above_average** (pulled down from â€œexcellentâ€ only by 2015â€“2016 NVH complaints and 2017â€“2019 1.5T oil dilution issues).

------

## Expected Lifespan (miles)

- With basic maintenance, it is common to see CRâ€‘Vs exceed 200,000 miles; CarEdge estimates about $7,636 in maintenance/repairs over the first 10 years with only a 21.7% chance of a â€œmajorâ€ repair, which is better than the segment.
- Owner reports and usedâ€‘market listings routinely show 2010â€“2013 CRâ€‘Vs running in the 200kâ€“250k mile range on original drivetrains.

Realistic expectation: 200,000â€“250,000 miles if you keep up on fluids, CVT service, and address known issues early.

------

## Sweet Spot for Purchase

Target a 2014â€“2015 CRâ€‘V with 80,000â€“130,000 miles: old enough to be affordable, new enough to have modern safety and infotainment, while mostly avoiding the worst 2010 oil consumption complaints and the later 1.5T oil dilution drama.

------

## Best Years

- 2013: Late 4thâ€‘gen with mature 2.4L and 5â€‘speed automatic, relatively few serious engine complaints and no turbo oil dilution.
- 2014: Similar mechanical package with incremental refinement and generally strong reliability scores from CR and low severe issue rates at RepairPal.
- 2020: 5thâ€‘gen after Hondaâ€™s oilâ€‘dilution updates, with improved calibration; RepairPal shows 0 reported problems and typical Honda low running costs so far.

------

## Years to Avoid

- 2010: Documented excessive oil consumption on the 2.4L engine, with 38 complaints and typical repair costs around $2,500 at ~83k miles.
- 2015â€“2016: Significant owner complaints about vibration at idle and driveline harshness after the switch to CVT, making them annoying to live with even though theyâ€™re not catastrophic.
- 2017â€“2019 (1.5T specifically): Wellâ€‘documented fuelâ€‘inâ€‘oil dilution issue on the 1.5L turbo CRâ€‘V, leading to classâ€‘action litigation and Honda TSB/software updates; mainly a risk if driven in short, coldâ€‘weather cycles.

------

## Common Problems

## 1. Oil Dilution â€“ 1.5L Turbo (2017â€“2019)

- Issue name: Fuelâ€‘inâ€‘oil / oil dilution on 1.5L turbo.
- Severity: major (can accelerate engine wear and affect drivability, but rarely an immediate safety hazard).
- Affected model years: 2017â€“2019 CRâ€‘V with 1.5L turbo engine.
- Typical mileage onset: 5,000â€“40,000 miles (often noticed at first oil changes).
- Symptoms: Rising oil level on dipstick, gasoline smell in oil, thin oil appearance, possible rough running, poor coldâ€‘weather performance, and sometimes checkâ€‘engine lights.
- Repair options and cost:
  - Software update per Honda TSB 18â€‘089 (recalibrates warmâ€‘up and fueling): usually done free under campaign/warranty.
  - Extraâ€‘frequent oil changes (every 3,000â€“5,000 miles): $60â€“$120 at an independent, $100â€“$160 at dealer.
  - In rare severe cases, engine repair or replacement could run into several thousand dollars if out of warranty.
- What the owner should actually do:
  - If you buy a 2017â€“2019 1.5T, confirm software updates and extended warranty status with a dealer, then plan short oil intervals and avoid mostly short, cold trips.
- NHTSA complaint count: The Center for Auto Safety notes numerous NHTSA complaints about 1.5T oil dilution on 2020 CRâ€‘V with similar engine; aggregated complaints specifically describing crankcase fuel/oil dilution for 2020 CRâ€‘V appear multiple times in their database, though NHTSA does not label a single defect code count.
- TSB/recall: Honda TSB 18â€‘089 (software update for oil dilution) and regional service campaigns; also referenced in related class action filings.

## 2. Excessive Oil Consumption â€“ 2.4L (2010 and some later years)

- Issue name: Excessive engine oil consumption.
- Severity: major (can lead to engine damage if oil runs low).
- Affected model years: 2010 CRâ€‘V primarily, with occasional reports on later 2.4L years (2011â€“2016), but 2010 is the standout.
- Typical mileage onset: 70,000â€“100,000 miles (2010 average around 83,800).
- Symptoms: Low oil between changes, blue smoke on startup or acceleration, engine noise, and sometimes checkâ€‘engine light for misfires or catalyst efficiency.
- Repair options and cost:
  - Monitoring and topping up oil: minimal cost but bandâ€‘aid only.
  - Honda oilâ€‘consumption TSB 11â€‘049 (piston/ring work) has been applied in some cases under warranty.
  - Outâ€‘ofâ€‘warranty ring job or rebuild: roughly $2,500 average per CarComplaints; full engine replacement higher.
- What the owner should actually do:
  - On 2010â€“2012, check oil every 1,000 miles; if consumption is high, get a formal consumption test and push dealer for TSB coverage or goodwill if mileage is reasonable.
- NHTSA complaint count: CarComplaints lists 38 owner reports of excessive oil consumption for the 2010 CRâ€‘V; NHTSAâ€™s database includes multiple engine/oilâ€‘related complaints under â€œEngineâ€ for that year.
- TSB/recall: Honda TSB 11â€‘049 for oil consumption/piston ring issues (applied to certain Kâ€‘series engines, including the CRâ€‘V).

## 3. Vibration at Idle / Driveline Harshness â€“ 2015â€“2016

- Issue name: Vibration at idle and low speeds after CVT introduction.
- Severity: moderate (annoying, affects comfort and perceived quality more than safety).
- Affected model years: 2015â€“2016 CRâ€‘V.
- Typical mileage onset: Often as early as 5,000â€“20,000 miles.
- Symptoms: Noticeable vibration when stopped in Drive, steering wheel and seat shaking, sometimes improved when A/C is turned on or RPM changes.
- Repair options and cost:
  - Honda issued updates such as revised engine mounts, software changes, and in some cases subframe/damper modifications; some repairs covered under warranty or goodwill.
  - Outâ€‘ofâ€‘warranty mounts or similar NVH fixes: roughly $400â€“$900 at an independent, $700â€“$1,200 at dealer depending on parts replaced.
- What the owner should actually do:
  - Testâ€‘drive at hot idle with A/C on and off; if vibration is severe, either negotiate hard or walk awayâ€”thereâ€™s no magic cheap fix if the car still bothers you after Hondaâ€™s updates.
- NHTSA complaint count: CarComplaints shows 43 reports of â€œVibration at idleâ€ for the 2016 CRâ€‘V alone, and many of those are also mirrored as NHTSA complaints under â€œUnknown or other.â€
- TSB/recall: Honda issued service bulletins aimed at reducing idle vibration (mount and software updates) for 2015â€“2016 CRâ€‘V; check service history to confirm completion.

## 4. A/C Compressor Failure â€“ Multiple Years

- Issue name: A/C blows warm air due to compressor seizure.
- Severity: moderate (comfort issue; not a safety defect unless you live somewhere extreme).
- Affected model years: Documented across many CRâ€‘V years including 2010 and 2020 on RepairPal; realistically seen in multiple 2010â€“2020 years as mileage accumulates.
- Typical mileage onset: 70,000â€“130,000 miles, though some earlier failures exist.
- Symptoms: A/C only blowing warm or ambient air, compressor clutch not engaging, unusual noises when A/C is turned on.
- Repair options and cost:
  - Proper fix is compressor replacement plus dryer/expansion valve and system flush; typically $900â€“$1,400 at independent shops, $1,200â€“$1,800 at a dealer.
- What the owner should actually do:
  - When buying, run the A/C at idle and at highway speeds; if it isnâ€™t cold, budget for a full compressor job or move on to another vehicle.
- NHTSA complaint count: A/C failure is rarely logged as a safety defect, so NHTSA complaint counts are relatively low, but RepairPal shows it as the most commonly reported problem for multiple CRâ€‘V years including 2010 and 2020.
- TSB/recall: No major safety recall specific to the CRâ€‘V A/C compressor; repairs are typically outâ€‘ofâ€‘pocket.

## 5. Door Lock & Miscellaneous Electrical Issues

- Issue name: Sticky or failing door locks and minor electrical faults.
- Severity: minor to moderate (annoyance, possible security concern).
- Affected model years: 2010â€“2014 particularly for sticky locks; sporadic reports later.
- Typical mileage onset: 60,000â€“120,000 miles.
- Symptoms: Door lock not actuating properly from key fob or switch, intermittent operation, in some cases actuator noise without movement.
- Repair options and cost:
  - Replace specific door lock actuator: roughly $250â€“$450 per door at an independent shop, $350â€“$600 at a dealer.
- What the owner should actually do:
  - During inspection, cycle all locks from the fob and switches; if a couple are weak but everything else is clean, use it as a negotiation chip.
- NHTSA complaint count: Several NHTSA complaints reference door lock failures, but counts are modest compared with engine issues; the problem is more about nuisance than safety.
- TSB/recall: Honda has issued lockâ€‘related bulletins on other models; CRâ€‘V tends to be handled through standard repair rather than recall.

------

## Maintenance Schedule Highlights

These points are specific quirks or mustâ€‘knows beyond generic oil changes.

- Engine oil and filter: Hondaâ€™s standard interval is up to 7,500â€“10,000 miles with a maintenance minder, but for 1.5T oilâ€‘dilution engines, many shops and Hondaâ€‘focused bulletins recommend 3,000â€“5,000â€‘mile oil changes, especially in cold/shortâ€‘trip usage.
- CVT fluid service: For CVTâ€‘equipped 2015â€“2020 CRâ€‘V, plan on fluid changes every 30,000â€“60,000 miles using Hondaâ€‘spec CVT fluid (HCFâ€‘2); skipping this is a good way to shorten CVT life.
- Automatic (5â€‘speed) transmission fluid: On 2010â€“2014, change ATF about every 30,000â€“60,000 miles with Honda ATF; highâ€‘mileage units that never had ATF service are a red flag.
- Spark plugs: Directâ€‘injected 2.4 and 1.5T engines typically have iridium plugs with 100,000â€‘mile nominal life, but oil dilution or rich running can foul them earlier; check or replace around 60,000â€“80,000 miles on 1.5T.
- Coolant: Use Hondaâ€‘spec longâ€‘life coolant; typical interval is around 10 years/120,000 miles for the first change, then shorter thereafterâ€”check service records on older CRâ€‘Vs.
- Differential and transfer case fluids (AWD): Rear differential fluid should be changed roughly every 30,000â€“60,000 miles to prevent moaning/groaning noises on turns, a known Honda AWD quirk.
- Valve adjustments: Some Kâ€‘series Honda engines benefit from valve lash checks at higher mileage; if thereâ€™s valve noise on cold start, plan a lash check/adjustment around 120,000 miles.

------

## Typical Annual Ownership Cost

(All numbers are U.S. national ballpark for a 2010â€“2020 CRâ€‘V driven ~15,000 miles/year.)

- Maintenance/repairs: RepairPal estimates about $407 per year on average over the fleet; CarEdge estimates about $763/year over the first 10 years (maintenance plus repairs), frontâ€‘loaded as the vehicle ages.
- Fuel: A typical CRâ€‘V in this era averages roughly midâ€‘20s mpg combined; at 15,000 miles/year and fuel around national average pricing, youâ€™re looking at about $1,500â€“$2,000/year in fuel.
- Insurance: Compact SUV insurance commonly falls in the roughly $1,100â€“$1,600/year range nationally depending on driver profile and state; CRâ€‘V is usually on the lowerâ€‘risk side compared with performance or luxury models.

------

## Depreciation

- Kelley Blue Bookâ€™s depreciation data puts the CRâ€‘V among the top compact SUVs for resale value; a 2020 CRâ€‘V shows around 18â€“25% depreciation over three years with a resale value around $17,600â€“$18,150 depending on trim and mileage.
- A 2010 CRâ€‘V, now much older, still retains value well: KBB lists a current resale value around $5,433, placing it in the top 10% for 2010 SUV depreciation performance.
- Translating this into a practical example: a 2015 CRâ€‘V with an original MSRP in the highâ€‘20k range and about 80,000 miles today typically sells for roughly 45â€“55% of its original price, reflecting Hondaâ€™s strong brand and the CRâ€‘Vâ€™s reputation for reliability.

------

## Sources

- RepairPal â€“ CRâ€‘V reliability, costs, and common problems (A/C compressor, recalls, annual repair cost, vibration, door locks).
- NHTSA / Recalls info â€“ general recall lookup instructions and safetyâ€‘defect recording practices.
- Consumer Reports â€“ overall CRâ€‘V reliability and ownerâ€‘satisfaction trends for 2010â€“2020.
- CarComplaints â€“ detailed complaint patterns for oil consumption (2010), vibration (2015â€“2016), and engine issues by year.
- Independent/technical sources â€“ oilâ€‘dilution explanation and TSB 18â€‘089 summary for 1.5T (Rohnert Park Transmission guide, Center for Auto Safety, classâ€‘action filings, YouTube technical breakdowns).
- CarEdge â€“ longâ€‘term maintenance cost and majorâ€‘repair probability over 10 years.
- Kelley Blue Book â€“ depreciation curves and resale values for 2010 and 2020 CRâ€‘V.
- Miscellaneous Honda/engine spec references â€“ horsepower and engine family overview.
