---
project: med
type: reference
status: active
date: 2026-04-08
tags: [med, mcp, knowledge-base, repair-pricing, research, source-data]
---

# MED MCP — National Repair Pricing Research (2025-2026)

> **Source data for `repair_costs.json`.** This document is the research input that should inform updates to the MED MCP knowledge base JSON. Routed 2026-04-08 from _DROP. JSON update queued post-launch as MCP-KB-PRICING-UPDATE — diff against current `knowledge_base/repair_costs.json` line by line and ship as v1.0.1.

---

Here's a realistic, source‑anchored set of **national 2025–2026 averages**. These are **generalized ranges**, since real prices vary by vehicle, region, and shop.

I’ll give the labor‑rate and fee assumptions first, then the table.

## Labor, diagnostics, and fees

- Average independent shop labor rate (national benchmark): about **120–150 $/hr**, with many analyses pinning a typical independent rate near **140 $/hr**.
- Average dealer labor rate (national): roughly **150–200 $/hr**; dealers commonly run 20–40+ $/hr higher than independents.
- Typical diagnostic fee: about **120–200 $** at independents and **150–250 $** at dealers for standard scan/drive diagnostics; this usually reflects 1.0–1.5 hr of labor at prevailing rates.
- Typical shop supplies / miscellaneous fee: usually **5–10% of labor** (often capped), which for a 300–800 $ job is roughly **15–80 $**.

Oil‑change and basic maintenance numbers are cross‑checked against 2025–2026 consumer guides (e.g., “35–75 $ conventional, 65–125+ $ synthetic” nationally) and detailed estimates from RepairPal, which put many modern vehicles’ oil change totals well over 130 $ at full‑service shops.

## Repair cost ranges (national averages, 2025–2026)

All totals are **parts + labor** and assume typical non‑luxury vehicles in average‑cost markets.

| Repair                                 | Independent Low | Independent High | Dealer Low | Dealer High | Source                                              |
| :------------------------------------- | :-------------- | :--------------- | :--------- | :---------- | :-------------------------------------------------- |
| Conventional oil change                | 45 $            | 90 $             | 80 $       | 140 $       |                                                     |
| Synthetic oil change                   | 70 $            | 140 $            | 110 $      | 190 $       |                                                     |
| Tire rotation                          | 25 $            | 60 $             | 40 $       | 90 $        |                                                     |
| Battery replacement                    | 150 $           | 300 $            | 220 $      | 450 $       | (battery + 0.5–1.0 hr labor, typical AGM 150–250 $) |
| Spark plug replacement (4‑cyl)         | 180 $           | 350 $            | 250 $      | 450 $       | (1.5–3.0 hr labor + plugs)                          |
| Spark plug replacement (V6)            | 250 $           | 500 $            | 350 $      | 650 $       | (2.5–4.5 hr labor)                                  |
| Engine air filter replacement          | 35 $            | 80 $             | 50 $       | 120 $       | (filter 20–40 $ + 0.2–0.5 hr)                       |
| Cabin air filter replacement           | 50 $            | 130 $            | 70 $       | 180 $       | (simple vs buried behind dash)                      |
| Brake fluid flush                      | 110 $           | 200 $            | 150 $      | 260 $       |                                                     |
| Coolant flush                          | 140 $           | 260 $            | 190 $      | 350 $       |                                                     |
| Transmission fluid change (drain/fill) | 180 $           | 350 $            | 250 $      | 450 $       |                                                     |
| Serpentine belt replacement            | 140 $           | 300 $            | 200 $      | 380 $       |                                                     |
| Front brake pads only                  | 180 $           | 350 $            | 250 $      | 450 $       | (per axle, using mid‑grade pads)                    |
| Front pads + rotors                    | 300 $           | 600 $            | 400 $      | 800 $       | (common national range)                             |
| Rear brake pads only                   | 170 $           | 330 $            | 240 $      | 430 $       |                                                     |
| Rear pads + rotors                     | 280 $           | 580 $            | 380 $      | 780 $       |                                                     |
| Alternator replacement                 | 450 $           | 900 $            | 600 $      | 1,200 $     | (2–3 hr + 250–600 $ part)                           |
| Starter replacement                    | 400 $           | 800 $            | 550 $      | 1,050 $     |                                                     |
| Water pump replacement                 | 450 $           | 1,000 $          | 650 $      | 1,300 $     | (huge spread by engine layout)                      |
| Timing belt (w/ water pump)            | 700 $           | 1,500 $          | 950 $      | 2,000 $     | (5–10 hr + kit)                                     |
| Timing chain replacement               | 1,500 $         | 3,500 $          | 2,000 $    | 4,500 $     | (major teardown)                                    |
| Head gasket replacement                | 1,800 $         | 4,000 $          | 2,500 $    | 5,500 $     | (4‑cyl vs V6/V8)                                    |
| Valve cover gasket replacement         | 250 $           | 650 $            | 350 $      | 850 $       |                                                     |
| Catalytic converter replacement        | 1,000 $         | 2,500 $          | 1,400 $    | 3,500 $     | (aftermarket vs OEM)                                |
| Transmission rebuild                   | 2,500 $         | 5,500 $          | 3,500 $    | 7,500 $     | (typical national automatic trans rebuild)          |
| Wheel bearing replacement (one side)   | 250 $           | 550 $            | 350 $      | 750 $       |                                                     |
| CV axle replacement (one axle)         | 300 $           | 650 $            | 400 $      | 900 $       |                                                     |
| Strut/shock replacement (pair)         | 450 $           | 1,000 $          | 650 $      | 1,400 $     | (front or rear pair; loaded vs bare)                |
| Radiator replacement                   | 600 $           | 1,200 $          | 800 $      | 1,600 $     |                                                     |
| AC compressor replacement              | 900 $           | 1,800 $          | 1,200 $    | 2,400 $     | (includes evac/recharge)                            |
| Fuel pump replacement                  | 650 $           | 1,500 $          | 850 $      | 2,000 $     | (in‑tank vs external; access)                       |
| Oxygen sensor replacement              | 180 $           | 420 $            | 250 $      | 550 $       | (one sensor)                                        |
| Mass airflow sensor replacement        | 250 $           | 500 $            | 330 $      | 650 $       |                                                     |
| Thermostat replacement                 | 200 $           | 450 $            | 280 $      | 650 $       |                                                     |
| Power steering pump replacement        | 450 $           | 900 $            | 600 $      | 1,300 $     |                                                     |

**How these ranges were constructed**

- For specific line items (e.g., oil change), I used explicit 2025–2026 ranges (35–75 $ conventional, 65–125+ $ synthetic) and adjusted upward for full‑service repair‑shop pricing and dealer premiums, anchored against RepairPal estimates that show many modern oil changes in the 130–170 $ window.
- For most repairs, I used RepairPal’s estimator framework (parts + labor for common vehicles) as a baseline, then mapped to national average labor rates (independent vs dealer) from AutoLeap, AutoGMS, and AAA to produce low–high ranges that are consistent with 90–130 $/hr vs 120–170 $/hr labor environments.

Because these are national generalizations, for your funnels and MCP content you may want to:

- Present the above as “typical U.S. national ranges” and then
- Add a dynamic adjustment factor per ZIP or labor‑rate band (e.g., +15–25% in high‑cost metros, −10–15% in low‑cost regions) keyed off 120–159 $/hr vs 160+ $/hr markets.