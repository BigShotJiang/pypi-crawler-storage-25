---
project: med
type: reference
status: active
date: 2026-04-17
tags: [med, operator-program, lead-gen, mcp, knowledge-base, json]
---

# Lead Gen DB — Extraction Summary

**Source:** `03_PROJECTS/Auto_Project/Ops/2026-04-14__MED__auto-lead-gen-database__REF__v01.pdf` (61 pages)
**Extractor:** `tools/parse_lead_gen_db.py`
**Extracted:** 2026-04-17

## Output files

- `lead_gen_db.json` — 417 entries, all fields populated
- `lead_gen_db_flagged.json` — 29 subset flagged for verification before outreach

## Extraction totals vs. PDF self-reported counts

| | PDF summary | Extracted | Delta |
|---|---|---|---|
| Auto Repair | 158 | 156 | -2 |
| Dealers | 85 | 81 | -4 |
| Tow | 106 | 104 | -2 |
| Body | 78 | 76 | -2 |
| **Total** | **427** | **417** | **-10** |

**10-entry gap explanation:** some entries in the PDF lack the standard `Name\nAddress:\n...` block structure and were skipped. Most missing entries appear to be under-specified listings in the "BBB listed" secondary sections. These can be added manually during outreach if they come up.

## By county

| County | Extracted |
|---|---|
| Wake | 181 |
| Johnston | 87 |
| Durham | 55 (50 Durham city + 5 RTP Area) |
| Franklin | 27 |
| Harnett | 41 |
| Chatham | 26 |

## By tier (auto-scored)

| Tier | Count | Criteria |
|---|---|---|
| tier-1 | 74 | 4.8+ with 100+ reviews OR 4.9+ at any volume OR 30+ years in business |
| tier-2 | 33 | 4.5+ with 50+ reviews OR 4.7+ with 20+ reviews OR 15+ years in business |
| tier-3 | 281 | Everything else with clean data |
| verify | 29 | Flag detected — must verify before outreach |

## Schema (per entry)

```json
{
  "id": "REPA-RALEIGH-001",
  "category": "repair | dealer | tow | body",
  "county": "Wake",
  "city": "Raleigh",
  "name": "Benchmark Autoworks",
  "address": "227 W Davie St, Raleigh, NC 27601",
  "phone": "(919) 664-8009" | null,
  "web": "benchmarkautoworks.com" | null,
  "rating": 3.8 | null,
  "rating_source": "Yelp | CARFAX | Google | BBB | Website" | null,
  "review_count": 25 | null,
  "established": 2012 | null,
  "years_in_biz": 13 | null,
  "specialty": "Full-service; brakes, engine, transmission, A/C",
  "description": "Full text from PDF",
  "flags": ["no verified phone"] | [],
  "tier": "tier-1 | tier-2 | tier-3 | verify"
}
```

## ID format

`{CAT}-{CITY}-{NNN}` where CAT is first 4 chars of category upper (`REPA`, `DEAL`, `TOW`, `BODY`), CITY is uppercased with hyphens replacing spaces, NNN is 3-digit sequence within that (category, city) bucket.

## Downstream use

This JSON feeds:
- **MED MCP v2 `get_recommended_shops` tool** — lookup by city, category, tier
- **Advisory agent** — local shop recommendations in advisory reports
- **`/ask` web demo** — "Recommended shops near me" response
- **Operator Program outreach** — Tier-1 walk-in prioritization, leave-behind generator

## Tier-1 outreach priority (cross-reference with queue MED-081)

Key operators already locked as outreach targets in DECISION_LOG:
- ✓ **Jeff Barnes Auto Repair** (Angier) — 5.0/261, est. 1988 — tier-1
- ✓ **CDT Automotive** (Fuquay-Varina) — 5.0/800+ — tier-1
- ✓ **Triangle Collision** (Morrisville/Cary) — 4.9/600+ — tier-1
- ✓ **Village Motor Works** (Raleigh) — est. 1946 (80 yrs) — tier-1
- ✓ **Modern Service** (Cary) — est. 1957 (69 yrs) — tier-1
- ✓ **Matt Davis Auto** (Garner) — est. 1964 (62 yrs) — tier-1

Top 15 by rating + review volume (across all categories): see `lead_gen_db.json` filtered where `tier == "tier-1"`.

## Re-running the extractor

```bash
python C:/zbd/tools/parse_lead_gen_db.py
```

Re-run after:
- PDF source updates
- Schema changes (update Python script first)
- Tier scoring rule changes (update `score_tier` function)

## Known limitations

- 10 under-specified entries not captured (see gap table above)
- `specialty` field is first-pass text extract — may need manual cleanup for phrasing
- Rating source may say "Website" when PDF description says "website (247 ratings)" — normalize during outreach if needed
- RTP Area is 5 entries (the explicit "-- RTP AREA" section only). Additional RTP-adjacent businesses are classified under Durham since the PDF doesn't explicitly tag them
- Flagged count (29) slightly over PDF's "27 businesses carry flags" claim — flag detection is conservative/over-catches rather than miss genuine issues
