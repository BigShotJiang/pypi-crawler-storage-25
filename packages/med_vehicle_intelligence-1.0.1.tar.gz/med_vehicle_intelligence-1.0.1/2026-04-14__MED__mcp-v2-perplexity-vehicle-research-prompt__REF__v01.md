---
project: med
type: reference
status: active
date: 2026-04-14
tags: [med, mcp, v2, perplexity, prompt, vehicle-research]
---

# Perplexity Prompts — MED MCP v2 Vehicle Profile Research

**Purpose:** Feed one of these prompts to Perplexity (Pro for single-vehicle depth, Computer agent for batch) to collect the structured data needed for MCP v2 vehicle profiles.

**Output target:** Matches the schema in `knowledge_base/vehicle_profiles_schema.json`. Perplexity returns Markdown sections — Claude normalizes to JSON in a second step.

**Do NOT ask Perplexity to write `what_chris_would_say`** — that's Chris's voice layer, captured via Granola recordings, not AI-generated.

---

## PROMPT 1 — Single Vehicle (deep, one at a time)

**Use:** Perplexity Pro chat. Swap the 4 bracketed fields. Run once per vehicle.

```
You are researching a used vehicle for a buyer's guide written by a 20-year mechanic. The audience is everyday drivers buying used cars in the 2010-2020 model year range, not enthusiasts or collectors. Be blunt, specific, and cite sources inline. Use RepairPal, NHTSA complaint database (nhtsa.gov/recalls), Consumer Reports, Car Complaints (carcomplaints.com), owner forums, and Toyota/Ford/GM TSB bulletins where relevant.

Vehicle: [MAKE] [MODEL]
Generation covered: [GENERATION CODE or YEAR RANGE — e.g. "XV50, 2012-2017" or "10th gen, 2016-2021"]
Body styles: [e.g. "sedan" or "crew cab pickup, regular cab pickup"]

Return your research in exactly these sections. Keep each section tight — facts, not filler.

## Engines
List each available engine and transmission with HP. Include any notable engine problems if variant-specific (e.g. "3.5L V6 is bulletproof, 2.5L I4 has known oil consumption on 2012-2014").

## Reliability Rating
One of: excellent / above_average / average / below_average / poor
Cite source (RepairPal reliability score, CR reliability verdict, etc.)

## Expected Lifespan (miles)
Realistic mileage most owners reach with basic maintenance. Cite specific high-mileage examples if well-documented.

## Sweet Spot for Purchase
Which specific years + mileage range offers the best value for a used buyer? One sentence recommendation with reason.

## Best Years
List the 2-3 best model years within the generation + ONE reason each (post-refresh improvements, issue resolution, etc.)

## Years to Avoid
List the 1-3 worst model years within the generation + ONE reason each. If none are notably bad, say so.

## Common Problems
Identify the top 3-5 issues that affect this generation. For EACH issue, return:
- Issue name
- Severity (minor / cosmetic / moderate / major / dangerous)
- Affected model years (specific, not "all")
- Typical mileage onset range (e.g. "80,000-120,000")
- Symptoms owner notices
- Repair options with cost ranges (independent shop vs dealer where material)
- What the owner should actually do
- NHTSA complaint count for the leading symptom (exact number — look it up)
- TSB or recall number if applicable

## Maintenance Schedule Highlights
List 5-7 maintenance items specific to this vehicle with interval (miles or months) and notes. Include anything non-obvious: specific fluid specs, timing chain vs belt, spark plug life, coolant type/interval. Skip generic intervals that apply to any car.

## Typical Annual Ownership Cost
Give national averages for: insurance, fuel (at ~15K miles/year), maintenance. One cost range for each.

## Depreciation
One paragraph on how this vehicle holds value. Include a specific example: "A 2015 with 80K miles typically sells for X% of original MSRP."

## Sources
List every source you used (inline citations are fine but summarize here).
```

---

## PROMPT 2 — Batch Mode (Perplexity Computer agent)

**Use:** Paste into Perplexity Computer (their agent product). The agent runs the research across multiple vehicles in one job and returns a consolidated output.

```
You are a research agent collecting used-vehicle buyer's guide data for a mechanic's advisory service. Audience: everyday drivers buying used cars 2010-2020. Tone: blunt, specific, cite sources inline.

TASK: Research each of the vehicles listed below. For each vehicle, produce one Markdown document using the EXACT section structure shown in the TEMPLATE below. Save each vehicle's output as a separate file or clearly delimited block.

VEHICLES TO RESEARCH:
1. Toyota Camry — XV50 generation (2012-2017), sedan
2. Honda Civic — 10th gen (2016-2021), sedan
3. Ford F-150 — 13th gen (2015-2020), all cab configurations
4. Chevy Silverado 1500 — K2XX generation (2014-2018), all cab configurations
5. Toyota RAV4 — XA40 generation (2013-2018), SUV
6. Honda CR-V — 5th gen (2017-2022), SUV

[Swap in more vehicles as needed. Run in batches of 5-6 for manageable output size. Full target list of 25 is in the MCP v2 build plan.]

SOURCES: RepairPal, NHTSA complaint database (nhtsa.gov/recalls), Consumer Reports, Car Complaints (carcomplaints.com), owner forums (e.g. CamryForums, F150Forum, CivicX), manufacturer TSBs.

TEMPLATE (use for each vehicle):

# [Make] [Model] — [Generation, Years]

## Engines
[list engines + transmissions + HP, note variant-specific issues]

## Reliability Rating
[excellent / above_average / average / below_average / poor + source]

## Expected Lifespan (miles)
[realistic number + evidence]

## Sweet Spot for Purchase
[specific years + mileage range + one-sentence reason]

## Best Years
- [year] — [reason]
- [year] — [reason]

## Years to Avoid
- [year] — [reason]
(or "None notably worse than others within generation")

## Common Problems (top 3-5)
### Problem 1: [name]
- Severity: [level]
- Affected years: [specific years]
- Typical mileage onset: [range]
- Symptoms: [list]
- Repair options: [option + cost range independent vs dealer]
- Owner action: [what to do]
- NHTSA complaint count: [exact number, cite search]
- TSB/recall: [number if applicable, else "none"]

### Problem 2: [name]
[repeat structure]

## Maintenance Schedule Highlights
- [service] — every [interval] — [notes, fluid spec, etc.]
- [service] — every [interval] — [notes]

## Typical Annual Ownership Cost
- Insurance: $[range]
- Fuel (15K mi/yr): $[range]
- Maintenance: $[range]

## Depreciation
[one paragraph + specific example]

## Sources
[list used]

IMPORTANT:
- Exact numbers for NHTSA counts, do NOT estimate.
- Cite sources inline for every claim.
- Do not pad sections with generic advice that applies to any car.
- If data is genuinely unavailable for a section, write "No reliable data found" rather than fabricating.
```

---

## PROMPT 3 — Single-Data-Type Fill (backfill mode)

**Use:** When a profile is mostly complete but one section is thin. Faster than re-running full research.

```
For the [YEAR] [MAKE] [MODEL], research ONLY the following and return in the exact structure requested:

[CHOOSE ONE]:
a) Top 5 common problems with affected years, NHTSA complaint counts, and owner action recommendations.
b) Manufacturer TSBs and open recalls affecting this generation, with TSB/recall numbers and summary.
c) Specific fluid specs and maintenance intervals (engine oil, transmission fluid, coolant, brake fluid, spark plugs, timing chain/belt).
d) Typical annual ownership cost breakdown (insurance, fuel at 15K mi/yr, maintenance) with national averages.
e) Depreciation trajectory — what % of MSRP does this vehicle retain at 3/5/8/10 years?

Sources: RepairPal, NHTSA, Consumer Reports, manufacturer TSBs, Edmunds. Cite inline.
```

---

## Full Vehicle Target List (25, for batch planning)

Run in batches of 5-6. Suggested batches:

**Batch 1 — existing v1 upgrade (Toyota/Honda anchor):**
Camry, Civic, Corolla, Accord, RAV4, CR-V

**Batch 2 — American sedans + Korean:**
Altima, Elantra, Sonata, Fusion, Malibu, Sentra

**Batch 3 — mid-size SUVs:**
Highlander, Pilot, Explorer, Grand Cherokee, Santa Fe, Escape

**Batch 4 — compact SUVs:**
Equinox, Rogue (remaining from Batch 1 if not done)

**Batch 5 — trucks:**
F-150, Silverado 1500, Sierra 1500, Ram 1500, Tacoma

**Within each batch, specify the exact generation range (2010-2020 window).**

---

## After Research Comes Back

1. Save raw Perplexity output per vehicle in `MCP_Server/knowledge_base/research_raw/[make]-[model]-[gen].md`
2. Claude normalizes each to JSON matching `vehicle_profiles_schema.json`
3. Chris records a 5-10 min Granola session per vehicle covering "what I'd tell a buyer" → transcribed → extracted to `what_chris_would_say` field
4. Validate against schema before merging into the live MCP knowledge base
5. Per MCP v2 plan — ship first 6 upgraded vehicles as v2.0.0, add remaining 19 in point releases
