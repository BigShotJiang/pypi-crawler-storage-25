"""
MED Vehicle Intelligence — Logo Builder

Generates branded PNG logos in multiple sizes for GitHub and other use cases.
Source design matches assets/icon.svg (navy background, M·E·D with D in orange,
subtitle, orange accent bar).

Output:
    icon-512.png        — 512x512, square (matches SVG)
    icon-1024.png       — 1024x1024, retina/high-res
    icon-256.png        — 256x256, smaller use
    social-preview.png  — 1280x640, GitHub social preview banner

Usage:
    python build_logo.py
"""

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

# ============================================================================
# MED Brand colors (match the live site myeverydaydriver.com)
# ============================================================================

NAVY = (13, 27, 42)        # #0D1B2A
ORANGE = (232, 101, 26)    # #E8651A
WHITE = (255, 255, 255)
GRAY = (170, 170, 170)     # subtitle muted gray

# ============================================================================
# Font discovery — try preferred fonts in order, fall back to defaults
# ============================================================================

WINDOWS_FONTS = Path("C:/Windows/Fonts")

BOLD_FONT_CANDIDATES = [
    "arialbd.ttf",      # Arial Bold
    "segoeuib.ttf",     # Segoe UI Bold
    "calibrib.ttf",     # Calibri Bold
    "verdanab.ttf",     # Verdana Bold
]

REGULAR_FONT_CANDIDATES = [
    "arialbd.ttf",
    "segoeuib.ttf",
    "calibrib.ttf",
]


def find_font(candidates):
    for name in candidates:
        path = WINDOWS_FONTS / name
        if path.exists():
            return str(path)
    return None


def load_font(candidates, size):
    font_path = find_font(candidates)
    if font_path:
        return ImageFont.truetype(font_path, size)
    return ImageFont.load_default()


# ============================================================================
# Square icon: 512px (and resize for other sizes)
# ============================================================================

def build_square_icon(size: int) -> Image.Image:
    """Build a square MED icon at the requested pixel size."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Rounded navy background
    corner_radius = int(size * 0.125)  # ~64px on a 512 canvas
    draw.rounded_rectangle(
        [(0, 0), (size, size)],
        radius=corner_radius,
        fill=NAVY,
    )

    # Main "M·E·D" text — D is orange, rest is white
    # Render in two parts so we can color the D separately
    main_font_size = int(size * 0.34)  # ~170px on 512
    main_font = load_font(BOLD_FONT_CANDIDATES, main_font_size)

    text_white = "M\u00B7E\u00B7"  # M·E·
    text_orange = "D"

    # Measure each part
    bbox_white = draw.textbbox((0, 0), text_white, font=main_font)
    bbox_orange = draw.textbbox((0, 0), text_orange, font=main_font)
    bbox_full = draw.textbbox((0, 0), text_white + text_orange, font=main_font)

    full_width = bbox_full[2] - bbox_full[0]
    text_height = bbox_full[3] - bbox_full[1]

    # Vertically center on 56% of canvas height (to leave room for subtitle below)
    main_y_center = int(size * 0.45)
    text_x_start = (size - full_width) // 2 - bbox_full[0]
    text_y = main_y_center - text_height // 2 - bbox_full[1]

    # Draw white portion
    draw.text((text_x_start, text_y), text_white, font=main_font, fill=WHITE)

    # Draw orange "D" right after the white text
    white_width = bbox_white[2] - bbox_white[0]
    draw.text(
        (text_x_start + white_width, text_y),
        text_orange,
        font=main_font,
        fill=ORANGE,
    )

    # Subtitle: "MY EVERYDAY DRIVER"
    subtitle_font_size = int(size * 0.066)  # ~34px on 512
    subtitle_font = load_font(BOLD_FONT_CANDIDATES, subtitle_font_size)
    subtitle_text = "MY EVERYDAY DRIVER"

    sub_bbox = draw.textbbox((0, 0), subtitle_text, font=subtitle_font)
    sub_width = sub_bbox[2] - sub_bbox[0]
    sub_height = sub_bbox[3] - sub_bbox[1]
    sub_x = (size - sub_width) // 2 - sub_bbox[0]
    sub_y = int(size * 0.72) - sub_height // 2 - sub_bbox[1]

    draw.text((sub_x, sub_y), subtitle_text, font=subtitle_font, fill=GRAY)

    # Orange accent bar near the bottom
    bar_y = int(size * 0.83)
    bar_height = max(2, int(size * 0.012))
    bar_inset = int(size * 0.18)
    draw.rounded_rectangle(
        [(bar_inset, bar_y), (size - bar_inset, bar_y + bar_height)],
        radius=bar_height // 2,
        fill=ORANGE,
    )

    return img


# ============================================================================
# Social preview: 1280x640 (GitHub social preview)
# ============================================================================

def build_social_preview() -> Image.Image:
    """Build a 1280x640 GitHub social preview banner.

    Layout: left half = MED wordmark stacked above subtitle (vertically centered).
    Right half = "Vehicle Intelligence for Claude" headline + 4 tool bullets.
    Bottom: orange accent bar + footer.
    """
    width, height = 1280, 640
    img = Image.new("RGB", (width, height), NAVY)
    draw = ImageDraw.Draw(img)

    # ----- Layout constants -----
    LEFT_PADDING = 80
    LEFT_COLUMN_RIGHT = 600   # left half ends here, gives 60px gap before right column
    RIGHT_COLUMN_LEFT = 660
    RIGHT_PADDING = 80
    BOTTOM_BAR_Y = height - 50

    # ============================================================
    # LEFT HALF: M·E·D wordmark + subtitle, vertically centered
    # ============================================================
    wordmark_size = 150  # was 220 — too wide. 150 fits in left column at 80px padding.
    main_font = load_font(BOLD_FONT_CANDIDATES, wordmark_size)
    subtitle_font = load_font(BOLD_FONT_CANDIDATES, 28)

    text_white = "M\u00B7E\u00B7"
    text_orange = "D"
    full_text = text_white + text_orange
    subtitle = "MY EVERYDAY DRIVER"

    # Use anchor="lt" (left-top) for clean positioning instead of bbox math
    # First, measure widths to compute centering inside the left column
    full_w = draw.textlength(full_text, font=main_font)
    white_w = draw.textlength(text_white, font=main_font)
    sub_w = draw.textlength(subtitle, font=subtitle_font)

    left_col_width = LEFT_COLUMN_RIGHT - LEFT_PADDING
    wordmark_x = LEFT_PADDING + (left_col_width - full_w) / 2
    subtitle_x = LEFT_PADDING + (left_col_width - sub_w) / 2

    # Vertical: center wordmark + 30px gap + subtitle as a single block
    block_height = wordmark_size + 30 + 28  # rough total height of the block
    block_top = (height - block_height) / 2 - 20  # nudge up to leave room for footer

    wordmark_y = block_top
    subtitle_y = wordmark_y + wordmark_size + 20

    # Draw wordmark (white M·E· then orange D)
    draw.text((wordmark_x, wordmark_y), text_white, font=main_font, fill=WHITE, anchor="lt")
    draw.text(
        (wordmark_x + white_w, wordmark_y),
        text_orange,
        font=main_font,
        fill=ORANGE,
        anchor="lt",
    )

    # Draw subtitle below wordmark
    draw.text((subtitle_x, subtitle_y), subtitle, font=subtitle_font, fill=GRAY, anchor="lt")

    # ============================================================
    # RIGHT HALF: Headline + tool bullets
    # ============================================================
    headline_font = load_font(BOLD_FONT_CANDIDATES, 46)
    headline_orange_font = load_font(BOLD_FONT_CANDIDATES, 46)
    body_font = load_font(REGULAR_FONT_CANDIDATES, 24)

    # Headline: "Vehicle Intelligence" white over "for Claude" orange
    headline_lines = [
        ("Vehicle Intelligence", WHITE),
        ("for Claude", ORANGE),
    ]
    headline_y_start = 130
    line_spacing = 60

    for i, (text, color) in enumerate(headline_lines):
        draw.text(
            (RIGHT_COLUMN_LEFT, headline_y_start + i * line_spacing),
            text,
            font=headline_font,
            fill=color,
            anchor="lt",
        )

    # Tool list — 4 bullets
    tools = [
        "Repair estimate fairness checks",
        "Maintenance schedules",
        "Fix-or-replace decisions",
        "Shop red flag detection",
    ]
    tools_y_start = headline_y_start + line_spacing * 2 + 40
    bullet_radius = 6
    bullet_text_gap = 22

    for i, tool in enumerate(tools):
        line_y = tools_y_start + i * 42
        # Orange bullet circle
        bullet_cx = RIGHT_COLUMN_LEFT + bullet_radius
        bullet_cy = line_y + 16
        draw.ellipse(
            [
                (bullet_cx - bullet_radius, bullet_cy - bullet_radius),
                (bullet_cx + bullet_radius, bullet_cy + bullet_radius),
            ],
            fill=ORANGE,
        )
        # Tool text
        draw.text(
            (RIGHT_COLUMN_LEFT + bullet_radius * 2 + bullet_text_gap, line_y),
            tool,
            font=body_font,
            fill=WHITE,
            anchor="lt",
        )

    # ============================================================
    # FOOTER: Orange accent bar + footer text
    # ============================================================
    # Footer text first (above the bar)
    footer_font = load_font(REGULAR_FONT_CANDIDATES, 18)
    footer_text = "First automotive MCP server  \u00B7  myeverydaydriver.com"
    footer_w = draw.textlength(footer_text, font=footer_font)
    footer_x = (width - footer_w) / 2
    draw.text(
        (footer_x, BOTTOM_BAR_Y - 30),
        footer_text,
        font=footer_font,
        fill=GRAY,
        anchor="lt",
    )

    # Orange accent bar
    bar_height = 6
    draw.rounded_rectangle(
        [(LEFT_PADDING, BOTTOM_BAR_Y), (width - LEFT_PADDING, BOTTOM_BAR_Y + bar_height)],
        radius=bar_height // 2,
        fill=ORANGE,
    )

    return img


# ============================================================================
# X header (1500x500)
# ============================================================================

def build_x_header() -> Image.Image:
    """Build a 1500x500 X (Twitter) header banner for MED."""
    width, height = 1500, 500
    img = Image.new("RGB", (width, height), NAVY)
    draw = ImageDraw.Draw(img)

    PADDING = 80

    # Left: MED wordmark stacked above subtitle
    wordmark_size = 160
    main_font = load_font(BOLD_FONT_CANDIDATES, wordmark_size)
    subtitle_font = load_font(BOLD_FONT_CANDIDATES, 26)

    text_white = "M\u00B7E\u00B7"
    text_orange = "D"
    full_text = text_white + text_orange
    subtitle = "MY EVERYDAY DRIVER"

    try:
        full_w = draw.textlength(full_text, font=main_font)
        white_w = draw.textlength(text_white, font=main_font)
    except Exception:
        full_w = wordmark_size * 2.4
        white_w = wordmark_size * 1.6

    block_height = wordmark_size + 24 + 26
    block_top = (height - block_height) / 2 - 15

    wordmark_x = PADDING
    wordmark_y = block_top
    subtitle_y = wordmark_y + wordmark_size + 18

    draw.text((wordmark_x, wordmark_y), text_white, font=main_font, fill=WHITE, anchor="lt")
    draw.text(
        (wordmark_x + white_w, wordmark_y),
        text_orange,
        font=main_font,
        fill=ORANGE,
        anchor="lt",
    )
    draw.text((wordmark_x, subtitle_y), subtitle, font=subtitle_font, fill=GRAY, anchor="lt")

    # Right side: tagline + NEW badge + footer
    tagline_font = load_font(BOLD_FONT_CANDIDATES, 36)
    badge_font = load_font(BOLD_FONT_CANDIDATES, 22)
    footer_font = load_font(BOLD_FONT_CANDIDATES, 18)

    right_x = 720
    right_block_top = 110

    draw.text(
        (right_x, right_block_top),
        "The Trusted Second Opinion",
        font=tagline_font,
        fill=WHITE,
        anchor="lt",
    )
    draw.text(
        (right_x, right_block_top + 48),
        "for Everyday Drivers",
        font=tagline_font,
        fill=ORANGE,
        anchor="lt",
    )

    # NEW badge
    badge_x = right_x
    badge_y = right_block_top + 130
    badge_text = "NEW: FREE AI VEHICLE ADVISOR"
    try:
        badge_w = draw.textlength(badge_text, font=badge_font) + 32
    except Exception:
        badge_w = 380
    draw.rounded_rectangle(
        [(badge_x, badge_y), (badge_x + badge_w, badge_y + 38)],
        radius=4,
        fill=ORANGE,
    )
    draw.text(
        (badge_x + 16, badge_y + 6),
        badge_text,
        font=badge_font,
        fill=WHITE,
        anchor="lt",
    )

    draw.text(
        (right_x, badge_y + 60),
        "myeverydaydriver.com  \u00B7  Wake County, NC",
        font=footer_font,
        fill=GRAY,
        anchor="lt",
    )

    # Orange accent bar at the bottom
    bar_y = height - 30
    bar_height = 5
    draw.rounded_rectangle(
        [(PADDING, bar_y), (width - PADDING, bar_y + bar_height)],
        radius=bar_height // 2,
        fill=ORANGE,
    )

    return img


# ============================================================================
# Main
# ============================================================================

def main():
    out_dir = Path(__file__).parent
    print(f"Output directory: {out_dir}")

    # Square icons at multiple sizes
    for size in [256, 512, 1024]:
        img = build_square_icon(size)
        out_path = out_dir / f"icon-{size}.png"
        img.save(out_path, "PNG", optimize=True)
        print(f"  [ok]{out_path.name}  ({out_path.stat().st_size:,} bytes)")

    # GitHub social preview
    social = build_social_preview()
    social_path = out_dir / "social-preview.png"
    social.save(social_path, "PNG", optimize=True)
    print(f"  [ok]{social_path.name}  ({social_path.stat().st_size:,} bytes)")

    # X header banner
    x_header = build_x_header()
    x_header_path = out_dir / "x-header.png"
    x_header.save(x_header_path, "PNG", optimize=True)
    print(f"  [ok]{x_header_path.name}  ({x_header_path.stat().st_size:,} bytes)")

    # Also overwrite the existing icon-test if any
    test_path = out_dir / "icon_test.png"
    if test_path.exists():
        test_path.unlink()

    print("\nDone.")


if __name__ == "__main__":
    main()
