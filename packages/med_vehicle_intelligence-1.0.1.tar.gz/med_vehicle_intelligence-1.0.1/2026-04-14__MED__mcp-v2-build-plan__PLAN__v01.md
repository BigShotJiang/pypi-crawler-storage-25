---
project: med
type: plan
status: active
date: 2026-04-14
tags: [med, mcp, plan, v2, vehicle-profiles]
---

# MED MCP v2 Build Plan

**Scope:** Evolve MED Vehicle Intelligence MCP from generic repair advisor (v1.0.0) into vehicle-specific ownership intelligence (v2.0.0). Add 25 vehicle profiles + new tool + enhance existing tools.

**Status:** Plan approved for execution. Schema for v2 already exists; this doc sequences data build, tool implementation, and release.

---

## Why v2

v1 answers generic questions well ("Is this brake price fair?"). It does NOT answer vehicle-specific questions the way a real mechanic would ("Your 2014 Camry with 110K miles asking for piston ring replacement — that's the known oil consumption TSB, here's what to verify before paying $3,200").

**The moat:** Chris's direct mechanic experience layered onto structured data (RepairPal + NHTSA + Consumer Reports). Every profile ends in a `what_chris_would_say` field — blunt, specific, practical. **That voice is the product.** Generic MCPs scrape Wikipedia. MED MCP has a human behind it.

**Downstream unlocks:**
- Advisory agent pipeline (MED-082 sequence) uses vehicle profiles as its knowledge core
- 27 draft articles cross-link to MCP profiles (SEO + AEO compounding)
- `/ask` web demo at `myeverydaydriver.com/ask` becomes genuinely useful, not a Wikipedia wrapper
- Fleet members get premium version (tool gate in v2.1+)

---

## Release Sequence

### v1.0.1 — Pricing hotfix (ship FIRST, before v2 work starts)
**Scope:** Update `repair_costs.json` with national 2025-2026 ranges per existing reference doc at `2026-04-08__MED__national-repair-pricing-2025-2026__REF__v01.md` (RepairPal-anchored, dealer vs independent split).
**Why first:** Already has source data, quick win, doesn't need v2 infrastructure. Currently queued as `MCP-KB-PRICING-UPDATE`.
**Gate:** Wait until MCP launch posts settle (per existing note — don't modify KB during launch window).
**Effort:** 2-3 hours (data diff + JSON update + version bump + Railway push + Smithery scan).

### v2.0.0 — Vehicle profiles (this plan)
**Scope:** 25 vehicle profiles + `get_vehicle_profile()` tool + minor enhancements to existing 4 tools to leverage profiles when available.
**Effort:** ~40-60 hours over 4-6 weeks (primarily data collection).

### v2.1.0 — Trusted shops (separate plan, later)
**Scope:** Add `find_trusted_shops(city)` tool backed by Operator Program installed partners (from lead-gen DB + MED-082 installs).
**Gate:** 5+ shops installed via Operator Program with signed partnership.
**Why separate:** Needs real operator installs first; shipping early would be a Yelp wrapper, not a moat.

---

## v2.0.0 Scope — Locked

### New Tool: `get_vehicle_profile(make, model, year)`

**Input:** make, model, year (all strings)
**Logic:**
1. Normalize input (lowercase, strip whitespace, handle common abbreviations — "F150" vs "F-150")
2. Find matching generation by year (e.g. Camry 2014 → XV50 generation)
3. Return full profile as formatted text (not JSON — per v1 convention)
4. If no match: return fallback with "We have limited data on this exact vehicle. Here's what we know about this class..."

**Output sections** (from existing schema):
- Make/Model/Generation/Years
- Engines + transmissions
- Reliability rating + expected lifespan
- **Sweet spot for purchase** (e.g. "2014-2015 with 60K-90K miles") — this is gold for advisory calls
- Best years / Years to avoid (with reason)
- Common problems (with affected years, symptoms, repair options, owner action, NHTSA complaint count)
- Maintenance schedule highlights
- Typical annual ownership cost (insurance + fuel + maintenance)
- Depreciation notes
- **`what_chris_would_say`** — voice-driven practical summary

### Enhancement: existing 4 tools use profiles when available

1. **`get_maintenance_schedule`** → if vehicle has profile, use profile's `maintenance_schedule_highlights` (more specific than generic intervals)
2. **`should_i_fix_or_replace`** → use profile's `expected_lifespan_miles` + `depreciation_notes` for smarter score
3. **`check_repair_estimate`** → check if repair matches a known `common_problems` entry; flag if so
4. **`check_shop_red_flags`** → no change (shop behavior isn't vehicle-specific)

All enhancements are additive — backward compatible with v1 callers.

### Data: 25 Vehicle Profiles

**Already in v1 (6):** Camry, F-150, Civic, Silverado, RAV4, CR-V — need profile upgrade from light data to full schema.

**Net new (19):** see table below. 2010-2020 window = 10-15 year old used cars = MED's advisory sweet spot.

| # | Vehicle | Gen Range 2010-2020 | Priority |
|---|---|---|---|
| 1 | Toyota Camry | XV40, XV50, XV70 | EXISTS — upgrade |
| 2 | Honda Civic | 9th gen, 10th gen | EXISTS — upgrade |
| 3 | Toyota Corolla | E140, E170, E210 | NEW |
| 4 | Honda Accord | 9th gen, 10th gen | EXISTS — upgrade |
| 5 | Nissan Altima | L33, L34 | NEW |
| 6 | Hyundai Elantra | 5th gen, 6th gen | NEW |
| 7 | Hyundai Sonata | 6th gen, 7th gen, 8th gen | NEW |
| 8 | Ford Fusion | 2nd gen | NEW |
| 9 | Chevy Malibu | 8th gen, 9th gen | NEW |
| 10 | Nissan Sentra | B17, B18 | NEW |
| 11 | Toyota RAV4 | XA30, XA40, XA50 | EXISTS — upgrade |
| 12 | Honda CR-V | 4th gen, 5th gen | EXISTS — upgrade |
| 13 | Ford Escape | 3rd gen, 4th gen | NEW |
| 14 | Chevy Equinox | 2nd gen, 3rd gen | NEW |
| 15 | Nissan Rogue | S35, T32 | NEW |
| 16 | Toyota Highlander | XU40, XU50 | NEW |
| 17 | Honda Pilot | 2nd gen, 3rd gen | NEW |
| 18 | Ford Explorer | 5th gen, 6th gen | NEW |
| 19 | Jeep Grand Cherokee | WK2 | NEW |
| 20 | Hyundai Santa Fe | 3rd gen, 4th gen | NEW |
| 21 | Ford F-150 | 12th gen, 13th gen | EXISTS — upgrade |
| 22 | Chevy Silverado 1500 | GMT900, K2XX, T1XX | EXISTS — upgrade |
| 23 | Ram 1500 | 4th gen, 5th gen | NEW |
| 24 | Toyota Tacoma | 2nd gen, 3rd gen | NEW |
| 25 | GMC Sierra 1500 | GMT900, K2XX, T1XX | NEW |

**Why this list:** top 25 by US sales volume 2010-2020, weighted toward non-luxury (MED audience), balanced across sedans (10) / SUVs (10) / trucks (5).

---

## Build Phases

### Phase A — Data Collection (30-40 hours total, batchable)

**Method:** Perplexity Pro + Chris voice layer.

**Per vehicle workflow** (~1-2 hours):
1. Perplexity research prompt (templated): pull RepairPal reliability, NHTSA complaints by year, Consumer Reports trend, owner forum top issues, TSBs
2. Fill structured fields: reliability_rating, expected_lifespan, best/worst years, common_problems (3-5 entries), maintenance, cost, depreciation
3. **Chris adds `what_chris_would_say`** — the voice layer. Could be recorded as a Granola session and transcribed (synergy with content priority #1).
4. Normalize to JSON per schema
5. Validate against schema with a JSON schema validator

**Batching:** 5 vehicles per session × 5 sessions = 25 profiles. Prioritize v1 upgrades first (6 vehicles already have light data, faster to complete).

**Granola synergy:** The `what_chris_would_say` field is perfect Granola rant material. Chris can record "Talk me through a used 2014 Camry, what would you tell a buyer?" — transcribe → extract to field → cross-use as podcast/article content. **One recording serves three outputs: MCP profile + article + social clip.**

### Phase B — Tool Implementation (4-6 hours)

1. `src/med_vehicle_intelligence/tools/vehicle_profile.py` — implements `get_vehicle_profile`
2. Generation-matching logic (year → generation):
   ```python
   def _match_generation(make, model, year):
       # lookup in vehicle_profiles.json
       # handle boundary years, variants (hybrid), truck configs
   ```
3. Formatted text output (per v1 convention — AI adapts presentation)
4. Edge cases: unknown vehicle, year outside coverage (2010-2020), commercial variants (F-150 vs F-150 SVT)
5. Register tool in `server.py` or equivalent entrypoint

### Phase C — Tool Enhancements (2-3 hours)

Light additive changes to 3 existing tools — do NOT break v1 callers.

1. `get_maintenance_schedule` — if profile available, prefer profile's maintenance over generic
2. `should_i_fix_or_replace` — add profile's lifespan/depreciation to scoring
3. `check_repair_estimate` — flag match against profile's `common_problems`

### Phase D — Tests (2-3 hours)

- `tests/test_vehicle_profile.py` — unit tests for generation matching, edge cases, unknown vehicles
- Update existing test files to cover profile-enhanced behavior
- Integration test: full query flow with all profiles loaded

### Phase E — Release (2-3 hours)

1. Version bump: `pyproject.toml` (0.1.0 → 2.0.0), `smithery.yaml`, `.well-known/mcp/server-card.json`
2. Changelog entry in README
3. Push to `zimconsulting-ops/med-vehicle-intelligence`
4. Railway auto-deploy
5. Smithery rescan (should pick up new tool automatically via static server-card.json)
6. Launch post across 3 X accounts + LinkedIn ("MCP v2 live — now answers vehicle-specific questions for 25 most common US cars")
7. Update `myeverydaydriver.com/ask` web demo when ready to showcase v2 capability

---

## Ownership + Time Estimate

| Phase | Owner | Hours | Dependencies |
|---|---|---|---|
| A. Data collection (25 profiles) | Claude + Chris voice layer | 30-40 | Granola rants help but not blocking |
| B. New tool implementation | Claude | 4-6 | Phase A has first 5 profiles ready |
| C. Existing tool enhancements | Claude | 2-3 | Phase B done |
| D. Tests | Claude | 2-3 | Phase B + C done |
| E. Release | Chris + Claude | 2-3 | All prior |

**Total:** ~40-55 hours, across 4-6 weeks at 8-10 hrs/wk.

**Critical-path parallel tracks:**
- Chris: Granola recordings feed `what_chris_would_say` fields (unblocks data depth)
- Claude: Phase A can start with top 5 vehicles (Camry, Civic, F-150, Corolla, RAV4) immediately — those already exist in v1 so just need upgrade

---

## Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Data drift — RepairPal/NHTSA change after collection | Timestamp each profile's `last_updated` field; plan annual refresh cycle |
| Generation boundary bugs (e.g. 2014 Camry — XV40 or XV50?) | Unit tests + fallback to "transition year" response |
| AI hallucination on NHTSA complaint counts | Always cite exact NHTSA search URL + pull count manually for each profile |
| Breaking v1 callers | All v2 changes are additive; existing tools return same format unless profile found |
| Chris voice layer blocks everything | Collect voice layer in parallel; ship without it if needed (mark profile as `voice_layer_pending`) |
| Smithery scan fails on v2 tool registration | Test locally with MCP inspector first; static server-card.json fallback already works |

---

## What This Unlocks

Once v2.0.0 ships:

1. **Advisory agent pipeline can start** (MED-082 sequence) — profiles are the data core
2. **27 draft articles cross-link to MCP** — SEO/AEO compounding, each article points to the relevant MCP profile for "live advice"
3. **`/ask` web demo becomes genuinely useful** — not a generic Claude wrapper
4. **Programmatic SEO** (`/costs/[city]/[repair]`) can layer shop recommendations (v2.1)
5. **Content multiplier** — each Granola recording feeds profile + article + social + podcast prep simultaneously

---

## First Move

**Before v2 work starts:**
1. Ship v1.0.1 pricing hotfix (2-3 hours, queued already)
2. Confirm MCP launch posts have settled (per existing note)

**Then v2 kickoff:**
1. Upgrade the 6 existing vehicles to full schema (fastest batch — data partially exists)
2. In parallel: Chris records "What I'd tell a buyer" Granola sessions for each of those 6 vehicles (5-10 min each, feeds `what_chris_would_say`)
3. After first 6 complete and profile format is proven, batch the remaining 19
