import zipfile
from collections import Counter
import sys
import glob

wheels = glob.glob('dist/*.whl')
if not wheels:
    print("No wheel found in dist/")
    sys.exit(1)

for wheel in wheels:
    print(f"\n=== {wheel} ===")
    z = zipfile.ZipFile(wheel)
    names = z.namelist()
    counter = Counter(names)
    dups = {k: v for k, v in counter.items() if v > 1}
    print(f"Total entries: {len(names)}")
    print(f"Unique entries: {len(set(names))}")
    if dups:
        print(f"\nDUPLICATES FOUND ({len(dups)}):")
        for path, count in dups.items():
            print(f"  [{count}x] {path}")
    else:
        print("\nNo duplicates.")
