use std::path::PathBuf;
use std::sync::Arc;

use anyhow::{Context, Result};
use jieba_rs::Jieba;
use tantivy::collector::TopDocs;
use tantivy::query::{BooleanQuery, Occur, QueryParser, TermQuery};
use tantivy::schema::*;
use tantivy::tokenizer::*;
use tantivy::{Index, IndexReader, IndexWriter, ReloadPolicy, TantivyDocument, Term};
use tracing::{info, warn};

use super::{synonyms, GLOBAL_JIEBA};
use crate::{SearchResult, SearchResultMetadata, TextChunk};
use cangjie_core::config::INDEX_WRITER_HEAP_BYTES;

const TOKENIZER_NAME: &str = "jieba";

// -- Jieba Tokenizer for Tantivy ---------------------------------------------

#[derive(Clone)]
struct JiebaTokenizer {
    jieba: Arc<Jieba>,
}

impl JiebaTokenizer {
    fn new() -> Self {
        Self {
            jieba: Arc::clone(&GLOBAL_JIEBA),
        }
    }
}

impl Tokenizer for JiebaTokenizer {
    type TokenStream<'a> = JiebaTokenStream;

    fn token_stream<'a>(&'a mut self, text: &'a str) -> Self::TokenStream<'a> {
        let lower = text.to_lowercase();
        let words = self.jieba.cut_for_search(&lower, true);
        let mut tokens = Vec::new();
        let mut offset = 0;

        for word in words {
            let word = word.trim();
            if word.is_empty() {
                continue;
            }
            tokens.push(Token {
                offset_from: offset,
                offset_to: offset + word.len(),
                position: tokens.len(),
                text: word.to_string(),
                position_length: 1,
            });
            offset += word.len();
        }

        JiebaTokenStream {
            tokens,
            index: 0,
            token: Token::default(),
        }
    }
}

struct JiebaTokenStream {
    tokens: Vec<Token>,
    index: usize,
    token: Token,
}

impl TokenStream for JiebaTokenStream {
    fn advance(&mut self) -> bool {
        if self.index < self.tokens.len() {
            self.token = self.tokens[self.index].clone();
            self.index += 1;
            true
        } else {
            false
        }
    }

    fn token(&self) -> &Token {
        &self.token
    }

    fn token_mut(&mut self) -> &mut Token {
        &mut self.token
    }
}

// -- BM25 Store --------------------------------------------------------------

pub struct BM25Store {
    index_dir: PathBuf,
    index: Option<Index>,
    reader: Option<IndexReader>,
    schema: Schema,
    field_text: Field,
    field_file_path: Field,
    field_category: Field,
    field_topic: Field,
    field_title: Field,
    field_has_code: Field,
    field_chunk_id: Field,
}

impl BM25Store {
    pub fn new(index_dir: PathBuf) -> Self {
        let mut schema_builder = Schema::builder();

        let text_options = TextOptions::default()
            .set_indexing_options(
                TextFieldIndexing::default()
                    .set_tokenizer(TOKENIZER_NAME)
                    .set_index_option(IndexRecordOption::WithFreqsAndPositions),
            )
            .set_stored();

        let field_text = schema_builder.add_text_field("text", text_options);
        let field_file_path = schema_builder.add_text_field("file_path", STRING | STORED);
        let field_category = schema_builder.add_text_field("category", STRING | STORED);
        let field_topic = schema_builder.add_text_field("topic", STRING | STORED);
        let field_title = schema_builder.add_text_field("title", STRING | STORED);
        let field_has_code = schema_builder.add_text_field("has_code", STRING | STORED);
        let field_chunk_id = schema_builder.add_text_field("chunk_id", STRING | STORED);

        let schema = schema_builder.build();

        Self {
            index_dir,
            index: None,
            reader: None,
            schema,
            field_text,
            field_file_path,
            field_category,
            field_topic,
            field_title,
            field_has_code,
            field_chunk_id,
        }
    }

    fn register_tokenizer(index: &Index) {
        let tokenizer = JiebaTokenizer::new();
        index
            .tokenizers()
            .register(TOKENIZER_NAME, TextAnalyzer::builder(tokenizer).build());
    }

    pub fn is_indexed(&self) -> bool {
        self.index_dir.exists() && self.index_dir.join("meta.json").exists()
    }

    pub async fn build_from_chunks(&mut self, chunks: &[TextChunk]) -> Result<()> {
        if chunks.is_empty() {
            warn!("No chunks provided for BM25 indexing.");
            return Ok(());
        }

        let chunks = chunks.to_vec();
        let index_dir = self.index_dir.clone();
        let schema = self.schema.clone();
        let ft = self.field_text;
        let ffp = self.field_file_path;
        let fc = self.field_category;
        let fto = self.field_topic;
        let fti = self.field_title;
        let fhc = self.field_has_code;
        let fci = self.field_chunk_id;

        let (index, reader) =
            tokio::task::spawn_blocking(move || -> Result<(Index, IndexReader)> {
                info!("Building BM25 index from {} chunks...", chunks.len());
                std::fs::create_dir_all(&index_dir)?;

                let index = Index::create_in_dir(&index_dir, schema)
                    .context("Failed to create tantivy index")?;
                Self::register_tokenizer(&index);

                let mut writer: IndexWriter = index
                    .writer(INDEX_WRITER_HEAP_BYTES)
                    .context("Failed to create index writer")?;

                for chunk in &chunks {
                    let mut doc = TantivyDocument::new();
                    doc.add_text(ft, &chunk.text);
                    doc.add_text(ffp, &chunk.metadata.file_path);
                    doc.add_text(fc, &chunk.metadata.category);
                    doc.add_text(fto, &chunk.metadata.topic);
                    doc.add_text(fti, &chunk.metadata.title);
                    doc.add_text(
                        fhc,
                        if chunk.metadata.has_code {
                            "true"
                        } else {
                            "false"
                        },
                    );
                    doc.add_text(fci, &chunk.metadata.chunk_id);
                    writer.add_document(doc)?;
                }

                writer.commit()?;
                let reader = index
                    .reader_builder()
                    .reload_policy(ReloadPolicy::Manual)
                    .try_into()?;

                info!("BM25 index built and saved to {:?}", index_dir);
                Ok((index, reader))
            })
            .await
            .context("BM25 build task panicked")??;

        self.index = Some(index);
        self.reader = Some(reader);
        Ok(())
    }

    pub async fn load(&mut self) -> Result<bool> {
        if !self.is_indexed() {
            return Ok(false);
        }

        let index_dir = self.index_dir.clone();

        let (index, reader) =
            tokio::task::spawn_blocking(move || -> Result<(Index, IndexReader)> {
                let index =
                    Index::open_in_dir(&index_dir).context("Failed to open tantivy index")?;
                Self::register_tokenizer(&index);
                let reader = index
                    .reader_builder()
                    .reload_policy(ReloadPolicy::Manual)
                    .try_into()?;
                info!("BM25 index loaded from {:?}", index_dir);
                Ok((index, reader))
            })
            .await
            .context("BM25 load task panicked")??;

        self.index = Some(index);
        self.reader = Some(reader);
        Ok(true)
    }

    pub async fn search(
        &self,
        query: &str,
        top_k: usize,
        category: Option<&str>,
    ) -> Result<Vec<SearchResult>> {
        let index = match &self.index {
            Some(idx) => idx.clone(),
            None => return Ok(Vec::new()),
        };
        let reader = match &self.reader {
            Some(r) => r.clone(),
            None => return Ok(Vec::new()),
        };

        let query = query.to_string();
        let category = category.map(|s| s.to_string());
        let field_text = self.field_text;
        let field_file_path = self.field_file_path;
        let field_category = self.field_category;
        let field_topic = self.field_topic;
        let field_title = self.field_title;
        let field_has_code = self.field_has_code;
        let field_chunk_id = self.field_chunk_id;
        let jieba = Arc::clone(&GLOBAL_JIEBA);

        tokio::task::spawn_blocking(move || {
            // Tokenize query with jieba for better CJK search
            let query_lower = query.to_lowercase();
            let tokens: Vec<&str> = jieba
                .cut_for_search(&query_lower, true)
                .into_iter()
                .filter(|w| !w.trim().is_empty())
                .collect();

            if tokens.is_empty() {
                return Ok(Vec::new());
            }

            let query_str = synonyms::expand_query(&tokens);

            let searcher = reader.searcher();
            let query_parser = QueryParser::for_index(&index, vec![field_text]);

            let text_query = query_parser
                .parse_query(&query_str)
                .unwrap_or_else(|_| Box::new(tantivy::query::AllQuery));

            // When category is specified, use BooleanQuery to pre-filter at the index level
            let final_query: Box<dyn tantivy::query::Query> = if let Some(ref cat) = category {
                let category_term = Term::from_field_text(field_category, cat);
                let category_query = TermQuery::new(category_term, IndexRecordOption::Basic);
                Box::new(BooleanQuery::new(vec![
                    (Occur::Must, text_query),
                    (Occur::Must, Box::new(category_query)),
                ]))
            } else {
                text_query
            };

            let top_docs = searcher
                .search(&final_query, &TopDocs::with_limit(top_k))
                .context("Search failed")?;

            let mut results = Vec::new();
            for (score, doc_addr) in top_docs {
                let doc: TantivyDocument = searcher.doc(doc_addr)?;

                let file_path = doc
                    .get_first(field_file_path)
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let cat = doc
                    .get_first(field_category)
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let topic = doc
                    .get_first(field_topic)
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let title = doc
                    .get_first(field_title)
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let has_code = doc
                    .get_first(field_has_code)
                    .and_then(|v| v.as_str())
                    .unwrap_or("false")
                    == "true";
                let text = doc
                    .get_first(field_text)
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let chunk_id = doc
                    .get_first(field_chunk_id)
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                results.push(SearchResult {
                    text,
                    score: score as f64,
                    metadata: SearchResultMetadata {
                        file_path,
                        category: cat,
                        topic,
                        title,
                        has_code,
                        chunk_id,
                    },
                });
            }

            Ok(results)
        })
        .await
        .context("BM25 search task panicked")?
    }
}
