pub mod client;
pub mod config;
pub mod dependency;
pub mod tools;
pub mod transport;
pub mod types;
pub mod utils;

use std::path::{Path, PathBuf};
use std::sync::Arc;

use tokio::sync::RwLock;
use tracing::{error, info};

use crate::client::CangjieClient;
use crate::config::{build_init_options, LSPSettings};

static LSP_CLIENT: once_cell::sync::Lazy<Arc<RwLock<Option<CangjieClient>>>> =
    once_cell::sync::Lazy::new(|| Arc::new(RwLock::new(None)));

fn detect_cangjie_home_from_vscode_settings(workspace: &Path) -> Option<PathBuf> {
    let settings_path = workspace.join(".vscode").join("settings.json");
    let content = std::fs::read_to_string(settings_path).ok()?;
    let root: serde_json::Value = serde_json::from_str(&content).ok()?;
    let root_obj = root.as_object()?;

    for (key, value) in root_obj {
        if !key.starts_with("terminal.integrated.env") {
            continue;
        }

        let env_obj = match value.as_object() {
            Some(env_obj) => env_obj,
            None => continue,
        };

        let sdk_path = match env_obj.get("CANGJIE_HOME").and_then(|v| v.as_str()) {
            Some(sdk_path) if !sdk_path.trim().is_empty() => sdk_path,
            _ => continue,
        };

        return Some(PathBuf::from(sdk_path));
    }

    None
}

fn detect_cangjie_home(workspace: &Path) -> Option<PathBuf> {
    std::env::var("CANGJIE_HOME")
        .ok()
        .filter(|value| !value.trim().is_empty())
        .map(PathBuf::from)
        .or_else(|| detect_cangjie_home_from_vscode_settings(workspace))
}

/// Create and start a new LSP client from settings.
/// Shared by both `init` (global singleton) and `LspPool` (per-workspace).
pub async fn start_client(settings: &LSPSettings) -> Result<CangjieClient, String> {
    let validation_errors = settings.validate();
    if !validation_errors.is_empty() {
        return Err(format!(
            "Invalid LSP settings: {}",
            validation_errors.join("; ")
        ));
    }

    if let Some(ref log_path) = settings.log_path {
        if let Err(e) = std::fs::create_dir_all(log_path) {
            tracing::warn!(
                "Failed to create LSP log directory {}: {}",
                log_path.display(),
                e
            );
        }
    }

    let cache_dir = settings.workspace_path.join(".cache").join("lsp");
    if let Err(e) = std::fs::create_dir_all(&cache_dir) {
        tracing::warn!(
            "Failed to create LSP cache directory {}: {}",
            cache_dir.display(),
            e
        );
    }

    let (init_options, require_path) = build_init_options(settings);
    CangjieClient::start(settings, &init_options, &require_path)
        .await
        .map_err(|e| format!("Failed to start LSP client: {e}"))
}

/// Initialize the global LSP client.
pub async fn init(settings: LSPSettings) -> bool {
    match start_client(&settings).await {
        Ok(client) => {
            *LSP_CLIENT.write().await = Some(client);
            info!("LSP client initialized successfully");
            if let Some(ref log_path) = settings.log_path {
                info!("LSP server log directory: {}", log_path.display());
            }
            true
        }
        Err(e) => {
            error!("{e}");
            false
        }
    }
}

/// Shutdown the global LSP client.
pub async fn shutdown() {
    let mut guard = LSP_CLIENT.write().await;
    if let Some(ref client) = *guard {
        let _ = client.shutdown().await;
    }
    *guard = None;
    info!("LSP client shutdown complete");
}

/// Check if the LSP client is available.
pub fn is_available() -> bool {
    let workspace = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    detect_cangjie_home(&workspace).is_some()
}

/// Get a reference to the global LSP client (read lock).
pub async fn get_client() -> Option<tokio::sync::RwLockReadGuard<'static, Option<CangjieClient>>> {
    let guard = LSP_CLIENT.read().await;
    if guard.is_some() {
        Some(guard)
    } else {
        None
    }
}

/// Try to auto-detect and create LSP settings.
pub fn detect_settings(workspace_path: Option<PathBuf>) -> Option<LSPSettings> {
    let workspace = workspace_path
        .unwrap_or_else(|| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));
    let sdk_path = detect_cangjie_home(&workspace)?;

    let log_path = std::env::temp_dir().join(format!("cangjie-lsp-{}", std::process::id()));

    Some(LSPSettings {
        sdk_path,
        workspace_path: workspace,
        log_enabled: true,
        log_path: Some(log_path),
        init_timeout_ms: 45000,
        disable_auto_import: true,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    fn write_workspace_settings(workspace: &Path, content: &str) {
        let vscode_dir = workspace.join(".vscode");
        std::fs::create_dir_all(&vscode_dir).unwrap();
        std::fs::write(vscode_dir.join("settings.json"), content).unwrap();
    }

    #[test]
    fn test_is_available_checks_env() {
        temp_env::with_var("CANGJIE_HOME", Some("/tmp/fake-cangjie-sdk"), || {
            assert!(is_available());
        });
        temp_env::with_var("CANGJIE_HOME", None::<&str>, || {
            assert!(!is_available());
        });
    }

    #[test]
    fn test_detect_settings_no_cangjie_home() {
        temp_env::with_var("CANGJIE_HOME", None::<&str>, || {
            let result = detect_settings(Some(PathBuf::from("/tmp/test")));
            assert!(result.is_none());
        });
    }

    #[test]
    fn test_detect_settings_with_cangjie_home() {
        temp_env::with_var("CANGJIE_HOME", Some("/tmp/fake-cangjie-sdk"), || {
            let result = detect_settings(Some(PathBuf::from("/tmp/workspace")));
            assert!(result.is_some());

            let settings = result.unwrap();
            assert_eq!(settings.sdk_path, PathBuf::from("/tmp/fake-cangjie-sdk"));
            assert_eq!(settings.workspace_path, PathBuf::from("/tmp/workspace"));
            assert!(settings.log_enabled);
            assert!(settings.log_path.is_some());
            assert_eq!(settings.init_timeout_ms, 45000);
            assert!(settings.disable_auto_import);
        });
    }

    #[test]
    fn test_detect_settings_falls_back_to_vscode_terminal_env() {
        let temp_dir = TempDir::new().unwrap();
        write_workspace_settings(
            temp_dir.path(),
            r#"{
  "terminal.integrated.env.windows": {
    "CANGJIE_HOME": "/from/vscode/settings"
  }
}"#,
        );

        temp_env::with_var("CANGJIE_HOME", None::<&str>, || {
            let result = detect_settings(Some(temp_dir.path().to_path_buf()));
            assert!(result.is_some());
            assert_eq!(
                result.unwrap().sdk_path,
                PathBuf::from("/from/vscode/settings")
            );
        });
    }

    #[test]
    fn test_detect_settings_env_takes_precedence_over_vscode_fallback() {
        let temp_dir = TempDir::new().unwrap();
        write_workspace_settings(
            temp_dir.path(),
            r#"{
  "terminal.integrated.env.windows": {
    "CANGJIE_HOME": "/from/vscode/settings"
  }
}"#,
        );

        temp_env::with_var("CANGJIE_HOME", Some("/from/env"), || {
            let result = detect_settings(Some(temp_dir.path().to_path_buf()));
            assert!(result.is_some());
            assert_eq!(result.unwrap().sdk_path, PathBuf::from("/from/env"));
        });
    }
}
