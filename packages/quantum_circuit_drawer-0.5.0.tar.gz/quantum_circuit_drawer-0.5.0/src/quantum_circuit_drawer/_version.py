"""Internal package version."""

from typing import Final

__version__: Final[str] = "0.5.0"
