"""Compliance — score a credential against LicenseFoundry's published rubric.

Public surface (no API key required — the scoring endpoint is public):

    from licensefoundry import compliance

    result = compliance.score(
        credential_jwt,
        base_url="https://sandbox.licensefoundry.com",
        jurisdiction="eu",
    )

    print(result.score)             # "5/8"
    print(result.score_pct)         # 65
    print(result.auto_fail_reason)  # None
    for cat in result.categories:
        ...

Wraps ``GET /v1/credentials/{id}/compliance-score``. The credential id is
extracted from the JWT's ``jti`` claim — the JWT payload is base64-decoded
locally (no signature verification) to find the id, then the public
endpoint is called. Use :class:`Verifier.verify` separately for
cryptographic validation; scoring is orthogonal to revocation/validity.

Rubric methodology: https://licensefoundry.com/rubric/v1.0
"""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass, field
from typing import Literal

import httpx

from licensefoundry.errors import (
    MalformedCredentialError,
    NetworkError,
    NotFoundError,
)

Jurisdiction = Literal[
    "uniform",
    "eu",
    "california",
    "us",
    "children",
    "health",
]


@dataclass(frozen=True)
class ComplianceCategoryResult:
    """One category's outcome.

    ``weight`` is the jurisdiction-adjusted weight (e.g. 1.5 under the EU
    view); ``reason`` is populated only when ``passed=False``.
    """

    id: str
    label: str
    passed: bool
    weight: float
    reason: str | None
    legal_anchors: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ComplianceScoreResult:
    """The full scoring result for one credential.

    ``score`` is the uniform "N/8" string for display; the weighted
    figures (``score_weighted``, ``score_max``, ``score_pct``) reflect
    the requested jurisdiction. ``auto_fail_reason`` is set only when
    the children's-data auto-fail rule fires.
    """

    credential_id: str
    rubric_version: str
    rubric_url: str
    jurisdiction: str
    score: str  # "N/8"
    passes: int  # 0..8
    total: int  # always 8 for rubric v1
    score_weighted: float
    score_max: float
    score_pct: int  # 0..100
    auto_fail_reason: str | None
    categories: list[ComplianceCategoryResult]


def _extract_credential_id(jwt: str) -> str:
    """Extract the credential id from a JWT-VC's ``jti`` claim.

    Raises :class:`MalformedCredentialError` if the JWT doesn't have
    three segments, the payload isn't decodable JSON, or there's no
    ``jti``.
    """
    segments = jwt.split(".")
    if len(segments) != 3:
        raise MalformedCredentialError(
            "JWT must have three dot-separated segments "
            "(header.payload.signature)"
        )
    payload_b64 = segments[1]
    try:
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        decoded = base64.urlsafe_b64decode(padded)
        payload = json.loads(decoded)
    except (ValueError, json.JSONDecodeError) as e:
        raise MalformedCredentialError(
            f"JWT payload is not decodable JSON: {e}"
        ) from e
    jti = payload.get("jti")
    if not jti or not isinstance(jti, str):
        raise MalformedCredentialError(
            "JWT payload missing `jti` claim (credential URL)"
        )
    tail = jti.rsplit("/", 1)[-1]
    if not tail:
        raise MalformedCredentialError(
            f"JWT `jti` claim has no trailing id segment: {jti}"
        )
    return tail


def score(
    credential_jwt: str,
    *,
    base_url: str,
    jurisdiction: Jurisdiction | None = None,
    rubric_version: str | None = None,
    timeout: float = 30.0,
    http_client: httpx.Client | None = None,
) -> ComplianceScoreResult:
    """Score a credential against the published rubric.

    The scoring endpoint is public — no API key needed. Returns the
    structured score breakdown.

    Raises:
        MalformedCredentialError: JWT shape is wrong.
        NotFoundError: credential id from the JWT doesn't exist server-side.
        NetworkError: network failure or non-2xx response.
    """
    if not base_url:
        raise ValueError("compliance.score: base_url is required")
    cred_id = _extract_credential_id(credential_jwt)
    params: dict[str, str] = {}
    if jurisdiction is not None:
        params["jurisdiction"] = jurisdiction
    if rubric_version is not None:
        params["rubric_version"] = rubric_version
    url = f"{base_url.rstrip('/')}/v1/credentials/{cred_id}/compliance-score"

    client = http_client or httpx.Client(timeout=timeout)
    own_client = http_client is None
    try:
        try:
            response = client.get(url, params=params or None)
        except httpx.RequestError as e:
            raise NetworkError(f"fetch failed: {e}") from e
        if response.status_code == 404:
            raise NotFoundError("credential_not_found")
        if response.status_code >= 400:
            raise NetworkError(
                f"compliance-score returned HTTP {response.status_code}: "
                f"{response.text[:200]}"
            )
        raw = response.json()
    finally:
        if own_client:
            client.close()

    categories = [
        ComplianceCategoryResult(
            id=c["id"],
            label=c["label"],
            passed=c["passed"],
            weight=c["weight"],
            reason=c.get("reason"),
            legal_anchors=list(c.get("legal_anchors") or []),
        )
        for c in raw["categories"]
    ]
    return ComplianceScoreResult(
        credential_id=raw["credential_id"],
        rubric_version=raw["rubric_version"],
        rubric_url=raw["rubric_url"],
        jurisdiction=raw["jurisdiction"],
        score=raw["score"],
        passes=raw["passes"],
        total=raw["total"],
        score_weighted=raw["score_weighted"],
        score_max=raw["score_max"],
        score_pct=raw["score_pct"],
        auto_fail_reason=raw.get("auto_fail_reason"),
        categories=categories,
    )


__all__ = [
    "ComplianceCategoryResult",
    "ComplianceScoreResult",
    "Jurisdiction",
    "score",
]
