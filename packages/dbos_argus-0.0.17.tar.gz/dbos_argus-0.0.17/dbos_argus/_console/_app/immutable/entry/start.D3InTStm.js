import{l as o,a as r}from"../chunks/DxqzSjti.js";export{o as load_css,r as start};
