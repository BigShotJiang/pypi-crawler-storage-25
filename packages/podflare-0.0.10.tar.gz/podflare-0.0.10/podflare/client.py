from __future__ import annotations

import json
import os
from typing import Iterator

import httpx

from podflare.types import Event, Language

DEFAULT_HOST = "https://api.podflare.ai"


class Client:
    """Thin HTTP transport for the hostd contract.

    One Client per process is fine; it owns an httpx.Client.
    """

    def __init__(
        self,
        host: str | None = None,
        timeout: float = 30.0,
        traceparent: str | None = None,
        api_key: str | None = None,
    ):
        """
        Args:
            traceparent: W3C Trace Context string. Sent as `traceparent`
                header; also read from ``PODFLARE_TRACEPARENT`` env.
            api_key: Bearer token sent as ``Authorization: Bearer <key>`` on
                every request. Also read from ``PODFLARE_API_KEY`` env.
        """
        self.host = (
            host
            or os.environ.get("PODFLARE_HOSTD_URL")
            or os.environ.get("PODFLARE_HOST")  # legacy alias, removed in 0.1
            or DEFAULT_HOST
        ).rstrip("/")
        self.traceparent = traceparent or os.environ.get("PODFLARE_TRACEPARENT") or None
        self.api_key = api_key or os.environ.get("PODFLARE_API_KEY") or None
        default_headers: dict[str, str] = {}
        if self.traceparent:
            default_headers["traceparent"] = self.traceparent
        if self.api_key:
            default_headers["authorization"] = f"Bearer {self.api_key}"
        self._http = httpx.Client(
            base_url=self.host,
            timeout=timeout,
            headers=default_headers or None,
        )

    def close(self) -> None:
        self._http.close()

    def healthz(self) -> bool:
        r = self._http.get("/v1/healthz")
        return r.status_code == 200 and r.text.strip() == "ok"

    def create_sandbox(
        self,
        template: str | None = None,
        *,
        timeout_seconds: int | None = None,
        idle_timeout_seconds: int | None = None,
        ram_mib: int | None = None,
        rootfs_gb: int | None = None,
        persistent: bool | None = None,
    ) -> str:
        """Return just the sandbox id — kept for back-compat."""
        return self.create_sandbox_info(
            template=template,
            timeout_seconds=timeout_seconds,
            idle_timeout_seconds=idle_timeout_seconds,
            ram_mib=ram_mib,
            rootfs_gb=rootfs_gb,
            persistent=persistent,
        )["id"]

    def create_sandbox_info(
        self,
        template: str | None = None,
        *,
        timeout_seconds: int | None = None,
        idle_timeout_seconds: int | None = None,
        ram_mib: int | None = None,
        rootfs_gb: int | None = None,
        persistent: bool | None = None,
    ) -> dict:
        """Create a sandbox and return the full server response:
        ``{"id": "...", "state": "ready", "region": "eu", "endpoint":
        "https://api.podflare.ai"}``. ``region`` + ``endpoint`` are
        present only when hostd has PODFLARE_REGION + PODFLARE_PUBLIC_URL
        configured; used by Sandbox to pin subsequent calls so a
        Cloudflare-Geo-LB-routed session can't wander to a different
        region mid-sandbox.

        ``timeout_seconds`` and ``idle_timeout_seconds`` override the
        server defaults, capped by the caller's billing tier."""
        body: dict = {}
        if template:
            body["template"] = template
        if timeout_seconds is not None:
            body["timeout_seconds"] = timeout_seconds
        if idle_timeout_seconds is not None:
            body["idle_timeout_seconds"] = idle_timeout_seconds
        if ram_mib is not None:
            body["ram_mib"] = ram_mib
        if rootfs_gb is not None:
            body["rootfs_gb"] = rootfs_gb
        if persistent is not None:
            body["persistent"] = persistent
        r = self._http.post("/v1/sandboxes", json=body)
        r.raise_for_status()
        return r.json()

    def resume_space(
        self,
        space_id: str,
        *,
        timeout_seconds: int | None = None,
        idle_timeout_seconds: int | None = None,
        persistent: bool | None = None,
    ) -> dict:
        """Resume a frozen Space into a fresh live sandbox.

        Returns the same shape as ``create_sandbox_info``: ``{"id": "...",
        "state": "ready", "region": ..., "endpoint": ...}``. The returned
        id is a NEW sandbox — the space is consumed on successful resume.
        Pass ``persistent=True`` to have the resumed sandbox re-freeze on
        next idle (creating a new space with a new id)."""
        body: dict = {}
        if timeout_seconds is not None:
            body["timeout_seconds"] = timeout_seconds
        if idle_timeout_seconds is not None:
            body["idle_timeout_seconds"] = idle_timeout_seconds
        if persistent is not None:
            body["persistent"] = persistent
        r = self._http.post(f"/v1/spaces/{space_id}/resume", json=body)
        r.raise_for_status()
        return r.json()

    def delete_space(self, space_id: str) -> None:
        r = self._http.delete(f"/v1/spaces/{space_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def destroy_sandbox(self, sandbox_id: str) -> None:
        r = self._http.delete(f"/v1/sandboxes/{sandbox_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def fork_sandbox(self, sandbox_id: str, n: int = 1) -> list[str]:
        r = self._http.post(
            f"/v1/sandboxes/{sandbox_id}/fork",
            json={"n": n},
            timeout=60.0,
        )
        r.raise_for_status()
        return r.json()["children"]

    def merge_into(self, parent_id: str, winner_id: str) -> None:
        r = self._http.post(f"/v1/sandboxes/{parent_id}/merge_into/{winner_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def replay(self, sandbox_id: str) -> list[Event]:
        r = self._http.get(f"/v1/sandboxes/{sandbox_id}/replay")
        r.raise_for_status()
        events: list[Event] = []
        for line in r.text.splitlines():
            line = line.strip()
            if not line:
                continue
            events.append(Event.from_json(json.loads(line)))
        return events

    def exec_stream(
        self, sandbox_id: str, code: str, language: Language = "python"
    ) -> Iterator[Event]:
        body = {"code": code, "language": language}
        with self._http.stream("POST", f"/v1/sandboxes/{sandbox_id}/exec", json=body) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if not line:
                    continue
                yield Event.from_json(json.loads(line))
