"""Region resolution for the SDK.

Region routing now lives at the edge (Cloudflare Worker at
``api.podflare.ai`` — see ``api-router/`` in the monorepo). The SDK
no longer hardcodes per-region origin URLs. It just sends:

    https://api.podflare.ai/r/{region}/v1/...

…and the Worker decides which origin to forward to. That means:

* Adding a new region: update the Worker, zero SDK publish.
* Removing / renaming a region: update the Worker, zero SDK publish.
* Server-side failover: invisible to clients.

After the initial ``POST /v1/sandboxes``, hostd returns an ``endpoint``
URL pointing directly at the region's origin (e.g.
``https://usw1.podflare.ai``). The Sandbox client pins subsequent
calls to that direct URL — bypassing the Worker on the hot path.

Override the API base via env var ``PODFLARE_API_URL`` — useful for
staging environments or self-hosted deployments.
"""
from __future__ import annotations

import os
from urllib.parse import quote

_API_BASE_URL = os.environ.get("PODFLARE_API_URL", "https://api.podflare.ai")


def resolve_region(region: str | None) -> str | None:
    """Return the base URL the SDK should target for the given region.

    Any non-empty region string is accepted; validation happens at the
    edge. Unknown regions fall through to geo-routing on the server
    side rather than raising.

    Returns ``None`` when no region was specified (caller should use
    its default host).
    """
    if region is None:
        return None
    key = region.strip().lower()
    if key == "":
        return None
    return f"{_API_BASE_URL}/r/{quote(key, safe='')}"


# Legacy export. Retained for backward compatibility with code that
# read this dict directly. Prefer calling ``resolve_region()`` — new
# regions won't appear here without an SDK publish, but they WILL
# work correctly when passed to ``resolve_region``.
REGIONS: dict[str, str] = {
    "eu": f"{_API_BASE_URL}/r/eu",
    "us": f"{_API_BASE_URL}/r/us-west",
    "us-west": f"{_API_BASE_URL}/r/us-west",
    "us-east": f"{_API_BASE_URL}/r/us-east",
}


class UnknownRegionError(ValueError):
    """Raised only when a region value is syntactically invalid
    (empty / wrong type). Unknown-but-syntactically-valid regions
    are forwarded to the edge for validation."""

    pass
