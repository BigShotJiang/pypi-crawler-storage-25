__version__ = "0.0.1"

from .care import secret_easter_egg, th_py_egg_thv
from .egg import main_egg_input, Chinese_Error_py