#!/usr/bin/env python3

import os
import random
import signal
import sys
from pathlib import Path

from text_discoloration import (
    random_typewriter,
    separator,
    custom_print,
    gradient_text,
    success,
    error,
    info,
)

tmp_path = Path.home() / ".th_temp.py"


__version__ = "0.0.1"


def clear_file():
    if tmp_path.exists():
        tmp_path.unlink()


def execute_temp_file():
    if tmp_path.exists():
        code = tmp_path.read_text(encoding="utf-8")
        exec(code, {"__name__": "__main__"})


def exit_handler(sig, frame):
    if tmp_path.exists():
        print("\n")
        info("检测到未执行的代码")
        choice = input("是否执行？(y/N): ").strip().lower()
        if choice == "y":
            execute_temp_file()
    clear_file()
    print()
    success("已退出")
    raise SystemExit



signal.signal(signal.SIGINT, exit_handler)
signal.signal(signal.SIGTERM, exit_handler)


def thv():
    print(f"th version {__version__}")


def main():
    clear_file()

    random_typewriter("th_py Python终端编辑器", delay=0.03)
    separator(color="purple")
    info("输入代码，每行按回车")
    info("输入 end 执行代码")
    info("按 Ctrl+C 可选择是否执行")
    separator(color="purple")

    while True:
        color_list = ["red", "green", "yellow", "blue", "purple", "cyan", "white"]
        now_color = random.choice(color_list)
        custom_print(">>> ", color=now_color, end="")

        try:
            inp = input()
        except EOFError:
            break

        if inp == "end":
            break

        with open(tmp_path, "a", encoding="utf-8") as f:
            f.write(inp + "\n")

    gradient_text("执行结果", (255, 0, 100), (0, 200, 255), delay=0.02)
    separator(color="cyan")

    execute_temp_file()
    clear_file()

    success("执行完成")
    separator(color="green")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "--version" or sys.argv[1] == "-v":
            thv()
        elif sys.argv[1] == "care_py_main_python":
            try:
                from .care import __file__ as care_path
                print(f"彩蛋位置: {care_path}")
            except ImportError:
                print("彩蛋文件未找到，但你正在靠近真相")
        else:
            print(f"未知命令: {sys.argv[1]}")
            print("用法: th  或  th --version")
    else:
        main()