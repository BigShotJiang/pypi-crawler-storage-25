# th-py
纯Python打造彩色终端编辑器
仅依赖 text-discoloration 2.7.0，无多余第三方依赖

## 版本
v0.0.1

## 功能
- 彩色随机 `>>>` 提示符
- 打字机开场动画 + 分割线美化
- 逐行录入Python代码
- 输入 end 结束录入自动运行
- 异常退出自动清理临时文件

## 安装
```bash
pip install th-py
