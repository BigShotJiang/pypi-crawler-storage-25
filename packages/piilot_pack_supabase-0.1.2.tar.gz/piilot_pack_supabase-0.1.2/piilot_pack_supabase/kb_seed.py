"""Lazy plugin-owned KB metadata seeding for Supabase.

Each Supabase connection gets its own metadata KB — one row per
table / view / RPC function / edge function / advisor finding —
embeddable for RAG so an agent can sift through the schema
semantically before composing a query.

The KB is **plugin-owned** (``owner_type='plugin'``,
``owner_ref='supabase'``) and **schema-locked**: once Compta proved
the pattern in prod, we apply it the same way here. The user can
read and search; admins can refresh; nobody can rewrite the column
shape outside the plugin.

When seeding happens
--------------------

Lazy. We do NOT create the KB in :meth:`Plugin.register` because
the boot context has no ``company_id``. Instead, the first time a
connection is created (or refresh-schema fires after install),
:func:`ensure_supabase_metadata_kb` materializes the KB for that
specific company — idempotent on every subsequent call thanks to
:func:`piilot.sdk.knowledge.find_kb`.

Pattern lifted from ``piilot-pack-compta`` (``kb_seed.py``):

  1. ``find_kb`` — short-circuits when the KB already exists.
  2. ``create_kb(schema_locked=True)`` — owner_type and owner_ref
     are stamped automatically by the SDK from the
     ``current_plugin`` contextvar.
  3. ``add_column`` for each declared field.

Column model
------------

Eight columns, all optional except the ``entity_type`` discriminator:

* ``entity_type`` (text) — ``table`` / ``view`` / ``rpc`` /
  ``edge_function`` / ``advisor`` / ``extension``.
* ``schema_name`` (text) — Postgres schema (or ``"-"`` for
  edge_function / advisor).
* ``name`` (text) — table / function / function-slug name.
* ``description`` (text) — comment / advisor message / function
  signature description. This is what the embedding indexes —
  the field that drives semantic discovery.
* ``data_type`` (text) — for advisors, the level (ERROR/WARN/INFO);
  for tables, ``BASE TABLE`` / ``VIEW`` / ``MATERIALIZED VIEW``;
  for RPC, the return type signature; for edge fns, the function
  status.
* ``parent_table`` (text) — qualified ``schema.table`` for column
  rows or RPC functions that operate on a known table; empty
  otherwise. Lets the agent narrow searches by table.
* ``columns_text`` (text) — comma-separated column list for table
  rows ("id, email, created_at"), empty for other entity types.
  Boosts the embedding signal for table rows.
* ``ref_url`` (text) — when applicable (e.g. edge function URL,
  advisor docs link). Blank for most rows.
"""

from __future__ import annotations

import logging
from typing import Any

from piilot.sdk.knowledge import add_column, create_kb, find_kb

logger = logging.getLogger(__name__)


KB_NAME_PREFIX = "Supabase Schema — "
"""Idempotency key alongside ``(owner_type='plugin', owner_ref='supabase',
organization_id)``. Renaming this constant after a release would
strand every existing company on the legacy KB name. Don't."""


_COLUMN_SPECS: list[dict[str, Any]] = [
    {
        "name": "entity_type",
        "column_type": "text",
        "description": (
            "Discriminator: 'table' / 'view' / 'rpc' / 'edge_function' / "
            "'advisor' / 'extension'."
        ),
    },
    {
        "name": "schema_name",
        "column_type": "text",
        "description": "Postgres schema (or '-' for non-PG entities).",
    },
    {
        "name": "name",
        "column_type": "text",
        "description": "Entity identifier (table / function / slug).",
    },
    {
        "name": "description",
        "column_type": "text",
        "description": (
            "Human-readable description (comment / advisor message / "
            "function purpose). Drives the RAG embedding."
        ),
    },
    {
        "name": "data_type",
        "column_type": "text",
        "description": (
            "Type-shaped detail: BASE TABLE / VIEW for tables, return "
            "signature for RPC, advisor level (ERROR/WARN/INFO) for "
            "advisors, etc."
        ),
    },
    {
        "name": "parent_table",
        "column_type": "text",
        "description": (
            "Qualified 'schema.table' for entities tied to a specific "
            "table. Empty when not applicable."
        ),
    },
    {
        "name": "columns_text",
        "column_type": "text",
        "description": (
            "Comma-separated column list for table rows. Boosts the "
            "embedding signal so an agent searching 'customer email' "
            "finds the table whose columns include 'email'."
        ),
    },
    {
        "name": "ref_url",
        "column_type": "text",
        "description": "Optional external reference (edge fn URL, advisor docs).",
    },
]


def kb_name_for(connection_label: str) -> str:
    """Stable name for the metadata KB tied to ``connection_label``.

    Centralised so callers (the seed function, the refresh path, the
    connector update path) can't drift from the canonical format.
    """
    return f"{KB_NAME_PREFIX}{connection_label}"


def ensure_supabase_metadata_kb(
    company_id: str,
    connection_label: str,
) -> dict[str, Any]:
    """Idempotently materialize the metadata KB for ``connection_label``.

    Args:
        company_id: tenant the KB belongs to.
        connection_label: human-readable name of the Supabase
            connection (the ``label`` column on
            ``integrations_master.connections``). Used as the
            uniqueness suffix on the KB name.

    Returns:
        The existing or newly-created KB row dict (as returned by
        :func:`piilot.sdk.knowledge.find_kb` / ``create_kb``).

    Notes:
        * Must be called from a plugin context — the SDK reads
          ``current_plugin`` from the contextvar to stamp
          ``owner_type='plugin'`` and ``owner_ref='supabase'`` on
          the KB row. The plugin loader sets the contextvar around
          every routes / tools / module entry, so this is automatic
          for production callers; tests need ``plugin_context``.
        * Renaming the connection later does NOT auto-rename the
          KB — that path is handled by the connector update route
          which calls a dedicated rename helper.
    """
    name = kb_name_for(connection_label)
    existing = find_kb(company_id=company_id, name=name)
    if existing is not None:
        return existing

    kb = create_kb(
        company_id=company_id,
        name=name,
        description=(
            f"Métadonnées du projet Supabase '{connection_label}' — "
            "tables, RPC, edge fns et advisors embeddés pour RAG. "
            "Schéma figé par le plugin Supabase. Réservé aux refresh "
            "automatiques."
        ),
        schema_locked=True,
    )

    for position, spec in enumerate(_COLUMN_SPECS):
        add_column(
            kb["id"],
            name=spec["name"],
            column_type=spec["column_type"],
            description=spec["description"],
            position=position,
            is_required=False,
        )

    logger.info(
        "[supabase] seeded metadata KB '%s' (id=%s) for company %s",
        name,
        kb["id"],
        company_id,
    )
    return kb
