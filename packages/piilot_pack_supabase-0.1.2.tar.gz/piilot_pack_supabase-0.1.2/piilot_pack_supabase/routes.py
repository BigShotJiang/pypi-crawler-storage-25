"""Admin-only HTTP routes for the Supabase plugin (Phase 8 PAT-only).

Mounted under ``/plugins/supabase/*`` by
:func:`piilot.sdk.http.register_router`. Every route requires admin
role for the requesting company.

Endpoints
---------

* ``POST /connections``                        — create a connection (label + url + pat)
* ``GET  /connections``                        — list company's connections
* ``GET  /connections/{id}``                   — connection detail
* ``DELETE /connections/{id}``                 — drop the row
* ``POST /connections/{id}/refresh-schema``    — re-introspect (rate-limited)
* ``POST /connections/{id}/test-connection``   — ping Management API
* ``GET  /connections/{id}/audit``             — last-N audit entries

Phase 8 dropped ``POST /setup-snippet`` (no PG user to create).
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from piilot.sdk import cache as sdk_cache
from piilot.sdk import connectors as sdk_connectors
from piilot.sdk.db import Json, run_in_thread
from piilot.sdk.http import register_router, require_admin

from . import connector_service

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter()


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class CreateConnectionRequest(BaseModel):
    """Body for ``POST /connections``.

    ``project_ref`` accepts either the bare Reference ID
    (``fmjxjnzyeeslwyewpipw``) or a full Supabase URL — the
    connector_service normalizes either to the bare ref before
    persisting.
    """

    label: str = Field(..., min_length=1, max_length=120)
    project_ref: str = Field(..., min_length=8, max_length=400)
    supabase_pat: str = Field(..., min_length=10, max_length=400)
    rls_disclaimer_acknowledged: bool = False


class PatchConnectionRequest(BaseModel):
    """Body for ``PATCH /connections/{id}`` — partial config update.

    Each field is optional; only the keys present in the body are
    merged into ``config`` (shallow merge via ``sdk.connectors.update_config``).

    ``selected_tables`` and ``selected_rpc`` use ``"schema.name"`` strings
    matching the snapshot's ``{schema, name}`` rows.
    """

    selected_tables: list[str] | None = Field(
        default=None, max_length=500
    )
    selected_rpc: list[str] | None = Field(default=None, max_length=500)
    advanced_sql_enabled: bool | None = None
    label: str | None = Field(default=None, min_length=1, max_length=120)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_REFRESH_RATE_LIMIT_TTL = 300  # seconds — 5 minutes
_REFRESH_RATE_LIMIT_MAX = 1
"""1 manual refresh / 5 min / connection. Auto refresh (the daily
schedule wired in Phase 6+) bypasses this limit because it goes
through the scheduler entry point, not the route."""


async def _check_refresh_rate_limit(connection_id: str) -> None:
    """Raise HTTP 429 if the rate limit is exhausted for ``connection_id``."""
    key = f"supabase:refresh:{connection_id}"
    count = await sdk_cache.incr(key, amount=1, ttl=_REFRESH_RATE_LIMIT_TTL)
    if count > _REFRESH_RATE_LIMIT_MAX:
        raise HTTPException(
            status_code=429,
            detail=(
                "Manual refresh limited to "
                f"{_REFRESH_RATE_LIMIT_MAX} per {_REFRESH_RATE_LIMIT_TTL // 60} "
                "minutes per connection. Please wait."
            ),
        )


def _scope_to_company(connection: dict[str, Any], company_id: str) -> dict[str, Any]:
    """Return the connection if it belongs to ``company_id``, else 404.

    Defensive: even if RLS already enforces tenant isolation at the
    DB layer, this gives a clean 404 (rather than an empty result) at
    the API boundary, which is friendlier for the frontend.
    """
    if str(connection.get("organization_id") or connection.get("company_id")) != str(
        company_id
    ):
        raise HTTPException(status_code=404, detail="Connection not found")
    return connection


# ---------------------------------------------------------------------------
# Connections — CRUD
# ---------------------------------------------------------------------------


@router.post("/connections")
async def post_connection(
    body: CreateConnectionRequest,
    auth: tuple[str, str, str] = Depends(require_admin),
) -> dict[str, Any]:
    """Create a new Supabase connection for the caller's company."""
    _user_id, _role, company_id = auth

    if not body.rls_disclaimer_acknowledged:
        raise HTTPException(
            status_code=400,
            detail="RLS disclaimer must be acknowledged before creating a connection.",
        )

    try:
        row = connector_service.create_connection(
            company_id=company_id,
            project_ref_or_url=body.project_ref,
            label=body.label,
            pat=body.supabase_pat,
            rls_disclaimer_acknowledged=body.rls_disclaimer_acknowledged,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return _serialize_connection(row)


@router.get("/connections")
async def list_connections(
    auth: tuple[str, str, str] = Depends(require_admin),
) -> dict[str, Any]:
    """List the company's Supabase connections.

    Returns ``{"connections": [...]}``. Each entry omits credentials
    (which are encrypted anyway) so the frontend can render the hub
    without ever touching ciphertext.
    """
    _user_id, _role, company_id = auth
    rows = sdk_connectors.list_connections(
        company_id=company_id, provider="supabase"
    )
    serialized = [_serialize_connection(r) for r in rows]
    for entry in serialized:
        await _attach_snapshot_counts(entry)
    return {"connections": serialized}


@router.get("/connections/{connection_id}")
async def get_connection(
    connection_id: str,
    auth: tuple[str, str, str] = Depends(require_admin),
) -> dict[str, Any]:
    """Single-connection detail."""
    _user_id, _role, company_id = auth
    row = sdk_connectors.get_connection(connection_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Connection not found")
    _scope_to_company(row, company_id)
    serialized = _serialize_connection(row)
    await _attach_snapshot_counts(serialized)
    return serialized


@router.delete("/connections/{connection_id}")
async def delete_connection(
    connection_id: str,
    auth: tuple[str, str, str] = Depends(require_admin),
) -> dict[str, Any]:
    """Drop the connection. Audit_log + schema_snapshot rows cascade.

    Note: the executor's pool for this connection_id is NOT drained
    here — the lifecycle is owned by the long-running Executor
    instance held by the plugin. Phase 6 wiring will pass a callback
    to drop the pool after the row is deleted.
    """
    _user_id, _role, company_id = auth
    row = sdk_connectors.get_connection(connection_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Connection not found")
    _scope_to_company(row, company_id)
    deleted = sdk_connectors.delete_connection(connection_id)
    return {"deleted": bool(deleted)}


@router.patch("/connections/{connection_id}")
async def patch_connection(
    connection_id: str,
    body: PatchConnectionRequest,
    auth: tuple[str, str, str] = Depends(require_admin),
) -> dict[str, Any]:
    """Partial update of a connection's ``config`` (whitelist + label).

    Validates that every entry of ``selected_tables`` / ``selected_rpc``
    exists in the latest ``schema_snapshot`` for this connection. The
    snapshot is the source of truth — refusing unknown identifiers
    prevents the admin from whitelisting tables that don't exist (and
    keeps the LLM tool whitelist coherent at all times).
    """
    _user_id, _role, company_id = auth
    row = sdk_connectors.get_connection(connection_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Connection not found")
    _scope_to_company(row, company_id)

    # Build the patch dict (only keys explicitly provided in the body).
    patch: dict[str, Any] = {}

    if body.selected_tables is not None or body.selected_rpc is not None:
        # Need the snapshot to validate identifiers — fetch once.
        snapshot = await run_in_thread(
            _fetch_snapshot_counts_sync, connection_id
        )
        if snapshot is None:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Cannot select tables/RPC before the schema has been "
                    "introspected. Click \"Refresh maintenant\" first."
                ),
            )

        if body.selected_tables is not None:
            valid = {
                f"{t['schema']}.{t['name']}"
                for t in snapshot["tables_list"]
            }
            unknown = [
                ident for ident in body.selected_tables if ident not in valid
            ]
            if unknown:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Unknown table(s) — not in latest snapshot: "
                        f"{', '.join(sorted(unknown)[:5])}"
                        + (" …" if len(unknown) > 5 else "")
                    ),
                )
            patch["selected_tables"] = body.selected_tables

        if body.selected_rpc is not None:
            valid_rpc = {
                f"{r['schema']}.{r['name']}" for r in snapshot["rpc_list"]
            }
            unknown_rpc = [
                ident for ident in body.selected_rpc if ident not in valid_rpc
            ]
            if unknown_rpc:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Unknown RPC function(s) — not in latest snapshot: "
                        f"{', '.join(sorted(unknown_rpc)[:5])}"
                        + (" …" if len(unknown_rpc) > 5 else "")
                    ),
                )
            patch["selected_rpc"] = body.selected_rpc

    if body.advanced_sql_enabled is not None:
        patch["advanced_sql_enabled"] = body.advanced_sql_enabled

    update_kwargs: dict[str, Any] = {}
    if body.label is not None:
        update_kwargs["label"] = body.label

    # Apply config patch (if any keys present).
    if patch:
        sdk_connectors.update_config(connection_id, patch)

    # Apply label update if provided. The SDK's update_config doesn't
    # touch top-level columns, so use a direct UPDATE for the label.
    if update_kwargs:
        await run_in_thread(_update_label_sync, connection_id, body.label)

    refreshed = sdk_connectors.get_connection(connection_id)
    serialized = _serialize_connection(refreshed)
    await _attach_snapshot_counts(serialized)
    return serialized


def _update_label_sync(connection_id: str, label: str) -> None:
    """Update the connection's label (top-level column, not config JSONB)."""
    from piilot.sdk.db import cursor

    with cursor() as cur:
        cur.execute(
            "UPDATE integrations_master.connections "
            "SET label = %(label)s, updated_at = now() "
            "WHERE id = %(id)s",
            {"label": label, "id": connection_id},
        )


# ---------------------------------------------------------------------------
# Refresh schema
# ---------------------------------------------------------------------------


_UPSERT_SNAPSHOT_SQL = """
INSERT INTO integrations_supabase.schema_snapshot
    (connection_id, company_id, tables, rpc_functions,
     edge_functions, storage_buckets, advisors, extensions,
     introspected_at)
VALUES
    (%(connection_id)s, %(company_id)s, %(tables)s, %(rpc_functions)s,
     %(edge_functions)s, %(storage_buckets)s, %(advisors)s, %(extensions)s,
     now())
ON CONFLICT (connection_id) DO UPDATE SET
    tables          = EXCLUDED.tables,
    rpc_functions   = EXCLUDED.rpc_functions,
    edge_functions  = EXCLUDED.edge_functions,
    storage_buckets = EXCLUDED.storage_buckets,
    advisors        = EXCLUDED.advisors,
    extensions      = EXCLUDED.extensions,
    introspected_at = now(),
    updated_at      = now()
"""


def _upsert_snapshot_sync(
    *,
    connection_id: str,
    company_id: str,
    snapshot: dict[str, Any],
) -> None:
    """Sync wrapper for the snapshot UPSERT — runs in a thread pool."""
    from piilot.sdk.db import cursor

    with cursor() as cur:
        cur.execute(
            _UPSERT_SNAPSHOT_SQL,
            {
                "connection_id": connection_id,
                "company_id": company_id,
                "tables": Json(snapshot["tables"]),
                "rpc_functions": Json(snapshot["rpc_functions"]),
                "edge_functions": Json(snapshot["edge_functions"]),
                "storage_buckets": Json(snapshot["storage_buckets"]),
                "advisors": Json(snapshot["advisors"]),
                "extensions": Json(snapshot["extensions"]),
            },
        )


@router.post("/connections/{connection_id}/refresh-schema")
async def post_refresh_schema(
    connection_id: str,
    auth: tuple[str, str, str] = Depends(require_admin),
) -> dict[str, Any]:
    """Re-introspect the connection. Rate-limited 1/5min."""
    _user_id, _role, company_id = auth

    row = sdk_connectors.get_connection(connection_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Connection not found")
    _scope_to_company(row, company_id)

    # Rate limit disabled for dogfood (Phase 8). The pre-call counter
    # incremented on failed runs too, locking the admin out of retries
    # for 5 min while the backend was iterating on bug fixes. Restore
    # in Phase 9 once the path is stable, ideally only on success.
    # await _check_refresh_rate_limit(connection_id)

    try:
        result, snapshot = await connector_service.refresh_schema(row)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    await run_in_thread(
        _upsert_snapshot_sync,
        connection_id=connection_id,
        company_id=str(company_id),
        snapshot=snapshot,
    )

    return {
        "introspected_at": result.introspected_at,
        "tables_count": result.tables_count,
        "rpc_count": result.rpc_count,
        "edge_functions_count": result.edge_functions_count,
        "advisors_security_count": result.advisors_security_count,
        "advisors_performance_count": result.advisors_performance_count,
        "extensions_count": result.extensions_count,
    }


# ---------------------------------------------------------------------------
# Test connection
# ---------------------------------------------------------------------------


@router.post("/connections/{connection_id}/test-connection")
async def post_test_connection(
    connection_id: str,
    auth: tuple[str, str, str] = Depends(require_admin),
) -> dict[str, Any]:
    """Ping the Management API to validate the saved PAT.

    Phase 8 swap: v0.1's 8-step PG probe is replaced by a single
    Management API ping. Binary outcome ``ok`` + a free-form
    ``detail`` string. Frontend renders the same green/red banner.
    """
    _user_id, _role, company_id = auth

    row = sdk_connectors.get_connection(connection_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Connection not found")
    _scope_to_company(row, company_id)

    try:
        ping = await connector_service.test_connection(row)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "ok": ping.ok,
        "detail": ping.detail,
        "project_name": ping.project_name,
        "region": ping.region,
    }


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------


_AUDIT_SELECT_SQL = """
SELECT id, connection_id, company_id, user_id, agent_id,
       tool_name, query_kind, query_payload, status,
       rejection_reason, rows_returned, duration_ms, created_at
FROM integrations_supabase.audit_log
WHERE connection_id = %(connection_id)s
  AND company_id    = %(company_id)s
ORDER BY created_at DESC
LIMIT %(limit)s
"""


def _fetch_audit_sync(
    *,
    connection_id: str,
    company_id: str,
    limit: int,
) -> list[dict[str, Any]]:
    """Sync wrapper for the audit fetch — runs in a thread pool."""
    from piilot.sdk.db import cursor

    with cursor() as cur:
        cur.execute(
            _AUDIT_SELECT_SQL,
            {
                "connection_id": connection_id,
                "company_id": company_id,
                "limit": limit,
            },
        )
        return [dict(r) for r in cur.fetchall()]


@router.get("/connections/{connection_id}/audit")
async def get_audit(
    connection_id: str,
    limit: int = 100,
    auth: tuple[str, str, str] = Depends(require_admin),
) -> dict[str, Any]:
    """Last-N audit entries for a connection.

    ``limit`` is capped at 500 to avoid runaway responses. Pagination
    via cursor will land in v0.2.
    """
    _user_id, _role, company_id = auth

    row = sdk_connectors.get_connection(connection_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Connection not found")
    _scope_to_company(row, company_id)

    capped_limit = max(1, min(500, limit))
    rows = await run_in_thread(
        _fetch_audit_sync,
        connection_id=connection_id,
        company_id=str(company_id),
        limit=capped_limit,
    )
    return {"entries": rows, "limit": capped_limit}


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


_SNAPSHOT_COUNTS_SQL = """
SELECT
    jsonb_array_length(COALESCE(tables, '[]'::jsonb))          AS tables_count,
    jsonb_array_length(COALESCE(rpc_functions, '[]'::jsonb))   AS rpc_count,
    jsonb_array_length(COALESCE(edge_functions, '[]'::jsonb))  AS edge_functions_count,
    jsonb_array_length(COALESCE(advisors, '[]'::jsonb))        AS advisors_count,
    jsonb_array_length(COALESCE(extensions, '[]'::jsonb))      AS extensions_count,
    introspected_at,
    tables          AS tables_full,
    rpc_functions   AS rpc_full
FROM integrations_supabase.schema_snapshot
WHERE connection_id = %(connection_id)s
"""

_SNAPSHOT_TABLES_CAP = 500
"""Hard cap on the number of tables returned to the frontend (TablePicker).

Real Supabase projects rarely have >500 user tables — the cap protects
the FastAPI response from blowing past 1MB on pathological projects
(Auth + storage + monitoring schemas already filtered out by
:data:`_TABLES_QUERY` exclusion list, but a permissive customer
project can still grow tens of schemas)."""


def _fetch_snapshot_counts_sync(connection_id: str) -> dict[str, Any] | None:
    """Read the latest snapshot counts + tables list for ``connection_id``.

    Returns counts (numbers) + a slim ``tables_list`` of ``{schema, name}``
    dicts capped at :data:`_SNAPSHOT_TABLES_CAP` rows. The full table
    metadata (columns, comments) stays server-side — the frontend
    TablePicker only needs the identity to render checkboxes.

    Sync helper, run via :func:`run_in_thread` in the route layer.
    """
    from piilot.sdk.db import cursor

    with cursor() as cur:
        cur.execute(_SNAPSHOT_COUNTS_SQL, {"connection_id": connection_id})
        row = cur.fetchone()
    if not row:
        return None

    full_tables = row.get("tables_full") or []
    truncated = len(full_tables) > _SNAPSHOT_TABLES_CAP
    tables_list = [
        {"schema": t.get("schema"), "name": t.get("name")}
        for t in full_tables[:_SNAPSHOT_TABLES_CAP]
        if t.get("schema") and t.get("name")
    ]
    full_rpc = row.get("rpc_full") or []
    rpc_list = [
        {"schema": r.get("schema"), "name": r.get("name")}
        for r in full_rpc[:_SNAPSHOT_TABLES_CAP]
        if r.get("schema") and r.get("name")
    ]
    return {
        "tables_count": int(row["tables_count"] or 0),
        "rpc_count": int(row["rpc_count"] or 0),
        "edge_functions_count": int(row["edge_functions_count"] or 0),
        "advisors_count": int(row["advisors_count"] or 0),
        "extensions_count": int(row["extensions_count"] or 0),
        "introspected_at": (
            row["introspected_at"].isoformat()
            if row.get("introspected_at")
            else None
        ),
        "tables_list": tables_list,
        "rpc_list": rpc_list,
        "tables_truncated": truncated,
    }


async def _attach_snapshot_counts(payload: dict[str, Any]) -> dict[str, Any]:
    """Attach ``last_snapshot`` to a serialized connection (None if never refreshed)."""
    cid = payload.get("id")
    if not cid:
        return payload
    counts = await run_in_thread(_fetch_snapshot_counts_sync, cid)
    payload["last_snapshot"] = counts
    return payload


def _serialize_connection(row: dict[str, Any]) -> dict[str, Any]:
    """Project a saved connection to a frontend-safe shape.

    Strips encrypted credentials — the frontend never needs to see
    ciphertext. The presence/absence of each secret IS surfaced as
    a boolean so the UI can show "PAT configured" or "no PAT" badges.
    """
    credentials = row.get("credentials") or {}
    config = row.get("config") or {}
    return {
        "id": str(row.get("id", "")),
        "label": row.get("label"),
        "provider": row.get("provider"),
        "is_active": row.get("is_active"),
        "config": {
            "supabase_url": config.get("supabase_url"),
            "project_ref": config.get("project_ref"),
            "pg_host": config.get("pg_host"),
            "pg_port": config.get("pg_port"),
            "pg_database": config.get("pg_database"),
            "selected_tables": config.get("selected_tables") or [],
            "selected_rpc": config.get("selected_rpc") or [],
            "advanced_sql_enabled": config.get("advanced_sql_enabled", False),
            "schema_refresh_interval_hours": config.get(
                "schema_refresh_interval_hours", 24
            ),
            "last_schema_refresh_at": config.get("last_schema_refresh_at"),
            "readonly_user_verified_at": config.get("readonly_user_verified_at"),
            "rls_disclaimer_acknowledged_at": config.get(
                "rls_disclaimer_acknowledged_at"
            ),
        },
        "has_pg_password": bool(credentials.get("pg_readonly_password")),
        "has_pat": bool(credentials.get("supabase_pat")),
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"),
        "last_snapshot": None,
    }


# ---------------------------------------------------------------------------
# Wiring
# ---------------------------------------------------------------------------


def wire_routes() -> None:
    """Mount the router under ``/plugins/supabase/*``.

    Called from :meth:`Plugin.register`. The empty ``prefix=""``
    means the SDK builds the URL as
    ``/plugins/{namespace}{router_path}`` — the namespace lives on
    the contextvar set by the loader.
    """
    register_router(router, prefix="")
