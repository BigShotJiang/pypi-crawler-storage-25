"""Business agent tools — 9 functions that talk to the active Supabase.

Every tool follows the same pipeline:

  1. Resolve the active connection from the session scope. If
     missing / ambiguous, return the message
     :data:`MSG_NEED_SELECT` and stop — the LLM relays it to the
     user, who picks a connection via ``supabase_select_connection``.
  2. Compose the SQL via the pure builders in :mod:`sql_builders`.
  3. Run it through :func:`validator.validate` against the connection's
     selected_tables whitelist.
  4. Execute via the module-level :class:`Executor` singleton.
  5. Append an audit row (success or rejection) via :mod:`audit`.

Tool implementations stay thin — heavy lifting (parameter building,
SQL composition, AST validation) lives in :mod:`sql_builders` and
:mod:`validator`. The implementations here are the orchestration glue.

Public surface — 9 StructuredTool exports
-----------------------------------------

* :data:`supabase_search_schema`     — RAG-ish substring lookup on the
                                       cached snapshot (full RAG via
                                       embeddings is v2).
* :data:`supabase_describe_table`    — columns / FKs / indexes for one
                                       table from ``schema_snapshot``.
* :data:`supabase_select`            — SELECT … FROM … WHERE.
* :data:`supabase_count`             — SELECT COUNT(*).
* :data:`supabase_aggregate`         — SUM/AVG/MIN/MAX/COUNT.
* :data:`supabase_top_n`             — ORDER BY … LIMIT N.
* :data:`supabase_invoke_rpc`        — POST-style call to a whitelisted
                                       RPC function.
* :data:`supabase_storage_list`      — v1 stub returning a deferral msg.
* :data:`supabase_sql_advanced`      — gated raw SQL behind
                                       ``advanced_sql_enabled``.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from langchain_core.tools import StructuredTool

from piilot.sdk.db import cursor as sdk_cursor
from piilot.sdk.db import run_in_thread

from piilot.sdk.tools import bind_session

from . import audit, sql_builders, validator
from ._session_helpers import get_supabase_context
from .connector_service import get_pat
from .mgmt_executor import (
    ExecutionError,
    ExecutionResult,
    ManagementExecutor,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Singleton executor
# ---------------------------------------------------------------------------

_EXECUTOR: ManagementExecutor | None = None
"""Lazy module-level singleton. One ManagementExecutor (Phase 8 PAT
flow) shared by every tool call across every connection — the PAT
travels per-call in the Authorization header. No connection pool to
key here. Never closed on its own; the SDK has no plugin shutdown
hook in 0.5.0."""


def _get_executor() -> ManagementExecutor:
    """Return the module-level ManagementExecutor, lazy."""
    global _EXECUTOR
    if _EXECUTOR is None:
        _EXECUTOR = ManagementExecutor()
    return _EXECUTOR


# ---------------------------------------------------------------------------
# Pipeline scaffolding
# ---------------------------------------------------------------------------


def _format_rows(result: ExecutionResult) -> str:
    """Render an ExecutionResult as a JSON string for the LLM.

    JSON is preferred over a markdown table because the LLM is
    better at structured data than at text-aligned columns. The
    truncation flags are surfaced explicitly so the LLM can warn
    the user if it returned a partial answer.
    """
    payload: dict[str, Any] = {
        "rows": result.rows,
        "rows_returned": result.rows_returned,
        "duration_ms": result.duration_ms,
    }
    if result.truncated_rows:
        payload["truncated_rows"] = True
    if result.truncated_strings:
        payload["truncated_strings"] = result.truncated_strings
    return json.dumps(payload, default=str, ensure_ascii=False)


def _allowed_tables_for(connection: dict[str, Any]) -> frozenset[tuple[str, str]]:
    """Materialize the validator whitelist from a connection's selected_tables.

    Each entry of ``config.selected_tables`` is expected to be in the
    form ``"schema.table"`` (the picker UI in Phase 7 stores it that
    way). We split + lowercase here for the validator's
    case-insensitive match.
    """
    config = connection.get("config") or {}
    raw = config.get("selected_tables") or []
    out: set[tuple[str, str]] = set()
    for entry in raw:
        if not entry or "." not in entry:
            continue
        schema, _, table = entry.partition(".")
        out.add((schema.strip().lower(), table.strip().lower()))
    return frozenset(out)


async def _run_sql(
    *,
    session_id: str,
    tool_name: str,
    query_kind: str,
    sql: str,
    query_params: list[Any] | None,
    allowed_tables: frozenset[tuple[str, str]],
    company_id: str,
    connection: dict[str, Any],
    user_id: str | None = None,
    agent_id: str | None = None,
    skip_validator: bool = False,
) -> str:
    """Validate + execute + audit a composed SQL.

    Returns the JSON-formatted result on success, an error message
    string on failure. Failures are also written to audit_log with
    a stable ``status`` ∈ {rejected_sqlglot, pg_error, …}.
    """
    started = time.monotonic()

    # --- Validate ---
    final_sql = sql
    if not skip_validator:
        try:
            final_sql = validator.validate(sql, allowed_tables=allowed_tables)
        except validator.ValidationError as exc:
            duration = int((time.monotonic() - started) * 1000)
            await audit.log_query(
                connection_id=str(connection["id"]),
                company_id=company_id,
                user_id=user_id,
                agent_id=agent_id,
                tool_name=tool_name,
                query_kind=query_kind,
                query_payload={"sql": sql, "params": query_params},
                status="rejected_sqlglot",
                rejection_reason=exc.reason,
                rows_returned=0,
                duration_ms=duration,
            )
            return f"Requête refusée : {exc.reason}"

    # --- Execute via Management API (Phase 8 PAT flow) ---
    config = connection.get("config") or {}
    project_ref = config.get("project_ref")
    if not project_ref:
        return (
            "Connexion mal configurée : pas de project_ref. "
            "Le mode self-hosted n'est pas encore supporté."
        )
    pat = get_pat(connection)
    if not pat:
        return (
            "Aucun Personal Access Token enregistré sur cette "
            "connexion. Recréez-la avec un PAT."
        )

    executor = _get_executor()
    try:
        result = await executor.run(
            project_ref=project_ref,
            pat=pat,
            sql=final_sql,
            query_params=query_params,
        )
    except ExecutionError as exc:
        duration = int((time.monotonic() - started) * 1000)
        await audit.log_query(
            connection_id=str(connection["id"]),
            company_id=company_id,
            user_id=user_id,
            agent_id=agent_id,
            tool_name=tool_name,
            query_kind=query_kind,
            query_payload={"sql": final_sql, "params": query_params},
            status=exc.kind,
            rejection_reason=exc.message,
            rows_returned=0,
            duration_ms=exc.duration_ms,
        )
        return f"Erreur Postgres ({exc.kind}) : {exc.message}"

    # --- Audit success ---
    await audit.log_query(
        connection_id=str(connection["id"]),
        company_id=company_id,
        user_id=user_id,
        agent_id=agent_id,
        tool_name=tool_name,
        query_kind=query_kind,
        query_payload={"sql": final_sql, "params": query_params},
        status="ok",
        rows_returned=result.rows_returned,
        duration_ms=result.duration_ms,
    )
    return _format_rows(result)


# ---------------------------------------------------------------------------
# 1. supabase_search_schema
# ---------------------------------------------------------------------------


def _fetch_snapshot_sync(connection_id: str) -> dict[str, Any] | None:
    """Read schema_snapshot for a connection (sync, run_in_thread'd)."""
    with sdk_cursor() as cur:
        cur.execute(
            """
            SELECT tables, rpc_functions, edge_functions, advisors,
                   extensions, introspected_at
            FROM integrations_supabase.schema_snapshot
            WHERE connection_id = %s
            """,
            (connection_id,),
        )
        row = cur.fetchone()
    return dict(row) if row is not None else None


async def _supabase_search_schema_fn(
    query: str = "",
    session_id: str = "",
) -> str:
    """Substring lookup on the cached snapshot, filtered by the admin's
    ``selected_tables`` / ``selected_rpc`` whitelist.

    Empty ``query`` → return every whitelisted entry (capped at 50).
    The agent then has the full surface it's allowed to query, with no
    pretense that more tables exist.
    """
    company_id, connection, err = get_supabase_context(session_id)
    if err:
        return err
    assert connection is not None and company_id is not None

    config = connection.get("config") or {}
    selected_tables: set[str] = {
        s for s in (config.get("selected_tables") or []) if isinstance(s, str)
    }
    selected_rpc: set[str] = {
        s for s in (config.get("selected_rpc") or []) if isinstance(s, str)
    }

    if not selected_tables and not selected_rpc:
        return (
            "Aucune table ni fonction RPC n'est exposée pour ce compte. "
            "Demande à un admin d'aller dans Paramètres → Configuration "
            "Supabase → onglet « Tables & RPC » et cocher les tables à "
            "rendre disponibles aux agents."
        )

    snapshot = await run_in_thread(
        _fetch_snapshot_sync, str(connection["id"])
    )
    if snapshot is None:
        return (
            "Le schéma n'a pas encore été introspecté pour ce compte. "
            "Demande à un admin de cliquer 'Refresh maintenant' dans "
            "Paramètres → Configuration Supabase."
        )

    q_lower = (query or "").strip().lower()
    matches: list[dict[str, Any]] = []

    for t in snapshot.get("tables") or []:
        ident = f"{t.get('schema') or ''}.{t.get('name') or ''}"
        if ident not in selected_tables:
            continue
        haystack = " ".join(
            [
                t.get("schema") or "",
                t.get("name") or "",
                t.get("comment") or "",
                " ".join(c.get("name", "") for c in t.get("columns") or []),
            ]
        ).lower()
        if q_lower and q_lower not in haystack:
            continue
        matches.append(
            {
                "kind": "table",
                "schema": t.get("schema"),
                "name": t.get("name"),
                "comment": t.get("comment"),
                "columns": [c.get("name") for c in t.get("columns") or []],
            }
        )

    for fn in snapshot.get("rpc_functions") or []:
        ident = f"{fn.get('schema') or ''}.{fn.get('name') or ''}"
        if ident not in selected_rpc:
            continue
        haystack = " ".join(
            [
                fn.get("schema") or "",
                fn.get("name") or "",
                fn.get("comment") or "",
                fn.get("arguments") or "",
            ]
        ).lower()
        if q_lower and q_lower not in haystack:
            continue
        matches.append(
            {
                "kind": "rpc",
                "schema": fn.get("schema"),
                "name": fn.get("name"),
                "comment": fn.get("comment"),
                "arguments": fn.get("arguments"),
            }
        )

    if not matches:
        if q_lower:
            return (
                f"Aucun résultat pour '{query}' parmi les tables/RPC "
                f"whitelistées ({len(selected_tables)} tables, "
                f"{len(selected_rpc)} RPC)."
            )
        # No results despite empty query — should be unreachable since
        # we early-returned on empty selected_*. Defensive.
        return "Whitelist vide : aucun élément à lister."

    matches = matches[:50]
    return json.dumps(
        {
            "matches": matches,
            "whitelist_total": {
                "tables": len(selected_tables),
                "rpc": len(selected_rpc),
            },
        },
        ensure_ascii=False,
        default=str,
    )


# ---------------------------------------------------------------------------
# 2. supabase_describe_table
# ---------------------------------------------------------------------------


async def _supabase_describe_table_fn(
    schema: str = "",
    table: str = "",
    session_id: str = "",
) -> str:
    """Return columns / FKs / indexes for one table from the snapshot.

    Filtered by ``selected_tables``: even though the snapshot caches
    every introspected table, only whitelisted ones are described to
    the agent. Otherwise the agent would learn schemas it can't query
    (and we'd leak structural info the admin chose to hide).
    """
    _company_id, connection, err = get_supabase_context(session_id)
    if err:
        return err
    assert connection is not None

    schema_l = (schema or "").strip().lower()
    table_l = (table or "").strip().lower()
    if not schema_l or not table_l:
        return "Précisez le schéma et le nom de la table."

    config = connection.get("config") or {}
    whitelist = {
        s.lower()
        for s in (config.get("selected_tables") or [])
        if isinstance(s, str)
    }
    if f"{schema_l}.{table_l}" not in whitelist:
        if not whitelist:
            return (
                "Aucune table n'est exposée pour ce compte. Demande à un "
                "admin d'aller dans Paramètres → Configuration Supabase "
                "→ onglet « Tables & RPC » pour cocher les tables à "
                "rendre accessibles."
            )
        return (
            f"La table '{schema}.{table}' n'est pas exposée. Utilise "
            f"d'abord supabase_search_schema pour lister les tables "
            f"autorisées."
        )

    snapshot = await run_in_thread(
        _fetch_snapshot_sync, str(connection["id"])
    )
    if snapshot is None:
        return "Le schéma n'a pas encore été introspecté pour ce compte."

    for t in snapshot.get("tables") or []:
        if (t.get("schema") or "").lower() == schema_l and (
            t.get("name") or ""
        ).lower() == table_l:
            return json.dumps(
                {
                    "schema": t.get("schema"),
                    "name": t.get("name"),
                    "comment": t.get("comment"),
                    "columns": t.get("columns") or [],
                    "foreign_keys": t.get("foreign_keys") or [],
                    "indexes": t.get("indexes") or [],
                },
                ensure_ascii=False,
                default=str,
            )

    return f"Table {schema}.{table} introuvable dans le schéma exposé."


# ---------------------------------------------------------------------------
# 3-7. SQL-shaped tools (select, count, aggregate, top_n, invoke_rpc)
# ---------------------------------------------------------------------------


def _coerce_filters(raw: dict[str, Any] | None) -> dict[str, sql_builders.FilterSpec]:
    """Convert a JSON-friendly filter dict into typed FilterSpec.

    Input shape (what the LLM sends):
        {"col_name": {"op": "eq", "value": 42}}
        {"col_name": {"op": "in", "values": [1, 2, 3]}}
        {"col_name": {"op": "is_null"}}

    Output: dict of validated FilterSpec instances.
    """
    if not raw:
        return {}
    out: dict[str, sql_builders.FilterSpec] = {}
    for col, spec in raw.items():
        if not isinstance(spec, dict):
            raise ValueError(f"filter on {col!r}: expected dict, got {type(spec).__name__}")
        op = spec.get("op")
        if not op:
            raise ValueError(f"filter on {col!r}: missing 'op'")
        out[col] = sql_builders.FilterSpec(
            op=op,
            value=spec.get("value"),
            values=spec.get("values"),
        )
    return out


def _coerce_order(raw: list[dict[str, Any]] | None) -> list[sql_builders.OrderClause]:
    """Convert a list of ``{column, direction}`` dicts into OrderClause."""
    if not raw:
        return []
    out: list[sql_builders.OrderClause] = []
    for item in raw:
        if not isinstance(item, dict) or not item.get("column"):
            raise ValueError("order_by item must be {column, direction}")
        out.append(
            sql_builders.OrderClause(
                column=item["column"],
                direction=item.get("direction", "asc"),
            )
        )
    return out


async def _supabase_select_fn(
    schema: str = "public",
    table: str = "",
    columns: list[str] | None = None,
    filters: dict[str, Any] | None = None,
    order_by: list[dict[str, Any]] | None = None,
    limit: int = 100,
    session_id: str = "",
) -> str:
    """Composed SELECT against a whitelisted table."""
    company_id, connection, err = get_supabase_context(session_id)
    if err:
        return err
    assert connection is not None and company_id is not None

    if not table:
        return "Précisez le nom de la table (``table=...``)."

    try:
        sql, params = sql_builders.build_select(
            schema,
            table,
            columns=columns,
            filters=_coerce_filters(filters),
            order_by=_coerce_order(order_by),
            limit=limit,
        )
    except ValueError as exc:
        return f"Argument invalide : {exc}"

    allowed = _allowed_tables_for(connection)
    if (schema.lower(), table.lower()) not in allowed:
        return (
            f"Table {schema}.{table} non exposée. Demandez à un admin "
            "de la cocher dans Paramètres → Intégrations → Supabase."
        )

    return await _run_sql(
        session_id=session_id,
        tool_name="supabase_select",
        query_kind="postgrest",
        sql=sql,
        query_params=params,
        allowed_tables=allowed,
        company_id=company_id,
        connection=connection,
    )


async def _supabase_count_fn(
    schema: str = "public",
    table: str = "",
    filters: dict[str, Any] | None = None,
    session_id: str = "",
) -> str:
    company_id, connection, err = get_supabase_context(session_id)
    if err:
        return err
    assert connection is not None and company_id is not None

    if not table:
        return "Précisez le nom de la table."

    try:
        sql, params = sql_builders.build_count(
            schema, table, filters=_coerce_filters(filters)
        )
    except ValueError as exc:
        return f"Argument invalide : {exc}"

    allowed = _allowed_tables_for(connection)
    if (schema.lower(), table.lower()) not in allowed:
        return f"Table {schema}.{table} non exposée."

    return await _run_sql(
        session_id=session_id,
        tool_name="supabase_count",
        query_kind="postgrest",
        sql=sql,
        query_params=params,
        allowed_tables=allowed,
        company_id=company_id,
        connection=connection,
    )


async def _supabase_aggregate_fn(
    schema: str = "public",
    table: str = "",
    column: str = "",
    op: str = "sum",
    filters: dict[str, Any] | None = None,
    session_id: str = "",
) -> str:
    company_id, connection, err = get_supabase_context(session_id)
    if err:
        return err
    assert connection is not None and company_id is not None

    if not table or not column:
        return "Précisez ``table`` et ``column``."

    try:
        sql, params = sql_builders.build_aggregate(
            schema, table, column, op, filters=_coerce_filters(filters)
        )
    except ValueError as exc:
        return f"Argument invalide : {exc}"

    allowed = _allowed_tables_for(connection)
    if (schema.lower(), table.lower()) not in allowed:
        return f"Table {schema}.{table} non exposée."

    return await _run_sql(
        session_id=session_id,
        tool_name="supabase_aggregate",
        query_kind="postgrest",
        sql=sql,
        query_params=params,
        allowed_tables=allowed,
        company_id=company_id,
        connection=connection,
    )


async def _supabase_top_n_fn(
    schema: str = "public",
    table: str = "",
    column: str = "",
    n: int = 10,
    direction: str = "desc",
    columns: list[str] | None = None,
    filters: dict[str, Any] | None = None,
    session_id: str = "",
) -> str:
    company_id, connection, err = get_supabase_context(session_id)
    if err:
        return err
    assert connection is not None and company_id is not None

    if not table or not column:
        return "Précisez ``table`` et ``column``."

    try:
        sql, params = sql_builders.build_top_n(
            schema,
            table,
            column,
            n,
            direction=direction,  # type: ignore[arg-type]
            columns=columns,
            filters=_coerce_filters(filters),
        )
    except ValueError as exc:
        return f"Argument invalide : {exc}"

    allowed = _allowed_tables_for(connection)
    if (schema.lower(), table.lower()) not in allowed:
        return f"Table {schema}.{table} non exposée."

    return await _run_sql(
        session_id=session_id,
        tool_name="supabase_top_n",
        query_kind="postgrest",
        sql=sql,
        query_params=params,
        allowed_tables=allowed,
        company_id=company_id,
        connection=connection,
    )


async def _supabase_invoke_rpc_fn(
    function_name: str = "",
    schema: str = "public",
    args: list[Any] | None = None,
    session_id: str = "",
) -> str:
    """Call a whitelisted RPC function.

    The RPC must be in the connection's ``selected_rpc`` list — admins
    add functions there explicitly via the picker. We bypass the
    sqlglot validator here (function-as-table doesn't fit its
    SELECT-tree assumptions) and rely on the whitelist + the
    ``piilot_readonly`` GRANT EXECUTE for safety.
    """
    company_id, connection, err = get_supabase_context(session_id)
    if err:
        return err
    assert connection is not None and company_id is not None

    if not function_name:
        return "Précisez le nom de la fonction RPC."

    config = connection.get("config") or {}
    selected_rpc: list[str] = config.get("selected_rpc") or []
    qualified = f"{schema}.{function_name}".lower()
    if qualified not in {r.lower() for r in selected_rpc}:
        return (
            f"Fonction {schema}.{function_name} non exposée. Demandez à "
            "un admin de la cocher dans la section RPC."
        )

    try:
        sql, params = sql_builders.build_rpc_call(
            schema, function_name, args=args
        )
    except ValueError as exc:
        return f"Argument invalide : {exc}"

    return await _run_sql(
        session_id=session_id,
        tool_name="supabase_invoke_rpc",
        query_kind="rpc",
        sql=sql,
        query_params=params,
        allowed_tables=frozenset(),  # not used (skip_validator)
        company_id=company_id,
        connection=connection,
        skip_validator=True,
    )


# ---------------------------------------------------------------------------
# 8. supabase_storage_list — v1 stub
# ---------------------------------------------------------------------------


async def _supabase_storage_list_fn(
    bucket: str = "",
    prefix: str = "",
    limit: int = 100,
    session_id: str = "",
) -> str:
    """v1 stub — Storage support is deferred to v2 (cf. spec §14)."""
    _ = (bucket, prefix, limit, session_id)
    return (
        "Le listing Storage n'est pas encore disponible (v2). "
        "Pour explorer les buckets, utilisez le dashboard Supabase "
        "directement."
    )


# ---------------------------------------------------------------------------
# 9. supabase_sql_advanced — gated raw SQL
# ---------------------------------------------------------------------------


async def _supabase_sql_advanced_fn(
    sql: str = "",
    session_id: str = "",
) -> str:
    """Run a raw SELECT — gated, rare-use."""
    company_id, connection, err = get_supabase_context(session_id)
    if err:
        return err
    assert connection is not None and company_id is not None

    config = connection.get("config") or {}
    if not config.get("advanced_sql_enabled", False):
        return (
            "Le mode SQL avancé n'est pas activé pour ce compte. "
            "Un admin peut l'activer dans Paramètres → Intégrations → "
            "Supabase → Sécurité (re-acknowledge requis)."
        )

    if not sql or not sql.strip():
        return "Précisez la requête SQL."

    return await _run_sql(
        session_id=session_id,
        tool_name="supabase_sql_advanced",
        query_kind="sql",
        sql=sql,
        query_params=None,
        allowed_tables=_allowed_tables_for(connection),
        company_id=company_id,
        connection=connection,
    )


# ---------------------------------------------------------------------------
# Exported StructuredTool instances
# ---------------------------------------------------------------------------


supabase_search_schema = StructuredTool.from_function(
    coroutine=bind_session(_supabase_search_schema_fn),
    name="supabase_search_schema",
    description=(
        "Recherche dans le schéma cached du compte Supabase actif "
        "(tables, RPC, commentaires). Renvoie jusqu'à 20 entités "
        "matchant le mot-clé. Premier outil à appeler quand on ne "
        "sait pas dans quelle table chercher une donnée."
    ),
)


supabase_describe_table = StructuredTool.from_function(
    coroutine=bind_session(_supabase_describe_table_fn),
    name="supabase_describe_table",
    description=(
        "Détaille une table : colonnes, types, foreign keys, indexes. "
        "Argument schema (default 'public') et table requis."
    ),
)


supabase_select = StructuredTool.from_function(
    coroutine=bind_session(_supabase_select_fn),
    name="supabase_select",
    description=(
        "SELECT classique sur une table whitelistée. "
        "filters: {col: {op, value}} avec op ∈ "
        "{eq, ne, gt, gte, lt, lte, like, ilike, in, is_null, is_not_null}. "
        "order_by: [{column, direction}]."
    ),
)


supabase_count = StructuredTool.from_function(
    coroutine=bind_session(_supabase_count_fn),
    name="supabase_count",
    description=(
        "Compte les lignes d'une table avec filtres optionnels. "
        "Précis (COUNT(*)). Mêmes filters que supabase_select."
    ),
)


supabase_aggregate = StructuredTool.from_function(
    coroutine=bind_session(_supabase_aggregate_fn),
    name="supabase_aggregate",
    description=(
        "Agrégat sur une colonne : op ∈ {sum, avg, min, max, count}. "
        "sum / avg castent automatiquement en numeric."
    ),
)


supabase_top_n = StructuredTool.from_function(
    coroutine=bind_session(_supabase_top_n_fn),
    name="supabase_top_n",
    description=(
        "Top N lignes triées par une colonne numérique. "
        "direction ∈ {asc, desc}, n capé à 1000."
    ),
)


supabase_invoke_rpc = StructuredTool.from_function(
    coroutine=bind_session(_supabase_invoke_rpc_fn),
    name="supabase_invoke_rpc",
    description=(
        "Appelle une fonction RPC PostgreSQL whitelistée par l'admin. "
        "args = liste positionnelle de valeurs."
    ),
)


supabase_storage_list = StructuredTool.from_function(
    coroutine=bind_session(_supabase_storage_list_fn),
    name="supabase_storage_list",
    description=(
        "Liste le contenu d'un bucket Storage. NON DISPONIBLE en v1 "
        "(deferred v2)."
    ),
)


supabase_sql_advanced = StructuredTool.from_function(
    coroutine=bind_session(_supabase_sql_advanced_fn),
    name="supabase_sql_advanced",
    description=(
        "SQL brut, gated par advanced_sql_enabled sur la connexion. "
        "À n'utiliser que pour CTE / window functions / sous-requêtes "
        "que les autres tools ne couvrent pas."
    ),
)
