"""Piilot plugin ``supabase`` — schema-aware Supabase connector.

Entry point referenced by ``[project.entry-points."piilot.plugins"]``
in ``pyproject.toml``. The Piilot core boot loop instantiates this
class once at startup and calls ``register(ctx)`` to wire migrations,
i18n and the connector spec.

Phase-by-phase wiring
---------------------

This module grows phase by phase per ``suivi.md`` (worktree
``PLT-32`` of ``AICockpit``):

* Phase 4 — migrations + integrations_supabase schema (✅ live).
* Phase 5 — connector + admin routes (this commit wires the
  connector; routes follow in the same phase).
* Phase 6 — agent tools (3 coordination + 9 business + 1 advanced).
* Phase 8 — agent template ``supabase_data_assistant``.

What's wired today
------------------

* :meth:`Plugin.register`
    - ``ctx.migrations.register_schema('supabase', __file__, 'migrations')``
    - ``ctx.i18n.register_locales('supabase', __file__, 'locales')``
    - :func:`piilot.sdk.connectors.register_connector` with the
      ``supabase.api`` spec — ``auth_type=custom`` because Supabase
      needs two independent secrets and the SDK manifest schema only
      accepts one of {api_key, oauth2, basic, custom}. ``custom``
      is the umbrella value that lets us declare both via
      ``credentials_schema``.

The two secrets:
  * ``pg_readonly_password`` — REQUIRED. Postgres password for the
    ``piilot_readonly`` role created by the admin via the snippet
    we generate for them in Phase 5's setup wizard. Drives both the
    introspection and the runtime SELECT path.
  * ``supabase_pat`` — OPTIONAL. Personal Access Token for the
    Supabase Management API. Without it the plugin still covers
    ~90% of the surface (tables + RPC); with it we get edge
    functions / advisors. The PAT is never used at agent runtime —
    it only feeds the daily schema refresh.

Why no ``service_role_key``: deliberately absent and never to be
introduced. See ``docs/docs_dev/feat_supabase_connector.md`` §10.2.1
+ §14 (banned at the spec level).
"""

from __future__ import annotations

import logging

from piilot.sdk import Plugin as _Plugin
from piilot.sdk import load_manifest

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Connector spec
# ---------------------------------------------------------------------------
#
# Module-level so tests can rebuild the schema registry deterministically
# (pattern copied from piilot-pack-pennylane).
#
# auth_type=custom — see module docstring for the rationale.

_SUPABASE_CONNECTOR_SPEC: dict = {
    "id": "supabase.api",
    "auth_type": "custom",
    "credentials_schema": [
        # Phase 8 pivot: PAT-only flow. v0.1's pg_readonly_password
        # path is gone — the Management API SQL endpoint
        # (POST /v1/projects/{ref}/database/query) accepts the PAT
        # for both introspection and runtime queries, sidestepping
        # Supabase Cloud's IPv6-only direct PG endpoint.
        {
            "name": "supabase_pat",
            "type": "secret",
            "required": True,
            "label": (
                "Personal Access Token Supabase — généré dans "
                "Account → Access Tokens. Sert à toutes les "
                "requêtes SQL via la Management API."
            ),
        },
    ],
}


# ---------------------------------------------------------------------------
# Plugin entry class
# ---------------------------------------------------------------------------


class Plugin(_Plugin):
    """Plugin entry class — must subclass ``piilot.sdk.Plugin``."""

    manifest = load_manifest(__file__)

    def register(self, ctx) -> None:
        """Wire the plugin's extension points.

        Order matters: migrations first (so the schema exists before
        any other primitive touches it), then declarative
        registrations (i18n, connector). Routes / tools / templates
        will be added in upcoming phases as they land.
        """
        ctx.migrations.register_schema(
            "supabase",
            __file__,
            "migrations",
        )

        ctx.i18n.register_locales(
            "supabase",
            __file__,
            "locales",
        )

        # Connector declaration — drives auto-encryption of every
        # ``secret`` field on ``save_connection``. The actual
        # ``register_connector`` is a module-level function on
        # ``piilot.sdk.connectors`` (reads the ``current_plugin``
        # contextvar bound by the loader) — NOT a method on
        # ``ctx.connectors``. Same pattern as Pennylane (the SDK
        # docstring noting otherwise is inaccurate, candidate v0.3
        # doc fix tracked upstream).
        from piilot.sdk.connectors import register_connector

        register_connector(_SUPABASE_CONNECTOR_SPEC)

        # Routes — admin-only CRUD on connections + setup-snippet,
        # refresh-schema (rate-limited), test-connection, audit.
        # Mounted under /plugins/supabase/* by the SDK.
        from .routes import wire_routes

        wire_routes()

        # Module — exposes the Supabase configuration surface as a
        # module view at /modules/supabase-settings. Frontend wires a
        # ``SupabaseSettingsView`` to the slug via
        # ``registerModuleView('supabase-settings', …)``.
        # Idempotent upsert (preserves UUID across reinstalls).
        from piilot.sdk.db import Json
        from piilot.sdk.modules import register_module

        register_module(
            {
                "slug": "supabase-settings",
                "module_name": "Configuration Supabase",
                "description": (
                    "Connecter et gérer un ou plusieurs projets Supabase : "
                    "wizard d'onboarding, sélection des tables exposées, "
                    "test du user piilot_readonly, audit des requêtes."
                ),
                "icon": "database",
                "category": "integration",
                "status": "published",
                "config": Json({"type": "settings", "requires_admin": True}),
            }
        )

        # Agent tools — 3 coordination (multi-connection hub) + 9
        # business (search / describe / select / count / aggregate /
        # top_n / invoke_rpc / storage / sql_advanced). The 9 business
        # tools read the active connection from the session scope —
        # the agent must call ``supabase_list_connections`` +
        # ``supabase_select_connection`` first when the company has
        # 2+ Supabase accounts.
        from piilot.sdk.tools import register_tool

        from .tools_business import (
            supabase_aggregate,
            supabase_count,
            supabase_describe_table,
            supabase_invoke_rpc,
            supabase_search_schema,
            supabase_select,
            supabase_sql_advanced,
            supabase_storage_list,
            supabase_top_n,
        )
        from .tools_coordination import (
            supabase_describe_connection,
            supabase_list_connections,
            supabase_select_connection,
        )

        _TOOL_SPECS: list[tuple[str, object]] = [
            ("supabase.list_connections", supabase_list_connections),
            ("supabase.select_connection", supabase_select_connection),
            ("supabase.describe_connection", supabase_describe_connection),
            ("supabase.search_schema", supabase_search_schema),
            ("supabase.describe_table", supabase_describe_table),
            ("supabase.select", supabase_select),
            ("supabase.count", supabase_count),
            ("supabase.aggregate", supabase_aggregate),
            ("supabase.top_n", supabase_top_n),
            ("supabase.invoke_rpc", supabase_invoke_rpc),
            ("supabase.storage_list", supabase_storage_list),
            ("supabase.sql_advanced", supabase_sql_advanced),
        ]
        for tool_id, tool_obj in _TOOL_SPECS:
            register_tool({"id": tool_id, "tool": tool_obj})

        # Agent template — ``supabase_data_assistant`` ready-to-use
        # data agent with anti-injection prompt + 12 plugin tools
        # auto-injected. Idempotent upsert on a deterministic UUID
        # so existing agents derived from this template keep their
        # ``template_id`` link across re-installs.
        from .agent_template import register_agent_template

        register_agent_template()
