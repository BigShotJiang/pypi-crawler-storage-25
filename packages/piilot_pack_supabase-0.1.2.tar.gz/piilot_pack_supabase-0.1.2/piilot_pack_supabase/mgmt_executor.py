"""Run validated SQL via the Supabase Management API.

Replaces the asyncpg / piilot_readonly path of v0.1's executor.py
with a thin wrapper over

    POST {API}/v1/projects/{ref}/database/query

This endpoint takes the project's Personal Access Token (PAT), runs
the SQL against the project's Postgres, and returns the rows as a
JSON array. No port-5432 connection, no IPv6 issue, no PG user to
configure on the customer side.

Trade-off vs the v0.1 PG-direct path
------------------------------------

We lose the Postgres-level ``READ ONLY DEFERRABLE`` belt that
refused writes server-side. The single layer protecting against
DML now is the :mod:`piilot_pack_supabase.validator` (sqlglot AST
walk + table whitelist + denied-functions list). The validator
already covers 47 attack vectors and the tests pin its behaviour;
it's the same defense that the LLM-generated SQL went through in
v0.1 anyway.

What we keep verbatim
---------------------

* :class:`ExecutionResult` and :class:`ExecutionError` dataclasses —
  same shape as v0.1, so :mod:`tools_business` can swap the executor
  with a one-line change. The ``kind`` field still feeds the audit
  log ``status`` column with stable codes.
* :func:`sanitize_rows` — re-imported here for caller convenience;
  the implementation lives in v0.1's executor.py until that file is
  dropped, then it moves here.

Public surface
--------------

* :class:`ManagementExecutor` — owns one :class:`httpx.AsyncClient`
  per process (not per connection — the PAT travels in the
  Authorization header per-call).
* :class:`ExecutionResult` / :class:`ExecutionError` — typed
  outcomes.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

MANAGEMENT_API_BASE = "https://api.supabase.com"

DEFAULT_HTTP_TIMEOUT_S = 90.0
"""Per-request timeout for the Management API. The pg_get_function_*
helpers used during refresh-schema can take 30-60s on Supabase Cloud
projects with lots of internal functions (auth schema + extensions
add up). 90s leaves margin without making a stuck request feel
forever to the admin."""

DEFAULT_ROW_CAP = 1000
"""Max rows returned to the LLM. Mirrors v0.1 — the validator
auto-injects ``LIMIT 1000`` so this is a belt-after-LIMIT guard."""

DEFAULT_STRING_TRUNCATE_CHARS = 2000
"""Max characters per string cell before we truncate. Mitigation
against prompt injection via cell content (cf spec §10.2.5)."""

_TRUNCATE_MARKER = "…[truncated]"


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------


@dataclass
class ExecutionResult:
    """Outcome of a single :meth:`ManagementExecutor.run` call.

    Same shape as the v0.1 PG-direct ExecutionResult so that
    :mod:`tools_business._run_sql` switches with a one-line import
    change.
    """

    rows: list[dict[str, Any]]
    rows_returned: int
    truncated_rows: bool
    truncated_strings: int
    duration_ms: int


@dataclass
class ExecutionError(Exception):
    """One error type for every failure path on the Management API.

    Attributes:
        kind: stable code suitable for the audit log ``status``
            column. Maps as follows:
              * 401 → ``invalid_token``
              * 403 → ``forbidden``  (PAT lacks scope on the project)
              * 404 → ``not_found``  (project ref unknown)
              * 408 / timeout → ``timeout``
              * 4xx with PG error in body → ``pg_error``
              * 5xx → ``server_error``
              * network / connect timeout → ``network``
              * else → ``unknown``
    """

    kind: str
    message: str
    duration_ms: int = 0
    sql_excerpt: str = field(default="", repr=False)

    def __str__(self) -> str:  # pragma: no cover — trivial
        return f"Management API {self.kind}: {self.message}"


# ---------------------------------------------------------------------------
# Sanitization (kept identical to v0.1's executor.py)
# ---------------------------------------------------------------------------


def sanitize_rows(
    rows: list[dict[str, Any]],
    *,
    row_cap: int = DEFAULT_ROW_CAP,
    string_truncate_chars: int = DEFAULT_STRING_TRUNCATE_CHARS,
) -> tuple[list[dict[str, Any]], bool, int]:
    """Cap rows + truncate string fields. Pure function, no IO.

    Args:
        rows: rows as returned by the Management API (dicts already).
        row_cap: maximum number of rows to return.
        string_truncate_chars: maximum characters per string cell.

    Returns:
        ``(safe_rows, truncated_rows, truncated_strings_count)``.
    """
    truncated_rows = len(rows) > row_cap
    capped = rows[:row_cap]

    truncated_strings = 0
    safe: list[dict[str, Any]] = []
    marker_len = len(_TRUNCATE_MARKER)

    for row in capped:
        new_row: dict[str, Any] = {}
        for key, value in row.items():
            if isinstance(value, str) and len(value) > string_truncate_chars:
                head = value[: max(0, string_truncate_chars - marker_len)]
                new_row[key] = head + _TRUNCATE_MARKER
                truncated_strings += 1
            else:
                new_row[key] = value
        safe.append(new_row)

    return safe, truncated_rows, truncated_strings


# ---------------------------------------------------------------------------
# Executor
# ---------------------------------------------------------------------------


class ManagementExecutor:
    """Stateless-ish wrapper over the Management API SQL endpoint.

    Owns ONE :class:`httpx.AsyncClient` for the whole process —
    auth lives in the Authorization header per-call (PAT travels
    with the request, not the client). HTTP keep-alive across calls
    amortizes TLS handshakes when the same backend hits multiple
    Supabase projects.

    Thread/loop safety: a single instance is shared by the asyncio
    loop running the FastAPI backend. Client creation is serialized
    via an ``asyncio.Lock``.
    """

    def __init__(
        self,
        *,
        http_timeout_s: float = DEFAULT_HTTP_TIMEOUT_S,
        row_cap: int = DEFAULT_ROW_CAP,
        string_truncate_chars: int = DEFAULT_STRING_TRUNCATE_CHARS,
    ) -> None:
        self._http_timeout_s = http_timeout_s
        self._row_cap = row_cap
        self._string_truncate_chars = string_truncate_chars
        self._client: httpx.AsyncClient | None = None
        self._lock = asyncio.Lock()

    async def _get_client(self) -> httpx.AsyncClient:
        """Lazy client creation, serialized."""
        if self._client is not None:
            return self._client
        async with self._lock:
            if self._client is None:
                self._client = httpx.AsyncClient(timeout=self._http_timeout_s)
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client. Idempotent."""
        async with self._lock:
            if self._client is not None:
                await self._client.aclose()
                self._client = None

    async def run(
        self,
        *,
        project_ref: str,
        pat: str,
        sql: str,
        query_params: list[Any] | None = None,
    ) -> ExecutionResult:
        """Run validated SQL on the Supabase project via Management API.

        Args:
            project_ref: Supabase Cloud project ref slug (e.g.
                ``abcdefghij``). Identifies the project the PAT
                operates on. Use :func:`extract_project_ref` to
                derive it from a URL.
            pat: cleartext Personal Access Token. Decrypt before
                passing in — NEVER persist or log.
            sql: validated SQL — caller MUST have passed it through
                :func:`piilot_pack_supabase.validator.validate` first.
                The Management API will happily run DML / DDL if
                we let it, so the validator is the single layer
                blocking writes.
            query_params: optional positional params. The Management
                API endpoint inlines params into the SQL itself
                (no native placeholder support), so we substitute
                ``$N`` placeholders client-side using sqlglot's
                literal quoting. ``None`` if the SQL has no
                placeholders.

        Returns:
            :class:`ExecutionResult` with sanitized rows.

        Raises:
            ExecutionError: on every failure path.
        """
        client = await self._get_client()
        url = f"{MANAGEMENT_API_BASE}/v1/projects/{project_ref}/database/query"
        headers = {
            "Authorization": f"Bearer {pat}",
            "Content-Type": "application/json",
        }

        # The Management API takes a single ``query`` field with the
        # SQL inlined. We substitute placeholders on the client side
        # using validator-safe literal quoting (sqlglot exp.Literal
        # → escaped ``'value'``).
        materialized_sql = _materialize_params(sql, query_params)

        started = time.monotonic()
        try:
            resp = await client.post(
                url,
                headers=headers,
                json={"query": materialized_sql},
            )
        except (httpx.TimeoutException, httpx.NetworkError) as exc:
            duration = int((time.monotonic() - started) * 1000)
            raise ExecutionError(
                kind="network",
                message=f"{type(exc).__name__}: {exc}",
                duration_ms=duration,
                sql_excerpt=_excerpt(materialized_sql),
            ) from exc

        duration = int((time.monotonic() - started) * 1000)
        rows = self._handle_response(resp, duration, materialized_sql)
        safe_rows, truncated_rows, truncated_strings = sanitize_rows(
            rows,
            row_cap=self._row_cap,
            string_truncate_chars=self._string_truncate_chars,
        )
        return ExecutionResult(
            rows=safe_rows,
            rows_returned=len(safe_rows),
            truncated_rows=truncated_rows,
            truncated_strings=truncated_strings,
            duration_ms=duration,
        )

    def _handle_response(
        self,
        resp: httpx.Response,
        duration: int,
        sql: str,
    ) -> list[dict[str, Any]]:
        """Translate HTTP status into ``ExecutionResult`` or raise.

        The Supabase Management API ``database/query`` endpoint
        returns 201 Created on success (not 200). The error paths
        (4xx / 5xx) follow standard HTTP semantics.
        """
        sc = resp.status_code

        if sc in (200, 201):
            try:
                body = resp.json()
            except ValueError as exc:
                raise ExecutionError(
                    kind="server_error",
                    message=f"non-JSON 200 body: {exc}",
                    duration_ms=duration,
                    sql_excerpt=_excerpt(sql),
                ) from exc
            if not isinstance(body, list):
                # Some endpoints return ``{"result": [...]}`` instead
                # of a flat list — accept both shapes.
                if isinstance(body, dict) and isinstance(body.get("result"), list):
                    return body["result"]
                raise ExecutionError(
                    kind="server_error",
                    message=(
                        f"expected JSON array, got {type(body).__name__}"
                    ),
                    duration_ms=duration,
                    sql_excerpt=_excerpt(sql),
                )
            return body

        # Error paths
        message = _extract_error_message(resp)
        if sc == 401:
            kind = "invalid_token"
        elif sc == 403:
            kind = "forbidden"
        elif sc == 404:
            kind = "not_found"
        elif sc == 408 or sc == 504:
            kind = "timeout"
        elif 400 <= sc < 500:
            # Most likely a PG error wrapped in 4xx (syntax, permission,
            # constraint, …). The Management API uses 4xx for query
            # errors that Postgres itself rejected.
            kind = "pg_error"
        elif 500 <= sc < 600:
            kind = "server_error"
        else:
            kind = "unknown"

        raise ExecutionError(
            kind=kind,
            message=message,
            duration_ms=duration,
            sql_excerpt=_excerpt(sql),
        )


# ---------------------------------------------------------------------------
# Helpers (public for tests)
# ---------------------------------------------------------------------------


def _excerpt(sql: str, length: int = 200) -> str:
    """Trim a SQL string for logging / audit fields."""
    one_line = " ".join(sql.split())
    return (one_line[:length] + "…") if len(one_line) > length else one_line


def _extract_error_message(resp: httpx.Response) -> str:
    """Pull a useful error message out of an error response."""
    try:
        body = resp.json()
    except ValueError:
        return f"{resp.status_code} {resp.reason_phrase}"
    if not isinstance(body, dict):
        return f"{resp.status_code} {resp.reason_phrase}"
    for key in ("message", "error", "detail", "msg"):
        v = body.get(key)
        if isinstance(v, str) and v:
            return v
    return f"{resp.status_code} {resp.reason_phrase}"


def _materialize_params(sql: str, params: list[Any] | None) -> str:
    """Inline ``$1, $2, …`` placeholders with quoted literal values.

    The Management API's ``database/query`` endpoint takes a single
    ``query`` string — no native parameter binding. We substitute
    placeholders client-side BEFORE sending; the validator already
    walked the AST and ensured the SQL shape is safe, but the values
    still need to be quoted to prevent string-injection.

    Quoting strategy: sqlglot's ``exp.Literal.string`` emits proper
    PG quoting (single quotes doubled, no smart-tricks). We use
    Python's repr-like ``"'" + value.replace("'", "''") + "'"``
    for strings, and direct casting for numbers / booleans / None.

    Args:
        sql: SQL with ``$1, $2, …`` placeholders.
        params: ordered list of values to inline. ``None`` or empty
            means the SQL is parameterless.

    Returns:
        SQL with literals inlined. Idempotent on already-inlined SQL
        (no ``$N`` matches → no substitution).
    """
    if not params:
        return sql
    out = sql
    # Replace from the highest index first to avoid ``$10`` getting
    # caught by the ``$1`` regex.
    for i in range(len(params), 0, -1):
        placeholder = f"${i}"
        value = params[i - 1]
        out = out.replace(placeholder, _quote_literal(value))
    return out


def _quote_literal(value: Any) -> str:
    """Quote a Python value as a PG literal."""
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    # Strings (and anything else we coerce via str(...)).
    s = str(value).replace("'", "''")
    return f"'{s}'"
