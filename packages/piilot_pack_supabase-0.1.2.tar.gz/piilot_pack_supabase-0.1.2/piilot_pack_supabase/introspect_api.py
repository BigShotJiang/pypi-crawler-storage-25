"""Supabase Management API client — edge functions, advisors, storage.

Uses ``httpx.AsyncClient`` with the Personal Access Token (PAT) the
admin saved at onboarding. Pairs with :mod:`introspect_pg` (which
covers tables / RPC via the Postgres connection) to populate
:class:`integrations_supabase.schema_snapshot`.

Why this is a separate module
-----------------------------

Edge functions, storage buckets and advisor outputs aren't reachable
via Postgres queries — they're managed by Supabase's control plane,
exposed under ``api.supabase.com``. We hit those endpoints directly
with httpx, no MCP middleware required (cf. spec §2 + suivi.md).

The PAT is **optional** end-to-end: if the admin doesn't set one at
onboarding (cf. spec §7.4), the introspection still covers ~90% of
the surface (tables + RPC) via introspect_pg. Routes / agent tools
that depend on edge functions / storage / advisors must check
whether the PAT is configured before invoking these helpers and
return an empty list with a hint when it isn't.

Public surface
--------------

* :class:`SupabaseAPIError` — one error type, with stable
  ``status_code`` (raw HTTP) and ``kind`` ({invalid_token,
  forbidden, not_found, server_error, network}).
* :func:`list_edge_functions`
* :func:`list_storage_buckets` — v1: returns []; spec §14 defers
  storage to v2 (the Management API does not expose a buckets list
  endpoint, only the Storage REST API does, and that requires the
  anon key which we deliberately don't ship).
* :func:`list_advisors_security`
* :func:`list_advisors_performance`
* :func:`ping_management_api` — used by the wizard step 7.4.1 to
  validate a PAT immediately on save.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MANAGEMENT_API_BASE = "https://api.supabase.com"
DEFAULT_TIMEOUT_S = 30.0
"""Per-request timeout. Generous because the Management API can be
slow under contention; advisor reports occasionally take 10-15s."""


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------


@dataclass
class SupabaseAPIError(Exception):
    """One error type for every Management API failure path.

    Attributes:
        kind: stable code suitable for the audit log + UI banner
            ({invalid_token, forbidden, not_found, server_error,
            network, unknown}).
        status_code: raw HTTP status, 0 if request never landed
            (network / timeout).
        message: short human-readable detail. Never includes the PAT.
    """

    kind: str
    status_code: int
    message: str

    def __str__(self) -> str:  # pragma: no cover — trivial
        return f"Supabase API {self.kind} ({self.status_code}): {self.message}"


# ---------------------------------------------------------------------------
# Internal HTTP helper
# ---------------------------------------------------------------------------


async def _get(
    client: httpx.AsyncClient,
    path: str,
    *,
    pat: str,
    expected_list: bool = True,
) -> Any:
    """GET ``MANAGEMENT_API_BASE + path`` with the PAT, parse + return.

    Raises :class:`SupabaseAPIError` for any non-200 outcome. Maps
    standard status codes to stable ``kind`` strings:

      * 401 → ``invalid_token``
      * 403 → ``forbidden`` (project out of PAT scope)
      * 404 → ``not_found``
      * 5xx → ``server_error``
      * timeout / connection refused → ``network``

    Args:
        client: an open ``httpx.AsyncClient``.
        path: path component starting with ``/v1/...``.
        pat: Personal Access Token (raw, decrypted).
        expected_list: if True and the body parses to a non-list,
            raises ``server_error`` (defensive for a flaky API).

    Returns:
        Parsed JSON body — typically a list of dicts.
    """
    headers = {
        "Authorization": f"Bearer {pat}",
        "Accept": "application/json",
    }
    try:
        response = await client.get(
            MANAGEMENT_API_BASE + path,
            headers=headers,
            timeout=DEFAULT_TIMEOUT_S,
        )
    except (httpx.TimeoutException, httpx.NetworkError) as exc:
        raise SupabaseAPIError(
            kind="network",
            status_code=0,
            message=f"{type(exc).__name__}: {exc}",
        ) from exc

    if response.status_code == 401:
        raise SupabaseAPIError(
            kind="invalid_token",
            status_code=401,
            message=(
                "Personal Access Token rejected. Generate a new PAT in "
                "Supabase → Account → Access Tokens and update the "
                "connection."
            ),
        )
    if response.status_code == 403:
        raise SupabaseAPIError(
            kind="forbidden",
            status_code=403,
            message=(
                "PAT does not cover this project. Either re-create it "
                "without project restriction, or pick the project the "
                "PAT was scoped to."
            ),
        )
    if response.status_code == 404:
        raise SupabaseAPIError(
            kind="not_found",
            status_code=404,
            message="Endpoint or project not found.",
        )
    if 500 <= response.status_code < 600:
        raise SupabaseAPIError(
            kind="server_error",
            status_code=response.status_code,
            message=(
                f"Supabase API returned {response.status_code}. "
                "Try again later."
            ),
        )
    if response.status_code != 200:
        raise SupabaseAPIError(
            kind="unknown",
            status_code=response.status_code,
            message=f"Unexpected status code: {response.status_code}",
        )

    try:
        body = response.json()
    except ValueError as exc:
        raise SupabaseAPIError(
            kind="server_error",
            status_code=response.status_code,
            message=f"Body is not valid JSON: {exc}",
        ) from exc

    if expected_list and not isinstance(body, list):
        raise SupabaseAPIError(
            kind="server_error",
            status_code=response.status_code,
            message=(
                f"Expected JSON array, got {type(body).__name__}. "
                "Supabase API contract may have changed."
            ),
        )
    return body


# ---------------------------------------------------------------------------
# Edge functions
# ---------------------------------------------------------------------------


async def list_edge_functions(
    client: httpx.AsyncClient,
    project_ref: str,
    pat: str,
) -> list[dict[str, Any]]:
    """List edge functions deployed to the project.

    Returns dicts with keys depending on the Supabase API contract:
      * ``id`` — function UUID
      * ``slug`` — function URL slug (``hello-world``)
      * ``name`` — display name
      * ``status`` — ``ACTIVE`` / ``THROTTLED`` / …
      * ``version`` — deployment version
      * ``created_at`` / ``updated_at``

    The Supabase API may add fields in future revisions — we
    pass-through any unknown keys verbatim into the snapshot.
    """
    body = await _get(
        client,
        f"/v1/projects/{project_ref}/functions",
        pat=pat,
    )
    return list(body)


# ---------------------------------------------------------------------------
# Storage buckets — v1 stub, see module docstring
# ---------------------------------------------------------------------------


async def list_storage_buckets(
    client: httpx.AsyncClient,
    project_ref: str,
    pat: str,
) -> list[dict[str, Any]]:
    """v1 stub — always returns ``[]``.

    The Management API doesn't expose a buckets list. The Storage
    REST API does, but it requires the project's anon key (which we
    deliberately don't ship — see security model) or the service_role
    key (which we ban). Storage support is deferred to v2.

    Kept as a real coroutine so the Phase 8 caller wiring doesn't
    have to special-case it: the call returns an empty list, the
    snapshot ends up with ``storage_buckets = []``, and the UI shows
    "Storage exposure not yet supported" for that section.
    """
    # pragma: no cover — unconditional empty return
    _ = (client, project_ref, pat)  # silence unused-arg lint
    return []


# ---------------------------------------------------------------------------
# Advisors
# ---------------------------------------------------------------------------


async def list_advisors_security(
    client: httpx.AsyncClient,
    project_ref: str,
    pat: str,
) -> list[dict[str, Any]]:
    """Security advisor findings (RLS gaps, exposed schemas, …).

    See Supabase docs → Database → Advisors. Findings have at minimum:
      * ``id`` — advisor rule id
      * ``name`` / ``title``
      * ``description``
      * ``level`` — ``ERROR`` / ``WARN`` / ``INFO``
      * ``cache_key`` — used by Supabase to dedupe

    We don't filter or transform these — the admin reads them as-is
    in the Sécurité tab.
    """
    body = await _get(
        client,
        f"/v1/projects/{project_ref}/advisors/security",
        pat=pat,
        expected_list=False,
    )
    return _normalize_advisors(body)


async def list_advisors_performance(
    client: httpx.AsyncClient,
    project_ref: str,
    pat: str,
) -> list[dict[str, Any]]:
    """Performance advisor findings (missing indexes, slow queries, …).

    Same shape as :func:`list_advisors_security`.
    """
    body = await _get(
        client,
        f"/v1/projects/{project_ref}/advisors/performance",
        pat=pat,
        expected_list=False,
    )
    return _normalize_advisors(body)


def _normalize_advisors(body: Any) -> list[dict[str, Any]]:
    """Return the advisor findings as a list, regardless of envelope.

    The Supabase advisors endpoint historically returned both
    ``[…]`` and ``{"lints": [...]}`` over time. We accept either and
    normalize to a flat list so callers don't have to branch.
    """
    if isinstance(body, list):
        return body
    if isinstance(body, dict):
        for key in ("lints", "findings", "results", "data"):
            if isinstance(body.get(key), list):
                return list(body[key])
        return []
    return []


# ---------------------------------------------------------------------------
# Ping (used by the onboarding wizard)
# ---------------------------------------------------------------------------


async def ping_management_api(
    client: httpx.AsyncClient,
    project_ref: str,
    pat: str,
) -> dict[str, Any]:
    """Lightweight liveness check used by step 7.4.1 of the wizard.

    Hits ``GET /v1/projects/{ref}`` — returns the project metadata
    if the PAT is valid and authorized for this project, otherwise
    raises :class:`SupabaseAPIError` with a precise ``kind``.
    """
    body = await _get(
        client,
        f"/v1/projects/{project_ref}",
        pat=pat,
        expected_list=False,
    )
    if not isinstance(body, dict):
        raise SupabaseAPIError(
            kind="server_error",
            status_code=200,
            message="Project metadata is not an object",
        )
    return body
