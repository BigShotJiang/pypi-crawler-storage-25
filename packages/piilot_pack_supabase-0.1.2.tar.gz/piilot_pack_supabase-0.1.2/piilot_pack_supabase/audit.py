"""Append-only audit log for every Supabase agent tool call.

Every meaningful interaction with the plugin — agent tool call,
schema refresh, manual test_connection probe — gets one row in
``integrations_supabase.audit_log``. The table is append-only at the
``GRANT`` level (cf. migration 003): even an admin session can't
``UPDATE`` or ``DELETE`` past entries.

What goes in the row
--------------------

* ``connection_id``, ``company_id``, ``user_id``, ``agent_id`` —
  the four identity dimensions. ``user_id`` and ``agent_id`` are
  None for system-driven calls (refresh job, lifespan tasks).
* ``tool_name`` — stable id (``supabase_select``,
  ``supabase_top_n``, ``supabase_refresh``, …).
* ``query_kind`` — coarse category {postgrest, sql, rpc, storage,
  introspect, meta}.
* ``query_payload`` — JSONB snapshot of the call arguments,
  **sanitized** of any field that could leak credentials (the
  helper :func:`sanitize_payload` clears values for keys named like
  passwords / tokens / secrets).
* ``status`` — ok / rejected_sqlglot / rejected_whitelist /
  rejected_rls / pg_error / timeout / rate_limited.
* ``rejection_reason``, ``rows_returned``, ``duration_ms`` —
  detail.

Sanitization contract
---------------------

Audit rows are read by company admins via the Audit tab. They MUST
never expose secrets. :func:`sanitize_payload` walks the payload
recursively and replaces values whose key name matches a deny-list
substring with ``"<redacted>"``. The deny-list is conservative
(password, token, secret, api_key, …) — false positives (a column
literally named ``password_strength``) are acceptable; false
negatives are not.

Public surface
--------------

* :func:`log_query` — async fire-and-forget INSERT. Swallows DB
  errors with a logger.warning; we never want an audit failure to
  cascade into a tool call failure (tool calls have their own
  failure semantics; audit is observational).
* :func:`sanitize_payload` — pure helper, exposed for tests.
"""

from __future__ import annotations

import logging
from typing import Any

from piilot.sdk.db import Json, run_in_thread

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Sanitization
# ---------------------------------------------------------------------------

_REDACTED = "<redacted>"
"""String that replaces a sensitive value. Stable for tests."""

_SENSITIVE_KEY_SUBSTRINGS: tuple[str, ...] = (
    "password",
    "passwd",
    "secret",
    "token",
    "api_key",
    "apikey",
    "auth",
    "credential",
    "private_key",
    "service_role",
    "pat",
)
"""Lowercase substrings that mark a key as carrying a secret. The
match is substring-based (not exact) so variants like
``pg_readonly_password`` and ``access_token`` both get caught."""


def sanitize_payload(payload: Any) -> Any:
    """Return a copy of ``payload`` with sensitive values redacted.

    Walks dicts and lists recursively. For each dict, replaces values
    of keys whose lowercased name contains any
    :data:`_SENSITIVE_KEY_SUBSTRINGS` entry with :data:`_REDACTED`.
    Other values are passed through unchanged. Leaves the input
    untouched (returns a new structure).

    Args:
        payload: any JSON-able structure (dict, list, scalar).

    Returns:
        A sanitized copy. Scalars are returned as-is.
    """
    if isinstance(payload, dict):
        out: dict[str, Any] = {}
        for key, value in payload.items():
            key_lower = str(key).lower()
            if any(substr in key_lower for substr in _SENSITIVE_KEY_SUBSTRINGS):
                out[key] = _REDACTED
            else:
                out[key] = sanitize_payload(value)
        return out
    if isinstance(payload, list):
        return [sanitize_payload(item) for item in payload]
    return payload


# ---------------------------------------------------------------------------
# Insert helper
# ---------------------------------------------------------------------------

_INSERT_SQL = """
INSERT INTO integrations_supabase.audit_log (
    connection_id, company_id, user_id, agent_id,
    tool_name, query_kind, query_payload, status,
    rejection_reason, rows_returned, duration_ms
) VALUES (
    %(connection_id)s, %(company_id)s, %(user_id)s, %(agent_id)s,
    %(tool_name)s, %(query_kind)s, %(query_payload)s, %(status)s,
    %(rejection_reason)s, %(rows_returned)s, %(duration_ms)s
)
"""


async def log_query(
    *,
    connection_id: str,
    company_id: str,
    user_id: str | None,
    agent_id: str | None,
    tool_name: str,
    query_kind: str,
    query_payload: dict[str, Any] | list[Any],
    status: str,
    rejection_reason: str | None = None,
    rows_returned: int | None = None,
    duration_ms: int | None = None,
) -> None:
    """Insert one row into ``integrations_supabase.audit_log``.

    Fire-and-forget: any error is logged at WARNING and swallowed.
    A failed audit row should never propagate up the call stack and
    fail the tool call that triggered it — the tool's own outcome
    is the source of truth for the user, the audit is observational.

    Args mirror the table columns. ``query_payload`` is sanitized
    via :func:`sanitize_payload` before insertion — callers don't
    need to redact themselves.
    """
    sanitized = sanitize_payload(query_payload)

    def _do_insert() -> None:
        from piilot.sdk.db import cursor

        with cursor() as cur:
            cur.execute(
                _INSERT_SQL,
                {
                    "connection_id": connection_id,
                    "company_id": company_id,
                    "user_id": user_id,
                    "agent_id": agent_id,
                    "tool_name": tool_name,
                    "query_kind": query_kind,
                    "query_payload": Json(sanitized),
                    "status": status,
                    "rejection_reason": rejection_reason,
                    "rows_returned": rows_returned,
                    "duration_ms": duration_ms,
                },
            )

    try:
        await run_in_thread(_do_insert)
    except Exception as exc:  # noqa: BLE001 — audit must never fail the caller
        logger.warning(
            "[supabase] audit insert failed for tool=%s status=%s: %s",
            tool_name,
            status,
            type(exc).__name__,
        )
