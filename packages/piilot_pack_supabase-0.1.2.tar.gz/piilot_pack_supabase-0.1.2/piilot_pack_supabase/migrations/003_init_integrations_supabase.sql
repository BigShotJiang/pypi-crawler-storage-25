-- ============================================================================
-- 003_init_integrations_supabase.sql
-- ============================================================================
--
-- Real schema for the piilot-pack-supabase plugin. Replaces the scaffold
-- residues from migrations 001_init.sql + 002_hello_counter.sql (which
-- created an unused ``supabase.counter`` table).
--
-- Why a third migration instead of rewriting 001 / 002:
-- the SDK plugin loader tracks applied migrations by filename in
-- ``plugins_registry.migrations_applied``. Rewriting 001 in place would
-- be a no-op for any backend that already applied the old version.
-- Adding 003 lets every existing dev installation pick up the new
-- schema on next restart, while fresh installations apply 001 → 002
-- → 003 sequentially with the same end state (the cleanup at the top
-- of 003 ensures that path is idempotent too).
--
-- Tables created:
--   * integrations_supabase.schema_snapshot — 1 row per connection,
--     JSONB cache of the introspected schema (tables / RPC / edge fns
--     / advisors / extensions). Updated at every refresh.
--   * integrations_supabase.audit_log — append-only log of every
--     agent tool call, used for compliance + circuit breaker
--     thresholds (cf. spec §10.2.6 + §10.2.7).
--
-- Security model (cf. spec §10.2):
--   * RLS FORCE on both tables. The plugin DB user (``piilot_app``)
--     never bypasses; the backend role (``piilot``) is the sole
--     bypass identity, used by lifespan tasks that need to read
--     snapshots without a request context.
--   * snapshot: admins can write, members can read.
--   * audit_log: members can INSERT (so any agent run can log), but
--     only admins can SELECT. UPDATE / DELETE are refused at the
--     GRANT level — there is no policy for them.
--
-- All operations idempotent (IF NOT EXISTS / IF EXISTS / DROP POLICY
-- IF EXISTS). Safe to re-run on a partially-migrated DB.
-- ============================================================================

BEGIN;

-- ── 0. Cleanup scaffold residues ───────────────────────────────────────────

DROP TABLE IF EXISTS supabase.counter CASCADE;
DROP SCHEMA IF EXISTS supabase CASCADE;

-- ── 1. Target schema ───────────────────────────────────────────────────────

CREATE SCHEMA IF NOT EXISTS integrations_supabase;
GRANT USAGE ON SCHEMA integrations_supabase TO piilot_app;

-- ── 2. schema_snapshot ─────────────────────────────────────────────────────
--
-- ON DELETE CASCADE on connection_id: when an admin deletes a
-- Supabase connection, the snapshot disappears with it. The KB
-- metadata referenced by metadata_kb_id is cleaned up separately
-- through the standard knowledge_bases delete flow.

CREATE TABLE IF NOT EXISTS integrations_supabase.schema_snapshot (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id            UUID NOT NULL UNIQUE
                                 REFERENCES integrations_master.connections(id) ON DELETE CASCADE,
    company_id               UUID NOT NULL
                                 REFERENCES public.companies(id) ON DELETE CASCADE,

    -- JSONB snapshot of the introspection output. Each shape comes
    -- from one helper in :mod:`piilot_pack_supabase.introspect_pg` /
    -- :mod:`introspect_api` — see those modules for the dict
    -- contract.
    tables                   JSONB NOT NULL DEFAULT '[]',
    rpc_functions            JSONB NOT NULL DEFAULT '[]',
    edge_functions           JSONB NOT NULL DEFAULT '[]',
    storage_buckets          JSONB NOT NULL DEFAULT '[]',
    advisors                 JSONB NOT NULL DEFAULT '[]',
    extensions               JSONB NOT NULL DEFAULT '[]',

    -- The plugin-owned KB embedding the metadata for RAG over the
    -- schema. ON DELETE SET NULL because the KB delete is owned by
    -- the knowledge service, not us — we don't want a cascading
    -- delete of the snapshot if a user wipes the metadata KB.
    metadata_kb_id           UUID
                                 REFERENCES public.knowledge_bases(id) ON DELETE SET NULL,

    introspected_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_isb_schema_snapshot_company
    ON integrations_supabase.schema_snapshot(company_id);

-- ── 3. audit_log ───────────────────────────────────────────────────────────
--
-- Append-only by GRANT (no UPDATE / DELETE for piilot_app — see
-- bottom of this migration). Even an admin user logged in via the
-- API cannot retroactively edit or remove a row.

CREATE TABLE IF NOT EXISTS integrations_supabase.audit_log (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id            UUID NOT NULL
                                 REFERENCES integrations_master.connections(id) ON DELETE CASCADE,
    company_id               UUID NOT NULL
                                 REFERENCES public.companies(id) ON DELETE CASCADE,
    user_id                  UUID REFERENCES public.users(id) ON DELETE SET NULL,

    -- Agent UUID — no FK because the agents.* schema is a separate
    -- world owned by the core. NULL for refresh / introspection
    -- tasks not bound to an agent.
    agent_id                 UUID,

    -- Stable identifier used in the audit UI ('supabase_select',
    -- 'supabase_top_n', 'supabase_invoke_rpc', 'supabase_refresh', …).
    tool_name                TEXT NOT NULL,

    -- Coarse classification of what the call did:
    --   'postgrest' — PostgREST-composed query
    --   'sql'       — direct SQL (sql_advanced)
    --   'rpc'       — RPC function invocation
    --   'storage'   — Storage REST call (v2)
    --   'introspect'— refresh schema
    --   'meta'      — list_connections, select_connection
    query_kind               TEXT NOT NULL,

    -- Sanitized payload. Filter values may be redacted by the caller
    -- if they're flagged sensitive in the KB metadata; raw text
    -- never lands here verbatim if it could leak credentials.
    query_payload            JSONB NOT NULL,

    -- Outcome:
    --   'ok'                  — query succeeded
    --   'rejected_sqlglot'    — validator refused
    --   'rejected_whitelist'  — table not in whitelist
    --   'rejected_rls'        — RLS or grant blocked the read
    --   'pg_error'            — runtime PG error (incl. permission)
    --   'timeout'             — statement_timeout fired
    --   'rate_limited'        — too many calls
    status                   TEXT NOT NULL,

    -- Free-form detail for non-ok statuses. NULL when status='ok'.
    rejection_reason         TEXT,

    rows_returned            INTEGER,
    duration_ms              INTEGER,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Two indexes:
--   * (company_id, created_at DESC) — feeds the admin "Audit" tab
--     paginated by recency. Most-common access pattern.
--   * (status, created_at DESC) WHERE status != 'ok' — partial,
--     keeps the index small and lets the alerting query
--     ``SELECT … WHERE status='rejected_sqlglot' AND created_at >
--     now() - interval '1h'`` stay fast even at millions of rows.
CREATE INDEX IF NOT EXISTS idx_isb_audit_company_created
    ON integrations_supabase.audit_log(company_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_isb_audit_status_created
    ON integrations_supabase.audit_log(status, created_at DESC)
    WHERE status != 'ok';

CREATE INDEX IF NOT EXISTS idx_isb_audit_connection_created
    ON integrations_supabase.audit_log(connection_id, created_at DESC);

-- ── 4. Row Level Security (FORCE) ──────────────────────────────────────────

ALTER TABLE integrations_supabase.schema_snapshot ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_supabase.schema_snapshot FORCE ROW LEVEL SECURITY;

ALTER TABLE integrations_supabase.audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_supabase.audit_log FORCE ROW LEVEL SECURITY;

-- ── 5. Policies ────────────────────────────────────────────────────────────
--
-- Pattern lessons learned (cf. core CLAUDE.md → KB v2 hot-fix
-- 2026-04-29 → "policy RLS doit lister TO piilot, piilot_app car
-- PG18 ne fait plus l'inheritance implicite via pg_auth_members"):
-- when a policy applies to ``piilot``, list it explicitly in TO.
-- Inheritance via piilot_app GRANT'd to piilot does NOT propagate
-- the policy match in PG18.
--
-- For symmetry we use one policy per (table × role × action) so
-- the intent is auditable in pg_policies.

-- schema_snapshot: piilot bypass for both ENABLE + WITH CHECK
DROP POLICY IF EXISTS isb_snapshot_bypass ON integrations_supabase.schema_snapshot;
CREATE POLICY isb_snapshot_bypass
    ON integrations_supabase.schema_snapshot
    TO piilot
    USING (true) WITH CHECK (true);

-- schema_snapshot: members read, admins write
DROP POLICY IF EXISTS isb_snapshot_select_member ON integrations_supabase.schema_snapshot;
CREATE POLICY isb_snapshot_select_member
    ON integrations_supabase.schema_snapshot
    FOR SELECT TO piilot_app
    USING (public.is_company_member(company_id));

DROP POLICY IF EXISTS isb_snapshot_admin_write ON integrations_supabase.schema_snapshot;
CREATE POLICY isb_snapshot_admin_write
    ON integrations_supabase.schema_snapshot
    FOR ALL TO piilot_app
    USING (public.is_company_admin(company_id))
    WITH CHECK (public.is_company_admin(company_id));

-- audit_log: piilot bypass
DROP POLICY IF EXISTS isb_audit_bypass ON integrations_supabase.audit_log;
CREATE POLICY isb_audit_bypass
    ON integrations_supabase.audit_log
    TO piilot
    USING (true) WITH CHECK (true);

-- audit_log: SELECT admin only
DROP POLICY IF EXISTS isb_audit_select_admin ON integrations_supabase.audit_log;
CREATE POLICY isb_audit_select_admin
    ON integrations_supabase.audit_log
    FOR SELECT TO piilot_app
    USING (public.is_company_admin(company_id));

-- audit_log: INSERT member (so any tool call by any agent run can log)
DROP POLICY IF EXISTS isb_audit_insert_member ON integrations_supabase.audit_log;
CREATE POLICY isb_audit_insert_member
    ON integrations_supabase.audit_log
    FOR INSERT TO piilot_app
    WITH CHECK (public.is_company_member(company_id));

-- ── 6. Grants ──────────────────────────────────────────────────────────────
--
-- schema_snapshot: full DML for piilot_app (admins write, members
-- read are enforced via the policies above).
GRANT SELECT, INSERT, UPDATE, DELETE
    ON integrations_supabase.schema_snapshot
    TO piilot_app;

-- audit_log: SELECT + INSERT only. We deliberately omit UPDATE and
-- DELETE so the table is append-only at the GRANT level — even a
-- compromised admin session cannot rewrite history. The only way a
-- row can disappear is via the FK CASCADE chain
-- (connection delete → audit rows delete), which is acceptable.
GRANT SELECT, INSERT
    ON integrations_supabase.audit_log
    TO piilot_app;

COMMIT;
