"""SQL validation via sqlglot AST — layer 3 of defense in depth.

Refuses every query that isn't a single SELECT (or CTE wrapping a
SELECT) against whitelisted tables, blocks dangerous Postgres
functions (filesystem, dblink, locks, long pg_sleep), and auto-injects
or caps the LIMIT clause.

This module is **the only authorized path** between an agent-generated
SQL string and the asyncpg executor. It is paired with two other
layers that each guard the same surface:

* Layer 2 (Postgres-side): the ``piilot_readonly`` user has GRANT
  SELECT only on the whitelisted tables, plus role-level
  ``statement_timeout=10s`` and ``default_transaction_read_only=on``.
  See spec §10.2.2.
* Layer 4 (asyncpg-side): every query runs inside
  ``BEGIN READ ONLY DEFERRABLE`` with ``SET LOCAL statement_timeout``,
  which refuses writes server-side even if validate() lets one slip.
  See ``executor.py``.

None of the three layers is sufficient on its own — a sqlglot bug, a
Postgres permission misconfiguration, or an asyncpg edge case would
each individually open a hole. All three together is the contract.

Public surface
--------------

* :func:`validate` — entry point. Parses, walks, rewrites, returns a
  safe SQL string or raises :class:`ValidationError`.
* :class:`ValidationError` — single error type with a stable
  ``reason`` field; tests assert against substrings.

Caller responsibilities
-----------------------

1. Pass the actual ``selected_tables`` set for the connection — not a
   stale cache. The whitelist check is the only thing standing
   between the LLM and a table the admin never approved.
2. Treat every :class:`ValidationError` as a security event: log to
   the audit table with ``status='rejected_sqlglot'`` and the
   ``reason`` field. Repeated rejections from the same agent should
   trip the circuit breaker (cf spec §10.2.6).
"""

from __future__ import annotations

from dataclasses import dataclass

import sqlglot
from sqlglot import exp

# ---------------------------------------------------------------------------
# Public exception
# ---------------------------------------------------------------------------


@dataclass
class ValidationError(Exception):
    """Single error type for every rejection path.

    Attributes:
        reason: short machine-readable reason (substring-stable across
            sqlglot versions). Goes into the audit log
            ``rejection_reason`` column.
    """

    reason: str

    def __str__(self) -> str:  # pragma: no cover — trivial
        return f"SQL rejected: {self.reason}"


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_LIMIT_CAP = 1000
"""Hard cap injected on every query without an explicit LIMIT, and the
ceiling we clamp existing LIMITs down to. The executor enforces a
second cap on the result set after execution (spec §10.2.4)."""

_DIALECT = "postgres"


# AST node types that mean "this is not a pure read". The find_all walk
# refuses any of these anywhere in the tree, including inside CTEs —
# this catches ``WITH x AS (DELETE ... RETURNING *) SELECT * FROM x``
# and other DML-in-CTE attempts.
_FORBIDDEN_NODE_TYPES: tuple[type[exp.Expression], ...] = (
    exp.Insert,
    exp.Update,
    exp.Delete,
    exp.Merge,
    exp.Drop,
    exp.Alter,
    exp.TruncateTable,
    exp.Create,
    exp.Grant,
    exp.Copy,
    # exp.Set covers SESSION-level SET; SET LOCAL is issued by us via
    # the executor, never embedded in user SQL.
    exp.Set,
    # Generic catch for REVOKE / ANALYZE / VACUUM / REINDEX and any
    # other statement sqlglot doesn't model with a typed node — the
    # parser falls back to ``exp.Command`` for these (verified on
    # sqlglot 25.34). REVOKE in particular has no dedicated class.
    exp.Command,
)


# Function names sqlglot exposes lowercased on ``exp.Anonymous.this``.
# This is a deny-list, not an allow-list — Postgres ships ~3000 builtin
# functions and we don't want to block harmless ones (date_trunc,
# coalesce, json_extract_path, ...). The list below is the curated
# minimum that has filesystem / IO / DoS / privilege-escalation
# implications under typical Supabase setups.
_DENIED_FUNCTIONS: frozenset[str] = frozenset(
    {
        # Filesystem read (some superuser-only, some not — defensive)
        "pg_read_file",
        "pg_read_server_files",
        "pg_read_binary_file",
        "pg_read_binary_file_off_len",
        "pg_ls_dir",
        "pg_ls_logdir",
        "pg_ls_waldir",
        "pg_stat_file",
        # Large objects (raw binary IO out of the DB)
        "lo_export",
        "lo_import",
        "lo_open",
        "lo_close",
        # Cross-DB / out-of-process queries
        "dblink",
        "dblink_connect",
        "dblink_connect_u",
        "dblink_disconnect",
        "dblink_exec",
        "dblink_open",
        "dblink_send_query",
        "dblink_fetch",
        # Backend control / DoS
        "pg_terminate_backend",
        "pg_cancel_backend",
        "pg_promote",
        "pg_advisory_lock",
        "pg_advisory_lock_shared",
        "pg_advisory_xact_lock",
        "pg_advisory_xact_lock_shared",
        "pg_advisory_unlock",
        "pg_advisory_unlock_all",
        # Settings / role manipulation
        "set_config",
        # Subprocess / OS interaction (rare extensions but defensive)
        "system",
        "shell_exec",
    }
)


# pg_sleep IS allowed but capped at 1.0s — agents may legitimately want
# to introduce a short pause (rate limiting, demos), but a 99999-second
# sleep is a DoS on the connection slot.
_PG_SLEEP_MAX_SECONDS = 1.0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def validate(
    sql: str,
    *,
    allowed_tables: frozenset[tuple[str, str]],
    limit_cap: int = DEFAULT_LIMIT_CAP,
) -> str:
    """Validate ``sql`` and return a rewritten string safe to execute.

    Args:
        sql: candidate SQL. Single statement only. Trailing semicolon
            is tolerated; multiple statements are not.
        allowed_tables: frozen set of ``(schema, table)`` tuples the
            query may reference. Identifiers are compared
            case-insensitively after lowercasing — pass them lowercased
            for clarity.
        limit_cap: maximum LIMIT value to inject or clamp to. Defaults
            to :data:`DEFAULT_LIMIT_CAP` (1000).

    Returns:
        Rewritten SQL with a safe LIMIT (injected if absent, clamped
        if higher than ``limit_cap``).

    Raises:
        ValidationError: if any rule is violated. The ``reason`` is
            stable across sqlglot versions (asserted in tests).
    """
    if not sql or not sql.strip():
        raise ValidationError("empty SQL")

    # ── 1. Parse, single statement only ────────────────────────────────
    try:
        statements = sqlglot.parse(sql, dialect=_DIALECT)
    except sqlglot.errors.ParseError as e:
        raise ValidationError(f"parse error: {e}") from None

    # sqlglot emits None entries for empty statements (e.g. trailing ``;``);
    # strip them.
    statements = [s for s in statements if s is not None]
    if len(statements) == 0:
        raise ValidationError("empty statement after parsing")
    if len(statements) > 1:
        raise ValidationError(
            f"multi-statement queries are not allowed (found {len(statements)})"
        )

    tree = statements[0]

    # ── 2. Top-level must be a SELECT-shaped expression ────────────────
    # Accept the four read-only top-level shapes:
    #   - exp.Select          : plain SELECT
    #   - exp.With            : SELECT preceded by CTEs
    #   - exp.Union           : ``SELECT a UNION SELECT b`` (also covers
    #                            sqlglot subclasses Intersect / Except via
    #                            the shared base class — see below)
    #   - exp.Subquery        : top-level parenthesized subquery
    # Intersect / Except subclass exp.Union in current sqlglot versions
    # but the relationship has wobbled over releases — list them
    # explicitly so the gate stays stable across upstream refactors.
    _ALLOWED_TOP_LEVEL = (
        exp.Select,
        exp.With,
        exp.Union,
        exp.Intersect,
        exp.Except,
        exp.Subquery,
    )
    if not isinstance(tree, _ALLOWED_TOP_LEVEL):
        raise ValidationError(
            f"top-level statement must be SELECT (got {type(tree).__name__})"
        )

    # ── 3. Walk the whole tree — refuse forbidden node types anywhere ──
    # This catches DML-in-CTE: a `WITH del AS (DELETE ... RETURNING *)
    # SELECT * FROM del` parses as exp.With with an exp.Delete inside,
    # find_all(exp.Delete) flags it.
    for forbidden_type in _FORBIDDEN_NODE_TYPES:
        for node in tree.find_all(forbidden_type):
            raise ValidationError(
                f"forbidden node {type(node).__name__}: "
                f"{_short_sql(node)}"
            )

    # ── 4. Whitelist functions BEFORE tables ───────────────────────────
    # Functions in FROM clauses (e.g. ``FROM dblink(...)``) parse as
    # both ``exp.Table`` (with empty name and a function child) AND
    # ``exp.Anonymous``. Catching the Anonymous deny-list match first
    # produces a clearer error than "table public. not in whitelist".
    #
    # exp.Anonymous covers the bulk of builtins; typed function nodes
    # (Sum, Coalesce, …) bypass the Anonymous walk but those aren't in
    # our deny list anyway.
    for fn_node in tree.find_all(exp.Anonymous):
        fn_name = (fn_node.this or "").lower()
        if fn_name in _DENIED_FUNCTIONS:
            raise ValidationError(f"forbidden function: {fn_name}()")
        if fn_name == "pg_sleep":
            _check_pg_sleep_arg(fn_node)

    # ── 5. Whitelist tables (excluding CTE references) ─────────────────
    # ``WITH x AS (SELECT ...) SELECT * FROM x`` — sqlglot parses the
    # second ``x`` as exp.Table even though it's just a CTE ref. We
    # collect every CTE name up front and skip them from the whitelist
    # check (only when used unqualified — a schema-qualified ``foo.x``
    # is a real table and must be in the whitelist regardless).
    #
    # A Table node with empty name typically means a function-as-table
    # whose function isn't in our deny-list (e.g. ``generate_series``).
    # We refuse those outright — read-only data tools should target
    # real, named, whitelisted tables, not synthesised series.
    cte_names = {
        (cte.alias_or_name or "").lower()
        for cte in tree.find_all(exp.CTE)
    }
    for table_node in tree.find_all(exp.Table):
        name = (table_node.name or "").lower()
        schema_explicit = table_node.args.get("db") is not None
        if not name:
            raise ValidationError(
                f"unnamed table reference: {_short_sql(table_node)}"
            )
        if name in cte_names and not schema_explicit:
            continue
        schema = _extract_schema(table_node)
        if (schema, name) not in allowed_tables:
            raise ValidationError(
                f"table {schema}.{name} not in whitelist"
            )

    # ── 6. Inject / clamp LIMIT ────────────────────────────────────────
    _ensure_limit(tree, limit_cap)

    return tree.sql(dialect=_DIALECT)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _short_sql(node: exp.Expression) -> str:
    """Truncate a node's serialized SQL for the rejection message."""
    s = node.sql(dialect=_DIALECT)
    return (s[:80] + "…") if len(s) > 80 else s


def _extract_schema(table_node: exp.Table) -> str:
    """Return the lowercased schema name for a Table node, default 'public'."""
    db = table_node.args.get("db")
    if db is None:
        return "public"
    # ``db`` is an exp.Identifier; .name is the unquoted identifier text.
    return (db.name or "public").lower()


def _check_pg_sleep_arg(fn_node: exp.Anonymous) -> None:
    """Refuse ``pg_sleep(n)`` when n is a literal > _PG_SLEEP_MAX_SECONDS.

    Non-literal arguments (column refs, expressions) are denied
    outright — we cannot statically evaluate them.
    """
    args = fn_node.args.get("expressions") or []
    if not args:
        return
    first = args[0]
    if isinstance(first, exp.Literal) and first.is_number:
        try:
            value = float(first.this)
        except (TypeError, ValueError):
            raise ValidationError("pg_sleep argument must be a number") from None
        if value > _PG_SLEEP_MAX_SECONDS:
            raise ValidationError(
                f"pg_sleep > {_PG_SLEEP_MAX_SECONDS}s is denied"
            )
        return
    # Non-literal arg — we can't bound it, refuse.
    raise ValidationError("pg_sleep with a non-literal argument is denied")


def _ensure_limit(tree: exp.Expression, cap: int) -> None:
    """Ensure the SELECT-bearing node has a LIMIT <= cap.

    Mutates ``tree`` in place. Handles:
      * exp.Select → adjust args["limit"]
      * exp.With → adjust the inner expression's limit
      * exp.Union → wrap in an outer SELECT with LIMIT (Postgres
        accepts the LIMIT directly on the union result)
      * exp.Subquery → drill into .this
    """
    target = tree
    while isinstance(target, exp.With):
        target = target.this
    while isinstance(target, exp.Subquery):
        target = target.this

    if not isinstance(target, (exp.Select, exp.Union)):
        # Unreachable given the top-level check, but defensive.
        return

    existing = target.args.get("limit")
    if existing is None:
        target.set(
            "limit",
            exp.Limit(expression=exp.Literal.number(cap)),
        )
        return

    # Existing limit: clamp it down if higher than cap. We don't change
    # lower limits — caller may legitimately want LIMIT 5.
    limit_expr = existing.expression
    if isinstance(limit_expr, exp.Literal) and limit_expr.is_number:
        try:
            current = int(limit_expr.this)
        except (TypeError, ValueError):
            current = cap + 1  # treat unparseable as too large
        if current > cap:
            target.set(
                "limit",
                exp.Limit(expression=exp.Literal.number(cap)),
            )
        return

    # Non-literal LIMIT (e.g. parameterized) — replace with our cap.
    # Allowing a runtime-evaluated value would defeat the purpose.
    target.set(
        "limit",
        exp.Limit(expression=exp.Literal.number(cap)),
    )
