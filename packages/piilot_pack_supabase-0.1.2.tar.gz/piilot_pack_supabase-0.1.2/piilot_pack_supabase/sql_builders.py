"""Pure SQL composers for the business agent tools.

Every public builder returns a ``(sql, params)`` tuple where
``sql`` is a single-statement SELECT (or RPC call) using asyncpg
``$1, $2, …`` placeholders, and ``params`` is the matching list of
values. The caller MUST then run ``validator.validate(sql,
allowed_tables=…)`` before passing both to ``Executor.run(...,
query_params=params)``.

Why parameterized over inlined literals
---------------------------------------

Inlining literals would require us to re-implement Postgres string
escaping correctly. A bug there is a SQL injection. asyncpg already
ships a battle-tested driver-level parameter binding — let it do
the escaping, we only assemble the static SQL.

Why both a ``validator`` AND a ``builder``
------------------------------------------

Defense in depth (cf. spec §10.2):

  * Builder enforces identifier safety (regex, whitelist).
  * Validator does AST parsing and refuses unexpected shapes (DML
    in a CTE, dangerous functions, multi-statement payloads, …).

Catching identifier injection at the builder is faster and clearer;
catching structural attacks at the validator is rule-of-thumb safer.
Either layer dropping out leaves the other as a backstop.

Public surface
--------------

* :class:`FilterSpec` — filter dict with ``op`` and value(s).
* :class:`OrderClause` — column + direction.
* :func:`validate_identifier` — pure helper for the regex.
* :func:`build_select` / :func:`build_count` /
  :func:`build_aggregate` / :func:`build_top_n` /
  :func:`build_rpc_call` — the five composers.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Literal


# ---------------------------------------------------------------------------
# Identifier validation
# ---------------------------------------------------------------------------

_IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
"""Strict identifier regex. Refuses semicolons, dashes (incl.
SQL comment ``--``), spaces, quotes — every escape vector for an
inline-quoted identifier path. Multi-byte / non-ASCII identifiers
are out of scope: they're rare in Supabase setups and the cost of
supporting them safely is high."""

_MAX_IDENTIFIER_LENGTH = 63
"""Postgres identifier length limit (NAMEDATALEN-1). We mirror it
to avoid silent truncation downstream."""


def validate_identifier(name: str) -> str:
    """Return ``name`` if it's a safe Postgres identifier, else raise.

    Raises:
        ValueError: with a stable message — the agent tool wraps
            the error as a ``rejected`` audit row.
    """
    if not name:
        raise ValueError("identifier is empty")
    if len(name) > _MAX_IDENTIFIER_LENGTH:
        raise ValueError(
            f"identifier too long ({len(name)} > {_MAX_IDENTIFIER_LENGTH})"
        )
    if not _IDENTIFIER_PATTERN.match(name):
        raise ValueError(
            f"invalid identifier {name!r} — only letters, digits and _"
        )
    return name


def quote_qualified(schema: str, table: str) -> str:
    """Compose a safe ``"schema"."table"`` reference.

    Both parts validated. Wrapping in double quotes is defensive —
    the regex already excludes embedded quotes, but we want PG to
    treat the identifier as case-sensitive even if the table name
    is reserved-word-shaped.
    """
    s = validate_identifier(schema)
    t = validate_identifier(table)
    return f'"{s}"."{t}"'


# ---------------------------------------------------------------------------
# Filters & order clauses
# ---------------------------------------------------------------------------

FilterOpName = Literal[
    "eq",
    "ne",
    "gt",
    "gte",
    "lt",
    "lte",
    "like",
    "ilike",
    "in",
    "is_null",
    "is_not_null",
]

_BINARY_OPS: dict[str, str] = {
    "eq": "=",
    "ne": "<>",
    "gt": ">",
    "gte": ">=",
    "lt": "<",
    "lte": "<=",
    "like": "LIKE",
    "ilike": "ILIKE",
}

_NULLARY_OPS: dict[str, str] = {
    "is_null": "IS NULL",
    "is_not_null": "IS NOT NULL",
}


@dataclass(frozen=True)
class FilterSpec:
    """A single WHERE clause condition.

    Attributes:
        op: one of :data:`FilterOpName`.
        value: scalar value for binary ops (eq/ne/gt/lt/like/…).
            ``None`` for nullary ops (is_null / is_not_null).
        values: list value for the ``in`` op. Required when
            ``op == 'in'``, ignored otherwise.
    """

    op: FilterOpName
    value: Any | None = None
    values: list[Any] | None = None


@dataclass(frozen=True)
class OrderClause:
    """ORDER BY column + direction.

    direction in {'asc', 'desc'}. Lowercased for comparison.
    """

    column: str
    direction: Literal["asc", "desc"] = "asc"


AggregateOp = Literal["sum", "avg", "min", "max", "count"]

_AGGREGATE_FN: dict[AggregateOp, str] = {
    "sum": "SUM",
    "avg": "AVG",
    "min": "MIN",
    "max": "MAX",
    "count": "COUNT",
}


# ---------------------------------------------------------------------------
# WHERE clause assembly
# ---------------------------------------------------------------------------


def _build_where(
    filters: dict[str, FilterSpec] | None,
    next_param_idx: int,
) -> tuple[str, list[Any], int]:
    """Compose the ``WHERE …`` clause + parameter list.

    Returns ``(clause, params, next_idx)``. ``clause`` is empty
    string when ``filters`` is empty / None — the caller appends it
    blindly.
    """
    if not filters:
        return "", [], next_param_idx

    parts: list[str] = []
    params: list[Any] = []
    idx = next_param_idx

    for col, spec in filters.items():
        validate_identifier(col)
        op = spec.op

        if op in _NULLARY_OPS:
            parts.append(f'"{col}" {_NULLARY_OPS[op]}')
            continue

        if op == "in":
            values = spec.values or []
            if not values:
                raise ValueError(
                    f"'in' filter on {col!r} requires non-empty values"
                )
            placeholders = []
            for v in values:
                placeholders.append(f"${idx}")
                params.append(v)
                idx += 1
            parts.append(f'"{col}" IN ({", ".join(placeholders)})')
            continue

        if op in _BINARY_OPS:
            parts.append(f'"{col}" {_BINARY_OPS[op]} ${idx}')
            params.append(spec.value)
            idx += 1
            continue

        raise ValueError(f"unknown filter op {op!r}")

    if not parts:
        return "", [], idx

    clause = " WHERE " + " AND ".join(parts)
    return clause, params, idx


def _build_order(order_by: list[OrderClause] | None) -> str:
    """Compose ``ORDER BY ...``. Empty when no clauses provided."""
    if not order_by:
        return ""
    parts: list[str] = []
    for o in order_by:
        validate_identifier(o.column)
        direction = o.direction.lower()
        if direction not in ("asc", "desc"):
            raise ValueError(
                f"invalid order direction {o.direction!r} (asc / desc)"
            )
        parts.append(f'"{o.column}" {direction.upper()}')
    return " ORDER BY " + ", ".join(parts)


def _build_columns(columns: list[str] | None) -> str:
    """Compose the column list for SELECT — defaults to ``*``."""
    if not columns:
        return "*"
    validated = [validate_identifier(c) for c in columns]
    return ", ".join(f'"{c}"' for c in validated)


# ---------------------------------------------------------------------------
# Public builders
# ---------------------------------------------------------------------------


def build_select(
    schema: str,
    table: str,
    *,
    columns: list[str] | None = None,
    filters: dict[str, FilterSpec] | None = None,
    order_by: list[OrderClause] | None = None,
    limit: int = 100,
) -> tuple[str, list[Any]]:
    """Compose ``SELECT … FROM schema.table … ORDER BY … LIMIT n``.

    Args:
        schema: PG schema name.
        table: PG table name.
        columns: optional column list (defaults to ``*``).
        filters: optional ``{col: FilterSpec}`` dict.
        order_by: optional list of :class:`OrderClause`.
        limit: row cap. Capped at the validator's ``DEFAULT_LIMIT_CAP``
            downstream regardless.

    Returns:
        ``(sql, params)`` — sql with ``$N`` placeholders, params list
        in matching order.
    """
    qualified = quote_qualified(schema, table)
    cols = _build_columns(columns)
    where, params, _next = _build_where(filters, next_param_idx=1)
    order = _build_order(order_by)

    sql = f"SELECT {cols} FROM {qualified}{where}{order} LIMIT {int(limit)}"
    return sql, params


def build_count(
    schema: str,
    table: str,
    *,
    filters: dict[str, FilterSpec] | None = None,
) -> tuple[str, list[Any]]:
    """Compose ``SELECT COUNT(*) FROM schema.table WHERE …``.

    Wrapped in a 1-row LIMIT to satisfy the validator's auto-injection
    contract — COUNT always returns one row anyway, this is harmless.
    """
    qualified = quote_qualified(schema, table)
    where, params, _next = _build_where(filters, next_param_idx=1)
    sql = f"SELECT COUNT(*) AS count FROM {qualified}{where} LIMIT 1"
    return sql, params


def build_aggregate(
    schema: str,
    table: str,
    column: str,
    op: AggregateOp,
    *,
    filters: dict[str, FilterSpec] | None = None,
) -> tuple[str, list[Any]]:
    """Compose ``SELECT op(column) FROM schema.table WHERE …``.

    ``op`` is one of {sum, avg, min, max, count}. For ``count`` we
    use ``COUNT(column)`` (i.e. count non-null values), not
    ``COUNT(*)`` — the latter has its own builder. ``sum`` / ``avg``
    cast the column to ``::numeric`` so a string-shaped numeric
    column doesn't blow up at runtime (Pennylane / Compta tool
    pattern, lifted from ``query_knowledge_aggregate``).
    """
    if op not in _AGGREGATE_FN:
        raise ValueError(f"unknown aggregate op {op!r}")

    qualified = quote_qualified(schema, table)
    validate_identifier(column)
    fn = _AGGREGATE_FN[op]

    if op in ("sum", "avg"):
        col_expr = f'"{column}"::numeric'
    else:
        col_expr = f'"{column}"'

    where, params, _next = _build_where(filters, next_param_idx=1)
    sql = (
        f"SELECT {fn}({col_expr}) AS {fn.lower()} FROM {qualified}{where} "
        "LIMIT 1"
    )
    return sql, params


def build_top_n(
    schema: str,
    table: str,
    column: str,
    n: int,
    *,
    direction: Literal["asc", "desc"] = "desc",
    columns: list[str] | None = None,
    filters: dict[str, FilterSpec] | None = None,
) -> tuple[str, list[Any]]:
    """Compose ``SELECT … FROM schema.table WHERE … ORDER BY column ↕ LIMIT n``.

    ``column`` must be NUMERIC for the ``::numeric`` cast to make
    sense (lifted from KB tool ``query_knowledge_top_n``). For
    ``desc`` we use ``NULLS LAST`` so a NULL doesn't win the top
    spot; for ``asc`` we use ``NULLS LAST`` too so the LIMIT 1 case
    doesn't pick a NULL row (pattern match the KB v2 hot-fix from
    2026-04-29).
    """
    qualified = quote_qualified(schema, table)
    validate_identifier(column)
    cols = _build_columns(columns)
    where, params, _next = _build_where(filters, next_param_idx=1)
    direction_lower = direction.lower()
    if direction_lower not in ("asc", "desc"):
        raise ValueError(f"invalid direction {direction!r}")
    order = (
        f' ORDER BY "{column}"::numeric {direction_lower.upper()} NULLS LAST'
    )
    capped_n = max(1, min(int(n), 1000))
    sql = f"SELECT {cols} FROM {qualified}{where}{order} LIMIT {capped_n}"
    return sql, params


def build_rpc_call(
    schema: str,
    function_name: str,
    args: list[Any] | None = None,
) -> tuple[str, list[Any]]:
    """Compose ``SELECT * FROM schema.fn($1, $2, …)`` for an RPC call.

    Note: the validator will reject this (``function_name`` parses
    as an unnamed Table-as-function reference). RPC calls go around
    the validator — the caller (the ``supabase_invoke_rpc`` tool)
    relies on the connection's ``selected_rpc`` whitelist instead,
    plus the ``piilot_readonly`` GRANT EXECUTE that the admin
    explicitly granted on the function.

    Args:
        schema: PG schema the function lives in.
        function_name: function name (without args).
        args: ordered list of positional args. ``None`` / empty
            means ``schema.fn()``.
    """
    s = validate_identifier(schema)
    f = validate_identifier(function_name)
    args = args or []
    if not args:
        sql = f'SELECT * FROM "{s}"."{f}"() LIMIT 1000'
        return sql, []
    placeholders = [f"${i + 1}" for i in range(len(args))]
    sql = (
        f'SELECT * FROM "{s}"."{f}"({", ".join(placeholders)}) '
        "LIMIT 1000"
    )
    return sql, list(args)
