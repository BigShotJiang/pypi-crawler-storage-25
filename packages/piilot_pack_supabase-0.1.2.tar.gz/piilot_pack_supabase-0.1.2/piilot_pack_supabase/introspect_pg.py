"""Schema introspection via the ``piilot_readonly`` Postgres connection.

Reads tables / columns / foreign keys / indexes / comments / RPC
functions through ``information_schema`` and ``pg_catalog``. Pairs
with :mod:`piilot_pack_supabase.introspect_api` (which covers edge
functions / storage buckets / advisors via the Management API) to
populate :class:`integrations_supabase.schema_snapshot`.

Why we stick to ``information_schema`` + ``pg_catalog``
-------------------------------------------------------

The Supabase MCP server officially wraps the Management API +
``execute_sql`` calls behind the same ``information_schema`` queries.
By dropping the MCP sidecar (cf. spec §2 + suivi.md), we removed a
Node.js process per connection — but we still get the same coverage
because the underlying source of truth is the Postgres catalog.

System schemas filtered by default
----------------------------------

Supabase projects always ship a handful of internal schemas that we
must NOT expose to agents — they contain auth hashes, secrets, vault
encryption keys, etc. The default ``EXCLUDED_SCHEMAS`` filter covers:

  * ``pg_*`` — Postgres internal catalogs
  * ``information_schema`` — meta layer (we read it, we don't expose it)
  * ``auth`` — Supabase Auth (users, sessions, password hashes)
  * ``vault`` / ``pgsodium`` — Supabase Vault (encrypted secrets)
  * ``storage`` — Supabase Storage tables (we expose buckets via
    Management API, not the underlying tables)
  * ``_realtime`` / ``_supabase`` — internal realtime + dashboard
  * ``extensions`` — extension catalogs

Public surface
--------------

* :func:`list_tables`
* :func:`list_columns`
* :func:`list_foreign_keys`
* :func:`list_indexes`
* :func:`list_rpc_functions`
* :func:`list_extensions`
* :func:`pg_to_kb_type` — pure helper, exposed for tests
* :func:`should_include_schema` — pure helper, exposed for tests

Each query takes an ``asyncpg.Connection`` (not a pool) so callers
control transaction scoping and connection lifetime. Typical usage
in :mod:`piilot_pack_supabase.routes` looks like::

    async with asyncpg.connect(**params) as conn:
        tables = await list_tables(conn)
        for t in tables:
            t["columns"] = await list_columns(conn, t["schema"], t["name"])
            t["foreign_keys"] = await list_foreign_keys(conn, t["schema"], t["name"])
"""

from __future__ import annotations

from typing import Any

import asyncpg

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

EXCLUDED_SCHEMAS: frozenset[str] = frozenset(
    {
        "information_schema",
        "auth",
        "vault",
        "pgsodium",
        "storage",
        "_realtime",
        "_supabase",
        "extensions",
        "graphql",
        "graphql_public",
        "realtime",
        "supabase_functions",
        "supabase_migrations",
        "net",
    }
)
"""Schemas an agent is never allowed to see, even if the admin asks.
``pg_*`` is filtered separately (any schema starting with ``pg_``)."""

DEFAULT_INCLUDED_SCHEMAS: frozenset[str] = frozenset({"public"})
"""Default schema the picker shows. Admins can opt into more
(``analytics``, ``reporting``, custom schemas) via the connection's
``config.included_schemas`` array."""


# ---------------------------------------------------------------------------
# Pure helpers (testable without Postgres)
# ---------------------------------------------------------------------------


def should_include_schema(
    schema: str,
    *,
    included: frozenset[str] | None = None,
    excluded: frozenset[str] = EXCLUDED_SCHEMAS,
) -> bool:
    """Return True if ``schema`` should be visible to the introspection.

    Rules in order:
      1. ``pg_*`` is always excluded (Postgres internal).
      2. Names in ``excluded`` are excluded.
      3. If ``included`` is set, the schema must be in it.
      4. Otherwise, accepted.

    The admin can later pick which tables they want to expose to
    agents on a per-table basis — this filter is the first pass.
    """
    if not schema:
        return False
    if schema.startswith("pg_"):
        return False
    if schema in excluded:
        return False
    if included is not None:
        return schema in included
    return True


def pg_to_kb_type(pg_type: str) -> str:
    """Map a Postgres data_type string to a coarse KB column type.

    Supabase ``information_schema.columns.data_type`` returns the SQL
    standard name (``character varying``, ``timestamp with time zone``,
    ``USER-DEFINED`` for enums, ``ARRAY`` for arrays, …). The Piilot
    KB column model only knows {text, numeric, date, file, kb_ref} —
    we coerce everything reasonable into ``text`` or ``numeric`` and
    let the agent see the precise PG type via the ``data_type`` field
    of the metadata row.
    """
    if not pg_type:
        return "text"
    p = pg_type.lower()
    # Numeric family
    if p in {
        "smallint",
        "integer",
        "bigint",
        "decimal",
        "numeric",
        "real",
        "double precision",
        "smallserial",
        "serial",
        "bigserial",
        "money",
    }:
        return "numeric"
    # Date / time family
    if p.startswith("timestamp") or p in {"date", "time", "interval"}:
        return "date"
    # Boolean → text (KB has no bool, agent sees the data_type anyway)
    if p == "boolean":
        return "text"
    # JSON / JSONB / arrays / user-defined → text (string-serialised)
    if p in {"json", "jsonb", "array", "user-defined"} or p.startswith("array"):
        return "text"
    # UUID, bytea, network types, geometric, range — all fall through
    # to text. Agents see the precise SQL type alongside.
    return "text"


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------

_TABLES_QUERY = """
SELECT
    t.table_schema  AS schema_name,
    t.table_name    AS table_name,
    obj_description(c.oid, 'pg_class') AS comment
FROM information_schema.tables AS t
JOIN pg_catalog.pg_namespace AS n
    ON n.nspname = t.table_schema
JOIN pg_catalog.pg_class AS c
    ON c.relname = t.table_name AND c.relnamespace = n.oid
WHERE t.table_type IN ('BASE TABLE', 'VIEW', 'MATERIALIZED VIEW')
  AND t.table_schema NOT LIKE 'pg\\_%' ESCAPE '\\'
  AND t.table_schema <> ALL($1::text[])
ORDER BY t.table_schema, t.table_name
"""


async def list_tables(
    conn: asyncpg.Connection,
    *,
    excluded: frozenset[str] = EXCLUDED_SCHEMAS,
) -> list[dict[str, Any]]:
    """Return every table / view in non-system schemas.

    Args:
        conn: open asyncpg connection bound to ``piilot_readonly``.
        excluded: explicit schema deny-list. Defaults to
            :data:`EXCLUDED_SCHEMAS`. ``pg_*`` is always filtered
            in addition.

    Returns:
        List of ``{schema, name, comment}`` dicts. Sorted by schema
        then name. Empty if the role can't read
        ``information_schema.tables`` (not expected with a normal
        ``GRANT USAGE`` on the schema).
    """
    rows = await conn.fetch(_TABLES_QUERY, list(excluded))
    return [
        {
            "schema": r["schema_name"],
            "name": r["table_name"],
            "comment": r["comment"],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Columns
# ---------------------------------------------------------------------------

_COLUMNS_QUERY = """
SELECT
    c.column_name,
    c.data_type,
    c.is_nullable,
    c.column_default,
    c.ordinal_position,
    c.character_maximum_length,
    c.numeric_precision,
    c.numeric_scale,
    pg_catalog.col_description(cls.oid, c.ordinal_position) AS comment
FROM information_schema.columns AS c
JOIN pg_catalog.pg_namespace AS ns ON ns.nspname = c.table_schema
JOIN pg_catalog.pg_class AS cls
    ON cls.relname = c.table_name AND cls.relnamespace = ns.oid
WHERE c.table_schema = $1
  AND c.table_name   = $2
ORDER BY c.ordinal_position
"""


async def list_columns(
    conn: asyncpg.Connection,
    schema: str,
    table: str,
) -> list[dict[str, Any]]:
    """Return columns for ``schema.table``.

    Returns dicts with keys:
      * ``name`` — column name
      * ``data_type`` — raw PG type string (e.g. ``character varying``)
      * ``kb_type`` — coarse KB type (text/numeric/date)
      * ``is_nullable`` — True / False
      * ``default`` — default expression as a string (or None)
      * ``ordinal_position`` — 1-based source order
      * ``character_maximum_length`` — for varchar(N), else None
      * ``numeric_precision`` / ``numeric_scale`` — for numeric, else None
      * ``comment`` — column comment if any
    """
    rows = await conn.fetch(_COLUMNS_QUERY, schema, table)
    return [
        {
            "name": r["column_name"],
            "data_type": r["data_type"],
            "kb_type": pg_to_kb_type(r["data_type"]),
            "is_nullable": r["is_nullable"] == "YES",
            "default": r["column_default"],
            "ordinal_position": r["ordinal_position"],
            "character_maximum_length": r["character_maximum_length"],
            "numeric_precision": r["numeric_precision"],
            "numeric_scale": r["numeric_scale"],
            "comment": r["comment"],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Foreign keys
# ---------------------------------------------------------------------------

_FOREIGN_KEYS_QUERY = """
SELECT
    kcu.column_name        AS column_name,
    ccu.table_schema       AS ref_schema,
    ccu.table_name         AS ref_table,
    ccu.column_name        AS ref_column,
    rc.update_rule         AS update_rule,
    rc.delete_rule         AS delete_rule
FROM information_schema.referential_constraints AS rc
JOIN information_schema.key_column_usage AS kcu
    ON  kcu.constraint_name    = rc.constraint_name
    AND kcu.constraint_schema  = rc.constraint_schema
JOIN information_schema.constraint_column_usage AS ccu
    ON  ccu.constraint_name    = rc.unique_constraint_name
    AND ccu.constraint_schema  = rc.unique_constraint_schema
WHERE kcu.table_schema = $1
  AND kcu.table_name   = $2
ORDER BY kcu.column_name
"""


async def list_foreign_keys(
    conn: asyncpg.Connection,
    schema: str,
    table: str,
) -> list[dict[str, Any]]:
    """Return foreign keys declared on ``schema.table``.

    Returns dicts with keys:
      * ``column`` — local column carrying the FK
      * ``ref_schema`` / ``ref_table`` / ``ref_column`` — target
      * ``update_rule`` / ``delete_rule`` — CASCADE / NO ACTION / …

    Only outbound FKs are returned (i.e. this table referencing
    others). Inbound references can be derived by querying with the
    referenced side reversed if the agent needs them.
    """
    rows = await conn.fetch(_FOREIGN_KEYS_QUERY, schema, table)
    return [
        {
            "column": r["column_name"],
            "ref_schema": r["ref_schema"],
            "ref_table": r["ref_table"],
            "ref_column": r["ref_column"],
            "update_rule": r["update_rule"],
            "delete_rule": r["delete_rule"],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Indexes
# ---------------------------------------------------------------------------

_INDEXES_QUERY = """
SELECT
    indexname    AS name,
    indexdef     AS definition
FROM pg_catalog.pg_indexes
WHERE schemaname = $1
  AND tablename  = $2
ORDER BY indexname
"""


async def list_indexes(
    conn: asyncpg.Connection,
    schema: str,
    table: str,
) -> list[dict[str, Any]]:
    """Return indexes declared on ``schema.table``.

    Returns dicts with keys:
      * ``name`` — index name
      * ``definition`` — full ``CREATE INDEX`` SQL as PG built it.
        Agents read this verbatim — it documents both the columns
        and the expression / partial / unique semantics in one
        string.
    """
    rows = await conn.fetch(_INDEXES_QUERY, schema, table)
    return [
        {"name": r["name"], "definition": r["definition"]}
        for r in rows
    ]


# ---------------------------------------------------------------------------
# RPC functions
# ---------------------------------------------------------------------------

_RPC_FUNCTIONS_QUERY = """
SELECT
    n.nspname           AS schema_name,
    p.proname           AS function_name,
    pg_catalog.pg_get_function_identity_arguments(p.oid) AS arguments,
    pg_catalog.pg_get_function_result(p.oid)             AS return_type,
    pg_catalog.obj_description(p.oid, 'pg_proc')         AS comment,
    p.provolatile       AS volatility,
    p.proisstrict       AS is_strict
FROM pg_catalog.pg_proc AS p
JOIN pg_catalog.pg_namespace AS n
    ON n.oid = p.pronamespace
WHERE n.nspname NOT LIKE 'pg\\_%' ESCAPE '\\'
  AND n.nspname <> ALL($1::text[])
  AND p.prokind = 'f'
ORDER BY n.nspname, p.proname
"""


async def list_rpc_functions(
    conn: asyncpg.Connection,
    *,
    excluded: frozenset[str] = EXCLUDED_SCHEMAS,
) -> list[dict[str, Any]]:
    """Return user-defined function metadata for non-system schemas.

    Functions on ``pg_*`` and the EXCLUDED_SCHEMAS list are filtered
    out — they're either internal or in schemas we never expose.

    Returns dicts with keys:
      * ``schema`` / ``name``
      * ``arguments`` — string from ``pg_get_function_identity_arguments``
        (e.g. ``"start_date date, end_date date"``)
      * ``return_type`` — string from ``pg_get_function_result``
      * ``comment`` — function-level COMMENT, if any
      * ``volatility`` — ``i`` (immutable) / ``s`` (stable) / ``v`` (volatile)
      * ``is_strict`` — True if NULL inputs short-circuit to NULL
    """
    rows = await conn.fetch(_RPC_FUNCTIONS_QUERY, list(excluded))
    return [
        {
            "schema": r["schema_name"],
            "name": r["function_name"],
            "arguments": r["arguments"],
            "return_type": r["return_type"],
            "comment": r["comment"],
            "volatility": r["volatility"],
            "is_strict": r["is_strict"],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Extensions
# ---------------------------------------------------------------------------

_EXTENSIONS_QUERY = """
SELECT
    extname     AS name,
    extversion  AS version
FROM pg_catalog.pg_extension
ORDER BY extname
"""


async def list_extensions(
    conn: asyncpg.Connection,
) -> list[dict[str, Any]]:
    """Return installed PG extensions (pgvector, postgis, …).

    Useful diagnostic for the admin UI: an agent that wants to use
    ``vector`` columns will need pgvector installed; the schema view
    surfaces this so the admin doesn't have to ssh into Supabase to
    check.
    """
    rows = await conn.fetch(_EXTENSIONS_QUERY)
    return [
        {"name": r["name"], "version": r["version"]} for r in rows
    ]
