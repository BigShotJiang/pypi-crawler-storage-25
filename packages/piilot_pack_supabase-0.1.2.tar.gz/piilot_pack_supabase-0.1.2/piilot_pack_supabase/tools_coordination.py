"""Coordination agent tools — multi-connection hub.

Three tools that drive the connection selection flow:

  * ``supabase_list_connections`` — show the user (via the agent)
    what Supabase accounts are configured.
  * ``supabase_select_connection`` — bind a specific connection to
    the agent session for the rest of the conversation.
  * ``supabase_describe_connection`` — preview a connection's
    contents (table count, RPC count, last refresh) without
    selecting it.

They form the *meta* layer of the plugin's tool surface — the agent
calls them when it doesn't know which Supabase account to query.
The 9 business tools (``supabase_select``, ``supabase_top_n``, …)
read the active connection from the session scope and never accept
a ``connection_id`` argument directly. That keeps cross-tenant
mistakes impossible: the LLM cannot accidentally point at a
connection it didn't explicitly select.

Pattern lifted from ``piilot-pack-pennylane`` (``pennylane_list_*``,
``pennylane_select_*``).
"""

from __future__ import annotations

from typing import Any

from langchain_core.tools import StructuredTool

from piilot.sdk import session as sdk_session
from piilot.sdk.tools import bind_session

from . import _session_helpers as helpers
from ._session_helpers import (
    MSG_NO_CONNECTIONS,
    MSG_NO_SESSION,
)


# ---------------------------------------------------------------------------
# Implementations
# ---------------------------------------------------------------------------


def _supabase_list_connections_fn(session_id: str = "") -> str:
    """List active Supabase connections for the caller's company."""
    company_id = helpers.get_session_company_id(session_id)
    if company_id is None:
        return MSG_NO_SESSION

    connections = helpers.list_active_connections(company_id)
    if not connections:
        return MSG_NO_CONNECTIONS

    scope = sdk_session.get_scope(session_id) or {}
    active_id = (
        str(scope.get("connection_id", ""))
        if scope.get("plugin") == "supabase"
        else ""
    )

    lines = [f"{len(connections)} compte(s) Supabase configuré(s) :"]
    for c in connections:
        cid = str(c.get("id", ""))
        label = c.get("label") or "(sans label)"
        config = c.get("config") or {}
        ref = config.get("project_ref") or "self-hosted"
        marker = " (actif)" if cid == active_id else ""
        lines.append(f"- '{label}' (project: {ref}){marker}")

    if not active_id and len(connections) > 1:
        lines.append("")
        lines.append(
            "Aucun compte n'est sélectionné pour cette conversation. "
            "Appelez ``supabase_select_connection`` avec un label "
            "pour choisir."
        )

    return "\n".join(lines)


def _supabase_select_connection_fn(
    ref: str = "",
    session_id: str = "",
) -> str:
    """Bind an active Supabase connection to the conversation."""
    company_id = helpers.get_session_company_id(session_id)
    if company_id is None:
        return MSG_NO_SESSION

    connection, err = helpers.resolve_connection_ref(company_id, ref)
    if err:
        return err

    assert connection is not None
    sdk_session.set_scope(
        session_id,
        "supabase",
        connection_id=str(connection["id"]),
        connection_label=connection.get("label"),
    )

    label = connection.get("label") or "(sans label)"
    config = connection.get("config") or {}
    project_ref = config.get("project_ref") or "self-hosted"
    n_tables = len(config.get("selected_tables") or [])
    return (
        f"Compte Supabase actif : '{label}' (project: {project_ref}, "
        f"{n_tables} table(s) exposée(s) aux agents). Vous pouvez "
        "maintenant utiliser les outils de requête."
    )


def _supabase_describe_connection_fn(
    ref: str = "",
    session_id: str = "",
) -> str:
    """Preview a connection without selecting it."""
    company_id = helpers.get_session_company_id(session_id)
    if company_id is None:
        return MSG_NO_SESSION

    connection, err = helpers.resolve_connection_ref(company_id, ref)
    if err:
        return err

    assert connection is not None
    config: dict[str, Any] = connection.get("config") or {}
    label = connection.get("label") or "(sans label)"
    project_ref = config.get("project_ref") or "self-hosted (pas de Management API)"
    last_refresh = config.get("last_schema_refresh_at") or "jamais"
    selected_tables = config.get("selected_tables") or []
    selected_rpc = config.get("selected_rpc") or []
    advanced_sql = config.get("advanced_sql_enabled", False)

    return (
        f"Compte Supabase '{label}' (project: {project_ref}) :\n"
        f"- Dernier refresh schéma : {last_refresh}\n"
        f"- Tables exposées : {len(selected_tables)}\n"
        f"- Fonctions RPC exposées : {len(selected_rpc)}\n"
        f"- SQL avancé activé : {'oui' if advanced_sql else 'non'}\n"
        "Pour interroger ce compte, appelez d'abord "
        "``supabase_select_connection`` avec ce label."
    )


# ---------------------------------------------------------------------------
# Exported tools
# ---------------------------------------------------------------------------


supabase_list_connections = StructuredTool.from_function(
    func=bind_session(_supabase_list_connections_fn),
    name="supabase_list_connections",
    description=(
        "Liste les comptes Supabase configurés pour l'entreprise courante. "
        "Marque celui qui est actuellement sélectionné pour cette "
        "conversation. À appeler en premier quand l'utilisateur évoque "
        "des données Supabase et que le compte n'est pas encore choisi."
    ),
)


supabase_select_connection = StructuredTool.from_function(
    func=bind_session(_supabase_select_connection_fn),
    name="supabase_select_connection",
    description=(
        "Sélectionne le compte Supabase actif pour le reste de la "
        "conversation. Argument ``ref`` accepte un label (ex: 'Prod EU') "
        "ou un identifiant UUID. À appeler après "
        "``supabase_list_connections`` quand plusieurs comptes existent "
        "et que l'utilisateur a précisé lequel utiliser."
    ),
)


supabase_describe_connection = StructuredTool.from_function(
    func=bind_session(_supabase_describe_connection_fn),
    name="supabase_describe_connection",
    description=(
        "Affiche un aperçu d'un compte Supabase sans le sélectionner : "
        "nombre de tables exposées, RPC, date du dernier refresh. "
        "Utile quand l'utilisateur veut comparer deux comptes avant "
        "d'en choisir un."
    ),
)
