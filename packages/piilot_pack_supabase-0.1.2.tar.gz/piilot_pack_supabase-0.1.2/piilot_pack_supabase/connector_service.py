"""Connector orchestration — PAT-only path (Phase 8).

The v0.1 path went via a dedicated ``piilot_readonly`` Postgres user
+ direct PG connection. It hit two walls in production: (a) Supabase
Cloud's direct PG endpoint is IPv6-only by default — Docker hosts
without IPv6 cannot reach it without the paid IPv4 add-on; (b) the
admin onboarding required copy-pasting a SQL snippet, generating
passwords, etc. — too much friction for a feature whose users are
already admins of their own Supabase project.

Phase 8 pivots to the **Personal Access Token (PAT)** flow. The
admin generates a PAT in their Supabase account once, pastes it into
Piilot's wizard, and we run every SQL query through

    POST {API}/v1/projects/{ref}/database/query

The Management API authenticates with the PAT, executes the SQL
against the project's Postgres, and returns rows. Five upsides:

  1. No ``piilot_readonly`` to create on the customer side.
  2. No SQL snippet to paste.
  3. No 5432 / IPv6 plumbing.
  4. Token revocation is one click in the Supabase dashboard.
  5. Two fewer secrets to store (just the PAT now, no PG password).

Trade-off documented in :mod:`mgmt_executor`: we lose the PG-level
``READ ONLY DEFERRABLE`` belt. The single layer protecting against
DML now is sqlglot. That's still tighter than what most read-only
SaaS connectors do (most pass the SQL straight through with no
validation at all).

Public surface (slimmed)
------------------------

* :func:`extract_project_ref` — pure helper, parses the project ref
  from a Supabase URL.
* :func:`get_pat` — decrypts the PAT from a saved connection row.
* :func:`test_connection` — pings the Management API to validate
  the PAT + project access.
* :func:`refresh_schema` — full schema introspection via the API
  (information_schema queries + edge fns + advisors).
* :func:`create_connection` — wrapper around
  :func:`piilot.sdk.connectors.save_connection`.

Dropped from v0.1: ``generate_setup_snippet``,
``parse_supabase_url`` (URL→host/port/db tuple),
``build_connection_params``, ``SetupSnippet`` dataclass.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

import httpx

from piilot.sdk import connectors as sdk_connectors
from piilot.sdk import crypto as sdk_crypto

from . import introspect_api
from .mgmt_executor import ExecutionError, ManagementExecutor

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# URL parsing
# ---------------------------------------------------------------------------

_CLOUD_TLD = ".supabase.co"


def extract_project_ref(url: str) -> str | None:
    """Extract the Cloud project ref from a Supabase URL, or ``None``.

    Returns the ``<ref>`` slug for ``https://<ref>.supabase.co`` or
    ``https://db.<ref>.supabase.co``. Returns ``None`` for self-hosted
    deployments — they have no Management API endpoint at
    ``api.supabase.com``, so the PAT path doesn't apply.
    """
    parsed = urlparse(url.strip())
    hostname = (parsed.hostname or "").lower()
    if not hostname.endswith(_CLOUD_TLD):
        return None
    parts = hostname.split(".")
    if hostname.startswith("db.") and len(parts) >= 4:
        return parts[1]
    if len(parts) >= 3:
        return parts[0]
    return None


# ---------------------------------------------------------------------------
# Credentials handling
# ---------------------------------------------------------------------------


def get_pat(connection_row: dict[str, Any]) -> str | None:
    """Decrypt the Personal Access Token from a saved connection.

    Returns ``None`` when the row has no PAT — the caller raises
    400 / surfaces a setup-incomplete message.

    The PAT lives in ``config`` (not in a dedicated column / not in
    a ``credentials`` key). The SDK's auto-encryption routes
    ``type=secret`` fields without a standard mapping
    (access_token / refresh_token / api_key) into the ``config``
    JSONB.
    """
    config = connection_row.get("config") or {}
    encrypted = config.get("supabase_pat")
    if not encrypted:
        return None
    return sdk_crypto.decrypt(encrypted)


# ---------------------------------------------------------------------------
# Test connection (ping Management API)
# ---------------------------------------------------------------------------


@dataclass
class PingResult:
    """Outcome of a Management API ping. Stable across SDK / runtime."""

    ok: bool
    detail: str
    project_name: str | None = None
    region: str | None = None


async def test_connection(connection_row: dict[str, Any]) -> PingResult:
    """Validate a saved connection by pinging the Management API.

    Replaces v0.1's 8-step ``piilot_readonly`` probe. The PAT path
    has nothing to verify on the PG side — if the Management API
    accepts the PAT for the project ref, the SQL path will work.

    Returns a single :class:`PingResult` (not a list of CheckResult
    like v0.1) — the binary "ok / not ok" outcome is enough now.
    """
    config = connection_row.get("config") or {}
    project_ref = config.get("project_ref")
    if not project_ref:
        return PingResult(
            ok=False,
            detail=(
                "Cette connexion est en mode self-hosted Supabase "
                "(sans Management API). Le path PAT n'est pas "
                "applicable."
            ),
        )

    pat = get_pat(connection_row)
    if not pat:
        return PingResult(
            ok=False,
            detail=(
                "Aucun Personal Access Token enregistré. Re-créez "
                "la connexion en fournissant un PAT."
            ),
        )

    async with httpx.AsyncClient() as client:
        try:
            project = await introspect_api.ping_management_api(
                client, project_ref, pat
            )
        except introspect_api.SupabaseAPIError as exc:
            return PingResult(ok=False, detail=str(exc))

    return PingResult(
        ok=True,
        detail="Personal Access Token valide pour ce projet.",
        project_name=project.get("name") if isinstance(project, dict) else None,
        region=project.get("region") if isinstance(project, dict) else None,
    )


# ---------------------------------------------------------------------------
# Refresh schema (introspection via Management API SQL exec)
# ---------------------------------------------------------------------------


@dataclass
class RefreshResult:
    """Aggregated outcome of :func:`refresh_schema`."""

    tables_count: int
    rpc_count: int
    edge_functions_count: int
    advisors_security_count: int
    advisors_performance_count: int
    extensions_count: int
    introspected_at: str


# Information_schema / pg_catalog queries reused from
# :mod:`introspect_pg`. We inline them here as Python strings so the
# Management API SQL exec can run them — ``introspect_pg`` queries
# took an ``asyncpg.Connection``; that path no longer exists.
_TABLES_QUERY = """
SELECT
    t.table_schema  AS schema_name,
    t.table_name    AS table_name,
    obj_description(c.oid, 'pg_class') AS comment
FROM information_schema.tables AS t
JOIN pg_catalog.pg_namespace AS n
    ON n.nspname = t.table_schema
JOIN pg_catalog.pg_class AS c
    ON c.relname = t.table_name AND c.relnamespace = n.oid
WHERE t.table_type IN ('BASE TABLE', 'VIEW', 'MATERIALIZED VIEW')
  AND t.table_schema NOT LIKE 'pg\\_%' ESCAPE '\\'
  AND t.table_schema NOT IN (
      'information_schema', 'auth', 'vault', 'pgsodium', 'storage',
      '_realtime', '_supabase', 'extensions', 'graphql',
      'graphql_public', 'realtime', 'supabase_functions',
      'supabase_migrations', 'net'
  )
ORDER BY t.table_schema, t.table_name
"""

_COLUMNS_QUERY = """
SELECT
    c.table_schema,
    c.table_name,
    c.column_name,
    c.data_type,
    c.is_nullable,
    c.column_default,
    c.ordinal_position
FROM information_schema.columns AS c
WHERE c.table_schema NOT LIKE 'pg\\_%' ESCAPE '\\'
  AND c.table_schema NOT IN (
      'information_schema', 'auth', 'vault', 'pgsodium', 'storage',
      '_realtime', '_supabase', 'extensions', 'graphql',
      'graphql_public', 'realtime', 'supabase_functions',
      'supabase_migrations', 'net'
  )
ORDER BY c.table_schema, c.table_name, c.ordinal_position
"""

_RPC_QUERY = """
SELECT
    n.nspname           AS schema_name,
    p.proname           AS function_name,
    pg_catalog.pg_get_function_identity_arguments(p.oid) AS arguments,
    pg_catalog.pg_get_function_result(p.oid)             AS return_type,
    pg_catalog.obj_description(p.oid, 'pg_proc')         AS comment
FROM pg_catalog.pg_proc AS p
JOIN pg_catalog.pg_namespace AS n
    ON n.oid = p.pronamespace
WHERE n.nspname NOT LIKE 'pg\\_%' ESCAPE '\\'
  AND n.nspname NOT IN (
      'information_schema', 'auth', 'vault', 'pgsodium', 'storage',
      '_realtime', '_supabase', 'extensions', 'graphql',
      'graphql_public', 'realtime', 'supabase_functions',
      'supabase_migrations', 'net'
  )
  AND p.prokind = 'f'
ORDER BY n.nspname, p.proname
"""

_EXTENSIONS_QUERY = """
SELECT extname AS name, extversion AS version
FROM pg_catalog.pg_extension
ORDER BY extname
"""


async def refresh_schema(
    connection_row: dict[str, Any],
    *,
    executor: ManagementExecutor | None = None,
) -> tuple[RefreshResult, dict[str, Any]]:
    """Run a full introspection cycle and return the snapshot payload.

    The caller (the route handler) takes ``snapshot_payload`` and
    UPSERTs it onto ``integrations_supabase.schema_snapshot``.

    Args:
        connection_row: dict from
            :func:`piilot.sdk.connectors.get_connection`.
        executor: optional :class:`ManagementExecutor` (DI for tests).
            A fresh instance is built per call when ``None`` — fine
            here because Refresh Schema is rare (1×/24h auto + manual).

    Returns:
        ``(RefreshResult, snapshot_payload)``. ``snapshot_payload``
        mirrors the JSONB columns of ``schema_snapshot``.

    Raises:
        ValueError: if the row is missing a project_ref or PAT.
        ExecutionError: if any Management API call fails.
    """
    config = connection_row.get("config") or {}
    project_ref = config.get("project_ref")
    if not project_ref:
        raise ValueError(
            "Connection has no project_ref — self-hosted Supabase "
            "isn't supported by the Phase 8 PAT flow."
        )
    pat = get_pat(connection_row)
    if not pat:
        raise ValueError(
            "Connection has no Personal Access Token. Re-create it "
            "with a PAT from Supabase → Account → Access Tokens."
        )

    own_executor = executor is None
    ex = executor or ManagementExecutor()
    try:
        # Schema-side queries (tables / columns / RPC / extensions).
        tables_rows = (await ex.run(
            project_ref=project_ref, pat=pat, sql=_TABLES_QUERY,
        )).rows
        columns_rows = (await ex.run(
            project_ref=project_ref, pat=pat, sql=_COLUMNS_QUERY,
        )).rows
        rpc_rows = (await ex.run(
            project_ref=project_ref, pat=pat, sql=_RPC_QUERY,
        )).rows
        ext_rows = (await ex.run(
            project_ref=project_ref, pat=pat, sql=_EXTENSIONS_QUERY,
        )).rows
    finally:
        if own_executor:
            await ex.close()

    logger.info(
        "[supabase] introspected: %d tables, %d columns, %d rpc, %d ext",
        len(tables_rows), len(columns_rows), len(rpc_rows), len(ext_rows),
    )

    # Build the per-table column index for the JSONB nested shape
    # the agent tools expect.
    by_table: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for c in columns_rows:
        key = (c["table_schema"], c["table_name"])
        by_table.setdefault(key, []).append(
            {
                "name": c["column_name"],
                "data_type": c["data_type"],
                "is_nullable": (c.get("is_nullable") or "").upper() == "YES",
                "default": c.get("column_default"),
                "ordinal_position": c.get("ordinal_position"),
            }
        )
    tables = [
        {
            "schema": t["schema_name"],
            "name": t["table_name"],
            "comment": t.get("comment"),
            "columns": by_table.get(
                (t["schema_name"], t["table_name"]), []
            ),
        }
        for t in tables_rows
    ]
    rpc_functions = [
        {
            "schema": r["schema_name"],
            "name": r["function_name"],
            "arguments": r.get("arguments"),
            "return_type": r.get("return_type"),
            "comment": r.get("comment"),
        }
        for r in rpc_rows
    ]
    extensions = [
        {"name": e.get("name") or e.get("extname"), "version": e.get("version") or e.get("extversion")}
        for e in ext_rows
    ]

    # Edge fns + advisors via Management API HTTP (PAT same usage).
    edge_functions: list[dict[str, Any]] = []
    advisors_security: list[dict[str, Any]] = []
    advisors_performance: list[dict[str, Any]] = []
    async with httpx.AsyncClient() as http:
        try:
            edge_functions = await introspect_api.list_edge_functions(
                http, project_ref, pat
            )
            advisors_security = await introspect_api.list_advisors_security(
                http, project_ref, pat
            )
            advisors_performance = await introspect_api.list_advisors_performance(
                http, project_ref, pat
            )
        except introspect_api.SupabaseAPIError as exc:
            logger.warning(
                "[supabase] Management API non-SQL endpoints failed: %s",
                exc,
            )

    snapshot = {
        "tables": tables,
        "rpc_functions": rpc_functions,
        "edge_functions": edge_functions,
        "storage_buckets": [],  # v2
        "advisors": [
            *[{**a, "_kind": "security"} for a in advisors_security],
            *[{**a, "_kind": "performance"} for a in advisors_performance],
        ],
        "extensions": extensions,
    }
    result = RefreshResult(
        tables_count=len(tables),
        rpc_count=len(rpc_functions),
        edge_functions_count=len(edge_functions),
        advisors_security_count=len(advisors_security),
        advisors_performance_count=len(advisors_performance),
        extensions_count=len(extensions),
        introspected_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )
    return result, snapshot


# ---------------------------------------------------------------------------
# Create connection
# ---------------------------------------------------------------------------


_PROJECT_REF_PATTERN = re.compile(r"^[a-z0-9]{8,32}$")
"""Real Supabase Cloud refs are 20 alphanumeric chars. We accept
8-32 to leave room for synthetic refs in tests + future Supabase
ref length changes (unlikely but cheap to allow)."""


def normalize_project_ref(raw: str) -> str:
    """Coerce user input into a 20-ish-char Supabase project ref.

    Accepts:
      * the bare ref:           ``fmjxjnzyeeslwyewpipw``
      * the project URL:        ``https://fmjxjnzyeeslwyewpipw.supabase.co``
      * the DB-qualified URL:   ``https://db.fmjxjnzyeeslwyewpipw.supabase.co``

    Returns the lowercased ref. Raises ``ValueError`` if the input
    doesn't yield a valid ref.
    """
    if not raw:
        raise ValueError("Project ref or URL is required.")
    s = raw.strip()
    if "://" in s or "." in s:
        # Looks like a URL — try to extract the ref via the URL parser.
        ref = extract_project_ref(s)
        if not ref:
            raise ValueError(
                "URL invalide. Saisissez l'ID du projet (Reference ID) "
                "ou une URL Supabase Cloud."
            )
        s = ref
    s = s.lower()
    if not _PROJECT_REF_PATTERN.match(s):
        raise ValueError(
            f"Project ref invalide ('{s}'). Format attendu : 16-32 "
            "caractères alphanumériques minuscules."
        )
    return s


def create_connection(
    *,
    company_id: str,
    project_ref_or_url: str,
    label: str,
    pat: str,
    rls_disclaimer_acknowledged: bool = False,
) -> dict[str, Any]:
    """Persist a new Supabase connection (PAT-only).

    Args:
        company_id: tenant scope.
        project_ref_or_url: the project's Reference ID
            (``fmjxjnzyeeslwyewpipw``) — accepts a full URL too for
            backwards compat with the v0.1 frontend payload. The
            stored ``supabase_url`` is always derived as
            ``https://<ref>.supabase.co``.
        label: human-readable name surfaced in the Hub.
        pat: cleartext Personal Access Token. Encrypted by the SDK
            on save.
        rls_disclaimer_acknowledged: must be True — gates the create.

    Raises:
        ValueError: when the disclaimer is not acknowledged, the PAT
            is empty, or the ref doesn't match the Supabase Cloud
            shape.
    """
    if not rls_disclaimer_acknowledged:
        raise ValueError(
            "Cannot create the connection — the RLS disclaimer must be "
            "acknowledged first."
        )
    if not pat or not pat.strip():
        raise ValueError("A Personal Access Token is required.")

    project_ref = normalize_project_ref(project_ref_or_url)
    supabase_url = f"https://{project_ref}.supabase.co"

    config = {
        "supabase_url": supabase_url,
        "project_ref": project_ref,
        "selected_tables": [],
        "selected_rpc": [],
        "selected_edge_functions": [],
        "selected_buckets": [],
        "advanced_sql_enabled": False,
        "rls_disclaimer_acknowledged_at": datetime.now(timezone.utc).isoformat(
            timespec="seconds"
        ),
        "schema_refresh_interval_hours": 24,
        "last_schema_refresh_at": None,
    }
    credentials = {"supabase_pat": pat}

    return sdk_connectors.save_connection(
        company_id=company_id,
        provider="supabase",
        auth_type="custom",
        label=label,
        credentials=credentials,
        config=config,
    )
