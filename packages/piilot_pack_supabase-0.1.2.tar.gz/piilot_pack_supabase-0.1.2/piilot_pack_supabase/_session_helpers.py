"""Session-scope helpers shared by every Supabase agent tool.

Pattern lifted 1:1 from ``piilot-pack-pennylane`` (``tools.py:_get_*``).
Every business / coordination tool starts with the same two questions:

  1. Which company is this session for?
  2. Which connection is currently scoped — or is the agent expected
     to ask the user?

These helpers answer both deterministically. They are private to the
plugin (underscore-prefixed module) — tests import them, business
tools wrap them, but no end-user surface depends on their shape.

Public surface (for tests / business tools)
-------------------------------------------

* :func:`get_session_company_id` — returns the company UUID stored on
  the session, or ``None`` if the session is invalid / unbound.
* :func:`list_active_connections` — returns the company's Supabase
  connections (label + id + config + credentials envelope).
* :func:`resolve_connection_ref` — resolves a user-supplied ``ref``
  (label or UUID) to a connection row. Returns ``(row, error)``.
* :func:`get_supabase_context` — chains the three: validates the
  session, reads the scope, returns ``(company_id, connection_row,
  error_message)`` ready for the business tools to short-circuit on.

User-facing error messages
--------------------------

Strings the agent reads back to the user are kept in this module as
module-level constants. Keeping them grouped makes i18n localization
trivial (Phase 7-8) and prevents accidental drift between tools.
"""

from __future__ import annotations

from typing import Any

from piilot.sdk import connectors as sdk_connectors
from piilot.sdk import session as sdk_session


# ---------------------------------------------------------------------------
# User-facing messages
# ---------------------------------------------------------------------------

MSG_NO_SESSION = (
    "Session inactive ou invalide. Reconnectez-vous puis relancez la requête."
)

MSG_NO_CONNECTIONS = (
    "Aucune intégration Supabase configurée pour cette entreprise. "
    "Demandez à un administrateur d'en ajouter une depuis "
    "Paramètres → Intégrations → Supabase."
)

MSG_NEED_SELECT = (
    "Plusieurs comptes Supabase sont configurés pour cette entreprise. "
    "Précisez celui à utiliser : appelez d'abord ``supabase_list_connections`` "
    "pour voir la liste, puis ``supabase_select_connection`` avec le label "
    "ou l'identifiant souhaité."
)

MSG_REF_REQUIRED = (
    "Précisez le label ou l'identifiant du compte Supabase "
    "(``supabase_list_connections`` pour voir la liste)."
)

MSG_REF_NOT_FOUND = (
    "Aucun compte Supabase trouvé pour la référence demandée. "
    "Appelez ``supabase_list_connections`` pour voir la liste exacte."
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def get_session_company_id(session_id: str) -> str | None:
    """Return the company UUID bound to ``session_id`` or ``None``.

    Reads the session via :mod:`piilot.sdk.session`. The company id
    lives under the conventional ``user_infos['_organization_id']``
    key set by the Piilot core auth layer.
    """
    state = sdk_session.get(session_id)
    if state is None:
        return None
    user_infos = getattr(state, "user_infos", None) or {}
    company_id = user_infos.get("_organization_id")
    if not company_id:
        return None
    return str(company_id)


def list_active_connections(company_id: str) -> list[dict[str, Any]]:
    """Return active Supabase connections for ``company_id``.

    Filters out rows where ``is_active`` is False — those have failed
    the readonly_check verification or were paused by an admin and
    must not be presented to agents as queryable.
    """
    rows = sdk_connectors.list_connections(
        company_id=company_id, provider="supabase"
    )
    return [r for r in rows if r.get("is_active")]


def resolve_connection_ref(
    company_id: str,
    ref: str,
) -> tuple[dict[str, Any] | None, str | None]:
    """Resolve a user-supplied ``ref`` (label or UUID) to a connection.

    Match precedence:
      1. Exact UUID match (case-insensitive on the hex digits).
      2. Exact label match (case-insensitive).
      3. Substring on the label (case-insensitive). If multiple
         matches → ambiguity error so the agent re-asks.

    Args:
        company_id: tenant scope. We never resolve cross-tenant —
            even with a UUID, a connection from another company is
            invisible.
        ref: user input, label OR UUID. Whitespace-trimmed.

    Returns:
        ``(connection_row, error_message)`` — exactly one is non-None.
    """
    if not ref or not ref.strip():
        return None, MSG_REF_REQUIRED

    ref_clean = ref.strip()
    ref_lower = ref_clean.lower()
    connections = list_active_connections(company_id)

    if not connections:
        return None, MSG_NO_CONNECTIONS

    # 1. UUID match
    for c in connections:
        if str(c.get("id", "")).lower() == ref_lower:
            return c, None

    # 2. Exact label match (case-insensitive)
    exact_label = [
        c for c in connections
        if (c.get("label") or "").lower() == ref_lower
    ]
    if len(exact_label) == 1:
        return exact_label[0], None
    if len(exact_label) > 1:
        # Two connections with the same label — should never happen
        # in practice, but guard anyway. Surface the ambiguity.
        return None, MSG_NEED_SELECT

    # 3. Substring on label
    contains = [
        c for c in connections
        if ref_lower in (c.get("label") or "").lower()
    ]
    if len(contains) == 1:
        return contains[0], None
    if len(contains) > 1:
        return None, MSG_NEED_SELECT

    return None, MSG_REF_NOT_FOUND


def get_supabase_context(
    session_id: str,
) -> tuple[str | None, dict[str, Any] | None, str | None]:
    """Resolve ``(company_id, connection_row, error)`` for a tool call.

    The flow business tools follow at the top of every implementation:

      1. Read the session — invalid → MSG_NO_SESSION.
      2. List active Supabase connections — empty → MSG_NO_CONNECTIONS.
      3. Read the session scope (``set_scope``):
         a. Scope present + plugin='supabase' → return that connection.
         b. Scope absent + exactly 1 connection → silently auto-pick.
         c. Scope absent + 2+ connections → MSG_NEED_SELECT.

    Returns:
        Triple where exactly one of ``connection_row`` /
        ``error`` is non-None (in addition to ``company_id``).
        Use ``if error:`` early-return in tool implementations.
    """
    company_id = get_session_company_id(session_id)
    if company_id is None:
        return None, None, MSG_NO_SESSION

    connections = list_active_connections(company_id)
    if not connections:
        return company_id, None, MSG_NO_CONNECTIONS

    scope = sdk_session.get_scope(session_id) or {}
    if scope.get("plugin") == "supabase" and scope.get("connection_id"):
        scoped_id = str(scope["connection_id"])
        for c in connections:
            if str(c.get("id", "")) == scoped_id:
                return company_id, c, None
        # Scope points at a connection that no longer exists / was
        # deleted under the agent's feet — clear the scope and ask
        # the user to pick again.
        sdk_session.clear_scope(session_id)
        return company_id, None, MSG_REF_NOT_FOUND

    # No scope yet
    if len(connections) == 1:
        return company_id, connections[0], None

    return company_id, None, MSG_NEED_SELECT
