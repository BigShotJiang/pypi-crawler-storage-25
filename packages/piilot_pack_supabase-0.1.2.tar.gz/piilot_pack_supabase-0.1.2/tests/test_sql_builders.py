"""Pure SQL builder tests.

Every public builder is tested for:
  * happy path with realistic args
  * identifier injection (;/--/spaces/quotes refused)
  * placeholder ordering ($1, $2, $3 in the right slots)
  * filter op coverage (eq / ne / gt / in / is_null …)
  * direction validation
"""

from __future__ import annotations

import pytest

from piilot_pack_supabase.sql_builders import (
    FilterSpec,
    OrderClause,
    build_aggregate,
    build_count,
    build_rpc_call,
    build_select,
    build_top_n,
    quote_qualified,
    validate_identifier,
)


# ---------------------------------------------------------------------------
# validate_identifier
# ---------------------------------------------------------------------------


def test_accepts_simple_identifier() -> None:
    assert validate_identifier("users") == "users"


def test_accepts_underscore_prefix() -> None:
    assert validate_identifier("_internal") == "_internal"


def test_accepts_camel_case() -> None:
    assert validate_identifier("UserOrders") == "UserOrders"


def test_accepts_digits_after_letter() -> None:
    assert validate_identifier("u123") == "u123"


def test_rejects_empty() -> None:
    with pytest.raises(ValueError, match="empty"):
        validate_identifier("")


def test_rejects_leading_digit() -> None:
    with pytest.raises(ValueError, match="invalid identifier"):
        validate_identifier("123_users")


def test_rejects_semicolon() -> None:
    with pytest.raises(ValueError, match="invalid identifier"):
        validate_identifier("users;DROP")


def test_rejects_dash_dash() -> None:
    with pytest.raises(ValueError, match="invalid identifier"):
        validate_identifier("users--evil")


def test_rejects_spaces() -> None:
    with pytest.raises(ValueError, match="invalid identifier"):
        validate_identifier("user table")


def test_rejects_quotes() -> None:
    with pytest.raises(ValueError, match="invalid identifier"):
        validate_identifier("user'table")


def test_rejects_unicode() -> None:
    with pytest.raises(ValueError, match="invalid identifier"):
        validate_identifier("café")


def test_rejects_too_long() -> None:
    with pytest.raises(ValueError, match="too long"):
        validate_identifier("a" * 64)


# ---------------------------------------------------------------------------
# quote_qualified
# ---------------------------------------------------------------------------


def test_quote_qualified_basic() -> None:
    assert quote_qualified("public", "users") == '"public"."users"'


def test_quote_qualified_rejects_bad_schema() -> None:
    with pytest.raises(ValueError):
        quote_qualified("public; DROP", "users")


def test_quote_qualified_rejects_bad_table() -> None:
    with pytest.raises(ValueError):
        quote_qualified("public", "users--")


# ---------------------------------------------------------------------------
# build_select
# ---------------------------------------------------------------------------


def test_select_default_columns() -> None:
    sql, params = build_select("public", "users")
    assert sql == 'SELECT * FROM "public"."users" LIMIT 100'
    assert params == []


def test_select_explicit_columns() -> None:
    sql, params = build_select("public", "users", columns=["id", "email"])
    assert "SELECT \"id\", \"email\" FROM" in sql
    assert params == []


def test_select_with_filters_eq() -> None:
    sql, params = build_select(
        "public",
        "orders",
        filters={"user_id": FilterSpec(op="eq", value=42)},
    )
    assert '"user_id" = $1' in sql
    assert params == [42]


def test_select_with_multiple_filters() -> None:
    sql, params = build_select(
        "public",
        "orders",
        filters={
            "user_id": FilterSpec(op="eq", value=42),
            "status": FilterSpec(op="ne", value="cancelled"),
        },
    )
    assert "$1" in sql
    assert "$2" in sql
    assert params == [42, "cancelled"]


def test_select_with_in_filter() -> None:
    sql, params = build_select(
        "public",
        "orders",
        filters={"status": FilterSpec(op="in", values=["paid", "pending"])},
    )
    assert '"status" IN ($1, $2)' in sql
    assert params == ["paid", "pending"]


def test_select_with_is_null() -> None:
    sql, params = build_select(
        "public",
        "orders",
        filters={"deleted_at": FilterSpec(op="is_null")},
    )
    assert '"deleted_at" IS NULL' in sql
    assert params == []


def test_select_with_order_by() -> None:
    sql, _ = build_select(
        "public",
        "orders",
        order_by=[
            OrderClause(column="created_at", direction="desc"),
            OrderClause(column="id", direction="asc"),
        ],
    )
    assert 'ORDER BY "created_at" DESC, "id" ASC' in sql


def test_select_rejects_bad_filter_column() -> None:
    with pytest.raises(ValueError):
        build_select(
            "public",
            "users",
            filters={"id; DROP TABLE": FilterSpec(op="eq", value=1)},
        )


def test_select_rejects_bad_table() -> None:
    with pytest.raises(ValueError):
        build_select("public", "users; DROP")


def test_select_rejects_unknown_filter_op() -> None:
    with pytest.raises(ValueError, match="unknown filter op"):
        build_select(
            "public",
            "users",
            filters={"id": FilterSpec(op="EXEC", value=1)},  # type: ignore[arg-type]
        )


def test_select_rejects_in_with_no_values() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        build_select(
            "public",
            "users",
            filters={"id": FilterSpec(op="in", values=[])},
        )


def test_select_custom_limit() -> None:
    sql, _ = build_select("public", "users", limit=42)
    assert "LIMIT 42" in sql


def test_select_rejects_bad_order_column() -> None:
    with pytest.raises(ValueError):
        build_select(
            "public",
            "users",
            order_by=[OrderClause(column="id; DROP", direction="asc")],
        )


def test_select_rejects_bad_direction() -> None:
    with pytest.raises(ValueError, match="direction"):
        build_select(
            "public",
            "users",
            order_by=[
                OrderClause(column="id", direction="random")  # type: ignore[arg-type]
            ],
        )


# ---------------------------------------------------------------------------
# build_count
# ---------------------------------------------------------------------------


def test_count_basic() -> None:
    sql, params = build_count("public", "users")
    assert sql == 'SELECT COUNT(*) AS count FROM "public"."users" LIMIT 1'
    assert params == []


def test_count_with_filter() -> None:
    sql, params = build_count(
        "public",
        "users",
        filters={"active": FilterSpec(op="eq", value=True)},
    )
    assert '"active" = $1' in sql
    assert params == [True]


# ---------------------------------------------------------------------------
# build_aggregate
# ---------------------------------------------------------------------------


def test_aggregate_sum_casts_numeric() -> None:
    sql, _ = build_aggregate("public", "orders", "amount", "sum")
    assert '"amount"::numeric' in sql
    assert "SUM(" in sql
    assert "AS sum" in sql


def test_aggregate_avg_casts_numeric() -> None:
    sql, _ = build_aggregate("public", "orders", "amount", "avg")
    assert '"amount"::numeric' in sql


def test_aggregate_min_does_not_cast() -> None:
    sql, _ = build_aggregate("public", "orders", "amount", "min")
    assert "::numeric" not in sql
    assert "MIN(" in sql


def test_aggregate_count_does_not_cast() -> None:
    sql, _ = build_aggregate("public", "orders", "id", "count")
    assert "::numeric" not in sql
    assert "COUNT(" in sql


def test_aggregate_rejects_unknown_op() -> None:
    with pytest.raises(ValueError, match="unknown aggregate"):
        build_aggregate("public", "orders", "amount", "median")  # type: ignore[arg-type]


def test_aggregate_with_filter_uses_placeholder() -> None:
    sql, params = build_aggregate(
        "public",
        "orders",
        "amount",
        "sum",
        filters={"status": FilterSpec(op="eq", value="paid")},
    )
    assert "$1" in sql
    assert params == ["paid"]


# ---------------------------------------------------------------------------
# build_top_n
# ---------------------------------------------------------------------------


def test_top_n_basic_desc() -> None:
    sql, _ = build_top_n("public", "orders", "amount", 5)
    assert 'ORDER BY "amount"::numeric DESC NULLS LAST' in sql
    assert "LIMIT 5" in sql


def test_top_n_asc() -> None:
    sql, _ = build_top_n("public", "orders", "amount", 5, direction="asc")
    assert 'ORDER BY "amount"::numeric ASC NULLS LAST' in sql


def test_top_n_caps_at_1000() -> None:
    sql, _ = build_top_n("public", "orders", "amount", 9999)
    assert "LIMIT 1000" in sql


def test_top_n_min_1() -> None:
    sql, _ = build_top_n("public", "orders", "amount", 0)
    assert "LIMIT 1" in sql


def test_top_n_with_filters() -> None:
    sql, params = build_top_n(
        "public",
        "orders",
        "amount",
        3,
        filters={"status": FilterSpec(op="eq", value="paid")},
    )
    assert "$1" in sql
    assert params == ["paid"]


def test_top_n_with_columns() -> None:
    sql, _ = build_top_n(
        "public", "orders", "amount", 5, columns=["id", "amount"]
    )
    assert 'SELECT "id", "amount" FROM' in sql


def test_top_n_rejects_bad_direction() -> None:
    with pytest.raises(ValueError, match="direction"):
        build_top_n("public", "orders", "amount", 5, direction="random")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# build_rpc_call
# ---------------------------------------------------------------------------


def test_rpc_call_no_args() -> None:
    sql, params = build_rpc_call("public", "compute_revenue")
    assert sql == 'SELECT * FROM "public"."compute_revenue"() LIMIT 1000'
    assert params == []


def test_rpc_call_with_args() -> None:
    sql, params = build_rpc_call(
        "public", "compute_revenue", args=["2026-01-01", "2026-12-31"]
    )
    assert "$1" in sql and "$2" in sql
    assert params == ["2026-01-01", "2026-12-31"]


def test_rpc_call_rejects_bad_function_name() -> None:
    with pytest.raises(ValueError):
        build_rpc_call("public", "fn(); DROP TABLE")


def test_rpc_call_rejects_bad_schema() -> None:
    with pytest.raises(ValueError):
        build_rpc_call("public; DROP", "fn")
