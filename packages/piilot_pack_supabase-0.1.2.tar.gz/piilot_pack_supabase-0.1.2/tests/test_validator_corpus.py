"""Validator regression — corpus of legitimate SELECTs (Phase 10).

Reads ``tests/fixtures/known_legitimate_selects.sql`` and feeds every
named block to ``validator.validate``. Every entry MUST pass — a
rejection here is a false-positive (the validator refuses a legit
SELECT) and ships as a P1 bug. Fix the validator OR move the case
to ``known_false_positives.sql`` with a documented workaround.

The fixture file uses the convention::

    --- @ <name>
    <SQL...>

which mirrors the `cargo-bench` style: human-readable, line-oriented
diffs, easy to review in a PR.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterator, Tuple

import pytest

from piilot_pack_supabase.validator import validate as validator_validate


FIXTURE = Path(__file__).parent / "fixtures" / "known_legitimate_selects.sql"


_ALLOWED = frozenset(
    {
        ("public", "users"),
        ("public", "products"),
        ("public", "orders"),
        ("public", "order_items"),
        ("public", "events"),
        ("public", "invoices"),
        ("public", "tickets"),
    }
)


def _parse_corpus(text: str) -> Iterator[Tuple[str, str]]:
    """Yield ``(name, sql)`` pairs from the fixture file.

    Blocks are delimited by ``--- @ <name>`` markers; SQL ends at the
    next marker or EOF. Comment-only lines (``-- ...``) and blank
    lines between blocks are stripped.
    """
    name: str | None = None
    buf: list[str] = []
    for line in text.splitlines():
        if line.startswith("--- @ "):
            if name is not None:
                sql = "\n".join(buf).strip()
                if sql:
                    yield name, sql
            name = line.removeprefix("--- @ ").strip()
            buf = []
            continue
        # Skip standalone comment / section header lines.
        stripped = line.strip()
        if stripped.startswith("--") and not stripped.startswith("---"):
            continue
        buf.append(line)
    if name is not None:
        sql = "\n".join(buf).strip()
        if sql:
            yield name, sql


def _load_cases() -> list[tuple[str, str]]:
    return list(_parse_corpus(FIXTURE.read_text(encoding="utf-8")))


_CASES = _load_cases()


def test_corpus_size() -> None:
    """The corpus must hold at least 50 cases (Phase 10 spec)."""
    assert len(_CASES) >= 50, (
        f"Need ≥ 50 legitimate SELECTs, found {len(_CASES)}. "
        "Add more cases to tests/fixtures/known_legitimate_selects.sql."
    )


@pytest.mark.parametrize(
    "name, sql",
    _CASES,
    ids=[name for name, _ in _CASES],
)
def test_validator_accepts_legit_select(name: str, sql: str) -> None:
    """Each named SELECT in the corpus passes validation."""
    # validate() returns the (possibly LIMIT-injected) rewritten SQL on
    # success and raises ValidationError on rejection.
    validator_validate(sql, allowed_tables=_ALLOWED)
