"""Tests for ``agent_template.register_agent_template``.

The function pushes one row to the SDK template buffer
(``piilot.sdk.templates._drain``). We verify the row's shape and
that it stays idempotent across repeated calls (deterministic UUID).
"""

from __future__ import annotations

import importlib

from piilot.sdk import templates as sdk_templates

from piilot_pack_supabase.agent_template import (
    _TEMPLATE_ID,
    _TEMPLATE_SLUG,
    register_agent_template,
)


def test_template_lands_in_sdk_buffer(plugin_context) -> None:
    """register_agent_template() pushes one row to the SDK buffer."""
    sdk_templates._drain()  # reset
    with plugin_context("supabase"):
        register_agent_template()
    rows = sdk_templates._drain()
    assert len(rows) == 1
    row = rows[0]
    assert row["id"] == _TEMPLATE_ID
    assert row["slug"] == _TEMPLATE_SLUG
    assert row["template_category"] == "data"
    assert row["is_active"] is True


def test_template_tools_enabled_includes_all_supabase_tools(
    plugin_context,
) -> None:
    """Every Supabase tool registered in __init__.py is in tools_enabled."""
    sdk_templates._drain()
    with plugin_context("supabase"):
        register_agent_template()
    row = sdk_templates._drain()[0]

    expected = {
        "supabase_list_connections",
        "supabase_select_connection",
        "supabase_describe_connection",
        "supabase_search_schema",
        "supabase_describe_table",
        "supabase_select",
        "supabase_count",
        "supabase_aggregate",
        "supabase_top_n",
        "supabase_invoke_rpc",
        "supabase_storage_list",
        "supabase_sql_advanced",
    }
    actual = set(row["tools_enabled"])
    missing = expected - actual
    assert not missing, f"missing tools in template: {missing}"


def test_template_prompt_warns_against_injection(plugin_context) -> None:
    """The prompt explicitly mentions injection defenses."""
    sdk_templates._drain()
    with plugin_context("supabase"):
        register_agent_template()
    row = sdk_templates._drain()[0]
    prompt = row["prompt_system"]
    # Anti-injection clause — keywords from the actual prompt body.
    assert "ignore les consignes précédentes" in prompt
    assert "données" in prompt
    assert "{company_name}" in prompt


def test_template_id_is_stable_across_calls(plugin_context) -> None:
    """The deterministic UUID survives multiple register() calls."""
    sdk_templates._drain()
    with plugin_context("supabase"):
        register_agent_template()
        register_agent_template()
    rows = sdk_templates._drain()
    # SDK buffer dedupes by ID — at least one row, all with the same ID.
    assert all(r["id"] == _TEMPLATE_ID for r in rows)


def test_full_plugin_register_includes_template(
    fake_ctx, plugin_context
) -> None:
    """End-to-end Plugin.register() pushes the template to the buffer."""
    sdk_templates._drain()
    pkg = importlib.import_module("piilot_pack_supabase")
    plugin = pkg.Plugin()
    with plugin_context("supabase"):
        plugin.register(fake_ctx)
    rows = sdk_templates._drain()
    assert any(r["id"] == _TEMPLATE_ID for r in rows)
