"""Unit tests for introspect_pg pure helpers.

The real query paths (list_tables, list_columns, …) need a live
Postgres and are exercised by ``tests/integration/test_introspect_pg.py``
under testcontainers (Phase 10 in suivi.md). This file covers the
synchronous helpers that we can test without a database:

* :func:`should_include_schema` — schema filter logic
* :func:`pg_to_kb_type` — Postgres type → KB column type mapping
"""

from __future__ import annotations

from piilot_pack_supabase.introspect_pg import (
    EXCLUDED_SCHEMAS,
    pg_to_kb_type,
    should_include_schema,
)


# ---------------------------------------------------------------------------
# should_include_schema
# ---------------------------------------------------------------------------


def test_excludes_pg_internal_schemas() -> None:
    assert should_include_schema("pg_catalog") is False
    assert should_include_schema("pg_temp_3") is False
    assert should_include_schema("pg_toast") is False


def test_excludes_supabase_system_schemas() -> None:
    """Auth, vault, storage and other Supabase internals are off-limits."""
    for name in ("auth", "vault", "pgsodium", "storage", "_realtime", "_supabase"):
        assert should_include_schema(name) is False, f"{name} must be excluded"


def test_excludes_extensions_schema() -> None:
    assert should_include_schema("extensions") is False


def test_allows_public_by_default() -> None:
    assert should_include_schema("public") is True


def test_allows_custom_user_schema_by_default() -> None:
    assert should_include_schema("analytics") is True
    assert should_include_schema("reporting") is True


def test_explicit_included_set_filters_out_others() -> None:
    included = frozenset({"public"})
    assert should_include_schema("public", included=included) is True
    assert should_include_schema("analytics", included=included) is False


def test_excluded_takes_precedence_over_included() -> None:
    """If an admin somehow puts ``auth`` in their included set, we
    still refuse it. Defense against misconfig.
    """
    included = frozenset({"auth", "public"})
    assert should_include_schema("auth", included=included) is False


def test_custom_excluded_set_overrides_default() -> None:
    """Passing an empty excluded set lets every non-pg schema through."""
    assert should_include_schema(
        "auth", excluded=frozenset()
    ) is True


def test_empty_schema_name_excluded() -> None:
    assert should_include_schema("") is False


def test_default_excluded_includes_known_supabase_schemas() -> None:
    """Sanity check: the EXCLUDED_SCHEMAS frozenset stays in sync
    with the docstring claims."""
    for name in (
        "auth",
        "vault",
        "pgsodium",
        "storage",
        "_realtime",
        "_supabase",
        "extensions",
        "graphql",
        "graphql_public",
        "realtime",
        "supabase_functions",
        "supabase_migrations",
    ):
        assert name in EXCLUDED_SCHEMAS, f"{name} missing from EXCLUDED_SCHEMAS"


# ---------------------------------------------------------------------------
# pg_to_kb_type
# ---------------------------------------------------------------------------


def test_numeric_types_map_to_numeric() -> None:
    for pg in (
        "smallint",
        "integer",
        "bigint",
        "decimal",
        "numeric",
        "real",
        "double precision",
        "serial",
        "bigserial",
        "smallserial",
        "money",
    ):
        assert pg_to_kb_type(pg) == "numeric", f"{pg} should map to numeric"


def test_date_time_types_map_to_date() -> None:
    for pg in (
        "date",
        "time",
        "timestamp",
        "timestamp without time zone",
        "timestamp with time zone",
        "interval",
    ):
        assert pg_to_kb_type(pg) == "date", f"{pg} should map to date"


def test_string_types_map_to_text() -> None:
    for pg in (
        "character varying",
        "character",
        "text",
        "uuid",
        "bytea",
        "boolean",
    ):
        assert pg_to_kb_type(pg) == "text", f"{pg} should map to text"


def test_json_types_map_to_text() -> None:
    """JSON / JSONB / arrays are serialised as text in the KB row."""
    for pg in ("json", "jsonb", "ARRAY", "USER-DEFINED"):
        assert pg_to_kb_type(pg) == "text", f"{pg} should map to text"


def test_array_prefix_maps_to_text() -> None:
    """``information_schema.columns.data_type`` returns ``ARRAY`` for
    array types regardless of element type. We catch that prefix.
    """
    assert pg_to_kb_type("ARRAY") == "text"


def test_unknown_type_falls_back_to_text() -> None:
    assert pg_to_kb_type("some_extension_type") == "text"
    assert pg_to_kb_type("hstore") == "text"


def test_empty_type_falls_back_to_text() -> None:
    assert pg_to_kb_type("") == "text"


def test_case_insensitive() -> None:
    """SQL standard data types come back uppercase from
    ``information_schema`` — we lowercase before matching.
    """
    assert pg_to_kb_type("INTEGER") == "numeric"
    assert pg_to_kb_type("Timestamp With Time Zone") == "date"
