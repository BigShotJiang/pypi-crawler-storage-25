"""Unit tests for ``PATCH /plugins/supabase/connections/{id}``.

The host-side ``Depends(require_admin)`` is bypassed by invoking the
async function directly with a synthetic ``auth`` tuple. The SDK
primitives (`get_connection`, `update_config`) are mocked.
"""

from __future__ import annotations

from unittest.mock import patch as mock_patch

import pytest
from fastapi import HTTPException

from piilot_pack_supabase.routes import (
    PatchConnectionRequest,
    patch_connection,
)


_AUTH = ("user-1", "admin", "company-A")


def _fake_connection(
    *,
    company_id: str = "company-A",
    selected_tables: list[str] | None = None,
) -> dict:
    return {
        "id": "conn-1",
        "label": "Test",
        "provider": "supabase",
        "is_active": True,
        "organization_id": company_id,
        "config": {
            "project_ref": "abcdefghij",
            "selected_tables": selected_tables or [],
            "selected_rpc": [],
        },
        "credentials": {"supabase_pat": "encrypted"},
        "created_at": None,
        "updated_at": None,
    }


def _fake_snapshot(tables: list[tuple[str, str]] | None = None) -> dict:
    tables = tables or [("public", "users"), ("public", "posts")]
    return {
        "tables_count": len(tables),
        "rpc_count": 0,
        "edge_functions_count": 0,
        "advisors_count": 0,
        "extensions_count": 0,
        "introspected_at": "2026-04-30T14:25:50+00:00",
        "tables_list": [{"schema": s, "name": n} for s, n in tables],
        "rpc_list": [],
        "tables_truncated": False,
    }


@pytest.mark.asyncio
async def test_patch_selected_tables_valid_subset() -> None:
    """Selecting tables that all exist in the snapshot succeeds."""
    body = PatchConnectionRequest(selected_tables=["public.users"])

    with mock_patch(
        "piilot_pack_supabase.routes.sdk_connectors.get_connection",
        return_value=_fake_connection(),
    ), mock_patch(
        "piilot_pack_supabase.routes.run_in_thread",
        side_effect=lambda fn, *a, **kw: _fake_snapshot()
        if fn.__name__ == "_fetch_snapshot_counts_sync"
        else None,
    ), mock_patch(
        "piilot_pack_supabase.routes.sdk_connectors.update_config",
        return_value={},
    ) as upd:
        await patch_connection("conn-1", body, auth=_AUTH)

    upd.assert_called_once_with("conn-1", {"selected_tables": ["public.users"]})


@pytest.mark.asyncio
async def test_patch_rejects_unknown_table() -> None:
    """Selecting a table absent from the snapshot returns HTTP 400."""
    body = PatchConnectionRequest(selected_tables=["public.nonexistent"])

    with mock_patch(
        "piilot_pack_supabase.routes.sdk_connectors.get_connection",
        return_value=_fake_connection(),
    ), mock_patch(
        "piilot_pack_supabase.routes.run_in_thread",
        side_effect=lambda fn, *a, **kw: _fake_snapshot(),
    ):
        with pytest.raises(HTTPException) as excinfo:
            await patch_connection("conn-1", body, auth=_AUTH)

    assert excinfo.value.status_code == 400
    assert "public.nonexistent" in excinfo.value.detail


@pytest.mark.asyncio
async def test_patch_409_when_no_snapshot() -> None:
    """Cannot select tables before refresh-schema has been run."""
    body = PatchConnectionRequest(selected_tables=["public.users"])

    with mock_patch(
        "piilot_pack_supabase.routes.sdk_connectors.get_connection",
        return_value=_fake_connection(),
    ), mock_patch(
        "piilot_pack_supabase.routes.run_in_thread",
        side_effect=lambda fn, *a, **kw: None,  # snapshot helper returns None
    ):
        with pytest.raises(HTTPException) as excinfo:
            await patch_connection("conn-1", body, auth=_AUTH)

    assert excinfo.value.status_code == 409


@pytest.mark.asyncio
async def test_patch_404_when_unknown_connection() -> None:
    """Unknown connection_id returns 404."""
    body = PatchConnectionRequest(selected_tables=["public.users"])

    with mock_patch(
        "piilot_pack_supabase.routes.sdk_connectors.get_connection",
        return_value=None,
    ):
        with pytest.raises(HTTPException) as excinfo:
            await patch_connection("ghost", body, auth=_AUTH)

    assert excinfo.value.status_code == 404


@pytest.mark.asyncio
async def test_patch_404_when_company_mismatch() -> None:
    """Connection belongs to another company → 404 (not 403, to avoid leak)."""
    body = PatchConnectionRequest(selected_tables=["public.users"])

    with mock_patch(
        "piilot_pack_supabase.routes.sdk_connectors.get_connection",
        return_value=_fake_connection(company_id="company-B"),
    ):
        with pytest.raises(HTTPException) as excinfo:
            await patch_connection("conn-1", body, auth=_AUTH)

    assert excinfo.value.status_code == 404


@pytest.mark.asyncio
async def test_patch_advanced_sql_only() -> None:
    """Patching only ``advanced_sql_enabled`` skips snapshot validation."""
    body = PatchConnectionRequest(advanced_sql_enabled=True)

    with mock_patch(
        "piilot_pack_supabase.routes.sdk_connectors.get_connection",
        return_value=_fake_connection(),
    ), mock_patch(
        "piilot_pack_supabase.routes.run_in_thread",
        side_effect=lambda fn, *a, **kw: _fake_snapshot()
        if fn.__name__ == "_fetch_snapshot_counts_sync"
        else None,
    ), mock_patch(
        "piilot_pack_supabase.routes.sdk_connectors.update_config",
        return_value={},
    ) as upd:
        await patch_connection("conn-1", body, auth=_AUTH)

    upd.assert_called_once_with("conn-1", {"advanced_sql_enabled": True})


def test_request_body_validation_max_500_tables() -> None:
    """Pydantic rejects >500 tables in selected_tables."""
    too_many = [f"public.t{i}" for i in range(501)]
    with pytest.raises(Exception):
        PatchConnectionRequest(selected_tables=too_many)


def test_request_body_validation_optional_fields() -> None:
    """All fields are optional — empty body is valid (no-op patch)."""
    body = PatchConnectionRequest()
    assert body.selected_tables is None
    assert body.selected_rpc is None
    assert body.advanced_sql_enabled is None
    assert body.label is None
