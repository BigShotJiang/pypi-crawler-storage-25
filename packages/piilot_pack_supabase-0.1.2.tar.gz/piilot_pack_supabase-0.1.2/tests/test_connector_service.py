"""Connector orchestration tests — Phase 8 PAT-only flow.

Phase 8 dropped: SetupSnippet, parse_supabase_url (host/port tuple),
build_connection_params (asyncpg ConnectionParams), the 32-char
password generation. The piilot_readonly user is gone.

What's left to test:
  * extract_project_ref — pure URL parsing (Cloud / db.<ref> / self-hosted)
  * get_pat — config['supabase_pat'] decryption (or None)
  * create_connection — disclaimer guard + URL validation +
    save_connection invocation shape

The ping path (test_connection) and refresh_schema are exercised in
their respective integration tests (HTTP mocked via respx).
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from piilot_pack_supabase.connector_service import (
    create_connection,
    extract_project_ref,
    get_pat,
)


# ---------------------------------------------------------------------------
# extract_project_ref
# ---------------------------------------------------------------------------


def test_extract_ref_from_cloud_url() -> None:
    assert extract_project_ref("https://abcdefg.supabase.co") == "abcdefg"


def test_extract_ref_from_db_qualified_url() -> None:
    assert extract_project_ref("https://db.abcdefg.supabase.co") == "abcdefg"


def test_extract_ref_returns_none_for_self_hosted() -> None:
    assert extract_project_ref("https://supabase.example.com") is None


def test_extract_ref_handles_trailing_slash() -> None:
    assert extract_project_ref("https://abc.supabase.co/path") == "abc"


def test_extract_ref_lowercases() -> None:
    assert extract_project_ref("https://ABC.SUPABASE.CO") == "abc"


def test_extract_ref_handles_whitespace() -> None:
    assert extract_project_ref("  https://abc.supabase.co  ") == "abc"


# ---------------------------------------------------------------------------
# get_pat
# ---------------------------------------------------------------------------


def test_get_pat_returns_none_when_absent() -> None:
    assert get_pat({"config": {}}) is None
    assert get_pat({}) is None
    assert get_pat({"config": None}) is None


def test_get_pat_decrypts_when_present() -> None:
    row = {"config": {"supabase_pat": "ENCRYPTED_PAT"}}
    with patch(
        "piilot_pack_supabase.connector_service.sdk_crypto.decrypt",
        return_value="sbp_cleartext",
    ) as mock_decrypt:
        out = get_pat(row)
    mock_decrypt.assert_called_once_with("ENCRYPTED_PAT")
    assert out == "sbp_cleartext"


# ---------------------------------------------------------------------------
# create_connection
# ---------------------------------------------------------------------------


def test_create_refuses_without_disclaimer_acknowledged() -> None:
    with pytest.raises(ValueError, match="RLS disclaimer"):
        create_connection(
            company_id="c",
            project_ref_or_url="fmjxjnzyeeslwyewpipw",
            label="Prod",
            pat="sbp_xxx",
            rls_disclaimer_acknowledged=False,
        )


def test_create_refuses_without_pat() -> None:
    with pytest.raises(ValueError, match="Personal Access Token"):
        create_connection(
            company_id="c",
            project_ref_or_url="fmjxjnzyeeslwyewpipw",
            label="Prod",
            pat="",
            rls_disclaimer_acknowledged=True,
        )


def test_create_refuses_invalid_ref() -> None:
    """Garbage inputs are rejected before save_connection runs."""
    with pytest.raises(ValueError):
        create_connection(
            company_id="c",
            project_ref_or_url="not a ref nor a url",
            label="Acme",
            pat="sbp_xxx",
            rls_disclaimer_acknowledged=True,
        )


def test_create_accepts_bare_ref() -> None:
    with patch(
        "piilot_pack_supabase.connector_service.sdk_connectors.save_connection",
        return_value={"id": "new-uuid"},
    ) as mock_save:
        out = create_connection(
            company_id="company-1",
            project_ref_or_url="fmjxjnzyeeslwyewpipw",
            label="Prod EU",
            pat="sbp_xxx",
            rls_disclaimer_acknowledged=True,
        )

    assert out == {"id": "new-uuid"}
    kwargs = mock_save.call_args.kwargs
    assert kwargs["label"] == "Prod EU"
    assert kwargs["credentials"] == {"supabase_pat": "sbp_xxx"}
    assert "pg_readonly_password" not in kwargs["credentials"]

    config = kwargs["config"]
    assert config["project_ref"] == "fmjxjnzyeeslwyewpipw"
    assert config["supabase_url"] == "https://fmjxjnzyeeslwyewpipw.supabase.co"
    assert config["selected_tables"] == []
    assert config["advanced_sql_enabled"] is False
    assert "pg_host" not in config


def test_create_accepts_full_url_and_normalizes() -> None:
    """Backwards compat: a full URL still works (frontend may pass it)."""
    with patch(
        "piilot_pack_supabase.connector_service.sdk_connectors.save_connection",
        return_value={"id": "new-uuid"},
    ) as mock_save:
        create_connection(
            company_id="c",
            project_ref_or_url="https://myproject.supabase.co",
            label="X",
            pat="sbp_xxx",
            rls_disclaimer_acknowledged=True,
        )
    config = mock_save.call_args.kwargs["config"]
    assert config["project_ref"] == "myproject"
    assert config["supabase_url"] == "https://myproject.supabase.co"


def test_create_lowercases_ref() -> None:
    with patch(
        "piilot_pack_supabase.connector_service.sdk_connectors.save_connection",
        return_value={"id": "uuid"},
    ) as mock_save:
        create_connection(
            company_id="c",
            project_ref_or_url="ABCDEFGHIJ12345678AB",
            label="X",
            pat="sbp_xxx",
            rls_disclaimer_acknowledged=True,
        )
    config = mock_save.call_args.kwargs["config"]
    assert config["project_ref"] == "abcdefghij12345678ab"
