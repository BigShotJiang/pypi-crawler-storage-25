"""Smoke tests that prove the plugin boots correctly.

Minimum tests every plugin should ship. They verify:

1. The plugin package imports without error.
2. The manifest loaded from ``pyproject.toml`` is valid against the
   Piilot SDK JSON Schema.
3. ``Plugin.register(ctx)`` wires its declared primitives without
   raising under a fake :class:`Context` from ``conftest.py``.
4. The connector spec lands in the SDK registry with the expected
   shape (auth_type, two-secret credentials_schema, no service_role).

These run **without** a Piilot backend — the fake Context fixture
covers everything ``register()`` reads at boot time.
"""

from __future__ import annotations

import importlib


def test_plugin_package_imports():
    """The plugin package is importable — basic syntactic smoke."""
    pkg = importlib.import_module("piilot_pack_supabase")
    assert hasattr(pkg, "Plugin"), "The plugin package must expose a 'Plugin' class"


def test_manifest_valid():
    """The pyproject.toml manifest passes the SDK schema validation
    that ran at package import time."""
    pkg = importlib.import_module("piilot_pack_supabase")
    m = pkg.Plugin.manifest
    assert m["manifest_version"] == 1
    assert m["namespace"] == "supabase"
    assert "supported_modes" in m and m["supported_modes"]
    assert "sdk_compat" in m


def test_plugin_register_does_not_raise(fake_ctx, plugin_context):
    """Plugin.register() runs to completion against a fake Context.

    The plugin_context fixture sets ``current_plugin`` so SDK
    primitives called from ``register()`` (register_connector, …)
    can resolve the plugin's namespace.
    """
    pkg = importlib.import_module("piilot_pack_supabase")
    plugin = pkg.Plugin()
    with plugin_context("supabase"):
        plugin.register(fake_ctx)  # must not raise


def test_connector_registered_with_expected_shape(fake_ctx, plugin_context):
    """register_connector queues the supabase.api spec correctly.

    Phase 8 PAT-only flow: a single ``supabase_pat`` credential
    (required). The legacy ``pg_readonly_password`` is gone —
    Management API SQL exec replaces direct PG.

    Checks:
      * id = 'supabase.api'
      * auth_type = 'custom'
      * credentials_schema has exactly one secret: supabase_pat (required)
      * Defense: 'service_role' / 'pg_readonly_password' MUST NOT appear.
    """
    from piilot.sdk import connectors as sdk_connectors

    sdk_connectors._drain()

    pkg = importlib.import_module("piilot_pack_supabase")
    plugin = pkg.Plugin()
    with plugin_context("supabase"):
        plugin.register(fake_ctx)

    specs = sdk_connectors._drain()
    supabase_specs = [s for s in specs if s.get("id") == "supabase.api"]
    assert len(supabase_specs) == 1, (
        f"Expected exactly one supabase.api connector, got {len(supabase_specs)}"
    )

    spec = supabase_specs[0]
    assert spec["auth_type"] == "custom"

    creds = spec["credentials_schema"]
    assert len(creds) == 1, "Phase 8 PAT-only: should ship exactly 1 secret"
    assert creds[0]["name"] == "supabase_pat"
    assert creds[0]["required"] is True
    assert creds[0]["type"] == "secret"

    # Defense: banned credentials must NEVER appear.
    field_names = {c["name"] for c in creds}
    assert "service_role" not in field_names
    assert "service_role_key" not in field_names
    assert "pg_readonly_password" not in field_names, (
        "Phase 8 dropped the PG-direct path — pg_readonly_password "
        "must not be back on the credentials_schema."
    )
