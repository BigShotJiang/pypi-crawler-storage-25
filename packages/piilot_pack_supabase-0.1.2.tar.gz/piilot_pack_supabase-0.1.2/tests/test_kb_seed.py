"""Tests for the KB metadata seeder.

The pure helpers are unit-tested here. The full seed flow against a
real ``knowledge_bases`` / ``kb_columns`` schema is exercised at
integration time.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from piilot_pack_supabase.kb_seed import (
    KB_NAME_PREFIX,
    _COLUMN_SPECS,
    ensure_supabase_metadata_kb,
    kb_name_for,
)


# ---------------------------------------------------------------------------
# kb_name_for
# ---------------------------------------------------------------------------


def test_kb_name_for_format() -> None:
    assert kb_name_for("Prod EU") == f"{KB_NAME_PREFIX}Prod EU"


def test_kb_name_prefix_constant() -> None:
    """Renaming this constant strands existing companies — keep it
    stable across releases."""
    assert KB_NAME_PREFIX == "Supabase Schema — "


def test_kb_name_handles_unicode() -> None:
    assert kb_name_for("Étude·légère") == f"{KB_NAME_PREFIX}Étude·légère"


# ---------------------------------------------------------------------------
# Column specs
# ---------------------------------------------------------------------------


def test_column_specs_count() -> None:
    """Hardcoded count avoids accidental column drift across releases."""
    assert len(_COLUMN_SPECS) == 8


def test_column_specs_have_required_fields() -> None:
    for spec in _COLUMN_SPECS:
        assert "name" in spec
        assert "column_type" in spec
        assert "description" in spec


def test_column_specs_use_supported_types() -> None:
    """KB column types must match the kb_columns.column_type CHECK
    constraint: text / numeric / date / file / kb_ref."""
    valid_types = {"text", "numeric", "date", "file", "kb_ref"}
    for spec in _COLUMN_SPECS:
        assert spec["column_type"] in valid_types, (
            f"{spec['name']}: invalid column_type {spec['column_type']!r}"
        )


def test_column_specs_have_unique_names() -> None:
    names = [s["name"] for s in _COLUMN_SPECS]
    assert len(names) == len(set(names)), "Column names must be unique"


def test_required_columns_present() -> None:
    """The schema design requires these specific columns — drift would
    break the agent's expected metadata shape."""
    names = {s["name"] for s in _COLUMN_SPECS}
    expected = {
        "entity_type",
        "schema_name",
        "name",
        "description",
        "data_type",
        "parent_table",
        "columns_text",
        "ref_url",
    }
    assert expected.issubset(names)


# ---------------------------------------------------------------------------
# ensure_supabase_metadata_kb idempotency
# ---------------------------------------------------------------------------


def test_ensure_returns_existing_kb_without_recreating() -> None:
    """find_kb hit → no create_kb call, no add_column calls."""
    fake_kb = {"id": "kb-uuid", "name": "Supabase Schema — Prod"}
    with (
        patch(
            "piilot_pack_supabase.kb_seed.find_kb", return_value=fake_kb
        ) as mock_find,
        patch("piilot_pack_supabase.kb_seed.create_kb") as mock_create,
        patch("piilot_pack_supabase.kb_seed.add_column") as mock_add,
    ):
        out = ensure_supabase_metadata_kb("company-1", "Prod")

    assert out is fake_kb
    mock_find.assert_called_once_with(
        company_id="company-1",
        name="Supabase Schema — Prod",
    )
    mock_create.assert_not_called()
    mock_add.assert_not_called()


def test_ensure_creates_kb_and_columns_on_miss() -> None:
    """find_kb miss → create_kb + 8 add_column calls."""
    fake_kb = {"id": "kb-new", "name": "Supabase Schema — Prod"}
    with (
        patch(
            "piilot_pack_supabase.kb_seed.find_kb", return_value=None
        ),
        patch(
            "piilot_pack_supabase.kb_seed.create_kb", return_value=fake_kb
        ) as mock_create,
        patch("piilot_pack_supabase.kb_seed.add_column") as mock_add,
    ):
        out = ensure_supabase_metadata_kb("company-1", "Prod")

    assert out is fake_kb
    mock_create.assert_called_once()
    create_kwargs = mock_create.call_args.kwargs
    assert create_kwargs["company_id"] == "company-1"
    assert create_kwargs["name"] == "Supabase Schema — Prod"
    assert create_kwargs["schema_locked"] is True
    assert mock_add.call_count == 8


def test_ensure_passes_position_in_order() -> None:
    """Columns must be added with monotonically increasing position."""
    fake_kb = {"id": "kb-new"}
    add_calls: list[int] = []

    def _capture_position(_kb_id: str, **kwargs: object) -> None:
        add_calls.append(int(kwargs["position"]))  # type: ignore[arg-type]

    with (
        patch("piilot_pack_supabase.kb_seed.find_kb", return_value=None),
        patch(
            "piilot_pack_supabase.kb_seed.create_kb", return_value=fake_kb
        ),
        patch(
            "piilot_pack_supabase.kb_seed.add_column",
            side_effect=_capture_position,
        ),
    ):
        ensure_supabase_metadata_kb("company-1", "Prod")

    assert add_calls == list(range(8))


def test_ensure_uses_correct_kb_name_format() -> None:
    """The KB name must come from kb_name_for — anywhere else and
    idempotency breaks."""
    captured: list[str] = []

    def _capture_name(*, company_id: str, name: str) -> None:
        captured.append(name)
        return None

    with (
        patch(
            "piilot_pack_supabase.kb_seed.find_kb",
            side_effect=_capture_name,
        ),
        patch("piilot_pack_supabase.kb_seed.create_kb"),
        patch("piilot_pack_supabase.kb_seed.add_column"),
    ):
        ensure_supabase_metadata_kb("c", "MyConn")

    assert captured == [f"{KB_NAME_PREFIX}MyConn"]
