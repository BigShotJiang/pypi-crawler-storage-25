"""Unit tests for the Management API client.

Mocks httpx via :mod:`respx` so we never touch the real Supabase API.
Covers happy path per endpoint plus the error mapping table:

  401 → invalid_token
  403 → forbidden
  404 → not_found
  5xx → server_error
  network / timeout → network
  unexpected JSON shape → server_error

Verifies:
  * The PAT is sent as ``Authorization: Bearer <token>``.
  * The PAT never appears in the SupabaseAPIError message.
  * Advisor responses are normalized whether the API returns a flat
    list or a ``{"lints": [...]}`` envelope.
"""

from __future__ import annotations

import httpx
import pytest
import respx

from piilot_pack_supabase.introspect_api import (
    MANAGEMENT_API_BASE,
    SupabaseAPIError,
    list_advisors_performance,
    list_advisors_security,
    list_edge_functions,
    list_storage_buckets,
    ping_management_api,
)

PROJECT_REF = "abcdefghij"
PAT = "sbp_test_token_value"


# ---------------------------------------------------------------------------
# Edge functions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_list_edge_functions_happy_path() -> None:
    sample = [
        {"id": "1", "slug": "hello-world", "status": "ACTIVE", "version": 3},
        {"id": "2", "slug": "stripe-webhook", "status": "ACTIVE", "version": 7},
    ]
    route = respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/functions"
    ).mock(return_value=httpx.Response(200, json=sample))

    async with httpx.AsyncClient() as client:
        out = await list_edge_functions(client, PROJECT_REF, PAT)

    assert out == sample
    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {PAT}"


@pytest.mark.asyncio
@respx.mock
async def test_list_edge_functions_401_invalid_token() -> None:
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/functions"
    ).mock(return_value=httpx.Response(401, json={"error": "unauthorized"}))

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await list_edge_functions(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "invalid_token"
    assert excinfo.value.status_code == 401
    # Defensive: the PAT must never appear in the error message.
    assert PAT not in str(excinfo.value)


@pytest.mark.asyncio
@respx.mock
async def test_list_edge_functions_403_forbidden() -> None:
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/functions"
    ).mock(return_value=httpx.Response(403))

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await list_edge_functions(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "forbidden"
    assert excinfo.value.status_code == 403


@pytest.mark.asyncio
@respx.mock
async def test_list_edge_functions_404_not_found() -> None:
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/functions"
    ).mock(return_value=httpx.Response(404))

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await list_edge_functions(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "not_found"
    assert excinfo.value.status_code == 404


@pytest.mark.asyncio
@respx.mock
async def test_list_edge_functions_500_server_error() -> None:
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/functions"
    ).mock(return_value=httpx.Response(503))

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await list_edge_functions(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "server_error"
    assert excinfo.value.status_code == 503


@pytest.mark.asyncio
@respx.mock
async def test_list_edge_functions_network_timeout() -> None:
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/functions"
    ).mock(side_effect=httpx.ConnectTimeout("connect timeout"))

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await list_edge_functions(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "network"
    assert excinfo.value.status_code == 0


@pytest.mark.asyncio
@respx.mock
async def test_list_edge_functions_rejects_non_list_body() -> None:
    """If the API contract drifts and returns a dict where we expect a
    list, raise server_error rather than misinterpret silently."""
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/functions"
    ).mock(return_value=httpx.Response(200, json={"oops": True}))

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await list_edge_functions(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "server_error"


@pytest.mark.asyncio
@respx.mock
async def test_list_edge_functions_rejects_non_json_body() -> None:
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/functions"
    ).mock(
        return_value=httpx.Response(200, content=b"not json", headers={"Content-Type": "text/plain"})
    )

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await list_edge_functions(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "server_error"


# ---------------------------------------------------------------------------
# Advisors
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_list_advisors_security_flat_list() -> None:
    sample = [
        {"name": "rls_disabled", "title": "RLS not enabled", "level": "ERROR"},
        {"name": "exposed_pii", "title": "PII exposed", "level": "WARN"},
    ]
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/advisors/security"
    ).mock(return_value=httpx.Response(200, json=sample))

    async with httpx.AsyncClient() as client:
        out = await list_advisors_security(client, PROJECT_REF, PAT)

    assert out == sample


@pytest.mark.asyncio
@respx.mock
async def test_list_advisors_security_lints_envelope() -> None:
    """Some Supabase API versions wrap the findings in {"lints": [...]}."""
    sample = [{"name": "rls_disabled", "level": "ERROR"}]
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/advisors/security"
    ).mock(return_value=httpx.Response(200, json={"lints": sample}))

    async with httpx.AsyncClient() as client:
        out = await list_advisors_security(client, PROJECT_REF, PAT)

    assert out == sample


@pytest.mark.asyncio
@respx.mock
async def test_list_advisors_security_other_envelope_keys() -> None:
    """Try ``findings`` / ``results`` / ``data`` keys too."""
    sample = [{"name": "x"}]
    for key in ("findings", "results", "data"):
        respx.reset()
        respx.get(
            f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/advisors/security"
        ).mock(return_value=httpx.Response(200, json={key: sample}))

        async with httpx.AsyncClient() as client:
            out = await list_advisors_security(client, PROJECT_REF, PAT)

        assert out == sample, f"Envelope key {key!r} should normalize"


@pytest.mark.asyncio
@respx.mock
async def test_list_advisors_security_unknown_envelope_returns_empty() -> None:
    """If the body is a dict but no recognized list key is present,
    return [] rather than raise — the snapshot just records no advisor
    findings."""
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/advisors/security"
    ).mock(return_value=httpx.Response(200, json={"unknown_envelope": True}))

    async with httpx.AsyncClient() as client:
        out = await list_advisors_security(client, PROJECT_REF, PAT)

    assert out == []


@pytest.mark.asyncio
@respx.mock
async def test_list_advisors_performance_routes_to_correct_path() -> None:
    sample = [{"name": "missing_index", "level": "WARN"}]
    route = respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}/advisors/performance"
    ).mock(return_value=httpx.Response(200, json=sample))

    async with httpx.AsyncClient() as client:
        out = await list_advisors_performance(client, PROJECT_REF, PAT)

    assert out == sample
    assert route.called


# ---------------------------------------------------------------------------
# Storage stub
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_storage_buckets_returns_empty_v1() -> None:
    """v1 stub: storage support is deferred per spec §14."""
    async with httpx.AsyncClient() as client:
        out = await list_storage_buckets(client, PROJECT_REF, PAT)
    assert out == []


# ---------------------------------------------------------------------------
# Ping
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_ping_happy_path() -> None:
    project = {
        "id": PROJECT_REF,
        "name": "My project",
        "region": "us-east-1",
    }
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}"
    ).mock(return_value=httpx.Response(200, json=project))

    async with httpx.AsyncClient() as client:
        out = await ping_management_api(client, PROJECT_REF, PAT)

    assert out == project


@pytest.mark.asyncio
@respx.mock
async def test_ping_404_when_pat_does_not_match_project() -> None:
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}"
    ).mock(return_value=httpx.Response(404))

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await ping_management_api(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "not_found"


@pytest.mark.asyncio
@respx.mock
async def test_ping_rejects_non_object_body() -> None:
    """Project metadata must be an object, not a list."""
    respx.get(
        f"{MANAGEMENT_API_BASE}/v1/projects/{PROJECT_REF}"
    ).mock(return_value=httpx.Response(200, json=[]))

    async with httpx.AsyncClient() as client:
        with pytest.raises(SupabaseAPIError) as excinfo:
            await ping_management_api(client, PROJECT_REF, PAT)

    assert excinfo.value.kind == "server_error"
