"""Tests for the audit log helper.

Covers the pure :func:`sanitize_payload` walker exhaustively. The
:func:`log_query` async insert is exercised at integration time
against the real ``integrations_supabase.audit_log`` table (Phase 10
testcontainers); mocking psycopg2's cursor / execute pipeline here
would test plumbing instead of the contract.
"""

from __future__ import annotations

from piilot_pack_supabase.audit import sanitize_payload


# ---------------------------------------------------------------------------
# sanitize_payload — top-level dicts
# ---------------------------------------------------------------------------


def test_redacts_password_key() -> None:
    out = sanitize_payload({"password": "hunter2", "name": "alice"})
    assert out == {"password": "<redacted>", "name": "alice"}


def test_redacts_token_key() -> None:
    out = sanitize_payload({"access_token": "x", "id": 1})
    assert out["access_token"] == "<redacted>"
    assert out["id"] == 1


def test_redacts_secret_key() -> None:
    out = sanitize_payload({"client_secret": "s", "id": 1})
    assert out["client_secret"] == "<redacted>"


def test_redacts_api_key_variants() -> None:
    for k in ("api_key", "apikey", "API_KEY", "ApiKey"):
        out = sanitize_payload({k: "v", "ok": "x"})
        assert out[k] == "<redacted>", f"{k} should be redacted"
        assert out["ok"] == "x"


def test_redacts_pat_key() -> None:
    out = sanitize_payload({"pat": "sbp_xxx", "purpose": "audit"})
    assert out["pat"] == "<redacted>"
    assert out["purpose"] == "audit"


def test_redacts_service_role_key() -> None:
    out = sanitize_payload(
        {"service_role_key": "anything_here", "id": 1}
    )
    assert out["service_role_key"] == "<redacted>"


def test_redacts_pg_readonly_password_substring_match() -> None:
    """Substring match catches namespace-prefixed variants."""
    out = sanitize_payload({"pg_readonly_password": "abc123"})
    assert out["pg_readonly_password"] == "<redacted>"


def test_does_not_redact_non_sensitive_keys() -> None:
    payload = {"id": 1, "email": "a@b", "active": True, "tags": ["x"]}
    out = sanitize_payload(payload)
    assert out == payload


# ---------------------------------------------------------------------------
# sanitize_payload — recursive
# ---------------------------------------------------------------------------


def test_recurses_into_nested_dicts() -> None:
    payload = {
        "user": {"id": 1, "password": "secret"},
        "stats": {"requests": 100},
    }
    out = sanitize_payload(payload)
    assert out["user"]["password"] == "<redacted>"
    assert out["user"]["id"] == 1
    assert out["stats"]["requests"] == 100


def test_recurses_into_lists() -> None:
    payload = {
        "events": [
            {"id": 1, "token": "x"},
            {"id": 2, "token": "y"},
        ]
    }
    out = sanitize_payload(payload)
    assert out["events"][0]["token"] == "<redacted>"
    assert out["events"][1]["token"] == "<redacted>"
    assert out["events"][0]["id"] == 1


def test_recurses_into_mixed_nesting() -> None:
    payload = {
        "outer": [
            {"inner": [{"password": "x"}]},
        ]
    }
    out = sanitize_payload(payload)
    assert out["outer"][0]["inner"][0]["password"] == "<redacted>"


# ---------------------------------------------------------------------------
# sanitize_payload — scalar / edge cases
# ---------------------------------------------------------------------------


def test_passes_scalars_through_unchanged() -> None:
    assert sanitize_payload(42) == 42
    assert sanitize_payload("hello") == "hello"
    assert sanitize_payload(None) is None
    assert sanitize_payload(True) is True


def test_empty_dict_unchanged() -> None:
    assert sanitize_payload({}) == {}


def test_empty_list_unchanged() -> None:
    assert sanitize_payload([]) == []


def test_does_not_mutate_input() -> None:
    payload = {"password": "x", "nested": {"token": "y"}}
    snapshot = {"password": "x", "nested": {"token": "y"}}
    sanitize_payload(payload)
    assert payload == snapshot


def test_redacts_value_regardless_of_type() -> None:
    """Even a list value under a sensitive key is redacted as a whole."""
    out = sanitize_payload({"tokens": ["a", "b", "c"]})
    assert out["tokens"] == "<redacted>"


def test_case_insensitive_substring_match() -> None:
    """Match on lowercased key — uppercase doesn't bypass."""
    out = sanitize_payload({"PASSWORD": "x", "Token": "y", "Secret": "z"})
    assert out["PASSWORD"] == "<redacted>"
    assert out["Token"] == "<redacted>"
    assert out["Secret"] == "<redacted>"
