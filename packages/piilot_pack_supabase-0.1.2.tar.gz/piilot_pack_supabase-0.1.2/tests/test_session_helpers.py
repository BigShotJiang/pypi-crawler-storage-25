"""Tests for the session-resolution helpers.

The async paths that touch the SDK session / connectors registry
are covered through their callers in the higher-level tool tests.
This file zooms in on :func:`resolve_connection_ref` since it has
non-trivial precedence rules (UUID > exact label > substring).
"""

from __future__ import annotations

from unittest.mock import patch

from piilot_pack_supabase._session_helpers import (
    MSG_NEED_SELECT,
    MSG_NO_CONNECTIONS,
    MSG_REF_NOT_FOUND,
    MSG_REF_REQUIRED,
    resolve_connection_ref,
)


# Three sample connections for the tests
_CONN_PROD = {
    "id": "11111111-1111-1111-1111-111111111111",
    "label": "Prod EU",
    "is_active": True,
}
_CONN_STAGING = {
    "id": "22222222-2222-2222-2222-222222222222",
    "label": "Staging",
    "is_active": True,
}
_CONN_PROD_US = {
    "id": "33333333-3333-3333-3333-333333333333",
    "label": "Prod US",
    "is_active": True,
}


def _stub_connections(connections: list) -> object:
    """Create a context manager that patches list_active_connections."""
    return patch(
        "piilot_pack_supabase._session_helpers.list_active_connections",
        return_value=connections,
    )


# ---------------------------------------------------------------------------
# Empty / missing inputs
# ---------------------------------------------------------------------------


def test_empty_ref_returns_required() -> None:
    with _stub_connections([_CONN_PROD]):
        conn, err = resolve_connection_ref("c", "")
    assert conn is None
    assert err == MSG_REF_REQUIRED


def test_whitespace_ref_returns_required() -> None:
    with _stub_connections([_CONN_PROD]):
        conn, err = resolve_connection_ref("c", "   ")
    assert conn is None
    assert err == MSG_REF_REQUIRED


def test_no_connections_returns_no_connections_message() -> None:
    with _stub_connections([]):
        conn, err = resolve_connection_ref("c", "anything")
    assert conn is None
    assert err == MSG_NO_CONNECTIONS


# ---------------------------------------------------------------------------
# UUID match (precedence 1)
# ---------------------------------------------------------------------------


def test_exact_uuid_match() -> None:
    with _stub_connections([_CONN_PROD, _CONN_STAGING]):
        conn, err = resolve_connection_ref("c", _CONN_PROD["id"])
    assert err is None
    assert conn is _CONN_PROD


def test_uuid_match_case_insensitive() -> None:
    with _stub_connections([_CONN_PROD]):
        conn, err = resolve_connection_ref("c", _CONN_PROD["id"].upper())
    assert err is None
    assert conn is _CONN_PROD


def test_uuid_takes_precedence_over_label_substring() -> None:
    """Even if a label happens to contain the UUID's hex chars, UUID
    match wins (it's exact + comes first in the resolution chain)."""
    weird = {"id": "abc12345-0000-0000-0000-000000000000", "label": "abc12345"}
    with _stub_connections([weird]):
        conn, err = resolve_connection_ref("c", weird["id"])
    assert conn is weird
    assert err is None


# ---------------------------------------------------------------------------
# Exact label match (precedence 2)
# ---------------------------------------------------------------------------


def test_exact_label_match() -> None:
    with _stub_connections([_CONN_PROD, _CONN_STAGING]):
        conn, err = resolve_connection_ref("c", "Prod EU")
    assert err is None
    assert conn is _CONN_PROD


def test_exact_label_case_insensitive() -> None:
    with _stub_connections([_CONN_PROD, _CONN_STAGING]):
        conn, err = resolve_connection_ref("c", "prod eu")
    assert err is None
    assert conn is _CONN_PROD


def test_exact_label_with_whitespace_trimmed() -> None:
    with _stub_connections([_CONN_PROD, _CONN_STAGING]):
        conn, err = resolve_connection_ref("c", "  Prod EU  ")
    assert err is None
    assert conn is _CONN_PROD


# ---------------------------------------------------------------------------
# Substring match (precedence 3)
# ---------------------------------------------------------------------------


def test_substring_unique_match() -> None:
    """'staging' uniquely matches the Staging connection."""
    with _stub_connections([_CONN_PROD, _CONN_STAGING]):
        conn, err = resolve_connection_ref("c", "stag")
    assert err is None
    assert conn is _CONN_STAGING


def test_substring_ambiguous_returns_need_select() -> None:
    """Two connections containing 'prod' → ambiguity."""
    with _stub_connections([_CONN_PROD, _CONN_PROD_US]):
        conn, err = resolve_connection_ref("c", "prod")
    assert conn is None
    assert err == MSG_NEED_SELECT


def test_substring_no_match_returns_not_found() -> None:
    with _stub_connections([_CONN_PROD, _CONN_STAGING]):
        conn, err = resolve_connection_ref("c", "preprod")
    assert conn is None
    assert err == MSG_REF_NOT_FOUND


# ---------------------------------------------------------------------------
# Single-connection edge cases
# ---------------------------------------------------------------------------


def test_single_connection_uuid_match() -> None:
    with _stub_connections([_CONN_PROD]):
        conn, err = resolve_connection_ref("c", _CONN_PROD["id"])
    assert conn is _CONN_PROD
    assert err is None


def test_single_connection_label_match() -> None:
    with _stub_connections([_CONN_PROD]):
        conn, err = resolve_connection_ref("c", "Prod EU")
    assert conn is _CONN_PROD


def test_single_connection_substring_match() -> None:
    with _stub_connections([_CONN_PROD]):
        conn, err = resolve_connection_ref("c", "Prod")
    assert conn is _CONN_PROD
