---
title: Recipient
description: "Payment recipient with account details"
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `Recipient`

Payment recipient with account details

## Properties

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `accountNumber` | `string` | ✓ | Recipient's bank account number Examples: `"5678-90-123456"`, `"GB29NWBK60161331926819"`. |
| `accountNumberType` | `string` \| `null` |  | Type of account number Default: `null`. Examples: `"Domestic"`, `"IBAN"`, `"SWIFT"`. |
| `address` | `string` \| `null` |  | Recipient's address (if available) Default: `null`. |
| `bankInfo` | `string` \| `null` |  | Bank name or identifier Default: `null`. Examples: `"Example Bank"`, `"Bank of America"`. |
| `description` | `string` \| `null` |  | User-provided description or note Default: `null`. Examples: `"Friend"`, `"Landlord"`, `"Contractor"`. |
| `id` | `string` \| `null` |  | Unique recipient identifier Default: `null`. |
| `isFavorite` | `boolean` |  | Whether this recipient is marked as favorite Default: `false`. |
| `name` | `string` | ✓ | Recipient's full name or business name |
| `paymentType` | `string` \| `null` |  | Type of payment supported Default: `null`. Examples: `"Domestic"`, `"International"`, `"SEPA"`. |
| `socialSecurityNumber` | `string` | ✓ | National ID / SSN (format varies by country) Examples: `"010190-1234"`, `"123-45-6789"`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Payment recipient with account details",
  "properties": {
    "accountNumber": {
      "description": "Recipient's bank account number",
      "examples": [
        "5678-90-123456",
        "GB29NWBK60161331926819"
      ],
      "title": "Accountnumber",
      "type": "string"
    },
    "accountNumberType": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Type of account number",
      "examples": [
        "Domestic",
        "IBAN",
        "SWIFT"
      ],
      "title": "Accountnumbertype"
    },
    "address": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Recipient's address (if available)",
      "title": "Address"
    },
    "bankInfo": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Bank name or identifier",
      "examples": [
        "Example Bank",
        "Bank of America"
      ],
      "title": "Bankinfo"
    },
    "description": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "User-provided description or note",
      "examples": [
        "Friend",
        "Landlord",
        "Contractor"
      ],
      "title": "Description"
    },
    "id": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Unique recipient identifier",
      "title": "Id"
    },
    "isFavorite": {
      "default": false,
      "description": "Whether this recipient is marked as favorite",
      "title": "Isfavorite",
      "type": "boolean"
    },
    "name": {
      "description": "Recipient's full name or business name",
      "title": "Name",
      "type": "string"
    },
    "paymentType": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Type of payment supported",
      "examples": [
        "Domestic",
        "International",
        "SEPA"
      ],
      "title": "Paymenttype"
    },
    "socialSecurityNumber": {
      "description": "National ID / SSN (format varies by country)",
      "examples": [
        "010190-1234",
        "123-45-6789"
      ],
      "title": "Socialsecuritynumber",
      "type": "string"
    }
  },
  "required": [
    "name",
    "socialSecurityNumber",
    "accountNumber"
  ],
  "title": "Recipient",
  "type": "object"
}
```

</details>
