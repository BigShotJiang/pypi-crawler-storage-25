---
title: Transaction
description: "Financial transaction with date, amount and metadata"
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `Transaction`

Financial transaction with date, amount and metadata

## Properties

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `amount` | `number` | ✓ | Transaction amount (negative for expenses, positive for income) |
| `category` | `string` \| `null` |  | Category name Default: `null`. |
| `description` | `string` | ✓ | Transaction description, merchant name or recipient name |
| `id` | `string` \| `null` |  | Unique transaction identifier Default: `null`. |
| `transaction_date` | `string` | ✓ | Transaction date in ISO 8601 format (YYYY-MM-DD) |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Financial transaction with date, amount and metadata",
  "properties": {
    "amount": {
      "description": "Transaction amount (negative for expenses, positive for income)",
      "title": "Amount",
      "type": "number"
    },
    "category": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Category name",
      "title": "Category"
    },
    "description": {
      "description": "Transaction description, merchant name or recipient name",
      "title": "Description",
      "type": "string"
    },
    "id": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Unique transaction identifier",
      "title": "Id"
    },
    "transaction_date": {
      "description": "Transaction date in ISO 8601 format (YYYY-MM-DD)",
      "format": "date",
      "title": "Transaction Date",
      "type": "string"
    }
  },
  "required": [
    "description",
    "amount",
    "transaction_date"
  ],
  "title": "Transaction",
  "type": "object"
}
```

</details>
