---
title: Data models
sidebar_position: 1
description: Shared Bank2AI data models — Account, Transaction, Category, Recipient.
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# Data models

These shared shapes are referenced from tool inputs and outputs. Servers MAY return additional fields; clients MUST tolerate unknown fields.

| Model | Description |
| --- | --- |
| [`Account`](./Account) | Bank account with balance and metadata |
| [`Category`](./Category) | Transaction category for spending classification |
| [`Recipient`](./Recipient) | Payment recipient with account details |
| [`Transaction`](./Transaction) | Financial transaction with date, amount and metadata |
