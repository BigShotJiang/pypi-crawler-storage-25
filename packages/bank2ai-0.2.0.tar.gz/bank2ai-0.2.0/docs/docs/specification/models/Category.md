---
title: Category
description: "Transaction category for spending classification"
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `Category`

Transaction category for spending classification

## Properties

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `id` | `string` | ✓ | Unique category identifier |
| `name` | `string` | ✓ | Category name (localized) Examples: `"Groceries"`, `"Transportation"`, `"Entertainment"`, `"Utilities"`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Transaction category for spending classification",
  "properties": {
    "id": {
      "description": "Unique category identifier",
      "title": "Id",
      "type": "string"
    },
    "name": {
      "description": "Category name (localized)",
      "examples": [
        "Groceries",
        "Transportation",
        "Entertainment",
        "Utilities"
      ],
      "title": "Name",
      "type": "string"
    }
  },
  "required": [
    "id",
    "name"
  ],
  "title": "Category",
  "type": "object"
}
```

</details>
