---
title: Account
description: "Bank account with balance and metadata"
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `Account`

Bank account with balance and metadata

## Properties

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `accountNumber` | `string` | ✓ | Formatted account number (format varies by country) Examples: `"1234-56-789012"`, `"GB29NWBK60161331926819"`. |
| `accountType` | `AccountType` \| `null` |  | Type of account Default: `null`. |
| `availableBalance` | `number` \| `null` |  | Available balance (after pending transactions) Default: `null`. |
| `balance` | `number` | ✓ | Current account balance |
| `currency` | `string` | ✓ | ISO 4217 currency code Examples: `"USD"`, `"EUR"`, `"ISK"`, `"GBP"`. Pattern: `^[A-Z]{3}$`. |
| `id` | `string` | ✓ | Unique account identifier |
| `isDefaultAccount` | `boolean` \| `null` |  | Whether this is the user's default account Default: `null`. |
| `isWithdrawalAccount` | `boolean` \| `null` |  | Whether this account can be used for withdrawals/transfers Default: `null`. |
| `name` | `string` \| `null` |  | Human-readable account name Default: `null`. Examples: `"Main Checking"`, `"Savings Account"`, `"Credit Card"`. |
| `overdraftLimit` | `number` \| `null` |  | Overdraft/credit limit (0 if none) Default: `null`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "$defs": {
    "AccountType": {
      "description": "Type of bank account.",
      "enum": [
        "Current",
        "Credit",
        "Savings"
      ],
      "title": "AccountType",
      "type": "string"
    }
  },
  "description": "Bank account with balance and metadata",
  "properties": {
    "accountNumber": {
      "description": "Formatted account number (format varies by country)",
      "examples": [
        "1234-56-789012",
        "GB29NWBK60161331926819"
      ],
      "title": "Accountnumber",
      "type": "string"
    },
    "accountType": {
      "anyOf": [
        {
          "$ref": "#/$defs/AccountType"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Type of account"
    },
    "availableBalance": {
      "anyOf": [
        {
          "type": "number"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Available balance (after pending transactions)",
      "title": "Availablebalance"
    },
    "balance": {
      "description": "Current account balance",
      "title": "Balance",
      "type": "number"
    },
    "currency": {
      "description": "ISO 4217 currency code",
      "examples": [
        "USD",
        "EUR",
        "ISK",
        "GBP"
      ],
      "pattern": "^[A-Z]{3}$",
      "title": "Currency",
      "type": "string"
    },
    "id": {
      "description": "Unique account identifier",
      "title": "Id",
      "type": "string"
    },
    "isDefaultAccount": {
      "anyOf": [
        {
          "type": "boolean"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Whether this is the user's default account",
      "title": "Isdefaultaccount"
    },
    "isWithdrawalAccount": {
      "anyOf": [
        {
          "type": "boolean"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Whether this account can be used for withdrawals/transfers",
      "title": "Iswithdrawalaccount"
    },
    "name": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Human-readable account name",
      "examples": [
        "Main Checking",
        "Savings Account",
        "Credit Card"
      ],
      "title": "Name"
    },
    "overdraftLimit": {
      "anyOf": [
        {
          "minimum": 0,
          "type": "number"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Overdraft/credit limit (0 if none)",
      "title": "Overdraftlimit"
    }
  },
  "required": [
    "id",
    "accountNumber",
    "currency",
    "balance"
  ],
  "title": "Account",
  "type": "object"
}
```

</details>
