---
title: get-accounts
description: "Get bank accounts and cards. Returns a list of accounts with balances, account numbers, and types."
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `get-accounts`

Get bank accounts and cards. Returns a list of accounts with balances, account numbers, and types.

## Input

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `account_type` | `"Current"` \| `"Savings"` \| `"Credit"` \| `null` |  | Filter by account type. Default: `null`. |
| `only_withdrawal_accounts` | `boolean` |  | If true, return only accounts usable for withdrawals/transfers. Default: `false`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "additionalProperties": false,
  "properties": {
    "account_type": {
      "anyOf": [
        {
          "enum": [
            "Current",
            "Savings",
            "Credit"
          ],
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Filter by account type."
    },
    "only_withdrawal_accounts": {
      "default": false,
      "description": "If true, return only accounts usable for withdrawals/transfers.",
      "type": "boolean"
    }
  },
  "type": "object"
}
```

</details>

## Output

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `items` | array&lt;`object`&gt; | ✓ | Accounts matching the request. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Envelope for a list of accounts",
  "properties": {
    "items": {
      "description": "Accounts matching the request.",
      "items": {
        "description": "Bank account with balance and metadata",
        "properties": {
          "accountNumber": {
            "description": "Formatted account number (format varies by country)",
            "examples": [
              "1234-56-789012",
              "GB29NWBK60161331926819"
            ],
            "type": "string"
          },
          "accountType": {
            "anyOf": [
              {
                "description": "Type of bank account.",
                "enum": [
                  "Current",
                  "Credit",
                  "Savings"
                ],
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Type of account"
          },
          "availableBalance": {
            "anyOf": [
              {
                "type": "number"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Available balance (after pending transactions)"
          },
          "balance": {
            "description": "Current account balance",
            "type": "number"
          },
          "currency": {
            "description": "ISO 4217 currency code",
            "examples": [
              "USD",
              "EUR",
              "ISK",
              "GBP"
            ],
            "pattern": "^[A-Z]{3}$",
            "type": "string"
          },
          "id": {
            "description": "Unique account identifier",
            "type": "string"
          },
          "isDefaultAccount": {
            "anyOf": [
              {
                "type": "boolean"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Whether this is the user's default account"
          },
          "isWithdrawalAccount": {
            "anyOf": [
              {
                "type": "boolean"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Whether this account can be used for withdrawals/transfers"
          },
          "name": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Human-readable account name",
            "examples": [
              "Main Checking",
              "Savings Account",
              "Credit Card"
            ]
          },
          "overdraftLimit": {
            "anyOf": [
              {
                "minimum": 0,
                "type": "number"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Overdraft/credit limit (0 if none)"
          }
        },
        "required": [
          "id",
          "accountNumber",
          "currency",
          "balance"
        ],
        "type": "object"
      },
      "type": "array"
    }
  },
  "required": [
    "items"
  ],
  "type": "object"
}
```

</details>
