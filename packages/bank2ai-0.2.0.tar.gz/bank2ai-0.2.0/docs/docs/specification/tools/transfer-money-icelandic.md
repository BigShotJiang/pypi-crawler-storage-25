---
title: transfer-money-icelandic
description: "Prepare a domestic money transfer. Validates recipient and prepares transfer details for confirmation."
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `transfer-money-icelandic`

Prepare a domestic money transfer. Validates recipient and prepares transfer details for confirmation.

## Input

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `amount` | `number` | ✓ | Transfer amount in the source account's currency. |
| `currency` | `string` |  | ISO 4217 currency code; if empty, source-account currency is used. Default: `""`. Examples: `"ISK"`, `"EUR"`, `"USD"`. Pattern: `^[A-Z]{3}$|^$`. |
| `description` | `string` |  | Free-text note shown on the recipient's statement. Default: `""`. |
| `recipient_account_number` | `string` | ✓ | Destination bank account number. Examples: `"5678-90-123456"`. |
| `recipient_ssn` | `string` | ✓ | Recipient's Icelandic kennitala. Examples: `"010190-1234"`. |
| `withdrawal_account_number` | `string` |  | Source account number; if empty, the user's default withdrawal account is used. Default: `""`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "additionalProperties": false,
  "properties": {
    "amount": {
      "description": "Transfer amount in the source account's currency.",
      "exclusiveMinimum": 0,
      "type": "number"
    },
    "currency": {
      "default": "",
      "description": "ISO 4217 currency code; if empty, source-account currency is used.",
      "examples": [
        "ISK",
        "EUR",
        "USD"
      ],
      "pattern": "^[A-Z]{3}$|^$",
      "type": "string"
    },
    "description": {
      "default": "",
      "description": "Free-text note shown on the recipient's statement.",
      "type": "string"
    },
    "recipient_account_number": {
      "description": "Destination bank account number.",
      "examples": [
        "5678-90-123456"
      ],
      "type": "string"
    },
    "recipient_ssn": {
      "description": "Recipient's Icelandic kennitala.",
      "examples": [
        "010190-1234"
      ],
      "type": "string"
    },
    "withdrawal_account_number": {
      "default": "",
      "description": "Source account number; if empty, the user's default withdrawal account is used.",
      "type": "string"
    }
  },
  "required": [
    "amount",
    "recipient_ssn",
    "recipient_account_number"
  ],
  "type": "object"
}
```

</details>

## Output

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `actions` | array&lt;`object`&gt; |  | Optional follow-up actions the client may surface. |
| `content` | `string` | ✓ | Human-readable status message |
| `item` | `object` \| `null` |  | Prepared transfer details when validation succeeded. Default: `null`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Prepared transfer details awaiting confirmation",
  "properties": {
    "actions": {
      "description": "Optional follow-up actions the client may surface.",
      "items": {
        "description": "Suggested follow-up action for a prepared transfer.",
        "properties": {
          "link": {
            "description": "Target URL or in-app link to perform the action.",
            "type": "string"
          },
          "title": {
            "description": "Human-readable label for the action.",
            "type": "string"
          }
        },
        "required": [
          "title",
          "link"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "content": {
      "description": "Human-readable status message",
      "type": "string"
    },
    "item": {
      "anyOf": [
        {
          "description": "Validated transfer details awaiting user confirmation.",
          "properties": {
            "amount": {
              "description": "Transfer amount in `currency`.",
              "exclusiveMinimum": 0,
              "type": "number"
            },
            "currency": {
              "description": "ISO 4217 currency code.",
              "examples": [
                "ISK",
                "EUR",
                "USD"
              ],
              "pattern": "^[A-Z]{3}$",
              "type": "string"
            },
            "description": {
              "description": "Free-text note shown on the recipient's statement.",
              "type": "string"
            },
            "recipient_account_number": {
              "description": "Destination bank account number.",
              "type": "string"
            },
            "recipient_name": {
              "description": "Recipient's full name or business name.",
              "type": "string"
            },
            "recipient_ssn": {
              "description": "Recipient's national ID / SSN.",
              "type": "string"
            },
            "withdrawal_account": {
              "description": "Resolved source account snapshot used for the transfer.",
              "properties": {
                "accountNumber": {
                  "description": "Formatted account number (format varies by country)",
                  "examples": [
                    "1234-56-789012",
                    "GB29NWBK60161331926819"
                  ],
                  "type": "string"
                },
                "accountType": {
                  "anyOf": [
                    {
                      "description": "Type of bank account.",
                      "enum": [
                        "Current",
                        "Credit",
                        "Savings"
                      ],
                      "type": "string"
                    },
                    {
                      "type": "null"
                    }
                  ],
                  "default": null,
                  "description": "Type of account"
                },
                "availableBalance": {
                  "anyOf": [
                    {
                      "type": "number"
                    },
                    {
                      "type": "null"
                    }
                  ],
                  "default": null,
                  "description": "Available balance (after pending transactions)"
                },
                "balance": {
                  "description": "Current account balance",
                  "type": "number"
                },
                "currency": {
                  "description": "ISO 4217 currency code",
                  "examples": [
                    "USD",
                    "EUR",
                    "ISK",
                    "GBP"
                  ],
                  "pattern": "^[A-Z]{3}$",
                  "type": "string"
                },
                "id": {
                  "description": "Unique account identifier",
                  "type": "string"
                },
                "isDefaultAccount": {
                  "anyOf": [
                    {
                      "type": "boolean"
                    },
                    {
                      "type": "null"
                    }
                  ],
                  "default": null,
                  "description": "Whether this is the user's default account"
                },
                "isWithdrawalAccount": {
                  "anyOf": [
                    {
                      "type": "boolean"
                    },
                    {
                      "type": "null"
                    }
                  ],
                  "default": null,
                  "description": "Whether this account can be used for withdrawals/transfers"
                },
                "name": {
                  "anyOf": [
                    {
                      "type": "string"
                    },
                    {
                      "type": "null"
                    }
                  ],
                  "default": null,
                  "description": "Human-readable account name",
                  "examples": [
                    "Main Checking",
                    "Savings Account",
                    "Credit Card"
                  ]
                },
                "overdraftLimit": {
                  "anyOf": [
                    {
                      "minimum": 0,
                      "type": "number"
                    },
                    {
                      "type": "null"
                    }
                  ],
                  "default": null,
                  "description": "Overdraft/credit limit (0 if none)"
                }
              },
              "required": [
                "id",
                "accountNumber",
                "currency",
                "balance"
              ],
              "type": "object"
            },
            "withdrawal_account_id": {
              "description": "Source account.id (from get-accounts).",
              "type": "string"
            }
          },
          "required": [
            "amount",
            "description",
            "currency",
            "recipient_account_number",
            "recipient_ssn",
            "recipient_name",
            "withdrawal_account_id",
            "withdrawal_account"
          ],
          "type": "object"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Prepared transfer details when validation succeeded."
    }
  },
  "required": [
    "content"
  ],
  "type": "object"
}
```

</details>
