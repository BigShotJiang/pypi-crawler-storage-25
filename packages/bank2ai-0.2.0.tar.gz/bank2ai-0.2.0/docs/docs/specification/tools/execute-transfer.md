---
title: execute-transfer
description: "Execute a money transfer after the user has confirmed the details. Use transfer-money-icelandic first to prepare and validate."
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `execute-transfer`

Execute a money transfer after the user has confirmed the details. Use transfer-money-icelandic first to prepare and validate.

## Input

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `amount` | `number` | ✓ | Transfer amount. |
| `description` | `string` |  | Free-text note shown on the recipient's statement. Default: `"Transfer"`. |
| `recipient_account_number` | `string` | ✓ | Destination bank account number. |
| `withdrawal_account_id` | `string` | ✓ | Source account.id (from get-accounts). |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "additionalProperties": false,
  "properties": {
    "amount": {
      "description": "Transfer amount.",
      "exclusiveMinimum": 0,
      "type": "number"
    },
    "description": {
      "default": "Transfer",
      "description": "Free-text note shown on the recipient's statement.",
      "type": "string"
    },
    "recipient_account_number": {
      "description": "Destination bank account number.",
      "type": "string"
    },
    "withdrawal_account_id": {
      "description": "Source account.id (from get-accounts).",
      "type": "string"
    }
  },
  "required": [
    "withdrawal_account_id",
    "recipient_account_number",
    "amount"
  ],
  "type": "object"
}
```

</details>

## Output

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `content` | `string` | ✓ | Human-readable status message |
| `item` | `object` \| `null` |  | Receipt details when the transfer was accepted by the bank. Default: `null`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Result of executing a transfer",
  "properties": {
    "content": {
      "description": "Human-readable status message",
      "type": "string"
    },
    "item": {
      "anyOf": [
        {
          "description": "Bank-issued receipt for an executed transfer.",
          "properties": {
            "status": {
              "description": "Execution status reported by the bank.",
              "examples": [
                "Completed",
                "Pending",
                "Rejected"
              ],
              "type": "string"
            },
            "timestamp": {
              "description": "ISO 8601 timestamp when the bank recorded the transfer.",
              "type": "string"
            },
            "transfer_id": {
              "description": "Bank-issued transfer identifier.",
              "type": "string"
            }
          },
          "required": [
            "transfer_id",
            "status",
            "timestamp"
          ],
          "type": "object"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Receipt details when the transfer was accepted by the bank."
    }
  },
  "required": [
    "content"
  ],
  "type": "object"
}
```

</details>
