---
title: Tool surface
sidebar_position: 1
description: The eight MCP tools every Bank2AI server registers.
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# Tool surface

Every compliant Bank2AI server registers the following MCP tools. Names, input schemas, and output schemas are fixed by the spec; servers MAY add vendor-specific tools but MUST NOT alter these.

| Tool | Purpose |
| --- | --- |
| [`create-recipient`](./create-recipient) | Create a new payment recipient with their name, account number, and national ID. The recipient can then be used for transfers. |
| [`execute-transfer`](./execute-transfer) | Execute a money transfer after the user has confirmed the details. Use transfer-money-icelandic first to prepare and validate. |
| [`get-accounts`](./get-accounts) | Get bank accounts and cards. Returns a list of accounts with balances, account numbers, and types. |
| [`get-categories`](./get-categories) | Get transaction categories. Returns a list of categories that transactions can be classified into. |
| [`recipients-by-name`](./recipients-by-name) | Lookup recipient of a payment or transfer by name. Returns matching recipients with their account details. |
| [`spending-summary`](./spending-summary) | Get an aggregated spending summary. Returns totals, counts, and averages grouped by category, category group, month, or merchant. |
| [`transactions`](./transactions) | Get bank transactions. Returns a list of transactions with amounts, dates, descriptions, and categories. |
| [`transfer-money-icelandic`](./transfer-money-icelandic) | Prepare a domestic money transfer. Validates recipient and prepares transfer details for confirmation. |
