---
title: get-categories
description: "Get transaction categories. Returns a list of categories that transactions can be classified into."
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `get-categories`

Get transaction categories. Returns a list of categories that transactions can be classified into.

## Input

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "additionalProperties": false,
  "properties": {},
  "type": "object"
}
```

</details>

## Output

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `items` | array&lt;`object`&gt; | ✓ | Available transaction categories. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Envelope for a list of categories",
  "properties": {
    "items": {
      "description": "Available transaction categories.",
      "items": {
        "description": "Transaction category for spending classification",
        "properties": {
          "id": {
            "description": "Unique category identifier",
            "type": "string"
          },
          "name": {
            "description": "Category name (localized)",
            "examples": [
              "Groceries",
              "Transportation",
              "Entertainment",
              "Utilities"
            ],
            "type": "string"
          }
        },
        "required": [
          "id",
          "name"
        ],
        "type": "object"
      },
      "type": "array"
    }
  },
  "required": [
    "items"
  ],
  "type": "object"
}
```

</details>
