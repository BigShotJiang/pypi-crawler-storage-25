---
title: transactions
description: "Get bank transactions. Returns a list of transactions with amounts, dates, descriptions, and categories."
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `transactions`

Get bank transactions. Returns a list of transactions with amounts, dates, descriptions, and categories.

## Input

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `account_id` | `string` \| `null` |  | Restrict to transactions on this account.id (from get-accounts). Default: `null`. |
| `categories` | array&lt;`string`&gt; \| `null` |  | Restrict to these category names (the `name` field from get-categories, not the id). Default: `null`. |
| `count` | `integer` \| `null` |  | Maximum number of transactions to return. Default: `null`. |
| `description` | `string` \| `null` |  | Free-text search across merchant/recipient/reference/description. Default: `null`. |
| `end_date` | `string` \| `null` |  | Inclusive upper bound, ISO 8601 (YYYY-MM-DD). Default: `null`. Examples: `"2024-03-15"`. |
| `order` | `"NewestFirst"` \| `"OldestFirst"` |  | Sort order. Default: `"NewestFirst"`. |
| `start_date` | `string` \| `null` |  | Inclusive lower bound, ISO 8601 (YYYY-MM-DD). Default: `null`. Examples: `"2024-03-15"`. |
| `type` | `"Any"` \| `"Income"` \| `"Expenses"` \| `"Savings"` |  | Filter by direction. Default: `"Any"`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "additionalProperties": false,
  "properties": {
    "account_id": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Restrict to transactions on this account.id (from get-accounts)."
    },
    "categories": {
      "anyOf": [
        {
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Restrict to these category names (the `name` field from get-categories, not the id)."
    },
    "count": {
      "anyOf": [
        {
          "minimum": 1,
          "type": "integer"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Maximum number of transactions to return."
    },
    "description": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Free-text search across merchant/recipient/reference/description."
    },
    "end_date": {
      "anyOf": [
        {
          "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Inclusive upper bound, ISO 8601 (YYYY-MM-DD).",
      "examples": [
        "2024-03-15"
      ]
    },
    "order": {
      "default": "NewestFirst",
      "description": "Sort order.",
      "enum": [
        "NewestFirst",
        "OldestFirst"
      ],
      "type": "string"
    },
    "start_date": {
      "anyOf": [
        {
          "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Inclusive lower bound, ISO 8601 (YYYY-MM-DD).",
      "examples": [
        "2024-03-15"
      ]
    },
    "type": {
      "default": "Any",
      "description": "Filter by direction.",
      "enum": [
        "Any",
        "Income",
        "Expenses",
        "Savings"
      ],
      "type": "string"
    }
  },
  "type": "object"
}
```

</details>

## Output

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `items` | array&lt;`object`&gt; | ✓ | Transactions matching the request. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Envelope for a list of transactions",
  "properties": {
    "items": {
      "description": "Transactions matching the request.",
      "items": {
        "description": "Financial transaction with date, amount and metadata",
        "properties": {
          "amount": {
            "description": "Transaction amount (negative for expenses, positive for income)",
            "type": "number"
          },
          "category": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Category name"
          },
          "description": {
            "description": "Transaction description, merchant name or recipient name",
            "type": "string"
          },
          "id": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Unique transaction identifier"
          },
          "transaction_date": {
            "description": "Transaction date in ISO 8601 format (YYYY-MM-DD)",
            "format": "date",
            "type": "string"
          }
        },
        "required": [
          "description",
          "amount",
          "transaction_date"
        ],
        "type": "object"
      },
      "type": "array"
    }
  },
  "required": [
    "items"
  ],
  "type": "object"
}
```

</details>
