---
title: create-recipient
description: "Create a new payment recipient with their name, account number, and national ID. The recipient can then be used for transfers."
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `create-recipient`

Create a new payment recipient with their name, account number, and national ID. The recipient can then be used for transfers.

## Input

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `account_number` | `string` | ✓ | Recipient's bank account number (format varies by country). Examples: `"5678-90-123456"`. |
| `kennitala` | `string` |  | Icelandic national ID for the recipient, if known. Default: `""`. Examples: `"010190-1234"`. |
| `name` | `string` | ✓ | Recipient's full name or business name. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "additionalProperties": false,
  "properties": {
    "account_number": {
      "description": "Recipient's bank account number (format varies by country).",
      "examples": [
        "5678-90-123456"
      ],
      "type": "string"
    },
    "kennitala": {
      "default": "",
      "description": "Icelandic national ID for the recipient, if known.",
      "examples": [
        "010190-1234"
      ],
      "type": "string"
    },
    "name": {
      "description": "Recipient's full name or business name.",
      "type": "string"
    }
  },
  "required": [
    "name",
    "account_number"
  ],
  "type": "object"
}
```

</details>

## Output

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `content` | `string` | ✓ | Human-readable status message |
| `item` | `object` \| `null` |  | The created recipient when creation succeeded. Default: `null`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Result of creating a payment recipient",
  "properties": {
    "content": {
      "description": "Human-readable status message",
      "type": "string"
    },
    "item": {
      "anyOf": [
        {
          "description": "Payment recipient with account details",
          "properties": {
            "accountNumber": {
              "description": "Recipient's bank account number",
              "examples": [
                "5678-90-123456",
                "GB29NWBK60161331926819"
              ],
              "type": "string"
            },
            "accountNumberType": {
              "anyOf": [
                {
                  "type": "string"
                },
                {
                  "type": "null"
                }
              ],
              "default": null,
              "description": "Type of account number",
              "examples": [
                "Domestic",
                "IBAN",
                "SWIFT"
              ]
            },
            "address": {
              "anyOf": [
                {
                  "type": "string"
                },
                {
                  "type": "null"
                }
              ],
              "default": null,
              "description": "Recipient's address (if available)"
            },
            "bankInfo": {
              "anyOf": [
                {
                  "type": "string"
                },
                {
                  "type": "null"
                }
              ],
              "default": null,
              "description": "Bank name or identifier",
              "examples": [
                "Example Bank",
                "Bank of America"
              ]
            },
            "description": {
              "anyOf": [
                {
                  "type": "string"
                },
                {
                  "type": "null"
                }
              ],
              "default": null,
              "description": "User-provided description or note",
              "examples": [
                "Friend",
                "Landlord",
                "Contractor"
              ]
            },
            "id": {
              "anyOf": [
                {
                  "type": "string"
                },
                {
                  "type": "null"
                }
              ],
              "default": null,
              "description": "Unique recipient identifier"
            },
            "isFavorite": {
              "default": false,
              "description": "Whether this recipient is marked as favorite",
              "type": "boolean"
            },
            "name": {
              "description": "Recipient's full name or business name",
              "type": "string"
            },
            "paymentType": {
              "anyOf": [
                {
                  "type": "string"
                },
                {
                  "type": "null"
                }
              ],
              "default": null,
              "description": "Type of payment supported",
              "examples": [
                "Domestic",
                "International",
                "SEPA"
              ]
            },
            "socialSecurityNumber": {
              "description": "National ID / SSN (format varies by country)",
              "examples": [
                "010190-1234",
                "123-45-6789"
              ],
              "type": "string"
            }
          },
          "required": [
            "name",
            "socialSecurityNumber",
            "accountNumber"
          ],
          "type": "object"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "The created recipient when creation succeeded."
    }
  },
  "required": [
    "content"
  ],
  "type": "object"
}
```

</details>
