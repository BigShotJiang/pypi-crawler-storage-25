---
title: spending-summary
description: "Get an aggregated spending summary. Returns totals, counts, and averages grouped by category, category group, month, or merchant."
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `spending-summary`

Get an aggregated spending summary. Returns totals, counts, and averages grouped by category, category group, month, or merchant.

## Input

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `categories` | array&lt;`string`&gt; \| `null` |  | Restrict to these category names (the `name` field from get-categories, not the id). Default: `null`. |
| `end_date` | `string` \| `null` |  | Inclusive upper bound, ISO 8601 (YYYY-MM-DD). Default: `null`. Examples: `"2024-03-15"`. |
| `group_by` | `"category"` \| `"group"` \| `"month"` \| `"merchant"` |  | Aggregation key. Default: `"category"`. |
| `start_date` | `string` \| `null` |  | Inclusive lower bound, ISO 8601 (YYYY-MM-DD). Default: `null`. Examples: `"2024-03-15"`. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "additionalProperties": false,
  "properties": {
    "categories": {
      "anyOf": [
        {
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Restrict to these category names (the `name` field from get-categories, not the id)."
    },
    "end_date": {
      "anyOf": [
        {
          "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Inclusive upper bound, ISO 8601 (YYYY-MM-DD).",
      "examples": [
        "2024-03-15"
      ]
    },
    "group_by": {
      "default": "category",
      "description": "Aggregation key.",
      "enum": [
        "category",
        "group",
        "month",
        "merchant"
      ],
      "type": "string"
    },
    "start_date": {
      "anyOf": [
        {
          "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Inclusive lower bound, ISO 8601 (YYYY-MM-DD).",
      "examples": [
        "2024-03-15"
      ]
    }
  },
  "type": "object"
}
```

</details>

## Output

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `period` | `object` | ✓ | Date range covered by the aggregation. |
| `summary` | array&lt;`object`&gt; | ✓ | One entry per aggregation key value. |
| `total` | `number` | ✓ | Sum across all groups in the summary. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Aggregated spending summary",
  "properties": {
    "period": {
      "description": "Date range covered by the aggregation.",
      "properties": {
        "end_date": {
          "description": "Inclusive upper bound, ISO 8601 (YYYY-MM-DD).",
          "examples": [
            "2024-03-31"
          ],
          "type": "string"
        },
        "start_date": {
          "description": "Inclusive lower bound, ISO 8601 (YYYY-MM-DD).",
          "examples": [
            "2024-03-01"
          ],
          "type": "string"
        }
      },
      "required": [
        "start_date",
        "end_date"
      ],
      "type": "object"
    },
    "summary": {
      "description": "One entry per aggregation key value.",
      "items": {
        "description": "One row of an aggregated spending summary.",
        "properties": {
          "average_amount": {
            "description": "Mean transaction amount within this group.",
            "type": "number"
          },
          "group": {
            "description": "Aggregation key value (category name, group, month, or merchant).",
            "type": "string"
          },
          "total_amount": {
            "description": "Sum of transaction amounts in this group.",
            "type": "number"
          },
          "transaction_count": {
            "description": "Number of transactions contributing to this group.",
            "minimum": 0,
            "type": "integer"
          }
        },
        "required": [
          "group",
          "total_amount",
          "transaction_count",
          "average_amount"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "total": {
      "description": "Sum across all groups in the summary.",
      "type": "number"
    }
  },
  "required": [
    "summary",
    "period",
    "total"
  ],
  "type": "object"
}
```

</details>
