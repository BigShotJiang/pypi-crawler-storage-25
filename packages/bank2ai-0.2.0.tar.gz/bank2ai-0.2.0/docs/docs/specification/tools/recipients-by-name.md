---
title: recipients-by-name
description: "Lookup recipient of a payment or transfer by name. Returns matching recipients with their account details."
---

{/* This file is generated from specs/bank2ai.json by docs/scripts/sync-spec.mjs. Do not edit by hand. */}

# `recipients-by-name`

Lookup recipient of a payment or transfer by name. Returns matching recipients with their account details.

## Input

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `name` | `string` | ✓ | Free-text search; matches partial names of saved recipients. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "additionalProperties": false,
  "properties": {
    "name": {
      "description": "Free-text search; matches partial names of saved recipients.",
      "type": "string"
    }
  },
  "required": [
    "name"
  ],
  "type": "object"
}
```

</details>

## Output

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `items` | array&lt;`object`&gt; | ✓ | Recipients matching the request. |

<details>
<summary>Raw JSON Schema</summary>

```json
{
  "description": "Envelope for a list of recipients",
  "properties": {
    "items": {
      "description": "Recipients matching the request.",
      "items": {
        "description": "Payment recipient with account details",
        "properties": {
          "accountNumber": {
            "description": "Recipient's bank account number",
            "examples": [
              "5678-90-123456",
              "GB29NWBK60161331926819"
            ],
            "type": "string"
          },
          "accountNumberType": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Type of account number",
            "examples": [
              "Domestic",
              "IBAN",
              "SWIFT"
            ]
          },
          "address": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Recipient's address (if available)"
          },
          "bankInfo": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Bank name or identifier",
            "examples": [
              "Example Bank",
              "Bank of America"
            ]
          },
          "description": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "User-provided description or note",
            "examples": [
              "Friend",
              "Landlord",
              "Contractor"
            ]
          },
          "id": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Unique recipient identifier"
          },
          "isFavorite": {
            "default": false,
            "description": "Whether this recipient is marked as favorite",
            "type": "boolean"
          },
          "name": {
            "description": "Recipient's full name or business name",
            "type": "string"
          },
          "paymentType": {
            "anyOf": [
              {
                "type": "string"
              },
              {
                "type": "null"
              }
            ],
            "default": null,
            "description": "Type of payment supported",
            "examples": [
              "Domestic",
              "International",
              "SEPA"
            ]
          },
          "socialSecurityNumber": {
            "description": "National ID / SSN (format varies by country)",
            "examples": [
              "010190-1234",
              "123-45-6789"
            ],
            "type": "string"
          }
        },
        "required": [
          "name",
          "socialSecurityNumber",
          "accountNumber"
        ],
        "type": "object"
      },
      "type": "array"
    }
  },
  "required": [
    "items"
  ],
  "type": "object"
}
```

</details>
