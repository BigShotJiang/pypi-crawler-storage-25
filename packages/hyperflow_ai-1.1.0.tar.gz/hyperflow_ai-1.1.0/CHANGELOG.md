# Changelog

All notable changes to this project will be documented in this file.

## [1.1.0] - 2026-04-09
### Added
- **Syntax Guard**: The Editor tool now automatically detects Python syntax errors, reverts broken edits, and provides corrective feedback to the MetaAgent.
- Dedicated documentation site at [hyperflow.lablnet.com](https://hyperflow.lablnet.com/).
- New comprehensive documentation on Limitations, Citations, and Advanced Concepts.

### Changed
- Aligned terminology with **HyperAgents** research (Metacognitive Self-Modification, Self-Referential Agents).
- Improved MetaAgent prompt logic for tool repair stability.

## [1.0.0] - 2026-04-09
### Added
- Initial release of HyperFlow (Python).
- Support for evolutionary self-improvement loop.
- Support for OpenAI, Anthropic, Google Gemini, and Ollama.
- Local and Docker execution modes.
- Static, LLM judge, and human feedback evaluators.
