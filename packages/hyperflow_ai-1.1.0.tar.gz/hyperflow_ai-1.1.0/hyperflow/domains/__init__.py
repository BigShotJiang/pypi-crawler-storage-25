"""Domain interfaces and evaluation helpers for HyperFlow."""
