"""Prompt templates for HyperFlow agents."""
