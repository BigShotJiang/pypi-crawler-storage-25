"""datagrowth-common — utilidades compartidas entre apps Datagrowth.

v0.3.1 (mayo 2026):
- Nuevo subpaquete `datagrowth_common.ui`: Jinja2 partials (`dg/...`),
  tokens CSS con tema light/dark, Tailwind precompilado y JS de theme/
  toasts/htmx-events. Helper `register_ui(app, jinja_env, mount_path)`
  para inyectar todo en una FastAPI host app.

v0.3.0 (mayo 2026, BREAKING):
- Eliminados `datagrowth_common.authentik` y `datagrowth_common.auth_fastapi`
  (forward-auth basado en Authentik). Importarlos lanza `ImportError`.
- `datagrowth_common.auth.local` renombrado a `datagrowth_common.auth.session_hmac`.
  Se eliminó toda la integración con Authentik OIDC (password_login, refresh,
  userinfo, start_oidc, oidc_callback, register_local, magic_link_request,
  password_reset, TokenPair, OidcStart). Solo se conserva la cookie HMAC.
  `auth.local` queda como alias deprecated (DeprecationWarning); eliminado en v0.4.0.
- Modelo único de auth: Supabase Auth (cookie JWT en `auth.session` +
  endpoints en `auth.router` + verify en `auth.supabase`).

v0.2.2 (anterior):
- `auth.supabase_admin` añadidos `create_user_with_password` y
  `send_password_reset` para flujos de gestión de usuarios end-to-end.

Ver CHANGELOG.md para la guía de migración completa.
"""
from .auth.supabase import (
    SupabaseUser,
    SupabaseUserDep,
    require_role,
    require_supabase_jwt,
    verify_supabase_jwt,
)
from .auth.session import (
    ACCESS_COOKIE,
    REFRESH_COOKIE,
    SessionTokens,
    SessionUserDep,
    clear_session,
    get_session_tokens,
    refresh_session_tokens,
    require_session,
    set_session,
)
from .auth.router import auth_router, make_auth_router
from .api.users import users_router
from .result import Result, ok, err
from .logger import get_logger, setup_logging
from .ui import UI_VERSION, register_ui

__version__ = "0.6.2"

__all__ = [
    # supabase auth (JWT)
    "SupabaseUser",
    "SupabaseUserDep",
    "require_role",
    "require_supabase_jwt",
    "verify_supabase_jwt",
    "users_router",
    # session (cookie httpOnly server-rendered)
    "ACCESS_COOKIE",
    "REFRESH_COOKIE",
    "SessionTokens",
    "SessionUserDep",
    "set_session",
    "clear_session",
    "get_session_tokens",
    "refresh_session_tokens",
    "require_session",
    # auth router (login + OAuth + refresh + logout)
    "auth_router",
    "make_auth_router",
    # core
    "Result",
    "ok",
    "err",
    "get_logger",
    "setup_logging",
    # ui (datagrowth_common.ui)
    "register_ui",
    "UI_VERSION",
    "__version__",
]
