from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_prospect_exclusion_lists_body import GetProspectExclusionListsBody
from ...models.get_prospect_exclusion_lists_response_200 import GetProspectExclusionListsResponse200
from ...models.get_prospect_exclusion_lists_response_400 import GetProspectExclusionListsResponse400
from ...models.get_prospect_exclusion_lists_response_401 import GetProspectExclusionListsResponse401
from ...models.get_prospect_exclusion_lists_response_402 import GetProspectExclusionListsResponse402
from ...models.get_prospect_exclusion_lists_response_403 import GetProspectExclusionListsResponse403
from ...models.get_prospect_exclusion_lists_response_404 import GetProspectExclusionListsResponse404
from ...models.get_prospect_exclusion_lists_response_429 import GetProspectExclusionListsResponse429
from ...models.get_prospect_exclusion_lists_response_500 import GetProspectExclusionListsResponse500
from ...models.get_prospect_exclusion_lists_response_503 import GetProspectExclusionListsResponse503
from ...types import Response


def _get_kwargs(
    *,
    body: GetProspectExclusionListsBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/exclusions/prospects/get-lists",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    GetProspectExclusionListsResponse200
    | GetProspectExclusionListsResponse400
    | GetProspectExclusionListsResponse401
    | GetProspectExclusionListsResponse402
    | GetProspectExclusionListsResponse403
    | GetProspectExclusionListsResponse404
    | GetProspectExclusionListsResponse429
    | GetProspectExclusionListsResponse500
    | GetProspectExclusionListsResponse503
    | None
):
    if response.status_code == 200:
        response_200 = GetProspectExclusionListsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = GetProspectExclusionListsResponse400.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = GetProspectExclusionListsResponse401.from_dict(response.json())

        return response_401

    if response.status_code == 402:
        response_402 = GetProspectExclusionListsResponse402.from_dict(response.json())

        return response_402

    if response.status_code == 403:
        response_403 = GetProspectExclusionListsResponse403.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = GetProspectExclusionListsResponse404.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = GetProspectExclusionListsResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = GetProspectExclusionListsResponse500.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = GetProspectExclusionListsResponse503.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    GetProspectExclusionListsResponse200
    | GetProspectExclusionListsResponse400
    | GetProspectExclusionListsResponse401
    | GetProspectExclusionListsResponse402
    | GetProspectExclusionListsResponse403
    | GetProspectExclusionListsResponse404
    | GetProspectExclusionListsResponse429
    | GetProspectExclusionListsResponse500
    | GetProspectExclusionListsResponse503
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: GetProspectExclusionListsBody,
) -> Response[
    GetProspectExclusionListsResponse200
    | GetProspectExclusionListsResponse400
    | GetProspectExclusionListsResponse401
    | GetProspectExclusionListsResponse402
    | GetProspectExclusionListsResponse403
    | GetProspectExclusionListsResponse404
    | GetProspectExclusionListsResponse429
    | GetProspectExclusionListsResponse500
    | GetProspectExclusionListsResponse503
]:
    r"""Get prospect exclusion lists

     Get prospect exclusion lists

    <span>⚡ <strong>Rate limit:</strong> 50 requests per 1 minute</span>

    <span>💰 <strong>Cost:</strong> FREE! No credits are charged for this API.&nbsp;<span title=\"Pricing
    shown is default pricing. Actual pricing may vary.\">ⓘ</span></span>

    Args:
        body (GetProspectExclusionListsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetProspectExclusionListsResponse200 | GetProspectExclusionListsResponse400 | GetProspectExclusionListsResponse401 | GetProspectExclusionListsResponse402 | GetProspectExclusionListsResponse403 | GetProspectExclusionListsResponse404 | GetProspectExclusionListsResponse429 | GetProspectExclusionListsResponse500 | GetProspectExclusionListsResponse503]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: GetProspectExclusionListsBody,
) -> (
    GetProspectExclusionListsResponse200
    | GetProspectExclusionListsResponse400
    | GetProspectExclusionListsResponse401
    | GetProspectExclusionListsResponse402
    | GetProspectExclusionListsResponse403
    | GetProspectExclusionListsResponse404
    | GetProspectExclusionListsResponse429
    | GetProspectExclusionListsResponse500
    | GetProspectExclusionListsResponse503
    | None
):
    r"""Get prospect exclusion lists

     Get prospect exclusion lists

    <span>⚡ <strong>Rate limit:</strong> 50 requests per 1 minute</span>

    <span>💰 <strong>Cost:</strong> FREE! No credits are charged for this API.&nbsp;<span title=\"Pricing
    shown is default pricing. Actual pricing may vary.\">ⓘ</span></span>

    Args:
        body (GetProspectExclusionListsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetProspectExclusionListsResponse200 | GetProspectExclusionListsResponse400 | GetProspectExclusionListsResponse401 | GetProspectExclusionListsResponse402 | GetProspectExclusionListsResponse403 | GetProspectExclusionListsResponse404 | GetProspectExclusionListsResponse429 | GetProspectExclusionListsResponse500 | GetProspectExclusionListsResponse503
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: GetProspectExclusionListsBody,
) -> Response[
    GetProspectExclusionListsResponse200
    | GetProspectExclusionListsResponse400
    | GetProspectExclusionListsResponse401
    | GetProspectExclusionListsResponse402
    | GetProspectExclusionListsResponse403
    | GetProspectExclusionListsResponse404
    | GetProspectExclusionListsResponse429
    | GetProspectExclusionListsResponse500
    | GetProspectExclusionListsResponse503
]:
    r"""Get prospect exclusion lists

     Get prospect exclusion lists

    <span>⚡ <strong>Rate limit:</strong> 50 requests per 1 minute</span>

    <span>💰 <strong>Cost:</strong> FREE! No credits are charged for this API.&nbsp;<span title=\"Pricing
    shown is default pricing. Actual pricing may vary.\">ⓘ</span></span>

    Args:
        body (GetProspectExclusionListsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetProspectExclusionListsResponse200 | GetProspectExclusionListsResponse400 | GetProspectExclusionListsResponse401 | GetProspectExclusionListsResponse402 | GetProspectExclusionListsResponse403 | GetProspectExclusionListsResponse404 | GetProspectExclusionListsResponse429 | GetProspectExclusionListsResponse500 | GetProspectExclusionListsResponse503]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: GetProspectExclusionListsBody,
) -> (
    GetProspectExclusionListsResponse200
    | GetProspectExclusionListsResponse400
    | GetProspectExclusionListsResponse401
    | GetProspectExclusionListsResponse402
    | GetProspectExclusionListsResponse403
    | GetProspectExclusionListsResponse404
    | GetProspectExclusionListsResponse429
    | GetProspectExclusionListsResponse500
    | GetProspectExclusionListsResponse503
    | None
):
    r"""Get prospect exclusion lists

     Get prospect exclusion lists

    <span>⚡ <strong>Rate limit:</strong> 50 requests per 1 minute</span>

    <span>💰 <strong>Cost:</strong> FREE! No credits are charged for this API.&nbsp;<span title=\"Pricing
    shown is default pricing. Actual pricing may vary.\">ⓘ</span></span>

    Args:
        body (GetProspectExclusionListsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetProspectExclusionListsResponse200 | GetProspectExclusionListsResponse400 | GetProspectExclusionListsResponse401 | GetProspectExclusionListsResponse402 | GetProspectExclusionListsResponse403 | GetProspectExclusionListsResponse404 | GetProspectExclusionListsResponse429 | GetProspectExclusionListsResponse500 | GetProspectExclusionListsResponse503
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
