from pathlib import Path

import cv2
import numpy as np

from lsdataset.io.video_utils import StreamingVideoEncoder


def test_streaming_video_encoder():
    encoder = StreamingVideoEncoder(fps=10)

    encoder.start_episode(video_keys=["cam_high", "cam_right", "cam_left"], temp_dir="temp_videos")

    for i in range(100):
        img_high = np.zeros((480, 640, 3), dtype=np.uint8)
        img_right = np.zeros((480, 640, 3), dtype=np.uint8)
        img_left = np.zeros((480, 640, 3), dtype=np.uint8)

        cv2.circle(
            img_high,
            (320 + int(100 * np.sin(i / 10)), 240 + int(100 * np.cos(i / 10))),
            50,
            (0, 255, 0),
            -1,
        )
        cv2.circle(
            img_right,
            (320 + int(100 * np.sin(i / 10 + np.pi)), 240 + int(100 * np.cos(i / 10 + np.pi))),
            50,
            (255, 0, 0),
            -1,
        )
        cv2.circle(
            img_left,
            (320 + int(100 * np.sin(i / 10 + 2 * np.pi)), 240 + int(100 * np.cos(i / 10 + 2 * np.pi))),
            50,
            (0, 0, 255),
            -1,
        )

        encoder.feed_frame(video_key="cam_high", image=img_high)
        encoder.feed_frame(video_key="cam_right", image=img_right)
        encoder.feed_frame(video_key="cam_left", image=img_left)

    res = encoder.finish_episode()
    assert "cam_high" in res
    assert Path(res["cam_high"][0]).exists()
