"""pytest 公共 fixture：隔离 cwd，保证 ``./data/lsrobot_datasets`` 与 ``./logs`` 落在临时目录。"""

from __future__ import annotations

import logging

import pytest


@pytest.fixture(autouse=True)
def _lsdataset_test_env(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "data" / "lsrobot_datasets").mkdir(parents=True, exist_ok=True)
    (tmp_path / "logs").mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, force=True)
    yield
