import time

import numpy as np
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from lsdataset.api.routes import router
from lsdataset.core.manager import add_frame, manager

features = {
    "timestamp": {"dtype": "float32", "shape": (1,), "names": None},
    "observation.images.cam_high": {"dtype": "video", "shape": (480, 640, 3), "names": ["height", "width", "channel"]},
    "observation.images.cam_right": {"dtype": "video", "shape": (480, 640, 3), "names": ["height", "width", "channel"]},
    "observation.images.cam_left": {"dtype": "video", "shape": (480, 640, 3), "names": ["height", "width", "channel"]},
    "observation.state.arm.left.end_effector_value": {
        "dtype": "float32",
        "shape": (1,),
        "names": [f"value_{i}" for i in range(1)],
    },
    "observation.state.arm.left.joint_positions": {"dtype": "float32", "shape": (6,), "names": [f"joint_{i}" for i in range(6)]},
    "observation.state.arm.left.end_effector_pose": {
        "dtype": "float32",
        "shape": (6,),
        "names": [f"pose_{i}" for i in range(6)],
    },
    "observation.state.arm.right.end_effector_value": {
        "dtype": "float32",
        "shape": (1,),
        "names": [f"value_{i}" for i in range(1)],
    },
    "observation.state.arm.right.joint_positions": {"dtype": "float32", "shape": (6,), "names": [f"joint_{i}" for i in range(6)]},
    "observation.state.arm.right.end_effector_pose": {
        "dtype": "float32",
        "shape": (6,),
        "names": [f"pose_{i}" for i in range(6)],
    },
}


def test_lsrobot_router():
    app = FastAPI()
    app.include_router(router)
    client = TestClient(app)

    response = client.post(
        "/lsdataset/internal/start_recording",
        json={"dataset_type": "lerobot_dataset", "repo_id": "test"},
    )
    assert response.status_code == 500

    config_data = {
        "fps": 10.0,
        "robot_type": "arm",
        "features": features,
        "root": "./data/lsrobot_datasets",
    }
    response = client.post("/lsdataset/internal/config", json=config_data)
    assert response.status_code == 200
    assert response.json() == {"ok": True, "message": "数据集配置已更新"}

    response = client.post(
        "/lsdataset/internal/start_recording",
        json={"dataset_type": "lerobot_dataset", "repo_id": "record_test"},
    )
    assert response.status_code == 200

    timestamp_f = 0.0
    top_img = np.zeros((480, 640, 3), dtype=np.uint8)
    right_img = np.zeros((480, 640, 3), dtype=np.uint8)
    left_img = np.zeros((480, 640, 3), dtype=np.uint8)
    arm_left_end_effector_value = np.array([0.0], dtype=np.float32)
    arm_left_joint_positions = np.zeros((6,), dtype=np.float32)
    arm_left_end_effector_pose = np.zeros((6,), dtype=np.float32)
    arm_right_end_effector_value = np.array([0.0], dtype=np.float32)
    arm_right_joint_positions = np.zeros((6,), dtype=np.float32)
    arm_right_end_effector_pose = np.zeros((6,), dtype=np.float32)

    for i in range(25):
        timestamp_f += 0.1
        top_img[:] = i * 10
        right_img[:] = i * 10
        left_img[:] = i * 10
        arm_left_end_effector_value[:] = i * 0.1
        arm_left_joint_positions[:] = i * 0.1
        arm_left_end_effector_pose[:] = i * 0.1
        arm_right_end_effector_value[:] = i * 0.1
        arm_right_joint_positions[:] = i * 0.1
        arm_right_end_effector_pose[:] = i * 0.1
        sample = {
            "observation.images.cam_high": top_img.copy(),
            "observation.images.cam_right": right_img.copy(),
            "observation.images.cam_left": left_img.copy(),
            "observation.state.arm.left.end_effector_value": arm_left_end_effector_value.copy(),
            "observation.state.arm.left.joint_positions": arm_left_joint_positions.copy(),
            "observation.state.arm.left.end_effector_pose": arm_left_end_effector_pose.copy(),
            "observation.state.arm.right.end_effector_value": arm_right_end_effector_value.copy(),
            "observation.state.arm.right.joint_positions": arm_right_joint_positions.copy(),
            "observation.state.arm.right.end_effector_pose": arm_right_end_effector_pose.copy(),
        }
        add_frame(sample, task="test_task")

    response = client.post("/lsdataset/internal/stop_recording", json={"abort": False})
    assert response.status_code == 200

    deadline = time.time() + 30.0
    while time.time() < deadline:
        try:
            manager.delete_dataset("lerobot_dataset", "record_test")
            break
        except RuntimeError as e:
            if "正在" in str(e) or "使用" in str(e):
                time.sleep(0.5)
            else:
                raise
    else:
        pytest.fail("timeout waiting to delete dataset")

    time.sleep(1)
