import logging

import numpy as np

from lsdataset.core.dataset import LsRobotDataset

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s", force=True)

features = {
    "timestamp": {"dtype": "float32", "shape": (1,), "names": None},
    "observation.images.cam_high": {"dtype": "video", "shape": (480, 640, 3), "names": ["height", "width", "channel"]},
    "observation.images.cam_right": {"dtype": "video", "shape": (480, 640, 3), "names": ["height", "width", "channel"]},
    "observation.images.cam_left": {"dtype": "video", "shape": (480, 640, 3), "names": ["height", "width", "channel"]},
    "observation.state.arm.left.end_effector_value": {
        "dtype": "float32",
        "shape": (1,),
        "names": [f"value_{i}" for i in range(1)],
    },
    "observation.state.arm.left.joint_positions": {"dtype": "float32", "shape": (6,), "names": [f"joint_{i}" for i in range(6)]},
    "observation.state.arm.left.end_effector_pose": {
        "dtype": "float32",
        "shape": (6,),
        "names": [f"pose_{i}" for i in range(6)],
    },
    "observation.state.arm.right.end_effector_value": {
        "dtype": "float32",
        "shape": (1,),
        "names": [f"value_{i}" for i in range(1)],
    },
    "observation.state.arm.right.joint_positions": {"dtype": "float32", "shape": (6,), "names": [f"joint_{i}" for i in range(6)]},
    "observation.state.arm.right.end_effector_pose": {
        "dtype": "float32",
        "shape": (6,),
        "names": [f"pose_{i}" for i in range(6)],
    },
}


def test_create_lsrobot_dataset():
    ds = LsRobotDataset.create(
        repo_id="my-lsrobot-dataset",
        root="./data/lsrobot_datasets",
        robot_type="arm",
        fps=10,
        features=features,
    )
    assert ds is not None
    logging.info("LsRobotDataset created successfully.")


def test_lsrobot_dataset_save_episode():
    ds = LsRobotDataset(repo_id="my-lsrobot-dataset", root="./data/lsrobot_datasets")

    for _j in range(10):
        timestamp = 0.0
        top_img = np.zeros((480, 640, 3), dtype=np.uint8)
        right_img = np.zeros((480, 640, 3), dtype=np.uint8)
        left_img = np.zeros((480, 640, 3), dtype=np.uint8)
        arm_left_end_effector_value = np.array([0.0], dtype=np.float32)
        arm_left_joint_positions = np.zeros((6,), dtype=np.float32)
        arm_left_end_effector_pose = np.zeros((6,), dtype=np.float32)
        arm_right_end_effector_value = np.array([0.0], dtype=np.float32)
        arm_right_joint_positions = np.zeros((6,), dtype=np.float32)
        arm_right_end_effector_pose = np.zeros((6,), dtype=np.float32)

        for i in range(10):
            timestamp += 0.1
            top_img[:] = i * 5
            right_img[:] = i * 5
            left_img[:] = i * 5
            arm_left_end_effector_value[:] = i * 0.1
            arm_left_joint_positions[:] = i * 0.1
            arm_left_end_effector_pose[:] = i * 0.1
            arm_right_end_effector_value[:] = i * 0.1
            arm_right_joint_positions[:] = i * 0.1
            arm_right_end_effector_pose[:] = i * 0.1
            sample = {
                "observation.images.cam_high": top_img.copy(),
                "observation.images.cam_right": right_img.copy(),
                "observation.images.cam_left": left_img.copy(),
                "observation.state.arm.left.end_effector_value": arm_left_end_effector_value.copy(),
                "observation.state.arm.left.joint_positions": arm_left_joint_positions.copy(),
                "observation.state.arm.left.end_effector_pose": arm_left_end_effector_pose.copy(),
                "observation.state.arm.right.end_effector_value": arm_right_end_effector_value.copy(),
                "observation.state.arm.right.joint_positions": arm_right_joint_positions.copy(),
                "observation.state.arm.right.end_effector_pose": arm_right_end_effector_pose.copy(),
            }
            ds.add_frame(sample, task="test_task")

        ds.save_episode()


def test_dataset_process():
    ds = LsRobotDataset(repo_id="my-lsrobot-dataset", root="./data/lsrobot_datasets")
    ds.annotate_episode(episode_index=1, splits=[], tasks=["test_task_updated"])
    ds.split_episode(episode_index=0, start_time=0.2, end_time=0.7)
    ds.delete_episodes(episode_indices=[0, 2])
    ds.copy_episodes_to_dataset(
        episode_indices=[1, 3],
        dst_repo_id="my-lsrobot-dataset-copy",
        dst_root="./data/lsrobot_datasets",
    )


def test_end_effector_value():
    timestamp = 0.0

    ds = LsRobotDataset.create(
        repo_id="end_effector",
        root="./data/lsrobot_datasets",
        robot_type="gripper",
        fps=10,
        features={
            "observation.left.value": {
                "dtype": "float32",
                "shape": (1,),
                "names": [f"value_{i}" for i in range(1)],
            },
            "observation.right.value": {
                "dtype": "float32",
                "shape": (2,),
                "names": [f"value_{i}" for i in range(5)],
            },
        },
    )

    for episode in range(3):
        left_value = np.array([episode * 0.1], dtype=np.float32)
        right_value = np.array([episode * 0.1 + 1, episode * 0.1 + 2], dtype=np.float32)

        for _frame in range(10):
            sample = {
                "observation.left.value": left_value.copy(),
                "observation.right.value": right_value.copy(),
            }
            ds.add_frame(sample, task="ee", timestamp=timestamp)
            timestamp += 0.1

        ds.save_episode()


def test_abort_when_recording():
    ds = LsRobotDataset.create(
        repo_id="abort-dataset",
        root="./data/lsrobot_datasets",
        robot_type="arm",
        fps=10,
        features={
            "observation.images.cam_high": {
                "dtype": "image",
                "shape": (480, 640, 3),
                "names": ["height", "width", "channel"],
            }
        },
    )

    for j in range(3):
        timestamp = 0.0
        top_img = np.zeros((480, 640, 3), dtype=np.uint8)

        for i in range(10):
            timestamp += 0.1
            top_img[:] = i * 5
            sample = {
                "observation.images.cam_high": top_img.copy(),
            }
            ds.add_frame(sample, task="test_task", timestamp=timestamp)

        if j < 2:
            ds.save_episode()
        else:
            ds.clear_episode_buffer()
            break
