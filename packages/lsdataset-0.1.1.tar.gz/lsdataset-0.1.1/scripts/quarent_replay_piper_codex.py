import argparse
import os
import signal
import sys
import time
from typing import Optional

import numpy as np
import pyarrow.parquet as pq
from scipy.spatial.transform import Rotation as R

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, PROJECT_ROOT)

from app.devices import *  # noqa: F401,F403 - 触发插件注册
from app.utils.abstract_fractory import RobotFactory

DEFAULT_PARQUET = (
    "/home/ls/agilex/lerobot_data/data/chunk-000/episode_000001_relative.parquet"
    # "/home/ls/Desktop/lcp_old/backend/data/lerobot_dataset/20260321_panda_dual_pika_32_22/data/chunk-000/episode_000015.parquet"
)
DEFAULT_COLUMN = "observation.state.arm.right.end_effector_pose"

def list_parquet_columns(parquet_file: str) -> list[str]:
    schema = pq.read_schema(parquet_file)
    return schema.names


def load_relative_pose_trajectory(parquet_file: str, column_name: str) -> np.ndarray:
    if not os.path.isfile(parquet_file):
        raise FileNotFoundError(f"Parquet 文件不存在: {parquet_file}")

    available_columns = list_parquet_columns(parquet_file)
    if column_name not in available_columns:
        raise KeyError(
            "未找到目标列: "
            f"{column_name}\n可用列:\n- " + "\n- ".join(available_columns)
        )

    table = pq.read_table(parquet_file, columns=[column_name])
    column = table.column(column_name).combine_chunks()
    deltas = np.asarray(column.to_pylist(), dtype=np.float64)

    if deltas.ndim != 2 or deltas.shape[1] != 6:
        raise ValueError(
            f"{column_name} 数据形状异常，期望 (N, 6)，实际为 {deltas.shape}"
        )
    if len(deltas) == 0:
        raise ValueError(f"{column_name} 为空，无法回放")

    print(f"📂 正在加载相对位姿轨迹: {parquet_file}")
    print(f"   - 列名: {column_name}")
    print(f"   - 时间步数: {len(deltas)}")
    print(f"   - 首帧增量: {np.array2string(deltas[0], precision=5)}")
    return deltas


def build_arm(ip: str):
    config = RobotFactory.getConfigFactory("arm").create(
        "piper_arm",
        name="piper_right_replay",
        dof=6,
        ip=ip,
    )
    return RobotFactory.getDeviceFactory("arm").create("piper_arm", config)


def get_initial_state(arm) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    state = arm.get_state()
    if state.joint_positions is None:
        raise RuntimeError("无法读取 Piper 当前关节角")

    joints = np.asarray(state.joint_positions, dtype=np.float64)
    gripper = (
        np.asarray(state.end_effector_value, dtype=np.float64)
        if state.end_effector_value is not None
        else np.zeros(1, dtype=np.float64)
    )
    pose = arm.get_forward_kinematics(joints)
    if pose is None or np.allclose(pose, 0.0):
        raise RuntimeError("Piper FK 不可用，无法从当前状态开始做相对位姿回放")

    return joints, gripper, np.asarray(pose, dtype=np.float64)


def apply_delta_pose(
    current_pose: np.ndarray,
    delta_pose: np.ndarray,
    pos_scale: float = 1.0,
    rot_scale: float = 1.0,
) -> np.ndarray:
    target_pose = current_pose.copy()
    target_pose[:3] += delta_pose[:3] * pos_scale
    current_rot = R.from_euler("xyz", current_pose[3:])
    delta_rot = R.from_euler("xyz", delta_pose[3:] * rot_scale)
    target_pose[3:] = (current_rot * delta_rot).as_euler("xyz")
    return target_pose


def move_pose_with_ik(
    arm,
    target_pose: np.ndarray,
    current_joints: np.ndarray,
    gripper: np.ndarray,
    follow: bool,
) -> Optional[np.ndarray]:
    joints = arm.get_inverse_kinematics(target_pose, current_joints=current_joints)
    if joints is None:
        return None
    if not arm.move_joints(joints, gripper, follow=follow):
        return None
    return np.asarray(joints, dtype=np.float64)


def lift_arm_in_z(
    arm,
    current_pose: np.ndarray,
    current_joints: np.ndarray,
    gripper: np.ndarray,
    z_lift: float,
    settle_time: float,
) -> tuple[np.ndarray, np.ndarray]:
    target_pose = current_pose.copy()
    target_pose[2] += z_lift

    print(
        f"🚀 预抬升: z {current_pose[2]:.4f} -> {target_pose[2]:.4f} "
        f"(+{z_lift:.4f} m)"
    )

    lifted_joints = move_pose_with_ik(
        arm=arm,
        target_pose=target_pose,
        current_joints=current_joints,
        gripper=gripper,
        follow=False,
    )
    if lifted_joints is None:
        print("⚠️  预抬升 IK/执行失败，跳过抬升并继续后续逆解回放")
        return current_pose, current_joints

    time.sleep(settle_time)
    return target_pose, lifted_joints


def replay_relative_pose_trajectory(
    arm,
    deltas: np.ndarray,
    current_pose: np.ndarray,
    current_joints: np.ndarray,
    gripper: np.ndarray,
    replay_speed: float,
    control_frequency: float,
    start_step: int,
    end_step: Optional[int],
    pos_scale: float,
    rot_scale: float,
    max_consecutive_failures: int,
) -> tuple[bool, np.ndarray, np.ndarray]:
    total_steps = len(deltas)
    if end_step is None or end_step > total_steps:
        end_step = total_steps
    if start_step < 0:
        start_step = 0
    if start_step >= end_step:
        raise ValueError(f"无效的回放范围: start_step={start_step}, end_step={end_step}")
    if replay_speed <= 0 or control_frequency <= 0:
        raise ValueError("speed 和 frequency 必须大于 0")

    step_interval = 1.0 / (control_frequency * replay_speed)
    print("\n🎬 开始右臂相对位姿回放")
    print(f"   - 步数区间: [{start_step}, {end_step}) / {total_steps}")
    print(f"   - 控制频率: {control_frequency:.2f} Hz")
    print(f"   - 回放速度: {replay_speed:.2f}x")
    print(f"   - 位置缩放: {pos_scale:.3f}")
    print(f"   - 姿态缩放: {rot_scale:.3f}")
    print(f"   - 帧间隔: {step_interval * 1000.0:.2f} ms")

    success_count = 0
    failed_count = 0
    consecutive_failures = 0
    started_at = time.monotonic()
    stopped_by_failures = False

    for step in range(start_step, end_step):
        target_pose = apply_delta_pose(
            current_pose=current_pose,
            delta_pose=deltas[step],
            pos_scale=pos_scale,
            rot_scale=rot_scale,
        )
        next_joints = move_pose_with_ik(
            arm=arm,
            target_pose=target_pose,
            current_joints=current_joints,
            gripper=gripper,
            follow=True,
        )

        if next_joints is None:
            failed_count += 1
            consecutive_failures += 1
            print(
                f"⚠️  第 {step} 步执行失败，连续失败 {consecutive_failures}/"
                f"{max_consecutive_failures}"
            )
            if consecutive_failures >= max_consecutive_failures:
                print("❌ 连续 IK/发送失败次数过多，结束本次回放")
                stopped_by_failures = True
                break
        else:
            success_count += 1
            consecutive_failures = 0
            current_pose = target_pose
            current_joints = next_joints

        if (step - start_step + 1) % 20 == 0 or step == end_step - 1:
            progress = (step - start_step + 1) / (end_step - start_step) * 100.0
            print(
                f"📊 进度: {progress:.1f}% "
                f"({step - start_step + 1}/{end_step - start_step}) "
                f"- 成功: {success_count}, 失败: {failed_count}"
            )

        next_deadline = started_at + (step - start_step + 1) * step_interval
        remaining = next_deadline - time.monotonic()
        if remaining > 0:
            time.sleep(remaining)

    if stopped_by_failures:
        print("\n⚠️ 相对位姿回放提前结束（连续失败超阈值）")
    else:
        print("\n✅ 相对位姿回放完成")
    print(f"   - 成功步数: {success_count}")
    print(f"   - 失败步数: {failed_count}")
    return (not stopped_by_failures), current_pose, current_joints


def hold_enabled_forever():
    print("\n🟢 回放结束，按要求保持使能。")
    print("   进程将持续驻留，请在需要时手动 kill。")
    while True:
        time.sleep(1.0)


def main() -> int:
    parser = argparse.ArgumentParser(description="Piper 右臂相对位姿回放")
    parser.add_argument("--file", "-f", default=DEFAULT_PARQUET, help="Parquet 文件路径")
    parser.add_argument("--column", default=DEFAULT_COLUMN, help="相对位姿列名")
    parser.add_argument("--ip", default="can_right", help="Piper CAN 接口，默认 can_arm0")
    parser.add_argument("--speed", "-s", type=float, default=1.0, help="回放速度倍数")
    parser.add_argument("--frequency", type=float, default=10.0, help="控制频率 Hz")
    parser.add_argument("--start", type=int, default=0, help="开始时间步")
    parser.add_argument("--end", type=int, default=None, help="结束时间步")
    parser.add_argument("--z-lift", type=float, default=0.1, help="回放前 z 轴抬升高度（米）")
    parser.add_argument("--lift-settle", type=float, default=2, help="抬升后等待时间（秒）")
    parser.add_argument("--pos-scale", type=float, default=0.6, help="位置增量缩放")
    parser.add_argument("--rot-scale", type=float, default=1.0, help="姿态增量缩放")
    parser.add_argument(
        "--max-consecutive-failures",
        type=int,
        default=5,
        help="连续失败阈值，超过后停止回放",
    )
    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("🤖 Piper 右臂相对位姿回放")
    print("=" * 60)
    print(f"📁 文件: {args.file}")
    print(f"🧭 列名: {args.column}")
    print(f"🔌 接口: {args.ip}")
    print(f"⬆️  预抬升: {args.z_lift:.4f} m")
    print("=" * 60)

    arm = build_arm(args.ip)

    try:
        deltas = load_relative_pose_trajectory(args.file, args.column)

        print("⏳ 连接并使能 Piper...")
        if not arm.connect(timeout=10.0):
            print("❌ Piper 连接失败")
            return 1
        if not arm.enable():
            print("❌ Piper 使能失败")
            return 2

        current_joints, gripper, current_pose = get_initial_state(arm)
        print(f"✅ 当前关节: {np.array2string(current_joints, precision=4)}")
        print(f"✅ 当前末端位姿: {np.array2string(current_pose, precision=4)}")

        current_pose, current_joints = lift_arm_in_z(
            arm=arm,
            current_pose=current_pose,
            current_joints=current_joints,
            gripper=gripper,
            z_lift=args.z_lift,
            settle_time=args.lift_settle,
        )

        success, _, _ = replay_relative_pose_trajectory(
            arm=arm,
            deltas=deltas,
            current_pose=current_pose,
            current_joints=current_joints,
            gripper=gripper,
            replay_speed=args.speed,
            control_frequency=args.frequency,
            start_step=args.start,
            end_step=args.end,
            pos_scale=args.pos_scale,
            rot_scale=args.rot_scale,
            max_consecutive_failures=args.max_consecutive_failures,
        )
        if not success:
            return 3

        hold_enabled_forever()
        return 0

    except KeyboardInterrupt:
        print("\n⚠️  收到中断信号，正在失能并断开 Piper...")
        return 130
    except Exception as exc:
        print(f"\n❌ 程序出错: {exc}")
        return 1
    finally:
        try:
            if getattr(arm, "is_enabled", False):
                arm.disable()
        except Exception:
            pass
        try:
            if getattr(arm, "is_connected", False):
                arm.disconnect()
        except Exception:
            pass


if __name__ == "__main__":
    def _signal_to_interrupt(*_args):
        raise KeyboardInterrupt()

    signal.signal(signal.SIGTERM, _signal_to_interrupt)
    raise SystemExit(main())
