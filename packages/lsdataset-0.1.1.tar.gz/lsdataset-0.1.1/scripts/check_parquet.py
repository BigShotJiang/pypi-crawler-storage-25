#!/usr/bin/env python3
"""检查数据集夹爪数据是否符合 dataset.py:194-200 的逻辑要求"""
import argparse
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd
import pyarrow.parquet as pq


def column_to_numpy_2d(column):
    """将 PyArrow 列转换为二维 numpy 数组"""
    data_list = column.to_pylist()
    return np.array(data_list)


def check_end_effector_value_shape(
    parquet_file: Path, column_name: str
) -> Tuple[bool, str]:
    """
    检查 parquet 文件中 end_effector_value 列的数据形状是否符合要求
    
    Args:
        parquet_file: parquet 文件路径
        column_name: 列名（如 "observation.state.arm.left.end_effector_value"）
    
    Returns:
        (is_valid, error_msg): 如果符合要求返回 (True, "")，否则返回 (False, 错误信息)
    """
    try:
        # 读取指定列
        table = pq.read_table(parquet_file, columns=[column_name])
        column = table.column(column_name).combine_chunks()
        
        if len(column) == 0:
            return True, ""  # 空数据视为有效
        
        # 获取第一个值检查其类型
        first_value = column[0].as_py()
        
        # 如果 shape 是 [1]，数据应该是标量值（float/int），而不是数组
        # 检查第一个值是否是列表/数组
        if isinstance(first_value, (list, np.ndarray)):
            # 如果是数组，检查是否长度为1
            if len(first_value) == 1:
                # 虽然长度是1，但仍然是数组形式，不符合要求
                return False, f"数据是数组形式 [{first_value[0]}]，应该是标量值 {first_value[0]}"
            else:
                return False, f"数据是长度为 {len(first_value)} 的数组，但 shape 应该是 [1]"
        
        # 检查所有值是否都是标量
        all_values = column.to_pylist()
        for idx, val in enumerate(all_values):
            if isinstance(val, (list, np.ndarray)):
                if len(val) == 1:
                    return False, f"第 {idx} 行数据是数组形式 [{val[0]}]，应该是标量值 {val[0]}"
                else:
                    return False, f"第 {idx} 行数据是长度为 {len(val)} 的数组，但 shape 应该是 [1]"
        
        return True, ""
        
    except Exception as e:
        return False, f"读取 parquet 文件时出错: {e}"


def fix_end_effector_value_shape(
    parquet_file: Path, column_name: str
) -> bool:
    """
    修复 parquet 文件中 end_effector_value 列的数据形状
    
    Args:
        parquet_file: parquet 文件路径
        column_name: 列名
    
    Returns:
        bool: 是否成功修复
    """
    try:
        # 使用 pyarrow 读取，更可靠地处理嵌套数组
        table = pq.read_table(parquet_file)
        
        if column_name not in table.column_names:
            print(f"  警告: 列 {column_name} 不存在于文件中")
            return False
        
        # 读取指定列
        column = table[column_name].combine_chunks()
        column_data = column.to_pylist()
        
        # 检查并修复数据
        fixed_values = []
        for idx, val in enumerate(column_data):
            if isinstance(val, (list, np.ndarray)):
                if len(val) == 1:
                    # 提取标量值
                    fixed_values.append(val[0])
                else:
                    print(f"  警告: 第 {idx} 行发现长度为 {len(val)} 的数组，无法自动修复")
                    return False
            else:
                # 已经是标量值，保持不变
                fixed_values.append(val)
        
        # 转换为 DataFrame 并更新列
        df = table.to_pandas()
        df[column_name] = fixed_values
        
        # 保存回 parquet 文件
        df.to_parquet(parquet_file, index=False)
        return True
        
    except Exception as e:
        print(f"  修复失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def check_dataset(
    data_root: str, repo_ids: List[str]
) -> Dict[str, List[Dict[str, Any]]]:
    """
    检查数据集中的夹爪数据
    
    Args:
        data_root: 数据集根目录
        repo_ids: 数据集 ID 列表
    
    Returns:
        Dict[str, List[Dict]]: 每个 repo_id 对应的不符合要求的 episode 列表
    """
    issues = {}
    
    for repo_id in repo_ids:
        dataset_path = Path(data_root) / repo_id
        info_json_path = dataset_path / "meta" / "info.json"
        
        if not info_json_path.exists():
            print(f"⚠️  跳过 {repo_id}: info.json 不存在")
            continue
        
        # 读取 info.json
        with open(info_json_path, 'r', encoding='utf-8') as f:
            info = json.load(f)
        
        features = info.get("features", {})
        data_path_template = info.get("data_path", "data/chunk-{episode_chunk:03d}/episode_{episode_index:06d}.parquet")
        total_episodes = info.get("total_episodes", 0)
        chunks_size = info.get("chunks_size", 1000)
        
        # 检查需要验证的列
        columns_to_check = []
        for col_name in [
            "observation.state.arm.left.end_effector_value",
            "observation.state.arm.right.end_effector_value"
        ]:
            if col_name in features:
                ft = features[col_name]
                shape = ft.get("shape", [])
                # 只检查 shape 为 [1] 的情况
                if isinstance(shape, list) and len(shape) == 1 and shape[0] == 1:
                    columns_to_check.append(col_name)
        
        if not columns_to_check:
            print(f"✓ {repo_id}: 没有需要检查的 end_effector_value 字段（shape=[1]）")
            continue
        
        print(f"\n📂 检查数据集: {repo_id}")
        print(f"   需要检查的列: {columns_to_check}")
        print(f"   总 episode 数: {total_episodes}")
        
        repo_issues = []
        
        # 遍历所有 episode
        for ep_index in range(total_episodes):
            episode_chunk = ep_index // chunks_size
            episode_file = dataset_path / data_path_template.format(
                episode_chunk=episode_chunk,
                episode_index=ep_index
            )
            
            if not episode_file.exists():
                continue
            
            # 检查每个需要验证的列
            for col_name in columns_to_check:
                is_valid, error_msg = check_end_effector_value_shape(episode_file, col_name)
                if not is_valid:
                    repo_issues.append({
                        "episode_index": ep_index,
                        "episode_file": str(episode_file),
                        "column_name": col_name,
                        "error": error_msg
                    })
                    print(f"  ❌ Episode {ep_index:06d} ({col_name}): {error_msg}")
        
        if repo_issues:
            issues[repo_id] = repo_issues
            print(f"  ⚠️  发现 {len(repo_issues)} 个问题")
        else:
            print(f"  ✓ 所有 episode 检查通过")
    
    return issues


def fix_issues(
    data_root: str, issues: Dict[str, List[Dict[str, Any]]]
) -> None:
    """
    修复发现的问题
    
    Args:
        data_root: 数据集根目录
        issues: 问题字典
    """
    print("\n" + "="*60)
    print("开始修复...")
    print("="*60)
    
    total_fixed = 0
    total_failed = 0
    
    for repo_id, repo_issues in issues.items():
        print(f"\n修复数据集: {repo_id}")
        
        for issue in repo_issues:
            episode_file = Path(issue["episode_file"])
            column_name = issue["column_name"]
            episode_index = issue["episode_index"]
            
            print(f"  Episode {episode_index:06d} - {column_name}: ", end="")
            
            if fix_end_effector_value_shape(episode_file, column_name):
                print("✓ 修复成功")
                total_fixed += 1
            else:
                print("✗ 修复失败")
                total_failed += 1
    
    print("\n" + "="*60)
    print(f"修复完成: 成功 {total_fixed} 个，失败 {total_failed} 个")
    print("="*60)


def main():
    # 检查数据集
    print("="*60)
    print("数据集夹爪数据检查工具")
    print("="*60)
    
    data_root = "./data/lerobot_dataset"
    repo_ids = []
    for repo_id in Path(data_root).iterdir():
        if repo_id.is_dir():
            print(f"发现数据集: {repo_id.name}")
            repo_ids.append(repo_id.name)
    
    issues = check_dataset(
        data_root=data_root,
        repo_ids=repo_ids
    )
    
    # 打印汇总信息
    print("\n" + "="*60)
    print("检查结果汇总")
    print("="*60)
    
    if not issues:
        print("✓ 所有数据集检查通过，没有发现问题！")
        return
    
    total_issues = sum(len(repo_issues) for repo_issues in issues.values())
    print(f"⚠️  发现 {len(issues)} 个数据集存在问题，共 {total_issues} 个问题：\n")
    
    for repo_id, repo_issues in issues.items():
        print(f"数据集: {repo_id}")
        print(f"  问题数量: {len(repo_issues)}")
        for issue in repo_issues:
            print(f"    - Episode {issue['episode_index']:06d}: {issue['column_name']}")
            print(f"      错误: {issue['error']}")
        print()
    
    # 询问是否修复
    response = input("\n是否自动修复这些问题？(y/n): ").strip().lower()
    should_fix = response in ('y', 'yes', '是')
    
    if should_fix:
        fix_issues(data_root, issues)
    else:
        print("\n跳过修复，退出。")


if __name__ == "__main__":
    main()
