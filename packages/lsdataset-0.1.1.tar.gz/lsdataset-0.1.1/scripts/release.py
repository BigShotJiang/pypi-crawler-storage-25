#!/usr/bin/env python3
"""发布前版本号工具：递增 ``pyproject.toml`` 中的 ``version``，可选同步 README、执行 build。

用法（在仓库根目录）::

    python scripts/release.py patch
    python scripts/release.py minor --sync-readme
    python scripts/release.py patch --build
    python scripts/release.py patch --dry-run

``patch`` / ``minor`` / ``major`` 遵循语义化版本（仅支持 ``x.y.z`` 三段数字）。
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path


def _parse_version(v: str) -> tuple[int, int, int]:
    parts = v.strip().split(".")
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise ValueError(f"仅支持 x.y.z 数字版本，当前为: {v!r}")
    return int(parts[0]), int(parts[1]), int(parts[2])


def _format_version(t: tuple[int, int, int]) -> str:
    return f"{t[0]}.{t[1]}.{t[2]}"


def _bump(current: str, kind: str) -> str:
    major, minor, patch = _parse_version(current)
    if kind == "patch":
        patch += 1
    elif kind == "minor":
        minor += 1
        patch = 0
    elif kind == "major":
        major += 1
        minor = 0
        patch = 0
    else:
        raise ValueError(kind)
    return _format_version((major, minor, patch))


def _read_version(pyproject: str) -> str:
    m = re.search(r"^version\s*=\s*\"([^\"]+)\"\s*$", pyproject, re.MULTILINE)
    if not m:
        raise RuntimeError("无法在 pyproject.toml 中找到 version = \"...\" 行")
    return m.group(1)


def _replace_pyproject_version(pyproject: str, new_ver: str) -> str:
    out, n = re.subn(
        r"^(version\s*=\s*)\"[^\"]+\"(\s*)$",
        rf'\1"{new_ver}"\2',
        pyproject,
        count=1,
        flags=re.MULTILINE,
    )
    if n != 1:
        raise RuntimeError("替换 pyproject.toml version 失败")
    return out


def _sync_readme_readme(readme: str, old_ver: str, new_ver: str) -> str:
    # LCP 文档示例：lsdataset[all]==x.y.z
    pattern = re.compile(re.escape(f"lsdataset[all]=={old_ver}"))
    if not pattern.search(readme):
        return readme
    return pattern.sub(f"lsdataset[all]=={new_ver}", readme)


def main() -> int:
    parser = argparse.ArgumentParser(description="Bump lsdataset version in pyproject.toml")
    parser.add_argument(
        "part",
        choices=("patch", "minor", "major"),
        help="semver 递增类型",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只打印新旧版本，不写文件、不 build",
    )
    parser.add_argument(
        "--sync-readme",
        action="store_true",
        help="若 README.md 中含 lsdataset[all]==旧版本，则同步为新版本",
    )
    parser.add_argument(
        "--build",
        action="store_true",
        help="bump 后执行 python -m build（需已安装 build）",
    )
    args = parser.parse_args()

    root = Path(__file__).resolve().parent.parent
    pyproject_path = root / "pyproject.toml"
    readme_path = root / "README.md"

    text = pyproject_path.read_text(encoding="utf-8")
    old = _read_version(text)
    new = _bump(old, args.part)

    print(f"version: {old} -> {new} ({args.part})")

    if args.dry_run:
        print("(dry-run，未写入文件)")
        return 0

    pyproject_path.write_text(_replace_pyproject_version(text, new), encoding="utf-8")
    print(f"已写入 {pyproject_path}")

    if args.sync_readme and readme_path.is_file():
        r = readme_path.read_text(encoding="utf-8")
        r2 = _sync_readme_readme(r, old, new)
        if r2 != r:
            readme_path.write_text(r2, encoding="utf-8")
            print(f"已同步 README 中的 lsdataset[all]=={old} -> {new}")
        else:
            print("README 中未找到匹配的 lsdataset[all]==… 行，跳过")

    if args.build:
        print("运行: python -m build …")
        subprocess.run(
            [sys.executable, "-m", "build"],
            cwd=root,
            check=True,
        )
        print("build 完成，dist/ 下已生成制品。后续: twine check dist/* && twine upload dist/*")
    else:
        print("后续建议: git add pyproject.toml README.md && git commit -m \"release v%s\"" % new)
        print("          git tag v%s && git push && git push --tags" % new)
        print("          python -m build && twine check dist/* && twine upload dist/*")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
