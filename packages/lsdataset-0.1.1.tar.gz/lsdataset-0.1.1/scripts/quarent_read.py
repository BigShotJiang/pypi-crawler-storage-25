import argparse
import os

import numpy as np
import pyarrow.parquet as pq


def column_to_numpy_2d(column):
    """将 PyArrow 列转换为二维 numpy 数组"""
    data_list = column.to_pylist()
    return np.array(data_list)

def main(parquet_file: str, time_step: int = 0, joint_idx: int = 0):
    if not os.path.isfile(parquet_file):
        raise FileNotFoundError(f"parquet 文件不存在: {parquet_file}")

    l_j = pq.read_table(parquet_file, columns=["observation.state.arm.left.joint_positions"])
    c_l_j = l_j.column("observation.state.arm.left.joint_positions").combine_chunks()

    l_g = pq.read_table(parquet_file, columns=["observation.state.arm.left.end_effector_value"])
    c_l_g = l_g.column("observation.state.arm.left.end_effector_value").combine_chunks()

    r_j = pq.read_table(parquet_file, columns=["observation.state.arm.right.joint_positions"])
    c_r_j = r_j.column("observation.state.arm.right.joint_positions").combine_chunks()

    l_j_N = len(c_l_j)
    l_g_N = len(c_l_g)
    r_j_N = len(c_r_j)

    # ========== 读取具体数据的方法 ==========

    try:
        l_j_data = c_l_j.to_numpy(zero_copy_only=False)
        l_g_data = c_l_g.to_numpy(zero_copy_only=False)
        r_j_data = c_r_j.to_numpy(zero_copy_only=False)
    except Exception:
        print("注意: to_numpy() 无法直接处理嵌套数组，将使用 to_pylist() 转 numpy 的方式")
        l_j_data = None
        l_g_data = None
        r_j_data = None

    l_j_list = c_l_j.to_pylist()
    l_g_list = c_l_g.to_pylist()
    r_j_list = c_r_j.to_pylist()

    if l_j_N > 0:
        first_left_joint = c_l_j[0].as_py()
        last_left_joint = c_l_j[l_j_N - 1].as_py()
        print(f"第一个时间步左臂关节位置: {first_left_joint}")
        print(f"最后一个时间步左臂关节位置: {last_left_joint}")

    l_j_2d = column_to_numpy_2d(c_l_j)
    l_g_2d = column_to_numpy_2d(c_l_g)
    r_j_2d = column_to_numpy_2d(c_r_j)

    print(f"\n数据统计:")
    print(f"左臂关节位置 - 时间步数: {l_j_N}, 形状: {l_j_2d.shape if l_j_N > 0 else 'N/A'}")
    print(f"左臂末端执行器 - 时间步数: {l_g_N}, 形状: {l_g_2d.shape if l_g_N > 0 else 'N/A'}")
    print(f"右臂关节位置 - 时间步数: {r_j_N}, 形状: {r_j_2d.shape if r_j_N > 0 else 'N/A'}")

    # 参数化访问：time_step / joint_idx
    if l_j_N > 0 and len(l_j_2d.shape) == 2:
        if not (0 <= time_step < l_j_N):
            raise IndexError(f"time_step 越界: {time_step}, 有效范围: [0, {l_j_N - 1}]")
        if not (0 <= joint_idx < l_j_2d.shape[1]):
            raise IndexError(f"joint_idx 越界: {joint_idx}, 有效范围: [0, {l_j_2d.shape[1] - 1}]")

        specific_value = l_j_2d[time_step, joint_idx]
        print(f"\n时间步 {time_step} 的左臂第 {joint_idx} 个关节角度: {specific_value}")

        ee_value = c_l_g[time_step].as_py() if l_g_N > time_step else None
        print(f"时间步 {time_step} 的左臂末端执行器值: {ee_value}")

    if l_j_N > 0 and len(l_j_2d.shape) == 2:
        all_timesteps_joint = l_j_2d[:, joint_idx] if 0 <= joint_idx < l_j_2d.shape[1] else None
        if all_timesteps_joint is not None:
            print(f"\n所有时间步的左臂第 {joint_idx} 个关节角度: {all_timesteps_joint[:5]}...")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="读取 parquet 中的机器人观测数据")
    parser.add_argument(
        "-f", "--parquet-file",
        required=True,
        help="parquet 文件路径",
    )
    parser.add_argument(
        "-t", "--time-step",
        type=int,
        default=0,
        help="要查看的时间步（默认 0）",
    )
    parser.add_argument(
        "-j", "--joint-idx",
        type=int,
        default=0,
        help="要查看的关节下标（默认 0）",
    )
    args = parser.parse_args()
    main(args.parquet_file, args.time_step, args.joint_idx)