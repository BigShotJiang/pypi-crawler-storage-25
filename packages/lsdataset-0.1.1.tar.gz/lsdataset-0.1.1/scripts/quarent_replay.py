import argparse
import os
import select
import sys
import termios
import threading
import time
import tty
from datetime import datetime
from typing import Dict, List, Optional, Tuple

# 添加项目根目录到路径
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

import cv2
import numpy as np
import pyarrow.parquet as pq
import pyrealsense2 as rs
import yaml
from scipy.spatial.transform import Rotation as R

from app.devices.arm_interface import ArmConfig, ArmFactory

# -------------------------------
# 数据读取和回放函数
# -------------------------------

def load_parquet_trajectory(parquet_file: str) -> Dict[str, np.ndarray]:
    """
    从 parquet 文件中加载轨迹数据
    
    Args:
        parquet_file: parquet 文件路径
        
    Returns:
        包含轨迹数据的字典，包括：
        - left_joint_positions: 左臂关节位置 (N, dof)
        - left_end_effector: 左臂末端执行器值 (N,)
        - right_joint_positions: 右臂关节位置 (N, dof)
        - right_end_effector: 右臂末端执行器值 (N,)
    """
    if not os.path.exists(parquet_file):
        raise FileNotFoundError(f"Parquet 文件不存在: {parquet_file}")
    
    print(f"📂 正在加载轨迹文件: {parquet_file}")
    
    try:
        # 读取左臂关节位置
        l_j_table = pq.read_table(parquet_file, columns=["observation.state.arm.left.joint_positions"])
        l_j_column = l_j_table.column("observation.state.arm.left.joint_positions").combine_chunks()
        left_joint_positions = np.array(l_j_column.to_pylist())
        
        # 读取左臂末端执行器
        l_g_table = pq.read_table(parquet_file, columns=["observation.state.arm.left.end_effector_value"])
        l_g_column = l_g_table.column("observation.state.arm.left.end_effector_value").combine_chunks()
        left_end_effector = np.array(l_g_column.to_pylist())
        
        # 读取右臂关节位置
        r_j_table = pq.read_table(parquet_file, columns=["observation.state.arm.right.joint_positions"])
        r_j_column = r_j_table.column("observation.state.arm.right.joint_positions").combine_chunks()
        right_joint_positions = np.array(r_j_column.to_pylist())
        
        # 尝试读取右臂末端执行器（可能不存在）
        try:
            r_g_table = pq.read_table(parquet_file, columns=["observation.state.arm.right.end_effector_value"])
            r_g_column = r_g_table.column("observation.state.arm.right.end_effector_value").combine_chunks()
            right_end_effector = np.array(r_g_column.to_pylist())
        except Exception as e:
            print(f"⚠️  未找到右臂末端执行器数据，使用左臂数据: {e}")
            right_end_effector = left_end_effector.copy()
        
        # 数据验证
        n_left = len(left_joint_positions)
        n_right = len(right_joint_positions)
        
        if n_left != n_right:
            raise ValueError(f"左右臂时间步数不一致: 左臂={n_left}, 右臂={n_right}")
        
        # 确保末端执行器数据维度正确
        if left_end_effector.ndim == 1:
            left_end_effector = left_end_effector.reshape(-1, 1)
        if right_end_effector.ndim == 1:
            right_end_effector = right_end_effector.reshape(-1, 1)
        
        print(f"✅ 轨迹加载成功:")
        print(f"   - 时间步数: {n_left}")
        print(f"   - 左臂关节数: {left_joint_positions.shape[1]}")
        print(f"   - 右臂关节数: {right_joint_positions.shape[1]}")
        print(f"   - 数据形状: 左臂关节={left_joint_positions.shape}, 右臂关节={right_joint_positions.shape}")
        
        return {
            "left_joint_positions": left_joint_positions,
            "left_end_effector": left_end_effector,
            "right_joint_positions": right_joint_positions,
            "right_end_effector": right_end_effector,
            "num_steps": n_left
        }
        
    except Exception as e:
        raise RuntimeError(f"加载 parquet 文件失败: {e}")


def replay_parquet_trajectory(
    parquet_file: str,
    left_arm,
    right_arm,
    replay_speed: float = 1.0,
    control_frequency: float = 30.0,
    start_step: int = 0,
    end_step: Optional[int] = None
) -> bool:
    """
    回放 parquet 轨迹到机械臂
    
    Args:
        parquet_file: parquet 文件路径
        left_arm: 左臂机械臂对象
        right_arm: 右臂机械臂对象
        replay_speed: 回放速度倍数 (1.0 = 原速, 0.5 = 半速, 2.0 = 双速)
        control_frequency: 控制频率 (Hz)
        start_step: 开始时间步（默认从头开始）
        end_step: 结束时间步（默认到结尾）
        
    Returns:
        True 表示回放成功，False 表示回放失败
    """
    try:
        # 加载轨迹数据
        trajectory = load_parquet_trajectory(parquet_file)
        
        left_joints = trajectory["left_joint_positions"]
        left_gripper = trajectory["left_end_effector"]
        right_joints = trajectory["right_joint_positions"]
        right_gripper = trajectory["right_end_effector"]
        total_steps = trajectory["num_steps"]
        
        # 确定回放范围
        if end_step is None or end_step > total_steps:
            end_step = total_steps
        
        if start_step < 0:
            start_step = 0
        
        if start_step >= end_step:
            raise ValueError(f"无效的回放范围: start_step={start_step}, end_step={end_step}")
        
        # 计算每帧间隔时间
        sleep_time = 1.0 / control_frequency / replay_speed
        
        print(f"\n🎬 开始回放轨迹:")
        print(f"   - 回放范围: 第 {start_step} 到 {end_step} 步（共 {end_step - start_step} 步）")
        print(f"   - 回放速度: {replay_speed}x")
        print(f"   - 控制频率: {control_frequency} Hz")
        print(f"   - 每帧间隔: {sleep_time*1000:.2f} ms")
        print(f"   - 预计时长: {(end_step - start_step) * sleep_time:.2f} 秒")
        
        # 回放主循环
        start_time = time.time()
        success_count = 0
        failed_count = 0
        
        for step in range(start_step, end_step):
            try:
                # 获取当前时间步的数据
                left_joint_pos = left_joints[step]
                left_gripper_val = np.array([ 1 if left_gripper[step] > 0.2  else 0])
                right_joint_pos = right_joints[step]
                right_gripper_val = np.array([1 if right_gripper[step] > 0.2 else 0])

                
                # 发送指令到左臂（使用 follow=True 以跟随模式执行）
                # print(left_joint_pos)
                left_success = left_arm.move_joints(
                    left_joint_pos[:6],
                    left_gripper_val
                )
                
                # 发送指令到右臂
                right_success = right_arm.move_joints(
                    right_joint_pos[:6],
                    right_gripper_val
                )

                if left_success and right_success:
                    success_count += 1
                else:
                    failed_count += 1
                    if failed_count > 10:
                        print(f"\n❌ 连续失败次数过多，停止回放")
                        return False
                
                # 显示进度
                if (step - start_step + 1) % 50 == 0 or step == end_step - 1:
                    progress = (step - start_step + 1) / (end_step - start_step) * 100
                    elapsed = time.time() - start_time
                    print(f"📊 进度: {progress:.1f}% ({step - start_step + 1}/{end_step - start_step}) "
                          f"- 已用时: {elapsed:.1f}s - 成功: {success_count}, 失败: {failed_count}")
                
                # 控制回放速度
                time.sleep(sleep_time)
                
            except KeyboardInterrupt:
                print(f"\n⚠️  用户中断回放")
                left_arm.stop()
                right_arm.stop()
                return False
                
            except Exception as e:
                print(f"\n❌ 回放第 {step} 步时出错: {e}")
                failed_count += 1
                if failed_count > 10:
                    return False
        
        # 回放完成
        actual_duration = time.time() - start_time
        print(f"\n✅ 轨迹回放完成!")
        print(f"   - 实际用时: {actual_duration:.2f} 秒")
        print(f"   - 成功步数: {success_count}/{end_step - start_step}")
        print(f"   - 失败步数: {failed_count}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ 回放失败: {e}")
        import traceback
        traceback.print_exc()
        return False


# -------------------------------
# 初始化机器人
# -------------------------------

# 使用Realman类初始化机械臂
left_arm_config = ArmConfig(
    name="rm65b_zhixing90c_udp",
    dof=6,
    ip="192.168.10.18",
    control_frequency=100.0,
    udp_listen_port=8089
)
left_robot_arm = ArmFactory.create("rm65b_zhixing90c_udp", left_arm_config)  

right_arm_config = ArmConfig(
    name="realman_yinshi_udp",
    dof=6,
    ip="192.168.10.19",
    control_frequency=100.0,
    udp_listen_port=8090
)
right_robot_arm = ArmFactory.create("rm65b_zhixing90c_udp", right_arm_config)  

left_robot_arm.connect()
time.sleep(1)
left_robot_arm.enable()

right_robot_arm.connect()
time.sleep(1)
right_robot_arm.enable()

left_state = left_robot_arm.get_state()
right_state = right_robot_arm.get_state()

print(f"✅ 左臂状态: 关节数={len(left_state.joint_positions) if left_state.joint_positions is not None else 'N/A'}")
print(f"✅ 右臂状态: 关节数={len(right_state.joint_positions) if right_state.joint_positions is not None else 'N/A'}")

# -------------------------------
# 主程序
# -------------------------------

def main():
    """主程序入口"""
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='从 Parquet 文件回放轨迹到机械臂')
    parser.add_argument(
        '--file', '-f',
        type=str,
        default="/home/ls/pop_corn/trace/episode_000003.parquet",
        help='Parquet 轨迹文件路径'
    )
    parser.add_argument(
        '--speed', '-s',
        type=float,
        default=1.0,
        help='回放速度倍数 (默认 1.0)'
    )
    parser.add_argument(
        '--start',
        type=int,
        default=0,
        help='开始时间步 (默认 0)'
    )
    parser.add_argument(
        '--end',
        type=int,
        default=None,
        help='结束时间步 (默认到结尾)'
    )
    parser.add_argument(
        '--frequency',
        type=float,
        default=10.0,
        help='控制频率 Hz (默认 150.0)'
    )
    
    args = parser.parse_args()
    
    print("\n" + "="*60)
    print("🤖 Parquet 轨迹回放系统")
    print("="*60)
    print(f"📁 轨迹文件: {args.file}")
    print(f"⚡ 回放速度: {args.speed}x")
    print(f"📊 控制频率: {args.frequency} Hz")
    print(f"🎯 回放范围: 步 {args.start} 到 {args.end if args.end else '结尾'}")
    print("="*60 + "\n")
    
    try:
        # 检查文件是否存在
        if not os.path.exists(args.file):
            print(f"❌ 错误: 文件不存在: {args.file}")
            return 1
        
        # 等待机械臂初始化完成
        print("⏳ 等待机械臂准备就绪...")
        time.sleep(2)
        
        # 开始回放
        success = replay_parquet_trajectory(
            parquet_file=args.file,
            left_arm=left_robot_arm,
            right_arm=right_robot_arm,
            replay_speed=args.speed,
            control_frequency=args.frequency,
            start_step=args.start,
            end_step=args.end
        )
        
        if success:
            print("\n🎉 回放任务完成!")
            return 0
        else:
            print("\n❌ 回放任务失败!")
            return 1
            
    except KeyboardInterrupt:
        print("\n\n⚠️  用户中断程序")
        left_robot_arm.stop()
        right_robot_arm.stop()
        return 130
        
    except Exception as e:
        print(f"\n❌ 程序出错: {e}")
        import traceback
        traceback.print_exc()
        return 1
        
    finally:
        # 清理资源
        print("\n🔌 断开机械臂连接...")
        try:
            left_robot_arm.disable()
            left_robot_arm.disconnect()
        except:
            pass
        try:
            right_robot_arm.disable()
            right_robot_arm.disconnect()
        except:
            pass
        print("👋 程序结束")


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)