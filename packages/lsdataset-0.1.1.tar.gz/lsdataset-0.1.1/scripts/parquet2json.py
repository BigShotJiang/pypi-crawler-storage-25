# env: datasets==4.*  （与你录制/当前能正常读取数据的环境一致）
import base64
import glob
import json
import os
import shutil

import numpy as np
import pandas as pd
from datasets import load_dataset

IN_DIR  = "/home/ls/workspace/lcp/backend/data/lerobot_dataset/20260313_panda_dual_pika/data/chunk-000" 
OUT_DIR = "/home/ls/workspace/lcp/temp"

# 可选：干净一点
if os.path.exists(OUT_DIR):
    shutil.rmtree(OUT_DIR)
os.makedirs(OUT_DIR, exist_ok=True)

class ComprehensiveEncoder(json.JSONEncoder):
    def default(self, obj):
        # 处理 NumPy 数组
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        
        # 处理 NumPy 整数类型
        if isinstance(obj, (np.int_, np.intc, np.intp, np.int8,
            np.int16, np.int32, np.int64, np.uint8,
            np.uint16, np.uint32, np.uint64)):
            return int(obj)
        
        # 处理 NumPy 浮点类型
        if isinstance(obj, (np.float16, np.float32, np.float64)):
            if np.isnan(obj):
                return None # JSON 不支持 NaN，转为 null
            if np.isinf(obj):
                return None # JSON 不支持 Inf，转为 null
            return float(obj)
        
        # 处理 NumPy 布尔值
        if isinstance(obj, np.bool_):
            return bool(obj)
        
        # 处理 Bytes (二进制数据)
        if isinstance(obj, bytes):
            try:
                # 尝试作为 UTF-8 文本解码
                return obj.decode('utf-8')
            except UnicodeDecodeError:
                # 如果解码失败，说明是真正的二进制数据（如图片）
                # 策略 A: 转为 Base64 字符串 (推荐，保留数据)
                return f"<base64_data>:{base64.b64encode(obj).decode('ascii')}"
                
                # 策略 B: 如果不需要二进制数据，可以直接返回空字符串或提示
                # return "<binary_data_skipped>"
        
        # 处理 Pandas/Timestamp 时间类型
        if isinstance(obj, pd.Timestamp):
            return obj.isoformat()
            
        if isinstance(obj, np.datetime64):
            return np.datetime_as_string(obj, unit='s')

        # 其他未知类型，尝试转为字符串
        return str(obj)

def safe_json_serialize(obj):
    try:
        # 使用自定义编码器
        return json.dumps(obj, cls=ComprehensiveEncoder, ensure_ascii=False, allow_nan=True)
    except (UnicodeDecodeError, UnicodeEncodeError, OverflowError, TypeError) as e:
        # 如果发生编码错误或类型错误，尝试清洗字符串
        def clean_item(item):
            if isinstance(item, str):
                # 修复非法 UTF-8 序列
                return item.encode('utf-8', errors='replace').decode('utf-8')
            elif isinstance(item, np.ndarray):
                # 如果是 ndarray，先转 list 再递归清洗（以防 list 里有坏字符串）
                return [clean_item(x) for x in item.tolist()]
            elif isinstance(item, list):
                return [clean_item(x) for x in item]
            elif isinstance(item, dict):
                return {k: clean_item(v) for k, v in item.items()}
            else:
                return item
        
        cleaned_obj = clean_item(obj)
        try:
            return json.dumps(cleaned_obj, cls=ComprehensiveEncoder, ensure_ascii=False, allow_nan=True)
        except Exception as final_e:
            print(f"警告：即使清洗后仍无法序列化某行数据: {final_e}")
            return None # 返回 None 表示跳过

# 获取所有parquet文件
parquet_files = glob.glob(os.path.join(IN_DIR, "*.parquet"))
print(f"发现 {len(parquet_files)} 个parquet文件: {[os.path.basename(f) for f in parquet_files]}")

# 逐个处理每个parquet文件
for parquet_file in parquet_files:
    # 获取文件名（不包含扩展名）
    base_name = os.path.splitext(os.path.basename(parquet_file))[0]
    
    print(f"正在处理: {base_name}.parquet")
    
    # 加载单个parquet文件
    dataset = load_dataset("parquet", data_files=parquet_file)
    
    # 输出jsonl文件，前缀名相同
    output_file = os.path.join(OUT_DIR, f"{base_name}.jsonl")
    
    # 通常parquet文件加载后会有一个'train' split
    if 'train' in dataset:
        ds = dataset['train']
    else:
        # 如果没有train split，取第一个split
        split_name = list(dataset.keys())[0]
        ds = dataset[split_name]
    
    # 重置timestamp为从0.0开始，按10Hz（0.1秒间隔）累加
    def reset_timestamp(examples):
        num_examples = len(examples['timestamp'])
        # 从0.0开始，每个间隔0.1秒（10Hz）
        new_timestamps = [i * 0.1 for i in range(num_examples)]
        examples['timestamp'] = new_timestamps
        return examples
    
    # 应用timestamp重置
    ds = ds.map(reset_timestamp, batched=True)
    
    # 导出为jsonl
    df = ds.to_pandas()
    with open(output_file, 'w', encoding='utf-8') as f:
        # df.to_dict(orient='records') 会把每一行变成一个字典
        records = df.to_dict(orient='records')
        
        for record in records:
            try:
                json_line = safe_json_serialize(record)
                f.write(json_line + '\n')
            except Exception as e:
                print(f"跳过了一行无法序列化的数据: {e}")
    
    print(f"已生成: {base_name}.jsonl")

print(f"所有转换完成! 输出目录: {OUT_DIR}")
