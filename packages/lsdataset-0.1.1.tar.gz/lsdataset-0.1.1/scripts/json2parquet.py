# 将JSONL文件转换回Parquet格式
import json
import os
from pathlib import Path

import pandas as pd


def jsonl_to_parquet(jsonl_file_path, output_parquet_path):
    """
    将JSONL文件转换为Parquet格式
    
    Args:
        jsonl_file_path (str): 输入JSONL文件路径
        output_parquet_path (str): 输出Parquet文件路径
    """
    
    # 读取JSONL文件
    data = []
    with open(jsonl_file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():  # 跳过空行
                data.append(json.loads(line))
    
    print(f"读取了 {len(data)} 条记录")
    
    # 转换为DataFrame
    df = pd.DataFrame(data)
    
    # 显示数据信息
    print("数据形状:", df.shape)
    print("列名:", df.columns.tolist())
    print("\n数据类型:")
    print(df.dtypes)
    
    # 确保输出目录存在
    output_dir = os.path.dirname(output_parquet_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    
    # 保存为Parquet格式
    df.to_parquet(output_parquet_path, index=False)
    print(f"\n成功保存为Parquet格式: {output_parquet_path}")
    
    return df

def batch_jsonl_to_parquet(input_dir, output_dir):
    """
    批量将JSONL文件转换为Parquet格式
    
    Args:
        input_dir (str): 输入JSONL文件目录
        output_dir (str): 输出Parquet文件目录
    """
    import glob

    # 获取所有jsonl文件
    jsonl_files = glob.glob(os.path.join(input_dir, "*.jsonl"))
    
    if not jsonl_files:
        print(f"在目录 {input_dir} 中没有找到jsonl文件")
        return
    
    print(f"发现 {len(jsonl_files)} 个jsonl文件: {[os.path.basename(f) for f in jsonl_files]}")
    
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    total_input_size = 0
    total_output_size = 0
    successful_conversions = 0
    
    # 逐个处理每个jsonl文件
    for jsonl_file in jsonl_files:
        # 获取文件名（不包含扩展名）
        base_name = os.path.splitext(os.path.basename(jsonl_file))[0]
        output_file = os.path.join(output_dir, f"{base_name}.parquet")
        
        print(f"\n正在处理: {base_name}.jsonl -> {base_name}.parquet")
        
        try:
            # 执行转换
            df = jsonl_to_parquet(jsonl_file, output_file)
            
            # 统计文件大小
            input_size = os.path.getsize(jsonl_file) / (1024 * 1024)  # MB
            output_size = os.path.getsize(output_file) / (1024 * 1024)  # MB
            
            total_input_size += input_size
            total_output_size += output_size
            successful_conversions += 1
            
            print(f"✓ 成功转换: {input_size:.2f} MB -> {output_size:.2f} MB")
            
        except Exception as e:
            print(f"✗ 转换失败: {e}")
    
    # 显示总体统计
    if successful_conversions > 0:
        print(f"\n=== 批量转换完成 ===")
        print(f"成功转换: {successful_conversions}/{len(jsonl_files)} 个文件")
        print(f"总输入大小: {total_input_size:.2f} MB")
        print(f"总输出大小: {total_output_size:.2f} MB")
        print(f"总压缩比: {(1 - total_output_size/total_input_size)*100:.1f}%")
        print(f"输出目录: {output_dir}")

def main():
    # 配置路径 - 批量处理模式
    INPUT_DIR = "/root/data0/wyh_dataset_tool/temp2/20250915_zhongliang_2_jsonl"  # jsonl文件目录
    OUTPUT_DIR = "/root/data0/wyh_dataset_tool/temp3/20250915_zhongliang_2"     # parquet输出目录
    
    # 检查输入目录是否存在
    if not os.path.exists(INPUT_DIR):
        print(f"错误: 找不到输入目录 {INPUT_DIR}")
        return
    
    print(f"开始批量转换: {INPUT_DIR} -> {OUTPUT_DIR}")
    
    try:
        # 执行批量转换
        batch_jsonl_to_parquet(INPUT_DIR, OUTPUT_DIR)
        
    except Exception as e:
        print(f"批量转换过程中出现错误: {e}")

if __name__ == "__main__":
    main()
