"""FastAPI routes for `/lsdataset/*` (see `routes.py`)."""
