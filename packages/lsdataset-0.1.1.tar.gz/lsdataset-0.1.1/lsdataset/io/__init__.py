"""Dataset file layout helpers, image writer, and video encoding."""
