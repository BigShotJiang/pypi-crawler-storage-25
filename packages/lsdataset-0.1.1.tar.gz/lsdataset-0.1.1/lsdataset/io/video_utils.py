#!/usr/bin/env python

# Copyright 2024 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import contextlib
import logging
import queue
import shutil
import subprocess
import tempfile
import threading
from fractions import Fraction
from pathlib import Path
from typing import OrderedDict, Union, Optional

import av
import numpy as np
from PIL import Image

# List of hardware encoders to probe for auto-selection. Availability depends on the platform and FFmpeg build.
# Determines the order of preference for auto-selection when vcodec="auto" is used.
HW_ENCODERS = [
    "h264_videotoolbox",  # macOS
    "hevc_videotoolbox",  # macOS
    "h264_nvenc",  # NVIDIA GPU
    "hevc_nvenc",  # NVIDIA GPU
    "h264_vaapi",  # Linux Intel/AMD
    "h264_qsv",  # Intel Quick Sync
]

VALID_VIDEO_CODECS = {"h264", "hevc", "libsvtav1", "auto"} | set(HW_ENCODERS)


def _get_codec_options(
    vcodec: str,
    g: Optional[int] = 2,
    crf: Optional[int] = 30,
    preset: Optional[int] = None,
) -> dict:
    """Build codec-specific options dict for video encoding."""
    options = {}

    # GOP size (keyframe interval) - supported by VideoToolbox and software encoders
    if g is not None and (vcodec in ("h264_videotoolbox", "hevc_videotoolbox") or vcodec not in HW_ENCODERS):
        options["g"] = str(g)

    # Quality control (codec-specific parameter names)
    if crf is not None:
        if vcodec in ("h264", "hevc", "libsvtav1"):
            options["crf"] = str(crf)
        elif vcodec in ("h264_videotoolbox", "hevc_videotoolbox"):
            quality = max(1, min(100, int(100 - crf * 2)))
            options["q:v"] = str(quality)
        elif vcodec in ("h264_nvenc", "hevc_nvenc"):
            options["rc"] = "constqp"
            options["qp"] = str(crf)
        elif vcodec in ("h264_vaapi",):
            options["qp"] = str(crf)
        elif vcodec in ("h264_qsv",):
            options["global_quality"] = str(crf)

    # Preset (only for libsvtav1)
    if vcodec == "libsvtav1":
        options["preset"] = str(preset) if preset is not None else "12"

    return options


def detect_available_hw_encoders() -> list[str]:
    """Probe PyAV/FFmpeg for available hardware video encoders."""
    available = []
    for codec_name in HW_ENCODERS:
        try:
            av.codec.Codec(codec_name, "w")
            available.append(codec_name)
        except Exception:  # nosec B110
            pass  # nosec B110
    return available


def resolve_vcodec(vcodec: str) -> str:
    """Validate vcodec and resolve 'auto' to best available HW encoder, fallback to libsvtav1."""
    if vcodec not in VALID_VIDEO_CODECS:
        raise ValueError(f"Invalid vcodec '{vcodec}'. Must be one of: {sorted(VALID_VIDEO_CODECS)}")
    if vcodec != "auto":
        logging.info(f"Using video codec: {vcodec}")
        return vcodec
    available = detect_available_hw_encoders()
    for encoder in HW_ENCODERS:
        if encoder in available:
            logging.info(f"Auto-selected video codec: {encoder}")
            return encoder
    logging.info("No hardware encoder available, falling back to software encoder 'libsvtav1'")
    return "libsvtav1"


def encode_video_frames(
    imgs_dir: Union[Path , str],
    video_path: Union[Path, str],
    fps: Union[int, float],
    vcodec: str = "h264",
    pix_fmt: str = "yuv420p",
    g: Optional[int] = 2,
    crf: Optional[int] = 18,
    fast_decode: int = 0,
    log_level: Optional[str] = "error",
    overwrite: bool = False,
) -> None:
    """More info on ffmpeg arguments tuning on `benchmark/video/README.md`"""
    vcodec = resolve_vcodec(vcodec)

    video_path = Path(video_path)
    imgs_dir = Path(imgs_dir)

    if video_path.exists() and not overwrite:
        logging.warning(f"Video file already exists: {video_path}. Skipping encoding.")
        return

    video_path.parent.mkdir(parents=True, exist_ok=True)

    # Encoders/pixel formats incompatibility check
    if (vcodec == "libsvtav1" or vcodec == "hevc") and pix_fmt == "yuv444p":
        logging.warning(
            f"Incompatible pixel format 'yuv444p' for codec {vcodec}, auto-selecting format 'yuv420p'"
        )
        pix_fmt = "yuv420p"

    ffmpeg_args = OrderedDict(
        [
            ("-f", "image2"),
            ("-r", str(fps)),
            ("-i", str(imgs_dir / "frame_%06d.png")),
            ("-vcodec", vcodec),
            ("-pix_fmt", pix_fmt),
            ("-b:v", "0"),  # 添加无比特率限制参数
        ]
    )

    if g is not None:
        ffmpeg_args["-g"] = str(g)

    if crf is not None:
        ffmpeg_args["-crf"] = str(crf)

    if fast_decode:
        key = "-svtav1-params" if vcodec == "libsvtav1" else "-tune"
        value = f"fast-decode={fast_decode}" if vcodec == "libsvtav1" else "fastdecode"
        ffmpeg_args[key] = value

    if log_level is not None:
        ffmpeg_args["-loglevel"] = str(log_level)

    ffmpeg_args = [item for pair in ffmpeg_args.items() for item in pair]
    if overwrite:
        ffmpeg_args.append("-y")

    ffmpeg_cmd = ["ffmpeg"] + ffmpeg_args + [str(video_path)]
    # redirect stdin to subprocess.DEVNULL to prevent reading random keyboard inputs from terminal
    subprocess.run(ffmpeg_cmd, check=True, stdin=subprocess.DEVNULL)

    if not video_path.exists():
        raise OSError(
            f"Video encoding did not work. File not found: {video_path}. "
            f"Try running the command manually to debug: `{''.join(ffmpeg_cmd)}`"
        )


def split_video_by_frames(
    src_video_path: Union[Path, str],
    dst_video_path: Union[Path, str],
    start_frame: int,
    end_frame: int,
    fps: int,
    dst_frames_dir: Union[Path, str],
    cleanup_temp: bool = True,
    log_level: Optional[str] = "error",
) -> None:
    """
    从源视频中提取指定范围的帧，复制到目标目录，并重新编码为新视频。

    Args:
        src_video_path: 源视频文件路径
        dst_video_path: 目标视频文件路径
        start_frame: 起始帧索引（从0开始）
        end_frame: 结束帧索引（不包含，从0开始）
        fps: 视频帧率
        dst_frames_dir: 目标帧目录（用于存储提取的帧，之后会被编码为视频）
        cleanup_temp: 是否清理临时文件（包括提取帧的临时目录）
        log_level: ffmpeg日志级别

    Raises:
        OSError: 如果视频编码失败
        ValueError: 如果参数无效
    """
    import shutil

    src_video_path = Path(src_video_path)
    dst_video_path = Path(dst_video_path)
    dst_frames_dir = Path(dst_frames_dir)

    if not src_video_path.exists():
        raise ValueError(f"Source video does not exist: {src_video_path}")

    if start_frame < 0 or end_frame <= start_frame:
        raise ValueError(f"Invalid frame range: start_frame={start_frame}, end_frame={end_frame}")

    # 创建临时拆帧目录（从原视频拆出来的所有帧）
    extract_dir = src_video_path.parent / f"temp_split_extract_{src_video_path.stem}"
    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    extract_dir.mkdir(parents=True, exist_ok=True)

    try:
        # ffmpeg 拆帧：frame_%06d.png（从 1 开始编号）
        extract_pattern = extract_dir / "frame_%06d.png"
        ffmpeg_cmd = [
            "ffmpeg",
            "-loglevel",
            log_level or "error",
            "-i",
            str(src_video_path),
            "-vsync",
            "0",
            str(extract_pattern),
            "-y",
        ]
        subprocess.run(ffmpeg_cmd, check=True, stdin=subprocess.DEVNULL)

        # 准备目标帧目录
        if dst_frames_dir.exists():
            shutil.rmtree(dst_frames_dir)
        dst_frames_dir.mkdir(parents=True, exist_ok=True)

        # 注意：ffmpeg 导出帧从 1 开始；而 start_frame 是从 0 开始
        # 复制指定范围的帧到目标目录，并重新编号（从 1 开始）
        for i in range(start_frame, end_frame):
            src_frame = extract_dir / f"frame_{i + 1:06d}.png"
            if not src_frame.exists():
                continue
            # 目标帧从 1 开始编号（encode_video_frames 期望 frame_%06d.png 从 1 开始）
            dst_frame = dst_frames_dir / f"frame_{i - start_frame + 1:06d}.png"
            shutil.copy2(src_frame, dst_frame)

        # 重新编码新视频
        encode_video_frames(dst_frames_dir, dst_video_path, fps, overwrite=True)

    finally:
        # 清理临时目录
        if cleanup_temp:
            if extract_dir.exists():
                shutil.rmtree(extract_dir, ignore_errors=True)
            # 注意：dst_frames_dir 通常也需要清理（因为视频已编码），但这里不自动清理
            # 让调用者决定是否保留帧目录


class _CameraEncoderThread(threading.Thread):
    """A thread that encodes video frames streamed via a queue into an MP4 file.

    One instance is created per camera per episode. Frames are received as numpy arrays
    from the main thread, encoded in real-time using PyAV (which releases the GIL during
    encoding), and written to disk. Stats are computed incrementally using
    RunningQuantileStats and returned via result_queue.
    """

    def __init__(
        self,
        video_path: Path,
        fps: Union[int, float],
        vcodec: str,
        pix_fmt: str,
        g: Optional[int],
        crf: Optional[int],
        preset: Optional[int],
        frame_queue: queue.Queue,
        result_queue: queue.Queue,
        stop_event: threading.Event,
        encoder_threads: Optional[int] = None,
    ):
        super().__init__(daemon=True)
        self.video_path = video_path
        self.fps = int(fps)
        self.vcodec = vcodec
        self.pix_fmt = pix_fmt
        self.g = g
        self.crf = crf
        self.preset = preset
        self.frame_queue = frame_queue
        self.result_queue = result_queue
        self.stop_event = stop_event
        self.encoder_threads = encoder_threads

    def run(self) -> None:
        container = None
        output_stream = None
        frame_count = 0

        try:
            logging.getLogger("libav").setLevel(av.logging.WARNING)

            while True:
                try:
                    frame_data = self.frame_queue.get(timeout=1)
                except queue.Empty:
                    if self.stop_event.is_set():
                        break
                    continue

                if frame_data is None:
                    # Sentinel: flush and close
                    break

                # Ensure HWC uint8 numpy array
                if isinstance(frame_data, np.ndarray):
                    if frame_data.ndim == 3 and frame_data.shape[0] == 3:
                        # CHW -> HWC
                        frame_data = frame_data.transpose(1, 2, 0)
                    if frame_data.dtype != np.uint8:
                        frame_data = (frame_data * 255).astype(np.uint8)

                # Open container on first frame (to get width/height)
                if container is None:
                    height, width = frame_data.shape[:2]
                    video_options = _get_codec_options(self.vcodec, self.g, self.crf, self.preset)
                    if self.encoder_threads is not None:
                        if self.vcodec == "libsvtav1":
                            lp_param = f"lp={self.encoder_threads}"
                            if "svtav1-params" in video_options:
                                video_options["svtav1-params"] += f":{lp_param}"
                            else:
                                video_options["svtav1-params"] = lp_param
                        else:
                            video_options["threads"] = str(self.encoder_threads)
                    Path(self.video_path).parent.mkdir(parents=True, exist_ok=True)
                    container = av.open(str(self.video_path), "w")
                    output_stream = container.add_stream(self.vcodec, self.fps, options=video_options)
                    output_stream.pix_fmt = self.pix_fmt
                    output_stream.width = width
                    output_stream.height = height
                    output_stream.time_base = Fraction(1, self.fps)

                # Encode frame with explicit timestamps
                pil_img = Image.fromarray(frame_data)
                video_frame = av.VideoFrame.from_image(pil_img)
                video_frame.pts = frame_count
                video_frame.time_base = Fraction(1, self.fps)
                packet = output_stream.encode(video_frame)
                if packet:
                    container.mux(packet)

                frame_count += 1

            # Flush encoder
            if output_stream is not None:
                packet = output_stream.encode()
                if packet:
                    container.mux(packet)

            if container is not None:
                container.close()

            av.logging.restore_default_callback()

            # Put result on result queue
            self.result_queue.put(("ok", frame_count))

        except Exception as e:
            logging.error(f"Encoder thread error: {e}")
            if container is not None:
                with contextlib.suppress(Exception):
                    container.close()
            self.result_queue.put(("error", str(e)))


class StreamingVideoEncoder:
    """Manages per-camera encoder threads for real-time video encoding during recording.

    Instead of writing frames as PNG images and then encoding to MP4 at episode end,
    this class streams frames directly to encoder threads, eliminating the
    PNG round-trip and making save_episode() near-instant.

    Uses threading instead of multiprocessing to avoid the overhead of pickling large
    numpy arrays through multiprocessing.Queue. PyAV's encode() releases the GIL,
    so encoding runs in parallel with the main recording loop.
    """

    def __init__(
        self,
        fps: Union[int, float],
        vcodec: str = "h264",
        pix_fmt: str = "yuv420p",
        g: Optional[int] = 2,
        crf: Optional[int] = 30,
        preset: Optional[int] = None,
        queue_maxsize: int = 30,
        encoder_threads: Optional[int] = None,
    ):
        self.fps = fps
        self.vcodec = resolve_vcodec(vcodec)
        self.pix_fmt = pix_fmt
        self.g = g
        self.crf = crf
        self.preset = preset
        self.queue_maxsize = queue_maxsize
        self.encoder_threads = encoder_threads

        self._frame_queues: dict[str, queue.Queue] = {}
        self._result_queues: dict[str, queue.Queue] = {}
        self._threads: dict[str, _CameraEncoderThread] = {}
        self._stop_events: dict[str, threading.Event] = {}
        self._video_paths: dict[str, Path] = {}
        self._dropped_frames: dict[str, int] = {}
        self._episode_active = False

    def start_episode(self, video_keys: list[str], temp_dir: Path) -> None:
        """Start encoder threads for a new episode.

        Args:
            video_keys: List of video feature keys (e.g. ["observation.images.laptop"])
            temp_dir: Base directory for temporary MP4 files
        """
        if self._episode_active:
            self.cancel_episode()

        self._dropped_frames.clear()

        for video_key in video_keys:
            frame_queue: queue.Queue = queue.Queue(maxsize=self.queue_maxsize)
            result_queue: queue.Queue = queue.Queue(maxsize=1)
            stop_event = threading.Event()

            temp_video_dir = Path(tempfile.mkdtemp(dir=temp_dir))
            video_path = temp_video_dir / f"{video_key.replace('/', '_')}_streaming.mp4"

            encoder_thread = _CameraEncoderThread(
                video_path=video_path,
                fps=self.fps,
                vcodec=self.vcodec,
                pix_fmt=self.pix_fmt,
                g=self.g,
                crf=self.crf,
                preset=self.preset,
                frame_queue=frame_queue,
                result_queue=result_queue,
                stop_event=stop_event,
                encoder_threads=self.encoder_threads,
            )
            encoder_thread.start()

            self._frame_queues[video_key] = frame_queue
            self._result_queues[video_key] = result_queue
            self._threads[video_key] = encoder_thread
            self._stop_events[video_key] = stop_event
            self._video_paths[video_key] = video_path

        self._episode_active = True

    def feed_frame(self, video_key: str, image: np.ndarray) -> None:
        """Feed a frame to the encoder for a specific camera.

        A copy of the image is made before enqueueing to prevent race conditions
        with camera drivers that may reuse buffers. If the encoder queue is full
        (encoder can't keep up), the frame is dropped with a warning instead of
        crashing the recording session.

        Args:
            video_key: The video feature key
            image: numpy array in (H,W,C) or (C,H,W) format, uint8 or float

        Raises:
            RuntimeError: If the encoder thread has crashed
        """
        if not self._episode_active:
            raise RuntimeError("No active episode. Call start_episode() first.")

        thread = self._threads[video_key]
        if not thread.is_alive():
            # Check for error
            try:
                status, msg = self._result_queues[video_key].get_nowait()
                if status == "error":
                    raise RuntimeError(f"Encoder thread for {video_key} crashed: {msg}")
            except queue.Empty:
                pass
            raise RuntimeError(f"Encoder thread for {video_key} is not alive")

        try:
            self._frame_queues[video_key].put(image.copy(), timeout=0.1)
        except queue.Full:
            self._dropped_frames[video_key] = self._dropped_frames.get(video_key, 0) + 1
            count = self._dropped_frames[video_key]
            # Log periodically to avoid spam (1st, then every 10th)
            if count == 1 or count % 10 == 0:
                logging.warning(
                    f"Encoder queue full for {video_key}, dropped {count} frame(s). "
                    f"Consider using vcodec='auto' for hardware encoding or increasing encoder_queue_maxsize."
                )

    def finish_episode(self) -> dict[str, tuple[Path, Union[dict, None]]]:
        """Finish encoding the current episode.

        Sends sentinel values, waits for encoder threads to complete,
        and collects results.

        Returns:
            Dict mapping video_key to (mp4_path, stats_dict_or_None)
        """
        if not self._episode_active:
            raise RuntimeError("No active episode to finish.")

        results = {}

        # Report dropped frames
        for video_key, count in self._dropped_frames.items():
            if count > 0:
                logging.warning(f"Episode finished with {count} dropped frame(s) for {video_key}.")

        # Send sentinel to all queues
        for video_key in self._frame_queues:
            self._frame_queues[video_key].put(None)

        # Wait for all threads and collect results
        for video_key in self._threads:
            self._threads[video_key].join(timeout=120)
            if self._threads[video_key].is_alive():
                logging.error(f"Encoder thread for {video_key} did not finish in time")
                self._stop_events[video_key].set()
                self._threads[video_key].join(timeout=5)
                results[video_key] = (self._video_paths[video_key], None)
                continue

            try:
                status, data = self._result_queues[video_key].get(timeout=5)
                if status == "error":
                    raise RuntimeError(f"Encoder thread for {video_key} failed: {data}")
                results[video_key] = (self._video_paths[video_key], data)
            except queue.Empty:
                logging.error(f"No result from encoder thread for {video_key}")
                results[video_key] = (self._video_paths[video_key], None)

        self._cleanup()
        self._episode_active = False
        return results

    def cancel_episode(self) -> None:
        """Cancel the current episode, stopping encoder threads and cleaning up."""
        if not self._episode_active:
            return

        # Signal all threads to stop
        for video_key in self._stop_events:
            self._stop_events[video_key].set()

        # Wait for threads to finish
        for video_key in self._threads:
            self._threads[video_key].join(timeout=5)

            # Clean up temp MP4 files
            video_path = self._video_paths.get(video_key)
            if video_path is not None and video_path.exists():
                shutil.rmtree(str(video_path.parent), ignore_errors=True)

        self._cleanup()
        self._episode_active = False

    def close(self) -> None:
        """Close the encoder, canceling any in-progress episode."""
        if self._episode_active:
            self.cancel_episode()

    def _cleanup(self) -> None:
        """Clean up queues and thread tracking dicts."""
        for q in self._frame_queues.values():
            with contextlib.suppress(Exception):
                while not q.empty():
                    q.get_nowait()
        self._frame_queues.clear()
        self._result_queues.clear()
        self._threads.clear()
        self._stop_events.clear()
        self._video_paths.clear()