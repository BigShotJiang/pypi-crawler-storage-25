import logging


class LsDatasetAdapter(logging.LoggerAdapter):
    """LoggerAdapter, 在日志消息前添加[lsdataset]前缀"""
    def process(self, msg, kwargs):
        # 在消息前添加[lsdataset]前缀
        return f"[lsdataset] {msg}", kwargs

logger = LsDatasetAdapter(logging.getLogger('lsdataset'), {})
