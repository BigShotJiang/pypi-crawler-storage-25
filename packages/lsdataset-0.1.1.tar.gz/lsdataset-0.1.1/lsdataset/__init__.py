"""LeRobot-style dataset I/O；HTTP 与录制入口请从子模块显式导入。

示例：``from lsdataset.api.routes import router``，``from lsdataset.core.manager import add_frame``。
"""
