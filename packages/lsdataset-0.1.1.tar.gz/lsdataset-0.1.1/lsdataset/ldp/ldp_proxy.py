"""
LDP 代理：LCP 通过此后端与 LDP 对接登录与上传，避免浏览器跨域问题。
机器码优先从设备树 serial-number 派生，其次 DMI product_uuid；两者都无则报错禁止上传。
"""
import hashlib
import os
import socket
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests

from ..core.manager import manager
from ..logger import logger

# 简单的上传进度缓存：key 为数据集名称（repo_id），value 记录总字节数/已上传字节数/进度等
_UPLOAD_PROGRESS: Dict[str, Dict[str, Any]] = {}


def get_upload_progress(dataset_name: str) -> Dict[str, Any]:
    """
    获取指定数据集当前的上传进度。
    返回字段：
      - dataset_name: 数据集名称
      - total_bytes: 总字节数
      - uploaded_bytes: 已上传字节数
      - progress: 进度百分比（0-100）
      - status: idle | uploading | completed | error
      - updated_at: 最近更新时间的时间戳
    """
    info = _UPLOAD_PROGRESS.get(dataset_name)
    if not info:
        return {
            "dataset_name": dataset_name,
            "total_bytes": 0,
            "uploaded_bytes": 0,
            "progress": 0,
            "status": "idle",
            "updated_at": None,
        }
    return info

MACHINE_CODE_LEN = 10  # 固定 10 位，便于展示与存储
DEFAULT_DATA_TYPE = "lerobot"

# 机器码持久化：统一存于 backend/machine_code
_BACKEND_DIR = Path(__file__).resolve().parent.parent.parent
_MACHINE_CODE_FILE = _BACKEND_DIR / "machine_code"

_machine_code_cache: Optional[str] = None


def _read_dmi_product_uuid() -> Tuple[Optional[str], Optional[str]]:
    """读取 DMI product_uuid。返回 (raw, error_type)，error_type 为 'permission' 时表示权限不足。"""
    for path in ("/sys/class/dmi/id/product_uuid", "/sys/devices/virtual/dmi/id/product_uuid"):
        p = Path(path)
        if not p.is_file():
            continue
        try:
            raw = (p.read_text(encoding="utf-8") or "").strip().upper()
            if raw and len(raw) >= 32:
                return (raw, None)
        except PermissionError:
            return (None, "permission")
        except OSError as e:
            logger.debug("读取 DMI product_uuid 失败: %s", e)
    return (None, None)


def _read_devicetree_serial() -> Optional[str]:
    """读取设备树序列号（ARM/树莓派/Jetson 等），每块板唯一。"""
    p = Path("/sys/firmware/devicetree/base/serial-number")
    if not p.is_file():
        return None
    try:
        data = p.read_bytes().rstrip(b"\x00").decode("utf-8", errors="replace").strip()
        if data:
            return data
    except (OSError, PermissionError):
        pass
    return None


def _get_machine_code() -> str:
    """从硬件派生 10 位十六进制机器码：优先设备树 serial-number，其次 DMI product_uuid；两者都无则报错禁止上传。"""
    raw: Optional[str] = None
    source = ""
    dmi_error: Optional[str] = None
    raw = _read_devicetree_serial()
    if raw:
        source = "devicetree"
    if not raw:
        raw, dmi_error = _read_dmi_product_uuid()
        if raw:
            source = "dmi"
    if not raw:
        msg = "无法获取硬件机器码："
        if dmi_error == "permission":
            msg += " （DMI 文件权限不足，可执行: sudo chmod 444 /sys/class/dmi/id/product_uuid，再重启服务）"
        raise RuntimeError(msg)
    logger.info("机器码来源: %s", source)
    h = hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()
    return h[:MACHINE_CODE_LEN]


def _is_valid_machine_code(s: str) -> bool:
    """校验是否为合法 10 位十六进制机器码。"""
    if not s or len(s) != MACHINE_CODE_LEN:
        return False
    try:
        int(s, 16)
        return True
    except ValueError:
        return False


def _fallback_machine_code_from_host() -> str:
    """无硬件 ID 时生成稳定 10 位十六进制占位码，保证后端能完成启动（开发机 / 权限不足 / 容器等）。"""
    base = f"{socket.gethostname()}:{os.getpid()}"
    return hashlib.sha256(base.encode("utf-8", errors="replace")).hexdigest()[:MACHINE_CODE_LEN]


def get_machine_code() -> str:
    """返回本机机器码。

    顺序：持久化文件 → 环境变量 ``LCP_MACHINE_CODE``（10 位十六进制）→ 硬件（设备树/DMI）
    → 最后使用主机名派生占位码（并打日志），**不再因缺硬件而中止进程**。
    生产环境建议写入 ``backend/machine_code`` 或设置 ``LCP_MACHINE_CODE``，以便与 LDP 设备标识一致。
    """
    global _machine_code_cache
    if _machine_code_cache is not None:
        return _machine_code_cache
    path = _MACHINE_CODE_FILE
    # 1. 尝试从本机持久化文件读取
    try:
        if path.is_file():
            code = (path.read_text(encoding="utf-8") or "").strip()
            if _is_valid_machine_code(code):
                _machine_code_cache = code
                return _machine_code_cache
    except Exception as e:
        logger.warning("读取机器码文件 %s 失败: %s", path, e)

    # 2. 环境变量（CI、macOS、无读 DMI 权限等）
    env_code = (os.environ.get("LCP_MACHINE_CODE") or "").strip()
    if _is_valid_machine_code(env_code):
        _machine_code_cache = env_code
        logger.info("机器码来源: 环境变量 LCP_MACHINE_CODE")
        return _machine_code_cache

    # 3. 硬件（设备树或 DMI）
    try:
        code = _get_machine_code()
    except RuntimeError as e:
        logger.warning(
            "无法从硬件读取机器码（%s）；使用主机名派生占位码。"
            " 生产请配置 %s 或设置 LCP_MACHINE_CODE（10 位十六进制）。",
            e,
            path,
        )
        code = _fallback_machine_code_from_host()

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(code, encoding="utf-8")
    except Exception as e:
        logger.warning("写入机器码文件 %s 失败: %s", path, e)
    _machine_code_cache = code
    return _machine_code_cache


def ldp_login(ldp_base_url: str, phone: str, password: str) -> Dict[str, Any]:
    """调用 LDP 登录接口，返回 token 等信息。"""
    url = f"{ldp_base_url.rstrip('/')}/api/auth/login/password"
    try:
        resp = requests.post(
            url,
            json={"phone": phone, "password": password},
            headers={"Content-Type": "application/json"},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        logger.warning(f"LDP login failed: {e}")
        if hasattr(e, "response") and e.response is not None:
            status = e.response.status_code
            try:
                body = e.response.json()
                detail = body.get("detail", str(e))
            except Exception:
                detail = e.response.text or str(e)
            raise ValueError(f"LDP 登录失败: {detail}") from e
        raise ValueError(f"LDP 登录失败: {e}") from e


# 分片上传：每批最多文件数 / 最大字节数，避免单次请求过大
_BATCH_MAX_FILES = 25
_BATCH_MAX_BYTES = 12 * 1024 * 1024  # 12MB


def _safe_remove_uploaded_files(root: Path, files_list: List[tuple[str, Path, int]]) -> None:
    """
    在上传全部成功后，删除本次实际参与上传的文件，并尝试清理空目录。
    若删除过程中出错，仅记录日志，不影响调用方。
    """
    # 1. 删除文件
    for _, abs_path, _ in files_list:
        try:
            if abs_path.is_file():
                abs_path.unlink()
        except Exception as e:
            logger.warning("删除已上传文件失败: %s (%s)", abs_path, e)

    # 2. 自底向上清理由本次数据集产生的空目录（不越出 root）
    try:
        root = root.resolve()
        for dirpath, dirnames, filenames in os.walk(root, topdown=False):
            p = Path(dirpath)
            # 避免越界删除，最多清理到 root 本身
            try:
                p.relative_to(root)
            except ValueError:
                continue
            if dirnames or filenames:
                continue
            try:
                p.rmdir()
            except OSError:
                # 目录非空或无权限，忽略
                pass
    except Exception as e:
        logger.warning("清理已上传数据集空目录失败: %s", e)


def _walk_dataset_files(root: Path) -> List[tuple[str, Path, int]]:
    """递归遍历数据集目录，返回 (相对路径, 绝对路径, 文件大小) 列表。跳过 images 目录以减小上传量。"""
    files: List[tuple[str, Path, int]] = []
    root = root.resolve()
    for dirpath, dirnames, filenames in os.walk(root):
        if "images" in dirnames:
            dirnames.remove("images")  # 不进入 images 目录
        dirpath = Path(dirpath)
        for f in filenames:
            abs_path = dirpath / f
            if not abs_path.is_file():
                continue
            try:
                rel = os.path.relpath(abs_path, root)
            except ValueError:
                continue
            rel = rel.replace("\\", "/")
            if rel.startswith("..") or "/.." in rel:
                continue
            try:
                size = abs_path.stat().st_size
            except OSError:
                size = 0
            files.append((rel, abs_path, size))
    return files


def _build_batches(
    files_list: List[tuple[str, Path, int]],
) -> List[List[tuple[str, Path]]]:
    """将文件列表按批拆分，每批最多 _BATCH_MAX_FILES 个或 _BATCH_MAX_BYTES 字节。"""
    batches: List[List[tuple[str, Path]]] = []
    current: List[tuple[str, Path]] = []
    current_bytes = 0
    for rel, abs_path, size in files_list:
        if (
            len(current) >= _BATCH_MAX_FILES
            or (current_bytes + size > _BATCH_MAX_BYTES and len(current) > 0)
        ):
            batches.append(current)
            current = []
            current_bytes = 0
        current.append((rel, abs_path))
        current_bytes += size
    if current:
        batches.append(current)
    return batches


def ldp_upload_directory(
    ldp_base_url: str,
    access_token: str,
    dataset_path: str,
    dataset_name: str,
    collection_device: str,
    data_type: str,
    source: Optional[str] = None,
) -> Dict[str, Any]:
    """
    将本地数据集目录上传到 LDP（分片上传：init → chunk → finish）。
    返回 LDP 的响应 JSON（来自 finish），或抛出 ValueError。
    """
    root = Path(dataset_path)
    if not root.is_dir():
        raise ValueError(f"数据集路径不存在或非目录: {dataset_path}")

    files_list = _walk_dataset_files(root)
    if not files_list:
        raise ValueError(f"数据集目录为空: {dataset_path}")

    # 统计总字节数并初始化进度缓存
    total_bytes = sum(size for _, _, size in files_list)
    size_map = {str(abs_path): size for _, abs_path, size in files_list}
    _UPLOAD_PROGRESS[dataset_name] = {
        "dataset_name": dataset_name,
        "total_bytes": int(total_bytes),
        "uploaded_bytes": 0,
        "progress": 0,
        "status": "uploading",
        "updated_at": time.time(),
    }

    base = ldp_base_url.rstrip("/")
    headers = {"Authorization": f"Bearer {access_token}"}

    # 1. init
    init_data = {
        "collectionDevice": collection_device,
        "dataType": data_type,
        "name": dataset_name,
    }
    if source:
        init_data["source"] = source
    init_resp = requests.post(
        f"{base}/api/datasets/upload-directory/init",
        headers=headers,
        data=init_data,
        timeout=30,
    )
    if not init_resp.ok:
        try:
            body = init_resp.json()
            detail = body.get("detail", init_resp.text or str(init_resp.status_code))
            if isinstance(detail, list) and detail:
                detail = detail[0].get("msg", str(detail))
        except Exception:
            detail = init_resp.text or str(init_resp.status_code)
        raise ValueError(f"LDP init 失败: {detail}") from None
    init_json = init_resp.json()
    upload_id = init_json.get("upload_id")
    if not upload_id:
        raise ValueError("LDP init 未返回 upload_id")

    # 2. chunk：按批上传
    batches = _build_batches(files_list)
    uploaded_bytes = 0
    for batch in batches:
        files_parts: List[tuple[str, tuple[str, Any]]] = []
        try:
            batch_bytes = 0
            for rel, abs_path in batch:
                abs_str = str(abs_path)
                batch_bytes += int(size_map.get(abs_str, 0))
                files_parts.append(("files", (rel, open(abs_path, "rb"))))
            chunk_resp = requests.post(
                f"{base}/api/datasets/upload-directory/chunk",
                headers=headers,
                data={"upload_id": upload_id},
                files=files_parts,
                timeout=300,
            )
            if not chunk_resp.ok:
                try:
                    body = chunk_resp.json()
                    detail = body.get("detail", chunk_resp.text or str(chunk_resp.status_code))
                    if isinstance(detail, list) and detail:
                        detail = detail[0].get("msg", str(detail))
                except Exception:
                    detail = chunk_resp.text or str(chunk_resp.status_code)
                # 标记错误状态
                _UPLOAD_PROGRESS[dataset_name] = {
                    "dataset_name": dataset_name,
                    "total_bytes": int(total_bytes),
                    "uploaded_bytes": int(uploaded_bytes),
                    "progress": int(uploaded_bytes * 100 / total_bytes) if total_bytes > 0 else 0,
                    "status": "error",
                    "updated_at": time.time(),
                    "error": detail,
                }
                raise ValueError(f"LDP chunk 失败: {detail}") from None

            # 本批上传成功，更新进度
            uploaded_bytes += batch_bytes
            progress = int(uploaded_bytes * 100 / total_bytes) if total_bytes > 0 else 100
            _UPLOAD_PROGRESS[dataset_name] = {
                "dataset_name": dataset_name,
                "total_bytes": int(total_bytes),
                "uploaded_bytes": int(min(uploaded_bytes, total_bytes)),
                "progress": min(progress, 100),
                "status": "uploading",
                "updated_at": time.time(),
            }
        finally:
            for _, (_, f) in files_parts:
                if hasattr(f, "close"):
                    try:
                        f.close()
                    except Exception:
                        pass

    # 3. finish
    finish_resp = requests.post(
        f"{base}/api/datasets/upload-directory/finish",
        headers=headers,
        data={"upload_id": upload_id},
        timeout=120,
    )
    if not finish_resp.ok:
        try:
            body = finish_resp.json()
            detail = body.get("detail", finish_resp.text or str(finish_resp.status_code))
            if isinstance(detail, list) and detail:
                detail = detail[0].get("msg", str(detail))
        except Exception:
            detail = finish_resp.text or str(finish_resp.status_code)
        # 标记错误状态
        _UPLOAD_PROGRESS[dataset_name] = {
            "dataset_name": dataset_name,
            "total_bytes": int(total_bytes),
            "uploaded_bytes": int(uploaded_bytes),
            "progress": int(uploaded_bytes * 100 / total_bytes) if total_bytes > 0 else 0,
            "status": "error",
            "updated_at": time.time(),
            "error": detail,
        }
        raise ValueError(f"LDP finish 失败: {detail}") from None

    # 上传完成，设置进度为 100%
    _UPLOAD_PROGRESS[dataset_name] = {
        "dataset_name": dataset_name,
        "total_bytes": int(total_bytes),
        "uploaded_bytes": int(total_bytes),
        "progress": 100,
        "status": "completed",
        "updated_at": time.time(),
    }

    # 4. 上传成功后，删除本次已上传的本地文件（及可能产生的空目录）
    try:
        _safe_remove_uploaded_files(root, files_list)
    except Exception as e:
        # 理论上不会到这里，单独防御一层，避免因为清理问题影响正常返回
        logger.warning("上传后删除本地文件时发生异常: %s", e)

    return finish_resp.json()


def ldp_upload_datasets(
    ldp_base_url: str,
    access_token: str,
    dataset_ids: List[Dict[str, str]],
    collection_device: Optional[str] = None,
    data_type: Optional[str] = None,
    source: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    批量上传多个 LCP 本地数据集到 LDP。
    dataset_ids: [{"dataset_type": "lerobot_dataset", "repo_id": "xxx"}, ...]
    采集设备默认从硬件派生机器码：优先设备树 serial-number，其次 DMI product_uuid；两者都无则报错禁止上传。数据类型默认 lerobot。
    返回每个数据集的 LDP 响应列表。
    """
    if collection_device is None or not str(collection_device).strip():
        collection_device = get_machine_code()
    else:
        collection_device = str(collection_device).strip()
    if data_type is None or not str(data_type).strip():
        data_type = DEFAULT_DATA_TYPE
    else:
        data_type = str(data_type).strip()

    results: List[Dict[str, Any]] = []

    for item in dataset_ids:
        dataset_type = item.get("dataset_type", "lerobot_dataset")
        repo_id = item.get("repo_id")
        if not repo_id:
            results.append({"error": "缺少 repo_id"})
            continue

        try:
            info = manager.get_dataset_info(dataset_type, repo_id)
            path = info.get("path")
            if not path or not os.path.isdir(path):
                results.append({"error": f"数据集 {repo_id} 路径无效"})
                continue

            result = ldp_upload_directory(
                ldp_base_url=ldp_base_url,
                access_token=access_token,
                dataset_path=path,
                dataset_name=repo_id,
                collection_device=collection_device,
                data_type=data_type,
                source=source,
            )
            results.append(result)
            logger.info(f"数据集 {repo_id} 已成功上传到 LDP")

            # 上传成功后，删除本地整个数据集目录，释放空间
            try:
                manager.delete_dataset(dataset_type=dataset_type, repo_id=repo_id)
                logger.info(f"数据集 {dataset_type}:{repo_id} 本地文件已在上传成功后删除。")
            except Exception as del_e:
                # 删除失败只记录日志，不影响上传结果
                logger.warning(f"上传成功后删除本地数据集 {dataset_type}:{repo_id} 失败: {del_e}")
        except Exception as e:
            logger.error(f"上传数据集 {repo_id} 失败: {e}", exc_info=True)
            results.append({"error": str(e)})

    return results


def ldp_precheck_upload_datasets(
    ldp_base_url: str,
    access_token: str,
    dataset_ids: List[Dict[str, str]],
    collection_device: Optional[str] = None,
    data_type: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    上传前预检查：查询 LDP 侧同名数据集，判断本次上传是否“可能覆盖”。

    说明：
    - LDP 的真实覆盖判定还会考虑 customer/device/collector 等条件；
    - 这里基于 datasetName(+dataType) 进行预检查，用于前端提前提示用户确认。
    """
    if collection_device is None or not str(collection_device).strip():
        collection_device = get_machine_code()
    else:
        collection_device = str(collection_device).strip()
    if data_type is None or not str(data_type).strip():
        data_type = DEFAULT_DATA_TYPE
    else:
        data_type = str(data_type).strip()

    base = ldp_base_url.rstrip("/")
    headers = {"Authorization": f"Bearer {access_token}"}
    results: List[Dict[str, Any]] = []

    for item in dataset_ids:
        repo_id = (item.get("repo_id") or "").strip()
        if not repo_id:
            results.append({"repo_id": "", "will_overwrite": False, "error": "缺少 repo_id"})
            continue
        try:
            resp = requests.get(
                f"{base}/api/datasets",
                headers=headers,
                params={
                    "datasetName": repo_id,
                    "page": 1,
                    "pageSize": 100,
                },
                timeout=20,
            )
            resp.raise_for_status()
            payload = resp.json() if resp.content else {}
            items_list = payload.get("items") if isinstance(payload, dict) else []
            if not isinstance(items_list, list):
                items_list = []

            candidates: List[Dict[str, Any]] = []
            for row in items_list:
                if not isinstance(row, dict):
                    continue
                row_name = str(row.get("name") or "").strip()
                row_type = str(row.get("dataType") or "").strip()
                # 预检查按“同名 + 同 data_type”匹配（更贴近真实覆盖条件）
                if row_name != repo_id:
                    continue
                if data_type and row_type and row_type.lower() != data_type.lower():
                    continue
                candidates.append(
                    {
                        "id": row.get("id"),
                        "name": row_name,
                        "dataType": row.get("dataType"),
                        "collectorAccount": row.get("collectorAccount"),
                        "collectionDevice": row.get("collectionDevice"),
                        "count": row.get("count"),
                        "size": row.get("size"),
                    }
                )

            results.append(
                {
                    "repo_id": repo_id,
                    "collection_device": collection_device,
                    "data_type": data_type,
                    "will_overwrite": len(candidates) > 0,
                    "matched_count": len(candidates),
                    "matched_items": candidates,
                }
            )
        except requests.RequestException as e:
            logger.warning("LDP precheck failed for %s: %s", repo_id, e)
            results.append(
                {
                    "repo_id": repo_id,
                    "collection_device": collection_device,
                    "data_type": data_type,
                    "will_overwrite": False,
                    "error": str(e),
                }
            )

    return results
