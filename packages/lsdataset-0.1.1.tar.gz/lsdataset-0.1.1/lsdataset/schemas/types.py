from typing import List, Optional

from pydantic import BaseModel, Field


class ConfigDatasetReq(BaseModel):
    """数据集配置请求"""
    fps: float
    robot_type: str
    features: dict
    root: Optional[str] = Field(None, description="数据集存储根目录")

class DatasetIdentifier(BaseModel):
    """数据集标识"""
    dataset_type: str = Field(..., description="数据集类型")
    repo_id: str = Field(..., description="仓库ID")

class StartRecordingReq(DatasetIdentifier):
    """开始记录数据集请求"""

class StopRecordingReq(BaseModel):
    """停止记录数据集请求"""
    abort: bool = Field(False, description="是否中止录制且不保存数据")


class DeleteDatasetReq(DatasetIdentifier):
    """删除数据集请求"""


class EpisodeIdentifier(DatasetIdentifier):
    """Episode标识"""
    episode_index: int = Field(..., description="要操作的episode索引")


class DeleteEpisodeReq(EpisodeIdentifier):
    """删除单个episode请求"""


class CommonOperationResp(BaseModel):
    """通用操作响应"""
    ok: bool = Field(True, description="操作是否成功")
    message: Optional[str] = Field(None, description="响应消息")

class DatasetsListResp(BaseModel):
    """数据集列表响应"""
    datasets: List[dict] = Field(..., description="数据集列表")


# LDP 代理相关


class LdpLoginReq(BaseModel):
    """LDP 登录代理请求"""
    ldp_base_url: str = Field(..., description="LDP 服务根地址，如 https://ldp.example.com")
    phone: str = Field(..., description="采集员手机号（LDP 登录账号）")
    password: str = Field(..., description="密码")


class LdpUploadDatasetItem(BaseModel):
    """单个要上传的数据集"""
    dataset_type: str = Field(default="lerobot_dataset", description="数据集类型")
    repo_id: str = Field(..., description="数据集 ID（目录名）")


class LdpUploadReq(BaseModel):
    """LDP 上传代理请求"""
    ldp_base_url: str = Field(..., description="LDP 服务根地址")
    access_token: str = Field(..., description="LDP 登录获得的 access_token")
    dataset_ids: List[LdpUploadDatasetItem] = Field(..., description="要上传的数据集列表")
    collection_device: Optional[str] = Field(None, description="采集设备，不填则从硬件（设备树/DMI）派生机器码")
    data_type: Optional[str] = Field(None, description="数据类型，不填则默认 lerobot")
    source: Optional[str] = Field(None, description="来源说明")


class LdpUploadPrecheckReq(BaseModel):
    """LDP 上传预检查请求（检查是否可能覆盖）"""
    ldp_base_url: str = Field(..., description="LDP 服务根地址")
    access_token: str = Field(..., description="LDP 登录获得的 access_token")
    dataset_ids: List[LdpUploadDatasetItem] = Field(..., description="要上传的数据集列表")
    collection_device: Optional[str] = Field(None, description="采集设备，不填则从硬件（设备树/DMI）派生机器码")
    data_type: Optional[str] = Field(None, description="数据类型，不填则默认 lerobot")