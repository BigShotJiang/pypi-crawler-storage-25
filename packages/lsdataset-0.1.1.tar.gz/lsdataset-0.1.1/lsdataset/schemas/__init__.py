"""Pydantic models for lsdataset HTTP API."""
