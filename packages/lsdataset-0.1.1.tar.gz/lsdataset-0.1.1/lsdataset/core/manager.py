import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
from scipy.spatial.transform import Rotation as R

from ..logger import logger
from ..schemas.types import ConfigDatasetReq
from .dataset import LEROBOT_HOME, LsRobotDataset


class RecordingState:
    def __init__(self):
        self.is_recording = False
        self.dataset_type = None
        self.repo_id = None
        self.is_aborting = False

    def start(self, dataset_type: str, repo_id: str):
        self.is_recording = True
        self.dataset_type = dataset_type
        self.repo_id = repo_id
        self.is_aborting = False

    def stop(self, abort: bool):
        self.is_recording = False
        self.dataset_type = None
        self.repo_id = None
        self.is_aborting = abort

class LsDatasetManager:
    MAX_ADD_FRAME_INTERVAL = 5.0  # seconds
    MAX_LOEADED_LIFETIME = 120.0  # seconds

    def __init__(self):
        self.dataset_config: Optional[ConfigDatasetReq] = None

        # 存放已经被加载的数据集，防止重复加载
        self.loaded_datasets: List[Dict[str, Any]] = [] # {'dataset_type': str, 'repo_id': str, 'dataset_obj': LsRobotDataset}
        self.recording_state = RecordingState()
        self.add_frame_callback: Optional[Callable] = None
        self._pika_last_end_effector_pose: Dict[str, np.ndarray] = {}

        self._lock = threading.Lock()

    @property
    def root(self) -> Optional[str]:
        """获取当前数据集存储根目录"""
        if self.dataset_config:
            return self.dataset_config.root
        return None

    @property
    def config_initialized(self) -> bool:
        """检查数据集配置是否已初始化"""
        return self.dataset_config is not None

    def config_dataset(self, config: ConfigDatasetReq) -> None:
        """配置数据集参数"""
        self.dataset_config = config

    def _reset_recording_transform_state(self) -> None:
        """重置录制期的帧转换状态。"""
        self._pika_last_end_effector_pose.clear()

    def _compute_relative_pika_pose(self, previous_pose: np.ndarray, current_pose: np.ndarray) -> np.ndarray:
        """将当前 xyzypr 位姿转换为以上一帧末端坐标系表达的相对位姿。"""
        previous_rotation = R.from_euler("ZYX", previous_pose[3:], degrees=False)
        current_rotation = R.from_euler("ZYX", current_pose[3:], degrees=False)

        relative_position = previous_rotation.inv().apply(current_pose[:3] - previous_pose[:3])
        relative_rotation = previous_rotation.inv() * current_rotation
        relative_ypr = relative_rotation.as_euler("ZYX", degrees=False)

        return np.concatenate([relative_position, relative_ypr]).astype(np.float32)

    def _transform_frame_for_recording(self, frame: dict) -> dict:
        """按 robot_type 转换录制帧。"""
        if self.dataset_config is None or self.dataset_config.robot_type != "pika":
            return frame

        transformed_frame = frame.copy()
        for key, value in frame.items():
            if not key.startswith("observation.state.arm.") or not key.endswith(".end_effector_pose"):
                continue

            current_pose = np.array(value, dtype=np.float32)
            if current_pose.size != 6:
                transformed_frame[key] = current_pose
                continue

            previous_pose = self._pika_last_end_effector_pose.get(key)
            if previous_pose is None:
                transformed_pose = np.zeros(6, dtype=np.float32)
            else:
                transformed_pose = self._compute_relative_pika_pose(previous_pose, current_pose)

            transformed_frame[key] = transformed_pose
            self._pika_last_end_effector_pose[key] = current_pose.copy()

        return transformed_frame

    def _recording_thread_loop(self, loaded_info: Dict[str, Any]) -> None:
        """录制线程循环，管理数据集的录制过程"""
        try:
            ds: LsRobotDataset = loaded_info['dataset_obj']
            last_update_time = time.time()
            def add_frame_callback(*args, **kwargs) -> None:
                nonlocal last_update_time
                ds.add_frame(*args, **kwargs)
                last_update_time = time.time()

            self.add_frame_callback = add_frame_callback

            logger.info("Recording thread loop started.")

            while self.recording_state.is_recording:
                if time.time() - last_update_time > self.MAX_ADD_FRAME_INTERVAL:
                    logger.warning("No frames added for a while, stopping recording.")
                    with self._lock:
                        self.recording_state.stop(abort=False)
                        self.add_frame_callback = None
                    break

                time.sleep(0.2)

            # 录制结束，保存数据集（无帧时跳过保存，避免 save_episode 抛错）
            if not self.recording_state.is_aborting:
                buf = ds.episode_buffer
                if buf is None or buf.size == 0:
                    logger.warning(
                        "录制结束但未写入任何帧，跳过保存。"
                        " 常见原因：各设备 is_latest_data_sample_ready 未就绪（例如机械臂姿态回调未注册），"
                        "或采集频率低于超时阈值。"
                    )
                    if buf is not None:
                        ds.clear_episode_buffer()
                else:
                    ds.save_episode()
                    logger.info(f"录制停止，数据集 {loaded_info['dataset_type']}:{loaded_info['repo_id']} 已保存。")
            else:
                ds.clear_episode_buffer()
                logger.info(f"录制中止，数据集 {loaded_info['dataset_type']}:{loaded_info['repo_id']} 未保存。")

            self.add_frame_callback = None
            self._reset_recording_transform_state()

            # 解除数据集加载
            with self._lock:
                self.loaded_datasets.remove(loaded_info)
            logger.info(f"数据集 {loaded_info['dataset_type']}:{loaded_info['repo_id']} 从内存中卸载。")

        except Exception as e:
            with self._lock:
                self.recording_state.stop(abort=True)
                self.add_frame_callback = None
                self._reset_recording_transform_state()
            logger.error(f"Error during recording: {e}", exc_info=True)

    def _is_in_use(self, dataset_type: str, repo_id: str, not_in_use_callback: Callable[[], None] = None) -> bool:
        """检查指定数据集是否正在被使用"""
        with self._lock:
            for info in self.loaded_datasets:
                if info.get('dataset_type') == dataset_type and info.get('repo_id') == repo_id:
                    return True

            if not_in_use_callback is not None:
                not_in_use_callback()

            return False

    def start_recording(self, dataset_type: str, repo_id: str) -> None:
        """开始记录数据集"""
        with self._lock:
            if self.recording_state.is_recording:
                raise RuntimeError(f"当前已有数据集 ({self.recording_state.dataset_type}: {self.recording_state.repo_id}) 在录制中，无法开始新的录制。")

            self.recording_state.start(dataset_type, repo_id)
            self._reset_recording_transform_state()

        try:
            # 此时已经保证没有数据集在录制，但可能有其他线程在处理数据集
            if self._is_in_use(dataset_type, repo_id):
                raise RuntimeError(f"{dataset_type} 数据集 {repo_id} 正在被使用，无法开始录制。")

            if LsRobotDataset.exists(dataset_type, repo_id):
                logger.info(f"加载 {dataset_type} 数据集 {repo_id} 进行录制。")
                dataset_obj = LsRobotDataset(repo_id=repo_id, clean_up_image=True) # 录制新数据集时需要尝试清理图片，以防出错
            else:
                if self.dataset_config is None:
                    raise RuntimeError("数据集配置未设置，请先调用 `/lsdataset/internal/config` 接口设置配置。")

                logger.info(f"创建新的 {dataset_type} 数据集 {repo_id} 进行录制。")
                dataset_obj = LsRobotDataset.create(
                    repo_id=repo_id,
                    fps=self.dataset_config.fps,
                    robot_type=self.dataset_config.robot_type,
                    features=self.dataset_config.features,
                    root=self.dataset_config.root,
                    clean_up_image=True
                )

            loaded_info = {'dataset_type': dataset_type, 'repo_id': repo_id, 'dataset_obj': dataset_obj}
            self.loaded_datasets.append(loaded_info)

        except Exception as e:
            with self._lock:
                self.recording_state.stop(abort=True)
            raise e

        threading.Thread(target=self._recording_thread_loop, args=(loaded_info,), daemon=True).start()

    def stop_recording(self, abort: bool = False) -> None:
        """停止记录数据集"""
        with self._lock:
            if not self.recording_state.is_recording:
                logger.warning("No recording in progress to stop.")
                return

            self.recording_state.stop(abort=abort)
            self._reset_recording_transform_state()

    def _use_dataset_decorator(func):
        """装饰器：确保在使用数据集时不会有并发冲突"""
        def wrapper(self: "LsDatasetManager", dataset_type: str, repo_id: str, *args, **kwargs):
            loaded_info = {'dataset_type': dataset_type, 'repo_id': repo_id}
            added = False

            # 检查是否在使用中，如果不在使用中则添加占位
            def callback():
                nonlocal added
                self.loaded_datasets.append(loaded_info)
                added = True
            if self._is_in_use(dataset_type, repo_id, not_in_use_callback=callback):
                raise RuntimeError(f"{dataset_type} 数据集 {repo_id} 正在被使用，无法进行操作。")

            try:
                return func(self, dataset_type, repo_id, *args, **kwargs)

            finally:
                # 确保移除占位
                if added:
                    self.loaded_datasets.remove(loaded_info)

        return wrapper

    @_use_dataset_decorator
    def delete_episode(self, dataset_type: str, repo_id: str, episode_index: int) -> None:
        """删除数据集中的指定 episode"""
        ds = LsRobotDataset(repo_id=repo_id, root=self.root, clean_up_image=True)
        ds.delete_episodes(episode_indices=[episode_index])

    @_use_dataset_decorator
    def delete_dataset(self, dataset_type: str, repo_id: str) -> None:
        """删除指定的数据集"""
        LsRobotDataset.delete(repo_id=repo_id, root=self.root, clean_up_image=True)

    def _get_datasets_details(self, dataset_type: str, repo_id: str, detail_keys: Optional[List[str]] = None) -> Dict[str, Any]:
        """获取指定数据集的详细信息"""
        dataset_info = {"id": repo_id}

        root_path = Path(self.root) if self.root else Path(LEROBOT_HOME)
        dataset_dir = root_path / repo_id

        # 检查数据集是否存在且有效
        try:
            exists = LsRobotDataset.exists(repo_id, root_path)
            open_error = None
            if exists:
                try:
                    ds = LsRobotDataset(repo_id=repo_id, root=root_path)
                except Exception as e:
                    open_error = str(e)
                    ds = None
            else:
                ds = None

            for key in (detail_keys or []):
                if key == "path":
                    dataset_info["path"] = str(dataset_dir.resolve())
                elif key == "exists":
                    dataset_info["exists"] = exists
                elif key == "type":
                    dataset_info["type"] = "lerobot_dataset"
                elif key == "open_error":
                    dataset_info["open_error"] = open_error
                elif ds is not None:
                    if key == "disk_size_bytes":
                        dataset_info["disk_size_bytes"] = ds.get_disk_size_bytes()
                    elif key == "num_frames":
                        dataset_info["num_frames"] = ds.total_frames
                    elif key == "num_episodes":
                        dataset_info["num_episodes"] = ds.total_episodes
                else:
                    if key == "disk_size_bytes":
                        dataset_info["disk_size_bytes"] = 0
                    elif key == "num_frames":
                        dataset_info["num_frames"] = 0
                    elif key == "num_episodes":
                        dataset_info["num_episodes"] = 0

        except Exception as e:
            logger.warning(f"Failed to load dataset {repo_id}: {e}")

        return dataset_info

    def list_datasets(self, dataset_type: str, detail_keys: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """列出指定类型的所有数据集"""

        datasets_list = []
        root_path = Path(self.root) if self.root else Path(LEROBOT_HOME)

        # 如果根目录不存在，返回空列表
        if not root_path.exists():
            return datasets_list

        try:
            # 遍历根目录下的所有文件夹
            for dataset_dir in root_path.iterdir():
                if not dataset_dir.is_dir():
                    continue

                repo_id = dataset_dir.name

                try:
                    dataset_info = self._get_datasets_details(dataset_type, repo_id, detail_keys)
                    datasets_list.append(dataset_info)
                except Exception as e:
                    logger.warning(f"Failed to load dataset {repo_id}: {e}")

        except Exception as e:
            logger.error(f"Error listing datasets: {e}", exc_info=True)

        # 按 ID 排序
        return sorted(datasets_list, key=lambda x: x.get("id", ""))

    def get_dataset_info(self, dataset_type: str, repo_id: str) -> Dict[str, Any]:
        """获取指定数据集的信息"""
        if not LsRobotDataset.exists(repo_id, root=self.root):
            raise RuntimeError(f"{dataset_type} 数据集 {repo_id} 不存在。")

        ds = LsRobotDataset(repo_id=repo_id, root=self.root)
        dataset_path = Path(self.root) / repo_id if self.root else Path(LEROBOT_HOME) / repo_id
        return {
            "id": repo_id,
            "path": str(dataset_path.resolve()),
            "exists": True,
            "type": dataset_type,
            "disk_size_bytes": ds.get_disk_size_bytes(),
            "num_frames": ds.total_frames,
            "num_episodes": ds.total_episodes,
            "videos": [{
                "episode_index": ep["episode_index"],
                "length": ds.get_video_length(ep["episode_index"]),
            } for ep in ds.episodes]
        }

    def get_episode_csv_and_columns(self, dataset_type: str, repo_id: str, episode_index: int) -> Tuple[str, List[Dict[str, Any]]]:
        """获取指定 episode 的 CSV 数据和列信息"""
        try:
            ds = LsRobotDataset(repo_id=repo_id, root=self.root)
            csv_str, columns = ds.get_episode_csv_and_columns(episode_index=episode_index)
            return csv_str, columns
        except IndexError:
            msg = f"Episode index {episode_index} out of range for dataset {repo_id}."
            logger.error(msg)
            raise RuntimeError(msg)
        except Exception as e:
            msg = f"Failed to get CSV data for episode {episode_index} in dataset {repo_id}: {e}"
            logger.error(msg, exc_info=True)
            raise RuntimeError(msg)

    def get_episode_data(self, dataset_type: str, repo_id: str, episode_index: int) -> Dict[str, Any]:
        """获取指定 episode 的可视化数据"""
        try:
            ds = LsRobotDataset(repo_id=repo_id, root=self.root)

            # 基本信息
            dataset_info = {
                "repo_id": repo_id,
                "num_frames": ds.total_frames,
                "num_episodes": ds.total_episodes,
                "fps": ds.fps,
            }

            # 视频列表（本地路径 → API URL）
            videos_info = []
            for key in ds.video_keys:
                api_url = f"/lsdataset/view/{dataset_type}/{repo_id}/{episode_index}/{key}.mp4"
                videos_info.append({"url": api_url, "filename": key})

            # 曲线数据
            csv_str, columns = ds.get_episode_csv_and_columns(episode_index=episode_index)

            return {
                "episode_id": episode_index,
                "dataset_info": dataset_info,
                "videos_info": videos_info,
                "episode_data_csv_str": csv_str,
                "columns": columns,
            }

        except IndexError:
            msg = f"Episode index {episode_index} out of range for dataset {repo_id}."
            logger.error(msg)
            raise RuntimeError(msg)
        except Exception as e:
            msg = f"Failed to get episode data for episode {episode_index} in dataset {repo_id}: {e}"
            logger.error(msg, exc_info=True)
            raise RuntimeError(msg)

    def get_episode_video(self, dataset_type: str, repo_id: str, episode_index: int, video_key: str) -> str:
        """获取指定 episode 的视频文件列表"""
        try:
            ds = LsRobotDataset(repo_id=repo_id, root=self.root)
            file = ds.root / str(ds._get_video_file(ep_index=episode_index, vid_key=video_key))
            if not file.exists():
                raise RuntimeError(f"Video file for key '{video_key}' in episode {episode_index} does not exist.")
            return str(file)

        except IndexError:
            msg = f"Episode index {episode_index} out of range for dataset {repo_id}."
            logger.error(msg)
            raise RuntimeError(msg)
        except Exception as e:
            msg = f"Failed to get episode videos for episode {episode_index} in dataset {repo_id}: {e}"
            logger.error(msg, exc_info=True)
            raise RuntimeError(msg)

manager = LsDatasetManager()

def add_frame(frame: dict, task: str, timestamp: float) -> None:
    if not manager.recording_state.is_recording:
        raise RuntimeError("No recording in progress to add frames.")
    elif manager.add_frame_callback is None: # 正在 recording，但回调未设置好
        logger.warning("Add frame callback has not been set yet, please wait.")
        return

    transformed_frame = manager._transform_frame_for_recording(frame)
    manager.add_frame_callback(transformed_frame, task, timestamp)