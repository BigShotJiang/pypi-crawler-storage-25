import csv
import os
import shutil
from io import StringIO
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import datasets
import numpy as np
import pandas as pd
import PIL.Image

from ..io.imwriter import AsyncImageWriter
from ..logger import logger
from ..io.utils import (CACHED_INFO_PATH, DEFAULT_FEATURES, DEFAULT_IMAGE_PATH,
                        EPISODES_PATH, INFO_PATH, TASKS_PATH,
                        create_empty_dataset_info, embed_images, get_dataset_mtime,
                        load_episodes, load_info, load_json, load_tasks,
                        validate_frame, write_episodes, write_info, write_json,
                        write_parquet, write_tasks)
from ..io.video_utils import StreamingVideoEncoder, split_video_by_frames

CODEBASE_VERSION = "v2.1"
LEROBOT_HOME = Path(os.getenv("LEROBOT_HOME", "~/.cache/huggingface/lerobot")).expanduser() / "lerobot_dataset"


def _int_from_env(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return int(raw)


def _default_image_writer_processes() -> int:
    return _int_from_env("LSDATASET_IMAGE_WRITER_PROCESSES", 4)


def _default_image_writer_threads() -> int:
    return _int_from_env("LSDATASET_IMAGE_WRITER_THREADS", 4)


class EpisodeBuffer:
    def __init__(self, episode_index: int, dataset_root: Path):
        # default features
        self.episode_index: int = episode_index
        self.timestamp: List[float] = []
        self.task: List[str] = []

        # custom features
        self.custom_features: Dict[str, List[Any]] = {}

        # 视频编码临时目录必须落在数据集根目录下，避免相对路径依赖进程 cwd 导致无权限或写到错误位置
        self.temp_video_dir: Path = dataset_root / "temp_videos" / f"episode_{episode_index:06d}"
        self.temp_video_dir.mkdir(parents=True, exist_ok=True)

    @property
    def size(self) -> int:
        return len(self.task)

    def save_to_parquet(self,
            path: Path,
            start_index: int,
            task_to_task_index: Dict[str, int],
            features: Dict[str, Dict[str, Any]],
            hf_features: datasets.Features
        ) -> None:
        episode_dict_keys = set(self.custom_features.keys()) & set(hf_features.keys())
        episode_dict = {key: self.custom_features[key] for key in episode_dict_keys}

        # default features
        size = self.size
        episode_dict["timestamp"] = np.array(self.timestamp, dtype=np.float32)
        episode_dict["frame_index"] = np.arange(size).astype(np.int64)
        episode_dict["episode_index"] = np.full((size,), self.episode_index, dtype=np.int64)
        episode_dict["index"] = np.arange(start_index, start_index + size).astype(np.int64)
        episode_dict["task_index"] = [task_to_task_index[t] for t in self.task]

        # 把 custom_features 转成 np
        for key, ft in features.items():
            if key in DEFAULT_FEATURES.keys():
                continue
            elif ft["dtype"] in ["image", "video"]:
                continue
            elif len(ft["shape"]) == 1 and ft["shape"][0] == 1:
                episode_dict[key] = np.array(episode_dict[key], dtype=ft["dtype"])
            elif len(ft["shape"]) == 1 and ft["shape"][0] > 1:
                episode_dict[key] = np.stack(episode_dict[key])
            else:
                raise ValueError(key)

        ep_dataset = datasets.Dataset.from_dict(episode_dict, features=hf_features, split="train")
        ep_dataset = embed_images(ep_dataset)
        path.parent.mkdir(parents=True, exist_ok=True)
        write_parquet(ep_dataset, path)


class LsRobotMetaBase:
    def __init__(self):
        self.info = {}
        self.tasks = []
        self.episodes = []

        # 在子类中初始化的变量
        self.root: Path

    @property
    def data_path(self) -> str:
        """Formattable string for the parquet files."""
        return self.info["data_path"]

    @property
    def video_path(self) -> str | None:
        """Formattable string for the video files."""
        return self.info["video_path"]

    @property
    def robot_type(self) -> str | None:
        """Robot type used in recording this dataset."""
        return self.info["robot_type"]

    @property
    def fps(self) -> int:
        """Frames per second used during data collection."""
        return self.info["fps"]

    @property
    def features(self) -> dict[str, dict]:
        """All features contained in the dataset."""
        return self.info["features"]

    @property
    def image_keys(self) -> list[str]:
        """Keys to access visual modalities stored as images."""
        return [key for key, ft in self.features.items() if ft["dtype"] == "image"]

    @property
    def video_keys(self) -> list[str]:
        """Keys to access visual modalities stored as videos."""
        return [key for key, ft in self.features.items() if ft["dtype"] == "video"]

    @property
    def camera_keys(self) -> list[str]:
        """Keys to access visual modalities (regardless of their storage method)."""
        return [key for key, ft in self.features.items() if ft["dtype"] in ["video", "image"]]

    @property
    def names(self) -> dict[str, list | dict]:
        """Names of the various dimensions of vector modalities."""
        return {key: ft["names"] for key, ft in self.features.items()}

    @property
    def shapes(self) -> dict:
        """Shapes for the different features."""
        return {key: tuple(ft["shape"]) for key, ft in self.features.items()}

    @property
    def total_episodes(self) -> int:
        """Total number of episodes available."""
        return self.info["total_episodes"]

    @property
    def total_frames(self) -> int:
        """Total number of frames saved in this dataset."""
        return self.info["total_frames"]

    @property
    def total_tasks(self) -> int:
        """Total number of different tasks performed in this dataset."""
        return self.info["total_tasks"]

    @property
    def total_chunks(self) -> int:
        """Total number of chunks (groups of episodes)."""
        return self.info["total_chunks"]

    @property
    def chunks_size(self) -> int:
        """Max number of episodes per chunk."""
        return self.info["chunks_size"]

    @property
    def task_to_task_index(self) -> dict:
        _mapping_dict = {}
        for d in self.tasks:
            _mapping_dict[d["task"]] = d["task_index"]
        return _mapping_dict

    @property
    def hf_features(self) -> datasets.Features:
        """Convert a LeRobot features dictionary to a `datasets.Features` object.

        Returns:
            datasets.Features: The corresponding Hugging Face `datasets.Features` object.

        Raises:
            ValueError: If a feature has an unsupported shape.
        """
        hf_features = {}
        for key, ft in self.features.items():
            if ft["dtype"] == "video":
                continue
            elif ft["dtype"] == "image":
                continue
            elif len(ft["shape"]) == 1:
                if ft["shape"][0] == 1:
                    hf_features[key] = datasets.Value(dtype=ft["dtype"])
                else:
                    hf_features[key] = datasets.Sequence(
                        length=ft["shape"][0], feature=datasets.Value(dtype=ft["dtype"])
                    )
            elif len(ft["shape"]) == 2:
                hf_features[key] = datasets.Array2D(shape=ft["shape"], dtype=ft["dtype"])
            elif len(ft["shape"]) == 3:
                hf_features[key] = datasets.Array3D(shape=ft["shape"], dtype=ft["dtype"])
            elif len(ft["shape"]) == 4:
                hf_features[key] = datasets.Array4D(shape=ft["shape"], dtype=ft["dtype"])
            elif len(ft["shape"]) == 5:
                hf_features[key] = datasets.Array5D(shape=ft["shape"], dtype=ft["dtype"])
            else:
                raise ValueError(f"Corresponding feature is not valid: {ft}")

        return datasets.Features(hf_features)

    def _get_episode_chunk(self, ep_index: int) -> int:
        return ep_index // self.chunks_size

    def _get_data_file(self, ep_index: int) -> Path:
        return Path(self.data_path.format(
            episode_chunk=self._get_episode_chunk(ep_index),
            episode_index=ep_index
        ))

    def _get_video_file(self, ep_index: int, vid_key: str) -> Path:
        return Path(self.video_path.format(
            episode_chunk=self._get_episode_chunk(ep_index),
            video_key=vid_key,
            episode_index=ep_index
        ))

    def _get_image_file(self, ep_index: int, image_key: str, frame_index: int) -> Path:
        return Path(DEFAULT_IMAGE_PATH.format(
            image_key=image_key, episode_index=ep_index, frame_index=frame_index
        ))

    def _get_image_dir(self, ep_index: int, image_key: str) -> Path:
        return self._get_image_file(ep_index, image_key, frame_index=0).parent

    def _load_meta(self) -> None:
        if not self.root.exists():
            raise FileNotFoundError(f"Dataset root directory {self.root} does not exist.")

        self.info = load_info(self.root)
        self.tasks = load_tasks(self.root)
        self.episodes = load_episodes(self.root)

    def _save_meta(self) -> None:
        if not self.root.exists():
            logger.warning(f"(_save_meta) Root directory {self.root} does not exist. Creating it.")
            self.root.mkdir(parents=True, exist_ok=True)

        write_info(self.info, self.root)
        write_tasks(self.tasks, self.root)
        write_episodes(self.episodes, self.root)


class LsRobotDataset(LsRobotMetaBase):
    def __init__(
        self,
        repo_id: str,
        root: Optional[Union[str, Path]] = None,
        tolerance_s: float = 1e-4,
        clean_up_image: bool = False,
        image_writer_processes: Optional[int] = None,
        image_writer_threads: Optional[int] = None,
    ):
        '''
        相比于 LeRobotDataset, LsRobotDataset 专注于数据集录制与数据处理, 提供灵活的数据访问和修改功能.
        数据集格式遵循 Codebase Version v2.1 规范. \n
        .                                       \n
        ├── data                                \n
        │   ├── chunk-000                       \n
        │   │   ├── episode_000000.parquet      \n
        │   │   ├── episode_000001.parquet      \n
        │   │   ├── episode_000002.parquet      \n
        │   │   └── ...                         \n
        │   ├── chunk-001                       \n
        │   │   ├── episode_001000.parquet      \n
        │   │   ├── episode_001001.parquet      \n
        │   │   ├── episode_001002.parquet      \n
        │   │   └── ...                         \n
        │   └── ...                             \n
        ├── meta                                \n
        │   ├── episodes.jsonl                  \n
        │   ├── info.json                       \n
        │   ├── stats.json                      \n
        │   └── tasks.jsonl                     \n
        └── videos                              \n
            ├── chunk-000                       \n
            │   ├── observation.images.laptop   \n
            │   │   ├── episode_000000.mp4      \n
            │   │   ├── episode_000001.mp4      \n
            │   │   ├── episode_000002.mp4      \n
            │   │   └── ...                     \n
            │   ├── observation.images.phone    \n
            │   │   ├── episode_000000.mp4      \n
            │   │   ├── episode_000001.mp4      \n
            │   │   ├── episode_000002.mp4      \n
            │   │   └── ...                     \n
            ├── chunk-001                       \n
            └── ...                             \n

        LsRobotDataset 提供了轻量级的数据集管理和录制功能, 对象的创建和初始化几乎不消耗资源.

        基本功能:
            - exists(repo_id: str, root: str | Path | None = None) -> bool:
              检查数据集是否存在.

            - check_meta(repo_id: str, root: str | Path | None = None, clean_up_image: bool = False) -> None:
              检查数据集完整性, 包括文件结构和 meta 信息.

            - create(repo_id: str, fps: int, features: dict, root: str | Path | None = None,
                     robot_type: str | None = None, use_videos: bool = True, tolerance_s: float = 1e-4,
                     clean_up_image: bool = False) -> "LsRobotDataset":
              创建一个新的 LsRobotDataset 实例. 如果数据集已经存在, 则比较 meta 信息, meta 若不匹配则抛出异常.

            - delete(repo_id: str, root: str | Path | None = None) -> None:
              删除整个数据集文件夹及其内容.

        信息获取接口:
            - get_disk_size_bytes() -> int:
              获取数据集占用的磁盘空间大小（字节）.

            - get_video_length(episode_index: int) -> float:
              获取指定 episode 的视频时长（秒）.

            - get_episode_csv_and_columns(episode_index: int) -> Tuple[str, List[Dict[str, Any]]]:
              获取指定 episode 的 CSV 数据字符串及列名元信息.

            - get_episode_task_indices(episode_index: int) -> List[int]:
              获取指定 episode 的任务索引列表.

        数据录制接口:
            - clear_episode_buffer(delete_images: bool = True) -> None:
              清空当前 episode 缓冲区, 可选择删除已保存的图像文件.

            - add_frame(frame: dict) -> None:
              将单帧数据添加到当前 episode 缓冲区.

            - save_episode(parallel_encoding: bool = True) -> None:
              将当前 episode 缓冲区的数据保存到数据集中.

        数据处理接口:
            - annotate_episode(episode_index: int, task: str) -> None:
              为指定 episode 添加任务标签.

            - split_episode(episode_index: int, start_time: float, end_time: float) -> None:
              将指定 episode 按时间范围分割成一个新的 episode.

            - delete_episodes(episode_indices: list[int]) -> None:
              删除指定的多个 episode.

            - delete_episode(episode_index: int) -> None:
              删除指定的单个 episode.

            - copy_episodes_to_dataset(self, episode_indices: List[int], dst_repo_id: str, dst_root: str | Path | None) -> LsRobotDataset
              将指定的多个 episode 复制到一个目标数据集中

        注意事项:
            - LsRobotDataset 不提供多线程资源访问保护机制, 因此在多线程环境下使用时, 需要用户自行确保线程安全.
        '''
        super().__init__()

        self.repo_id = repo_id
        self.root = Path(root) if root is not None else LEROBOT_HOME
        self.root = self.root / repo_id

        LsRobotDataset.check_meta(repo_id, root, clean_up_image)
        self._load_meta()

        self.tolerance_s = tolerance_s
        self.image_writer = None
        self.episode_buffer = None
        self.video_encoder = None
        self._image_writer_processes = (
            image_writer_processes
            if image_writer_processes is not None
            else _default_image_writer_processes()
        )
        self._image_writer_threads = (
            image_writer_threads
            if image_writer_threads is not None
            else _default_image_writer_threads()
        )

    # -------------------- 基本功能 -------------------- #
    @classmethod
    def exists(cls, repo_id: str, root: Optional[Union[str, Path]] = None) -> bool:
        """检查数据集是否存在.
        Args:
            repo_id (str): 数据集的仓库ID, 例如 "20260101_panda_dual_arm"
            root (str | Path | None): 数据集存储的根目录路径, 默认为 LEROBOT_HOME
        Returns:
            bool: 如果数据集存在则返回 True, 否则返回 False.
        """
        # 检查文件夹结构是否存在
        root_path = Path(root) if root is not None else LEROBOT_HOME
        dataset_path = root_path / repo_id
        if not dataset_path.exists():
            return False

        # 检查必要的 meta 文件是否存在
        if not (dataset_path / INFO_PATH).exists():
            return False
        if not (dataset_path / TASKS_PATH).exists():
            return False
        if not (dataset_path / EPISODES_PATH).exists():
            return False

        return True

    @classmethod
    def _cleanup_orphaned_images(
        cls, dataset_path: Path, info: Dict[str, Any], episodes: List[Dict[str, Any]]
    ) -> None:
        """检测并删除多余的 images 文件夹（断电等异常情况导致）.
        
        Args:
            dataset_path: 数据集路径
            info: 数据集 info.json 内容
            episodes: episodes.jsonl 内容列表
        """
        import re
        
        # 1. 从 episodes.jsonl 中提取所有有效的 episode_index
        valid_episode_indices = set()
        for ep in episodes:
            ep_idx = ep.get("episode_index")
            if ep_idx is not None:
                valid_episode_indices.add(ep_idx)
        
        # 2. 从 videos 文件夹中扫描所有存在的 episode_index（如果存在）
        video_episode_indices = set()
        video_path_template = info.get("video_path", "")
        
        if video_path_template:
            videos_dir = dataset_path / "videos"
            if videos_dir.exists() and videos_dir.is_dir():
                # 遍历所有 chunk 目录
                for chunk_dir in videos_dir.iterdir():
                    if chunk_dir.is_dir() and chunk_dir.name.startswith("chunk-"):
                        # 遍历所有 video_key 目录
                        for video_key_dir in chunk_dir.iterdir():
                            if video_key_dir.is_dir():
                                # 扫描该目录下的所有视频文件
                                for video_file in video_key_dir.glob("episode_*.mp4"):
                                    # 从文件名中提取 episode_index: episode_XXXXXX.mp4
                                    match = re.match(r"episode_(\d{6})\.mp4", video_file.name)
                                    if match:
                                        ep_idx = int(match.group(1))
                                        video_episode_indices.add(ep_idx)
        
        # 3. 从 images 文件夹中扫描所有存在的 episode_index
        images_dir = dataset_path / "images"
        image_episode_indices = set()
        
        if images_dir.exists() and images_dir.is_dir():
            # 遍历所有 image_key 目录
            for image_key_dir in images_dir.iterdir():
                if image_key_dir.is_dir():
                    # 扫描该目录下的所有 episode 文件夹
                    for episode_dir in image_key_dir.iterdir():
                        if episode_dir.is_dir():
                            # 从文件夹名中提取 episode_index: episode_XXXXXX
                            match = re.match(r"episode_(\d{6})", episode_dir.name)
                            if match:
                                ep_idx = int(match.group(1))
                                image_episode_indices.add(ep_idx)
        
        # 4. 找出多余的 episode_index（在 images 中存在，但在 episodes 和 videos 中都不存在）
        orphaned_episode_indices = image_episode_indices - valid_episode_indices - video_episode_indices
        
        if not orphaned_episode_indices:
            logger.info(f"(check_meta) 未发现多余的 images 文件夹")
            return
        
        logger.warning(
            f"(check_meta) 发现 {len(orphaned_episode_indices)} 个多余的 episode（在 images 中存在但不在 episodes.jsonl 和 videos 中）: {sorted(orphaned_episode_indices)}"
        )
        
        # 5. 删除这些多余的 images 文件夹
        deleted_folders = []
        for ep_idx in orphaned_episode_indices:
            # 遍历所有 image_key，删除对应的 episode 文件夹
            for image_key_dir in images_dir.iterdir():
                if image_key_dir.is_dir():
                    episode_dir = image_key_dir / f"episode_{ep_idx:06d}"
                    if episode_dir.exists() and episode_dir.is_dir():
                        try:
                            shutil.rmtree(episode_dir)
                            deleted_folders.append(str(episode_dir))
                            logger.info(f"(check_meta) 已删除多余的 images 文件夹: {episode_dir}")
                        except Exception as e:
                            logger.error(f"(check_meta) 删除文件夹失败 {episode_dir}: {e}")
        
        if deleted_folders:
            logger.info(f"(check_meta) 清理完成，共删除 {len(deleted_folders)} 个多余的 images 文件夹（涉及 {len(orphaned_episode_indices)} 个 episode）")

    @classmethod
    def check_meta(cls, repo_id: str, root: Optional[Union[str, Path]] = None, clean_up_image: bool = False) -> None:
        """检查数据集完整性, 包括文件结构和 meta 信息.

        Args:
            repo_id (str): 数据集的仓库ID, 例如 "20260101_panda_dual_arm"
            root (str | Path | None): 数据集存储的根目录路径, 默认为 LEROBOT_HOME

        Raises:
            FileNotFoundError: 如果数据集文件夹或必要的 meta 文件不存在.
            ValueError: 如果加载 meta 信息失败或 meta 信息不正确.
        """
        # 检查数据集是否存在
        if not cls.exists(repo_id, root):
            raise FileNotFoundError(f"Dataset '{repo_id}' does not exist in the specified root directory.")

        # 加载 meta 信息
        root_path = Path(root) if root is not None else LEROBOT_HOME
        dataset_path = root_path / repo_id

        try:
            info = load_info(dataset_path)
        except Exception as e:
            raise ValueError(f"Failed to load dataset info: {e}")

        try:
            tasks = load_tasks(dataset_path)
        except Exception as e:
            raise ValueError(f"Failed to load dataset tasks: {e}")

        try:
            episodes = load_episodes(dataset_path)
        except Exception as e:
            raise ValueError(f"Failed to load dataset episodes: {e}")

        # 检查 meta 信息的正确性
        empty_info = create_empty_dataset_info(
            codebase_version=CODEBASE_VERSION,
            fps=10,
            features={},
            use_videos=None,
            robot_type=""
        )
        for key in empty_info:
            if key not in info:
                raise ValueError(f"Dataset info is missing key: '{key}'.")

        # 检查 episodes
        if len(episodes) != info["total_episodes"]:
            raise ValueError(f"Dataset episodes count mismatch: info has {info['total_episodes']}, but loaded {len(episodes)}.")

        # 检测并删除多余的 images 文件夹（断电等异常情况导致）
        if clean_up_image:
            cls._cleanup_orphaned_images(dataset_path, info, episodes)

    @classmethod
    def create(cls,
            repo_id: str,
            fps: int,
            features: dict,
            root: str | Path | None = None,
            robot_type: str | None = None,
            use_videos: bool = True,
            tolerance_s: float = 1e-4,
            clean_up_image: bool = False,
            image_writer_processes: Optional[int] = None,
            image_writer_threads: Optional[int] = None,
        ) -> "LsRobotDataset":
        """创建一个新的 LsRobotDataset 实例. 如果数据集已经存在, 则比较 meta 信息, meta 若不匹配则抛出异常.

        Args:
            repo_id (str): 数据集的仓库ID, 例如 "20260101_panda_dual_arm"
            fps (int): 数据集的帧率
            features (dict): 数据集包含的特征字典
            root (str | Path | None): 数据集存储的根目录路径, 默认为 LEROBOT_HOME
            robot_type (str | None): 机器人类型, 可选
            use_videos (bool): 是否使用视频存储视觉数据, 默认为 True
            tolerance_s (float): 时间戳容差, 默认为 1e-4 秒

        Returns:
            LsRobotDataset: 创建或加载的数据集实例

        Raises:
            ValueError: 如果数据集已存在且 meta 信息不匹配
        """
        root = Path(root) if root is not None else LEROBOT_HOME

        # 处理数据集已存在的情况
        if cls.exists(repo_id, root):
            logger.warning(f"(create) Dataset '{repo_id}' already exists in the specified root directory.")
            cls.check_meta(repo_id, root, clean_up_image)

            # 判断 meta 信息是否匹配
            info = load_info(Path(root) / repo_id)
            for k, v in features.items():
                if k not in info["features"]:
                    raise ValueError(f"Feature '{k}' not found in existing dataset features.")
                feat = info["features"][k]
                if feat['dtype'] != v['dtype'] or tuple(feat['shape']) != tuple(v['shape']) or feat.get('names') != v.get('names'):
                    raise ValueError(f"Feature '{k}' does not match existing dataset feature. "
                                     f"Expected: {info['features'][k]}, Got: {v}")
            if info["fps"] != fps:
                raise ValueError(f"FPS does not match existing dataset FPS. "
                                 f"Expected: {info['fps']}, Got: {fps}")
            if info["robot_type"] != robot_type:
                raise ValueError(f"Robot type does not match existing dataset robot type. "
                                 f"Expected: {info['robot_type']}, Got: {robot_type}")

            # 返回已存在的数据集实例
            logger.info(f"(create) Meta check passed, Loading existing dataset '{repo_id}'.")
            return cls(
                repo_id=repo_id,
                root=root,
                tolerance_s=tolerance_s,
                clean_up_image=clean_up_image,
                image_writer_processes=image_writer_processes,
                image_writer_threads=image_writer_threads,
            )

        # 创建新数据集
        obj = cls.__new__(cls)
        obj.repo_id = repo_id
        obj.root = root / repo_id
        obj.tolerance_s = tolerance_s
        obj.image_writer = None
        obj.episode_buffer = None
        obj.video_encoder = None
        obj._image_writer_processes = (
            image_writer_processes
            if image_writer_processes is not None
            else _default_image_writer_processes()
        )
        obj._image_writer_threads = (
            image_writer_threads
            if image_writer_threads is not None
            else _default_image_writer_threads()
        )

        if features is None:
            raise ValueError(
                "Dataset features must either come from a Robot or explicitly passed upon creation."
            )

        for key in features:
            if "/" in key:
                raise ValueError(f"Feature names should not contain '/'. Found '/' in feature '{key}'.")

        features = {**features, **DEFAULT_FEATURES}

        obj.info = create_empty_dataset_info(
            codebase_version=CODEBASE_VERSION,
            fps=fps,
            features=features,
            use_videos=use_videos,
            robot_type=robot_type
        )
        obj.tasks = []
        obj.episodes = []
        if len(obj.video_keys) > 0 and not use_videos:
            raise ValueError()

        obj._save_meta()

        return obj

    @classmethod
    def delete(cls, repo_id: str, root: Optional[Union[str, Path]] = None, clean_up_image: bool = False) -> None:
        """删除整个数据集文件夹及其内容。clean_up_image 参数仅为兼容调用方，整目录删除时无需单独处理图片。"""
        _ = clean_up_image
        root_path = Path(root) if root is not None else LEROBOT_HOME
        dataset_path = root_path / repo_id
        if dataset_path.exists() and dataset_path.is_dir():
            shutil.rmtree(dataset_path)
            logger.info(f"Dataset '{repo_id}' has been deleted from '{root_path}'.")
        else:
            logger.warning(f"Dataset '{repo_id}' does not exist in '{root_path}'. Nothing to delete.")

    # -------------------- 信息获取接口 -------------------- #
    def _write_cached_info(self, cached_info: dict) -> None:
        """写入缓存的数据信息."""
        cached_info_path = self.root / CACHED_INFO_PATH
        cached_info_path.parent.mkdir(parents=True, exist_ok=True)
        write_json(cached_info, cached_info_path)

    def _load_cached_info(self) -> dict:
        """加载缓存的数据信息."""
        cached_info_path = self.root / CACHED_INFO_PATH
        if cached_info_path.exists():
            try:
                cached_info = load_json(cached_info_path)
                return cached_info
            except Exception as e:
                pass # 忽略缓存加载错误, 返回空字典
        return {}

    def get_disk_size_bytes(self) -> int:
        """获取数据集占用的磁盘空间大小（字节）."""

        # 尝试从缓存获取
        current_mtime = get_dataset_mtime(self.root)
        cached_info = self._load_cached_info()
        if "mtime" in cached_info and cached_info["mtime"] == current_mtime:
            if "disk_size_bytes" in cached_info:
                logger.info(f"缓存命中: {self.repo_id} 磁盘大小 {cached_info['disk_size_bytes']} bytes.")
                return cached_info["disk_size_bytes"]

        size_bytes = sum(f.stat().st_size for f in self.root.rglob("*") if f.is_file())
        logger.info(f"缓存未命中，计算得到: {self.repo_id} 磁盘大小 {size_bytes} bytes.")

        # 写入缓存
        cached_info = {"mtime": current_mtime, "disk_size_bytes": size_bytes}
        self._write_cached_info({**self._load_cached_info(), **cached_info})

        return size_bytes

    def get_video_length(self, episode_index: int) -> float:
        """获取指定 episode 的视频时长（秒）."""
        num_frames = self.episodes[episode_index]["length"]
        return num_frames / self.fps

    def get_episode_csv_and_columns(self, episode_index: int) -> Tuple[str, List[Dict[str, Any]]]:
        if not 0 <= episode_index < self.total_episodes:
            raise ValueError(f"Episode index {episode_index} is out of range. Must be between 0 and {self.total_episodes - 1}.")

        # 生成与 visualize_dataset_html.py 相似的 CSV 字符串与列名元信息，但仅针对本地数据集
        selected_columns = [col for col, ft in self.features.items() if ft["dtype"] == "float32"]
        if "timestamp" in selected_columns:
            selected_columns.remove("timestamp")

        # 列名信息
        columns: List[Dict[str, Any]] = []
        for column_name in selected_columns:
            dim = self.shapes[column_name][0]
            if "names" in self.features[column_name] and self.features[column_name]["names"]:
                column_names = self.features[column_name]["names"]
                while not isinstance(column_names, list):
                    column_names = list(column_names.values())[0]
            else:
                column_names = [f"motor_{i}" for i in range(dim)]
            columns.append({"key": column_name, "value": column_names})

        header = ["timestamp"] + [f"{name}_{i}" for name in selected_columns for i in range(self.shapes[name][0])]

        # 从 parquet 文件读取 episode 数据
        data_file_path = self.root / self._get_data_file(ep_index=episode_index)
        if not data_file_path.exists():
            raise ValueError(f"Data file for episode index {episode_index} does not exist: {data_file_path}")

        df = pd.read_parquet(data_file_path)

        # 选择需要的列
        columns_to_select = ["timestamp"] + selected_columns
        df_selected = df[columns_to_select]

        # 转换为 numpy 数组
        timestamps = np.expand_dims(df_selected["timestamp"].values, axis=1)
        stacks = [timestamps]
        for name in selected_columns:
            values = df_selected[name].values
            # 检查数据形状：如果 shape[0] > 1，说明是向量数据，需要堆叠
            dim = self.shapes[name][0]
            if dim > 1:
                # 向量数据：从 parquet 读取后可能是列表的列表，需要转换为二维数组
                if len(values) > 0 and isinstance(values[0], (list, np.ndarray)):
                    values = np.vstack([np.array(v) for v in values])
                else:
                    values = np.vstack(values)
            else:
                # 标量数据：扩展维度
                values = np.expand_dims(values, axis=1)
            stacks.append(values)
        rows = np.hstack(stacks).tolist()

        # 构造 CSV 字符串
        csv_buffer = StringIO()
        csv_writer = csv.writer(csv_buffer)
        csv_writer.writerow(header)
        csv_writer.writerows(rows)
        return csv_buffer.getvalue(), columns

    def get_episode_task_indices(self, episode_index: int) -> List[int]:
        if not 0 <= episode_index < self.total_episodes:
            raise ValueError(f"Episode index {episode_index} is out of range. Must be between 0 and {self.total_episodes - 1}.")

        data_file_path = self.root / self._get_data_file(ep_index=episode_index)
        if not data_file_path.exists():
            raise ValueError(f"Data file for episode index {episode_index} does not exist: {data_file_path}")

        df = pd.read_parquet(data_file_path)
        return df["task_index"].tolist()

    # -------------------- Image Writer -------------------- #
    def _start_image_writer(self) -> None:
        if isinstance(self.image_writer, AsyncImageWriter):
            logger.warning(
                "(_start_image_writer) You are starting a new AsyncImageWriter that is replacing an already existing one in the dataset."
            )

        self.image_writer = AsyncImageWriter(
            num_processes=self._image_writer_processes,
            num_threads=self._image_writer_threads,
        )

    def _wait_image_writer(self) -> None:
        """Wait for asynchronous image writer to finish."""
        if self.image_writer is not None:
            self.image_writer.wait_until_done()

    def _save_image(
        self, image: Union[np.ndarray, PIL.Image.Image],
        fpath: Path,
        compress_level: int = 1
    ) -> None:
        if self.image_writer is None:
            self._start_image_writer()

        self.image_writer.save_image(image=image, fpath=fpath, compress_level=compress_level)

    # -------------------- 数据录制接口 -------------------- #
    def _create_episode_buffer(self) -> EpisodeBuffer:
        # size and task are special cases that are not in self.features
        ep_buffer = EpisodeBuffer(episode_index=self.total_episodes, dataset_root=self.root)
        for key in self.features:
            if not key in DEFAULT_FEATURES.keys():
                ep_buffer.custom_features[key] = []
        return ep_buffer

    def clear_episode_buffer(self, delete_images: bool = True, delete_video_images: bool = True) -> None:
        if self.episode_buffer is None:
            logger.warning("(_clear_episode_buffer) No episode buffer to clear.")
            return

        # Wait for the async image writer to finish
        if self.image_writer is not None:
            self._wait_image_writer()

        episode_index = self.episode_buffer.episode_index
        if isinstance(episode_index, np.ndarray):
            episode_index = episode_index.item() if episode_index.size == 1 else episode_index[0]

        # Clean up image files for the current episode buffer
        if delete_images:
            for img_key in self.image_keys:
                img_dir = self.root / self._get_image_dir(episode_index, img_key)
                if img_dir.exists and img_dir.is_dir():
                    shutil.rmtree(img_dir)
            logger.info(f"(_clear_episode_buffer) Deleted images of episode {episode_index}: {self.image_keys} when clearing episode buffer.")

        if delete_video_images:
            for vid_key in self.video_keys:
                img_dir = self.root / self._get_image_dir(episode_index, vid_key)
                if img_dir.exists and img_dir.is_dir():
                    shutil.rmtree(img_dir)
            logger.info(f"(_clear_episode_buffer) Deleted video cached images of episode {episode_index}: {self.video_keys} when clearing episode buffer.")

        # Reset the buffer
        self.episode_buffer = None

    def add_frame(self, frame: dict, task: str, timestamp: float) -> None:
        """
        This function only adds the frame to the episode_buffer. Apart from images — which are written in a
        temporary directory — nothing is written to disk. To save those frames, the 'save_episode()' method
        then needs to be called.
        """

        validate_frame(frame, self.features)

        if self.episode_buffer is None:
            self.episode_buffer = self._create_episode_buffer()

            # 如果有视频需要录制，初始化视频编码器
            if self.video_keys:
                if self.video_encoder is not None:
                    logger.warning(
                        "You are creating a new episode buffer while an existing video encoder is still active. "
                        "This means that the video encoder will be reused for the new episode, which might not be what you intended."
                    )
                    self.video_encoder.close()
                    self.video_encoder = None

                self.video_encoder = StreamingVideoEncoder(fps=self.fps)
                self.video_encoder.start_episode(
                    video_keys=self.video_keys,
                    temp_dir=self.episode_buffer.temp_video_dir
                )

        # 自动处理 default features
        frame_index = self.episode_buffer.size
        self.episode_buffer.timestamp.append(timestamp)
        self.episode_buffer.task.append(task)

        # 添加 frame features
        for key in frame:
            # 图片和视频均不存入 parquet 文件中, 因此不添加到 custom_features
            if self.features[key]["dtype"] == "image":
                img_path = self.root / self._get_image_file(
                    ep_index=self.episode_buffer.episode_index, image_key=key, frame_index=frame_index
                )

                if not img_path.parent.exists():
                    img_path.parent.mkdir(parents=True, exist_ok=True)

                compress_level = 1 if self.features[key]["dtype"] == "video" else 6
                self._save_image(frame[key], img_path, compress_level)

            elif self.features[key]["dtype"] == "video":
                if self.video_encoder is not None:
                    self.video_encoder.feed_frame(video_key=key, image=frame[key])
                else:
                    self.video_encoder = StreamingVideoEncoder(fps=self.fps)
                    self.video_encoder.start_episode(
                        video_keys=self.video_keys,
                        temp_dir=self.episode_buffer.temp_video_dir
                    )
                    self.video_encoder.feed_frame(video_key=key, image=frame[key])
                    logger.warning(
                        "Video encoder was not initialized when feeding a video frame. "
                        "A new video encoder has been initialized and the frame has been fed to it, "
                        "but you should make sure to initialize the video encoder at the start of the episode to avoid potential issues."
                    )

            else:
                self.episode_buffer.custom_features[key].append(frame[key])

    def save_episode(self) -> None:
        """
        This will save to disk the current episode in self.episode_buffer.

        Video encoding is handled automatically based on batch_encoding_size:
        - If batch_encoding_size == 1: Videos are encoded immediately after each episode
        - If batch_encoding_size > 1: Videos are encoded in batches.
        """
        if self.episode_buffer is None:
            raise ValueError("No episode data to save. Please add frames using 'add_frame' before saving.")

        if self.episode_buffer.episode_index != self.total_episodes:
            raise NotImplementedError(
                "You might have manually provided the episode_buffer with an episode_index that doesn't "
                "match the total number of episodes already in the dataset. This is not supported for now."
            )

        if self.episode_buffer.size == 0:
            raise ValueError("You must add one or several frames with `add_frame` before calling `add_episode`.")

        # 检查 episode_buffer 中的 features 是否和 self.features 匹配
        buffer_keys = set(self.episode_buffer.custom_features.keys())
        feature_keys = set(self.features.keys()) - set(DEFAULT_FEATURES.keys())
        if buffer_keys != feature_keys:
            raise ValueError(
                f"Features from `episode_buffer` don't match the ones in `features`.\n"
                f"In episode_buffer not in features: {buffer_keys - feature_keys}\n"
                f"In features not in episode_buffer: {feature_keys - buffer_keys}"
            )

        episode_start_index = self.total_frames # 计算当前 episode 在整个数据集中的起始帧索引

        # 更新 info 信息
        self.info["total_episodes"] += 1
        self.info["total_frames"] += self.episode_buffer.size
        self.info["total_videos"] += len(self.video_keys)
        self.info["total_chunks"] = (self.info["total_episodes"] + self.chunks_size - 1) // self.chunks_size
        self.info["splits"] = {"train": f"0:{self.info['total_episodes']}"}

        # 更新 tasks 信息
        ep_tasks = list(set(self.episode_buffer.task))
        for task in ep_tasks:
            if task not in self.task_to_task_index:
                task_index = self.info["total_tasks"]
                self.info["total_tasks"] += 1
                self.tasks.append(
                    {"task_index": task_index, "task": task}
                )

        # 更新 episodes 信息
        self.episodes.append(
            {
                "episode_index": self.episode_buffer.episode_index,
                "tasks": ep_tasks,
                "length": self.episode_buffer.size,
            }
        )

        self._save_meta()

        # 保存数据
        data_file_path = self.root / self._get_data_file(ep_index=self.episode_buffer.episode_index)
        self.episode_buffer.save_to_parquet(
            path=data_file_path,
            start_index=episode_start_index,
            task_to_task_index=self.task_to_task_index,
            features=self.features,
            hf_features=self.hf_features
        )

        # 保存视频
        if self.video_keys and self.video_encoder is not None:
            encoded_videos = self.video_encoder.finish_episode()
            for key, video in encoded_videos.items():
                temp_video_path = Path(video[0])
                video_path = self.root / self._get_video_file(self.episode_buffer.episode_index, key)
                video_path.parent.mkdir(parents=True, exist_ok=True)
                temp_video_path.rename(video_path)
                logger.info(f"Saved video for episode {self.episode_buffer.episode_index}, video key '{key}': {video_path}")
            shutil.rmtree(self.episode_buffer.temp_video_dir)
            self.video_encoder = None

        # 保存图像
        self._wait_image_writer()

        # 清空 episode buffer
        self.clear_episode_buffer(delete_images=False, delete_video_images=True)

    # -------------------- 数据处理接口 -------------------- #
    def annotate_episode(self, episode_index: int, splits: List[float], tasks: List[str]) -> None:
        """为指定的 episode 添加任务标签.

        Args:
            episode_index (int): 要注释的 episode 的索引.
            splits (List[float]): 时间戳列表, 指定任务划分点.
            tasks (List[str]): 任务标签列表, 与 splits 对应.

        Raises:
            ValueError: 如果指定的 episode_index 不存在.
        """
        if episode_index < 0 or episode_index >= self.total_episodes:
            raise ValueError(f"Episode index {episode_index} is out of range.")

        # 验证 splits 和 tasks 的长度关系
        if len(splits) + 1 != len(tasks):
            raise ValueError(f"Length mismatch: len(splits)={len(splits)}, len(tasks)={len(tasks)}, expected len(tasks)=len(splits)+1")

        # 检查task是否已经存在, 若不存在则添加
        for task in tasks:
            task_index = self.task_to_task_index.get(task, None)
            if task_index is None:
                task_index = self.info["total_tasks"]
                self.info["total_tasks"] += 1
                self.tasks.append(
                    {"task_index": task_index, "task": task}
                )
                logger.info(f"(_annotate_episode) Added new task '{task}' with index {task_index}.")

        # 修改 episodes.jsonl 中的 tasks
        self.episodes[episode_index]["tasks"] = sorted(list(set(tasks)))

        self._save_meta()

        # 修改 .parquet 中的 task_index
        data_file_path = self.root / self._get_data_file(ep_index=episode_index)
        if not data_file_path.exists():
            raise ValueError(f"Data file for episode index {episode_index} does not exist.")

        df = pd.read_parquet(data_file_path)

        # 根据 splits 和 fps 计算分割的帧索引
        fps = float(self.fps)
        if fps <= 0:
            raise ValueError(f"Invalid fps: {fps}")

        split_indices = [int(split_time * fps) for split_time in splits]

        # 根据 tasks 为不同的分割区间赋值 task_index
        task_index_array = np.zeros(len(df), dtype=np.int64)
        if len(split_indices) > 0:
            for i, frame_idx in enumerate(split_indices):
                if i == 0:
                    task_index_array[:frame_idx] = self.task_to_task_index[tasks[0]]
                else:
                    task_index_array[split_indices[i - 1]:frame_idx] = self.task_to_task_index[tasks[i]]
            # 处理最后一个区间
            task_index_array[split_indices[-1]:] = self.task_to_task_index[tasks[-1]]
        else:
            # 如果没有 splits，整个 episode 使用第一个 task
            task_index_array[:] = self.task_to_task_index[tasks[0]]

        df["task_index"] = task_index_array
        df.to_parquet(data_file_path, index=False)

        logger.info(f"(_annotate_episode) Updated <episode {episode_index}> task_index ({len(splits)} splits, {len(tasks)} tasks)")

    def split_episode(self, episode_index: int, start_time: float, end_time: float, task: Optional[str] = None) -> None:
        """
        将指定 episode 按时间区间拆分为一个新的 episode（追加到数据集末尾）。

        - parquet: 直接用 pandas 切片并重写（不经过 json 中转）
        - image_keys: 同步迁移对应帧图片到新 episode
        - video_keys: 从原 mp4 拆帧 -> 迁移子区间帧到新 episode 临时目录 -> 重新编码 mp4 -> 删除临时文件
        - meta: 更新 info / episodes（可选覆盖 task）
        """
        if episode_index < 0 or episode_index >= self.total_episodes:
            raise ValueError(f"Episode index {episode_index} is out of range.")

        if start_time < 0:
            start_time = 0.0
            logger.warning(f"(_split_episode) start_time({start_time:.2f}) < 0, set to 0.0")

        if start_time >= end_time:
            logger.warning(f"(_split_episode) start_time({start_time:.2f}) >= end_time({end_time:.2f}), skipping split.")
            return

        fps = float(self.fps)
        if fps <= 0:
            raise ValueError(f"Invalid fps: {fps}")

        split_start_index = int(start_time * fps)
        split_end_index = int(end_time * fps)
        if split_start_index >= split_end_index:
            logger.warning(
                f"(_split_episode) Computed split_start_index({split_start_index}) >= split_end_index({split_end_index}), skipping split."
            )
            return

        # 1) 读取并切分 parquet
        src_parquet_path = self.root / self._get_data_file(ep_index=episode_index)
        if not src_parquet_path.exists():
            raise ValueError(f"Data file for episode index {episode_index} does not exist: {src_parquet_path}")

        df = pd.read_parquet(src_parquet_path)
        if split_end_index > len(df):
            raise ValueError("end_time out of range for this episode.")

        new_df = df.iloc[split_start_index:split_end_index].copy()
        new_len = len(new_df)
        if new_len <= 0:
            raise ValueError("Split result is empty.")

        # 新 episode index（追加）
        new_episode_index = int(self.total_episodes)
        new_episode_start_index = int(self.total_frames)

        # 重置默认列（如果存在就覆盖，不存在就创建）
        new_df["timestamp"] = (np.arange(new_len, dtype=np.float32) / np.float32(fps)).astype(np.float32)
        new_df["frame_index"] = np.arange(new_len, dtype=np.int64)
        new_df["episode_index"] = np.full((new_len,), new_episode_index, dtype=np.int64)
        new_df["index"] = np.arange(new_episode_start_index, new_episode_start_index + new_len, dtype=np.int64)

        # 覆盖 task
        if task is not None:
            task_index = self.task_to_task_index.get(task, None)
            if task_index is None:
                task_index = int(self.info["total_tasks"])
                self.info["total_tasks"] += 1
                self.tasks.append({"task_index": int(task_index), "task": task})
            new_df["task_index"] = int(task_index)

        dst_parquet_path = self.root / self._get_data_file(ep_index=new_episode_index)
        dst_parquet_path.parent.mkdir(parents=True, exist_ok=True)
        new_df.to_parquet(dst_parquet_path, index=False)

        logger.info(f"(_split_episode) parquet data split finished: [{split_start_index}, {split_end_index}) -> {new_len} frames.")

        # 2) 迁移 image_keys 的帧图片
        for img_key in self.image_keys:
            src_img_dir = self.root / self._get_image_dir(ep_index=episode_index, image_key=img_key)
            if not src_img_dir.exists() or not src_img_dir.is_dir():
                continue

            dst_img_dir = self.root / self._get_image_dir(ep_index=new_episode_index, image_key=img_key)
            dst_img_dir.mkdir(parents=True, exist_ok=True)

            # 逐帧拷贝并重编号
            for i in range(split_start_index, split_end_index):
                src_img = self.root / self._get_image_file(ep_index=episode_index, image_key=img_key, frame_index=i)
                if not src_img.exists():
                    continue
                dst_img = self.root / self._get_image_file(
                    ep_index=new_episode_index, image_key=img_key, frame_index=i - split_start_index
                )
                dst_img.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_img, dst_img)

        if self.image_keys:
            logger.info(f"(_split_episode) Image files split finished for keys: {self.image_keys}.")

        # 3) 处理 video_keys：拆帧 -> 迁移 -> 重编码 -> 清理
        for vid_key in self.video_keys:
            src_video_path = self.root / self._get_video_file(ep_index=episode_index, vid_key=vid_key)
            if not src_video_path.exists():
                continue

            # 新 episode 的视频帧临时目录（用于编码）
            dst_vid_frames_dir = self.root / self._get_image_dir(ep_index=new_episode_index, image_key=vid_key)
            dst_video_path = self.root / self._get_video_file(ep_index=new_episode_index, vid_key=vid_key)

            # 拆分视频
            split_video_by_frames(
                src_video_path=src_video_path,
                dst_video_path=dst_video_path,
                start_frame=split_start_index,
                end_frame=split_end_index,
                fps=self.fps,
                dst_frames_dir=dst_vid_frames_dir,
                cleanup_temp=True,
            )

            # 清理新 episode 的视频帧目录
            if dst_vid_frames_dir.exists():
                shutil.rmtree(dst_vid_frames_dir, ignore_errors=True)

        if self.video_keys:
            logger.info(f"(_split_episode) Video files split finished for keys: {self.video_keys}.")

        # 4) 更新 meta 并写回 parquet
        # episodes: 默认继承原 episode 的 tasks（如果没有传 task），否则用新 task
        if task is None:
            src_tasks = []
            try:
                src_tasks = list(self.episodes[episode_index].get("tasks", []))
            except Exception:
                src_tasks = []
            new_tasks = src_tasks
        else:
            new_tasks = [task]

        self.episodes.append(
            {
                "episode_index": new_episode_index,
                "tasks": new_tasks,
                "length": int(new_len),
            }
        )

        self.info["total_episodes"] += 1
        self.info["total_frames"] += int(new_len)
        self.info["total_videos"] += len(self.video_keys)
        self.info["total_chunks"] = (self.info["total_episodes"] + self.chunks_size - 1) // self.chunks_size
        self.info["splits"] = {"train": f"0:{self.info['total_episodes']}"}

        self._save_meta()

        logger.info(f"(_split_episode) Meta info updated after splitting episode.")

        logger.info(
            f"(_split_episode) Split episode {episode_index} [{start_time}s, {end_time}s) -> new episode {new_episode_index} "
            f"({new_len} frames)."
        )

    def delete_episodes(self, episode_indices: List[int]) -> None:
        """
        删除指定的多个 episode
        删除数据条有可能是因为数据错误，因此不论如何都要尽量保证删除成功，不能随便中断。

        删除操作包括：
        - 删除 parquet 数据文件
        - 删除视频文件
        - 删除图片目录（包括 image 和 video 的图片）
        - 从 episodes 列表中移除
        - 更新统计信息
        - 重命名后续 episode 的文件和目录，使索引连续
        - 更新所有后续 episode 的 parquet 文件中的 episode_index 字段

        Args:
            episode_indices: 要删除的 episode 索引列表

        Raises:
            ValueError: 如果 episode_indices 无效或删除后数据集为空
        """
        if not episode_indices:
            logger.warning("(_delete_episodes) No episode indices provided, nothing to delete.")
            return

        # 去重并排序
        episode_indices = list(sorted(set(episode_indices)))

        # 验证所有 episode_index
        valid_episode_indices = []
        for ep_idx in episode_indices:
            if ep_idx < 0 or ep_idx >= self.total_episodes:
                logger.warning(f"(_delete_episodes) Episode index {ep_idx} is out of range, skipping.")
            else:
                valid_episode_indices.append(ep_idx)

        # # 检查删除后是否还有剩余 episode
        # remaining_count = self.total_episodes - len(valid_episode_indices)
        # if remaining_count <= 0:
        #     logger.warning("(_delete_episodes) Deleting all episodes is not allowed, skipping deletion.")
        #     return

         # 允许删除全部 episode（包括仅有一条时删除最后一条），删除后数据集可为空
        if not valid_episode_indices:
            logger.warning("(_delete_episodes) No episode indices provided, nothing to delete.")
            return

        # 获取要删除的 episode 信息
        episodes_to_delete = {}
        total_deleted_frames = 0
        for ep in self.episodes:
            ep_idx = ep.get("episode_index")
            if ep_idx in valid_episode_indices:
                episodes_to_delete[ep_idx] = ep
                total_deleted_frames += ep.get("length", 0)

        if len(episodes_to_delete) != len(valid_episode_indices):
            missing = set(valid_episode_indices) - set(episodes_to_delete.keys())
            logger.warning(f"(_delete_episodes) Some episodes not found in episodes list: {missing}")

        logger.info(f"(_delete_episodes) Deleting {len(valid_episode_indices)} episodes: {valid_episode_indices} (total frames: {total_deleted_frames})")

        # 1) 删除所有指定 episode 的文件
        for ep_idx in valid_episode_indices:
            # 删除 parquet 文件
            parquet_path = self.root / self._get_data_file(ep_index=ep_idx)
            if parquet_path.exists():
                parquet_path.unlink()
                logger.debug(f"(_delete_episodes) Deleted parquet file: {parquet_path}")

            # 删除视频文件
            for vid_key in self.video_keys:
                video_path = self.root / self._get_video_file(ep_index=ep_idx, vid_key=vid_key)
                if video_path.exists():
                    video_path.unlink()
                    logger.debug(f"(_delete_episodes) Deleted video file: {video_path}")

            # 删除图片目录（包括 image 和 video 的图片）
            for key, value in self.features.items():
                if value.get("dtype") in ["image", "video"]:
                    image_dir = self.root / self._get_image_dir(ep_index=ep_idx, image_key=key)
                    if image_dir.exists() and image_dir.is_dir():
                        shutil.rmtree(image_dir)
                        logger.debug(f"(_delete_episodes) Deleted image directory: {image_dir}")

        logger.info(f"(_delete_episodes) Deleted files for episodes: {valid_episode_indices}")

        # 2) 从 episodes 列表中删除
        for ep_idx in valid_episode_indices:
            if ep_idx in episodes_to_delete:
                ep_info = episodes_to_delete[ep_idx]
                if ep_info in self.episodes:
                    self.episodes.remove(ep_info)

        # 3) 更新统计信息
        deleted_count = len(valid_episode_indices)
        self.info["total_episodes"] = max(0, self.info["total_episodes"] - deleted_count)
        self.info["total_frames"] = max(0, self.info["total_frames"] - total_deleted_frames)

        # 更新视频数量
        if "total_videos" in self.info:
            video_count_per_episode = len(self.video_keys)
            self.info["total_videos"] = max(0, self.info["total_videos"] - video_count_per_episode * deleted_count)

        # 更新 chunks
        self.info["total_chunks"] = (self.info["total_episodes"] + self.chunks_size - 1) // self.chunks_size

        # 更新 splits
        if self.info["total_episodes"] > 0:
            self.info["splits"] = {"train": f"0:{self.info['total_episodes']}"}
        else:
            self.info["splits"] = {"train": "0:0"}

        logger.info(f"(_delete_episodes) Updated dataset info after deletion.")

        # 4) 重命名后续 episode 的文件和目录，使索引连续，同时更新 parquet 文件中的 episode_index 字段
        changed_pairs = [[], []]
        for ep_idx in range(self.total_episodes):
            if self.episodes[ep_idx]["episode_index"] == ep_idx:
                continue

            old_idx = self.episodes[ep_idx]["episode_index"]
            new_idx = ep_idx

            # 重命名 parquet 文件并更新 episode_index 字段
            old_parquet_path = self.root / self._get_data_file(ep_index=old_idx)
            new_parquet_path = self.root / self._get_data_file(ep_index=new_idx)
            if old_parquet_path.exists():
                # 更新 parquet 文件中的 episode_index 字段
                df = pd.read_parquet(old_parquet_path)
                if "episode_index" in df.columns:
                    df["episode_index"] = new_idx
                    df.to_parquet(new_parquet_path, index=False)

                old_parquet_path.unlink()  # 删除旧文件

            # 重命名视频文件
            for vid_key in self.video_keys:
                old_video_path = self.root / self._get_video_file(ep_index=old_idx, vid_key=vid_key)
                new_video_path = self.root / self._get_video_file(ep_index=new_idx, vid_key=vid_key)
                if old_video_path.exists():
                    old_video_path.rename(new_video_path)

            # 重命名图片目录
            for key, value in self.features.items():
                if value.get("dtype") in ["image", "video"]:
                    old_image_dir = self.root / self._get_image_dir(ep_index=old_idx, image_key=key)
                    new_image_dir = self.root / self._get_image_dir(ep_index=new_idx, image_key=key)
                    if old_image_dir.exists() and old_image_dir.is_dir():
                        old_image_dir.rename(new_image_dir)

            # 更新 episodes 列表中的 episode_index
            self.episodes[ep_idx]["episode_index"] = new_idx
            logger.debug(f"(_delete_episodes) Updated episode_index in episodes list: {old_idx} -> {new_idx}")
            changed_pairs[0].append(old_idx)
            changed_pairs[1].append(new_idx)

        logger.info("(_delete_episodes) Renamed subsequent episodes to maintain continuous indices.")
        logger.info(f"(_delete_episodes) {changed_pairs[0]} ->")
        logger.info(f"(_delete_episodes) {changed_pairs[1]}")

        # 5) 保存更新后的 meta
        self._save_meta()

        logger.info(
            f"(_delete_episodes) Successfully deleted {len(episode_indices)} episodes: {episode_indices}. "
            f"Remaining episodes: {self.total_episodes}"
        )

    def delete_episode(self, episode_index: int) -> None:
        """删除指定的 episode.

        Args:
            episode_index (int): 要删除的 episode 的索引.

        Raises:
            ValueError: 如果指定的 episode_index 不存在.
        """
        self.delete_episodes([episode_index])

    def copy_episodes_to_dataset(self, episode_indices: List[int], dst_repo_id: str, dst_root: Optional[Union[str, Path]] = None) -> "LsRobotDataset":
        """
        将指定的多个 episode 拷贝到数据集。

        如果目标数据集不存在，会创建新数据集并复制源数据集的配置（info.json、tasks.jsonl）。
        如果目标数据集已存在，会将 episode 追加到现有数据集.

        Args:
            episode_indices: 要拷贝的 episode 索引列表
            dst_repo_id: 目标数据集的仓库ID
            dst_root: 目标数据集存储的根目录路径，默认为 LEROBOT_HOME

        Returns:
            LsRobotDataset: 目标数据集实例

        Raises:
            ValueError: 如果 episode_indices 无效或拷贝失败
        """
        if not episode_indices:
            raise ValueError("Episode indices list cannot be empty")

        # 去重并排序
        episode_indices = list(sorted(set(episode_indices)))

        # 验证所有 episode_index
        for ep_idx in episode_indices:
            if ep_idx < 0 or ep_idx >= self.total_episodes:
                raise ValueError(f"Episode index {ep_idx} is out of range (0-{self.total_episodes - 1})")

        # 构建目标数据集路径
        target_root = Path(dst_root) if dst_root is not None else LEROBOT_HOME

        # 处理目标数据集
        if LsRobotDataset.exists(dst_repo_id, target_root):
            logger.info(f"(_copy_episodes_to_dataset) Target dataset already exists: {dst_repo_id}, appending episodes")
            target_dataset = LsRobotDataset(
                repo_id=dst_repo_id,
                root=target_root,
                image_writer_processes=self._image_writer_processes,
                image_writer_threads=self._image_writer_threads,
            )
        else:
            logger.info(f"(_copy_episodes_to_dataset) Target dataset does not exist, creating new dataset: {dst_repo_id}")
            target_dataset = LsRobotDataset.create(
                repo_id=dst_repo_id,
                fps=self.fps,
                features=self.features,
                root=target_root,
                robot_type=self.robot_type,
                use_videos=len(self.video_keys) > 0,
                tolerance_s=self.tolerance_s,
                image_writer_processes=self._image_writer_processes,
                image_writer_threads=self._image_writer_threads,
            )

        # 获取目标数据集的起始 episode 索引
        target_episode_index_start = target_dataset.total_episodes

        # 逐个拷贝数据条
        copied_count = 0
        target_episode_index = target_episode_index_start
        total_frames = target_dataset.total_frames
        total_videos = target_dataset.info.get("total_videos", 0)

        for source_ep_idx in episode_indices:
            try:
                episode_info = self.episodes[source_ep_idx]
                if episode_info is None:
                    logger.warning(f"(_copy_episodes_to_dataset) Episode {source_ep_idx} info not found, skipping")
                    continue

                episode_length = episode_info.get("length", 0)

                # 获取源 episode 的 tasks（从 episodes.jsonl 或 parquet）
                source_tasks = episode_info.get("tasks", [])
                if not source_tasks:
                    logger.warning(f"(_copy_episodes_to_dataset) Episode {source_ep_idx} has no tasks in episodes.jsonl, trying to read from parquet")

                    # 如果 episodes.jsonl 中没有 tasks，尝试从 parquet 中读取
                    source_parquet = self.root / self._get_data_file(ep_index=source_ep_idx)
                    if source_parquet.exists():
                        df = pd.read_parquet(source_parquet)
                        if "task_index" in df.columns and len(df) > 0:
                            source_task_index = int(df["task_index"].iloc[0])
                            # 从源数据集的 tasks 中查找对应的 task
                            source_task = None
                            for task_item in self.tasks:
                                if task_item.get("task_index") == source_task_index:
                                    source_task = task_item.get("task")
                                    break
                            if source_task:
                                source_tasks = [source_task]

                # 处理 tasks：在目标数据集中添加不存在的 task，并建立映射关系
                target_tasks = []
                task_index_mapping = {}  # 源 task_index -> 目标 task_index

                for source_task in source_tasks:
                    # 检查目标数据集中是否存在该 task
                    target_task_index = target_dataset.task_to_task_index.get(source_task, None)
                    if target_task_index is None:
                        # 如果不存在，添加到目标数据集
                        target_task_index = target_dataset.info["total_tasks"]
                        target_dataset.info["total_tasks"] += 1
                        target_dataset.tasks.append(
                            {"task_index": target_task_index, "task": source_task}
                        )
                        logger.info(f"(_copy_episodes_to_dataset) Added new task '{source_task}' with index {target_task_index} to target dataset")

                    target_tasks.append(source_task)

                    # 建立 task_index 映射（从源数据集的 task_index 到目标数据集的 task_index）
                    source_task_index = self.task_to_task_index.get(source_task)
                    if source_task_index is not None:
                        task_index_mapping[source_task_index] = target_task_index

                # 拷贝 parquet 文件并更新 task_index
                source_parquet = self.root / self._get_data_file(ep_index=source_ep_idx)
                target_parquet = target_dataset.root / target_dataset._get_data_file(ep_index=target_episode_index)
                if source_parquet.exists():
                    target_parquet.parent.mkdir(parents=True, exist_ok=True)
                    # 读取源 parquet，更新 task_index，然后保存
                    df = pd.read_parquet(source_parquet)
                    if "task_index" in df.columns:
                        if task_index_mapping:
                            # 更新 task_index：将源数据集的 task_index 映射到目标数据集的 task_index
                            df["task_index"] = df["task_index"].map(
                                lambda x: task_index_mapping.get(int(x), int(x))
                            )
                        elif target_tasks:
                            # 如果 task_index_mapping 为空但 target_tasks 不为空，使用目标数据集的第一个 task_index
                            if len(target_tasks) > 0:
                                first_target_task = target_tasks[0]
                                target_task_index = target_dataset.task_to_task_index.get(first_target_task)
                                if target_task_index is not None:
                                    df["task_index"] = target_task_index
                    df.to_parquet(target_parquet, index=False)
                    logger.debug(f"(_copy_episodes_to_dataset) Copied and updated parquet: {source_ep_idx} -> {target_episode_index}")

                # 拷贝视频文件
                for vid_key in self.video_keys:
                    source_video = self.root / self._get_video_file(ep_index=source_ep_idx, vid_key=vid_key)
                    target_video = target_dataset.root / target_dataset._get_video_file(ep_index=target_episode_index, vid_key=vid_key)
                    if source_video.exists():
                        target_video.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source_video, target_video)
                        logger.debug(f"(_copy_episodes_to_dataset) Copied video: {vid_key}, {source_ep_idx} -> {target_episode_index}")

                # 拷贝图片目录
                for key, value in self.features.items():
                    if value.get("dtype") in ["image", "video"]:
                        source_img_dir = self.root / self._get_image_dir(ep_index=source_ep_idx, image_key=key)
                        target_img_dir = target_dataset.root / target_dataset._get_image_dir(ep_index=target_episode_index, image_key=key)
                        if source_img_dir.exists() and source_img_dir.is_dir():
                            if target_img_dir.exists():
                                shutil.rmtree(target_img_dir)
                            shutil.copytree(source_img_dir, target_img_dir)
                            logger.debug(f"(_copy_episodes_to_dataset) Copied image directory: {key}, {source_ep_idx} -> {target_episode_index}")

                # 更新目标数据集的 episode 信息
                new_episode_info = episode_info.copy()
                new_episode_info["episode_index"] = target_episode_index
                new_episode_info["tasks"] = target_tasks  # 使用目标数据集的 tasks

                # 追加到目标数据集的 episodes 列表
                target_dataset.episodes.append(new_episode_info)

                # 更新统计信息（暂存，稍后写入）
                total_frames += episode_length
                if "total_videos" in target_dataset.info:
                    video_count = len(self.video_keys)
                    total_videos += video_count

                target_episode_index += 1
                copied_count += 1

            except Exception as e:
                logger.error(f"(_copy_episodes_to_dataset) Failed to copy episode {source_ep_idx}: {e}", exc_info=True)
                # 继续拷贝其他数据条，不中断整个流程

        if copied_count == 0:
            raise ValueError("No episodes were successfully copied")

        # 所有文件拷贝完成，更新目标数据集的 info.json
        target_dataset.info["total_episodes"] = target_episode_index
        target_dataset.info["total_frames"] = total_frames
        if "total_videos" in target_dataset.info:
            target_dataset.info["total_videos"] = total_videos

        # 更新 chunks
        chunk_size = target_dataset.chunks_size
        target_dataset.info["total_chunks"] = (target_dataset.info["total_episodes"] + chunk_size - 1) // chunk_size

        # 更新 splits
        if target_dataset.info["total_episodes"] > 0:
            target_dataset.info["splits"] = {"train": f"0:{target_dataset.info['total_episodes']}"}
        else:
            target_dataset.info["splits"] = {"train": "0:0"}

        # 保存更新后的 meta
        target_dataset._save_meta()

        logger.info(
            f"(_copy_episodes_to_dataset) Successfully copied {copied_count}/{len(episode_indices)} episodes to dataset {dst_repo_id}. "
            f"Target dataset now has {target_dataset.total_episodes} episodes."
        )

        return target_dataset