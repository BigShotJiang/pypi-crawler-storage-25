"""Dataset domain (`LsRobotDataset`) and process-wide `LsDatasetManager`."""
