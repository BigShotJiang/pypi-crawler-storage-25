# lsdataset

独立仓库中的 **LeRobot 风格**数据集读写与（可选）`/lsdataset/*` FastAPI 路由。PyPI：[lsdataset](https://pypi.org/project/lsdataset/)。项目名与 **import 名**均为 **`lsdataset`**。

包根 `import lsdataset` **不会**预加载路由或 FastAPI；请显式导入，例如 `from lsdataset.api.routes import router`、`from lsdataset.core.manager import add_frame`。

## 安装

```bash
# 仅核心：数据集读写（LsRobotDataset、io 等）
pip install lsdataset

# FastAPI 路由与 LDP 所需 requests（与 LCP 后端一致）
pip install "lsdataset[all]"
# 或：pip install "lsdataset[server]"
```

Extras：`[ldp]` 仅加 `requests`；`[server]` / `[all]` 为 `fastapi` + `requests`。

从本仓库源码开发时可使用：

```bash
pip install -e ".[all]"
```

**版本单一来源**：`datasets` / `pyarrow` / `jsonlines` / `av`、`fastapi`、`pydantic`、`numpy`、`Pillow`、`requests` 等仅在 **`pyproject.toml`** 中声明。

异步图像写入并发度（默认 `4`）可通过环境变量覆盖：

- `LSDATASET_IMAGE_WRITER_PROCESSES`
- `LSDATASET_IMAGE_WRITER_THREADS`

## 测试

```bash
pip install -e ".[all,dev]"
make test
# 或：python -m pytest tests -q --tb=short
```

集成脚本（非 pytest）在 **`scripts/`**。

## 与 LCP（`ooo/lcp`）联调

LCP 一般从 PyPI 安装并在 `requirements.txt` 中 pin 版本（如 **`lsdataset[all]==…`**）。本地改包联调可将该行临时改为 editable（路径按本机调整），例如 `-e ../../../lsdataset[all]`。
