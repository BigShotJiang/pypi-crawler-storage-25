from decimal import Decimal, ROUND_HALF_UP

def calculate_proration(current_price: Decimal, new_price: Decimal, days_used: int, total_days: int) -> Decimal:
    """
    Calculates the prorated amount due when upgrading a plan.
    Uses Decimal for precise financial calculations to avoid floating point errors.
    """
    if days_used < 0 or total_days <= 0 or days_used > total_days:
        raise ValueError("Invalid days configuration")
        
    if new_price <= current_price:
        # For downgrades, we usually don't charge, we give credits (simplified here)
        return Decimal('0.00')
        
    days_remaining = total_days - days_used
    
    # Calculate daily rates
    current_daily_rate = current_price / Decimal(total_days)
    new_daily_rate = new_price / Decimal(total_days)
    
    # Value of unused time on old plan
    unused_value = current_daily_rate * Decimal(days_remaining)
    
    # Cost of remaining time on new plan
    new_cost = new_daily_rate * Decimal(days_remaining)
    
    # Amount due
    amount_due = new_cost - unused_value
    
    # Round to 2 decimal places (standard currency)
    return amount_due.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)