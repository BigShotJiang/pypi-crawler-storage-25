from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from decimal import Decimal
from datetime import datetime
from src.domain.billing_logic import calculate_proration

app = FastAPI(
    title="BillCycle API",
    description="Subscription & Usage-based Billing Engine",
    version="1.0.0"
)

class UpgradeRequest(BaseModel):
    subscription_id: str
    current_plan_price: Decimal
    new_plan_price: Decimal
    days_used: int
    total_days_in_cycle: int

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

@app.post("/api/v1/subscriptions/upgrade", tags=["Billing"])
async def upgrade_subscription(request: UpgradeRequest):
    """
    Calculate the prorated amount a user needs to pay when upgrading their plan mid-cycle.
    """
    try:
        prorated_charge = calculate_proration(
            current_price=request.current_plan_price,
            new_price=request.new_plan_price,
            days_used=request.days_used,
            total_days=request.total_days_in_cycle
        )
        
        return {
            "subscription_id": request.subscription_id,
            "prorated_charge": str(prorated_charge),
            "currency": "USD"
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))