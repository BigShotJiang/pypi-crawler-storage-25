# BillCycle: Subscription & Usage-based Billing Engine

**BillCycle** handles complex recurring billing, plan upgrades/downgrades, and usage metering for SaaS and subscription box e-commerce.

Developed by **Alireza Aminzadeh** ([@syeedalireza](https://github.com/syeedalireza)).

## Architecture
- **API:** FastAPI
- **Database:** PostgreSQL (SQLAlchemy)
- **Background Jobs:** Celery Beat
- **Pattern:** State Machine Pattern, Event Sourcing

*(Technical implementation pending in next iteration)*
