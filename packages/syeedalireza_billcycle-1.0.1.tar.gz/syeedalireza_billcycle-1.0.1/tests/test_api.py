import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app
import pytest_asyncio

@pytest_asyncio.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_upgrade_proration(async_client):
    payload = {
        "subscription_id": "SUB-123",
        "current_plan_price": 30.00, # $1/day for 30 days
        "new_plan_price": 60.00,     # $2/day for 30 days
        "days_used": 15,             # 15 days remaining
        "total_days_in_cycle": 30
    }
    
    # Old plan unused value: 15 days * $1 = $15
    # New plan cost for 15 days: 15 days * $2 = $30
    # Due: $30 - $15 = $15.00
    
    response = await async_client.post("/api/v1/subscriptions/upgrade", json=payload)
    assert response.status_code == 200
    assert response.json()["prorated_charge"] == "15.00"