"""Cairn.info XML converter."""

__version__ = "1.8.41"
