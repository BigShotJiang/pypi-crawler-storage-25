"""Tests for the session manager.

Unit tests mock the kernel and Hypha service, focusing on the session
lifecycle management, config persistence, and multi-session coordination.
"""

import json
import os
import shutil
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from safe_colab_cli.session_manager import (
    SessionConfig,
    SessionManager,
    SessionStatus,
    SESSIONS_DIR,
)


class TestSessionConfig:
    """Test SessionConfig dataclass."""

    def test_defaults(self):
        config = SessionConfig(id="abc123", name="test", env_name="default")
        assert config.status == SessionStatus.CREATED
        assert config.sandbox_backend == "auto"
        assert config.timeout == 120
        assert config.allow_shell is False
        assert config.allow_install is False

    def test_to_dict(self):
        config = SessionConfig(
            id="abc123",
            name="test",
            env_name="default",
            data_dir="/data",
        )
        d = config.to_dict()
        assert d["id"] == "abc123"
        assert d["data_dir"] == "/data"
        assert isinstance(d, dict)


class TestSessionManager:
    """Test session management without actually starting kernels."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="test-session-mgr-")
        self.sessions_dir = os.path.join(self.tmpdir, "sessions")
        self.envs_dir = os.path.join(self.tmpdir, "envs")
        os.makedirs(self.sessions_dir)
        os.makedirs(self.envs_dir)

        # Create a fake env
        self.fake_env_path = os.path.join(self.envs_dir, "test-env")
        os.makedirs(os.path.join(self.fake_env_path, "bin"))
        fake_python = os.path.join(self.fake_env_path, "bin", "python")
        with open(fake_python, "w") as f:
            f.write("#!/bin/sh\necho fake")
        os.chmod(fake_python, 0o755)
        # Write env metadata
        meta = {
            "name": "test-env",
            "path": self.fake_env_path,
            "python_version": "3.12",
            "packages": [],
            "channels": ["conda-forge"],
            "created_at": "",
            "size_mb": 0,
        }
        with open(os.path.join(self.fake_env_path, ".safe-colab-env.json"), "w") as f:
            json.dump(meta, f)

        # Patch the sessions dir
        self._sessions_dir_patch = patch(
            "safe_colab_cli.session_manager.SESSIONS_DIR", self.sessions_dir
        )
        self._sessions_dir_patch.start()

        # Create manager with mock env_manager
        from safe_colab_cli.env_manager import EnvManager

        self.env_mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=os.path.join(self.tmpdir, "bin"))
        self.mgr = SessionManager(env_manager=self.env_mgr)

    def teardown_method(self):
        self._sessions_dir_patch.stop()
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_create_session(self):
        config = self.mgr.create_session(name="Test Session", env_name="test-env")
        assert config.name == "Test Session"
        assert config.env_name == "test-env"
        assert config.status == SessionStatus.CREATED
        assert config.id
        assert os.path.isdir(config.work_dir)

    def test_create_session_with_data_dir(self):
        data_dir = os.path.join(self.tmpdir, "data")
        os.makedirs(data_dir)
        config = self.mgr.create_session(
            name="With Data", env_name="test-env", data_dir=data_dir
        )
        assert config.data_dir == os.path.abspath(data_dir)

    def test_create_session_bad_env(self):
        with pytest.raises(FileNotFoundError):
            self.mgr.create_session(name="Bad", env_name="nonexistent-env")

    def test_list_sessions(self):
        self.mgr.create_session(name="Session 1", env_name="test-env")
        self.mgr.create_session(name="Session 2", env_name="test-env")
        sessions = self.mgr.list_sessions()
        assert len(sessions) == 2
        names = {s.name for s in sessions}
        assert names == {"Session 1", "Session 2"}

    def test_get_session(self):
        config = self.mgr.create_session(name="Get Test", env_name="test-env")
        loaded = self.mgr.get_session(config.id)
        assert loaded.name == "Get Test"
        assert loaded.id == config.id

    def test_get_session_not_found(self):
        with pytest.raises(FileNotFoundError):
            self.mgr.get_session("nonexistent-id")

    def test_delete_session(self):
        config = self.mgr.create_session(name="To Delete", env_name="test-env")
        session_dir = os.path.join(self.sessions_dir, config.id)
        assert os.path.isdir(session_dir)

        self.mgr.delete_session(config.id)
        assert not os.path.isdir(session_dir)

    def test_delete_running_session_fails(self):
        config = self.mgr.create_session(name="Running", env_name="test-env")
        # Manually set status to running
        config.status = SessionStatus.RUNNING
        self.mgr._save_config(config)

        with pytest.raises(RuntimeError, match="running"):
            self.mgr.delete_session(config.id)

    def test_config_persistence(self):
        """Verify session config survives save/load cycle."""
        config = self.mgr.create_session(
            name="Persist Test",
            env_name="test-env",
            sandbox_backend="docker",
            allow_shell=True,
            timeout=300,
        )
        loaded = self.mgr._load_config(config.id)
        assert loaded.name == "Persist Test"
        assert loaded.sandbox_backend == "docker"
        assert loaded.allow_shell is True
        assert loaded.timeout == 300

    def test_list_sessions_marks_stale_running(self):
        """If a session says 'running' but no runtime exists, mark it stopped."""
        config = self.mgr.create_session(name="Stale", env_name="test-env")
        config.status = SessionStatus.RUNNING
        self.mgr._save_config(config)

        sessions = self.mgr.list_sessions()
        assert sessions[0].status == SessionStatus.STOPPED


class TestSessionManagerAsync:
    """Async tests for start/stop (mocked kernel and service)."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="test-session-async-")
        self.sessions_dir = os.path.join(self.tmpdir, "sessions")
        self.envs_dir = os.path.join(self.tmpdir, "envs")
        os.makedirs(self.sessions_dir)
        os.makedirs(self.envs_dir)

        # Create fake env
        fake_env = os.path.join(self.envs_dir, "test-env")
        os.makedirs(os.path.join(fake_env, "bin"))
        fake_python = os.path.join(fake_env, "bin", "python")
        with open(fake_python, "w") as f:
            f.write("#!/bin/sh\n")
        os.chmod(fake_python, 0o755)

        self._patches = [
            patch("safe_colab_cli.session_manager.SESSIONS_DIR", self.sessions_dir),
        ]
        for p in self._patches:
            p.start()

        from safe_colab_cli.env_manager import EnvManager
        self.env_mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=os.path.join(self.tmpdir, "bin"))
        self.mgr = SessionManager(env_manager=self.env_mgr)

    def teardown_method(self):
        for p in self._patches:
            p.stop()
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    @pytest.mark.asyncio
    async def test_stop_session(self):
        """Test stopping a session that was never started (edge case)."""
        config = self.mgr.create_session(name="Stop Test", env_name="test-env")
        config.status = SessionStatus.RUNNING
        self.mgr._save_config(config)

        result = await self.mgr.stop_session(config.id)
        assert result.status == SessionStatus.STOPPED

    @pytest.mark.asyncio
    async def test_stop_all_empty(self):
        """Test stop_all with no running sessions."""
        await self.mgr.stop_all()  # Should not raise
