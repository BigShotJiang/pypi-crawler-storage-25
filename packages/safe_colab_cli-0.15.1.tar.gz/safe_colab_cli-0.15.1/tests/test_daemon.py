"""Tests for the daemon JSON-RPC server.

Tests the HTTP API layer using aiohttp test client.
"""

import json
import os
import shutil
import tempfile
from unittest.mock import patch

import pytest

# aiohttp is optional — skip if not installed
pytest.importorskip("aiohttp")

from aiohttp import web
from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop


class TestDaemonHealth:
    """Basic daemon tests without aiohttp test server."""

    def test_daemon_imports(self):
        """Verify all daemon imports work."""
        from safe_colab_cli.daemon import Daemon, create_app, JsonRpcError

    def test_json_rpc_error(self):
        from safe_colab_cli.daemon import JsonRpcError
        err = JsonRpcError(-32601, "Method not found")
        assert err.code == -32601
        assert err.message == "Method not found"


@pytest.fixture
def daemon_app():
    """Create a test daemon app with temp directories."""
    tmpdir = tempfile.mkdtemp(prefix="test-daemon-")
    envs_dir = os.path.join(tmpdir, "envs")
    bin_dir = os.path.join(tmpdir, "bin")
    sessions_dir = os.path.join(tmpdir, "sessions")
    os.makedirs(envs_dir)
    os.makedirs(bin_dir)
    os.makedirs(sessions_dir)

    patches = [
        patch("safe_colab_cli.session_manager.SESSIONS_DIR", sessions_dir),
        patch("safe_colab_cli.env_manager.SAFE_COLAB_HOME", tmpdir),
        patch("safe_colab_cli.env_manager.ENVS_DIR", envs_dir),
        patch("safe_colab_cli.env_manager.BIN_DIR", bin_dir),
    ]
    for p in patches:
        p.start()

    from safe_colab_cli.daemon import Daemon, create_app
    from safe_colab_cli.env_manager import EnvManager
    from safe_colab_cli.session_manager import SessionManager

    env_mgr = EnvManager(envs_dir=envs_dir, bin_dir=bin_dir)
    session_mgr = SessionManager(env_manager=env_mgr)
    daemon = Daemon.__new__(Daemon)
    daemon.env_manager = env_mgr
    daemon.session_manager = session_mgr
    daemon._credentials = None
    daemon._event_subscribers = []

    app = create_app(daemon)

    yield app, tmpdir, envs_dir

    for p in patches:
        p.stop()
    shutil.rmtree(tmpdir, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_endpoint(daemon_app, aiohttp_client):
    app, tmpdir, envs_dir = daemon_app
    client = await aiohttp_client(app)
    resp = await client.get("/health")
    assert resp.status == 200
    data = await resp.json()
    assert data["status"] == "ok"


@pytest.mark.asyncio
async def test_rpc_env_list_empty(daemon_app, aiohttp_client):
    app, tmpdir, envs_dir = daemon_app
    client = await aiohttp_client(app)
    resp = await client.post(
        "/rpc",
        json={"jsonrpc": "2.0", "method": "env.list", "params": {}, "id": 1},
    )
    assert resp.status == 200
    data = await resp.json()
    assert data["result"] == []


@pytest.mark.asyncio
async def test_rpc_session_list_empty(daemon_app, aiohttp_client):
    app, tmpdir, envs_dir = daemon_app
    client = await aiohttp_client(app)
    resp = await client.post(
        "/rpc",
        json={"jsonrpc": "2.0", "method": "session.list", "params": {}, "id": 1},
    )
    assert resp.status == 200
    data = await resp.json()
    assert data["result"] == []


@pytest.mark.asyncio
async def test_rpc_unknown_method(daemon_app, aiohttp_client):
    app, tmpdir, envs_dir = daemon_app
    client = await aiohttp_client(app)
    resp = await client.post(
        "/rpc",
        json={"jsonrpc": "2.0", "method": "nonexistent.method", "params": {}, "id": 1},
    )
    assert resp.status == 200
    data = await resp.json()
    assert "error" in data
    assert data["error"]["code"] == -32601


@pytest.mark.asyncio
async def test_rpc_parse_error(daemon_app, aiohttp_client):
    app, tmpdir, envs_dir = daemon_app
    client = await aiohttp_client(app)
    resp = await client.post("/rpc", data=b"not json")
    assert resp.status == 400
    data = await resp.json()
    assert data["error"]["code"] == -32700


@pytest.mark.asyncio
async def test_rpc_session_create_bad_env(daemon_app, aiohttp_client):
    app, tmpdir, envs_dir = daemon_app
    client = await aiohttp_client(app)
    resp = await client.post(
        "/rpc",
        json={
            "jsonrpc": "2.0",
            "method": "session.create",
            "params": {"name": "Test", "env_name": "nonexistent"},
            "id": 1,
        },
    )
    data = await resp.json()
    assert "error" in data


@pytest.mark.asyncio
async def test_events_endpoint(daemon_app, aiohttp_client):
    """Test SSE events endpoint connects."""
    app, tmpdir, envs_dir = daemon_app
    client = await aiohttp_client(app)
    # Just verify the endpoint accepts connections
    resp = await client.get("/events")
    assert resp.status == 200
    assert "text/event-stream" in resp.headers.get("Content-Type", "")
    resp.close()
