#!/usr/bin/env python3
"""Test the full remote deploy + start + run_code flow.

Usage:
    python tests/test_remote_start.py [--app-id APP_ID]

Requires:
    - HYPHA_TOKEN env var or ~/.safe-colab/credentials.json
    - The app to be installed (default: safe-colab-test-patient-data)
"""
import asyncio
import os
import sys


async def main():
    from hypha_rpc import connect_to_server

    server_url = os.environ.get("HYPHA_SERVER_URL", "https://hypha.aicell.io")
    workspace = os.environ.get("HYPHA_WORKSPACE", "safe-colab")
    token = os.environ.get("HYPHA_TOKEN", "")
    app_id = sys.argv[1] if len(sys.argv) > 1 else "safe-colab-test-patient-data"

    if not token:
        import json, pathlib
        creds = pathlib.Path.home() / ".safe-colab" / "credentials.json"
        if creds.exists():
            token = json.loads(creds.read_text()).get("token", "")
    if not token:
        print("ERROR: No HYPHA_TOKEN found")
        sys.exit(1)

    print(f"Connecting to {server_url} (workspace: {workspace})...")
    server = await connect_to_server({
        "server_url": server_url,
        "workspace": workspace,
        "token": token,
    })

    server_apps = await server.get_service("public/server-apps")

    # Capture service URL from progress messages
    captured_url = {}

    def on_progress(update):
        msg = update.get("message", "")
        ptype = update.get("type", "info")
        prefix = {"info": "  ℹ", "success": "  ✓", "error": "  ✗"}.get(ptype, "  •")
        print(f"{prefix} {msg}")
        if "Service URL:" in msg:
            captured_url["url"] = msg.split("Service URL:")[-1].strip()

    print(f"\n{'='*60}")
    print(f"  Starting app: {app_id}")
    print(f"{'='*60}\n")

    try:
        result = await server_apps.start(
            app_id,
            timeout=600,
            wait_for_service=False,
            progress_callback=on_progress,
        )

        print(f"\n{'='*60}")
        print(f"  App started successfully!")
        if isinstance(result, dict):
            print(f"  Session: {result.get('session_id', result.get('id', '?'))}")
        print(f"{'='*60}")

        service_url = captured_url.get("url")
        if not service_url:
            print("\nNo service URL captured. The session may still be initializing.")
            await server.disconnect()
            return

        print(f"\nService URL: {service_url}")

        # Extract service name from URL
        # Format: https://hypha.aicell.io/<workspace>/services/<service-name>
        parts = service_url.rstrip("/").split("/services/")
        if len(parts) != 2:
            print(f"Could not parse service URL")
            await server.disconnect()
            return

        svc_name = parts[1]
        print(f"Connecting to safe-colab service: {svc_name}...")
        svc = await server.get_service(svc_name)

        # ── Test 1: Get skill document ───────────────────────────────
        print("\n--- Test 1: get_skill_md() ---")
        skill = await svc.get_skill_md()
        print(f"SKILL.md ({len(skill)} chars):")
        # Print first 10 lines
        for line in skill.splitlines()[:10]:
            print(f"  {line}")

        # ── Test 2: Run harmless code ────────────────────────────────
        print("\n--- Test 2: run_code('print(1+1)') ---")
        result = await svc.run_code("print(1+1)")
        print(f"Result: {result}")

        # ── Test 3: Run pandas code on the dataset ───────────────────
        print("\n--- Test 3: Load and describe dataset ---")
        result = await svc.run_code(
            "import pandas as pd\n"
            "import os\n"
            "files = os.listdir('/tmp/safe-colab-data')\n"
            "print(f'Files: {files}')\n"
            "csv_files = [f for f in files if f.endswith('.csv')]\n"
            "if csv_files:\n"
            "    df = pd.read_csv(f'/tmp/safe-colab-data/{csv_files[0]}')\n"
            "    print(f'Shape: {df.shape}')\n"
            "    print(f'Columns: {list(df.columns)}')\n"
            "    print(df.describe())\n"
        )
        print(f"Result: {result}")

        # ── Test 4: Test guardian blocks PII ──────────────────────────
        print("\n--- Test 4: Guardian should block PII access ---")
        result = await svc.run_code("print(df.head())")
        print(f"Result: {result}")

        print("\n" + "="*60)
        print("  All tests complete!")
        print("="*60)

    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        await server.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
