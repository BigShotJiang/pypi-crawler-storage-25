"""Tests for the environment manager.

These tests verify the EnvManager's ability to create, list, clone,
delete, and inspect conda environments via micromamba.

Note: Some tests require micromamba and network access to actually
create conda environments. Tests that require this are marked with
pytest.mark.slow and can be skipped in CI with: pytest -m "not slow"
"""

import json
import os
import shutil
import tempfile

import pytest

from safe_colab_cli.env_manager import EnvManager, EnvInfo, MICROMAMBA_URLS


# ── Unit tests (no micromamba needed) ──


class TestEnvManagerUnit:
    """Tests that don't require micromamba or network access."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="test-env-mgr-")
        self.envs_dir = os.path.join(self.tmpdir, "envs")
        self.bin_dir = os.path.join(self.tmpdir, "bin")
        os.makedirs(self.envs_dir)
        os.makedirs(self.bin_dir)

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_env_info_dataclass(self):
        info = EnvInfo(
            name="test",
            path="/tmp/test",
            python_version="3.12.0",
            packages=["numpy", "pandas"],
            channels=["conda-forge"],
        )
        d = info.to_dict()
        assert d["name"] == "test"
        assert d["packages"] == ["numpy", "pandas"]

    def test_list_envs_empty(self):
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        assert mgr.list_envs() == []

    def test_resolve_env_not_found(self):
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        with pytest.raises(FileNotFoundError):
            mgr._resolve_env("nonexistent")

    def test_save_and_load_env_meta(self):
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        env_path = os.path.join(self.envs_dir, "testenv")
        os.makedirs(env_path)
        info = EnvInfo(
            name="testenv",
            path=env_path,
            python_version="3.12",
            packages=["numpy"],
            channels=["conda-forge"],
            created_at="2024-01-01T00:00:00Z",
        )
        mgr._save_env_meta(info)

        loaded = mgr._load_env_meta("testenv")
        assert loaded is not None
        assert loaded.name == "testenv"
        assert loaded.packages == ["numpy"]

    def test_load_env_meta_missing(self):
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        env_path = os.path.join(self.envs_dir, "no-meta")
        os.makedirs(env_path)
        assert mgr._load_env_meta("no-meta") is None

    def test_dir_size_mb(self):
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        test_dir = os.path.join(self.tmpdir, "sized")
        os.makedirs(test_dir)
        with open(os.path.join(test_dir, "file.bin"), "wb") as f:
            f.write(b"x" * 1024 * 1024)  # 1 MB
        size = mgr._dir_size_mb(test_dir)
        assert 0.9 <= size <= 1.1

    def test_create_duplicate_raises(self):
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        env_path = os.path.join(self.envs_dir, "exists")
        os.makedirs(env_path)
        with pytest.raises(ValueError, match="already exists"):
            mgr.create("exists")

    def test_delete_removes_directory(self):
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        env_path = os.path.join(self.envs_dir, "to-delete")
        os.makedirs(env_path)
        # Write a file so it's non-empty
        with open(os.path.join(env_path, "dummy"), "w") as f:
            f.write("test")
        mgr.delete("to-delete")
        assert not os.path.exists(env_path)

    def test_micromamba_urls_all_platforms(self):
        """Verify we have download URLs for all major platforms."""
        assert ("darwin", "arm64") in MICROMAMBA_URLS
        assert ("darwin", "x86_64") in MICROMAMBA_URLS
        assert ("linux", "x86_64") in MICROMAMBA_URLS
        assert ("linux", "aarch64") in MICROMAMBA_URLS

    def test_find_python_candidates(self):
        """Test that _find_python finds Python in standard locations."""
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        env_path = os.path.join(self.envs_dir, "py-test")
        bin_path = os.path.join(env_path, "bin")
        os.makedirs(bin_path)

        # Create a fake python binary
        fake_python = os.path.join(bin_path, "python")
        with open(fake_python, "w") as f:
            f.write("#!/bin/sh\necho fake")
        os.chmod(fake_python, 0o755)

        found = mgr._find_python(env_path)
        assert found == fake_python

    def test_find_python_none(self):
        mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)
        env_path = os.path.join(self.envs_dir, "no-python")
        os.makedirs(env_path)
        assert mgr._find_python(env_path) is None


# ── Integration tests (require micromamba + network) ──


@pytest.mark.slow
class TestEnvManagerIntegration:
    """Tests that create real conda environments."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="test-env-int-")
        self.envs_dir = os.path.join(self.tmpdir, "envs")
        self.bin_dir = os.path.join(self.tmpdir, "bin")
        self.mgr = EnvManager(envs_dir=self.envs_dir, bin_dir=self.bin_dir)

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_micromamba_auto_install(self):
        """Test that micromamba is auto-installed."""
        path = self.mgr.micromamba
        assert os.path.isfile(path)
        assert os.access(path, os.X_OK)

    def test_create_and_list_env(self):
        """Test creating a minimal conda environment."""
        info = self.mgr.create("test-create", python_version="3.12")
        assert info.name == "test-create"
        assert os.path.isdir(info.path)
        assert self.mgr._find_python(info.path) is not None

        envs = self.mgr.list_envs()
        names = [e.name for e in envs]
        assert "test-create" in names

    def test_create_with_packages(self):
        """Test creating env with additional packages."""
        info = self.mgr.create(
            "test-pkgs", packages=["numpy"], python_version="3.12"
        )
        assert info.name == "test-pkgs"
        # Verify numpy is importable
        python = self.mgr.get_python("test-pkgs")
        import subprocess
        result = subprocess.run(
            [python, "-c", "import numpy; print(numpy.__version__)"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0

    def test_clone_env(self):
        """Test cloning an environment."""
        self.mgr.create("original", python_version="3.12")
        cloned = self.mgr.clone("original", "cloned")
        assert cloned.name == "cloned"
        assert os.path.isdir(cloned.path)
        assert self.mgr._find_python(cloned.path) is not None

    def test_get_info(self):
        """Test getting detailed environment info."""
        self.mgr.create("info-test", python_version="3.12")
        info = self.mgr.get_info("info-test")
        assert info.name == "info-test"
        assert "3.12" in info.python_version
        assert info.size_mb > 0

    def test_pip_install(self):
        """Test installing a package via pip."""
        self.mgr.create("pip-test", python_version="3.12")
        self.mgr.pip_install("pip-test", ["requests"])
        python = self.mgr.get_python("pip-test")
        import subprocess
        result = subprocess.run(
            [python, "-c", "import requests; print(requests.__version__)"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0
