# Safe Colab CLI

**Enable AI agents to analyze your sensitive data remotely — without ever copying it.**

A command-line tool that launches a sandboxed Python environment on your machine (or in the cloud), registers it as a remote service via [Hypha](https://hypha.aicell.io), and lets AI agents execute code through a guardian agent that enforces your sensitivity policy.

## Key Features

- **Guardian Agent** — LLM-powered security checks validate code before execution and output before return
- **Sensitivity Contract** — Define protected columns, minimum aggregation, and allowed operations in a README.md
- **Live Dashboard** — Web dashboard with real-time activity log and operation stats
- **Protected Audit Logs** — Full audit trail in `~/.safe-colab/logs/`, protected from sandboxed code
- **Sandbox Isolation** — nono (macOS/Linux) or Docker restricts kernel filesystem access
- **Remote Hosting** — Upload dataset once, cloud pods spin up on demand (no laptop needed)
- **Zero Config for Agents** — Agents call `get_skill_md` via curl to learn the API. No SDK, no token needed.

## Quick Start

### Local Mode (data stays on your machine)

```bash
pip install safe-colab-cli
safe-colab login
safe-colab start --data-dir ./my-data --guardian-url http://safe-colab-guardian.hypha.aicell.io
```

### Remote Mode (upload once, pods on demand)

```bash
pip install safe-colab-cli
safe-colab login
safe-colab deploy --data-dir ./my-data --guardian-url http://safe-colab-guardian.hypha.aicell.io
# → Uploads dataset, registers app. Share the App ID with your AI agent.
# → Pods spin up automatically when an agent calls start().
```

## Documentation

See the [docs site](https://aicell-lab.github.io/safe-colab-cli/) or the [GitHub project](https://github.com/aicell-lab/safe-colab-cli) for full documentation.

## License

Copyright 2024-2026 Amun AI AB. All rights reserved.

This software is proprietary and confidential. No part of this software may be reproduced, distributed, or transmitted in any form or by any means without the prior written permission of Amun AI AB. Unauthorized copying, modification, distribution, or use of this software is strictly prohibited.
