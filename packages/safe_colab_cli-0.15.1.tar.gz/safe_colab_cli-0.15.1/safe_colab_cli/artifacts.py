"""Artifact manager integration for file sharing, logging, and auditing.

Creates a collection per user and a child artifact per session.
Files (plots, results, large datasets) are uploaded to the artifact manager
and shared via presigned URLs - no data copying needed.
"""

import os
import time
import json
import secrets
import logging
from datetime import datetime, timezone
from typing import Optional

import httpx

logger = logging.getLogger("safe_colab_cli.artifacts")

COLLECTION_ALIAS = "safe-colab-sessions"


class SessionArtifactManager:
    """Manages artifacts for a single safe-colab session.

    Creates a collection (if needed) and a session artifact within it.
    Provides upload/download via presigned URLs and audit logging.
    """

    def __init__(self, artifact_manager, session_id: str, workspace: str, server_url: str = "https://hypha.aicell.io"):
        self._am = artifact_manager
        self.session_id = session_id
        self.workspace = workspace
        self.server_url = server_url.rstrip("/")
        self.collection_id = None
        self.artifact_id = None
        self.artifact_alias = None
        self.view_base_url = None
        self._log_buffer = []

    async def initialize(self):
        """Create the collection (idempotent) and session artifact."""
        # Ensure collection exists
        try:
            collection = await self._am.read(artifact_id=COLLECTION_ALIAS)
            self.collection_id = collection["id"]
        except Exception:
            collection = await self._am.create(
                type="collection",
                alias=COLLECTION_ALIAS,
                manifest={
                    "name": "Safe Colab Sessions",
                    "description": "Collection of safe-colab session artifacts for auditing and file sharing",
                },
                config={
                    "permissions": {"*": "r", "@": "rw+"},
                },
                stage=True,
            )
            self.collection_id = collection["id"]
            try:
                await self._am.commit(self.collection_id)
            except Exception:
                pass  # Already committed or no staging needed

        # Create session artifact with static hosting enabled
        self.artifact_alias = f"session-{self.session_id}"
        artifact = await self._am.create(
            type="dataset",
            alias=self.artifact_alias,
            parent_id=self.collection_id,
            manifest={
                "name": f"Session {self.session_id[:8]}",
                "description": f"Safe Colab session started at {datetime.now(timezone.utc).isoformat()}",
                "session_id": self.session_id,
                "created_at": datetime.now(timezone.utc).isoformat(),
            },
            config={
                "permissions": {"*": "r", "@": "rw+"},
                "view_config": {
                    "templates": [],
                },
            },
            stage=True,
        )
        self.artifact_id = artifact["id"]
        self.view_base_url = f"{self.server_url}/{self.workspace}/view/{self.artifact_alias}"
        logger.info(f"Session artifact created: {self.artifact_id}")
        logger.info(f"View URL: {self.view_base_url}/")

        # Write initial audit log entry
        await self.log_event("session_start", {"session_id": self.session_id})

    async def upload_file(self, local_path: str, remote_path: Optional[str] = None) -> dict:
        """Upload a file and return a permanent view URL.

        The file is uploaded to the session artifact which has static hosting
        enabled. The returned URL renders in the browser (HTML/images) rather
        than triggering a download.

        Args:
            local_path: Local file path to upload.
            remote_path: Path within the artifact (defaults to filename).

        Returns:
            Dict with 'view_url' (permanent, renders in browser) and
            'download_url' (presigned S3, expires in 1h).
        """
        if remote_path is None:
            remote_path = os.path.basename(local_path)

        # Re-enter staging mode if already committed (allows multiple uploads)
        try:
            await self._am.edit(artifact_id=self.artifact_id, stage=True)
        except Exception:
            pass  # May already be in staging

        put_url = await self._am.put_file(self.artifact_id, file_path=remote_path)

        async with httpx.AsyncClient() as client:
            with open(local_path, "rb") as f:
                resp = await client.put(put_url, content=f.read())
                resp.raise_for_status()

        # Commit so the file is visible via /view/
        try:
            await self._am.commit(self.artifact_id)
        except Exception:
            pass  # May already be committed

        view_url = f"{self.view_base_url}/{remote_path}"
        download_url = await self._am.get_file(self.artifact_id, file_path=remote_path)

        await self.log_event("file_upload", {
            "local_path": local_path,
            "remote_path": remote_path,
            "size_bytes": os.path.getsize(local_path),
            "view_url": view_url,
        })

        return {"view_url": view_url, "download_url": download_url}

    async def upload_bytes(self, data: bytes, remote_path: str, content_type: str = "application/octet-stream") -> str:
        """Upload raw bytes and return a presigned download URL."""
        put_url = await self._am.put_file(self.artifact_id, file_path=remote_path)

        async with httpx.AsyncClient() as client:
            resp = await client.put(put_url, content=data, headers={"Content-Type": content_type})
            resp.raise_for_status()

        get_url = await self._am.get_file(self.artifact_id, file_path=remote_path)

        await self.log_event("bytes_upload", {
            "remote_path": remote_path,
            "size_bytes": len(data),
            "content_type": content_type,
        })

        return get_url

    async def get_download_url(self, remote_path: str) -> str:
        """Get a presigned download URL for an existing file."""
        return await self._am.get_file(self.artifact_id, file_path=remote_path)

    async def list_files(self) -> list:
        """List all files in the session artifact."""
        return await self._am.list_files(self.artifact_id)

    async def log_event(self, event_type: str, details: dict):
        """Append an audit log entry to the session artifact."""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": event_type,
            **details,
        }
        self._log_buffer.append(entry)

        # Write log file
        log_content = "\n".join(json.dumps(e) for e in self._log_buffer) + "\n"
        try:
            try:
                await self._am.edit(artifact_id=self.artifact_id, stage=True)
            except Exception:
                pass
            put_url = await self._am.put_file(self.artifact_id, file_path="audit_log.jsonl")
            async with httpx.AsyncClient() as client:
                await client.put(put_url, content=log_content.encode())
        except Exception as e:
            logger.warning(f"Failed to write audit log: {e}")

    async def log_code_execution(self, code: str, result: dict):
        """Log a code execution event for auditing."""
        await self.log_event("code_execution", {
            "code_length": len(code),
            "code_preview": code[:200] + ("..." if len(code) > 200 else ""),
            "has_error": result.get("error") is not None,
            "stdout_length": len(result.get("stdout", "")),
        })

    async def log_command_execution(self, command: str, result: dict):
        """Log a shell command execution event."""
        await self.log_event("command_execution", {
            "command": command[:200],
            "returncode": result.get("returncode"),
        })

    async def commit(self, version: Optional[str] = None):
        """Commit the session artifact (makes files permanent)."""
        await self._am.commit(
            self.artifact_id,
            version=version,
            comment=f"Session {self.session_id[:8]} committed",
        )
        logger.info(f"Session artifact committed: {self.artifact_id}")
