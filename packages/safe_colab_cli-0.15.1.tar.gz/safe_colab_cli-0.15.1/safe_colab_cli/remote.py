"""Remote dataset hosting: upload to Hypha Artifact Manager, install as server app.

Flow:
  1. safe-colab upload --data-dir ./data --name my-dataset
     → uploads data to artifact collection 'safe-colab-datasets'
     → installs Hypha server app with type='safe-colab-runner'

  2. SafeColabRunnerWorker (running in guardian agent pod) sees the app
     → calls Agent Sandbox API to spin up a K8s pod
     → pod downloads dataset, runs safe-colab start, registers Hypha service
"""

import os
import logging
from pathlib import Path
from typing import Optional, Callable

import httpx

logger = logging.getLogger("safe_colab_cli.remote")

DATASETS_COLLECTION_ALIAS = "safe-colab-datasets"

# Files/dirs to skip when uploading
_SKIP_NAMES = {".git", "__pycache__", ".DS_Store", "node_modules", ".venv", ".safe-colab"}
_SKIP_EXTENSIONS = {".pyc", ".pyo"}


def _should_skip(name: str, is_dir: bool = False) -> bool:
    if name.startswith(".") and name not in (".env",):
        return True
    if name in _SKIP_NAMES:
        return True
    if not is_dir:
        _, ext = os.path.splitext(name)
        if ext in _SKIP_EXTENSIONS:
            return True
    return False


def _collect_files(data_dir: str) -> list[tuple[str, str]]:
    """Walk data_dir, return list of (local_path, relative_path).

    Skips hidden files (except .env), __pycache__, .git, etc.
    """
    result = []
    abs_data = os.path.abspath(data_dir)

    for root, dirs, files in os.walk(abs_data):
        dirs[:] = [d for d in dirs if not _should_skip(d, is_dir=True)]
        for fname in sorted(files):
            if _should_skip(fname):
                continue
            local_path = os.path.join(root, fname)
            rel = os.path.relpath(local_path, abs_data)
            result.append((local_path, rel.replace(os.sep, "/")))

    return result


async def _upload_file_presigned(
    artifact_manager,
    artifact_id: str,
    local_path: str,
    remote_path: str,
) -> int:
    """Upload one file to artifact storage using a presigned PUT URL.

    Streams the file in 8MB chunks for memory efficiency.
    Returns the number of bytes uploaded.
    """
    file_size = os.path.getsize(local_path)

    put_url = await artifact_manager.put_file(
        artifact_id=artifact_id,
        file_path=remote_path,
    )
    if not put_url or not isinstance(put_url, str):
        raise RuntimeError(f"put_file returned invalid URL for {remote_path}: {put_url}")

    async with httpx.AsyncClient(timeout=600) as client:
        with open(local_path, "rb") as fh:
            resp = await client.put(
                put_url,
                content=fh,
                headers={
                    "Content-Length": str(file_size),
                    "Content-Type": "application/octet-stream",
                },
            )
        if not resp.is_success:
            body = resp.text[:200]
            raise RuntimeError(
                f"Upload failed for {remote_path}: HTTP {resp.status_code} {body}"
            )

    return file_size


async def ensure_datasets_collection(artifact_manager) -> str:
    """Create the 'safe-colab-datasets' collection if it doesn't exist.

    Returns the collection ID.
    """
    try:
        collection = await artifact_manager.read(artifact_id=DATASETS_COLLECTION_ALIAS)
        return collection["id"]
    except Exception:
        collection = await artifact_manager.create(
            type="collection",
            alias=DATASETS_COLLECTION_ALIAS,
            manifest={
                "name": "Safe Colab Datasets",
                "description": "Datasets uploaded for remote safe-colab sessions",
            },
            config={
                "permissions": {"*": "r+", "@": "rw+"},
            },
        )
        collection_id = collection["id"]
        try:
            await artifact_manager.commit(collection_id)
        except Exception:
            pass
        return collection_id


async def upload_dataset(
    artifact_manager,
    data_dir: str,
    name: str,
    overwrite: bool = False,
    progress_cb: Optional[Callable[[str, int, int], None]] = None,
) -> dict:
    """Upload a data directory to Hypha Artifact Manager.

    Creates or updates a dataset artifact in the safe-colab-datasets collection.

    Args:
        artifact_manager: Connected Hypha artifact-manager service.
        data_dir: Local path to the data directory.
        name: Human-readable dataset name (used for the alias).
        overwrite: If True, replace existing dataset with same name.
        progress_cb: Called with (filename, bytes_done, total_bytes).

    Returns:
        Dict with artifact id, alias, file count, total bytes, and any errors.
    """
    abs_data = os.path.abspath(data_dir)

    # Build alias from name
    alias = "dataset-" + name.lower().replace(" ", "-").replace("_", "-")
    # Strip non-alphanumeric except dashes
    alias = "".join(c if c.isalnum() or c == "-" else "-" for c in alias)
    alias = alias.strip("-")

    collection_id = await ensure_datasets_collection(artifact_manager)

    # Check for existing artifact
    artifact_id = None
    try:
        existing = await artifact_manager.read(artifact_id=alias)
        if not overwrite:
            raise RuntimeError(
                f"Dataset '{name}' already exists (alias: {alias}). "
                f"Use --overwrite to update it."
            )
        artifact_id = existing["id"]
        await artifact_manager.edit(artifact_id=artifact_id)
        logger.info(f"Updating existing dataset artifact: {alias}")
    except RuntimeError:
        raise
    except Exception:
        # Create new artifact
        artifact = await artifact_manager.create(
            type="dataset",
            alias=alias,
            parent_id=collection_id,
            manifest={
                "name": name,
                "description": f"Dataset uploaded via safe-colab upload",
            },
            config={
                "permissions": {"*": "r+", "@": "rw+"},
            },
        )
        artifact_id = artifact["id"]
        logger.info(f"Created dataset artifact: {alias} ({artifact_id})")

    # Collect files
    files = _collect_files(abs_data)
    total_bytes = sum(os.path.getsize(lp) for lp, _ in files)
    done_bytes = 0
    errors = []

    for i, (local_path, rel_path) in enumerate(files):
        remote_path = f"data/{rel_path}"
        try:
            n = await _upload_file_presigned(
                artifact_manager, artifact_id, local_path, remote_path
            )
            done_bytes += n
            if progress_cb:
                progress_cb(rel_path, done_bytes, total_bytes)
        except Exception as e:
            logger.warning(f"Upload error for {rel_path}: {e}")
            errors.append(f"{rel_path}: {e}")

    # Commit
    await artifact_manager.commit(artifact_id)
    logger.info(f"Committed dataset artifact: {alias}")

    return {
        "id": artifact_id,
        "alias": alias,
        "name": name,
        "files": len(files) - len(errors),
        "bytes": done_bytes,
        "errors": errors,
    }


async def install_runner_app(
    server,
    dataset_info: dict,
    server_url: str,
    workspace: str,
    token: str,
    guardian_url: Optional[str] = None,
    overwrite: bool = True,
) -> dict:
    """Install a safe-colab-runner server app for a dataset.

    Registers the app in Hypha so that any registered SafeColabRunnerWorker
    can pick it up and spin up a pod on demand.

    Args:
        server: Connected hypha_rpc server.
        dataset_info: Dict returned by upload_dataset().
        server_url: Hypha server URL.
        workspace: Hypha workspace.
        token: Long-lived token that the pod will use to download data + register.
        guardian_url: Optional guardian agent URL.
        overwrite: Replace existing app with same id.

    Returns:
        Dict with app_id.
    """
    server_apps = await server.get_service("server-apps")

    # App ID derived from dataset alias
    app_id = dataset_info["alias"]  # e.g. "dataset-my-dataset"

    app_config = {
        "artifact_id": dataset_info["id"],
        "hypha_server_url": server_url,
        "hypha_workspace": workspace,
        "hypha_token": token,
        "dataset_name": dataset_info["name"],
    }
    if guardian_url:
        app_config["guardian_url"] = guardian_url

    manifest = {
        "id": app_id,
        "name": f"Safe Colab: {dataset_info['name']}",
        "type": "safe-colab-runner",
        "description": f"Remote safe-colab session for dataset '{dataset_info['name']}'",
        "version": "1.0.0",
        "config": app_config,
    }

    installed_id = await server_apps.install(
        manifest=manifest,
        overwrite=overwrite,
    )

    logger.info(f"Installed safe-colab-runner app: {installed_id}")
    return {"app_id": installed_id}


async def list_datasets(artifact_manager) -> list[dict]:
    """List all datasets in the safe-colab-datasets collection."""
    try:
        await ensure_datasets_collection(artifact_manager)
        items = await artifact_manager.list(
            parent_id=DATASETS_COLLECTION_ALIAS,
            limit=100,
        )
        return items.get("items", items) if isinstance(items, dict) else items
    except Exception as e:
        logger.warning(f"Could not list datasets: {e}")
        return []


async def remove_dataset(artifact_manager, server, alias_or_name: str) -> bool:
    """Remove a dataset artifact and its runner app."""
    # Try as alias directly, then as "dataset-<name>"
    candidates = [alias_or_name]
    if not alias_or_name.startswith("dataset-"):
        slug = alias_or_name.lower().replace(" ", "-").replace("_", "-")
        candidates.append(f"dataset-{slug}")

    removed = False
    for alias in candidates:
        try:
            await artifact_manager.delete(artifact_id=alias)
            logger.info(f"Deleted dataset artifact: {alias}")
            removed = True
        except Exception:
            pass

        # Also try removing the runner app
        try:
            server_apps = await server.get_service("server-apps")
            await server_apps.uninstall(app_id=alias)
            logger.info(f"Uninstalled runner app: {alias}")
        except Exception:
            pass

        if removed:
            break

    return removed
