"""Desktop daemon — JSON-RPC server for the GUI to control sessions and environments.

Runs as a long-lived local process, exposing an HTTP API on localhost that the
Tauri frontend calls via IPC. Also supports standalone use for testing.

Endpoints:
    POST /rpc  — JSON-RPC 2.0 (methods below)
    GET  /health — health check
    GET  /events — SSE stream of session events

Methods:
    env.list, env.create, env.delete, env.clone, env.install, env.info,
    env.list_packages, env.export, env.import, env.pip_install
    session.list, session.create, session.start, session.stop, session.restart,
    session.delete, session.get, session.logs
    auth.status, auth.login
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import signal
import sys
from pathlib import Path
from typing import Any

logger = logging.getLogger("safe_colab_cli.daemon")

SAFE_COLAB_HOME = os.environ.get(
    "SAFE_COLAB_HOME", os.path.join(Path.home(), ".safe-colab")
)


class JsonRpcError(Exception):
    def __init__(self, code: int, message: str, data: Any = None):
        self.code = code
        self.message = message
        self.data = data


class Daemon:
    """The desktop daemon — manages sessions and environments via JSON-RPC."""

    def __init__(self):
        from .env_manager import EnvManager
        from .session_manager import SessionManager

        self.env_manager = EnvManager()
        self.session_manager = SessionManager(self.env_manager)
        self._credentials: dict | None = None
        self._event_subscribers: list[asyncio.Queue] = []

    def _load_credentials(self) -> dict:
        """Load saved Hypha credentials."""
        if self._credentials:
            return self._credentials
        from .auth import load_credentials

        server_url, workspace, token = load_credentials()
        self._credentials = {
            "server_url": server_url or "",
            "workspace": workspace or "",
            "token": token or "",
        }
        return self._credentials

    async def handle_rpc(self, method: str, params: dict) -> Any:
        """Dispatch a JSON-RPC method call."""
        handlers = {
            # Environment management
            "env.list": self._env_list,
            "env.create": self._env_create,
            "env.delete": self._env_delete,
            "env.clone": self._env_clone,
            "env.install": self._env_install,
            "env.pip_install": self._env_pip_install,
            "env.info": self._env_info,
            "env.list_packages": self._env_list_packages,
            "env.export": self._env_export,
            "env.import": self._env_import,
            # Session management
            "session.list": self._session_list,
            "session.create": self._session_create,
            "session.start": self._session_start,
            "session.stop": self._session_stop,
            "session.restart": self._session_restart,
            "session.delete": self._session_delete,
            "session.get": self._session_get,
            "session.logs": self._session_logs,
            # Auth
            "auth.status": self._auth_status,
            "auth.login": self._auth_login,
        }
        handler = handlers.get(method)
        if not handler:
            raise JsonRpcError(-32601, f"Method not found: {method}")
        return await handler(params)

    # --- Environment methods ---

    async def _env_list(self, params: dict) -> list[dict]:
        envs = self.env_manager.list_envs()
        return [e.to_dict() for e in envs]

    async def _env_create(self, params: dict) -> dict:
        info = self.env_manager.create(
            name=params["name"],
            packages=params.get("packages"),
            channels=params.get("channels"),
            python_version=params.get("python_version", "3.12"),
            yaml_spec=params.get("yaml_spec"),
        )
        return info.to_dict()

    async def _env_delete(self, params: dict) -> dict:
        self.env_manager.delete(params["name"])
        return {"ok": True}

    async def _env_clone(self, params: dict) -> dict:
        info = self.env_manager.clone(params["source"], params["name"])
        return info.to_dict()

    async def _env_install(self, params: dict) -> dict:
        info = self.env_manager.install(
            params["name"],
            params["packages"],
            channels=params.get("channels"),
        )
        return info.to_dict()

    async def _env_pip_install(self, params: dict) -> dict:
        output = self.env_manager.pip_install(params["name"], params["packages"])
        return {"ok": True, "output": output}

    async def _env_info(self, params: dict) -> dict:
        info = self.env_manager.get_info(params["name"])
        return info.to_dict()

    async def _env_list_packages(self, params: dict) -> list[dict]:
        return self.env_manager.list_packages(params["name"])

    async def _env_export(self, params: dict) -> dict:
        path = self.env_manager.export_env(
            params["name"], output_path=params.get("output_path")
        )
        return {"path": path}

    async def _env_import(self, params: dict) -> dict:
        info = self.env_manager.import_env(
            params["tarball_path"], name=params.get("name")
        )
        return info.to_dict()

    # --- Session methods ---

    async def _session_list(self, params: dict) -> list[dict]:
        sessions = self.session_manager.list_sessions()
        return [s.to_dict() for s in sessions]

    async def _session_create(self, params: dict) -> dict:
        config = self.session_manager.create_session(
            name=params["name"],
            env_name=params["env_name"],
            data_dir=params.get("data_dir"),
            sandbox_backend=params.get("sandbox_backend", "auto"),
            guardian_url=params.get("guardian_url"),
            allow_shell=params.get("allow_shell", False),
            allow_install=params.get("allow_install", False),
            timeout=params.get("timeout", 120),
        )
        return config.to_dict()

    async def _session_start(self, params: dict) -> dict:
        creds = self._load_credentials()
        if not creds.get("token"):
            raise JsonRpcError(-32000, "Not logged in — run auth.login first")
        config = await self.session_manager.start_session(
            session_id=params["id"],
            server_url=creds["server_url"],
            workspace=creds["workspace"],
            token=creds["token"],
        )
        self._broadcast_event("session.started", config.to_dict())
        return config.to_dict()

    async def _session_stop(self, params: dict) -> dict:
        config = await self.session_manager.stop_session(params["id"])
        self._broadcast_event("session.stopped", config.to_dict())
        return config.to_dict()

    async def _session_restart(self, params: dict) -> dict:
        creds = self._load_credentials()
        config = await self.session_manager.restart_session(
            session_id=params["id"],
            server_url=creds["server_url"],
            workspace=creds["workspace"],
            token=creds["token"],
        )
        return config.to_dict()

    async def _session_delete(self, params: dict) -> dict:
        self.session_manager.delete_session(params["id"])
        return {"ok": True}

    async def _session_get(self, params: dict) -> dict:
        config = self.session_manager.get_session(params["id"])
        return config.to_dict()

    async def _session_logs(self, params: dict) -> list[dict]:
        return self.session_manager.get_session_logs(
            params["id"],
            offset=params.get("offset", 0),
            limit=params.get("limit", 100),
        )

    # --- Auth methods ---

    async def _auth_status(self, params: dict) -> dict:
        creds = self._load_credentials()
        from .auth import extract_email_from_token, is_token_expired

        token = creds.get("token", "")
        logged_in = bool(token) and not is_token_expired(token)
        email = extract_email_from_token(token) if token else ""
        return {
            "logged_in": logged_in,
            "email": email or "",
            "server_url": creds.get("server_url", ""),
            "workspace": creds.get("workspace", ""),
        }

    async def _auth_login(self, params: dict) -> dict:
        # Trigger browser-based login flow
        from .auth import login_interactive

        server_url = params.get("server_url", "https://hypha.aicell.io")
        token, workspace = await asyncio.get_event_loop().run_in_executor(
            None, login_interactive, server_url
        )
        self._credentials = {
            "server_url": server_url,
            "workspace": workspace,
            "token": token,
        }
        return {"ok": True, "workspace": workspace}

    # --- Event broadcasting ---

    def _broadcast_event(self, event_type: str, data: Any) -> None:
        """Broadcast event to all SSE subscribers."""
        for q in self._event_subscribers:
            try:
                q.put_nowait({"type": event_type, "data": data})
            except asyncio.QueueFull:
                pass

    def subscribe_events(self) -> asyncio.Queue:
        q = asyncio.Queue(maxsize=100)
        self._event_subscribers.append(q)
        return q

    def unsubscribe_events(self, q: asyncio.Queue) -> None:
        if q in self._event_subscribers:
            self._event_subscribers.remove(q)

    async def shutdown(self) -> None:
        """Graceful shutdown — stop all sessions."""
        await self.session_manager.stop_all()


def create_app(daemon: Daemon | None = None):
    """Create an aiohttp web application for the daemon."""
    from aiohttp import web

    if daemon is None:
        daemon = Daemon()

    app = web.Application()

    async def handle_health(request):
        return web.json_response({"status": "ok"})

    async def handle_rpc(request):
        try:
            body = await request.json()
        except json.JSONDecodeError:
            return web.json_response(
                {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": None},
                status=400,
            )

        req_id = body.get("id")
        method = body.get("method", "")
        params = body.get("params", {})

        try:
            result = await daemon.handle_rpc(method, params)
            return web.json_response(
                {"jsonrpc": "2.0", "result": result, "id": req_id}
            )
        except JsonRpcError as e:
            return web.json_response(
                {
                    "jsonrpc": "2.0",
                    "error": {"code": e.code, "message": e.message, "data": e.data},
                    "id": req_id,
                }
            )
        except Exception as e:
            logger.exception(f"RPC error: {method}")
            return web.json_response(
                {
                    "jsonrpc": "2.0",
                    "error": {"code": -32000, "message": str(e)},
                    "id": req_id,
                }
            )

    async def handle_events(request):
        """Server-Sent Events stream for real-time updates."""
        response = web.StreamResponse(
            status=200,
            reason="OK",
            headers={
                "Content-Type": "text/event-stream",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Access-Control-Allow-Origin": "*",
            },
        )
        await response.prepare(request)

        q = daemon.subscribe_events()
        try:
            while True:
                event = await q.get()
                data = json.dumps(event["data"])
                await response.write(
                    f"event: {event['type']}\ndata: {data}\n\n".encode()
                )
        except (asyncio.CancelledError, ConnectionResetError):
            pass
        finally:
            daemon.unsubscribe_events(q)
        return response

    # CORS middleware for Tauri webview
    @web.middleware
    async def cors_middleware(request, handler):
        if request.method == "OPTIONS":
            return web.Response(
                headers={
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type",
                }
            )
        response = await handler(request)
        response.headers["Access-Control-Allow-Origin"] = "*"
        return response

    app.middlewares.append(cors_middleware)
    app.router.add_get("/health", handle_health)
    app.router.add_post("/rpc", handle_rpc)
    app.router.add_get("/events", handle_events)

    async def on_shutdown(app):
        await daemon.shutdown()

    app.on_shutdown.append(on_shutdown)

    return app


def main():
    """Entry point for the daemon process."""
    parser = argparse.ArgumentParser(description="Safe Colab Desktop Daemon")
    parser.add_argument("--port", type=int, default=17380, help="Port to listen on")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--verbose", "-v", action="count", default=0)
    args = parser.parse_args()

    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    from aiohttp import web

    daemon = Daemon()
    app = create_app(daemon)

    # Save daemon state
    state_file = os.path.join(SAFE_COLAB_HOME, "daemon.json")
    os.makedirs(SAFE_COLAB_HOME, exist_ok=True)
    with open(state_file, "w") as f:
        json.dump({"pid": os.getpid(), "port": args.port, "host": args.host}, f)

    logger.info(f"Daemon starting on {args.host}:{args.port}")

    try:
        web.run_app(app, host=args.host, port=args.port, print=logger.info)
    finally:
        if os.path.isfile(state_file):
            os.unlink(state_file)


if __name__ == "__main__":
    main()
