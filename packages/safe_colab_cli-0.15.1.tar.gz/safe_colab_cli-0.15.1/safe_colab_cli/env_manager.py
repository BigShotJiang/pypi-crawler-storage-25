"""Environment manager — creates and manages isolated conda environments via micromamba.

NOTE: Uses `from __future__ import annotations` for Python 3.9+ compatibility.

Each session can have its own conda environment with independent packages.
Environments are stored in ~/.safe-colab/envs/<name>/ and managed by a bundled
micromamba binary (no system conda/mamba required).

Supports:
- Creating envs from package lists or YAML specs
- Installing/removing packages
- Cloning envs
- Importing/exporting via conda-pack tarballs
- Listing and deleting envs
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import shutil
import stat
import subprocess
import tarfile
import tempfile
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger("safe_colab_cli.env_manager")

SAFE_COLAB_HOME = os.environ.get(
    "SAFE_COLAB_HOME", os.path.join(Path.home(), ".safe-colab")
)
ENVS_DIR = os.path.join(SAFE_COLAB_HOME, "envs")
BIN_DIR = os.path.join(SAFE_COLAB_HOME, "bin")
CACHE_DIR = os.path.join(SAFE_COLAB_HOME, "env-cache")

# micromamba download URLs by platform
MICROMAMBA_URLS = {
    ("darwin", "arm64"): "https://micro.mamba.pm/api/micromamba/osx-arm64/latest",
    ("darwin", "x86_64"): "https://micro.mamba.pm/api/micromamba/osx-64/latest",
    ("linux", "x86_64"): "https://micro.mamba.pm/api/micromamba/linux-64/latest",
    ("linux", "aarch64"): "https://micro.mamba.pm/api/micromamba/linux-aarch64/latest",
    ("win32", "x86_64"): "https://micro.mamba.pm/api/micromamba/win-64/latest",
}

DEFAULT_CHANNELS = ["conda-forge"]
DEFAULT_PYTHON_VERSION = "3.12"


@dataclass
class EnvInfo:
    """Metadata for a managed conda environment."""

    name: str
    path: str
    python_version: str = ""
    packages: list[str] = field(default_factory=list)
    channels: list[str] = field(default_factory=list)
    created_at: str = ""
    size_mb: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


class EnvManager:
    """Manages isolated conda environments via micromamba."""

    def __init__(self, envs_dir: str = ENVS_DIR, bin_dir: str = BIN_DIR):
        self.envs_dir = envs_dir
        self.bin_dir = bin_dir
        self._micromamba: Optional[str] = None
        os.makedirs(self.envs_dir, exist_ok=True)
        os.makedirs(self.bin_dir, exist_ok=True)
        os.makedirs(CACHE_DIR, exist_ok=True)

    @property
    def micromamba(self) -> str:
        """Path to micromamba binary, auto-installing if needed."""
        if self._micromamba and os.path.isfile(self._micromamba):
            return self._micromamba
        self._micromamba = self._find_or_install_micromamba()
        return self._micromamba

    def _find_or_install_micromamba(self) -> str:
        """Find micromamba in bin_dir or PATH, install if missing."""
        # Check our bin dir first
        local = os.path.join(self.bin_dir, "micromamba")
        if os.path.isfile(local) and os.access(local, os.X_OK):
            return local
        # Check PATH
        from_path = shutil.which("micromamba")
        if from_path:
            return from_path
        # Auto-install
        return self._install_micromamba()

    def _install_micromamba(self) -> str:
        """Download and install micromamba binary."""
        system = platform.system().lower()
        if system == "win32" or system == "windows":
            system = "win32"
        machine = platform.machine().lower()
        if machine in ("arm64", "aarch64"):
            machine = "aarch64" if system == "linux" else "arm64"
        elif machine in ("x86_64", "amd64"):
            machine = "x86_64"

        key = (system, machine)
        url = MICROMAMBA_URLS.get(key)
        if not url:
            raise RuntimeError(
                f"No micromamba binary available for {system}/{machine}. "
                "Please install micromamba manually: https://mamba.readthedocs.io/en/latest/installation/micromamba-installation.html"
            )

        target = os.path.join(self.bin_dir, "micromamba")
        logger.info(f"Downloading micromamba for {system}/{machine}...")

        try:
            with tempfile.NamedTemporaryFile(
                suffix=".tar.bz2", delete=False
            ) as tmp:
                tmp_path = tmp.name
                req = urllib.request.Request(url, headers={"User-Agent": "safe-colab-cli"})
                with urllib.request.urlopen(req, timeout=60) as resp:
                    while True:
                        chunk = resp.read(8192)
                        if not chunk:
                            break
                        tmp.write(chunk)

            # Extract micromamba from the tarball
            with tarfile.open(tmp_path, "r:bz2") as tf:
                for member in tf.getmembers():
                    if member.name.endswith("/micromamba") or member.name == "micromamba":
                        member.name = "micromamba"
                        tf.extract(member, self.bin_dir)
                        break
                    # Some tarballs have bin/micromamba
                    if "micromamba" in member.name and member.isfile():
                        with tf.extractfile(member) as src:
                            with open(target, "wb") as dst:
                                dst.write(src.read())
                        break

            os.chmod(target, os.stat(target).st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
            os.unlink(tmp_path)

            # Verify
            result = subprocess.run(
                [target, "--version"], capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                logger.info(f"micromamba installed: {target} ({result.stdout.strip()})")
                return target
            else:
                raise RuntimeError(f"micromamba verification failed: {result.stderr}")
        except Exception as e:
            if os.path.exists(target):
                os.unlink(target)
            raise RuntimeError(f"Failed to install micromamba: {e}") from e

    def _run_micromamba(
        self,
        args: list[str],
        timeout: int = 600,
        capture: bool = True,
        env: dict | None = None,
    ) -> subprocess.CompletedProcess:
        """Run micromamba with the correct root prefix."""
        cmd = [
            self.micromamba,
            *args,
            "--root-prefix",
            os.path.join(SAFE_COLAB_HOME, "mamba-root"),
        ]
        proc_env = os.environ.copy()
        # Prevent micromamba from reading user's .condarc
        proc_env["CONDARC"] = os.path.join(SAFE_COLAB_HOME, ".condarc")
        if env:
            proc_env.update(env)
        return subprocess.run(
            cmd,
            capture_output=capture,
            text=True,
            timeout=timeout,
            env=proc_env,
        )

    def create(
        self,
        name: str,
        packages: list[str] | None = None,
        channels: list[str] | None = None,
        python_version: str = DEFAULT_PYTHON_VERSION,
        yaml_spec: str | None = None,
    ) -> EnvInfo:
        """Create a new conda environment.

        Args:
            name: Environment name (used as directory name).
            packages: List of packages to install (e.g. ["numpy", "pandas"]).
            channels: Conda channels (default: conda-forge).
            python_version: Python version (default: 3.12).
            yaml_spec: Path to environment.yaml file (overrides packages/channels).

        Returns:
            EnvInfo with the created environment metadata.
        """
        env_path = os.path.join(self.envs_dir, name)
        if os.path.exists(env_path):
            raise ValueError(f"Environment '{name}' already exists at {env_path}")

        channels = channels or DEFAULT_CHANNELS

        if yaml_spec:
            # Create from YAML spec
            args = ["create", "-p", env_path, "-f", yaml_spec, "-y"]
            for ch in channels:
                args.extend(["-c", ch])
        else:
            # Create from package list
            pkgs = [f"python={python_version}"] + (packages or [])
            args = ["create", "-p", env_path, "-y"]
            for ch in channels:
                args.extend(["-c", ch])
            args.extend(pkgs)

        logger.info(f"Creating environment '{name}'...")
        result = self._run_micromamba(args, timeout=900)
        if result.returncode != 0:
            # Clean up partial env
            if os.path.exists(env_path):
                shutil.rmtree(env_path, ignore_errors=True)
            raise RuntimeError(
                f"Failed to create environment '{name}': {result.stderr}"
            )

        # Save metadata
        info = EnvInfo(
            name=name,
            path=env_path,
            python_version=python_version,
            packages=packages or [],
            channels=channels,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._save_env_meta(info)
        logger.info(f"Environment '{name}' created at {env_path}")
        return info

    def install(self, name: str, packages: list[str], channels: list[str] | None = None) -> EnvInfo:
        """Install packages into an existing environment."""
        env_path = self._resolve_env(name)
        channels = channels or DEFAULT_CHANNELS

        args = ["install", "-p", env_path, "-y"]
        for ch in channels:
            args.extend(["-c", ch])
        args.extend(packages)

        logger.info(f"Installing {packages} into '{name}'...")
        result = self._run_micromamba(args, timeout=600)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to install packages: {result.stderr}")

        # Update metadata
        info = self._load_env_meta(name)
        if info:
            info.packages = list(set(info.packages + packages))
            self._save_env_meta(info)
        return info or self.get_info(name)

    def remove_packages(self, name: str, packages: list[str]) -> EnvInfo:
        """Remove packages from an environment."""
        env_path = self._resolve_env(name)
        args = ["remove", "-p", env_path, "-y"] + packages
        result = self._run_micromamba(args, timeout=300)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to remove packages: {result.stderr}")
        return self.get_info(name)

    def clone(self, source_name: str, new_name: str) -> EnvInfo:
        """Clone an existing environment by copying the directory."""
        source_path = self._resolve_env(source_name)
        new_path = os.path.join(self.envs_dir, new_name)
        if os.path.exists(new_path):
            raise ValueError(f"Environment '{new_name}' already exists")

        logger.info(f"Cloning '{source_name}' -> '{new_name}'...")
        shutil.copytree(source_path, new_path, symlinks=True)

        # Update metadata
        source_info = self._load_env_meta(source_name)
        info = EnvInfo(
            name=new_name,
            path=new_path,
            python_version=source_info.python_version if source_info else "",
            packages=source_info.packages if source_info else [],
            channels=source_info.channels if source_info else DEFAULT_CHANNELS,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._save_env_meta(info)
        logger.info(f"Environment '{new_name}' cloned from '{source_name}'")
        return info

    def delete(self, name: str) -> None:
        """Delete an environment and its metadata."""
        env_path = self._resolve_env(name)
        shutil.rmtree(env_path)
        logger.info(f"Environment '{name}' deleted")

    def list_envs(self) -> list[EnvInfo]:
        """List all managed environments."""
        envs = []
        if not os.path.isdir(self.envs_dir):
            return envs
        for entry in sorted(os.listdir(self.envs_dir)):
            env_path = os.path.join(self.envs_dir, entry)
            if not os.path.isdir(env_path):
                continue
            # Must have a Python binary to be a valid env
            python = self._find_python(env_path)
            if not python:
                continue
            info = self._load_env_meta(entry)
            if not info:
                info = EnvInfo(name=entry, path=env_path)
            envs.append(info)
        return envs

    def get_info(self, name: str) -> EnvInfo:
        """Get detailed info about an environment."""
        env_path = self._resolve_env(name)
        info = self._load_env_meta(name)
        if not info:
            info = EnvInfo(name=name, path=env_path)
        # Get actual Python version
        python = self._find_python(env_path)
        if python:
            try:
                result = subprocess.run(
                    [python, "--version"], capture_output=True, text=True, timeout=10
                )
                if result.returncode == 0:
                    info.python_version = result.stdout.strip().replace("Python ", "")
            except Exception:
                pass
        # Calculate size
        info.size_mb = self._dir_size_mb(env_path)
        return info

    def list_packages(self, name: str) -> list[dict]:
        """List installed packages in an environment."""
        env_path = self._resolve_env(name)
        args = ["list", "-p", env_path, "--json"]
        result = self._run_micromamba(args, timeout=30)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to list packages: {result.stderr}")
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return []

    def export_env(self, name: str, output_path: str | None = None) -> str:
        """Export environment as a conda-pack tarball.

        Requires conda-pack to be installed in the environment.
        Returns path to the tarball.
        """
        env_path = self._resolve_env(name)
        if not output_path:
            output_path = os.path.join(CACHE_DIR, f"{name}.tar.gz")

        python = self._find_python(env_path)
        if not python:
            raise RuntimeError(f"No Python found in environment '{name}'")

        # Ensure conda-pack is available
        check = subprocess.run(
            [python, "-c", "import conda_pack"],
            capture_output=True,
            timeout=10,
        )
        if check.returncode != 0:
            # Install conda-pack into the env
            self.install(name, ["conda-pack"])

        logger.info(f"Exporting '{name}' to {output_path}...")
        result = subprocess.run(
            [python, "-m", "conda_pack", "-p", env_path, "-o", output_path, "--force"],
            capture_output=True,
            text=True,
            timeout=600,
        )
        if result.returncode != 0:
            raise RuntimeError(f"conda-pack failed: {result.stderr}")
        logger.info(f"Exported '{name}' ({os.path.getsize(output_path) / 1024 / 1024:.1f} MB)")
        return output_path

    def import_env(self, tarball_path: str, name: str | None = None) -> EnvInfo:
        """Import an environment from a conda-pack tarball.

        Uses SHA-256 caching to avoid re-extracting identical tarballs.
        """
        if not os.path.isfile(tarball_path):
            raise FileNotFoundError(f"Tarball not found: {tarball_path}")

        if not name:
            name = Path(tarball_path).stem.replace(".tar", "")

        env_path = os.path.join(self.envs_dir, name)
        if os.path.exists(env_path):
            raise ValueError(f"Environment '{name}' already exists")

        logger.info(f"Importing environment from {tarball_path}...")
        os.makedirs(env_path, exist_ok=True)

        # Extract
        with tarfile.open(tarball_path, "r:gz") as tf:
            tf.extractall(env_path)

        # Run conda-unpack to fix paths
        unpack_script = os.path.join(env_path, "bin", "conda-unpack")
        if os.path.isfile(unpack_script):
            os.chmod(unpack_script, os.stat(unpack_script).st_mode | stat.S_IEXEC)
            subprocess.run([unpack_script], cwd=env_path, timeout=120)

        info = EnvInfo(
            name=name,
            path=env_path,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._save_env_meta(info)
        logger.info(f"Environment '{name}' imported from tarball")
        return info

    def get_python(self, name: str) -> str:
        """Get the path to the Python binary in an environment."""
        env_path = self._resolve_env(name)
        python = self._find_python(env_path)
        if not python:
            raise RuntimeError(f"No Python binary found in environment '{name}'")
        return python

    def get_env_path(self, name: str) -> str:
        """Get the path to an environment directory."""
        return self._resolve_env(name)

    def pip_install(self, name: str, packages: list[str]) -> str:
        """Install packages via pip in the environment.

        Use this for PyPI-only packages not available via conda.
        """
        python = self.get_python(name)
        cmd = [python, "-m", "pip", "install", "--no-input"] + packages
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if result.returncode != 0:
            raise RuntimeError(f"pip install failed: {result.stderr}")
        return result.stdout

    # --- Internal helpers ---

    def _resolve_env(self, name: str) -> str:
        """Resolve env name to path, raising if not found."""
        env_path = os.path.join(self.envs_dir, name)
        if not os.path.isdir(env_path):
            raise FileNotFoundError(f"Environment '{name}' not found at {env_path}")
        return env_path

    def _find_python(self, env_path: str) -> str | None:
        """Find the Python binary in an env."""
        candidates = [
            os.path.join(env_path, "bin", "python"),
            os.path.join(env_path, "bin", "python3"),
            os.path.join(env_path, "python.exe"),
            os.path.join(env_path, "Scripts", "python.exe"),
        ]
        for c in candidates:
            if os.path.isfile(c) and os.access(c, os.X_OK):
                return c
        return None

    def _save_env_meta(self, info: EnvInfo) -> None:
        """Save environment metadata to env_path/.safe-colab-env.json."""
        meta_path = os.path.join(info.path, ".safe-colab-env.json")
        with open(meta_path, "w") as f:
            json.dump(info.to_dict(), f, indent=2)

    def _load_env_meta(self, name: str) -> EnvInfo | None:
        """Load environment metadata."""
        meta_path = os.path.join(self.envs_dir, name, ".safe-colab-env.json")
        if not os.path.isfile(meta_path):
            return None
        try:
            with open(meta_path) as f:
                data = json.load(f)
            return EnvInfo(**data)
        except Exception:
            return None

    def _dir_size_mb(self, path: str) -> float:
        """Calculate directory size in MB (approximate, non-recursive into symlinks)."""
        total = 0
        try:
            for dirpath, _, filenames in os.walk(path, followlinks=False):
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    if os.path.isfile(fp) and not os.path.islink(fp):
                        total += os.path.getsize(fp)
        except OSError:
            pass
        return round(total / (1024 * 1024), 1)
