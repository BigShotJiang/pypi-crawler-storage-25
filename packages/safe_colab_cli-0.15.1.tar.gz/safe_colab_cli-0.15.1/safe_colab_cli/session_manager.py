"""Session manager — orchestrates multiple safe-colab sessions.

Each session has:
- An isolated conda environment (via EnvManager)
- A sandboxed Jupyter kernel
- A registered Hypha service
- An audit event logger

Sessions are persisted as JSON configs in ~/.safe-colab/sessions/<id>/.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import secrets
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

logger = logging.getLogger("safe_colab_cli.session_manager")

SAFE_COLAB_HOME = os.environ.get(
    "SAFE_COLAB_HOME", os.path.join(Path.home(), ".safe-colab")
)
SESSIONS_DIR = os.path.join(SAFE_COLAB_HOME, "sessions")


class SessionStatus(str, Enum):
    CREATED = "created"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class SessionConfig:
    """Persistent session configuration."""

    id: str
    name: str
    env_name: str
    data_dir: Optional[str] = None
    work_dir: Optional[str] = None
    sandbox_backend: str = "auto"
    guardian_url: Optional[str] = "https://security-agent.hypha.amun.ai"
    allow_shell: bool = False
    allow_install: bool = False
    timeout: int = 120
    created_at: str = ""
    status: str = SessionStatus.CREATED
    service_url: Optional[str] = None
    dashboard_url: Optional[str] = None
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)


class SessionRuntime:
    """In-memory runtime state for an active session."""

    def __init__(self, config: SessionConfig):
        self.config = config
        self.kernel = None
        self.server = None
        self.event_logger = None
        self.guardian = None
        self._task: Optional[asyncio.Task] = None


class SessionManager:
    """Manages multiple safe-colab sessions concurrently."""

    def __init__(self, env_manager=None):
        from .env_manager import EnvManager

        self.env_manager = env_manager or EnvManager()
        self._sessions: dict[str, SessionRuntime] = {}
        os.makedirs(SESSIONS_DIR, exist_ok=True)

    def create_session(
        self,
        name: str,
        env_name: str,
        data_dir: str | None = None,
        sandbox_backend: str = "auto",
        guardian_url: str | None = "https://security-agent.hypha.amun.ai",
        allow_shell: bool = False,
        allow_install: bool = False,
        timeout: int = 120,
    ) -> SessionConfig:
        """Create a new session configuration (does not start it)."""
        session_id = secrets.token_hex(16)
        session_dir = os.path.join(SESSIONS_DIR, session_id)
        work_dir = os.path.join(session_dir, "workspace")
        os.makedirs(work_dir, exist_ok=True)

        # Verify environment exists
        self.env_manager.get_env_path(env_name)

        config = SessionConfig(
            id=session_id,
            name=name,
            env_name=env_name,
            data_dir=os.path.abspath(data_dir) if data_dir else None,
            work_dir=work_dir,
            sandbox_backend=sandbox_backend,
            guardian_url=guardian_url,
            allow_shell=allow_shell,
            allow_install=allow_install,
            timeout=timeout,
            created_at=datetime.now(timezone.utc).isoformat(),
            status=SessionStatus.CREATED,
        )
        self._save_config(config)
        logger.info(f"Session '{name}' created (id={session_id[:8]})")
        return config

    async def start_session(
        self,
        session_id: str,
        server_url: str,
        workspace: str,
        token: str,
    ) -> SessionConfig:
        """Start a session: launch kernel, register Hypha service."""
        config = self._load_config(session_id)
        if config.status == SessionStatus.RUNNING:
            raise RuntimeError(f"Session '{config.name}' is already running")

        config.status = SessionStatus.STARTING
        config.error = None
        self._save_config(config)

        runtime = SessionRuntime(config)
        self._sessions[session_id] = runtime

        try:
            await self._launch_session(runtime, server_url, workspace, token)
            config.status = SessionStatus.RUNNING
            self._save_config(config)
            logger.info(
                f"Session '{config.name}' started — service: {config.service_url}"
            )
        except Exception as e:
            config.status = SessionStatus.ERROR
            config.error = str(e)
            self._save_config(config)
            logger.error(f"Session '{config.name}' failed to start: {e}")
            raise

        return config

    async def stop_session(self, session_id: str) -> SessionConfig:
        """Stop a running session."""
        config = self._load_config(session_id)
        config.status = SessionStatus.STOPPING
        self._save_config(config)

        runtime = self._sessions.get(session_id)
        if runtime:
            try:
                if runtime.kernel:
                    await runtime.kernel.stop()
                if runtime.event_logger:
                    runtime.event_logger.session_ended()
            except Exception as e:
                logger.warning(f"Error stopping session '{config.name}': {e}")
            del self._sessions[session_id]

        config.status = SessionStatus.STOPPED
        config.service_url = None
        config.dashboard_url = None
        self._save_config(config)
        logger.info(f"Session '{config.name}' stopped")
        return config

    async def restart_session(
        self,
        session_id: str,
        server_url: str,
        workspace: str,
        token: str,
    ) -> SessionConfig:
        """Restart a session (stop then start)."""
        config = self._load_config(session_id)
        if config.status == SessionStatus.RUNNING:
            await self.stop_session(session_id)
        return await self.start_session(session_id, server_url, workspace, token)

    def delete_session(self, session_id: str) -> None:
        """Delete a session and its workspace (must be stopped first)."""
        config = self._load_config(session_id)
        if config.status == SessionStatus.RUNNING:
            raise RuntimeError("Cannot delete a running session — stop it first")
        import shutil

        session_dir = os.path.join(SESSIONS_DIR, session_id)
        if os.path.isdir(session_dir):
            shutil.rmtree(session_dir)
        logger.info(f"Session '{config.name}' deleted")

    def list_sessions(self) -> list[SessionConfig]:
        """List all sessions (from disk)."""
        sessions = []
        if not os.path.isdir(SESSIONS_DIR):
            return sessions
        for entry in sorted(os.listdir(SESSIONS_DIR)):
            config_path = os.path.join(SESSIONS_DIR, entry, "session.json")
            if os.path.isfile(config_path):
                try:
                    config = self._load_config(entry)
                    # Check if a "running" session is actually still alive
                    if config.status == SessionStatus.RUNNING and entry not in self._sessions:
                        config.status = SessionStatus.STOPPED
                        self._save_config(config)
                    sessions.append(config)
                except Exception:
                    continue
        return sessions

    def get_session(self, session_id: str) -> SessionConfig:
        """Get session config by ID."""
        return self._load_config(session_id)

    def get_session_logs(
        self, session_id: str, offset: int = 0, limit: int = 100
    ) -> list[dict]:
        """Get audit log entries for a session."""
        from .event_log import get_session_log_dir

        config = self._load_config(session_id)
        # Find the log directory — try all matching dirs
        logs_base = os.path.join(SAFE_COLAB_HOME, "logs")
        short_id = session_id[:8]
        entries = []

        if not os.path.isdir(logs_base):
            return entries

        for d in os.listdir(logs_base):
            if short_id in d:
                log_file = os.path.join(logs_base, d, "session.log.jsonl")
                if os.path.isfile(log_file):
                    with open(log_file) as f:
                        lines = f.readlines()
                    for line in lines[offset : offset + limit]:
                        try:
                            entries.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
                    break
        return entries

    async def _launch_session(
        self,
        runtime: SessionRuntime,
        server_url: str,
        workspace: str,
        token: str,
    ) -> None:
        """Internal: set up kernel, guardian, logger, and register service."""
        config = runtime.config
        env_path = self.env_manager.get_env_path(config.env_name)

        # Resolve sandbox backend
        sandbox = config.sandbox_backend
        if sandbox == "auto":
            from .sandbox import detect_backend

            sandbox = detect_backend()

        # Start kernel with the session's conda env
        from .kernel import SandboxKernel

        kernel = SandboxKernel()
        kernel_env = {}
        if config.data_dir:
            kernel_env["SAFE_COLAB_DATA_DIR"] = config.data_dir
        kernel_env["SAFE_COLAB_WORK_DIR"] = config.work_dir

        if sandbox == "nono":
            # nono must be pre-started synchronously — run in executor
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: kernel.pre_start_nono(
                    env=kernel_env,
                    data_dir=config.data_dir,
                    work_dir=config.work_dir,
                    env_path=env_path,
                ),
            )
            await kernel.start(
                env=kernel_env, sandbox_backend="nono",
                data_dir=config.data_dir, work_dir=config.work_dir,
            )
        else:
            await kernel.start(
                env=kernel_env,
                sandbox_backend=sandbox,
                data_dir=config.data_dir,
                work_dir=config.work_dir,
                env_path=env_path,
            )
        runtime.kernel = kernel

        # Set up guardian
        guardian = None
        if config.guardian_url:
            from .guardian import GuardianAgent

            dataset_desc = ""
            if config.data_dir:
                for fname in ["README.md", "SECURITY_CONTRACT.md"]:
                    fpath = os.path.join(config.data_dir, fname)
                    if os.path.isfile(fpath):
                        with open(fpath) as f:
                            dataset_desc = f.read()
                        break
            guardian = GuardianAgent(
                endpoint_url=config.guardian_url,
                dataset_description=dataset_desc,
            )
            try:
                if await asyncio.get_event_loop().run_in_executor(
                    None, guardian.health
                ):
                    runtime.guardian = guardian
                else:
                    logger.warning("Guardian unreachable — proceeding without")
                    guardian = None
            except Exception:
                logger.warning("Guardian check failed — proceeding without")
                guardian = None

        # Set up event logger
        from .event_log import EventLogger

        event_logger = EventLogger(
            session_id=config.id,
            data_dir=config.data_dir,
            work_dir=config.work_dir,
            sandbox_backend=sandbox,
            guardian_url=config.guardian_url,
        )
        runtime.event_logger = event_logger

        # Register Hypha service
        from .service import register_service

        server, service_info, agent_instructions, service_url = (
            await register_service(
                server_url=server_url,
                workspace=workspace,
                token=token,
                kernel=kernel,
                data_dir=config.data_dir or "",
                work_dir=config.work_dir,
                session_id=config.id,
                guardian=guardian,
                event_logger=event_logger,
                allow_shell=config.allow_shell,
            )
        )
        runtime.server = server
        config.service_url = service_url
        # Extract dashboard URL if available
        if hasattr(service_info, "get"):
            config.dashboard_url = service_info.get("dashboard_url")
        self._save_config(config)

    def _save_config(self, config: SessionConfig) -> None:
        """Persist session config to disk."""
        session_dir = os.path.join(SESSIONS_DIR, config.id)
        os.makedirs(session_dir, exist_ok=True)
        path = os.path.join(session_dir, "session.json")
        with open(path, "w") as f:
            json.dump(config.to_dict(), f, indent=2)

    def _load_config(self, session_id: str) -> SessionConfig:
        """Load session config from disk."""
        path = os.path.join(SESSIONS_DIR, session_id, "session.json")
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Session '{session_id}' not found")
        with open(path) as f:
            data = json.load(f)
        return SessionConfig(**data)

    async def stop_all(self) -> None:
        """Stop all running sessions (for graceful shutdown)."""
        for session_id in list(self._sessions.keys()):
            try:
                await self.stop_session(session_id)
            except Exception as e:
                logger.warning(f"Error stopping session {session_id}: {e}")
