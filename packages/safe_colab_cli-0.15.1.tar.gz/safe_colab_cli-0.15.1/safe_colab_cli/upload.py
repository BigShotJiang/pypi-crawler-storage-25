"""Upload a local data directory to a Hypha artifact with multipart support.

Large files (>= MULTIPART_THRESHOLD) are split into parts and uploaded via
S3 multipart. Smaller files use a single presigned PUT. Both paths stream
the data to avoid loading the whole file into memory.
"""

import asyncio
import logging
import os
from pathlib import Path
from typing import Callable, Optional

import httpx

logger = logging.getLogger("safe_colab_cli.upload")

MULTIPART_THRESHOLD = 50 * 1024 * 1024   # 50 MB — use multipart above this
CHUNK_SIZE          = 50 * 1024 * 1024   # 50 MB per part
UPLOAD_TIMEOUT      = 600                 # seconds per HTTP call


# ── Low-level S3 helpers ─────────────────────────────────────────────────────

async def _put_simple(client: httpx.AsyncClient, url: str, local_path: str):
    """Upload a file with a single presigned PUT."""
    with open(local_path, "rb") as f:
        data = f.read()
    resp = await client.put(url, content=data, timeout=UPLOAD_TIMEOUT)
    resp.raise_for_status()


async def _put_multipart(
    am,
    artifact_id: str,
    file_path: str,
    local_path: str,
    echo: Callable[[str], None],
):
    """Upload a large file using S3 multipart via Hypha artifact manager."""
    file_size = os.path.getsize(local_path)
    part_count = max(1, (file_size + CHUNK_SIZE - 1) // CHUNK_SIZE)

    # 1. Initiate — get presigned part URLs
    result = await am.put_file_start_multipart(
        artifact_id=artifact_id,
        file_path=file_path,
        part_count=part_count,
    )
    upload_id = result["upload_id"]
    part_url_map = {p["part_number"]: p["url"] for p in result["part_urls"]}

    # 2. Upload each part
    parts = []
    async with httpx.AsyncClient(timeout=UPLOAD_TIMEOUT) as client:
        with open(local_path, "rb") as f:
            for part_num in range(1, part_count + 1):
                chunk = f.read(CHUNK_SIZE)
                resp = await client.put(part_url_map[part_num], content=chunk)
                resp.raise_for_status()
                etag = resp.headers.get("ETag", "").strip('"')
                parts.append({"part_number": part_num, "etag": etag})
                echo(f"    part {part_num}/{part_count}")

    # 3. Complete
    await am.put_file_complete_multipart(
        artifact_id=artifact_id,
        upload_id=upload_id,
        parts=parts,
    )


# ── Public API ───────────────────────────────────────────────────────────────

async def upload_data_dir(
    data_dir: str,
    artifact_alias: str,
    server_url: str,
    token: str,
    workspace: str,
    echo: Optional[Callable[[str], None]] = None,
    overwrite: bool = False,
) -> dict:
    """Upload every file under *data_dir* to a Hypha artifact.

    Creates the artifact if it doesn't exist; updates (re-stages) if it does.
    Files >= MULTIPART_THRESHOLD are uploaded in 50 MB chunks. The artifact
    is committed after all uploads.

    Returns:
        {
            "artifact_id": "ws-user.../alias",
            "alias": "alias",
            "workspace": "ws-user...",
            "file_count": 12,
            "version": "v0",
        }
    """
    from hypha_rpc import connect_to_server

    if echo is None:
        echo = logger.info

    data_dir_path = Path(data_dir).resolve()

    server = await connect_to_server({
        "server_url": server_url,
        "token": token,
        **({"workspace": workspace} if workspace else {}),
    })
    am = await server.get_service("public/artifact-manager")

    # ── Create or re-stage artifact ──────────────────────────────────────────
    try:
        artifact = await am.read(artifact_alias)
        artifact_id = artifact["id"]
        if not overwrite:
            echo(f"  Artifact exists: {artifact_id} — staging for update")
        await am.edit(artifact_id=artifact_id, stage=True)
    except Exception:
        echo(f"  Creating artifact: {artifact_alias}")
        artifact = await am.create(
            alias=artifact_alias,
            type="dataset",
            manifest={
                "name": artifact_alias,
                "description": f"Safe Colab dataset: {data_dir_path.name}",
            },
            config={
                # Owner full access; others need explicit grant or token
                "permissions": {"@": "rw+"},
            },
            stage=True,
        )
        artifact_id = artifact["id"]

    # ── Collect files (skip hidden) ──────────────────────────────────────────
    files = []
    for path in sorted(data_dir_path.rglob("*")):
        if path.is_file() and not any(p.startswith(".") for p in path.parts):
            rel = str(path.relative_to(data_dir_path))
            files.append((rel, str(path), path.stat().st_size))

    total = len(files)
    echo(f"  Uploading {total} file(s) from {data_dir_path}")

    # ── Upload ───────────────────────────────────────────────────────────────
    async with httpx.AsyncClient(timeout=UPLOAD_TIMEOUT) as http:
        for idx, (rel_path, local_path, size) in enumerate(files):
            size_str = _human_size(size)
            echo(f"  [{idx+1}/{total}] {rel_path} ({size_str})")

            # Re-enter staging before each put_file (required by artifact manager)
            try:
                await am.edit(artifact_id=artifact_id, stage=True)
            except Exception:
                pass

            if size >= MULTIPART_THRESHOLD:
                echo(f"    → multipart ({(size // CHUNK_SIZE) + 1} parts)")
                await _put_multipart(am, artifact_id, rel_path, local_path, echo)
            else:
                url = await am.put_file(artifact_id=artifact_id, file_path=rel_path)
                await _put_simple(http, url, local_path)

    # ── Commit ───────────────────────────────────────────────────────────────
    echo("  Committing artifact...")
    committed = await am.commit(artifact_id)
    version = committed.get("version", "v0") if isinstance(committed, dict) else "v0"
    echo(f"  Done — version {version}")

    await server.disconnect()

    return {
        "artifact_id": artifact_id,
        "alias": artifact_alias,
        "workspace": workspace,
        "file_count": total,
        "version": version,
    }


async def generate_artifact_token(
    artifact_id: str,
    server_url: str,
    token: str,
    workspace: str,
    expires_in: int = 365 * 24 * 3600,  # 1 year default
) -> str:
    """Generate a long-lived workspace token for artifact access.

    The returned token has read access to the workspace that owns the artifact.
    It is stored in the app's startup_context so the worker pod can download
    the dataset without requiring the user's primary token.
    """
    from hypha_rpc import connect_to_server

    server = await connect_to_server({
        "server_url": server_url,
        "token": token,
        **({"workspace": workspace} if workspace else {}),
    })
    artifact_token = await server.generate_token({
        "expires_in": expires_in,
        "permission": "read",
    })
    await server.disconnect()
    return artifact_token


async def install_runner_app(
    artifact_id: str,
    artifact_alias: str,
    artifact_token: str,
    server_url: str,
    token: str,
    workspace: str,
    guardian_url: Optional[str] = None,
    echo: Optional[Callable[[str], None]] = None,
) -> dict:
    """Install a safe-colab-runner server app in Hypha directly from the CLI.

    The worker inside the guardian pod listens for apps of this type and spins
    up an agent-sandbox pod on demand.

    Returns {"app_id": <installed_id>}.
    """
    from hypha_rpc import connect_to_server

    _echo = echo or (lambda s: None)

    server = await connect_to_server({
        "server_url": server_url,
        "token": token,
        **({"workspace": workspace} if workspace else {}),
    })

    try:
        server_apps = await server.get_service("server-apps")
    except Exception as e:
        await server.disconnect()
        raise RuntimeError(f"Could not get server-apps service: {e}") from e

    app_config = {
        "artifact_id": artifact_id,
        "artifact_token": artifact_token,
        "hypha_server_url": server_url,
        "hypha_workspace": workspace,
    }
    if guardian_url:
        app_config["guardian_url"] = guardian_url

    manifest = {
        "id": artifact_alias,
        "name": f"Safe Colab: {artifact_alias}",
        "type": "safe-colab-runner",
        "description": f"Remote safe-colab session — dataset: {artifact_alias}",
        "version": "1.0.0",
        "config": app_config,
    }

    try:
        installed_id = await server_apps.install(
            manifest=manifest,
            overwrite=True,
        )
    except Exception as e:
        await server.disconnect()
        raise RuntimeError(f"server-apps.install failed: {e}") from e

    await server.disconnect()
    _echo(f"  Installed runner app: {installed_id}")
    return {"app_id": installed_id}


def _human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"
