import os
import tempfile
from pathlib import Path

import pytest

from qwen3_repo.ingester import (
    CODE_EXTENSIONS,
    ContextBudget,
    FileRole,
    RepoFile,
    SKIP_EXTENSIONS,
    _compute_importance_scores,
    _topological_sort,
    build_dependency_graph,
    classify_file_role,
    compute_ordering,
    discover_files,
    estimate_tokens,
    extract_go_imports,
    extract_js_ts_imports,
    extract_python_imports,
    format_context_pack,
    is_text_file,
    resolve_import_to_path,
    should_skip_path,
)


class TestEstimateTokens:
    def test_empty_string(self):
        assert estimate_tokens("") == 1

    def test_english_text(self):
        text = "def hello_world():\n    return 42\n"
        tokens = estimate_tokens(text)
        assert 5 < tokens < 20

    def test_cjk_text(self):
        text = "def func():\n    pass\n"
        base = estimate_tokens(text)
        cjk_text = text + "中文测试"
        cjk = estimate_tokens(cjk_text)
        assert cjk > base


class TestContextBudget:
    def test_default_27b(self):
        b = ContextBudget()
        assert b.model == "Qwen3.6-27B"
        assert b.max_context == 262_144
        assert b.pack_budget == 180_000

    def test_extended_context(self):
        b = ContextBudget("Qwen3.6-27B", extended=True)
        assert b.max_context == 1_010_000

    def test_language_model_only(self):
        b = ContextBudget("Qwen3.6-27B", language_model_only=True)
        assert b.pack_budget > 180_000

    def test_35b_a3b(self):
        b = ContextBudget("Qwen3.6-35B-A3B")
        assert b.max_context == 262_144
        assert b.pack_budget == 180_000

    def test_can_fit(self):
        b = ContextBudget()
        assert b.can_fit(100_000)
        assert not b.can_fit(999_999)

    def test_qwen3_32b(self):
        b = ContextBudget("Qwen3-32B")
        assert b.max_context == 32_768
        assert b.pack_budget == 24_000

    def test_qwen3_32b_extended(self):
        b = ContextBudget("Qwen3-32B", extended=True)
        assert b.max_context == 131_072

    def test_qwen3_small_model(self):
        b = ContextBudget("Qwen3-0.6B")
        assert b.max_context == 32_768
        assert b.pack_budget == 20_000

    def test_unknown_model_uses_qwen3_32b_defaults(self):
        b = ContextBudget("unknown-model")
        assert b.max_context == 32_768


class TestFileClassification:
    def test_config_files(self):
        assert classify_file_role("pyproject.toml") == FileRole.CONFIG
        assert classify_file_role("package.json") == FileRole.CONFIG
        assert classify_file_role("requirements.txt") == FileRole.CONFIG

    def test_type_def_files(self):
        assert classify_file_role("src/types.py") == FileRole.TYPE_DEF
        assert classify_file_role("src/models.ts") == FileRole.TYPE_DEF
        assert classify_file_role("src/pkg/__init__.py") == FileRole.TYPE_DEF

    def test_test_files(self):
        assert classify_file_role("tests/test_main.py") == FileRole.TEST
        assert classify_file_role("src/foo.test.ts") == FileRole.TEST
        assert classify_file_role("spec/helper_spec.rb") == FileRole.TEST

    def test_doc_files(self):
        assert classify_file_role("README.md") == FileRole.DOC
        assert classify_file_role("docs/guide.rst") == FileRole.DOC

    def test_asset_files(self):
        assert classify_file_role("assets/logo.png") == FileRole.ASSET

    def test_build_files(self):
        assert classify_file_role(".github/workflows/ci.yml") == FileRole.BUILD
        assert classify_file_role("Dockerfile") == FileRole.BUILD

    def test_unclassified(self):
        assert classify_file_role("random_file.xyz") == FileRole.OTHER


class TestSkipPath:
    def test_skips_git(self):
        assert should_skip_path(".git/config")

    def test_skips_pycache(self):
        assert should_skip_path("__pycache__/module.pyc")

    def test_skips_node_modules(self):
        assert should_skip_path("node_modules/pkg/index.js")

    def test_allows_normal_paths(self):
        assert not should_skip_path("src/main.py")
        assert not should_skip_path("lib/core/engine.ts")


class TestPythonImports:
    def test_simple_import(self):
        imports = extract_python_imports("import os\nimport json")
        assert "os" in imports
        assert "json" in imports

    def test_from_import(self):
        imports = extract_python_imports("from pathlib import Path")
        assert "pathlib" in imports

    def test_syntax_error_fallback(self):
        imports = extract_python_imports("import os\nthis is broken {{")
        assert "os" in imports


class TestJsTsImports:
    def test_es_import(self):
        imports = extract_js_ts_imports("import { foo } from './utils'")
        assert "./utils" in imports

    def test_require(self):
        imports = extract_js_ts_imports("const fs = require('fs')")
        assert "fs" in imports

    def test_dynamic_import(self):
        imports = extract_js_ts_imports("const mod = import('./lazy')")
        assert "./lazy" in imports


class TestGoImports:
    def test_go_imports(self):
        imports = extract_go_imports('import "github.com/foo/bar"')
        assert "github.com/foo/bar" in imports


class TestResolveImport:
    def test_resolve_python_module(self):
        files = {"mypackage/utils.py": RepoFile(path="mypackage/utils.py", abs_path="")}
        resolved = resolve_import_to_path("mypackage.utils", files)
        assert "mypackage/utils.py" in resolved

    def test_resolve_init(self):
        files = {"mypackage/__init__.py": RepoFile(path="mypackage/__init__.py", abs_path="")}
        resolved = resolve_import_to_path("mypackage", files)
        assert "mypackage/__init__.py" in resolved


class TestDiscoverFiles:
    def test_discovers_text_files(self, tmp_path):
        (tmp_path / "main.py").write_text("print('hello')")
        (tmp_path / "README.md").write_text("# readme")
        files = discover_files(tmp_path)
        paths = {f.path for f in files}
        assert "main.py" in paths
        assert "README.md" in paths

    def test_marks_binary_not_text(self, tmp_path):
        (tmp_path / "data.bin").write_bytes(b"\x00\x01\x02\x03" * 100)
        files = discover_files(tmp_path)
        binfile = next((f for f in files if f.path == "data.bin"), None)
        assert binfile is not None
        assert binfile.is_text is False

    def test_skips_pycache(self, tmp_path):
        cache_dir = tmp_path / "__pycache__"
        cache_dir.mkdir()
        (cache_dir / "mod.pyc").write_bytes(b"\x00" * 50)
        files = discover_files(tmp_path)
        assert len(files) == 0


class TestDependencyGraph:
    def test_builds_graph(self, tmp_path):
        (tmp_path / "a.py").write_text("import b")
        (tmp_path / "b.py").write_text("x = 1")
        files = discover_files(tmp_path)
        graph = build_dependency_graph(files)
        assert "a.py" in graph
        assert "b.py" in graph["a.py"]

    def test_records_imported_by(self, tmp_path):
        (tmp_path / "a.py").write_text("import b")
        (tmp_path / "b.py").write_text("x = 1")
        files = discover_files(tmp_path)
        build_dependency_graph(files)
        b = next(f for f in files if f.path == "b.py")
        assert "a.py" in b.imported_by


class TestComputeOrdering:
    def test_config_before_feature(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text("[project]\nname='test'")
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("print(1)")
        files = discover_files(tmp_path)
        graph = build_dependency_graph(files)
        budget = ContextBudget()
        ordered = compute_ordering(files, graph, budget)
        paths = [f.path for f in ordered]
        config_idx = next(i for i, p in enumerate(paths) if "pyproject" in p)
        app_idx = next(i for i, p in enumerate(paths) if "app.py" in p)
        assert config_idx < app_idx

    def test_respects_budget(self, tmp_path):
        for i in range(50):
            (tmp_path / f"file_{i}.py").write_text("x = 1\n" * 1000)
        files = discover_files(tmp_path)
        graph = build_dependency_graph(files)
        budget = ContextBudget()
        budget.pack_budget = 1000
        ordered = compute_ordering(files, graph, budget)
        total = sum(f.estimated_tokens for f in ordered)
        assert total <= budget.pack_budget * 1.1


class TestTopologicalSort:
    def test_simple_sort(self):
        paths = ["a", "b", "c"]
        deps = {"b": {"a"}, "c": {"b"}}
        importance = {"a": 1.0, "b": 2.0, "c": 3.0}
        result = _topological_sort(paths, deps, importance)
        assert result.index("a") < result.index("b")
        assert result.index("b") < result.index("c")

    def test_cycle_handling(self):
        paths = ["a", "b"]
        deps = {"a": {"b"}, "b": {"a"}}
        importance = {"a": 2.0, "b": 1.0}
        result = _topological_sort(paths, deps, importance)
        assert set(result) == {"a", "b"}


class TestFormatContextPack:
    def test_includes_file_content(self):
        rf = RepoFile(path="main.py", abs_path="", content="print('hi')", is_text=True)
        pack = format_context_pack([rf])
        assert "[FILE: main.py]" in pack
        assert "print('hi')" in pack

    def test_includes_structure_header(self):
        rf = RepoFile(path="main.py", abs_path="", content="x=1", is_text=True)
        pack = format_context_pack([rf], repo_url="https://github.com/test/repo")
        assert "[REPO: repo]" in pack
        assert "[STRUCTURE]" in pack

    def test_no_summary_option(self):
        rf = RepoFile(path="main.py", abs_path="", content="x=1", is_text=True)
        pack = format_context_pack([rf], include_summary=False)
        assert "[STRUCTURE]" not in pack
        assert "[FILE: main.py]" in pack


class TestImportanceScores:
    def test_high_centrality_gets_high_score(self):
        a = RepoFile(path="a.py", abs_path="", imported_by=set())
        b = RepoFile(path="b.py", abs_path="", imported_by={"a.py", "c.py", "d.py"})
        scores = _compute_importance_scores([a, b])
        assert scores["b.py"] > scores["a.py"]

    def test_config_role_boost(self):
        config = RepoFile(path="pyproject.toml", abs_path="", role=FileRole.CONFIG)
        other = RepoFile(path="random.xyz", abs_path="", role=FileRole.OTHER)
        scores = _compute_importance_scores([config, other])
        assert scores["pyproject.toml"] > scores["random.xyz"]
