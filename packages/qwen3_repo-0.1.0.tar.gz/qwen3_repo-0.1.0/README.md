# qwen3-repo

Architecture-aware repo-to-context scaffold for Qwen3 and Qwen3.6. Ingests a GitHub repository into a dependency-ordered context pack, runs an agentic coding loop via any OpenAI-compatible endpoint, and includes NL2Repo / SWE-bench evaluation runners.

## Why ordering matters

Qwen3.6's hybrid architecture (Gated DeltaNet + Gated Attention) processes three out of four layers with linear attention and a fixed-size recurrent state. Placing definitions before their dependents should help the recurrent state accumulate core types and interfaces before call sites reference them.

Standard Qwen3 models use full attention and can look back to any position, so ordering matters less -- but dependency-aware packing still avoids wasting context on low-value files and keeps related code together.

Qwen's NL2Repo evaluations (score: 36.2) were run via Claude Code (`temp=1.0, top_p=0.95, max_turns=900`). This scaffold provides an open-source alternative with architecture-aware context formatting.

## Installation

```bash
pip install qwen3-repo
```

## Quick start

### Ingest a repository

```python
from qwen3_repo import ingest_repo

# Works with any supported Qwen3 or Qwen3.6 model
context_pack, files, budget = ingest_repo(
    "https://github.com/user/repo",
    model="Qwen3-32B",
)
print(f"{len(files)} files, ~{budget.pack_budget:,} token budget")
```

### Rank files by importance

```python
from qwen3_repo import rank_files
from qwen3_repo.ingester import discover_files
from pathlib import Path

files = discover_files(Path("/path/to/repo"))
ranked = rank_files(files)
for r in ranked[:10]:
    print(f"{r.score:.2f}  {r.path}")
```

### Detect vision encoder needs

```python
from qwen3_repo import detect_vision_needs
from pathlib import Path

# Vision encoder is only relevant for Qwen3.6 (Qwen3 has no vision)
result = detect_vision_needs(Path("/path/to/repo"))
print(result["recommendation"])
# "Consider --language-model-only. Frees ~6 GB KV cache (~100K-150K additional tokens)."
```

### Run the agentic scaffold

```bash
# Start a vLLM server first:
# vllm serve Qwen/Qwen3-32B --port 8000

python -m qwen3_repo.scaffold \
    --repo-path /path/to/repo \
    --task "Fix the failing test in test_auth.py" \
    --max-turns 900 \
    --temperature 1.0 \
    --top-p 0.95
```

### Run NL2Repo evaluation

```bash
python -m qwen3_repo.eval.nl2repo \
    --tasks nl2repo_tasks.json \
    --api-url http://localhost:8000/v1 \
    --model Qwen/Qwen3.6-27B \
    --output-dir nl2repo_results
```

### Compare Claude Code vs qwen3-repo

```bash
python -m qwen3_repo.bench_compare \
    --tasks comparison_tasks.json \
    --repo-path /path/to/repo \
    --markdown
```

## Context ordering strategy

1. **Role-based grouping**: CONFIG -> TYPE_DEF -> CORE_LIB -> UTILITY -> FEATURE -> TEST -> DOC -> BUILD
2. **Dependency-aware ordering**: Topological sort within each group (Kahn's algorithm, importance as tiebreaker)
3. **Budget trimming**: Lowest-importance files dropped first; tests and docs trimmed before core code

## Importance scoring signals

| Signal | Weight | Description |
|--------|--------|-------------|
| Centrality | 3.0 | How many files import this file (log-scaled) |
| Role weight | 2.0 | TYPE_DEF > CONFIG > CORE_LIB > FEATURE > TEST > DOC |
| Recency | 1.5 | Exponentially decayed git last-modified (30-day half-life) |
| Coverage | 1.0 | Whether corresponding test files exist |
| Structural | 0.8 | Directory depth (root > deep nesting) |
| Size efficiency | 0.5 | Information density (tokens/byte) |

## Vision encoder decision (Qwen3.6 only)

Qwen3 models have no vision encoder. For Qwen3.6:

| Repo contents | Vision encoder | Reason |
|---------------|---------------|--------|
| No images | Disabled (`--language-model-only`) | Frees ~6 GB KV cache |
| Design mockups/screenshots | Enabled | Model needs to see design intent |
| SVG diagrams | Enabled | Vision helps with SVG understanding |
| Canvas/WebGL code | Enabled | Vision helps understand visual output |
| Only icons/favicons | Disabled | Low relevance, not worth KV cost |

## Supported models

### Qwen3 (standard transformer, full attention)

| Model | Context |
|-------|---------|
| Qwen3-235B-A22B | 32K native, 128K extended |
| Qwen3-32B | 32K native, 128K extended |
| Qwen3-30B-A3B | 32K native, 128K extended |
| Qwen3-14B | 32K native, 128K extended |
| Qwen3-8B | 32K native, 128K extended |
| Qwen3-4B | 32K native |
| Qwen3-1.7B | 32K native |
| Qwen3-0.6B | 32K native |

### Qwen3.6 (hybrid Gated DeltaNet + Gated Attention)

| Model | Layers | Layout | Context |
|-------|--------|--------|---------|
| Qwen3.6-27B | 64 | 16 x (3 x GDN + 1 x GA) | 262K native, 1M extended |
| Qwen3.6-35B-A3B | 40 | 10 x (3 x GDN + 1 x GA), MoE | 262K native |

## License

Apache 2.0
