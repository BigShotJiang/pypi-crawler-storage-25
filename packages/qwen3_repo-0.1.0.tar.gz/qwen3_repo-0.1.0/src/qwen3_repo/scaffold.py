"""OpenAI-compatible agentic loop for Qwen3 and Qwen3.6."""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "bash",
            "description": (
                "Execute a bash command in the repository workspace. "
                "Working directory is the repository root."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "The bash command to execute"},
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds (default: 120)",
                        "default": 120,
                    },
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "file_edit",
            "description": "Create or edit a file in the repository workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path from repo root"},
                    "content": {"type": "string", "description": "Full file content to write"},
                    "create_if_missing": {
                        "type": "boolean",
                        "description": "Create the file if it doesn't exist (default: true)",
                        "default": True,
                    },
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "file_read",
            "description": "Read the contents of a file in the repository workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path from repo root"},
                    "start_line": {"type": "integer", "description": "Starting line (1-based)"},
                    "end_line": {"type": "integer", "description": "Ending line (inclusive)"},
                },
                "required": ["path"],
            },
        },
    },
]

SYSTEM_PROMPT_TEMPLATE = """You are an expert software engineering agent with access to a repository workspace.

Tools: bash, file_edit, file_read

## Repository Context

{context_pack}

## Instructions

1. Read the task carefully and identify what needs to change.
2. Explore the relevant code before making changes.
3. Make minimal, correct edits.
4. Run tests to verify your changes.
5. Iterate if tests fail."""


# ---------------------------------------------------------------------------
# API client
# ---------------------------------------------------------------------------

class OpenAIClient:
    def __init__(
        self,
        base_url: str = "http://localhost:8000/v1",
        api_key: str = "EMPTY",
        model: str = "Qwen/Qwen3.6-27B",
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model

    def chat_completion(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict]] = None,
        temperature: float = 1.0,
        top_p: float = 0.95,
        max_tokens: int = 8192,
        thinking: bool = True,
    ) -> Dict[str, Any]:
        import urllib.request

        url = f"{self.base_url}/chat/completions"

        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens,
        }

        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        if thinking:
            payload["extra_body"] = {"thinking": {"type": "enabled", "budget_tokens": 8192}}
            payload["chat_template_kwargs"] = {"thinking": True}

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")

        with urllib.request.urlopen(req, timeout=300) as resp:
            return json.loads(resp.read().decode("utf-8"))


# ---------------------------------------------------------------------------
# Tool execution
# ---------------------------------------------------------------------------

@dataclass
class ToolResult:
    tool_call_id: str
    function_name: str
    output: str
    success: bool = True


def execute_bash(command: str, cwd: str, timeout: int = 120) -> ToolResult:
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
            env={**os.environ, "TERM": "dumb"},
        )
        output = result.stdout
        if result.stderr:
            output += f"\nSTDERR:\n{result.stderr}"

        max_output = 50_000
        if len(output) > max_output:
            output = output[:max_output] + f"\n... [truncated, {len(output) - max_output} chars]"

        return ToolResult(
            tool_call_id="",
            function_name="bash",
            output=output,
            success=result.returncode == 0,
        )
    except subprocess.TimeoutExpired:
        return ToolResult(
            tool_call_id="",
            function_name="bash",
            output=f"Command timed out after {timeout}s",
            success=False,
        )
    except Exception as e:
        return ToolResult(
            tool_call_id="",
            function_name="bash",
            output=f"Error: {e}",
            success=False,
        )


def execute_file_edit(
    path: str, content: str, cwd: str, create_if_missing: bool = True,
) -> ToolResult:
    try:
        full_path = Path(cwd) / path
        if not create_if_missing and not full_path.exists():
            return ToolResult(
                tool_call_id="",
                function_name="file_edit",
                output=f"File does not exist: {path}",
                success=False,
            )

        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")

        return ToolResult(
            tool_call_id="",
            function_name="file_edit",
            output=f"Wrote {len(content)} chars to {path}",
            success=True,
        )
    except Exception as e:
        return ToolResult(
            tool_call_id="",
            function_name="file_edit",
            output=f"Error: {e}",
            success=False,
        )


def execute_file_read(
    path: str, cwd: str, start_line: int = 1, end_line: Optional[int] = None,
) -> ToolResult:
    try:
        full_path = Path(cwd) / path
        if not full_path.exists():
            return ToolResult(
                tool_call_id="",
                function_name="file_read",
                output=f"File does not exist: {path}",
                success=False,
            )

        lines = full_path.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
        start_idx = max(0, start_line - 1)
        end_idx = end_line if end_line else len(lines)
        selected = lines[start_idx:end_idx]

        numbered = [f"{i:>6}\t{line.rstrip()}" for i, line in enumerate(selected, start=start_line)]
        output = "\n".join(numbered)

        if len(output) > 100_000:
            output = output[:100_000] + "\n... [truncated]"

        return ToolResult(
            tool_call_id="",
            function_name="file_read",
            output=output,
            success=True,
        )
    except Exception as e:
        return ToolResult(
            tool_call_id="",
            function_name="file_read",
            output=f"Error: {e}",
            success=False,
        )


def execute_tool(function_name: str, arguments: Dict[str, Any], cwd: str) -> ToolResult:
    if function_name == "bash":
        return execute_bash(arguments["command"], cwd, arguments.get("timeout", 120))
    elif function_name == "file_edit":
        return execute_file_edit(
            arguments["path"], arguments["content"], cwd, arguments.get("create_if_missing", True),
        )
    elif function_name == "file_read":
        return execute_file_read(
            arguments["path"], cwd, arguments.get("start_line", 1), arguments.get("end_line"),
        )
    return ToolResult(tool_call_id="", function_name=function_name, output=f"Unknown tool: {function_name}", success=False)


# ---------------------------------------------------------------------------
# Agentic loop
# ---------------------------------------------------------------------------

@dataclass
class AgentRunResult:
    task_id: str
    task_description: str
    success: bool
    total_turns: int
    total_tokens: int = 0
    total_time: float = 0.0
    tool_calls: int = 0
    bash_commands: int = 0
    file_edits: int = 0
    file_reads: int = 0
    error: Optional[str] = None
    final_response: Optional[str] = None
    conversation: List[Dict] = field(default_factory=list)


_COMPLETION_PATTERNS = [
    r"task\s+(is\s+)?complete",
    r"successfully\s+(implemented|fixed|resolved|updated)",
    r"all\s+tests\s+pass",
    r"changes?\s+(have\s+)?been\s+(made|applied|implemented)",
    r"the\s+(issue|bug|feature)\s+(is\s+)?(fixed|resolved|implemented)",
]


def _assess_completion(final_response: str) -> bool:
    if not final_response:
        return False
    for pattern in _COMPLETION_PATTERNS:
        if re.search(pattern, final_response, re.IGNORECASE):
            return True
    return False


def run_agent(
    task_description: str,
    repo_path: str,
    context_pack: str,
    client: OpenAIClient,
    max_turns: int = 900,
    temperature: float = 1.0,
    top_p: float = 0.95,
    max_tokens: int = 8192,
    thinking: bool = True,
    task_id: Optional[str] = None,
    on_turn_complete: Optional[Callable] = None,
) -> AgentRunResult:
    task_id = task_id or str(uuid.uuid4())[:8]
    start_time = time.time()

    result = AgentRunResult(
        task_id=task_id,
        task_description=task_description,
        success=False,
        total_turns=0,
    )

    system_prompt = SYSTEM_PROMPT_TEMPLATE.format(context_pack=context_pack)
    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": task_description},
    ]

    for turn in range(max_turns):
        result.total_turns = turn + 1

        try:
            response = client.chat_completion(
                messages=messages,
                tools=TOOL_DEFINITIONS,
                temperature=temperature,
                top_p=top_p,
                max_tokens=max_tokens,
                thinking=thinking,
            )

            choice = response.get("choices", [{}])[0]
            message = choice.get("message", {})

            usage = response.get("usage", {})
            result.total_tokens += usage.get("total_tokens", 0)

            messages.append(message)
            result.conversation.append({
                "turn": turn + 1,
                "role": "assistant",
                "content": message.get("content", ""),
                "tool_calls": message.get("tool_calls"),
            })

            tool_calls = message.get("tool_calls", [])

            if not tool_calls:
                result.final_response = message.get("content", "")
                result.success = _assess_completion(result.final_response)
                break

            for tc in tool_calls:
                func = tc.get("function", {})
                func_name = func.get("name", "")
                try:
                    func_args = json.loads(func.get("arguments", "{}"))
                except json.JSONDecodeError:
                    func_args = {}

                tool_result = execute_tool(func_name, func_args, repo_path)
                tool_result.tool_call_id = tc.get("id", "")

                result.tool_calls += 1
                if func_name == "bash":
                    result.bash_commands += 1
                elif func_name == "file_edit":
                    result.file_edits += 1
                elif func_name == "file_read":
                    result.file_reads += 1

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", ""),
                    "content": tool_result.output,
                })

            if on_turn_complete:
                on_turn_complete(turn + 1, result)

        except Exception as e:
            result.error = str(e)
            logger.error("Turn %d failed: %s", turn + 1, e)
            break

    result.total_time = time.time() - start_time
    return result


def run_evaluation(
    tasks: List[Dict[str, str]],
    repo_path: str,
    context_pack: str,
    client: OpenAIClient,
    max_turns: int = 900,
    temperature: float = 1.0,
    top_p: float = 0.95,
    output_dir: Optional[str] = None,
) -> List[AgentRunResult]:
    results: List[AgentRunResult] = []

    for i, task in enumerate(tasks):
        task_id = task.get("id", f"task-{i + 1}")
        task_desc = task.get("description", task.get("task", ""))

        logger.info("Running task %d/%d: %s", i + 1, len(tasks), task_id)

        try:
            subprocess.run(["git", "checkout", "."], cwd=repo_path, capture_output=True, timeout=30)
            subprocess.run(["git", "clean", "-fd"], cwd=repo_path, capture_output=True, timeout=30)
        except (subprocess.TimeoutExpired, OSError):
            logger.warning("Failed to reset workspace for task %s", task_id)

        result = run_agent(
            task_description=task_desc,
            repo_path=repo_path,
            context_pack=context_pack,
            client=client,
            max_turns=max_turns,
            temperature=temperature,
            top_p=top_p,
            task_id=task_id,
        )
        results.append(result)

        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            output_path = os.path.join(output_dir, f"{task_id}.json")
            with open(output_path, "w") as f:
                json.dump({
                    "task_id": result.task_id,
                    "success": result.success,
                    "total_turns": result.total_turns,
                    "total_tokens": result.total_tokens,
                    "total_time": result.total_time,
                    "tool_calls": result.tool_calls,
                    "error": result.error,
                    "final_response": result.final_response,
                }, f, indent=2)

    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    import argparse

    parser = argparse.ArgumentParser(description="Qwen3 and Qwen3.6 agentic scaffold")
    parser.add_argument("--api-url", default="http://localhost:8000/v1")
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", default="Qwen/Qwen3.6-27B")
    parser.add_argument("--repo-path", required=True)
    parser.add_argument("--context-pack", help="Path to context pack file")
    parser.add_argument("--task")
    parser.add_argument("--task-file")
    parser.add_argument("--max-turns", type=int, default=900)
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--top-p", type=float, default=0.95)
    parser.add_argument("--max-tokens", type=int, default=8192)
    parser.add_argument("--no-thinking", action="store_true")
    parser.add_argument("--output-dir")
    parser.add_argument("--verbose", "-v", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(message)s",
    )

    if args.context_pack:
        with open(args.context_pack, "r") as f:
            context_pack = f.read()
    else:
        from qwen3_repo.ingester import (
            ContextBudget,
            build_dependency_graph,
            compute_ordering,
            discover_files,
            format_context_pack,
        )

        repo_root = Path(args.repo_path)
        files = discover_files(repo_root)
        dep_graph = build_dependency_graph(files)
        budget = ContextBudget(args.model)
        ordered = compute_ordering(files, dep_graph, budget)
        context_pack = format_context_pack(ordered)

    if args.task:
        task = args.task
    elif args.task_file:
        with open(args.task_file, "r") as f:
            task = f.read().strip()
    else:
        task = input("Enter task description: ")

    client = OpenAIClient(base_url=args.api_url, api_key=args.api_key, model=args.model)

    result = run_agent(
        task_description=task,
        repo_path=args.repo_path,
        context_pack=context_pack,
        client=client,
        max_turns=args.max_turns,
        temperature=args.temperature,
        top_p=args.top_p,
        max_tokens=args.max_tokens,
        thinking=not args.no_thinking,
    )

    print(f"\n--- Agent Run Summary ---")
    print(f"Task: {result.task_id}")
    print(f"Success: {result.success}")
    print(f"Turns: {result.total_turns}")
    print(f"Tokens: {result.total_tokens:,}")
    print(f"Time: {result.total_time:.1f}s")
    print(
        f"Tool calls: {result.tool_calls} "
        f"(bash: {result.bash_commands}, edit: {result.file_edits}, read: {result.file_reads})"
    )


if __name__ == "__main__":
    main()
