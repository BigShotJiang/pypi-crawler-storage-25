"""Git clone -> dependency graph -> ordered context pack for Qwen3 and Qwen3.6."""

from __future__ import annotations

import ast
import heapq
import logging
import os
import re
import subprocess
import tempfile
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

# Qwen tokenizer averages ~3.5 chars/token on code, ~4.0 on English prose.
# Errs slightly low (overestimates token count) so we don't exceed budgets.
CHARS_PER_TOKEN_CODE = 3.5
CHARS_PER_TOKEN_PROSE = 4.0


def estimate_tokens(text: str) -> int:
    cjk_chars = len(re.findall(r"[一-鿿㐀-䶿]", text))
    latin_chars = len(text) - cjk_chars
    tokens = int(latin_chars / CHARS_PER_TOKEN_CODE) + int(cjk_chars / 1.75)
    return max(1, tokens)


# ---------------------------------------------------------------------------
# Context budget
# ---------------------------------------------------------------------------

class ContextBudget:
    BUDGETS = {
        # Qwen3: standard dense transformers, full attention
        "Qwen3-235B-A22B": {
            "native": 32_768,
            "extended": 131_072,
            "recommended_pack": 24_000,
            "max_pack": 110_000,
        },
        "Qwen3-32B": {
            "native": 32_768,
            "extended": 131_072,
            "recommended_pack": 24_000,
            "max_pack": 110_000,
        },
        "Qwen3-30B-A3B": {
            "native": 32_768,
            "extended": 131_072,
            "recommended_pack": 24_000,
            "max_pack": 110_000,
        },
        "Qwen3-14B": {
            "native": 32_768,
            "extended": 131_072,
            "recommended_pack": 24_000,
            "max_pack": 110_000,
        },
        "Qwen3-8B": {
            "native": 32_768,
            "extended": 131_072,
            "recommended_pack": 24_000,
            "max_pack": 110_000,
        },
        "Qwen3-4B": {
            "native": 32_768,
            "extended": 32_768,
            "recommended_pack": 24_000,
            "max_pack": 28_000,
        },
        "Qwen3-1.7B": {
            "native": 32_768,
            "extended": 32_768,
            "recommended_pack": 24_000,
            "max_pack": 28_000,
        },
        "Qwen3-0.6B": {
            "native": 32_768,
            "extended": 32_768,
            "recommended_pack": 20_000,
            "max_pack": 28_000,
        },
        # Qwen3.6: hybrid Gated DeltaNet + Gated Attention
        "Qwen3.6-27B": {
            "native": 262_144,
            "extended": 1_010_000,
            "recommended_pack": 180_000,
            "max_pack": 900_000,
        },
        "Qwen3.6-35B-A3B": {
            "native": 262_144,
            "extended": 262_144,
            "recommended_pack": 180_000,
            "max_pack": 230_000,
        },
        "Qwen3.6-Plus": {
            "native": 1_010_000,
            "extended": 1_010_000,
            "recommended_pack": 800_000,
            "max_pack": 950_000,
        },
    }

    def __init__(
        self,
        model: str = "Qwen3.6-27B",
        extended: bool = False,
        language_model_only: bool = False,
    ):
        self.model = model
        self.extended = extended
        self.language_model_only = language_model_only

        budget = self.BUDGETS.get(model, self.BUDGETS["Qwen3-32B"])
        self.max_context = budget["extended"] if extended else budget["native"]

        # Reserve 15% of context for system prompt + tool calls + output,
        # clamped to [4K, 50K] so small models stay usable.
        reserve = max(4_000, min(50_000, int(self.max_context * 0.15)))
        if language_model_only:
            self.pack_budget = min(budget["max_pack"], self.max_context - reserve)
        else:
            self.pack_budget = min(budget["recommended_pack"], self.max_context - reserve)

    def can_fit(self, token_count: int) -> bool:
        return token_count <= self.pack_budget


# ---------------------------------------------------------------------------
# File classification
# ---------------------------------------------------------------------------

class FileRole(Enum):
    CONFIG = 0
    TYPE_DEF = 1
    CORE_LIB = 2
    UTILITY = 3
    FEATURE = 4
    TEST = 5
    DOC = 6
    ASSET = 7
    BUILD = 8
    OTHER = 9


ROLE_PATTERNS: Dict[FileRole, List[str]] = {
    FileRole.CONFIG: [
        r"pyproject\.toml$", r"setup\.py$", r"setup\.cfg$",
        r"package\.json$", r"Cargo\.toml$", r"go\.mod$",
        r"tsconfig\.json$", r"\.env\.example$", r"Makefile$",
        r"requirements.*\.txt$", r"Pipfile$", r"pom\.xml$",
        r"build\.gradle$", r"CMakeLists\.txt$", r"\.pre-commit-config\.yaml$",
    ],
    FileRole.TYPE_DEF: [
        r"(^|/)types\.", r"(^|/)interfaces\.", r"(^|/)schemas\.", r"(^|/)models\.",
        r"(^|/)__init__\.py$", r"(^|/)index\.ts$", r"(^|/)index\.js$",
        r"(^|/)protocols\.", r"(^|/)abstract\.", r"(^|/)base\.py$",
        r"(^|/)constants\.", r"(^|/)enums\.", r"(^|/)definitions\.",
    ],
    FileRole.CORE_LIB: [
        r"(^|/)core/", r"(^|/)lib/", r"(^|/)src/lib/", r"(^|/)engine/",
        r"(^|/)kernel/", r"(^|/)framework/", r"(^|/)foundation/",
    ],
    FileRole.UTILITY: [
        r"(^|/)utils?/", r"(^|/)helpers?/", r"(^|/)tools?/", r"(^|/)common/",
        r"(^|/)shared/", r"(^|/)support/",
    ],
    FileRole.TEST: [
        r"(^|/)tests?/", r"(^|/)spec/", r"(^|/)__tests__/",
        r"\.test\.", r"\.spec\.",
        r"(^|/)e2e/", r"(^|/)integration/", r"(^|/)fixtures/",
    ],
    FileRole.DOC: [
        r"(^|/)docs?/", r"(^|/)README", r"(^|/)CHANGELOG", r"(^|/)CONTRIBUTING",
        r"\.md$", r"\.rst$", r"\.adoc$",
    ],
    FileRole.ASSET: [
        r"\.(png|jpg|jpeg|gif|svg|webp|ico|bmp|tiff)$",
        r"\.(woff2?|ttf|eot|otf)$",
        r"\.(mp4|mp3|wav|ogg|webm)$",
        r"(^|/)assets/", r"(^|/)static/", r"(^|/)public/",
        r"(^|/)images/", r"(^|/)fonts/",
    ],
    FileRole.BUILD: [
        r"(^|/)\.github/workflows/", r"(^|/)\.gitlab-ci", r"dockerfile",
        r"(^|/)docker-compose", r"(^|/)deploy/", r"(^|/)scripts/",
        r"\.yaml$",
    ],
}

SKIP_EXTENSIONS = {
    ".pyc", ".pyo", ".so", ".dylib", ".dll", ".exe", ".o", ".a",
    ".class", ".jar", ".war", ".zip", ".tar", ".gz", ".bz2", ".xz",
    ".7z", ".rar", ".dmg", ".iso", ".woff", ".woff2", ".ttf", ".eot",
    ".otf", ".mp3", ".mp4", ".avi", ".mov", ".wmv", ".flv", ".webm",
    ".ogv", ".ogg", ".wav", ".flac", ".aac",
}

CODE_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".kt", ".scala",
    ".go", ".rs", ".c", ".cpp", ".h", ".hpp", ".cs", ".rb", ".php",
    ".swift", ".m", ".mm", ".r", ".R", ".lua", ".pl", ".ex", ".exs",
    ".erl", ".hs", ".ml", ".fs", ".clj", ".dart", ".zig", ".nim",
}


@dataclass
class RepoFile:
    path: str
    abs_path: str
    content: Optional[str] = None
    role: FileRole = FileRole.OTHER
    size_bytes: int = 0
    estimated_tokens: int = 0
    imports: Set[str] = field(default_factory=set)
    imported_by: Set[str] = field(default_factory=set)
    is_text: bool = True
    last_modified_days: float = 999.0
    test_coverage: float = 0.0


# ---------------------------------------------------------------------------
# Repository cloning
# ---------------------------------------------------------------------------

def clone_repo(
    repo_url: str,
    target_dir: Optional[str] = None,
    branch: Optional[str] = None,
    depth: Optional[int] = None,
) -> Path:
    if target_dir is None:
        target_dir = tempfile.mkdtemp(prefix="qwen3-repo-")

    cmd = ["git", "clone"]
    if branch:
        cmd.extend(["--branch", branch])
    if depth:
        cmd.extend(["--depth", str(depth)])
    cmd.extend([repo_url, target_dir])

    logger.info("Cloning %s -> %s", repo_url, target_dir)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        raise RuntimeError(f"git clone failed: {result.stderr}")

    return Path(target_dir)


# ---------------------------------------------------------------------------
# File discovery and classification
# ---------------------------------------------------------------------------

_SKIP_DIRS = {
    ".git", "__pycache__", "node_modules", ".tox", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", "venv", ".venv", "env", ".env",
    "dist", "build", ".next", ".nuxt", "target", "out", "bin",
    ".gradle", ".idea", ".vscode", ".DS_Store", "coverage",
    ".terraform", ".serverless", ".cache",
}


def should_skip_path(path: str) -> bool:
    parts = Path(path).parts
    return any(p in _SKIP_DIRS for p in parts)


def classify_file_role(relative_path: str) -> FileRole:
    path_lower = relative_path.lower()
    for role in FileRole:
        patterns = ROLE_PATTERNS.get(role, [])
        for pattern in patterns:
            if re.search(pattern, path_lower):
                return role
    return FileRole.OTHER


def is_text_file(filepath: Path) -> bool:
    if filepath.suffix.lower() in SKIP_EXTENSIONS:
        return False
    try:
        if filepath.stat().st_size > 1_000_000:
            return False
    except OSError:
        return False
    try:
        with open(filepath, "rb") as f:
            chunk = f.read(8192)
        if b"\x00" in chunk:
            return False
    except (OSError, UnicodeDecodeError):
        return False
    return True


def discover_files(repo_root: Path) -> List[RepoFile]:
    files = []
    git_dates = _get_git_file_dates(repo_root)

    for dirpath, dirnames, filenames in os.walk(repo_root):
        dirnames[:] = [d for d in dirnames if not should_skip_path(d)]

        for filename in filenames:
            abs_path = Path(dirpath) / filename
            rel_path = str(abs_path.relative_to(repo_root))

            if should_skip_path(rel_path):
                continue

            text = is_text_file(abs_path)
            role = classify_file_role(rel_path)
            size = abs_path.stat().st_size if abs_path.exists() else 0

            est_tokens = 0
            if text:
                try:
                    with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
                        content = f.read()
                    est_tokens = estimate_tokens(content)
                except (OSError, UnicodeDecodeError):
                    pass

            rf = RepoFile(
                path=rel_path,
                abs_path=str(abs_path),
                role=role,
                size_bytes=size,
                estimated_tokens=est_tokens,
                is_text=text,
                last_modified_days=git_dates.get(rel_path, 999.0),
            )
            files.append(rf)

    return files


def _get_git_file_dates(repo_root: Path) -> Dict[str, float]:
    dates: Dict[str, float] = {}
    try:
        result = subprocess.run(
            ["git", "log", "--name-only", "--pretty=format:%ct", "--diff-filter=AMCR"],
            cwd=str(repo_root), capture_output=True, text=True, timeout=60,
        )
        if result.returncode != 0:
            return dates
        import time
        now = time.time()
        current_ts = None
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            try:
                current_ts = float(line)
                continue
            except ValueError:
                pass
            if current_ts is not None:
                days_ago = (now - current_ts) / 86400
                dates[line] = min(dates.get(line, 999.0), days_ago)
    except (subprocess.TimeoutExpired, OSError):
        pass
    return dates


# ---------------------------------------------------------------------------
# Dependency graph
# ---------------------------------------------------------------------------

def extract_python_imports(content: str) -> Set[str]:
    imports: Set[str] = set()
    try:
        tree = ast.parse(content)
    except SyntaxError:
        for match in re.finditer(r"(?:from|import)\s+([a-zA-Z_][\w.]*)", content):
            imports.add(match.group(1))
        return imports

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.add(node.module)
    return imports


def extract_js_ts_imports(content: str) -> Set[str]:
    imports: Set[str] = set()
    for match in re.finditer(r"""import\s+.*?from\s+['"]([^'"]+)['"]""", content):
        imports.add(match.group(1))
    for match in re.finditer(r"""import\s+['"]([^'"]+)['"]""", content):
        imports.add(match.group(1))
    for match in re.finditer(r"""require\s*\(\s*['"]([^'"]+)['"]\s*\)""", content):
        imports.add(match.group(1))
    for match in re.finditer(r"""import\s*\(\s*['"]([^'"]+)['"]\s*\)""", content):
        imports.add(match.group(1))
    return imports


def extract_go_imports(content: str) -> Set[str]:
    imports: Set[str] = set()
    for match in re.finditer(r'"([^"]+)"', content):
        path = match.group(1)
        if "/" in path and not path.startswith("/"):
            imports.add(path)
    return imports


def extract_imports(filepath: str, content: str) -> Set[str]:
    ext = Path(filepath).suffix.lower()
    if ext == ".py":
        return extract_python_imports(content)
    elif ext in (".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"):
        return extract_js_ts_imports(content)
    elif ext == ".go":
        return extract_go_imports(content)
    return set()


def resolve_import_to_path(import_str: str, repo_files: Dict[str, RepoFile]) -> Set[str]:
    resolved: Set[str] = set()
    parts = import_str.replace(".", "/").replace("\\", "/")

    candidates = [
        parts + ".py",
        parts + ".ts",
        parts + ".tsx",
        parts + ".js",
        parts + ".jsx",
        parts + ".go",
        parts + "/__init__.py",
        parts + "/index.ts",
        parts + "/index.js",
        parts + "/index.tsx",
        parts + "/index.jsx",
        parts + "/mod.go",
    ]

    for candidate in candidates:
        if candidate in repo_files:
            resolved.add(candidate)

    for path in repo_files:
        if path.startswith(parts + "/") or path == parts:
            resolved.add(path)

    return resolved


def build_dependency_graph(files: List[RepoFile]) -> Dict[str, Set[str]]:
    file_index = {f.path: f for f in files}

    for rf in files:
        if not rf.is_text or Path(rf.path).suffix.lower() not in CODE_EXTENSIONS:
            continue
        try:
            with open(rf.abs_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            rf.content = content
            rf.imports = extract_imports(rf.path, content)
        except (OSError, UnicodeDecodeError):
            continue

    dep_graph: Dict[str, Set[str]] = defaultdict(set)
    for rf in files:
        if not rf.imports:
            continue
        for imp in rf.imports:
            resolved = resolve_import_to_path(imp, file_index)
            for target in resolved:
                if target != rf.path:
                    dep_graph[rf.path].add(target)
                    if target in file_index:
                        file_index[target].imported_by.add(rf.path)

    return dict(dep_graph)


# ---------------------------------------------------------------------------
# Topological ordering
# ---------------------------------------------------------------------------

_ROLE_WEIGHTS = {
    FileRole.CONFIG: 2.0,
    FileRole.TYPE_DEF: 2.5,
    FileRole.CORE_LIB: 2.0,
    FileRole.UTILITY: 1.5,
    FileRole.FEATURE: 1.0,
    FileRole.TEST: 0.7,
    FileRole.DOC: 0.5,
    FileRole.ASSET: 0.3,
    FileRole.BUILD: 0.6,
    FileRole.OTHER: 0.8,
}


def _compute_importance_scores(files: List[RepoFile]) -> Dict[str, float]:
    scores: Dict[str, float] = {}
    max_imported_by = max((len(f.imported_by) for f in files), default=1) or 1

    for rf in files:
        centrality = len(rf.imported_by) / max_imported_by
        recency = 1.0 / (1.0 + rf.last_modified_days / 30.0)
        role_w = _ROLE_WEIGHTS.get(rf.role, 1.0)
        size_penalty = 0.8 if rf.estimated_tokens > 50_000 else 1.0
        coverage_bonus = 1.0 + 0.2 * rf.test_coverage

        score = (
            centrality * 3.0
            + recency * 1.0
            + role_w * 2.0
            + size_penalty
            + coverage_bonus * 0.5
        )
        scores[rf.path] = score

    return scores


def _topological_sort(
    paths: List[str],
    deps: Dict[str, Set[str]],
    importance: Dict[str, float],
) -> List[str]:
    in_degree = {p: 0 for p in paths}
    reverse_deps: Dict[str, Set[str]] = defaultdict(set)

    for path in paths:
        for dep in deps.get(path, set()):
            if dep in in_degree:
                in_degree[path] += 1
                reverse_deps[dep].add(path)

    heap: list = []
    for path in paths:
        if in_degree[path] == 0:
            heapq.heappush(heap, (-importance.get(path, 0), path))

    result: List[str] = []
    while heap:
        _, path = heapq.heappop(heap)
        result.append(path)

        for dependent in reverse_deps.get(path, set()):
            if dependent in in_degree:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    heapq.heappush(heap, (-importance.get(dependent, 0), dependent))

    remaining = [p for p in paths if p not in set(result)]
    remaining.sort(key=lambda p: -importance.get(p, 0))
    result.extend(remaining)

    return result


def compute_ordering(
    files: List[RepoFile],
    dep_graph: Dict[str, Set[str]],
    budget: ContextBudget,
) -> List[RepoFile]:
    file_index = {f.path: f for f in files}
    importance = _compute_importance_scores(files)

    role_groups: Dict[FileRole, List[str]] = defaultdict(list)
    for rf in files:
        if rf.is_text:
            role_groups[rf.role].append(rf.path)

    ordered_paths: List[str] = []
    for role in FileRole:
        group = role_groups.get(role, [])
        if not group:
            continue

        sub_deps: Dict[str, Set[str]] = {}
        for path in group:
            deps = dep_graph.get(path, set())
            relevant_deps = deps & (set(group) | set(ordered_paths))
            sub_deps[path] = relevant_deps

        sorted_group = _topological_sort(group, sub_deps, importance)
        ordered_paths.extend(sorted_group)

    result: List[RepoFile] = []
    total_tokens = 0
    for path in ordered_paths:
        rf = file_index.get(path)
        if rf is None:
            continue
        if total_tokens + rf.estimated_tokens > budget.pack_budget:
            if rf.role in (FileRole.TEST, FileRole.DOC, FileRole.BUILD, FileRole.OTHER):
                continue
            if total_tokens + rf.estimated_tokens > budget.pack_budget * 1.1:
                continue
        result.append(rf)
        total_tokens += rf.estimated_tokens

    logger.info(
        "Context pack: %d/%d files, ~%s tokens (budget: %s)",
        len(result), len(files), f"{total_tokens:,}", f"{budget.pack_budget:,}",
    )
    return result


# ---------------------------------------------------------------------------
# Context pack formatting
# ---------------------------------------------------------------------------

def format_context_pack(
    ordered_files: List[RepoFile],
    repo_url: str = "",
    include_summary: bool = True,
) -> str:
    parts: List[str] = []

    if include_summary:
        repo_name = (
            repo_url.rstrip("/").split("/")[-1].replace(".git", "") if repo_url else "repo"
        )
        parts.append(f"[REPO: {repo_name}]")
        parts.append("")

        tree_lines: List[str] = []
        for rf in ordered_files:
            indicator = {
                FileRole.CONFIG: "[config]",
                FileRole.TYPE_DEF: "[types]",
                FileRole.CORE_LIB: "[core]",
                FileRole.UTILITY: "[util]",
                FileRole.FEATURE: "[feature]",
                FileRole.TEST: "[test]",
                FileRole.DOC: "[doc]",
                FileRole.ASSET: "[asset]",
                FileRole.BUILD: "[build]",
                FileRole.OTHER: "",
            }.get(rf.role, "")
            token_info = f"({rf.estimated_tokens:,}t)" if rf.estimated_tokens else ""
            tree_lines.append(f"  {rf.path} {indicator} {token_info}")

        parts.append("[STRUCTURE]")
        parts.extend(tree_lines)
        parts.append("")
        parts.append(
            "[DEPENDENCY ORDERING: definitions precede dependents -- "
            "optimized for Qwen3/3.6 architecture-aware context packing]"
        )
        parts.append("")

    for rf in ordered_files:
        if not rf.is_text:
            parts.append(f"[FILE: {rf.path}]")
            parts.append(f"<binary: {rf.size_bytes:,} bytes, {rf.role.name}>")
            parts.append("")
            continue

        if rf.content is None:
            try:
                with open(rf.abs_path, "r", encoding="utf-8", errors="replace") as f:
                    rf.content = f.read()
            except (OSError, UnicodeDecodeError):
                continue

        parts.append(f"[FILE: {rf.path}]")
        parts.append(rf.content)
        parts.append("")

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def ingest_repo(
    repo_url: str,
    model: str = "Qwen3.6-27B",
    extended_context: bool = False,
    language_model_only: bool = False,
    branch: Optional[str] = None,
    clone_depth: Optional[int] = None,
    target_dir: Optional[str] = None,
    output_file: Optional[str] = None,
    max_tokens: Optional[int] = None,
) -> Tuple[str, List[RepoFile], ContextBudget]:
    repo_root = clone_repo(repo_url, target_dir, branch, clone_depth)

    from qwen3_repo.vision_detect import detect_vision_needs

    vision_config = detect_vision_needs(repo_root)

    if vision_config["has_images"] and not language_model_only:
        logger.info(
            "Repo contains %d image assets. Vision encoder will stay active.",
            vision_config["image_count"],
        )

    budget = ContextBudget(model, extended_context, language_model_only)
    if max_tokens:
        budget.pack_budget = min(max_tokens, budget.pack_budget)

    logger.info("Discovering repository files...")
    all_files = discover_files(repo_root)
    logger.info("Found %d files (%d text)", len(all_files), sum(1 for f in all_files if f.is_text))

    logger.info("Building dependency graph...")
    dep_graph = build_dependency_graph(all_files)
    logger.info("Dependency graph: %d files with dependencies", len(dep_graph))

    logger.info("Computing file ordering...")
    ordered_files = compute_ordering(all_files, dep_graph, budget)

    logger.info("Formatting context pack...")
    context_pack = format_context_pack(ordered_files, repo_url)

    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(context_pack)
        logger.info(
            "Context pack written to %s (~%s tokens)",
            output_file, f"{estimate_tokens(context_pack):,}",
        )

    return context_pack, ordered_files, budget


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description="Ingest a GitHub repo into a Qwen3 and Qwen3.6 context pack"
    )
    parser.add_argument("repo_url", help="GitHub repository URL")
    parser.add_argument(
        "--model", default="Qwen3.6-27B",
        choices=list(ContextBudget.BUDGETS.keys()),
    )
    parser.add_argument("--extended-context", action="store_true")
    parser.add_argument("--language-model-only", action="store_true")
    parser.add_argument("--branch")
    parser.add_argument("--depth", type=int)
    parser.add_argument("--output", "-o")
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--verbose", "-v", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(message)s",
    )

    context_pack, ordered_files, budget = ingest_repo(
        repo_url=args.repo_url,
        model=args.model,
        extended_context=args.extended_context,
        language_model_only=args.language_model_only,
        branch=args.branch,
        clone_depth=args.depth,
        output_file=args.output,
        max_tokens=args.max_tokens,
    )

    if not args.output:
        print(context_pack)

    total_tokens = estimate_tokens(context_pack)
    print(f"\n--- Ingestion Summary ---", file=sys.stderr)
    print(f"Files in pack: {len(ordered_files)}", file=sys.stderr)
    print(f"Estimated tokens: {total_tokens:,}", file=sys.stderr)
    print(f"Context budget: {budget.pack_budget:,}", file=sys.stderr)
    print(f"Utilization: {total_tokens / budget.pack_budget * 100:.1f}%", file=sys.stderr)


if __name__ == "__main__":
    main()
