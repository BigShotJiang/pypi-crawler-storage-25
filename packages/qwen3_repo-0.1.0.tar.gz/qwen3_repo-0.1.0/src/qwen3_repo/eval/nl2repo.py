"""NL2Repo evaluation runner for Qwen3 and Qwen3.6.

Qwen3.6-27B scored 36.2 on NL2Repo, evaluated via Claude Code
(temp=1.0, top_p=0.95, max_turns=900). This runner provides a
neutral alternative using architecture-aware context formatting.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from qwen3_repo.scaffold import OpenAIClient, run_agent

logger = logging.getLogger(__name__)


@dataclass
class NL2RepoTask:
    task_id: str
    description: str
    reference_repo: Optional[str] = None
    test_command: Optional[str] = None
    language: str = "python"
    difficulty: str = "medium"
    category: str = "general"


@dataclass
class NL2RepoResult:
    task_id: str
    success: bool
    score: float = 0.0
    build_success: bool = False
    test_success: bool = False
    completeness: float = 0.0
    correctness: float = 0.0
    total_turns: int = 0
    total_tokens: int = 0
    total_time: float = 0.0
    error: Optional[str] = None


def load_nl2repo_tasks(tasks_file: str) -> List[NL2RepoTask]:
    with open(tasks_file, "r") as f:
        data = json.load(f)

    tasks: List[NL2RepoTask] = []
    for item in data:
        tasks.append(NL2RepoTask(
            task_id=item.get("task_id", f"nl2repo-{len(tasks) + 1:03d}"),
            description=item.get("description", item.get("task", "")),
            reference_repo=item.get("reference_repo"),
            test_command=item.get("test_command"),
            language=item.get("language", "python"),
            difficulty=item.get("difficulty", "medium"),
            category=item.get("category", "general"),
        ))
    return tasks


def load_nl2repo_bench(bench_dir: Optional[str] = None) -> List[NL2RepoTask]:
    if bench_dir and os.path.exists(os.path.join(bench_dir, "tasks.json")):
        return load_nl2repo_tasks(os.path.join(bench_dir, "tasks.json"))

    try:
        from datasets import load_dataset

        ds = load_dataset("NL2Repo/NL2Repo-Bench", split="test")
        tasks: List[NL2RepoTask] = []
        for item in ds:
            tasks.append(NL2RepoTask(
                task_id=item.get("task_id", f"nl2repo-{len(tasks) + 1:03d}"),
                description=item.get("description", item.get("prompt", "")),
                reference_repo=item.get("reference_repo"),
                test_command=item.get("test_command", "pytest"),
                language=item.get("language", "python"),
                difficulty=item.get("difficulty", "medium"),
                category=item.get("category", "general"),
            ))
        return tasks
    except (ImportError, Exception) as e:
        logger.warning("Could not load NL2Repo-Bench from HuggingFace: %s", e)
        return []


def evaluate_nl2repo_task(
    task: NL2RepoTask,
    client: OpenAIClient,
    max_turns: int = 900,
    temperature: float = 1.0,
    top_p: float = 0.95,
    workspace_dir: Optional[str] = None,
) -> NL2RepoResult:
    result = NL2RepoResult(task_id=task.task_id, success=False)

    if workspace_dir is None:
        workspace_dir = tempfile.mkdtemp(prefix="nl2repo-")
    else:
        os.makedirs(workspace_dir, exist_ok=True)

    try:
        subprocess.run(["git", "init"], cwd=workspace_dir, capture_output=True, timeout=10)
    except (subprocess.TimeoutExpired, OSError):
        pass

    task_prompt = (
        f"## Task: Create a Repository\n\n"
        f"Create a complete, functional {task.language} repository based on:\n\n"
        f"{task.description}\n\n"
        f"Requirements:\n"
        f"1. Create all necessary source files, tests, and configuration.\n"
        f"2. Follow {task.language} best practices.\n"
        f"3. Include a README.md.\n"
        f"4. Write comprehensive tests.\n"
    )
    if task.test_command:
        task_prompt += f"\nTest command: `{task.test_command}`\n"

    context_pack = (
        f"[NL2Repo Task: {task.task_id}]\n"
        f"[Language: {task.language}]\n"
        f"[Difficulty: {task.difficulty}]\n"
    )

    start_time = time.time()
    agent_result = run_agent(
        task_description=task_prompt,
        repo_path=workspace_dir,
        context_pack=context_pack,
        client=client,
        max_turns=max_turns,
        temperature=temperature,
        top_p=top_p,
    )

    result.total_turns = agent_result.total_turns
    result.total_tokens = agent_result.total_tokens
    result.total_time = time.time() - start_time
    result.error = agent_result.error

    # Check completeness
    expected_files = _get_expected_files(task)
    existing_files: set = set()
    for dirpath, _, filenames in os.walk(workspace_dir):
        for fn in filenames:
            existing_files.add(os.path.relpath(os.path.join(dirpath, fn), workspace_dir))

    if expected_files:
        found = sum(1 for f in expected_files if any(f in ef for ef in existing_files))
        result.completeness = found / len(expected_files)
    else:
        result.completeness = 1.0 if existing_files else 0.0

    result.build_success = _check_build(workspace_dir, task.language)
    result.score += 0.2 if result.build_success else 0.0

    test_cmd = task.test_command or _discover_test_command(workspace_dir, task.language)
    if test_cmd:
        result.test_success, result.correctness = _run_tests(workspace_dir, test_cmd, task.language)
        result.score += 0.5 * result.correctness

    result.score += 0.3 * result.completeness
    result.success = result.build_success and result.test_success and result.completeness >= 0.5

    return result


def _get_expected_files(task: NL2RepoTask) -> List[str]:
    if task.language == "python":
        return ["pyproject.toml", "README.md", "tests/", "test_", "__init__.py"]
    elif task.language in ("javascript", "typescript"):
        return ["package.json", "README.md", "test/", ".test.", ".spec."]
    elif task.language == "go":
        return ["go.mod", "README.md", "_test.go"]
    elif task.language == "rust":
        return ["Cargo.toml", "README.md", "tests/"]
    return ["README.md"]


def _check_build(workspace_dir: str, language: str) -> bool:
    build_commands = {
        "python": ["pip install -e . 2>/dev/null || python -c 'import .'"],
        "javascript": ["npm install"],
        "typescript": ["npm install && npx tsc --noEmit 2>/dev/null || npm install"],
        "go": ["go build ./..."],
        "rust": ["cargo build"],
    }

    for cmd in build_commands.get(language, []):
        try:
            result = subprocess.run(
                cmd, shell=True, cwd=workspace_dir,
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0:
                return True
        except (subprocess.TimeoutExpired, OSError):
            continue
    return False


def _run_tests(workspace_dir: str, test_command: str, language: str) -> Tuple[bool, float]:
    try:
        result = subprocess.run(
            test_command, shell=True, cwd=workspace_dir,
            capture_output=True, text=True, timeout=300,
        )
        output = result.stdout + result.stderr

        if "pytest" in test_command or language == "python":
            return _parse_pytest_results(output)
        elif "npm test" in test_command or "jest" in test_command:
            return _parse_jest_results(output)
        elif "go test" in test_command:
            return _parse_go_test_results(output)
        return result.returncode == 0, 1.0 if result.returncode == 0 else 0.0

    except (subprocess.TimeoutExpired, OSError):
        return False, 0.0


def _parse_pytest_results(output: str) -> Tuple[bool, float]:
    import re

    match = re.search(r"(\d+) passed", output)
    if not match:
        return False, 0.0

    passed = int(match.group(1))
    failed_match = re.search(r"(\d+) failed", output)
    failed = int(failed_match.group(1)) if failed_match else 0

    total = passed + failed
    if total == 0:
        return False, 0.0
    return failed == 0, passed / total


def _parse_jest_results(output: str) -> Tuple[bool, float]:
    import re

    match = re.search(r"(\d+) passed.*?(\d+) failed", output)
    if match:
        passed = int(match.group(1))
        failed = int(match.group(2))
        total = passed + failed
        return failed == 0, passed / total if total > 0 else 0.0

    match = re.search(r"Tests:\s+(\d+)\s+passed", output)
    if match:
        return True, 1.0
    return False, 0.0


def _parse_go_test_results(output: str) -> Tuple[bool, float]:
    import re

    if "FAIL" in output:
        passed = len(re.findall(r"--- PASS:", output))
        failed = len(re.findall(r"--- FAIL:", output))
        total = passed + failed
        return failed == 0, passed / total if total > 0 else 0.0
    elif "ok" in output or "PASS" in output:
        return True, 1.0
    return False, 0.0


def _discover_test_command(workspace_dir: str, language: str) -> Optional[str]:
    if language == "python":
        return "pytest -x"
    elif language in ("javascript", "typescript"):
        return "npm test"
    elif language == "go":
        return "go test ./..."
    elif language == "rust":
        return "cargo test"
    return None


def run_nl2repo_evaluation(
    tasks: List[NL2RepoTask],
    client: OpenAIClient,
    max_turns: int = 900,
    temperature: float = 1.0,
    top_p: float = 0.95,
    output_dir: Optional[str] = None,
    workspace_base: Optional[str] = None,
) -> Dict:
    results: List[NL2RepoResult] = []
    workspace_base = workspace_base or tempfile.mkdtemp(prefix="nl2repo-eval-")

    for i, task in enumerate(tasks):
        logger.info("NL2Repo Task %d/%d: %s", i + 1, len(tasks), task.task_id)

        workspace = os.path.join(workspace_base, task.task_id)
        result = evaluate_nl2repo_task(
            task=task, client=client,
            max_turns=max_turns, temperature=temperature, top_p=top_p,
            workspace_dir=workspace,
        )
        results.append(result)

        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            path = os.path.join(output_dir, f"{task.task_id}.json")
            with open(path, "w") as f:
                json.dump({
                    "task_id": result.task_id,
                    "success": result.success,
                    "score": result.score,
                    "build_success": result.build_success,
                    "test_success": result.test_success,
                    "completeness": result.completeness,
                    "correctness": result.correctness,
                    "total_turns": result.total_turns,
                    "total_tokens": result.total_tokens,
                    "total_time": result.total_time,
                    "error": result.error,
                }, f, indent=2)

    total = len(results)
    if total == 0:
        return {"error": "No tasks to evaluate"}

    avg_score = sum(r.score for r in results) / total
    nl2repo_score = avg_score * 100

    summary = {
        "model": client.model,
        "framework": "qwen3-repo",
        "num_tasks": total,
        "nl2repo_score": round(nl2repo_score, 1),
        "success_rate": round(sum(1 for r in results if r.success) / total * 100, 1),
        "build_rate": round(sum(1 for r in results if r.build_success) / total * 100, 1),
        "test_rate": round(sum(1 for r in results if r.test_success) / total * 100, 1),
        "avg_completeness": round(sum(r.completeness for r in results) / total, 3),
        "avg_correctness": round(sum(r.correctness for r in results) / total, 3),
        "config": {
            "temperature": temperature,
            "top_p": top_p,
            "max_turns": max_turns,
        },
        "comparison": {
            "qwen3_reported_score": 36.2,
            "qwen_original_scaffold": "Claude Code",
        },
    }

    if output_dir:
        with open(os.path.join(output_dir, "nl2repo_summary.json"), "w") as f:
            json.dump(summary, f, indent=2)

    return summary


def main():
    import argparse

    parser = argparse.ArgumentParser(description="NL2Repo evaluation for Qwen3 and Qwen3.6")
    parser.add_argument("--tasks")
    parser.add_argument("--bench-dir")
    parser.add_argument("--api-url", default="http://localhost:8000/v1")
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", default="Qwen/Qwen3.6-27B")
    parser.add_argument("--max-turns", type=int, default=900)
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--top-p", type=float, default=0.95)
    parser.add_argument("--output-dir", default="nl2repo_results")
    parser.add_argument("--workspace")
    parser.add_argument("--verbose", "-v", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(message)s",
    )

    if args.tasks:
        tasks = load_nl2repo_tasks(args.tasks)
    else:
        tasks = load_nl2repo_bench(args.bench_dir)

    if not tasks:
        print("Error: No tasks loaded. Provide --tasks or --bench-dir", file=sys.stderr)
        return

    print(f"Loaded {len(tasks)} NL2Repo tasks")
    print(f"Model: {args.model}")
    print(f"Config: temp={args.temperature}, top_p={args.top_p}, max_turns={args.max_turns}")

    client = OpenAIClient(base_url=args.api_url, api_key=args.api_key, model=args.model)

    summary = run_nl2repo_evaluation(
        tasks=tasks, client=client,
        max_turns=args.max_turns, temperature=args.temperature, top_p=args.top_p,
        output_dir=args.output_dir, workspace_base=args.workspace,
    )

    print(f"\nNL2Repo Score: {summary.get('nl2repo_score', 'N/A')}")
    print(f"Success Rate: {summary.get('success_rate', 'N/A')}%")
    print(f"Qwen's Reported Score: 36.2 (via Claude Code)")


if __name__ == "__main__":
    main()
