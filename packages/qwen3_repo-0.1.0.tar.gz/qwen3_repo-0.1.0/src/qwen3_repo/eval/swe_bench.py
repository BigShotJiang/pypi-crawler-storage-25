"""SWE-bench Verified runner for Qwen3 and Qwen3.6.

Qwen3.6-27B scored 77.2% on SWE-bench Verified using an internal
scaffold (bash + file-edit, temp=1.0, top_p=0.95, 200K context).
This runner provides neutral reproduction via qwen3-repo.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from qwen3_repo.ingester import (
    ContextBudget,
    build_dependency_graph,
    clone_repo,
    compute_ordering,
    discover_files,
    format_context_pack,
)
from qwen3_repo.scaffold import OpenAIClient, run_agent

logger = logging.getLogger(__name__)


@dataclass
class SWEBenchTask:
    task_id: str
    repo: str
    base_commit: str
    problem_statement: str
    hints_text: str = ""
    test_patch: str = ""


@dataclass
class SWEBenchResult:
    task_id: str
    resolved: bool = False
    patch_applied: bool = False
    tests_passed: bool = False
    test_results: Dict = field(default_factory=dict)
    total_turns: int = 0
    total_tokens: int = 0
    total_time: float = 0.0
    model_patch: str = ""
    error: Optional[str] = None


def load_swe_bench_tasks(
    tasks_file: Optional[str] = None,
    split: str = "verified",
    max_tasks: Optional[int] = None,
) -> List[SWEBenchTask]:
    if tasks_file and os.path.exists(tasks_file):
        with open(tasks_file, "r") as f:
            data = json.load(f)
    else:
        try:
            from datasets import load_dataset

            dataset_name = (
                "princeton-nlp/SWE-bench_Verified"
                if split == "verified"
                else "princeton-nlp/SWE-bench"
            )
            ds = load_dataset(dataset_name, split="test")
            data = list(ds)
        except (ImportError, Exception) as e:
            logger.error("Could not load SWE-bench: %s", e)
            return []

    tasks: List[SWEBenchTask] = []
    for item in (data[:max_tasks] if max_tasks else data):
        tasks.append(SWEBenchTask(
            task_id=item.get("instance_id", item.get("task_id", f"swebench-{len(tasks) + 1}")),
            repo=item.get("repo", ""),
            base_commit=item.get("base_commit", item.get("commit", "")),
            problem_statement=item.get("problem_statement", item.get("problem", "")),
            hints_text=item.get("hints_text", ""),
            test_patch=item.get("test_patch", ""),
        ))
    return tasks


def setup_swe_bench_workspace(
    task: SWEBenchTask, base_dir: str, clone_depth: int = 100,
) -> Tuple[str, str]:
    repo_name = task.repo
    if "/" not in repo_name:
        repo_name = f"{repo_name}/{repo_name}"
    repo_url = f"https://github.com/{repo_name}.git"

    workspace = os.path.join(base_dir, task.task_id.replace("/", "__"))
    os.makedirs(workspace, exist_ok=True)

    try:
        repo_root = clone_repo(repo_url, workspace, depth=clone_depth)
    except RuntimeError as e:
        logger.error("Failed to clone %s: %s", repo_url, e)
        return workspace, ""

    try:
        subprocess.run(
            ["git", "fetch", "origin", task.base_commit],
            cwd=str(repo_root), capture_output=True, timeout=60,
        )
        subprocess.run(
            ["git", "checkout", task.base_commit],
            cwd=str(repo_root), capture_output=True, timeout=30,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        logger.warning("Failed to checkout %s: %s", task.base_commit, e)

    if task.test_patch:
        try:
            subprocess.run(
                ["git", "apply", "--allow-empty"],
                input=task.test_patch, text=True,
                cwd=str(repo_root), capture_output=True, timeout=30,
            )
        except (subprocess.TimeoutExpired, OSError):
            pass

    try:
        files = discover_files(repo_root)
        dep_graph = build_dependency_graph(files)
        budget = ContextBudget("Qwen3.6-27B", language_model_only=True)
        # Match Qwen's 200K context window config
        budget.pack_budget = 150_000
        ordered = compute_ordering(files, dep_graph, budget)
        context_pack = format_context_pack(ordered, repo_url)
    except Exception as e:
        logger.error("Failed to generate context pack: %s", e)
        context_pack = ""

    return str(repo_root), context_pack


def evaluate_swe_bench_task(
    task: SWEBenchTask,
    client: OpenAIClient,
    max_turns: int = 900,
    temperature: float = 1.0,
    top_p: float = 0.95,
    base_dir: Optional[str] = None,
) -> SWEBenchResult:
    result = SWEBenchResult(task_id=task.task_id)
    base_dir = base_dir or tempfile.mkdtemp(prefix="swebench-")

    workspace, context_pack = setup_swe_bench_workspace(task, base_dir)

    if not context_pack:
        result.error = "Failed to set up workspace or generate context pack"
        return result

    task_prompt = f"## Task: Fix the following issue\n\n{task.problem_statement}\n"
    if task.hints_text:
        task_prompt += f"\n## Hints\n{task.hints_text}\n"
    task_prompt += (
        "\nInstructions:\n"
        "1. Read the relevant source files.\n"
        "2. Identify the root cause.\n"
        "3. Implement the minimal fix.\n"
        "4. Run tests to verify.\n"
    )

    start_time = time.time()
    agent_result = run_agent(
        task_description=task_prompt,
        repo_path=workspace,
        context_pack=context_pack,
        client=client,
        max_turns=max_turns,
        temperature=temperature,
        top_p=top_p,
    )

    result.total_turns = agent_result.total_turns
    result.total_tokens = agent_result.total_tokens
    result.total_time = time.time() - start_time
    result.error = agent_result.error

    try:
        diff_result = subprocess.run(
            ["git", "diff"], cwd=workspace, capture_output=True, text=True, timeout=30,
        )
        result.model_patch = diff_result.stdout
    except (subprocess.TimeoutExpired, OSError):
        result.model_patch = ""

    if not result.model_patch:
        result.error = "Model did not make any changes"
        return result

    result.patch_applied, result.tests_passed, result.test_results = _validate_patch(
        task, result.model_patch, base_dir,
    )
    result.resolved = result.patch_applied and result.tests_passed

    return result


def _validate_patch(
    task: SWEBenchTask, model_patch: str, base_dir: str,
) -> Tuple[bool, bool, Dict]:
    val_dir = os.path.join(base_dir, f"validation_{task.task_id.replace('/', '__')}")
    os.makedirs(val_dir, exist_ok=True)

    repo_name = task.repo
    if "/" not in repo_name:
        repo_name = f"{repo_name}/{repo_name}"
    repo_url = f"https://github.com/{repo_name}.git"

    try:
        val_root = clone_repo(repo_url, val_dir, depth=100)
    except RuntimeError:
        return False, False, {"details": "Failed to clone for validation"}

    try:
        subprocess.run(
            ["git", "checkout", task.base_commit],
            cwd=str(val_root), capture_output=True, timeout=30,
        )
    except (subprocess.TimeoutExpired, OSError):
        pass

    # Apply model patch
    try:
        apply_result = subprocess.run(
            ["git", "apply", "--allow-empty"],
            input=model_patch, text=True,
            cwd=str(val_root), capture_output=True, timeout=30,
        )
        if apply_result.returncode != 0:
            for p in range(4):
                try:
                    apply_result = subprocess.run(
                        ["patch", f"-p{p}", "--forward", "--no-backup-if-mismatch"],
                        input=model_patch, text=True,
                        cwd=str(val_root), capture_output=True, timeout=30,
                    )
                    if apply_result.returncode == 0:
                        break
                except (subprocess.TimeoutExpired, OSError):
                    continue

            if apply_result.returncode != 0:
                return False, False, {
                    "details": "Patch did not apply cleanly",
                    "error": apply_result.stderr,
                }
    except (subprocess.TimeoutExpired, OSError) as e:
        return False, False, {"details": f"Patch application error: {e}"}

    # Apply test patch
    if task.test_patch:
        try:
            subprocess.run(
                ["git", "apply", "--allow-empty"],
                input=task.test_patch, text=True,
                cwd=str(val_root), capture_output=True, timeout=30,
            )
        except (subprocess.TimeoutExpired, OSError):
            pass

    # Run tests
    test_cmd = _discover_test_command(str(val_root))
    if test_cmd:
        try:
            test_result = subprocess.run(
                test_cmd, shell=True, cwd=str(val_root),
                capture_output=True, text=True, timeout=600,
            )
            return True, test_result.returncode == 0, {
                "command": test_cmd,
                "returncode": test_result.returncode,
            }
        except subprocess.TimeoutExpired:
            return True, False, {"details": "Test suite timed out"}

    return True, False, {"details": "No test command found"}


def _discover_test_command(workspace: str) -> Optional[str]:
    if os.path.exists(os.path.join(workspace, "pyproject.toml")):
        return "pytest -x"
    if os.path.exists(os.path.join(workspace, "pytest.ini")):
        return "pytest -x"
    if os.path.exists(os.path.join(workspace, "tox.ini")):
        return "tox"
    if os.path.exists(os.path.join(workspace, "package.json")):
        return "npm test"
    if os.path.exists(os.path.join(workspace, "go.mod")):
        return "go test ./..."
    # SWE-bench repos are predominantly Python
    if any(f.endswith(".py") for f in os.listdir(workspace)):
        return "pytest -x"
    return None


def run_swe_bench_evaluation(
    tasks: List[SWEBenchTask],
    client: OpenAIClient,
    max_turns: int = 900,
    temperature: float = 1.0,
    top_p: float = 0.95,
    output_dir: Optional[str] = None,
    base_dir: Optional[str] = None,
) -> Dict:
    base_dir = base_dir or tempfile.mkdtemp(prefix="swebench-eval-")
    results: List[SWEBenchResult] = []

    for i, task in enumerate(tasks):
        logger.info("SWE-bench Task %d/%d: %s", i + 1, len(tasks), task.task_id)

        result = evaluate_swe_bench_task(
            task=task, client=client,
            max_turns=max_turns, temperature=temperature, top_p=top_p,
            base_dir=base_dir,
        )
        results.append(result)

        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            path = os.path.join(output_dir, f"{task.task_id.replace('/', '__')}.json")
            with open(path, "w") as f:
                json.dump({
                    "task_id": result.task_id,
                    "resolved": result.resolved,
                    "patch_applied": result.patch_applied,
                    "tests_passed": result.tests_passed,
                    "total_turns": result.total_turns,
                    "total_tokens": result.total_tokens,
                    "total_time": result.total_time,
                    "error": result.error,
                }, f, indent=2)

    total = len(results)
    if total == 0:
        return {"error": "No tasks evaluated"}

    resolved_count = sum(1 for r in results if r.resolved)

    summary = {
        "model": client.model,
        "framework": "qwen3-repo",
        "split": "verified",
        "num_tasks": total,
        "resolved": resolved_count,
        "resolved_rate": round(resolved_count / total * 100, 1),
        "patch_applied_rate": round(
            sum(1 for r in results if r.patch_applied) / total * 100, 1,
        ),
        "avg_turns": round(sum(r.total_turns for r in results) / total, 1),
        "avg_time": round(sum(r.total_time for r in results) / total, 1),
        "config": {
            "temperature": temperature,
            "top_p": top_p,
            "max_turns": max_turns,
            "context_window": "200K",
        },
        "comparison": {
            "qwen3_reported_score": 77.2,
            "qwen_scaffold": "internal (bash + file-edit tools)",
        },
    }

    if output_dir:
        with open(os.path.join(output_dir, "swe_bench_summary.json"), "w") as f:
            json.dump(summary, f, indent=2)

    return summary


def main():
    import argparse

    parser = argparse.ArgumentParser(description="SWE-bench Verified evaluation for Qwen3 and Qwen3.6")
    parser.add_argument("--tasks")
    parser.add_argument("--split", default="verified", choices=["verified", "lite", "full"])
    parser.add_argument("--max-tasks", type=int)
    parser.add_argument("--api-url", default="http://localhost:8000/v1")
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", default="Qwen/Qwen3.6-27B")
    parser.add_argument("--max-turns", type=int, default=900)
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--top-p", type=float, default=0.95)
    parser.add_argument("--output-dir", default="swebench_results")
    parser.add_argument("--workspace")
    parser.add_argument("--verbose", "-v", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(message)s",
    )

    tasks = load_swe_bench_tasks(args.tasks, args.split, args.max_tasks)
    if not tasks:
        print("Error: No tasks loaded", file=sys.stderr)
        return

    print(f"Loaded {len(tasks)} SWE-bench {args.split} tasks")
    print(f"Model: {args.model}")

    client = OpenAIClient(base_url=args.api_url, api_key=args.api_key, model=args.model)

    summary = run_swe_bench_evaluation(
        tasks=tasks, client=client,
        max_turns=args.max_turns, temperature=args.temperature, top_p=args.top_p,
        output_dir=args.output_dir, base_dir=args.workspace,
    )

    print(f"\nResolved: {summary.get('resolved', 'N/A')}/{summary.get('num_tasks', 'N/A')}")
    print(f"Resolved Rate: {summary.get('resolved_rate', 'N/A')}%")
    print(f"Qwen's Reported: 77.2% (internal scaffold)")


if __name__ == "__main__":
    main()
