"""Scan repository for image assets and configure vision encoder (Qwen3.6 only)."""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger(__name__)

IMAGE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".tif",
    ".webp", ".ico", ".svg", ".avif",
}

VIDEO_EXTENSIONS = {
    ".mp4", ".avi", ".mov", ".wmv", ".flv", ".webm", ".ogv", ".mkv",
}

DESIGN_EXTENSIONS = {
    ".fig", ".sketch", ".xd", ".psd", ".ai", ".figma",
}

DESIGN_FILE_PATTERNS = [
    r"mockup", r"wireframe", r"screenshot", r"design",
    r"prototype", r"ui[_-]", r"ux[_-]", r"visual",
    r"figma", r"storybook",
]

_WALK_SKIP = {"node_modules", "__pycache__", "venv", ".venv", "dist", "build", "target", ".git"}


class AssetType(Enum):
    RASTER_IMAGE = "raster_image"
    VECTOR_IMAGE = "vector_image"
    VIDEO = "video"
    DESIGN_FILE = "design_file"
    CSS_ANIMATION = "css_animation"
    CANVAS_WEBGL = "canvas_webgl"
    DIAGRAM = "diagram"


@dataclass
class VisualAsset:
    path: str
    asset_type: AssetType
    size_bytes: int = 0
    relevance_score: float = 0.0


@dataclass
class VisionConfig:
    use_vision: bool = False
    language_model_only: bool = True
    detected_assets: List[VisualAsset] = field(default_factory=list)
    image_count: int = 0
    video_count: int = 0
    design_file_count: int = 0
    svg_count: int = 0
    has_css_animations: bool = False
    has_canvas_webgl: bool = False
    recommendation: str = ""
    kv_cache_savings_gb: float = 0.0


# ---------------------------------------------------------------------------
# Detectors
# ---------------------------------------------------------------------------

def _filtered_walk(repo_root: Path):
    for dirpath, dirnames, filenames in os.walk(repo_root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in _WALK_SKIP]
        yield dirpath, dirnames, filenames


def detect_image_assets(repo_root: Path) -> List[VisualAsset]:
    assets: List[VisualAsset] = []

    for dirpath, _, filenames in _filtered_walk(repo_root):
        for filename in filenames:
            abs_path = Path(dirpath) / filename
            ext = abs_path.suffix.lower()

            if ext not in IMAGE_EXTENSIONS:
                continue

            rel_path = str(abs_path.relative_to(repo_root))
            asset_type = AssetType.VECTOR_IMAGE if ext == ".svg" else AssetType.RASTER_IMAGE
            relevance = _estimate_image_relevance(rel_path)

            name_lower = filename.lower()
            is_design = any(re.search(p, name_lower) for p in DESIGN_FILE_PATTERNS)
            if is_design:
                relevance = max(relevance, 0.8)
                if ext in DESIGN_EXTENSIONS:
                    asset_type = AssetType.DESIGN_FILE

            try:
                size = abs_path.stat().st_size
            except OSError:
                size = 0

            assets.append(VisualAsset(
                path=rel_path,
                asset_type=asset_type,
                size_bytes=size,
                relevance_score=relevance,
            ))

    return assets


def detect_video_assets(repo_root: Path) -> List[VisualAsset]:
    assets: List[VisualAsset] = []

    for dirpath, _, filenames in _filtered_walk(repo_root):
        for filename in filenames:
            ext = Path(filename).suffix.lower()
            if ext not in VIDEO_EXTENSIONS:
                continue

            abs_path = Path(dirpath) / filename
            rel_path = str(abs_path.relative_to(repo_root))
            try:
                size = abs_path.stat().st_size
            except OSError:
                size = 0

            assets.append(VisualAsset(
                path=rel_path,
                asset_type=AssetType.VIDEO,
                size_bytes=size,
                relevance_score=0.7,
            ))

    return assets


def detect_css_animations(repo_root: Path) -> bool:
    animation_patterns = [
        r"@keyframes",
        r"animation\s*:",
        r"transition\s*:",
        r"transform\s*:",
        r"perspective\s*:",
    ]

    for dirpath, _, filenames in _filtered_walk(repo_root):
        for filename in filenames:
            if Path(filename).suffix.lower() not in {".css", ".scss", ".less", ".sass"}:
                continue

            abs_path = Path(dirpath) / filename
            try:
                with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
            except (OSError, UnicodeDecodeError):
                continue

            for pattern in animation_patterns:
                if re.search(pattern, content):
                    return True

    return False


def detect_canvas_webgl(repo_root: Path) -> bool:
    canvas_patterns = [
        r"getContext\s*\(\s*['\"]2d['\"]\s*\)",
        r"getContext\s*\(\s*['\"]webgl2?['\"]\s*\)",
        r"HTMLCanvasElement",
        r"OffscreenCanvas",
        r"THREE\.",
        r"PIXI\.",
        r"D3\.",
        r"p5\.",
    ]

    code_extensions = {".js", ".jsx", ".ts", ".tsx", ".html", ".vue", ".svelte"}

    for dirpath, _, filenames in _filtered_walk(repo_root):
        for filename in filenames:
            if Path(filename).suffix.lower() not in code_extensions:
                continue

            abs_path = Path(dirpath) / filename
            try:
                with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
            except (OSError, UnicodeDecodeError):
                continue

            for pattern in canvas_patterns:
                if re.search(pattern, content):
                    return True

    return False


def detect_diagram_files(repo_root: Path) -> List[VisualAsset]:
    assets: List[VisualAsset] = []
    diagram_extensions = {
        ".mmd": "mermaid", ".mermaid": "mermaid",
        ".puml": "plantuml", ".plantuml": "plantuml",
        ".dot": "graphviz", ".gv": "graphviz",
    }

    for dirpath, _, filenames in _filtered_walk(repo_root):
        for filename in filenames:
            ext = Path(filename).suffix.lower()
            if ext not in diagram_extensions:
                continue

            abs_path = Path(dirpath) / filename
            rel_path = str(abs_path.relative_to(repo_root))
            assets.append(VisualAsset(
                path=rel_path,
                asset_type=AssetType.DIAGRAM,
                relevance_score=0.6,
            ))

    return assets


def _estimate_image_relevance(rel_path: str) -> float:
    path_lower = rel_path.lower()

    if any(d in path_lower for d in ["design", "mockup", "wireframe", "screenshot"]):
        return 0.9
    if "storybook" in path_lower:
        return 0.85
    if any(d in path_lower for d in ["test", "spec", "fixture", "__tests__"]):
        return 0.7
    if any(d in path_lower for d in ["assets", "images", "img", "static", "public"]):
        return 0.6
    if any(d in path_lower for d in ["docs", "doc", "readme", "guide"]):
        return 0.5
    if "favicon" in path_lower or "icon" in path_lower:
        return 0.2
    return 0.4


# ---------------------------------------------------------------------------
# Vision config decision
# ---------------------------------------------------------------------------

def decide_vision_config(
    assets: List[VisualAsset],
    has_css_animations: bool,
    has_canvas_webgl: bool,
) -> VisionConfig:
    config = VisionConfig()

    images = [a for a in assets if a.asset_type in (AssetType.RASTER_IMAGE, AssetType.VECTOR_IMAGE)]
    svgs = [a for a in assets if a.asset_type == AssetType.VECTOR_IMAGE]
    videos = [a for a in assets if a.asset_type == AssetType.VIDEO]
    designs = [a for a in assets if a.asset_type == AssetType.DESIGN_FILE]

    config.image_count = len(images)
    config.video_count = len(videos)
    config.design_file_count = len(designs)
    config.svg_count = len(svgs)
    config.has_css_animations = has_css_animations
    config.has_canvas_webgl = has_canvas_webgl
    config.detected_assets = assets

    high_relevance_count = sum(1 for a in assets if a.relevance_score >= 0.6)

    enable_vision = False
    reasons: List[str] = []

    if designs:
        enable_vision = True
        reasons.append(f"{len(designs)} design/mockup file(s)")

    if high_relevance_count >= 3:
        enable_vision = True
        reasons.append(f"{high_relevance_count} high-relevance visual assets")

    if svgs and any(a.relevance_score >= 0.5 for a in svgs):
        enable_vision = True
        reasons.append(f"{len(svgs)} SVG file(s)")

    if has_canvas_webgl:
        enable_vision = True
        reasons.append("Canvas/WebGL code detected")

    if has_css_animations and high_relevance_count >= 1:
        enable_vision = True
        reasons.append("CSS animations with visual assets")

    if videos:
        enable_vision = True
        reasons.append(f"{len(videos)} video file(s)")

    frontend_paths = {
        "public/", "src/components/", "src/pages/", "src/views/",
        "src/styles/", "src/assets/", "storybook-static/",
    }
    is_frontend = any(a.path.startswith(p) for a in assets for p in frontend_paths)
    if is_frontend and high_relevance_count >= 2:
        enable_vision = True
        reasons.append("frontend repo with visual assets")

    config.use_vision = enable_vision
    config.language_model_only = not enable_vision

    if config.language_model_only:
        # ~6 GB for Qwen3.6-27B ViT-bigG (2B params @ fp16 + KV overhead)
        config.kv_cache_savings_gb = 6.0
        config.recommendation = (
            "Consider --language-model-only. No high-relevance visual assets detected. "
            "Frees ~6 GB KV cache (~100K-150K additional context tokens)."
        )
    else:
        config.kv_cache_savings_gb = 0.0
        reason_text = "; ".join(reasons)
        config.recommendation = f"Keep vision encoder active. {reason_text}."

    return config


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def detect_vision_needs(repo_root: Path) -> Dict:
    repo_root = Path(repo_root)

    image_assets = detect_image_assets(repo_root)
    video_assets = detect_video_assets(repo_root)
    diagram_assets = detect_diagram_files(repo_root)
    has_css_anim = detect_css_animations(repo_root)
    has_canvas = detect_canvas_webgl(repo_root)

    all_assets = image_assets + video_assets + diagram_assets
    config = decide_vision_config(all_assets, has_css_anim, has_canvas)

    return {
        "use_vision": config.use_vision,
        "language_model_only": config.language_model_only,
        "image_count": config.image_count,
        "video_count": config.video_count,
        "svg_count": config.svg_count,
        "design_file_count": config.design_file_count,
        "has_css_animations": config.has_css_animations,
        "has_canvas_webgl": config.has_canvas_webgl,
        "recommendation": config.recommendation,
        "kv_cache_savings_gb": config.kv_cache_savings_gb,
        "has_images": config.image_count > 0 or config.svg_count > 0,
        "assets": [
            {
                "path": a.path,
                "type": a.asset_type.value,
                "relevance": round(a.relevance_score, 2),
                "size_bytes": a.size_bytes,
            }
            for a in sorted(all_assets, key=lambda a: -a.relevance_score)
        ],
    }


# ---------------------------------------------------------------------------
# Ollama vision capability detection
# ---------------------------------------------------------------------------

KNOWN_VISION_PATTERNS = [
    r"qwen3\.6-27b",
    r"qwen3\.6-plus",
    r"llava",
    r"bakllava",
    r"llama3\.2-vision",
    r"minicpm-v",
    r"phi-3-vision",
    r"pixtral",
]


def detect_ollama_vision_capability(model_name: str = "qwen3.6-27b") -> Dict:
    result = {
        "model": model_name,
        "supports_vision": False,
        "detection_method": "unknown",
        "raw_capabilities": [],
    }

    # Method 1: ollama show --modelfile
    try:
        proc = subprocess.run(
            ["ollama", "show", model_name, "--modelfile"],
            capture_output=True, text=True, timeout=30,
        )
        if proc.returncode == 0:
            modelfile = proc.stdout
            if "vision" in modelfile.lower() or "image" in modelfile.lower():
                result["supports_vision"] = True
                result["detection_method"] = "modelfile_keyword"
            caps = []
            for line in modelfile.split("\n"):
                line = line.strip()
                if line.startswith("PARAMETER"):
                    caps.append(line)
            result["raw_capabilities"] = caps
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    # Method 2: known model name patterns
    if not result["supports_vision"]:
        for pattern in KNOWN_VISION_PATTERNS:
            if re.search(pattern, model_name, re.IGNORECASE):
                result["supports_vision"] = True
                result["detection_method"] = "known_pattern"
                break

    # Method 3: Ollama API
    if not result["supports_vision"]:
        try:
            import urllib.request

            url = "http://localhost:11434/api/show"
            data = json.dumps({"name": model_name}).encode()
            req = urllib.request.Request(
                url, data=data, headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                model_info = json.loads(resp.read())
                details = model_info.get("details", {})
                families = details.get("families", [])
                if "clip" in families or "vision" in str(families).lower():
                    result["supports_vision"] = True
                    result["detection_method"] = "api_families"
                result["raw_capabilities"] = families
        except Exception:
            pass

    # Qwen3.6-27B always has vision
    if "qwen3.6" in model_name.lower() and "27b" in model_name.lower():
        result["supports_vision"] = True
        result["detection_method"] = "architecture_override"

    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description="Detect visual assets and configure Qwen3.6 vision encoder"
    )
    parser.add_argument("repo_path")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--check-ollama", action="store_true")
    parser.add_argument("--ollama-model", default="qwen3.6-27b")

    args = parser.parse_args()

    repo_root = Path(args.repo_path)
    if not repo_root.is_dir():
        print(f"Error: {args.repo_path} is not a directory", file=sys.stderr)
        return

    result = detect_vision_needs(repo_root)

    if args.check_ollama:
        result["ollama_detection"] = detect_ollama_vision_capability(args.ollama_model)

    if args.json:
        output = {k: v for k, v in result.items() if k != "assets"}
        output["asset_count"] = len(result.get("assets", []))
        print(json.dumps(output, indent=2))
    else:
        print(f"Vision Detection Results for {args.repo_path}")
        print("=" * 60)
        print(f"Images: {result['image_count']}")
        print(f"SVGs: {result['svg_count']}")
        print(f"Videos: {result['video_count']}")
        print(f"Design files: {result['design_file_count']}")
        print(f"CSS animations: {result['has_css_animations']}")
        print(f"Canvas/WebGL: {result['has_canvas_webgl']}")
        print(f"\nUse vision encoder: {result['use_vision']}")
        print(f"--language-model-only: {result['language_model_only']}")
        if result["kv_cache_savings_gb"] > 0:
            print(f"KV cache savings: ~{result['kv_cache_savings_gb']:.0f} GB")
        print(f"\n{result['recommendation']}")


if __name__ == "__main__":
    main()
