from __future__ import annotations

from typing import Required, TypedDict

from .asset import Asset, AudioRef, FileRef, ImageRef, VideoRef


class SplitVideoInput(TypedDict, total=False):
    video: Required[Asset]

class SplitVideoOutput(TypedDict, total=False):
    error: str
    success: Required[bool]
    text: str
    thinking: str
    video_parts: list[VideoRef]

