# Shellbase CLI Relay Agent

This package provides a small CLI to register a relay with the Shellbase backend and keep a websocket-based relay tunnel alive.

## Install

```bash
python3 -m pip install -e .
```

## Register a relay

```bash
shellbase-cli register-relay \
  --backend-url http://localhost:8000 \
  --email mauritzlemgen@artim-industries.com \
  --team-id 69d555478c20fa9ebd3e9aab \
  --name "Office Relay" \
  --local-host 127.0.0.1 \
  --local-port 22
```

## Run the relay agent

```bash
shellbase-cli run-agent
```

## Start the relay agent in the background

```bash
shellbase-cli up
```

## Stop the relay agent

```bash
shellbase-cli down
```

## Remove the relay and cleanup local state

```bash
shellbase-cli remove --backend-url http://localhost:8000 --email you@example.com
```

## Clear local relay state only

```bash
shellbase-cli clear
```

## Start the relay agent in the background

```bash
shellbase-cli up
```

## Stop the relay agent

```bash
shellbase-cli down
```
