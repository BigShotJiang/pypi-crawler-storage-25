import asyncio
import base64
import datetime
import json
import socket
import sys
import traceback
from pathlib import Path
from urllib.parse import urlparse, urlunparse

import websockets


async def send_json(ws, payload):
    try:
        await ws.send(json.dumps(payload))
    except Exception:
        pass


def _log(message: str) -> None:
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(f"[{timestamp}] {message}", file=sys.stderr, flush=True)


def _ensure_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


class RelayAgent:
    def __init__(self, backend_url: str, token: str, relay_id: str):
        self.backend_url = backend_url.rstrip("/")
        self.token = token
        self.relay_id = relay_id
        self.ws = None
        self.connections: dict[str, socket.socket] = {}
        self.read_tasks: dict[str, asyncio.Task] = {}
        self.closed = False

    def _ws_url(self) -> str:
        parsed = urlparse(self.backend_url)
        scheme = "wss" if parsed.scheme == "https" else "ws"
        path = parsed.path.rstrip("/")
        target_path = f"{path}/api/relays/ws/{self.relay_id}"
        return urlunparse((scheme, parsed.netloc, target_path, "", f"token={self.token}", ""))

    async def heartbeat(self):
        while not self.closed:
            await asyncio.sleep(5)
            await send_json(self.ws, {
                "type": "health",
                "timestamp": datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat(),
                "agentId": self.relay_id,
            })

    async def read_remote(self, conn_id: str, sock: socket.socket):
        try:
            while True:
                data = await asyncio.to_thread(sock.recv, 4096)
                if not data:
                    break
                await send_json(self.ws, {
                    "type": "data",
                    "connId": conn_id,
                    "payload": base64.b64encode(data).decode("ascii"),
                })
        except Exception:
            pass
        finally:
            await send_json(self.ws, {"type": "close", "connId": conn_id})
            self.close_connection(conn_id)

    def close_connection(self, conn_id: str) -> None:
        sock = self.connections.pop(conn_id, None)
        task = self.read_tasks.pop(conn_id, None)
        if task:
            task.cancel()
        if sock:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                sock.close()
            except Exception:
                pass

    async def handle_open(self, conn_id: str, target_host: str, target_port: int):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        try:
            sock.connect((target_host, target_port))
        except Exception as exc:
            await send_json(self.ws, {"type": "open_ack", "connId": conn_id, "status": str(exc)})
            sock.close()
            return

        sock.setblocking(True)
        self.connections[conn_id] = sock
        self.read_tasks[conn_id] = asyncio.create_task(self.read_remote(conn_id, sock))
        await send_json(self.ws, {"type": "open_ack", "connId": conn_id, "status": "ok"})

    async def handle_data(self, conn_id: str, payload: str):
        sock = self.connections.get(conn_id)
        if not sock:
            return
        try:
            data = base64.b64decode(payload)
            await asyncio.to_thread(sock.sendall, data)
        except Exception:
            self.close_connection(conn_id)

    async def handle_close(self, conn_id: str):
        self.close_connection(conn_id)

    async def run(self):
        url = self._ws_url()
        safe_url = url.split("?", 1)[0]
        _log(f"Relay agent starting for relay={self.relay_id}")
        _log(f"Connecting to {safe_url}")
        while True:
            try:
                async with websockets.connect(url) as ws:
                    _log("WebSocket connected")
                    self.ws = ws
                    heartbeat_task = asyncio.create_task(self.heartbeat())
                    try:
                        async for raw in ws:
                            try:
                                frame = json.loads(raw)
                            except Exception:
                                continue

                            frame_type = frame.get("type")
                            conn_id = frame.get("connId")
                            if frame_type == "open" and conn_id:
                                await self.handle_open(conn_id, frame.get("targetHost", ""), int(frame.get("targetPort", 22)))
                            elif frame_type == "data" and conn_id:
                                await self.handle_data(conn_id, frame.get("payload", ""))
                            elif frame_type == "close" and conn_id:
                                await self.handle_close(conn_id)
                    except websockets.exceptions.ConnectionClosed as exc:
                        _log(f"WebSocket closed by server code={exc.code} reason={exc.reason!r}")
                    finally:
                        heartbeat_task.cancel()
                        await asyncio.gather(heartbeat_task, return_exceptions=True)
                        for conn_id in list(self.connections.keys()):
                            self.close_connection(conn_id)
                        self.ws = None
            except Exception as exc:
                _log(f"WebSocket connect/run error: {exc}")
                _log(traceback.format_exc().rstrip())
                await asyncio.sleep(5)


def load_config(path: str) -> dict[str, str]:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Shellbase relay agent")
    parser.add_argument("--config", required=True, help="Path to relay config JSON")
    args = parser.parse_args()

    config = load_config(args.config)
    backend_url = config["backendUrl"]
    token = config.get("wsToken") or config["token"]
    relay_id = config["relayId"]

    asyncio.run(RelayAgent(backend_url, token, relay_id).run())


if __name__ == "__main__":
    main()
