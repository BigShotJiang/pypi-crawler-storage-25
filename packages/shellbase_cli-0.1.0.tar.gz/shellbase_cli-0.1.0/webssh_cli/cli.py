import json
import os
import signal
import sys
import subprocess
from pathlib import Path

import click
import httpx

CONFIG_DIR = Path.home() / ".shellbase-cli"
CONFIG_PATH = CONFIG_DIR / "relay_config.json"
PID_PATH = CONFIG_DIR / "relay_agent.pid"
LOG_PATH = Path.home() / ".shellbase-cli" / "relay_agent.log"


def load_config(path: Path) -> dict:
    if not path.exists():
        raise RuntimeError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


@click.group()
def main():
    """WebSSH CLI for relay registration and agent management."""


def _format_backend_url(url: str) -> str:
    return url.rstrip("/")


def login(backend_url: str, email: str, password: str) -> str:
    url = f"{backend_url}/api/auth/login"
    with httpx.Client(timeout=10.0) as client:
        response = client.post(url, data={"username": email, "password": password})
    response.raise_for_status()
    return response.json()["access_token"]


def create_relay(backend_url: str, token: str, team_id: str, name: str, description: str, local_host: str, local_port: int) -> dict:
    url = f"{backend_url}/api/teams/{team_id}/relays"
    with httpx.Client(timeout=20.0) as client:
        response = client.post(
            url,
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json={
                "name": name,
                "description": description,
                "localHost": local_host,
                "localPort": local_port,
                "enabled": True,
            },
        )
    response.raise_for_status()
    return response.json()


def get_relay_agent_token(backend_url: str, token: str, team_id: str, relay_id: str) -> str:
    url = f"{backend_url}/api/teams/{team_id}/relays/{relay_id}/agent-token"
    with httpx.Client(timeout=20.0) as client:
        response = client.get(url, headers={"Authorization": f"Bearer {token}"})
    response.raise_for_status()
    payload = response.json()
    ws_token = payload.get("wsToken")
    if not ws_token:
        raise RuntimeError("Backend did not return relay wsToken")
    return ws_token


def install_cron_entry(command: str) -> None:
    try:
        existing = subprocess.run(["crontab", "-l"], capture_output=True, text=True, check=False)
        lines = existing.stdout.splitlines() if existing.returncode == 0 else []
        if command in lines:
            return
        lines.append(command)
        subprocess.run(["crontab", "-"], input="\n".join(lines) + "\n", text=True, check=True)
    except Exception as exc:
        raise RuntimeError(f"Unable to install cron job: {exc}") from exc


def remove_cron_entry(command: str) -> None:
    try:
        existing = subprocess.run(["crontab", "-l"], capture_output=True, text=True, check=False)
        if existing.returncode != 0:
            return
        lines = existing.stdout.splitlines()
        next_lines = [line for line in lines if line.strip() != command.strip()]
        if len(next_lines) == len(lines):
            return
        subprocess.run(["crontab", "-"], input="\n".join(next_lines) + "\n", text=True, check=True)
    except Exception as exc:
        raise RuntimeError(f"Unable to remove cron job: {exc}") from exc


def delete_relay(backend_url: str, token: str, team_id: str, relay_id: str) -> None:
    url = f"{backend_url}/api/teams/{team_id}/relays/{relay_id}"
    with httpx.Client(timeout=20.0) as client:
        response = client.delete(url, headers={"Authorization": f"Bearer {token}"})
    response.raise_for_status()


@main.command()
@click.option("--backend-url", required=True, help="Backend base URL e.g. https://example.com")
@click.option("--email", required=True, help="User email for backend login")
@click.option("--password", prompt=True, hide_input=True, help="Password for backend login")
@click.option("--team-id", default=None, help="Team ID where relay is registered")
@click.option("--remove-cron/--no-remove-cron", default=True, help="Remove relay agent cron job")
@click.option("--remove-config/--no-remove-config", default=True, help="Remove local relay config file")
def remove(backend_url, email, password, team_id, remove_cron, remove_config):
    backend_url = _format_backend_url(backend_url)
    click.echo("Logging in to backend…")
    token = login(backend_url, email, password)

    config = load_config(CONFIG_PATH)
    relay_id = config.get("relayId")
    if not relay_id:
        raise click.ClickException("Relay ID not found in config")

    if not team_id:
        team_id = config.get("teamId")
    if not team_id:
        raise click.ClickException("Missing team ID. Pass --team-id or re-register the relay with teamId stored in config.")

    click.echo(f"Removing relay {relay_id} from team {team_id}…")
    delete_relay(backend_url, token, team_id, relay_id)
    click.echo("Relay removed from backend.")

    if remove_cron:
        python_path = sys.executable
        command = f"@reboot {python_path} -m shellbase_cli.agent --config {CONFIG_PATH} >> {LOG_PATH} 2>&1"
        remove_cron_entry(command)
        click.echo("Removed cron job.")

    if PID_PATH.exists():
        try:
            pid = int(PID_PATH.read_text().strip())
            if _is_process_running(pid):
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(pid), "/F"], check=False)
                else:
                    os.kill(pid, signal.SIGTERM)
                click.echo(f"Stopped relay agent (PID {pid}).")
        except Exception:
            pass
        finally:
            PID_PATH.unlink(missing_ok=True)

    if remove_config and CONFIG_PATH.exists():
        CONFIG_PATH.unlink()
        click.echo(f"Removed config file {CONFIG_PATH}.")

    click.echo("Relay remove complete.")


@main.command()
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
@click.option("--remove-cron/--no-remove-cron", default=True, help="Remove relay agent cron job")
@click.option("--remove-pid/--no-remove-pid", default=True, help="Stop running agent and delete local PID file")
@click.option("--remove-config/--no-remove-config", default=True, help="Remove local relay config file")
def clear(config, remove_cron, remove_pid, remove_config):
    config_path = Path(config).expanduser()

    if remove_cron:
        python_path = sys.executable
        command = f"@reboot {python_path} -m shellbase_cli.agent --config {config_path} >> {LOG_PATH} 2>&1"
        remove_cron_entry(command)
        click.echo("Removed cron job.")

    if remove_pid and PID_PATH.exists():
        try:
            pid = int(PID_PATH.read_text().strip())
            if _is_process_running(pid):
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(pid), "/F"], check=False)
                else:
                    os.kill(pid, signal.SIGTERM)
                click.echo(f"Stopped relay agent (PID {pid}).")
        except Exception:
            pass
        finally:
            PID_PATH.unlink(missing_ok=True)
            click.echo(f"Removed PID file {PID_PATH}.")

    if remove_config and config_path.exists():
        config_path.unlink()
        click.echo(f"Removed config file {config_path}.")

    click.echo("Local relay state cleared.")


@main.command()
@click.option("--backend-url", required=True, help="Backend base URL e.g. https://example.com")
@click.option("--email", required=True, help="User email for backend login")
@click.option("--password", prompt=True, hide_input=True, help="Password for backend login")
@click.option("--team-id", required=True, help="Team ID to attach the relay to")
@click.option("--name", required=True, help="Relay name")
@click.option("--description", default="", help="Optional relay description")
@click.option("--local-host", default="127.0.0.1", show_default=True, help="Local host accessible by the relay agent")
@click.option("--local-port", default=22, show_default=True, help="Local port to use for tunneled connections")
@click.option("--install-cron/--no-install-cron", default=True, help="Install @reboot cron job for the relay agent")
def register_relay(backend_url, email, password, team_id, name, description, local_host, local_port, install_cron):
    backend_url = _format_backend_url(backend_url)
    click.echo("Logging in to backend…")
    token = login(backend_url, email, password)

    click.echo("Registering relay…")
    relay = create_relay(backend_url, token, team_id, name, description, local_host, local_port)
    relay_id = relay.get("_id") or relay.get("id")
    if not relay_id:
        raise click.ClickException("Backend did not return relay id")
    ws_token = get_relay_agent_token(backend_url, token, team_id, relay_id)

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config = {
        "backendUrl": backend_url,
        "token": token,
        "teamId": team_id,
        "relayId": relay_id,
        "wsToken": ws_token,
    }
    CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")

    click.echo(f"Relay registered: {relay.get('name')} ({config['relayId']})")
    click.echo(f"Saved agent config to {CONFIG_PATH}")

    if install_cron:
        python_path = sys.executable
        command = f"@reboot {python_path} -m shellbase_cli.agent --config {CONFIG_PATH} >> {LOG_PATH} 2>&1"
        install_cron_entry(command)
        click.echo("Installed cron job to start the relay agent on reboot.")

    click.echo("Relay CLI setup is complete.")


@main.command(name="refresh-agent-token")
@click.option("--backend-url", default=None, help="Backend base URL e.g. https://example.com")
@click.option("--email", required=True, help="User email for backend login")
@click.option("--password", prompt=True, hide_input=True, help="Password for backend login")
@click.option("--team-id", default=None, help="Team ID where relay is registered")
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
def refresh_agent_token(backend_url, email, password, team_id, config):
    config_path = Path(config).expanduser()
    cfg = load_config(config_path)

    resolved_backend_url = _format_backend_url(backend_url or cfg.get("backendUrl", ""))
    if not resolved_backend_url:
        raise click.ClickException("Missing backend URL. Pass --backend-url or store backendUrl in config.")

    relay_id = cfg.get("relayId")
    if not relay_id:
        raise click.ClickException("Relay ID not found in config")

    resolved_team_id = team_id or cfg.get("teamId")
    if not resolved_team_id:
        raise click.ClickException("Missing team ID. Pass --team-id or store teamId in config.")

    click.echo("Logging in to backend…")
    user_token = login(resolved_backend_url, email, password)
    ws_token = get_relay_agent_token(resolved_backend_url, user_token, resolved_team_id, relay_id)

    cfg["backendUrl"] = resolved_backend_url
    cfg["teamId"] = resolved_team_id
    cfg["token"] = user_token
    cfg["wsToken"] = ws_token
    config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

    click.echo(f"Updated relay wsToken in {config_path}")
    click.echo("Run `shellbase-cli down` and `shellbase-cli up` to reconnect the agent.")


@main.command()
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
def run_agent(config):
    config_path = Path(config).expanduser()
    if not config_path.exists():
        raise click.ClickException(f"Config file not found: {config_path}")
    os.execvp(sys.executable, [sys.executable, "-m", "shellbase_cli.agent", "--config", str(config_path)])


@main.command()
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
def up(config):
    config_path = Path(config).expanduser()
    try:
        load_config(config_path)
    except Exception as exc:
        raise click.ClickException(str(exc)) from exc

    if PID_PATH.exists():
        try:
            pid = int(PID_PATH.read_text().strip())
            if _is_process_running(pid):
                click.echo(f"Relay agent is already running (PID {pid}).")
                return
        except Exception:
            pass

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOG_PATH, "a", encoding="utf-8") as log_handle:
        process = subprocess.Popen(
            [sys.executable, "-m", "shellbase_cli.agent", "--config", str(config_path)],
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            close_fds=True,
        )

    PID_PATH.write_text(str(process.pid), encoding="utf-8")
    click.echo(f"Started relay agent in background (PID {process.pid}).")
    click.echo(f"Logs are appended to {LOG_PATH}")


@main.command()
@click.option("--config", default=CONFIG_PATH, help="Path to relay config JSON")
def down(config):
    config_path = Path(config).expanduser()
    if not config_path.exists():
        raise click.ClickException(f"Config file not found: {config_path}")
    if not PID_PATH.exists():
        click.echo("Relay agent is not running.")
        return

    try:
        pid = int(PID_PATH.read_text().strip())
    except Exception:
        PID_PATH.unlink(missing_ok=True)
        raise click.ClickException("Invalid PID file, removed stale PID record.")

    if not _is_process_running(pid):
        PID_PATH.unlink(missing_ok=True)
        click.echo("Relay agent is not running.")
        return

    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], check=False)
        else:
            os.kill(pid, signal.SIGTERM)
        click.echo(f"Stopped relay agent (PID {pid}).")
    except Exception as exc:
        raise click.ClickException(f"Unable to stop relay agent: {exc}") from exc
    finally:
        PID_PATH.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
