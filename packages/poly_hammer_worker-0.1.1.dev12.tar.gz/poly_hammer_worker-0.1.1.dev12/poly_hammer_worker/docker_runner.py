"""
Docker container lifecycle management for self-hosted workers.

Handles:
  - Dynamic image pulling with progress reporting
  - Container create / start / stream-stdout / wait
  - JSON-line protocol parsing from container stdout
"""

import json
import logging
import os
import platform
import shutil
import time
from collections.abc import Callable
from pathlib import Path

import docker
import docker.errors

logger = logging.getLogger(__name__)

# ph-worker images are identified by this tag prefix
_PH_IMAGE_PREFIX = "ph-"

# Minimum free disk space (GB) required before pulling an image
MIN_FREE_DISK_GB = 10.0


class DockerRunError(Exception):
    """Raised when a container exits with a non-zero status."""

    def __init__(self, exit_code: int, stderr: str):
        self.exit_code = exit_code
        self.stderr = stderr
        super().__init__(f"Container exited with code {exit_code}: {stderr}")


class InsufficientDiskError(Exception):
    """Raised when there isn't enough disk space to pull an image."""

    def __init__(self, free_gb: float, required_gb: float):
        self.free_gb = free_gb
        self.required_gb = required_gb
        super().__init__(
            f"Insufficient disk space: {free_gb:.1f} GB free, "
            f"need at least {required_gb:.1f} GB"
        )


def get_docker_disk_usage(client: docker.DockerClient) -> dict:
    """Return Docker disk usage breakdown in GB."""
    try:
        df = client.df()
        image_bytes = sum(img.get("Size", 0) for img in df.get("Images", []))
        return {
            "images_gb": round(image_bytes / (1024**3), 2),
            "image_count": len(df.get("Images", [])),
        }
    except Exception:
        logger.debug("Could not query Docker disk usage", exc_info=True)
        return {}


def get_docker_root() -> str:
    """Return the Docker data-root directory where images are stored."""
    try:
        client = docker.from_env()
        info = client.info()
        return info.get("DockerRootDir", "/var/lib/docker")
    except Exception:
        logger.debug("Could not query Docker root dir", exc_info=True)
        return "/var/lib/docker"


def _resolve_docker_host_storage_path() -> str:
    """Resolve the host filesystem path where Docker actually stores data.

    On Linux the Docker root (e.g. ``/var/lib/docker``) is a real local
    path.  On Windows and macOS, Docker Desktop runs inside a VM and the
    reported root is a Linux path that does not exist on the host.  This
    function returns the host-side directory whose partition should be
    checked for free space.
    """
    system = platform.system()

    if system == "Linux":
        return get_docker_root()

    if system == "Windows":
        # Docker Desktop (WSL2 backend) stores its ext4.vhdx here
        local_app_data = os.environ.get("LOCALAPPDATA", "")
        if local_app_data:
            docker_wsl = os.path.join(local_app_data, "Docker", "wsl")
            if os.path.isdir(docker_wsl):
                return docker_wsl
        # Older Docker Desktop installations
        program_data = os.environ.get("ProgramData", r"C:\ProgramData")
        docker_pd = os.path.join(program_data, "DockerDesktop")
        if os.path.isdir(docker_pd):
            return docker_pd
        # Last resort: Docker Desktop defaults to C: drive
        return os.environ.get("SystemDrive", "C:\\")

    if system == "Darwin":
        # Docker Desktop for Mac stores its VM disk image here
        docker_data = (
            Path.home() / "Library" / "Containers" / "com.docker.docker" / "Data"
        )
        if docker_data.is_dir():
            return str(docker_data)
        return str(Path.home())

    # Unknown OS — try the Docker root directly
    return get_docker_root()


def get_free_disk_gb(path: str | None = None) -> float:
    """Return free disk space in GB on the partition containing *path*.

    Defaults to the Docker data-root partition so disk checks reflect
    where images will actually be stored.
    """
    if path is None:
        path = _resolve_docker_host_storage_path()
    try:
        usage = shutil.disk_usage(path)
    except (FileNotFoundError, OSError):
        logger.debug("Cannot stat %s, falling back to SystemDrive", path)
        usage = shutil.disk_usage(os.environ.get("SystemDrive", "/"))
    return round(usage.free / (1024**3), 2)


def list_ph_images(client: docker.DockerClient) -> list[docker.models.images.Image]:
    """Return all locally-cached images pulled by ph-worker (by repo prefix)."""
    images = []
    for img in client.images.list():
        for tag in img.tags:
            if tag.startswith(_PH_IMAGE_PREFIX):
                images.append(img)
                break
    return images


def cleanup_ph_images(
    client: docker.DockerClient,
    keep_image: str | None = None,
    on_status: Callable[[str], None] | None = None,
) -> float:
    """Remove ph-worker images to free disk space.

    Parameters
    ----------
    keep_image:
        Image reference to skip (the one needed for the current job).
    on_status:
        Status callback.

    Returns
    -------
    float — approximate GB freed.
    """
    freed_bytes = 0
    for img in list_ph_images(client):
        # Don't remove the image we're about to use
        if keep_image and keep_image in img.tags:
            continue
        size = img.attrs.get("Size", 0)
        tag_names = ", ".join(img.tags) or img.short_id
        try:
            client.images.remove(img.id, force=True)
            freed_bytes += size
            if on_status:
                on_status(f"Removed {tag_names} ({size / (1024**3):.1f} GB)")
        except Exception:
            logger.debug("Failed to remove image %s", tag_names, exc_info=True)
    return freed_bytes / (1024**3)


def ensure_image(
    client: docker.DockerClient,
    image_ref: str,
    auto_cleanup: bool = False,
    registry_url: str | None = None,
    on_status: Callable[[str], None] | None = None,
) -> None:
    """Ensure *image_ref* is available locally.

    Resolution order:

    1. Check if the image exists locally — use it immediately.
    2. If not found and *registry_url* is provided, attempt to pull from
       ``{registry_url}/{image_ref}``.
    3. If not found and no registry — raise with build instructions.

    Checks disk space before pulling. If *auto_cleanup* is True and space is
    low, removes other ph-worker images first.

    Raises
    ------
    InsufficientDiskError
        If there isn't enough disk space even after cleanup.
    RuntimeError
        If the image is not found locally and no registry is configured.
    """
    # 1. Check local
    try:
        client.images.get(image_ref)
        logger.info("Image already present: %s", image_ref)
        return
    except docker.errors.ImageNotFound:
        pass

    # 2. If no registry, tell user to build locally
    if not registry_url:
        raise RuntimeError(
            f"Image '{image_ref}' not found locally. "
            f"Build it with: docker compose -f workers/self-hosted/images/docker-compose.yml build\n"
            f"Then tag it: docker tag <image>:latest {image_ref}\n"
            f"Or pass --registry to pull from a custom registry."
        )

    # 3. Pull from user-specified registry
    remote_ref = f"{registry_url.rstrip('/')}/{image_ref}"

    # ---- Disk space check before pull -----------------------------------------
    free_gb = get_free_disk_gb()
    if on_status:
        on_status(f"Free disk space: {free_gb:.1f} GB")

    if free_gb < MIN_FREE_DISK_GB:
        if auto_cleanup:
            if on_status:
                on_status(
                    f"Low disk ({free_gb:.1f} GB free) — cleaning up old worker images …"
                )
            freed = cleanup_ph_images(client, keep_image=image_ref, on_status=on_status)
            free_gb = get_free_disk_gb()
            if on_status:
                on_status(f"Freed {freed:.1f} GB — now {free_gb:.1f} GB available")

        if free_gb < MIN_FREE_DISK_GB:
            raise InsufficientDiskError(free_gb, MIN_FREE_DISK_GB)

    # ---- Pull -----------------------------------------------------------------
    if on_status:
        on_status(f"Pulling {remote_ref} …")

    repo, _, tag = remote_ref.rpartition(":")
    if not repo:
        repo = remote_ref
        tag = "latest"

    last_log = 0.0
    for chunk in client.api.pull(repo, tag=tag, stream=True, decode=True):
        now = time.monotonic()
        if now - last_log >= 2.0 and on_status:
            pull_status = chunk.get("status", "")
            layer_id = chunk.get("id", "")
            on_status(f"  {layer_id}: {pull_status}")
            last_log = now

    # Re-tag as the local image_ref so future lookups find it
    try:
        pulled = client.images.get(remote_ref)
        pulled.tag(image_ref)
        logger.info("Tagged %s → %s", remote_ref, image_ref)
    except docker.errors.ImageNotFound:
        raise RuntimeError(
            f"Pull appeared to succeed but image '{remote_ref}' not found"
        )

    # Verify the pull succeeded
    client.images.get(image_ref)
    if on_status:
        on_status(f"Pull complete: {image_ref}")

    # ---- Post-pull space check (warn if dangerously low) ----------------------
    post_free = get_free_disk_gb()
    if post_free < MIN_FREE_DISK_GB and on_status:
        on_status(
            f"Warning: only {post_free:.1f} GB free after pull — "
            f"consider enabling --auto-cleanup"
        )


def run_inference_container(
    client: docker.DockerClient,
    image_ref: str,
    job_payload: dict,
    on_progress: Callable[[float], None] | None = None,
    on_status: Callable[[str], None] | None = None,
    on_log: Callable[[str], None] | None = None,
) -> dict:
    """Run an inference container and return the result dict.

    Parameters
    ----------
    client:
        Docker SDK client.
    image_ref:
        Fully-qualified image reference (with tag).
    job_payload:
        WorkerJobPayload dict — piped to container stdin as JSON.
    on_progress:
        Called with progress float (0.0–1.0) as the container reports progress.
    on_status:
        Called with human-readable status strings (pulling, running, etc.).
    on_log:
        Called with each line of container output (both stdout and stderr).

    Returns
    -------
    dict  — The ``result`` message emitted by the container.

    Raises
    ------
    DockerRunError  — If the container exits non-zero or emits an error message.
    """
    if on_status:
        on_status(f"Creating container from {image_ref}")

    container = client.containers.create(
        image_ref,
        environment={"JOB_PAYLOAD": json.dumps(job_payload)},
        detach=True,
        device_requests=[
            docker.types.DeviceRequest(count=-1, capabilities=[["gpu"]]),
        ],
    )

    result_msg: dict | None = None
    error_msg: str | None = None

    try:
        container.start()

        if on_status:
            on_status("Inference running …")

        # Stream both stdout and stderr for JSON-line progress + container logs
        stderr_lines: list[str] = []
        for raw_line in container.logs(
            stream=True, follow=True, stdout=True, stderr=True
        ):
            line = raw_line.decode("utf-8", errors="replace").strip()
            if not line:
                continue

            if on_log:
                on_log(line)

            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                # Non-JSON output is stderr or unstructured stdout
                stderr_lines.append(line)
                continue

            msg_type = msg.get("type")
            if msg_type == "progress":
                progress_val = msg.get("progress", 0.0)
                if on_progress:
                    on_progress(progress_val)
            elif msg_type == "error":
                error_msg = msg.get("error", "Unknown container error")
            elif msg_type == "result":
                result_msg = msg

        # Wait for container exit
        exit_info = container.wait(timeout=30)
        exit_code = exit_info.get("StatusCode", -1)

        if error_msg:
            raise DockerRunError(exit_code, error_msg)

        if exit_code != 0:
            stderr_tail = "\n".join(stderr_lines)[-2000:]
            raise DockerRunError(exit_code, stderr_tail)

        if result_msg is None:
            raise DockerRunError(
                exit_code, "Container exited without emitting a result message"
            )

        return result_msg

    finally:
        try:
            container.remove(force=True)
        except Exception:
            logger.debug("Failed to remove container", exc_info=True)
