"""
GPU and system hardware detection for self-hosted workers.

Uses nvidia-smi / pynvml to detect GPU information, and psutil for
CPU / RAM. Returns a dict suitable for the WorkerCreate.hardware_info
schema.
"""

import logging
import shutil
import subprocess

import psutil

from poly_hammer_worker.docker_runner import get_free_disk_gb

logger = logging.getLogger(__name__)


def detect_hardware() -> dict:
    """Return hardware info dict for worker registration / heartbeat.

    Keys: gpu_model, vram_gb, cuda_version, cpu_cores, ram_gb, disk_free_gb.
    Values will be None if detection fails for a particular field.
    """
    gpu_info = _detect_gpu()
    disk_free_gb = _get_docker_disk_free_gb()
    return {
        "gpu_model": gpu_info.get("name"),
        "vram_gb": gpu_info.get("vram_gb"),
        "cuda_version": gpu_info.get("cuda_version"),
        "cpu_cores": psutil.cpu_count(logical=False),
        "ram_gb": round(psutil.virtual_memory().total / (1024**3), 1),
        "disk_free_gb": disk_free_gb,
    }


def get_cuda_version() -> str | None:
    """Return the local CUDA driver version string (e.g. '13.1') or None."""
    return _detect_gpu().get("cuda_version")


def _detect_gpu() -> dict:
    """Query nvidia-smi for GPU name, VRAM and CUDA version."""
    nvidia_smi = shutil.which("nvidia-smi")
    if not nvidia_smi:
        logger.warning("nvidia-smi not found — cannot detect GPU")
        return {}

    try:
        result = subprocess.run(
            [
                nvidia_smi,
                "--query-gpu=name,memory.total",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            logger.warning("nvidia-smi failed: %s", result.stderr.strip())
            return {}

        line = result.stdout.strip().split("\n")[0]
        parts = [p.strip() for p in line.split(",")]
        name = parts[0] if len(parts) > 0 else None
        vram_mb = float(parts[1]) if len(parts) > 1 else None
        vram_gb = round(vram_mb / 1024, 1) if vram_mb else None

        cuda_version = _get_cuda_version_from_smi(nvidia_smi)

        return {"name": name, "vram_gb": vram_gb, "cuda_version": cuda_version}
    except Exception:
        logger.warning("GPU detection failed", exc_info=True)
        return {}


def _get_cuda_version_from_smi(nvidia_smi: str) -> str | None:
    """Parse CUDA version from nvidia-smi output."""
    try:
        result = subprocess.run(
            [nvidia_smi],
            capture_output=True,
            text=True,
            timeout=10,
        )
        # nvidia-smi header contains e.g. "CUDA Version: 13.1"
        for line in result.stdout.split("\n"):
            if "CUDA Version" in line:
                # e.g. "| NVIDIA-SMI 535.129.03   Driver Version: 535.129.03   CUDA Version: 13.1  |"
                index = line.index("CUDA Version:")
                version_str = (
                    line[index + len("CUDA Version:") :].strip().rstrip("|").strip()
                )
                # Return major.minor only
                parts = version_str.split(".")
                if len(parts) >= 2:
                    return f"{parts[0]}.{parts[1]}"
                return version_str
    except Exception:
        logger.debug("Could not parse CUDA version from nvidia-smi", exc_info=True)
    return None


def _get_docker_disk_free_gb() -> float | None:
    """Return free GB on the partition where Docker stores images."""
    try:
        return get_free_disk_gb()
    except Exception:
        logger.debug("Could not check Docker disk free space", exc_info=True)
        return None
