"""
Logging configuration for the ph-worker agent.

Configures both console and rotating file handlers with timestamps.
Log files are stored in a platform-appropriate directory and automatically
cleaned up after 30 days.
"""

import logging
import os
import sys
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path

_LOG_FORMAT = "[%(levelname)s] %(asctime)s %(name)s %(message)s"
_LOG_DATE_FORMAT = "%H:%M:%S %d-%m-%Y"
_RETENTION_DAYS = 30


def _log_dir() -> Path:
    """Return the log directory, creating it if needed.

    Uses ``PH_WORKER_LOG_DIR`` env var if set, otherwise falls back to
    ``~/.poly-hammer-worker/logs/``.
    """
    env = os.environ.get("PH_WORKER_LOG_DIR")
    if env:
        path = Path(env)
    else:
        path = Path.home() / ".poly-hammer-worker" / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def configure_logging(*, verbose: bool = False) -> Path:
    """Set up root logger with console + rotating file handlers.

    Returns the log file path so the CLI can display it.
    """
    level = logging.DEBUG if verbose else logging.INFO
    root = logging.getLogger()
    root.setLevel(level)

    # Remove any pre-existing handlers (e.g. from basicConfig)
    root.handlers.clear()

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_LOG_DATE_FORMAT)

    # ---- Console handler (stderr) ----
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root.addHandler(console_handler)

    # ---- Rotating file handler (daily rotation, 30-day retention) ----
    log_file = _log_dir() / "ph-worker.log"
    file_handler = TimedRotatingFileHandler(
        filename=str(log_file),
        when="midnight",
        interval=1,
        backupCount=_RETENTION_DAYS,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)  # always capture debug in file
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)

    # ---- Quiet noisy third-party loggers unless verbose ----
    if not verbose:
        for name in ("httpx", "httpcore", "urllib3", "docker", "hpack"):
            logging.getLogger(name).setLevel(logging.WARNING)

    return log_file
