# Output Format

You MUST output complete file content blocks with this format;
Use provided filenames for files that already have specified the name;
Each file block MUST have filename specified above the code block using square brackets like this:
...

[example.txt]
```txt
... text content here ...
```

[example.sql]
```sql
... sql code here ...
```

[example.html]
```html
... html code here ...
```

... and so on.

> Note: This is the strict output response format you must comply!
