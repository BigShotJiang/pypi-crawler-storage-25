from aisi.__system__.imports import *


class Openai:
    ####################################################################################// Params
    model = ""
    client = None
    sources = ""

    ####################################################################################// Load
    def __init__(self, key, model, project):
        Openai.model = model
        Openai.client = OpenAIClient(api_key=key)
        Openai.sources = os.path.dirname(os.path.dirname(__file__)) + "/sources"
        pass

    ####################################################################################// Main
    def reply(prompt):
        try:
            response = Openai.client.responses.create(model=Openai.model, input=prompt)
            return response.output_text.replace("—", "-")
        except Exception as e:
            cli.trace(str(e))
            return ""
        return ""

    def files(prompt):
        if prompt.strip() == "":
            return {}
        prompt = cli.read(Openai.sources + "/prompt.files.md") + "\n\n" + prompt

        try:
            response = Openai.client.responses.create(model=Openai.model, input=prompt)
            return Help.extractBlocks(response.output_text)
        except Exception as e:
            cli.trace(str(e))
            return {}
        return {}

    def image(prompt, path):
        try:
            result = Openai.client.images.generate(
                model="gpt-image-1", prompt=prompt, size="1024x1024"
            )
            image_base64 = result.data[0].b64_json
            image_bytes = base64.b64decode(image_base64)

            with open(path, "wb") as f:
                f.write(image_bytes)
            return path
        except Exception as e:
            cli.trace(str(e))
            return ""
        return ""

    def video(prompt, path):
        # Not available via stable API
        return ""

    def audio(prompt, path):
        try:
            result = Openai.client.audio.speech.create(
                model="gpt-4o-mini-tts", voice="alloy", input=prompt
            )

            with open(path, "wb") as f:
                f.write(result.read())

            return path
        except Exception as e:
            cli.trace(str(e))
            return ""
        return ""

    ####################################################################################// Helpers
