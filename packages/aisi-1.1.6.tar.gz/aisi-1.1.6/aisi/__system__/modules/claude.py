from aisi.__system__.imports import *


class Claude:
    ####################################################################################// Params
    client = None
    model = None
    sources = ""

    ####################################################################################// Load
    def __init__(self, key, model, project):
        Claude.client = Anthropic(api_key=key)
        Claude.model = model
        Claude.sources = os.path.dirname(os.path.dirname(__file__)) + "/sources"
        pass

    ####################################################################################// Main
    def reply(prompt):
        if not Claude.client:
            return ""

        try:
            response = Claude.client.messages.create(
                model=Claude.model,
                max_tokens=4096,
                messages=[{"role": "user", "content": prompt}],
            )

            text = ""
            for block in response.content:
                if block.type == "text":
                    text += block.text
            return text.strip()
        except Exception:
            return ""
        return ""

    def files(prompt):
        if prompt.strip() == "":
            return {}
        prompt = cli.read(Claude.sources + "/prompt.files.md") + "\n\n" + prompt

        if not Claude.client:
            return {}

        try:
            response = Claude.client.messages.create(
                model=Claude.model,
                max_tokens=8192,
                messages=[{"role": "user", "content": prompt}],
            )

            text = ""
            for block in response.content:
                if block.type == "text":
                    text += block.text

            return Help.extractBlocks(text)
        except Exception:
            return {}
        return {}

    def image(prompt, path):
        # Not supported by Claude API
        return ""

    def video(prompt, path):
        # Not supported by Claude API
        return ""

    def audio(prompt, path):
        # Not supported by Claude API
        return ""

    ####################################################################################// Helpers
