"""AVI operations modules."""
