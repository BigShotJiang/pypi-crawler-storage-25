def deficit_based_distribution(store_a, max_a, store_b, max_b):
    """Split fluxes by relative storage deficit.

    Returns the normalized deficits for both stores so translated Sacramento
    routing code can keep using the Matlab-style two-output helper.
    """

    deficit_a = max(float(max_a) - float(store_a), 0.0)
    deficit_b = max(float(max_b) - float(store_b), 0.0)
    total = deficit_a + deficit_b

    if total <= 0.0:
        return 0.5, 0.5

    return deficit_a / total, deficit_b / total
