from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from pyrrmod.auxiliary.numba import optional_njit


FloatArray = NDArray[np.float64]


@dataclass(slots=True, kw_only=True)
class SingleUHState:
    uh_weights: FloatArray
    uh_pending: FloatArray

    def pending_total(self) -> float:
        return float(np.sum(self.uh_pending))

    def as_legacy_uhs(self) -> list[tuple[FloatArray, FloatArray]]:
        return [(self.uh_weights, self.uh_pending)]


@dataclass(slots=True, kw_only=True)
class DoubleUHState:
    uh1_weights: FloatArray
    uh1_pending: FloatArray
    uh2_weights: FloatArray
    uh2_pending: FloatArray

    def pending_total(self) -> float:
        return float(np.sum(self.uh1_pending) + np.sum(self.uh2_pending))

    def as_legacy_uhs(self) -> list[tuple[FloatArray, FloatArray]]:
        return [
            (self.uh1_weights, self.uh1_pending),
            (self.uh2_weights, self.uh2_pending),
        ]


@dataclass(slots=True, kw_only=True)
class TripleUHState:
    uh1_weights: FloatArray
    uh1_pending: FloatArray
    uh2_weights: FloatArray
    uh2_pending: FloatArray
    uh3_weights: FloatArray
    uh3_pending: FloatArray

    def pending_total(self) -> float:
        return float(
            np.sum(self.uh1_pending)
            + np.sum(self.uh2_pending)
            + np.sum(self.uh3_pending)
        )

    def as_legacy_uhs(self) -> list[tuple[FloatArray, FloatArray]]:
        return [
            (self.uh1_weights, self.uh1_pending),
            (self.uh2_weights, self.uh2_pending),
            (self.uh3_weights, self.uh3_pending),
        ]


def route_uh_current(pending: FloatArray) -> float:
    if pending.size == 0:
        return 0.0
    return float(pending[0])


def update_uh_inplace(weights: FloatArray, pending: FloatArray, inflow: float) -> None:
    if pending.size == 0:
        return

    if pending.size > 1:
        for index in range(pending.size - 1):
            pending[index] = pending[index + 1]
    pending[pending.size - 1] = 0.0

    inflow_value = float(inflow)
    for index in range(pending.size):
        pending[index] += weights[index] * inflow_value


@optional_njit(cache=True)
def route_uh_current_nb(pending: FloatArray) -> float:
    if pending.size == 0:
        return 0.0
    return float(pending[0])


@optional_njit(cache=True)
def update_uh_inplace_nb(
    weights: FloatArray,
    pending: FloatArray,
    inflow: float,
) -> None:
    if pending.size == 0:
        return

    inflow_value = float(inflow)
    n_pending = pending.shape[0]
    previous = weights[n_pending - 1] * inflow_value

    for index in range(n_pending - 2, -1, -1):
        new_value = pending[index + 1] + weights[index] * inflow_value
        pending[index + 1] = previous
        previous = new_value

    pending[0] = previous


def route(flux, uh):
    _weights, pending = uh
    return route_uh_current(pending)


def update_uh(uh, flux):
    weights, still_to_flow = uh
    weights_array = np.asarray(weights, dtype=np.float64)
    shifted = np.ascontiguousarray(np.asarray(still_to_flow, dtype=np.float64).copy())
    update_uh_inplace(weights_array, shifted, flux)
    return (weights_array, shifted)


def make_unit_hydrograph(weights):
    values = np.asarray(weights, dtype=np.float64).reshape(-1)
    if values.size == 0:
        values = np.ones(1, dtype=np.float64)

    values = np.clip(values, 0.0, None)
    total = float(values.sum())
    if total <= 0.0 or not np.isfinite(total):
        values = np.ones(1, dtype=np.float64)
        total = 1.0

    values = np.ascontiguousarray(values / total, dtype=np.float64)
    return (values, np.zeros_like(values))


def weights_from_cdf(cdf_values):
    cdf = np.asarray(cdf_values, dtype=np.float64).reshape(-1)
    cdf = np.clip(cdf, 0.0, 1.0)
    cdf = np.maximum.accumulate(cdf)
    edges = np.concatenate(([0.0], cdf))
    return np.diff(edges)


def half_hydrograph(duration, delta_t, power):
    duration = max(float(duration), float(delta_t), 1e-9)
    steps = max(1, int(math.ceil(duration / delta_t)))
    times = np.arange(1, steps + 1, dtype=np.float64) * delta_t
    cdf = np.minimum(times / duration, 1.0) ** power
    return make_unit_hydrograph(weights_from_cdf(cdf))


def full_hydrograph(duration, delta_t, power):
    duration = max(float(duration), float(delta_t), 1e-9)
    steps = max(1, int(math.ceil((2.0 * duration) / delta_t)))
    times = np.arange(1, steps + 1, dtype=np.float64) * delta_t
    scaled = times / duration

    cdf = np.empty_like(scaled)
    lower = scaled <= 1.0
    middle = (scaled > 1.0) & (scaled < 2.0)

    cdf[lower] = 0.5 * scaled[lower] ** power
    cdf[middle] = 1.0 - 0.5 * (2.0 - scaled[middle]) ** power
    cdf[scaled >= 2.0] = 1.0

    return make_unit_hydrograph(weights_from_cdf(cdf))


def uniform_hydrograph(duration, delta_t):
    duration = max(float(duration), float(delta_t), 1e-9)
    steps = max(1, int(math.ceil(duration / delta_t)))
    return make_unit_hydrograph(np.ones(steps, dtype=np.float64))


def delay_hydrograph(delay, delta_t):
    delay = max(float(delay), 0.0)
    steps = max(1, int(round(delay / delta_t)))
    weights = np.zeros(steps, dtype=np.float64)
    weights[-1] = 1.0
    return make_unit_hydrograph(weights)


def gamma_hydrograph(shape, scale, delta_t):
    shape = max(float(shape), 1e-6)
    scale = max(float(scale), float(delta_t), 1e-6)
    max_time = max(scale * shape * 8.0, delta_t)
    steps = max(1, int(math.ceil(max_time / delta_t)))
    times = np.arange(1, steps + 1, dtype=np.float64) * delta_t

    coefficient = 1.0 / (math.gamma(shape) * scale**shape)
    pdf = coefficient * times ** (shape - 1.0) * np.exp(-times / scale)
    return make_unit_hydrograph(pdf)


__all__ = [
    "DoubleUHState",
    "FloatArray",
    "SingleUHState",
    "TripleUHState",
    "delay_hydrograph",
    "full_hydrograph",
    "gamma_hydrograph",
    "half_hydrograph",
    "make_unit_hydrograph",
    "route",
    "route_uh_current",
    "route_uh_current_nb",
    "uniform_hydrograph",
    "update_uh",
    "update_uh_inplace",
    "update_uh_inplace_nb",
    "weights_from_cdf",
]
