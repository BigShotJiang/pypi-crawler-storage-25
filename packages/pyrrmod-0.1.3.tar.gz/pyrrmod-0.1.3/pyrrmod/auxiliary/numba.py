from __future__ import annotations

from collections.abc import Callable
from typing import Any

try:
    import numba
except Exception:  # pragma: no cover - optional dependency
    numba = None


NUMBA_AVAILABLE = numba is not None


def optional_njit(
    *args: Any, **kwargs: Any
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Return ``numba.njit`` when available, otherwise an identity decorator."""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        if numba is None:
            return func
        return numba.njit(*args, **kwargs)(func)

    return decorator


def ensure_njit(
    func: Callable[..., Any], *args: Any, **kwargs: Any
) -> Callable[..., Any]:
    """Return a numba dispatcher for ``func`` and reuse compiled dispatchers."""

    if numba is None:
        raise RuntimeError("numba is not installed")
    if hasattr(func, "nopython_signatures"):
        return func
    return numba.njit(*args, **kwargs)(func)
