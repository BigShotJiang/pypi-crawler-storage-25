import numpy as np

from pyrrmod.auxiliary.numba import optional_njit


@optional_njit(cache=True)
def percolation_1(p1, S, dt):
    # Flux function
    # Description: Percolation at a constant rate
    # Constraints: f <= S/dt
    # Inputs: p1 - base percolation rate [mm/day]
    #         S  - current storage [mm]
    #         dt - time step size [day]
    out = min(p1, S / dt)
    return out


# Python code
@optional_njit(cache=True)
def percolation_2(p1, S, Smax, dt):
    # Percolation scaled by current relative storage
    # Constraints: f <= S/dt
    # Inputs: p1 - maximum percolation rate [mm/d]
    #         S - current storage [mm]
    #         Smax - maximum storage [mm]
    #         dt - time step size [d]
    out = min(S / dt, p1 * S / Smax)
    return out


@optional_njit(cache=True)
def percolation_3(S, Smax):
    """
    Non-linear percolation (empirical) function
    """
    out = Smax ** (-4) / 4 * (4 / 9) ** 4 * S**5
    return out


def percolation_4(p1, p2, p3, p4, p5, S, Smax, dt):
    """
    Flux function for demand-based percolation scaled by available moisture.

    Args:
    p1   : float : base percolation rate [mm/d]
    p2   : float : percolation rate increase due moisture deficiencies [mm/d]
    p3   : float : non-linearity parameter [-]
    p4   : float : summed deficiency across all model stores [mm]
    p5   : float : summed capacity of model stores [mm]
    S    : float : current storage in the supplying store [mm]
    Smax : float : maximum storage in the supplying store [mm]
    dt   : float : time step size [d]

    Returns:
    out  : float : percolation rate [mm/d]
    """
    out = max(
        0, min(S / dt, max(0, S / Smax) * (p1 * (1 + p2 * (p4 / p5) ** (1 + p3))))
    )
    return out


@optional_njit(cache=True)
def percolation_5(p1, p2, S, Smax, dt):
    # Flux function
    # Description: Non-linear percolation
    # Constraints: f <= S/dt, S >= 0 (prevents complex numbers)
    # Inputs: p1 - base percolation rate [mm/d]
    #         p2 - exponential scaling parameter [-]
    #         S - current storage [mm]
    #         Smax - maximum contributing storage [mm]
    #         dt - time step size [d]

    return min(S / dt, p1 * ((max(S, 0.0) / Smax) ** p2))


def percolation_6(p1, p2, S, dt):
    """

    WARRANTY. See <https://www.gnu.org/licenses/> for details.

    Flux function

    Description:  Threshold-based percolation from a store that can reach negative values
    Constraints:  f <= S/dt

    Parameters
    ----------
    p1 : float
        maximum percolation rate
    p2 : float
        storage threshold for reduced percolation [mm]
    S : float
        current storage [mm]
    dt : float
        time step size [d]

    Returns
    -------
    out : float
        Percolation from storage
    """
    out = min(max(0, S) / dt, p1 * min(1, max(0, S) / p2))
    return out
