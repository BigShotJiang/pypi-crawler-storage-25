import numpy as np
from pyrrmod.auxiliary.smooth import smooth_threshold_storage_logistic as stsl
from pyrrmod.auxiliary.numba import optional_njit
# Flux function
# ------------------
# Description:  Exponential inflow to surface depression store
# Constraints:  f <= (Smax-S)/dt
#               S <= Smax
# @(Inputs):    p1   - linear scaling parameter [-]
#               p2   - exponential scaling parameter [-]
#               S    - current storage [mm]
#               Smax - maximum storage [mm]
#               dt   - time step size [d]


@optional_njit(cache=True)
def abstraction_1(p1):
    # Flux function
    # Description: Function for constant groundwater abstraction
    # Constraints: None, taken from a store with possible negative depth
    # @(Inputs): p1 - Abstraction rate [mm/d]
    return p1


def area_1(p1: float, p2: float, S: float, Smin: float, Smax: float, *args) -> float:
    """
    Auxiliary function that calculates a variable contributing area.

    Parameters
    ----------
    p1 : float
        Linear scaling parameter [-].
    p2 : float
        Exponential scaling parameter [-].
    S : float
        Current storage [mm].
    Smin : float
        Minimum contributing storage [mm].
    Smax : float
        Maximum contributing storage [mm].
    args : tuple, optional
        Additional arguments for smoothing. Default is (0.01, 5.00).

    Returns
    -------
    float
        Variable contributing area.
    """

    if len(args) == 0:
        smoothing_factor = stsl(S, Smin)
    elif len(args) == 1:
        smoothing_factor = stsl(S, Smin, args[0])
    elif len(args) == 2:
        smoothing_factor = stsl(S, Smin, args[0], args[1])

    area = np.minimum(1, p1 * (np.maximum(0, S - Smin) / (Smax - Smin)) ** p2) * (
        1 - smoothing_factor
    )

    return area


@optional_njit(cache=True)
def depression_1(p1, p2, S, Smax, flux, dt):
    available = max(Smax - S, 0)
    if available <= 0 or dt <= 0:
        return 0.0

    potential = p1 * np.exp(-1 * p2 * S / available) * flux
    out = min(potential, max(available / dt, 0))
    return max(out, 0.0)


# Python equivalent of the MATLAB function effective_1
# WARRANTY. See <https://www.gnu.org/licenses/> for details.


# Flux function
# Description:  General effective flow (returns flux [mm/d])
# Constraints:  In1 > In2
# Inputs:       In1  - first flux [mm/d]
#               In2  - second flux [mm/d]
@optional_njit(cache=True)
def effective_1(In1, In2):
    # Calculate the maximum of the difference between In1 and In2 and 0
    out = max(In1 - In2, 0)
    return out


@optional_njit(cache=True)
def excess_1(So, Smax, dt):
    # Flux function
    # ------------------
    # Description:  Storage excess when store size changes (returns flux [mm/d])
    # Constraints:  f >= 0
    # @(Inputs):    So   - 'old' storage [mm]
    #               Smax - 'new' maximum storage [mm]
    #               dt   - time step size [d]

    out = max((So - Smax) / dt, 0.0)
    return out


@optional_njit(cache=True)
def refreeze_1(p1, p2, p3, T, S, dt):
    """
    Flux function
    Description: Refreezing of stored melted snow
    Constraints: f <= S/dt
    Inputs:
      p1 - reduction fraction of degree-day-factor [-]
      p2 - degree-day-factor [mm/oC/d]
      p3 - temperature threshold for snowmelt [oC]
      T  - current temperature [oC]
      S  - current storage [mm]
      dt - time step size [d]
    """

    out = max(min(p1 * p2 * (p3 - T), S / dt), 0)
    return out


def routing_1(p1, p2, p3, S, dt):
    # non-linear routing
    # WARRANTY. See <https://www.gnu.org/licenses/> for details.

    # Flux function
    # ------------------
    # Description:  Threshold-based non-linear routing
    # Constraints:  f <= S/dt
    #               S >= 0      prevents complex numbers
    # @(Inputs):    p1   - linear scaling parameter [-]
    #               p2   - exponential scaling parameter [-]
    #               p3   - fractional release parameter [-]
    #               S    - current storage [mm]
    #               dt   - time step size [d]

    out = min([S / dt, p1 * (max(S, 0) ** p2), p3 * S / dt])
    return out
