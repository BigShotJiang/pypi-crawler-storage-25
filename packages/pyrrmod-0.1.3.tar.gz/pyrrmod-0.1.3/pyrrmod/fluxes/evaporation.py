import numpy as np
from pyrrmod.auxiliary.smooth import smooth_threshold_storage_logistic
from pyrrmod.auxiliary.numba import optional_njit


@optional_njit(cache=True)
def evap_1(S, Ep, dt):
    # Flux function
    # Description: Evaporation at the potential rate
    # Constraints: f <= S/dt
    # @(Inputs): S    - current storage [mm]
    #            Ep   - potential evaporation rate [mm/d]
    #            dt   - time step size
    out = min(S / dt, Ep)
    return out


# Python function for evap_10
@optional_njit(cache=True)
def evap_10(p1, S, Smax, Ep, dt):
    # Flux function
    # Description: Evaporation from bare soil scaled by relative storage
    # Constraints: Ea <= Ep, Ea <= S/dt
    # Inputs: p1 - fraction of area that is bare soil [-]
    #         S - current storage [mm]
    #         Smax - maximum storage [mm]
    #         Ep - potential evapotranspiration rate [mm/d]
    #         dt - time step size [d]
    out = max(min(p1 * S / Smax * Ep, S / dt), 0.0)
    return out


@optional_njit(cache=True)
def evap_11(S, Smax, Ep):
    # Evaporation quadratically related to current soil moisture
    # Constraints:  f >= 0
    # Inputs: S - current storage [mm]
    #         Smax - maximum storage [mm]
    #         Ep - potential evapotranspiration rate [mm/d]
    out = max(0, (2 * S / Smax - (S / Smax) ** 2) * Ep)
    return out


@optional_njit(cache=True)
def evap_12(S, p1, Ep):
    # Evaporation from deficit store, with exponential decline as deficit goes below a threshold
    # Inputs:
    #   S  - current storage [mm]
    #   p1 - wilting point [mm]
    #   Ep - potential evapotranspiration rate [mm/d]
    # Returns:
    #   Evaporation rate [mm/d]
    return min(1, np.exp(2 * (1 - S / p1))) * Ep


@optional_njit(cache=True)
def evap_13(p1, p2, Ep, S, dt):
    # Flux function
    # Description: Exponentially scaled evaporation
    # Constraints: f <= S/dt
    # Inputs:
    #   p1 - linear scaling parameter [-]
    #   p2 - exponential scaling parameter [-]
    #   Ep - potential evapotranspiration rate [mm/d]
    #   S - current storage [mm]
    #   dt - time step size [d]

    out = min((p1**p2) * Ep, S / dt)
    return out


@optional_njit(cache=True)
def evap_14(p1, p2, Ep, S1, S2, S2min, dt):
    """
    Exponentially scaled evaporation that only activates if another store goes below a certain threshold.

    Constraints: f <= S1/dt
    Inputs:
        p1   - linear scaling parameter [-]
        p2   - exponential scaling parameter [-]
        Ep   - potential evapotranspiration rate [mm/d]
        S1   - current storage in S1 [mm]
        S2   - current storage in S2 [mm]
        S2min- threshold for evaporation deactivation [mm]
        dt   - time step size [d]
    """
    out = min((p1**p2) * Ep, S1 / dt) * smooth_threshold_storage_logistic(S2, S2min)
    return out


def evap_15(Ep, S1, S1max, S2, S2min, dt):
    """
    Flux function.

    Description: Scaled evaporation if another store is below a threshold.

    Constraints: f <= S1/dt

    Parameters:
    -----------
    Ep : float
        Potential evapotranspiration rate [mm/d].
    S1 : float
        Current storage in S1 [mm].
    S1max : float
        Maximum storage in S1 [mm].
    S2 : float
        Current storage in S2 [mm].
    S2min : float
        Minimum storage in S2 [mm].
    dt : float
        Time step size [d].

    Returns:
    --------
    out : float
        Resulting flux.
    """
    return min(
        (S1 / S1max * Ep) * smooth_threshold_storage_logistic(S2, S2min), S1 / dt
    )


@optional_njit(cache=True)
def evap_16(p1, S1, S2, S2min, Ep, dt):
    # Flux function
    # ------------------
    # Description:  Scaled evaporation if another store is below a threshold
    # Constraints:  f <= S1/dt
    # @(Inputs):    p1    - linear scaling parameter [-]
    #               S1    - current storage in S1 [mm]
    #               S2    - current storage in S2 [mm]
    #               S2min - threshold S2 storage for evaporation occurence [mm]
    #               Ep    - potential evapotranspiration rate [mm/d]
    #               dt    - time step size [d]

    out = min((p1 * Ep) * smooth_threshold_storage_logistic(S2, S2min), S1 / dt)
    return out


def evap_17(p1, S, Ep):
    """
    Flux function
    Description: Scaled evaporation from a store that allows negative values
    Constraints: -
    Inputs:
        p1 - linear scaling parameter [mm-1]
        S - current storage [mm]
        Ep - potential evapotranspiration rate [mm/d]
    """
    import numpy as np

    # bug fix: 11July2024 - SAS - if else statement added to prevent overflow in np.exp term
    if abs(-1 * p1 * S) > 700:
        out = 0
    else:
        out = 1 / (1 + np.exp(-1 * p1 * S)) * Ep

    return out


def evap_18(p1: float, p2: float, p3: float, S: float, Ep: float) -> float:
    """
    Calculate the exponentially declining evaporation from the deficit store.

    Parameters
    ----------
    p1 : float
        Linear scaling parameter [-].
    p2 : float
        Linear scaling parameter [-].
    p3 : float
        Storage scaling parameter [mm].
    S : float
        Current storage [mm].
    Ep : float
        Potential evapotranspiration rate [mm/d].

    Returns
    -------
    float
        The evaporation rate [mm/d].
    """
    out = p1 * np.exp(-1.0 * p2 * S / p3) * Ep
    return out


def evap_19(p1, p2, S, Smax, Ep, dt):
    # Description: Non-linear scaled evaporation
    # Constraints: f <= Ep, f <= S/dt
    # Inputs: p1 - linear scaling parameter [-]
    #         p2 - exponential scaling parameter [-]
    #         S - current storage [mm]
    #         Smax - maximum storage [mm]
    #         Ep - potential evapotranspiration rate [mm/d]
    #         dt - time step size [d]
    out = min([S / dt, Ep, p1 * max(0, S / Smax) ** (p2) * Ep])
    return out


@optional_njit(cache=True)
def evap_2(p1, S, Smax, Ep, dt):
    # Flux function
    # Description: Evaporation at a scaled, plant-controlled rate
    # Constraints: f <= Ep
    #              f <= S/dt
    # @(Inputs):   p1   - plant-controlled base evaporation rate [mm/d]
    #             S    - current storage [mm]
    #             Smax - maximum storage [mm]
    #             Ep   - potential evapotranspiration rate [mm/d]
    #             dt   - time step size [d]

    return min(p1 * S / Smax, min(Ep, S / dt))


@optional_njit(cache=True)
def evap_20(p1, p2, S, Smax, Ep, dt):
    """
    Evaporation limited by a maximum evaporation rate and scaled below a wilting point
    :param p1: maximum evaporation rate [mm/d]
    :param p2: wilting point as fraction of Smax [-]
    :param S: current storage [mm]
    :param Smax: maximum storage [mm]
    :param Ep: potential evapotranspiration rate [mm/d]
    :param dt: time step size [d]
    :return: evaporation flux
    """
    return min(p1 * S / (p2 * Smax), min(Ep, S / dt))


# Equivalent Python function for the Matlab evaporation function


# Threshold-based evaporation with constant minimum rate
# Arguments:
# p1 : float
#     Wilting point (1st threshold) [mm]
# p2 : float
#     2nd threshold as a fraction of wilting point [-]
# S : float
#     Current storage [mm]
# Ep : float
#     Potential evapotranspiration rate [mm/d]
# dt : float
#     Time step size [d]
# Returns:
# float
#     Evaporation rate
# Function Body:
@optional_njit(cache=True)
def evap_21(p1, p2, S, Ep, dt):
    return min(max(p2, min(S / p1, 1)) * Ep, S / dt)


def evap_22(p1, p2, S, Ep, dt):
    # evap_22 3-part piece-wise evaporation
    # Flux function
    # Description: Threshold-based evaporation rate
    # Constraints: f <= S/dt
    # @(Inputs): p1 - wilting point [mm]
    #            p2 - 2nd (lower) threshold [mm]
    #            S - current storage [mm]
    #            Ep - potential evapotranspiration rate [mm/d]
    #            dt - time step size [d]

    return min(S / dt, max(0, min((S - p1) / (p2 - p1) * Ep, Ep)))


def evap_23(p1: float, p2: float, S: float, Smax: float, Ep: float, dt: float) -> float:
    """
    Combines evaporation and transpiration processes.

    Transpiration from vegetation at the potential rate if storage is
    above field capacity and scaled by relative storage if not,
    addition of evaporation from bare soil scaled by relative storage.

    Parameters
    ----------
    p1 : float
        Fraction vegetated area [-] (0...1).
    p2 : float
        Field capacity coefficient [-].
    S : float
        Current storage [mm].
    Smax : float
        Maximum storage [mm].
    Ep : float
        Potential evapotranspiration rate [mm/d].
    dt : float
        Time step size [d].

    Returns
    -------
    float
        The combined evaporation and transpiration rate [mm/d].
    """
    term1 = p1 * Ep + (1 - p1) * S / Smax * Ep
    term2 = p1 * Ep * S / (p2 * Smax) + (1 - p1) * S / Smax * Ep
    term3 = S / dt
    out = min(term1, term2, term3)
    return out


@optional_njit(cache=True)
def evap_3(p1: float, S: float, Smax: float, Ep: float, dt: float) -> float:
    """
    Evaporation based on scaled current water storage and wilting point.

    Parameters
    ----------
    p1 : float
        Wilting point as fraction of Smax [-].
    S : float
        Current storage [mm].
    Smax : float
        Maximum storage [mm].
    Ep : float
        Potential evapotranspiration rate [mm/d].
    dt : float
        Time step size [d].

    Returns
    -------
    float
        Evaporation rate [mm/d].
    """

    out = min(S / (p1 * Smax) * Ep, min(Ep, S / dt))

    return out


@optional_njit(cache=True)
def evap_4(Ep, p1, S, p2, Smax, dt):
    """
    Evaporation based on scaled current water storage, a wilting point,
    a constraining factor and limited by potential rate.

    Args:
    - Ep: potential evapotranspiration rate [mm/d]
    - p1: scaling parameter [-]
    - p2: wilting point as fraction of Smax [-]
    - S: current storage [mm]
    - Smax: maximum storage [mm]
    - dt: time step size [d]

    Returns:
    - out: calculated evaporation
    """
    out = min(Ep * max(0, p1 * (S - p2 * Smax) / (Smax - p2 * Smax)), S / dt)
    return out


@optional_njit(cache=True)
def evap_5(p1, S, Smax, Ep, dt):
    """
    evap_5 evaporation based on scaled current water storage, for a fraction
    of the surface

    Inputs:
    - p1   : fraction of area that is bare soil [-]
    - S    : current storage [mm]
    - Smax : maximum storage [mm]
    - Ep   : potential evapotranspiration rate [mm/d]
    - dt   : time step size [d]

    Output:
    - out  : evaporation value
    """
    out = np.maximum(np.minimum((1 - p1) * (S / Smax) * Ep, S / dt), 0.0)

    return out


@optional_njit(cache=True)
def evap_6(p1, p2, S, Smax, Ep, dt):
    """
    evap_6 evaporation based on scaled current water storage, a wilting point, a constraining factor and limited by potential rate.

    Original MATLAB function description:
    # Flux function
    # ------------------
    # Description:  Transpiration from vegetation at the potential rate if
    #               storage is above a wilting point and scaled by relative
    #               storage if not
    # Constraints:  Ea <= Ep
    #               Ea <= S/dt
    # @(Inputs):    p1   - fraction vegetated area [-]
    #               p2   - wilting point as fraction of Smax
    #               S    - current storage [mm]
    #               Smax - maximum storage [mm]
    #               Ep   - potential evapotranspiration rate [mm/d]
    #               dt   - time step size [d]
    """
    return min(p1 * Ep, min(p1 * Ep * S / (p2 * Smax), S / dt))


@optional_njit(cache=True)
def evap_7(S, Smax, Ep, dt):
    # evaporation based on scaled current water storage, limited by potential rate.

    # Flux function
    # Description:  Evaporation scaled by relative storage
    # Constraints:  f <= S/dt
    # Inputs:    S    - current storage [mm]
    #            Smax - maximum contributing storage [mm]
    #            Ep   - potential evapotranspiration rate [mm/d]
    #            dt   - time step size [d]
    out = min(S / Smax * Ep, S / dt)
    return out


@optional_njit(cache=True)
def evap_8(S1, S2, p1, p2, Ep, dt):
    # evap_8 evaporation based on scaled current water storage, a wilting point, and a distribution factor.

    # Flux function
    # ------------------
    # Description:  Transpiration from vegetation, at potential rate if soil
    #               moisture is above the wilting point, and linearly
    #               decreasing if not. Also scaled by relative storage across
    #               all stores
    # Constraints:  f <= S/dt
    #               f >= 0
    # @(Inputs):    S1   - current storage in store 1 [mm]
    #               S2   - current storage in store 2 [mm]
    #               p1   - fraction vegetated area [-]
    #               p2   - wilting point [mm]
    #               Ep   - potential evapotranspiration rate [mm/d]
    #               dt   - time step size [d]

    if S1 + S2 == 0:
        out = 0
    else:
        option_1 = S1 / (S1 + S2) * p1 * Ep
        option_2 = S1 / (S1 + S2) * S1 / p2 * p1 * Ep
        out = max(min(option_1, min(option_2, S1 / dt)), 0.0)

    return out


@optional_njit(cache=True)
def evap_9(S1, S2, p1, Smax, Ep, dt):
    # Flux function
    # Description:  Evaporation from bare soil scaled by relative storage and
    #               by relative water availability across all stores
    # Constraints:  f <= S/dt
    #               f >= 0
    # Inputs:       S1   - current storage in store 1 [mm]
    #               S2   - current storage in store 2 [mm]
    #               p1   - fraction vegetated area [-]
    #               Smax - maximum storage [mm]
    #               Ep   - potential evapotranspiration rate [mm/d]
    #               dt   - time step size [d]

    if S1 + S2 == 0:
        out = 0
    else:
        out = max(min(S1 / (S1 + S2) * (1 - p1) * S1 / (Smax - S2) * Ep, S1 / dt), 0)

    return out
