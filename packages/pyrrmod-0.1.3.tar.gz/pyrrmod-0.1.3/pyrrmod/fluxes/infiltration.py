import numpy as np
from pyrrmod.auxiliary.smooth import smooth_threshold_storage_logistic
from pyrrmod.auxiliary.smooth import smooth_threshold_storage_logistic as stsl
from pyrrmod.auxiliary.numba import optional_njit


@optional_njit(cache=True)
def infiltration_1(p1: float, p2: float, S: float, Smax: float, fin: float) -> float:
    """
    Calculates infiltration as an exponentially declining function based on relative storage.

    Parameters
    ----------
    p1 : float
        Maximum infiltration rate [mm/d].
    p2 : float
        Exponential scaling parameter [-].
    S : float
        Current storage [mm].
    Smax : float
        Maximum storage [mm].
    fin : float
        Size of incoming flux [mm/d].

    Returns
    -------
    float
        The infiltration flux, constrained to be less than or equal to the incoming flux.
    """
    out = np.minimum(p1 * np.exp((-1 * p2 * S) / Smax), fin)
    return out


@optional_njit(cache=True)
def infiltration_2(p1, p2, S1, S1max, flux, S2, dt):
    # Flux function
    # Description:  Infiltration as exponentially declining based on relative storage
    # Constraints:  0 <= f <= S2/dt
    # Inputs:  p1    - maximum infiltration rate [mm,/d]
    #               p2    - exponential scaling parameter [-]
    #               S1    - current storage in S1 [mm]
    #               S1max - maximum storage in S1 [mm]
    #               flux  - reduction of infiltration rate by infiltration
    #                       demand already fulfilled elsewhere [mm/d]
    #               S2    - storage available for infiltration [mm]
    #               dt    - time step size [d]

    out = max(min((p1 * np.exp(p2 * S1 / S1max) - flux), S2 / dt), 0)
    return out


@optional_njit(cache=True)
def infiltration_3(In, S, Smax, *varargs):
    """
    Infiltration to soil moisture of liquid water stored in snow pack

    Arguments:
    In : float
        incoming flux [mm/d]
    S : float
        current storage [mm]
    Smax : float
        maximum storage [mm]
    varargs : tuple
        smoothing variable r (default 0.01), smoothing variable e (default 5.00)

    Returns:
    out : float
    """
    if len(varargs) == 0:
        out = In * (1 - smooth_threshold_storage_logistic(S, Smax))
    elif len(varargs) == 1:
        out = In * (1 - smooth_threshold_storage_logistic(S, Smax, varargs[0]))
    elif len(varargs) == 2:
        out = In * (
            1 - smooth_threshold_storage_logistic(S, Smax, varargs[0], varargs[1])
        )
    return out


@optional_njit(cache=True)
def infiltration_4(fluxIn, p1):
    # Flux function
    # Description:  Constant infiltration rate
    # Constraints:  f <= fin
    # Inputs:       p1   - Infiltration rate [mm/d]
    #               fin  - incoming flux [mm/d]

    # Returns the minimum of fluxIn and p1
    return min(fluxIn, p1)


def infiltration_5(p1, p2, S1, S1max, S2, S2max):
    """
    Flux function
    Description:  Maximum infiltration rate non-linearly based on relative deficit and storage
    Constraints:  S2 >= 0     - prevents complex numbers
                  f <= 10^9   - prevents numerical issues with Inf outcomes
    @(Inputs):    p1    - base infiltration rate [mm/d]
                  p2    - exponential scaling parameter [-]
                  S1    - current storage in S1 [mm]
                  S1max - maximum storage in S1 [mm]
                  S2    - current storage in S2 [mm]
                  S2max - maximum storage in S2 [mm]
    """
    import numpy as np

    # prevents issues with small negative S2 values, as well as mathematical errors when S2 = 0
    # If S2/S2max = 1.0, scaler =  1
    # If S2/S2max = 0.5, scaler >  1
    # If S2/S2max = 0.1, scaler >> 1
    # Thus,
    # if S2/S2max = 0.00, scaler >>> 1
    # However, Python does not calculate 0**-1 (DIV0 error) and we need the code below
    if S2 / S2max > 0:
        # We need to set the dtype to avoid “<error>”
        scaler = np.power(S2 / S2max, -1 * p2, dtype=np.float64)
    else:
        scaler = 10**9  # Something large, but we cannot compute (0/S2max)**(-1*p2)

    # Resume function calculation
    # max(0,x) prevents issues with small negative values for S1
    out = max(0, p1 * (1 - S1 / S1max) * scaler)
    return out


def infiltration_6(p1, p2, S, Smax, fin):
    """
    Creates scaled, non-linear infiltration
    """

    # Infiltration rate non-linearly scaled by relative storage
    # Constraints:  f <= fin
    # @(Inputs):    p1   - base infiltration rate [mm/d]
    #               p2   - exponential scaling parameter [-]
    #               S    - current storage [mm]
    #               Smax - maximum contributing storage [mm]
    #               fin  - incoming flux [mm/d]

    out = min([fin, p1 * max(0, S / Smax) ** p2 * fin])
    return out


def infiltration_7(
    p1: float, p2: float, S: float, Smax: float, In: float, *args
) -> np.ndarray:
    """
    Calculates infiltration as an exponentially declining function based on relative storage with customization.

    Parameters
    ----------
    p1 : float
        Maximum infiltration rate [mm/d].
    p2 : float
        Exponential scaling parameter [-].
    S : float
        Current storage [mm].
    Smax : float
        Maximum storage [mm].
    In : float
        Size of incoming flux [mm/d].
    *args : float
        Additional optional parameters for the smoothing function.

    Returns
    -------
    float
        The infiltration flux, constrained to be less than or equal to the incoming flux and customized with smoothing.
    """
    pre_smoother = np.minimum(p1 * np.exp((-1 * p2 * S) / Smax), In)

    if len(args) == 0:
        out = pre_smoother * (1 - stsl(S, Smax))
    elif len(args) == 1:
        out = pre_smoother * (1 - stsl(S, Smax, args[0]))
    elif len(args) == 2:
        out = pre_smoother * (1 - stsl(S, Smax, args[0], args[1]))
    else:
        raise ValueError("Too many arguments provided for the smoothing function.")

    return out


def infiltration_8(S, Smax, fin):
    # Infiltration into storage is equal to the inflow when current storage is under the maximum storage,
    # and zero when storage reaches maximum capacity
    # Constraints:  f <= fin
    # @(Inputs):
    #     S    - current storage [mm]
    #     Smax - maximum storage [mm]
    #     fin  - size of incoming flux [mm/d]

    out = (S < Smax) * fin
    return out
