import numpy as np

from pyrrmod.auxiliary.numba import optional_njit


@optional_njit(cache=True)
def exchange_1(
    p1: float, p2: float, p3: float, S: float, fmax: float, dt: float
) -> float:
    """
    Water exchange between aquifer and channel.

    Parameters
    ----------
    p1 : float
        Linear scaling parameter [-].
    p2 : float
        Linear scaling parameter [-].
    p3 : float
        Exponential scaling parameter [-].
    S : float
        Current storage [mm].
    fmax : float
        Maximum flux size [mm/d].
    dt : float
        Time step size [d].

    Returns
    -------
    float
        The calculated water exchange flux.
    """
    out = max(
        (p1 * abs(S / dt) + p2 * (1 - np.exp(-p3 * abs(S / dt)))) * np.sign(S),
        -fmax,
    )
    return out


def exchange_2(p1, S1, S1max, S2, S2max):
    # Water exchange based on relative storages
    # Inputs: p1 - base exchange rate [mm/d]
    #         S1 - current storage in S1 [mm]
    #         S1max - maximum storage in S1 [mm]
    #         S2 - current storage in S2 [mm]
    #         S2max - maximum storage in S2 [mm]

    out = p1 * (S1 / S1max - S2 / S2max)
    return out


@optional_njit(cache=True)
def exchange_3(p1, S, p2):
    """
    Flux function
    Description: Water exchange with infinite size store based on threshold
    Constraints: -
    Inputs:
        p1 - base leakage time delay [d-1]
        p2 - threshold for flow reversal [mm]
        S  - current storage [mm]
    """
    return p1 * (S - p2)


@optional_njit(cache=True)
def exchange_4(S, Smax, p1):
    """Power-law exchange used by GR4J routing storage."""

    return p1 * ((max(S, 0.0) / Smax) ** 3.5)
