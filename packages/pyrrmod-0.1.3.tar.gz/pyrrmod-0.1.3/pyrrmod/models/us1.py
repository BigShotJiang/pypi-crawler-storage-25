from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    evap_10,
    evap_5,
    evap_8,
    evap_9,
    excess_1,
    interception_3,
    saturation_1,
)
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _us1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    alpha_ei = float(theta[0])
    m = float(theta[1])
    smax = float(theta[2])
    fc = float(theta[3])
    alpha_ss = float(theta[4])

    S1 = float(states[0])
    S2 = float(states[1])

    P = float(precip[step_index])
    Ep = float(pet[step_index])
    recharge_limit = fc * (smax - S2)

    flux_eusei = interception_3(alpha_ei, P)
    flux_eusveg = evap_8(S1, S2, m, recharge_limit, Ep, delta_t)
    flux_eusbs = evap_9(S1, S2, m, smax, Ep, delta_t)
    flux_esatveg = evap_10(m, S2, smax, Ep, delta_t)
    flux_esatbs = evap_5(m, S2, smax, Ep, delta_t)
    flux_rg = saturation_1(P, S1, recharge_limit)
    flux_se = excess_1(S1, recharge_limit, delta_t)
    flux_qse = saturation_1(flux_rg + flux_se, S2, smax)
    flux_qss = baseflow_1(alpha_ss, S2)

    out_dS[0] = P - flux_eusei - flux_eusveg - flux_eusbs - flux_rg - flux_se
    out_dS[1] = flux_rg + flux_se - flux_esatveg - flux_esatbs - flux_qse - flux_qss

    out_fluxes[0] = flux_eusei
    out_fluxes[1] = flux_eusveg
    out_fluxes[2] = flux_eusbs
    out_fluxes[3] = flux_esatveg
    out_fluxes[4] = flux_esatbs
    out_fluxes[5] = flux_rg
    out_fluxes[6] = flux_se
    out_fluxes[7] = flux_qse
    out_fluxes[8] = flux_qss


class us1(StepKernelModel):
    python_step_function = staticmethod(_us1_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 9
        self.num_params = 5
        self.jacob_pattern = np.array([[1, 1], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[0, 1], [0.05, 0.95], [1, 2000], [0.05, 0.95], [0, 1]],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2"]
        self.flux_names = [
            "eusei",
            "eusveg",
            "eusbs",
            "esatveg",
            "esatbs",
            "rg",
            "se",
            "qse",
            "qss",
        ]
        self.flux_groups = {"Ea": [1, 2, 3, 4, 5], "Q": [8, 9]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
