from __future__ import annotations

import numpy as np

from pyrrmod.auxiliary.numba import optional_njit
from pyrrmod.auxiliary.unit_hydro import (
    DoubleUHState,
    half_hydrograph,
    route_uh_current_nb,
)
from pyrrmod.fluxes import baseflow_1, evap_3, percolation_2, saturation_3, split_1
from pyrrmod.models.base import FloatArray, HydrologyModel, UnitHydroNumbaMixin


def _flexb_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _uh1_weights: FloatArray,
    uh1_pending: FloatArray,
    _uh2_weights: FloatArray,
    uh2_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weight arrays in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    s1max = float(theta[0])
    beta = float(theta[1])
    d = float(theta[2])
    percmax = float(theta[3])
    lp = float(theta[4])
    kf = float(theta[7])
    ks = float(theta[8])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ru = saturation_3(S1, s1max, beta, P)
    flux_eur = evap_3(lp, S1, s1max, Ep, delta_t)
    flux_ps = percolation_2(percmax, S1, s1max, delta_t)
    flux_rf = split_1(1.0 - d, P - flux_ru)
    flux_rs = split_1(d, P - flux_ru)
    flux_rfl = route_uh_current_nb(uh1_pending)
    flux_rsl = route_uh_current_nb(uh2_pending)
    flux_qf = baseflow_1(kf, S2)
    flux_qs = baseflow_1(ks, S3)

    out_dS[0] = flux_ru - flux_eur - flux_ps
    out_dS[1] = flux_rfl - flux_qf
    out_dS[2] = flux_rsl - flux_qs

    out_fluxes[0] = flux_ru
    out_fluxes[1] = flux_eur
    out_fluxes[2] = flux_ps
    out_fluxes[3] = flux_rf
    out_fluxes[4] = flux_rs
    out_fluxes[5] = flux_rfl
    out_fluxes[6] = flux_rsl
    out_fluxes[7] = flux_qf
    out_fluxes[8] = flux_qs


_flexb_compute_step_numba = optional_njit(cache=True)(_flexb_compute_step)


@optional_njit(cache=True)
def _flexb_commit_inflow_nb(fluxes: FloatArray) -> tuple[float, float]:
    return fluxes[3], fluxes[2] + fluxes[4]


class flexb(UnitHydroNumbaMixin, HydrologyModel):
    python_step_function = staticmethod(_flexb_compute_step)
    numba_step_function = staticmethod(_flexb_compute_step_numba)
    numba_commit_inflow_function = staticmethod(_flexb_commit_inflow_nb)
    routing_state_type = DoubleUHState
    routed_numba_newton_kind = "double"

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 9
        self.num_params = 9
        self.jacob_pattern = np.array([[1, 0, 0], [1, 1, 0], [1, 0, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [1, 2000],
                [0, 10],
                [0, 1],
                [0, 20],
                [0.05, 0.95],
                [1, 5],
                [1, 15],
                [0, 1],
                [0, 1],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["ru", "eur", "ps", "rf", "rs", "rfl", "rsl", "qf", "qs"]
        self.flux_groups = {"Ea": 2, "Q": [8, 9]}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        uh1, _ = half_hydrograph(float(theta[5]), float(self.delta_t), power=1.5)
        uh2, _ = half_hydrograph(float(theta[6]), float(self.delta_t), power=1.5)
        routing_state = DoubleUHState(
            uh1_weights=np.ascontiguousarray(uh1, dtype=np.float64),
            uh1_pending=np.zeros_like(uh1),
            uh2_weights=np.ascontiguousarray(uh2, dtype=np.float64),
            uh2_pending=np.zeros_like(uh2),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()
