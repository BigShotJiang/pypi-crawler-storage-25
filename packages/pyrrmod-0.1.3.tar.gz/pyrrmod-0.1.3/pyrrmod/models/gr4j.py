from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Any, Callable

import numpy as np

from pyrrmod.auxiliary.numba import optional_njit
from pyrrmod.auxiliary.solver import NUMBA_AVAILABLE
from pyrrmod.auxiliary.unit_hydro import (
    full_hydrograph,
    half_hydrograph,
    route_uh_current_nb,
    update_uh_inplace,
    update_uh_inplace_nb,
)
from pyrrmod.fluxes import baseflow_3, evap_11, exchange_4, percolation_3, saturation_4
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


@dataclass(slots=True, kw_only=True)
class GR4JRoutingState:
    q9_weights: FloatArray
    q9_pending: FloatArray
    q1_weights: FloatArray
    q1_pending: FloatArray

    def pending_total(self) -> float:
        return float(np.sum(self.q9_pending) + np.sum(self.q1_pending))

    def as_legacy_uhs(self) -> list[tuple[FloatArray, FloatArray]]:
        return [
            (self.q9_weights, self.q9_pending),
            (self.q1_weights, self.q1_pending),
        ]


def _make_gr4j_uh1(x4: float, delta_t: float) -> FloatArray:
    weights, _ = half_hydrograph(x4, delta_t, power=2.5)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _make_gr4j_uh2(x4: float, delta_t: float) -> FloatArray:
    weights, _ = full_hydrograph(2.0 * x4, delta_t, power=2.5)
    return np.ascontiguousarray(weights, dtype=np.float64)


def _gr4j_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _q9_weights: FloatArray,
    q9_pending: FloatArray,
    _q1_weights: FloatArray,
    q1_pending: FloatArray,
    out_states: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep weight arrays in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    x1 = float(theta[0])
    x2 = float(theta[1])
    x3 = float(theta[2])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pn = max(P - Ep, 0.0)
    flux_en = max(Ep - P, 0.0)
    flux_ef = P - flux_pn
    flux_ps = saturation_4(S1, x1, flux_pn)
    flux_es = evap_11(S1, x1, flux_en)
    flux_perc = percolation_3(S1, x1)
    flux_q9 = route_uh_current_nb(q9_pending) / delta_t
    flux_q1 = route_uh_current_nb(q1_pending) / delta_t
    flux_fr = exchange_4(S2, x3, x2)
    flux_fq = flux_fr
    flux_qr = baseflow_3(S2, x3)
    quick_component = flux_q1 + flux_fq
    quick_positive = quick_component if quick_component > 0.0 else 0.0
    flux_qt = flux_qr + quick_positive
    flux_ex = flux_fr + quick_positive - flux_q1

    dS1 = flux_ps - flux_es - flux_perc
    dS2 = flux_q9 + flux_fr - flux_qr
    out_states[0] = min(x1, max(0.0, S1 + dS1 * delta_t))
    out_states[1] = min(x3, max(0.0, S2 + dS2 * delta_t))

    out_fluxes[0] = flux_pn
    out_fluxes[1] = flux_en
    out_fluxes[2] = flux_ef
    out_fluxes[3] = flux_ps
    out_fluxes[4] = flux_es
    out_fluxes[5] = flux_perc
    out_fluxes[6] = flux_q9
    out_fluxes[7] = flux_q1
    out_fluxes[8] = flux_fr
    out_fluxes[9] = flux_fq
    out_fluxes[10] = flux_qr
    out_fluxes[11] = flux_qt
    out_fluxes[12] = flux_ex


_gr4j_compute_step_numba = optional_njit(cache=True)(_gr4j_compute_step)


def _gr4j_fluxes_to_dS(
    fluxes: FloatArray, out_dS: FloatArray | None = None
) -> FloatArray:
    if out_dS is None:
        out_dS = np.empty(2, dtype=np.float64)
    out_dS[0] = float(fluxes[3] - fluxes[4] - fluxes[5])
    out_dS[1] = float(fluxes[6] + fluxes[8] - fluxes[10])
    return out_dS


@optional_njit(cache=True)
def _gr4j_compute_step_nb(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    q9_pending: FloatArray,
    q1_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    x1 = theta[0]
    x2 = theta[1]
    x3 = theta[2]

    S1 = states[0]
    S2 = states[1]
    P = precip[step_index]
    Ep = pet[step_index]

    flux_pn = P - Ep if P > Ep else 0.0
    flux_en = Ep - P if Ep > P else 0.0
    flux_ef = P - flux_pn

    flux_ps = saturation_4(S1, x1, flux_pn)
    flux_es = evap_11(S1, x1, flux_en)
    flux_perc = percolation_3(S1, x1)
    flux_q9 = route_uh_current_nb(q9_pending) / delta_t
    flux_q1 = route_uh_current_nb(q1_pending) / delta_t

    flux_fr = exchange_4(S2, x3, x2)
    flux_fq = flux_fr
    flux_qr = baseflow_3(S2, x3)

    quick_component = flux_q1 + flux_fq
    quick_positive = quick_component if quick_component > 0.0 else 0.0
    flux_qt = flux_qr + quick_positive
    flux_ex = flux_fr + quick_positive - flux_q1

    out_dS[0] = flux_ps - flux_es - flux_perc
    out_dS[1] = flux_q9 + flux_fr - flux_qr

    out_fluxes[0] = flux_pn
    out_fluxes[1] = flux_en
    out_fluxes[2] = flux_ef
    out_fluxes[3] = flux_ps
    out_fluxes[4] = flux_es
    out_fluxes[5] = flux_perc
    out_fluxes[6] = flux_q9
    out_fluxes[7] = flux_q1
    out_fluxes[8] = flux_fr
    out_fluxes[9] = flux_fq
    out_fluxes[10] = flux_qr
    out_fluxes[11] = flux_qt
    out_fluxes[12] = flux_ex


@optional_njit(cache=True)
def _gr4j_clip_state_inplace_nb(
    states: FloatArray,
    store_min: FloatArray,
    store_max: FloatArray,
) -> None:
    for state_index in range(states.shape[0]):
        if states[state_index] < store_min[state_index]:
            states[state_index] = store_min[state_index]
        elif states[state_index] > store_max[state_index]:
            states[state_index] = store_max[state_index]


@optional_njit(cache=True)
def _gr4j_fill_residual_nb(
    states: FloatArray,
    previous_states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    q9_pending: FloatArray,
    q1_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
    out_residual: FloatArray,
) -> None:
    _gr4j_compute_step_nb(
        states,
        step_index,
        theta,
        delta_t,
        precip,
        pet,
        temp,
        q9_pending,
        q1_pending,
        out_dS,
        out_fluxes,
    )

    for state_index in range(states.shape[0]):
        out_residual[state_index] = (
            states[state_index] - previous_states[state_index]
        ) / delta_t - out_dS[state_index]


@optional_njit(cache=True)
def run_gr4j_heun_full(
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    s0: FloatArray,
    store_min: FloatArray,
    store_max: FloatArray,
    q9_weights: FloatArray,
    q9_pending: FloatArray,
    q1_weights: FloatArray,
    q1_pending: FloatArray,
) -> tuple[
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
]:
    n_steps = precip.shape[0]
    n_stores = s0.shape[0]

    stores = np.empty((n_steps, n_stores), dtype=np.float64)
    fluxes = np.empty((n_steps, 13), dtype=np.float64)
    residual_norms = np.zeros(n_steps, dtype=np.float64)
    iterations = np.ones(n_steps, dtype=np.int64)
    nfev = np.full(n_steps, 3, dtype=np.int64)
    njev = np.zeros(n_steps, dtype=np.int64)

    current_states = s0.copy()
    predicted_states = np.empty(n_stores, dtype=np.float64)
    k1 = np.empty(n_stores, dtype=np.float64)
    k2 = np.empty(n_stores, dtype=np.float64)
    accepted_dS = np.empty(n_stores, dtype=np.float64)
    flux_1 = np.empty(13, dtype=np.float64)
    flux_2 = np.empty(13, dtype=np.float64)

    for step_index in range(n_steps):
        _gr4j_compute_step_nb(
            current_states,
            step_index,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            q9_pending,
            q1_pending,
            k1,
            flux_1,
        )

        for state_index in range(n_stores):
            predicted_states[state_index] = (
                current_states[state_index] + delta_t * k1[state_index]
            )
        _gr4j_clip_state_inplace_nb(predicted_states, store_min, store_max)

        _gr4j_compute_step_nb(
            predicted_states,
            step_index,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            q9_pending,
            q1_pending,
            k2,
            flux_2,
        )

        for state_index in range(n_stores):
            current_states[state_index] = current_states[
                state_index
            ] + 0.5 * delta_t * (k1[state_index] + k2[state_index])
        _gr4j_clip_state_inplace_nb(current_states, store_min, store_max)

        _gr4j_compute_step_nb(
            current_states,
            step_index,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            q9_pending,
            q1_pending,
            accepted_dS,
            fluxes[step_index],
        )

        for state_index in range(n_stores):
            stores[step_index, state_index] = current_states[state_index]

        inflow_volume = (
            fluxes[step_index, 0] - fluxes[step_index, 3] + fluxes[step_index, 5]
        )
        update_uh_inplace_nb(q9_weights, q9_pending, 0.9 * inflow_volume)
        update_uh_inplace_nb(q1_weights, q1_pending, 0.1 * inflow_volume)

    return stores, fluxes, residual_norms, iterations, nfev, njev


@optional_njit(cache=True)
def run_gr4j_numba_newton_full(
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    s0: FloatArray,
    store_min: FloatArray,
    store_max: FloatArray,
    q9_weights: FloatArray,
    q9_pending: FloatArray,
    q1_weights: FloatArray,
    q1_pending: FloatArray,
    jacobian_pattern: FloatArray,
    tol: float,
    max_iter: int,
    diff_step: float,
    damping: float,
) -> tuple[
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
    FloatArray,
]:
    n_steps = precip.shape[0]
    n_stores = s0.shape[0]

    stores = np.empty((n_steps, n_stores), dtype=np.float64)
    fluxes = np.empty((n_steps, 13), dtype=np.float64)
    residual_norms = np.empty(n_steps, dtype=np.float64)
    iterations = np.empty(n_steps, dtype=np.int64)
    nfev = np.empty(n_steps, dtype=np.int64)
    njev = np.empty(n_steps, dtype=np.int64)

    previous_states = np.empty(n_stores, dtype=np.float64)
    trial_states = np.empty(n_stores, dtype=np.float64)
    perturbed_states = np.empty(n_stores, dtype=np.float64)
    accepted_dS = np.empty(n_stores, dtype=np.float64)
    trial_dS = np.empty(n_stores, dtype=np.float64)
    accepted_fluxes = np.empty(13, dtype=np.float64)
    trial_fluxes = np.empty(13, dtype=np.float64)
    residual = np.empty(n_stores, dtype=np.float64)
    trial_residual = np.empty(n_stores, dtype=np.float64)
    jacobian = np.empty((n_stores, n_stores), dtype=np.float64)
    delta = np.empty(n_stores, dtype=np.float64)
    rhs = np.empty(n_stores, dtype=np.float64)

    current_states = s0.copy()

    for step_index in range(n_steps):
        for state_index in range(n_stores):
            previous_states[state_index] = current_states[state_index]
            trial_states[state_index] = current_states[state_index]

        step_nfev = 0
        step_njev = 0
        step_iterations = 0
        residual_norm = 0.0
        max_delta = tol + 1.0

        for iteration in range(max_iter):
            step_iterations = iteration + 1
            _gr4j_fill_residual_nb(
                trial_states,
                previous_states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                q9_pending,
                q1_pending,
                accepted_dS,
                accepted_fluxes,
                residual,
            )
            step_nfev += 1

            residual_norm = 0.0
            for row_index in range(n_stores):
                residual_norm += residual[row_index] * residual[row_index]
            residual_norm = residual_norm**0.5
            if residual_norm <= tol:
                max_delta = 0.0
                break

            for row_index in range(n_stores):
                for col_index in range(n_stores):
                    jacobian[row_index, col_index] = 0.0

            for col_index in range(n_stores):
                active_column = False
                for row_index in range(n_stores):
                    if jacobian_pattern[row_index, col_index] != 0:
                        active_column = True
                        break
                if not active_column:
                    continue

                for row_index in range(n_stores):
                    perturbed_states[row_index] = trial_states[row_index]

                reference = trial_states[col_index]
                step = diff_step * abs(reference)
                if step < diff_step:
                    step = diff_step
                perturbed_states[col_index] = reference + step
                _gr4j_clip_state_inplace_nb(perturbed_states, store_min, store_max)
                effective_step = perturbed_states[col_index] - reference
                if effective_step == 0.0:
                    effective_step = step

                _gr4j_fill_residual_nb(
                    perturbed_states,
                    previous_states,
                    step_index,
                    theta,
                    delta_t,
                    precip,
                    pet,
                    temp,
                    q9_pending,
                    q1_pending,
                    trial_dS,
                    trial_fluxes,
                    trial_residual,
                )
                step_nfev += 1

                for row_index in range(n_stores):
                    if jacobian_pattern[row_index, col_index] != 0:
                        jacobian[row_index, col_index] = (
                            trial_residual[row_index] - residual[row_index]
                        ) / effective_step

            step_njev += 1

            for row_index in range(n_stores):
                rhs[row_index] = -residual[row_index]
                jacobian[row_index, row_index] = jacobian[row_index, row_index] + 1e-12

            delta = np.linalg.solve(jacobian, rhs)
            max_delta = 0.0
            for row_index in range(n_stores):
                delta_value = damping * delta[row_index]
                trial_states[row_index] = trial_states[row_index] + delta_value
                if abs(delta_value) > max_delta:
                    max_delta = abs(delta_value)

            _gr4j_clip_state_inplace_nb(trial_states, store_min, store_max)
            if max_delta <= tol:
                break

        _gr4j_fill_residual_nb(
            trial_states,
            previous_states,
            step_index,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            q9_pending,
            q1_pending,
            accepted_dS,
            accepted_fluxes,
            residual,
        )
        step_nfev += 1

        residual_norm = 0.0
        for row_index in range(n_stores):
            residual_norm += residual[row_index] * residual[row_index]
        residual_norms[step_index] = residual_norm**0.5
        iterations[step_index] = step_iterations
        nfev[step_index] = step_nfev
        njev[step_index] = step_njev

        for state_index in range(n_stores):
            current_states[state_index] = trial_states[state_index]
            stores[step_index, state_index] = trial_states[state_index]
        for flux_index in range(13):
            fluxes[step_index, flux_index] = accepted_fluxes[flux_index]

        inflow_volume = accepted_fluxes[0] - accepted_fluxes[3] + accepted_fluxes[5]
        update_uh_inplace_nb(q9_weights, q9_pending, 0.9 * inflow_volume)
        update_uh_inplace_nb(q1_weights, q1_pending, 0.1 * inflow_volume)

    return stores, fluxes, residual_norms, iterations, nfev, njev


@optional_njit(cache=True)
def run_gr4j_numba_full(
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    s0: FloatArray,
    store_min: FloatArray,
    store_max: FloatArray,
    q9_weights: FloatArray,
    q9_pending: FloatArray,
    q1_weights: FloatArray,
    q1_pending: FloatArray,
) -> tuple[FloatArray, FloatArray]:
    n_steps = precip.shape[0]
    n_stores = s0.shape[0]

    stores = np.empty((n_steps, n_stores), dtype=np.float64)
    fluxes = np.empty((n_steps, 13), dtype=np.float64)
    dS = np.empty(n_stores, dtype=np.float64)
    current_states = s0.copy()

    for step_index in range(n_steps):
        _gr4j_compute_step_nb(
            current_states,
            step_index,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            q9_pending,
            q1_pending,
            dS,
            fluxes[step_index],
        )

        for state_index in range(n_stores):
            next_state = current_states[state_index] + dS[state_index] * delta_t
            if next_state < store_min[state_index]:
                next_state = store_min[state_index]
            elif next_state > store_max[state_index]:
                next_state = store_max[state_index]
            stores[step_index, state_index] = next_state
            current_states[state_index] = next_state

        inflow_volume = (
            fluxes[step_index, 0] - fluxes[step_index, 3] + fluxes[step_index, 5]
        )
        update_uh_inplace_nb(q9_weights, q9_pending, 0.9 * inflow_volume)
        update_uh_inplace_nb(q1_weights, q1_pending, 0.1 * inflow_volume)

    return stores, fluxes


class gr4j(HydrologyModel):
    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 13
        self.num_params = 4
        self.jacob_pattern = np.array([[1, 1], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [-20, 20], [1, 300], [0.5, 15]], dtype=np.float64
        )
        self.store_names = ["S1", "S2"]
        self.flux_names = [
            "pn",
            "en",
            "ef",
            "ps",
            "es",
            "perc",
            "q9",
            "q1",
            "fr",
            "fq",
            "qr",
            "qt",
            "ex",
        ]
        self.flux_groups = {"Ea": [3, 5], "Q": [12], "Exchange": -13}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        x1 = float(theta[0])
        x3 = float(theta[2])
        x4 = float(theta[3])
        self.store_max = np.array([x1, x3], dtype=np.float64)

        q9_weights = _make_gr4j_uh1(x4, float(self.delta_t))
        q1_weights = _make_gr4j_uh2(x4, float(self.delta_t))
        routing_state = GR4JRoutingState(
            q9_weights=q9_weights,
            q9_pending=np.zeros_like(q9_weights),
            q1_weights=q1_weights,
            q1_pending=np.zeros_like(q1_weights),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = self._require_routing_state(runtime)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        q9_weights = routing.q9_weights
        q9_pending = routing.q9_pending
        q1_weights = routing.q1_weights
        q1_pending = routing.q1_pending

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                q9_weights,
                q9_pending,
                q1_weights,
                q1_pending,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_states: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_states is None:
            out_states = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        kernel = (
            self.compiler.compiled_model_fun
            if self.compiler.enabled
            else self._python_model_fun
        )
        if runtime is self.runtime_context and kernel is not None:
            kernel(state_vector, resolved_step, out_states, out_fluxes)
            return out_states, out_fluxes

        routing = self._require_routing_state(runtime)
        _gr4j_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            routing.q9_weights,
            routing.q9_pending,
            routing.q1_weights,
            routing.q1_pending,
            out_states,
            out_fluxes,
        )
        return out_states, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        return self._bind_kernel(_gr4j_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        compiled_step = self._get_or_compile_numba_step_function(
            python_step_function=_gr4j_compute_step,
            numba_step_function=_gr4j_compute_step_numba,
        )
        kernel = self._bind_kernel(compiled_step, runtime)
        self._warm_bound_kernel(runtime, kernel)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        _, fluxes = self._compute_into(state_vector, step_index=self.t)
        dS = _gr4j_fluxes_to_dS(fluxes)
        return dS, fluxes

    def compute_dS(
        self,
        s: np.ndarray,
        forcing: np.ndarray,
        params: np.ndarray,
    ) -> np.ndarray:
        del forcing, params
        dS, _ = self.model_fun(np.asarray(s, dtype=np.float64).reshape(-1))
        return dS

    def residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        return self._finite_difference_residual_jacobian(
            states,
            previous_states,
            step_index,
            diff_step=diff_step,
            compute_dS=lambda trial, index, runtime: _gr4j_fluxes_to_dS(
                self.evaluate_fluxes(
                    trial,
                    step_index=index,
                    ctx=runtime,
                )
            ),
        )

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        raise NotImplementedError(
            "gr4j does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        raise NotImplementedError(
            "gr4j does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def step(self) -> None:
        routing = self._require_routing_state(self.runtime_context)
        fluxes = self.fluxes[self.t, :]
        # Commit UH inflow only after the accepted step; do not mutate routing in model_fun().
        inflow_volume = float(fluxes[0] - fluxes[3] + fluxes[5])
        update_uh_inplace(routing.q9_weights, routing.q9_pending, 0.9 * inflow_volume)
        update_uh_inplace(routing.q1_weights, routing.q1_pending, 0.1 * inflow_volume)
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()

    def _should_use_numba_full(self) -> bool:
        return bool(NUMBA_AVAILABLE and self.compiler.requested_target != "python")

    def _apply_solver_outputs(
        self,
        runtime: RuntimeContext,
        routing: GR4JRoutingState,
        stores: FloatArray,
        fluxes: FloatArray,
        solver_name: str,
        resnorm: FloatArray,
        iterations: FloatArray,
        nfev: FloatArray,
        njev: FloatArray,
        q9_pending: FloatArray,
        q1_pending: FloatArray,
    ) -> None:
        runtime.stores[:, :] = stores
        runtime.fluxes[:, :] = fluxes * float(runtime.delta_t)
        runtime.routing_state = routing

        self.stores = runtime.stores
        self.fluxes = runtime.fluxes
        routing.q9_pending[:] = q9_pending
        routing.q1_pending[:] = q1_pending
        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()
        self.t = int(runtime.precip.shape[0]) - 1
        self.status = 1

        n_steps = int(runtime.precip.shape[0])
        self.solver_data = {
            "solver": np.full(n_steps, solver_name, dtype=object),
            "resnorm": np.asarray(resnorm, dtype=np.float64),
            "iterations": np.asarray(iterations, dtype=np.int64),
            "nfev": np.asarray(nfev, dtype=np.int64),
            "njev": np.asarray(njev, dtype=np.int64),
        }

    def _run_numba_discrete(self, runtime: RuntimeContext) -> None:
        routing = self._require_routing_state(runtime)

        q9_pending = np.ascontiguousarray(routing.q9_pending.copy(), dtype=np.float64)
        q1_pending = np.ascontiguousarray(routing.q1_pending.copy(), dtype=np.float64)

        stores, fluxes = run_gr4j_numba_full(
            np.asarray(runtime.theta, dtype=np.float64),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
            np.asarray(runtime.S0, dtype=np.float64),
            np.asarray(runtime.store_min, dtype=np.float64),
            np.asarray(runtime.store_max, dtype=np.float64),
            np.asarray(routing.q9_weights, dtype=np.float64),
            q9_pending,
            np.asarray(routing.q1_weights, dtype=np.float64),
            q1_pending,
        )
        n_steps = int(runtime.precip.shape[0])
        self._apply_solver_outputs(
            runtime,
            routing,
            stores,
            fluxes,
            "numba_full",
            np.zeros(n_steps, dtype=np.float64),
            np.ones(n_steps, dtype=np.int64),
            np.ones(n_steps, dtype=np.int64),
            np.zeros(n_steps, dtype=np.int64),
            q9_pending,
            q1_pending,
        )

    def _run_numba_heun(self, runtime: RuntimeContext) -> None:
        routing = self._require_routing_state(runtime)
        q9_pending = np.ascontiguousarray(routing.q9_pending.copy(), dtype=np.float64)
        q1_pending = np.ascontiguousarray(routing.q1_pending.copy(), dtype=np.float64)

        stores, fluxes, resnorm, iterations, nfev, njev = run_gr4j_heun_full(
            np.asarray(runtime.theta, dtype=np.float64),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
            np.asarray(runtime.S0, dtype=np.float64),
            np.asarray(runtime.store_min, dtype=np.float64),
            np.asarray(runtime.store_max, dtype=np.float64),
            np.asarray(routing.q9_weights, dtype=np.float64),
            q9_pending,
            np.asarray(routing.q1_weights, dtype=np.float64),
            q1_pending,
        )

        self._apply_solver_outputs(
            runtime,
            routing,
            stores,
            fluxes,
            "heun",
            resnorm,
            iterations,
            nfev,
            njev,
            q9_pending,
            q1_pending,
        )

    def _run_numba_newton(self, runtime: RuntimeContext) -> None:
        routing = self._require_routing_state(runtime)
        q9_pending = np.ascontiguousarray(routing.q9_pending.copy(), dtype=np.float64)
        q1_pending = np.ascontiguousarray(routing.q1_pending.copy(), dtype=np.float64)

        stores, fluxes, resnorm, iterations, nfev, njev = run_gr4j_numba_newton_full(
            np.asarray(runtime.theta, dtype=np.float64),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
            np.asarray(runtime.S0, dtype=np.float64),
            np.asarray(runtime.store_min, dtype=np.float64),
            np.asarray(runtime.store_max, dtype=np.float64),
            np.asarray(routing.q9_weights, dtype=np.float64),
            q9_pending,
            np.asarray(routing.q1_weights, dtype=np.float64),
            q1_pending,
            np.asarray(self.jacob_pattern, dtype=np.int64),
            float(self.solver_opts.get("resnorm_tolerance", 1e-8)),
            int(self.solver_opts.get("resnorm_maxiter", 50)),
            float(self.solver_opts.get("diff_step", 1e-6)),
            float(self.solver_opts.get("damping", 0.8)),
        )

        self._apply_solver_outputs(
            runtime,
            routing,
            stores,
            fluxes,
            "numba_newton",
            resnorm,
            iterations,
            nfev,
            njev,
            q9_pending,
            q1_pending,
        )

    def _run_python_iterative_solver(
        self,
        runtime: RuntimeContext,
        *,
        solver: str,
    ) -> None:
        n_steps = int(runtime.precip.shape[0])
        solver_name = np.full(n_steps, solver, dtype=object)
        resnorm = np.zeros(n_steps, dtype=np.float64)
        iteration_count = np.zeros(n_steps, dtype=np.int64)
        nfev = np.zeros(n_steps, dtype=np.int64)
        njev = np.zeros(n_steps, dtype=np.int64)

        for step_index in range(n_steps):
            self.t = step_index
            previous = runtime.S0 if step_index == 0 else self.stores[step_index - 1, :]

            if solver == "scipy_fsolve":
                state, fluxes, rnorm, eval_count, jac_count = self._fsolve_step(
                    previous,
                    step_index,
                )
                iters = max(
                    1,
                    min(eval_count, int(self.solver_opts.get("resnorm_maxiter", 50))),
                )
            elif solver == "heun":
                state, fluxes, rnorm, iters, jac_count = HydrologyModel._heun_step(
                    self,
                    previous,
                    step_index,
                )
                eval_count = 3
            else:
                raise ValueError("unsupported gr4j iterative solver")

            self.stores[step_index, :] = state
            self.fluxes[step_index, :] = fluxes * float(runtime.delta_t)
            runtime.stores = self.stores
            runtime.fluxes = self.fluxes

            resnorm[step_index] = float(rnorm)
            iteration_count[step_index] = int(iters)
            nfev[step_index] = int(eval_count)
            njev[step_index] = int(jac_count)

            self.step()
            runtime.routing_state = self.routing_state

        self.status = 1
        self.solver_data = {
            "solver": solver_name,
            "resnorm": resnorm,
            "iterations": iteration_count,
            "nfev": nfev,
            "njev": njev,
        }

    def run(
        self,
        *,
        config: Any | None = None,
        theta: Any | None = None,
        delta_t: float | None = None,
        S0: Any | None = None,
        input_climate: Any | None = None,
        solver_opts: Any | None = None,
        compile_target: str | None = None,
        solver: str = "fsolve",
    ) -> "gr4j":
        if solver == "fsolve":
            return super().run(
                config=config,
                theta=theta,
                delta_t=delta_t,
                S0=S0,
                input_climate=input_climate,
                solver_opts=solver_opts,
                compile_target=compile_target,
                solver=solver,
            )

        if (
            config is not None
            or theta is not None
            or delta_t is not None
            or S0 is not None
            or input_climate is not None
        ):
            self.configure(
                config=config,
                theta=theta,
                delta_t=delta_t,
                S0=S0,
                input_climate=input_climate,
                solver_opts=solver_opts,
                compile_target=compile_target,
            )

        runtime = self.runtime_context
        if (
            runtime is None
            or self.stores is None
            or self.fluxes is None
            or self.S0 is None
        ):
            raise RuntimeError("model is not configured")

        if solver == "default":
            if not self._should_use_numba_full():
                return super().run(solver="fsolve")

            try:
                self._run_numba_discrete(runtime)
            except Exception as exc:
                warnings.warn(
                    f"gr4j Numba full loop failed ({exc}); falling back to fsolve.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                return super().run(solver="fsolve")

            return self

        if solver == "scipy_fsolve":
            self._run_python_iterative_solver(runtime, solver="scipy_fsolve")
            return self

        if solver == "heun":
            if self._should_use_numba_full():
                try:
                    self._run_numba_heun(runtime)
                    return self
                except Exception as exc:
                    warnings.warn(
                        f"gr4j Numba Heun failed ({exc}); falling back to Python Heun.",
                        RuntimeWarning,
                        stacklevel=2,
                    )

            self._run_python_iterative_solver(runtime, solver="heun")
            return self

        if solver == "numba_newton":
            if self._should_use_numba_full():
                try:
                    self._run_numba_newton(runtime)
                    return self
                except Exception as exc:
                    warnings.warn(
                        f"gr4j Numba Newton failed ({exc}); falling back to scipy_fsolve.",
                        RuntimeWarning,
                        stacklevel=2,
                    )

            self._run_python_iterative_solver(runtime, solver="scipy_fsolve")
            return self

        raise ValueError(
            "gr4j solver must be one of: fsolve, scipy_fsolve, numba_newton, heun, default"
        )

    def _uses_discrete_step_solver(self) -> bool:
        return True

    def _advance_discrete_step(
        self,
        previous_states: FloatArray,
        step_index: int,
        out_states: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        kernel = (
            self.compiler.compiled_model_fun
            if self.compiler.enabled
            else self._python_model_fun
        )
        if kernel is None:
            raise RuntimeError("gr4j routing kernel is not initialised")
        kernel(
            np.asarray(previous_states, dtype=np.float64),
            step_index,
            out_states,
            out_fluxes,
        )

    def _require_routing_state(
        self,
        runtime: RuntimeContext | None,
    ) -> GR4JRoutingState:
        routing = runtime.routing_state if runtime is not None else self.routing_state
        if isinstance(routing, GR4JRoutingState):
            return routing

        self.init()
        if isinstance(self.routing_state, GR4JRoutingState):
            return self.routing_state
        raise RuntimeError("gr4j routing state is not initialised")
