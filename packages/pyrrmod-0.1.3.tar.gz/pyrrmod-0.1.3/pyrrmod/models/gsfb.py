from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    baseflow_9,
    evap_20,
    interflow_11,
    recharge_5,
    saturation_1,
)
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _gsfb_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    c = float(theta[0])
    ndc = float(theta[1])
    smax = float(theta[2])
    emax = float(theta[3])
    frate = float(theta[4])
    b = float(theta[5])
    dpf = float(theta[6])
    sdrmax = float(theta[7])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    threshold = ndc * smax
    flux_ea = evap_20(emax, ndc, S1, smax, Ep, delta_t)
    flux_qs = saturation_1(P, S1, smax)
    flux_f = interflow_11(frate, threshold, S1, delta_t)
    flux_qb = baseflow_9(b * dpf, sdrmax, S2)
    flux_dp = baseflow_1((1.0 - b) * dpf, S2)
    flux_qdr = recharge_5(c, threshold, S3, S1)

    out_dS[0] = P + flux_qdr - flux_ea - flux_qs - flux_f
    out_dS[1] = flux_f - flux_qb - flux_dp
    out_dS[2] = flux_dp - flux_qdr

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_qs
    out_fluxes[2] = flux_f
    out_fluxes[3] = flux_qb
    out_fluxes[4] = flux_dp
    out_fluxes[5] = flux_qdr


class gsfb(StepKernelModel):
    python_step_function = staticmethod(_gsfb_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 6
        self.num_params = 8
        self.jacob_pattern = np.array([[1, 0, 1], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [0, 1],
                [0.05, 0.95],
                [1, 2000],
                [0, 20],
                [0, 200],
                [0, 1],
                [0, 1],
                [1, 300],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["ea", "qs", "f", "qb", "dp", "qdr"]
        self.flux_groups = {"Ea": 1, "Q": [2, 4]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
