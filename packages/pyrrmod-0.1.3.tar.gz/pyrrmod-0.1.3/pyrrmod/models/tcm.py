from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    abstraction_1,
    baseflow_1,
    baseflow_6,
    effective_1,
    evap_1,
    evap_16,
    saturation_1,
    saturation_9,
    split_1,
)
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _tcm_prepare_theta(theta: FloatArray, precip: FloatArray) -> FloatArray:
    prepared = np.empty(theta.size + 1, dtype=np.float64)
    prepared[: theta.size] = theta
    prepared[theta.size] = float(theta[4]) * float(np.mean(precip))
    return prepared


def _tcm_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    phi = float(theta[0])
    rc = float(theta[1])
    gam = float(theta[2])
    k1 = float(theta[3])
    k2 = float(theta[5])
    ca = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pn = effective_1(P, Ep)
    flux_en = P - flux_pn
    flux_pby = split_1(phi, flux_pn)
    flux_pin = split_1(1.0 - phi, flux_pn)
    flux_ea = evap_1(S1, Ep, delta_t)
    flux_et = evap_16(gam, np.inf, S1, 0.01, Ep, delta_t)
    flux_qex1 = saturation_1(flux_pin, S1, rc)
    flux_qex2 = saturation_9(flux_qex1, S2, 0.01)
    flux_quz = baseflow_1(k1, S3)
    flux_a = abstraction_1(ca)
    flux_q = baseflow_6(k2, 0, S4, delta_t)

    out_dS[0] = flux_pin - flux_ea - flux_qex1
    out_dS[1] = flux_et + flux_qex2 - flux_qex1
    out_dS[2] = flux_qex2 + flux_pby - flux_quz
    out_dS[3] = flux_quz - flux_a - flux_q

    out_fluxes[0] = flux_pn
    out_fluxes[1] = flux_en
    out_fluxes[2] = flux_pby
    out_fluxes[3] = flux_pin
    out_fluxes[4] = flux_ea
    out_fluxes[5] = flux_et
    out_fluxes[6] = flux_qex1
    out_fluxes[7] = flux_qex2
    out_fluxes[8] = flux_quz
    out_fluxes[9] = flux_a
    out_fluxes[10] = flux_q


class tcm(StepKernelModel):
    python_step_function = staticmethod(_tcm_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 11
        self.num_params = 6
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [1, 1, 1, 0], [0, 0, 1, 1]], dtype=int
        )
        self.par_ranges = np.array(
            [[0, 1], [1, 2000], [0, 1], [0, 1], [0, 1], [0, 1]], dtype=np.float64
        )
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = [
            "pn",
            "en",
            "pby",
            "pin",
            "ea",
            "et",
            "qex1",
            "qex2",
            "quz",
            "a",
            "q",
        ]
        self.flux_groups = {"Ea": [2, 5, 6], "Q": 11, "Abstraction": 10}
        self.StoreSigns = np.array([1.0, -1.0, 1.0, 1.0], dtype=np.float64)

    def init(self) -> None:
        pass

    def _get_kernel_bind_args(
        self,
        runtime: RuntimeContext,
    ) -> tuple[FloatArray, float, FloatArray, FloatArray, FloatArray]:
        return (
            _tcm_prepare_theta(
                np.asarray(runtime.theta, dtype=np.float64),
                runtime.precip,
            ),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
        )

    def step(self) -> None:
        pass
