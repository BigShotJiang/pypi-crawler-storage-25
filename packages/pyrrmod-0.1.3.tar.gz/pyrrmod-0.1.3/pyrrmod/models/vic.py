from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_5,
    effective_1,
    evap_7,
    excess_1,
    interception_1,
    percolation_5,
    phenology_2,
    saturation_1,
    saturation_2,
)
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _vic_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    ibar = float(theta[0])
    idelta = float(theta[1])
    ishift = float(theta[2])
    stot = float(theta[3])
    fsm = float(theta[4])
    b = float(theta[5])
    k1 = float(theta[6])
    c1 = float(theta[7])
    k2 = float(theta[8])
    c2 = float(theta[9])

    smmax = fsm * stot
    gwmax = (1.0 - fsm) * stot
    tmax = 365.25

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    aux_imax = phenology_2(ibar, idelta, ishift, step_index + 1, tmax, delta_t)
    flux_ei = evap_7(S1, aux_imax, Ep, delta_t)
    flux_peff = interception_1(P, S1, aux_imax)
    flux_iex = excess_1(S1, aux_imax, delta_t)
    flux_qie = saturation_2(S2, smmax, b, flux_peff + flux_iex)
    flux_inf = effective_1(flux_peff + flux_iex, flux_qie)
    flux_et1 = evap_7(S2, smmax, max(0.0, Ep - flux_ei), delta_t)
    flux_qex1 = saturation_1(flux_inf, S2, smmax)
    flux_pc = percolation_5(k1, c1, S2, smmax, delta_t)
    flux_et2 = evap_7(S3, gwmax, max(0.0, Ep - flux_ei - flux_et1), delta_t)
    flux_qex2 = saturation_1(flux_pc, S3, gwmax)
    flux_qb = baseflow_5(k2, c2, S3, gwmax, delta_t)

    out_dS[0] = P - flux_ei - flux_peff - flux_iex
    out_dS[1] = flux_inf - flux_et1 - flux_qex1 - flux_pc
    out_dS[2] = flux_pc - flux_et2 - flux_qex2 - flux_qb

    out_fluxes[0] = flux_ei
    out_fluxes[1] = flux_peff
    out_fluxes[2] = flux_iex
    out_fluxes[3] = flux_qie
    out_fluxes[4] = flux_inf
    out_fluxes[5] = flux_et1
    out_fluxes[6] = flux_qex1
    out_fluxes[7] = flux_pc
    out_fluxes[8] = flux_et2
    out_fluxes[9] = flux_qex2
    out_fluxes[10] = flux_qb


class vic(StepKernelModel):
    python_step_function = staticmethod(_vic_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 11
        self.num_params = 10
        self.jacob_pattern = np.array([[1, 0, 0], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [0.1, 5],
                [0, 1],
                [1, 365],
                [1, 2000],
                [0.01, 0.99],
                [0, 10],
                [0, 1],
                [0, 10],
                [0, 1],
                [1, 5],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = [
            "ei",
            "peff",
            "iex",
            "qie",
            "inf",
            "et1",
            "qex1",
            "pc",
            "et2",
            "qex2",
            "qb",
        ]
        self.flux_groups = {"Ea": [1, 6, 9], "Q": [4, 7, 10, 11]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
