from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import baseflow_1, evap_5, evap_6, interflow_9, saturation_1
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _newzealand1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    s1max = float(theta[0])
    sfc = float(theta[1])
    m = float(theta[2])
    a = float(theta[3])
    b = float(theta[4])
    tcbf = float(theta[5])

    S1 = float(states[0])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_veg = evap_6(m, sfc, S1, s1max, Ep, delta_t)
    flux_ebs = evap_5(m, S1, s1max, Ep, delta_t)
    flux_qse = saturation_1(P, S1, s1max)
    flux_qss = interflow_9(S1, a, sfc * s1max, b, delta_t)
    flux_qbf = baseflow_1(tcbf, S1)

    out_dS[0] = P - flux_veg - flux_ebs - flux_qse - flux_qss - flux_qbf

    out_fluxes[0] = flux_veg
    out_fluxes[1] = flux_ebs
    out_fluxes[2] = flux_qse
    out_fluxes[3] = flux_qss
    out_fluxes[4] = flux_qbf


class newzealand1(StepKernelModel):
    python_step_function = staticmethod(_newzealand1_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 1
        self.num_fluxes = 5
        self.num_params = 6
        self.jacob_pattern = np.array([1], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0.05, 0.95], [0.05, 0.95], [0, 1], [1, 5], [0, 1]],
            dtype=np.float64,
        )
        self.store_names = ["S1"]
        self.flux_names = ["veg", "ebs", "qse", "qss", "qbf"]
        self.flux_groups = {"Ea": [1, 2], "Q": [3, 4, 5]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
