from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    depression_1,
    evap_1,
    evap_2,
    exchange_1,
    exchange_3,
    infiltration_1,
    infiltration_2,
    interception_1,
    interflow_1,
    recharge_1,
    saturation_1,
)
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _modhydrolog_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    insc = float(theta[0])
    coeff = float(theta[1])
    sq = float(theta[2])
    smsc = float(theta[3])
    sub = float(theta[4])
    crak = float(theta[5])
    em = float(theta[6])
    dsc = float(theta[7])
    ads = float(theta[8])
    md = float(theta[9])
    vcond = float(theta[10])
    dlev = float(theta[11])
    k1 = float(theta[12])
    k2 = float(theta[13])
    k3 = float(theta[14])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_Ei = evap_1(S1, Ep, delta_t)
    flux_EXC = interception_1(P, S1, insc)
    flux_INF = infiltration_1(coeff, sq, S2, smsc, flux_EXC)
    flux_INT = interflow_1(sub, S2, smsc, flux_INF)
    flux_REC = recharge_1(crak, S2, smsc, flux_INF - flux_INT)
    flux_SMF = flux_INF - flux_INT - flux_REC
    flux_Et = evap_2(em, S2, smsc, Ep, delta_t)
    flux_GWF = saturation_1(flux_SMF, S2, smsc)
    flux_RUN = flux_EXC - flux_INF
    flux_TRAP = depression_1(ads, md, S3, dsc, flux_RUN, delta_t)
    flux_Ed = evap_1(S3, ads * Ep, delta_t)
    flux_DINF = ads * infiltration_2(coeff, sq, S2, smsc, flux_SMF, S3, delta_t)
    flux_SEEP = exchange_3(vcond, S4, dlev)
    flux_SRUN = flux_RUN - flux_TRAP
    flux_FLOW = exchange_1(k1, k2, k3, S4, flux_SRUN, delta_t)
    flux_Q = baseflow_1(1, S5)

    out_dS[0] = P - flux_Ei - flux_EXC
    out_dS[1] = flux_SMF + flux_DINF - flux_Et - flux_GWF
    out_dS[2] = flux_TRAP - flux_Ed - flux_DINF
    out_dS[3] = flux_REC + flux_GWF - flux_SEEP - flux_FLOW
    out_dS[4] = flux_SRUN + flux_INT + flux_FLOW - flux_Q

    out_fluxes[0] = flux_Ei
    out_fluxes[1] = flux_EXC
    out_fluxes[2] = flux_INF
    out_fluxes[3] = flux_INT
    out_fluxes[4] = flux_REC
    out_fluxes[5] = flux_SMF
    out_fluxes[6] = flux_Et
    out_fluxes[7] = flux_GWF
    out_fluxes[8] = flux_TRAP
    out_fluxes[9] = flux_Ed
    out_fluxes[10] = flux_DINF
    out_fluxes[11] = flux_SEEP
    out_fluxes[12] = flux_FLOW
    out_fluxes[13] = flux_Q
    out_fluxes[14] = flux_RUN
    out_fluxes[15] = flux_SRUN


class modhydrolog(StepKernelModel):
    python_step_function = staticmethod(_modhydrolog_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 5
        self.num_fluxes = 16
        self.num_params = 15
        self.jacob_pattern = np.array(
            [
                [1, 0, 0, 0, 0],
                [1, 1, 0, 0, 0],
                [1, 1, 1, 0, 0],
                [1, 1, 1, 1, 0],
                [1, 1, 1, 1, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [
                [0, 5],
                [0, 600],
                [0, 15],
                [1, 2000],
                [0, 1],
                [0, 1],
                [0, 20],
                [0, 50],
                [0, 1],
                [0.99, 1],
                [0, 0.5],
                [-10, 10],
                [0, 1],
                [0, 1],
                [0, 100],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4", "S5"]
        self.flux_names = [
            "Ei",
            "EXC",
            "INF",
            "INT",
            "REC",
            "SMF",
            "Et",
            "GWF",
            "TRAP",
            "Ed",
            "DINF",
            "SEEP",
            "FLOW",
            "Q",
            "RUN",
            "SRUN",
        ]
        self.flux_groups = {"Ea": [1, 7, 10], "Q": [14], "GWseepage": 12}

    def init(self) -> None:
        self.store_min[3] = -np.inf


    def step(self) -> None:
        pass
