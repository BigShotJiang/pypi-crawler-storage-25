from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import evap_7, excess_1, interflow_3, recharge_3, saturation_1
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _australia_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    sb = float(theta[0])
    phi = float(theta[1])
    fc = float(theta[2])
    alpha_ss = float(theta[3])
    beta_ss = float(theta[4])
    k_deep = float(theta[5])
    alpha_bf = float(theta[6])
    beta_bf = float(theta[7])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    soil_capacity = (sb - S2) * fc / phi
    flux_eus = evap_7(S1, sb, Ep, delta_t)
    flux_rg = saturation_1(P, S1, soil_capacity)
    flux_se = excess_1(S1, soil_capacity, delta_t)
    flux_esat = evap_7(S2, sb, Ep, delta_t)
    flux_qse = saturation_1(flux_rg + flux_se, S2, sb)
    flux_qss = interflow_3(alpha_ss, beta_ss, S2, delta_t)
    flux_qr = recharge_3(k_deep, S2)
    flux_qbf = interflow_3(alpha_bf, beta_bf, S3, delta_t)

    out_dS[0] = P - flux_eus - flux_rg - flux_se
    out_dS[1] = flux_rg + flux_se - flux_esat - flux_qse - flux_qss - flux_qr
    out_dS[2] = flux_qr - flux_qbf

    out_fluxes[0] = flux_eus
    out_fluxes[1] = flux_rg
    out_fluxes[2] = flux_se
    out_fluxes[3] = flux_esat
    out_fluxes[4] = flux_qse
    out_fluxes[5] = flux_qss
    out_fluxes[6] = flux_qr
    out_fluxes[7] = flux_qbf


class australia(StepKernelModel):
    python_step_function = staticmethod(_australia_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 8
        self.num_params = 8
        self.jacob_pattern = np.array([[1, 1, 0], [1, 1, 0], [0, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [1, 2000],
                [0.05, 0.95],
                [0.01, 1.00],
                [0, 1.00],
                [1, 5],
                [0, 1.00],
                [0, 1.00],
                [1, 5],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["eus", "rg", "se", "esat", "qse", "qss", "qr", "qbf"]
        self.flux_groups = {"Ea": [1, 4], "Q": [5, 6, 8]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
