from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_16,
    saturation_1,
    saturation_9,
    split_1,
)
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _penman_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    smax = float(theta[0])
    phi = float(theta[1])
    gam = float(theta[2])
    k1 = float(theta[3])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ea = evap_1(S1, Ep, delta_t)
    flux_qex = saturation_1(P, S1, smax)
    flux_u1 = split_1(phi, flux_qex)
    flux_q12 = split_1(1.0 - phi, flux_qex)
    flux_et = evap_16(gam, np.inf, S1, 0.01, Ep, delta_t)
    flux_u2 = saturation_9(flux_q12, S2, 0.01)
    flux_q = baseflow_1(k1, S3)

    out_dS[0] = P - flux_ea - flux_qex
    out_dS[1] = flux_et + flux_u2 - flux_q12
    out_dS[2] = flux_u1 + flux_u2 - flux_q

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_qex
    out_fluxes[2] = flux_u1
    out_fluxes[3] = flux_q12
    out_fluxes[4] = flux_et
    out_fluxes[5] = flux_u2
    out_fluxes[6] = flux_q


class penman(StepKernelModel):
    python_step_function = staticmethod(_penman_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 7
        self.num_params = 4
        self.jacob_pattern = np.array([[1, 0, 0], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0, 1], [0, 1], [0, 1]], dtype=np.float64
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = ["ea", "qex", "u1", "q12", "et", "u2", "q"]
        self.flux_groups = {"Ea": [1, 5], "Q": [7]}
        self.StoreSigns = np.array([1.0, -1.0, 1.0], dtype=np.float64)

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
