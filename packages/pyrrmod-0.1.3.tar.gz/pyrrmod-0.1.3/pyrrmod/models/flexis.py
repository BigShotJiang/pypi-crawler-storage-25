from __future__ import annotations

import numpy as np

from pyrrmod.auxiliary.numba import optional_njit
from pyrrmod.auxiliary.unit_hydro import (
    DoubleUHState,
    half_hydrograph,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_3,
    interception_1,
    melt_1,
    percolation_2,
    rainfall_1,
    saturation_3,
    snowfall_1,
    split_1,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, UnitHydroNumbaMixin


def _flexis_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _uh1_weights: FloatArray,
    uh1_pending: FloatArray,
    _uh2_weights: FloatArray,
    uh2_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weight arrays in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    smax = float(theta[0])
    beta = float(theta[1])
    d = float(theta[2])
    percmax = float(theta[3])
    lp = float(theta[4])
    kf = float(theta[7])
    ks = float(theta[8])
    imax = float(theta[9])
    tt = float(theta[10])
    ddf = float(theta[11])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])
    T = float(temp[step_index])

    flux_ps = snowfall_1(P, T, tt)
    flux_pi = rainfall_1(P, T, tt)
    flux_m = melt_1(ddf, tt, T, S1, delta_t)
    flux_peff = interception_1(flux_m + flux_pi, S2, imax)
    flux_ei = evap_1(S2, Ep, delta_t)
    flux_ru = saturation_3(S3, smax, beta, flux_peff)
    flux_eur = evap_3(lp, S3, smax, Ep, delta_t)
    flux_rp = percolation_2(percmax, S3, smax, delta_t)
    flux_rf = split_1(1.0 - d, flux_peff - flux_ru)
    flux_rs = split_1(d, flux_peff - flux_ru)
    flux_rfl = route_uh_current_nb(uh1_pending)
    flux_rsl = route_uh_current_nb(uh2_pending)
    flux_qf = baseflow_1(kf, S4)
    flux_qs = baseflow_1(ks, S5)

    out_dS[0] = flux_ps - flux_m
    out_dS[1] = flux_m + flux_pi - flux_peff - flux_ei
    out_dS[2] = flux_ru - flux_eur - flux_rp
    out_dS[3] = flux_rfl - flux_qf
    out_dS[4] = flux_rsl - flux_qs

    out_fluxes[0] = flux_ps
    out_fluxes[1] = flux_pi
    out_fluxes[2] = flux_m
    out_fluxes[3] = flux_peff
    out_fluxes[4] = flux_ei
    out_fluxes[5] = flux_ru
    out_fluxes[6] = flux_eur
    out_fluxes[7] = flux_rp
    out_fluxes[8] = flux_rf
    out_fluxes[9] = flux_rs
    out_fluxes[10] = flux_rfl
    out_fluxes[11] = flux_rsl
    out_fluxes[12] = flux_qf
    out_fluxes[13] = flux_qs


_flexis_compute_step_numba = optional_njit(cache=True)(_flexis_compute_step)


@optional_njit(cache=True)
def _flexis_commit_inflow_nb(fluxes: FloatArray) -> tuple[float, float]:
    return fluxes[8], fluxes[7] + fluxes[9]


class flexis(UnitHydroNumbaMixin, HydrologyModel):
    python_step_function = staticmethod(_flexis_compute_step)
    numba_step_function = staticmethod(_flexis_compute_step_numba)
    numba_commit_inflow_function = staticmethod(_flexis_commit_inflow_nb)
    routing_state_type = DoubleUHState
    routed_numba_newton_kind = "double"

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 5
        self.num_fluxes = 14
        self.num_params = 12
        self.jacob_pattern = np.array(
            [
                [1, 0, 0, 0, 0],
                [1, 1, 0, 0, 0],
                [1, 1, 1, 0, 0],
                [1, 1, 1, 1, 0],
                [1, 1, 1, 0, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [
                [1, 2000],
                [0, 10],
                [0, 1],
                [0, 20],
                [0.05, 0.95],
                [1, 5],
                [1, 15],
                [0, 1],
                [0, 1],
                [0, 5],
                [-3, 5],
                [0, 20],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4", "S5"]
        self.flux_names = [
            "ps",
            "pi",
            "m",
            "peff",
            "ei",
            "ru",
            "eur",
            "rp",
            "rf",
            "rs",
            "rf1",
            "rs1",
            "qf",
            "qs",
        ]
        self.flux_groups = {"Ea": [5, 7], "Q": [13, 14]}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        uh1, _ = half_hydrograph(float(theta[5]), float(self.delta_t), power=1.5)
        uh2, _ = half_hydrograph(float(theta[6]), float(self.delta_t), power=1.5)
        routing_state = DoubleUHState(
            uh1_weights=np.ascontiguousarray(uh1, dtype=np.float64),
            uh1_pending=np.zeros_like(uh1),
            uh2_weights=np.ascontiguousarray(uh2, dtype=np.float64),
            uh2_pending=np.zeros_like(uh2),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()
