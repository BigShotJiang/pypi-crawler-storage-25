from __future__ import annotations

import numpy as np

from pyrrmod.auxiliary.numba import ensure_njit, optional_njit
from pyrrmod.auxiliary.unit_hydro import (
    SingleUHState,
    full_hydrograph,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    capillary_1,
    evap_3,
    excess_1,
    infiltration_3,
    interflow_2,
    melt_1,
    percolation_1,
    rainfall_2,
    recharge_2,
    refreeze_1,
    snowfall_2,
)
from pyrrmod.models.base import (
    FloatArray,
    HydrologyModel,
    RuntimeContext,
    UnitHydroNumbaMixin,
)


def _hbv_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    prev_s2old: float,
    _uh_weights: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weights in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    tt = float(theta[0])
    tti = float(theta[1])
    ttm = float(theta[2])
    cfr = float(theta[3])
    cfmax = float(theta[4])
    whc = float(theta[5])
    cflux = float(theta[6])
    fc = float(theta[7])
    lp = float(theta[8])
    beta = float(theta[9])
    k0 = float(theta[10])
    alpha = float(theta[11])
    perc = float(theta[12])
    k1 = float(theta[13])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])
    T = float(temp[step_index])

    flux_sf = snowfall_2(P, T, tt, tti)
    flux_refr = refreeze_1(cfr, cfmax, ttm, T, S2, delta_t)
    flux_melt = melt_1(cfmax, ttm, T, S1, delta_t)
    flux_rf = rainfall_2(P, T, tt, tti)
    flux_in = infiltration_3(flux_rf + flux_melt, S2, whc * S1)
    flux_se = excess_1(prev_s2old, whc * S1, delta_t)
    flux_cf = capillary_1(cflux, S3, fc, S4, delta_t)
    flux_ea = evap_3(lp, S3, fc, Ep, delta_t)
    flux_r = recharge_2(beta, S3, fc, flux_in + flux_se)
    flux_q0 = interflow_2(k0, S4, alpha, delta_t)
    flux_perc = percolation_1(perc, S4, delta_t)
    flux_q1 = baseflow_1(k1, S5)
    flux_qt = route_uh_current_nb(uh_pending)

    out_dS[0] = flux_sf + flux_refr - flux_melt
    out_dS[1] = flux_rf + flux_melt - flux_refr - flux_in - flux_se
    out_dS[2] = flux_in + flux_se + flux_cf - flux_ea - flux_r
    out_dS[3] = flux_r - flux_cf - flux_q0 - flux_perc
    out_dS[4] = flux_perc - flux_q1

    out_fluxes[0] = flux_sf
    out_fluxes[1] = flux_refr
    out_fluxes[2] = flux_melt
    out_fluxes[3] = flux_rf
    out_fluxes[4] = flux_in
    out_fluxes[5] = flux_se
    out_fluxes[6] = flux_cf
    out_fluxes[7] = flux_ea
    out_fluxes[8] = flux_r
    out_fluxes[9] = flux_q0
    out_fluxes[10] = flux_perc
    out_fluxes[11] = flux_q1
    out_fluxes[12] = flux_qt


_hbv_compute_step_numba = optional_njit(cache=True)(_hbv_compute_step)


@optional_njit(cache=True)
def _hbv_commit_inflow_nb(fluxes: FloatArray) -> float:
    return fluxes[9] + fluxes[11]


class hbv(UnitHydroNumbaMixin, HydrologyModel):
    python_step_function = staticmethod(_hbv_compute_step)
    numba_step_function = staticmethod(_hbv_compute_step_numba)
    numba_commit_inflow_function = staticmethod(_hbv_commit_inflow_nb)
    routing_state_type = SingleUHState
    routed_numba_newton_kind = "single"
    routed_numba_newton_default_damping = 1.0
    routed_numba_newton_default_diff_step = 1e-7

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 5
        self.num_fluxes = 13
        self.num_params = 15
        self.jacob_pattern = np.array(
            [
                [1, 1, 0, 0, 0],
                [1, 1, 0, 0, 0],
                [1, 1, 1, 1, 0],
                [1, 1, 1, 1, 0],
                [0, 0, 0, 1, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [
                [-3, 5],
                [0, 17],
                [-3, 3],
                [0, 1],
                [0, 20],
                [0, 1],
                [0, 4],
                [1, 2000],
                [0.05, 0.95],
                [0, 10],
                [0, 1],
                [0, 4],
                [0, 20],
                [0, 1],
                [1, 120],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4", "S5"]
        self.flux_names = [
            "sf",
            "refr",
            "melt",
            "rf",
            "in",
            "se",
            "cf",
            "ea",
            "r",
            "q0",
            "perc",
            "q1",
            "qt",
        ]
        self.flux_groups = {"Ea": 8, "Q": 13}

    def init(self) -> None:
        weights, _ = full_hydrograph(
            float(self.theta[14]), float(self.delta_t), power=1.5
        )
        routing_state = SingleUHState(
            uh_weights=np.ascontiguousarray(weights, dtype=np.float64),
            uh_pending=np.zeros_like(weights),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _bind_kernel(self, step_fun, runtime: RuntimeContext):
        routing = self._require_routing_state(runtime)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        stores = runtime.stores
        S0 = runtime.S0
        uh_weights = routing.uh_weights
        uh_pending = routing.uh_pending

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            prev_s2old = (
                float(S0[1]) if step_index == 0 else float(stores[step_index - 1, 1])
            )
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                prev_s2old,
                uh_weights,
                uh_pending,
                out_states,
                out_fluxes,
            )

        return kernel

    def _compute_into(
        self,
        states,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        routing = self._require_routing_state(runtime)
        if runtime is not None:
            prev_s2old = (
                float(runtime.S0[1])
                if resolved_step == 0
                else float(runtime.stores[resolved_step - 1, 1])
            )
        elif self.S0 is not None and resolved_step == 0:
            prev_s2old = float(np.asarray(self.S0, dtype=np.float64)[1])
        elif self.stores is not None and resolved_step > 0:
            prev_s2old = float(
                np.asarray(self.stores, dtype=np.float64)[resolved_step - 1, 1]
            )
        else:
            prev_s2old = float(state_vector[1])

        _hbv_compute_step(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            prev_s2old,
            routing.uh_weights,
            routing.uh_pending,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def _build_routed_numba_newton_step_kernel(self, runtime: RuntimeContext):
        if (
            self._routed_numba_newton_step_kernel is not None
            and self._routed_numba_newton_step_kernel_runtime is runtime
        ):
            return self._routed_numba_newton_step_kernel

        routing = self._require_routing_state(runtime)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        stores = runtime.stores
        s0 = runtime.S0
        uh_weights = routing.uh_weights
        step_fun = self._get_or_compile_numba_step_function(
            python_step_function=self.python_step_function,
            numba_step_function=self.numba_step_function,
        )

        def kernel(
            states: FloatArray,
            step_index: int,
            uh_pending: FloatArray,
            out_dS: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            prev_s2old = s0[1] if step_index == 0 else stores[step_index - 1, 1]
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                prev_s2old,
                uh_weights,
                uh_pending,
                out_dS,
                out_fluxes,
            )

        kernel = ensure_njit(kernel, cache=False)
        warm_dS = np.empty(int(self.num_stores), dtype=np.float64)
        warm_fluxes = np.empty(int(self.num_fluxes), dtype=np.float64)
        kernel(
            np.asarray(runtime.S0, dtype=np.float64),
            0,
            routing.uh_pending,
            warm_dS,
            warm_fluxes,
        )
        self._routed_numba_newton_step_kernel = kernel
        self._routed_numba_newton_step_kernel_runtime = runtime
        return kernel

    def residual_jacobian(
        self,
        states,
        previous_states,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        del states, previous_states, step_index, diff_step
        # HBV switches branches around snow and infiltration thresholds, so the
        # generic finite-difference Jacobian is less reliable than Jacobian-free fsolve.
        return None
