from __future__ import annotations

import numpy as np

from pyrrmod.auxiliary.numba import optional_njit
from pyrrmod.auxiliary.unit_hydro import (
    SingleUHState,
    full_hydrograph,
    route_uh_current_nb,
)
from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_5,
    evap_6,
    interception_1,
    interflow_9,
    saturation_1,
)
from pyrrmod.models.base import FloatArray, HydrologyModel, UnitHydroNumbaMixin


def _newzealand2_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _uh_weights: FloatArray,
    uh_pending: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    # Keep UH weights in the signature so routed-model kernels stay uniform.
    # Current-step routing only reads pending state; weight application happens in step().
    s1max = float(theta[0])
    s2max = float(theta[1])
    sfc = float(theta[2])
    m = float(theta[3])
    a = float(theta[4])
    b = float(theta[5])
    tcbf = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_eint = evap_1(S1, Ep, delta_t)
    flux_qtf = interception_1(P, S1, s1max)
    flux_veg = evap_6(m, sfc, S2, s2max, Ep, delta_t)
    flux_ebs = evap_5(m, S2, s2max, Ep, delta_t)
    flux_qse = saturation_1(flux_qtf, S2, s2max)
    flux_qss = interflow_9(S2, a, sfc * s2max, b, delta_t)
    flux_qbf = baseflow_1(tcbf, S2)
    flux_qt = route_uh_current_nb(uh_pending)

    out_dS[0] = P - flux_eint - flux_qtf
    out_dS[1] = flux_qtf - flux_veg - flux_ebs - flux_qse - flux_qss - flux_qbf

    out_fluxes[0] = flux_eint
    out_fluxes[1] = flux_qtf
    out_fluxes[2] = flux_veg
    out_fluxes[3] = flux_ebs
    out_fluxes[4] = flux_qse
    out_fluxes[5] = flux_qss
    out_fluxes[6] = flux_qbf
    out_fluxes[7] = flux_qt


_newzealand2_compute_step_numba = optional_njit(cache=True)(_newzealand2_compute_step)


@optional_njit(cache=True)
def _newzealand2_commit_inflow_nb(fluxes: FloatArray) -> float:
    return fluxes[4] + fluxes[5] + fluxes[6]


class newzealand2(UnitHydroNumbaMixin, HydrologyModel):
    python_step_function = staticmethod(_newzealand2_compute_step)
    numba_step_function = staticmethod(_newzealand2_compute_step_numba)
    numba_commit_inflow_function = staticmethod(_newzealand2_commit_inflow_nb)
    routing_state_type = SingleUHState
    routed_numba_newton_kind = "single"
    routed_numba_newton_use_predictor = False

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 8
        self.num_params = 8
        self.jacob_pattern = np.array([[1, 0], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [
                [0, 5],
                [1, 2000],
                [0.05, 0.95],
                [0.05, 0.95],
                [0, 1],
                [1, 5],
                [0, 1],
                [1, 120],
            ],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2"]
        self.flux_names = ["eint", "qtf", "veg", "ebs", "qse", "qss", "qbf", "qt"]
        self.flux_groups = {"Ea": [1, 3, 4], "Q": 8}

    def init(self) -> None:
        theta = np.asarray(self.theta, dtype=np.float64)
        self.store_max = np.array([theta[0], theta[1]], dtype=np.float64)
        weights, _ = full_hydrograph(float(theta[7]), float(self.delta_t), power=1.5)
        routing_state = SingleUHState(
            uh_weights=np.ascontiguousarray(weights, dtype=np.float64),
            uh_pending=np.zeros_like(weights),
        )
        self.routing_state = routing_state
        self.uhs = routing_state.as_legacy_uhs()

    def _supports_routed_numba_newton(self) -> bool:
        return False
