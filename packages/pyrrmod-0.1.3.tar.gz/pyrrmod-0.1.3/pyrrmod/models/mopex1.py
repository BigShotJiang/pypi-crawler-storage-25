from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import baseflow_1, evap_7, recharge_3, saturation_1
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _mopex1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    s1max = float(theta[0])
    tw = float(theta[1])
    tu = float(theta[2])
    se = float(theta[3])
    tc = float(theta[4])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_et1 = evap_7(S1, s1max, Ep, delta_t)
    flux_q1f = saturation_1(P, S1, s1max)
    flux_qw = recharge_3(tw, S1)
    flux_et2 = evap_7(S2, se, Ep, delta_t)
    flux_q2u = baseflow_1(tu, S2)
    flux_qf = baseflow_1(tc, S3)
    flux_qs = baseflow_1(tc, S4)

    out_dS[0] = P - flux_et1 - flux_q1f - flux_qw
    out_dS[1] = flux_qw - flux_et2 - flux_q2u
    out_dS[2] = flux_q1f - flux_qf
    out_dS[3] = flux_q2u - flux_qs

    out_fluxes[0] = flux_et1
    out_fluxes[1] = flux_q1f
    out_fluxes[2] = flux_qw
    out_fluxes[3] = flux_et2
    out_fluxes[4] = flux_q2u
    out_fluxes[5] = flux_qf
    out_fluxes[6] = flux_qs


class mopex1(StepKernelModel):
    python_step_function = staticmethod(_mopex1_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 4
        self.num_fluxes = 7
        self.num_params = 5
        self.jacob_pattern = np.array(
            [[1, 0, 0, 0], [1, 1, 0, 0], [1, 0, 1, 0], [0, 1, 0, 1]], dtype=int
        )
        self.par_ranges = np.array(
            [[1, 2000], [0, 1], [0, 1], [1, 2000], [0, 1]],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4"]
        self.flux_names = ["et1", "q1f", "qw", "et2", "q2u", "qf", "qs"]
        self.flux_groups = {"Ea": [1, 4], "Q": [6, 7]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
