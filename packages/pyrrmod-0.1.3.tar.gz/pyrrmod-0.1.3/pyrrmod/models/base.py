from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Literal
import warnings

import numpy as np
from pydantic import AliasChoices, BaseModel, ConfigDict, Field, ValidationError
from pydantic import field_validator, model_validator
from scipy.optimize import fsolve

from pyrrmod.auxiliary.numba import ensure_njit
from pyrrmod.auxiliary.solver import (
    newton_raphson,
    run_routed_numba_newton_kernel_double,
    run_routed_numba_newton_kernel_single,
    run_routed_numba_newton_kernel_triple,
)
from pyrrmod.auxiliary.unit_hydro import (
    DoubleUHState,
    SingleUHState,
    TripleUHState,
    update_uh_inplace,
)


FloatArray = np.ndarray


def _as_float_array(value: Any, *, field_name: str) -> FloatArray:
    array = np.asarray(value, dtype=np.float64).reshape(-1)
    if array.size == 0:
        raise ValueError(f"{field_name} cannot be empty")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{field_name} must contain only finite values")
    return array


class ClimateInput(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, populate_by_name=True)

    precip: FloatArray = Field(validation_alias=AliasChoices("precip", "rainfall"))
    temp: FloatArray = Field(validation_alias=AliasChoices("temp", "temperature"))
    pet: FloatArray = Field(validation_alias=AliasChoices("pet", "PET"))

    @field_validator("precip", "temp", "pet", mode="before")
    @classmethod
    def _coerce_array(cls, value: Any, info: Any) -> FloatArray:
        return _as_float_array(value, field_name=str(info.field_name))

    @model_validator(mode="after")
    def _validate_lengths(self) -> "ClimateInput":
        n = int(self.precip.shape[0])
        if int(self.temp.shape[0]) != n or int(self.pet.shape[0]) != n:
            raise ValueError("climate arrays must have the same length")
        return self


class SolverOptionsInput(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    resnorm_tolerance: float = Field(
        1e-8, validation_alias=AliasChoices("resnorm_tolerance", "TolFun")
    )
    resnorm_maxiter: int = Field(
        50, validation_alias=AliasChoices("resnorm_maxiter", "MaxIter")
    )
    diff_step: float = Field(
        1e-6, validation_alias=AliasChoices("diff_step", "DiffStep")
    )
    damping: float = Field(1.0, validation_alias=AliasChoices("damping", "Damping"))


class ModelConfigInput(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, populate_by_name=True)

    delta_t: float
    S0: FloatArray = Field(validation_alias=AliasChoices("S0", "initial_stores"))
    input_climate: ClimateInput = Field(
        validation_alias=AliasChoices("input_climate", "climate")
    )
    solver_opts: SolverOptionsInput | None = Field(
        default=None,
        validation_alias=AliasChoices("solver_opts", "solver_options"),
    )
    compile_target: Literal["auto", "python", "numba"] = "numba"

    @field_validator("S0", mode="before")
    @classmethod
    def _coerce_s0(cls, value: Any) -> FloatArray:
        return _as_float_array(value, field_name="S0")


class ModelRunInput(ModelConfigInput):
    theta: FloatArray

    @field_validator("theta", mode="before")
    @classmethod
    def _coerce_theta(cls, value: Any) -> FloatArray:
        return _as_float_array(value, field_name="theta")


@dataclass(slots=True)
class ClimateArrays:
    precip: FloatArray
    temp: FloatArray
    pet: FloatArray


@dataclass(slots=True)
class RuntimeContext:
    theta: FloatArray
    delta_t: float
    S0: FloatArray
    precip: FloatArray
    temp: FloatArray
    pet: FloatArray
    climate: ClimateArrays
    stores: FloatArray
    fluxes: FloatArray
    solver_opts: dict[str, Any]
    store_min: FloatArray
    store_max: FloatArray
    routing_state: Any = None


@dataclass(slots=True)
class CompilerState:
    requested_target: str = "auto"
    target: str = "python"
    enabled: bool = False
    detail: str = "python kernel"
    compiled_model_fun: (
        Callable[[FloatArray, int, FloatArray, FloatArray], None] | None
    ) = None


class HydrologyModel:
    def __init__(self) -> None:
        self.num_stores = 0
        self.num_fluxes = 0
        self.num_params = 0

        self.jacob_pattern: FloatArray | None = None
        self.par_ranges: FloatArray | None = None
        self.store_names: list[str] = []
        self.flux_names: list[str] = []
        self.flux_groups: dict[str, Any] = {}
        self.StoreSigns: FloatArray | None = None

        self.theta: FloatArray | None = None
        self.delta_t: float | None = None
        self.S0: FloatArray | None = None
        self.solver_opts: dict[str, Any] = {}

        self.store_min: FloatArray = np.zeros(0, dtype=np.float64)
        self.store_max: FloatArray = np.zeros(0, dtype=np.float64)

        self.climate_arrays: ClimateArrays | None = None
        self.stores: FloatArray | None = None
        self.fluxes: FloatArray | None = None
        self.solver_data: dict[str, FloatArray] | None = None
        self.runtime_context: RuntimeContext | None = None

        self.status = 0
        self.t = 0
        self.routing_state: Any = None
        self.uhs: Any = None
        self._initial_routing_pending_total = 0.0

        self.compiler = CompilerState()
        self._python_model_fun: (
            Callable[[FloatArray, int, FloatArray, FloatArray], None] | None
        ) = None
        self._routed_numba_newton_step_kernel: Callable[..., None] | None = None
        self._routed_numba_newton_step_kernel_runtime: RuntimeContext | None = None

    def init(self) -> None:
        pass

    def step(self) -> None:
        pass

    def _routing_pending_total(self) -> float:
        routing = self.routing_state
        pending_total = getattr(routing, "pending_total", None)
        if callable(pending_total):
            return float(pending_total())

        if self.uhs is None:
            return 0.0

        total = 0.0
        for item in self.uhs:
            if isinstance(item, (tuple, list)) and len(item) == 2:
                total += float(np.sum(np.asarray(item[1], dtype=np.float64)))
        return total

    def residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        return None

    def _uses_discrete_step_solver(self) -> bool:
        return False

    def _supports_routed_numba_newton(self) -> bool:
        return False

    def _run_routed_numba_newton(self, runtime: RuntimeContext) -> None:
        raise RuntimeError("routed numba newton is not available")

    def _advance_discrete_step(
        self,
        previous_states: FloatArray,
        step_index: int,
        out_states: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        raise NotImplementedError

    def _as_state_vector(self, states: Any) -> FloatArray:
        return np.asarray(states, dtype=np.float64).reshape(-1)

    def _resolve_runtime_inputs(
        self,
        ctx: RuntimeContext | None = None,
    ) -> tuple[
        RuntimeContext | None,
        FloatArray,
        float,
        FloatArray,
        FloatArray,
        FloatArray,
    ]:
        runtime = ctx if ctx is not None else self.runtime_context
        if runtime is not None:
            return (
                runtime,
                runtime.theta,
                float(runtime.delta_t),
                runtime.precip,
                runtime.pet,
                runtime.temp,
            )

        climate = self.climate_arrays
        if climate is None or self.theta is None or self.delta_t is None:
            raise RuntimeError(
                f"{self.__class__.__name__} requires theta, delta_t, and input_climate"
            )

        return (
            None,
            np.asarray(self.theta, dtype=np.float64),
            float(self.delta_t),
            climate.precip,
            climate.pet,
            climate.temp,
        )

    def _resolve_step_index(
        self,
        *,
        step_index: int | None = None,
        t: float | None = None,
        time_steps: int,
        delta_t: float,
    ) -> int:
        if step_index is not None:
            resolved = int(step_index)
        elif t is not None:
            resolved = int(float(t) / delta_t) if t > 0.0 else 0
        elif self.t is not None:
            resolved = int(self.t)
        else:
            resolved = 0

        if resolved < 0:
            return 0
        if resolved >= time_steps:
            return time_steps - 1
        return resolved

    def _warm_bound_kernel(
        self,
        runtime: RuntimeContext,
        kernel: Callable[[FloatArray, int, FloatArray, FloatArray], None],
    ) -> None:
        warm_dS = np.empty(self.num_stores, dtype=np.float64)
        warm_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        kernel(np.asarray(runtime.S0, dtype=np.float64), 0, warm_dS, warm_fluxes)

    def _compile_bound_kernel(
        self,
        runtime: RuntimeContext,
        kernel: Callable[[FloatArray, int, FloatArray, FloatArray], None],
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        compiled = ensure_njit(kernel, cache=False)
        self._warm_bound_kernel(runtime, compiled)
        return compiled

    def _get_or_compile_numba_step_function(
        self,
        *,
        python_step_function: Callable[..., None] | None,
        numba_step_function: Callable[..., None] | None,
    ) -> Callable[..., None]:
        source = (
            numba_step_function
            if numba_step_function is not None
            else python_step_function
        )
        if source is None:
            raise RuntimeError("python_step_function is not defined")

        cls = type(self)
        cached = getattr(cls, "_cached_numba_step_function", None)
        cached_source = getattr(cls, "_cached_numba_step_source", None)
        if cached is not None and cached_source is source:
            return cached

        compiled = ensure_njit(source, cache=True)
        setattr(cls, "_cached_numba_step_source", source)
        setattr(cls, "_cached_numba_step_function", compiled)
        return compiled

    def _finite_difference_residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
        compute_dS: Callable[[FloatArray, int, RuntimeContext], FloatArray],
    ) -> FloatArray | None:
        runtime = self.runtime_context
        if runtime is None or self.jacob_pattern is None:
            return None

        state_vector = self._as_state_vector(states)
        previous_vector = self._as_state_vector(previous_states)
        if state_vector.size != int(self.num_stores) or previous_vector.size != int(
            self.num_stores
        ):
            return None

        pattern = np.asarray(self.jacob_pattern, dtype=np.int64)
        if pattern.ndim == 1:
            pattern = pattern.reshape(1, -1)

        base_dS = np.asarray(
            compute_dS(state_vector, int(step_index), runtime),
            dtype=np.float64,
        )
        base_residual = (state_vector - previous_vector) / float(
            runtime.delta_t
        ) - base_dS
        jacobian = np.zeros(
            (int(self.num_stores), int(self.num_stores)),
            dtype=np.float64,
        )

        for col_index in range(int(self.num_stores)):
            if not np.any(pattern[:, col_index] != 0):
                continue

            perturbed = state_vector.copy()
            step = diff_step * max(abs(float(state_vector[col_index])), 1.0)
            perturbed[col_index] = perturbed[col_index] + step
            perturbed = np.minimum(
                np.maximum(perturbed, runtime.store_min),
                runtime.store_max,
            )
            effective_step = float(perturbed[col_index] - state_vector[col_index])
            if effective_step == 0.0:
                effective_step = step

            trial_dS = np.asarray(
                compute_dS(perturbed, int(step_index), runtime),
                dtype=np.float64,
            )
            trial_residual = (perturbed - previous_vector) / float(
                runtime.delta_t
            ) - trial_dS

            for row_index in range(int(self.num_stores)):
                if pattern[row_index, col_index] != 0:
                    jacobian[row_index, col_index] = (
                        trial_residual[row_index] - base_residual[row_index]
                    ) / effective_step

        return jacobian

    def validate_run_payload(self, payload: Any) -> ModelRunInput:
        return ModelRunInput.model_validate(payload)

    def _format_mcp_error(self, exc: Exception) -> dict[str, Any]:
        if isinstance(exc, ValidationError):
            category = "payload_error"
            details = exc.errors()
        elif isinstance(exc, RuntimeError):
            category = "simulation_error"
            details = {"message": str(exc)}
        else:
            category = "configuration_error"
            details = {"message": str(exc)}

        return {
            "ok": False,
            "error": {
                "category": category,
                "type": exc.__class__.__name__,
                "message": str(exc),
                "details": details,
            },
        }

    def _reset_store_bounds(self) -> None:
        self.store_min = np.zeros(self.num_stores, dtype=np.float64)
        self.store_max = np.full(self.num_stores, np.inf, dtype=np.float64)

    def _resolve_config(
        self, config: Any
    ) -> tuple[ModelConfigInput | ModelRunInput | None, FloatArray | None]:
        if config is None:
            return None, None
        if isinstance(config, ModelRunInput):
            return config, config.theta
        if isinstance(config, ModelConfigInput):
            return config, None
        if isinstance(config, dict) and "theta" in config:
            parsed = ModelRunInput.model_validate(config)
            return parsed, parsed.theta
        parsed = ModelConfigInput.model_validate(config)
        return parsed, None

    def configure(
        self,
        *,
        config: Any | None = None,
        theta: Any | None = None,
        delta_t: float | None = None,
        S0: Any | None = None,
        input_climate: Any | None = None,
        solver_opts: Any | None = None,
        compile_target: str | None = None,
    ) -> "HydrologyModel":
        parsed_config, parsed_theta = self._resolve_config(config)

        if parsed_config is not None:
            delta_t = float(parsed_config.delta_t)
            S0 = np.asarray(parsed_config.S0, dtype=np.float64)
            input_climate = parsed_config.input_climate
            if parsed_config.solver_opts is not None:
                solver_opts = parsed_config.solver_opts.model_dump()
            if compile_target is None:
                compile_target = parsed_config.compile_target

        if parsed_theta is not None and theta is None:
            theta = parsed_theta

        if theta is not None:
            self.theta = _as_float_array(theta, field_name="theta")
        if delta_t is not None:
            self.delta_t = float(delta_t)
        if S0 is not None:
            self.S0 = _as_float_array(S0, field_name="S0")

        if input_climate is not None:
            climate = (
                input_climate
                if isinstance(input_climate, ClimateInput)
                else ClimateInput.model_validate(input_climate)
            )
            self.climate_arrays = ClimateArrays(
                precip=np.asarray(climate.precip, dtype=np.float64),
                temp=np.asarray(climate.temp, dtype=np.float64),
                pet=np.asarray(climate.pet, dtype=np.float64),
            )

        if (
            self.theta is None
            or self.delta_t is None
            or self.S0 is None
            or self.climate_arrays is None
        ):
            raise RuntimeError(
                "configure requires theta, delta_t, S0, and input_climate"
            )

        if int(self.theta.shape[0]) != int(self.num_params):
            raise ValueError(f"theta length must be {self.num_params}")
        if int(self.S0.shape[0]) != int(self.num_stores):
            raise ValueError(f"S0 length must be {self.num_stores}")

        n_steps = int(self.climate_arrays.precip.shape[0])
        self.stores = np.zeros((n_steps, self.num_stores), dtype=np.float64)
        self.fluxes = np.zeros((n_steps, self.num_fluxes), dtype=np.float64)

        self._reset_store_bounds()
        self.routing_state = None
        self.uhs = None
        self._initial_routing_pending_total = 0.0
        if self.StoreSigns is None or int(self.StoreSigns.shape[0]) != int(
            self.num_stores
        ):
            self.StoreSigns = np.ones(self.num_stores, dtype=np.float64)

        self.init()
        self._initial_routing_pending_total = self._routing_pending_total()
        if int(self.store_min.shape[0]) != int(self.num_stores) or int(
            self.store_max.shape[0]
        ) != int(self.num_stores):
            raise RuntimeError("store bounds must match num_stores")

        solver_dict: dict[str, Any]
        if solver_opts is None:
            solver_dict = {}
        elif isinstance(solver_opts, SolverOptionsInput):
            solver_dict = solver_opts.model_dump()
        else:
            solver_dict = SolverOptionsInput.model_validate(solver_opts).model_dump()
        self.solver_opts = solver_dict

        self.runtime_context = RuntimeContext(
            theta=np.asarray(self.theta, dtype=np.float64),
            delta_t=float(self.delta_t),
            S0=np.asarray(self.S0, dtype=np.float64),
            precip=np.asarray(self.climate_arrays.precip, dtype=np.float64),
            temp=np.asarray(self.climate_arrays.temp, dtype=np.float64),
            pet=np.asarray(self.climate_arrays.pet, dtype=np.float64),
            climate=self.climate_arrays,
            stores=self.stores,
            fluxes=self.fluxes,
            solver_opts=self.solver_opts,
            store_min=np.asarray(self.store_min, dtype=np.float64),
            store_max=np.asarray(self.store_max, dtype=np.float64),
            routing_state=self.routing_state,
        )
        self._routed_numba_newton_step_kernel = None
        self._routed_numba_newton_step_kernel_runtime = None

        requested = "auto" if compile_target is None else str(compile_target)
        self.compile_model_fun(target=requested)
        return self

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        raise NotImplementedError

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        return None

    def compile_model_fun(self, target: str = "auto") -> str:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("configure must be called before compile_model_fun")

        requested = str(target)
        self._python_model_fun = self.build_python_kernel(runtime)
        self.compiler = CompilerState(
            requested_target=requested,
            target="python",
            enabled=False,
            detail="python kernel",
            compiled_model_fun=None,
        )

        if requested == "python":
            return self.compiler.target

        if requested not in {"auto", "numba"}:
            raise ValueError("compile target must be one of: auto, python, numba")

        try:
            compiled = self.build_numba_model_fun(runtime)
            if compiled is None:
                raise RuntimeError("numba kernel not provided")
            self.compiler.target = "numba"
            self.compiler.enabled = True
            self.compiler.compiled_model_fun = compiled
            self.compiler.detail = "numba kernel"
        except Exception as exc:
            self.compiler.target = "python"
            self.compiler.enabled = False
            self.compiler.compiled_model_fun = None
            self.compiler.detail = f"compiled model unavailable: {exc}"
            if requested == "numba":
                warnings.warn(
                    f"Numba requested but compiled model unavailable; using python kernel ({exc})",
                    RuntimeWarning,
                )

        return self.compiler.target

    def _evaluate_step_into(
        self,
        states: FloatArray,
        step_index: int,
        out_dS: FloatArray,
        out_fluxes: FloatArray,
    ) -> None:
        kernel = (
            self.compiler.compiled_model_fun
            if self.compiler.enabled
            else self._python_model_fun
        )
        if kernel is None:
            raise RuntimeError("model kernel is not initialised")
        kernel(states, int(step_index), out_dS, out_fluxes)

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        raise NotImplementedError

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        del t, ctx
        state_vector = self._as_state_vector(states)
        dS = np.empty(self.num_stores, dtype=np.float64)
        fluxes = np.empty(self.num_fluxes, dtype=np.float64)
        index = self.t if step_index is None else int(step_index)
        self._evaluate_step_into(state_vector, index, dS, fluxes)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        runtime = self.runtime_context if ctx is None else ctx
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")
        step = int(max(0, min(runtime.precip.shape[0] - 1, int(t / runtime.delta_t))))
        old_t = self.t
        try:
            self.t = step
            dS, _ = self.model_fun(self._as_state_vector(y))
            return np.asarray(dS, dtype=np.float64)
        finally:
            self.t = old_t

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        def rhs(t: float, y: FloatArray) -> FloatArray:
            return self.scipy_rhs(t, y, ctx)

        return rhs

    def compute_dS(
        self,
        s: np.ndarray,
        forcing: np.ndarray,
        params: np.ndarray,
    ) -> np.ndarray:
        del s, forcing, params
        raise NotImplementedError("compute_dS is required for heun")

    def _fsolve_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")
        delta_t = float(runtime.delta_t)

        previous_states = np.asarray(previous_states, dtype=np.float64)

        def residual(trial: FloatArray) -> FloatArray:
            dS, _ = self.model_fun(trial)
            return (trial - previous_states) / delta_t - dS

        jac = self.residual_jacobian(
            previous_states,
            previous_states,
            step_index,
            diff_step=float(self.solver_opts.get("diff_step", 1e-6)),
        )

        if jac is None:
            root, info, ier, _ = fsolve(residual, previous_states, full_output=True)
        else:

            def fprime(trial: FloatArray) -> FloatArray:
                resolved = self.residual_jacobian(
                    trial,
                    previous_states,
                    step_index,
                    diff_step=float(self.solver_opts.get("diff_step", 1e-6)),
                )
                return np.asarray(
                    resolved if resolved is not None else jac, dtype=np.float64
                )

            root, info, ier, _ = fsolve(
                residual, previous_states, fprime=fprime, full_output=True
            )

        trial_state = np.asarray(root, dtype=np.float64)
        trial_state = np.minimum(
            np.maximum(trial_state, runtime.store_min), runtime.store_max
        )
        dS, fluxes = self.model_fun(trial_state)
        residual_norm = float(np.linalg.norm(residual(trial_state)))
        nfev = int(info.get("nfev", 0))
        njev = int(info.get("njev", 0))
        _ = int(ier)
        return (
            trial_state,
            np.asarray(fluxes, dtype=np.float64),
            residual_norm,
            nfev,
            njev,
        )

    def _newton_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")
        delta_t = float(runtime.delta_t)

        previous_states = np.asarray(previous_states, dtype=np.float64)

        def residual(trial: FloatArray) -> FloatArray:
            dS, _ = self.model_fun(trial)
            return (trial - previous_states) / delta_t - dS

        opts = {
            "MaxIter": int(self.solver_opts.get("resnorm_maxiter", 50)),
            "DiffStep": float(self.solver_opts.get("diff_step", 1e-6)),
            "TolFun": float(self.solver_opts.get("resnorm_tolerance", 1e-8)),
            "Damping": float(self.solver_opts.get("damping", 1.0)),
        }
        root, residual_vec, _ = newton_raphson(residual, previous_states, opts)
        trial_state = np.asarray(root, dtype=np.float64)
        trial_state = np.minimum(
            np.maximum(trial_state, runtime.store_min), runtime.store_max
        )
        _, fluxes = self.model_fun(trial_state)
        residual_norm = float(
            np.linalg.norm(np.asarray(residual_vec, dtype=np.float64))
        )
        return (
            trial_state,
            np.asarray(fluxes, dtype=np.float64),
            residual_norm,
            int(opts["MaxIter"]),
            0,
        )

    def _heun_step(
        self, previous_states: FloatArray, step_index: int
    ) -> tuple[FloatArray, FloatArray, float, int, int]:
        runtime = self.runtime_context
        if runtime is None:
            raise RuntimeError("runtime context is not initialised")

        state = np.asarray(previous_states, dtype=np.float64)
        forcing = np.array(
            [
                runtime.precip[step_index],
                runtime.temp[step_index],
                runtime.pet[step_index],
            ],
            dtype=np.float64,
        )
        params = np.asarray(runtime.theta, dtype=np.float64)

        k1 = np.asarray(self.compute_dS(state, forcing, params), dtype=np.float64)
        predicted = state + runtime.delta_t * k1
        predicted = np.minimum(
            np.maximum(predicted, runtime.store_min), runtime.store_max
        )
        k2 = np.asarray(self.compute_dS(predicted, forcing, params), dtype=np.float64)

        new_state = state + 0.5 * runtime.delta_t * (k1 + k2)
        new_state = np.minimum(
            np.maximum(new_state, runtime.store_min), runtime.store_max
        )
        _, fluxes = self.model_fun(new_state)
        return new_state, np.asarray(fluxes, dtype=np.float64), 0.0, 1, 0

    def run(
        self,
        *,
        config: Any | None = None,
        theta: Any | None = None,
        delta_t: float | None = None,
        S0: Any | None = None,
        input_climate: Any | None = None,
        solver_opts: Any | None = None,
        compile_target: str | None = None,
        solver: str = "fsolve",
    ) -> "HydrologyModel":
        if (
            config is not None
            or theta is not None
            or delta_t is not None
            or S0 is not None
            or input_climate is not None
        ):
            self.configure(
                config=config,
                theta=theta,
                delta_t=delta_t,
                S0=S0,
                input_climate=input_climate,
                solver_opts=solver_opts,
                compile_target=compile_target,
            )

        if (
            self.runtime_context is None
            or self.stores is None
            or self.fluxes is None
            or self.S0 is None
        ):
            raise RuntimeError("model is not configured")

        if solver == "numba_newton" and self._supports_routed_numba_newton():
            self._run_routed_numba_newton(self.runtime_context)
            return self

        if solver == "numba_newton" and not isinstance(self, StepKernelModel):
            warnings.warn(
                "Falling back to fsolve for routed models with discrete history.",
                RuntimeWarning,
            )
            solver = "fsolve"

        n_steps = int(self.runtime_context.precip.shape[0])
        solver_name = np.full(n_steps, solver, dtype=object)
        resnorm = np.zeros(n_steps, dtype=np.float64)
        iteration_count = np.zeros(n_steps, dtype=np.int64)
        nfev = np.zeros(n_steps, dtype=np.int64)
        njev = np.zeros(n_steps, dtype=np.int64)

        for step_index in range(n_steps):
            self.t = step_index
            previous = (
                self.runtime_context.S0
                if step_index == 0
                else self.stores[step_index - 1, :]
            )

            if self._uses_discrete_step_solver() and solver in {
                "fsolve",
                "numba_newton",
            }:
                out_states = np.empty(self.num_stores, dtype=np.float64)
                out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)
                self._advance_discrete_step(
                    previous, step_index, out_states, out_fluxes
                )
                state = np.asarray(out_states, dtype=np.float64)
                fluxes = np.asarray(out_fluxes, dtype=np.float64)
                rnorm = 0.0
                iters = 1
                eval_count = 1
                jac_count = 0
            elif solver == "fsolve":
                state, fluxes, rnorm, eval_count, jac_count = self._fsolve_step(
                    previous, step_index
                )
                iters = max(
                    1, min(eval_count, int(self.solver_opts.get("resnorm_maxiter", 50)))
                )
            elif solver == "numba_newton":
                state, fluxes, rnorm, iters, jac_count = self._newton_step(
                    previous, step_index
                )
                eval_count = max(1, iters)
            elif solver == "heun":
                state, fluxes, rnorm, iters, jac_count = self._heun_step(
                    previous, step_index
                )
                eval_count = 2
            else:
                raise ValueError("solver must be one of: fsolve, numba_newton, heun")

            self.stores[step_index, :] = state
            self.fluxes[step_index, :] = fluxes * float(self.runtime_context.delta_t)

            self.runtime_context.stores = self.stores
            self.runtime_context.fluxes = self.fluxes

            resnorm[step_index] = float(rnorm)
            iteration_count[step_index] = int(iters)
            nfev[step_index] = int(eval_count)
            njev[step_index] = int(jac_count)

            self.step()
            self.runtime_context.routing_state = self.routing_state

        self.status = 1
        self.solver_data = {
            "solver": solver_name,
            "resnorm": resnorm,
            "iterations": iteration_count,
            "nfev": nfev,
            "njev": njev,
        }
        return self

    def _resolve_group_flux(self, group_spec: Any) -> FloatArray:
        if self.fluxes is None:
            raise RuntimeError("run must be called first")
        if isinstance(group_spec, int):
            index = abs(group_spec) - 1
            series = np.asarray(self.fluxes[:, index], dtype=np.float64)
            return -series if group_spec < 0 else series
        if isinstance(group_spec, (list, tuple)):
            out = np.zeros(self.fluxes.shape[0], dtype=np.float64)
            for item in group_spec:
                out = out + self._resolve_group_flux(item)
            return out
        raise TypeError(f"unsupported flux group spec: {group_spec}")

    def get_streamflow(self) -> FloatArray:
        if "Q" not in self.flux_groups:
            raise RuntimeError("flux group 'Q' is not defined")
        return self._resolve_group_flux(self.flux_groups["Q"])

    def check_water_balance(self) -> float:
        if self.runtime_context is None or self.stores is None or self.S0 is None:
            raise RuntimeError("run must be called first")
        precip_total = float(
            np.sum(self.runtime_context.precip) * self.runtime_context.delta_t
        )
        ea_total = (
            float(np.sum(self._resolve_group_flux(self.flux_groups.get("Ea", []))))
            if "Ea" in self.flux_groups
            else 0.0
        )
        q_total = (
            float(np.sum(self.get_streamflow())) if "Q" in self.flux_groups else 0.0
        )
        final_state = np.asarray(self.stores[-1, :], dtype=np.float64)
        signs = np.asarray(self.StoreSigns, dtype=np.float64)
        delta_storage = float(np.sum((final_state - self.S0) * signs))
        routing_delta = self._routing_pending_total() - float(
            self._initial_routing_pending_total
        )
        return precip_total - ea_total - q_total - delta_storage - routing_delta

    def get_output(self, nargout: int = 3):
        flux_output = {
            key: self._resolve_group_flux(spec)
            for key, spec in self.flux_groups.items()
            if key != "Exchange"
        }
        flux_internal = {
            name: np.asarray(self.fluxes[:, idx], dtype=np.float64)
            for idx, name in enumerate(self.flux_names)
        }
        store_internal = {
            name: np.asarray(self.stores[:, idx], dtype=np.float64)
            for idx, name in enumerate(self.store_names)
        }

        if nargout == 3:
            return flux_output, flux_internal, store_internal
        if nargout == 4:
            return (
                flux_output,
                flux_internal,
                store_internal,
                self.check_water_balance(),
            )
        if nargout == 5:
            return (
                flux_output,
                flux_internal,
                store_internal,
                self.check_water_balance(),
                self.solver_data,
            )
        raise ValueError("nargout must be 3, 4, or 5")

    def get_output_dict(
        self,
        *,
        include_flux_internal: bool = False,
        include_store_internal: bool = False,
        include_solver: bool = False,
        include_execution: bool = False,
    ) -> dict[str, Any]:
        if self.fluxes is None:
            raise RuntimeError("run must be called first")

        payload: dict[str, Any] = {
            "model": self.__class__.__name__,
            "status": int(self.status),
            "flux_groups": {
                k: self._resolve_group_flux(v)
                for k, v in self.flux_groups.items()
                if k != "Exchange"
            },
            "streamflow": self.get_streamflow(),
            "water_balance_error": float(self.check_water_balance()),
        }

        if include_flux_internal:
            payload["flux_internal"] = {
                name: np.asarray(self.fluxes[:, idx], dtype=np.float64)
                for idx, name in enumerate(self.flux_names)
            }
        if include_store_internal and self.stores is not None:
            payload["store_internal"] = {
                name: np.asarray(self.stores[:, idx], dtype=np.float64)
                for idx, name in enumerate(self.store_names)
            }
        if include_solver and self.solver_data is not None:
            payload["solver_data"] = self.solver_data
        if include_execution:
            payload["execution"] = {
                "requested_target": self.compiler.requested_target,
                "resolved_target": self.compiler.target,
                "compiler_detail": self.compiler.detail,
            }

        return payload

    def _to_json_safe(self, value: Any) -> Any:
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, dict):
            return {str(k): self._to_json_safe(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [self._to_json_safe(v) for v in value]
        return value

    def to_mcp_payload(self, **kwargs: Any) -> dict[str, Any]:
        return self._to_json_safe(self.get_output_dict(**kwargs))

    def run_from_payload(
        self,
        payload: Any,
        *,
        include_flux_internal: bool = False,
        include_store_internal: bool = False,
        include_solver: bool = False,
        include_execution: bool = False,
        solver: str = "fsolve",
    ) -> dict[str, Any]:
        run_input = (
            payload
            if isinstance(payload, ModelRunInput)
            else self.validate_run_payload(payload)
        )
        self.run(config=run_input, solver=solver)
        return self.to_mcp_payload(
            include_flux_internal=include_flux_internal,
            include_store_internal=include_store_internal,
            include_solver=include_solver,
            include_execution=include_execution,
        )


class StepKernelModel(HydrologyModel):
    python_step_function: Callable[..., None] | None = None
    numba_step_function: Callable[..., None] | None = None

    def _get_kernel_bind_args(
        self,
        runtime: RuntimeContext,
    ) -> tuple[FloatArray, float, FloatArray, FloatArray, FloatArray]:
        return (
            np.asarray(runtime.theta, dtype=np.float64),
            float(runtime.delta_t),
            runtime.precip,
            runtime.pet,
            runtime.temp,
        )

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        theta, delta_t, precip, pet, temp = self._get_kernel_bind_args(runtime)

        def kernel(
            states: FloatArray,
            step_index: int,
            out_dS: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                out_dS,
                out_fluxes,
            )

        return kernel

    def _warm_step_fun(
        self,
        kernel: Callable[[FloatArray, int, FloatArray, FloatArray], None],
        runtime: RuntimeContext,
    ) -> None:
        self._warm_bound_kernel(runtime, kernel)

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        step_fun = self.python_step_function
        if step_fun is None:
            raise RuntimeError("python_step_function is not defined")
        step_fun(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        if self.python_step_function is None:
            raise RuntimeError("python_step_function is not defined")
        return self._bind_kernel(self.python_step_function, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        step_fun = self._get_or_compile_numba_step_function(
            python_step_function=self.python_step_function,
            numba_step_function=self.numba_step_function,
        )
        kernel = self._bind_kernel(step_fun, runtime)
        self._warm_bound_kernel(runtime, kernel)
        return kernel

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        return self._finite_difference_residual_jacobian(
            states,
            previous_states,
            step_index,
            diff_step=diff_step,
            compute_dS=lambda trial, index, runtime: self._compute_into(
                trial,
                step_index=index,
                ctx=runtime,
            )[0],
        )


class UnitHydroNumbaMixin:
    python_step_function: Callable[..., None] | None = None
    numba_step_function: Callable[..., None] | None = None
    numba_commit_inflow_function: Callable[..., Any] | None = None
    routing_state_type: type[Any] | None = None
    routed_numba_newton_kind: str = "auto"
    routed_numba_newton_use_predictor: bool = True
    routed_numba_newton_default_damping: float = 0.8
    routed_numba_newton_default_diff_step: float = 1e-6
    routed_numba_newton_default_maxiter: int = 50

    def compute_dS(
        self,
        s: np.ndarray,
        forcing: np.ndarray,
        params: np.ndarray,
    ) -> np.ndarray:
        del forcing, params
        state_vector = np.asarray(s, dtype=np.float64).reshape(-1)
        dS, _ = self._compute_into(state_vector, step_index=int(self.t))
        return np.asarray(dS, dtype=np.float64)

    def _require_routing_state(self, runtime: RuntimeContext | None) -> Any:
        routing = runtime.routing_state if runtime is not None else self.routing_state
        expected = self.routing_state_type
        if expected is None:
            if routing is None:
                raise RuntimeError(
                    f"{self.__class__.__name__} routing state is not initialised"
                )
            return routing
        if isinstance(routing, expected):
            return routing
        raise RuntimeError(
            f"{self.__class__.__name__} routing state is not initialised"
        )

    def _resolve_routed_kind(self, routing: Any) -> str:
        kind = self.routed_numba_newton_kind
        if kind == "auto":
            if isinstance(routing, TripleUHState):
                return "triple"
            if isinstance(routing, DoubleUHState):
                return "double"
            if isinstance(routing, SingleUHState):
                return "single"
            if hasattr(routing, "uh3_weights") and hasattr(routing, "uh3_pending"):
                return "triple"
            if hasattr(routing, "uh2_weights") and hasattr(routing, "uh2_pending"):
                return "double"
            return "single"
        return kind

    def _routing_bind_args(self, routing: Any) -> tuple[Any, ...]:
        kind = self._resolve_routed_kind(routing)
        if kind == "single":
            return routing.uh_weights, routing.uh_pending
        if kind == "double":
            return (
                routing.uh1_weights,
                routing.uh1_pending,
                routing.uh2_weights,
                routing.uh2_pending,
            )
        if kind == "triple":
            return (
                routing.uh1_weights,
                routing.uh1_pending,
                routing.uh2_weights,
                routing.uh2_pending,
                routing.uh3_weights,
                routing.uh3_pending,
            )
        raise RuntimeError(f"unsupported routed numba newton kind: {kind}")

    def _compute_into(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
        out_dS: FloatArray | None = None,
        out_fluxes: FloatArray | None = None,
    ) -> tuple[FloatArray, FloatArray]:
        runtime, theta, delta_t, precip, pet, temp = self._resolve_runtime_inputs(ctx)
        resolved_step = self._resolve_step_index(
            step_index=step_index,
            t=t,
            time_steps=int(precip.shape[0]),
            delta_t=delta_t,
        )
        state_vector = np.asarray(states, dtype=np.float64).reshape(-1)
        if out_dS is None:
            out_dS = np.empty(self.num_stores, dtype=np.float64)
        if out_fluxes is None:
            out_fluxes = np.empty(self.num_fluxes, dtype=np.float64)

        if runtime is self.runtime_context and (
            self.compiler.enabled or self._python_model_fun is not None
        ):
            self._evaluate_step_into(state_vector, resolved_step, out_dS, out_fluxes)
            return out_dS, out_fluxes

        step_fun = self.python_step_function
        if step_fun is None:
            raise RuntimeError("python_step_function is not defined")
        routing = self._require_routing_state(runtime)
        step_fun(
            state_vector,
            resolved_step,
            theta,
            delta_t,
            precip,
            pet,
            temp,
            *self._routing_bind_args(routing),
            out_dS,
            out_fluxes,
        )
        return out_dS, out_fluxes

    def residual_jacobian(
        self,
        states: Any,
        previous_states: Any,
        step_index: int,
        *,
        diff_step: float,
    ) -> FloatArray | None:
        return self._finite_difference_residual_jacobian(
            states,
            previous_states,
            step_index,
            diff_step=diff_step,
            compute_dS=lambda trial, index, runtime: self._compute_into(
                trial,
                step_index=index,
                ctx=runtime,
            )[0],
        )

    def _bind_kernel(
        self,
        step_fun: Callable[..., None],
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        routing = self._require_routing_state(runtime)
        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        routing_args = self._routing_bind_args(routing)

        def kernel(
            states: FloatArray,
            step_index: int,
            out_states: FloatArray,
            out_fluxes: FloatArray,
        ) -> None:
            step_fun(
                states,
                step_index,
                theta,
                delta_t,
                precip,
                pet,
                temp,
                *routing_args,
                out_states,
                out_fluxes,
            )

        return kernel

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None]:
        if self.python_step_function is None:
            raise RuntimeError("python_step_function is not defined")
        return self._bind_kernel(self.python_step_function, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ) -> Callable[[FloatArray, int, FloatArray, FloatArray], None] | None:
        step_fun = self._get_or_compile_numba_step_function(
            python_step_function=self.python_step_function,
            numba_step_function=self.numba_step_function,
        )
        kernel = self._bind_kernel(step_fun, runtime)
        return self._compile_bound_kernel(runtime, kernel)

    def model_fun(self, states: FloatArray) -> tuple[FloatArray, FloatArray]:
        return self._compute_into(states, step_index=self.t)

    def evaluate_fluxes(
        self,
        states: Any,
        *,
        step_index: int | None = None,
        t: float | None = None,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        _, fluxes = self._compute_into(states, step_index=step_index, t=t, ctx=ctx)
        return fluxes

    def scipy_rhs(
        self,
        t: float,
        y: Any,
        ctx: RuntimeContext | None = None,
    ) -> FloatArray:
        del t, y, ctx
        raise NotImplementedError(
            f"{self.__class__.__name__} does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and committed in step()."
        )

    def make_scipy_rhs(self, ctx: RuntimeContext | None = None):
        del ctx
        raise NotImplementedError(
            f"{self.__class__.__name__} does not provide a solve_ivp RHS because unit-hydrograph routing is discrete and history-dependent."
        )

    def _routing_inflows_from_fluxes(
        self,
        routing: Any,
        fluxes: FloatArray,
    ) -> tuple[float, ...]:
        inflow_fun = self.numba_commit_inflow_function
        if inflow_fun is None:
            raise RuntimeError("numba_commit_inflow_function is not defined")

        inflows = inflow_fun(np.asarray(fluxes, dtype=np.float64))
        kind = self._resolve_routed_kind(routing)
        if kind == "single":
            return (float(inflows),)

        if isinstance(inflows, tuple):
            return tuple(float(value) for value in inflows)

        values = np.asarray(inflows, dtype=np.float64).reshape(-1)
        return tuple(float(value) for value in values)

    def step(self) -> None:
        if self.fluxes is None:
            raise RuntimeError("model fluxes are not initialised")

        routing = self._require_routing_state(self.runtime_context)
        inflows = self._routing_inflows_from_fluxes(routing, self.fluxes[self.t])
        kind = self._resolve_routed_kind(routing)

        if kind == "single":
            update_uh_inplace(routing.uh_weights, routing.uh_pending, inflows[0])
        elif kind == "double":
            update_uh_inplace(routing.uh1_weights, routing.uh1_pending, inflows[0])
            update_uh_inplace(routing.uh2_weights, routing.uh2_pending, inflows[1])
        elif kind == "triple":
            update_uh_inplace(routing.uh1_weights, routing.uh1_pending, inflows[0])
            update_uh_inplace(routing.uh2_weights, routing.uh2_pending, inflows[1])
            update_uh_inplace(routing.uh3_weights, routing.uh3_pending, inflows[2])
        else:
            raise RuntimeError(f"unsupported routed numba newton kind: {kind}")

        self.routing_state = routing
        self.uhs = routing.as_legacy_uhs()

    def _supports_routed_numba_newton(self) -> bool:
        return (
            self.numba_step_function is not None
            and self.numba_commit_inflow_function is not None
        )

    def _build_routed_numba_newton_step_kernel(
        self,
        runtime: RuntimeContext,
    ) -> Callable[..., None]:
        if (
            self._routed_numba_newton_step_kernel is not None
            and self._routed_numba_newton_step_kernel_runtime is runtime
        ):
            return self._routed_numba_newton_step_kernel

        theta = np.asarray(runtime.theta, dtype=np.float64)
        delta_t = float(runtime.delta_t)
        precip = runtime.precip
        pet = runtime.pet
        temp = runtime.temp
        routing = self._require_routing_state(runtime)
        kind = self._resolve_routed_kind(routing)
        step_fun = self._get_or_compile_numba_step_function(
            python_step_function=self.python_step_function,
            numba_step_function=self.numba_step_function,
        )

        if kind == "single":
            uh_weights = routing.uh_weights

            def kernel(
                states: FloatArray,
                step_index: int,
                uh_pending: FloatArray,
                out_dS: FloatArray,
                out_fluxes: FloatArray,
            ) -> None:
                step_fun(
                    states,
                    step_index,
                    theta,
                    delta_t,
                    precip,
                    pet,
                    temp,
                    uh_weights,
                    uh_pending,
                    out_dS,
                    out_fluxes,
                )
        elif kind == "double":
            uh1_weights = routing.uh1_weights
            uh2_weights = routing.uh2_weights

            def kernel(
                states: FloatArray,
                step_index: int,
                uh1_pending: FloatArray,
                uh2_pending: FloatArray,
                out_dS: FloatArray,
                out_fluxes: FloatArray,
            ) -> None:
                step_fun(
                    states,
                    step_index,
                    theta,
                    delta_t,
                    precip,
                    pet,
                    temp,
                    uh1_weights,
                    uh1_pending,
                    uh2_weights,
                    uh2_pending,
                    out_dS,
                    out_fluxes,
                )
        elif kind == "triple":
            uh1_weights = routing.uh1_weights
            uh2_weights = routing.uh2_weights
            uh3_weights = routing.uh3_weights

            def kernel(
                states: FloatArray,
                step_index: int,
                uh1_pending: FloatArray,
                uh2_pending: FloatArray,
                uh3_pending: FloatArray,
                out_dS: FloatArray,
                out_fluxes: FloatArray,
            ) -> None:
                step_fun(
                    states,
                    step_index,
                    theta,
                    delta_t,
                    precip,
                    pet,
                    temp,
                    uh1_weights,
                    uh1_pending,
                    uh2_weights,
                    uh2_pending,
                    uh3_weights,
                    uh3_pending,
                    out_dS,
                    out_fluxes,
                )
        else:
            raise RuntimeError(f"unsupported routed numba newton kind: {kind}")

        kernel = ensure_njit(kernel, cache=False)
        warm_dS = np.empty(int(self.num_stores), dtype=np.float64)
        warm_fluxes = np.empty(int(self.num_fluxes), dtype=np.float64)
        if kind == "single":
            kernel(
                np.asarray(runtime.S0, dtype=np.float64),
                0,
                routing.uh_pending,
                warm_dS,
                warm_fluxes,
            )
        elif kind == "double":
            kernel(
                np.asarray(runtime.S0, dtype=np.float64),
                0,
                routing.uh1_pending,
                routing.uh2_pending,
                warm_dS,
                warm_fluxes,
            )
        else:
            kernel(
                np.asarray(runtime.S0, dtype=np.float64),
                0,
                routing.uh1_pending,
                routing.uh2_pending,
                routing.uh3_pending,
                warm_dS,
                warm_fluxes,
            )
        self._routed_numba_newton_step_kernel = kernel
        self._routed_numba_newton_step_kernel_runtime = runtime
        return kernel

    def _run_routed_numba_newton(self, runtime: RuntimeContext) -> None:
        if runtime is None or self.stores is None or self.fluxes is None:
            raise RuntimeError("runtime context is not initialised")

        step_kernel = self._build_routed_numba_newton_step_kernel(runtime)
        pattern = np.asarray(self.jacob_pattern, dtype=np.int64)
        if pattern.ndim == 1:
            pattern = pattern.reshape(1, -1)

        inflow_kernel = self.numba_commit_inflow_function
        if inflow_kernel is None:
            raise RuntimeError("numba_commit_inflow_function is not defined")

        routing = runtime.routing_state
        if routing is None:
            raise RuntimeError("routing state is not initialised")

        kind = self.routed_numba_newton_kind
        if kind == "auto":
            if hasattr(routing, "uh3_weights") and hasattr(routing, "uh3_pending"):
                kind = "triple"
            elif hasattr(routing, "uh2_weights") and hasattr(routing, "uh2_pending"):
                kind = "double"
            else:
                kind = "single"

        common_args = (
            step_kernel,
            inflow_kernel,
            runtime.stores,
            runtime.fluxes,
            np.asarray(runtime.S0, dtype=np.float64),
            float(runtime.delta_t),
            np.asarray(runtime.store_min, dtype=np.float64),
            np.asarray(runtime.store_max, dtype=np.float64),
            float(self.solver_opts.get("resnorm_tolerance", 1e-8)),
            int(
                self.solver_opts.get(
                    "resnorm_maxiter", self.routed_numba_newton_default_maxiter
                )
            ),
            float(
                self.solver_opts.get(
                    "diff_step", self.routed_numba_newton_default_diff_step
                )
            ),
            float(
                self.solver_opts.get(
                    "damping", self.routed_numba_newton_default_damping
                )
            ),
            pattern,
            bool(self.routed_numba_newton_use_predictor),
        )

        if kind == "triple":
            stores, fluxes, resnorm, iterations, nfev, njev = (
                run_routed_numba_newton_kernel_triple(
                    *common_args,
                    routing.uh1_weights,
                    routing.uh1_pending,
                    routing.uh2_weights,
                    routing.uh2_pending,
                    routing.uh3_weights,
                    routing.uh3_pending,
                )
            )
        elif kind == "double":
            stores, fluxes, resnorm, iterations, nfev, njev = (
                run_routed_numba_newton_kernel_double(
                    *common_args,
                    routing.uh1_weights,
                    routing.uh1_pending,
                    routing.uh2_weights,
                    routing.uh2_pending,
                )
            )
        elif kind == "single":
            stores, fluxes, resnorm, iterations, nfev, njev = (
                run_routed_numba_newton_kernel_single(
                    *common_args,
                    routing.uh_weights,
                    routing.uh_pending,
                )
            )
        else:
            raise RuntimeError("unsupported routing state for routed numba newton")

        self.stores = stores
        self.fluxes = fluxes
        runtime.stores = stores
        runtime.fluxes = fluxes
        self.status = 1
        self.t = int(runtime.precip.shape[0]) - 1
        self.solver_data = {
            "solver": np.full(
                int(runtime.precip.shape[0]), "numba_newton", dtype=object
            ),
            "resnorm": np.asarray(resnorm, dtype=np.float64),
            "iterations": np.asarray(iterations, dtype=np.int64),
            "nfev": np.asarray(nfev, dtype=np.int64),
            "njev": np.asarray(njev, dtype=np.int64),
        }
