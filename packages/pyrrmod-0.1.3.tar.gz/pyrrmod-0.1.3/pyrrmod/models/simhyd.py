from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import (
    baseflow_1,
    evap_1,
    evap_2,
    infiltration_1,
    interception_1,
    interflow_1,
    recharge_1,
    saturation_1,
)
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _simhyd_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    insc = float(theta[0])
    coeff = float(theta[1])
    sq = float(theta[2])
    smsc = float(theta[3])
    sub = float(theta[4])
    crak = float(theta[5])
    k = float(theta[6])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_Ei = evap_1(S1, Ep, delta_t)
    flux_EXC = interception_1(P, S1, insc)
    flux_INF = infiltration_1(coeff, sq, S2, smsc, flux_EXC)
    flux_INT = interflow_1(sub, S2, smsc, flux_INF)
    flux_REC = recharge_1(crak, S2, smsc, flux_INF - flux_INT)
    flux_Et = evap_2(10, S2, smsc, Ep, delta_t)
    flux_GWF = saturation_1(flux_INF - flux_INT - flux_REC, S2, smsc)
    flux_BAS = baseflow_1(k, S3)
    flux_SRUN = flux_EXC - flux_INF
    flux_Qt = flux_SRUN + flux_INT + flux_BAS
    flux_SMF = flux_INF - flux_INT - flux_REC

    out_dS[0] = P - flux_Ei - flux_EXC
    out_dS[1] = flux_SMF - flux_Et - flux_GWF
    out_dS[2] = flux_REC + flux_GWF - flux_BAS

    out_fluxes[0] = flux_Ei
    out_fluxes[1] = flux_EXC
    out_fluxes[2] = flux_INF
    out_fluxes[3] = flux_INT
    out_fluxes[4] = flux_REC
    out_fluxes[5] = flux_Et
    out_fluxes[6] = flux_GWF
    out_fluxes[7] = flux_BAS
    out_fluxes[8] = flux_SRUN
    out_fluxes[9] = flux_Qt


class simhyd(StepKernelModel):
    python_step_function = staticmethod(_simhyd_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 3
        self.num_fluxes = 10
        self.num_params = 7
        self.jacob_pattern = np.array([[1, 0, 0], [1, 1, 0], [1, 1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[0, 5], [0, 600], [0, 15], [1, 2000], [0, 1], [0, 1], [0, 1]],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3"]
        self.flux_names = [
            "Ei",
            "EXC",
            "INF",
            "INT",
            "REC",
            "Et",
            "GWF",
            "BAS",
            "SRUN",
            "Qt",
        ]
        self.flux_groups = {"Ea": [1, 6], "Q": 10}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
