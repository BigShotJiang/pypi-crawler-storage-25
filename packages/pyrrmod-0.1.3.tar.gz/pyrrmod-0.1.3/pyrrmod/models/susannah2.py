from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import evap_7, excess_1, interflow_3, saturation_1
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _susannah2_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    sb = float(theta[0])
    phi = float(theta[1])
    fc = float(theta[2])
    r = float(theta[3])
    c = float(theta[4])
    d = float(theta[5])

    S1 = float(states[0])
    S2 = float(states[1])

    P = float(precip[step_index])
    Ep = float(pet[step_index])
    recharge_limit = (sb - S2) * fc / phi

    flux_eus = evap_7(S1, sb, Ep, delta_t)
    flux_rg = saturation_1(P, S1, recharge_limit)
    flux_se = excess_1(S1, recharge_limit, delta_t)
    flux_esat = evap_7(S2, sb, Ep, delta_t)
    flux_qse = saturation_1(flux_rg + flux_se, S2, sb)
    flux_qss = interflow_3((1.0 - r) * c, d, S2, delta_t)
    flux_qr = interflow_3(r * c, d, S2, delta_t)
    flux_qt = flux_qse + flux_qss

    out_dS[0] = P - flux_eus - flux_rg - flux_se
    out_dS[1] = flux_rg + flux_se - flux_esat - flux_qse - flux_qss - flux_qr

    out_fluxes[0] = flux_eus
    out_fluxes[1] = flux_rg
    out_fluxes[2] = flux_se
    out_fluxes[3] = flux_esat
    out_fluxes[4] = flux_qse
    out_fluxes[5] = flux_qss
    out_fluxes[6] = flux_qr
    out_fluxes[7] = flux_qt


class susannah2(StepKernelModel):
    python_step_function = staticmethod(_susannah2_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 2
        self.num_fluxes = 8
        self.num_params = 6
        self.jacob_pattern = np.array([[1, 1], [1, 1]], dtype=int)
        self.par_ranges = np.array(
            [[1, 2000], [0.05, 0.95], [0.05, 0.95], [0, 1], [0, 1], [1, 5]],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2"]
        self.flux_names = ["eus", "rg", "se", "esat", "qse", "qss", "qr", "qt"]
        self.flux_groups = {"Ea": [1, 4], "Q": 8, "GWsink": 7}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
