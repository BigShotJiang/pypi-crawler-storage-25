from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import evap_7, saturation_1
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _collie1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    S1max = float(theta[0])
    S1 = float(states[0])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ea = evap_7(S1, S1max, Ep, delta_t)
    flux_qse = saturation_1(P, S1, S1max)

    out_dS[0] = P - flux_ea - flux_qse
    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_qse


class collie1(StepKernelModel):
    python_step_function = staticmethod(_collie1_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 1
        self.num_fluxes = 2
        self.num_params = 1
        self.jacob_pattern = np.array([1], dtype=int)
        self.par_ranges = np.array([[1, 2000]], dtype=np.float64)
        self.store_names = ["S1"]
        self.flux_names = ["ea", "qse"]
        self.flux_groups = {"Ea": 1, "Q": 2}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
