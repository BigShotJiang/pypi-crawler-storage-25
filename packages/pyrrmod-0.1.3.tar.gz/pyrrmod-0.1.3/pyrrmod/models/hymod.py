from __future__ import annotations

from typing import Any

import numpy as np

from pyrrmod.fluxes import baseflow_1, evap_7, saturation_2, split_1
from pyrrmod.models.base import FloatArray, RuntimeContext, StepKernelModel


def _hymod_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    smax = float(theta[0])
    b = float(theta[1])
    a = float(theta[2])
    kf = float(theta[3])
    ks = float(theta[4])

    S1 = float(states[0])
    S2 = float(states[1])
    S3 = float(states[2])
    S4 = float(states[3])
    S5 = float(states[4])

    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_ea = evap_7(S1, smax, Ep, delta_t)
    flux_pe = saturation_2(S1, smax, b, P)
    flux_pf = split_1(a, flux_pe)
    flux_ps = split_1(1.0 - a, flux_pe)
    flux_qf1 = baseflow_1(kf, S2)
    flux_qf2 = baseflow_1(kf, S3)
    flux_qf3 = baseflow_1(kf, S4)
    flux_qs = baseflow_1(ks, S5)

    out_dS[0] = P - flux_ea - flux_pe
    out_dS[1] = flux_pf - flux_qf1
    out_dS[2] = flux_qf1 - flux_qf2
    out_dS[3] = flux_qf2 - flux_qf3
    out_dS[4] = flux_ps - flux_qs

    out_fluxes[0] = flux_ea
    out_fluxes[1] = flux_pe
    out_fluxes[2] = flux_pf
    out_fluxes[3] = flux_ps
    out_fluxes[4] = flux_qf1
    out_fluxes[5] = flux_qf2
    out_fluxes[6] = flux_qf3
    out_fluxes[7] = flux_qs


class hymod(StepKernelModel):
    python_step_function = staticmethod(_hymod_compute_step)

    def __init__(self) -> None:
        super().__init__()
        self.num_stores = 5
        self.num_fluxes = 8
        self.num_params = 5
        self.jacob_pattern = np.array(
            [
                [1, 0, 0, 0, 0],
                [1, 1, 0, 0, 0],
                [0, 1, 1, 0, 0],
                [0, 0, 1, 1, 0],
                [1, 0, 0, 0, 1],
            ],
            dtype=int,
        )
        self.par_ranges = np.array(
            [[1, 2000], [0, 10], [0, 1], [0, 1], [0, 1]],
            dtype=np.float64,
        )
        self.store_names = ["S1", "S2", "S3", "S4", "S5"]
        self.flux_names = ["ea", "pe", "pf", "ps", "qf1", "qf2", "qf3", "qs"]
        self.flux_groups = {"Ea": 1, "Q": [7, 8]}

    def init(self) -> None:
        pass


    def step(self) -> None:
        pass
