from __future__ import annotations

from pathlib import Path
import sys
import warnings

import numpy as np
import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.auxiliary.unit_hydro import update_uh_inplace, update_uh_inplace_nb
from pyrrmod.models import (
    alpine1,
    collie1,
    flexb,
    flexi,
    flexis,
    gr4j,
    hbv,
    hillslope,
    ihacres,
    newzealand2,
    plateau,
    smar,
)


DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"


def _load_forcing(n_steps: int) -> dict[str, np.ndarray]:
    data = np.loadtxt(DATA_FILE, delimiter=",", skiprows=1, max_rows=n_steps)
    data = np.atleast_2d(data)
    return {
        "precip": np.asarray(data[:, 0], dtype=np.float64),
        "temp": np.asarray(data[:, 1], dtype=np.float64),
        "pet": np.asarray(data[:, 2], dtype=np.float64),
    }


def _alpine1_config(n_steps: int = 120) -> dict[str, object]:
    forcing = _load_forcing(n_steps)
    return {
        "theta": [0.0, 3.0, 500.0, 0.05],
        "delta_t": 1.0,
        "initial_stores": [50.0, 120.0],
        "climate": forcing,
        "compile_target": "numba",
    }


def _gr4j_config(
    n_steps: int = 120, *, compile_target: str = "numba"
) -> dict[str, object]:
    forcing = _load_forcing(n_steps)
    return {
        "theta": [500.0, 1.0, 100.0, 2.0],
        "delta_t": 1.0,
        "initial_stores": [250.0, 50.0],
        "climate": forcing,
        "compile_target": compile_target,
    }


def _auto_routed_config(model_cls, n_steps: int = 40) -> dict[str, object]:
    forcing = _load_forcing(n_steps)
    probe = model_cls()
    theta = np.mean(np.asarray(probe.par_ranges, dtype=np.float64), axis=1)
    probe.theta = np.asarray(theta, dtype=np.float64)
    probe.delta_t = 1.0
    probe.S0 = np.ones(probe.num_stores, dtype=np.float64)
    probe.climate_arrays = type("ClimateShim", (), forcing)()
    probe._reset_store_bounds()
    if probe.StoreSigns is None or int(probe.StoreSigns.shape[0]) != int(
        probe.num_stores
    ):
        probe.StoreSigns = np.ones(probe.num_stores, dtype=np.float64)
    probe.init()
    s0 = np.where(
        np.isfinite(np.asarray(probe.store_max, dtype=np.float64)),
        np.maximum(1.0, 0.5 * np.asarray(probe.store_max, dtype=np.float64)),
        10.0,
    )
    return {
        "theta": theta.tolist(),
        "delta_t": 1.0,
        "initial_stores": s0.tolist(),
        "climate": forcing,
        "compile_target": "numba",
    }


def test_numba_newton_matches_fsolve_for_alpine1() -> None:
    config = _alpine1_config(100)

    reference = alpine1()
    reference.run(config=config, solver="fsolve")

    candidate = alpine1()
    candidate.run(config=config, solver="numba_newton")

    np.testing.assert_allclose(reference.stores, candidate.stores, atol=1e-5, rtol=0.0)
    np.testing.assert_allclose(reference.fluxes, candidate.fluxes, atol=1e-5, rtol=0.0)
    assert np.all(candidate.solver_data["solver"] == "numba_newton")


def test_heun_requires_compute_dS_when_missing() -> None:
    forcing = _load_forcing(20)
    model = collie1()
    model.configure(
        theta=[500.0],
        delta_t=1.0,
        S0=[100.0],
        input_climate=forcing,
    )

    with pytest.raises(NotImplementedError, match="compute_dS"):
        model.run(solver="heun")


def test_heun_executes_for_model_with_compute_dS() -> None:
    config = _alpine1_config(50)
    model = alpine1()
    model.run(config=config, solver="heun")

    assert np.all(model.solver_data["solver"] == "heun")
    assert np.all(np.isfinite(model.stores))
    assert np.all(np.isfinite(model.fluxes))


def test_numba_newton_executes_for_hbv() -> None:
    forcing = _load_forcing(20)
    model = hbv()
    config = {
        "theta": [
            0.0,
            1.0,
            0.0,
            0.1,
            3.0,
            0.1,
            0.1,
            500.0,
            0.5,
            1.0,
            0.05,
            0.5,
            1.0,
            0.01,
            2.0,
        ],
        "delta_t": 1.0,
        "initial_stores": [120.0, 80.0, 30.0, 20.0, 10.0],
        "climate": forcing,
        "compile_target": "numba",
    }

    model.run(config=config, solver="numba_newton")

    assert np.all(model.solver_data["solver"] == "numba_newton")
    assert np.all(np.isfinite(model.stores))
    assert np.all(np.isfinite(model.fluxes))
    assert np.all(np.isfinite(model.get_streamflow()))


def test_unit_hydro_numba_update_matches_python() -> None:
    weights = np.asarray([0.2, 0.5, 0.3], dtype=np.float64)
    inflows = [0.0, 1.5, 2.0, 0.3]

    pending_python = np.asarray([0.1, 0.4, 0.2], dtype=np.float64)
    pending_numba = pending_python.copy()

    for inflow in inflows:
        update_uh_inplace(weights, pending_python, inflow)
        update_uh_inplace_nb(weights, pending_numba, inflow)

    np.testing.assert_allclose(pending_numba, pending_python, atol=0.0, rtol=0.0)


def test_gr4j_default_matches_fsolve_and_preserves_water_balance() -> None:
    pytest.importorskip("numba")
    config = _gr4j_config(180)

    reference = gr4j()
    reference.run(config=config, solver="fsolve")

    candidate = gr4j()
    candidate.run(config=config, solver="default")

    np.testing.assert_allclose(reference.stores, candidate.stores, atol=1e-10, rtol=0.0)
    np.testing.assert_allclose(reference.fluxes, candidate.fluxes, atol=1e-10, rtol=0.0)
    np.testing.assert_allclose(
        reference.get_streamflow(),
        candidate.get_streamflow(),
        atol=1e-10,
        rtol=0.0,
    )
    assert np.all(candidate.solver_data["solver"] == "numba_full")
    assert (
        abs(reference.check_water_balance() - candidate.check_water_balance()) < 1e-10
    )


def test_gr4j_numba_newton_matches_scipy_fsolve() -> None:
    pytest.importorskip("numba")
    config = _gr4j_config(180)

    reference = gr4j()
    reference.run(config=config, solver="scipy_fsolve")

    candidate = gr4j()
    candidate.run(config=config, solver="numba_newton")

    np.testing.assert_allclose(
        reference.get_streamflow(),
        candidate.get_streamflow(),
        atol=1e-7,
        rtol=0.0,
    )
    np.testing.assert_allclose(reference.stores, candidate.stores, atol=1e-6, rtol=0.0)
    assert np.all(candidate.solver_data["solver"] == "numba_newton")
    assert abs(reference.check_water_balance() - candidate.check_water_balance()) < 1e-5


def test_gr4j_heun_runs_and_produces_finite_outputs() -> None:
    pytest.importorskip("numba")
    config = _gr4j_config(120)

    model = gr4j()
    model.run(config=config, solver="heun")

    assert np.all(model.solver_data["solver"] == "heun")
    assert np.all(np.isfinite(model.stores))
    assert np.all(np.isfinite(model.fluxes))
    assert np.all(np.isfinite(model.get_streamflow()))


@pytest.mark.parametrize(
    ("model_cls", "expected_solver"),
    [
        (smar, "numba_newton"),
        (plateau, "numba_newton"),
        (newzealand2, "fsolve"),
        (hillslope, "numba_newton"),
        (hbv, "numba_newton"),
        (flexb, "numba_newton"),
        (flexi, "numba_newton"),
        (flexis, "numba_newton"),
        (ihacres, "numba_newton"),
    ],
)
def test_routed_models_numba_newton_smoke(model_cls, expected_solver) -> None:
    pytest.importorskip("numba")
    config = _auto_routed_config(model_cls, 30)

    model = model_cls()
    model.run(config=config, solver="numba_newton")

    assert np.all(model.solver_data["solver"] == expected_solver)
    assert np.all(np.isfinite(model.stores))
    assert np.all(np.isfinite(model.fluxes))
    assert np.all(np.isfinite(model.get_streamflow()))
