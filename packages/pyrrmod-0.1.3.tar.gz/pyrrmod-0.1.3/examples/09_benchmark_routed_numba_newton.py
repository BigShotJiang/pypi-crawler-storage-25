from __future__ import annotations

import argparse
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import (
    ClimateInput,
    flexb,
    flexi,
    flexis,
    gr4j,
    hbv,
    hillslope,
    ihacres,
    newzealand2,
    plateau,
    smar,
)


ROUTED_MODELS = [
    smar,
    plateau,
    newzealand2,
    hillslope,
    hbv,
    flexb,
    flexi,
    flexis,
    ihacres,
    gr4j,
]


@dataclass(slots=True)
class BenchmarkResult:
    model: str
    baseline_solver: str
    candidate_solver: str
    candidate_actual_solver: str
    baseline_avg_s: float
    candidate_avg_s: float
    speedup: float
    max_q_diff: float
    max_store_diff: float
    water_balance_diff: float


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Benchmark routed numba_newton against baseline solvers.",
    )
    parser.add_argument(
        "--data-file",
        type=Path,
        default=PROJECT_ROOT / "data" / "03604000.csv",
        help="CSV file with precip,temp,pet columns.",
    )
    parser.add_argument(
        "--steps",
        type=int,
        default=120,
        help="Number of forcing rows to load.",
    )
    parser.add_argument(
        "--repeats",
        type=int,
        default=3,
        help="Number of warm timing repeats per solver.",
    )
    return parser.parse_args()


def load_forcing(data_file: Path, n_steps: int) -> dict[str, np.ndarray]:
    data = np.loadtxt(data_file, delimiter=",", skiprows=1, max_rows=n_steps)
    data = np.atleast_2d(data)
    climate = ClimateInput.model_validate(
        {
            "precip": np.asarray(data[:, 0], dtype=np.float64),
            "temp": np.asarray(data[:, 1], dtype=np.float64),
            "pet": np.asarray(data[:, 2], dtype=np.float64),
        }
    )
    return {
        "precip": np.asarray(climate.precip, dtype=np.float64),
        "temp": np.asarray(climate.temp, dtype=np.float64),
        "pet": np.asarray(climate.pet, dtype=np.float64),
    }


def build_auto_config(model_cls, forcing: dict[str, np.ndarray]) -> dict[str, object]:
    probe = model_cls()
    theta = np.mean(np.asarray(probe.par_ranges, dtype=np.float64), axis=1)
    probe.theta = np.asarray(theta, dtype=np.float64)
    probe.delta_t = 1.0
    probe.S0 = np.ones(probe.num_stores, dtype=np.float64)
    probe.climate_arrays = type("ClimateShim", (), forcing)()
    probe._reset_store_bounds()
    if probe.StoreSigns is None or int(probe.StoreSigns.shape[0]) != int(
        probe.num_stores
    ):
        probe.StoreSigns = np.ones(probe.num_stores, dtype=np.float64)
    probe.init()

    store_max = np.asarray(probe.store_max, dtype=np.float64)
    s0 = np.where(np.isfinite(store_max), np.maximum(1.0, 0.5 * store_max), 10.0)
    return {
        "theta": theta.tolist(),
        "delta_t": 1.0,
        "initial_stores": s0.tolist(),
        "climate": forcing,
        "compile_target": "numba",
    }


def run_once(model_cls, config: dict[str, object], solver: str):
    model = model_cls()
    start = time.perf_counter()
    model.run(config=config, solver=solver)
    elapsed = time.perf_counter() - start
    return model, elapsed


def capture_reset_state(model) -> dict[str, object]:
    routing = model.routing_state
    pending_snapshots: dict[str, np.ndarray] = {}
    if routing is not None:
        for name in (
            "uh_pending",
            "uh1_pending",
            "uh2_pending",
            "uh3_pending",
            "q9_pending",
            "q1_pending",
        ):
            if hasattr(routing, name):
                pending_snapshots[name] = np.asarray(getattr(routing, name)).copy()
    return {"pending": pending_snapshots}


def reset_model(model, snapshot: dict[str, object]) -> None:
    if model.stores is not None:
        model.stores.fill(0.0)
    if model.fluxes is not None:
        model.fluxes.fill(0.0)
    model.status = 0
    model.t = 0
    model.solver_data = None

    routing = model.routing_state
    if routing is not None:
        for name, values in snapshot["pending"].items():
            getattr(routing, name)[:] = values
        if hasattr(routing, "as_legacy_uhs"):
            model.uhs = routing.as_legacy_uhs()
    if model.runtime_context is not None:
        model.runtime_context.stores = model.stores
        model.runtime_context.fluxes = model.fluxes
        model.runtime_context.routing_state = model.routing_state


def benchmark_solver(model_cls, config: dict[str, object], solver: str, repeats: int):
    model = model_cls()
    model.configure(config=config)
    snapshot = capture_reset_state(model)

    reset_model(model, snapshot)
    model.run(solver=solver)

    timings: list[float] = []
    for _ in range(repeats):
        reset_model(model, snapshot)
        start = time.perf_counter()
        model.run(solver=solver)
        elapsed = time.perf_counter() - start
        timings.append(elapsed)
    return model, float(sum(timings) / len(timings))


def compare_model(
    model_cls, forcing: dict[str, np.ndarray], repeats: int
) -> BenchmarkResult:
    config = build_auto_config(model_cls, forcing)
    baseline_solver = "scipy_fsolve" if model_cls is gr4j else "fsolve"
    candidate_solver = "numba_newton"

    baseline_model, baseline_avg_s = benchmark_solver(
        model_cls,
        config,
        baseline_solver,
        repeats,
    )
    candidate_model, candidate_avg_s = benchmark_solver(
        model_cls,
        config,
        candidate_solver,
        repeats,
    )

    return BenchmarkResult(
        model=model_cls.__name__,
        baseline_solver=baseline_solver,
        candidate_solver=candidate_solver,
        candidate_actual_solver=str(candidate_model.solver_data["solver"][0]),
        baseline_avg_s=baseline_avg_s,
        candidate_avg_s=candidate_avg_s,
        speedup=(baseline_avg_s / candidate_avg_s) if candidate_avg_s > 0 else np.inf,
        max_q_diff=float(
            np.max(
                np.abs(
                    baseline_model.get_streamflow() - candidate_model.get_streamflow()
                )
            )
        ),
        max_store_diff=float(
            np.max(
                np.abs(
                    np.asarray(baseline_model.stores)
                    - np.asarray(candidate_model.stores)
                )
            )
        ),
        water_balance_diff=float(
            abs(
                float(baseline_model.check_water_balance())
                - float(candidate_model.check_water_balance())
            )
        ),
    )


def main() -> None:
    args = parse_args()
    forcing = load_forcing(args.data_file, args.steps)
    results = [
        compare_model(model_cls, forcing, args.repeats) for model_cls in ROUTED_MODELS
    ]

    print(
        "model,baseline_solver,candidate_solver,candidate_actual_solver,baseline_avg_s,candidate_avg_s,speedup,max_q_diff,max_store_diff,water_balance_diff"
    )
    for result in results:
        print(
            f"{result.model},{result.baseline_solver},{result.candidate_solver},{result.candidate_actual_solver},"
            f"{result.baseline_avg_s:.6f},{result.candidate_avg_s:.6f},{result.speedup:.3f},"
            f"{result.max_q_diff:.6e},{result.max_store_diff:.6e},{result.water_balance_diff:.6e}"
        )


if __name__ == "__main__":
    main()
