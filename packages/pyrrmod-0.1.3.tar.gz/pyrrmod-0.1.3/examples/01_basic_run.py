from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import ModelRunInput, collie1


def main() -> None:
    n_steps = 120
    time = np.arange(n_steps, dtype=np.float64)

    run_input = ModelRunInput(
        theta=[500.0],
        delta_t=1.0,
        S0=[120.0],
        climate={
            "precip": 5.0 + 3.0 * np.sin(time / 8.0),
            "pet": np.full(n_steps, 2.0),
            "temp": 15.0 + 5.0 * np.cos(time / 14.0),
        },
    )

    model = collie1()
    model.run(config=run_input)

    q_sim = model.get_streamflow()
    print(f"model={model.model_name} timesteps={q_sim.size}")
    print(f"Q first 5 = {q_sim[:5]}")
    print(f"water balance error = {model.check_water_balance():.6f}")


if __name__ == "__main__":
    main()
