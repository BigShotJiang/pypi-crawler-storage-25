from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from types import MethodType
from typing import Any

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import alpine1, xinanjiang


DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Benchmark SciPy solver overhead under Python/Numba kernels with "
            "optional Jacobian and least_squares methods."
        )
    )
    parser.add_argument(
        "--model",
        choices=("alpine1", "xinanjiang"),
        default="alpine1",
        help="Model to benchmark.",
    )
    parser.add_argument(
        "--steps",
        type=int,
        default=0,
        help="Number of forcing steps. 0 means full dataset.",
    )
    parser.add_argument(
        "--resnorm-tolerance",
        type=float,
        default=0.1,
        help="Residual tolerance scaling passed to solver options.",
    )
    parser.add_argument(
        "--resnorm-maxiter",
        type=int,
        default=6,
        help="Maximum restart attempts in rerun_solver.",
    )
    return parser.parse_args()


def load_forcing(n_steps: int) -> dict[str, np.ndarray]:
    kwargs: dict[str, Any] = {"delimiter": ",", "skiprows": 1}
    if n_steps > 0:
        kwargs["max_rows"] = n_steps
    data = np.loadtxt(DATA_FILE, **kwargs)
    return {
        "precip": np.asarray(data[:, 0], dtype=np.float64),
        "temp": np.asarray(data[:, 1], dtype=np.float64),
        "pet": np.asarray(data[:, 2], dtype=np.float64),
    }


def model_baseline(
    model_name: str,
) -> tuple[type[alpine1] | type[xinanjiang], list[float], list[float]]:
    if model_name == "alpine1":
        return alpine1, [0.0, 3.0, 500.0, 0.05], [50.0, 120.0]
    return (
        xinanjiang,
        [
            0.30,
            0.10,
            2.00,
            500.0,
            0.50,
            0.50,
            0.30,
            1.50,
            0.05,
            0.03,
            0.10,
            0.05,
        ],
        [120.0, 80.0, 30.0, 20.0],
    )


def force_solver_backend(model: alpine1 | xinanjiang, solver_backend: str) -> None:
    if solver_backend == "default":
        return

    def solve_stores_with_scipy(self, previous_states):
        previous = self._as_state_vector(previous_states)
        current_states, residuals, _, iterations = self.rerun_solver(
            solver_backend,
            previous,
            previous,
        )
        residual_array = self._as_state_vector(residuals)
        resnorm = float(np.sum(residual_array**2))
        return current_states, resnorm, solver_backend, int(iterations)

    model.solve_stores = MethodType(solve_stores_with_scipy, model)


def build_config(
    *,
    model_name: str,
    forcing: dict[str, np.ndarray],
    compile_target: str,
    resnorm_tolerance: float,
    resnorm_maxiter: int,
    fsolve_use_jacobian: bool,
    lsq_use_jacobian: bool,
    lsq_method: str,
    allow_unbounded_lm: bool,
) -> dict[str, object]:
    _, theta, initial_stores = model_baseline(model_name)
    return {
        "theta": theta,
        "delta_t": 1.0,
        "initial_stores": initial_stores,
        "climate": {
            "precip": forcing["precip"],
            "temp": forcing["temp"],
            "pet": forcing["pet"],
        },
        "solver_options": {
            "resnorm_tolerance": resnorm_tolerance,
            "resnorm_maxiter": resnorm_maxiter,
            "fsolve": {
                "use_jacobian": fsolve_use_jacobian,
                "jacobian_diff_step": 1e-6,
            },
            "lsqnonlin": {
                "use_jacobian": lsq_use_jacobian,
                "jacobian_diff_step": 1e-6,
                "least_squares_method": lsq_method,
                "allow_unbounded_lm": allow_unbounded_lm,
            },
        },
        "compile_target": compile_target,
    }


def timed_run(
    model: alpine1 | xinanjiang, *, config: dict[str, object] | None = None
) -> float:
    start = time.perf_counter()
    if config is None:
        model.run()
    else:
        model.run(config=config)
    return time.perf_counter() - start


def collect_solver_stats(model: alpine1 | xinanjiang) -> tuple[int, int]:
    data = model.solver_data
    if data is None:
        return 0, 0
    nfev = int(np.sum(np.asarray(data["nfev"], dtype=np.int64)))
    njev = int(np.sum(np.asarray(data["njev"], dtype=np.int64)))
    return nfev, njev


def run_case(
    *,
    model_name: str,
    forcing: dict[str, np.ndarray],
    solver_backend: str,
    compile_target: str,
    warm_numba: bool,
    resnorm_tolerance: float,
    resnorm_maxiter: int,
    fsolve_use_jacobian: bool,
    lsq_use_jacobian: bool,
    lsq_method: str,
    allow_unbounded_lm: bool,
) -> dict[str, Any]:
    model_cls, _, _ = model_baseline(model_name)
    model = model_cls()
    force_solver_backend(model, solver_backend)

    config = build_config(
        model_name=model_name,
        forcing=forcing,
        compile_target=compile_target,
        resnorm_tolerance=resnorm_tolerance,
        resnorm_maxiter=resnorm_maxiter,
        fsolve_use_jacobian=fsolve_use_jacobian,
        lsq_use_jacobian=lsq_use_jacobian,
        lsq_method=lsq_method,
        allow_unbounded_lm=allow_unbounded_lm,
    )

    np.random.seed(42)
    if warm_numba:
        _ = timed_run(model, config=config)
        elapsed = timed_run(model)
    else:
        elapsed = timed_run(model, config=config)

    q = model.get_streamflow()
    water_balance = model.check_water_balance()
    nfev, njev = collect_solver_stats(model)
    solver_data = model.solver_data
    solver_set = []
    if solver_data is not None:
        solver_set = [
            str(value)
            for value in np.unique(np.asarray(solver_data["solver"]).reshape(-1))
        ]

    return {
        "elapsed": elapsed,
        "q": q,
        "water_balance": float(water_balance),
        "nfev": nfev,
        "njev": njev,
        "solvers": solver_set,
        "resolved_target": model.compiler.target,
        "compiler_detail": model.compiler.detail,
    }


def main() -> None:
    args = parse_args()
    forcing = load_forcing(args.steps)

    scenarios = [
        {
            "name": "fsolve_python",
            "solver_backend": "fsolve",
            "compile_target": "python",
            "warm_numba": False,
            "fsolve_use_jacobian": False,
            "lsq_use_jacobian": False,
            "lsq_method": "trf",
            "allow_unbounded_lm": False,
        },
        {
            "name": "fsolve_numba_warm",
            "solver_backend": "fsolve",
            "compile_target": "numba",
            "warm_numba": True,
            "fsolve_use_jacobian": False,
            "lsq_use_jacobian": False,
            "lsq_method": "trf",
            "allow_unbounded_lm": False,
        },
        {
            "name": "fsolve_numba_warm_jacobian",
            "solver_backend": "fsolve",
            "compile_target": "numba",
            "warm_numba": True,
            "fsolve_use_jacobian": True,
            "lsq_use_jacobian": False,
            "lsq_method": "trf",
            "allow_unbounded_lm": False,
        },
        {
            "name": "least_squares_trf",
            "solver_backend": "lsqnonlin",
            "compile_target": "numba",
            "warm_numba": True,
            "fsolve_use_jacobian": False,
            "lsq_use_jacobian": False,
            "lsq_method": "trf",
            "allow_unbounded_lm": False,
        },
        {
            "name": "least_squares_dogbox",
            "solver_backend": "lsqnonlin",
            "compile_target": "numba",
            "warm_numba": True,
            "fsolve_use_jacobian": False,
            "lsq_use_jacobian": False,
            "lsq_method": "dogbox",
            "allow_unbounded_lm": False,
        },
        {
            "name": "least_squares_lm",
            "solver_backend": "lsqnonlin",
            "compile_target": "numba",
            "warm_numba": True,
            "fsolve_use_jacobian": False,
            "lsq_use_jacobian": False,
            "lsq_method": "lm",
            "allow_unbounded_lm": True,
        },
    ]

    results: dict[str, dict[str, Any]] = {}
    for scenario in scenarios:
        result = run_case(
            model_name=args.model,
            forcing=forcing,
            solver_backend=scenario["solver_backend"],
            compile_target=scenario["compile_target"],
            warm_numba=scenario["warm_numba"],
            resnorm_tolerance=args.resnorm_tolerance,
            resnorm_maxiter=args.resnorm_maxiter,
            fsolve_use_jacobian=scenario["fsolve_use_jacobian"],
            lsq_use_jacobian=scenario["lsq_use_jacobian"],
            lsq_method=scenario["lsq_method"],
            allow_unbounded_lm=scenario["allow_unbounded_lm"],
        )
        results[scenario["name"]] = result

    reference = results["fsolve_python"]
    reference_q = np.asarray(reference["q"], dtype=np.float64)

    print(f"model: {args.model}")
    print(f"dataset: {DATA_FILE}")
    print(f"timesteps: {reference_q.size}")
    print(
        "solver options: "
        f"resnorm_tolerance={args.resnorm_tolerance}, "
        f"resnorm_maxiter={args.resnorm_maxiter}"
    )
    print()

    for name, result in results.items():
        q = np.asarray(result["q"], dtype=np.float64)
        max_abs_diff = float(np.max(np.abs(reference_q - q)))
        print(f"[{name}]")
        print(f"elapsed: {result['elapsed']:.6f} s")
        print(f"resolved target: {result['resolved_target']}")
        print(f"solvers used: {result['solvers']}")
        print(f"max |Q_ref - Q|: {max_abs_diff:.3e}")
        print(f"water balance error: {result['water_balance']:.3e}")
        print(f"nfev (total): {result['nfev']}")
        print(f"njev (total): {result['njev']}")
        if name != "fsolve_python":
            speedup = (
                reference["elapsed"] / result["elapsed"]
                if result["elapsed"] > 0.0
                else np.nan
            )
            print(f"speedup vs fsolve_python: {speedup:.2f}x")
        print()


if __name__ == "__main__":
    main()
