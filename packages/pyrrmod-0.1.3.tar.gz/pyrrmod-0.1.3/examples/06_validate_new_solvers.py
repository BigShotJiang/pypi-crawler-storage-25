from __future__ import annotations

import time
from pathlib import Path

import numpy as np

from pyrrmod.models import alpine1


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"


def load_forcing(n_steps: int = 365) -> dict[str, np.ndarray]:
    data = np.loadtxt(DATA_FILE, delimiter=",", skiprows=1, max_rows=n_steps)
    data = np.atleast_2d(data)
    return {
        "precip": np.asarray(data[:, 0], dtype=np.float64),
        "temp": np.asarray(data[:, 1], dtype=np.float64),
        "pet": np.asarray(data[:, 2], dtype=np.float64),
    }


def run_once(
    solver: str,
    forcing: dict[str, np.ndarray],
    *,
    initial_stores: list[float] | None = None,
) -> tuple[alpine1, float]:
    model = alpine1()
    config = {
        "theta": [0.0, 3.0, 500.0, 0.05],
        "delta_t": 1.0,
        "initial_stores": [50.0, 120.0] if initial_stores is None else initial_stores,
        "climate": forcing,
        "compile_target": "numba",
    }

    start = time.perf_counter()
    model.run(config=config, solver=solver)
    elapsed = time.perf_counter() - start
    return model, elapsed


def main() -> None:
    # Case A: strict consistency check on a mild forcing case.
    n_zero = 180
    zero_forcing = {
        "precip": np.zeros(n_zero, dtype=np.float64),
        "temp": np.zeros(n_zero, dtype=np.float64),
        "pet": np.zeros(n_zero, dtype=np.float64),
    }

    zero_fsolve, _ = run_once("fsolve", zero_forcing, initial_stores=[0.0, 0.0])
    zero_newton, _ = run_once("numba_newton", zero_forcing, initial_stores=[0.0, 0.0])
    zero_heun, _ = run_once("heun", zero_forcing, initial_stores=[0.0, 0.0])

    out_fsolve = zero_fsolve.stores
    out_newton = zero_newton.stores
    out_heun = zero_heun.stores

    assert np.allclose(out_fsolve, out_newton, atol=1e-5)
    assert np.allclose(out_fsolve, out_heun, atol=1e-3)

    print("consistency check (mild forcing):")
    print("- assert allclose(fsolve, numba_newton, atol=1e-5): passed")
    print("- assert allclose(fsolve, heun, atol=1e-3): passed")
    print()

    # Case B: practical benchmark on real forcing (may show explicit-integration bias).
    forcing = load_forcing(365)
    model_fsolve, t_fsolve = run_once("fsolve", forcing)
    _warm_newton, _ = run_once("numba_newton", forcing)
    model_newton, t_newton = run_once("numba_newton", forcing)
    _warm_heun, _ = run_once("heun", forcing)
    model_heun, t_heun = run_once("heun", forcing)

    q_fsolve = model_fsolve.get_streamflow()
    q_newton = model_newton.get_streamflow()
    q_heun = model_heun.get_streamflow()

    newton_close = np.allclose(q_fsolve, q_newton, atol=1e-5)
    heun_close = np.allclose(q_fsolve, q_heun, atol=1e-3)
    newton_max_diff = float(np.max(np.abs(q_fsolve - q_newton)))
    heun_max_diff = float(np.max(np.abs(q_fsolve - q_heun)))

    print("real-forcing comparison (streamflow):")
    print(f"- fsolve vs numba_newton | allclose(atol=1e-5): {newton_close}")
    print(f"- fsolve vs heun         | allclose(atol=1e-3): {heun_close}")
    print(f"- max |Q_fsolve-Q_newton|: {newton_max_diff:.6e}")
    print(f"- max |Q_fsolve-Q_heun|  : {heun_max_diff:.6e}")
    print()
    print("timings (second run, after warmup):")
    print(f"- fsolve       : {t_fsolve:.6f} s")
    print(f"- numba_newton : {t_newton:.6f} s")
    print(f"- heun         : {t_heun:.6f} s")
    if t_newton > 0.0:
        print(f"- speedup numba_newton vs fsolve: {t_fsolve / t_newton:.2f}x")
    if t_heun > 0.0:
        print(f"- speedup heun vs fsolve: {t_fsolve / t_heun:.2f}x")


if __name__ == "__main__":
    main()
