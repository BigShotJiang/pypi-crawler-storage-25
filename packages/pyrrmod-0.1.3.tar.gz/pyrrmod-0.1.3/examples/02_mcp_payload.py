from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import collie1


def main() -> None:
    n_steps = 48
    payload = {
        "theta": [400.0],
        "delta_t": 1.0,
        "initial_stores": [80.0],
        "climate": {
            "rainfall": (
                3.0 + np.random.default_rng(13).uniform(0.0, 4.0, n_steps)
            ).tolist(),
            "PET": np.full(n_steps, 1.8).tolist(),
            "temperature": np.full(n_steps, 12.0).tolist(),
        },
    }

    model = collie1()
    mcp_result = model.run_from_payload(payload, include_internal=False)

    print(json.dumps(mcp_result, indent=2)[:800])


if __name__ == "__main__":
    main()
