from __future__ import annotations

import argparse
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from numba import njit

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import alpine1, gr4j
from pyrrmod.models.base import FloatArray, HydrologyModel, RuntimeContext


DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"
ALPINE1_THETA = [0.0, 3.0, 500.0, 0.05]
ALPINE1_S0 = [50.0, 120.0]
GR4J_THETA = [500.0, 0.0, 100.0, 2.5]
GR4J_S0 = [250.0, 50.0]


@njit(cache=True)
def _pilot_temperature_logistic(temperature: float, threshold: float) -> float:
    exponent = (temperature - threshold) / 0.01
    if exponent >= 700.0:
        return 0.0
    return 1.0 / (1.0 + np.exp(exponent))


@njit(cache=True)
def _pilot_storage_logistic(storage: float, storage_max: float) -> float:
    storage_cap = storage_max if storage_max > 0.0 else 0.0
    if 0.01 * storage_cap == 0.0:
        exponent = (storage - storage_cap + 0.01 * 5.0 * storage_cap) / 0.01
    else:
        exponent = (storage - storage_cap + 0.01 * 5.0 * storage_cap) / (
            0.01 * storage_cap
        )

    if exponent >= 700.0:
        return 0.0
    return 1.0 / (1.0 + np.exp(exponent))


def _pilot_alpine1_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    out_dS: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    tt = float(theta[0])
    ddf = float(theta[1])
    storage_max = float(theta[2])
    tc = float(theta[3])

    S1 = float(states[0])
    S2 = float(states[1])
    precip_t = float(precip[step_index])
    pet_t = float(pet[step_index])
    temp_t = float(temp[step_index])

    snow_fraction = _pilot_temperature_logistic(temp_t, tt)
    flux_ps = precip_t * snow_fraction
    flux_pr = precip_t * (1.0 - snow_fraction)
    flux_qn = max(min(ddf * (temp_t - tt), S1 / delta_t), 0.0)
    flux_ea = min(S2 / delta_t, pet_t)
    flux_qse = (precip_t + flux_qn) * (1.0 - _pilot_storage_logistic(S2, storage_max))
    flux_qss = tc * S2

    out_dS[0] = flux_ps - flux_qn
    out_dS[1] = flux_pr + flux_qn - flux_ea - flux_qse - flux_qss
    out_fluxes[0] = flux_ps
    out_fluxes[1] = flux_pr
    out_fluxes[2] = flux_qn
    out_fluxes[3] = flux_ea
    out_fluxes[4] = flux_qse
    out_fluxes[5] = flux_qss


@njit(cache=True)
def _pilot_gr4j_route_current(pending: FloatArray) -> float:
    if pending.size == 0:
        return 0.0
    return float(pending[0])


@njit(cache=True)
def _pilot_gr4j_saturation_quadratic(
    storage: float,
    storage_max: float,
    inflow: float,
) -> float:
    return max(0.0, (1.0 - (storage / storage_max) ** 2) * inflow)


@njit(cache=True)
def _pilot_gr4j_evap_quadratic(
    storage: float,
    storage_max: float,
    evap_pot: float,
) -> float:
    scaled = storage / storage_max
    return max(0.0, (2.0 * scaled - scaled**2) * evap_pot)


@njit(cache=True)
def _pilot_gr4j_percolation(storage: float, storage_max: float) -> float:
    return storage_max ** (-4.0) / 4.0 * (4.0 / 9.0) ** 4 * storage**5


@njit(cache=True)
def _pilot_gr4j_exchange(storage: float, storage_max: float, x2: float) -> float:
    return x2 * ((max(storage, 0.0) / storage_max) ** 3.5)


@njit(cache=True)
def _pilot_gr4j_baseflow(storage: float, storage_max: float) -> float:
    return storage_max ** (-4.0) / 4.0 * storage**5


def _pilot_gr4j_compute_step(
    states: FloatArray,
    step_index: int,
    theta: FloatArray,
    delta_t: float,
    precip: FloatArray,
    pet: FloatArray,
    temp: FloatArray,
    _q9_weights: FloatArray,
    q9_pending: FloatArray,
    _q1_weights: FloatArray,
    q1_pending: FloatArray,
    out_states: FloatArray,
    out_fluxes: FloatArray,
) -> None:
    x1 = float(theta[0])
    x2 = float(theta[1])
    x3 = float(theta[2])

    S1 = float(states[0])
    S2 = float(states[1])
    P = float(precip[step_index])
    Ep = float(pet[step_index])

    flux_pn = max(P - Ep, 0.0)
    flux_en = max(Ep - P, 0.0)
    flux_ef = P - flux_pn
    flux_ps = _pilot_gr4j_saturation_quadratic(S1, x1, flux_pn)
    flux_es = _pilot_gr4j_evap_quadratic(S1, x1, flux_en)
    flux_perc = _pilot_gr4j_percolation(S1, x1)
    flux_q9 = _pilot_gr4j_route_current(q9_pending) / delta_t
    flux_q1 = _pilot_gr4j_route_current(q1_pending) / delta_t
    flux_fr = _pilot_gr4j_exchange(S2, x3, x2)
    flux_fq = flux_fr
    flux_qr = _pilot_gr4j_baseflow(S2, x3)
    quick_component = flux_q1 + flux_fq
    quick_positive = quick_component if quick_component > 0.0 else 0.0
    flux_qt = flux_qr + quick_positive
    flux_ex = flux_fr + quick_positive - flux_q1

    dS1 = flux_ps - flux_es - flux_perc
    dS2 = flux_q9 + flux_fr - flux_qr
    out_states[0] = min(x1, max(0.0, S1 + dS1 * delta_t))
    out_states[1] = min(x3, max(0.0, S2 + dS2 * delta_t))

    out_fluxes[0] = flux_pn
    out_fluxes[1] = flux_en
    out_fluxes[2] = flux_ef
    out_fluxes[3] = flux_ps
    out_fluxes[4] = flux_es
    out_fluxes[5] = flux_perc
    out_fluxes[6] = flux_q9
    out_fluxes[7] = flux_q1
    out_fluxes[8] = flux_fr
    out_fluxes[9] = flux_fq
    out_fluxes[10] = flux_qr
    out_fluxes[11] = flux_qt
    out_fluxes[12] = flux_ex


_PILOT_ALPINE1_COMPILED = njit(cache=True)(_pilot_alpine1_compute_step)
_PILOT_GR4J_COMPILED = njit(cache=True)(_pilot_gr4j_compute_step)


def _warm_bound_kernel(
    model: HydrologyModel,
    runtime: RuntimeContext,
    kernel,
):
    warm_states = np.asarray(runtime.S0, dtype=np.float64)
    warm_out_states = np.empty(model.num_stores, dtype=np.float64)
    warm_out_fluxes = np.empty(model.num_fluxes, dtype=np.float64)
    kernel(warm_states, 0, warm_out_states, warm_out_fluxes)
    return kernel


def _compile_bound_kernel(
    model: HydrologyModel,
    runtime: RuntimeContext,
    kernel,
):
    compiled_kernel = njit(cache=False)(kernel)
    return _warm_bound_kernel(model, runtime, compiled_kernel)


class Alpine1BaseKernelPilot(alpine1):
    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ):
        return HydrologyModel._bind_kernel(self, _pilot_alpine1_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ):
        compiled_step = HydrologyModel._compile_step_fun(
            self,
            _pilot_alpine1_compute_step,
            runtime,
            n_stores=self.num_stores,
            n_fluxes=self.num_fluxes,
        )
        kernel = HydrologyModel._bind_kernel(self, compiled_step, runtime)
        return _compile_bound_kernel(self, runtime, kernel)


class GR4JBaseKernelPilot(gr4j):
    def _get_kernel_bind_args(self, runtime: RuntimeContext):
        routing = self._require_routing_state(runtime)
        return (
            *HydrologyModel._get_kernel_bind_args(self, runtime),
            routing.q9_weights,
            routing.q9_pending,
            routing.q1_weights,
            routing.q1_pending,
        )

    def build_python_kernel(
        self,
        runtime: RuntimeContext,
    ):
        return HydrologyModel._bind_kernel(self, _pilot_gr4j_compute_step, runtime)

    def build_numba_model_fun(
        self,
        runtime: RuntimeContext,
    ):
        compiled_step = HydrologyModel._compile_step_fun(
            self,
            _pilot_gr4j_compute_step,
            runtime,
            n_stores=self.num_stores,
            n_fluxes=self.num_fluxes,
        )
        kernel = HydrologyModel._bind_kernel(self, compiled_step, runtime)
        return _warm_bound_kernel(self, runtime, kernel)


@dataclass(slots=True)
class RunResult:
    elapsed: float
    compiler_target: str
    compiler_detail: str
    solvers: list[str]
    streamflow: FloatArray
    water_balance: float


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Validate new base-kernel helpers with alpine1/gr4j pilot models and "
            "report warm-run speedups."
        )
    )
    parser.add_argument(
        "--steps",
        type=int,
        default=365,
        help="Number of source forcing rows to read. 0 means full dataset.",
    )
    parser.add_argument(
        "--repeat-forcing",
        type=int,
        default=4,
        help="Repeat the forcing block to make timing differences easier to observe.",
    )
    parser.add_argument(
        "--repeats",
        type=int,
        default=3,
        help="Number of timed warm runs per scenario.",
    )
    return parser.parse_args()


def load_forcing(steps: int, repeat_forcing: int) -> dict[str, np.ndarray]:
    kwargs = {"delimiter": ",", "skiprows": 1}
    if steps > 0:
        kwargs["max_rows"] = steps
    data = np.loadtxt(DATA_FILE, **kwargs)
    data = np.atleast_2d(data)
    if repeat_forcing > 1:
        data = np.tile(data, (repeat_forcing, 1))
    return {
        "precip": np.asarray(data[:, 0], dtype=np.float64),
        "temp": np.asarray(data[:, 1], dtype=np.float64),
        "pet": np.asarray(data[:, 2], dtype=np.float64),
    }


def build_alpine1_config(
    forcing: dict[str, np.ndarray],
    *,
    compile_target: str,
    solver: str,
) -> dict[str, object]:
    return {
        "theta": ALPINE1_THETA,
        "delta_t": 1.0,
        "initial_stores": ALPINE1_S0,
        "climate": forcing,
        "compile_target": compile_target,
        "solver": solver,
    }


def build_gr4j_config(
    forcing: dict[str, np.ndarray],
    *,
    compile_target: str,
) -> dict[str, object]:
    return {
        "theta": GR4J_THETA,
        "delta_t": 1.0,
        "initial_stores": GR4J_S0,
        "climate": forcing,
        "compile_target": compile_target,
    }


def _solver_names(model) -> list[str]:
    solver_data = model.solver_data
    if solver_data is None:
        return []
    return [
        str(value) for value in np.unique(np.asarray(solver_data["solver"]).reshape(-1))
    ]


def run_once(model_cls, config: dict[str, object]) -> tuple[RunResult, object]:
    model = model_cls()
    start = time.perf_counter()
    model.run(config=config)
    elapsed = time.perf_counter() - start
    result = RunResult(
        elapsed=elapsed,
        compiler_target=str(model.compiler.target),
        compiler_detail=str(model.compiler.detail),
        solvers=_solver_names(model),
        streamflow=np.asarray(model.get_streamflow(), dtype=np.float64).copy(),
        water_balance=float(model.check_water_balance()),
    )
    return result, model


def _reset_runtime_for_repeat(model, runtime: RuntimeContext) -> None:
    runtime.stores[:, :] = 0.0
    runtime.fluxes[:, :] = 0.0
    runtime.solver_data["resnorm"][:] = 0.0
    runtime.solver_data["solver"][:] = "None"
    runtime.solver_data["iter"][:] = 0
    runtime.solver_data["nfev"][:] = 0
    runtime.solver_data["njev"][:] = 0
    runtime.active_step = 0

    if runtime.delta_states_scratch is not None:
        runtime.delta_states_scratch[:] = 0.0
    if runtime.fluxes_scratch is not None:
        runtime.fluxes_scratch[:] = 0.0
    if runtime.residual_scratch is not None:
        runtime.residual_scratch[:] = 0.0

    routing = runtime.routing_state
    for name in (
        "q9_pending",
        "q1_pending",
        "uh_pending",
        "uh1_pending",
        "uh2_pending",
        "uh3_pending",
    ):
        values = getattr(routing, name, None)
        if values is not None:
            values[:] = 0.0

    if routing is not None:
        model.routing_state = routing
        legacy = getattr(routing, "as_legacy_uhs", None)
        if callable(legacy):
            model.uhs = legacy()

    model.t = None
    model.status = 0


def _run_backend(model, runtime: RuntimeContext, solver_name: str) -> None:
    if model._uses_discrete_step_solver():
        model._run_discrete(runtime)
    elif solver_name == "fsolve":
        model._run_implicit_backend(runtime, "fsolve")
    elif solver_name == "numba_newton":
        model._run_numba_newton(runtime)
    elif solver_name == "heun":
        model._run_heun(runtime)
    else:
        raise ValueError(f"unsupported solver for benchmark: {solver_name}")
    model.status = 1


def benchmark_hot_path(
    model_cls,
    config: dict[str, object],
    *,
    solver_name: str,
    repeats: int,
) -> RunResult:
    model = model_cls()
    model.configure(config=config)
    model.init_runtime()
    runtime = model._require_runtime_context()

    _reset_runtime_for_repeat(model, runtime)
    _run_backend(model, runtime, solver_name)

    timings: list[float] = []
    for _ in range(repeats):
        _reset_runtime_for_repeat(model, runtime)
        start = time.perf_counter()
        _run_backend(model, runtime, solver_name)
        timings.append(time.perf_counter() - start)

    return RunResult(
        elapsed=float(statistics.median(timings)),
        compiler_target=str(model.compiler.target),
        compiler_detail=str(model.compiler.detail),
        solvers=_solver_names(model),
        streamflow=np.asarray(model.get_streamflow(), dtype=np.float64).copy(),
        water_balance=float(model.check_water_balance()),
    )


def max_abs_diff(lhs: FloatArray, rhs: FloatArray) -> float:
    return float(np.max(np.abs(np.asarray(lhs) - np.asarray(rhs))))


def assert_close(
    lhs: FloatArray, rhs: FloatArray, *, atol: float, message: str
) -> float:
    diff = max_abs_diff(lhs, rhs)
    if not np.allclose(lhs, rhs, atol=atol, rtol=0.0):
        raise AssertionError(f"{message}; max diff={diff:.3e}")
    return diff


@njit(cache=True)
def _smoke_test_alpine1_numba_call() -> float:
    states = np.zeros(2, dtype=np.float64)
    theta = np.zeros(4, dtype=np.float64)
    theta[1] = 3.0
    theta[2] = 500.0
    theta[3] = 0.05
    precip = np.ones(8, dtype=np.float64)
    pet = np.ones(8, dtype=np.float64)
    temp = np.full(8, 5.0, dtype=np.float64)
    out_dS = np.zeros(2, dtype=np.float64)
    out_fluxes = np.zeros(6, dtype=np.float64)
    _PILOT_ALPINE1_COMPILED(
        states,
        0,
        theta,
        1.0,
        precip,
        pet,
        temp,
        out_dS,
        out_fluxes,
    )
    return out_fluxes[0]


@njit(cache=True)
def _smoke_test_gr4j_numba_call() -> float:
    states = np.zeros(2, dtype=np.float64)
    states[0] = 250.0
    states[1] = 50.0
    theta = np.zeros(4, dtype=np.float64)
    theta[0] = 500.0
    theta[2] = 100.0
    theta[3] = 2.5
    precip = np.ones(8, dtype=np.float64)
    pet = np.zeros(8, dtype=np.float64)
    temp = np.zeros(8, dtype=np.float64)
    q9_weights = np.asarray([1.0], dtype=np.float64)
    q9_pending = np.asarray([0.0], dtype=np.float64)
    q1_weights = np.asarray([1.0], dtype=np.float64)
    q1_pending = np.asarray([0.0], dtype=np.float64)
    out_states = np.zeros(2, dtype=np.float64)
    out_fluxes = np.zeros(13, dtype=np.float64)
    _PILOT_GR4J_COMPILED(
        states,
        0,
        theta,
        1.0,
        precip,
        pet,
        temp,
        q9_weights,
        q9_pending,
        q1_weights,
        q1_pending,
        out_states,
        out_fluxes,
    )
    return out_fluxes[11]


def print_result(label: str, result: RunResult) -> None:
    print(f"{label}: {result.elapsed:.6f} s")
    print(f"  compiler target: {result.compiler_target}")
    print(f"  compiler detail: {result.compiler_detail}")
    print(f"  solvers used: {result.solvers}")
    print(f"  water balance: {result.water_balance:.3e}")


def main() -> None:
    args = parse_args()
    forcing = load_forcing(args.steps, args.repeat_forcing)
    time_steps = int(forcing["precip"].shape[0])

    print(f"dataset: {DATA_FILE}")
    print(f"time steps used: {time_steps}")
    print(f"timed repeats: {args.repeats}")
    print()

    alpine1_fsolve_cfg = build_alpine1_config(
        forcing,
        compile_target="python",
        solver="fsolve",
    )
    alpine1_numba_newton_cfg = build_alpine1_config(
        forcing,
        compile_target="numba",
        solver="numba_newton",
    )
    alpine1_heun_cfg = build_alpine1_config(
        forcing,
        compile_target="numba",
        solver="heun",
    )
    gr4j_python_cfg = build_gr4j_config(forcing, compile_target="python")
    gr4j_numba_cfg = build_gr4j_config(forcing, compile_target="numba")

    smoke_alpine1 = _smoke_test_alpine1_numba_call()
    smoke_gr4j = _smoke_test_gr4j_numba_call()
    print(f"pilot alpine1 numba smoke: {smoke_alpine1:.6f}")
    print(f"pilot gr4j numba smoke: {smoke_gr4j:.6f}")
    print()

    current_alpine1_fsolve, _ = run_once(alpine1, alpine1_fsolve_cfg)
    pilot_alpine1_fsolve, _ = run_once(
        Alpine1BaseKernelPilot,
        alpine1_fsolve_cfg,
    )
    current_alpine1_newton, _ = run_once(
        alpine1,
        alpine1_numba_newton_cfg,
    )
    pilot_alpine1_newton, _ = run_once(
        Alpine1BaseKernelPilot,
        alpine1_numba_newton_cfg,
    )
    current_alpine1_heun, _ = run_once(alpine1, alpine1_heun_cfg)
    pilot_alpine1_heun, _ = run_once(Alpine1BaseKernelPilot, alpine1_heun_cfg)

    current_gr4j_python, _ = run_once(gr4j, gr4j_python_cfg)
    current_gr4j_numba, _ = run_once(gr4j, gr4j_numba_cfg)
    pilot_gr4j_python, _ = run_once(
        GR4JBaseKernelPilot,
        gr4j_python_cfg,
    )
    pilot_gr4j_numba, _ = run_once(
        GR4JBaseKernelPilot,
        gr4j_numba_cfg,
    )

    perf_current_alpine1_fsolve = benchmark_hot_path(
        alpine1,
        alpine1_fsolve_cfg,
        solver_name="fsolve",
        repeats=args.repeats,
    )
    perf_pilot_alpine1_fsolve = benchmark_hot_path(
        Alpine1BaseKernelPilot,
        alpine1_fsolve_cfg,
        solver_name="fsolve",
        repeats=args.repeats,
    )
    perf_current_alpine1_newton = benchmark_hot_path(
        alpine1,
        alpine1_numba_newton_cfg,
        solver_name="numba_newton",
        repeats=args.repeats,
    )
    perf_pilot_alpine1_newton = benchmark_hot_path(
        Alpine1BaseKernelPilot,
        alpine1_numba_newton_cfg,
        solver_name="numba_newton",
        repeats=args.repeats,
    )
    perf_current_alpine1_heun = benchmark_hot_path(
        alpine1,
        alpine1_heun_cfg,
        solver_name="heun",
        repeats=args.repeats,
    )
    perf_pilot_alpine1_heun = benchmark_hot_path(
        Alpine1BaseKernelPilot,
        alpine1_heun_cfg,
        solver_name="heun",
        repeats=args.repeats,
    )
    perf_current_gr4j_python = benchmark_hot_path(
        gr4j,
        gr4j_python_cfg,
        solver_name="discrete",
        repeats=args.repeats,
    )
    perf_current_gr4j_numba = benchmark_hot_path(
        gr4j,
        gr4j_numba_cfg,
        solver_name="discrete",
        repeats=args.repeats,
    )
    perf_pilot_gr4j_python = benchmark_hot_path(
        GR4JBaseKernelPilot,
        gr4j_python_cfg,
        solver_name="discrete",
        repeats=args.repeats,
    )
    perf_pilot_gr4j_numba = benchmark_hot_path(
        GR4JBaseKernelPilot,
        gr4j_numba_cfg,
        solver_name="discrete",
        repeats=args.repeats,
    )

    alpine1_fsolve_diff = assert_close(
        current_alpine1_fsolve.streamflow,
        pilot_alpine1_fsolve.streamflow,
        atol=1e-10,
        message="pilot alpine1 fsolve diverged from current alpine1 fsolve",
    )
    alpine1_newton_diff = assert_close(
        current_alpine1_newton.streamflow,
        pilot_alpine1_newton.streamflow,
        atol=1e-10,
        message="pilot alpine1 numba_newton diverged from current alpine1 numba_newton",
    )
    alpine1_heun_diff = assert_close(
        current_alpine1_heun.streamflow,
        pilot_alpine1_heun.streamflow,
        atol=1e-10,
        message="pilot alpine1 heun diverged from current alpine1 heun",
    )
    alpine1_solver_newton_diff = assert_close(
        pilot_alpine1_fsolve.streamflow,
        pilot_alpine1_newton.streamflow,
        atol=1e-5,
        message="pilot alpine1 numba_newton deviates from pilot alpine1 fsolve",
    )
    current_alpine1_solver_heun_diff = max_abs_diff(
        current_alpine1_fsolve.streamflow,
        current_alpine1_heun.streamflow,
    )
    pilot_alpine1_solver_heun_diff = max_abs_diff(
        pilot_alpine1_fsolve.streamflow,
        pilot_alpine1_heun.streamflow,
    )
    gr4j_python_diff = assert_close(
        current_gr4j_python.streamflow,
        pilot_gr4j_python.streamflow,
        atol=1e-10,
        message="pilot gr4j python diverged from current gr4j python",
    )
    gr4j_numba_diff = assert_close(
        current_gr4j_python.streamflow,
        pilot_gr4j_numba.streamflow,
        atol=1e-10,
        message="pilot gr4j numba diverged from current gr4j python",
    )

    print("Validation")
    print(f"  alpine1 current vs pilot fsolve max diff: {alpine1_fsolve_diff:.3e}")
    print(
        f"  alpine1 current vs pilot numba_newton max diff: {alpine1_newton_diff:.3e}"
    )
    print(f"  alpine1 current vs pilot heun max diff: {alpine1_heun_diff:.3e}")
    print(
        f"  alpine1 pilot fsolve vs numba_newton max diff: {alpine1_solver_newton_diff:.3e}"
    )
    print(
        f"  alpine1 current fsolve vs heun max diff: {current_alpine1_solver_heun_diff:.3e}"
    )
    print(
        f"  alpine1 pilot fsolve vs heun max diff: {pilot_alpine1_solver_heun_diff:.3e}"
    )
    print(f"  gr4j current vs pilot python max diff: {gr4j_python_diff:.3e}")
    print(f"  gr4j current python vs pilot numba max diff: {gr4j_numba_diff:.3e}")
    print()

    print("Performance")
    print_result("  current alpine1 fsolve", perf_current_alpine1_fsolve)
    print_result("  pilot alpine1 fsolve", perf_pilot_alpine1_fsolve)
    print_result("  current alpine1 numba_newton", perf_current_alpine1_newton)
    print_result("  pilot alpine1 numba_newton", perf_pilot_alpine1_newton)
    print_result("  current alpine1 heun", perf_current_alpine1_heun)
    print_result("  pilot alpine1 heun", perf_pilot_alpine1_heun)
    print_result("  current gr4j python", perf_current_gr4j_python)
    print_result("  current gr4j compile_target=numba", perf_current_gr4j_numba)
    print_result("  pilot gr4j python", perf_pilot_gr4j_python)
    print_result("  pilot gr4j numba", perf_pilot_gr4j_numba)
    print()

    print("Speedup")
    print(
        "  alpine1 current numba_newton vs current fsolve: "
        f"{perf_current_alpine1_fsolve.elapsed / perf_current_alpine1_newton.elapsed:.2f}x"
    )
    print(
        "  alpine1 pilot numba_newton vs pilot fsolve: "
        f"{perf_pilot_alpine1_fsolve.elapsed / perf_pilot_alpine1_newton.elapsed:.2f}x"
    )
    print(
        "  alpine1 pilot/current numba_newton: "
        f"{perf_current_alpine1_newton.elapsed / perf_pilot_alpine1_newton.elapsed:.2f}x"
    )
    print(
        "  alpine1 pilot/current heun: "
        f"{perf_current_alpine1_heun.elapsed / perf_pilot_alpine1_heun.elapsed:.2f}x"
    )
    print(
        "  gr4j pilot numba vs current python: "
        f"{perf_current_gr4j_python.elapsed / perf_pilot_gr4j_numba.elapsed:.2f}x"
    )
    print(
        "  gr4j pilot numba vs current compile_target=numba fallback: "
        f"{perf_current_gr4j_numba.elapsed / perf_pilot_gr4j_numba.elapsed:.2f}x"
    )


if __name__ == "__main__":
    main()
