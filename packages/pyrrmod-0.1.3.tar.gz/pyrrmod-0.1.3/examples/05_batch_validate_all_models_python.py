from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import MODEL_REGISTRY, create_model


DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"


@dataclass(slots=True)
class ModelCheckResult:
    model: str
    run_ok: bool
    correct: bool
    status: int | None
    steps: int
    water_balance_error: float | None
    message: str


def load_climate(n_steps: int) -> dict[str, np.ndarray]:
    data = np.loadtxt(DATA_FILE, delimiter=",", skiprows=1, max_rows=n_steps)
    return {
        "precip": np.asarray(data[:, 0], dtype=np.float64),
        "temp": np.asarray(data[:, 1], dtype=np.float64),
        "pet": np.asarray(data[:, 2], dtype=np.float64),
    }


def build_theta_from_par_ranges(model: Any) -> np.ndarray:
    n_params = int(model.num_params or 0)
    if n_params <= 0:
        return np.zeros(0, dtype=np.float64)

    ranges = model.par_ranges
    if ranges is None:
        return np.ones(n_params, dtype=np.float64)

    arr = np.asarray(ranges, dtype=np.float64)
    if arr.ndim != 2 or arr.shape != (n_params, 2):
        return np.ones(n_params, dtype=np.float64)

    low = arr[:, 0]
    high = arr[:, 1]
    theta = np.ones(n_params, dtype=np.float64)

    finite = np.isfinite(low) & np.isfinite(high)
    theta[finite] = low[finite] + 0.30 * (high[finite] - low[finite])

    only_low_finite = np.isfinite(low) & ~np.isfinite(high)
    theta[only_low_finite] = low[only_low_finite] + np.maximum(
        1.0, np.abs(low[only_low_finite]) * 0.10
    )

    only_high_finite = ~np.isfinite(low) & np.isfinite(high)
    theta[only_high_finite] = high[only_high_finite] - np.maximum(
        1.0, np.abs(high[only_high_finite]) * 0.10
    )

    both_inf = ~np.isfinite(low) & ~np.isfinite(high)
    theta[both_inf] = 1.0

    return theta


def build_initial_stores(model: Any) -> np.ndarray:
    n_stores = int(model.num_stores or 0)
    if n_stores <= 0:
        return np.zeros(0, dtype=np.float64)
    return np.full(n_stores, 50.0, dtype=np.float64)


def check_correctness(
    model: Any,
    streamflow: np.ndarray,
    expected_steps: int,
    wb_tolerance: float,
) -> tuple[bool, float, str]:
    if int(model.status) != 1:
        return False, np.nan, f"status={model.status}"

    if streamflow.shape[0] != expected_steps:
        return (
            False,
            np.nan,
            f"streamflow length mismatch: {streamflow.shape[0]} != {expected_steps}",
        )

    if not np.all(np.isfinite(streamflow)):
        return False, np.nan, "streamflow contains NaN/Inf"

    water_balance_error = float(model.check_water_balance())
    if not np.isfinite(water_balance_error):
        return False, water_balance_error, "water_balance_error is NaN/Inf"

    if abs(water_balance_error) > wb_tolerance:
        return (
            False,
            water_balance_error,
            f"|water_balance_error| > tolerance ({wb_tolerance:g})",
        )

    return True, water_balance_error, "ok"


def run_single_model(
    model_name: str,
    climate: dict[str, np.ndarray],
    *,
    delta_t: float,
    wb_tolerance: float,
) -> ModelCheckResult:
    model = create_model(model_name)
    theta = build_theta_from_par_ranges(model)
    stores = build_initial_stores(model)

    payload = {
        "theta": theta,
        "delta_t": float(delta_t),
        "initial_stores": stores,
        "climate": {
            "precip": np.asarray(climate["precip"], dtype=np.float64),
            "temp": np.asarray(climate["temp"], dtype=np.float64),
            "pet": np.asarray(climate["pet"], dtype=np.float64),
        },
        "compile_target": "python",
    }

    try:
        model.run(config=payload)
        q_sim = np.asarray(model.get_streamflow(), dtype=np.float64)
        correct, wb_error, message = check_correctness(
            model,
            q_sim,
            expected_steps=int(climate["precip"].shape[0]),
            wb_tolerance=wb_tolerance,
        )
        return ModelCheckResult(
            model=model_name,
            run_ok=True,
            correct=bool(correct),
            status=int(model.status),
            steps=int(q_sim.shape[0]),
            water_balance_error=float(wb_error) if np.isfinite(wb_error) else None,
            message=message,
        )
    except Exception as exc:
        return ModelCheckResult(
            model=model_name,
            run_ok=False,
            correct=False,
            status=int(getattr(model, "status", 0)),
            steps=0,
            water_balance_error=None,
            message=f"{exc.__class__.__name__}: {exc}",
        )


def print_report(results: list[ModelCheckResult]) -> None:
    total = len(results)
    run_ok_count = sum(1 for result in results if result.run_ok)
    correct_count = sum(1 for result in results if result.correct)

    print("=" * 120)
    print("PyRRMod Batch Model Run Report (Python backend only)")
    print("=" * 120)
    print(
        f"Total models: {total} | Run succeeded: {run_ok_count} | Correctness passed: {correct_count} | "
        f"Failures/exceptions: {total - run_ok_count}"
    )
    print("-" * 120)
    print(
        f"{'Model':<14} {'RunOK':<7} {'Correct':<8} {'Status':<7} {'Steps':<8} "
        f"{'WBError':<15} Message"
    )
    print("-" * 120)

    for result in results:
        wb_text = (
            "-"
            if result.water_balance_error is None
            else f"{result.water_balance_error:.3e}"
        )
        print(
            f"{result.model:<14} {str(result.run_ok):<7} {str(result.correct):<8} "
            f"{str(result.status):<7} {str(result.steps):<8} {wb_text:<15} {result.message}"
        )

    print("-" * 120)
    failed_models = [result.model for result in results if not result.run_ok]
    incorrect_models = [
        result.model for result in results if result.run_ok and not result.correct
    ]
    print(f"Failed models: {failed_models if failed_models else 'None'}")
    print(
        f"Correctness-check failed models: {incorrect_models if incorrect_models else 'None'}"
    )
    print("=" * 120)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Batch run all registered models with python backend and generate report."
    )
    parser.add_argument(
        "--n-steps",
        type=int,
        default=120,
        help="Number of forcing steps to run from data/03604000.csv.",
    )
    parser.add_argument(
        "--delta-t",
        type=float,
        default=1.0,
        help="Simulation time step.",
    )
    parser.add_argument(
        "--wb-tolerance",
        type=float,
        default=1e-3,
        help="Absolute tolerance for water balance error correctness check.",
    )
    parser.add_argument(
        "--report-file",
        type=Path,
        default=None,
        help="Optional JSON file path for detailed report.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    climate = load_climate(args.n_steps)
    model_names = sorted(MODEL_REGISTRY)

    results: list[ModelCheckResult] = []
    for model_name in model_names:
        result = run_single_model(
            model_name,
            climate,
            delta_t=args.delta_t,
            wb_tolerance=args.wb_tolerance,
        )
        results.append(result)

    print_report(results)

    if args.report_file is not None:
        args.report_file.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "data_file": str(DATA_FILE),
            "n_steps": int(args.n_steps),
            "delta_t": float(args.delta_t),
            "wb_tolerance": float(args.wb_tolerance),
            "total_models": len(results),
            "run_ok_count": sum(1 for result in results if result.run_ok),
            "correct_count": sum(1 for result in results if result.correct),
            "results": [asdict(result) for result in results],
        }
        args.report_file.write_text(
            json.dumps(payload, indent=2),
            encoding="utf-8",
        )
        print(f"JSON report saved to: {args.report_file}")


if __name__ == "__main__":
    main()
