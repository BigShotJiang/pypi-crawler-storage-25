# pyrrmod Examples

This folder shows the recommended simulation input interface based on
Pydantic payloads and MCP-friendly output.

## Prerequisites

- Install dependencies from `pyproject.toml`.
## Files

- `01_basic_run.py`: minimal model run using `ModelRunInput`.
- `02_mcp_payload.py`: parse an MCP-style dictionary payload and return JSON-safe output.

## Run

```bash
python examples/01_basic_run.py
python examples/02_mcp_payload.py
```
