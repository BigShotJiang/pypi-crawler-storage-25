from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from types import MethodType

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pyrrmod.models import xinanjiang


DATA_FILE = PROJECT_ROOT / "data" / "03604000.csv"


def build_config(
    compile_target: str,
    *,
    resnorm_tolerance: float,
    resnorm_maxiter: int,
) -> dict[str, object]:
    data = np.loadtxt(DATA_FILE, delimiter=",", skiprows=1)
    return {
        "theta": [
            0.30,
            0.10,
            2.00,
            500.0,
            0.50,
            0.50,
            0.30,
            1.50,
            0.05,
            0.03,
            0.10,
            0.05,
        ],
        "delta_t": 1.0,
        "initial_stores": [120.0, 80.0, 30.0, 20.0],
        "climate": {
            "precip": data[:, 0],
            "temp": data[:, 1],
            "pet": data[:, 2],
        },
        "solver_options": {
            "resnorm_tolerance": resnorm_tolerance,
            "resnorm_maxiter": resnorm_maxiter,
        },
        "compile_target": compile_target,
    }


def force_solver_backend(model: xinanjiang, solver_backend: str) -> None:
    if solver_backend == "default":
        return

    def solve_stores_with_scipy(
        self: xinanjiang,
        previous_states: np.ndarray,
    ) -> tuple[np.ndarray, float, str, int]:
        previous = np.asarray(previous_states, dtype=np.float64).reshape(-1)
        current_states, residuals, _, iterations = self.rerun_solver(
            solver_backend,
            previous,
            previous,
        )
        residual_array = np.asarray(residuals, dtype=np.float64).reshape(-1)
        resnorm = float(np.sum(residual_array**2))
        return current_states, resnorm, solver_backend, int(iterations)

    model.solve_stores = MethodType(solve_stores_with_scipy, model)


def timed_run(
    model: xinanjiang,
    *,
    config: dict[str, object] | None = None,
) -> float:
    start = time.perf_counter()
    if config is None:
        model.run()
    else:
        model.run(config=config)
    return time.perf_counter() - start


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Benchmark xinanjiang with python vs numba backends."
    )
    parser.add_argument(
        "--solver-backend",
        choices=("default", "fsolve", "lsqnonlin"),
        default="default",
        help="Solver strategy for state solving.",
    )
    parser.add_argument(
        "--resnorm-tolerance",
        type=float,
        default=0.1,
        help="Residual tolerance scaling used by solver options.",
    )
    parser.add_argument(
        "--resnorm-maxiter",
        type=int,
        default=6,
        help="Maximum restart attempts used in rerun_solver.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    python_model = xinanjiang()
    force_solver_backend(python_model, args.solver_backend)
    python_config = build_config(
        "python",
        resnorm_tolerance=args.resnorm_tolerance,
        resnorm_maxiter=args.resnorm_maxiter,
    )
    python_elapsed = timed_run(python_model, config=python_config)
    python_q = python_model.get_streamflow()
    python_solver_data = python_model.solver_data
    python_solvers = []
    if python_solver_data is not None:
        python_solvers = [
            str(value)
            for value in np.unique(np.asarray(python_solver_data["solver"]).reshape(-1))
        ]

    numba_model = xinanjiang()
    force_solver_backend(numba_model, args.solver_backend)
    numba_config = build_config(
        "numba",
        resnorm_tolerance=args.resnorm_tolerance,
        resnorm_maxiter=args.resnorm_maxiter,
    )
    numba_cold_elapsed = timed_run(numba_model, config=numba_config)
    numba_warm_elapsed = timed_run(numba_model)
    numba_q = numba_model.get_streamflow()
    numba_solver_data = numba_model.solver_data
    numba_solvers = []
    if numba_solver_data is not None:
        numba_solvers = [
            str(value)
            for value in np.unique(np.asarray(numba_solver_data["solver"]).reshape(-1))
        ]

    max_abs_diff = float(np.max(np.abs(python_q - numba_q)))
    cold_speedup = (
        python_elapsed / numba_cold_elapsed if numba_cold_elapsed > 0 else np.nan
    )
    warm_speedup = (
        python_elapsed / numba_warm_elapsed if numba_warm_elapsed > 0 else np.nan
    )

    print(f"dataset: {DATA_FILE}")
    print(f"solver backend: {args.solver_backend}")
    print(
        "solver opts: "
        f"resnorm_tolerance={args.resnorm_tolerance}, "
        f"resnorm_maxiter={args.resnorm_maxiter}"
    )
    print(f"timesteps: {python_q.size}")
    print()
    print(f"python run time: {python_elapsed:.6f} s")
    print(f"numba cold run time: {numba_cold_elapsed:.6f} s")
    print(f"numba warm run time: {numba_warm_elapsed:.6f} s")
    print()
    print(f"cold speedup (python/numba cold): {cold_speedup:.2f}x")
    print(f"warm speedup (python/numba warm): {warm_speedup:.2f}x")
    print(f"compiler target resolved: {numba_model.compiler.target}")
    print(f"compiler detail: {numba_model.compiler.detail}")
    print(f"solvers used (python): {python_solvers}")
    print(f"solvers used (numba): {numba_solvers}")
    print(f"max |Q_python - Q_numba|: {max_abs_diff:.3e}")
    print(f"water balance error (python): {python_model.check_water_balance():.3e}")
    print(f"water balance error (numba): {numba_model.check_water_balance():.3e}")


if __name__ == "__main__":
    main()
