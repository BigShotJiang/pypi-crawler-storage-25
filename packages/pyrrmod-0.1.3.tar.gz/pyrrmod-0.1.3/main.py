def main():
    print("Hello from pyrrmod!")


if __name__ == "__main__":
    main()
