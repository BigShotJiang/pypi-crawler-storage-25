from setuptools import setup, find_packages

setup(
    name='faskip',
    version='0.0.1',
    packages=find_packages(),
    description='Reserved package - demo version',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    classifiers=[
        'Development Status :: 1 - Planning',  # 规划中状态
    ],
)