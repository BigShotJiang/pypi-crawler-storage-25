#-----------------------------------------------------------------------
# Name:        didanalysis_helper (diffindiff package)
# Purpose:     Helper functions for didanalysis module
# Author:      Thomas Wieland 
#              ORCID: 0000-0001-5168-9846
#              mail: geowieland@googlemail.com              
# Version:     1.2.0
# Last update: 2025-05-01 09:28
# Copyright (c) 2025-2026 Thomas Wieland
#-----------------------------------------------------------------------

import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import ols
from patsy.highlevel import dmatrices
import numpy as np
from datetime import datetime
import diffindiff.didtools as tools
import diffindiff.config as config


def create_fixed_effects(
    data: pd.DataFrame,
    col: str,
    type: str = "unit",
    drop_first: bool = False,
    verbose: bool = config.VERBOSE
    ):

    """
    Create dummy variables for fixed effects and attach them to the data.

    Parameters
    ----------
    data : pandas.DataFrame
        Input data frame.
    col : str
        Column for which to create fixed-effect dummies.
    type : {'unit','time','group'}, optional
        Type of fixed effect to create.
    drop_first : bool, optional
        If True, drop the first dummy.
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    list
        [data_with_dummies (DataFrame), dummies_join (str), dummy_vars (list), dummy_original (list)]

    Raises
    ------
    ValueError
        If ``type`` is not supported.

    Examples
    --------
    >>> create_fixed_effects(df, 'unit', type='unit')
    """
    
    if type not in config.FE_TYPES:
        raise ValueError(f"Parameter 'type' must be one of the following: {', '.join(config.FE_TYPES)}")

    for key, value in config.EFFECTS_TYPES["FE"]["types"].items():

        if value["FE"] == type:
            
            prefix = value["dummy_prefix"]
            
            if verbose:
                print(f"Creating {value['description']} for column '{col}' with prefix '{prefix}{config.DELIMITER}'", end = " ... ")
    
    dummy_unit_original = list(data[col].astype(str).unique())
    
    dummy_unit_vars = [f"{prefix}{config.DELIMITER}{tools.clean_column_name(val)}" for val in dummy_unit_original]    
    
    dummies = pd.DataFrame(
        pd.get_dummies(
            data = data[col].astype(str),
            dtype = int,
            prefix = prefix,
            prefix_sep = config.DELIMITER,
            drop_first = drop_first
            )
        )

    dummies.columns = [tools.clean_column_name(col) for col in dummies.columns]

    data = pd.concat([data, dummies], axis=1)

    dummies_join = " + ".join(dummies.columns)

    if verbose:
        print("OK")

    return [
        data, 
        dummies_join, 
        dummy_unit_vars,
        dummy_unit_original
        ]

def demean_variables(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    outcome_col: str,
    treatment_col: list,
    covariates: list = None,
    spillover_vars: list = None,
    interactions: list = None,
    TG_col: list = None,
    TT_col: list = None,
    after_treatment_col: list = None,
    ATT_col: list = None,
    FE_unit: bool = False,
    FE_time: bool = False,
    max_iter=10,
    tol=1e-8,
    verbose: bool = config.VERBOSE    
    ):
    
    """
    Demean numeric variables by removing unit and/or time means.

    The function appends demeaned versions of the specified variables to a copy
    of `data`. Demeaning can be done by unit means, by time means, or by an
    iterative two-way procedure that alternates unit- and time-demeaning until
    convergence (or until `max_iter` is reached).

    Parameters
    ----------
    data : pandas.DataFrame
        Panel data containing unit and time identifiers and the variables to demean.
    unit_col : str
        Column name identifying the cross-sectional unit (e.g. individual or region).
    time_col : str
        Column name identifying the time period (e.g. year, date index).
    outcome_col : str
        Name of the primary outcome variable to be demeaned (included in the
        returned mapping).
    treatment_col : list
        List of treatment variable names to be demeaned.
    covariates : list, optional
        Additional covariate column names to demean (default: None).
    spillover_vars : list, optional
        Names of spillover variables to demean (default: None).
    interactions : list, optional
        Names of interaction variables to demean (default: None).
    FE_unit : bool, optional
        If True, remove unit means (within-unit demeaning). Default is False.
    FE_time : bool, optional
        If True, remove time means (within-time demeaning). Default is False.
    max_iter : int, optional
        Maximum number of iterations for the iterative two-way demeaning
        (when both `FE_unit` and `FE_time` are requested). Default is 10.
    tol : float, optional
        Convergence tolerance for iterative demeaning. Iteration stops when the
        maximum absolute change across observations is below `tol`. Default is 1e-8.
    verbose : bool, optional
        If True, print progress and informational messages (default: config.VERBOSE).

    Returns
    -------
    tuple
        (data_demean, cols_to_demean_new)
        - data_demean : pandas.DataFrame
            A copy of `data` with new demeaned columns appended. Each original
            column receives a new column named ``<orig><DELIMITER><suffix>``.
        - cols_to_demean_new : dict
            Dictionary mapping the original variable categories to their new
            demeaned column names. Keys include: ``outcome_col``, ``treatment_col``, 
            ``covariates``, ``spillover_vars``, ``interactions``.

    Examples
    --------
    >>> df = pd.DataFrame({
    ...     'unit': ['a','a','b','b'],
    ...     'time': [1,2,1,2],
    ...     'y': [1.0,2.0,3.0,4.0],
    ...     'x1': [10,11,12,13]
    ...     })
    >>> data_demean, cols_to_demean_new = demean_variables(
    ...     data=df,
    ...     unit_col='unit',
    ...     time_col='time',
    ...     outcome_col='y',
    ...     treatment_col=[],
    ...     covariates=['x1'],
    ...     FE_unit=True,
    ...     FE_time=False
    ...     )
    """

    def demean(numeric_vector):
        
        numeric_vector_demeaned = numeric_vector - numeric_vector.mean()
        
        return numeric_vector_demeaned

    if covariates is None:
        covariates = []
    if spillover_vars is None:
        spillover_vars = []
    if interactions is None:
        interactions = []
    if TG_col is None:
        TG_col = []
    if TT_col is None:
        TT_col = []
    if after_treatment_col is None:
        after_treatment_col = []
    if ATT_col is None:
        ATT_col = []

    data_demean = data.copy()
    
    cols_to_demean = [outcome_col] + treatment_col + covariates + spillover_vars + interactions
    
    cols_to_demean_new = {}
    cols_to_demean_new["outcome_col"] = ""
    cols_to_demean_new["treatment_col"] = {}
    cols_to_demean_new["covariates"] = {}
    cols_to_demean_new["spillover_vars"] = {}
    cols_to_demean_new["interactions"] = {}
    cols_to_demean_new["TG_col"] = {}
    cols_to_demean_new["TT_col"] = {}
    cols_to_demean_new["after_treatment_col"] = {}
    cols_to_demean_new["ATT_col"] = {}

    suffix = f"{config.DELIMITER}{config.DEMEAN_SUFFIX}"

    if not FE_unit and not FE_time:
        
        print("NOTE: Neither 'FE_unit' nor 'FE_time' is set to True. No demeaning will be performed.")
        
        for col in cols_to_demean:

            if col == outcome_col:
                cols_to_demean_new["outcome_col"] = col
            elif col in treatment_col:
                cols_to_demean_new["treatment_col"][col] = col
            elif col in spillover_vars:
                cols_to_demean_new["spillover_vars"][col] = col
            elif col in interactions:
                cols_to_demean_new["interactions"][col] = col
            elif col in TG_col:
                cols_to_demean_new["TG_col"][col] = col
            elif col in TT_col:
                cols_to_demean_new["TT_col"][col] = col
            elif col in after_treatment_col:
                cols_to_demean_new["after_treatment_col"][col] = col
            elif col in ATT_col:
                cols_to_demean_new["ATT_col"][col] = col
            else:
                cols_to_demean_new["covariates"][col] = col
    
    else:
        
        tools.check_columns(
            df = data,
            columns = cols_to_demean + [unit_col] + [time_col],
            verbose = verbose
            )
                
        tools.is_numeric(
            df = data,
            columns = cols_to_demean,
            verbose = verbose
            )
         
        if FE_unit and not FE_time:
            
            if verbose:
                print(f"Demeaning variables {', '.join(cols_to_demean)} by removing unit means", end = " ... ")

            for col in cols_to_demean:
                
                col_demeaned = f"{col}{suffix}"
                
                data_demean[col_demeaned] = data_demean.groupby(data_demean[unit_col])[col].transform(demean)
                
                if col == outcome_col:
                    cols_to_demean_new["outcome_col"] = col_demeaned
                elif col in treatment_col:
                    cols_to_demean_new["treatment_col"][col] = col_demeaned
                elif col in spillover_vars:
                    cols_to_demean_new["spillover_vars"][col] = col_demeaned
                elif col in interactions:
                    cols_to_demean_new["interactions"][col] = col_demeaned
                elif col in TG_col:
                    cols_to_demean_new["TG_col"][col] = col_demeaned
                elif col in TT_col:
                    cols_to_demean_new["TT_col"][col] = col_demeaned
                elif col in after_treatment_col:
                    cols_to_demean_new["after_treatment_col"][col] = col_demeaned
                elif col in ATT_col:
                    cols_to_demean_new["ATT_col"][col] = col_demeaned
                else:
                    cols_to_demean_new["covariates"][col] = col_demeaned

            if verbose:
                print("OK")

        elif FE_time and not FE_unit:

            if verbose:
                print(f"Demeaning variables {', '.join(cols_to_demean)} by removing time means", end = " ... ")

            for col in cols_to_demean:

                col_demeaned = f"{col}{suffix}"
                
                data_demean[col_demeaned] = data_demean.groupby(data_demean[time_col])[col].transform(demean)
                
                if col == outcome_col:
                    cols_to_demean_new["outcome_col"] = col_demeaned
                elif col in treatment_col:
                    cols_to_demean_new["treatment_col"][col] = col_demeaned
                elif col in spillover_vars:
                    cols_to_demean_new["spillover_vars"][col] = col_demeaned
                elif col in interactions:
                    cols_to_demean_new["interactions"][col] = col_demeaned
                elif col in TG_col:
                    cols_to_demean_new["TG_col"][col] = col_demeaned
                elif col in TT_col:
                    cols_to_demean_new["TT_col"][col] = col_demeaned
                elif col in after_treatment_col:
                    cols_to_demean_new["after_treatment_col"][col] = col_demeaned
                elif col in ATT_col:
                    cols_to_demean_new["ATT_col"][col] = col_demeaned
                else:
                    cols_to_demean_new["covariates"][col] = col_demeaned

            if verbose:
                print("OK")

        else:

            if verbose:
                print(f"Demeaning variables {', '.join(cols_to_demean)} by iteratively removing unit and time means with max. {max_iter} iterations and tolerance = {tol}", end = " ... ")

            cols_steps = {}
            
            for col in cols_to_demean:

                v = data_demean[col].copy()
                
                for step in range(max_iter):

                    v_old = v.copy()
                    
                    v = v.groupby(data_demean[unit_col]).transform(demean)
                    
                    v = v.groupby(data_demean[time_col]).transform(demean)
                    
                    if (v - v_old).abs().max() < tol:

                        cols_steps[col] = step + 1
                        
                        break

                    if step+1 == max_iter:
                        
                        cols_steps[col] = step + 1
                        print(f"WARNING: Demeaning for column '{col}' did not converge within {max_iter} iterations. Consider increasing 'max_iter' or 'tol' parameters.")
                
                col_demeaned = f"{col}{suffix}" 
                data_demean[col_demeaned] = v

                if col == outcome_col:
                    cols_to_demean_new["outcome_col"] = col_demeaned
                elif col in treatment_col:
                    cols_to_demean_new["treatment_col"][col] = col_demeaned
                elif col in spillover_vars:
                    cols_to_demean_new["spillover_vars"][col] = col_demeaned
                elif col in interactions:
                    cols_to_demean_new["interactions"][col] = col_demeaned
                elif col in TG_col:
                    cols_to_demean_new["TG_col"][col] = col_demeaned
                elif col in TT_col:
                    cols_to_demean_new["TT_col"][col] = col_demeaned
                elif col in after_treatment_col:
                    cols_to_demean_new["after_treatment_col"][col] = col_demeaned
                elif col in ATT_col:
                    cols_to_demean_new["ATT_col"][col] = col_demeaned
                else:
                    cols_to_demean_new["covariates"][col] = col_demeaned                
            
            if verbose:
                print("OK")
                print(f"NOTE: Demeaning completed in {max_iter} iterations with the following number of steps until convergence: {', '.join([f'{col}: {steps}' for col, steps in cols_steps.items()])}.")
        
    return data_demean, cols_to_demean_new

def create_specific_time_trends(    
    data: pd.DataFrame,
    time_col: str,
    FE_vars: list,
    type: str = "ITT",
    verbose: bool = config.VERBOSE
    ):

    """
    Create unit-specific time trend variables (interactions with a time counter).

    Parameters
    ----------
    data : pandas.DataFrame
        Input data frame.
    time_col : str
        Column name for time variable.
    FE_vars : list
        List of fixed-effect dummy column names to interact with time.
    type : str, optional
        Type label for the created trends: 'ITT' for individual-specific,
        'GTT' for group-specific (default 'ITT').
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    list
        [data_with_trends (DataFrame), join_string (str), trend_vars (Index)]

    Raises
    ------
    ValueError
        If ``type`` is not supported.

    Examples
    --------
    >>> create_specific_time_trends(df, 'date', ['FE_A', 'FE_B'])
    """
    
    if type not in config.TIME_TRENDS_TYPES:
        raise ValueError(f"Parameter 'type' must be one of the following: {', '.join(config.TIME_TRENDS_TYPES)}")
    
    tools.check_columns(
        df = data,
        columns = FE_vars,
        verbose = verbose
        )
    
    data = tools.date_counter(
        data,
        time_col,
        new_col=config.TIME_COUNTER_COL,
        verbose = verbose
        )
    
    if verbose:
        print(f"Creating {config.EFFECTS_TYPES[type]['description']} for {len(FE_vars)} entities with suffix '{config.DELIMITER}{config.TIME_COL}'", end = " ... ")
    
    id_x_time = pd.DataFrame()
    
    for col in FE_vars:
        
        if col in data.columns:
            
            id_x_time[col] = data[col] * data[config.TIME_COUNTER_COL]
            new_col_name = f"{col}{config.DELIMITER_INTERACT}{config.TIME_COL}"
            id_x_time = id_x_time.rename(columns={col: new_col_name})
            
    data = pd.concat([data, id_x_time], axis = 1)
    
    time_trend_vars = id_x_time.columns
    id_x_time_join = " + ".join(time_trend_vars)
    
    if verbose:
        print("OK")
    
    return [
        data, 
        id_x_time_join, 
        time_trend_vars
        ]

def create_specific_treatment_effects(
    data: pd.DataFrame,
    treatment_col: list,
    FE_vars: list,
    type: str = "ITE",
    verbose: bool = config.VERBOSE
    ):

    """
    Create unit-specific treatment effect interaction variables.

    Parameters
    ----------
    data : pandas.DataFrame
        Input data.
    treatment_col : list
        Treatment column names to interact with FE variables.
    FE_vars : list
        Fixed-effect dummy columns to interact.
    type : str, optional
        Type label for specific effects: 'ITE' for individual-specific,
        'GTE' for group-specific (default 'ITE').
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    list
        [data_with_interactions (DataFrame), join_string (str), interaction_vars (Index)]

    Raises
    ------
    ValueError
        If ``type`` is not supported.

    Examples
    --------
    >>> create_specific_treatment_effects(df, ['treat'], ['FE_A'])
    """
    
    if type not in config.SPECIFIC_EFFFECTS_TYPES:
        raise ValueError(f"Parameter 'type' must be one of the following: {', '.join(config.SPECIFIC_EFFFECTS_TYPES)}")
    
    tools.check_columns(
        df = data,
        columns = FE_vars,
        verbose = verbose
        )   
    
    if verbose:
        print(f"Creating {config.EFFECTS_TYPES[type]['description']} for {len(FE_vars)} entities and {len(treatment_col)} treatments", end = " ... ")
        
    id_x_treatment = pd.DataFrame()
            
    for col in FE_vars:
        
        if col in data.columns:
        
            for treatment in treatment_col:
                                  
                id_x_treatment[col] = data[col] * data[treatment]
                new_col_name = f"{treatment}{config.DELIMITER}{col}"
                id_x_treatment = id_x_treatment.rename(columns={col: new_col_name})
                
                if id_x_treatment[new_col_name].sum() == 0:
                    id_x_treatment = id_x_treatment.drop(columns=[new_col_name])                    
                
    data = pd.concat([data, id_x_treatment], axis = 1)
    
    id_treatment_vars = id_x_treatment.columns
    id_x_treatment_join = ' + '.join(id_treatment_vars)
    
    if verbose:
        print("OK")

    return [
        data, 
        id_x_treatment_join, 
        id_treatment_vars
        ]
        
def create_spillover(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    treatment_col: list,
    TT_col: str = None,
    spillover_treatment: list = None,
    spillover_units: list = None,
    verbose: bool = config.VERBOSE
    ):

    """
    Create spillover indicator variables for given treatments and units.

    Parameters
    ----------
    data : pandas.DataFrame
        Panel data frame.
    unit_col : str
        Unit identifier column.
    time_col : str
        Time identifier column.
    treatment_col : list
        List of treatment column names to base spillovers on.
    TT_col : str, optional
        Treatment time column to use; created if not present.
    spillover_treatment : list
        Treatments to consider for spillover creation.
    spillover_units : list
        Units to be marked as spillover-exposed.
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    list
        [data_with_spillover (DataFrame), join_string (str), spillover_vars (list)]

    Raises
    ------
    ValueError
        If ``spillover_treatment`` or ``spillover_units`` are empty.

    Examples
    --------
    >>> create_spillover(df, 'unit', 'time', ['treat'], spillover_treatment=['treat'], spillover_units=['u1'])
    """
    
    if spillover_treatment is None:
        spillover_treatment = []
    if spillover_units is None:
        spillover_units = []
        
    if len(spillover_treatment) == 0:
        raise ValueError("Parameter 'spillover_treatment' does not contain any treatment")
    if len(spillover_units) == 0:
        raise ValueError("Parameter 'spillover_units' does not contain any treatment")

    if verbose:
        print(f"Creating spillover variables for treatment(s) {', '.join(treatment_col)} and {len(spillover_units)} units", end = " ... ")

    spillover_unit_vars = []
    spillover_treatment_vars = []

    for treatment in treatment_col:

        if TT_col is None:
            
            TT_col = config.TT_COL

            data = tools.treatment_time_col(
                data = data,
                unit_col = unit_col,
                time_col = time_col,
                treatment_col = treatment,
                create_TT_col = TT_col,
                verbose = False
                )[0]          

        sp_unit_col = f"{config.SPILLOVER_UNIT_PREFIX}{config.DELIMITER}{treatment}"
        sp_treatment_col = f"{config.SPILLOVER_PREFIX}{config.DELIMITER}{treatment}"

        data[sp_unit_col] = 0
        data[sp_treatment_col] = 0

        spillover_unit_vars.append(sp_unit_col)
        spillover_treatment_vars.append(sp_treatment_col)

        data.loc[
            data[unit_col].astype(str).isin(spillover_units),
            sp_unit_col
            ] = 1
        
        data[sp_treatment_col] = data[sp_unit_col]*data[TT_col]

    spillover_treatment_vars_join = ' + '.join(spillover_treatment_vars)

    if verbose:
        print("OK")

    return [
        data,
        spillover_treatment_vars_join,
        spillover_treatment_vars
        ]
    
def create_interactions(
    data: pd.DataFrame,
    interactions: dict = None,
    verbose: bool = config.VERBOSE
    ):

    """
    Create interaction variables by multiplying specified treatment columns.

    Parameters
    ----------
    data : pandas.DataFrame
        Input data frame containing treatment columns.
    interactions : dict, optional
        Dictionary defining interaction variables. Each entry should be a
        mapping with keys "name" (desired new column name) and
        "treatments" (list of existing treatment column names to multiply).
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    list
        [data_with_interactions (DataFrame), join_string (str), interaction_vars (list)]

    Raises
    ------
    TypeError
        If ``interactions`` is not a dict.
    KeyError
        If a stated interaction name already exists in `data` or if any
        referenced treatment column does not exist in `data`.
    ValueError
        If fewer than two treatments are provided to build an interaction.

    Examples
    --------
    >>> create_interactions(
    ...     df, 
    ...     {
    ...         0: {
    ...             'name': 'interaction_col', 
    ...             'treatments': ['treatment1', 'treatment2']
    ...         }
    ...     }
    ... )
    """
    
    if interactions is None:
        interactions = {}
        
    if not isinstance(interactions, dict):
        raise TypeError("Parameter 'interactions' must be a dict") 
      
    interaction_vars = []
    
    if len(interactions) > 0:
        
        if verbose:
            print(f"Creating {len(interactions)} interaction variables", end = " ... ")
        
        for key, value in interactions.items():
            
            interaction_var_name = value["name"]
            
            if interaction_var_name in data.columns:
                raise KeyError(f"Stated column name '{interaction_var_name}' already exists in data frame")
            
            interaction_var_name = tools.clean_column_name(interaction_var_name)
            
            interaction_vars.append(interaction_var_name)            
            
            treatments = value["treatments"]
            
            if len (treatments) < 2:
                raise ValueError(f"To build interaction variables, at least two treatment variables must be stated, not {len(treatments)}")            
            
            treatment_cols_not_available = []            
            
            for treatment in treatments:
                if treatment not in data.columns:
                    treatment_cols_not_available.append(treatment)
            
            if len(treatment_cols_not_available) > 0:                    
                raise KeyError(f"The following column(s) stated do not exist in the data frame: {', '.join(treatment_cols_not_available)}")            
            
            treatment1 = treatments[0]
            
            data[interaction_var_name] = data[treatment1]
            
            for key, treatment in enumerate(treatments):
                
                if key == 0:
                    continue
                
                data[interaction_var_name] = data[interaction_var_name]*data[treatment]
            
        if verbose:
            print("OK")
            
            if len(interaction_vars) > 0:
                print(f"NOTE: The following {len(interaction_vars)} interaction variables were created: {', '.join(interaction_vars)}.")
    
    else:
        
        print("WARNING: Parameter 'interactions' was not set. No interaction variables were created.")
    
    interaction_vars_join = ' + '.join(interaction_vars)
    
    return [
        data,
        interaction_vars_join,
        interaction_vars
        ]

def data_diagnostics(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    outcome_col: str,
    cols_relevant: list = None,
    drop_missing: bool = True,
    missing_replace_by_zero: bool = False,
    verbose: bool = config.VERBOSE
    ):

    """
    Run diagnostics on model data: missingness, balance and basic stats.

    Parameters
    ----------
    data : pandas.DataFrame
        Panel data.
    unit_col : str
        Unit id column.
    time_col : str
        Time column.
    outcome_col : str
        Outcome variable name.
    cols_relevant : list, optional
        List of further relevant columns considered for balance checks.
    drop_missing : bool, optional
        If True, drop missing observations.
    missing_replace_by_zero : bool, optional
        If True, replace missing values with zero.
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    dict
        Dictionary of diagnostic indicators (balanced, missing, prepost, statistics...).

    Examples
    --------
    >>> data_diagnostics(df, 'unit', 'time', 'y')
    """

    if cols_relevant is None:
        cols_relevant = []

    modeldata_ispanel = tools.is_panel(
        data=data,
        unit_col=unit_col,
        time_col=time_col,
        verbose=verbose
    )
    
    if not modeldata_ispanel[0]:
        raise TypeError(f"A difference-in-differences analysis requires panel data with at least two observational units and time points, respectively. Input data is likely {modeldata_ispanel[1]}")

    modeldata_ismissing = tools.is_missing(
        data, 
        drop_missing = drop_missing,
        missing_replace_by_zero = missing_replace_by_zero,
        verbose = verbose
        )    

    if modeldata_ismissing[0]:        

        if drop_missing or missing_replace_by_zero:
            data = modeldata_ismissing[2]           

        if not drop_missing and not missing_replace_by_zero:
            print("WARNING: Missing values are not cleaned. Model may crash.")   
    
    other_cols_relevant = [col for col in cols_relevant if col not in [unit_col, time_col, outcome_col]]

    modeldata_isbalanced = tools.is_balanced(
        data = data,
        unit_col = unit_col,
        time_col = time_col,
        outcome_col = outcome_col,
        other_cols = other_cols_relevant,
        verbose = verbose
        )
    
    modeldata_isprepost = tools.is_prepost(
        data = data,
        unit_col = unit_col,
        time_col = time_col,
        verbose = verbose
        )
    if modeldata_isprepost:
        data_type = config.PREPOST_PANELDATA_DESCRIPTION
    else:
        data_type = config.MULTIPERIOD_PANELDATA_DESCRIPTION
    
    observations = len(data)
    
    outcome_mean = np.mean(data[outcome_col])
    outcome_sd = np.std(data[outcome_col])
    
    data_diagnostics_results = {
        list(config.DATA_DIAGNOSTICS)[0]: bool(modeldata_isbalanced),
        list(config.DATA_DIAGNOSTICS)[1]: bool(modeldata_ismissing[0]),
        list(config.DATA_DIAGNOSTICS)[2]: bool(drop_missing),
        list(config.DATA_DIAGNOSTICS)[3]: bool(missing_replace_by_zero),
        list(config.DATA_DIAGNOSTICS)[4]: bool(modeldata_isprepost),
        list(config.DATA_DIAGNOSTICS)[5]: data_type,
        list(config.DATA_DIAGNOSTICS)[6]: outcome_col, 
        list(config.DATA_DIAGNOSTICS)[7]: f"Mean={round(outcome_mean, config.ROUND_STATISTIC)} SD={round(outcome_sd, config.ROUND_STATISTIC)}",
        list(config.DATA_DIAGNOSTICS)[8]: observations,        
        }
    
    return data_diagnostics_results

def treatment_diagnostics(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    treatment_col: list,
    outcome_col: str,
    pre_post: bool = False,
    confint_alpha = 0.05,
    verbose: bool = config.VERBOSE    
    ):
    
    """
    Compute diagnostics for each treatment: simultaneity, parallel trends, 
    binary format, etc.

    Parameters
    ----------
    data : pandas.DataFrame
        Panel data.
    unit_col : str
        Unit id column.
    time_col : str
        Time column.
    treatment_col : list
        List of treatment column names.
    outcome_col : str
        Outcome variable name used for tests.
    pre_post : bool, optional
        If True, data are treated as pre-post (skip some tests).
    confint_alpha : float, optional
        Significance level for parallel trends test.
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    list
        [treatment_diagnostics_results (dict), staggered_adoption (bool), untreated (list)]

    Examples
    --------
    >>> treatment_diagnostics(df, 'unit', 'time', ['treat'], 'y')
    """

    if verbose:
        print("Treatment diagnostics:")

    no_treatments = len(treatment_col)

    treatment_diagnostics_results = {}

    staggered_adoption = False

    for i, treatment in enumerate(treatment_col):
            
        is_notreatment_result = tools.is_notreatment(
            data = data,
            unit_col = unit_col,
            treatment_col = treatment,
            verbose = verbose 
            )
        treatment_group_size = int(len(is_notreatment_result[1]))
        control_group_size = int(len(is_notreatment_result[2]))
              
        is_parallel_result = tools.is_parallel(
            data = data,
            unit_col = unit_col,
            time_col = time_col,
            treatment_col = treatment,
            outcome_col = outcome_col,
            pre_post = pre_post,
            alpha = confint_alpha,
            verbose = verbose
            )
        
        is_simultaneous_result = tools.is_simultaneous(
            data = data,
            unit_col = unit_col,
            time_col = time_col,
            treatment_col = treatment,
            pre_post = pre_post,
            verbose = verbose
            )
        if is_simultaneous_result:
            adoption_type = config.TREATMENT_SIMULTANEOUS_DESCRIPTION
        else:
            adoption_type = config.TREATMENT_STAGGERED_DESCRIPTION
                
        is_binary_result = tools.is_binary(
            data = data,
            treatment_col = treatment,
            verbose = verbose
            )
        
        is_multiple_treatment_period_result = tools.is_multiple_treatment_period(
            data = data,
            unit_col = unit_col,
            treatment_col = treatment,
            verbose = verbose
        )
        
        treatment_diagnostics_results[i] = { 
            list(config.TREATMENT_DIAGNOSTICS)[0]: treatment,
            list(config.TREATMENT_DIAGNOSTICS)[1]: bool(is_notreatment_result[0]),
            list(config.TREATMENT_DIAGNOSTICS)[2]: is_notreatment_result[1],
            list(config.TREATMENT_DIAGNOSTICS)[3]: is_notreatment_result[2],
            list(config.TREATMENT_DIAGNOSTICS)[4]: bool(is_parallel_result[0]),
            list(config.TREATMENT_DIAGNOSTICS)[5]: bool(is_simultaneous_result),
            list(config.TREATMENT_DIAGNOSTICS)[6]: adoption_type,
            list(config.TREATMENT_DIAGNOSTICS)[7]: bool(is_binary_result[0]),
            list(config.TREATMENT_DIAGNOSTICS)[8]: is_binary_result[1],
            list(config.TREATMENT_DIAGNOSTICS)[9]: treatment_group_size,
            list(config.TREATMENT_DIAGNOSTICS)[10]: control_group_size,
            list(config.TREATMENT_DIAGNOSTICS)[11]: bool(is_multiple_treatment_period_result[0])
            }

    staggered_count = 0
    for key, value in treatment_diagnostics_results.items():
        if not value["is_simultaneous"]:
            staggered_count = staggered_count+1
    if staggered_count > 0:
        staggered_adoption = True

    untreated = tools.untreated_units(
        data = data,
        unit_col = unit_col,
        treatment_col = treatment_col,
        verbose = verbose
        )
    
    if verbose:
        
        if no_treatments > 1:
            print(f"There are {no_treatments} treatments (simultaneous: {no_treatments-staggered_count}, staggered: {staggered_count}) with {untreated[0]} treated and {untreated[1]} untreated units.")
        else:
            print(f"There is {no_treatments} treatment (staggered: {staggered_count}) with {untreated[0]} treated and {untreated[1]} untreated units.")

    return [
        treatment_diagnostics_results,
        staggered_adoption,
        untreated
    ]

def ols_fit(
    data,
    formula,
    confint_alpha = 0.05,
    cluster_SE_by: str = None,
    verbose: bool = config.VERBOSE
    ):
    
    """
    Estimate an OLS model using a formula and return coefficients and predictions.

    Parameters
    ----------
    data : pandas.DataFrame
        Data frame for estimation.
    formula : str
        Formula for the regression, e.g., 'y ~ x'.
    confint_alpha : float, optional
        Confidence level for intervals.
    cluster_SE_by : str, optional
        Column name used for clustering standard errors.
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    list
        [ols_model, coef, coef_se, tvalues, pvalues, conf_int, predictions]

    Examples
    --------
    >>> ols_fit(df, 'y ~ x')
    """

    if verbose:
        print("Estimating model via Ordinary Least Squares", end = " ... ")  
    
    if cluster_SE_by is not None:
    
        ols_model = ols(
            formula, 
            data=data
            ).fit(
                cov_type="cluster", 
                cov_kwds={"groups": data[cluster_SE_by]} if cluster_SE_by else None
                )

    else:
        
        ols_model = ols(formula, data).fit()
        
    ols_coef = ols_model.params
    ols_coef_se = ols_model.bse
    ols_coef_t = ols_model.tvalues
    ols_coef_p = ols_model.pvalues
    ols_coef_ci = ols_model.conf_int(alpha = confint_alpha)
    
    ols_predictions = ols_model.get_prediction(data).summary_frame(alpha=confint_alpha)
    
    if verbose:
        print("OK")
    
    return [
        ols_model,
        ols_coef,
        ols_coef_se,
        ols_coef_t,
        ols_coef_p,
        ols_coef_ci,
        ols_predictions
    ]
    
def ml_fit(
    data,
    formula,
    confint_alpha = 0.05,
    family=sm.families.Gaussian(),
    link=sm.families.links.Identity(),
    verbose: bool = config.VERBOSE
    ):
    
    """
    Estimate a model by maximum likelihood (GLM) and return coefficients and predictions.

    Parameters
    ----------
    data : pandas.DataFrame
        Data frame for estimation.
    formula : str
        Formula describing the model, e.g., 'y ~ x'.
    confint_alpha : float, optional
        Confidence level for intervals.
    family, link : statsmodels.family, optional
        Family and link used for GLM.
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    list
        [coef, coef_se, zvalues, pvalues, conf_int, predictions]

    Examples
    --------
    >>> ml_fit(df, 'y ~ x')
    """

    if verbose:
        print("Estimating model via Maximum Likelihood", end = " ... ")  
    
    y, X = dmatrices(
        formula, 
        data=data, 
        return_type = "dataframe"
        )

    mle_model = sm.GLM(
        y, 
        X, 
        family=family(link=link)
        ).fit()

    mle_coef = mle_model.params
    mle_coef_se = mle_model.bse
    mle_coef_z = mle_model.tvalues
    mle_coef_p = mle_model.pvalues
    mle_coef_ci = mle_model.conf_int(alpha=confint_alpha)
    
    mle_predictions = mle_model.get_prediction(X).summary_frame(alpha=confint_alpha)

    if verbose:
        print("OK")
        
    return [
        mle_coef,
        mle_coef_se,
        mle_coef_z,
        mle_coef_p,
        mle_coef_ci,
        mle_predictions
    ]
    
def extract_model_results(
    fit_result,
    TG_col: list = None,
    TT_col: list = None,
    treatment_col: list = None,
    after_treatment_col: list = None,
    ATT_col: list = None,
    spillover_vars: list = None,
    FE_unit_vars: list = None,
    dummy_unit_original: list = None,
    FE_time_vars: list = None,
    dummy_time_original: list = None,
    FE_group_vars: list = None,
    dummy_group_original: list = None,
    ITE_vars: list = None,
    GTE_vars: list = None,
    ITT_vars: list = None,
    GTT_vars: list = None,
    TG_x_BG_x_TT_col: list = None,
    BG_col: list = None, 
    TG_x_BG_col: list = None, 
    BG_x_TT_col: list = None,
    covariates: list = None,
    verbose: bool = config.VERBOSE
    ):

    """
    Compile and format model coefficient results into a structured dict.

    Parameters
    ----------
    fit_result : list
        Result returned by ``ols_fit`` or ``ml_fit``.
    Other parameters
        Lists of variable names used to identify coefficients (TG_col, TT_col, etc.).
    verbose : bool, optional
        If True, print progress messages.

    Returns
    -------
    dict
        Structured model results keyed by effect type.

    Examples
    --------
    >>> extract_model_results(fit_result, TG_col=['TG'], treatment_col=['treat'])
    """

    if TG_col is None:
        TG_col = []
    if TT_col is None:
        TT_col = []
    if treatment_col is None:
        treatment_col = []
    if after_treatment_col is None:
        after_treatment_col = []
    if ATT_col is None:
        ATT_col = []
    if spillover_vars is None:
        spillover_vars = []
    if FE_unit_vars is None:
        FE_unit_vars = []
    if dummy_unit_original is None:
        dummy_unit_original = []
    if FE_time_vars is None:
        FE_time_vars = []
    if dummy_time_original is None:
        dummy_time_original = []
    if FE_group_vars is None:
        FE_group_vars = []
    if dummy_group_original is None:
        dummy_group_original = []
    if ITE_vars is None:
        ITE_vars = []
    if GTE_vars is None:
        GTE_vars = []
    if ITT_vars is None:    
        ITT_vars = []
    if GTT_vars is None:
        GTT_vars = []
    if TG_x_BG_x_TT_col is None:
        TG_x_BG_x_TT_col = []
    if BG_col is None:
        BG_col = []
    if TG_x_BG_col is None:
        TG_x_BG_col = []
    if BG_x_TT_col is None:
        BG_x_TT_col = []
    if covariates is None:
        covariates = []

    if verbose:
        print("Compiling model results", end = " ... ")

    coefficients = fit_result[1]
    coef_standarderrors = fit_result[2]
    coef_t = fit_result[3]
    coef_p = fit_result[4]
    coef_conf_intervals = fit_result[5]
    
    no_treatments = len(treatment_col)
    
    model_results = {}

    if (len(treatment_col) > 0) and (any(col in coefficients for col in treatment_col)):
        
        ATE = {}
        
        for i, treatment in enumerate(treatment_col):
            ATE[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: treatment,
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[treatment],
                "SE": float(coef_standarderrors[treatment]),
                "t": float(coef_t[treatment]),
                "p": float(coef_p[treatment]),
                "CI_lower": float(coef_conf_intervals.loc[treatment, 0]),
                "CI_upper": float(coef_conf_intervals.loc[treatment, 1]),
                }
        
        model_results = {config.EFFECTS_TYPES["ATE"]["model_results_key"]: ATE}
    
    if (len(TG_col) > 0) and (any(col in coefficients for col in TG_col)):
        
        beta_1 = {}        
        
        for i, TG_ in enumerate(TG_col):
            beta_1[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: TG_,
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[TG_],
                "SE": float(coef_standarderrors[TG_]),
                "t": float(coef_t[TG_]),
                "p": float(coef_p[TG_]),
                "CI_lower": float(coef_conf_intervals.loc[TG_, 0]),
                "CI_upper": float(coef_conf_intervals.loc[TG_, 1]),
                }
                        
        model_results[config.EFFECTS_TYPES["beta_1"]["model_results_key"]] = beta_1

    if (len(TT_col) > 0) and (any(col in coefficients for col in TT_col)):
        
        delta_0 = {}
        
        for i, TT_ in enumerate(TT_col):
            delta_0[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: TT_,
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[TT_],
                "SE": float(coef_standarderrors[TT_]),
                "t": float(coef_t[TT_]),
                "p": float(coef_p[TT_]),
                "CI_lower": float(coef_conf_intervals.loc[TT_, 0]),
                "CI_upper": float(coef_conf_intervals.loc[TT_, 1]),
                }
        
        model_results[config.EFFECTS_TYPES["delta_0"]["model_results_key"]] = delta_0

    if "Intercept" in coefficients:
        
        beta_0 = {}        
       
        beta_0[0] = {
            config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients["Intercept"], 
            "SE": coef_standarderrors["Intercept"], 
            "t": coef_t["Intercept"], 
            "p": coef_p["Intercept"],
            "CI_lower": coef_conf_intervals.loc["Intercept", 0],
            "CI_upper": coef_conf_intervals.loc["Intercept", 1],
            }
        model_results[config.EFFECTS_TYPES["beta_0"]["model_results_key"]] = beta_0 
   
    if (len(after_treatment_col) > 0) and (any(col in coefficients for col in after_treatment_col)):
        
        AATE = {}
        
        for i, AATE_ in enumerate(after_treatment_col):
            AATE[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: AATE_,
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[AATE_],
                "SE": float(coef_standarderrors[AATE_]),
                "t": float(coef_t[AATE_]),
                "p": float(coef_p[AATE_]),
                "CI_lower": float(coef_conf_intervals.loc[AATE_, 0]),
                "CI_upper": float(coef_conf_intervals.loc[AATE_, 1]),
                }
            
        model_results[config.EFFECTS_TYPES["AATE"]["model_results_key"]] = AATE
    
    if (len(ATT_col) > 0) and (any(col in coefficients for col in ATT_col)):
        
        ATT = {}
                
        for i, ATT_ in enumerate(ATT_col):
            ATT[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: ATT_,
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[ATT_],
                "SE": float(coef_standarderrors[ATT_]),
                "t": float(coef_t[ATT_]),
                "p": float(coef_p[ATT_]),
                "CI_lower": float(coef_conf_intervals.loc[ATT_, 0]),
                "CI_upper": float(coef_conf_intervals.loc[ATT_, 1]),
                }
                       
        model_results[config.EFFECTS_TYPES["ATT"]["model_results_key"]] = ATT    
    
    if (len(spillover_vars) > 0) and (any(col in coefficients for col in spillover_vars)):

        spillover_coef = {}
        
        for i, spillover_var in enumerate(spillover_vars):
            spillover_coef[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: spillover_var,
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[spillover_var],
                "SE": float(coef_standarderrors[spillover_var]),
                "t": float(coef_t[spillover_var]),
                "p": float(coef_p[spillover_var]),
                "CI_lower": float(coef_conf_intervals.loc[spillover_var, 0]),
                "CI_upper": float(coef_conf_intervals.loc[spillover_var, 1]),
                } 
                       
        model_results[config.EFFECTS_TYPES["spillover"]["model_results_key"]] = spillover_coef
    
    fixed_effects = [
        None, 
        None, 
        None
        ]  

    if (len(FE_unit_vars) > 0) and (any(col in coefficients for col in FE_unit_vars)):
        
        FE_unit_coef = {}
               
        for i, unit_dummy in enumerate(FE_unit_vars):
            FE_unit_coef[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: dummy_unit_original[i],
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[unit_dummy],
                "SE": float(coef_standarderrors[unit_dummy]),
                "t": float(coef_t[unit_dummy]),
                "p": float(coef_p[unit_dummy]),
                "CI_lower": float(coef_conf_intervals.loc[unit_dummy, 0]),
                "CI_upper": float(coef_conf_intervals.loc[unit_dummy, 1]),
                "Coefficient_type": config.EFFECTS_TYPES["FE"]["types"][0]["description"]
                }
            
        fixed_effects[0] = {config.EFFECTS_TYPES["FE"]["types"][0]["model_results_key"]: FE_unit_coef}
    
    if (len(FE_time_vars) > 0) and (any(col in coefficients for col in FE_time_vars)):

        FE_time_coef = {}
        
        for i, time_dummy in enumerate(FE_time_vars):
            FE_time_coef[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: dummy_time_original[i],
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[time_dummy],
                "SE": float(coef_standarderrors[time_dummy]),
                "t": float(coef_t[time_dummy]),
                "p": float(coef_p[time_dummy]),
                "CI_lower": float(coef_conf_intervals.loc[time_dummy, 0]),
                "CI_upper": float(coef_conf_intervals.loc[time_dummy, 1]),
                "Coefficient_type": config.EFFECTS_TYPES["FE"]["types"][1]["description"]
                }
            
        fixed_effects[1] = {config.EFFECTS_TYPES["FE"]["types"][1]["model_results_key"]: FE_time_coef}
        
    if (len(FE_group_vars) > 0) and (any(col in coefficients for col in FE_group_vars)):

        FE_group_coef = {}
        
        for i, group_dummy in enumerate(FE_group_vars):
            FE_group_coef[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: dummy_group_original[i],
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[group_dummy],
                "SE": float(coef_standarderrors[group_dummy]),
                "t": float(coef_t[group_dummy]),
                "p": float(coef_p[group_dummy]),
                "CI_lower": float(coef_conf_intervals.loc[group_dummy, 0]),
                "CI_upper": float(coef_conf_intervals.loc[group_dummy, 1]),
                "Coefficient_type": config.EFFECTS_TYPES["FE"]["types"][2]["description"]
                }
            
        fixed_effects[2] = {config.EFFECTS_TYPES["FE"]["types"][2]["model_results_key"]: FE_group_coef}

    model_results[config.EFFECTS_TYPES["FE"]["model_results_key"]] = fixed_effects

    if (len(ITT_vars) > 0) and (any(col in coefficients for col in ITT_vars)):
      
        ITT_coef = {}

        for i, ITT_var in enumerate(ITT_vars):

            ITT_coef[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: dummy_unit_original[i],
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[ITT_var],
                "SE": float(coef_standarderrors[ITT_var]),
                "t": float(coef_t[ITT_var]),
                "p": float(coef_p[ITT_var]),
                "CI_lower": float(coef_conf_intervals.loc[ITT_var, 0]),
                "CI_upper": float(coef_conf_intervals.loc[ITT_var, 1]),
                }      
        
        model_results["individual_time_trends"] = ITT_coef

    if (len(ITE_vars) > 0) and (any(col in coefficients for col in ITE_vars)):
    
        ITE_coef = {}

        dummy_unit_current = dummy_unit_original*no_treatments

        treatment_current = []
        for treatment in treatment_col:
            treatment_single = [treatment]*len(dummy_unit_original)
            treatment_current = treatment_current + treatment_single

        for i, ITE_var in enumerate(ITE_vars):                

            ITE_coef[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: treatment_current[i] + " " + dummy_unit_current[i],
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: float(coefficients[ITE_var]),
                "SE": float(coef_standarderrors[ITE_var]),
                "t": float(coef_t[ITE_var]),
                "p": float(coef_p[ITE_var]),
                "CI_lower": float(coef_conf_intervals.loc[ITE_var, 0]),
                "CI_upper": float(coef_conf_intervals.loc[ITE_var, 1]),
                }            
            
        model_results["individual_treatment_effects"] = ITE_coef

    if (len(GTT_vars) > 0) and (any(col in coefficients for col in GTT_vars)):
        
        GTT_coef = {}

        for i, GTT_var in enumerate(GTT_vars):

            GTT_coef[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: dummy_group_original[i],
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[GTT_var],
                "SE": float(coef_standarderrors[GTT_var]),
                "t": float(coef_t[GTT_var]),
                "p": float(coef_p[GTT_var]),
                "CI_lower": float(coef_conf_intervals.loc[GTT_var, 0]),
                "CI_upper": float(coef_conf_intervals.loc[GTT_var, 1]),
                }      
        
        model_results["group_time_trends"] = GTT_coef

    if (len(GTE_vars) > 0) and (any(col in coefficients for col in GTE_vars)):
        
        GTE_coef = {}

        dummy_group_current = dummy_group_original*no_treatments

        treatment_current = []
        for treatment in treatment_col:
            treatment_single = [treatment]*len(dummy_group_original)
            treatment_current = treatment_current + treatment_single
        
        for i, GTE_var in enumerate(GTE_vars):
            GTE_coef[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: treatment_current[i] + " " + dummy_group_current[i],
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[GTE_var],
                "SE": float(coef_standarderrors[GTE_var]),
                "t": float(coef_t[GTE_var]),
                "p": float(coef_p[GTE_var]),
                "CI_lower": float(coef_conf_intervals.loc[GTE_var, 0]),
                "CI_upper": float(coef_conf_intervals.loc[GTE_var, 1]),
                }      
        
        model_results["group_treatment_effects"] = GTE_coef

    if (len(covariates) > 0) and (any(col in coefficients for col in covariates)):

        covariates_effects = {}
        
        for i, covariate in enumerate(covariates):
            covariates_effects[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: covariate,
                config.OLS_MODEL_RESULTS["coef"]["model_results_key"]: coefficients[covariate],
                "SE": float(coef_standarderrors[covariate]),
                "t": float(coef_t[covariate]),
                "p": float(coef_p[covariate]),
                "CI_lower": float(coef_conf_intervals.loc[covariate, 0]),
                "CI_upper": float(coef_conf_intervals.loc[covariate, 1]),
                }
            
        model_results["covariates_effects"] = covariates_effects    

    if (len(TG_x_BG_x_TT_col) > 0) and (any(col in coefficients for col in TG_x_BG_x_TT_col)):

        TDATE = {}

        for i, TG_x_BG_x_TT_ in enumerate(TG_x_BG_x_TT_col):
            TDATE[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: TG_x_BG_x_TT_,
                "Estimate": coefficients[TG_x_BG_x_TT_],
                "SE": float(coef_standarderrors[TG_x_BG_x_TT_]),
                "t": float(coef_t[TG_x_BG_x_TT_]),
                "p": float(coef_p[TG_x_BG_x_TT_]),
                "CI_lower": float(coef_conf_intervals.loc[TG_x_BG_x_TT_, 0]),
                "CI_upper": float(coef_conf_intervals.loc[TG_x_BG_x_TT_, 1]),
                }
        
        model_results = {config.EFFECTS_TYPES_DDD["TDATE"]["model_results_key"]: TDATE}
    
    if (len(BG_col) > 0) and (any(col in coefficients for col in BG_col)):

        BG = {}        

        for i, BG_ in enumerate(BG_col):
            BG[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: BG_,
                "Estimate": coefficients[BG_],
                "SE": float(coef_standarderrors[BG_]),
                "t": float(coef_t[BG_]),
                "p": float(coef_p[BG_]),
                "CI_lower": float(coef_conf_intervals.loc[BG_, 0]),
                "CI_upper": float(coef_conf_intervals.loc[BG_, 1]),
                }            

        model_results[config.EFFECTS_TYPES_DDD["beta_2"]["model_results_key"]] = BG
        
    if (len(TG_x_BG_col) > 0) and (any(col in coefficients for col in TG_x_BG_col)):

        TG_x_BG = {}

        for i, TG_x_BG_ in enumerate(TG_x_BG_col):
            TG_x_BG[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: TG_x_BG_,
                "Estimate": coefficients[TG_x_BG_],
                "SE": float(coef_standarderrors[TG_x_BG_]),
                "t": float(coef_t[TG_x_BG_]),
                "p": float(coef_p[TG_x_BG_]),
                "CI_lower": float(coef_conf_intervals.loc[TG_x_BG_, 0]),
                "CI_upper": float(coef_conf_intervals.loc[TG_x_BG_, 1]),
                }            

        model_results[config.EFFECTS_TYPES_DDD["beta_4"]["model_results_key"]] = TG_x_BG

    if (len(BG_x_TT_col) > 0) and (any(col in coefficients for col in BG_x_TT_col)):

        BG_x_TT = {}        

        for i, BG_x_TT_ in enumerate(BG_x_TT_col):
            BG_x_TT[i] = {
                config.OLS_MODEL_RESULTS["coef_name"]["model_results_key"]: BG_x_TT_,
                "Estimate": coefficients[BG_x_TT_],
                "SE": float(coef_standarderrors[BG_x_TT_]),
                "t": float(coef_t[BG_x_TT_]),
                "p": float(coef_p[BG_x_TT_]),
                "CI_lower": float(coef_conf_intervals.loc[BG_x_TT_, 0]),
                "CI_upper": float(coef_conf_intervals.loc[BG_x_TT_, 1]),
                }            

        model_results[config.EFFECTS_TYPES_DDD["beta_6"]["model_results_key"]] = BG_x_TT
    
    if verbose:
        print("OK")

    return model_results

def fit_metrics(
    data,
    outcome_col,
    model_predictions,
    indep_vars_no: int = None
    ):

    """
    Compute fit metrics for a model given data and predictions.

    Parameters
    ----------
    data : pandas.DataFrame
        Original data used for observed values.
    outcome_col : str
        Name of the observed outcome column in ``data``.
    model_predictions : object
        Predictions summary frame returned by statsmodels or similar.
    indep_vars_no : int, optional
        Number of independent variables (for adjusted R^2).

    Returns
    -------
    list
        Result from ``tools.fit_metrics``: [residuals_df, metrics_dict].

    Examples
    --------
    >>> fit_metrics(df, 'y', predictions)
    """

    model_predictions = pd.DataFrame(model_predictions)
    model_predictions = model_predictions.reset_index()
    model_predictions.rename(columns = {config.PREDICTIONS_SUMMARY_FRAME_COLS_LIST[0]: f"{outcome_col}{config.DELIMITER}{config.EXPECTED_SUFFIX}"}, inplace = True)

    observed_expected = pd.concat (
        [
            data, 
            model_predictions
            ], 
            axis = 1
            )

    fit_metrics_result = tools.fit_metrics(
        observed = observed_expected[outcome_col],
        expected = observed_expected[f"{outcome_col}{config.DELIMITER}{config.EXPECTED_SUFFIX}"],
        indep_vars_no = indep_vars_no
    )

    return fit_metrics_result

def create_timestamp(function):

    """
    Create a standard timestamp dictionary for logging or metadata.

    Parameters
    ----------
    function : str or callable
        Name of the function (string) or a callable object whose ``__name__`` will be used.

    Returns
    -------
    dict
        Dictionary with keys ``package_version``, ``function`` and ``datetime``.

    Raises
    ------
    TypeError
        If ``function`` is neither a string nor a callable.

    Examples
    --------
    >>> create_timestamp('did_analysis')
    {'package_version': 'diffindiff 2.3.0', 'function': 'create_data', 'datetime': '2026-02-27 18-00-00'}
    """

    if not isinstance(function, str) and not callable(function):
        raise TypeError("Parameter 'function' must be a string or a callable")

    now = datetime.now()

    function_name = function.__name__ if callable(function) else function

    timestamp_dict = {
        "package_version": f"{config.PACKAGE_NAME} {config.PACKAGE_VERSION}",
        "function": function_name,
        "datetime": now.strftime("%Y-%m-%d %H-%M-%S")
    }

    return timestamp_dict