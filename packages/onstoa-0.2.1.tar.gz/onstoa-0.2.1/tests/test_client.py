from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from stoa.client import Stoa
from stoa.exceptions import StoaError


def test_stoa_reads_api_key_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa() reads STOA_API_KEY from environment."""
    monkeypatch.setenv("STOA_API_KEY", "test-key-from-env")

    with patch("stoa.client.StoaHTTPClient") as mock_http:
        client = Stoa()
        assert client.api_key == "test-key-from-env"
        mock_http.assert_called_once_with("test-key-from-env", "https://api.onstoa.com")


def test_stoa_uses_provided_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa(api_key=...) uses the provided key over env."""
    monkeypatch.setenv("STOA_API_KEY", "env-key")

    with patch("stoa.client.StoaHTTPClient") as mock_http:
        client = Stoa(api_key="provided-key")
        assert client.api_key == "provided-key"
        mock_http.assert_called_once_with("provided-key", "https://api.onstoa.com")


def test_stoa_raises_if_no_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa() raises StoaError if no API key is available."""
    monkeypatch.delenv("STOA_API_KEY", raising=False)

    with pytest.raises(StoaError, match="STOA_API_KEY not set"):
        Stoa()


def test_stoa_uses_custom_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa(base_url=...) uses provided base URL."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    with patch("stoa.client.StoaHTTPClient") as mock_http:
        client = Stoa(base_url="https://custom.api.dev")
        assert client.base_url == "https://custom.api.dev"
        mock_http.assert_called_once_with("test-key", "https://custom.api.dev")


def test_stoa_reads_app_id_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa() reads STOA_APP_ID from environment."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")
    monkeypatch.setenv("STOA_APP_ID", "app_env_123")

    with patch("stoa.client.StoaHTTPClient"):
        client = Stoa()
        assert client.app_id == "app_env_123"


def test_stoa_uses_provided_app_id(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa(app_id=...) uses the provided app ID over env."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")
    monkeypatch.setenv("STOA_APP_ID", "app_env_123")

    with patch("stoa.client.StoaHTTPClient"):
        client = Stoa(app_id="app_provided_123")
        assert client.app_id == "app_provided_123"


def test_stoa_reads_base_url_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa() reads STOA_BASE_URL from environment."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")
    monkeypatch.setenv("STOA_BASE_URL", "https://env.api.dev")

    with patch("stoa.client.StoaHTTPClient") as mock_http:
        client = Stoa()
        assert client.base_url == "https://env.api.dev"
        mock_http.assert_called_once_with("test-key", "https://env.api.dev")


def test_openai_returns_proxied_client(monkeypatch: pytest.MonkeyPatch) -> None:
    """openai() returns a StoaProxy wrapping an OpenAI client."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    mock_openai_client = MagicMock()
    mock_openai_module = MagicMock()
    mock_openai_module.OpenAI.return_value = mock_openai_client

    with (
        patch("stoa.client.StoaHTTPClient") as mock_http_cls,
        patch("stoa.client.StoaProxy") as mock_proxy,
        patch.dict("sys.modules", {"openai": mock_openai_module}),
    ):
        mock_http = MagicMock()
        mock_http_cls.return_value = mock_http

        client = Stoa()
        result = client.openai("user-123")

        mock_openai_module.OpenAI.assert_called_once()
        mock_proxy.assert_called_once_with(
            obj=mock_openai_client,
            function_name="openai",
            user_id="user-123",
            stoa_client=mock_http,
        )
        assert result == mock_proxy.return_value


def test_anthropic_returns_proxied_client(monkeypatch: pytest.MonkeyPatch) -> None:
    """anthropic() returns a StoaProxy wrapping an Anthropic client."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    mock_anthropic_client = MagicMock()
    mock_anthropic_module = MagicMock()
    mock_anthropic_module.Anthropic.return_value = mock_anthropic_client

    with (
        patch("stoa.client.StoaHTTPClient") as mock_http_cls,
        patch("stoa.client.StoaProxy") as mock_proxy,
        patch.dict("sys.modules", {"anthropic": mock_anthropic_module}),
    ):
        mock_http = MagicMock()
        mock_http_cls.return_value = mock_http

        client = Stoa()
        result = client.anthropic("user-123")

        mock_anthropic_module.Anthropic.assert_called_once()
        mock_proxy.assert_called_once_with(
            obj=mock_anthropic_client,
            function_name="anthropic",
            user_id="user-123",
            stoa_client=mock_http,
        )
        assert result == mock_proxy.return_value


def test_elevenlabs_returns_proxied_client(monkeypatch: pytest.MonkeyPatch) -> None:
    """elevenlabs() returns a StoaProxy wrapping an ElevenLabs client."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    mock_elevenlabs_client = MagicMock()
    mock_elevenlabs_module = MagicMock()
    mock_elevenlabs_module.ElevenLabs.return_value = mock_elevenlabs_client

    with (
        patch("stoa.client.StoaHTTPClient") as mock_http_cls,
        patch("stoa.client.StoaProxy") as mock_proxy,
        patch.dict(
            "sys.modules", {"elevenlabs": MagicMock(), "elevenlabs.client": mock_elevenlabs_module}
        ),
    ):
        mock_http = MagicMock()
        mock_http_cls.return_value = mock_http

        client = Stoa()
        result = client.elevenlabs("user-123")

        mock_elevenlabs_module.ElevenLabs.assert_called_once()
        mock_proxy.assert_called_once_with(
            obj=mock_elevenlabs_client,
            function_name="elevenlabs",
            user_id="user-123",
            stoa_client=mock_http,
        )
        assert result == mock_proxy.return_value


def test_openrouter_returns_proxied_client(monkeypatch: pytest.MonkeyPatch) -> None:
    """openrouter() returns a StoaProxy wrapping an OpenAI client configured for OpenRouter."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")
    monkeypatch.setenv("OPENROUTER_API_KEY", "or-key")

    mock_openai_client = MagicMock()
    mock_openai_module = MagicMock()
    mock_openai_module.OpenAI.return_value = mock_openai_client

    with (
        patch("stoa.client.StoaHTTPClient") as mock_http_cls,
        patch("stoa.client.StoaProxy") as mock_proxy,
        patch.dict("sys.modules", {"openai": mock_openai_module}),
    ):
        mock_http = MagicMock()
        mock_http_cls.return_value = mock_http

        client = Stoa()
        result = client.openrouter("user-123")

        mock_openai_module.OpenAI.assert_called_once_with(
            base_url="https://openrouter.ai/api/v1",
            api_key="or-key",
        )
        mock_proxy.assert_called_once_with(
            obj=mock_openai_client,
            function_name="openrouter",
            user_id="user-123",
            stoa_client=mock_http,
        )
        assert result == mock_proxy.return_value


def test_stoa_register_member_delegates(monkeypatch: pytest.MonkeyPatch) -> None:
    """Vetted member registration uses the signed helper then HTTP client."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    with patch("stoa.client.StoaHTTPClient") as mock_http_cls:
        mock_http = MagicMock()
        mock_http.register_member.return_value = MagicMock(
            membership_id="mem_123",
            user_id="user_123",
        )
        mock_http_cls.return_value = mock_http

        client = Stoa()
        result = client.register_member(
            registration_secret="registration-secret",
            app_id="app_123",
            user_id="user_123",
            email="ada@example.com",
            name="Ada",
            avatar_url="https://example.com/avatar.png",
            nonce="nonce_1234567890abcd",
            timestamp=1717082400,
        )

        mock_http.register_member.assert_called_once_with(
            app_id="app_123",
            user_id="user_123",
            email="ada@example.com",
            name="Ada",
            avatar_url="https://example.com/avatar.png",
            nonce="nonce_1234567890abcd",
            timestamp=1717082400,
            signature="f6ab5e852d49541ee7c320e0759ba0cbc01005a091ae1422b8c36a12cc6e78fc",
        )
        assert result.membership_id == "mem_123"


def test_stoa_register_member_generates_nonce_when_omitted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Vetted member registration auto-generates a nonce for the public API."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    with patch("stoa.client.StoaHTTPClient") as mock_http_cls:
        mock_http = MagicMock()
        mock_http.register_member.return_value = MagicMock(
            membership_id="mem_123",
            user_id="user_123",
        )
        mock_http_cls.return_value = mock_http

        client = Stoa()
        client.register_member(
            registration_secret="registration-secret",
            app_id="app_123",
            user_id="user_123",
            email="ada@example.com",
            timestamp=1717082400,
        )

        kwargs = mock_http.register_member.call_args.kwargs
        assert kwargs["app_id"] == "app_123"
        assert kwargs["user_id"] == "user_123"
        assert kwargs["email"] == "ada@example.com"
        assert isinstance(kwargs["nonce"], str)
        assert kwargs["nonce"]


def test_stoa_register_member_uses_client_app_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Vetted member registration uses the client app_id by default."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    with patch("stoa.client.StoaHTTPClient") as mock_http_cls:
        mock_http = MagicMock()
        mock_http.register_member.return_value = MagicMock(
            membership_id="mem_123",
            user_id="user_123",
        )
        mock_http_cls.return_value = mock_http

        client = Stoa(app_id="app_client_123")
        client.register_member(
            registration_secret="registration-secret",
            user_id="user_123",
            email="ada@example.com",
            timestamp=1717082400,
        )

        kwargs = mock_http.register_member.call_args.kwargs
        assert kwargs["app_id"] == "app_client_123"


def test_stoa_register_member_requires_app_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Vetted member registration requires an app_id if none is configured."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")
    monkeypatch.delenv("STOA_APP_ID", raising=False)

    with patch("stoa.client.StoaHTTPClient"):
        client = Stoa()

        with pytest.raises(StoaError, match="STOA_APP_ID not set"):
            client.register_member(
                registration_secret="registration-secret",
                user_id="user_123",
                email="ada@example.com",
            )


def test_stoa_get_topup_url_delegates(monkeypatch: pytest.MonkeyPatch) -> None:
    """Hosted top-up helper delegates to the HTTP client."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    with patch("stoa.client.StoaHTTPClient") as mock_http_cls:
        mock_http = MagicMock()
        mock_http.get_hosted_topup_link.return_value = "https://onstoa.com/payments/user_123"
        mock_http_cls.return_value = mock_http

        client = Stoa()
        result = client.get_topup_url(user_id="user_123")

        mock_http.get_hosted_topup_link.assert_called_once_with(
            user_id="user_123",
        )
        assert result == "https://onstoa.com/payments/user_123"
