"""Helpers for trusted embedded onboarding."""

from __future__ import annotations

import hmac
import json
import secrets
import time
from dataclasses import dataclass
from typing import TypedDict


class EmbeddedMembershipRequest(TypedDict):
    """Canonical request body for trusted embedded onboarding."""

    app_id: str
    external_user_id: str
    email: str
    name: str | None
    avatar_url: str | None
    timestamp: int
    nonce: str
    signature: str


@dataclass(frozen=True, slots=True)
class EmbeddedMembershipResult:
    """Result returned after embedded onboarding registration."""

    membership_id: str
    user_id: str


def build_embedded_signature_message(
    *,
    app_id: str,
    external_user_id: str,
    email: str,
    name: str | None,
    avatar_url: str | None,
    timestamp: int,
    nonce: str,
) -> str:
    """Build the canonical trusted embedded onboarding signature message."""
    return json.dumps(
        {
            "app_id": app_id,
            "external_user_id": external_user_id,
            "email": email,
            "name": name,
            "avatar_url": avatar_url,
            "timestamp": timestamp,
            "nonce": nonce,
        },
        separators=(",", ":"),
        sort_keys=True,
    )


def create_embedded_membership_request(
    *,
    registration_secret: str,
    app_id: str,
    user_id: str,
    email: str,
    nonce: str | None = None,
    name: str | None = None,
    avatar_url: str | None = None,
    timestamp: int | None = None,
) -> EmbeddedMembershipRequest:
    """Create a signed request body for trusted embedded onboarding."""
    request_timestamp = timestamp or int(time.time())
    request_nonce = nonce or secrets.token_urlsafe(24)
    message = build_embedded_signature_message(
        app_id=app_id,
        external_user_id=user_id,
        email=email,
        name=name,
        avatar_url=avatar_url,
        timestamp=request_timestamp,
        nonce=request_nonce,
    )
    signature = hmac.new(
        registration_secret.encode(),
        message.encode(),
        "sha256",
    ).hexdigest()
    return EmbeddedMembershipRequest(
        app_id=app_id,
        external_user_id=user_id,
        email=email,
        name=name,
        avatar_url=avatar_url,
        timestamp=request_timestamp,
        nonce=request_nonce,
        signature=signature,
    )
