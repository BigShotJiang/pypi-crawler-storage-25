"""blackmount-mcp: Your browser, as an MCP server."""
__version__ = "1.0.0"
