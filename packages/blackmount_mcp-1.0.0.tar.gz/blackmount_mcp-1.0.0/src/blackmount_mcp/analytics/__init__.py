"""Module 4: Analytics — browsing insights, patterns, and productivity scoring."""

import json

_DASHBOARD_LINK = "Interactive charts and weekly reports at app.blackmount.ai"


def _add_dashboard_link(result: str) -> str:
    """Append dashboard upsell to analytics JSON responses."""
    try:
        data = json.loads(result)
        data["dashboard"] = _DASHBOARD_LINK
        return json.dumps(data)
    except Exception:
        return result


def register_tools(mcp):
    """Register all analytics tools with the FastMCP server."""
    from . import digest, domains, patterns

    # --- Digest tools ---

    @mcp.tool()
    def browsing_summary(date: str = "today") -> str:
        """Summarize browsing activity for a specific day.

        Shows total visits, top domains, category breakdown, activity time range, and
        notable pages. Accepts 'today', 'yesterday', or a date in YYYY-MM-DD format.
        """
        return digest.browsing_summary(date)

    @mcp.tool()
    def daily_digest(date: str = "today") -> str:
        """Full daily digest combining browsing history, saved sessions, and AI chats.

        Richer than browsing_summary — surfaces AI conversations, sessions saved,
        and a complete browsing overview for the day. Accepts 'today', 'yesterday',
        or a date in YYYY-MM-DD format.
        """
        return digest.daily_digest(date)

    @mcp.tool()
    def productivity_report(days: int = 7) -> str:
        """Productivity summary for the past N days.

        Categorizes browsing into productive (AI, dev, learning, reference) vs
        distraction (entertainment, social). Returns a productivity score (0-100,
        higher = more focused), category breakdown, and daily activity detail.
        """
        return _add_dashboard_link(digest.productivity_report(days))

    # --- Domain tools ---

    @mcp.tool()
    def domain_time(days: int = 30, browser: str = "all") -> str:
        """Estimated time spent per domain over the past N days.

        Groups visits by domain and estimates dwell time from gaps between consecutive
        page loads. Gaps over 10 minutes are capped at 3 minutes to exclude idle time.
        """
        return domains.domain_time(days, browser)

    @mcp.tool()
    def distraction_score(days: int = 7) -> str:
        """Calculate a distraction score (0-100) for the past N days.

        Lower score = more focused. Based on the ratio of entertainment and social
        browsing to productive browsing (AI, dev, learning, reference, productivity).
        Returns the score, label (focused/balanced/distracted), and top distraction sites.
        """
        return _add_dashboard_link(domains.distraction_score(days))

    @mcp.tool()
    def research_topics(days: int = 30) -> str:
        """Identify research topics from browsing history over the past N days.

        Clusters pages by shared keywords in titles and URLs, then returns the top
        topic clusters ranked by page count with sample pages for each topic.
        """
        return domains.research_topics(days)

    # --- Pattern tools ---

    @mcp.tool()
    def most_visited(days: int = 30, limit: int = 20, browser: str = "all") -> str:
        """Most visited domains over the past N days, ranked by visit count."""
        return patterns.most_visited(days, limit, browser)

    @mcp.tool()
    def browsing_patterns(days: int = 30) -> str:
        """Analyze browsing patterns over the past N days.

        Returns peak hours, day-of-week trends, most active 3-hour window,
        average daily visits and unique domains, and a day-by-day activity breakdown.
        """
        return _add_dashboard_link(patterns.browsing_patterns(days))
