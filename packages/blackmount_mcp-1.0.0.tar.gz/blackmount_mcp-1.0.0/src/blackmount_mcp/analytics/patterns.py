"""Browsing pattern analysis: peak hours, day-of-week trends, most-visited domains."""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from datetime import datetime

from blackmount_mcp.utils.format import domain_of as _domain_of


def _load_entries(days: int, browser: str = "all") -> list[dict]:
    """Fetch raw history entries, returning empty list on any error."""
    from blackmount_mcp.browser.history import list_history

    try:
        raw = json.loads(list_history(days=days, limit=100000, browser=browser))
        return raw.get("results", []) if isinstance(raw, dict) else []
    except Exception:
        return []


def most_visited(days: int = 30, limit: int = 20, browser: str = "all") -> str:
    """Most visited domains by visit count."""
    entries = _load_entries(days, browser)
    if not entries:
        return json.dumps({
            "days": days,
            "browser": browser,
            "limit": limit,
            "results": [],
            "message": "No browsing history found.",
        })

    domain_counts: Counter = Counter()
    for e in entries:
        domain = _domain_of(e.get("url", ""))
        if domain:
            domain_counts[domain] += 1

    results = [
        {"domain": d, "visits": c}
        for d, c in domain_counts.most_common(limit)
    ]

    return json.dumps({
        "days": days,
        "browser": browser,
        "limit": limit,
        "results": results,
        "total_domains": len(domain_counts),
        "total_visits": len(entries),
    })


def browsing_patterns(days: int = 30) -> str:
    """Analyze browsing patterns: peak hours, day-of-week trends,
    average daily sites, most active periods.
    """
    DAY_NAMES = [
        "Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday",
    ]

    entries = _load_entries(days)
    if not entries:
        return json.dumps({
            "days": days,
            "total_visits": 0,
            "hourly_distribution": {},
            "day_of_week_distribution": {},
            "peak_hour": None,
            "peak_day": None,
            "most_active_period": None,
            "average_daily_visits": 0,
            "average_daily_domains": 0,
            "daily_activity": {},
            "message": "No browsing history found.",
        })

    # Parse timestamps
    hourly: Counter = Counter()            # hour (0-23) -> visit count
    day_of_week: Counter = Counter()       # weekday (0=Mon) -> visit count
    daily_visits: defaultdict[str, int] = defaultdict(int)
    daily_domains: defaultdict[str, set] = defaultdict(set)

    for e in entries:
        try:
            dt = datetime.fromisoformat(e["date"].replace("Z", "+00:00"))
        except (ValueError, KeyError):
            continue

        hour = dt.hour
        weekday = dt.weekday()
        day_key = dt.date().isoformat()
        domain = _domain_of(e.get("url", ""))

        hourly[hour] += 1
        day_of_week[weekday] += 1
        daily_visits[day_key] += 1
        if domain:
            daily_domains[day_key].add(domain)

    # Peak hour
    peak_hour_num = hourly.most_common(1)[0][0] if hourly else None
    peak_hour = f"{peak_hour_num:02d}:00" if peak_hour_num is not None else None

    # Peak day of week
    peak_day_num = day_of_week.most_common(1)[0][0] if day_of_week else None
    peak_day = DAY_NAMES[peak_day_num] if peak_day_num is not None else None

    # Most active period: find the 3-hour window with the highest visit count
    most_active_period = None
    if hourly:
        best_window_start = 0
        best_window_count = 0
        for start_h in range(24):
            window_count = sum(hourly.get((start_h + offset) % 24, 0) for offset in range(3))
            if window_count > best_window_count:
                best_window_count = window_count
                best_window_start = start_h
        end_h = (best_window_start + 3) % 24
        most_active_period = {
            "start": f"{best_window_start:02d}:00",
            "end": f"{end_h:02d}:00",
            "visits": best_window_count,
        }

    # Averages
    num_days = len(daily_visits)
    avg_visits = round(len(entries) / num_days, 1) if num_days else 0
    avg_domains = (
        round(sum(len(s) for s in daily_domains.values()) / num_days, 1)
        if num_days else 0
    )

    # Hourly distribution as dict with string keys for JSON
    hourly_dist = {f"{h:02d}:00": hourly.get(h, 0) for h in range(24)}

    # Day-of-week distribution
    dow_dist = {DAY_NAMES[d]: day_of_week.get(d, 0) for d in range(7)}

    # Daily activity (sorted)
    daily_activity = {
        day: {
            "visits": daily_visits[day],
            "unique_domains": len(daily_domains[day]),
        }
        for day in sorted(daily_visits.keys())
    }

    return json.dumps({
        "days": days,
        "total_visits": len(entries),
        "hourly_distribution": hourly_dist,
        "day_of_week_distribution": dow_dist,
        "peak_hour": peak_hour,
        "peak_day": peak_day,
        "most_active_period": most_active_period,
        "average_daily_visits": avg_visits,
        "average_daily_domains": avg_domains,
        "daily_activity": daily_activity,
    })
