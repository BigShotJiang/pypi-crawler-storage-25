"""Domain-level analytics: time estimates, distraction scoring, research topic clustering."""

from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from datetime import datetime

from blackmount_mcp.utils.format import domain_of as _domain_of


def _load_entries(days: int, browser: str = "all") -> list[dict]:
    """Fetch raw history entries, returning empty list on any error."""
    from blackmount_mcp.browser.history import list_history

    try:
        raw = json.loads(list_history(days=days, limit=100000, browser=browser))
        return raw.get("results", []) if isinstance(raw, dict) else []
    except Exception:
        return []


def domain_time(days: int = 30, browser: str = "all") -> str:
    """Time spent per domain estimated from visit frequency and patterns.

    Groups by domain, counts visits, estimates time based on consecutive visits.
    Consecutive visits to the same domain within 5 minutes are treated as a
    single session; each session contributes an estimated dwell time based on
    the gap between consecutive page loads (capped at 10 minutes per gap).
    """
    entries = _load_entries(days, browser)
    if not entries:
        return json.dumps({
            "days": days,
            "browser": browser,
            "domains": [],
            "total_estimated_minutes": 0,
            "message": "No browsing history found.",
        })

    # Parse and sort by time ascending for session analysis
    parsed: list[tuple[datetime, str, str]] = []
    for e in entries:
        try:
            dt = datetime.fromisoformat(e["date"].replace("Z", "+00:00"))
            parsed.append((dt, e.get("url", ""), e.get("title", "")))
        except (ValueError, KeyError):
            continue

    parsed.sort(key=lambda x: x[0])

    # Accumulate estimated dwell time per domain
    # Strategy: gap between successive page loads, attributed to the earlier page's domain.
    # Gaps > 10 min are capped at 3 min (user likely walked away).
    MAX_GAP_SECONDS = 600       # 10 minutes — above this we assume a break
    ASSUMED_DWELL_SECONDS = 180  # fallback dwell for gaps > MAX_GAP_SECONDS

    domain_visits: Counter = Counter()
    domain_seconds: defaultdict[str, float] = defaultdict(float)

    for i, (dt, url, _) in enumerate(parsed):
        domain = _domain_of(url)
        domain_visits[domain] += 1

        if i + 1 < len(parsed):
            next_dt = parsed[i + 1][0]
            gap = (next_dt - dt).total_seconds()
            dwell = gap if 0 < gap <= MAX_GAP_SECONDS else ASSUMED_DWELL_SECONDS
        else:
            dwell = ASSUMED_DWELL_SECONDS

        domain_seconds[domain] += dwell

    # Build sorted result
    all_domains = set(domain_visits.keys()) | set(domain_seconds.keys())
    domain_rows = []
    for domain in all_domains:
        minutes = round(domain_seconds[domain] / 60, 1)
        domain_rows.append({
            "domain": domain,
            "visits": domain_visits[domain],
            "estimated_minutes": minutes,
        })

    domain_rows.sort(key=lambda r: r["estimated_minutes"], reverse=True)

    total_minutes = round(sum(r["estimated_minutes"] for r in domain_rows), 1)

    return json.dumps({
        "days": days,
        "browser": browser,
        "domains": domain_rows[:50],  # top 50 by time
        "total_estimated_minutes": total_minutes,
        "note": (
            "Time estimates are based on gaps between consecutive page loads. "
            "Gaps over 10 minutes are capped at 3 minutes to exclude idle time."
        ),
    })


def distraction_score(days: int = 7) -> str:
    """Calculate distraction score: ratio of entertainment/social to productive browsing.

    Returns score 0-100 (lower = more focused) with category breakdown.
    """
    from blackmount_mcp.utils.categories import categorize_domain, get_category_stats

    PRODUCTIVE = {"ai", "productivity", "development", "learning", "reference"}
    DISTRACTION = {"entertainment", "social"}

    entries = _load_entries(days)
    if not entries:
        return json.dumps({
            "days": days,
            "distraction_score": 0,
            "total_visits": 0,
            "productive_visits": 0,
            "distraction_visits": 0,
            "category_breakdown": {},
            "top_distractions": [],
            "message": "No browsing history found.",
        })

    domains = [_domain_of(e.get("url", "")) for e in entries]
    category_stats = get_category_stats(domains)

    productive_count = sum(category_stats.get(c, 0) for c in PRODUCTIVE)
    distraction_count = sum(category_stats.get(c, 0) for c in DISTRACTION)

    denom = productive_count + distraction_count
    score = round((distraction_count / denom) * 100) if denom > 0 else 0

    # Top distraction domains
    distraction_domains: Counter = Counter()
    for e in entries:
        domain = _domain_of(e.get("url", ""))
        if categorize_domain(domain) in DISTRACTION:
            distraction_domains[domain] += 1

    top_distractions = [
        {"domain": d, "visits": c, "category": categorize_domain(d)}
        for d, c in distraction_domains.most_common(10)
    ]

    label = "focused" if score < 20 else "balanced" if score < 50 else "distracted"

    return json.dumps({
        "days": days,
        "distraction_score": score,
        "label": label,
        "total_visits": len(entries),
        "productive_visits": productive_count,
        "distraction_visits": distraction_count,
        "category_breakdown": category_stats,
        "top_distractions": top_distractions,
        "interpretation": (
            f"Score {score}/100 — {label}. "
            "Lower is more focused. Productive = AI, dev, learning, reference, productivity. "
            "Distraction = entertainment, social."
        ),
    })


def research_topics(days: int = 30) -> str:
    """Identify research topics by clustering related URLs and titles.

    Groups pages by common keywords in titles/URLs, then returns the top clusters
    ranked by page count.
    """
    STOP_WORDS = {
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "with", "by", "from", "is", "it", "this", "that", "was", "are",
        "be", "been", "have", "has", "had", "do", "does", "did", "will", "would",
        "could", "should", "may", "might", "can", "not", "no", "www", "http",
        "https", "com", "org", "net", "io", "co", "html", "php", "asp", "js",
        "page", "home", "index", "search", "google", "result", "results", "how",
        "what", "why", "when", "where", "who", "which",
    }
    MIN_KEYWORD_LEN = 3
    MIN_CLUSTER_SIZE = 2
    TOP_N_TOPICS = 20

    entries = _load_entries(days)
    if not entries:
        return json.dumps({
            "days": days,
            "topics": [],
            "total_pages_analyzed": 0,
            "message": "No browsing history found.",
        })

    def extract_keywords(text: str) -> list[str]:
        words = re.findall(r"[a-zA-Z0-9]+", text.lower())
        return [
            w for w in words
            if len(w) >= MIN_KEYWORD_LEN and w not in STOP_WORDS and not w.isdigit()
        ]

    # Build keyword -> list of page dicts
    keyword_pages: defaultdict[str, list[dict]] = defaultdict(list)

    for e in entries:
        url = e.get("url", "")
        title = e.get("title", "")
        combined = f"{title} {url}"
        keywords = set(extract_keywords(combined))
        page_info = {"url": url, "title": title, "date": e.get("date", "")}
        for kw in keywords:
            keyword_pages[kw].append(page_info)

    # Filter keywords that appear in at least MIN_CLUSTER_SIZE pages
    clusters = {
        kw: pages
        for kw, pages in keyword_pages.items()
        if len(pages) >= MIN_CLUSTER_SIZE
    }

    # Sort by cluster size
    sorted_clusters = sorted(clusters.items(), key=lambda x: len(x[1]), reverse=True)

    # De-duplicate topics that share almost the same page sets
    # Simple approach: skip a keyword if it's a subset of an already-added cluster
    selected: list[dict] = []
    seen_urls: list[frozenset] = []

    for kw, pages in sorted_clusters[:100]:
        url_set = frozenset(p["url"] for p in pages)
        # Skip if this cluster is dominated by an already-selected one
        is_subset = any(url_set <= prev for prev in seen_urls)
        if is_subset:
            continue
        seen_urls.append(url_set)

        # Representative pages: deduplicated, newest first
        unique_pages: dict[str, dict] = {}
        for p in pages:
            if p["url"] not in unique_pages:
                unique_pages[p["url"]] = p
        page_list = sorted(unique_pages.values(), key=lambda x: x["date"], reverse=True)

        selected.append({
            "topic": kw,
            "page_count": len(page_list),
            "sample_pages": page_list[:5],
        })

        if len(selected) >= TOP_N_TOPICS:
            break

    return json.dumps({
        "days": days,
        "topics": selected,
        "total_pages_analyzed": len(entries),
        "topic_count": len(selected),
    })
