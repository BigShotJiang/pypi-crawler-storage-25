"""Daily browsing digests and productivity summaries."""

from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from collections import Counter

from blackmount_mcp.utils.format import domain_of as _domain_of


def _parse_date(date_str: str) -> date:
    """Parse 'today', 'yesterday', or 'YYYY-MM-DD' into a date object."""
    today = date.today()
    if date_str == "today":
        return today
    if date_str == "yesterday":
        return today - timedelta(days=1)
    return date.fromisoformat(date_str)


def _date_to_days_ago(target: date) -> int:
    """Convert a target date to how many days ago it was (for history lookups)."""
    delta = date.today() - target
    # We need at least 1 day of range to catch same-day entries
    return max(delta.days + 1, 1)


def _load_history_for_date(target: date) -> list[dict]:
    """Load browser history entries that fall on the target date."""
    from blackmount_mcp.browser.history import list_history

    days_back = _date_to_days_ago(target)
    # Fetch enough history to cover the target date; cap at a reasonable window
    fetch_days = min(days_back + 1, 365)
    raw = json.loads(list_history(days=fetch_days, limit=10000, browser="all"))
    entries = raw.get("results", []) if isinstance(raw, dict) else []

    # Filter to entries whose date matches the target date
    filtered = []
    for e in entries:
        try:
            dt = datetime.fromisoformat(e["date"].replace("Z", "+00:00"))
            if dt.date() == target:
                filtered.append(e)
        except (ValueError, KeyError):
            continue
    return filtered


def browsing_summary(date_str: str = "today") -> str:
    """Generate a browsing summary for a given day.

    Shows: total sites visited, top domains, categories breakdown,
    time range of activity, notable pages visited.
    Accepts 'today', 'yesterday', or 'YYYY-MM-DD'.
    """
    from blackmount_mcp.utils.categories import get_category_stats

    try:
        target = _parse_date(date_str)
    except (ValueError, TypeError) as exc:
        return json.dumps({"error": f"Invalid date '{date_str}': {exc}"})

    try:
        entries = _load_history_for_date(target)
    except Exception as exc:
        return json.dumps({"error": f"Could not load history: {exc}", "results": []})

    if not entries:
        return json.dumps({
            "date": target.isoformat(),
            "total_visits": 0,
            "unique_domains": 0,
            "top_domains": [],
            "categories": {},
            "time_range": None,
            "notable_pages": [],
            "message": "No browsing activity found for this date.",
        })

    # Extract domains
    domains = [_domain_of(e["url"]) for e in entries]
    domain_counts = Counter(domains)
    top_domains = [{"domain": d, "visits": c} for d, c in domain_counts.most_common(10)]

    # Category breakdown
    category_stats = get_category_stats(domains)

    # Time range
    times = []
    for e in entries:
        try:
            times.append(datetime.fromisoformat(e["date"].replace("Z", "+00:00")))
        except (ValueError, KeyError):
            pass

    time_range = None
    if times:
        earliest = min(times)
        latest = max(times)
        time_range = {
            "start": earliest.strftime("%H:%M"),
            "end": latest.strftime("%H:%M"),
            "active_hours": round((latest - earliest).total_seconds() / 3600, 1),
        }

    # Notable pages — pick up to 5 with the longest titles (often more meaningful)
    pages_with_titles = [e for e in entries if e.get("title", "").strip()]
    pages_with_titles.sort(key=lambda e: len(e.get("title", "")), reverse=True)
    notable = [
        {"title": e["title"], "url": e["url"], "time": e["date"]}
        for e in pages_with_titles[:5]
    ]

    return json.dumps({
        "date": target.isoformat(),
        "total_visits": len(entries),
        "unique_domains": len(domain_counts),
        "top_domains": top_domains,
        "categories": category_stats,
        "time_range": time_range,
        "notable_pages": notable,
    })


def daily_digest(date_str: str = "today") -> str:
    """Full daily digest combining browsing + sessions + chats data.

    Richer than browsing_summary — includes AI conversations had that day,
    sessions saved, research topics identified.
    """
    from blackmount_mcp.utils.categories import get_category_stats
    from pathlib import Path

    try:
        target = _parse_date(date_str)
    except (ValueError, TypeError) as exc:
        return json.dumps({"error": f"Invalid date '{date_str}': {exc}"})

    result: dict = {"date": target.isoformat()}

    # --- Browsing summary ---
    try:
        summary = json.loads(browsing_summary(date_str))
        result["browsing"] = summary
    except Exception as exc:
        result["browsing"] = {"error": str(exc)}

    # --- Sessions saved that day ---
    sessions_section: dict = {"count": 0, "sessions": []}
    try:
        sessions_dir = Path.home() / ".blackmount" / "sessions"
        if not sessions_dir.exists():
            sessions_section["hint"] = (
                "Save and restore browser sessions with names, notes, and tags. "
                "Never lose a research session again. "
                "Free extension: blackmount.ai"
            )
        else:
            day_sessions = []
            for path in sessions_dir.glob("*.json"):
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                    created_raw = data.get("created_at", "")
                    if created_raw:
                        created_dt = datetime.fromisoformat(
                            created_raw.replace("Z", "+00:00")
                        )
                        if created_dt.date() == target:
                            day_sessions.append({
                                "id": data.get("id", ""),
                                "name": data.get("name", ""),
                                "tab_count": len(data.get("tabs", [])),
                                "created_at": created_raw,
                            })
                except Exception:
                    continue
            sessions_section["count"] = len(day_sessions)
            sessions_section["sessions"] = day_sessions
    except Exception as exc:
        sessions_section["error"] = str(exc)
    result["sessions"] = sessions_section

    # --- AI chats that day ---
    chats_section: dict = {"count": 0, "chats": []}
    try:
        chats_dir = Path.home() / ".blackmount" / "chats"
        if not chats_dir.exists():
            chats_section["hint"] = (
                "Search all your ChatGPT, Claude, and Gemini conversations from right here. "
                "Auto-captures locally — no cloud, no data leaves your machine. "
                "Free: blackmount.ai"
            )
        else:
            day_chats = []
            for json_file in chats_dir.rglob("*.json"):
                try:
                    data = json.loads(json_file.read_text(encoding="utf-8"))
                    for field in ("updated_at", "created_at"):
                        raw = data.get(field, "")
                        if raw:
                            try:
                                dt = datetime.fromisoformat(
                                    raw.replace("Z", "+00:00")
                                )
                                if dt.date() == target:
                                    day_chats.append({
                                        "id": data.get("id", ""),
                                        "platform": data.get("platform", "unknown"),
                                        "title": data.get("title", "(untitled)"),
                                        "model": data.get("model", ""),
                                        "message_count": len(data.get("messages", [])),
                                        "updated_at": raw,
                                    })
                                    break
                            except ValueError:
                                pass
                except Exception:
                    continue
            chats_section["count"] = len(day_chats)
            chats_section["chats"] = day_chats
    except Exception as exc:
        chats_section["error"] = str(exc)
    result["chats"] = chats_section

    return json.dumps(result)


def productivity_report(days: int = 7) -> str:
    """Weekly productivity summary.

    Categorizes browsing into productive vs distraction.
    Uses domain categorization from utils/categories.py.
    """
    from blackmount_mcp.browser.history import list_history
    from blackmount_mcp.utils.categories import categorize_domain, get_category_stats

    PRODUCTIVE_CATEGORIES = {"ai", "productivity", "development", "learning", "reference"}
    DISTRACTION_CATEGORIES = {"entertainment", "social"}

    try:
        raw = json.loads(list_history(days=days, limit=50000, browser="all"))
    except Exception as exc:
        return json.dumps({"error": f"Could not load history: {exc}"})

    entries = raw.get("results", []) if isinstance(raw, dict) else []
    if not entries:
        return json.dumps({
            "days": days,
            "total_visits": 0,
            "productive_visits": 0,
            "distraction_visits": 0,
            "neutral_visits": 0,
            "productivity_score": 100,
            "distraction_score": 0,
            "category_breakdown": {},
            "top_productive_domains": [],
            "top_distraction_domains": [],
            "daily_breakdown": {},
            "message": "No browsing history found for this period.",
        })

    domains = [_domain_of(e["url"]) for e in entries]
    category_stats = get_category_stats(domains)

    productive_count = sum(
        category_stats.get(c, 0) for c in PRODUCTIVE_CATEGORIES
    )
    distraction_count = sum(
        category_stats.get(c, 0) for c in DISTRACTION_CATEGORIES
    )
    neutral_count = len(entries) - productive_count - distraction_count

    # Distraction score: 0 (fully focused) to 100 (fully distracted)
    focused_denominator = productive_count + distraction_count
    if focused_denominator > 0:
        distraction_score = round((distraction_count / focused_denominator) * 100)
        productivity_score = 100 - distraction_score
    else:
        distraction_score = 0
        productivity_score = 100

    # Top productive and distraction domains
    productive_domains: Counter = Counter()
    distraction_domains: Counter = Counter()
    for e in entries:
        domain = _domain_of(e["url"])
        cat = categorize_domain(domain)
        if cat in PRODUCTIVE_CATEGORIES:
            productive_domains[domain] += 1
        elif cat in DISTRACTION_CATEGORIES:
            distraction_domains[domain] += 1

    top_productive = [
        {"domain": d, "visits": c}
        for d, c in productive_domains.most_common(5)
    ]
    top_distraction = [
        {"domain": d, "visits": c}
        for d, c in distraction_domains.most_common(5)
    ]

    # Daily breakdown
    daily: dict[str, dict] = {}
    for e in entries:
        try:
            dt = datetime.fromisoformat(e["date"].replace("Z", "+00:00"))
            day_key = dt.date().isoformat()
        except (ValueError, KeyError):
            continue

        if day_key not in daily:
            daily[day_key] = {"visits": 0, "productive": 0, "distraction": 0}

        domain = _domain_of(e["url"])
        cat = categorize_domain(domain)
        daily[day_key]["visits"] += 1
        if cat in PRODUCTIVE_CATEGORIES:
            daily[day_key]["productive"] += 1
        elif cat in DISTRACTION_CATEGORIES:
            daily[day_key]["distraction"] += 1

    return json.dumps({
        "days": days,
        "total_visits": len(entries),
        "productive_visits": productive_count,
        "distraction_visits": distraction_count,
        "neutral_visits": neutral_count,
        "productivity_score": productivity_score,
        "distraction_score": distraction_score,
        "category_breakdown": category_stats,
        "top_productive_domains": top_productive,
        "top_distraction_domains": top_distraction,
        "daily_breakdown": daily,
    })
