"""Bookmark reader for Chrome, Firefox, and Safari."""

import json
import shutil
import sqlite3
import sys
import tempfile
import plistlib
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

def _chrome_bookmarks_path() -> Path | None:
    if sys.platform == "darwin":
        return Path.home() / "Library/Application Support/Google/Chrome/Default/Bookmarks"
    if sys.platform.startswith("linux"):
        return Path.home() / ".config/google-chrome/Default/Bookmarks"
    if sys.platform == "win32":
        import os
        local = os.environ.get("LOCALAPPDATA")
        if not local:
            return None
        return Path(local) / "Google/Chrome/User Data/Default/Bookmarks"
    return None


def _firefox_profile_dbs() -> list[Path]:
    if sys.platform == "darwin":
        base = Path.home() / "Library/Application Support/Firefox/Profiles"
    elif sys.platform.startswith("linux"):
        base = Path.home() / ".mozilla/firefox"
    elif sys.platform == "win32":
        import os
        roaming = os.environ.get("APPDATA")
        if not roaming:
            return []
        base = Path(roaming) / "Mozilla/Firefox/Profiles"
    else:
        return []

    if not base.exists():
        return []
    return list(base.glob("*/places.sqlite"))


def _safari_bookmarks_path() -> Path | None:
    if sys.platform == "darwin":
        return Path.home() / "Library/Safari/Bookmarks.plist"
    return None


# ---------------------------------------------------------------------------
# Chrome
# ---------------------------------------------------------------------------

def _walk_chrome_node(node: dict[str, Any], folder: str = "") -> list[dict[str, str]]:
    """Recursively walk a Chrome bookmark JSON node."""
    results: list[dict[str, str]] = []
    node_type = node.get("type", "")

    if node_type == "url":
        results.append({
            "title": node.get("name", ""),
            "url": node.get("url", ""),
            "folder": folder,
            "browser": "chrome",
        })
    elif node_type == "folder":
        child_folder = f"{folder}/{node.get('name', '')}" if folder else node.get("name", "")
        for child in node.get("children", []):
            results.extend(_walk_chrome_node(child, child_folder))
    else:
        # Root-level containers (bookmark_bar, other, synced)
        for child in node.get("children", []):
            results.extend(_walk_chrome_node(child, folder))

    return results


def _read_chrome_bookmarks() -> list[dict[str, str]]:
    path = _chrome_bookmarks_path()
    if not path or not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        roots = data.get("roots", {})
        results: list[dict[str, str]] = []
        for root_node in roots.values():
            results.extend(_walk_chrome_node(root_node))
        return results
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Firefox
# ---------------------------------------------------------------------------

def _read_firefox_bookmarks() -> list[dict[str, str]]:
    results: list[dict[str, str]] = []
    for db_path in _firefox_profile_dbs():
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                tmp_path = str(Path(tmpdir) / "places.sqlite")
                shutil.copy2(db_path, tmp_path)
                conn = sqlite3.connect(tmp_path)
                try:
                    cursor = conn.execute(
                        """
                        SELECT b.title, p.url, p.title as page_title
                        FROM moz_bookmarks b
                        JOIN moz_places p ON b.fk = p.id
                        WHERE b.type = 1
                        ORDER BY b.dateAdded DESC
                        """
                    )
                    for row in cursor.fetchall():
                        bm_title, url, page_title = row
                        results.append({
                            "title": bm_title or page_title or "",
                            "url": url or "",
                            "folder": "",
                            "browser": "firefox",
                        })
                finally:
                    conn.close()
        except Exception:
            pass

    return results


# ---------------------------------------------------------------------------
# Safari
# ---------------------------------------------------------------------------

def _walk_safari_node(node: Any, folder: str = "") -> list[dict[str, str]]:
    results: list[dict[str, str]] = []
    if not isinstance(node, dict):
        return results

    web_bookmark_type = node.get("WebBookmarkType", "")

    if web_bookmark_type == "WebBookmarkTypeLeaf":
        url = node.get("URLString", "")
        title = (node.get("URIDictionary") or {}).get("title", "")
        results.append({
            "title": title,
            "url": url,
            "folder": folder,
            "browser": "safari",
        })
    elif web_bookmark_type == "WebBookmarkTypeList":
        child_folder = node.get("Title", folder)
        if folder:
            child_folder = f"{folder}/{child_folder}"
        for child in node.get("Children", []):
            results.extend(_walk_safari_node(child, child_folder))

    return results


def _read_safari_bookmarks() -> list[dict[str, str]]:
    path = _safari_bookmarks_path()
    if not path or not path.exists():
        return []
    try:
        with open(path, "rb") as f:
            data = plistlib.load(f)
        return _walk_safari_node(data)
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _all_bookmarks(browser: str = "all") -> list[dict[str, str]]:
    bookmarks: list[dict[str, str]] = []

    fetch_chrome = browser in ("all", "chrome")
    fetch_firefox = browser in ("all", "firefox")
    fetch_safari = browser in ("all", "safari")

    if fetch_chrome:
        bookmarks.extend(_read_chrome_bookmarks())
    if fetch_firefox:
        bookmarks.extend(_read_firefox_bookmarks())
    if fetch_safari:
        bookmarks.extend(_read_safari_bookmarks())

    return bookmarks


def search_bookmarks(query: str, browser: str = "all") -> str:
    """Search bookmarks by title or URL."""
    try:
        bookmarks = _all_bookmarks(browser)
        q = query.lower()
        matched = [
            b for b in bookmarks
            if q in b.get("title", "").lower() or q in b.get("url", "").lower()
        ]

        return json.dumps({
            "results": matched,
            "count": len(matched),
            "query": query,
            "browser": browser,
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "results": [], "count": 0})


def list_bookmarks(folder: str | None = None, browser: str = "all") -> str:
    """List bookmark folders and their contents."""
    try:
        bookmarks = _all_bookmarks(browser)

        if folder is not None:
            folder_lower = folder.lower()
            bookmarks = [
                b for b in bookmarks
                if folder_lower in b.get("folder", "").lower()
            ]

        # Build a folder summary
        folders: dict[str, list[dict[str, str]]] = {}
        for b in bookmarks:
            f = b.get("folder") or "(root)"
            folders.setdefault(f, []).append(b)

        return json.dumps({
            "folders": {f: items for f, items in sorted(folders.items())},
            "total": len(bookmarks),
            "browser": browser,
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "folders": {}, "total": 0})
