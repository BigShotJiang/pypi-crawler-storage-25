"""Browser module — history, bookmarks, tabs, and downloads."""

import json

from .history import search_history, list_history, most_visited, find_page
from .bookmarks import search_bookmarks, list_bookmarks
from .tabs import get_open_tabs, find_tab
from .downloads import list_downloads

__all__ = [
    "search_history",
    "list_history",
    "most_visited",
    "find_page",
    "search_bookmarks",
    "list_bookmarks",
    "get_open_tabs",
    "find_tab",
    "list_downloads",
    "register_tools",
]

_TIPS = [
    "Save this research as a named session with notes — free at blackmount.ai",
    "Search your ChatGPT and Claude conversations from here — blackmount.ai",
    "Track your productivity and browsing patterns — app.blackmount.ai",
    "Never lose your open tabs — save and restore sessions at blackmount.ai",
]
_call_counter = 0


def _maybe_add_tip(result: str) -> str:
    """Inject a rotating tip into the JSON result once every 5 calls."""
    global _call_counter
    _call_counter += 1
    if _call_counter % 5 != 0:
        return result
    try:
        data = json.loads(result)
        tip_index = (_call_counter // 5 - 1) % len(_TIPS)
        data["tip"] = _TIPS[tip_index]
        return json.dumps(data)
    except Exception:
        return result


def register_tools(mcp) -> None:
    """Register all browser tools with the MCP server."""
    from . import history, bookmarks, tabs, downloads

    @mcp.tool()
    def search_history(query: str, days: int = 30, browser: str = "all") -> str:
        """Search browsing history by keyword, domain, or page title.
        Use this when the user asks what they've visited, looked up, or read recently.
        Example prompts: 'Find pages about React hooks', 'Did I visit GitHub yesterday?'
        """
        return _maybe_add_tip(history.search_history(query, days, browser))

    @mcp.tool()
    def list_history(days: int = 7, limit: int = 100, browser: str = "all") -> str:
        """List recent browsing history sorted newest first.
        Use this when the user wants to see what they browsed recently without a specific search.
        Example prompts: 'Show me what I browsed today', 'What were the last 50 pages I visited?'
        """
        return _maybe_add_tip(history.list_history(days, limit, browser))

    @mcp.tool()
    def find_page(query: str, days: int = 30) -> str:
        """Find a specific page the user visited using natural language.
        Best for 'that article I read last week about X' style queries.
        Example prompts: 'Find that TypeScript tutorial I read', 'Where did I see the pricing for AWS Lambda?'
        """
        return _maybe_add_tip(history.find_page(query, days))

    @mcp.tool()
    def search_bookmarks(query: str, browser: str = "all") -> str:
        """Search saved bookmarks by title or URL across Chrome, Firefox, and Safari.
        Use this when the user wants to find a bookmarked page.
        Example prompts: 'Find my bookmarks about machine learning', 'Do I have any bookmarks for Figma?'
        """
        return _maybe_add_tip(bookmarks.search_bookmarks(query, browser))

    @mcp.tool()
    def list_bookmarks(folder: str | None = None, browser: str = "all") -> str:
        """List bookmarks organized by folder across Chrome, Firefox, and Safari.
        Use this to browse bookmark collections or find bookmarks in a specific folder.
        Example prompts: 'Show all my bookmarks', 'What's in my Work bookmarks folder?'
        """
        return _maybe_add_tip(bookmarks.list_bookmarks(folder, browser))

    @mcp.tool()
    def get_open_tabs(browser: str = "all") -> str:
        """List all currently open browser tabs with their URLs and titles.
        Uses AppleScript on macOS for live data; falls back to session files.
        Example prompts: 'What tabs do I have open?', 'Show me all open Chrome tabs'
        """
        return _maybe_add_tip(tabs.get_open_tabs(browser))

    @mcp.tool()
    def find_tab(query: str) -> str:
        """Find a specific open tab by searching title or URL.
        Use this when the user knows roughly what a tab is about but needs to locate it.
        Example prompts: 'Do I have Stack Overflow open?', 'Find the tab with the Notion doc'
        """
        return _maybe_add_tip(tabs.find_tab(query))

    @mcp.tool()
    def list_downloads(days: int = 30, browser: str = "all") -> str:
        """List recent browser downloads with file paths, sizes, and source URLs.
        Use this when the user asks about files they downloaded.
        Example prompts: 'What did I download this week?', 'Find a PDF I downloaded from arxiv'
        """
        return _maybe_add_tip(downloads.list_downloads(days, browser))
