"""Browser history reader using the browser-history package."""

import json
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse


def _get_cutoff(days: int) -> datetime:
    return datetime.now(tz=timezone.utc) - timedelta(days=days)


def _ensure_aware(dt: datetime) -> datetime:
    """Make a datetime timezone-aware (UTC) if it isn't already."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _fetch_all_histories(browser: str = "all") -> list[tuple[datetime, str, str]]:
    """Return a flat list of (datetime, url, title) tuples across requested browsers."""
    from browser_history.browsers import (
        Chrome, Firefox, Safari, Edge, Brave, Opera, Vivaldi,
    )

    browser_map = {
        "chrome": Chrome,
        "firefox": Firefox,
        "safari": Safari,
        "edge": Edge,
        "brave": Brave,
        "opera": Opera,
        "vivaldi": Vivaldi,
    }

    if browser != "all":
        key = browser.lower()
        if key not in browser_map:
            return []
        candidates = {key: browser_map[key]}
    else:
        candidates = browser_map

    entries: list[tuple[datetime, str, str]] = []
    for name, cls in candidates.items():
        try:
            obj = cls()
            outputs = obj.fetch_history()
            # .histories is a list of (datetime, url) or (datetime, url, title)
            for row in outputs.histories:
                if not isinstance(row, (tuple, list)) or len(row) < 2:
                    continue
                url = row[1]
                if not url:
                    continue
                dt = _ensure_aware(row[0])
                title = row[2] if len(row) > 2 else ""
                entries.append((dt, url, title))
        except Exception:
            # Browser not installed / no history / permission error — skip silently
            pass

    return entries


def _filter_by_days(
    entries: list[tuple[datetime, str, str]], days: int
) -> list[tuple[datetime, str, str]]:
    cutoff = _get_cutoff(days)
    return [e for e in entries if e[0] >= cutoff]


def search_history(query: str, days: int = 30, browser: str = "all") -> str:
    """Search browsing history by keyword in URL or title. Filters by days and optional browser."""
    try:
        entries = _fetch_all_histories(browser)
        entries = _filter_by_days(entries, days)

        q = query.lower()
        matched = [
            e for e in entries if q in e[1].lower() or q in e[2].lower()
        ]

        # Sort newest first
        matched.sort(key=lambda e: e[0], reverse=True)

        results = [
            {"date": e[0].isoformat(), "url": e[1], "title": e[2]}
            for e in matched
        ]

        return json.dumps({
            "results": results,
            "count": len(results),
            "query": query,
            "browser": browser,
            "date_range_days": days,
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "results": [], "count": 0})


def list_history(days: int = 7, limit: int = 100, browser: str = "all") -> str:
    """Recent browsing history sorted by date desc, with limit."""
    try:
        entries = _fetch_all_histories(browser)
        entries = _filter_by_days(entries, days)

        # Sort newest first and apply limit
        entries.sort(key=lambda e: e[0], reverse=True)
        entries = entries[:limit]

        results = [
            {"date": e[0].isoformat(), "url": e[1], "title": e[2]}
            for e in entries
        ]

        return json.dumps({
            "results": results,
            "count": len(results),
            "browser": browser,
            "date_range_days": days,
            "limit": limit,
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "results": [], "count": 0})


def most_visited(days: int = 30, limit: int = 20, browser: str = "all") -> str:
    """Most visited domains by visit count."""
    try:
        entries = _fetch_all_histories(browser)
        entries = _filter_by_days(entries, days)

        domain_counts: dict[str, int] = {}
        for _, url, _ in entries:
            try:
                domain = urlparse(url).netloc or url
            except Exception:
                domain = url
            domain_counts[domain] = domain_counts.get(domain, 0) + 1

        ranked = sorted(domain_counts.items(), key=lambda x: x[1], reverse=True)[:limit]

        results = [{"domain": d, "visits": c} for d, c in ranked]

        return json.dumps({
            "results": results,
            "count": len(results),
            "browser": browser,
            "date_range_days": days,
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "results": [], "count": 0})


def find_page(query: str, days: int = 30) -> str:
    """Find a specific page visited. Natural language friendly — searches URL and title."""
    try:
        entries = _fetch_all_histories("all")
        entries = _filter_by_days(entries, days)

        q = query.lower()
        # Score: title match weighted higher than URL match
        scored: list[tuple[int, datetime, str, str]] = []
        for dt, url, title in entries:
            score = 0
            if q in title.lower():
                score += 2
            if q in url.lower():
                score += 1
            if score:
                scored.append((score, dt, url, title))

        # Sort by score desc then date desc
        scored.sort(key=lambda x: (x[0], x[1]), reverse=True)

        results = [
            {"score": s, "date": dt.isoformat(), "url": url, "title": title}
            for s, dt, url, title in scored
        ]

        return json.dumps({
            "results": results,
            "count": len(results),
            "query": query,
            "date_range_days": days,
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "results": [], "count": 0})
