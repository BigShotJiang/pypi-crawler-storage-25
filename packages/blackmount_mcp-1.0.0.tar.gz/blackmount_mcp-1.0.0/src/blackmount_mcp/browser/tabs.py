"""Currently open browser tabs reader.

Primary approach (macOS): AppleScript to query Chrome/Safari/Firefox directly.
Fallback: SNSS binary scan of Chrome session files.
"""

import json
import re
import subprocess
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# AppleScript helpers (macOS only)
# ---------------------------------------------------------------------------

def _applescript_chrome_tabs() -> list[dict[str, str]]:
    """Use AppleScript to get all open Chrome tabs."""
    script = (
        'tell application "Google Chrome"\n'
        '  set tabList to {}\n'
        '  repeat with w in windows\n'
        '    repeat with t in tabs of w\n'
        '      set end of tabList to (URL of t) & "|||" & (title of t)\n'
        '    end repeat\n'
        '  end repeat\n'
        '  set AppleScript\'s text item delimiters to "\\n"\n'
        '  set output to tabList as text\n'
        '  set AppleScript\'s text item delimiters to ""\n'
        '  return output\n'
        'end tell'
    )
    try:
        proc = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if proc.returncode != 0:
            return []
        raw = proc.stdout.strip()
        if not raw:
            return []
        tabs = []
        for line in raw.splitlines():
            if "|||" in line:
                url, title = line.split("|||", 1)
                tabs.append({"url": url.strip(), "title": title.strip(), "browser": "chrome"})
        return tabs
    except Exception:
        return []


def _applescript_safari_tabs() -> list[dict[str, str]]:
    """Use AppleScript to get all open Safari tabs."""
    script = (
        'tell application "Safari"\n'
        '  set tabList to {}\n'
        '  repeat with w in windows\n'
        '    if class of w is browser window then\n'
        '      repeat with t in tabs of w\n'
        '        set end of tabList to (URL of t) & "|||" & (name of t)\n'
        '      end repeat\n'
        '    end if\n'
        '  end repeat\n'
        '  set AppleScript\'s text item delimiters to "\\n"\n'
        '  set output to tabList as text\n'
        '  set AppleScript\'s text item delimiters to ""\n'
        '  return output\n'
        'end tell'
    )
    try:
        proc = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if proc.returncode != 0:
            return []
        raw = proc.stdout.strip()
        if not raw:
            return []
        tabs = []
        for line in raw.splitlines():
            if "|||" in line:
                url, title = line.split("|||", 1)
                tabs.append({"url": url.strip(), "title": title.strip(), "browser": "safari"})
        return tabs
    except Exception:
        return []


# ---------------------------------------------------------------------------
# SNSS binary fallback for Chrome
# ---------------------------------------------------------------------------

_URL_PATTERN = re.compile(rb"https?://[^\x00-\x1f\x7f ]{8,}")


def _snss_scan_chrome() -> list[dict[str, str]]:
    """Scan Chrome's Current Session SNSS binary file for URL strings."""
    if sys.platform == "darwin":
        session_dir = (
            Path.home()
            / "Library/Application Support/Google/Chrome/Default"
        )
    elif sys.platform.startswith("linux"):
        session_dir = Path.home() / ".config/google-chrome/Default"
    elif sys.platform == "win32":
        import os
        local = os.environ.get("LOCALAPPDATA")
        if not local:
            return []
        session_dir = Path(local) / "Google/Chrome/User Data/Default"
    else:
        return []

    candidates = [
        session_dir / "Current Session",
        session_dir / "Current Tabs",
        session_dir / "Last Session",
        session_dir / "Last Tabs",
    ]

    found_urls: list[str] = []
    for path in candidates:
        if not path.exists():
            continue
        try:
            data = path.read_bytes()
            matches = _URL_PATTERN.findall(data)
            for m in matches:
                try:
                    url = m.decode("utf-8", errors="ignore")
                    if url not in found_urls:
                        found_urls.append(url)
                except Exception:
                    pass
        except Exception:
            pass

    return [{"url": u, "title": "", "browser": "chrome"} for u in found_urls]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_open_tabs(browser: str = "all") -> str:
    """List currently open tabs. Uses AppleScript on macOS; falls back to session file scan."""
    try:
        tabs: list[dict[str, str]] = []

        if sys.platform == "darwin":
            # AppleScript is the most reliable method on macOS
            if browser in ("all", "chrome"):
                tabs.extend(_applescript_chrome_tabs())
            if browser in ("all", "safari"):
                tabs.extend(_applescript_safari_tabs())

            # If AppleScript returned nothing for Chrome, try SNSS fallback
            chrome_tabs = [t for t in tabs if t["browser"] == "chrome"]
            if not chrome_tabs and browser in ("all", "chrome"):
                tabs.extend(_snss_scan_chrome())
        else:
            # Non-macOS: SNSS scan only for Chrome
            if browser in ("all", "chrome"):
                tabs.extend(_snss_scan_chrome())

        return json.dumps({
            "results": tabs,
            "count": len(tabs),
            "browser": browser,
            "note": (
                "Tab listing is most accurate when Chrome/Safari is running on macOS. "
                "Firefox tab access is not supported via AppleScript."
            ),
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "results": [], "count": 0})


def find_tab(query: str) -> str:
    """Find a specific open tab by title or URL keyword."""
    try:
        all_tabs_json = json.loads(get_open_tabs("all"))
        tabs = all_tabs_json.get("results", [])

        q = query.lower()
        matched = [
            t for t in tabs
            if q in t.get("url", "").lower() or q in t.get("title", "").lower()
        ]

        return json.dumps({
            "results": matched,
            "count": len(matched),
            "query": query,
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "results": [], "count": 0})
