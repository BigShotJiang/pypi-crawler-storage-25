"""Download history reader for Chrome, Firefox, and Safari."""

import json
import plistlib
import shutil
import sqlite3
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_cutoff(days: int) -> datetime:
    return datetime.now(tz=timezone.utc) - timedelta(days=days)


def _ensure_aware(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _copy_sqlite_to_dir(path: Path, tmpdir: str) -> str:
    """Copy a SQLite DB to a temp directory to avoid lock conflicts."""
    tmp_path = str(Path(tmpdir) / "db.sqlite")
    shutil.copy2(path, tmp_path)
    return tmp_path


def _chrome_epoch_to_dt(chrome_ts: int) -> datetime:
    """Chrome timestamps are microseconds since 1601-01-01."""
    CHROME_EPOCH = datetime(1601, 1, 1, tzinfo=timezone.utc)
    return CHROME_EPOCH + timedelta(microseconds=chrome_ts)


# ---------------------------------------------------------------------------
# Chrome
# ---------------------------------------------------------------------------

def _chrome_history_path() -> Path | None:
    if sys.platform == "darwin":
        return Path.home() / "Library/Application Support/Google/Chrome/Default/History"
    if sys.platform.startswith("linux"):
        return Path.home() / ".config/google-chrome/Default/History"
    if sys.platform == "win32":
        import os
        local = os.environ.get("LOCALAPPDATA")
        if not local:
            return None
        return Path(local) / "Google/Chrome/User Data/Default/History"
    return None


def _read_chrome_downloads(days: int) -> list[dict]:
    path = _chrome_history_path()
    if not path or not path.exists():
        return []

    results = []
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = _copy_sqlite_to_dir(path, tmpdir)
            conn = sqlite3.connect(tmp)
            try:
                cursor = conn.execute(
                    """
                    SELECT
                        target_path,
                        tab_url,
                        total_bytes,
                        start_time,
                        end_time,
                        state,
                        danger_type
                    FROM downloads
                    ORDER BY start_time DESC
                    """
                )
                cutoff = _get_cutoff(days)
                for row in cursor.fetchall():
                    target_path, tab_url, total_bytes, start_time, end_time, state, danger_type = row
                    dt = _chrome_epoch_to_dt(start_time)
                    if dt < cutoff:
                        continue
                    filename = Path(target_path).name if target_path else ""
                    results.append({
                        "filename": filename,
                        "path": target_path or "",
                        "url": tab_url or "",
                        "size_bytes": total_bytes or 0,
                        "date": dt.isoformat(),
                        "browser": "chrome",
                    })
            finally:
                conn.close()
    except Exception:
        pass

    return results


# ---------------------------------------------------------------------------
# Firefox
# ---------------------------------------------------------------------------

def _firefox_profile_dbs() -> list[Path]:
    if sys.platform == "darwin":
        base = Path.home() / "Library/Application Support/Firefox/Profiles"
    elif sys.platform.startswith("linux"):
        base = Path.home() / ".mozilla/firefox"
    elif sys.platform == "win32":
        import os
        roaming = os.environ.get("APPDATA")
        if not roaming:
            return []
        base = Path(roaming) / "Mozilla/Firefox/Profiles"
    else:
        return []

    if not base.exists():
        return []
    return list(base.glob("*/places.sqlite"))


def _firefox_epoch_to_dt(micro: int) -> datetime:
    """Firefox timestamps are microseconds since Unix epoch."""
    return datetime.fromtimestamp(micro / 1_000_000, tz=timezone.utc)


def _read_firefox_downloads(days: int) -> list[dict]:
    results = []
    cutoff = _get_cutoff(days)

    for db_path in _firefox_profile_dbs():
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                tmp = _copy_sqlite_to_dir(db_path, tmpdir)
                conn = sqlite3.connect(tmp)
                try:
                    # Downloads are stored as annotations on moz_places
                    cursor = conn.execute(
                        """
                        SELECT
                            p.url,
                            p.title,
                            a.content,
                            a.dateAdded
                        FROM moz_annos a
                        JOIN moz_places p ON a.place_id = p.id
                        WHERE a.anno_attribute_id = (
                            SELECT id FROM moz_anno_attributes WHERE name = 'downloads/destinationFileURI'
                        )
                        ORDER BY a.dateAdded DESC
                        """
                    )
                    for row in cursor.fetchall():
                        source_url, title, dest_uri, date_added = row
                        dt = _firefox_epoch_to_dt(date_added)
                        if dt < cutoff:
                            continue

                        # dest_uri is a file:// URI — use urlparse for proper decoding
                        if dest_uri:
                            from urllib.parse import unquote, urlparse
                            file_path = unquote(urlparse(dest_uri).path)
                        else:
                            file_path = ""
                        filename = Path(file_path).name if file_path else (title or "")

                        results.append({
                            "filename": filename,
                            "path": file_path,
                            "url": source_url or "",
                            "size_bytes": 0,  # not easily available from annotations
                            "date": dt.isoformat(),
                            "browser": "firefox",
                        })
                finally:
                    conn.close()
        except Exception:
            pass

    return results


# ---------------------------------------------------------------------------
# Safari
# ---------------------------------------------------------------------------

def _safari_downloads_path() -> Path | None:
    if sys.platform == "darwin":
        return Path.home() / "Library/Safari/Downloads.plist"
    return None


def _read_safari_downloads(days: int) -> list[dict]:
    path = _safari_downloads_path()
    if not path or not path.exists():
        return []

    results = []
    cutoff = _get_cutoff(days)

    try:
        with open(path, "rb") as f:
            data = plistlib.load(f)

        for item in data.get("DownloadHistory", []):
            raw_date = item.get("DownloadEntryDateFinishedKey")
            if raw_date:
                # plistlib returns datetime objects (naive, local time) for plist dates
                dt = _ensure_aware(raw_date) if isinstance(raw_date, datetime) else None
            else:
                dt = None

            if dt and dt < cutoff:
                continue

            dest = item.get("DownloadEntryPath", "") or ""
            source = item.get("DownloadEntryURL", "") or ""
            filename = Path(dest).name if dest else ""
            size = item.get("DownloadEntryProgressTotalToLoad", 0) or 0

            results.append({
                "filename": filename,
                "path": dest,
                "url": source,
                "size_bytes": int(size),
                "date": dt.isoformat() if dt else "",
                "browser": "safari",
            })
    except Exception:
        pass

    return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def list_downloads(days: int = 30, browser: str = "all") -> str:
    """Recent downloads with file paths, sizes, and source URLs."""
    try:
        results: list[dict] = []

        if browser in ("all", "chrome"):
            results.extend(_read_chrome_downloads(days))
        if browser in ("all", "firefox"):
            results.extend(_read_firefox_downloads(days))
        if browser in ("all", "safari"):
            results.extend(_read_safari_downloads(days))

        # Sort newest first
        results.sort(key=lambda r: r.get("date", ""), reverse=True)

        return json.dumps({
            "results": results,
            "count": len(results),
            "browser": browser,
            "date_range_days": days,
        })
    except Exception as exc:
        return json.dumps({"error": str(exc), "results": [], "count": 0})
