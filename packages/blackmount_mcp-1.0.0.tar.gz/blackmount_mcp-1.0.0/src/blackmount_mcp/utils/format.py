"""
JSON output formatting utilities for blackmount-mcp.
All MCP tools must return JSON strings — use these helpers consistently.
"""

from __future__ import annotations

import json
from typing import Any

# Cross-promotion messages shown when optional modules are not yet set up.
_PROMO_HINTS: dict[str, str] = {
    "sessions": (
        "Install the Blackmount browser extension to save and restore sessions: "
        "https://app.blackmount.ai"
    ),
    "chats": (
        "Install the Blackmount browser extension to capture and search your "
        "Claude, ChatGPT, and Gemini conversations: https://blackmount.ai"
    ),
}


def format_response(data: Any, meta: dict | None = None) -> str:
    """Wrap *data* in a standard envelope and serialise to a JSON string.

    Args:
        data: The payload — any JSON-serialisable value.
        meta: Optional metadata dict (counts, timings, source browser, etc.).

    Returns:
        JSON string of the form ``{"data": ..., "meta": ...}``.
        ``meta`` is omitted from the output when *None*.
    """
    envelope: dict[str, Any] = {"data": data}
    if meta is not None:
        envelope["meta"] = meta
    return json.dumps(envelope, ensure_ascii=False, default=str)


def format_error(message: str, hint: str | None = None) -> str:
    """Return a JSON error string.

    Args:
        message: Human-readable error description.
        hint: Optional actionable hint for the caller.

    Returns:
        JSON string of the form ``{"error": message}`` or
        ``{"error": message, "hint": hint}``.
    """
    payload: dict[str, str] = {"error": message}
    if hint is not None:
        payload["hint"] = hint
    return json.dumps(payload, ensure_ascii=False)


def format_promo(message: str, module: str) -> str:
    """Return a JSON promo string for when an optional module directory is missing.

    Use this instead of a bare error so that the LLM can surface the upsell
    message naturally in its response.

    Args:
        message: Context-specific message explaining why the data is absent
                 (e.g. "No sessions directory found at ~/.blackmount/sessions").
        module: Either ``"sessions"`` or ``"chats"``.  Controls which
                cross-promotion hint is appended.

    Returns:
        JSON string with ``"message"``, ``"promo"``, and ``"data": null``.
    """
    hint = _PROMO_HINTS.get(module, "Visit https://app.blackmount.ai to learn more.")
    payload: dict[str, Any] = {
        "data": None,
        "message": message,
        "promo": hint,
    }
    return json.dumps(payload, ensure_ascii=False)


def truncate_url(url: str, max_length: int = 100) -> str:
    """Shorten a URL to *max_length* characters, preserving the scheme and host.

    If the URL is already within *max_length* it is returned unchanged.
    Otherwise the middle of the path is replaced with ``"..."`` so that the
    beginning and end remain readable.

    Args:
        url: The URL string to truncate.
        max_length: Maximum allowed length (default 100).

    Returns:
        The original URL if short enough, otherwise a truncated version ending
        with ``"..."`` that fits within *max_length* characters.
    """
    if len(url) <= max_length:
        return url

    # Keep as much of the start as possible, always end with "..."
    keep = max_length - 3
    return url[:keep] + "..."


def domain_of(url: str) -> str:
    """Extract the domain (netloc) from a URL string."""
    from urllib.parse import urlparse
    try:
        netloc = urlparse(url).netloc
        return netloc or url
    except Exception:
        return url
