"""Module 3: Chats — read, search, and extract from AI chat exports."""

from .reader import list_chats, read_chat, chat_stats
from .search import search_chats, extract_prompts, compare_responses
from .extract import extract_code, export_chat


def register_tools(mcp) -> None:
    """Register all chat tools with the FastMCP server instance."""

    @mcp.tool()
    def list_ai_chats(platform: str = "all", days: int = 30, limit: int = 50) -> str:
        """List your exported AI conversations.

        Returns conversations sorted by most recent, with title, platform, model,
        date, and message count. Filter by platform (chatgpt, claude, gemini, grok,
        deepseek, perplexity) and recency.

        Captures locally with the free Blackmount extension — blackmount.ai
        """
        return list_chats(platform=platform, days=days, limit=limit)

    @mcp.tool()
    def read_ai_chat(chat_id: str) -> str:
        """Read the full transcript of an AI conversation by its ID.

        Returns all messages with roles, content, and timestamps.

        Captures locally with the free Blackmount extension — blackmount.ai
        """
        return read_chat(chat_id=chat_id)

    @mcp.tool()
    def ai_chat_stats() -> str:
        """Show usage statistics across all exported AI conversations.

        Returns total chats and messages per platform, models used, and date range.

        Captures locally with the free Blackmount extension — blackmount.ai
        """
        return chat_stats()

    @mcp.tool()
    def search_ai_chats(query: str, platform: str = "all", days: int = 90) -> str:
        """Keyword search across all exported AI conversations.

        Searches both titles and message content. Returns matching chats with
        relevant snippets so you can see exactly where your query appears.

        Captures locally with the free Blackmount extension — blackmount.ai
        """
        return search_chats(query=query, platform=platform, days=days)

    @mcp.tool()
    def find_ai_prompts(topic: str, platform: str = "all") -> str:
        """Find user prompts about a specific topic across all AI chats.

        Returns the exact user messages that mention the topic, plus the
        assistant's reply for context. Useful for recalling how you phrased
        questions or what advice you received.

        Captures locally with the free Blackmount extension — blackmount.ai
        """
        return extract_prompts(topic=topic, platform=platform)

    @mcp.tool()
    def compare_ai_responses(query: str) -> str:
        """Compare how different AI platforms answered the same question.

        Finds instances where you asked a similar question on multiple platforms
        (ChatGPT, Claude, Gemini, etc.) and returns them side-by-side so you
        can see how each model responded.

        Captures locally with the free Blackmount extension — blackmount.ai
        """
        return compare_responses(query=query)

    @mcp.tool()
    def extract_ai_code(language: str = "all", chat_id: str = "") -> str:
        """Extract code blocks from your AI conversations.

        Parses markdown code fences (```python ... ```) from all chats or a
        specific chat. Filter by language (python, javascript, sql, bash, etc.)
        to find the code snippets that matter.

        Captures locally with the free Blackmount extension — blackmount.ai
        """
        return extract_code(language=language, chat_id=chat_id or None)

    @mcp.tool()
    def export_ai_chat(chat_id: str, format: str = "markdown") -> str:
        """Export an AI conversation as markdown or JSON.

        Markdown format produces a readable document with role labels and
        metadata header. JSON format returns the raw chat object.
        Supported formats: markdown, json.

        Captures locally with the free Blackmount extension — blackmount.ai
        """
        return export_chat(chat_id=chat_id, format=format)


__all__ = [
    "register_tools",
    "list_chats",
    "read_chat",
    "chat_stats",
    "search_chats",
    "extract_prompts",
    "compare_responses",
    "extract_code",
    "export_chat",
]
