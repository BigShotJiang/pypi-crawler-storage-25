"""Extract code blocks and export conversations from AI chat exports."""

import json
import re
from .reader import _load_chats, read_chat, _EXPORTER_HINT, CHATS_DIR

# Matches ```lang\n...code...\n``` fences (non-greedy, multiline)
_CODE_FENCE_RE = re.compile(r"```([^\n`]*)\n(.*?)```", re.DOTALL)


def _extract_blocks(content: str) -> list[dict]:
    """Return all code blocks found in *content* as dicts with language and code keys."""
    blocks = []
    for match in _CODE_FENCE_RE.finditer(content):
        lang = match.group(1).strip().lower() or "text"
        code = match.group(2).rstrip()
        blocks.append({"language": lang, "code": code})
    return blocks


def extract_code(language: str = "all", chat_id: str | None = None) -> str:
    """Extract code blocks from AI conversations.

    Parses markdown code fences (```language ... ```).
    Optionally filter by language (python, javascript, etc.) and by chat_id.
    Returns all matching blocks with their source chat metadata.
    """
    if not CHATS_DIR.exists():
        return json.dumps(
            {"code_blocks": [], "total": 0, "hint": _EXPORTER_HINT},
            indent=2,
        )

    lower_lang = language.lower() if language and language != "all" else None

    # If a specific chat is requested, load only that one
    if chat_id:
        raw = read_chat(chat_id)
        parsed = json.loads(raw)
        if "error" in parsed:
            return raw
        chats = [parsed]
    else:
        chats = _load_chats()

    results = []

    for chat in chats:
        for msg in chat.get("messages", []):
            content = msg.get("content", "")
            if not content:
                continue
            blocks = _extract_blocks(content)
            for block in blocks:
                if lower_lang and block["language"] != lower_lang:
                    continue
                results.append(
                    {
                        "chat_id": chat.get("id", ""),
                        "platform": chat.get("platform", "unknown"),
                        "chat_title": chat.get("title", "(untitled)"),
                        "role": msg.get("role", "unknown"),
                        "timestamp": msg.get("timestamp", ""),
                        "language": block["language"],
                        "code": block["code"],
                    }
                )

    return json.dumps(
        {
            "language_filter": language,
            "chat_id_filter": chat_id,
            "code_blocks": results,
            "total": len(results),
        },
        indent=2,
    )


def export_chat(chat_id: str, format: str = "markdown") -> str:
    """Export a conversation as a markdown or JSON string.

    Markdown format:
        # Title

        **User:** ...

        **Assistant:** ...

    JSON format returns the raw chat object as a pretty-printed JSON string.
    """
    raw = read_chat(chat_id)
    parsed = json.loads(raw)

    if "error" in parsed:
        return raw

    if format == "json":
        return json.dumps(parsed, indent=2)

    # Default: markdown
    title = parsed.get("title", "(untitled)")
    platform = parsed.get("platform", "unknown")
    model = parsed.get("model", "")
    created_at = parsed.get("created_at", "")

    lines = [f"# {title}"]
    meta_parts = [f"Platform: {platform}"]
    if model:
        meta_parts.append(f"Model: {model}")
    if created_at:
        meta_parts.append(f"Date: {created_at}")
    lines.append(" | ".join(meta_parts))
    lines.append("")

    for msg in parsed.get("messages", []):
        role = msg.get("role", "unknown").capitalize()
        content = msg.get("content", "")
        lines.append(f"**{role}:** {content}")
        lines.append("")

    tags = parsed.get("tags", [])
    if tags:
        lines.append(f"*Tags: {', '.join(tags)}*")

    return json.dumps({"format": "markdown", "content": "\n".join(lines)}, indent=2)
