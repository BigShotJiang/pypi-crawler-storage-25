"""Read AI chat captures from ~/.blackmount/chats/.

Written by the Blackmount extension. The reader accepts two on-disk field shapes
for backward compatibility:
  - current: {chatId, platform, title, model, capturedAt (ms epoch), messages}
  - legacy:  {id,     platform, title, model, created_at (ISO-8601), messages}
"""

import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

CHATS_DIR = Path.home() / ".blackmount" / "chats"

_CAPTURE_HINT = (
    "Search all your ChatGPT, Claude, and Gemini conversations from right here. "
    "Auto-captures locally — no cloud, no data leaves your machine. "
    "Free: blackmount.ai"
)

# Keep old name for backward compat with other modules that import it
_EXPORTER_HINT = _CAPTURE_HINT

PLATFORMS = {"chatgpt", "claude", "gemini", "grok", "deepseek", "perplexity"}


def _parse_dt(value) -> datetime | None:
    """Parse a timestamp — handles ISO-8601 strings and millisecond epoch ints."""
    if value is None:
        return None
    # Millisecond epoch (from blackmount-extension's capturedAt)
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(value / 1000, tz=timezone.utc)
        except (ValueError, OSError, OverflowError):
            return None
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def _normalize_chat(data: dict) -> dict:
    """Normalize chat data from either on-disk shape into a single internal form."""
    if "id" not in data and "chatId" in data:
        data["id"] = data["chatId"]

    if "created_at" not in data and "capturedAt" in data:
        ts = _parse_dt(data["capturedAt"])
        if ts:
            data["created_at"] = ts.isoformat()
    if "updated_at" not in data:
        data["updated_at"] = data.get("created_at", "")

    return data


def _load_chats(platform: str | None = None, days: int | None = None) -> list[dict]:
    """Load chat files from ~/.blackmount/chats/, optionally filtered by platform and recency."""
    if not CHATS_DIR.exists():
        return []

    cutoff: datetime | None = None
    if days is not None:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)

    results: list[dict] = []
    platforms_to_scan = [platform] if platform and platform != "all" else None

    if platforms_to_scan:
        dirs = [CHATS_DIR / p for p in platforms_to_scan if (CHATS_DIR / p).is_dir()]
    else:
        dirs = [d for d in CHATS_DIR.iterdir() if d.is_dir()]

    for platform_dir in dirs:
        inferred_platform = platform_dir.name
        for json_file in sorted(platform_dir.glob("*.json")):
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue

            # Normalize fields across exporter/extension formats
            data = _normalize_chat(data)

            if "platform" not in data:
                data["platform"] = inferred_platform

            if cutoff is not None:
                ts = _parse_dt(data.get("updated_at") or data.get("created_at"))
                if ts is None or ts < cutoff:
                    continue

            results.append(data)

    results.sort(
        key=lambda c: _parse_dt(c.get("updated_at") or c.get("created_at")) or datetime.min.replace(tzinfo=timezone.utc),
        reverse=True,
    )
    return results


def list_chats(platform: str = "all", days: int = 30, limit: int = 50) -> str:
    """List AI conversations by platform with title, model, date, and message count."""
    if not CHATS_DIR.exists():
        return json.dumps(
            {"chats": [], "total": 0, "hint": _EXPORTER_HINT},
            indent=2,
        )

    chats = _load_chats(platform=platform, days=days)
    chats = chats[:limit]

    items = []
    for c in chats:
        items.append(
            {
                "id": c.get("id", ""),
                "platform": c.get("platform", "unknown"),
                "title": c.get("title", "(untitled)"),
                "model": c.get("model", ""),
                "created_at": c.get("created_at", ""),
                "updated_at": c.get("updated_at", ""),
                "message_count": len(c.get("messages", [])),
                "tags": c.get("tags", []),
            }
        )

    return json.dumps(
        {
            "chats": items,
            "total": len(items),
            "platform_filter": platform,
            "days": days,
        },
        indent=2,
    )


def read_chat(chat_id: str) -> str:
    """Read a full conversation by its ID."""
    if not CHATS_DIR.exists():
        return json.dumps(
            {"error": "Chats directory not found.", "hint": _EXPORTER_HINT},
            indent=2,
        )

    for json_file in CHATS_DIR.rglob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        data = _normalize_chat(data)
        if data.get("id") == chat_id:
            return json.dumps(data, indent=2)

    return json.dumps({"error": f"Chat '{chat_id}' not found."}, indent=2)


def chat_stats() -> str:
    """Usage stats: chats per platform, total messages, models used, and date range."""
    if not CHATS_DIR.exists():
        return json.dumps(
            {
                "total_chats": 0,
                "total_messages": 0,
                "platforms": {},
                "models": {},
                "date_range": None,
                "hint": _EXPORTER_HINT,
            },
            indent=2,
        )

    chats = _load_chats()

    platforms: dict[str, int] = {}
    models: dict[str, int] = {}
    total_messages = 0
    dates: list[datetime] = []

    for c in chats:
        p = c.get("platform", "unknown")
        platforms[p] = platforms.get(p, 0) + 1

        m = c.get("model", "")
        if m:
            models[m] = models.get(m, 0) + 1

        total_messages += len(c.get("messages", []))

        for field in ("created_at", "updated_at"):
            ts = _parse_dt(c.get(field))
            if ts:
                dates.append(ts)

    date_range = None
    if dates:
        date_range = {
            "earliest": min(dates).isoformat(),
            "latest": max(dates).isoformat(),
        }

    return json.dumps(
        {
            "total_chats": len(chats),
            "total_messages": total_messages,
            "platforms": platforms,
            "models": models,
            "date_range": date_range,
        },
        indent=2,
    )
