"""Keyword search and cross-platform comparison for AI chat exports."""

import json
from .reader import _load_chats, _EXPORTER_HINT, CHATS_DIR

_SNIPPET_WINDOW = 120  # characters around a match to include as context


def _snippet(text: str, query: str, window: int = _SNIPPET_WINDOW) -> str:
    """Return a short excerpt of *text* centred on the first occurrence of *query*."""
    lower_text = text.lower()
    lower_query = query.lower()
    idx = lower_text.find(lower_query)
    if idx == -1:
        return text[:window * 2].strip()
    start = max(0, idx - window // 2)
    end = min(len(text), idx + len(query) + window // 2)
    prefix = "..." if start > 0 else ""
    suffix = "..." if end < len(text) else ""
    return prefix + text[start:end].strip() + suffix


def _chat_matches(chat: dict, query: str) -> list[dict]:
    """Return a list of match dicts (role + snippet) for every message that contains *query*."""
    lower_query = query.lower()
    hits: list[dict] = []

    # Check title
    title = chat.get("title", "")
    if lower_query in title.lower():
        hits.append({"location": "title", "snippet": title})

    for msg in chat.get("messages", []):
        content = msg.get("content", "")
        if lower_query in content.lower():
            hits.append(
                {
                    "role": msg.get("role", "unknown"),
                    "timestamp": msg.get("timestamp", ""),
                    "snippet": _snippet(content, query),
                }
            )
    return hits


def search_chats(query: str, platform: str = "all", days: int = 90) -> str:
    """Keyword search across all AI conversations. Searches titles and message content.
    Returns matching chats with relevant message snippets."""
    if not CHATS_DIR.exists():
        return json.dumps(
            {"results": [], "total": 0, "hint": _EXPORTER_HINT},
            indent=2,
        )

    if not query or not query.strip():
        return json.dumps({"error": "query must not be empty."}, indent=2)

    chats = _load_chats(platform=platform, days=days)
    results = []

    for chat in chats:
        hits = _chat_matches(chat, query)
        if hits:
            results.append(
                {
                    "id": chat.get("id", ""),
                    "platform": chat.get("platform", "unknown"),
                    "title": chat.get("title", "(untitled)"),
                    "model": chat.get("model", ""),
                    "updated_at": chat.get("updated_at", ""),
                    "matches": hits,
                }
            )

    return json.dumps(
        {
            "query": query,
            "platform_filter": platform,
            "days": days,
            "results": results,
            "total": len(results),
        },
        indent=2,
    )


def extract_prompts(topic: str, platform: str = "all") -> str:
    """Find user prompts about a specific topic across all chats.
    Returns the user messages that match, with surrounding context."""
    if not CHATS_DIR.exists():
        return json.dumps(
            {"prompts": [], "total": 0, "hint": _EXPORTER_HINT},
            indent=2,
        )

    if not topic or not topic.strip():
        return json.dumps({"error": "topic must not be empty."}, indent=2)

    chats = _load_chats(platform=platform)
    lower_topic = topic.lower()
    prompts = []

    for chat in chats:
        messages = chat.get("messages", [])
        for i, msg in enumerate(messages):
            if msg.get("role") != "user":
                continue
            content = msg.get("content", "")
            if lower_topic not in content.lower():
                continue

            # Grab next assistant message as context if available
            context = ""
            if i + 1 < len(messages) and messages[i + 1].get("role") == "assistant":
                context = messages[i + 1].get("content", "")[:300]

            prompts.append(
                {
                    "chat_id": chat.get("id", ""),
                    "platform": chat.get("platform", "unknown"),
                    "chat_title": chat.get("title", "(untitled)"),
                    "timestamp": msg.get("timestamp", ""),
                    "prompt": content,
                    "assistant_context": context,
                }
            )

    return json.dumps(
        {
            "topic": topic,
            "platform_filter": platform,
            "prompts": prompts,
            "total": len(prompts),
        },
        indent=2,
    )


def compare_responses(query: str) -> str:
    """Find the same or similar question asked across different AI platforms.
    Returns a side-by-side comparison grouped by platform."""
    if not CHATS_DIR.exists():
        return json.dumps(
            {"comparison": {}, "hint": _EXPORTER_HINT},
            indent=2,
        )

    if not query or not query.strip():
        return json.dumps({"error": "query must not be empty."}, indent=2)

    chats = _load_chats()
    lower_query = query.lower()
    comparison: dict[str, list[dict]] = {}

    for chat in chats:
        platform = chat.get("platform", "unknown")
        messages = chat.get("messages", [])

        for i, msg in enumerate(messages):
            if msg.get("role") != "user":
                continue
            content = msg.get("content", "")
            if lower_query not in content.lower():
                continue

            # Find the assistant reply that follows this user message
            assistant_reply = ""
            for j in range(i + 1, len(messages)):
                if messages[j].get("role") == "assistant":
                    assistant_reply = messages[j].get("content", "")
                    break

            entry = {
                "chat_id": chat.get("id", ""),
                "chat_title": chat.get("title", "(untitled)"),
                "model": chat.get("model", ""),
                "timestamp": msg.get("timestamp", ""),
                "user_prompt": _snippet(content, query, window=200),
                "assistant_response": assistant_reply[:600] + ("..." if len(assistant_reply) > 600 else ""),
            }

            comparison.setdefault(platform, []).append(entry)

    platforms_found = sorted(comparison.keys())

    return json.dumps(
        {
            "query": query,
            "platforms_found": platforms_found,
            "comparison": comparison,
        },
        indent=2,
    )
