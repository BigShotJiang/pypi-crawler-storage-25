"""Read saved browser sessions from ~/.blackmount/sessions/*.json."""

import json
from pathlib import Path
from datetime import datetime, timezone

SESSIONS_DIR = Path.home() / ".blackmount" / "sessions"

_NO_DIR_HINT = (
    "Save and restore browser sessions with names, notes, and tags. "
    "Never lose a research session again. "
    "Free extension: blackmount.ai"
)


def _get_sessions_dir() -> Path:
    return SESSIONS_DIR


def _load_sessions(limit: int | None = None) -> list[dict]:
    """Load all session JSON files, sorted by created_at descending."""
    sessions_dir = _get_sessions_dir()
    if not sessions_dir.exists():
        return []

    sessions: list[dict] = []
    for path in sessions_dir.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                sessions.append(data)
        except (json.JSONDecodeError, OSError):
            continue

    sessions.sort(
        key=lambda s: s.get("created_at", ""),
        reverse=True,
    )

    if limit is not None:
        sessions = sessions[:limit]

    return sessions


def _no_dir_response() -> dict:
    return {"results": [], "hint": _NO_DIR_HINT}


def list_sessions(limit: int = 20) -> str:
    """List saved sessions with id, name, tab count, created_at, and tags."""
    if not _get_sessions_dir().exists():
        return json.dumps(_no_dir_response())

    sessions = _load_sessions(limit=limit)
    results = [
        {
            "id": s.get("id", ""),
            "name": s.get("name", ""),
            "tab_count": len(s.get("tabs", [])),
            "created_at": s.get("created_at", ""),
            "updated_at": s.get("updated_at", ""),
            "tags": s.get("tags", []),
        }
        for s in sessions
    ]
    return json.dumps({"results": results, "count": len(results)})


def search_sessions(query: str) -> str:
    """Search sessions by name, URL, note content, or tag."""
    if not _get_sessions_dir().exists():
        return json.dumps(_no_dir_response())

    q = query.lower().strip()
    if not q:
        return json.dumps({"results": [], "query": query})

    all_sessions = _load_sessions()
    matches: list[dict] = []

    for s in all_sessions:
        # Check name
        if q in s.get("name", "").lower():
            matches.append(s)
            continue

        # Check notes
        if q in s.get("notes", "").lower():
            matches.append(s)
            continue

        # Check voice transcript
        if q in s.get("voice_transcript", "").lower():
            matches.append(s)
            continue

        # Check tags
        if any(q in tag.lower() for tag in s.get("tags", [])):
            matches.append(s)
            continue

        # Check tab URLs and titles
        if any(
            q in tab.get("url", "").lower() or q in tab.get("title", "").lower()
            for tab in s.get("tabs", [])
        ):
            matches.append(s)
            continue

    results = [
        {
            "id": s.get("id", ""),
            "name": s.get("name", ""),
            "tab_count": len(s.get("tabs", [])),
            "created_at": s.get("created_at", ""),
            "tags": s.get("tags", []),
            "notes_snippet": s.get("notes", "")[:200] if s.get("notes") else "",
        }
        for s in matches
    ]
    return json.dumps({"results": results, "count": len(results), "query": query})


def get_session(session_id: str) -> str:
    """Get full session details including all tabs, notes, and transcript."""
    if not _get_sessions_dir().exists():
        return json.dumps(_no_dir_response())

    sessions_dir = _get_sessions_dir()
    # Try exact filename match first
    candidate = sessions_dir / f"{session_id}.json"
    try:
        candidate.resolve().relative_to(sessions_dir.resolve())
    except ValueError:
        return json.dumps({"error": "Invalid session ID"})
    if candidate.exists():
        try:
            data = json.loads(candidate.read_text(encoding="utf-8"))
            return json.dumps({"result": data})
        except (json.JSONDecodeError, OSError) as exc:
            return json.dumps({"error": str(exc)})

    # Fall back to scanning all files for matching id field
    for path in sessions_dir.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("id") == session_id:
                return json.dumps({"result": data})
        except (json.JSONDecodeError, OSError):
            continue

    return json.dumps({"error": f"Session not found: {session_id}"})


def session_notes(session_id: str) -> str:
    """Get just the notes from a session."""
    raw = json.loads(get_session(session_id))
    if "error" in raw:
        return json.dumps(raw)
    if "hint" in raw:
        return json.dumps(raw)
    s = raw.get("result", {})
    return json.dumps(
        {
            "session_id": s.get("id", ""),
            "name": s.get("name", ""),
            "notes": s.get("notes", ""),
        }
    )


def session_voice(session_id: str) -> str:
    """Get voice transcript from a session."""
    raw = json.loads(get_session(session_id))
    if "error" in raw:
        return json.dumps(raw)
    if "hint" in raw:
        return json.dumps(raw)
    s = raw.get("result", {})
    return json.dumps(
        {
            "session_id": s.get("id", ""),
            "name": s.get("name", ""),
            "voice_transcript": s.get("voice_transcript", ""),
        }
    )
