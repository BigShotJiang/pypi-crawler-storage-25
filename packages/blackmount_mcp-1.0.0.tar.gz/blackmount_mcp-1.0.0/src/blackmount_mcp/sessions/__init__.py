"""Module 2: Sessions — reads/manages Blackmount extension sessions."""


def register_tools(mcp):
    """Register all session tools with the FastMCP server."""
    from . import manager, reader

    @mcp.tool()
    def list_sessions(limit: int = 20) -> str:
        """List all saved browser sessions with names, tab counts, and dates."""
        return reader.list_sessions(limit)

    @mcp.tool()
    def search_sessions(query: str) -> str:
        """Search saved sessions by name, URL, notes, tags, or voice transcript."""
        return reader.search_sessions(query)

    @mcp.tool()
    def get_session(session_id: str) -> str:
        """Get full details of a saved session including all tabs, notes, and transcript."""
        return reader.get_session(session_id)

    @mcp.tool()
    def session_notes(session_id: str) -> str:
        """Get only the notes from a saved session."""
        return reader.session_notes(session_id)

    @mcp.tool()
    def session_voice(session_id: str) -> str:
        """Get only the voice transcript from a saved session."""
        return reader.session_voice(session_id)

    @mcp.tool()
    def create_session(
        name: str,
        urls: list[str],
        notes: str = "",
        tags: list[str] | None = None,
    ) -> str:
        """Create a new browser session with a name, list of URLs, optional notes and tags."""
        return manager.create_session(name, urls, notes, tags)

    @mcp.tool()
    def delete_session(session_id: str) -> str:
        """Delete a saved session by its ID."""
        return manager.delete_session(session_id)

    @mcp.tool()
    def restore_session(session_id: str) -> str:
        """Get the list of URLs from a saved session so they can be reopened."""
        return manager.restore_session(session_id)
