"""Create, delete, and restore browser sessions in ~/.blackmount/sessions/."""

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .reader import _get_sessions_dir, get_session


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def create_session(
    name: str,
    urls: list[str],
    notes: str = "",
    tags: list[str] | None = None,
) -> str:
    """Create a new session programmatically and save it to disk.

    Returns the created session as a JSON string.
    """
    sessions_dir = _get_sessions_dir()
    try:
        sessions_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return json.dumps({"error": f"Could not create sessions directory: {exc}"})

    session_id = str(uuid.uuid4())
    now = _now_iso()

    tabs = [{"url": url, "title": "", "favicon": ""} for url in urls]

    session: dict = {
        "id": session_id,
        "name": name,
        "created_at": now,
        "updated_at": now,
        "tabs": tabs,
        "notes": notes,
        "voice_transcript": "",
        "tags": tags or [],
        "source": "blackmount-mcp",
    }

    file_path = sessions_dir / f"{session_id}.json"
    try:
        file_path.write_text(json.dumps(session, indent=2), encoding="utf-8")
    except OSError as exc:
        return json.dumps({"error": f"Could not write session file: {exc}"})

    return json.dumps({"result": session, "created": True})


def delete_session(session_id: str) -> str:
    """Delete a session by ID. Returns confirmation JSON."""
    sessions_dir = _get_sessions_dir()
    if not sessions_dir.exists():
        return json.dumps({"error": f"Session not found: {session_id}"})

    # Try exact filename match first
    candidate = sessions_dir / f"{session_id}.json"
    try:
        candidate.resolve().relative_to(sessions_dir.resolve())
    except ValueError:
        return json.dumps({"error": "Invalid session ID"})
    if candidate.exists():
        try:
            candidate.unlink()
            return json.dumps({"deleted": True, "session_id": session_id})
        except OSError as exc:
            return json.dumps({"error": str(exc)})

    # Fall back to scanning for matching id field
    for path in sessions_dir.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("id") == session_id:
                path.unlink()
                return json.dumps({"deleted": True, "session_id": session_id})
        except (json.JSONDecodeError, OSError):
            continue

    return json.dumps({"error": f"Session not found: {session_id}"})


def restore_session(session_id: str) -> str:
    """Return the list of URLs from a session so the client/AI can open them."""
    raw = json.loads(get_session(session_id))

    if "error" in raw:
        return json.dumps(raw)
    if "hint" in raw:
        return json.dumps(raw)

    s = raw.get("result", {})
    urls = [tab.get("url", "") for tab in s.get("tabs", []) if tab.get("url")]

    return json.dumps(
        {
            "session_id": s.get("id", ""),
            "name": s.get("name", ""),
            "urls": urls,
            "tab_count": len(urls),
        }
    )
