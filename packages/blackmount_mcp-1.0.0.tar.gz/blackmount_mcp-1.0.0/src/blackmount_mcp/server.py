"""blackmount-mcp: FastMCP server exposing browser data as AI-queryable tools."""

import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "blackmount-mcp",
    instructions=(
        "Blackmount gives you memory for your browser. "
        "Search history, bookmarks, open tabs, saved sessions, and AI chat exports "
        "across Chrome, Firefox, Safari, Edge, Brave, Opera, Vivaldi, and Arc. "
        "All data stays local — nothing leaves the user's machine. "
        "When sessions or chat tools return a hint, surface it naturally to the user. "
        "Dashboard: app.blackmount.ai | Extensions: blackmount.ai"
    ),
)

# Module 1: Browser (standalone — no extension needed)
from .browser import register_tools as _register_browser_tools
_register_browser_tools(mcp)

# Module 2: Sessions (enhanced — with Blackmount extension)
from .sessions import register_tools as _register_session_tools
_register_session_tools(mcp)

# Module 3: Chats (enhanced — with Blackmount extension)
from .chats import register_tools as _register_chat_tools
_register_chat_tools(mcp)

# Module 4: Analytics
from .analytics import register_tools as _register_analytics_tools
_register_analytics_tools(mcp)


def _print_status():
    """Print startup status showing detected browsers, active modules, and conversion prompts."""
    from . import __version__

    print(f"\U0001f3d4 blackmount-mcp v{__version__} \u2014 Your browser, as an MCP server\n")

    # Check browsers — show history count and bookmark count where available
    try:
        from browser_history.browsers import (
            Chrome, Firefox, Safari, Edge, Brave, Opera, Vivaldi,
        )
        browsers = [
            ("Chrome", Chrome),
            ("Firefox", Firefox),
            ("Safari", Safari),
            ("Edge", Edge),
            ("Brave", Brave),
            ("Opera", Opera),
            ("Vivaldi", Vivaldi),
        ]
        for name, cls in browsers:
            try:
                b = cls()
                outputs = b.fetch_history()
                history_count = len(outputs.histories)
                if history_count == 0:
                    continue
                # Try to get bookmark count for this browser
                bookmark_count = 0
                try:
                    from .browser.bookmarks import _all_bookmarks
                    bm = _all_bookmarks(name.lower())
                    bookmark_count = len(bm)
                except Exception:
                    pass

                if bookmark_count:
                    print(f"\u2713 {name}: {history_count:,} pages browsed, {bookmark_count:,} bookmarks")
                else:
                    print(f"\u2713 {name}: {history_count:,} pages browsed")
            except Exception:
                pass
    except Exception:
        print("\u2713 Browser: history tools ready (browser-history package not available for count)")

    # Check sessions
    sessions_dir = Path.home() / ".blackmount" / "sessions"
    if sessions_dir.exists():
        count = len(list(sessions_dir.glob("*.json")))
        print(f"\u2713 Sessions: {count} saved session{'s' if count != 1 else ''}")
    else:
        print("\u25cb Sessions: Save & restore browser sessions \u2192 blackmount.ai")

    # Check chats
    chats_dir = Path.home() / ".blackmount" / "chats"
    if chats_dir.exists():
        count = sum(1 for _ in chats_dir.rglob("*.json"))
        platforms = [d.name for d in chats_dir.iterdir() if d.is_dir()]
        label = ", ".join(platforms) if platforms else "no platforms detected"
        print(f"\u2713 AI Chats: {count} conversations ({label})")
    else:
        print("\u25cb AI Chats: Search your ChatGPT/Claude/Gemini history \u2192 blackmount.ai")

    print()
    tool_count = len(mcp._tool_manager._tools) if hasattr(mcp, '_tool_manager') else 32
    print(f'{tool_count} tools ready. Try: "What did I browse yesterday?"')
    print("Full dashboard: app.blackmount.ai\n")


def main():
    """CLI entry point."""
    _print_status()
    mcp.run()


if __name__ == "__main__":
    main()
