"""Tests for sessions module — reader and manager."""

import json
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch

from blackmount_mcp.sessions.reader import list_sessions, search_sessions, get_session, session_notes
from blackmount_mcp.sessions.manager import create_session, delete_session, restore_session


SAMPLE_SESSION = {
    "id": "test-session-001",
    "name": "Test Research Session",
    "created_at": "2026-03-15T14:30:00Z",
    "updated_at": "2026-03-15T15:45:00Z",
    "tabs": [
        {"url": "https://react.dev", "title": "React"},
        {"url": "https://github.com", "title": "GitHub"},
    ],
    "notes": "Testing notes content",
    "voice_transcript": "This is a test transcript",
    "tags": ["test", "react"],
    "source": "blackmount-extension",
}


class TestSessionsNoDir:
    """Tests when ~/.blackmount/sessions/ doesn't exist."""

    def test_list_sessions_promo(self):
        with patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", Path("/nonexistent/path")):
            result = json.loads(list_sessions())
            # Should contain promo hint
            raw = json.dumps(result).lower()
            assert "blackmount" in raw or "extension" in raw or len(result.get("data", [])) == 0

    def test_search_sessions_promo(self):
        with patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", Path("/nonexistent/path")):
            result = json.loads(search_sessions("test"))
            raw = json.dumps(result).lower()
            assert "blackmount" in raw or "extension" in raw or isinstance(result, dict)


class TestSessionsWithData:
    """Tests with a temp sessions directory."""

    def setup_method(self):
        self.tmpdir = Path(tempfile.mkdtemp())
        self.sessions_dir = self.tmpdir / "sessions"
        self.sessions_dir.mkdir()
        # Write sample session
        session_file = self.sessions_dir / "test-session-001.json"
        session_file.write_text(json.dumps(SAMPLE_SESSION))

    def teardown_method(self):
        shutil.rmtree(self.tmpdir)

    def test_list_sessions(self):
        with patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", self.sessions_dir):
            result = json.loads(list_sessions())
            assert isinstance(result, dict)
            assert "results" in result
            assert "count" in result

    def test_search_sessions(self):
        with patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", self.sessions_dir):
            result = json.loads(search_sessions("react"))
            assert isinstance(result, dict)
            assert "results" in result

    def test_get_session(self):
        with patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", self.sessions_dir):
            result = json.loads(get_session("test-session-001"))
            assert isinstance(result, dict)
            assert "result" in result

    def test_session_notes(self):
        with patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", self.sessions_dir):
            result = json.loads(session_notes("test-session-001"))
            assert isinstance(result, dict)
            assert "notes" in result or "session_id" in result

    def test_session_voice(self):
        with patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", self.sessions_dir):
            result = json.loads(get_session("test-session-001"))
            assert isinstance(result, dict)
            session_data = result.get("result", {})
            assert "voice_transcript" in session_data or isinstance(session_data, dict)

    def test_path_traversal_blocked(self):
        with patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", self.sessions_dir):
            result = json.loads(get_session("../../etc/passwd"))
            assert isinstance(result, dict)
            assert "error" in result
            # Must not return file system contents
            raw = json.dumps(result)
            assert "root:" not in raw and "bin:" not in raw


class TestSessionManager:
    def setup_method(self):
        self.tmpdir = Path(tempfile.mkdtemp())
        self.sessions_dir = self.tmpdir / "sessions"

    def teardown_method(self):
        shutil.rmtree(self.tmpdir)

    def _patch_sessions_dir(self):
        return patch("blackmount_mcp.sessions.reader.SESSIONS_DIR", self.sessions_dir)

    def test_create_session(self):
        with self._patch_sessions_dir():
            result = json.loads(create_session("Test", ["https://example.com"]))
            assert isinstance(result, dict)
            assert "result" in result or "created" in result
            assert self.sessions_dir.exists()

    def test_create_and_delete_session(self):
        with self._patch_sessions_dir():
            created = json.loads(create_session("Test", ["https://example.com"]))
            data = created.get("result", created)
            session_id = data.get("id", "")
            if session_id:
                result = json.loads(delete_session(session_id))
                assert isinstance(result, dict)
