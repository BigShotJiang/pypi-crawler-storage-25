"""Tests for chats module — reader, search, extract."""

import json
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch

from blackmount_mcp.chats.reader import list_chats, read_chat, chat_stats
from blackmount_mcp.chats.search import search_chats, extract_prompts, compare_responses
from blackmount_mcp.chats.extract import extract_code, export_chat


SAMPLE_CHAT = {
    "id": "chat-test-001",
    "platform": "chatgpt",
    "title": "Debug React hydration error",
    "model": "gpt-4o",
    "created_at": "2026-03-10T09:00:00Z",
    "updated_at": "2026-03-10T09:45:00Z",
    "messages": [
        {"role": "user", "content": "I'm getting a hydration error in React", "timestamp": "2026-03-10T09:00:00Z"},
        {"role": "assistant", "content": "This is caused by SSR mismatch. Here's a fix:\n```python\nprint('hello')\n```", "timestamp": "2026-03-10T09:00:15Z"},
    ],
    "tags": ["react", "debugging"],
    "source": "blackmount-exporter",
}

# Extension format uses chatId (not id) and capturedAt (ms, not ISO)
SAMPLE_CHAT_EXTENSION = {
    "chatId": "ext-chat-002",
    "platform": "claude",
    "title": "Fix CORS error in Next.js",
    "model": "claude-opus-4",
    "url": "https://claude.ai/chat/ext-chat-002",
    "messages": [
        {"role": "user", "content": "I'm getting CORS errors in my Next.js API route"},
        {"role": "assistant", "content": "Add the appropriate CORS headers:\n```typescript\nres.setHeader('Access-Control-Allow-Origin', '*');\n```"},
    ],
    "messageCount": 2,
    "capturedAt": 1775692800000,
    "device": "macbook",
    "browser": "chrome",
}


class TestChatsNoDir:
    def test_list_chats_promo(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", Path("/nonexistent/path")):
            result = json.loads(list_chats())
            raw = json.dumps(result).lower()
            assert "blackmount" in raw or "exporter" in raw or isinstance(result, dict)

    def test_chat_stats_promo(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", Path("/nonexistent/path")):
            result = json.loads(chat_stats())
            assert isinstance(result, dict)


class TestChatsWithData:
    def setup_method(self):
        self.tmpdir = Path(tempfile.mkdtemp())
        self.chats_dir = self.tmpdir / "chats"
        chatgpt_dir = self.chats_dir / "chatgpt"
        chatgpt_dir.mkdir(parents=True)
        (chatgpt_dir / "chat-test-001.json").write_text(json.dumps(SAMPLE_CHAT))
        # Also add extension-format chat
        claude_dir = self.chats_dir / "claude"
        claude_dir.mkdir(parents=True)
        (claude_dir / "ext-chat-002.json").write_text(json.dumps(SAMPLE_CHAT_EXTENSION))

    def teardown_method(self):
        shutil.rmtree(self.tmpdir)

    def test_list_chats(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            result = json.loads(list_chats())
            assert isinstance(result, dict)
            assert "chats" in result

    def test_read_chat(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            result = json.loads(read_chat("chat-test-001"))
            assert isinstance(result, dict)

    def test_chat_stats(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            result = json.loads(chat_stats())
            assert isinstance(result, dict)
            # Should have at least one stats-like numeric or summary key
            stats_keys = {"total_chats", "total_messages", "platforms", "models", "count"}
            assert any(k in result for k in stats_keys)

    def test_search_chats(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            with patch("blackmount_mcp.chats.search.CHATS_DIR", self.chats_dir):
                result = json.loads(search_chats("hydration"))
                assert isinstance(result, dict)
                assert "results" in result or "matches" in result or "chats" in result

    def test_extract_prompts(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            with patch("blackmount_mcp.chats.search.CHATS_DIR", self.chats_dir):
                result = json.loads(extract_prompts("react"))
                assert isinstance(result, dict)

    def test_extract_code(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            with patch("blackmount_mcp.chats.extract.CHATS_DIR", self.chats_dir):
                result = json.loads(extract_code("python"))
                assert isinstance(result, dict)
                assert "results" in result or "blocks" in result or "code_blocks" in result

    def test_export_chat_markdown(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            with patch("blackmount_mcp.chats.extract.CHATS_DIR", self.chats_dir):
                result = json.loads(export_chat("chat-test-001", "markdown"))
                assert isinstance(result, dict)

    def test_compare_responses(self):
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            with patch("blackmount_mcp.chats.search.CHATS_DIR", self.chats_dir):
                result = json.loads(compare_responses("hydration"))
                assert isinstance(result, dict)
                # Should return comparisons or an appropriate message
                raw = json.dumps(result)
                assert len(raw) > 2

    def test_extension_format_chatId_normalized(self):
        """Extension uses chatId instead of id — verify normalization."""
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            result = json.loads(read_chat("ext-chat-002"))
            assert isinstance(result, dict)
            assert "error" not in result
            assert result.get("id") == "ext-chat-002" or result.get("chatId") == "ext-chat-002"

    def test_extension_format_capturedAt_normalized(self):
        """Extension uses capturedAt (ms) instead of created_at (ISO) — verify normalization."""
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            result = json.loads(list_chats(platform="claude"))
            assert isinstance(result, dict)
            chats = result.get("chats", [])
            assert len(chats) >= 1
            chat = chats[0]
            # created_at should be populated from capturedAt
            assert chat.get("created_at") != ""

    def test_extension_format_listed_alongside_exporter(self):
        """Both exporter and extension chats show in list_chats(all)."""
        with patch("blackmount_mcp.chats.reader.CHATS_DIR", self.chats_dir):
            result = json.loads(list_chats(platform="all", days=365))
            chats = result.get("chats", [])
            ids = [c.get("id", "") for c in chats]
            assert "chat-test-001" in ids
            assert "ext-chat-002" in ids
