"""Tests for browser module — history, bookmarks, tabs, downloads."""

import json

from blackmount_mcp.browser.history import search_history, list_history, most_visited, find_page
from blackmount_mcp.browser.bookmarks import search_bookmarks, list_bookmarks
from blackmount_mcp.browser.tabs import get_open_tabs, find_tab
from blackmount_mcp.browser.downloads import list_downloads


class TestHistory:
    def test_search_history_returns_json(self):
        result = search_history("google")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed
        assert isinstance(parsed["count"], int)
        assert parsed["query"] == "google"

    def test_list_history_returns_json(self):
        result = list_history(days=1, limit=10)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed
        assert isinstance(parsed["count"], int)
        assert parsed["browser"] == "all"

    def test_most_visited_returns_json(self):
        result = most_visited(days=7, limit=5)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed

    def test_find_page_returns_json(self):
        result = find_page("test")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed
        assert parsed["query"] == "test"

    def test_search_history_with_browser_filter(self):
        result = search_history("test", days=7, browser="chrome")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert parsed["browser"] == "chrome"


class TestBookmarks:
    def test_search_bookmarks_returns_json(self):
        result = search_bookmarks("test")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed or "error" in parsed

    def test_list_bookmarks_returns_json(self):
        result = list_bookmarks()
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "folders" in parsed or "error" in parsed


class TestTabs:
    def test_get_open_tabs_returns_json(self):
        result = get_open_tabs()
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed
        assert "count" in parsed

    def test_find_tab_returns_json(self):
        result = find_tab("github")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed


class TestDownloads:
    def test_list_downloads_returns_json(self):
        result = list_downloads(days=7)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed
