"""Tests for utils module — categories and formatting."""

import json

from blackmount_mcp.utils.categories import categorize_domain, get_category_stats
from blackmount_mcp.utils.format import format_response, format_error, format_promo, truncate_url


class TestCategorize:
    def test_known_domains(self):
        assert categorize_domain("github.com") == "productivity"
        assert categorize_domain("stackoverflow.com") == "development"
        assert categorize_domain("youtube.com") == "entertainment"
        assert categorize_domain("chat.openai.com") == "ai"
        assert categorize_domain("google.com") in ("search",)
        assert categorize_domain("reddit.com") == "social"
        assert categorize_domain("claude.ai") == "ai"
        assert categorize_domain("wikipedia.org") == "reference"

    def test_www_stripped(self):
        assert categorize_domain("www.github.com") == categorize_domain("github.com")

    def test_unknown_domain(self):
        assert categorize_domain("some-random-site-12345.xyz") == "other"

    def test_category_stats(self):
        domains = ["github.com", "gitlab.com", "youtube.com", "netflix.com"]
        stats = get_category_stats(domains)
        assert isinstance(stats, dict)
        assert stats.get("productivity", 0) >= 2 or stats.get("development", 0) >= 2
        assert stats.get("entertainment", 0) >= 1
        # Verify category names are actual strings present as keys
        assert all(isinstance(k, str) for k in stats.keys())
        category_names = set(stats.keys())
        assert "entertainment" in category_names or len(category_names) > 0


class TestFormat:
    def test_format_response(self):
        result = json.loads(format_response({"key": "value"}))
        assert result["data"]["key"] == "value"

    def test_format_response_with_meta(self):
        result = json.loads(format_response([1, 2], meta={"count": 2}))
        assert result["data"] == [1, 2]
        assert result["meta"]["count"] == 2

    def test_format_error(self):
        result = json.loads(format_error("something broke"))
        assert "error" in result
        assert result["error"] == "something broke"

    def test_format_error_with_hint(self):
        result = json.loads(format_error("fail", hint="try again"))
        assert result["hint"] == "try again"

    def test_format_promo_sessions(self):
        result = json.loads(format_promo("no data", "sessions"))
        assert "blackmount" in result.get("promo", "").lower() or "extension" in json.dumps(result).lower()

    def test_format_promo_chats(self):
        result = json.loads(format_promo("no data", "chats"))
        body = json.dumps(result).lower()
        assert "extension" in body and "blackmount" in body

    def test_truncate_url_short(self):
        url = "https://example.com"
        assert truncate_url(url) == url

    def test_truncate_url_long(self):
        url = "https://example.com/" + "a" * 200
        result = truncate_url(url, max_length=50)
        assert len(result) <= 50
        assert result.endswith("...")
