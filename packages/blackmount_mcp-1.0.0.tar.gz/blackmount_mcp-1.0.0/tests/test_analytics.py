"""Tests for analytics module — digest, domains, patterns."""

import json

from blackmount_mcp.analytics.digest import browsing_summary, daily_digest, productivity_report
from blackmount_mcp.analytics.domains import domain_time, distraction_score, research_topics
from blackmount_mcp.analytics.patterns import most_visited, browsing_patterns


class TestDigest:
    def test_browsing_summary_returns_json(self):
        result = browsing_summary("today")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "date" in parsed
        assert "total_visits" in parsed

    def test_daily_digest_returns_json(self):
        result = daily_digest("today")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "date" in parsed

    def test_productivity_report_returns_json(self):
        result = productivity_report(7)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "days" in parsed
        assert "productivity_score" in parsed or "total_visits" in parsed

    def test_browsing_summary_yesterday(self):
        result = browsing_summary("yesterday")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)

    def test_browsing_summary_bad_date(self):
        result = browsing_summary("not-a-date")
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "error" in parsed


class TestDomains:
    def test_domain_time_returns_json(self):
        result = domain_time(days=7)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "days" in parsed

    def test_distraction_score_returns_json(self):
        result = distraction_score(days=7)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "distraction_score" in parsed

    def test_research_topics_returns_json(self):
        result = research_topics(days=7)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)


class TestPatterns:
    def test_most_visited_returns_json(self):
        result = most_visited(days=7, limit=5)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "results" in parsed

    def test_browsing_patterns_returns_json(self):
        result = browsing_patterns(days=7)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert "total_visits" in parsed
