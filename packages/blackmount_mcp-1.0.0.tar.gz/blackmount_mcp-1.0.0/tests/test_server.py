"""Tests for server — import, tool registration, status."""

import json


class TestServerImport:
    def test_server_imports(self):
        from blackmount_mcp.server import mcp
        assert mcp is not None

    def test_tool_count(self):
        from blackmount_mcp.server import mcp
        tools = mcp._tool_manager._tools
        assert len(tools) == 32

    def test_main_exists(self):
        from blackmount_mcp.server import main
        assert callable(main)

    def test_version(self):
        from blackmount_mcp import __version__
        assert __version__ == "1.0.0"
