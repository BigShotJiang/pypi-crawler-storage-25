#!/usr/bin/env python3
"""Quick test script for blackmount-mcp.

Run: python examples/quickstart.py
"""

import json


def main():
    print("blackmount-mcp Quick Test")
    print("=" * 40)

    # 1. Server status
    from blackmount_mcp.server import mcp

    tool_count = len(mcp._tool_manager._tools)
    print(f"\nTools registered: {tool_count}")

    # 2. Browser history
    from blackmount_mcp.browser.history import list_history

    history = json.loads(list_history(days=1, limit=5))
    print(f"\nToday's browsing: {history['count']} entries")
    for entry in history["results"][:3]:
        print(f"  {entry['title'][:50]}")

    # 3. Open tabs
    from blackmount_mcp.browser.tabs import get_open_tabs

    tabs = json.loads(get_open_tabs())
    print(f"\nOpen tabs: {tabs['count']}")

    # 4. Bookmarks
    from blackmount_mcp.browser.bookmarks import search_bookmarks

    bookmarks = json.loads(search_bookmarks("python"))
    print(f"\nBookmarks matching 'python': {bookmarks['count']}")

    # 5. Productivity
    from blackmount_mcp.analytics.digest import productivity_report

    report = json.loads(productivity_report(days=7))
    score = report.get("productivity_score", "N/A")
    print(f"\n7-day productivity score: {score}/100")

    print("\nAll systems go!")


if __name__ == "__main__":
    main()
