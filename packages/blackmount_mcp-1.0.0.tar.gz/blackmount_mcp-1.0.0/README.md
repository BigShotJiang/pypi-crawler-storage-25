# blackmount-mcp

[![PyPI](https://img.shields.io/pypi/v/blackmount-mcp)](https://pypi.org/project/blackmount-mcp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://python.org)

Your AI assistant is blind to your browsing life. Claude doesn't know what you researched yesterday, what tabs you have open, or what articles you bookmarked. **blackmount-mcp fixes that.**

Connect your browser history, bookmarks, open tabs, saved sessions, and AI chat exports directly to Claude, Cursor, or any MCP client — all from your local machine.

## Quick Start

```bash
pip install blackmount-mcp
```

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "blackmount": {
      "command": "blackmount-mcp"
    }
  }
}
```

Restart Claude Desktop. Done.

## What can you ask?

Once connected, try these in Claude:

- *"What was that article about React Server Components I read last Tuesday?"*
- *"How much time did I spend on Reddit vs GitHub this week?"*
- *"Find all the ML papers I bookmarked"*
- *"What tabs do I have open right now?"*
- *"Summarize what I researched yesterday"*
- *"Find that pricing page I visited for Vercel — I need to compare it"*
- *"What did I download from arxiv in the last month?"*
- *"Show me everything I've browsed about LLM fine-tuning"*
- *"When do I browse the most — mornings or evenings?"*
- *"Find that GitHub PR tab I have open somewhere"*

## Tool Catalog

### Browser (works standalone — no extensions needed)

| Tool | Description | Example Prompt |
|------|-------------|----------------|
| `search_history` | Search browsing history by keyword | *"Find that React article I read last week"* |
| `list_history` | Recent browsing history | *"What sites did I visit today?"* |
| `find_page` | Natural language page search | *"That TypeScript tutorial I read"* |
| `search_bookmarks` | Search bookmarks by title/URL | *"Find my saved Python tutorials"* |
| `list_bookmarks` | Browse bookmark folders | *"What's in my Work bookmarks folder?"* |
| `get_open_tabs` | List currently open tabs | *"What tabs do I have open?"* |
| `find_tab` | Find a specific open tab | *"Find that GitHub PR tab"* |
| `list_downloads` | Recent file downloads | *"What did I download this week?"* |

### Sessions (with [Blackmount extension](https://blackmount.ai))

| Tool | Description | Example Prompt |
|------|-------------|----------------|
| `list_sessions` | Saved browser sessions | *"Show my saved sessions"* |
| `search_sessions` | Search by name, URL, notes | *"Find my React research session"* |
| `get_session` | Full session with tabs & notes | *"Open session 'API Design Research'"* |
| `restore_session` | Get URLs to reopen a session | *"Restore yesterday's debug session"* |
| `session_notes` | Notes attached to a session | *"What notes did I take in that session?"* |
| `session_voice` | Voice transcript from a session | *"Read back my voice notes"* |
| `create_session` | Save a session programmatically | *"Save these URLs as a session"* |
| `delete_session` | Remove a session | *"Delete that old session"* |

### AI Chats (with [Blackmount extension](https://blackmount.ai))

| Tool | Description | Example Prompt |
|------|-------------|----------------|
| `search_ai_chats` | Search across all AI conversations | *"Find my chats about Docker"* |
| `list_ai_chats` | List conversations by platform | *"Show my recent Claude conversations"* |
| `read_ai_chat` | Read full AI conversation | *"Show that ChatGPT thread"* |
| `extract_ai_code` | Extract code blocks by language | *"Get all Python code from my chats"* |
| `find_ai_prompts` | Find your best prompts | *"Find prompts I used about testing"* |
| `ai_chat_stats` | Usage stats across platforms | *"How much do I use each AI?"* |
| `compare_ai_responses` | Compare answers across AIs | *"Same question on ChatGPT vs Claude?"* |
| `export_ai_chat` | Export as markdown or JSON | *"Export that conversation"* |

### Analytics

| Tool | Description | Example Prompt |
|------|-------------|----------------|
| `browsing_summary` | Daily browsing summary | *"Summarize my browsing today"* |
| `daily_digest` | Full daily digest (browsing + AI) | *"What did I do online yesterday?"* |
| `productivity_report` | Weekly productivity summary | *"How productive was I this week?"* |
| `domain_time` | Time spent per domain | *"Where do I spend my time online?"* |
| `distraction_score` | Focus vs distraction ratio | *"Am I getting distracted?"* |
| `most_visited` | Top domains by visits | *"My most visited sites this month"* |
| `research_topics` | Clustered research topics | *"What have I been researching?"* |
| `browsing_patterns` | Peak hours, trends | *"When do I browse the most?"* |

## Unlock More Power

**The 8 standalone browser tools work immediately after install.** The remaining 24 tools unlock with the free Blackmount extension:

- **Save sessions + search AI chats** → [Install Blackmount extension](https://blackmount.ai) — save browser sessions with notes and voice, auto-capture ChatGPT/Claude/Gemini conversations locally.
- **Full dashboard with analytics** → [app.blackmount.ai](https://app.blackmount.ai) — visual browsing analytics, session management, and more.

All data stays on your machine. Nothing leaves your disk unless you choose to share it.

## Claude Desktop Config

```json
{
  "mcpServers": {
    "blackmount": {
      "command": "blackmount-mcp"
    }
  }
}
```

Config file locations:
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

## Supported Browsers

Chrome, Firefox, Safari, Edge, Brave, Opera, Vivaldi, and Arc.

## Privacy

- All data is read locally from your machine
- No network requests, no telemetry, no cloud
- Open source (MIT) — audit the code yourself
- Session and chat files are standard JSON on disk

## Development

```bash
git clone https://github.com/BlackMount-ai/blackmount-mcp.git
cd blackmount-mcp
pip install -e .
pytest tests/ -v
blackmount-mcp
```

## Contributing

Pull requests welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) if it exists, or open an issue to discuss.

## Links

- [blackmount.ai](https://blackmount.ai) — Home + browser extension
- [app.blackmount.ai](https://app.blackmount.ai) — Full dashboard
- [PyPI](https://pypi.org/project/blackmount-mcp/) — Package

## License

MIT
