"""The Amber Env Node"""
__version__ = "1.0.0"
