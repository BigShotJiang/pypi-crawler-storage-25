-- RDST Key Service - initial schema.
--
-- All statements are IF NOT EXISTS / OR IGNORE so this migration is a no-op
-- against the staging/prod databases that already have the schema
-- applied. New databases (e.g. per-CL preview DBs) will run it cleanly.
--
-- Wrangler tracks applied migrations in a `d1_migrations` table inside D1
-- itself; subsequent migrations should land as 0002_*.sql, 0003_*.sql, etc.

CREATE TABLE IF NOT EXISTS users (
    email TEXT PRIMARY KEY,
    token TEXT UNIQUE NOT NULL,           -- single auth credential. Accepted at
                                          -- /anthropic (Authorization header)
                                          -- AND /send-report (body field).
    verification_token TEXT,
    verified INTEGER DEFAULT 0,
    usage_cents INTEGER DEFAULT 0,
    limit_cents INTEGER DEFAULT 500,
    created_at TEXT NOT NULL,
    verified_at TEXT,
    last_used_at TEXT,
    ip_address TEXT,
    status TEXT DEFAULT 'pending',        -- pending | active | exhausted | reports_only
    email_tier TEXT DEFAULT 'business'    -- personal ($1.50) | business ($5.00)
);

CREATE INDEX IF NOT EXISTS idx_users_token ON users(token);

CREATE TABLE IF NOT EXISTS usage_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    model TEXT,
    input_tokens INTEGER,
    output_tokens INTEGER,
    cost_cents REAL,
    created_at TEXT NOT NULL,
    ip_address TEXT
);

CREATE INDEX IF NOT EXISTS idx_usage_email ON usage_log(email);
CREATE INDEX IF NOT EXISTS idx_usage_ip_created ON usage_log(ip_address, created_at);

CREATE TABLE IF NOT EXISTS registration_attempts (
    ip_address TEXT NOT NULL,
    attempted_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reg_ip ON registration_attempts(ip_address);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS report_sends (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    sent_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_report_sends_email_time ON report_sends(email, sent_at);

-- Hosted shareable reports — opaque-UUID URLs returned in emails so
-- recipients can view full-fidelity HTML in a browser. 30-day default TTL,
-- opportunistically cleaned up at view time.
CREATE TABLE IF NOT EXISTS hosted_reports (
    id              TEXT PRIMARY KEY,           -- random UUIDv4
    report_token    TEXT NOT NULL,              -- creator's verified token (for audit)
    email           TEXT NOT NULL,              -- recipient
    subject         TEXT NOT NULL,
    html            TEXT NOT NULL,              -- the report body
    size_bytes      INTEGER NOT NULL,
    created_at      TEXT NOT NULL,              -- ISO8601
    expires_at      TEXT NOT NULL,              -- ISO8601
    view_count      INTEGER DEFAULT 0,
    last_viewed_at  TEXT,
    password_hash   TEXT
);
CREATE INDEX IF NOT EXISTS idx_hosted_reports_expires ON hosted_reports(expires_at);
CREATE INDEX IF NOT EXISTS idx_hosted_reports_token ON hosted_reports(report_token);

-- Queued report payloads keyed to a verification_token. Used when the CLI
-- POSTs HTML at /register-report time so the report can be sent server-side
-- the moment the user clicks the verify link — without the CLI having to
-- stay alive and poll. Rows are deleted immediately on send. Stale rows
-- (verification never clicked) are cleaned up after 24h.
CREATE TABLE IF NOT EXISTS pending_reports (
    verification_token  TEXT PRIMARY KEY,
    email               TEXT NOT NULL,
    subject             TEXT NOT NULL,
    html                TEXT NOT NULL,
    summary_json        TEXT,
    mode                TEXT NOT NULL DEFAULT 'link',
    ttl_days            INTEGER NOT NULL DEFAULT 30,
    created_at          TEXT NOT NULL,             -- ISO8601
    expires_at          TEXT NOT NULL              -- ISO8601 (24h from creation)
);
CREATE INDEX IF NOT EXISTS idx_pending_reports_expires ON pending_reports(expires_at);
CREATE INDEX IF NOT EXISTS idx_pending_reports_email ON pending_reports(email);

-- Default: 100 trial user slots
INSERT OR IGNORE INTO settings (key, value) VALUES ('max_trial_users', '100');
