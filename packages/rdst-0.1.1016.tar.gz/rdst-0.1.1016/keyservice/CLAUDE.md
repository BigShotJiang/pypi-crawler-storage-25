# RDST Keyservice — Working Notes

Trial credit proxy for RDST. Cloudflare Worker (Python via Pyodide) +
D1 (SQLite). Code lives in `src/index.py`; full architecture is in
`README.md`.

## Before you touch this service

**Spin up your own dev env.** Per-CL preview Workers cover automated
review; for interactive iteration each developer runs their own
personal env keyed off their handle:

```bash
cd rdst/keyservice
./scripts/deploy-dev-env.sh <yourhandle>
# follow the printed `export RDST_KEYSERVICE_URL=...` lines
```

The script provisions a Worker + D1 named `rdst-keyservice-<yourhandle>`,
pulls secrets from the shared non-prod bundle at AWS-SM
`rdst/keyservice/dev01` (the same blob preview deploys read — the
"dev01" name is a historical AWS-SM identifier; the Worker env was
retired), and prints the env vars to point your local RDST CLI at it.
Re-running is idempotent — same Worker name, same D1, migrations
no-op once applied. See README § "Personal dev environments" for
details.

## Runtime / deploy facts

- Wrangler-managed migrations live under `migrations/`. New schema =
  add `0002_<name>.sql`; CI auto-applies on every deploy.
- AWS Secrets Manager (`rdst/keyservice/<env>`, account `305232526136`,
  `us-east-2`) is the source of truth for runtime secrets. CI re-pushes
  to the Worker on every deploy via `wrangler secret bulk`. The
  `rdst/keyservice/dev01` blob is kept as the shared non-prod bundle
  (preview + personal envs) even though the dev01 Worker env was
  retired.
- Prod's `ATTESTATION_SECRET` MUST equal `_DEFAULT_CLIENT_ATTESTATION`
  in `shared/llm_manager/key_resolution.py`. Other envs can rotate.
- HMAC sig is the **first 32 hex chars** of `HMAC-SHA256(timestamp.token,
  ATTESTATION_SECRET)`, not the full 64. Header format: `<ts>.<32hex>`.

## Buildkite triggering

Changes under `rdst/keyservice/*` route through the
`generate_monorepo_pipeline.sh` dispatcher's `rdst/*` match to the
`readyset-rdst` pipeline. Keyservice deploy steps live in
`rdst/.buildkite/pipeline.yml` (preview pre-merge, staging post-merge,
prod off the `release-approval` gate); there is no separate
`readyset-keyservice` pipeline.

The pipeline is dynamically generated: the static `pipeline.yml` only
runs `rdst/.buildkite/detect_pipeline_areas.sh`, which inspects the
git diff and emits step YAML for the surfaces this build touches
(keyservice, python, or both) before piping to `buildkite-agent
pipeline upload`. Buildkite's `if:` expression language doesn't
support build meta-data, so gating happens at upload time, not at
step-evaluation time. Falls open (emits everything) on shallow
checkouts where `HEAD~1` is missing.
