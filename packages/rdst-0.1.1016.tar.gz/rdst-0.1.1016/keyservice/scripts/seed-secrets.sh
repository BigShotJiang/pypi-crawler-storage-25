#!/usr/bin/env bash
# Seed runtime secrets for the RDST keyservice.
#
# AWS Secrets Manager is the source of truth — CI fetches the JSON blob
# at rdst/keyservice/<env> on every deploy and re-pushes it to the
# Cloudflare Worker via `wrangler secret bulk` (mirrors the web-apps
# cloud pipeline). This script writes BOTH places at once so:
#   1. AWS-SM has the canonical copy CI will read on the next deploy
#   2. The Worker is updated immediately without waiting for a deploy
#
# Use this for the initial bootstrap of a new env and for rotations.
#
# Secrets seeded (per env):
#   ANTHROPIC_API_KEY    — company Anthropic key (swapped in for trial tokens)
#   RESEND_API_KEY       — Resend API key for verification emails
#   ATTESTATION_SECRET   — HMAC secret for X-RDST-Signature attestation;
#                          prod's value MUST match the CLIENT_ATTESTATION
#                          constant baked into shipped CLIs in the wild
#                          (see shared/llm_manager/key_resolution.py)
#   ADMIN_SECRET         — bearer token for admin endpoints
#
# By default the same value is pushed to every env (dev01, staging, prod).
# Per the project setup ATTESTATION_SECRET and ADMIN_SECRET should be
# generated fresh per env — set <KEY>_<ENV_UPPER> overrides; the script
# prefers the suffixed value when present.
#
# Note on `dev01`: the dev01 Cloudflare Worker env was retired, but the
# AWS-SM bundle at rdst/keyservice/dev01 stays as the shared non-prod
# secrets blob (read by per-CL preview deploys and the personal dev env
# script). For dev01 the script writes only to AWS-SM and skips the
# Wrangler push; staging and prod write to both.
#
# Per-CL preview Workers are NOT seeded here — previews pull the shared
# rdst/keyservice/dev01 blob via deploy-preview.sh on every deploy.
#
# Usage:
#   export ANTHROPIC_API_KEY=sk-ant-...
#   export RESEND_API_KEY=re_...
#   export ADMIN_SECRET=$(openssl rand -hex 32)   # or an existing value
#   ./scripts/seed-secrets.sh                     # all envs
#   ./scripts/seed-secrets.sh --env staging       # one env only
#   ./scripts/seed-secrets.sh --dry-run           # print, don't execute
#   ./scripts/seed-secrets.sh --aws-only          # write AWS-SM only (skip Wrangler)
#   ./scripts/seed-secrets.sh --wrangler-only     # write Wrangler only (skip AWS-SM)
#
# AWS auth: this script uses the caller's default AWS credentials
# (AWS_PROFILE / AWS_REGION or instance role).
# Cloudflare auth: wrangler picks up CLOUDFLARE_API_TOKEN /
# CLOUDFLARE_ACCOUNT_ID from your shell, or `wrangler login` browser auth.
#
# Idempotent: AWS-SM put-secret-value and `wrangler secret put` overwrite
# on each run.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
KEYSERVICE_DIR="$(dirname "$SCRIPT_DIR")"

ALL_ENVS=(dev01 staging prod)
# Subset of envs that have a live Cloudflare Worker — dev01 is AWS-SM-only.
WORKER_ENVS=(staging prod)
KEYS=(ANTHROPIC_API_KEY RESEND_API_KEY ATTESTATION_SECRET ADMIN_SECRET)

ENV_FILTER=""
DRY_RUN=false
WRITE_AWS=true
WRITE_WRANGLER=true

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env) ENV_FILTER="$2"; shift ;;
    --dry-run) DRY_RUN=true ;;
    --aws-only) WRITE_WRANGLER=false ;;
    --wrangler-only) WRITE_AWS=false ;;
    -h|--help) sed -n '2,40p' "$0"; exit 0 ;;
    *) echo "Unknown flag: $1" >&2; exit 2 ;;
  esac
  shift
done

if [[ -n "$ENV_FILTER" ]]; then
  case "$ENV_FILTER" in
    dev01|staging|prod) ENVS=("$ENV_FILTER") ;;
    *) echo "ERROR: --env must be one of: ${ALL_ENVS[*]}" >&2; exit 2 ;;
  esac
else
  ENVS=("${ALL_ENVS[@]}")
fi

# Resolve per-env values: prefer <KEY>_<ENV_UPPER>, fall back to <KEY>.
value_for() {
  local key="$1" env="$2"
  local upper_env
  upper_env="$(echo "$env" | tr '[:lower:]' '[:upper:]')"
  local suffixed="${key}_${upper_env}"
  if [[ -n "${!suffixed:-}" ]]; then
    printf '%s' "${!suffixed}"
  else
    printf '%s' "${!key:-}"
  fi
}

# Validate we have a value (suffixed or unsuffixed) for every key/env we'll push.
missing=()
for env in "${ENVS[@]}"; do
  for key in "${KEYS[@]}"; do
    if [[ -z "$(value_for "$key" "$env")" ]]; then
      upper_env="$(echo "$env" | tr '[:lower:]' '[:upper:]')"
      missing+=("$key for $env (set $key or ${key}_${upper_env})")
    fi
  done
done
if [[ ${#missing[@]} -gt 0 ]]; then
  echo "ERROR: missing required env vars:" >&2
  for m in "${missing[@]}"; do echo "  - $m" >&2; done
  exit 1
fi

if $WRITE_AWS && ! command -v aws >/dev/null 2>&1; then
  echo "ERROR: aws CLI not found; install awscli (or pass --wrangler-only)" >&2
  exit 1
fi
if $WRITE_WRANGLER && ! command -v npx >/dev/null 2>&1; then
  echo "ERROR: npx not found; install Node.js (or pass --aws-only)" >&2
  exit 1
fi
if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: jq not found; install jq (used to build the AWS-SM JSON blob)" >&2
  exit 1
fi

say() { printf '\033[1;36m==>\033[0m %s\n' "$*"; }

cd "$KEYSERVICE_DIR"
for env in "${ENVS[@]}"; do
  # Build the per-env JSON blob CI consumes as APP_SECRETS.
  blob="$(jq -n \
    --arg anthropic   "$(value_for ANTHROPIC_API_KEY  "$env")" \
    --arg resend      "$(value_for RESEND_API_KEY     "$env")" \
    --arg attestation "$(value_for ATTESTATION_SECRET "$env")" \
    --arg admin       "$(value_for ADMIN_SECRET       "$env")" \
    '{ANTHROPIC_API_KEY: $anthropic, RESEND_API_KEY: $resend, ATTESTATION_SECRET: $attestation, ADMIN_SECRET: $admin}')"

  if $WRITE_AWS; then
    secret_id="rdst/keyservice/${env}"
    say "AWS-SM: $secret_id"
    if $DRY_RUN; then
      printf '   [dry-run] aws secretsmanager put-secret-value --secret-id %s  (value hidden)\n' "$secret_id"
    else
      # Create on first run; overwrite on subsequent runs. The describe-secret
      # check distinguishes the two so a fresh env doesn't fail noisily.
      if aws secretsmanager describe-secret --secret-id "$secret_id" >/dev/null 2>&1; then
        aws secretsmanager put-secret-value \
          --secret-id "$secret_id" \
          --secret-string "$blob" >/dev/null
      else
        aws secretsmanager create-secret \
          --name "$secret_id" \
          --secret-string "$blob" >/dev/null
      fi
    fi
  fi

  if $WRITE_WRANGLER; then
    # Skip envs that don't have a Cloudflare Worker (e.g. dev01 is
    # AWS-SM-only — the Worker env was retired but the secret bundle
    # stays as the shared non-prod overrides blob).
    if ! printf '%s\n' "${WORKER_ENVS[@]}" | grep -qx "$env"; then
      say "Wrangler: skipping env=$env (no Cloudflare Worker)"
    else
      for key in "${KEYS[@]}"; do
        val="$(value_for "$key" "$env")"
        say "Wrangler: $key on env=$env"
        if $DRY_RUN; then
          printf '   [dry-run] npx wrangler secret put %s --env %s  (value hidden)\n' "$key" "$env"
        else
          printf '%s' "$val" | npx wrangler secret put "$key" --env "$env" >/dev/null
        fi
      done
    fi
  fi
done

say "Done."
