#!/usr/bin/env bash
# Deploy a personal dev environment for the rdst keyservice.
#
# Each developer gets their own Worker + D1 database keyed off a short
# name (typically your handle):
#   Worker: rdst-keyservice-<name>
#   D1:     rdst-keyservice-db-<name>
#   URL:    https://rdst-keyservice-<name>.readysetio.workers.dev
#
# Per-CL preview Workers cover automated review; this script covers
# interactive iteration. There is no shared canary — `dev01` (which
# used to play that role) was retired because every CL build overwrote
# it.
#
# Mirrors deploy-preview.sh but runs from your laptop:
#   - no Gerrit/Buildkite plumbing
#   - no apt-get / Docker container — uses your local node + uv
#   - reuses the per-CL preview wrangler.toml template + the shared
#     non-prod AWS-SM secret bundle at rdst/keyservice/dev01 (the
#     "dev01" name is a historical AWS-SM identifier — same blob
#     preview deploys read — so the printed RDST_ATTESTATION_SECRET
#     works against any non-prod env)
#
# Required tools on your host:
#   aws (with SSO logged into the keyservice account, 305232526136)
#   node + npx (for `wrangler d1`)
#   uv (for `pywrangler deploy`)
#   jq
#
# Usage:
#   ./scripts/deploy-dev-env.sh <name>
#
# Optional env-var overrides:
#   RDST_AWS_PROFILE   AWS profile for the keyservice account
#                      (default: AdministratorAccess-305232526136)
#   AWS_REGION         (default: us-east-2)
#
# Lifecycle: the D1 database is created on first run and never destroyed —
# Cloudflare D1 is free at rest on the paid plan. Re-running this script
# is idempotent: same Worker name, same D1, schema migrations re-applied
# (no-op once 0001_initial is recorded).
#
# After deploying, point a local CLI at your env:
#   export RDST_KEYSERVICE_URL=https://rdst-keyservice-<name>.readysetio.workers.dev
#   export RDST_ATTESTATION_SECRET=<shared non-prod attestation secret, printed below>
set -euo pipefail

# --- args + validation -------------------------------------------------------
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <name>" >&2
  echo "  name: lowercase alphanumeric + hyphens, max 20 chars (e.g. your handle)" >&2
  exit 2
fi

NAME="$1"
# Cloudflare Worker names allow [a-z0-9-]; keep ≤20 chars to leave headroom
# under the 63-char total Worker name limit when prefixed with rdst-keyservice-.
if [[ ! "$NAME" =~ ^[a-z0-9]([a-z0-9-]{0,18}[a-z0-9])?$ ]]; then
  echo "ERROR: <name> must be lowercase alphanumeric + hyphens, 1–20 chars," >&2
  echo "       and start/end with a letter or digit. Got: '$NAME'" >&2
  exit 2
fi

WORKER_NAME="rdst-keyservice-${NAME}"
DB_NAME="rdst-keyservice-db-${NAME}"
SERVICE_URL="https://${WORKER_NAME}.readysetio.workers.dev"
CONFIG_FILE="wrangler.dev.${NAME}.toml"

AWS_PROFILE_DEFAULT="AdministratorAccess-305232526136"
AWS_PROFILE_TO_USE="${RDST_AWS_PROFILE:-$AWS_PROFILE_DEFAULT}"
AWS_REGION_TO_USE="${AWS_REGION:-us-east-2}"

# Run from the keyservice dir so all relative paths (template, migrations,
# wrangler.toml) line up the same way as deploy-preview.sh / deploy.sh.
cd "$(dirname "$0")/.."

echo "--- Personal dev env for ${NAME}"
echo "Worker:    ${WORKER_NAME}"
echo "D1:        ${DB_NAME}"
echo "URL:       ${SERVICE_URL}"
echo "Config:    ${CONFIG_FILE} (gitignored)"
echo "AWS:       profile=${AWS_PROFILE_TO_USE}  region=${AWS_REGION_TO_USE}"
echo

# --- prereq checks -----------------------------------------------------------
for tool in aws node npx uv jq; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "ERROR: required tool not found in PATH: $tool" >&2
    exit 1
  fi
done

# Catch expired/missing AWS creds before anything else fails.
if ! aws --profile "$AWS_PROFILE_TO_USE" sts get-caller-identity >/dev/null 2>&1; then
  echo "ERROR: AWS profile '${AWS_PROFILE_TO_USE}' is not authenticated." >&2
  echo "       Run: aws sso login --profile ${AWS_PROFILE_TO_USE}" >&2
  exit 1
fi

# --- pull APP_SECRETS from the shared non-prod AWS-SM bundle ----------------
# Same JSON blob preview deploys use — one shared non-prod bundle means the
# same RDST_ATTESTATION_SECRET works against every non-prod env. The
# "dev01" name is a historical AWS-SM identifier; the dev01 Worker env
# was retired but the secret blob persists.
echo "--- Fetching APP_SECRETS from AWS-SM rdst/keyservice/dev01"
APP_SECRETS=$(aws --profile "$AWS_PROFILE_TO_USE" --region "$AWS_REGION_TO_USE" \
  secretsmanager get-secret-value --secret-id rdst/keyservice/dev01 \
  --query SecretString --output text)

if ! printf '%s' "$APP_SECRETS" | jq -e 'type == "object" and all(.[]; type == "string")' > /dev/null; then
  echo "ERROR: APP_SECRETS must be a flat JSON object with string values" >&2
  exit 1
fi

# --- ensure uv has the Python deps for pywrangler ----------------------------
echo "--- uv sync"
uv sync --frozen 2>/dev/null || uv sync

# --- look up or create the D1 database ---------------------------------------
echo "--- Looking up D1 ${DB_NAME}"
DB_LIST_JSON="$(npx --yes wrangler d1 list --json 2>/dev/null || echo '[]')"
DB_ID="$(printf '%s' "$DB_LIST_JSON" | jq -r --arg n "$DB_NAME" '.[] | select(.name == $n) | .uuid' | head -n1)"

if [[ -z "$DB_ID" ]]; then
  echo "--- Creating D1 ${DB_NAME} (first run for this name)"
  CREATE_OUT="$(npx --yes wrangler d1 create "$DB_NAME")"
  echo "$CREATE_OUT"
  DB_ID="$(printf '%s' "$CREATE_OUT" | grep -oE 'database_id *= *"[^"]+"' | head -n1 | sed -E 's/.*"([^"]+)".*/\1/')"
  if [[ -z "$DB_ID" ]]; then
    echo "ERROR: failed to extract database_id from wrangler d1 create output" >&2
    exit 1
  fi
fi
echo "DB_ID=${DB_ID}"

# --- render the per-dev wrangler config --------------------------------------
echo "--- Rendering ${CONFIG_FILE}"
sed \
  -e "s|__WORKER_NAME__|${WORKER_NAME}|g" \
  -e "s|__DB_NAME__|${DB_NAME}|g" \
  -e "s|__DB_ID__|${DB_ID}|g" \
  -e "s|__SERVICE_URL__|${SERVICE_URL}|g" \
  wrangler.preview.toml.template > "$CONFIG_FILE"

# --- apply migrations --------------------------------------------------------
# `printf 'y\n' |` feeds wrangler's "About to apply N migration(s) ... continue?"
# prompt — the auto-skip-in-non-interactive detection is unreliable when a
# pty is attached. Same workaround as deploy.sh / deploy-preview.sh.
echo "--- Applying D1 migrations to ${DB_NAME} (remote)"
printf 'y\n' | npx --yes wrangler d1 migrations apply "$DB_NAME" --remote \
  --config "$CONFIG_FILE" --env preview

# --- deploy ------------------------------------------------------------------
echo "--- Deploying Worker (${WORKER_NAME})"
uv run pywrangler deploy --config "$CONFIG_FILE" --env preview

# --- push runtime secrets ----------------------------------------------------
echo "--- Syncing runtime secrets to ${WORKER_NAME}"
echo "$APP_SECRETS" | npx --yes wrangler secret bulk --config "$CONFIG_FILE" --env preview

# --- print override instructions ---------------------------------------------
ATTESTATION_SECRET=$(printf '%s' "$APP_SECRETS" | jq -r '.ATTESTATION_SECRET')

echo
echo "============================================================"
echo "Done. Personal dev env deployed at:"
echo "  ${SERVICE_URL}"
echo
echo "Point your local CLI at it (add to your shell rc to make sticky):"
echo "  export RDST_KEYSERVICE_URL=${SERVICE_URL}"
echo "  export RDST_ATTESTATION_SECRET=${ATTESTATION_SECRET}"
echo
echo "Sanity check:"
echo "  curl ${SERVICE_URL}/health"
echo "============================================================"
