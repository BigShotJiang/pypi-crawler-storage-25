# RDST Key Service

Trial credit proxy for RDST. Gives new users $5 of free Anthropic API credits so they can try RDST without creating an Anthropic account or buying credits first.

## How It Works

```
RDST CLI                     Key Service (Cloudflare Worker + D1)         Anthropic API
   |                                      |                                    |
   |  1. rdst init                        |                                    |
   |     POST /register {email}           |                                    |
   |  ----------------------------------> |                                    |
   |     "Check your email"               | --> Resend: verification email      |
   |  <---------------------------------- |                                    |
   |                                      |                                    |
   |  2. User clicks email link           |                                    |
   |              GET /verify?token=xxx   |                                    |
   |                                      | assigns trial token                |
   |                                      | shows token on HTML page           |
   |                                      |                                    |
   |  3. User pastes token in rdst init   |                                    |
   |     Token saved to ~/.rdst/config.toml                                    |
   |                                      |                                    |
   |  4. rdst analyze / help / ask / etc  |                                    |
   |     POST /v1/messages                |                                    |
   |     x-api-key: <trial-token>         |                                    |
   |     X-RDST-Client: rdst             |                                    |
   |     X-RDST-Signature: <hmac>        |                                    |
   |  ----------------------------------> |  validate token + HMAC             |
   |                                      |  check $5 cap                      |
   |                                      |  swap key with real Anthropic key  |
   |                                      |  --------------------------------> |
   |                                      |  <-------------------------------- |
   |                                      |  count tokens, update usage        |
   |     Anthropic response               |  X-RDST-Trial-Remaining-Cents      |
   |  <---------------------------------- |                                    |
```

### Key-Type Routing (in RDST)

The RDST client determines routing based on where the API key came from. There is no `ANTHROPIC_BASE_URL` manipulation — it's purely key-type based:

```
ANTHROPIC_API_KEY set?        --yes-->  Direct to api.anthropic.com
         | no
RDST_TRIAL_TOKEN set?         --yes-->  Route to keyservice proxy
         | no
Trial token in config.toml?   --yes-->  Route to keyservice proxy
         | no
         +-->  Error: "No API key. Run rdst init or set ANTHROPIC_API_KEY"
```

Own-key users never touch the proxy. Zero latency impact for paying customers.

### Client Attestation

Trial tokens are protected by HMAC-based attestation headers so they can't be trivially used outside RDST:

- `X-RDST-Client: rdst` — presence check
- `X-RDST-Signature: <timestamp>.<hmac>` — HMAC-SHA256 of `<timestamp>.<trial_token>` using a shared secret

The shared secret is embedded as `_DEFAULT_CLIENT_ATTESTATION` in `rdst/shared/llm_manager/key_resolution.py` and matched on the worker side by the `ATTESTATION_SECRET` Wrangler secret (sourced from AWS-SM, see [Secrets](#secrets-aws-sm-source-of-truth--cloudflare-wrangler)). Prod's worker secret MUST equal the constant baked into shipped CLIs so tokens minted in the wild keep validating. This is defense-in-depth, not cryptographic security — someone with source access could extract the constant, but the $5 cap limits damage.

**Pointing a local CLI at a non-prod env.** Set `RDST_ATTESTATION_SECRET` to that env's `ATTESTATION_SECRET` value (from AWS-SM `rdst/keyservice/<env>`), paired with `RDST_KEYSERVICE_URL` pointing at the matching Worker. The CLI uses the env-var override if set, falling back to the baked-in constant otherwise. Per-CL preview deploys and personal dev envs both pull from the shared non-prod secrets bundle at AWS-SM `rdst/keyservice/dev01`, so the same `RDST_ATTESTATION_SECRET` value works against any non-prod Worker.

### Usage Tracking

Every proxied request logs token counts from Anthropic's response to a `usage_log` table. Cost is calculated using hardcoded model pricing (same pricing table exists in the keyservice and in RDST's `lib/functions/llm_analysis.py`). When a user's cumulative cost hits their limit (default $5), their status flips to `exhausted` and subsequent requests are rejected with a `TRIAL_EXHAUSTED` error.

### Safety Limits

- **Per-user credit cap**: $5.00 default (configurable per-user via admin)
- **Max trial users**: 100 default (configurable via admin). Limits total exposure to $500.
- **IP rate limiting**: Max 3 registration attempts per IP per hour
- **Email verification**: Must click email link before trial activates

## Architecture

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Worker | Cloudflare Workers (Python/FastAPI) | HTTP routing, proxy, auth |
| Database | Cloudflare D1 (SQLite) | Users, usage logs, settings |
| Email | Resend API | Verification emails |
| DNS | `rdst-keyservice.readysetio.workers.dev` | Worker endpoint |

### Database Tables

| Table | Purpose |
|-------|---------|
| `users` | Email, trial token, usage (cents), limit (cents), status (`pending`/`active`/`exhausted`/`reports_only`), `email_tier` (`personal` $1.50 / `business` $5.00), timestamps |
| `usage_log` | Per-request log: model, input/output tokens, cost, timestamp |
| `registration_attempts` | IP + timestamp for rate limiting |
| `settings` | Key-value store (currently: `max_trial_users`) |
| `report_sends` | Audit log of `/send-report` calls (email + sent_at) for daily-rate-limit checks |
| `hosted_reports` | Shareable HTML reports served at `/report/{id}`. UUID PK, 30-day TTL, optional `password_hash`, view counter |
| `pending_reports` | Report payloads queued at `/register-report` time, keyed by `verification_token`. Sent server-side when the user clicks the verify link, then deleted; stale rows expire after 24h |

### API Endpoints

| Method | Path | Auth | Purpose |
|--------|------|------|---------|
| POST | `/register` | None | Register for trial (sends verification email) |
| GET | `/verify?token=xxx` | None | Verify email; if a `pending_reports` row exists for the token, sends the report and shows a confirmation page; otherwise shows the trial token |
| POST | `/v1/messages` | Trial token + HMAC | Proxy to Anthropic |
| POST | `/register-report` | Trial token + HMAC | Queue a report payload tied to a verification token (CLI fire-and-forget; sent server-side when the verify link is clicked) |
| GET | `/verify-report?token=xxx` | None | Verify-and-send shortcut for queued reports (legacy path; `/verify` handles both flows now) |
| GET | `/report-status?token=xxx` | None | Poll status of a queued report |
| POST | `/send-report` | Trial token in body | Send a report immediately to a verified address (rate-limited via `report_sends`) |
| GET | `/report/{report_id}` | None (optional password) | View a hosted HTML report; increments `view_count` |
| GET | `/admin` | None (page), Bearer (API calls) | Admin web dashboard |
| GET | `/admin/status` | Bearer | Aggregate stats |
| GET | `/admin/users` | Bearer | List all users with usage |
| PUT | `/admin/users` | Bearer | Update user limit/status |
| GET | `/admin/users/log?email=...` | Bearer | Per-user request history |
| GET | `/admin/reports` | Bearer | List hosted reports (audit / cleanup) |
| PUT | `/admin/settings` | Bearer | Update max_trial_users, etc. |
| GET | `/health` | None | Health check |

### Secrets (AWS-SM source of truth → Cloudflare Wrangler)

| Secret | Purpose |
|--------|---------|
| `ANTHROPIC_API_KEY` | Company Anthropic API key (swapped in for trial tokens) |
| `RESEND_API_KEY` | Resend API key for sending verification emails |
| `ATTESTATION_SECRET` | HMAC secret for `X-RDST-Signature` validation. **Prod's value must equal the `_DEFAULT_CLIENT_ATTESTATION` constant in `shared/llm_manager/key_resolution.py`** so shipped CLIs in the wild keep validating. staging/preview/personal envs can rotate freely; devs hitting those envs override via `RDST_ATTESTATION_SECRET`. |
| `ADMIN_SECRET` | Bearer token for admin endpoints and dashboard login |

**AWS Secrets Manager is the source of truth.** The four secrets above are stored as JSON blobs at `rdst/keyservice/<env>` for `staging` and `prod`, plus `rdst/keyservice/dev01` which serves as the shared non-prod secrets bundle (read by per-CL preview deploys and personal dev envs — the dev01 Worker env itself was retired, but the secret name persists). On every deploy CI fetches the relevant blob via the `seek-oss/aws-sm` plugin as `APP_SECRETS` and re-pushes it to the Worker via `wrangler secret bulk --env <env>` — same pattern web-apps uses. This keeps the Worker in sync with AWS-SM automatically.

For initial bootstrap of a new env, or rotation, use `scripts/seed-secrets.sh`. By default it writes BOTH places (AWS-SM + Cloudflare Wrangler) so the next CI deploy reads the same value the Worker is already running. They are never visible in code or logs.

## Admin Dashboard

**URL**: `https://rdst-keyservice.readysetio.workers.dev/admin`

Login with the `ADMIN_SECRET` bearer token. The token is stored in browser `sessionStorage` (clears when tab closes).

**Features**:
- Stats overview: users, active, exhausted, total spend, API requests, tokens, 24h signups
- Model usage breakdown: per-model request counts, tokens, cost
- Settings: change max trial users on the fly
- User table: email, status, request count, usage with progress bar, limit, tokens (in/out), timestamps
- Search: filter users by email
- Pagination: 25 per page default, configurable 15/25/50/100
- Edit: change any user's credit limit or status (reactivates exhausted users when limit is increased)
- Request log: expand inline (last 20) or modal view (last 100) of a user's request history

## RDST Client-Side Integration

The key resolution logic lives in `lib/llm_manager/key_resolution.py`. Key files involved:

| File | Role |
|------|------|
| `lib/llm_manager/key_resolution.py` | Shared resolver: env vars > trial token, HMAC attestation |
| `lib/llm_manager/claude_provider.py` | `base_url` + `extra_headers` params, proxy-down handling, trial exhaustion detection |
| `lib/llm_manager/llm_manager.py` | Uses resolver, passes routing to provider, propagates trial balance |
| `lib/agent/chat_agent.py` | Uses resolver for Anthropic SDK `base_url` + `default_headers` |
| `lib/llm_manager/trial_display.py` | Low-balance and exhaustion warnings |
| `lib/cli/configuration_wizard.py` | Trial registration flow in `rdst init` |
| `lib/cli/rdst_cli.py` | `TargetsConfig` trial helpers (get/set/is_active) |

### Config File (`~/.rdst/config.toml`)

```toml
[trial]
token = "550e8400-e29b-41d4-a716-446655440000"
email = "user@example.com"
status = "active"    # active | exhausted
```

## Deployment

The keyservice has two CI-deployed environments — `staging`
(post-merge canary) and `prod` — configured as separate `env.*` blocks
in `wrangler.toml` with their own worker name, D1 database, and runtime
vars. Every `wrangler` / `pywrangler` command needs `--env staging` or
`--env prod`; there is no top-level default. Per-CL preview Workers
and personal dev envs cover everything else.

| Env | Worker name | D1 database |
|-----|-------------|-------------|
| staging | `rdst-keyservice-staging` | `rdst-keyservice-db-staging` |
| prod | `rdst-keyservice` | `rdst-keyservice-db` |
| preview (per CL) | `rdst-keyservice-pr-<gerrit-change-id>` | `rdst-keyservice-db-pr-<gerrit-change-id>` |
| personal dev | `rdst-keyservice-<yourhandle>` | `rdst-keyservice-db-<yourhandle>` |

Runtime secrets (`ANTHROPIC_API_KEY`, `RESEND_API_KEY`, `ATTESTATION_SECRET`, `ADMIN_SECRET`) live in AWS-SM at `rdst/keyservice/<env>` and are re-pushed to the Worker on every deploy — see [Secrets](#secrets-aws-sm-source-of-truth--cloudflare-wrangler) above.

### CI: Buildkite (primary path)

Keyservice deploy steps live inside the existing `readyset-rdst`
pipeline. There is no separate `readyset-keyservice` pipeline — the
repo-level dispatcher (`.buildkite/generate_monorepo_pipeline.sh`)
routes any `rdst/*` change (including `rdst/keyservice/*`) to the
single `readyset-rdst` pipeline.

The pipeline is dynamically generated. The static
`rdst/.buildkite/pipeline.yml` contains a single bootstrap step that
runs `rdst/.buildkite/detect_pipeline_areas.sh`, which inspects the
git diff and emits step YAML for the surfaces this build touches
before piping to `buildkite-agent pipeline upload`. Buildkite's `if:`
expression language doesn't support build meta-data, so surface gating
has to happen at upload time, not at step-evaluation time.

The script categorises each changed file as:

- **Keyservice** — any `rdst/keyservice/*` path. Emits the keyservice
  deploy steps (preview pre-merge, staging post-merge, prod off the
  release-approval gate).
- **Python** — any other `rdst/*` path, or any rdst-affecting
  `web-apps/*` path. Emits the python unit + integration tests.

A keyservice-only CL skips the python suite; an rdst-python-only CL
skips the keyservice deploys; a mixed CL runs both. If `HEAD~1` is
unavailable (shallow checkout) the script fails open — emits
everything — so the pipeline runs rather than silently skipping work.
- **CLs (pre-merge)** — `keyservice-preview-deploy` provisions a
  per-CL ephemeral Worker (see
  [Preview environments](#preview-environments)) and posts the URL
  back to Gerrit.
- **Main (post-merge)** — `keyservice-staging-deploy` runs
  automatically. The existing `release-approval` block (the same
  manual gate that publishes RDST to PyPI) then fans out to BOTH
  `publish-release` (PyPI + CodeArtifact) AND `keyservice-prod-deploy`
  in parallel. One Approve = one full release across both surfaces.

### Personal dev environments

Each developer working on the keyservice runs their own personal env
for interactive iteration. Per-CL preview Workers handle automated CL
validation; personal dev envs cover everything else. There is no
shared canary to deploy to — `dev01` (which used to play that role)
was retired because every CL build overwrote it.

```bash
cd rdst/keyservice
./scripts/deploy-dev-env.sh <yourhandle>
```

Provisions, on first run:

| Resource | Name |
|---|---|
| Worker | `rdst-keyservice-<yourhandle>` |
| URL | `https://rdst-keyservice-<yourhandle>.readysetio.workers.dev` |
| D1 | `rdst-keyservice-db-<yourhandle>` |
| Local config (gitignored) | `wrangler.dev.<yourhandle>.toml` |

Re-running the script is idempotent — same Worker + same D1, migrations
are no-ops once `0001_initial.sql` is recorded. Secrets are pulled from
the shared non-prod bundle at AWS-SM `rdst/keyservice/dev01` (the same
blob preview deploys use), so the printed `RDST_ATTESTATION_SECRET`
works for any non-prod env you hit (staging, your env, any preview).

Requires: AWS SSO logged into the keyservice account
(`AdministratorAccess-305232526136`), `node`/`npx`, `uv`, and `jq` on
your host. Override the AWS profile with `RDST_AWS_PROFILE=<other>` if
needed.

The legacy `[env.mike]` block in `wrangler.toml` is grandfathered for
that named env; new dev envs should use this script.

### Preview environments

Every CL that changes anything under `rdst/keyservice/` gets its own
ephemeral Worker + D1 database, both keyed off the Gerrit change id:

| Resource | Name |
|---|---|
| Worker | `rdst-keyservice-pr-<change-id>` |
| URL | `https://rdst-keyservice-pr-<change-id>.readysetio.workers.dev` |
| D1 | `rdst-keyservice-db-pr-<change-id>` |

Newer patchsets on the same CL reuse the same Worker + DB, so preview
state is stable for the lifetime of the review. `deploy-preview.sh`
creates the D1 on first deploy and runs `wrangler d1 migrations apply`
every build (no-op once `0001_initial.sql` is recorded), and posts the
preview URL back to Gerrit as a comment.

**Secrets** are pulled from the shared non-prod bundle at AWS-SM
`rdst/keyservice/dev01` and pushed to the preview Worker on every
deploy. Every non-prod surface (preview, personal dev env) reads from
this one bundle, so devs only need one `RDST_ATTESTATION_SECRET` /
`ADMIN_SECRET` pair to test against any of them. The "dev01" name is
a historical AWS-SM identifier — there's no Worker env by that name
anymore, but the secret blob persists. Mirrors the web-apps cloud
preview pattern of reusing `frontend/cloud/dev01`.

**Cleanup**: none. Cloudflare D1 is free at rest on the paid plan and
Workers don't accrue cost when idle, so preview Workers/DBs accumulate
indefinitely. Add a scheduled reaper later if the dashboard gets noisy.

**Pointing a local RDST CLI at a preview**:

```bash
export RDST_KEYSERVICE_URL=https://rdst-keyservice-pr-12345.readysetio.workers.dev
export RDST_ATTESTATION_SECRET=<shared non-prod ATTESTATION_SECRET (AWS-SM rdst/keyservice/dev01)>
rdst init                # registers a trial token against the preview keyservice
rdst ask "..."           # uses that trial token through the preview proxy
```

The Gerrit comment posted by CI includes the URL and the export lines.

`deploy.sh` runs inside `python:3.12-slim-bookworm` with `rdst/keyservice/`
mounted at `/app`, installs Node (for `npx wrangler` D1 ops) + `uv` (for
`pywrangler`), runs `wrangler d1 migrations apply` against the env's D1, deploys with
`pywrangler deploy --env $ENV`, and finally `wrangler secret bulk --env $ENV`
re-pushes the `APP_SECRETS` JSON blob from AWS-SM to keep the Worker in
sync. The `frontend/cloudflare` AWS-SM read provides the Cloudflare API
token CI uses to authenticate (shared with web-apps).

### Seeding secrets (one-time / rotation)

Use `rdst/keyservice/scripts/seed-secrets.sh`. By default it writes BOTH
AWS-SM (`rdst/keyservice/<env>`) AND the Cloudflare Worker, so AWS-SM —
the source of truth CI reads on every deploy — and the live Worker stay
aligned. Pass `--aws-only` if you only want the durable copy (next
deploy will sync it to the Worker), or `--wrangler-only` for a hotfix
that bypasses AWS-SM (CI will overwrite it on the next deploy unless you
also update AWS-SM). By default writes to all three secret names
(`dev01`, `staging`, `prod`); pass `--env <name>` to scope to one. Note
that `dev01` is AWS-SM-only — the Worker env was retired but the secret
blob remains as the shared non-prod overrides bundle, so the script
writes only to AWS-SM for that name and skips the Wrangler push.
Supports `--dry-run` and per-env overrides
(`ANTHROPIC_API_KEY_DEV01`, `..._STAGING`, `..._PROD`, etc.) when you
want different values per env.

### Manual Wrangler (fallback / hotfix)

```bash
cd rdst/keyservice

# Deploy code (pick an env — no default)
uv run pywrangler deploy --env staging
uv run pywrangler deploy --env prod

# Update a single secret in one env
echo "sk-ant-..." | npx wrangler secret put ANTHROPIC_API_KEY  --env prod
echo "re_..."     | npx wrangler secret put RESEND_API_KEY     --env prod
echo "rdst-..."   | npx wrangler secret put ATTESTATION_SECRET --env prod
echo "your-token" | npx wrangler secret put ADMIN_SECRET       --env prod

# Apply migrations (each env has its own D1; CI does this on every deploy)
# (`migrations apply` auto-skips its confirmation prompt in non-interactive
#  shells; pass it through stdin or run interactively when needed.)
npx wrangler d1 migrations apply rdst-keyservice-db-staging --remote --env staging
npx wrangler d1 migrations apply rdst-keyservice-db         --remote --env prod

# Check admin status
curl -H 'Authorization: Bearer <ADMIN_SECRET>' \
  https://rdst-keyservice.readysetio.workers.dev/admin/status
```

### Local Development

```bash
cd rdst/keyservice
cp .dev.vars.example .dev.vars   # Fill in local secrets
wrangler dev                     # Starts on localhost:8787 with local D1
```

### Known Limitations

- **CI container mounts only `rdst/keyservice/` at `/app`.** The
  keyservice deploy steps in `rdst/.buildkite/pipeline.yml` mount this
  directory only, not the repo root. Everything `deploy.sh` currently
  needs (`wrangler.toml`, `migrations/`, `pyproject.toml`, `src/`) lives
  inside the mount, so this is fine today. If a future deploy step
  needs a file outside `rdst/keyservice/` (e.g. a shared script under
  `scripts/`), extend the `volumes:` list on every keyservice step in
  `rdst/.buildkite/pipeline.yml` — they all have to agree or
  staging/prod/preview deploys will diverge from CL validation.
- **Per-env `ATTESTATION_SECRET`.** Each Worker holds its own HMAC
  secret as a Wrangler secret. Prod's value must equal the
  `_DEFAULT_CLIENT_ATTESTATION` constant baked into shipped CLIs; the
  other envs are free to rotate. Devs hitting non-prod envs override
  with `RDST_ATTESTATION_SECRET` (see Preview environments above).
- **Node + Python in one container.** `deploy.sh` installs Node via `apt-get`
  on top of `python:3.12-slim-bookworm` because `pywrangler` handles Python
  Worker deploy but doesn't expose D1 subcommands — those need `npx wrangler`.
  Adds ~30s to every CI deploy. Replace with a pre-built image in the
  `305232526136` ECR if that cost matters.

### D1 Database Migrations

Schema is managed by `wrangler d1 migrations`. Migration files live in
`rdst/keyservice/migrations/` as numbered SQL (`0001_initial.sql`,
`0002_<name>.sql`, …). Wrangler tracks applied migrations in a `d1_migrations`
table inside D1 itself, so each migration runs at most once per database.

Each `[[d1_databases]]` block in `wrangler.toml` (and the preview template)
sets `migrations_dir = "migrations"` so wrangler knows where to read from.

CI's `deploy.sh` calls `wrangler d1 migrations apply` on every deploy; in
steady state this is a no-op (returns "no migrations to apply"). Adding a
new migration is the only schema-change workflow:

```bash
cd rdst/keyservice

# Scaffold the next migration (writes migrations/000N_<name>.sql)
npx wrangler d1 migrations create rdst-keyservice-db-staging add_foo_table

# Edit the generated file, then preview/apply locally if you have a local
# D1 (rare — usually let CI handle it):
npx wrangler d1 migrations apply rdst-keyservice-db-staging --remote --env staging

# Inspect applied migrations on a remote DB
npx wrangler d1 migrations list rdst-keyservice-db-staging --remote --env staging

# Ad-hoc query
npx wrangler d1 execute rdst-keyservice-db --remote --env prod \
  --command="SELECT email, usage_cents, status FROM users"
```

Migrations are forward-only — `wrangler d1 migrations` has no rollback
concept. To revert a bad change, write a compensating migration.

## Pricing Sync

Model pricing is hardcoded in two places that must stay in sync:

| Location | Format |
|----------|--------|
| `keyservice/src/index.py` — `CLAUDE_PRICING` | `{model_id: {"input": $/MTok, "output": $/MTok}}` |
| `lib/functions/llm_analysis.py` — `CLAUDE_PRICING` | Same format |

When Anthropic changes prices, update both. The keyservice pricing determines billing; the RDST pricing is for cost estimation display only.

## Operations

### Give a user more credits

Via the admin dashboard (Edit button), or via API:

```bash
curl -X PUT https://rdst-keyservice.readysetio.workers.dev/admin/users \
  -H 'Authorization: Bearer <ADMIN_SECRET>' \
  -H 'Content-Type: application/json' \
  -d '{"email": "user@example.com", "limit_cents": 1000}'
```

Setting `limit_cents` above their current `usage_cents` automatically reactivates an exhausted user.

### Increase the trial user cap

Via the admin dashboard (Settings section), or via API:

```bash
curl -X PUT https://rdst-keyservice.readysetio.workers.dev/admin/settings \
  -H 'Authorization: Bearer <ADMIN_SECRET>' \
  -H 'Content-Type: application/json' \
  -d '{"max_trial_users": 200}'
```

### Rotate the Anthropic API key

Update AWS-SM so the next CI deploy picks it up everywhere, then optionally
push it live without waiting:

```bash
# Durable source of truth (re-run seed script for the env you're rotating)
rdst/keyservice/scripts/seed-secrets.sh --aws-only --env prod

# Live-push without a redeploy
echo "sk-ant-new-key-here" | npx wrangler secret put ANTHROPIC_API_KEY --env prod
```

Wrangler secrets update live on the worker — no redeployment needed.

### Rotate the admin token

Same pattern — update AWS-SM as the source of truth, optionally hot-push:

```bash
# Durable source of truth
ADMIN_SECRET=$(openssl rand -hex 32) \
  rdst/keyservice/scripts/seed-secrets.sh --aws-only --env prod

# Live-push without a redeploy
echo "new-admin-token" | npx wrangler secret put ADMIN_SECRET --env prod
```

Anyone logged into the prod dashboard will be logged out on next API call.

### View raw database

```bash
# Prod
npx wrangler d1 execute rdst-keyservice-db --remote \
  --command="SELECT * FROM users ORDER BY created_at DESC"

npx wrangler d1 execute rdst-keyservice-db --remote \
  --command="SELECT * FROM usage_log ORDER BY created_at DESC LIMIT 20"

npx wrangler d1 execute rdst-keyservice-db --remote \
  --command="SELECT * FROM settings"

# Staging (swap in rdst-keyservice-db-staging)
npx wrangler d1 execute rdst-keyservice-db-staging --remote \
  --command="SELECT * FROM users ORDER BY created_at DESC"
```
