import argparse
import sys
import os
from pypdf import PdfReader, PdfWriter
from pypdf.errors import PdfStreamError, PdfReadError, FileNotDecryptedError
import io

def get_extracted_size(file_path: str, start_page: int, end_page: int) -> int:
    """抽出されたPDFのサイズを取得"""
    data = extract_pages(file_path, start_page, end_page)
    return len(data)

def extract_pages(file_path: str, start_page: int, end_page: int) -> bytes:
    """PDFから指定ページ範囲を抽出"""
    reader = PdfReader(file_path)
    writer = PdfWriter()
    
    for i in range(start_page, end_page + 1):
        writer.add_page(reader.pages[i])
    
    with io.BytesIO() as buffer:
        writer.write(buffer)
        return buffer.getvalue()

def find_split_point(file_path: str, start_page: int, max_size: int) -> int:
    """分割ポイントを見つける"""
    reader = PdfReader(file_path)
    total_pages = len(reader.pages)
    
    # 1ページも収まらない場合は例外を発生させる
    first_page_size = get_extracted_size(file_path, start_page, start_page)
    if first_page_size > max_size:
        raise ValueError("1ページ目が既に指定サイズを超過しているため分割できません")

    # 平均サイズから、おおよそのページ数を予測
    total_file_size = os.path.getsize(file_path)
    avg_page_size = total_file_size / total_pages
    predicted_count = max(1, int(max_size // avg_page_size))
    
    # 予測したページ数を初期値として、微調整（線形探索）を行う
    current_end = min(start_page + predicted_count - 1, total_pages - 1)
    
    # 予測地点が大きすぎる場合は戻る
    while current_end > start_page and get_extracted_size(file_path, start_page, current_end) > max_size:
        current_end -= 1
        
    # 予測地点にまだ余裕がある場合は進む
    while current_end < total_pages - 1 and get_extracted_size(file_path, start_page, current_end + 1) <= max_size:
        current_end += 1

    return current_end

def split_pdf_by_size(input_pdf: str, max_size: int, output_dir: str, verbose: bool = False) -> None:
    """PDFを指定サイズで分割する内部関数"""
    # ファイル存在チェック
    if not os.path.exists(input_pdf):
        raise ValueError("ファイルが存在しません")

    # ファイル読み取り権限チェック
    if not os.access(input_pdf, os.R_OK):
        raise ValueError("ファイルを読み取る権限がありません")

    # ディレクトリ存在チェック
    if not os.path.isdir(output_dir):
        raise ValueError("出力先ディレクトリが存在しません")

    # 上限サイズのチェック
    if max_size <= 0:
        raise ValueError("上限サイズは1以上の数値を指定してください")

    try:
        reader = PdfReader(input_pdf)
    except (PdfStreamError, PdfReadError) as e:
        raise ValueError("無効なPDFファイルです")

    try:
        total_pages = len(reader.pages)
    except FileNotDecryptedError:
        raise ValueError("暗号化されたPDFファイルはサポートされていません")

    total_file_size = os.path.getsize(input_pdf)

    # 指定サイズ以下の場合は分割不要
    if total_file_size <= max_size:
        if verbose:
            print(f"処理をスキップします: {input_pdf}（サイズ{total_file_size}バイトは上限{max_size}バイト以下）")
        return

    if verbose:
        print(f"処理を開始します: {input_pdf}")

    base_name = os.path.splitext(os.path.basename(input_pdf))[0]

    start_page = 0
    part_number = 1

    while start_page < total_pages:
        # 上限に収まる終了ページを見つける
        end_page = find_split_point(input_pdf, start_page, max_size)

        # 該当ページを抽出してファイルに保存
        pdf_data = extract_pages(input_pdf, start_page, end_page)
        output_filename = os.path.join(output_dir, f"{base_name}_part{part_number}.pdf")

        with open(output_filename, "wb") as f:
            f.write(pdf_data)

        if verbose:
            page_count = end_page - start_page + 1
            print(f"生成中: {output_filename} (ページ {start_page + 1}-{end_page + 1}, {page_count}ページ)")

        # 次の分割へ進む
        start_page = end_page + 1
        part_number += 1

    if verbose:
        print(f"完了しました: {part_number - 1}個のファイルを生成しました")

# ライブラリAPIとして公開する関数
def split_pdf(input_pdf: str, max_size: int, output_dir: str = ".", verbose: bool = False) -> None:
    """
    PDFファイルを指定したサイズで分割するライブラリ関数
    
    Args:
        input_pdf: 分割したいPDFファイルのパス
        max_size: 分割する上限サイズ（バイト単位）
        output_dir: 出力先のディレクトリ（デフォルトは現在のディレクトリ）
        verbose: 詳細な進捗情報を表示するかどうか（デフォルトはFalse）
    
    Raises:
        ValueError: ファイルが存在しない、権限がない、無効なPDFなどのエラー
    """
    split_pdf_by_size(input_pdf, max_size, output_dir, verbose)

def main() -> None:
    parser = argparse.ArgumentParser(description="PDFファイルを指定したサイズ（バイト）で分割するツール")
    parser.add_argument("input_pdf", help="分割したいPDFファイルのパス")
    parser.add_argument("max_size", type=int, help="分割する上限サイズ（バイト単位）")
    parser.add_argument("-o", "--output", default=".", help="出力先のディレクトリ（デフォルトは現在のディレクトリ）")
    parser.add_argument("-v", "--verbose", action="store_true", help="詳細な進捗情報を表示する")

    args = parser.parse_args()

    try:
        split_pdf_by_size(args.input_pdf, args.max_size, args.output, args.verbose)
    except ValueError as e:
        print(f"エラー: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"予期せぬエラーが発生しました: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
