import pytest
import sys
import os

def test_split_logic_uses_relative_import() -> None:
    """src/split_logic.py が相対インポートを使用していることを確認"""
    with open("src/split_logic.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # 絶対インポート（src.pdf_extraction）が含まれていないこと
    assert "from src.pdf_extraction" not in content, "絶対インポートが使用されています。相対インポートに変更してください"
    
    # 相対インポート（.pdf_extraction）が含まれていること
    assert "from .pdf_extraction" in content, "相対インポートが使用されていません"

def test_splitter_uses_relative_import() -> None:
    """src/splitter.py が相対インポートを使用していることを確認"""
    with open("src/splitter.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # 絶対インポートが含まれていないこと
    assert "from src.pdf_extraction" not in content, "絶対インポートが使用されています。相対インポートに変更してください"
    assert "from src.split_logic" not in content, "絶対インポートが使用されています。相対インポートに変更してください"
    
    # 相対インポートが含まれていること
    assert "from .pdf_extraction" in content, "相対インポートが使用されていません"
    assert "from .split_logic" in content, "相対インポートが使用されていません"

def test_main_entry_has_path_setup() -> None:
    """pdf_size_splitter.py が自己完結した実装であることを確認"""
    with open("pdf_size_splitter.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # srcモジュールへの依存がないこと
    assert "from src" not in content, "srcモジュールへの依存があります。自己完結した実装にしてください"
    
    # 必要な実装関数が含まれていること
    assert "def split_pdf(" in content, "split_pdf関数がありません"
    assert "def split_pdf_by_size(" in content, "split_pdf_by_size関数がありません"
    assert "def extract_pages(" in content, "extract_pages関数がありません"
    assert "def find_split_point(" in content, "find_split_point関数がありません"
