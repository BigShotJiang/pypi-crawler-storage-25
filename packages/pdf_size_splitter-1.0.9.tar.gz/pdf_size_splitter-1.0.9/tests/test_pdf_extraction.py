import pytest
import os
import io
from pypdf import PdfReader # 追加
from src.pdf_extraction import get_extracted_size, extract_pages

def test_get_extracted_size_single_page() -> None:
    # Given: 3ページのPDFとそのファイルサイズ
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    original_size = os.path.getsize(input_pdf)
    
    # When: 1ページ分（0枚目）だけ抽出したとき
    size = get_extracted_size(input_pdf, 0, 0)
    
    # Then: 抽出したサイズが、元のファイルサイズよりも小さいこと
    assert isinstance(size, int)
    assert size < original_size

def test_get_extracted_size_multiple_pages() -> None:
    # Given: 3ページのPDFとそのファイルサイズ
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    original_size = os.path.getsize(input_pdf)
    
    # When: 2ページ分（0〜1枚目）を抽出したとき
    multiple_pages_size = get_extracted_size(input_pdf, 0, 1)
    
    # Then: 抽出したサイズが元のサイズより小さいこと
    assert isinstance(multiple_pages_size, int)
    assert multiple_pages_size < original_size

def test_extract_pages_correct_count() -> None:
    # Given: 3ページのPDFから、0ページ目から1ページ目（計2ページ）を抽出したい
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    start_page = 0
    end_page = 1

    # When: 指定範囲を抽出したとき
    extracted_pdf_data = extract_pages(input_pdf, start_page, end_page)

    # Then: 抽出されたPDFのページ数が2であること
    reader = PdfReader(io.BytesIO(extracted_pdf_data))
    assert len(reader.pages) == 2
