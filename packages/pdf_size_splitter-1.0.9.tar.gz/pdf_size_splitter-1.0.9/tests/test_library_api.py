"""
ライブラリAPIのテスト
"""
import pytest
import tempfile
import os


def test_import_split_pdf():
    """ライブラリからsplit_pdf関数をインポートできることを確認"""
    try:
        from pdf_size_splitter import split_pdf
        assert callable(split_pdf)
    except ImportError as e:
        pytest.fail(f"split_pdfのインポートに失敗しました: {e}")


def test_split_pdf_function_signature():
    """split_pdf関数のシグネチャを確認"""
    from pdf_size_splitter import split_pdf
    import inspect
    
    sig = inspect.signature(split_pdf)
    params = list(sig.parameters.keys())
    
    # 必要なパラメータが存在することを確認
    assert 'input_pdf' in params
    assert 'max_size' in params
    assert 'output_dir' in params


def test_split_pdf_basic_usage():
    """ライブラリとしての基本的な使用方法をテスト"""
    from pdf_size_splitter import split_pdf
    
    # テスト用PDFファイルのパスを取得
    test_pdf = "tests/test_data/sample.pdf"
    
    if not os.path.exists(test_pdf):
        pytest.skip(f"テストファイル {test_pdf} が存在しません")
    
    # 一時ディレクトリを作成
    with tempfile.TemporaryDirectory() as temp_dir:
        # 関数を呼び出し（エラーが発生しないことを確認）
        try:
            split_pdf(test_pdf, 1000000, temp_dir)
        except ValueError as e:
            # ファイルサイズが小さい場合はスキップされる可能性がある
            if "サイズ" in str(e) and "以下" in str(e):
                pass  # これは期待される動作
            else:
                raise


def test_import_from_main_package():
    """メインパッケージからインポートできることを確認"""
    try:
        import pdf_size_splitter
        assert hasattr(pdf_size_splitter, 'split_pdf')
    except ImportError as e:
        pytest.fail(f"pdf_size_splitterパッケージのインポートに失敗しました: {e}")
