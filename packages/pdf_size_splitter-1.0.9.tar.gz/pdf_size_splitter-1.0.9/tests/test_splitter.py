import pytest
import os
import glob
from io import StringIO
from unittest.mock import patch
from src.splitter import split_pdf_by_size

def test_split_pdf_by_size(tmp_path) -> None:
    # Given: 10ページのPDFと、保存先ディレクトリ(pytestのtmp_pathを使用)
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    output_dir = str(tmp_path)
    
    # 上限サイズを「約3ページ分」に設定する
    total_size = os.path.getsize(input_pdf)
    max_size = (total_size // 10) * 3 + 100 
    
    # When: PDFを分割処理する
    split_pdf_by_size(input_pdf, max_size, output_dir)
    
    # Then: 出力先ディレクトリに複数のPDFが生成されていること
    output_files = glob.glob(os.path.join(output_dir, "*.pdf"))
    assert len(output_files) > 1

def test_split_pdf_by_size_file_not_found(tmp_path) -> None:
    input_pdf = "non_existent_file.pdf"
    output_dir = str(tmp_path)
    max_size = 1000

    # 単なるFileNotFoundErrorではなく、明確な意図を持った ValueError を期待する
    with pytest.raises(ValueError, match="ファイルが存在しません"):
        split_pdf_by_size(input_pdf, max_size, output_dir)

def test_split_pdf_by_size_output_dir_not_found() -> None:
    # Given: 存在する入力ファイルと、存在しない出力先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    output_dir = "non_existent_directory"
    max_size = 1000

    # When / Then: 実行すると ValueError が発生することを確認
    with pytest.raises(ValueError, match="出力先ディレクトリが存在しません"):
        split_pdf_by_size(input_pdf, max_size, output_dir)

def test_split_pdf_by_size_invalid_max_size(tmp_path) -> None:
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    output_dir = str(tmp_path)

    # 上限サイズが0の場合
    with pytest.raises(ValueError, match="上限サイズは1以上の数値を指定してください"):
        split_pdf_by_size(input_pdf, 0, output_dir)

    # 上限サイズがマイナスの場合
    with pytest.raises(ValueError, match="上限サイズは1以上の数値を指定してください"):
        split_pdf_by_size(input_pdf, -100, output_dir)

def test_split_pdf_by_size_verbose(tmp_path, capsys) -> None:
    # Given: 10ページのPDFと、保存先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    output_dir = str(tmp_path)
    total_size = os.path.getsize(input_pdf)
    max_size = (total_size // 10) * 3 + 100

    # When: verboseモードでPDFを分割処理する
    split_pdf_by_size(input_pdf, max_size, output_dir, verbose=True)

    # Then: 標準出力に進捗メッセージが出力されていること
    captured = capsys.readouterr()
    assert "開始" in captured.out or "処理を開始" in captured.out
    assert "完了" in captured.out or "完了しました" in captured.out
    assert "part" in captured.out  # ファイル名が出力されていること

def test_split_pdf_by_size_one_page(tmp_path) -> None:
    """1ページPDFの分割テスト（分割不要なので何も生成されない）"""
    # Given: 1ページのPDFと、保存先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "one_page.pdf")
    output_dir = str(tmp_path)
    max_size = 10000  # 1ページが収まるサイズ

    # When: PDFを分割処理する
    split_pdf_by_size(input_pdf, max_size, output_dir)

    # Then: 出力先ディレクトリにファイルが生成されていないこと（1ページなので分割不要）
    output_files = glob.glob(os.path.join(output_dir, "*.pdf"))
    assert len(output_files) == 0

def test_split_pdf_by_size_empty_pdf(tmp_path) -> None:
    """空のPDF（0ページ）の分割テスト"""
    # Given: 空のPDFと、保存先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "empty.pdf")
    output_dir = str(tmp_path)
    max_size = 10000

    # When: 空のPDFを分割処理する
    split_pdf_by_size(input_pdf, max_size, output_dir)

    # Then: 出力先ディレクトリにファイルが生成されていないこと（0ページなので分割されない）
    output_files = glob.glob(os.path.join(output_dir, "*.pdf"))
    assert len(output_files) == 0

def test_split_pdf_by_size_within_limit(tmp_path) -> None:
    """指定サイズ以下のPDFは分割不要のテスト"""
    # Given: 3ページのPDFと、保存先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    output_dir = str(tmp_path)
    total_size = os.path.getsize(input_pdf)
    max_size = total_size + 1000  # 全体サイズより大きい値を指定

    # When: PDFを分割処理する（指定サイズ以上なので分割不要）
    split_pdf_by_size(input_pdf, max_size, output_dir)

    # Then: 出力先ディレクトリにファイルが生成されていないこと（サイズ制限内なので分割不要）
    output_files = glob.glob(os.path.join(output_dir, "*.pdf"))
    assert len(output_files) == 0

def test_split_pdf_by_size_corrupted_pdf(tmp_path) -> None:
    """破損したPDFファイルのエラーハンドリングテスト"""
    # Given: 破損したPDFファイルと、保存先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "corrupted.pdf")
    output_dir = str(tmp_path)
    max_size = 1000

    # When / Then: 破損したPDFを処理しようとすると ValueError が発生すること
    with pytest.raises(ValueError, match="無効なPDFファイルです"):
        split_pdf_by_size(input_pdf, max_size, output_dir)

def test_split_pdf_by_size_encrypted_pdf(tmp_path) -> None:
    """暗号化されたPDFファイルのエラーハンドリングテスト"""
    # Given: 暗号化されたPDFファイルと、保存先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "encrypted.pdf")
    output_dir = str(tmp_path)
    max_size = 1000

    # When / Then: 暗号化されたPDFを処理しようとすると ValueError が発生すること
    with pytest.raises(ValueError, match="暗号化されたPDFファイルはサポートされていません"):
        split_pdf_by_size(input_pdf, max_size, output_dir)

def test_split_pdf_by_size_permission_denied(tmp_path) -> None:
    """ファイル読み取り権限がない場合のエラーハンドリングテスト"""
    # Given: 存在するPDFファイルと、保存先ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "ten_pages.pdf")
    output_dir = str(tmp_path)
    max_size = 1000

    # When / Then: os.accessがFalseを返すようにモックして、権限エラーをシミュレート
    with patch('os.access', return_value=False):
        with pytest.raises(ValueError, match="ファイルを読み取る権限がありません"):
            split_pdf_by_size(input_pdf, max_size, output_dir)
