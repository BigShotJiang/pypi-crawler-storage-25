from setuptools import setup, find_packages

setup(
    name="turtlefx",
    version="0.1.0",
    packages=find_packages(),
    description="Creative coding framework built on top of turtle",
    author="Sundaram Gupra",
    license="MIT",
    install_requires=[],
)