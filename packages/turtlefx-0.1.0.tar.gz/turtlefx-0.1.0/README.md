# turtlefx

Creative coding with Python turtle.

## Install
pip install turtlefx

## Example
from turtlefx import *

bgcolor("black")
rainbowmarker(True)
spiral()
done()