## 4.0.5.20260518 (2026-05-18)

Upgrade black to 26.5.0 ([#15801](https://github.com/python/typeshed/pull/15801))

## 4.0.5.20260509 (2026-05-09)

[peewee] Update to 4.0.5 ([#15696](https://github.com/python/typeshed/pull/15696))

## 4.0.1.20260508 (2026-05-08)

Import some items from typing instead of typing_extensions ([#15711](https://github.com/python/typeshed/pull/15711))

Part of #13782

## 4.0.1.20260503 (2026-05-03)

[peewee] add return type to query.count() and the model._meta attribute ([#15691](https://github.com/python/typeshed/pull/15691))

## 4.0.1.20260426 (2026-04-26)

[peewee] Update to 4.0.1 ([#15479](https://github.com/python/typeshed/pull/15479))

## 4.0.0.20260408 (2026-04-08)

Use dashes instead of underscores for METADATA.toml field names ([#15614](https://github.com/python/typeshed/pull/15614))

## 4.0.0.20260402 (2026-04-02)

Rename `requires` to `dependencies` in METADATA files ([#15594](https://github.com/python/typeshed/pull/15594))

Update most test/lint dependencies ([#15582](https://github.com/python/typeshed/pull/15582))

## 4.0.0.20260223 (2026-02-23)

[peewee] Annotate return types ([#15450](https://github.com/python/typeshed/pull/15450))

Add __slots__

## 4.0.0.20260222 (2026-02-22)

[peewee] Update to 4.0.0 ([#15445](https://github.com/python/typeshed/pull/15445))

* Add default values

## 3.19.0.20260109 (2026-01-09)

[stubsabot] Bump peewee to 3.19.0 ([#15230](https://github.com/python/typeshed/pull/15230))

Release: https://pypi.org/pypi/peewee/3.19.0
Repository: https://github.com/coleifer/peewee
Typeshed stubs: https://github.com/python/typeshed/tree/main/stubs/peewee
Changelog: https://github.com/coleifer/peewee/blob/master/CHANGELOG.md
Diff: https://github.com/coleifer/peewee/compare/3.18.3...3.19.0

Stubsabot analysis of the diff between the two releases:
 - 1 public Python file has been added: `playhouse/_pysqlite/__init__.py`.
 - 0 files included in typeshed's stubs have been deleted.
 - 1 file included in typeshed's stubs has been modified or renamed: `peewee.py`.
 - Total lines of Python code added: 86.
 - Total lines of Python code deleted: 121.

If stubtest fails for this PR:
- Leave this PR open (as a reminder, and to prevent stubsabot from opening another PR)
- Fix stubtest failures in another PR, then close this PR

Note that you will need to close and re-open the PR in order to trigger CI

Co-authored-by: stubsabot <>

## 3.18.3.20251105 (2025-11-05)

[stubsabot] Bump peewee to 3.18.3 ([#14976](https://github.com/python/typeshed/pull/14976))

Co-authored-by: stubsabot <>

## 3.18.2.20250710 (2025-07-10)

[stubsabot] Bump peewee to 3.18.2 ([#14385](https://github.com/python/typeshed/pull/14385))

Release: https://pypi.org/pypi/peewee/3.18.2
Homepage: https://github.com/coleifer/peewee/
Repository: https://github.com/coleifer/peewee
Typeshed stubs: https://github.com/python/typeshed/tree/main/stubs/peewee
Diff: https://github.com/coleifer/peewee/compare/3.18.1...3.18.2

Stubsabot analysis of the diff between the two releases:
 - 0 public Python files have been added.
 - 0 files included in typeshed's stubs have been deleted.
 - 1 file included in typeshed's stubs has been modified or renamed: `peewee.py`.
 - Total lines of Python code added: 5.
 - Total lines of Python code deleted: 3.

If stubtest fails for this PR:
- Leave this PR open (as a reminder, and to prevent stubsabot from opening another PR)
- Fix stubtest failures in another PR, then close this PR

Note that you will need to close and re-open the PR in order to trigger CI

Co-authored-by: stubsabot <>

## 3.18.1.20250708 (2025-07-08)

[peewee] Fix type for field operations ([#14275](https://github.com/python/typeshed/pull/14275))

## 3.18.1.20250601 (2025-06-01)

[peewee] Mark field_type as ClassVar ([#14203](https://github.com/python/typeshed/pull/14203))

Should help with #14194

## 3.18.1.20250516 (2025-05-16)

Replace `Incomplete | None = None` in third party stubs ([#14063](https://github.com/python/typeshed/pull/14063))

## 3.18.1.20250512 (2025-05-12)

[stubsabot] Bump peewee to 3.18.1 ([#13910](https://github.com/python/typeshed/pull/13910))

## 3.18.0.20250501 (2025-05-01)

[stubsabot] Bump peewee to 3.18.0 ([#13907](https://github.com/python/typeshed/pull/13907))

## 3.17.9.20250401 (2025-04-01)

Add `__all__` part 2 ([#13719](https://github.com/python/typeshed/pull/13719))

---------

Co-authored-by: Avasam <samuel.06@hotmail.com>

## 3.17.9.20250308 (2025-03-08)

Mark database parameters in Peewee as optional ([#13442](https://github.com/python/typeshed/pull/13442))

Peewee injects database arguments using a decorator whenever a model
or query has a bound connection. Passing the argument is therefore not
required, even for some function parameters without default values.

## 3.17.9.20250210 (2025-02-10)

Bump peewee to 3.17.9 ([#13475](https://github.com/python/typeshed/pull/13475))

## 3.17.8.20241229 (2024-12-29)

Add return type for get_tables() in peewee ([#13230](https://github.com/python/typeshed/pull/13230))

## 3.17.8.20241221 (2024-12-21)

Update to mypy 1.14 ([#13272](https://github.com/python/typeshed/pull/13272))

## 3.17.8.20241117 (2024-11-17)

Bump peewee to 3.17.8 ([#13014](https://github.com/python/typeshed/pull/13014))

## 3.17.7.20241017 (2024-10-17)

[stubsabot] Bump peewee to 3.17.7 ([#12820](https://github.com/python/typeshed/pull/12820))

## 3.17.6.20241014 (2024-10-14)

[peewee] Some methods return `Self` ([#12788](https://github.com/python/typeshed/pull/12788))

## 3.17.6.20240813 (2024-08-13)

Use Generator instead of Iterator for 3rd-party context managers ([#12481](https://github.com/python/typeshed/pull/12481))

## 3.17.6.20240806 (2024-08-06)

Bump mypy to 1.11.1 ([#12463](https://github.com/python/typeshed/pull/12463))

## 3.17.6.20240722 (2024-07-22)

add some missing or incorrect types to peewee ([#12251](https://github.com/python/typeshed/pull/12251))

## 3.17.6.20240712 (2024-07-12)

[stubsabot] Bump peewee to 3.17.6 ([#12290](https://github.com/python/typeshed/pull/12290))

Release: https://pypi.org/pypi/peewee/3.17.6
Homepage: https://github.com/coleifer/peewee/
Repository: https://github.com/coleifer/peewee
Typeshed stubs: https://github.com/python/typeshed/tree/main/stubs/peewee
Diff: https://github.com/coleifer/peewee/compare/3.17.5...3.17.6

Stubsabot analysis of the diff between the two releases:
 - 0 public Python files have been added.
 - 0 files included in typeshed's stubs have been deleted.
 - 1 file included in typeshed's stubs has been modified or renamed: `peewee.py`.
 - Total lines of Python code added: 234.
 - Total lines of Python code deleted: 61.

## 3.17.5.20240626 (2024-06-26)

Bump peewee to 3.17.5 ([#12201](https://github.com/python/typeshed/pull/12201))

## 3.17.3.20240424 (2024-04-24)

Add peewee `playhouse.flask_utils` stubs ([#11731](https://github.com/python/typeshed/pull/11731))

Co-authored-by: Avasam <samuel.06@hotmail.com>
Co-authored-by: Alex Waygood <alex.waygood@gmail.com>

## 3.17.3.20240420 (2024-04-20)

Bump peewee to 3.17.3 and fix stubtest entries ([#11787](https://github.com/python/typeshed/pull/11787))

## 3.17.0.20240311 (2024-03-11)

Use PEP 570 syntax in third party stubs ([#11554](https://github.com/python/typeshed/pull/11554))

## 3.17.0.20240207 (2024-02-07)

Pin peewee more tightly for stubtest ([#11372](https://github.com/python/typeshed/pull/11372))

Fixes  #11367

## 3.17.0.20240118 (2024-01-18)

Added some typings to peewee stubs ([#11284](https://github.com/python/typeshed/pull/11284))

## 3.17.0.0 (2023-10-17)

Bump peewee to 3.17.* ([#10895](https://github.com/python/typeshed/pull/10895))

## 3.16.0.2 (2023-08-15)

Update peewee for 3.16.3 ([#10580](https://github.com/python/typeshed/pull/10580))

## 3.16.0.1 (2023-07-20)

Add an upstream_repository field to METADATA.toml ([#10487](https://github.com/python/typeshed/pull/10487))

Closes: #10478

## 3.16.0.0 (2023-02-28)

Update peewee stubs to v3.16 ([#9827](https://github.com/python/typeshed/pull/9827))

Bump peewee to 3.16.*

Release: https://pypi.org/pypi/peewee/3.16.0
Homepage: https://github.com/coleifer/peewee/
Diff: https://github.com/coleifer/peewee/compare/3.15.4...3.16.0

Stubsabot analysis of the diff between the two releases:
 - 0 public Python files have been added.
 - 0 files included in typeshed's stubs have been deleted.
 - 1 file included in typeshed's stubs has been modified or renamed: `peewee.py`.
 - Total lines of Python code added: 120.
 - Total lines of Python code deleted: 90.

Co-authored-by: Alex Waygood <Alex.Waygood@Gmail.com>

## 3.15.0.8 (2023-02-26)

Improve many `__(a)exit__` annotations ([#9696](https://github.com/python/typeshed/pull/9696))

## 3.15.0.7 (2023-02-21)

Stubtest settings: change `ignore_missing_stub` default to `false` ([#9779](https://github.com/python/typeshed/pull/9779))

If you're reading about this commit from an autogenerated changelog entry, this should have no user-visible impact on how the stubs are interpreted by a type checker; it's just an internal change to how typeshed's tests work.

## 3.15.0.6 (2023-02-15)

Use `typing_extensions.Self` instead of `_typeshed.Self` ([#9702](https://github.com/python/typeshed/pull/9702))

## 3.15.0.5 (2022-11-23)

Mark first argument of `__[get|set|del]attr__` as `str` ([#9245](https://github.com/python/typeshed/pull/9245))

## 3.15.0.4 (2022-11-13)

Make peewee stubs compatible with peewee 3.15.4 ([#9176](https://github.com/python/typeshed/pull/9176))

## 3.15.0.3 (2022-11-09)

All `__nonzero__` are methods that return `bool` ([#9139](https://github.com/python/typeshed/pull/9139))

## 3.15.0.2 (2022-11-09)

Annotate known magic-method return types ([#9131](https://github.com/python/typeshed/pull/9131))

## 3.15.0.1 (2022-11-08)

Fix and allow classes with missing metaclasses ([#9136](https://github.com/python/typeshed/pull/9136))

## 3.15.0.0 (2022-10-04)

Add auto-generated peewee stubs ([#8834](https://github.com/python/typeshed/pull/8834))

