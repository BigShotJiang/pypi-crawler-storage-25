import json
import os
import threading
import time
from typing import Any, Dict, Iterable, List, Optional, Tuple

from openai import OpenAI

from .html_parser import SimpleHTMLTranslator, collect_translatable_items, resolve_prompt_type
from .page_registry import PageRegistry
from .utils import (
    BACKEND_DICT_BOT,
    BACKEND_DICT_SYSTEM,
    BOT_PENDING_FILENAME,
    PENDING_FILENAME,
    SYSTEM_PENDING_FILENAME,
    UI_KEY_PREFIX,
    build_lang_chain,
    compose_backend_storage_key,
    compose_ui_storage_key,
    deep_copy_json_like,
    extract_backend_key,
    extract_json,
    join_leaf_path,
    normalize_backend_dict_name,
    normalize_lang,
    parse_target_langs,
    safe_json_load,
    safe_json_save,
    should_translate,
    should_translate_backend_text,
    should_translate_ui_text,
    split_preserve_whitespace,
)


class Translator:
    def __init__(
        self,
        cache_dir: str = "./translations",
        api_key: Optional[str] = None,
        source_lang: Optional[str] = None,
        model: str = "gpt-4o-mini",
        target_langs: Optional[List[str]] = None,
    ):
        self.source_lang = normalize_lang(source_lang or os.getenv("SOURCE_LANG", "ru"))
        self.cache_dir = cache_dir
        self.client = OpenAI(api_key=api_key or os.getenv("OPENAI_API_KEY"))
        self.model = model
        self.target_langs = parse_target_langs(target_langs, source_lang=self.source_lang)

        self._current_lang: Optional[str] = None
        self._current_file: Optional[str] = None
        self._cache: Dict[str, str] = {}
        self._lock = threading.RLock()
        self._page_registry = PageRegistry()

    # -------------------------------------------------------------------------
    # Paths / storage
    # -------------------------------------------------------------------------

    def _legacy_file_path(self, page_name: str, lang: str) -> str:
        return os.path.join(self.cache_dir, f"{page_name}.{lang}.json")

    def _file_path(self, lang: str) -> str:
        return os.path.join(self.cache_dir, f"{lang}.json")

    def _pending_file_path(self) -> str:
        return os.path.join(self.cache_dir, PENDING_FILENAME)

    def _backend_dir(self) -> str:
        return os.path.join(self.cache_dir, "backend")

    def _backend_file_path(self, dict_name: str, lang: str) -> str:
        dict_name = normalize_backend_dict_name(dict_name)
        lang = self._normalize_lang(lang)
        return os.path.join(self._backend_dir(), f"{dict_name}.{lang}.json")

    def _backend_pending_file_path(self, dict_name: str) -> str:
        dict_name = normalize_backend_dict_name(dict_name)
        filename = BOT_PENDING_FILENAME if dict_name == BACKEND_DICT_BOT else SYSTEM_PENDING_FILENAME
        return os.path.join(self._backend_dir(), filename)

    def _normalize_lang(self, lang: Optional[str]) -> str:
        return normalize_lang(lang, source_lang=self.source_lang)

    def _get_lang_chain(self, target_lang: str) -> List[str]:
        return build_lang_chain(target_lang=target_lang, source_lang=self.source_lang)

    def _normalize_pending_meta(self, storage_key: str, meta: Any) -> Dict[str, str]:
        if isinstance(meta, dict):
            text = str(meta.get("text") or storage_key)
            prompt_type = str(meta.get("prompt_type") or "normal")
        else:
            text = storage_key
            prompt_type = "normal"

        return {
            "text": text,
            "prompt_type": prompt_type,
        }

    def _load_pending(self) -> Dict[str, Dict[str, Dict[str, str]]]:
        data = safe_json_load(self._pending_file_path())
        result: Dict[str, Dict[str, Dict[str, str]]] = {}

        for lang, items in data.items():
            if not isinstance(lang, str) or not isinstance(items, dict):
                continue

            normalized_lang = self._normalize_lang(lang)
            lang_bucket = result.setdefault(normalized_lang, {})

            for storage_key, meta in items.items():
                if not isinstance(storage_key, str):
                    continue
                if storage_key not in lang_bucket:
                    lang_bucket[storage_key] = self._normalize_pending_meta(storage_key, meta)

        return result

    def _save_pending(self, data: Dict[str, Dict[str, Dict[str, str]]]) -> None:
        cleaned = {self._normalize_lang(lang): items for lang, items in data.items() if items}
        safe_json_save(self._pending_file_path(), cleaned)

    def _load_backend_pending(self, dict_name: str) -> Dict[str, Dict[str, Dict[str, str]]]:
        path = self._backend_pending_file_path(dict_name)
        data = safe_json_load(path)
        result: Dict[str, Dict[str, Dict[str, str]]] = {}

        for lang, items in data.items():
            if not isinstance(lang, str) or not isinstance(items, dict):
                continue

            normalized_lang = self._normalize_lang(lang)
            lang_bucket = result.setdefault(normalized_lang, {})

            for storage_key, meta in items.items():
                if not isinstance(storage_key, str):
                    continue
                lang_bucket[storage_key] = self._normalize_pending_meta(storage_key, meta)

        return result

    def _save_backend_pending(self, dict_name: str, data: Dict[str, Dict[str, Dict[str, str]]]) -> None:
        cleaned = {self._normalize_lang(lang): items for lang, items in data.items() if items}
        safe_json_save(self._backend_pending_file_path(dict_name), cleaned)

    def _load_storage(self, page_name: str, lang: str) -> None:
        lang = self._normalize_lang(lang)
        target_path = self._file_path(lang)
        cache = safe_json_load(target_path)

        legacy_path = self._legacy_file_path(page_name, lang)
        legacy_cache = safe_json_load(legacy_path)

        if legacy_cache:
            cache.update({k: v for k, v in legacy_cache.items() if k not in cache})
            safe_json_save(target_path, cache)

        self._cache = cache
        self._current_file = target_path
        self._current_lang = lang

    def _ensure_storage(self, page_name: str, lang: str) -> None:
        lang = self._normalize_lang(lang)
        if self._current_lang != lang or not self._current_file:
            self._load_storage(page_name, lang)

    def _save_storage(self) -> None:
        if self._current_file:
            safe_json_save(self._current_file, self._cache)

    def _load_lang_cache(self, page_name: str, lang: str) -> Dict[str, str]:
        lang = self._normalize_lang(lang)
        path = self._file_path(lang)
        cache = safe_json_load(path)

        legacy_path = self._legacy_file_path(page_name, lang)
        legacy_cache = safe_json_load(legacy_path)
        if legacy_cache:
            cache.update({k: v for k, v in legacy_cache.items() if k not in cache})

        return cache

    def _load_backend_lang_cache(self, dict_name: str, lang: str) -> Dict[str, str]:
        return safe_json_load(self._backend_file_path(dict_name, lang))

    def _save_backend_lang_cache(self, dict_name: str, lang: str, data: Dict[str, str]) -> None:
        safe_json_save(self._backend_file_path(dict_name, lang), data)

    def _get_from_cache_chain(self, key: str, page_name: str, target_lang: str) -> Optional[str]:
        for lang in self._get_lang_chain(target_lang):
            cache = self._load_lang_cache(page_name=page_name, lang=lang)
            if key in cache:
                return cache[key]
        return None

    def _get_backend_from_cache_chain(self, storage_key: str, dict_name: str, target_lang: str) -> Optional[str]:
        for lang in self._get_lang_chain(target_lang):
            cache = self._load_backend_lang_cache(dict_name=dict_name, lang=lang)
            if storage_key in cache:
                return cache[storage_key]
        return None

    def _resolve_target_langs(self, target_langs: Optional[List[str]] = None) -> List[str]:
        langs = parse_target_langs(target_langs, source_lang=self.source_lang)
        if langs:
            return langs
        return list(self.target_langs)

    # -------------------------------------------------------------------------
    # OpenAI translation
    # -------------------------------------------------------------------------

    def _build_single_prompt(self, text: str, target_lang: str, prompt_type: str = "normal") -> str:
        if prompt_type == "button":
            return (
                f"Translate the UI button label from {self.source_lang} to {target_lang}. "
                f"Return only the translation, without explanations.\n\n{text}"
            )

        if prompt_type == "attr":
            return (
                f"Translate the UI attribute text from {self.source_lang} to {target_lang}. "
                f"Return only the translation, without explanations.\n\n{text}"
            )

        if prompt_type == "ui":
            return (
                f"Translate the frontend UI string from {self.source_lang} to {target_lang}. "
                f"Return only the translation, without explanations.\n\n{text}"
            )

        if prompt_type == "backend":
            return (
                f"Translate the backend system phrase from {self.source_lang} to {target_lang}. "
                f"Return only the translation, without explanations.\n\n{text}"
            )

        return (
            f"Translate the text from {self.source_lang} to {target_lang}. "
            f"Return only the translation, without explanations.\n\n{text}"
        )

    def _translate_via_api(self, prompt: str) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
        )
        return (response.choices[0].message.content or "").strip()

    def _translate_single(self, text: str, target_lang: str, prompt_type: str = "normal") -> str:
        prompt = self._build_single_prompt(text, target_lang, prompt_type)
        translated = self._translate_via_api(prompt)
        return translated or text

    def _translate_batch(self, items: List[Dict[str, str]], target_lang: str) -> Dict[str, str]:
        if not items:
            return {}

        payload = [
            {
                "id": idx,
                "storage_key": item["storage_key"],
                "text": item["text"],
                "kind": item["prompt_type"],
            }
            for idx, item in enumerate(items, start=1)
        ]

        prompt = (
            f"Translate each item from {self.source_lang} to {target_lang}.\n"
            f"Rules:\n"
            f"- Return STRICT JSON object only.\n"
            f"- Format: {{\"items\": [{{\"id\": 1, \"translated\": \"...\"}}]}}\n"
            f"- Keep meaning precise.\n"
            f"- For buttons and frontend UI labels keep text concise.\n"
            f"- For backend/system phrases keep placeholders, variable names and formatting unchanged.\n"
            f"- Do not omit any item.\n"
            f"- Do not add comments.\n\n"
            f"Input JSON:\n{json.dumps(payload, ensure_ascii=False)}"
        )

        raw = self._translate_via_api(prompt)
        parsed = extract_json(raw)

        result: Dict[str, str] = {}
        translated_items = parsed.get("items", []) if isinstance(parsed, dict) else []

        by_id: Dict[int, str] = {}
        for item in translated_items:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            translated = item.get("translated")
            if isinstance(item_id, int) and isinstance(translated, str):
                by_id[item_id] = translated.strip()

        for idx, item in enumerate(items, start=1):
            result[item["storage_key"]] = by_id.get(idx) or item["text"]

        return result

    # -------------------------------------------------------------------------
    # Public registration API
    # -------------------------------------------------------------------------

    def register_page(
        self,
        page_name: str,
        html_getter,
        target_langs: List[str],
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        normalized_langs = [self._normalize_lang(lang) for lang in target_langs]
        self._page_registry.register_page(
            page_name=page_name,
            html_getter=html_getter,
            target_langs=normalized_langs,
            context=context or {},
        )

    def register_keys(
        self,
        items: Dict[str, str],
        dict_name: str = BACKEND_DICT_BOT,
        target_langs: Optional[List[str]] = None,
    ) -> int:
        dict_name = normalize_backend_dict_name(dict_name)

        if not isinstance(items, dict):
            raise TypeError("items must be a dict")

        langs = self._resolve_target_langs(target_langs)
        if not langs:
            return 0

        source_cache = self._load_backend_lang_cache(dict_name=dict_name, lang=self.source_lang)
        pending = self._load_backend_pending(dict_name)
        added = 0

        for key, default_text in items.items():
            if default_text is None:
                continue

            normalized_key = str(key).strip()
            normalized_text = str(default_text).strip()

            if not normalized_key:
                continue

            if not normalized_text or not should_translate_backend_text(normalized_text):
                continue

            storage_key = compose_backend_storage_key(normalized_key)
            source_cache[storage_key] = normalized_text

            for lang in langs:
                if lang == self.source_lang:
                    continue

                lang_cache = self._load_backend_lang_cache(dict_name=dict_name, lang=lang)
                lang_bucket = pending.setdefault(lang, {})

                if storage_key in lang_cache or storage_key in lang_bucket:
                    continue

                lang_bucket[storage_key] = {
                    "text": normalized_text,
                    "prompt_type": "backend",
                }
                added += 1

        self._save_backend_lang_cache(dict_name=dict_name, lang=self.source_lang, data=source_cache)
        self._save_backend_pending(dict_name=dict_name, data=pending)
        return added

    def scan_page(self, page_name: str, target_lang: str) -> List[Tuple[str, str]]:
        target_lang = self._normalize_lang(target_lang)
        page = self._page_registry.get_page(page_name)
        html = page.html_getter(**(page.context or {}))
        if not isinstance(html, str):
            raise TypeError(f"html_getter for page '{page_name}' must return str")

        items = collect_translatable_items(html)
        cache = self._load_lang_cache(page_name=page_name, lang=target_lang)

        missing: List[Tuple[str, str]] = []
        for text, prompt_type in items:
            if text not in cache:
                missing.append((text, prompt_type))

        return missing

    def scan_all_pages(self) -> Dict[str, Dict[str, List[Tuple[str, str]]]]:
        result: Dict[str, Dict[str, List[Tuple[str, str]]]] = {}

        for page in self._page_registry.list_pages():
            page_result: Dict[str, List[Tuple[str, str]]] = {}
            for lang in page.target_langs:
                missing = self.scan_page(page.page_name, lang)
                if missing:
                    page_result[lang] = missing
            if page_result:
                result[page.page_name] = page_result

        return result

    def process_page_translations(self, page_name: str, target_lang: str, batch_size: int = 50) -> int:
        missing = self.scan_page(page_name, target_lang)
        if not missing:
            return 0

        self.enqueue_missing_texts(missing, target_lang=target_lang, page_name=page_name)
        return self.process_pending_translations(
            target_lang=target_lang,
            page_name=page_name,
            batch_size=batch_size,
        )

    def process_all_translations(self, batch_size: int = 50) -> Dict[str, Dict[str, int]]:
        report: Dict[str, Dict[str, int]] = {}

        for page in self._page_registry.list_pages():
            page_report: Dict[str, int] = {}
            for lang in page.target_langs:
                processed = self.process_page_translations(page.page_name, lang, batch_size=batch_size)
                if processed:
                    page_report[lang] = processed
            if page_report:
                report[page.page_name] = page_report

        backend_report = self.process_all_backend_key_translations(batch_size=batch_size)
        if backend_report:
            report["_backend_keys"] = backend_report

        return report

    # -------------------------------------------------------------------------
    # Queue / pending
    # -------------------------------------------------------------------------

    def enqueue_missing_texts(
        self,
        texts: Iterable,
        target_lang: str,
        page_name: str = "page",
    ) -> int:
        target_lang = self._normalize_lang(target_lang)

        if not target_lang or target_lang == self.source_lang:
            return 0

        with self._lock:
            self._ensure_storage(page_name, target_lang)
            pending = self._load_pending()
            bucket = pending.setdefault(target_lang, {})
            added = 0

            for item in texts:
                storage_key: Optional[str] = None
                text: Optional[str] = None
                prompt_type = "normal"
                is_ui = False

                if isinstance(item, dict):
                    storage_key = item.get("storage_key")
                    text = item.get("text")
                    prompt_type = str(item.get("prompt_type") or "normal")
                    is_ui = prompt_type == "ui" or str(storage_key or "").startswith(UI_KEY_PREFIX)

                elif isinstance(item, tuple):
                    if len(item) == 3:
                        text, tag, attr_name = item
                        prompt_type = resolve_prompt_type(tag, attr_name)
                        storage_key = str(text)
                    elif len(item) == 2:
                        text, prompt_type = item
                        storage_key = str(text)
                    else:
                        continue
                else:
                    text = item
                    storage_key = str(item)

                if text is None:
                    continue

                text = str(text)
                storage_key = str(storage_key or text)

                if is_ui:
                    candidate = text.strip()
                    if not candidate or not should_translate_ui_text(candidate):
                        continue
                    normalized_text = candidate
                else:
                    _, core, _ = split_preserve_whitespace(text)
                    if not core or not should_translate(core):
                        continue
                    normalized_text = core

                if storage_key in self._cache or storage_key in bucket:
                    continue

                bucket[storage_key] = {
                    "text": normalized_text,
                    "prompt_type": prompt_type,
                }
                added += 1

            self._save_pending(pending)
            return added

    def enqueue_backend_missing_keys(
        self,
        items: Dict[str, str],
        target_lang: str,
        dict_name: str = BACKEND_DICT_BOT,
    ) -> int:
        dict_name = normalize_backend_dict_name(dict_name)
        target_lang = self._normalize_lang(target_lang)

        if not target_lang or target_lang == self.source_lang:
            return 0

        cache = self._load_backend_lang_cache(dict_name=dict_name, lang=target_lang)
        pending = self._load_backend_pending(dict_name)
        bucket = pending.setdefault(target_lang, {})
        added = 0

        for key, default_text in items.items():
            storage_key = compose_backend_storage_key(key)
            text = str(default_text or "").strip()

            if not text or not should_translate_backend_text(text):
                continue

            if storage_key in cache or storage_key in bucket:
                continue

            bucket[storage_key] = {
                "text": text,
                "prompt_type": "backend",
            }
            added += 1

        self._save_backend_pending(dict_name=dict_name, data=pending)
        return added

    def get_pending_entries(self, target_lang: Optional[str] = None) -> Dict[str, Dict[str, Dict[str, str]]]:
        pending = self._load_pending()
        if target_lang:
            target_lang = self._normalize_lang(target_lang)
            return {target_lang: pending.get(target_lang, {})}
        return pending

    def get_backend_pending_entries(
        self,
        dict_name: str = BACKEND_DICT_BOT,
        target_lang: Optional[str] = None,
    ) -> Dict[str, Dict[str, Dict[str, str]]]:
        dict_name = normalize_backend_dict_name(dict_name)
        pending = self._load_backend_pending(dict_name)
        if target_lang:
            target_lang = self._normalize_lang(target_lang)
            return {target_lang: pending.get(target_lang, {})}
        return pending

    def process_pending_translations(
        self,
        target_lang: Optional[str] = None,
        page_name: str = "page",
        batch_size: int = 50,
    ) -> int:
        with self._lock:
            pending = self._load_pending()
            langs = [self._normalize_lang(target_lang)] if target_lang else list(pending.keys())
            processed_total = 0

            for lang in langs:
                bucket = pending.get(lang, {})
                if not bucket:
                    continue

                self._ensure_storage(page_name, lang)

                items: List[Dict[str, str]] = []
                keys_for_remove: List[str] = []

                for storage_key, meta in bucket.items():
                    if storage_key in self._cache:
                        keys_for_remove.append(storage_key)
                        continue

                    text = str(meta.get("text") or storage_key)
                    prompt_type = str(meta.get("prompt_type") or "normal")

                    items.append(
                        {
                            "storage_key": storage_key,
                            "text": text,
                            "prompt_type": prompt_type,
                        }
                    )
                    if len(items) >= batch_size:
                        break

                for storage_key in keys_for_remove:
                    bucket.pop(storage_key, None)

                if not items:
                    if not bucket:
                        pending.pop(lang, None)
                    continue

                short_items = []
                long_items = []

                for item in items:
                    if len(item["text"]) > 3000:
                        long_items.append(item)
                    else:
                        short_items.append(item)

                translated_map: Dict[str, str] = {}

                if short_items:
                    translated_map.update(self._translate_batch(short_items, lang))

                for item in long_items:
                    translated_map[item["storage_key"]] = self._translate_single(
                        item["text"],
                        lang,
                        prompt_type=item["prompt_type"],
                    )

                if translated_map:
                    self._cache.update(translated_map)
                    self._save_storage()

                    for item in items:
                        bucket.pop(item["storage_key"], None)

                    processed_total += len(items)

                if not bucket:
                    pending.pop(lang, None)

            self._save_pending(pending)
            return processed_total

    def process_backend_key_translations(
        self,
        dict_name: str = BACKEND_DICT_BOT,
        target_lang: Optional[str] = None,
        batch_size: int = 50,
    ) -> int:
        dict_name = normalize_backend_dict_name(dict_name)

        with self._lock:
            pending = self._load_backend_pending(dict_name)
            langs = [self._normalize_lang(target_lang)] if target_lang else list(pending.keys())
            processed_total = 0

            for lang in langs:
                bucket = pending.get(lang, {})
                if not bucket:
                    continue

                cache = self._load_backend_lang_cache(dict_name=dict_name, lang=lang)
                items: List[Dict[str, str]] = []
                keys_for_remove: List[str] = []

                for storage_key, meta in bucket.items():
                    if storage_key in cache:
                        keys_for_remove.append(storage_key)
                        continue

                    items.append(
                        {
                            "storage_key": storage_key,
                            "text": str(meta.get("text") or extract_backend_key(storage_key)),
                            "prompt_type": str(meta.get("prompt_type") or "backend"),
                        }
                    )
                    if len(items) >= batch_size:
                        break

                for storage_key in keys_for_remove:
                    bucket.pop(storage_key, None)

                if not items:
                    if not bucket:
                        pending.pop(lang, None)
                    continue

                short_items = []
                long_items = []

                for item in items:
                    if len(item["text"]) > 3000:
                        long_items.append(item)
                    else:
                        short_items.append(item)

                translated_map: Dict[str, str] = {}

                if short_items:
                    translated_map.update(self._translate_batch(short_items, lang))

                for item in long_items:
                    translated_map[item["storage_key"]] = self._translate_single(
                        item["text"],
                        lang,
                        prompt_type=item["prompt_type"],
                    )

                if translated_map:
                    cache.update(translated_map)
                    self._save_backend_lang_cache(dict_name=dict_name, lang=lang, data=cache)

                    for item in items:
                        bucket.pop(item["storage_key"], None)

                    processed_total += len(items)

                if not bucket:
                    pending.pop(lang, None)

            self._save_backend_pending(dict_name=dict_name, data=pending)
            return processed_total

    def process_all_backend_key_translations(self, batch_size: int = 50) -> Dict[str, int]:
        report: Dict[str, int] = {}

        for dict_name in (BACKEND_DICT_BOT, BACKEND_DICT_SYSTEM):
            processed = self.process_backend_key_translations(
                dict_name=dict_name,
                batch_size=batch_size,
            )
            if processed:
                report[dict_name] = processed

        return report

    def run_translation_loop(
        self,
        interval: int = 300,
        target_lang: Optional[str] = None,
        page_name: str = "page",
        stop_event: Optional[threading.Event] = None,
        batch_size: int = 50,
    ) -> None:
        if interval <= 0:
            raise ValueError("interval must be > 0")

        while True:
            try:
                if self._page_registry.list_pages() and target_lang is None:
                    self.process_all_translations(batch_size=batch_size)
                else:
                    self.process_pending_translations(
                        target_lang=target_lang,
                        page_name=page_name,
                        batch_size=batch_size,
                    )
                    self.process_backend_key_translations(
                        dict_name=BACKEND_DICT_BOT,
                        target_lang=target_lang,
                        batch_size=batch_size,
                    )
                    self.process_backend_key_translations(
                        dict_name=BACKEND_DICT_SYSTEM,
                        target_lang=target_lang,
                        batch_size=batch_size,
                    )
            except Exception:
                pass

            if stop_event and stop_event.is_set():
                break

            time.sleep(interval)

            if stop_event and stop_event.is_set():
                break

    # -------------------------------------------------------------------------
    # Translate API
    # -------------------------------------------------------------------------

    def translate_text(
        self,
        text: str,
        target_lang: str,
        page_name: str = "page",
        prompt_type: str = "normal",
    ) -> str:
        if text is None:
            return text

        original = text
        leading, core, trailing = split_preserve_whitespace(original)

        if not core:
            return original

        target_lang = self._normalize_lang(target_lang)

        if target_lang == self.source_lang:
            return original

        if not should_translate(core):
            return original

        translated = self._get_from_cache_chain(core, page_name=page_name, target_lang=target_lang)
        if translated is not None:
            return f"{leading}{translated}{trailing}"

        self._ensure_storage(page_name, target_lang)
        self.enqueue_missing_texts([(core, prompt_type)], target_lang=target_lang, page_name=page_name)
        return original

    def translate_key(
        self,
        key: str,
        lang: str,
        default: str,
        dict_name: str = BACKEND_DICT_BOT,
    ) -> str:
        dict_name = normalize_backend_dict_name(dict_name)

        normalized_key = str(key or "").strip()
        default_text = str(default or "").strip()
        target_lang = self._normalize_lang(lang)

        if not normalized_key:
            return default

        if target_lang == self.source_lang:
            return default

        storage_key = compose_backend_storage_key(normalized_key)
        translated = self._get_backend_from_cache_chain(
            storage_key=storage_key,
            dict_name=dict_name,
            target_lang=target_lang,
        )
        if translated is not None:
            return translated

        if default_text:
            self.register_keys({normalized_key: default_text}, dict_name=dict_name)
            self.enqueue_backend_missing_keys(
                {normalized_key: default_text},
                target_lang=target_lang,
                dict_name=dict_name,
            )

        return default

    def translate_html(self, html: str, target_lang: str, page_name: str = "page") -> str:
        target_lang = self._normalize_lang(target_lang)

        if target_lang == self.source_lang:
            return html

        self._ensure_storage(page_name, target_lang)

        collected: List[Tuple[str, Optional[str], Optional[str]]] = []
        seen = set()

        def collector(text: str, tag: Optional[str], attr_name: Optional[str]) -> str:
            translated = self._get_from_cache_chain(text, page_name=page_name, target_lang=target_lang)
            if translated is not None:
                return translated

            key = (text, tag, attr_name)
            if key not in seen:
                seen.add(key)
                collected.append(key)

            return text

        pre_parser = SimpleHTMLTranslator(translate_callback=collector)
        pre_parser.feed(html)
        pre_parser.close()

        if collected:
            self.enqueue_missing_texts(collected, target_lang=target_lang, page_name=page_name)

        def renderer(text: str, tag: Optional[str], attr_name: Optional[str]) -> str:
            translated = self._get_from_cache_chain(text, page_name=page_name, target_lang=target_lang)
            return translated if translated is not None else text

        parser = SimpleHTMLTranslator(translate_callback=renderer)
        parser.feed(html)
        parser.close()
        return parser.get_html()

    def translate_dict(
        self,
        page_name: str,
        dict_name: str,
        source_dict: dict,
        target_lang: Optional[str] = None,
        filter_keys: Optional[List[str]] = None,
    ) -> dict:
        if source_dict is None:
            return {}

        if not isinstance(source_dict, dict):
            raise TypeError("source_dict must be a dict")

        target_lang = self._normalize_lang(target_lang)

        if not target_lang or target_lang == self.source_lang:
            return deep_copy_json_like(source_dict)

        self._ensure_storage(page_name, target_lang)

        filter_keys_set = set(filter_keys or [])
        collected: List[Dict[str, str]] = []

        def walk(value: Any, path_parts: List[str]) -> Any:
            if isinstance(value, dict):
                result = {}
                for key, inner_value in value.items():
                    result[key] = walk(inner_value, path_parts + [str(key)])
                return result

            if isinstance(value, list):
                result = []
                for index, inner_value in enumerate(value):
                    result.append(walk(inner_value, path_parts + [str(index)]))
                return result

            if isinstance(value, str):
                if filter_keys_set and path_parts:
                    if path_parts[-1] not in filter_keys_set:
                        return value

                if not should_translate_ui_text(value):
                    return value

                storage_key = compose_ui_storage_key(
                    page_name=page_name,
                    dict_name=dict_name,
                    leaf_key=join_leaf_path(path_parts),
                )

                translated = self._get_from_cache_chain(
                    storage_key,
                    page_name=page_name,
                    target_lang=target_lang,
                )
                if translated is not None:
                    return translated

                collected.append(
                    {
                        "storage_key": storage_key,
                        "text": value.strip(),
                        "prompt_type": "ui",
                    }
                )
                return value

            return value

        translated = walk(deep_copy_json_like(source_dict), [])

        if collected:
            self.enqueue_missing_texts(
                collected,
                target_lang=target_lang,
                page_name=page_name,
            )

        return translated

    # -------------------------------------------------------------------------
    # Coverage / helper API
    # -------------------------------------------------------------------------

    def get_translation_coverage(self, lang: str) -> dict:
        lang = self._normalize_lang(lang)

        cache = self._load_lang_cache(page_name="page", lang=lang)
        pending = self._load_pending().get(lang, {})

        total = len(cache) + len(pending)
        percent = 100.0 if total == 0 else round((len(cache) / total) * 100, 2)

        return {
            "lang": lang,
            "translated": len(cache),
            "pending": len(pending),
            "total": total,
            "percent": percent,
        }

    def get_backend_translation_coverage(
        self,
        lang: str,
        dict_name: str = BACKEND_DICT_BOT,
    ) -> dict:
        dict_name = normalize_backend_dict_name(dict_name)
        lang = self._normalize_lang(lang)

        cache = self._load_backend_lang_cache(dict_name=dict_name, lang=lang)
        pending = self._load_backend_pending(dict_name).get(lang, {})

        total = len(cache) + len(pending)
        percent = 100.0 if total == 0 else round((len(cache) / total) * 100, 2)

        return {
            "dict_name": dict_name,
            "lang": lang,
            "translated": len(cache),
            "pending": len(pending),
            "total": total,
            "percent": percent,
        }

    def detect_browser_lang(self, accept_language: str) -> str:
        if not accept_language:
            return self.source_lang

        lang = accept_language.split(",")[0]
        return self._normalize_lang(lang)

    def get_alternative_lang(self, current_lang: str, browser_lang: str) -> str:
        current_lang = self._normalize_lang(current_lang)
        browser_lang = self._normalize_lang(browser_lang)

        if not browser_lang:
            return "en" if current_lang == self.source_lang else self.source_lang

        if current_lang == browser_lang:
            return "en" if current_lang != "en" else self.source_lang

        return browser_lang