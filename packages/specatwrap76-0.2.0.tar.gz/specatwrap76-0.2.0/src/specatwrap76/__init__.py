"""
Specatwrap - A wrapper for processing healthcare data.

This module provides a CLI for converting and processing healthcare data files.
"""

import click

from .sas_converter import sas2parquet
from .prep import prep
from .sas_preview import preview
from .printable import print_file


@click.group()
@click.version_option(version="0.1.0")
def cli():
    """
    Specatwrap - A wrapper for processing healthcare data.

    A command-line tool for processing and converting healthcare data files.
    """
    pass


# Register command groups
cli.add_command(sas2parquet)
cli.add_command(prep)
cli.add_command(preview)
cli.add_command(print_file)


def main():
    """Entry point for the CLI application."""
    cli()


if __name__ == "__main__":
    main()
