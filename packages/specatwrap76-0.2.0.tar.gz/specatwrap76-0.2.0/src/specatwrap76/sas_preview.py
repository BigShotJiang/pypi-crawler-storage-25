"""
SAS file preview module.

This module provides functionality to quickly preview the first N rows
of a SAS7BDAT file for inspection purposes.
"""

import click
from pathlib import Path
import sys
import pyreadstat


@click.command()
@click.argument("input_file", type=click.Path(exists=True, path_type=Path))
@click.option(
    "-n",
    "--num-rows",
    type=int,
    default=10,
    help="Number of rows to display (default: 10)",
)
@click.option(
    "--encoding",
    type=str,
    default=None,
    help="File encoding (default: auto-detect)",
)
def preview(input_file, num_rows, encoding):
    """
    Preview the first N rows of a SAS file.

    INPUT_FILE: Path to the SAS file (.sas7bdat)

    This command quickly reads and displays the first few rows of a SAS file
    to help you inspect the data structure and content without converting
    the entire file.

    Example usage:

        specatwrap preview input.sas7bdat

        specatwrap preview input.sas7bdat --num-rows 20

        specatwrap preview input.sas7bdat --encoding latin1
    """
    try:
        # Validate file exists
        if not input_file.exists():
            click.secho(f"✗ Error: File not found: {input_file}", fg="red", err=True)
            sys.exit(1)

        if input_file.suffix.lower() != ".sas7bdat":
            click.secho(
                "✗ Error: Input file must be a .sas7bdat file", fg="red", err=True
            )
            sys.exit(1)

        click.echo(f"Reading first {num_rows} rows from: {input_file.name}")
        click.echo()

        # Read first N rows using pyreadstat
        df, meta = pyreadstat.read_sas7bdat(
            str(input_file),
            row_limit=num_rows,
            encoding=encoding,
            output_format="polars",
        )

        # Display metadata
        click.echo(f"Total columns: {len(meta.column_names)}")
        click.echo(f"Column names: {', '.join(meta.column_names)}")
        if encoding:
            click.echo(f"Encoding: {encoding}")
        click.echo()

        # Display the data using Polars' pretty print
        click.echo(str(df))
        click.echo()
        click.secho(f"✓ Showing {len(df)} row(s)", fg="green")

    except FileNotFoundError as e:
        click.secho(f"✗ Error: File not found - {e}", fg="red", err=True)
        sys.exit(1)
    except PermissionError as e:
        click.secho(f"✗ Error: Permission denied - {e}", fg="red", err=True)
        sys.exit(1)
    except ValueError as e:
        click.secho(f"✗ Error: Invalid input - {e}", fg="red", err=True)
        sys.exit(1)
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg="red", err=True)
        sys.exit(1)
