import polars as pl

lf = pl.scan_parquet("diag.parquet")
lf_death = pl.scan_parquet("death.parquet")

lf_death = lf_death.rename(
    {"PNR": "case:PNR", "DODDATO": "startTime"}
).with_columns(
    pl.lit("Death").alias("TDiag"),
    pl.lit("Death").alias("ADiag"),
    pl.col("startTime").cast(pl.Datetime("us")).dt.offset_by("1d").dt.offset_by("-1us"),
)  # Shift death events to just before the next day to ensure they are ordered after any diagnoses on the same day

lf = pl.concat([lf, lf_death], how="diagonal").sort(["case:PNR", "startTime"])
lf.sink_parquet("combined_diag_death.parquet")
