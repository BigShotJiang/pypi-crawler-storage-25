import polars as pl

# Assuming df is your DataFrame and 'TDiag' is the column
df = df.with_columns(
    pl.when(pl.col("TDiag").str.starts_with("CANCER"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CANCER3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("CARDIOVASCULAR"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CARDIOVASCULAR3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("MUSCULOSKELETAL"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 2)
        .then(pl.lit("MUSCULOSKELETAL2+"))
        .otherwise(pl.col("TDiag"))
    )
    .otherwise(pl.col("TDiag"))
    .alias("TDiag")
)
