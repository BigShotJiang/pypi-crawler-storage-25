import pm4py
import polars as pl
from pm4py.algo.filtering.dfg import dfg_filtering
from pm4py.visualization.dfg import visualizer as dfg_vis


def print_stats(pdf):
    cols = {
        "mortality": "case:mortality",
        "diagnosis count": "case:diagnosis_count",
        "duration": "case:duration",
    }

    print(f"{'Metric':.<20} | {'Mean':>10} | {'Median':>10}")
    print("-" * 46)

    for label, col in cols.items():
        mean_val = pdf[col].mean()

        med_val = pdf[col].median()
        print(f"{label:.<20} | {mean_val:>10.2f} | {med_val:>10.2f}")

    count = pdf["case:PNR"].nunique()
    print("-" * 46)
    print(f"{'Unique cases':.<20} : {count}")


def view(
    df,
    case_id_key="case:PNR",
    activity_key="TDiag",
    timestamp_key="startTime",
    path_filter=0.25,
):
    pdf = df.to_pandas()
    pdf["case:concept:name"] = pdf[case_id_key]
    pdf["concept:name"] = pdf[activity_key]
    pdf["time:timestamp"] = pdf[timestamp_key]

    dfg, sa, ea = pm4py.discover_dfg(pdf)

    activities_count = pm4py.get_event_attribute_values(pdf, "concept:name")

    dfg, sa, ea, activities_count = dfg_filtering.filter_dfg_on_paths_percentage(
        dfg, sa, ea, activities_count, path_filter
    )

    dfg_vis.view(dfg_vis.apply(dfg))
    print_stats(pdf)


def view_starts(df):
    for x in ["CANCER", "CARDIO", "MUSCU"]:
        print(x)
        df_tmp = df.filter(pl.col("TDiag").str.starts_with(x)).first().over("case:PNR")
        view(df_tmp)
