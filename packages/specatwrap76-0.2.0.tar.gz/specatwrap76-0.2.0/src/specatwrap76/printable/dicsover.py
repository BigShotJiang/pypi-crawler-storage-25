from pm4py.algo.discovery.dfg import algorithm as dfg_discovery
from pm4py.algo.filtering.dfg import dfg_filtering

# 1. Discover Frequency (for filtering logic)
dfg_freq = dfg_discovery.apply(pdf, variant=dfg_discovery.Variants.FREQUENCY)

# 2. Discover Performance (for visualization data)

dfg_perf = dfg_discovery.apply(pdf, variant=dfg_discovery.Variants.PERFORMANCE)


# 3. Filter based on frequency (keep top 25% of paths)
dfg_freq_filt, sa, ea, activities_count = dfg_filtering.filter_dfg_on_paths_percentage(
    dfg_freq, sa, ea, activities_count, 0.25
)


# 4. Align the Performance DFG to only include paths kept in the Frequency DFG
dfg_perf_filt = {k: v for k, v in dfg_perf.items() if k in dfg_freq_filt}


# 5. Visualize the filtered Performance map
gviz = dfg_visualizer.apply(
    dfg_perf_filt, 
    variant=dfg_visualizer.Variants.PERFORMANCE,
    parameters={"aggregationMeasure": "mean"}
)
dfg_visualizer.view(gviz)
