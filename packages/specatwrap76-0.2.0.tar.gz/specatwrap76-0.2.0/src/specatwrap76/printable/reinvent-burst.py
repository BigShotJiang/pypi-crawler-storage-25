import polars as pl

lf: pl.LazyFrame = None
# {{paste:begin}}

# {{paste:reinvent}}

# {{paste:burst}}
