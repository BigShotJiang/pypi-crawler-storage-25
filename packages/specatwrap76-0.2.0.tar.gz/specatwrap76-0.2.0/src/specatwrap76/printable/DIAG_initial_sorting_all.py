import polars as pl

# {{paste:begin}}
allowed_events = ["MUSCULOSKELETAL", "CARDIOVASCULAR", "CANCER"]

lf = (
    pl.scan_parquet(r"..\combined_diag_death.parquet")
    .filter(pl.col("TDiag").is_in(allowed_events).any().over("case:PNR"))
    .filter(
        # If contains Death then it must be the last
        ~((pl.col("TDiag") == "Death").any().over("case:PNR"))
        | ((pl.col("TDiag") == "Death").last().over("case:PNR"))
    )
    .unique(subset=["case:PNR", "ADiag"], keep="first", maintain_order=True)
).filter((pl.col("TDiag") == "Death").last().over("case:PNR"))
