import glob
import contextlib
import os
import shutil
import subprocess
import sys
import time
import uuid
import tempfile
import pathutilx as p
import setuptools.build_meta as build_backend


ROOT_DIR = p.cwd()
DIST_DIR = p.resolve("dist", base=ROOT_DIR)
EGG_INFO_DIR = p.resolve("projectme_lib.egg-info", base=ROOT_DIR)
DEV_TMP_DIR = p.resolve(".dev_tmp", base=ROOT_DIR)


def run(cmd, env=None):
    print(f">>> {' '.join(cmd)}")
    subprocess.run(cmd, check=True, env=env)


def clean():
    print(">>> Cleaning dist/ and .egg-info/")
    if DIST_DIR.exists():
        for artifact in glob.glob(str(p.resolve("*", base=DIST_DIR))):
            artifact_path = p.resolve(artifact, base=ROOT_DIR)
            try:
                if artifact_path.is_dir():
                    shutil.rmtree(artifact_path)
                else:
                    artifact_path.unlink()
            except PermissionError:
                print(f">>> Skipping locked artifact: {artifact_path}")

    if EGG_INFO_DIR.exists():
        try:
            shutil.rmtree(EGG_INFO_DIR)
        except PermissionError:
            print(f">>> Skipping locked metadata directory: {EGG_INFO_DIR}")
    print(">>> Cleaned successfully.")


def build_environment():
    DEV_TMP_DIR.mkdir(parents=True, exist_ok=True)
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env["TEMP"] = str(DEV_TMP_DIR)
    env["TMP"] = str(DEV_TMP_DIR)
    return env


def local_mkdtemp(suffix="", prefix="tmp", dir=None):
    base_dir = p.resolve(dir, base=ROOT_DIR) if dir else DEV_TMP_DIR
    while True:
        temp_dir = p.resolve(f"{prefix}{uuid.uuid4().hex}{suffix}", base=base_dir)
        if not temp_dir.exists():
            temp_dir.mkdir(parents=True, exist_ok=False)
            return str(temp_dir)


class LocalTemporaryDirectory:
    def __init__(self, suffix="", prefix="tmp", dir=None, ignore_cleanup_errors=False):
        self.name = local_mkdtemp(suffix=suffix, prefix=prefix, dir=dir)
        self._ignore_cleanup_errors = ignore_cleanup_errors

    def __enter__(self):
        return self.name

    def __exit__(self, exc_type, exc_value, traceback):
        self.cleanup()

    def cleanup(self):
        shutil.rmtree(self.name, ignore_errors=self._ignore_cleanup_errors)


@contextlib.contextmanager
def local_tempdirs():
    original_mkdtemp = tempfile.mkdtemp
    original_tempdir_class = tempfile.TemporaryDirectory

    tempfile.mkdtemp = local_mkdtemp
    tempfile.TemporaryDirectory = LocalTemporaryDirectory
    try:
        yield
    finally:
        tempfile.mkdtemp = original_mkdtemp
        tempfile.TemporaryDirectory = original_tempdir_class


def build_distributions():
    with local_tempdirs():
        print(">>> Building source distribution")
        sdist_name = build_backend.build_sdist(str(DIST_DIR))
        print(">>> Building wheel")
        wheel_name = build_backend.build_wheel(str(DIST_DIR))
    return [str(p.resolve(sdist_name, base=DIST_DIR)), str(p.resolve(wheel_name, base=DIST_DIR))]


def build_and_upload():
    env = build_environment()

    try:
        files = build_distributions()
        if not files:
            files = glob.glob(str(p.resolve("*", base=DIST_DIR)))

        if not files:
            print(">>> No files found in dist/")
            return

        print(">>> Files:")
        for file_path in files:
            print(f" - {file_path}")

        run([sys.executable, "-m", "twine", "check", *files], env=env)
        run([sys.executable, "-m", "twine", "upload", *files], env=env)

        print(">>> Build and upload completed successfully! Leaving in 3 seconds...")
        time.sleep(3)
    except Exception as exc:
        print(f"Error during build/upload: {exc}")
        input("Press Enter to exit...")
        sys.exit(1)

def git_output(cmd):
    return subprocess.check_output(cmd, text=True).strip()


def git_status():
    output = git_output(["git", "status", "--porcelain"])
    files = []
    for line in output.splitlines():
        if not line:
            continue
        files.append(line[3:])
    return files


def publish_to_github():
    files = git_status()

    if not files:
        print(">>> No git changes to commit.")
        return

    print(">>> Files to be committed:")
    for file_path in files:
        print(f" - {file_path}")

    message = input(">>> Commit message for GitHub: ").strip()
    if not message:
        print(">>> Commit message is required for the GitHub step.")
        sys.exit(1)

    try:
        run(["git", "add", "."])
        run(["git", "commit", "-m", message])
        run(["git", "push"])
        print(">>> GitHub push completed successfully!")
    except Exception as exc:
        print(f"Error during GitHub publish: {exc}")
        input("Press Enter to exit...")
        sys.exit(1)

if __name__ == "__main__":
    clean()
    build_and_upload()
    publish_to_github()