"""cfgkit — reserved."""

__version__ = "0.0.1rc0"
__all__ = ["__version__"]
