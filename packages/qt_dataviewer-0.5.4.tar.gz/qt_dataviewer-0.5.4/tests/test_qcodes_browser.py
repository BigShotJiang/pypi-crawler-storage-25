from qt_dataviewer.qcodes.data_browser import QCoDeSDataBrowser
from qt_dataviewer.utils.logger import configure_logging

configure_logging()
browser = QCoDeSDataBrowser()
