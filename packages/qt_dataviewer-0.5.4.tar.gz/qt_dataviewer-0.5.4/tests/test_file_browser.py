from qt_dataviewer.data_file_browser import DataFileBrowser
from qt_dataviewer.utils.logger import configure_logging

configure_logging()

browser = DataFileBrowser()  # "test_data", gui_style="dark")
