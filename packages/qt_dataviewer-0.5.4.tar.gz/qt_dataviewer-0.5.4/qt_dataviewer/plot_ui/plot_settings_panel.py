import logging
from functools import partial

from qtpy import QtCore, QtWidgets

from qt_dataviewer.model.plot_model import AxisMode, AxisSettings, AxisType, PlotModel, ComplexMode
from qt_dataviewer.resources.icons import Icons
from qt_dataviewer.utils.qt_utils import qt_log_exception, get_font
from .smart_format import SmartFormatter

logger = logging.getLogger(__name__)


class PlotSettings(QtWidgets.QWidget):
    def __init__(self, plot_model: PlotModel):
        super().__init__()
        self._plot_model = plot_model

        max_column = 9

        layout = QtWidgets.QGridLayout(self)
        layout.setColumnMinimumWidth(0, 100)
        layout.setVerticalSpacing(0)
        layout.setHorizontalSpacing(8)
        layout.setColumnStretch(0, 1)
        for icol in range(1, max_column-1):
            layout.setColumnMinimumWidth(icol, 20)
        layout.setColumnMinimumWidth(max_column-1, 30)

        self._updating = False
        self._rb_groups = {}
        self._cb_log = {}
        self._cb_fft = {}
        self._sliders = {}
        irow = 0
        btn_col = 1

        label_name = QtWidgets.QLabel(plot_model.var_name)
        label_name.setFont(get_font(1.2))
        label_name.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)

        layout.addWidget(label_name, irow, 0, 1, max_column)
        irow += 1
        layout.addWidget(self._height_filler(), irow, 0)
        irow += 1

        if plot_model.error_message:
            label_error = QtWidgets.QLabel("Error: " + plot_model.error_message)
            label_error.setFont(get_font(1.2))
            label_error.setStyleSheet("color: #aa0000;")
            label_error.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
            layout.addWidget(label_error, irow, 0, 1, max_column)
            irow += 1
            layout.addWidget(self._height_filler(), irow, 0)
            irow += 1
            return

        for i, text in enumerate(['x', 'y', '*', 'avg', 'slice', 'log', 'fft', 'len'], btn_col):
            label_name = QtWidgets.QLabel(text)
            label_name.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
            layout.addWidget(label_name, irow, i)
        irow += 1
        layout.addWidget(self._height_filler(), irow, 0)
        irow += 1
        for axis in range(plot_model.n_axis):
            settings = plot_model.get_axis_settings(axis)
            ax_name = settings.name
            layout.addWidget(QtWidgets.QLabel(ax_name), irow, 0)

            group = QtWidgets.QButtonGroup(layout)
            self._rb_groups[axis] = group

            if settings.axis_type == AxisType.Coord:
                options = [AxisMode.XAxis, AxisMode.YAxis, AxisMode.All]
            else:
                options = [AxisMode.XAxis, AxisMode.YAxis, AxisMode.All, AxisMode.Average, AxisMode.Slice]

            for icol, mode in enumerate(options, btn_col):
                rb = QtWidgets.QRadioButton()
                rb.setChecked(settings.mode == mode)
                rb.toggled.connect(partial(self._set_mode, index=axis, mode=mode))
                group.addButton(rb, mode)
                layout.addWidget(rb, irow, icol, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

            if settings.axis_type == AxisType.Coord:
                lbl = QtWidgets.QLabel(str(settings.dims))
                layout.addWidget(lbl, irow, btn_col + len(options), 1, 2,
                                 alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

            if settings.axis_type != AxisType.Dim:
                cb = QtWidgets.QCheckBox()
                cb.setChecked(settings.logarithmic)
                cb.toggled.connect(partial(self._set_log, index=axis))
                self._cb_log[axis] = cb
                layout.addWidget(cb, irow, max_column-3, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

            if settings.axis_type == AxisType.DimCoord:
                cb = QtWidgets.QCheckBox()
                cb.setChecked(settings.fft)
                cb.toggled.connect(partial(self._set_fft, index=axis))
                self._cb_fft[axis] = cb
                layout.addWidget(cb, irow, max_column-2, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

            if settings.axis_type != AxisType.Coord:
                dim_label = QtWidgets.QLabel(f"{len(settings.data)}")
                dim_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight)
                layout.addWidget(dim_label, irow, max_column-1)

            irow += 1

            # Slider ROW
            layout.addWidget(self._height_filler(), irow, 0)

            slider = Slider(self, axis, settings, partial(self._set_slice, index=axis))
            slider.set_enabled(settings.mode == AxisMode.Slice)
            self._sliders[axis] = slider
            layout.addWidget(slider.widget, irow, 0, 1, max_column)
            # layout.setRowMinimumHeight(irow, 10)
            irow += 1

        # Histogram
        axis = "histogram"
        hist_mode = plot_model.histogram_mode
        layout.addWidget(QtWidgets.QLabel("histogram"), irow, 0)
        group = QtWidgets.QButtonGroup(layout)
        self._rb_groups[axis] = group
        for icol, mode in enumerate([AxisMode.XAxis, AxisMode.YAxis], btn_col):
            rb = QtWidgets.QRadioButton()
            rb.setChecked(hist_mode == mode)
            rb.toggled.connect(partial(self._set_mode, index=axis, mode=mode))
            group.addButton(rb, mode)
            layout.addWidget(rb, irow, icol, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)
        irow += 1
        layout.addWidget(self._height_filler(), irow, 0)
        irow += 1
        # TODO add hist bins, range

        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        line.setFrameShadow(QtWidgets.QFrame.Sunken)
        layout.addWidget(line, irow, 0, 1, max_column)
        irow += 1
        layout.addWidget(self._height_filler(), irow, 0)
        irow += 1

        layout.addWidget(QtWidgets.QLabel("multiline plot"), irow, 0)
        cb = QtWidgets.QCheckBox()
        cb.setChecked(plot_model.multiline_plot)
        cb.toggled.connect(self._set_multiline_plot)
        self._cb_multiline = cb
        layout.addWidget(cb, irow, btn_col, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)
        irow += 1
        layout.addWidget(self._height_filler(), irow, 0)
        irow += 1

        layout.addWidget(QtWidgets.QLabel("measured log."), irow, 0)
        cb = QtWidgets.QCheckBox()
        cb.setChecked(plot_model.logarithmic)
        cb.toggled.connect(self._set_logarithmic)
        self._cb_measured_log = cb
        layout.addWidget(cb, irow, btn_col, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)
        irow += 1
        layout.addWidget(self._height_filler(), irow, 0)
        irow += 1

        if plot_model.iscomplex:
            layout.addWidget(QtWidgets.QLabel("Complex"), irow, 0)
            combo = QtWidgets.QComboBox()
            combo.setMinimumWidth(80)
            combo.addItem("---", None)
            combo.currentTextChanged.connect(self._set_complex_mode)
            self._complex_mode_cbx = combo
            self._complex_mode_cbx_ndim = None
            layout.addWidget(self._complex_mode_cbx, irow, btn_col, 1, 7)
            irow += 1
            layout.addWidget(self._height_filler(), irow, 0)
            irow += 1

        layout.addWidget(QtWidgets.QLabel("2D colorbar"), irow, 0)
        sidebar_state = plot_model.show_sidebar
        sidebar_layout = QtWidgets.QHBoxLayout()
        group = QtWidgets.QButtonGroup(layout)
        self._rb_sidebar = group
        for icol, state in enumerate(["off", "std", "histogram"], btn_col):
            rb = QtWidgets.QRadioButton(state)
            rb.setChecked(sidebar_state == state)
            rb.toggled.connect(partial(self._set_show_sidebar, state=state))
            group.addButton(rb, icol)
            sidebar_layout.addWidget(rb)
        sidebar_layout.addStretch(4)
        layout.addLayout(sidebar_layout, irow, btn_col, 1, 7)

        irow += 1
        layout.addWidget(self._height_filler(), irow, 0)
        irow += 1

        self._info_lbl = QtWidgets.QLabel("INFO")
        layout.addWidget(self._info_lbl, irow, 0, 1, 7, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

        irow += 1
        layout.addWidget(self._height_filler(), irow, 0)
        irow += 1

        self.update_gui()

    def _height_filler(self):
        height_filler = QtWidgets.QFrame()
        height_filler.setMinimumHeight(10)
        return height_filler

    @qt_log_exception
    def _set_mode(self, checked, index, mode):
        if checked:
            logger.debug(f"set mode {index} {mode}")
            self._plot_model.set_axis_mode(index, mode)
            self.update_gui()
            try:
                slider = self._sliders[index]
                slider.set_enabled(mode == AxisMode.Slice)
            except KeyError:
                pass
        elif index == 'histogram':
            logger.debug(f"set mode {index} {mode}")
            hist_btns = self._rb_groups['histogram']
            if hist_btns.checkedButton() is None:
                self._plot_model.set_axis_mode(index, None)
                self.update_gui()

    @qt_log_exception
    def _set_log(self, checked, index):
        logger.debug(f"set log {index}")
        self._plot_model.set_axis_log(index, checked)

    @qt_log_exception
    def _set_fft(self, checked, index):
        logger.debug(f"set fft {index}")
        self._plot_model.set_axis_fft(index, checked)
        self.update_gui()

    @qt_log_exception
    def _set_slice(self, slice_index, index):
        logger.debug(f"set slice {index}")
        self._plot_model.set_axis_slice(index, slice_index)

    @qt_log_exception
    def _set_logarithmic(self, checked):
        self._plot_model.set_logarithmic(checked)

    @qt_log_exception
    def _set_multiline_plot(self, checked):
        self._plot_model.set_multiline_plot(checked)

    @qt_log_exception
    def _set_complex_mode(self, mode: str):
        try:
            complex_mode = ComplexMode(mode)
        except ValueError:
            # ignore "---" or ""
            return
        if complex_mode != self._plot_model.complex_mode:
            self._plot_model.set_complex_mode(complex_mode)
            self.update_gui()

    @qt_log_exception
    def _set_show_sidebar(self, checked, state):
        if checked:
            self._plot_model.set_show_sidebar(state)

    def update_gui(self):
        logger.debug("update gui")
        plot_model = self._plot_model
        if not plot_model:
            return
        if self._updating:
            return
        self._updating = True

        ndim = len(plot_model.plot_axes)

        if plot_model.info_message is None:
            self._info_lbl.setVisible(False)
        else:
            self._info_lbl.setVisible(True)
            self._info_lbl.setText(plot_model.info_message)

        for axis in range(plot_model.n_axis):
            settings = plot_model.get_axis_settings(axis)
            mode = settings.mode
            self._rb_groups[axis].button(mode).setChecked(True)
            if settings.axis_type != AxisType.Dim:
                self._cb_log[axis].setEnabled(mode in [AxisMode.XAxis, AxisMode.YAxis])
            if settings.axis_type == AxisType.DimCoord:
                self._cb_fft[axis].setEnabled(mode in [AxisMode.XAxis, AxisMode.YAxis])

        # histogram
        hist_btns = self._rb_groups["histogram"]
        hist_btns.setExclusive(False)
        hist_mode = plot_model.histogram_mode
        for mode in [AxisMode.XAxis, AxisMode.YAxis]:
            hist_btns.button(mode).setChecked(mode == hist_mode)

        for btn in self._rb_sidebar.buttons():
            btn.setEnabled(ndim == 2 and not plot_model.multiline_plot)

        if plot_model.iscomplex and self._complex_mode_cbx_ndim != ndim:
            cbx = self._complex_mode_cbx
            cbx.clear()
            current_mode = plot_model.complex_mode
            if plot_model.ndim == 1:
                for mode in ComplexMode:
                    cbx.addItem(mode.value)
                cbx.setCurrentText(current_mode.value)
            elif plot_model.ndim == 2:
                for mode in ComplexMode.modes_2D():
                    cbx.addItem(mode.value)
                cbx.setCurrentText(current_mode.to_2D_mode().value)
            else:
                cbx.addItem("---")
            self._complex_mode_cbx_ndim = ndim

        self._cb_measured_log.setEnabled(ndim == 1 or plot_model.multiline_plot)
        self._updating = False

    def stop(self):
        for slider in self._sliders.values():
            slider.set_enabled(False)


class Slider(QtCore.QObject):
    def __init__(self, parent, axis: int, settings: AxisSettings, changed_cb):
        super().__init__(parent)
        self.axis = axis
        self.settings = settings
        self.changed_cb = changed_cb
        self.formatter = SmartFormatter(settings.data)

        slider = QtWidgets.QSlider(parent)
        slider.setFocusPolicy(QtCore.Qt.StrongFocus)
        slider.setOrientation(QtCore.Qt.Horizontal)
        slider.setTickInterval(1)
        slider.setMinimum(0)
        slider.setMaximum(len(settings.data)-1)
        slider.valueChanged.connect(self._slider_changed)
        slider.setStyleSheet(
            """
            /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */
            QSlider::groove:horizontal {
                border: 1px solid #999999;
                height: 6px;
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #B1B1B1, stop:1 #c4c4c4);
                margin: 0px 0;
                border-radius: 2px;
            }

            /* handle is placed by default on the contents rect of the groove. Expand outside the groove */
            QSlider::handle:horizontal {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);
                border: 1px solid #5c5c5c;
                width: 10px;
                margin: -6px 0;
                border-radius: 3px;
            }
            QSlider:focus {
                border: 1px dotted #404040;
            }
            """)

        label = QtWidgets.QLabel()
        label.setMinimumWidth(40)
        label.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)

        loop_btn = QtWidgets.QPushButton(Icons.looping(), "")
        loop_btn.setCheckable(True)
        loop_btn.clicked.connect(self._loop_clicked)

        self._enabled = False

        self._looping = False
        self._timer_id = None
        n = len(self.settings.data)
        interval = 5000 // n
        if interval < 100:
            interval = 100
        if interval > 500:
            interval = 500
        self._loop_interval = interval

        self.qslider = slider
        self.label = label
        self.widget = QtWidgets.QWidget()
        self.widget.setVisible(False)
        self.loop_btn = loop_btn
        layout = QtWidgets.QHBoxLayout(self.widget)
        layout.setContentsMargins(20, 2, 0, 4)
        layout.addWidget(loop_btn)
        layout.addWidget(slider)
        layout.addWidget(label)

        self._set_label_text(settings.slice_index)
        slider.setValue(settings.slice_index)

    def _set_label_text(self, slice_index):
        settings = self.settings
        value = self.formatter.without_unit_prefix(settings.data[slice_index].item()) # TODO Make 1 call?
        value_str = self.formatter.with_units(value, settings.data)
        self.label.setText(value_str)

    @qt_log_exception
    def _slider_changed(self, slice_index):
        self._set_label_text(slice_index)
        self.changed_cb(slice_index)

    def set_enabled(self, enabled: bool):
        if enabled != self._enabled:
            if self.loop_btn.isChecked():
                self.loop_btn.setChecked(False)
                self.killTimer(self._timer_id)
                self._timer_id = None
                self._looping = False
            self.widget.setVisible(enabled)
            self._enabled = enabled

    def _loop_clicked(self, checked: bool):
        self._looping = checked
        if self._timer_id is not None:
            self.killTimer(self._timer_id)
            self._timer_id = None
        if checked:
            self._timer_id = self.startTimer(self._loop_interval)

    def _increment_index(self):
        if not self._looping:
            return

        index = self.qslider.value()
        if index < len(self.settings.data) - 1:
            index += 1
        else:
            index = 0
        self.qslider.setValue(index)

    def timerEvent(self, event):
        self._increment_index()
