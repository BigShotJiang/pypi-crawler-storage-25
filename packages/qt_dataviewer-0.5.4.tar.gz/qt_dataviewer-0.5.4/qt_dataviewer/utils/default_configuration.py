# hard coded default configuration.

_default_configuration = """
plotting:
  colormap: viridis  # viridis, plasma, inferno, magma, afmhot, Spectral, coolwarm, terrain, rainbow, jet, turbo
  2D-colorbar: off  # options: off, std, histogram

logging:
  enabled: true
  file_location: ~/.qt-dataviewer/logs
  file_name: qt-dataviewer.log
  file_level: INFO
  console_level: WARNING
"""
