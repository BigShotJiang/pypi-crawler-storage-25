# Local Agent Foundry

[![CI](https://github.com/vystartasv/agent-foundry/actions/workflows/ci.yml/badge.svg)](https://github.com/vystartasv/agent-foundry/actions/workflows/ci.yml)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-163%20passed-brightgreen)]()
[![NHS DTAC](https://img.shields.io/badge/NHS-DTAC%20Aligned-005EB8)]()
[![ISO 27001](https://img.shields.io/badge/ISO%2027001-Mapped-0072C6)]()

> **Agents building agents. Offline. Auditable. Regulated-industry ready.**

A desktop platform for running, managing, and orchestrating AI agents entirely offline. Agents build, test, and deploy other agents — with full audit trails and compliance documentation for NHS, finance, and government.

![Dashboard Screenshot](desktop/mockups/dashboard-light.png)

![CLI Demo](desktop/mockups/demo-animated.gif)

![Dashboard Demo](desktop/mockups/dashboard-demo.gif)

## Why

No existing platform combines:
- **Local-only operation** (air-gapped, GDPR-compliant)
- **Agent orchestration** (multi-agent with formal handoffs)
- **Observability** (audit trail, cost tracking, health)
- **Quality gates** (behavioural tests for agents)
- **Regulated industry readiness** (compliance docs, model cards)

## Quick Start

```bash
# Install
pip install agent-foundry

# Or from source
git clone <repo-url>
cd agent-foundry
pip install -e ".[dev]"

# Start an agent
foundry agent start builder --model qwen-8b --tools terminal,file

# Run a task
foundry agent run builder "Create a test file"

# Hand off to a reviewer
foundry agent start reviewer --model qwen-8b --tools terminal,file
foundry handoff create --from builder --to reviewer --task "Review the work"

# Check quality gates
foundry gate run --agent builder --file output.txt

# Export audit log
foundry audit export --output compliance-report.json
```

## Architecture

Six layers, running entirely on your machine:

```
Desktop UI (Tauri) ·················· [Phase 2]
CLI (`foundry`) ····················· [MVP ✓]
Agent Engine · Handoff Protocol ★ · Quality Gates · Observability
Model Runtime (oMLX · llama.cpp · Ollama)
Tool Registry (MCP · Hermes skills)
Storage (SQLite)
```

**The handoff protocol** is the core differentiator — a formal standard for agents to pass work between each other with full state preservation and verification. Every handoff is auditable.

## For Regulated Industries

Pre-built compliance documentation included in `docs/compliance/`:
- **DPIA Template** — Data Protection Impact Assessment
- **Model Cards** — Per-model capability and limitation documentation
- **GDPR Checklist** — Article-by-article compliance verification
- **NHS DTAC Alignment** — Digital Technology Assessment Criteria mapping
- **ISO 27001 Control Mapping** — All 71 Annex A controls mapped
- **Deployment Architecture** — On-prem deployment patterns, data flows

Zero cloud dependency. Air-gap capable. No data leaves your device.

## Requirements

- Python 3.11+
- macOS (Apple Silicon), Linux, or Windows
- 16GB+ RAM (32GB recommended for 8B+ models)
- No network required (offline operation after model download)

## Model Backends

| Backend | Status | Notes |
|---------|--------|-------|
| oMLX | ✅ Supported | Apple Silicon, local inference |
| llama.cpp | ✅ Supported | Cross-platform GGUF models |
| Ollama | ✅ Supported | Easy model management |
| Dummy | ✅ Testing | Simulated backend for tests |

## Commands

```
foundry agent start|stop|list|stats|run    Manage agents
foundry handoff create|accept|complete|list|show    Formal work transfer
foundry gate run                          Quality checks
foundry skill discover|list|show          Agent skills
foundry audit show|export|stats           Audit trail
foundry backend health|models|test        Backend management
```

## Development

```bash
pip install -e ".[dev]"
pytest                    # 163 tests
foundry --help            # CLI reference
```

## Documentation

- [Architecture](docs/architecture.md) — Full system design
- [Compliance Pack](docs/compliance/) — Regulated industry procurement docs
- [Getting Started](docs/getting-started.md) — Setup and first agent workflow

## Roadmap

- [x] CLI MVP — agent engine, handoff, gates, audit
- [x] Compliance pack — NHS, GDPR, ISO 27001
- [x] M365 Bridge — SharePoint, Teams, Graph API integration
- [x] Multi-machine orchestration
- [x] Cloud model fallback (opt-in)
- [ ] Desktop UI (Tauri) — dashboard, logs, model management

## License

MIT — see [LICENSE](LICENSE)
