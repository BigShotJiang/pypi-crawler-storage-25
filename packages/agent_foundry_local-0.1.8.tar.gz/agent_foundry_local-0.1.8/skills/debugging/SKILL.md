---
name: debugging
description: Systematic debugging — understand the bug before fixing
version: 1.0.0
---

# Systematic Debugging Skill

When debugging, follow this 4-phase approach:

## Phase 1: Reproduce
- Get the exact error message and stack trace
- Identify the conditions that trigger the bug
- Create a minimal reproduction case

## Phase 2: Isolate
- Use binary search to narrow the cause
- Check recent changes (git diff)
- Identify the specific line or condition causing the failure

## Phase 3: Understand
- Explain WHY the bug occurs, not just what happens
- Check assumptions about the code
- Verify the fix addresses the root cause, not symptoms

## Phase 4: Fix & Verify
- Apply the minimal fix
- Run the reproduction case to confirm
- Run the full test suite
- Add a regression test

## Output Format
```
## Bug: <description>

### Root Cause
...

### Fix
...

### Verification
- Test passes: ✓/✗
- Regression test added: ✓/✗
```
