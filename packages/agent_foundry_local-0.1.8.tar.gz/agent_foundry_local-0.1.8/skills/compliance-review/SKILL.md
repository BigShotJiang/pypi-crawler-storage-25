---
name: compliance-review
description: Review agent output for compliance with NHS DTAC, GDPR, and ISO 27001 requirements
version: 1.0.0
---

# Compliance Review Skill

When reviewing code or documentation that will be used in regulated industries (NHS, finance, government), check compliance against these frameworks.

## Steps

1. **Identify applicable frameworks** — NHS DTAC, GDPR, ISO 27001, or all three
2. **Check data handling** — No personal data in logs, no cloud dependencies, encryption at rest
3. **Check audit trail** — Every action must be logged, timestamps present, agent identity clear
4. **Check safety** — No dangerous commands, human-in-the-loop for destructive actions
5. **Check documentation** — Model cards complete, DPIA filled, deployment architecture clear
6. **Summarize gaps** — List compliance issues with framework reference

## Key Rules

- **No cloud dependencies**: All processing must be local. No external API calls without explicit opt-in.
- **Audit everything**: Every agent action must be traceable to a specific agent, timestamped.
- **Data minimisation**: Agents must not collect or log personal data. Audit logs must be purgeable.
- **Safety first**: Quality gates must pass before deployment. Safety gate blocks dangerous commands.
- **Human review**: Handoff protocol requires human verification for deployment.

## Output Format
```
## Compliance Review: <artefact>

### Data Protection (GDPR)
- Finding

### Clinical Safety (NHS DTAC)
- Finding

### Information Security (ISO 27001)
- Finding

### Recommendations
1. Action item
2. Action item

### Verdict
✓ Compliant / ⚠️ Needs Review / ✗ Non-compliant
```
