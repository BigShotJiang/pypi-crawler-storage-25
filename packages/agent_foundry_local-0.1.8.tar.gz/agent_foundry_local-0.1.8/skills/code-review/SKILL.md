---
name: code-review
description: Review code for bugs, style, and security issues
version: 1.0.0
---

# Code Review Skill

When you receive a code review task, follow this checklist:

## Steps
1. **Read the code** — understand the purpose and flow
2. **Check for bugs** — logic errors, edge cases, error handling
3. **Check style** — consistent naming, proper formatting, docstrings
4. **Check security** — input validation, no hardcoded secrets, safe commands
5. **Summarize findings** — list issues found with severity (critical/high/medium/low)

## Output Format
```
## Code Review: <file/feature>

### Critical Issues
- Issue description

### High Issues
- Issue description

### Medium Issues
- Issue description

### Low Issues
- Issue description

### Summary
Overall assessment and recommendation.
```
