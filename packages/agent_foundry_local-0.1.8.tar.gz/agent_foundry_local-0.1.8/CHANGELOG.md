# Changelog

All notable changes to Local Agent Foundry.

## [0.1.8] — 2026-05-04



## [0.1.7] — 2026-05-04

- 🐛 fix: invalid PyPI classifier + sync pyproject.toml version in release script


## [0.1.6] — 2026-05-04



## [0.1.5] — 2026-05-04



## [0.1.4] — 2026-05-04

- ✨ feat: dashboard demo GIF with live randomness — values jitter ±5%, agent states flip, timestamps tick
- ✨ feat: working dashboard navigation — 7 tab panels with real content switching
- 🐛 fix: dashboard demo stays light theme throughout (no dark toggle)


## [0.1.3] — 2026-05-04



## [0.1.2] — 2026-05-04

- 🐛 fix: dashboard demo starts light-first (user preference)
- ✨ feat: dynamic dashboard demo GIF — nav clicks, gate check, theme toggle
- ✨ feat: dashboard UI demo GIF + Playwright capture script
- 🐛 fix: resolve 86 lint errors + slow demo GIF to human speed


## [0.1.1] — 2026-05-04

- 🐛 fix: animated demo GIF, updated changelog, roadmap sync
- ✨ feat: animated CLI demo, light mode screenshot, pyproject fixes, demo script
- ✨ feat: light/dark theme + screenshots for README
- ✨ feat: dashboard mockup + comms kit + README badges
- ✨ feat: CI/CD release pipeline — GitHub Actions, PyPI publishing
- ✨ feat: Desktop UI scaffold — Tauri + React
- ✨ feat: Multi-machine orchestration — peer discovery + cross-machine handoffs
- ✨ feat: Cloud model fallback — opt-in cloud backend
- ✨ feat: M365 Bridge — SharePoint, Teams, Graph API, Power Platform
- ✨ feat: compliance pack + docs — project complete
- v0.2: Real tool execution + skill registry + live model support
- Initial commit: Local Agent Foundry MVP
- 📝 docs: architecture for Local Agent Foundry


## [0.1.1] — 2026-05-04

### ✨ Features

- **M365 Bridge**: 4 modules (auth, Graph, SharePoint, Teams, Power Platform) with 14 CLI commands
- **Multi-machine Orchestration**: P2P node registry, mDNS discovery, HTTPS handoff transport
- **Cloud Fallback**: Opt-in OpenAI-compatible backend with `FOUNDRY_CLOUD_CONSENT` gate
- **Desktop UI Scaffold**: Tauri + React 19 with 6-panel dashboard, light/dark theme
- **Release Pipeline**: GitHub Actions CI + PyPI publish on tag push, `scripts/release.py`

### 📝 Documentation

- Animated CLI demo GIF showing 9-step workflow
- Comms kit (LinkedIn, Twitter, blog, pitch deck) in `docs/comms-kit.md`
- Dashboard mockups with realistic NHS M365 data (light + dark)
- Screenshots captured via Playwright/Chromium

### 🧪 Testing

- 163 tests, all passing (up from 103)

---

## [0.1.0] — 2026-05-04

### ✨ Features

- **MVP CLI**: Full agent lifecycle management — start, stop, list, run agents
- **Handoff Protocol**: Formal agent-to-agent work transfer with state preservation, definition of done, and verification
- **Quality Gates**: 5 gate types — syntax, safety, behaviour, security, performance
- **Observability**: Audit trail with SQLite backend, export to JSON, statistics dashboard
- **Skill System**: Hermes SKILL.md format — discover, load, and execute agent skills
- **Tool Registry**: Extensible tool registration system with built-in terminal/file tools
- **Model Runtime**: Abstract backend interface with oMLX, llama.cpp, Ollama, and Dummy implementations
- **Dummy Backend**: Predictable responses for testing without a real model

### 📝 Documentation

- Full architecture documentation with competitive landscape
- Getting Started guide with 10-minute multi-agent workflow tutorial
- Compliance pack: DPIA template, GDPR checklist, NHS DTAC alignment, ISO 27001 mapping
- Model card template for documenting AI models used in regulated contexts
- Deployment architecture guide with 3 deployment models (standalone, air-gapped, VDI)

### 🧪 Testing

- 163 tests covering all 6 layers
- test_engine, test_handoff, test_gates, test_observability, test_registry, test_runtime
- Integration tests for end-to-end agent workflows

---

## Upcoming

Planned for future releases:
- Desktop UI (Tauri + React) — full dashboard, logs, model management
- OAuth2 device flow for M365 Bridge
- Agent skill marketplace / discovery

