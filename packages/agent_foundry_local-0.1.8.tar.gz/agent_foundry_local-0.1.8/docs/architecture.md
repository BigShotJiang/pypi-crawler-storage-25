# Local Agent Foundry — Architecture

> **Motto:** Agents building agents. Offline. Auditable. Regulated-industry ready.

## What It Is

A desktop platform where AI agents run, collaborate, and build other agents — entirely offline. Think "Docker for agents" but local-first, with compliance documentation for NHS, finance, and government.

## Why It Exists

No existing platform combines:
- **Local-only operation** (air-gapped, GDPR-compliant)
- **Agent orchestration** (multi-agent with formal handoffs)
- **Observability** (audit trail, cost tracking, health)
- **Quality gates** (behavioral tests for agents)
- **Regulated industry readiness** (compliance docs, model cards)

OpenHands has a local GUI but targets developers. Ollama serves models but isn't an agent platform. Claude Code/Codex are cloud-dependent. Nobody has all five.

## Architecture Layers

```
┌─────────────────────────────────────────────────┐
│                  Desktop UI (Tauri)              │
│            Dashboard · Logs · Model Mgmt          │
├─────────────────────────────────────────────────┤
│                  CLI (`foundry`)                  │
│     start · stop · handoff · test · audit        │
├──────────┬──────────┬──────────┬────────────────┤
│ Agent    │ Handoff  │ Quality  │ Observability  │
│ Engine   │ Protocol │ Gates    │                │
├──────────┴──────────┴──────────┴────────────────┤
│              Model Runtime                       │
│    oMLX · llama.cpp · Bonsai · Ollama            │
├─────────────────────────────────────────────────┤
│              Tool Registry                       │
│    MCP servers · Hermes skills · Custom tools    │
├─────────────────────────────────────────────────┤
│              Storage (SQLite)                    │
│    Agent state · Audit log · Skills · Models     │
└─────────────────────────────────────────────────┘
```

### 1. Model Runtime
**What:** Abstracts model backends. First target: oMLX (already working locally). Later: llama.cpp, Bonsai, Ollama.
**Responsibilities:** Model discovery, loading/unloading, inference with tool-use support, quantization management.
**Key insight:** Different models are reliable at different agent tasks. The runtime tracks which model works for which agent role.

### 2. Agent Engine
**What:** Agent lifecycle manager. Create, configure, run, pause, stop agents. Each agent gets: a model, a toolset, a skill set, a working directory, and a role.
**Responsibilities:**
- Agent process management (background agents that persist across sessions)
- Tool registration and capability discovery
- Skill loading (Hermes SKILL.md format)
- Agent-to-agent communication bus
- Role-based access (what can Agent A do that Agent B can't)

### 3. Handoff Protocol ★ (Core Differentiator)
**What:** A formal standard for agents to pass work to each other with full state preservation.

**Handoff packet format:**
```json
{
  "handoff_id": "uuid",
  "from_agent": "builder-01",
  "to_agent": "reviewer-02",
  "task": { "goal": "...", "priority": "high" },
  "state_snapshot": {
    "dirty_files": ["src/main.py", "tests/test_main.py"],
    "git_hash": "abc1234",
    "working_dir": "/path/to/project",
    "env_vars": {}
  },
  "context": {
    "decisions_made": ["Used SQLite over Postgres for portability"],
    "blockers": [],
    "notes": "Build passes, 3 tests failing — see test output"
  },
  "definition_of_done": [
    "All 3 tests pass",
    "No new lint errors",
    "Security scan clean"
  ],
  "verification": {
    "commands": ["pytest -x", "ruff check src/"],
    "expected_results": "0 failures, 0 lint errors"
  },
  "timestamp": "2026-05-03T23:00:00Z"
}
```

**Handoff lifecycle:**
1. Agent A completes work → snapshots state → creates handoff packet
2. Agent B receives handoff → verifies state matches → acknowledges
3. Agent B works → meets DoD → verifies → marks handoff complete
4. Audit log records entire handoff chain

**Why this matters for regulated industries:** Every handoff is auditable. You can trace exactly which agent did what, when, and whether verification passed. This is the compliance paper trail that cloud agents can't provide.

### 4. Quality Gates
**What:** Before an agent is deployed or a handoff is accepted, gates must pass.

**Gate types:**
| Gate | What it checks | Example |
|------|---------------|---------|
| Syntax | Code compiles/parses | `ast.parse()`, `npm run build` |
| Safety | No dangerous commands | Blocklist: `rm -rf /`, `DROP TABLE` |
| Behavior | Agent behaves correctly | Test suite for agent tool-calling |
| Security | No secrets in output | Secret scanning |
| Performance | Model responds within SLA | Timeout checks |
| Compatibility | Skills work with current model | Skill validation suite |

### 5. Observability
**What:** See everything your agents are doing.

**Dashboard panels:**
- Active agents (health, uptime, current task)
- Handoff chain (who handed what to whom)
- Cost tracking (tokens, compute time, electricity)
- Failure trends (which agents fail most, on what tasks)
- Audit log (every action, timestamped, exportable)

**For regulated industries:** Full audit trail export (PDF/JSON). Timestamps. Agent identity. Action taken. Outcome.

### 6. Compliance Pack
**What:** Pre-built documentation for regulated industry procurement.

**Includes:**
- DPIA template (Data Protection Impact Assessment)
- Model card for each model used
- GDPR compliance checklist
- NHS DTAC alignment doc
- ISO 27001 control mapping
- Deployment architecture diagram (on-prem, no cloud dependencies)

### 7. M365 Bridge (Vilius's Domain)
**What:** Connect agents to Microsoft 365.

**Capabilities:**
- SharePoint: Read/write lists, libraries, pages
- Teams: Send messages, read channels
- Graph API: Full M365 automation
- Power Platform: Trigger flows, update dataverse

## MVP Scope

**First deliverable:** CLI tool that proves the concept end-to-end.

```
foundry agent start builder --model qwen-8b --tools terminal,file
foundry agent start reviewer --model qwen-8b --tools terminal,file
foundry handoff builder reviewer --task "Review src/main.py"
foundry gate run --agent reviewer
foundry audit export --from "2026-05-01" --format pdf
```

**Tech stack:**
- Python 3.11+ (core engine)
- SQLite (state, audit log, skill registry)
- oMLX (first model backend, already working)
- Click/Typer (CLI)
- Tauri (desktop UI, phase 2)

**What it WON'T do in MVP:**
- Desktop GUI (CLI only)
- Multi-machine orchestration (single machine)
- Cloud model fallback (offline only)
- M365 Bridge (phase 2)

## Competitive Landscape

| Area | What Exists | Gap | Our Angle |
|------|------------|-----|-----------|
| Agent platforms | OpenHands (local GUI), LangChain, CrewAI | None are offline + regulated + desktop | Local-only + compliance |
| Model serving | Ollama, LM Studio, oMLX | Tool-use is unreliable on local models | Quality gates catch this |
| Observability | LangSmith, W&B (cloud) | No offline audit trails | Local audit log with export |
| Handoff | Nothing formal exists | No standard at all | We define the standard |
| Regulated AI | Palantir (cloud/hybrid) | No desktop/offline agent platform | NHS DTAC alignment |
| MCP | Growing ecosystem | Desktop hosts are thin | Foundry is a rich MCP host |

**Primary competitor:** OpenHands — closest to "local agent platform." But targets developers, not regulated industries. No handoff protocol. No compliance pack. Cloud-dependent for best models.

**Our wedge:** Regulated industries + agent handoff standard + offline operation.

## "Agents by Agents" Angle

The Foundry itself is built by agents using the Foundry. This is our proof case:

1. **Agent A (Builder)** scaffolds features using Foundry's agent engine
2. **Agent B (Reviewer)** reviews via handoff protocol
3. **Agent C (Tester)** runs quality gates
4. **Agent D (Documentor)** writes docs
5. All handoffs are logged → becomes our own case study

This is the Bastion pattern applied to the Foundry itself. 111 web parts → N agent features.

## First Concrete Step

Build the CLI skeleton + Agent Engine core. Prove: agent starts, runs a task, hands off to another agent, quality gate passes, audit log records it all.

**Files to create:**
```
agent-foundry/
├── src/
│   ├── __init__.py
│   ├── cli.py              # Click CLI entry point
│   ├── engine/
│   │   ├── __init__.py
│   │   ├── agent.py        # Agent lifecycle
│   │   ├── runtime.py      # Model backend abstraction
│   │   └── handoff.py      # Handoff protocol
│   ├── gates/
│   │   ├── __init__.py
│   │   ├── syntax.py       # ast.parse gate
│   │   └── safety.py       # Dangerous command detection
│   ├── observability/
│   │   ├── __init__.py
│   │   └── audit.py        # Audit log (SQLite)
│   └── registry/
│       ├── __init__.py
│       └── tools.py        # Tool registry
├── tests/
│   ├── test_agent.py
│   ├── test_handoff.py
│   └── test_gates.py
├── skills/                  # Hermes skills for Foundry agents
├── docs/
│   └── architecture.md     # This file
└── pyproject.toml
```
