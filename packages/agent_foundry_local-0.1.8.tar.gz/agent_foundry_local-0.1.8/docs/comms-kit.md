# Comms Kit — Local Agent Foundry Launch

> Channel-specific posts and assets to establish Vilius Vystartas as an "agentic engineer" with M365 expertise in regulated industries.

---

## 1. LinkedIn Post (Primary)

**Headline:** I built an AI agent platform that NHS trusts can actually use. Here's why that matters.

**Body:**

Most AI agent platforms have a fatal flaw for regulated industries: they send your data to the cloud.

Try explaining that to an NHS Caldicott Guardian. Or a financial services CISO. Or a government DPO.

So I built Local Agent Foundry — a desktop platform where AI agents run, collaborate, and build other agents entirely offline. Zero cloud dependency. Air-gap capable.

**What it does:**
🦞 Agents start, run tasks, and hand off work to each other with full state preservation
🔄 Formal handoff protocol — every transfer is auditable (this doesn't exist anywhere else)
🛡️ Quality gates — syntax, safety, behaviour, security checks before deployment
☁️ M365 Bridge — agents read/write SharePoint, send Teams messages, query Dataverse
📋 Complete audit trail — every action logged, exportable for compliance
📦 pip install agent-foundry

**Built for regulated industries:**
✅ DPIA template pre-filled
✅ GDPR checklist — all 99 articles mapped
✅ NHS DTAC alignment — all 5 domains
✅ ISO 27001 — 71 Annex A controls mapped
✅ Zero cloud — local SQLite, local models, no telemetry

The M365 Bridge is the piece I'm most proud of. Your agents can:
→ Read/write SharePoint lists and document libraries
→ Send compliance alerts to Teams channels
→ Trigger Power Automate flows
→ Query Dataverse tables

All from a CLI. All local. All auditable.

This is what "agentic engineering" looks like in practice — not just using AI, but building systems where AI agents operate within real regulatory constraints.

Open source. MIT license. 163 tests passing.
→ github.com/vystartasv/agent-foundry

If you work in NHS digital, financial services, or government IT — I'd love to hear your thoughts. What would make this actually useful in your environment?

#AgenticEngineering #NHSDigital #Microsoft365 #AI #Compliance #OpenSource #Python

---

## 2. Twitter/X Thread

**Tweet 1 (Hook):**
I built an AI agent platform that NHS trusts can use without sending data to the cloud.

Zero cloud dependency. Air-gap capable. M365-integrated.

Open source. MIT. 🦞

**Tweet 2:**
The problem: every major AI agent platform (LangChain, CrewAI, OpenHands) requires cloud APIs.

That's a non-starter for:
• NHS (patient data)
• Financial services (regulated data)
• Government (classified data)

So I built Local Agent Foundry.

**Tweet 3:**
The core innovation? A formal **handoff protocol**.

Agents don't just chat — they transfer work with full state preservation:
• What files changed
• What decisions were made
• What verification is needed
• Is it done?

Every handoff is auditable. Every action is logged.

**Tweet 4:**
The M365 Bridge is where it gets interesting for enterprise:

Agents can:
→ Read/write SharePoint lists & libraries
→ Send Teams messages to channels
→ Trigger Power Automate flows
→ Query Dataverse tables

All from `foundry sharepoint items <site> <list>`

**Tweet 5:**
Regulated industry procurement is usually a nightmare.

So the compliance pack comes pre-built:
• DPIA template (filled in)
• GDPR checklist (99 articles)
• NHS DTAC alignment (5 domains)
• ISO 27001 mapping (71 controls)

Your DPO will thank you.

**Tweet 6:**
Tech stack:
• Python 3.11+, Click CLI
• oMLX / llama.cpp / Ollama (local models)
• SQLite for state + audit
• Tauri + React for desktop UI
• 163 tests, all passing

pip install agent-foundry

**Tweet 7:**
If you're an "AI engineer" who:
• Actually builds agent systems (not just prompts)
• Understands regulatory constraints
• Can bridge AI and M365

The market is wide open. Nobody's doing this yet.

Open source. Go build something.
→ github.com/vystartasv/agent-foundry

---

## 3. GitHub README Showcase

*(Already done — see README.md. Add these badges at top:)*

```markdown
[![PyPI version](https://img.shields.io/pypi/v/agent-foundry)](https://pypi.org/project/agent-foundry/)
[![CI](https://github.com/vystartasv/agent-foundry/actions/workflows/ci.yml/badge.svg)](https://github.com/vystartasv/agent-foundry/actions/workflows/ci.yml)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-163%20passed-brightgreen)]()
[![NHS DTAC](https://img.shields.io/badge/NHS-DTAC%20Aligned-blue)]()
[![ISO 27001](https://img.shields.io/badge/ISO%2027001-Mapped-blue)]()
```

---

## 4. Blog Post Outline — "Agentic Engineering: Beyond the Prompt"

**Title:** Agentic Engineering: What I Learned Building an AI Agent Platform for NHS Trusts

**Hook:** "AI engineering" today means prompt engineering. But in regulated industries, prompts aren't enough. You need agents that operate within real constraints — audit trails, compliance gates, and zero-cloud architectures.

**Sections:**

### What "Agentic Engineering" Actually Means
- Not just calling LLM APIs
- Designing agent systems with: lifecycle management, quality gates, handoff protocols, observability
- The shift from "what should the model say?" to "how should agents collaborate?"

### The Regulated Industry Reality
- NHS: DTAC, DCB 0129, Caldicott Guardians
- Finance: ISO 27001, GDPR, audit requirements
- Government: air-gapped networks, no cloud dependency
- How these constraints shape architecture decisions

### The Handoff Protocol — A New Primitive
- Why agent-to-agent handoff is different from function calling
- State preservation across agent boundaries
- Definition of Done as a contract
- Verification as a first-class concern

### M365 Bridge — Agents in the Enterprise
- SharePoint as an agent-accessible knowledge base
- Teams as a compliance notification channel
- Power Platform as an automation trigger
- Why Microsoft 365 is the integration surface for regulated industries

### What's Next
- Multi-machine orchestration
- Desktop UI
- Real NHS pilot deployments
- Call for collaborators

**CTA:** If you're building AI systems for regulated environments, let's talk. Open source: github.com/vystartasv/agent-foundry

---

## 5. Pitch Deck Outline (for consulting/employment)

**Slide 1 — Title:** Local Agent Foundry — AI Agents for Regulated Industries

**Slide 2 — The Gap:** No existing platform combines local-only operation, agent orchestration, quality gates, observability, AND regulated industry compliance.

**Slide 3 — Architecture:** 6 layers — Model Runtime, Agent Engine, Handoff Protocol, Quality Gates, Observability, Tool Registry

**Slide 4 — M365 Bridge:** Agents reading/writing SharePoint, sending Teams messages, triggering Power Automate — all offline, all auditable.

**Slide 5 — Compliance Pack:** DPIA, GDPR, NHS DTAC, ISO 27001 — pre-built procurement docs that accelerate NHS/finance/govt adoption.

**Slide 6 — Live Demo:** Dashboard showing agents running, M365 operations flowing, handoffs completing, audit trail recording.

**Slide 7 — Market:** NHS digital teams, financial services innovation groups, government digital service — all desperate for AI tools that meet their compliance requirements.

**Slide 8 — Roadmap:** Desktop UI, multi-machine orchestration, NHS trust pilots.

**Slide 9 — Call to Action:** Let's pilot this in your environment.
