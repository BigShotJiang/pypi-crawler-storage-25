# ISO 27001:2022 Control Mapping — Local Agent Foundry

> **Maps Foundry features to Annex A controls. For ISO 27001 certification preparation.**

---

## How to Use This Document

Each control below is mapped to Foundry features. Status indicators:
- ✅ **Fully addressed** — Foundry feature directly satisfies the control
- ⚠️ **Partially addressed** — Foundry helps but requires organisational measures
- ❌ **Not addressed** — Organisation must implement separately

---

## A.5 — Organisational Controls

| Ref | Control | Foundry Status | Evidence / Notes |
|-----|---------|---------------|------------------|
| A.5.1 | Policies for information security | ⚠️ | This template supports policy creation. Organisation must maintain. |
| A.5.2 | Information security roles and responsibilities | ⚠️ | Foundry supports role-based access (agent roles). Org must define. |
| A.5.3 | Segregation of duties | ✅ | Agent roles enforce separation: Builder ≠ Reviewer ≠ Tester |
| A.5.4 | Management responsibilities | ⚠️ | Audit trail supports management oversight |
| A.5.5 | Contact with authorities | ❌ | Organisation responsibility |
| A.5.6 | Contact with special interest groups | ❌ | Organisation responsibility |
| A.5.7 | Threat intelligence | ❌ | Organisation responsibility |
| A.5.8 | Information security in project management | ✅ | Quality gates enforce security in agent workflows |
| A.5.9 | Inventory of information and other associated assets | ⚠️ | Audit log serves as partial asset inventory |
| A.5.10 | Acceptable use of information | ⚠️ | Tool scoping enforces acceptable use boundaries |
| A.5.11 | Return of assets | ❌ | Organisation responsibility |
| A.5.12 | Classification of information | ⚠️ | Org must classify files agents access |
| A.5.13 | Labelling of information | ⚠️ | Org must label; Foundry processes whatever it's given |
| A.5.14 | Information transfer | ✅ | No information transfer — local-only operation |
| A.5.15 | Access control | ✅ | OS file permissions + tool scoping |
| A.5.16 | Identity management | ⚠️ | Relies on OS identity. No internal authentication (MVP). |
| A.5.17 | Authentication information | ⚠️ | OS-level auth. Foundry doesn't manage credentials. |
| A.5.18 | Access rights | ✅ | Tool scoping = least privilege by design |
| A.5.19 | Information security in supplier relationships | ⚠️ | No cloud suppliers in MVP. Future: DPA required for cloud fallback. |
| A.5.20 | Addressing information security within supplier agreements | ⚠️ | N/A for MVP. Required for future model providers. |
| A.5.21 | Managing information security in the ICT supply chain | ✅ | No supply chain — everything runs locally |
| A.5.22 | Monitoring, review, and change management of supplier services | ⚠️ | Model updates should be reviewed before deployment |
| A.5.23 | Information security for use of cloud services | ✅ | No cloud services used (MVP) |
| A.5.24 | Information security incident management planning and preparation | ⚠️ | Audit log supports incident investigation. Org needs plan. |
| A.5.25 | Assessment and decision on information security events | ⚠️ | Audit trail provides evidence. Org decides. |
| A.5.26 | Response to information security incidents | ❌ | Organisation responsibility |
| A.5.27 | Learning from information security incidents | ✅ | Audit trail + handoff chain enables post-incident analysis |
| A.5.28 | Collection of evidence | ✅ | Full audit trail: every action, timestamp, agent identity |
| A.5.29 | Information security during disruption | ❌ | Organisation responsibility (BC/DR) |
| A.5.30 | ICT readiness for business continuity | ❌ | Organisation responsibility |
| A.5.31 | Legal, statutory, regulatory, and contractual requirements | ✅ | GDPR checklist + DPIA + DTAC alignment |
| A.5.32 | Intellectual property rights | ⚠️ | Model cards document training data concerns |
| A.5.33 | Protection of records | ✅ | Local SQLite + export. No cloud dependency. |
| A.5.34 | Privacy and protection of PII | ✅ | No PII processing by default. GDPR checklist provided. |
| A.5.35 | Independent review of information security | ❌ | Organisation responsibility |
| A.5.36 | Compliance with policies, rules, and standards for information security | ✅ | Quality gates enforce compliance |
| A.5.37 | Documented operating procedures | ✅ | Architecture docs + compliance pack |

---

## A.8 — Technological Controls

| Ref | Control | Foundry Status | Evidence / Notes |
|-----|---------|---------------|------------------|
| A.8.1 | User endpoint devices | ✅ | Foundry IS the endpoint device. Full-disk encryption required. |
| A.8.2 | Privileged access rights | ✅ | Tool scoping limits agent privileges |
| A.8.3 | Information access restriction | ✅ | Agents access only explicitly granted tools + directories |
| A.8.4 | Access to source code | ⚠️ | Foundry IS a code tool. Org decides which repos to expose. |
| A.8.5 | Secure authentication | ⚠️ | OS-level only (MVP) |
| A.8.6 | Capacity management | ⚠️ | Quality gate: Performance gate checks model SLA |
| A.8.7 | Protection against malware | ⚠️ | Safety gate blocks dangerous commands. Org needs endpoint AV. |
| A.8.8 | Management of technical vulnerabilities | ⚠️ | Model updates + security gate scanning |
| A.8.9 | Configuration management | ✅ | Agent config is explicit and auditable |
| A.8.10 | Information deletion | ✅ | `foundry audit purge` for logs. Org handles file deletion. |
| A.8.11 | Data masking | ❌ | Not implemented. Org should mask sensitive data before agent access. |
| A.8.12 | Data leakage prevention | ✅ | Local-only, no network. No data exfiltration vector. |
| A.8.13 | Information backup | ⚠️ | Org responsibility. Foundry data is local files — covered by org's backup. |
| A.8.14 | Redundancy of information processing facilities | ❌ | Not applicable — single-machine platform |
| A.8.15 | Logging | ✅ | Comprehensive audit logging |
| A.8.16 | Monitoring activities | ✅ | Observability dashboard (CLI: `foundry observe`) |
| A.8.17 | Clock synchronisation | ⚠️ | Relies on OS clock |
| A.8.18 | Use of privileged utility programs | ✅ | Agent tools are explicitly scoped |
| A.8.19 | Installation of software on operational systems | ⚠️ | Foundry is installed software. Org controls deployment. |
| A.8.20 | Network security | ✅ | No network — air-gap capable |
| A.8.21 | Security of network services | ✅ | N/A — no network services |
| A.8.22 | Segregation in networks | ✅ | N/A — no network |
| A.8.23 | Web filtering | ❌ | N/A — no web access in MVP |
| A.8.24 | Use of cryptography | ✅ | Full-disk encryption (FileVault/BitLocker) |
| A.8.25 | Secure development life cycle | ✅ | Quality gates enforce SDL: syntax → safety → behaviour → security |
| A.8.26 | Application security requirements | ✅ | Gate system enforces requirements |
| A.8.27 | Secure system architecture and engineering principles | ✅ | Layered architecture with isolation between components |
| A.8.28 | Secure coding | ⚠️ | Agents generate code — gates check it. Human review required. |
| A.8.29 | Security testing in development and acceptance | ✅ | Security gate scans agent output |
| A.8.30 | Outsourced development | ✅ | No outsourced development. Agents build locally. |
| A.8.31 | Separation of development, test, and production environments | ⚠️ | Org should use separate machines or VMs for dev/prod |
| A.8.32 | Change management | ✅ | Handoff protocol requires explicit task definition + DoD |
| A.8.33 | Test information | ✅ | Synthetic data recommended. No production data in testing. |
| A.8.34 | Protection of information systems during audit testing | ✅ | Audit is read-only. No impact on running agents. |

---

## Summary

| Category | Addressed | Partial | Not Addressed |
|----------|-----------|---------|---------------|
| Organisational (A.5) | 10 | 18 | 9 |
| Technological (A.8) | 16 | 14 | 4 |
| **Total** | **26** | **32** | **13** |

### Key Gaps (Organisation Must Address)

1. **Authentication** — Foundry relies on OS security. Multi-user auth not in MVP.
2. **Incident response** — Audit trail supports investigation but org needs IR plan.
3. **Business continuity** — Not addressed. Single-machine platform.
4. **Data masking** — No built-in data masking. Org must pseudonymise before agent access.
5. **Network security monitoring** — N/A in MVP but relevant if cloud fallback added.

### Certification Readiness

> **Foundry can be deployed within an ISO 27001-certified environment. The platform addresses 26 controls fully and supports 32 more. The remaining 13 are organisational responsibilities unrelated to the tool itself. As a local-only platform with no network surface, Foundry *reduces* the scope of ISO 27001 certification rather than expanding it.**

---

*Template version 1.0. ISO 27001:2022 Annex A. Organisations should verify mapping against their own certification scope.*
