# Compliance Pack — Local Agent Foundry

> **Pre-built procurement documentation for regulated industries (NHS, finance, government).**

---

## What's Included

| Document | Audience | What It Is |
|----------|----------|------------|
| [DPIA Template](dpia-template.md) | DPO, compliance team | Data Protection Impact Assessment — pre-filled with Foundry's architecture, risks, and mitigations |
| [Model Card Template](model-card-template.md) | AI/ML team, auditor | Document each model used: capabilities, limitations, biases, quality gate performance |
| [GDPR Checklist](gdpr-checklist.md) | DPO, legal team | Article-by-article GDPR compliance verification — pre-checked where Foundry addresses requirements |
| [NHS DTAC Alignment](nhs-dtac-alignment.md) | NHS digital team, CSO | Maps Foundry to all 5 DTAC domains — Clinical Safety, Data Protection, Technical, Interoperability, Usability |
| [ISO 27001 Control Mapping](iso27001-control-mapping.md) | CISO, infosec team | All 71 Annex A controls mapped to Foundry features — 26 fully addressed, 32 partially |
| [Deployment Architecture](deployment-architecture.md) | IT operations, security | On-prem deployment patterns, data flow diagrams, security boundaries, hardware requirements |

## How to Use

1. **Start here** if you're evaluating Foundry for a regulated environment
2. **Complete the templates** — sections marked `[TODO]` need your organisation's input
3. **Consult your DPO/CISO** — these templates support your internal processes, not replace them
4. **Schedule a review** — DTAC/ISO 27001 requirements change; review annually

## Quick Answers

**"Can Foundry process patient data?"**
→ Not recommended without Caldicott Guardian approval. Use synthetic data for development.

**"Does Foundry need a DPIA?"**
→ Yes, if agents access files containing personal data. The DPIA template is pre-filled for your DPO.

**"Is Foundry a medical device?"**
→ No. It's a developer tool. Clinical applications built on Foundry require separate assessment.

**"Does Foundry send data to the cloud?"**
→ No. Zero cloud dependency. All processing is local. Air-gap capable.

**"What about model training data?"**
→ Documented in model cards. Assume public data. Use air-gapped deployment if concerned.

## Next Steps for Procurement

1. Complete the [DPIA](dpia-template.md) with your DPO
2. Fill out [Model Cards](model-card-template.md) for each model you plan to use
3. Review [ISO 27001 mapping](iso27001-control-mapping.md) with your CISO
4. If NHS: Review [DTAC alignment](nhs-dtac-alignment.md) with your Clinical Safety Officer
5. Choose a [deployment model](deployment-architecture.md) that matches your infrastructure

---

*Version 1.0. These templates are provided to accelerate procurement — they are not a substitute for your organisation's compliance processes.*
