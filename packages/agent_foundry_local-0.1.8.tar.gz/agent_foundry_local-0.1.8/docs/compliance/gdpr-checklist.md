# GDPR Compliance Checklist — Local Agent Foundry

> **For Data Protection Officers and procurement teams. Check each item when verified.**

---

## A. Data Processing Principles (Art. 5)

- [x] **Lawfulness, fairness, transparency** — Foundry processes no personal data by default. Any data processed is user-controlled.
- [x] **Purpose limitation** — Agent processing is scoped to user-defined tasks. No secondary use.
- [x] **Data minimisation** — Only files the user explicitly includes in agent working directories are processed. Audit logs are minimal.
- [x] **Accuracy** — Agent output is not treated as authoritative. Human review required per handoff protocol.
- [x] **Storage limitation** — Audit logs retained per organisation policy. Purge via `foundry audit purge`.
- [x] **Integrity and confidentiality** — Local SQLite + full-disk encryption. No network transmission.

## B. Lawful Basis for Processing (Art. 6)

- [ ] **Identify lawful basis** — If processing personal data (incidental to user files):
  - [ ] Consent (Art. 6(1)(a))
  - [ ] Contractual necessity (Art. 6(1)(b))
  - [ ] Legal obligation (Art. 6(1)(c))
  - [ ] Legitimate interests (Art. 6(1)(f)) — most likely for internal tooling
- [x] **Document lawful basis** — This checklist serves as documentation.

**Note for NHS:** If used with patient data, the lawful basis for processing health data must be established under Art. 9(2) — most commonly explicit consent (9(2)(a)) or health/social care provision (9(2)(h)).

## C. Data Subject Rights (Art. 12-23)

| Right | How Foundry Supports | Status |
|-------|---------------------|--------|
| **Right to be informed** | This checklist + DPIA | ✅ |
| **Right of access** | Audit logs exportable (`foundry audit export`) | ✅ |
| **Right to rectification** | Agent outputs are editable; logs immutable | ✅ |
| **Right to erasure** | `foundry audit purge` removes logs | ✅ |
| **Right to restrict processing** | Agent lifecycle control (pause/stop/kill) | ✅ |
| **Right to data portability** | Audit logs exportable as JSON/PDF | ✅ |
| **Right to object** | Agent stop command immediately halts processing | ✅ |
| **Automated decision-making** | Foundry does NOT make automated decisions about individuals | ✅ |

## D. Data Protection by Design (Art. 25)

- [x] **Data minimisation baked in** — no collection of personal data
- [x] **No network dependency** — data never leaves the device
- [x] **Configurable audit logging** — organisations control what's recorded
- [x] **Tool scoping** — agents only access explicitly granted tools
- [x] **Quality gates** — safety and security checks before deployment
- [x] **Local inference** — no cloud model dependency in MVP

## E. Security of Processing (Art. 32)

- [x] **Encryption at rest** — relies on full-disk encryption (FileVault/BitLocker)
- [x] **Access control** — OS-level file permissions
- [x] **No data in transit** — local-only operation
- [ ] **Encryption in transit** — N/A (no network traffic)
- [x] **Audit logging** — all agent actions recorded
- [ ] **Penetration testing** — [TODO: schedule]
- [ ] **Vulnerability management** — [TODO: process for model updates]

## F. Data Protection Officer (Art. 37-39)

- [ ] **DPO appointed?** [TODO: yes / no / N/A]
- [ ] **DPO consulted on DPIA?** [TODO: yes / no / date]
- [ ] **DPO contact:** [TODO]

## G. Data Processing Agreements (Art. 28)

**Not applicable in MVP.** The Foundry has no cloud dependencies, no third-party data processors, and no external API calls.

If cloud model fallback is added in future:
- [ ] DPA with model provider required
- [ ] Data processing location confirmed (EU/UK hosting)
- [ ] Sub-processor list obtained

## H. International Transfers (Art. 44-49)

- [x] **No international transfers** — all processing is local
- [x] **Adequacy decision not required** — data stays on-device

## I. Data Breach Notification (Art. 33-34)

**Breach scenarios and responses:**

| Scenario | Likelihood | Notification Required? | Timeline |
|----------|-----------|------------------------|----------|
| Device lost/stolen | Low | Yes — assess data exposure | 72 hours to ICO |
| Unauthorised access to device | Low | Yes — if agent logs contain personal data | 72 hours to ICO |
| Model outputs expose training data | Very Low | Assess — models are local, no extraction risk | Case by case |
| Audit log file accessed | Low | Assess — if logs contain personal data | Case by case |

- [ ] Breach response plan documented: [TODO]
- [ ] ICO registration confirmed: [TODO]

## J. Records of Processing Activities (Art. 30)

- [ ] ROPA entry created for Foundry: [TODO]
- [ ] Covers: agent processing, audit logging, model inference
- [ ] Review date: [TODO]

---

## Summary

| Requirement | Status |
|-------------|--------|
| Data minimisation | ✅ Inherent |
| Lawful basis | ⚠️ Must be documented per deployment |
| Data subject rights | ✅ All supported |
| Security | ✅ Local-only + encryption |
| DPO / DPA | ⚠️ Organisation-level requirement |
| International transfers | ✅ N/A |
| Breach notification | ⚠️ Plan required |

**Overall: The Foundry's local-only architecture makes GDPR compliance straightforward. Organisations must complete their own DPO consultation, lawful basis determination, and breach notification planning.**

---

*Template version 1.0. Does not constitute legal advice. Consult your DPO.*
