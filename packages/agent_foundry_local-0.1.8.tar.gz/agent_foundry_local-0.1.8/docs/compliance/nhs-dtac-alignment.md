# NHS DTAC Alignment — Local Agent Foundry

> **Digital Technology Assessment Criteria for health and social care. Maps Foundry features to DTAC requirements.**

---

## What is DTAC?

The NHS Digital Technology Assessment Criteria (DTAC) is the national baseline criteria for evaluating digital health technologies. It covers 5 areas:

1. Clinical Safety
2. Data Protection
3. Technical Assurance
4. Interoperability
5. Usability & Accessibility

**Important:** Local Agent Foundry is a *platform*, not a clinical application. This document shows how the platform meets DTAC requirements for tools used in NHS settings. Clinical applications built ON Foundry require their own DTAC assessment.

---

## 1. Clinical Safety (DCB 0129 / DCB 0160)

### DCB 0129 — Clinical Risk Management (Manufacturer)

| Requirement | Foundry Status | Evidence |
|-------------|---------------|----------|
| Clinical Risk Management Plan | ⚠️ N/A — platform, not clinical tool | Applications built on Foundry require their own |
| Hazard Log | ⚠️ N/A | See above |
| Clinical Safety Case Report | ⚠️ N/A | See above |
| Clinical Safety Officer appointed | [ ] [TODO: Yes / No] | Organisation-level |

### DCB 0160 — Clinical Risk Management (Deployer)

| Requirement | Foundry Status | Evidence |
|-------------|---------------|----------|
| Clinical Safety Case | ⚠️ Per-application | Builders: complete for each agent workflow |
| Hazard identification | ⚠️ Per-application | Foundry provides audit trail for review |

### Platform-Level Safety Measures

- [x] **Quality gates** — Safety gate blocks dangerous commands
- [x] **Audit trail** — Every agent action logged with timestamp
- [x] **Human-in-the-loop** — Handoff verification step
- [x] **Tool scoping** — Agents cannot access tools beyond explicit grant
- [x] **No automated clinical decisions** — Foundry does not make clinical recommendations
- [x] **Output clearly labelled** — Agent output is identifiable, not presented as clinical judgment

**Clinical Safety Officer Note:** Foundry is equivalent to a "development tool" in clinical contexts. Like an IDE or CI/CD pipeline, it is not a medical device. Clinical safety assessment is required for *applications built with it*, not the platform itself.

## 2. Data Protection

See full **GDPR Checklist** (`gdpr-checklist.md`) and **DPIA** (`dpia-template.md`).

### DTAC Data Protection Highlights

| Requirement | Foundry Status |
|-------------|---------------|
| GDPR compliance | ✅ DPIA + GDPR checklist provided |
| Data Security Protection Toolkit (DSPT) | ⚠️ Organisation-level — Foundry supports with audit trail |
| Data in transit encryption | ✅ N/A — no data in transit |
| Data at rest encryption | ✅ Full-disk encryption (FileVault/BitLocker) |
| No data sent outside UK | ✅ Local-only, no cloud dependency |
| Data minimisation | ✅ No personal data collected by platform |
| Right to erasure | ✅ `foundry audit purge` |
| IG Toolkit alignment | ✅ Audit trail supports IG reporting |

### Handling Patient Data

**⚠️ If patient data is present in files agents access:**

- [ ] Caldicott Guardian approval obtained
- [ ] Data Sharing Agreement in place
- [ ] Staff training on IG completed
- [ ] Pseudonymisation considered for non-clinical use

**Recommendation:** Use synthetic/fake data for agent development and testing. Only introduce real patient data after Caldicott Guardian approval and in a fully air-gapped environment.

## 3. Technical Assurance

### IT Health Check (ITHC)

| Requirement | Foundry Status |
|-------------|---------------|
| Penetration test | [ ] [TODO: schedule] |
| Vulnerability scan | [ ] [TODO: schedule] |
| Remediation plan | [ ] [TODO] |

**Note:** As an offline, local-only platform, the attack surface is the host machine's OS security. Standard NHS endpoint security (antivirus, encryption, access control) applies.

### Accessibility

| Standard | Status |
|----------|--------|
| WCAG 2.1 AA | ⚠️ MVP is CLI-only — accessibility via terminal standards |
| Desktop UI (planned) | [ ] WCAG 2.1 AA compliance target |

### Browser & Device Compatibility

| Aspect | Status |
|--------|--------|
| Browsers | N/A (desktop application) |
| Operating Systems | macOS (Apple Silicon), Windows (planned) |
| Mobile | N/A |

### Technical Documentation

- [x] Architecture documentation — `docs/architecture.md`
- [x] Deployment guide — `docs/compliance/deployment-architecture.md`
- [x] Audit trail — SQLite + JSON export
- [ ] API documentation — [TODO]
- [ ] User manual — [TODO]

## 4. Interoperability

### Open Standards

| Standard | Foundry Status |
|----------|---------------|
| FHIR | ⚠️ Not directly — agents could be scoped to work with FHIR APIs |
| HL7 v2 | ⚠️ Not directly |
| SNOMED CT | ⚠️ N/A — platform, not clinical app |
| ICD-10/11 | ⚠️ N/A |
| OpenAPI | ✅ Tool registry supports MCP/OpenAPI integration |

### NHS Systems Integration

| System | Integration Path |
|--------|-----------------|
| NHS Spine | Via M365 Bridge (phase 2) — agents interact through M365 Graph |
| NHSmail | Via M365 Bridge |
| e-Referral Service | Not directly supported |
| Summary Care Records | Not directly supported — not a clinical application |

### GP Connect / IM1

- **GP Connect:** Not directly supported. Agents could interact with GP Connect APIs if scoped appropriately.
- **IM1:** Not applicable at platform level.

## 5. Usability & Accessibility

### User Research

| Aspect | Status |
|--------|--------|
| User needs identified | ⚠️ MVP focused on developers/technical users |
| User testing conducted | [ ] [TODO] |
| Accessibility testing | [ ] [TODO: when desktop UI is built] |

### Key Personas

1. **AI Engineer** — Builds and orchestrates agent workflows
2. **Compliance Officer** — Reviews audit trails, runs quality gates
3. **Clinical Developer** — Builds NHS applications using agent workflows
4. **IT Administrator** — Manages deployment, model updates, security

---

## DTAC Summary Scorecard

| Domain | Score | Status |
|--------|-------|--------|
| **Clinical Safety** | 🟢 DCB 0129: N/A (platform). Safety gates + audit trail provided. | Applications built on Foundry require separate assessment. |
| **Data Protection** | 🟢 GDPR-compliant architecture. DPIA + checklist provided. | Organisation must complete their own DPO consultation. |
| **Technical Assurance** | 🟡 CLI-only MVP. ITHC pending. | Desktop UI will require WCAG 2.1 AA. |
| **Interoperability** | 🟡 Open standards support via MCP. No native FHIR/HL7. | Suitable for M365-adjacent NHS workflows. |
| **Usability** | 🟡 Developer-focused MVP. User testing pending. | Not yet suitable for non-technical NHS staff. |

### Procurement Recommendation

> **The Local Agent Foundry is suitable for NHS digital teams as a developer tool for building, testing, and auditing AI agent workflows — provided:**
> 1. It is deployed in a secure, encrypted environment (standard NHS endpoint)
> 2. No patient data is processed without Caldicott Guardian approval
> 3. Applications built with Foundry undergo separate DTAC assessment
> 4. Clinical safety assessment is completed for each clinical use case
> 5. Staff using Foundry complete NHS IG training

---

*Template version 1.0. DTAC requirements may change. Check https://www.nhsx.nhs.uk/key-tools-and-info/digital-technology-assessment-criteria-dtac/ for latest criteria.*
