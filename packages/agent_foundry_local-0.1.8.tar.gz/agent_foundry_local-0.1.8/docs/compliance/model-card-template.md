# Model Card — [Model Name]

> **Template for documenting AI models used in Agent Foundry. Complete one per model.**

---

## Model Identity

| Field | Value |
|-------|-------|
| **Model Name** | [TODO: e.g., AgenticQwen-8B-oQ4] |
| **Version** | [TODO: e.g., Q4_K_M quantisation] |
| **Provider/Developer** | [TODO: e.g., Qwen (Alibaba) / Nous Research] |
| **Architecture** | [TODO: e.g., Transformer, 8B parameters] |
| **Quantisation** | [TODO: e.g., 4-bit GGUF] |
| **Date Deployed** | [TODO] |
| **Deployment Context** | Local Agent Foundry — on-prem, offline |

## Intended Use

### Primary Use Case
[TODO: e.g., "Code generation, review, and debugging for SPFx web part development"]

### Agent Role(s)
- [ ] Builder (code generation, scaffolding)
- [ ] Reviewer (code review, quality gates)
- [ ] Tester (test generation, execution)
- [ ] Documentor (documentation generation)
- [ ] Orchestrator (multi-agent coordination)
- [ ] Other: [TODO]

### Suitable for regulated industries?
- [ ] NHS — clinical support (non-diagnostic)
- [ ] Finance — code review, documentation
- [ ] Government — policy analysis, drafting

**Limitation: These models are NOT certified medical devices. Output must be reviewed by a qualified professional.**

## Performance Characteristics

| Metric | Value | Context |
|--------|-------|---------|
| **Benchmark** | [TODO: e.g., MMLU, HumanEval] | [TODO: score] |
| **Context Window** | [TODO: e.g., 32K tokens] | [TODO] |
| **Inference Speed** | [TODO: tok/s on Apple Silicon] | [TODO: hardware] |
| **Memory Usage** | [TODO: e.g., ~6GB RAM] | [TODO: hardware] |
| **Tool-calling Reliability** | [TODO: % correct tool selections] | [TODO: eval set] |

## Known Limitations

### Technical
- [TODO: e.g., "Limited to 32K context — long files may be truncated"]
- [TODO: e.g., "Occasionally fails to escape special characters in shell commands"]
- [TODO: e.g., "Struggles with deeply nested JSON schemas"]

### Behavioural
- [TODO: e.g., "May hallucinate API endpoints that don't exist"]
- [TODO: e.g., "Tendency to over-explain simple tasks"]
- [TODO: e.g., "Sometimes suggests cloud-dependent solutions unless explicitly constrained"]

### Safety
- [TODO: e.g., "May generate plausible-looking but incorrect code"]
- [TODO: e.g., "No built-in refusal mechanism — all prompts processed"]
- [TODO: e.g., "Not aligned for clinical safety — do not use for diagnostic purposes"]

## Quality Gate Performance

| Gate | Pass Rate | Notes |
|------|-----------|-------|
| **Syntax** | [TODO: %] | [TODO] |
| **Safety** | [TODO: %] | [TODO] |
| **Behaviour** | [TODO: %] | [TODO] |
| **Security** | [TODO: %] | [TODO] |
| **Performance** | [TODO: %] | [TODO: SLA target] |

## Training Data

- [TODO: Known training data sources]
- [TODO: Date of training data cutoff]
- [ ] Training data includes PHI? No (standard LLM — cannot guarantee)
- [ ] Training data includes proprietary code? Unknown (standard LLM)

**Recommendation for regulated use:** Assume the model has been trained on publicly available data, including potentially copyrighted material. Do not expose the model to sensitive data unless in a fully air-gapped environment.

## Bias and Fairness

- [TODO: Known biases — e.g., "English-dominant, may underperform on Welsh-language content"]
- [TODO: Fairness evaluation results if available]

**Recommendation:** Output should be reviewed for bias, especially when generating content for diverse audiences (NHS patient communications, government public-facing documents).

## Deployment & Maintenance

| Aspect | Detail |
|--------|--------|
| **Update Frequency** | [TODO: e.g., "As new quantisations are released by community"] |
| **Deprecation Plan** | [TODO: e.g., "Replace when next-gen 8B models show >20% improvement on quality gates"] |
| **Rollback Procedure** | `foundry model switch <model> --version <previous>` |
| **Monitoring** | Quality gate metrics tracked via Foundry Observability |

## Regulatory Alignment

| Framework | Status | Notes |
|-----------|--------|-------|
| **GDPR** | ✅ Compliant (local inference, no data export) | No personal data processed by model |
| **NHS DTAC** | ⚠️ Clinical safety assessment required | Not a medical device |
| **ISO 27001** | ✅ A.8.1, A.8.33 mapped | See ISO 27001 control mapping |
| **EU AI Act** | ⚠️ Classification required | Likely minimal risk for current use cases |

---

*Complete one card per model. Store in `docs/compliance/model-cards/`. Review annually or when model is updated.*
