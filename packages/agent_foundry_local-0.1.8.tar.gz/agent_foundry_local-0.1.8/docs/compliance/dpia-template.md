# Data Protection Impact Assessment (DPIA) — Local Agent Foundry

> **Template for NHS/finance/government procurement. Complete the sections marked [ ] and [TODO].**

## 1. Overview

| Field | Value |
|-------|-------|
| **Project Name** | Local Agent Foundry — On-Prem Agent Platform |
| **Date of Assessment** | [TODO: date] |
| **Assessor** | [TODO: name / role] |
| **DPO Consulted** | [TODO: yes / no / N/A] |
| **Version** | 1.0 |

## 2. Description of Processing

### 2.1 What data is processed?

- [ ] **No personal data** — agents process code, configuration files, and system metadata only.
- [ ] **Organisational data** — file paths, project names, git commit hashes, tool outputs.
- [ ] **Model inference input/output** — text prompts and responses processed locally. **Not transmitted externally.**
- [ ] **Audit logs** — agent actions, timestamps, handoff chains, quality gate results. Stored in local SQLite.

**Key claim: The Foundry does not require, collect, or transmit personal data to function.** Any personal data appearing in agent I/O is incidental to the user's own files.

### 2.2 How is data collected?

- File system access (user's working directories)
- Local model inference (oMLX, llama.cpp, Ollama)
- Agent state snapshots during handoffs

### 2.3 How is data stored?

- **SQLite database** (`~/.foundry/`) — agent state, audit logs, skill registry
- **JSON files** (`~/.foundry/handoffs/`) — handoff packets
- **No cloud storage** — everything is local to the user's machine

## 3. Necessity and Proportionality

### 3.1 Why is this processing necessary?

The Foundry enables regulated organisations to use AI agents without sending data to cloud providers. This is the *less intrusive* alternative to cloud-based agent platforms (OpenHands, LangSmith, CrewAI) that require data to leave the organisation's network.

### 3.2 Could the same outcome be achieved with less data?

Yes. The Foundry is designed to be data-minimalist:
- Does not require API keys or authentication to external services
- Does not phone home — no telemetry
- Does not require network access (air-gapped operation supported)
- Audit logs are configurable — organisations can reduce verbosity

## 4. Risk Assessment

### 4.1 Data breach risk: **LOW**

- All processing is local. Breach requires physical access to the machine.
- No data in transit. No external API calls.
- SQLite files encrypted at rest via full-disk encryption (macOS FileVault / Windows BitLocker).

### 4.2 Model inference data leakage risk: **LOW**

- Models run locally (oMLX, llama.cpp). Inference is on-device.
- No cloud model fallback in MVP.
- Future cloud fallback, if added, must be opt-in with explicit user consent.

### 4.3 Audit log exposure risk: **LOW**

- Audit logs are local SQLite files.
- Export functionality (PDF/JSON) is user-initiated, not automatic.
- Logs can be purged via `foundry audit purge`.

### 4.4 Agent autonomy risk: **MEDIUM**

- Agents can execute terminal commands and modify files.
- **Mitigations:**
  - Quality gates: Safety gate blocks dangerous commands (`rm -rf /`, `DROP TABLE`, etc.)
  - Tool scoping: Each agent's toolset is explicitly configured (`--tools terminal,file`)
  - Audit trail: Every agent action is logged
  - Human-in-the-loop: Handoff protocol requires verification before deployment
  - No agent can self-escalate privileges

### 4.5 Model bias / hallucination risk: **MEDIUM**

- Local models (7-9B parameter) may hallucinate or produce biased output.
- **Mitigations:**
  - Quality gates: Behavioural gate validates agent output against expected patterns
  - Security gate: Scans for secrets in output
  - Verification commands run in handoff definition-of-done
  - Model cards document known limitations for each model

## 5. Risk Summary Matrix

| Risk | Likelihood | Impact | Residual Risk |
|------|-----------|--------|---------------|
| Data breach | Low | Medium | Low |
| Inference data leakage | Low | High | Low |
| Audit log exposure | Low | Medium | Low |
| Agent autonomy | Medium | High | Medium |
| Model bias/hallucination | Medium | Medium | Medium |

## 6. Mitigation Measures

1. **Local-only operation** — no data leaves the device
2. **Quality gates** — automated checks before deployment
3. **Tool scoping** — explicit, per-agent tool permissions
4. **Audit trail** — every action logged, exportable
5. **Air-gap support** — zero network dependency
6. **Compliance documentation** — this DPIA, plus model cards, GDPR checklist
7. **Human-in-the-loop** — verification step in handoff protocol

## 7. Consultation

- [ ] DPO consulted: [TODO]
- [ ] Security team consulted: [TODO]
- [ ] Clinical safety officer consulted (NHS): [TODO]

## 8. DPO Recommendation

- [ ] Proceed (risks adequately mitigated)
- [ ] Proceed with conditions: [TODO]
- [ ] Do not proceed: [TODO]

## 9. Review Schedule

| Review trigger | Frequency |
|---------------|-----------|
| Routine review | Annual |
| New model added | Before first use |
| New tool added | Before first use |
| Cloud fallback introduced | Before enabling |
| Security incident | Within 48 hours |

---

*Template version 1.0. For use with Local Agent Foundry v0.1+. Adapt to your organisation's DPIA template and consult your DPO.*
