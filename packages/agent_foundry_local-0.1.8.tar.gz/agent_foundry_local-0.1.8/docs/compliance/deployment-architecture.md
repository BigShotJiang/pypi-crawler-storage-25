# Deployment Architecture — Local Agent Foundry

> **On-premises deployment pattern for regulated industries. Zero cloud dependency.**

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    NHS / Finance / Government               │
│                    Secure Endpoint Device                    │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Full-Disk Encryption                      │  │
│  │          (FileVault / BitLocker / LUKS)               │  │
│  │                                                       │  │
│  │  ┌─────────────────────────────────────────────┐     │  │
│  │  │         Local Agent Foundry                  │     │  │
│  │  │                                              │     │  │
│  │  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  │     │  │
│  │  │  │  Agent   │  │  Agent   │  │  Agent   │  │     │  │
│  │  │  │ Builder  │  │ Reviewer │  │  Tester  │  │     │  │
│  │  │  └────┬─────┘  └────┬─────┘  └────┬─────┘  │     │  │
│  │  │       │             │             │        │     │  │
│  │  │       └──────┬──────┴──────┬──────┘        │     │  │
│  │  │              │  Handoff    │                │     │  │
│  │  │              │  Protocol   │                │     │  │
│  │  │              └──────┬──────┘                │     │  │
│  │  │                     │                       │     │  │
│  │  │  ┌──────────────────┼──────────────────┐   │     │  │
│  │  │  │           Quality Gates              │   │     │  │
│  │  │  │  Syntax · Safety · Behaviour · Sec   │   │     │  │
│  │  │  └──────────────────┼──────────────────┘   │     │  │
│  │  │                     │                       │     │  │
│  │  │  ┌──────────────────┼──────────────────┐   │     │  │
│  │  │  │         Observability                 │   │     │  │
│  │  │  │     Audit Log · Metrics · Health      │   │     │  │
│  │  │  └──────────────────┼──────────────────┘   │     │  │
│  │  │                     │                       │     │  │
│  │  │  ┌──────────────────┼──────────────────┐   │     │  │
│  │  │  │           Storage (SQLite)            │   │     │  │
│  │  │  │   Agent State · Audit DB · Registry   │   │     │  │
│  │  │  └──────────────────┼──────────────────┘   │     │  │
│  │  │                     │                       │     │  │
│  │  │  ┌──────────────────┼──────────────────┐   │     │  │
│  │  │  │         Model Runtime                  │   │     │  │
│  │  │  │    oMLX / llama.cpp / Ollama           │   │     │  │
│  │  │  └──────────────────────────────────────┘   │     │  │
│  │  │                                              │     │  │
│  │  └─────────────────────────────────────────────┘     │  │
│  │                                                       │  │
│  │  ┌─────────────────────┐  ┌──────────────────────┐  │  │
│  │  │    Working Files     │  │   Model Weights      │  │  │
│  │  │  ~/projects/*        │  │  ~/.cache/models/*   │  │  │
│  │  │  (user-controlled)   │  │  (downloaded offline)│  │  │
│  │  └─────────────────────┘  └──────────────────────┘  │  │
│  │                                                       │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│                        ═══════════                           │
│                         AIR GAP                              │
│                        ═══════════                           │
│                                                              │
│                    No External Network                       │
│              No API Calls · No Telemetry                    │
│               No Cloud Dependency                           │
└─────────────────────────────────────────────────────────────┘
```

## Deployment Models

### Model 1: Standalone Developer Workstation

**Use case:** Individual AI engineer building/testing agent workflows.

```
MacBook Pro (Apple Silicon) / Windows Workstation
├── Full-disk encryption: Enabled
├── Antivirus: Organisational standard
├── Foundry: Installed via pip (`pip install agent-foundry`)
├── Models: Downloaded once, loaded locally
└── Network: Optional — only needed for initial model download
```

**Requirements:**
- 16GB+ RAM (32GB recommended for 8B+ models)
- Apple Silicon (M1+) or NVIDIA GPU
- macOS 14+ / Windows 11 / Ubuntu 22.04+

### Model 2: Air-Gapped Build Server

**Use case:** CI/CD-style agent pipeline in a secure environment.

```
Dedicated Linux/macOS machine
├── Full-disk encryption: LUKS / FileVault
├── Network: Disabled after initial setup
├── Foundry: Installed offline from verified package
├── Models: Transferred via encrypted USB, verified with checksums
├── Project files: Transferred via encrypted USB or internal network share
└── Output: Exported via encrypted USB or write-once media
```

**Setup procedure:**
1. Install OS + full-disk encryption
2. Install Foundry from verified package (SHA-256 checksum verified)
3. Download models on a separate internet-connected machine
4. Verify model checksums against published hashes
5. Transfer models via encrypted USB to air-gapped machine
6. Verify model checksums again on air-gapped machine
7. Disable all network interfaces
8. Begin operation

### Model 3: Virtual Desktop Infrastructure (VDI)

**Use case:** NHS Trust / government department with centralised IT.

```
VDI Infrastructure (e.g., Citrix / Azure Virtual Desktop)
├── Golden Image: macOS / Windows with Foundry pre-installed
├── Full-disk encryption: Via VDI storage policies
├── Network: Internal-only VLAN, no internet egress
├── Models: Stored on encrypted network share, read-only
├── Audit logs: Centralised collection (opt-in)
└── Access: RBAC via Active Directory
```

## Security Boundaries

```
┌──────────────────────────────────────────┐
│ TRUST BOUNDARY: Host OS                   │
│  ┌──────────────────────────────────────┐ │
│  │ Foundry Process                       │ │
│  │  ┌────────────────────────────────┐  │ │
│  │  │ Agent 1 (Builder)               │  │ │
│  │  │  Tools: terminal, file          │  │ │
│  │  │  Working dir: ~/projects/app-a  │  │ │
│  │  └────────────────────────────────┘  │ │
│  │  ┌────────────────────────────────┐  │ │
│  │  │ Agent 2 (Reviewer)              │  │ │
│  │  │  Tools: terminal, file          │  │ │
│  │  │  Working dir: ~/projects/app-a  │  │ │
│  │  └────────────────────────────────┘  │ │
│  │                                       │ │
│  │  ⚠️ Agents share same OS user.        │ │
│  │  Tool scoping is permission-based,    │ │
│  │  not OS-level isolation (MVP).        │ │
│  └──────────────────────────────────────┘ │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │ Other Applications (browser, etc.)    │ │
│  │  ⚠️ No Foundry access unless tool      │ │
│  │  grants are explicitly configured     │ │
│  └──────────────────────────────────────┘ │
└──────────────────────────────────────────┘
```

**Note for security teams:** In MVP, agents share the same OS user and process space. For sensitive deployments, consider running agents in separate VMs or containers. OS-level sandboxing (macOS App Sandbox, Windows AppContainer) is a post-MVP improvement target.

## Network Flow (None)

```
┌────────────┐          ┌────────────┐
│   Foundry  │          │   Model    │
│   Engine   │◄────────►│  Runtime   │
└────────────┘   IPC    └────────────┘
      │
      │ File I/O only
      ▼
┌────────────┐
│  Local FS  │
│  + SQLite  │
└────────────┘

NO EXTERNAL CONNECTIONS
```

## Data Flow

```
User Request
    │
    ▼
CLI (`foundry agent start`)
    │
    ▼
Agent Engine ──► Model Runtime (local inference)
    │                   │
    │                   ▼
    │              Model Response
    │                   │
    ▼                   ▼
Agent executes tools (terminal, file)
    │
    ▼
Tool Output
    │
    ▼
Agent returns result
    │
    ├──► User (terminal output)
    └──► Audit Log (SQLite)
           │
           ▼
         Export (JSON/PDF, user-initiated only)
```

## Compliance-Relevant Configuration

```bash
# Disable all logging (maximum privacy)
foundry config set audit.log_level none

# Restrict agent tools to read-only
foundry config set agent.default_tools "read_file,search_files"

# Require human approval for all terminal commands
foundry config set agent.require_approval true

# Set data retention policy
foundry config set audit.retention_days 90

# Export audit log for compliance review
foundry audit export --from "2026-01-01" --format pdf --output compliance-report.pdf
```

## Hardware Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| **CPU** | Apple M1 / Intel i7 (4-core) | Apple M2+ / AMD Ryzen 7 |
| **RAM** | 16 GB | 32 GB (for 8B+ models) |
| **Storage** | 50 GB free | 200 GB (model cache) |
| **GPU** | Integrated (Apple Silicon) | Dedicated GPU for larger models |
| **OS** | macOS 14+ / Ubuntu 22.04+ | macOS 15+ / Ubuntu 24.04+ |
| **Network** | None required | None required |

---

*Template version 1.0. Adapt to your organisation's infrastructure standards.*
