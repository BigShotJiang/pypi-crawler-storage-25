# Getting Started — Local Agent Foundry

> **Run your first multi-agent workflow in under 10 minutes.**

## Prerequisites

- macOS (Apple Silicon) or Linux with Python 3.11+
- 16GB+ RAM
- A local model backend (oMLX recommended for Mac)

## 1. Install

```bash
# Clone and install
git clone <repo-url> agent-foundry
cd agent-foundry
pip install -e ".[dev]"

# Verify
foundry --version
```

## 2. Start a Model Backend

Choose one:

**oMLX (Apple Silicon):**
```bash
# Start oMLX server on port 8000
# See oMLX docs for setup
```

**Ollama (cross-platform):**
```bash
ollama pull qwen2.5:7b
ollama serve
```

**Dummy (no model needed — for testing):**
```bash
# Use --backend dummy with any command
```

## 3. Your First Agent

```bash
# Create a builder agent
foundry agent start builder --model qwen-8b --tools terminal,file

# List running agents
foundry agent list

# Check agent stats
foundry agent stats builder
```

## 4. Run a Task

```bash
# Simple task
foundry agent run builder "Create a file named hello.txt with 'Hello, Foundry!' in it"

# With JSON context
foundry agent run builder "Process the data" --context '{"format": "json", "output": "result.json"}'

# With context file
foundry agent run builder "Analyze" --context-file input.json
```

## 5. Multi-Agent with Handoffs

This is where Foundry shines. Two agents passing work with full state preservation:

```bash
# Start two agents
foundry agent start builder --model qwen-8b --tools terminal,file --role builder
foundry agent start reviewer --model qwen-8b --tools terminal,file --role reviewer

# Builder completes work, then handoff to reviewer
foundry handoff create \
  --from builder \
  --to reviewer \
  --task "Review hello.txt for correctness" \
  --dod "File exists,Content is correct,No syntax errors" \
  --priority high

# Reviewer accepts the handoff
foundry handoff accept <handoff-id>

# (Reviewer does their work...)

# Reviewer completes the handoff
foundry handoff complete <handoff-id> --result "All checks passed"

# View the handoff chain
foundry handoff list
foundry handoff show <handoff-id>
```

## 6. Quality Gates

Before deploying agent output, run quality gates:

```bash
# Check a file
foundry gate run --agent builder --file hello.txt

# Check text directly
foundry gate run --agent builder --text "print('hello')"

# Gates check: syntax, safety, behaviour, security
```

Example output:
```
Gate Run: ✓ PASSED
----------------------------------------
  ✓ Syntax Gate: All files parsed successfully (2.1ms)
  ✓ Safety Gate: No dangerous patterns detected (1.5ms)
  ✓ Security Gate: No secrets found (0.8ms)
```

## 7. Audit Everything

Every action is logged:

```bash
# Recent audit entries
foundry audit show --limit 20

# Filter by agent
foundry audit show --agent builder

# Filter by event type
foundry audit show --event handoff_create

# Audit statistics
foundry audit stats

# Export for compliance
foundry audit export --output compliance-report.json
foundry audit export --from "2026-01-01" --until "2026-06-01"
```

## 8. Skills

Agents can use Hermes skills for specialized knowledge:

```bash
# Discover available skills
foundry skill discover

# List registered skills
foundry skill list

# View a skill's content
foundry skill show code-review

# Start an agent with specific skills
foundry agent start expert --tools terminal,file --skills code-review,debugging
```

## Backend Management

```bash
# Check which backends are available
foundry backend health

# List models across backends
foundry backend models

# Quick test of a backend
foundry backend test --backend omlx --prompt "Say hello"
```

## Common Workflows

### Code Review Pipeline
```bash
foundry agent start builder --tools terminal,file
foundry agent run builder "Implement feature X in src/app.py"
foundry agent start reviewer --tools terminal,file
foundry handoff create --from builder --to reviewer --task "Review feature X"
foundry gate run --agent builder --file src/app.py
```

### Compliance Audit
```bash
foundry audit show --limit 100
foundry audit stats
foundry audit export --output "audit-$(date +%Y-%m-%d).json"
```

### Agent Health Check
```bash
foundry agent list
foundry agent stats builder
foundry backend health
```

## Next Steps

- Read the [Architecture](architecture.md) for deep design understanding
- Browse the [Compliance Pack](compliance/) for regulated industry deployment
- Add your own skills to the `skills/` directory
- Check `foundry --help` for all available commands

## Troubleshooting

**"oMLX backend not reachable"**
→ Start oMLX server first, or use `--backend dummy` for testing.

**"No agents running"**
→ Create an agent first with `foundry agent start <name>`.

**"Module not found" on import**
→ Run `pip install -e ".[dev]"` from the project root.

**Tests failing to collect**
→ Ensure the editable install is active: `pip install -e ".[dev]"`.
