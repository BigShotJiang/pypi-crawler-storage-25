# Documentation — Local Agent Foundry

- **[Getting Started](getting-started.md)** — Set up and run your first multi-agent workflow
- **[Architecture](architecture.md)** — Full system design, layers, and competitive landscape
- **[Compliance Pack](compliance/)** — Regulated industry procurement documentation
  - [DPIA Template](compliance/dpia-template.md)
  - [Model Card Template](compliance/model-card-template.md)
  - [GDPR Checklist](compliance/gdpr-checklist.md)
  - [NHS DTAC Alignment](compliance/nhs-dtac-alignment.md)
  - [ISO 27001 Control Mapping](compliance/iso27001-control-mapping.md)
  - [Deployment Architecture](compliance/deployment-architecture.md)
