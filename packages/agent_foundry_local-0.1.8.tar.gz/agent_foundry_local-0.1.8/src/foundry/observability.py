"""Observability — audit trail, cost tracking, health monitoring.

Every agent action is logged. Exportable. Regulated-industry ready.
Storage: SQLite. Export formats: JSON, planned PDF.
"""

from __future__ import annotations

import json
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


@dataclass
class AuditEntry:
    """A single auditable event."""
    entry_id: str = ""
    timestamp: float = field(default_factory=time.time)
    agent_name: str = ""
    event_type: str = ""  # task_start, task_complete, tool_call, handoff_create, gate_run, error
    action: str = ""  # human-readable description
    outcome: str = ""  # success, failure, pending
    details: dict[str, Any] = field(default_factory=dict)
    tokens_used: int = 0
    latency_ms: float = 0.0


class AuditLog:
    """Persistent audit log backed by SQLite.

    Schema:
      CREATE TABLE audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id TEXT UNIQUE,
        timestamp REAL,
        agent_name TEXT,
        event_type TEXT,
        action TEXT,
        outcome TEXT,
        details TEXT,  -- JSON
        tokens_used INTEGER,
        latency_ms REAL
      );
    """

    def __init__(self, db_path: str = ".foundry/audit.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    entry_id TEXT UNIQUE,
                    timestamp REAL,
                    agent_name TEXT,
                    event_type TEXT,
                    action TEXT,
                    outcome TEXT,
                    details TEXT,
                    tokens_used INTEGER DEFAULT 0,
                    latency_ms REAL DEFAULT 0.0
                )
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_audit_agent
                ON audit_log(agent_name)
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_audit_timestamp
                ON audit_log(timestamp)
            """)
            self._conn.commit()
        return self._conn

    def log(self, entry: AuditEntry) -> None:
        """Write an audit entry."""
        conn = self._get_conn()
        conn.execute(
            """INSERT OR REPLACE INTO audit_log
               (entry_id, timestamp, agent_name, event_type, action, outcome, details, tokens_used, latency_ms)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                entry.entry_id,
                entry.timestamp,
                entry.agent_name,
                entry.event_type,
                entry.action,
                entry.outcome,
                json.dumps(entry.details, default=str),
                entry.tokens_used,
                entry.latency_ms,
            ),
        )
        conn.commit()

    def log_event(
        self,
        agent_name: str,
        event_type: str,
        action: str,
        outcome: str = "success",
        details: dict | None = None,
        tokens_used: int = 0,
        latency_ms: float = 0.0,
    ) -> str:
        """Convenience: log an event and return its ID."""
        import uuid
        entry = AuditEntry(
            entry_id=str(uuid.uuid4()),
            agent_name=agent_name,
            event_type=event_type,
            action=action,
            outcome=outcome,
            details=details or {},
            tokens_used=tokens_used,
            latency_ms=latency_ms,
        )
        self.log(entry)
        return entry.entry_id

    def query(
        self,
        agent_name: str | None = None,
        event_type: str | None = None,
        since: float | None = None,
        until: float | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Query the audit log with filters."""
        conn = self._get_conn()
        conditions = []
        params: list[Any] = []

        if agent_name:
            conditions.append("agent_name = ?")
            params.append(agent_name)
        if event_type:
            conditions.append("event_type = ?")
            params.append(event_type)
        if since:
            conditions.append("timestamp >= ?")
            params.append(since)
        if until:
            conditions.append("timestamp <= ?")
            params.append(until)

        where = " AND ".join(conditions) if conditions else "1=1"
        query = f"SELECT * FROM audit_log WHERE {where} ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def export_json(
        self,
        output_path: str,
        since: float | None = None,
        until: float | None = None,
    ) -> int:
        """Export audit log to JSON file. Returns entry count."""
        entries = self.query(since=since, until=until, limit=100_000)
        export = {
            "exported_at": datetime.now(UTC).isoformat(),
            "total_entries": len(entries),
            "filters": {
                "since": since,
                "until": until,
            },
            "entries": entries,
        }
        Path(output_path).write_text(json.dumps(export, indent=2, default=str))
        return len(entries)

    def get_stats(self) -> dict[str, Any]:
        """Get aggregate statistics."""
        conn = self._get_conn()
        stats = {}

        # Total entries
        row = conn.execute("SELECT COUNT(*) as c FROM audit_log").fetchone()
        stats["total_entries"] = row["c"]

        # By agent
        rows = conn.execute(
            "SELECT agent_name, COUNT(*) as c FROM audit_log GROUP BY agent_name ORDER BY c DESC"
        ).fetchall()
        stats["by_agent"] = {r["agent_name"]: r["c"] for r in rows}

        # By event type
        rows = conn.execute(
            "SELECT event_type, COUNT(*) as c FROM audit_log GROUP BY event_type ORDER BY c DESC"
        ).fetchall()
        stats["by_event_type"] = {r["event_type"]: r["c"] for r in rows}

        # Total tokens
        row = conn.execute("SELECT SUM(tokens_used) as t FROM audit_log").fetchone()
        stats["total_tokens"] = row["t"] or 0

        # Failure count
        row = conn.execute(
            "SELECT COUNT(*) as c FROM audit_log WHERE outcome = 'failure'"
        ).fetchone()
        stats["failures"] = row["c"]

        return stats

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
