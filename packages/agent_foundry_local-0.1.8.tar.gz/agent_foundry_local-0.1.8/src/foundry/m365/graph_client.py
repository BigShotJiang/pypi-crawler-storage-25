"""Microsoft Graph API client.

Thin wrapper around httpx for calling Microsoft Graph endpoints.
Handles authentication, pagination, and error responses.
"""

from __future__ import annotations

import json
from urllib.parse import urljoin

import httpx

from foundry.m365.auth import M365Auth, M365Credentials

GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0/"


class GraphError(Exception):
    """Raised when the Graph API returns an error."""

    def __init__(self, status_code: int, message: str, details: dict | None = None):
        self.status_code = status_code
        self.message = message
        self.details = details or {}
        super().__init__(f"Graph API error {status_code}: {message}")


class GraphClient:
    """Authenticated Microsoft Graph client for Foundry agents."""

    def __init__(self, auth: M365Auth):
        self._auth = auth
        self._creds: M365Credentials | None = None
        self._client = httpx.Client(timeout=30.0)

    @property
    def _token(self) -> str:
        """Lazy token acquisition — prompts for auth on first use."""
        if self._creds is None or self._creds.expired:
            self._creds = self._auth.get_token()
        return self._creds.access_token

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    # ── Low-level request ──────────────────────────────────────────

    def get(self, path: str, params: dict | None = None) -> dict:
        """GET a Graph API endpoint. Returns parsed JSON."""
        url = urljoin(GRAPH_BASE_URL, path.lstrip("/"))
        resp = self._client.get(url, headers=self._headers(), params=params)
        return self._handle_response(resp)

    def post(self, path: str, body: dict) -> dict:
        """POST to a Graph API endpoint."""
        url = urljoin(GRAPH_BASE_URL, path.lstrip("/"))
        resp = self._client.post(url, headers=self._headers(), json=body)
        return self._handle_response(resp)

    def patch(self, path: str, body: dict) -> dict:
        """PATCH a Graph API resource."""
        url = urljoin(GRAPH_BASE_URL, path.lstrip("/"))
        resp = self._client.patch(url, headers=self._headers(), json=body)
        return self._handle_response(resp)

    def delete(self, path: str) -> bool:
        """DELETE a Graph API resource. Returns True on success."""
        url = urljoin(GRAPH_BASE_URL, path.lstrip("/"))
        resp = self._client.delete(url, headers=self._headers())
        if resp.status_code == 204:
            return True
        self._handle_response(resp)
        return True

    def _handle_response(self, resp: httpx.Response) -> dict:
        """Parse response or raise GraphError."""
        if resp.status_code < 300:
            if resp.status_code == 204:
                return {}
            return resp.json()

        try:
            error_data = resp.json().get("error", {})
            message = error_data.get("message", resp.text)
            raise GraphError(resp.status_code, message, error_data)
        except (json.JSONDecodeError, KeyError) as err:
            raise GraphError(resp.status_code, resp.text) from err

    # ── Pagination ─────────────────────────────────────────────────

    def get_all(self, path: str, params: dict | None = None) -> list[dict]:
        """GET with automatic pagination — collects all pages."""
        results: list[dict] = []
        next_url: str | None = None

        while True:
            if next_url:
                resp = self._client.get(next_url, headers=self._headers())
                data = self._handle_response(resp)
            else:
                data = self.get(path, params)

            results.extend(data.get("value", []))

            next_url = data.get("@odata.nextLink")
            if not next_url:
                break

        return results

    def close(self) -> None:
        self._client.close()

    # ── User ───────────────────────────────────────────────────────

    def me(self) -> dict:
        """Get the authenticated user's profile."""
        return self.get("/me")

    def user(self, user_id: str) -> dict:
        """Get a user by ID or UPN."""
        return self.get(f"/users/{user_id}")

    # ── Sites ──────────────────────────────────────────────────────

    def sites(self, search: str = "") -> list[dict]:
        """Search for SharePoint sites."""
        if search:
            return self.get_all(f"/sites?search={search}")
        return self.get_all("/sites?search=*")

    def site_by_id(self, site_id: str) -> dict:
        """Get a site by ID."""
        return self.get(f"/sites/{site_id}")

    def site_by_url(self, site_url: str) -> dict:
        """Get a site by URL (e.g., 'contoso.sharepoint.com:/sites/MySite')."""
        return self.get(f"/sites/{site_url}")

    # ── Lists ──────────────────────────────────────────────────────

    def lists(self, site_id: str) -> list[dict]:
        """List all lists in a SharePoint site."""
        return self.get_all(f"/sites/{site_id}/lists")

    def list_items(self, site_id: str, list_id: str, expand: str = "fields") -> list[dict]:
        """Get all items from a SharePoint list."""
        return self.get_all(
            f"/sites/{site_id}/lists/{list_id}/items",
            params={"expand": expand},
        )

    def create_list_item(self, site_id: str, list_id: str, fields: dict) -> dict:
        """Create a new item in a SharePoint list."""
        return self.post(
            f"/sites/{site_id}/lists/{list_id}/items",
            body={"fields": fields},
        )

    def update_list_item(self, site_id: str, list_id: str, item_id: str, fields: dict) -> dict:
        """Update an existing list item."""
        return self.patch(
            f"/sites/{site_id}/lists/{list_id}/items/{item_id}",
            body={"fields": fields},
        )

    def delete_list_item(self, site_id: str, list_id: str, item_id: str) -> bool:
        """Delete a list item."""
        return self.delete(f"/sites/{site_id}/lists/{list_id}/items/{item_id}")

    # ── Drives / Files ─────────────────────────────────────────────

    def drives(self, site_id: str) -> list[dict]:
        """List document libraries (drives) in a site."""
        return self.get_all(f"/sites/{site_id}/drives")

    def drive_children(self, drive_id: str, path: str = "/") -> list[dict]:
        """List files/folders in a drive."""
        item_path = f"root:{path}:/children" if path and path != "/" else "root/children"
        return self.get_all(f"/drives/{drive_id}/{item_path}")

    def drive_item_content(self, drive_id: str, item_id: str) -> bytes:
        """Download a file's content."""
        url = urljoin(GRAPH_BASE_URL, f"/drives/{drive_id}/items/{item_id}/content")
        resp = self._client.get(url, headers=self._headers())
        if resp.status_code == 200:
            return resp.content
        self._handle_response(resp)
        return b""

    def upload_file(self, drive_id: str, parent_path: str, filename: str, content: bytes) -> dict:
        """Upload a file to a drive."""
        path = f"{parent_path}/{filename}".replace("//", "/")
        url = urljoin(GRAPH_BASE_URL,
            f"/drives/{drive_id}/root:{path}:/content"
        )
        resp = self._client.put(
            url,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/octet-stream",
            },
            content=content,
        )
        return self._handle_response(resp)

    # ── Teams ──────────────────────────────────────────────────────

    def my_teams(self) -> list[dict]:
        """List the user's joined teams."""
        return self.get_all("/me/joinedTeams")

    def team_channels(self, team_id: str) -> list[dict]:
        """List channels in a team."""
        return self.get_all(f"/teams/{team_id}/channels")

    def channel_messages(self, team_id: str, channel_id: str, top: int = 50) -> list[dict]:
        """Get messages from a channel."""
        return self.get_all(
            f"/teams/{team_id}/channels/{channel_id}/messages",
            params={"top": top},
        )

    def send_channel_message(self, team_id: str, channel_id: str, content: str) -> dict:
        """Send a message to a Teams channel."""
        return self.post(
            f"/teams/{team_id}/channels/{channel_id}/messages",
            body={
                "body": {
                    "contentType": "html",
                    "content": content,
                }
            },
        )

    def send_chat_message(self, chat_id: str, content: str) -> dict:
        """Send a message to a Teams chat."""
        return self.post(
            f"/chats/{chat_id}/messages",
            body={
                "body": {
                    "contentType": "html",
                    "content": content,
                }
            },
        )

    # ── Chat ───────────────────────────────────────────────────────

    def chats(self) -> list[dict]:
        """List the user's chats."""
        return self.get_all("/me/chats")
