"""SharePoint operations — lists, libraries, pages, search.

High-level wrapper around GraphClient for common SharePoint tasks.
Designed for agent tool calling — methods return structured dicts, not raw Graph responses.
"""

from __future__ import annotations

from typing import Any

from foundry.m365.graph_client import GraphClient


class SharePointClient:
    """Agent-friendly SharePoint client."""

    def __init__(self, graph: GraphClient):
        self._g = graph

    # ── Sites ──────────────────────────────────────────────────────

    def find_site(self, query: str) -> list[dict[str, Any]]:
        """Search for SharePoint sites by name or URL."""
        sites = self._g.sites(search=query)
        return [
            {
                "id": s.get("id"),
                "name": s.get("name"),
                "display_name": s.get("displayName"),
                "url": s.get("webUrl"),
                "description": s.get("description", ""),
            }
            for s in sites
        ]

    def get_site(self, site_id: str) -> dict[str, Any]:
        """Get site details by ID."""
        s = self._g.site_by_id(site_id)
        return {
            "id": s.get("id"),
            "name": s.get("name"),
            "display_name": s.get("displayName"),
            "url": s.get("webUrl"),
        }

    # ── Lists ──────────────────────────────────────────────────────

    def get_lists(self, site_id: str) -> list[dict[str, Any]]:
        """Get all lists in a site."""
        lists = self._g.lists(site_id)
        return [
            {
                "id": lst.get("id"),
                "name": lst.get("name"),
                "display_name": lst.get("displayName"),
                "description": lst.get("description", ""),
            }
            for lst in lists
        ]

    def get_list_items(
        self, site_id: str, list_id: str
    ) -> dict[str, Any]:
        """Get all items from a list, with fields flattened."""
        items = self._g.list_items(site_id, list_id)
        return {
            "count": len(items),
            "items": [
                {
                    "id": item.get("id"),
                    **item.get("fields", {}),
                }
                for item in items
            ],
        }

    def add_list_item(
        self, site_id: str, list_id: str, **fields
    ) -> dict[str, Any]:
        """Add an item to a SharePoint list. Pass field values as kwargs.

        Example: add_list_item(site_id, list_id, Title="Hello", Status="Active")
        """
        result = self._g.create_list_item(site_id, list_id, fields)
        return {
            "id": result.get("id"),
            "created": True,
            **result.get("fields", {}),
        }

    def update_list_item(
        self, site_id: str, list_id: str, item_id: str, **fields
    ) -> dict[str, Any]:
        """Update fields on a list item."""
        result = self._g.update_list_item(site_id, list_id, item_id, fields)
        return {
            "id": result.get("id"),
            "updated": True,
            **result.get("fields", {}),
        }

    def delete_list_item(self, site_id: str, list_id: str, item_id: str) -> dict[str, Any]:
        """Delete a list item."""
        self._g.delete_list_item(site_id, list_id, item_id)
        return {"id": item_id, "deleted": True}

    # ── Document Libraries ─────────────────────────────────────────

    def get_libraries(self, site_id: str) -> list[dict[str, Any]]:
        """Get all document libraries in a site."""
        drives = self._g.drives(site_id)
        return [
            {
                "id": d.get("id"),
                "name": d.get("name"),
                "type": d.get("driveType"),
                "url": d.get("webUrl"),
            }
            for d in drives
        ]

    def list_files(
        self, drive_id: str, path: str = "/"
    ) -> dict[str, Any]:
        """List files and folders in a document library."""
        items = self._g.drive_children(drive_id, path)
        files = []
        folders = []
        for item in items:
            entry = {
                "id": item.get("id"),
                "name": item.get("name"),
                "size": item.get("size", 0),
                "url": item.get("webUrl"),
            }
            if item.get("folder"):
                folders.append(entry)
            else:
                files.append(entry)

        return {"path": path, "files": files, "folders": folders, "count": len(items)}

    def download_file(self, drive_id: str, item_id: str, output_path: str) -> dict[str, Any]:
        """Download a file from SharePoint to local disk."""
        content = self._g.drive_item_content(drive_id, item_id)
        from pathlib import Path

        p = Path(output_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(content)
        return {"path": str(p), "size": len(content), "downloaded": True}

    def upload_file(
        self, drive_id: str, folder: str, local_path: str
    ) -> dict[str, Any]:
        """Upload a local file to a SharePoint document library."""
        from pathlib import Path

        p = Path(local_path)
        content = p.read_bytes()
        result = self._g.upload_file(drive_id, folder, p.name, content)
        return {
            "name": result.get("name"),
            "id": result.get("id"),
            "url": result.get("webUrl"),
            "uploaded": True,
        }

    # ── Search ─────────────────────────────────────────────────────

    def search(self, query: str) -> list[dict[str, Any]]:
        """Search SharePoint content (files, list items, pages)."""
        results = self._g.get_all(
            "/search/query",
            params={
                "queryText": query,
                "select": "Title,Path,Url,FileType,LastModifiedTime",
            },
        )
        hits = []
        for table in results:
            for row in table.get("Rows", []):
                cells = {c["Key"]: c["Value"] for c in row.get("Cells", [])}
                hits.append({
                    "title": cells.get("Title", ""),
                    "path": cells.get("Path", ""),
                    "url": cells.get("Url", ""),
                    "type": cells.get("FileType", ""),
                })
        return hits
