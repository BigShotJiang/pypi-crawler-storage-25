"""Power Platform operations — Power Automate triggers, Dataverse queries.

Connects Foundry agents to the Power Platform ecosystem.
Uses the same Graph + Power Platform API auth flow.
"""

from __future__ import annotations

from typing import Any

from foundry.m365.graph_client import GraphClient


class PowerPlatformClient:
    """Agent-friendly Power Platform client."""

    POWERAPPS_BASE = "https://api.powerapps.com"
    FLOW_BASE = "https://api.flow.microsoft.com"

    def __init__(self, graph: GraphClient):
        self._g = graph
        self._token: str = ""

    def _ensure_token(self) -> str:
        """Get a token for Power Platform APIs."""
        if not self._token:
            self._token = self._g._token
            self._token = self._g._token  # refresh if needed
        return self._token

    # ── Environments ───────────────────────────────────────────────

    def get_environments(self) -> list[dict[str, Any]]:
        """List Power Platform environments the user has access to."""
        # Available via Graph /powerApps/environments (beta endpoint)
        try:
            envs = self._g.get_all("/powerApps/environments")
            return [
                {
                    "id": e.get("name"),  # environment ID
                    "display_name": e.get("properties", {}).get("displayName"),
                    "type": e.get("properties", {}).get("environmentType"),
                    "region": e.get("properties", {}).get("location"),
                }
                for e in envs
            ]
        except Exception:
            return []

    # ── Dataverse ──────────────────────────────────────────────────

    def query_dataverse(
        self, environment_id: str, table: str, filter_expr: str = "", top: int = 100
    ) -> dict[str, Any]:
        """Query a Dataverse table using OData.

        Example: query_dataverse(env_id, "accounts", "name eq 'Contoso'")
        """
        from urllib.parse import quote

        base_url = (
            f"{self.POWERAPPS_BASE}/providers/Microsoft.PowerApps/"
            f"environments/{environment_id}/data/ Microsoft.Dynamics.CRM/"
            f"{quote(table)}"
        )

        params = {"$top": top}
        if filter_expr:
            params["$filter"] = filter_expr

        try:
            results = self._g.get_all(base_url, params=params)
            return {"table": table, "count": len(results), "records": results}
        except Exception as e:
            return {"table": table, "error": str(e)}

    # ── Power Automate ─────────────────────────────────────────────

    def list_flows(self, environment_id: str) -> list[dict[str, Any]]:
        """List Power Automate flows in an environment."""
        try:
            flows = self._g.get_all(
                f"/powerAutomate/flows?$filter=environmentName eq '{environment_id}'"
            )
            return [
                {
                    "id": f.get("name"),
                    "display_name": f.get("properties", {}).get("displayName"),
                    "state": f.get("properties", {}).get("state"),
                    "created": f.get("properties", {}).get("createdTime"),
                }
                for f in flows
            ]
        except Exception:
            return []

    def trigger_flow(
        self,
        environment_id: str,
        flow_id: str,
        payload: dict | None = None,
    ) -> dict[str, Any]:
        """Trigger a Power Automate flow with an optional JSON payload.

        Note: Flow must have a 'When an HTTP request is received' trigger
        configured with the appropriate schema.
        """
        import httpx

        trigger_url = (
            f"{self.FLOW_BASE}/providers/Microsoft.ProcessSimple/"
            f"environments/{environment_id}/flows/{flow_id}/triggers/manual/paths/invoke"
        )
        params = {"api-version": "2016-06-01"}

        try:
            resp = httpx.post(
                trigger_url,
                params=params,
                json=payload or {},
                headers={
                    "Authorization": f"Bearer {self._ensure_token()}",
                    "Content-Type": "application/json",
                },
                timeout=30.0,
            )
            if resp.status_code < 300:
                return {
                    "triggered": True,
                    "flow_id": flow_id,
                    "response": resp.json() if resp.text else {},
                }
            return {"triggered": False, "error": resp.text, "status": resp.status_code}
        except Exception as e:
            return {"triggered": False, "error": str(e)}
