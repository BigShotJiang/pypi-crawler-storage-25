"""Microsoft Graph authentication via MSAL.

Supports two flows:
- Device code: Interactive CLI login (user browses to https://microsoft.com/devicelogin)
- Client credentials: Daemon/app-only (certificate or secret)

Credentials are cached to disk so agents don't re-authenticate every session.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

# msal is an optional dependency — M365 Bridge won't work without it
try:
    import msal
    HAS_MSAL = True
except ImportError:
    HAS_MSAL = False


@dataclass
class M365Credentials:
    """OAuth token + expiry."""

    access_token: str
    refresh_token: str | None = None
    expires_at: float = 0.0
    tenant_id: str = ""
    scopes: list[str] | None = None

    @property
    def expired(self) -> bool:
        return time.time() > (self.expires_at - 60)

    @property
    def valid(self) -> bool:
        return bool(self.access_token) and not self.expired


class M365Auth:
    """Handles MSAL authentication with token caching."""

    # Default scopes for Foundry M365 Bridge
    DEFAULT_SCOPES = [
        "Sites.ReadWrite.All",
        "Files.ReadWrite.All",
        "Team.ReadBasic.All",
        "ChannelMessage.Read.All",
        "ChannelMessage.Send",
        "User.Read",
        "offline_access",
    ]

    def __init__(
        self,
        client_id: str,
        tenant_id: str = "common",
        scopes: list[str] | None = None,
        cache_dir: Path | str | None = None,
    ):
        if not HAS_MSAL:
            raise ImportError(
                "msal is required for M365 Bridge. Install with: pip install msal"
            )
        self.client_id = client_id
        self.tenant_id = tenant_id
        self.scopes = scopes or self.DEFAULT_SCOPES
        self.cache_dir = Path(cache_dir or ".foundry/m365")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache_file = self.cache_dir / "token_cache.json"
        self._app = msal.PublicClientApplication(
            client_id,
            authority=f"https://login.microsoftonline.com/{tenant_id}",
            token_cache=self._build_cache(),
        )

    def _build_cache(self):
        """Load cached tokens from disk."""
        if self._cache_file.exists():
            try:
                return msal.SerializableTokenCache()
            except Exception:
                pass
        return msal.TokenCache()

    def _save_cache(self):
        """Persist token cache to disk."""
        if hasattr(self._app.token_cache, "serialize"):
            self._cache_file.write_text(self._app.token_cache.serialize())

    def device_code_flow(self) -> M365Credentials | None:
        """Interactive device code authentication.

        Prints a URL + code for the user to enter in a browser.
        Returns credentials on success, None if cancelled.
        """
        flow = self._app.initiate_device_flow(scopes=self.scopes)
        if "user_code" not in flow:
            return None

        print("\n🔑 Sign in to Microsoft 365")
        print(f"   URL:  {flow['verification_uri']}")
        print(f"   Code: {flow['user_code']}")
        print("\n   Waiting for authentication...")

        result = self._app.acquire_token_by_device_flow(flow)
        self._save_cache()

        if "access_token" in result:
            return M365Credentials(
                access_token=result["access_token"],
                refresh_token=result.get("refresh_token"),
                expires_at=time.time() + result.get("expires_in", 3600),
                tenant_id=self.tenant_id,
                scopes=self.scopes,
            )

        error = result.get("error_description", result.get("error", "unknown"))
        print(f"   ✗ Authentication failed: {error}")
        return None

    def acquire_token_silent(self) -> M365Credentials | None:
        """Try to get a token from cache without user interaction."""
        accounts = self._app.get_accounts()
        if accounts:
            result = self._app.acquire_token_silent(
                scopes=self.scopes, account=accounts[0]
            )
            if result and "access_token" in result:
                self._save_cache()
                return M365Credentials(
                    access_token=result["access_token"],
                    refresh_token=result.get("refresh_token"),
                    expires_at=time.time() + result.get("expires_in", 3600),
                    tenant_id=self.tenant_id,
                    scopes=self.scopes,
                )
        return None

    def get_token(self) -> M365Credentials:
        """Get a valid token — silent if possible, device code if needed."""
        creds = self.acquire_token_silent()
        if creds and creds.valid:
            return creds

        creds = self.device_code_flow()
        if creds is None:
            raise RuntimeError("M365 authentication failed. Could not obtain token.")
        return creds

    def clear_cache(self) -> None:
        """Remove cached tokens."""
        self._cache_file.unlink(missing_ok=True)
