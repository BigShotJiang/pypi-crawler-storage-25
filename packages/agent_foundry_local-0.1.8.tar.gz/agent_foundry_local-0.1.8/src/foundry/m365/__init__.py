"""M365 Bridge — Connect agents to Microsoft 365.

SharePoint lists/libraries/pages, Teams messaging, Graph API, Power Platform.
Uses MSAL for device-code and client-credentials authentication.
"""

from foundry.m365.graph_client import GraphClient
from foundry.m365.power_platform import PowerPlatformClient
from foundry.m365.sharepoint import SharePointClient
from foundry.m365.teams import TeamsClient

__all__ = [
    "GraphClient",
    "SharePointClient",
    "TeamsClient",
    "PowerPlatformClient",
]
