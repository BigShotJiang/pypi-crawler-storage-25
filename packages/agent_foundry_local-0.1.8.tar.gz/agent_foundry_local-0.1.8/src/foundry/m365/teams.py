"""Teams operations — channels, messages, chats.

High-level wrapper for Microsoft Teams Graph API calls.
"""

from __future__ import annotations

from typing import Any

from foundry.m365.graph_client import GraphClient


class TeamsClient:
    """Agent-friendly Teams client."""

    def __init__(self, graph: GraphClient):
        self._g = graph

    def my_teams(self) -> list[dict[str, Any]]:
        """List all teams the authenticated user belongs to."""
        teams = self._g.my_teams()
        return [
            {
                "id": t.get("id"),
                "display_name": t.get("displayName"),
                "description": t.get("description", ""),
            }
            for t in teams
        ]

    def get_channels(self, team_id: str) -> list[dict[str, Any]]:
        """List channels in a team."""
        channels = self._g.team_channels(team_id)
        return [
            {
                "id": c.get("id"),
                "display_name": c.get("displayName"),
                "description": c.get("description", ""),
            }
            for c in channels
        ]

    def get_messages(
        self, team_id: str, channel_id: str, limit: int = 50
    ) -> dict[str, Any]:
        """Get recent messages from a channel."""
        messages = self._g.channel_messages(team_id, channel_id, top=limit)
        return {
            "count": len(messages),
            "messages": [
                {
                    "id": m.get("id"),
                    "from": m.get("from", {}).get("user", {}).get("displayName", "Unknown"),
                    "body": m.get("body", {}).get("content", ""),
                    "created": m.get("createdDateTime"),
                }
                for m in messages
            ],
        }

    def send_to_channel(
        self, team_id: str, channel_id: str, message: str
    ) -> dict[str, Any]:
        """Send a message to a Teams channel."""
        result = self._g.send_channel_message(team_id, channel_id, message)
        return {
            "id": result.get("id"),
            "sent": True,
            "channel": channel_id,
        }

    def get_chats(self) -> list[dict[str, Any]]:
        """List all chats."""
        chats = self._g.chats()
        return [
            {
                "id": c.get("id"),
                "topic": c.get("topic", ""),
                "type": c.get("chatType"),
                "last_updated": c.get("lastUpdatedDateTime"),
            }
            for c in chats
        ]

    def send_to_chat(self, chat_id: str, message: str) -> dict[str, Any]:
        """Send a message to a Teams chat."""
        result = self._g.send_chat_message(chat_id, message)
        return {
            "id": result.get("id"),
            "sent": True,
            "chat": chat_id,
        }
