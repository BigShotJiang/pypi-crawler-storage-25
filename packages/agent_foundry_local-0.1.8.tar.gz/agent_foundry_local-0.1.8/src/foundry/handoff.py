"""Handoff protocol — formal agent-to-agent work transfer.

Implements the handoff packet format from the architecture:
  1. Agent A completes work → snapshots state → creates handoff packet
  2. Agent B receives handoff → verifies state → acknowledges
  3. Agent B works → meets DoD → verifies → marks complete
  4. Audit log records entire handoff chain

This is the compliance paper trail for regulated industries.
"""

from __future__ import annotations

import json
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class HandoffStatus(Enum):
    CREATED = "created"
    ACCEPTED = "accepted"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    REJECTED = "rejected"


@dataclass
class HandoffPacket:
    """Formal handoff from one agent to another.

    This is the core protocol. Every field is auditable.
    """
    handoff_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    from_agent: str = ""
    to_agent: str = ""

    # What needs doing
    task: dict[str, Any] = field(default_factory=dict)
    # {"goal": "...", "priority": "high|medium|low"}

    # State at time of handoff
    state_snapshot: dict[str, Any] = field(default_factory=dict)
    # {"dirty_files": [...], "git_hash": "...", "working_dir": "...", "env_vars": {}}

    # Context for the receiving agent
    context: dict[str, Any] = field(default_factory=dict)
    # {"decisions_made": [...], "blockers": [...], "notes": "..."}

    # What "done" looks like
    definition_of_done: list[str] = field(default_factory=list)

    # How to verify
    verification: dict[str, Any] = field(default_factory=dict)
    # {"commands": [...], "expected_results": "..."}

    # Timestamps
    created_at: float = field(default_factory=time.time)
    accepted_at: float | None = None
    completed_at: float | None = None

    # Status
    status: HandoffStatus = HandoffStatus.CREATED

    # Result
    result: str | None = None
    verification_passed: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "handoff_id": self.handoff_id,
            "from_agent": self.from_agent,
            "to_agent": self.to_agent,
            "task": self.task,
            "state_snapshot": self.state_snapshot,
            "context": self.context,
            "definition_of_done": self.definition_of_done,
            "verification": self.verification,
            "created_at": self.created_at,
            "accepted_at": self.accepted_at,
            "completed_at": self.completed_at,
            "status": self.status.value,
            "result": self.result,
            "verification_passed": self.verification_passed,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, default=str)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HandoffPacket:
        return cls(
            handoff_id=data.get("handoff_id", ""),
            from_agent=data.get("from_agent", ""),
            to_agent=data.get("to_agent", ""),
            task=data.get("task", {}),
            state_snapshot=data.get("state_snapshot", {}),
            context=data.get("context", {}),
            definition_of_done=data.get("definition_of_done", []),
            verification=data.get("verification", {}),
            created_at=data.get("created_at", time.time()),
            accepted_at=data.get("accepted_at"),
            completed_at=data.get("completed_at"),
            status=HandoffStatus(data.get("status", "created")),
            result=data.get("result"),
            verification_passed=data.get("verification_passed"),
        )


class HandoffManager:
    """Manages the handoff lifecycle between agents."""

    def __init__(self, storage_dir: str = ".foundry/handoffs"):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self._handoffs: dict[str, HandoffPacket] = {}
        self.load_all()  # restore from disk on init

    def create(
        self,
        from_agent: str,
        to_agent: str,
        task: dict[str, Any],
        definition_of_done: list[str] | None = None,
        context: dict[str, Any] | None = None,
        working_dir: str | None = None,
    ) -> HandoffPacket:
        """Create a new handoff packet.

        Captures current state snapshot automatically (git hash, dirty files).
        """
        # Auto-capture state snapshot
        state_snapshot = self._capture_state(working_dir)

        packet = HandoffPacket(
            from_agent=from_agent,
            to_agent=to_agent,
            task=task,
            state_snapshot=state_snapshot,
            context=context or {},
            definition_of_done=definition_of_done or [],
            verification={
                "commands": self._infer_verification_commands(definition_of_done or []),
                "expected_results": "All verification commands exit 0",
            },
        )

        self._handoffs[packet.handoff_id] = packet
        self._save(packet)
        return packet

    def accept(self, handoff_id: str) -> HandoffPacket | None:
        """Accept a handoff — the receiving agent acknowledges."""
        packet = self._handoffs.get(handoff_id)
        if packet is None:
            return None
        if packet.status != HandoffStatus.CREATED:
            raise ValueError(f"Handoff {handoff_id} is {packet.status.value}, not 'created'")

        packet.status = HandoffStatus.ACCEPTED
        packet.accepted_at = time.time()
        self._save(packet)
        return packet

    def start_work(self, handoff_id: str) -> HandoffPacket | None:
        """Mark handoff as in progress."""
        packet = self._handoffs.get(handoff_id)
        if packet is None:
            return None
        packet.status = HandoffStatus.IN_PROGRESS
        self._save(packet)
        return packet

    def complete(
        self,
        handoff_id: str,
        result: str,
        verification_passed: bool,
    ) -> HandoffPacket | None:
        """Complete a handoff with result and verification status."""
        packet = self._handoffs.get(handoff_id)
        if packet is None:
            return None

        packet.status = HandoffStatus.COMPLETED if verification_passed else HandoffStatus.FAILED
        packet.completed_at = time.time()
        packet.result = result
        packet.verification_passed = verification_passed
        self._save(packet)
        return packet

    def reject(self, handoff_id: str, reason: str) -> HandoffPacket | None:
        """Reject a handoff."""
        packet = self._handoffs.get(handoff_id)
        if packet is None:
            return None

        packet.status = HandoffStatus.REJECTED
        packet.completed_at = time.time()
        packet.result = reason
        packet.verification_passed = False
        self._save(packet)
        return packet

    def get(self, handoff_id: str) -> HandoffPacket | None:
        return self._handoffs.get(handoff_id)

    def list_all(self) -> list[HandoffPacket]:
        return list(self._handoffs.values())

    def list_for_agent(self, agent_name: str) -> list[HandoffPacket]:
        return [
            h for h in self._handoffs.values()
            if h.from_agent == agent_name or h.to_agent == agent_name
        ]

    def run_verification(self, handoff_id: str, working_dir: str | None = None) -> tuple[bool, str]:
        """Run verification commands from the handoff's definition of done."""
        packet = self._handoffs.get(handoff_id)
        if packet is None:
            return False, "Handoff not found"

        commands = packet.verification.get("commands", [])
        if not commands:
            return True, "No verification commands defined"

        results = []
        all_passed = True

        for cmd in commands:
            try:
                proc = subprocess.run(
                    cmd,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=60,
                    cwd=working_dir or packet.state_snapshot.get("working_dir"),
                )
                passed = proc.returncode == 0
                if not passed:
                    all_passed = False
                results.append(f"{'✓' if passed else '✗'} {cmd}\n  {proc.stdout[:200]}{proc.stderr[:200]}")
            except Exception as e:
                all_passed = False
                results.append(f"✗ {cmd}\n  Error: {e}")

        return all_passed, "\n".join(results)

    def _capture_state(self, working_dir: str | None) -> dict[str, Any]:
        """Auto-capture git state and dirty files."""
        snapshot: dict[str, Any] = {
            "working_dir": working_dir or str(Path.cwd()),
            "env_vars": {},
        }

        if working_dir:
            wd = Path(working_dir)
            if (wd / ".git").exists():
                try:
                    # Git hash
                    proc = subprocess.run(
                        ["git", "rev-parse", "HEAD"],
                        capture_output=True, text=True, timeout=5, cwd=working_dir,
                    )
                    if proc.returncode == 0:
                        snapshot["git_hash"] = proc.stdout.strip()

                    # Dirty files
                    proc = subprocess.run(
                        ["git", "diff", "--name-only"],
                        capture_output=True, text=True, timeout=5, cwd=working_dir,
                    )
                    dirty = [f for f in proc.stdout.strip().split("\n") if f]
                    proc2 = subprocess.run(
                        ["git", "diff", "--cached", "--name-only"],
                        capture_output=True, text=True, timeout=5, cwd=working_dir,
                    )
                    dirty.extend(f for f in proc2.stdout.strip().split("\n") if f)
                    snapshot["dirty_files"] = list(set(dirty))
                except Exception:
                    pass

        return snapshot

    def _infer_verification_commands(self, dod: list[str]) -> list[str]:
        """Infer verification commands from definition of done items."""
        commands = []
        for item in dod:
            item_lower = item.lower()
            if "test" in item_lower:
                commands.append("pytest -x --tb=short")
            if "lint" in item_lower:
                commands.append("ruff check src/")
            if "build" in item_lower or "compile" in item_lower:
                commands.append("python -m compileall src/")
            if "type" in item_lower and "check" in item_lower:
                commands.append("mypy src/")
        return commands if commands else ["echo 'No auto-detected verification commands'"]

    def _save(self, packet: HandoffPacket) -> None:
        """Persist handoff to disk."""
        filepath = self.storage_dir / f"{packet.handoff_id}.json"
        filepath.write_text(packet.to_json())

    def load_all(self) -> int:
        """Load all handoffs from disk. Returns count loaded."""
        count = 0
        for filepath in self.storage_dir.glob("*.json"):
            try:
                data = json.loads(filepath.read_text())
                packet = HandoffPacket.from_dict(data)
                self._handoffs[packet.handoff_id] = packet
                count += 1
            except Exception:
                continue
        return count
