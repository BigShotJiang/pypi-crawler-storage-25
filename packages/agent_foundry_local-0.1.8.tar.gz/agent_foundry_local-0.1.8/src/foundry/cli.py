"""CLI for Local Agent Foundry.

Commands:
  foundry agent start/stop/list/stats
  foundry handoff create/accept/complete/list
  foundry gate run
  foundry audit show/export
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import click

from foundry import __version__
from foundry.engine import AgentConfig, AgentEngine, AgentRole, AgentTask
from foundry.gates import GateRunner
from foundry.handoff import HandoffManager
from foundry.m365 import GraphClient, SharePointClient, TeamsClient
from foundry.m365.auth import M365Auth
from foundry.observability import AuditLog
from foundry.orchestration.node import NodeInfo, NodeRegistry, NodeRole, NodeStatus
from foundry.orchestration.transport import TransportClient
from foundry.registry import SkillRegistry, ToolRegistry
from foundry.runtime import (
    BackendType,
    CloudBackend,
    DummyBackend,
    GenerationRequest,
    OMLXBackend,
    RuntimeRegistry,
)


def _get_runtime() -> RuntimeRegistry:
    """Build the runtime registry with available backends."""
    registry = RuntimeRegistry()

    # Try oMLX first
    omlx = OMLXBackend()
    registry.register(omlx)

    # Cloud backend — requires explicit consent (FOUNDRY_CLOUD_CONSENT env var)
    cloud = CloudBackend()
    registry.register(cloud)

    # Always register dummy for testing
    registry.register(DummyBackend())

    return registry


def _get_registry() -> ToolRegistry:
    """Build the tool registry with default built-in tools and skills."""
    registry = ToolRegistry().register_default_tools()
    # Discover and register Hermes skills
    skill_reg = SkillRegistry("skills")
    discovered = skill_reg.discover()
    if discovered > 0:
        skill_reg.register_to_tools(registry)
    return registry


def _get_audit() -> AuditLog:
    return AuditLog(".foundry/audit.db")


def _get_handoff() -> HandoffManager:
    return HandoffManager(".foundry/handoffs")


def _get_engine() -> AgentEngine:
    return AgentEngine(_get_runtime(), tool_registry=_get_registry())


@click.group()
@click.version_option(__version__)
def main():
    """Local Agent Foundry — agents building agents. Offline. Auditable."""
    pass


# --- Agent Commands ---

@main.group()
def agent():
    """Manage agents — start, stop, list, inspect."""
    pass


@agent.command("start")
@click.argument("name")
@click.option("--model", default="qwen-8b", help="Model name")
@click.option("--backend", default="omlx", type=click.Choice(["omlx", "dummy", "ollama", "llama_cpp", "openai"]))
@click.option("--role", default="custom", type=click.Choice([r.value for r in AgentRole]))
@click.option("--tools", default="", help="Comma-separated tool names")
@click.option("--skills", default="", help="Comma-separated skill names")
@click.option("--working-dir", default="", help="Working directory")
@click.option("--system-prompt", default="", help="System prompt override")
def agent_start(name, model, backend, role, tools, skills, working_dir, system_prompt):
    """Start a new agent."""
    engine = _get_engine()

    config = AgentConfig(
        name=name,
        role=AgentRole(role),
        model=model,
        backend=BackendType(backend),
        tools=[t.strip() for t in tools.split(",") if t.strip()],
        skills=[s.strip() for s in skills.split(",") if s.strip()],
        working_dir=working_dir or str(Path.cwd()),
        system_prompt=system_prompt,
    )

    engine.create_agent(config)
    audit = _get_audit()
    audit.log_event(name, "agent_start", f"Agent '{name}' started with role '{role}'")

    click.echo(f"✓ Agent '{name}' created (role: {role}, model: {model}, backend: {backend})")
    if tools:
        click.echo(f"  Tools: {', '.join(config.tools)}")
    if skills:
        click.echo(f"  Skills: {', '.join(config.skills)}")


@agent.command("stop")
@click.argument("name")
def agent_stop(name):
    """Stop an agent."""
    engine = _get_engine()
    agent = engine.get_agent(name)
    if agent is None:
        click.echo(f"✗ Agent '{name}' not found.", err=True)
        sys.exit(1)

    asyncio.run(agent.stop())
    audit = _get_audit()
    audit.log_event(name, "agent_stop", f"Agent '{name}' stopped")
    click.echo(f"✓ Agent '{name}' stopped.")


@agent.command("list")
def agent_list():
    """List all agents."""
    engine = _get_engine()
    agents = engine.list_agents()
    if not agents:
        click.echo("No agents running.")
        return

    click.echo(f"{'Name':<20} {'Role':<15} {'State':<12} {'Model':<15} {'Tasks':<8}")
    click.echo("-" * 70)
    for a in agents:
        s = a.stats
        tasks = f"{s['tasks_completed']} ok / {s['tasks_failed']} fail"
        click.echo(f"{s['name']:<20} {s['role']:<15} {s['state']:<12} {a.config.model:<15} {tasks:<8}")


@agent.command("stats")
@click.argument("name")
def agent_stats(name):
    """Show detailed stats for an agent."""
    engine = _get_engine()
    agent = engine.get_agent(name)
    if agent is None:
        click.echo(f"✗ Agent '{name}' not found.", err=True)
        sys.exit(1)

    s = agent.stats
    click.echo(f"Agent: {s['name']}")
    click.echo(f"  Role:      {s['role']}")
    click.echo(f"  State:     {s['state']}")
    click.echo(f"  Model:     {agent.config.model}")
    click.echo(f"  Tasks:     {s['tasks_completed']} completed, {s['tasks_failed']} failed")
    click.echo(f"  Tokens:    {s['total_tokens']:,}")
    click.echo(f"  Latency:   {s['total_latency_ms']:.0f}ms total")
    click.echo(f"  Errors:    {s['error_count']}")
    click.echo(f"  Uptime:    {s['uptime_seconds']:.0f}s")
    click.echo(f"  Backend:   {agent.config.backend.value}")
    click.echo(f"  Work dir:  {agent.config.working_dir}")


@agent.command("run")
@click.argument("name")
@click.argument("task_goal")
@click.option("--context", default="", help="JSON context for the task")
@click.option("--context-file", default="", help="Load context from a JSON file")
@click.option("--backend", default="", help="Override backend for this run (omlx, dummy, ollama)")
@click.option("--model", default="", help="Override model for this run")
@click.option("--stream", is_flag=True, default=False, help="Stream output (not yet implemented)")
def agent_run(name, task_goal, context, context_file, backend, model, stream):
    """Run a task on an agent."""
    if stream:
        click.echo("⚠ Streaming mode not yet implemented.", err=True)

    engine = _get_engine()
    agent = engine.get_agent(name)
    if agent is None:
        click.echo(f"✗ Agent '{name}' not found.", err=True)
        sys.exit(1)
    if agent.is_busy:
        click.echo(f"✗ Agent '{name}' is busy ({agent.state.value}).", err=True)
        sys.exit(1)

    # Override backend/model if specified
    if backend:
        agent.config.backend = BackendType(backend)
    if model:
        agent.config.model = model

    # Health check for non-dummy backends
    if agent.config.backend != BackendType.DUMMY:
        backend_obj = agent.runtime.get(agent.config.backend)
        if backend_obj:
            healthy = asyncio.run(backend_obj.health_check())
            if not healthy:
                if agent.config.backend == BackendType.OMLX:
                    click.echo(
                        "⚠ oMLX backend at http://localhost:8000 is not reachable.\n"
                        "  Start oMLX first or use: foundry agent start <name> --backend dummy",
                        err=True,
                    )
                else:
                    click.echo(f"⚠ Backend '{agent.config.backend.value}' is not reachable.", err=True)
                sys.exit(1)
        click.echo(f"✓ Backend '{agent.config.backend.value}' is healthy.")

    ctx = {}
    if context:
        try:
            ctx = json.loads(context)
        except json.JSONDecodeError as e:
            click.echo(f"✗ Invalid context JSON: {e}", err=True)
            sys.exit(1)
    if context_file:
        try:
            ctx.update(json.loads(Path(context_file).read_text()))
        except Exception as e:
            click.echo(f"✗ Cannot read context file: {e}", err=True)
            sys.exit(1)

    task = AgentTask(goal=task_goal, context=ctx)
    audit = _get_audit()
    audit.log_event(name, "task_start", f"Running: {task_goal}")

    click.echo(f"→ Running '{task_goal}' on {name}...")
    click.echo(f"  Backend: {agent.config.backend.value} | Model: {agent.config.model}")

    result = asyncio.run(agent.run_task(task))

    # Show stats
    tokens = agent._total_tokens
    latency = agent._total_latency_ms
    click.echo(f"\n  Tokens used: {tokens:,} | Latency: {latency:.0f}ms | Errors: {agent._error_count}")

    if result.error:
        audit.log_event(name, "task_error", result.error, outcome="failure")
        click.echo(f"✗ Error: {result.error}")
        sys.exit(1)
    else:
        audit.log_event(name, "task_complete", result.result or "Done")
        click.echo(f"✓ Complete: {result.result or 'Done'}")


# --- Backend Commands ---

@main.group()
def backend():
    """Inspect and test model backends."""
    pass


@backend.command("health")
def backend_health():
    """Check health of all registered backends."""
    runtime = _get_runtime()
    for bt, be in runtime.backends.items():
        healthy = asyncio.run(be.health_check())
        icon = "✓" if healthy else "✗"
        click.echo(f"  {icon} {bt.value}: {'healthy' if healthy else 'unreachable'}")


@backend.command("models")
def backend_models():
    """List available models across all backends."""
    runtime = _get_runtime()
    models = asyncio.run(runtime.discover_models())
    if not models:
        click.echo("No models found on any backend.")
        return

    for bt, model_list in models.items():
        click.echo(f"\n{bt.value}:")
        for m in model_list:
            click.echo(f"  - {m.name} ({m.status.value})")


@backend.command("test")
@click.option("--backend", "-b", default="dummy", help="Backend to test")
@click.option("--prompt", "-p", default="Say 'hello world'", help="Test prompt")
def backend_test(backend, prompt):
    """Send a quick test prompt to verify end-to-end."""
    runtime = _get_runtime()
    be = runtime.get(BackendType(backend))
    if be is None:
        click.echo(f"✗ Backend '{backend}' not registered.", err=True)
        sys.exit(1)

    if not asyncio.run(be.health_check()):
        click.echo(f"✗ Backend '{backend}' is not healthy.", err=True)
        sys.exit(1)

    click.echo(f"→ Testing {backend} backend with: '{prompt}'")
    response = asyncio.run(be.generate(GenerationRequest(prompt=prompt, max_tokens=50)))

    click.echo(f"  Response: {response.text[:200]}")
    click.echo(f"  Model: {response.model} | Tokens: {response.tokens_used} | Latency: {response.latency_ms:.0f}ms")


# --- Handoff Commands ---

@main.group()
def handoff():
    """Manage agent handoffs — the formal work transfer protocol."""
    pass


@handoff.command("create")
@click.option("--from", "from_agent", required=True, help="Source agent")
@click.option("--to", "to_agent", required=True, help="Target agent")
@click.option("--task", required=True, help="Task description")
@click.option("--priority", default="medium", type=click.Choice(["low", "medium", "high"]))
@click.option("--dod", default="", help="Comma-separated definition of done items")
@click.option("--context", default="", help="JSON context")
@click.option("--working-dir", default="", help="Working directory for state snapshot")
def handoff_create(from_agent, to_agent, task, priority, dod, context, working_dir):
    """Create a handoff from one agent to another."""
    engine = _get_engine()
    if engine.get_agent(from_agent) is None:
        click.echo(f"✗ Source agent '{from_agent}' not found.", err=True)
        sys.exit(1)
    if engine.get_agent(to_agent) is None:
        click.echo(f"✗ Target agent '{to_agent}' not found.", err=True)
        sys.exit(1)

    ctx = {}
    if context:
        try:
            ctx = json.loads(context)
        except json.JSONDecodeError:
            click.echo("✗ Invalid context JSON.", err=True)
            sys.exit(1)

    dod_list = [d.strip() for d in dod.split(",") if d.strip()]

    hm = _get_handoff()
    packet = hm.create(
        from_agent=from_agent,
        to_agent=to_agent,
        task={"goal": task, "priority": priority},
        definition_of_done=dod_list,
        context=ctx,
        working_dir=working_dir or None,
    )

    audit = _get_audit()
    audit.log_event(from_agent, "handoff_create", f"Handoff to {to_agent}: {task}")

    click.echo(f"✓ Handoff created: {packet.handoff_id}")
    click.echo(f"  From: {from_agent} → To: {to_agent}")
    click.echo(f"  Task: {task}")
    click.echo(f"  DoD:  {dod_list if dod_list else '(none)'}")
    click.echo(f"  Snapshot: git={packet.state_snapshot.get('git_hash', 'N/A')[:8]}, "
               f"dirty={len(packet.state_snapshot.get('dirty_files', []))} files")


@handoff.command("accept")
@click.argument("handoff_id")
def handoff_accept(handoff_id):
    """Accept a pending handoff."""
    hm = _get_handoff()
    packet = hm.accept(handoff_id)
    if packet is None:
        click.echo(f"✗ Handoff '{handoff_id}' not found.", err=True)
        sys.exit(1)

    audit = _get_audit()
    audit.log_event(packet.to_agent, "handoff_accept", f"Accepted handoff {handoff_id}")
    click.echo(f"✓ Handoff {handoff_id} accepted by {packet.to_agent}")


@handoff.command("complete")
@click.argument("handoff_id")
@click.option("--result", default="Completed", help="Result summary")
@click.option("--verify/--no-verify", default=True, help="Run verification commands")
@click.option("--working-dir", default="", help="Working directory for verification")
def handoff_complete(handoff_id, result, verify, working_dir):
    """Complete a handoff with result and verification."""
    hm = _get_handoff()
    packet = hm.get(handoff_id)
    if packet is None:
        click.echo(f"✗ Handoff '{handoff_id}' not found.", err=True)
        sys.exit(1)

    verification_passed = True
    if verify:
        verification_passed, output = hm.run_verification(handoff_id, working_dir or None)
        click.echo(output)

    packet = hm.complete(handoff_id, result, verification_passed)
    audit = _get_audit()
    status = "completed" if verification_passed else "failed verification"
    audit.log_event(packet.to_agent, "handoff_complete", f"Handoff {handoff_id} {status}")

    if verification_passed:
        click.echo(f"✓ Handoff {handoff_id} completed: {result}")
    else:
        click.echo(f"✗ Handoff {handoff_id} failed verification")


@handoff.command("list")
@click.option("--agent", default="", help="Filter by agent name")
def handoff_list(agent):
    """List all handoffs."""
    hm = _get_handoff()
    handoffs = hm.list_for_agent(agent) if agent else hm.list_all()
    if not handoffs:
        click.echo("No handoffs found.")
        return

    click.echo(f"{'ID':<10} {'From':<15} {'To':<15} {'Status':<12} {'Task'}")
    click.echo("-" * 80)
    for h in handoffs:
        task = h.task.get("goal", "")[:40]
        hid = h.handoff_id[:8]
        click.echo(f"{hid:<10} {h.from_agent:<15} {h.to_agent:<15} {h.status.value:<12} {task}")


@handoff.command("show")
@click.argument("handoff_id")
def handoff_show(handoff_id):
    """Show full details of a handoff."""
    hm = _get_handoff()
    packet = hm.get(handoff_id)
    if packet is None:
        click.echo(f"✗ Handoff '{handoff_id}' not found.", err=True)
        sys.exit(1)

    click.echo(packet.to_json())


# --- Gate Commands ---

@main.group()
def gate():
    """Run quality gates on agent output."""
    pass


@gate.command("run")
@click.option("--agent", default="", help="Agent name for audit context")
@click.option("--text", default="", help="Text to check")
@click.option("--file", "filepath", default="", help="File to check")
def gate_run(agent, text, filepath):
    """Run quality gates against text or file."""
    runner = GateRunner().add_defaults()

    if filepath:
        run = runner.run_on_file(agent or "cli", filepath)
    elif text:
        run = runner.run(agent or "cli", text)
    else:
        click.echo("✗ Provide --text or --file", err=True)
        sys.exit(1)

    audit = _get_audit()
    audit.log_event(
        agent or "cli",
        "gate_run",
        f"Gates: {run.passed}",
        outcome="success" if run.passed else "failure",
        details={"failed": [g.gate_name for g in run.failed_gates]},
    )

    click.echo(f"\nGate Run: {'✓ PASSED' if run.passed else '✗ FAILED'}")
    click.echo("-" * 40)
    for g in run.gates:
        icon = "✓" if g.result.value in ("pass", "skip") else "✗"
        click.echo(f"  {icon} {g.gate_name}: {g.reason} ({g.duration_ms:.1f}ms)")

    if not run.passed:
        sys.exit(1)


# --- Skill Commands ---

@main.group()
def skill():
    """Discover and manage agent skills."""
    pass


@skill.command("discover")
@click.option("--dir", "skills_dir", default="skills", help="Skills directory to scan")
def skill_discover(skills_dir):
    """Scan a directory for Hermes SKILL.md files and list them."""
    skill_reg = SkillRegistry(skills_dir)
    count = skill_reg.discover()

    if count == 0:
        click.echo(f"No skills found in '{skills_dir}'.")
        return

    click.echo(f"Discovered {count} skills in '{skills_dir}':\n")
    for s in skill_reg.list_all():
        click.echo(f"  • {s.name}")
        click.echo(f"    {s.description[:80]}")
        click.echo()


@skill.command("list")
def skill_list():
    """List all registered skills (from the current tool registry)."""
    registry = _get_registry()
    skills = [t for t in registry.list_all() if t.source.value == "hermes_skill"]

    if not skills:
        click.echo("No skills registered. Run 'foundry skill discover' first.")
        return

    click.echo(f"{'Name':<25} {'Description'}")
    click.echo("-" * 60)
    for s in skills:
        click.echo(f"{s.name:<25} {s.description[:50]}")


@skill.command("show")
@click.argument("name")
def skill_show(name):
    """Show the full content of a skill."""
    skill_reg = SkillRegistry("skills")
    skill_reg.discover()

    s = skill_reg.get(name)
    if s is None:
        click.echo(f"✗ Skill '{name}' not found.", err=True)
        sys.exit(1)

    click.echo(s.load())


# --- Audit Commands ---

@main.group()
def audit():
    """Inspect and export the audit log."""
    pass


@audit.command("show")
@click.option("--agent", default="", help="Filter by agent")
@click.option("--event", "event_type", default="", help="Filter by event type")
@click.option("--limit", default=20, help="Max entries")
def audit_show(agent, event_type, limit):
    """Show recent audit entries."""
    al = _get_audit()
    entries = al.query(
        agent_name=agent or None,
        event_type=event_type or None,
        limit=limit,
    )

    if not entries:
        click.echo("No audit entries found.")
        return

    click.echo(f"{'Time':<20} {'Agent':<15} {'Event':<18} {'Action'}")
    click.echo("-" * 80)
    for e in entries:
        ts = e.get("timestamp", 0)
        time_str = f"{ts:.0f}" if ts else ""
        click.echo(f"{time_str:<20} {e.get('agent_name', '')[:14]:<15} "
                   f"{e.get('event_type', '')[:17]:<18} {e.get('action', '')[:40]}")


@audit.command("export")
@click.option("--output", "-o", default="audit_export.json", help="Output file path")
@click.option("--from", "since", default="", help="From timestamp (unix)")
@click.option("--until", default="", help="Until timestamp (unix)")
def audit_export(output, since, until):
    """Export audit log to JSON."""
    al = _get_audit()
    since_f = float(since) if since else None
    until_f = float(until) if until else None

    count = al.export_json(output, since=since_f, until=until_f)
    click.echo(f"✓ Exported {count} entries to {output}")


@audit.command("stats")
def audit_stats():
    """Show audit log statistics."""
    al = _get_audit()
    stats = al.get_stats()

    click.echo("Audit Log Statistics")
    click.echo("=" * 40)
    click.echo(f"  Total entries:  {stats['total_entries']}")
    click.echo(f"  Total failures: {stats['failures']}")
    click.echo(f"  Total tokens:   {stats['total_tokens']:,}")

    click.echo("\nBy Agent:")
    for agent_name, count in stats.get("by_agent", {}).items():
        click.echo(f"  {agent_name}: {count}")

    click.echo("\nBy Event Type:")
    for event_type, count in stats.get("by_event_type", {}).items():
        click.echo(f"  {event_type}: {count}")


# ── M365 Helper ────────────────────────────────────────────────────

_M365_CLIENT_ID_HELP = (
    "Azure AD app registration client ID. "
    "Or set FOUNDRY_M365_CLIENT_ID env var."
)


def _get_m365_auth(client_id: str | None = None) -> M365Auth:
    """Build M365Auth from CLI options or env vars."""
    import os

    cid = client_id or os.environ.get("FOUNDRY_M365_CLIENT_ID")
    if not cid:
        raise click.UsageError(
            "M365 client ID required. Set FOUNDRY_M365_CLIENT_ID env var "
            "or pass --client-id."
        )
    return M365Auth(client_id=cid)


def _get_graph(auth: M365Auth) -> GraphClient:
    return GraphClient(auth)


# ── M365 Commands ──────────────────────────────────────────────────


@main.group()
def m365():
    """Microsoft 365 integration — SharePoint, Teams, Graph."""
    pass


@m365.group()
def sharepoint():
    """SharePoint operations — sites, lists, files."""
    pass


@m365.group()
def teams():
    """Teams operations — channels, messages."""
    pass


# ── M365 Auth ──────────────────────────────────────────────────────


@m365.command("login")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def m365_login(client_id):
    """Authenticate with Microsoft 365 (device code flow)."""
    auth = _get_m365_auth(client_id or None)
    creds = auth.device_code_flow()
    if creds:
        click.echo("✓ Authenticated successfully.")
        click.echo(f"  Token expires in {creds.expires_at - __import__('time').time():.0f}s")
    else:
        click.echo("✗ Authentication failed.", err=True)
        sys.exit(1)


@m365.command("logout")
def m365_logout():
    """Clear cached M365 credentials."""
    auth = M365Auth(client_id="", cache_dir=".foundry/m365")
    auth.clear_cache()
    click.echo("✓ Cached credentials cleared.")


@m365.command("status")
def m365_status():
    """Check M365 authentication status."""
    import os
    import time as _time

    cid = os.environ.get("FOUNDRY_M365_CLIENT_ID", "")
    if not cid:
        click.echo("⚠ FOUNDRY_M365_CLIENT_ID not set. Use --client-id with commands.")
        return

    auth = M365Auth(client_id=cid)
    creds = auth.acquire_token_silent()
    if creds and creds.valid:
        remaining = int(creds.expires_at - _time.time())
        click.echo(f"✓ Authenticated — token valid for {remaining}s")
    else:
        click.echo("✗ Not authenticated. Run: foundry m365 login")


# ── SharePoint CLI ─────────────────────────────────────────────────


@sharepoint.command("sites")
@click.option("--query", "-q", default="", help="Search query for sites")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def sp_sites(query, client_id):
    """Search for SharePoint sites."""
    auth = _get_m365_auth(client_id or None)
    sp = SharePointClient(_get_graph(auth))
    sites = sp.find_site(query or "*")
    if not sites:
        click.echo("No sites found.")
        return
    for s in sites:
        click.echo(f"  {s['display_name']}")
        click.echo(f"    ID:  {s['id']}")
        click.echo(f"    URL: {s['url']}")
        click.echo()


@sharepoint.command("lists")
@click.argument("site_id")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def sp_lists(site_id, client_id):
    """List all lists in a SharePoint site."""
    auth = _get_m365_auth(client_id or None)
    sp = SharePointClient(_get_graph(auth))
    lists = sp.get_lists(site_id)
    if not lists:
        click.echo("No lists found.")
        return
    for lst in lists:
        click.echo(f"  [{lst['id']}] {lst['display_name']}")
        if lst.get("description"):
            click.echo(f"    {lst['description']}")


@sharepoint.command("items")
@click.argument("site_id")
@click.argument("list_id")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def sp_items(site_id, list_id, client_id):
    """Get all items from a SharePoint list."""
    auth = _get_m365_auth(client_id or None)
    sp = SharePointClient(_get_graph(auth))
    result = sp.get_list_items(site_id, list_id)
    click.echo(f"List has {result['count']} items.\n")
    for item in result["items"]:
        fields = {k: v for k, v in item.items() if k not in ("id", "@odata.etag")}
        click.echo(f"  [{item['id']}] {json.dumps(fields, default=str)[:120]}")


@sharepoint.command("libraries")
@click.argument("site_id")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def sp_libraries(site_id, client_id):
    """List document libraries in a site."""
    auth = _get_m365_auth(client_id or None)
    sp = SharePointClient(_get_graph(auth))
    libs = sp.get_libraries(site_id)
    if not libs:
        click.echo("No libraries found.")
        return
    for lib in libs:
        click.echo(f"  [{lib['id']}] {lib['name']} ({lib['type']})")
        click.echo(f"    URL: {lib['url']}")


@sharepoint.command("files")
@click.argument("drive_id")
@click.option("--path", "-p", default="/", help="Folder path in the drive")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def sp_files(drive_id, path, client_id):
    """List files in a document library."""
    auth = _get_m365_auth(client_id or None)
    sp = SharePointClient(_get_graph(auth))
    result = sp.list_files(drive_id, path)
    click.echo(f"Path: {result['path']} ({result['count']} items)\n")
    if result["folders"]:
        click.echo("Folders:")
        for f in result["folders"]:
            click.echo(f"  📁 {f['name']}")
    if result["files"]:
        click.echo("Files:")
        for f in result["files"]:
            size_kb = f["size"] / 1024
            click.echo(f"  📄 {f['name']} ({size_kb:.1f} KB)")


@sharepoint.command("download")
@click.argument("drive_id")
@click.argument("item_id")
@click.option("--output", "-o", default=".", help="Output directory or file path")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def sp_download(drive_id, item_id, output, client_id):
    """Download a file from SharePoint."""
    auth = _get_m365_auth(client_id or None)
    sp = SharePointClient(_get_graph(auth))
    result = sp.download_file(drive_id, item_id, output)
    click.echo(f"✓ Downloaded {result['size']} bytes to {result['path']}")


@sharepoint.command("upload")
@click.argument("drive_id")
@click.argument("local_path")
@click.option("--folder", "-f", default="/", help="Target folder in the drive")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def sp_upload(drive_id, local_path, folder, client_id):
    """Upload a file to a SharePoint document library."""
    auth = _get_m365_auth(client_id or None)
    sp = SharePointClient(_get_graph(auth))
    result = sp.upload_file(drive_id, folder, local_path)
    click.echo(f"✓ Uploaded: {result['name']}")
    click.echo(f"  URL: {result['url']}")


@sharepoint.command("search")
@click.argument("query")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def sp_search(query, client_id):
    """Search SharePoint content."""
    auth = _get_m365_auth(client_id or None)
    sp = SharePointClient(_get_graph(auth))
    results = sp.search(query)
    if not results:
        click.echo("No results found.")
        return
    click.echo(f"Found {len(results)} results:\n")
    for r in results:
        click.echo(f"  {r['title']}")
        click.echo(f"    {r['url']}")
        click.echo()


# ── Teams CLI ──────────────────────────────────────────────────────


@teams.command("list")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def teams_list(client_id):
    """List my Teams."""
    auth = _get_m365_auth(client_id or None)
    tc = TeamsClient(_get_graph(auth))
    teams_list = tc.my_teams()
    if not teams_list:
        click.echo("No teams found.")
        return
    for t in teams_list:
        click.echo(f"  [{t['id']}] {t['display_name']}")
        if t.get("description"):
            click.echo(f"    {t['description']}")


@teams.command("channels")
@click.argument("team_id")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def teams_channels(team_id, client_id):
    """List channels in a team."""
    auth = _get_m365_auth(client_id or None)
    tc = TeamsClient(_get_graph(auth))
    channels = tc.get_channels(team_id)
    if not channels:
        click.echo("No channels found.")
        return
    for c in channels:
        click.echo(f"  [{c['id']}] {c['display_name']}")


@teams.command("messages")
@click.argument("team_id")
@click.argument("channel_id")
@click.option("--limit", "-n", default=20, help="Max messages")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def teams_messages(team_id, channel_id, limit, client_id):
    """Get messages from a channel."""
    auth = _get_m365_auth(client_id or None)
    tc = TeamsClient(_get_graph(auth))
    result = tc.get_messages(team_id, channel_id, limit=limit)
    click.echo(f"Channel has {result['count']} recent messages:\n")
    for m in result["messages"]:
        body = m["body"].replace("<p>", "").replace("</p>", "").replace("<br>", "\n")[:120]
        click.echo(f"  [{m['from']}] {body}")


@teams.command("send")
@click.argument("team_id")
@click.argument("channel_id")
@click.argument("message")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def teams_send(team_id, channel_id, message, client_id):
    """Send a message to a Teams channel."""
    auth = _get_m365_auth(client_id or None)
    tc = TeamsClient(_get_graph(auth))
    result = tc.send_to_channel(team_id, channel_id, message)
    click.echo(f"✓ Message sent (ID: {result['id']})")


@teams.command("chats")
@click.option("--client-id", default="", help=_M365_CLIENT_ID_HELP)
def teams_chats(client_id):
    """List my Teams chats."""
    auth = _get_m365_auth(client_id or None)
    tc = TeamsClient(_get_graph(auth))
    chats = tc.get_chats()
    if not chats:
        click.echo("No chats found.")
        return
    for c in chats:
        click.echo(f"  [{c['id']}] {c.get('topic', 'No topic')} ({c['type']})")


# ── Cluster Helpers ───────────────────────────────────────────────


def _get_node_registry() -> NodeRegistry:
    return NodeRegistry(".foundry/nodes.json")


def _get_local_node() -> NodeInfo:
    """Get or create the local node identity."""
    registry = _get_node_registry()
    if registry.local_node:
        return registry.local_node
    node = NodeInfo.local()
    registry.set_local(node)
    return node


# ── Cluster Commands ──────────────────────────────────────────────


@main.group()
def cluster():
    """Multi-machine orchestration — discover peers and hand off work."""
    pass


@cluster.command("status")
def cluster_status():
    """Show cluster status — local node and discovered peers."""
    registry = _get_node_registry()
    local = registry.local_node

    click.echo("=== Local Node ===")
    if local:
        click.echo(f"  ID:       {local.node_id}")
        click.echo(f"  Hostname: {local.hostname}")
        click.echo(f"  Roles:    {', '.join(r.value for r in local.roles)}")
        click.echo(f"  IPs:      {', '.join(local.ip_addresses)}")
        click.echo(f"  Port:     {local.port}")
        click.echo(f"  Version:  {local.version}")
    else:
        click.echo("  Not initialized. Run: foundry cluster init")

    click.echo(f"\n=== Peers ({registry.peer_count}) ===")
    peers = registry.list_peers()
    if not peers:
        click.echo("  No peers discovered.")
        return

    for p in peers:
        status_icon = {"online": "🟢", "busy": "🟡", "offline": "🔴", "unknown": "⚪"}
        icon = status_icon.get(p.status.value, "⚪")
        click.echo(f"  {icon} {p.display_name} ({p.hostname})")
        click.echo(f"     ID:    {p.node_id}")
        click.echo(f"     Roles: {', '.join(r.value for r in p.roles)}")
        click.echo(f"     Addr:  {p.address}")
        click.echo(f"     Load:  {p.current_agent_count}/{p.max_concurrent_agents}")
        click.echo(f"     Seen:  {p.last_seen:.0f}s ago")
        click.echo()


@cluster.command("init")
@click.option("--port", default=9420, help="Orchestration port")
@click.option("--role", default="worker",
              type=click.Choice([r.value for r in NodeRole]))
def cluster_init(port, role):
    """Initialize this node for multi-machine orchestration."""
    registry = _get_node_registry()
    node = NodeInfo.local(port=port)
    node.roles = [NodeRole(role)]
    registry.set_local(node)
    click.echo(f"✓ Node initialized: {node.node_id}")
    click.echo(f"  Hostname: {node.hostname}")
    click.echo(f"  Role:     {role}")
    click.echo(f"  Port:     {port}")
    click.echo(f"  Address:  {node.address}")


@cluster.command("peer")
@click.argument("action", type=click.Choice(["add", "remove", "list"]))
@click.argument("address", default="")
def cluster_peer(action, address):
    """Manage static peers.

    \b
    Actions:
      add    — Add a static peer: foundry cluster peer add http://192.168.1.10:9420
      remove — Remove a peer by node ID
      list   — List all peers
    """
    registry = _get_node_registry()

    if action == "list":
        peers = registry.list_peers()
        if not peers:
            click.echo("No peers.")
            return
        for p in peers:
            click.echo(f"  {p.node_id} — {p.address}")
        return

    if action == "add":
        if not address:
            click.echo("✗ Address required. Example: foundry cluster peer add http://192.168.1.10:9420", err=True)
            sys.exit(1)

        transport = TransportClient()
        try:
            info = asyncio.run(transport.get_node_info(address))
            node = NodeInfo.from_dict(info)
            registry.add_peer(node)
            click.echo(f"✓ Peer added: {node.display_name} ({node.node_id})")
            click.echo(f"  Address: {address}")
            click.echo(f"  Roles:   {', '.join(r.value for r in node.roles)}")
        except Exception as e:
            click.echo(f"✗ Could not reach {address}: {e}", err=True)
            sys.exit(1)
        finally:
            asyncio.run(transport.close())

    if action == "remove":
        if not address:
            click.echo("✗ Node ID required.", err=True)
            sys.exit(1)
        if registry.remove_peer(address):
            click.echo(f"✓ Peer removed: {address}")
        else:
            click.echo(f"✗ Peer not found: {address}", err=True)
            sys.exit(1)


@cluster.command("handoff")
@click.argument("peer_id")
@click.option("--from-agent", required=True, help="Source agent on this node")
@click.option("--to-agent", required=True, help="Target agent on peer node")
@click.option("--task", required=True, help="Task description")
@click.option("--cluster-secret", default="", help="Cluster authentication secret")
def cluster_handoff(peer_id, from_agent, to_agent, task, cluster_secret):
    """Send a handoff to a peer node.

    Example:
      foundry cluster handoff <node-id> --from-agent builder --to-agent reviewer \\
        --task "Review the latest build"
    """
    import os

    registry = _get_node_registry()
    peer = registry.get_peer(peer_id)
    if peer is None:
        click.echo(f"✗ Peer '{peer_id}' not found.", err=True)
        sys.exit(1)

    if peer.status == NodeStatus.OFFLINE:
        click.echo(f"✗ Peer '{peer.display_name}' is offline.", err=True)
        sys.exit(1)

    secret = cluster_secret or os.environ.get("FOUNDRY_CLUSTER_SECRET", "")
    transport = TransportClient(cluster_secret=secret)

    click.echo(f"→ Sending handoff to {peer.display_name} ({peer.address})...")

    packet = {
        "from_node": registry.local_node.node_id if registry.local_node else "",
        "from_agent": from_agent,
        "to_agent": to_agent,
        "task": {"goal": task, "priority": "medium"},
    }

    try:
        result = asyncio.run(transport.send_handoff(peer.address, packet))
        if result.get("accepted"):
            click.echo(f"✓ Handoff accepted by {peer.display_name}")
            click.echo(f"  Handoff ID: {result.get('handoff_id')}")
        else:
            click.echo(f"✗ Handoff rejected: {result.get('reason', 'unknown')}", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"✗ Handoff failed: {e}", err=True)
        sys.exit(1)
    finally:
        asyncio.run(transport.close())


@cluster.command("discover")
def cluster_discover():
    """Force a peer discovery scan (probes static peers)."""

    click.echo("→ Probing static peers...")
    # Static peer discovery is done during heartbeat; force immediate check
    registry = _get_node_registry()

    # Load static peers from config file if present
    config_path = Path(".foundry/cluster_config.json")
    static_peers = []
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text())
            static_peers = cfg.get("static_peers", [])
        except Exception:
            pass

    if not static_peers:
        click.echo("  No static peers configured.")
        click.echo("  Add with: foundry cluster peer add <address>")
        return

    transport = TransportClient()
    found = 0
    for peer_url in static_peers:
        try:
            info = asyncio.run(transport.get_node_info(peer_url))
            node = NodeInfo.from_dict(info)
            registry.add_peer(node)
            click.echo(f"  ✓ Found: {node.display_name} at {peer_url}")
            found += 1
        except Exception as e:
            click.echo(f"  ✗ Unreachable: {peer_url} ({e})")

    asyncio.run(transport.close())
    click.echo(f"\n  Discovered {found}/{len(static_peers)} peers.")


if __name__ == "__main__":
    main()
