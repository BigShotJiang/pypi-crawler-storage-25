"""Model runtime — abstract model backends behind a common interface.

Backends: oMLX (primary), llama.cpp, Ollama, Bonsai (future).
Each backend provides: generate(), health_check(), model listing.
"""

from __future__ import annotations

import json
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import httpx


class BackendType(Enum):
    OMLX = "omlx"
    LLAMA_CPP = "llama_cpp"
    OLLAMA = "ollama"
    BONSAI = "bonsai"
    OPENAI = "openai"
    DUMMY = "dummy"  # for testing


class ModelStatus(Enum):
    LOADED = "loaded"
    UNLOADED = "unloaded"
    LOADING = "loading"
    ERROR = "error"


@dataclass
class ModelInfo:
    """Metadata about a model known to a backend."""
    name: str
    backend: BackendType
    status: ModelStatus = ModelStatus.UNLOADED
    parameters: str = ""  # e.g. "8B", "70B"
    quantization: str = ""  # e.g. "Q4_K_M", "4bit"
    context_length: int = 32768


@dataclass
class ToolDefinition:
    """A tool the model can call."""
    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    # JSON Schema for parameters


@dataclass
class GenerationRequest:
    """What to ask the model."""
    prompt: str
    system_prompt: str = ""
    tools: list[ToolDefinition] = field(default_factory=list)
    max_tokens: int = 4096
    temperature: float = 0.7
    stop_sequences: list[str] = field(default_factory=list)


@dataclass
class ToolCall:
    """A tool call extracted from model output."""
    tool_name: str
    arguments: dict[str, Any]
    call_id: str = ""


@dataclass
class GenerationResponse:
    """What the model returns."""
    text: str
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str = "stop"  # stop, length, tool_calls
    tokens_used: int = 0
    model: str = ""
    latency_ms: float = 0.0


class ModelBackend(ABC):
    """Abstract model backend. Implement for each model server type."""

    backend_type: BackendType

    @abstractmethod
    async def generate(self, request: GenerationRequest) -> GenerationResponse:
        """Send a generation request to the model."""
        ...

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if the backend is reachable and ready."""
        ...

    @abstractmethod
    async def list_models(self) -> list[ModelInfo]:
        """List available models on this backend."""
        ...

    async def load_model(self, model_name: str) -> ModelInfo:
        """Load a model into memory (no-op for always-loaded backends)."""
        return ModelInfo(
            name=model_name,
            backend=self.backend_type,
            status=ModelStatus.LOADED,
        )

    async def unload_model(self, model_name: str) -> None:  # noqa: B027 — default no-op
        """Unload a model from memory. Override in subclasses."""
        pass


class OMLXBackend(ModelBackend):
    """oMLX backend — Apple MLX models served via oMLX API.

    Default endpoint: http://localhost:8000
    Uses OpenAI-compatible chat completions API.
    """

    backend_type = BackendType.OMLX

    def __init__(self, base_url: str = "http://localhost:8000", timeout: float = 120.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
            )
        return self._client

    async def health_check(self) -> bool:
        try:
            client = await self._get_client()
            # Try /health first, fall back to /v1/models
            resp = await client.get("/health")
            return resp.status_code == 200
        except Exception:
            try:
                client = await self._get_client()
                resp = await client.get("/v1/models")
                return resp.status_code == 200
            except Exception:
                return False

    async def list_models(self) -> list[ModelInfo]:
        try:
            client = await self._get_client()
            resp = await client.get("/v1/models")
            if resp.status_code != 200:
                return []

            data = resp.json()
            models = []
            for m in data.get("data", []):
                models.append(ModelInfo(
                    name=m.get("id", "unknown"),
                    backend=BackendType.OMLX,
                    status=ModelStatus.LOADED,
                ))
            return models
        except Exception:
            return []

    async def generate(self, request: GenerationRequest) -> GenerationResponse:
        client = await self._get_client()

        messages: list[dict[str, Any]] = []
        if request.system_prompt:
            messages.append({"role": "system", "content": request.system_prompt})
        messages.append({"role": "user", "content": request.prompt})

        payload: dict[str, Any] = {
            "model": "omlx-model",  # oMLX typically auto-selects
            "messages": messages,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "stream": False,
        }

        if request.stop_sequences:
            payload["stop"] = request.stop_sequences

        if request.tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.parameters,
                    },
                }
                for t in request.tools
            ]
            payload["tool_choice"] = "auto"

        start = time.monotonic()
        resp = await client.post("/v1/chat/completions", json=payload)
        latency = (time.monotonic() - start) * 1000

        if resp.status_code != 200:
            return GenerationResponse(
                text=f"Error: {resp.status_code} {resp.text[:500]}",
                finish_reason="error",
                latency_ms=latency,
            )

        data = resp.json()
        choice = data["choices"][0]
        message = choice.get("message", {})

        tool_calls = []
        if "tool_calls" in message:
            for tc in message["tool_calls"]:
                func = tc.get("function", {})
                try:
                    args = json.loads(func.get("arguments", "{}"))
                except json.JSONDecodeError:
                    args = {}
                tool_calls.append(ToolCall(
                    tool_name=func.get("name", ""),
                    arguments=args,
                    call_id=tc.get("id", ""),
                ))

        return GenerationResponse(
            text=message.get("content", "") or "",
            tool_calls=tool_calls,
            finish_reason=choice.get("finish_reason", "stop"),
            tokens_used=data.get("usage", {}).get("total_tokens", 0),
            model=data.get("model", "omlx"),
            latency_ms=latency,
        )

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None


class DummyBackend(ModelBackend):
    """Dummy backend for testing — returns predictable responses."""

    backend_type = BackendType.DUMMY

    def __init__(self, responses: list[str] | None = None):
        self.responses = responses or ["Task completed successfully."]
        self._idx = 0
        self._health = True

    async def health_check(self) -> bool:
        return self._health

    async def list_models(self) -> list[ModelInfo]:
        return [
            ModelInfo(
                name="dummy-model",
                backend=BackendType.DUMMY,
                status=ModelStatus.LOADED,
                parameters="1B",
                quantization="none",
            )
        ]

    async def generate(self, request: GenerationRequest) -> GenerationResponse:
        response = self.responses[self._idx % len(self.responses)]
        self._idx += 1
        return GenerationResponse(
            text=response,
            finish_reason="stop",
            tokens_used=len(response.split()),
            model="dummy-model",
            latency_ms=1.0,
        )


class CloudBackend(ModelBackend):
    """OpenAI-compatible cloud backend — opt-in only.

    WARNING: This backend sends data to an external API. It will NOT work unless:
    1. Config `cloud.enabled` is set to true (`foundry config set cloud.enabled true`)
    2. Environment variable `FOUNDRY_CLOUD_CONSENT=explicit` is set

    Never auto-fallback. User must explicitly choose cloud backend.
    """

    backend_type = BackendType.OPENAI

    def __init__(
        self,
        api_key: str = "",
        base_url: str = "https://api.openai.com/v1",
        model: str = "gpt-4o",
        timeout: float = 120.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None
        self._consent_given = False

    def _check_consent(self) -> None:
        """Refuse to operate without explicit cloud consent."""
        import os

        consent = os.environ.get("FOUNDRY_CLOUD_CONSENT", "").lower()
        if consent not in ("true", "explicit", "1", "yes"):
            raise RuntimeError(
                "Cloud backend requires explicit consent.\n\n"
                "  Set env var: FOUNDRY_CLOUD_CONSENT=explicit\n"
                "  Or config:   foundry config set cloud.enabled true\n\n"
                "The Foundry is offline-first by design. Cloud backends send\n"
                "data to external APIs. This must be explicitly enabled."
            )
        self._consent_given = True

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            api_key = self.api_key or __import__("os").environ.get("OPENAI_API_KEY", "")
            if not api_key:
                raise RuntimeError(
                    "OpenAI API key required. Set OPENAI_API_KEY env var."
                )
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                timeout=httpx.Timeout(self.timeout),
            )
        return self._client

    async def health_check(self) -> bool:
        """Check if the cloud API is reachable. Requires consent."""
        try:
            self._check_consent()
            client = await self._get_client()
            resp = await client.get("/models")
            return resp.status_code == 200
        except RuntimeError:
            return False
        except Exception:
            return False

    async def list_models(self) -> list[ModelInfo]:
        """List available cloud models. Requires consent."""
        self._check_consent()
        try:
            client = await self._get_client()
            resp = await client.get("/models")
            if resp.status_code != 200:
                return []

            data = resp.json()
            models = []
            for m in data.get("data", []):
                model_id = m.get("id", "")
                # Filter to chat models
                if any(p in model_id for p in ("gpt-", "claude", "gemini", "llama")):
                    models.append(ModelInfo(
                        name=model_id,
                        backend=BackendType.OPENAI,
                        status=ModelStatus.LOADED,
                    ))
            return models
        except RuntimeError:
            return []
        except Exception:
            return []

    async def generate(self, request: GenerationRequest) -> GenerationResponse:
        """Send a generation request to the cloud API. Requires consent."""
        self._check_consent()
        client = await self._get_client()

        messages: list[dict[str, Any]] = []
        if request.system_prompt:
            messages.append({"role": "system", "content": request.system_prompt})
        messages.append({"role": "user", "content": request.prompt})

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "stream": False,
        }

        if request.stop_sequences:
            payload["stop"] = request.stop_sequences

        if request.tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.parameters,
                    },
                }
                for t in request.tools
            ]
            payload["tool_choice"] = "auto"

        start = time.monotonic()
        resp = await client.post("/chat/completions", json=payload)
        latency = (time.monotonic() - start) * 1000

        if resp.status_code != 200:
            return GenerationResponse(
                text=f"Cloud API error: {resp.status_code} {resp.text[:500]}",
                finish_reason="error",
                latency_ms=latency,
            )

        data = resp.json()
        choice = data["choices"][0]
        message = choice.get("message", {})

        tool_calls = []
        if "tool_calls" in message:
            for tc in message["tool_calls"]:
                func = tc.get("function", {})
                try:
                    args = json.loads(func.get("arguments", "{}"))
                except json.JSONDecodeError:
                    args = {}
                tool_calls.append(ToolCall(
                    tool_name=func.get("name", ""),
                    arguments=args,
                    call_id=tc.get("id", ""),
                ))

        return GenerationResponse(
            text=message.get("content", "") or "",
            tool_calls=tool_calls,
            finish_reason=choice.get("finish_reason", "stop"),
            tokens_used=data.get("usage", {}).get("total_tokens", 0),
            model=data.get("model", self.model),
            latency_ms=latency,
        )

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None


class RuntimeRegistry:
    """Central registry of model backends. Agents request models from here."""

    def __init__(self):
        self._backends: dict[BackendType, ModelBackend] = {}

    def register(self, backend: ModelBackend) -> None:
        self._backends[backend.backend_type] = backend

    def get(self, backend_type: BackendType) -> ModelBackend | None:
        return self._backends.get(backend_type)

    async def discover_models(self) -> dict[BackendType, list[ModelInfo]]:
        """Query all registered backends for their models."""
        result: dict[BackendType, list[ModelInfo]] = {}
        for bt, backend in self._backends.items():
            if await backend.health_check():
                result[bt] = await backend.list_models()
        return result

    @property
    def backends(self) -> dict[BackendType, ModelBackend]:
        return dict(self._backends)
