"""Tool registry — discoverable, typed tool definitions for agents.

Sources: MCP servers, Hermes SKILL.md files, custom Python tools.
Each tool has: name, description, JSON Schema parameters, and a handler.
"""

from __future__ import annotations

import json
import subprocess
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class ToolSource(Enum):
    MCP = "mcp"
    HERMES_SKILL = "hermes_skill"
    CUSTOM = "custom"
    BUILTIN = "builtin"


@dataclass
class Tool:
    """A registered tool that an agent can call."""
    name: str
    description: str
    source: ToolSource
    parameters: dict[str, Any] = field(default_factory=dict)
    # JSON Schema for parameters, e.g.:
    # {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}
    handler: Callable[..., Any] | None = None
    # For MCP tools: server_command, for custom: Python callable
    mcp_server_command: str | None = None
    mcp_tool_name: str | None = None

    def to_openai_tool(self) -> dict[str, Any]:
        """Convert to OpenAI tool format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    async def execute(self, arguments: dict[str, Any]) -> str:
        """Execute the tool with given arguments. Returns result string."""
        if self.handler:
            try:
                result = self.handler(**arguments)
                return str(result)
            except Exception as e:
                return f"Error executing {self.name}: {e}"

        if self.source == ToolSource.MCP and self.mcp_server_command:
            # Execute MCP tool via subprocess
            return await self._execute_mcp(arguments)

        return f"Tool {self.name} has no handler configured."

    async def _execute_mcp(self, arguments: dict[str, Any]) -> str:
        """Call an MCP tool via stdio protocol."""
        # Simplified: for MVP, call tool by name via MCP server
        try:
            proc = subprocess.run(
                [*self.mcp_server_command.split(), "tool", self.mcp_tool_name or self.name],
                input=json.dumps(arguments),
                capture_output=True,
                text=True,
                timeout=30,
            )
            if proc.returncode == 0:
                return proc.stdout
            return f"MCP error: {proc.stderr}"
        except Exception as e:
            return f"MCP execution error: {e}"


class Skill:
    """A registered skill that agents can load and execute."""

    def __init__(self, name: str, description: str, path: Path, content: str = ""):
        self.name = name
        self.description = description
        self.path = path
        self.content = content

    def load(self) -> str:
        """Load the full skill content."""
        if self.content:
            return self.content
        try:
            self.content = self.path.read_text()
            return self.content
        except Exception as e:
            return f"Error loading skill {self.name}: {e}"

    def summary(self) -> str:
        """Return a summary of the skill (first 500 chars)."""
        content = self.load()
        return content[:500] + ("..." if len(content) > 500 else "")


class SkillRegistry:
    """Manages Hermes SKILL.md files as agent-callable tools.

    Skills are instruction sets. Agents call a skill to get instructions
    on how to perform a specific task (code review, debugging, testing, etc.)
    """

    def __init__(self, skills_dir: str = "skills"):
        self.skills_dir = Path(skills_dir)
        self._skills: dict[str, Skill] = {}

    def discover(self) -> int:
        """Scan the skills directory and register all SKILL.md files.

        Returns the number of skills discovered.
        """
        if not self.skills_dir.exists():
            return 0

        count = 0
        for skill_file in self.skills_dir.rglob("SKILL.md"):
            try:
                content = skill_file.read_text()
                name = skill_file.parent.name or skill_file.stem
                description = ""

                # Parse YAML frontmatter
                if content.startswith("---"):
                    parts = content.split("---", 2)
                    if len(parts) >= 3:
                        for line in parts[1].split("\n"):
                            line = line.strip()
                            if line.startswith("name:"):
                                name = line.split(":", 1)[1].strip()
                            elif line.startswith("description:"):
                                description = line.split(":", 1)[1].strip()

                self._skills[name] = Skill(
                    name=name,
                    description=description or f"Skill: {name}",
                    path=skill_file,
                    content=content,
                )
                count += 1
            except Exception:
                continue
        return count

    def register_to_tools(self, tool_registry: ToolRegistry) -> int:
        """Register all discovered skills as tools in a ToolRegistry.

        Each skill becomes a tool that, when called, returns the skill's
        instructions for the agent to follow.

        Returns the number of skills registered.
        """
        count = 0
        for skill in self._skills.values():
            # Create a closure capturing the skill
            def make_handler(s: Skill):
                def _load_skill(action: str = "load") -> str:
                    if action == "summary":
                        return s.summary()
                    return s.load()
                return _load_skill

            tool_registry.register(Tool(
                name=skill.name,
                description=skill.description,
                source=ToolSource.HERMES_SKILL,
                parameters={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["load", "summary"],
                            "description": "Load full skill or get summary",
                            "default": "load",
                        },
                    },
                },
                handler=make_handler(skill),
            ))
            count += 1
        return count

    def get(self, name: str) -> Skill | None:
        return self._skills.get(name)

    def list_all(self) -> list[Skill]:
        return list(self._skills.values())


class ToolRegistry:
    """Central tool registry. Agents query this for available tools."""

    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def register_builtin(self, name: str, description: str, handler: Callable, parameters: dict | None = None) -> Tool:
        """Convenience: register a built-in tool with a Python handler."""
        tool = Tool(
            name=name,
            description=description,
            source=ToolSource.BUILTIN,
            parameters=parameters or {"type": "object", "properties": {}, "required": []},
            handler=handler,
        )
        self._tools[name] = tool
        return tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def list_for_agent(self, tool_names: list[str]) -> list[Tool]:
        """Get tools by name. Empty list = all tools."""
        if not tool_names:
            return list(self._tools.values())
        return [t for t in self._tools.values() if t.name in tool_names]

    def list_all(self) -> list[Tool]:
        return list(self._tools.values())

    def discover_skills(self, skills_dir: str) -> int:
        """Scan a directory of Hermes SKILL.md files and register them as tools."""
        skills_path = Path(skills_dir)
        if not skills_path.exists():
            return 0

        count = 0
        for skill_file in skills_path.rglob("SKILL.md"):
            try:
                content = skill_file.read_text()
                # Extract frontmatter for name/description
                name = skill_file.parent.name or skill_file.stem
                description = ""
                if content.startswith("---"):
                    parts = content.split("---", 2)
                    if len(parts) >= 3:
                        for line in parts[1].split("\n"):
                            line = line.strip()
                            if line.startswith("name:"):
                                name = line.split(":", 1)[1].strip()
                            elif line.startswith("description:"):
                                description = line.split(":", 1)[1].strip()

                self.register(Tool(
                    name=name,
                    description=description or f"Skill: {name}",
                    source=ToolSource.HERMES_SKILL,
                    parameters={
                        "type": "object",
                        "properties": {
                            "action": {
                                "type": "string",
                                "description": f"Action for {name} skill",
                            }
                        },
                    },
                ))
                count += 1
            except Exception:
                continue
        return count

    @property
    def tools(self) -> dict[str, Tool]:
        return dict(self._tools)

    def register_default_tools(self) -> ToolRegistry:
        """Register the standard built-in tool suite.

        These are the tools agents can use out of the box:
        - terminal: Execute shell commands
        - read_file: Read file contents
        - write_file: Write file contents
        """

        def _terminal(command: str, timeout: int = 30) -> str:
            """Execute a shell command and return output."""
            try:
                proc = subprocess.run(
                    command, shell=True, capture_output=True, text=True, timeout=timeout,
                )
                output = proc.stdout
                if proc.stderr:
                    output += "\n[stderr]\n" + proc.stderr
                return output.strip() or f"(exit {proc.returncode})"
            except subprocess.TimeoutExpired:
                return f"Command timed out after {timeout}s"
            except Exception as e:
                return f"Terminal error: {e}"

        def _read_file(path: str, offset: int = 1, limit: int = 500) -> str:
            """Read a file and return its contents."""
            try:
                p = Path(path)
                if not p.exists():
                    return f"File not found: {path}"
                if p.is_dir():
                    return f"Path is a directory: {path}"
                lines = p.read_text().splitlines()
                start = max(0, offset - 1)
                end = min(len(lines), start + limit)
                result = []
                for i in range(start, end):
                    result.append(f"{i+1}|{lines[i]}")
                return "\n".join(result)
            except Exception as e:
                return f"Read error: {e}"

        def _write_file(path: str, content: str) -> str:
            """Write content to a file."""
            try:
                p = Path(path)
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content)
                return f"Written {len(content)} bytes to {path}"
            except Exception as e:
                return f"Write error: {e}"

        self.register_builtin(
            "terminal", "Execute a shell command and return the output.",
            _terminal,
            parameters={
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Shell command to execute"},
                    "timeout": {"type": "integer", "description": "Timeout in seconds", "default": 30},
                },
                "required": ["command"],
            },
        )

        self.register_builtin(
            "read_file", "Read contents of a file.",
            _read_file,
            parameters={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file"},
                    "offset": {"type": "integer", "description": "Line to start from", "default": 1},
                    "limit": {"type": "integer", "description": "Max lines to return", "default": 500},
                },
                "required": ["path"],
            },
        )

        self.register_builtin(
            "write_file", "Write content to a file.",
            _write_file,
            parameters={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to write to"},
                    "content": {"type": "string", "description": "Content to write"},
                },
                "required": ["path", "content"],
            },
        )

        return self
