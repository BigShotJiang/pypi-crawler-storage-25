"""Local Agent Foundry — Agents building agents. Offline. Auditable."""

__version__ = "0.1.8"
