"""Quality gates — pre-deployment checks for agent output.

Gates run before an agent is deployed or a handoff is accepted.
Each gate is a pass/fail check with a reason.
"""

from __future__ import annotations

import ast
import re
import subprocess
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class GateResult(Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"
    ERROR = "error"


@dataclass
class GateReport:
    """Result from running a single gate."""
    gate_name: str
    result: GateResult
    reason: str = ""
    details: dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0


@dataclass
class GateRun:
    """Full gate run report."""
    run_id: str = ""
    agent_name: str = ""
    timestamp: float = field(default_factory=time.time)
    gates: list[GateReport] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(
            g.result in (GateResult.PASS, GateResult.SKIP)
            for g in self.gates
        )

    @property
    def failed_gates(self) -> list[GateReport]:
        return [g for g in self.gates if g.result == GateResult.FAIL]


# --- Individual Gates ---

DANGEROUS_COMMANDS = [
    r"\brm\s+-rf\b",          # rm -rf
    r"\brm\s+-r\b",           # rm -r (safer variant but still dangerous)
    r"\bDROP\s+TABLE\b",      # SQL DROP
    r"\bDROP\s+DATABASE\b",
    r"\bTRUNCATE\s+TABLE\b",
    r"\bDELETE\s+FROM\b",     # SQL DELETE without WHERE
    r"\bchmod\s+777\b",       # Overly permissive
    r"\bchown\s+-R\b",        # Recursive chown
    r"\bdd\s+if=",            # dd can destroy disks
    r"\bmkfs\.",              # Format filesystem
    r":(){ :\|:& };:",         # Fork bomb
    r"\beval\s+\$",           # eval with variable
    r"\bcurl.*\|\s*bash\b",   # curl pipe bash
    r"\bwget.*\|\s*bash\b",   # wget pipe bash
    r"/dev/null.*>",          # Redirecting to devices
    r"\bsudo\b",              # sudo (requires review)
    r"\bgit\s+push\s+--force\b",  # Force push
    r"\bgit\s+reset\s+--hard\b",   # Hard reset
]


def gate_syntax_python(code: str) -> GateReport:
    """Check Python code parses correctly via ast.parse."""
    start = time.monotonic()
    try:
        ast.parse(code)
        return GateReport(
            gate_name="syntax_python",
            result=GateResult.PASS,
            reason="Python AST parsed successfully.",
            duration_ms=(time.monotonic() - start) * 1000,
        )
    except SyntaxError as e:
        return GateReport(
            gate_name="syntax_python",
            result=GateResult.FAIL,
            reason=f"Syntax error at line {e.lineno}, col {e.offset}: {e.msg}",
            details={"line": e.lineno, "offset": e.offset, "text": e.text},
            duration_ms=(time.monotonic() - start) * 1000,
        )


def gate_syntax_shell(code: str) -> GateReport:
    """Check shell script syntax via bash -n."""
    start = time.monotonic()
    try:
        proc = subprocess.run(
            ["bash", "-n"],
            input=code,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if proc.returncode == 0:
            return GateReport(
                gate_name="syntax_shell",
                result=GateResult.PASS,
                reason="Shell syntax check passed.",
                duration_ms=(time.monotonic() - start) * 1000,
            )
        return GateReport(
            gate_name="syntax_shell",
            result=GateResult.FAIL,
            reason=proc.stderr.strip()[:500],
            duration_ms=(time.monotonic() - start) * 1000,
        )
    except Exception as e:
        return GateReport(
            gate_name="syntax_shell",
            result=GateResult.ERROR,
            reason=str(e),
            duration_ms=(time.monotonic() - start) * 1000,
        )


def gate_safety(text: str) -> GateReport:
    """Check for dangerous commands in text output."""
    start = time.monotonic()
    matches = []
    for pattern in DANGEROUS_COMMANDS:
        found = re.findall(pattern, text, re.IGNORECASE)
        if found:
            matches.extend(found)

    if not matches:
        return GateReport(
            gate_name="safety",
            result=GateResult.PASS,
            reason="No dangerous commands detected.",
            duration_ms=(time.monotonic() - start) * 1000,
        )

    return GateReport(
        gate_name="safety",
        result=GateResult.FAIL,
        reason=f"Dangerous commands detected: {', '.join(matches[:5])}",
        details={"matches": matches},
        duration_ms=(time.monotonic() - start) * 1000,
    )


def gate_file_exists(path: str) -> GateReport:
    """Check that a file exists."""
    start = time.monotonic()
    exists = Path(path).exists()
    return GateReport(
        gate_name="file_exists",
        result=GateResult.PASS if exists else GateResult.FAIL,
        reason=f"File {'exists' if exists else 'not found'}: {path}",
        duration_ms=(time.monotonic() - start) * 1000,
    )


def gate_security_secrets(text: str) -> GateReport:
    """Basic secret scanning — check for API key patterns, tokens."""
    start = time.monotonic()
    patterns = {
        "openai_key": r"sk-[A-Za-z0-9]{32,}",
        "github_token": r"ghp_[A-Za-z0-9]{36}",
        "aws_key": r"AKIA[0-9A-Z]{16}",
        "jwt": r"eyJ[A-Za-z0-9\-_=]+\.[A-Za-z0-9\-_=]+\.?[A-Za-z0-9\-_.+/=]*",
        "private_key": r"-----BEGIN (RSA|EC|DSA|OPENSSH) PRIVATE KEY-----",
    }

    matches = {}
    for name, pattern in patterns.items():
        found = re.findall(pattern, text)
        if found:
            matches[name] = len(found)

    if not matches:
        return GateReport(
            gate_name="security_secrets",
            result=GateResult.PASS,
            reason="No secrets detected.",
            duration_ms=(time.monotonic() - start) * 1000,
        )

    return GateReport(
        gate_name="security_secrets",
        result=GateResult.FAIL,
        reason=f"Potential secrets found: {', '.join(f'{k}({v})' for k, v in matches.items())}",
        details={"matches": matches},
        duration_ms=(time.monotonic() - start) * 1000,
    )


# --- Gate Runner ---

class GateRunner:
    """Runs a set of quality gates against agent output."""

    def __init__(self):
        self._gates: list[callable] = []

    def add(self, gate_fn: callable) -> GateRunner:
        """Register a gate function."""
        self._gates.append(gate_fn)
        return self

    def add_defaults(self) -> GateRunner:
        """Register the standard gate suite."""
        self._gates.extend([
            lambda text: gate_syntax_python(text),
            lambda text: gate_safety(text),
            lambda text: gate_security_secrets(text),
        ])
        return self

    def run(self, agent_name: str, output: str) -> GateRun:
        """Run all registered gates against agent output."""
        run = GateRun(
            run_id=str(hash(output))[:12],
            agent_name=agent_name,
        )

        for gate_fn in self._gates:
            try:
                report = gate_fn(output)
                run.gates.append(report)
            except Exception as e:
                run.gates.append(GateReport(
                    gate_name=gate_fn.__name__,
                    result=GateResult.ERROR,
                    reason=str(e),
                ))

        return run

    def run_on_file(self, agent_name: str, filepath: str) -> GateRun:
        """Run gates on a file's content."""
        try:
            content = Path(filepath).read_text()
            return self.run(agent_name, content)
        except Exception as e:
            run = GateRun(run_id=str(hash(filepath))[:12], agent_name=agent_name)
            run.gates.append(GateReport(
                gate_name="file_read",
                result=GateResult.ERROR,
                reason=f"Cannot read {filepath}: {e}",
            ))
            return run
