"""Cross-machine handoff transport layer.

Handles secure transfer of handoff packets between Foundry nodes.
Uses HTTPS with token-based authentication.

Two roles:
- Sender: Pushes a handoff packet to a peer node
- Receiver: Exposes an endpoint for incoming handoffs

Security: Nodes authenticate via a shared cluster secret (CLUSTER_SECRET env var).
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import httpx

from foundry.orchestration.node import NodeInfo


class TransportClient:
    """Client for sending handoff packets to remote Foundry nodes."""

    def __init__(self, cluster_secret: str = "", timeout: float = 30.0):
        self.cluster_secret = cluster_secret
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            headers = {
                "Content-Type": "application/json",
            }
            if self.cluster_secret:
                headers["X-Foundry-Cluster-Secret"] = self.cluster_secret
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                headers=headers,
            )
        return self._client

    async def ping(self, address: str) -> dict[str, Any]:
        """Check if a remote node is reachable."""
        client = await self._get_client()
        try:
            resp = await client.get(f"{address}/.foundry/ping")
            return {
                "reachable": resp.status_code == 200,
                "status": resp.status_code,
            }
        except Exception as e:
            return {"reachable": False, "error": str(e)}

    async def get_node_info(self, address: str) -> dict[str, Any]:
        """Fetch NodeInfo from a remote node."""
        client = await self._get_client()
        resp = await client.get(f"{address}/.foundry/node-info")
        if resp.status_code != 200:
            raise TransportError(f"Failed to get node info: {resp.status_code}")
        return resp.json()

    async def send_handoff(
        self,
        address: str,
        handoff_packet: dict[str, Any],
    ) -> dict[str, Any]:
        """Send a handoff packet to a remote node.

        Returns the remote node's response (accept/reject).
        """
        client = await self._get_client()

        payload = {
            "handoff_id": handoff_packet.get("handoff_id", ""),
            "from_node": handoff_packet.get("from_node", ""),
            "from_agent": handoff_packet.get("from_agent", ""),
            "to_agent": handoff_packet.get("to_agent", ""),
            "task": handoff_packet.get("task", {}),
            "state_snapshot": handoff_packet.get("state_snapshot", {}),
            "context": handoff_packet.get("context", {}),
            "definition_of_done": handoff_packet.get("definition_of_done", []),
            "verification": handoff_packet.get("verification", {}),
            "timestamp": time.time(),
        }

        resp = await client.post(f"{address}/.foundry/handoff/receive", json=payload)

        if resp.status_code == 202:
            return {"accepted": True, "handoff_id": payload["handoff_id"]}
        elif resp.status_code == 409:
            return {"accepted": False, "reason": "target_busy"}
        elif resp.status_code == 406:
            return {
                "accepted": False,
                "reason": resp.json().get("reason", "rejected"),
            }
        else:
            raise TransportError(
                f"Handoff failed: {resp.status_code} {resp.text[:200]}"
            )

    async def submit_result(
        self,
        address: str,
        handoff_id: str,
        result: str,
        verification_passed: bool = True,
    ) -> dict[str, Any]:
        """Submit completed work back to the originating node."""
        client = await self._get_client()
        payload = {
            "handoff_id": handoff_id,
            "result": result,
            "verification_passed": verification_passed,
            "timestamp": time.time(),
        }
        resp = await client.post(
            f"{address}/.foundry/handoff/{handoff_id}/result",
            json=payload,
        )
        return resp.json() if resp.status_code == 200 else {"error": resp.text}

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None


class HandoffTransport:
    """High-level transport for agent-to-agent handoffs across machines.

    Wraps TransportClient with NodeInfo resolution and error handling.
    """

    def __init__(self, transport: TransportClient):
        self._transport = transport

    async def handoff_to_node(
        self,
        target_node: NodeInfo,
        handoff_packet: dict[str, Any],
    ) -> dict[str, Any]:
        """Send a handoff to a specific node by address.

        Auto-retries on transient failures (up to 3 attempts).
        """
        last_error = None
        for attempt in range(3):
            try:
                return await self._transport.send_handoff(
                    target_node.address, handoff_packet
                )
            except TransportError as e:
                last_error = e
                await asyncio.sleep(2 ** attempt)
                continue
            except Exception as e:
                last_error = e
                break

        return {
            "accepted": False,
            "reason": "transport_error",
            "error": str(last_error),
        }

    async def ping_node(self, node: NodeInfo) -> bool:
        """Check if a node is reachable."""
        result = await self._transport.ping(node.address)
        return result.get("reachable", False)

    async def close(self) -> None:
        await self._transport.close()


class TransportError(Exception):
    """Raised when cross-machine transport fails."""
    pass
