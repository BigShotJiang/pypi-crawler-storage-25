"""Node identity and registry for multi-machine orchestration.

Each Foundry instance is a Node. Nodes discover each other via mDNS
or static configuration, then exchange handoff packets over HTTPS.
"""

from __future__ import annotations

import hashlib
import json
import socket
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class NodeRole(Enum):
    """Role of this node in the multi-machine cluster."""

    BUILDER = "builder"       # Runs agent builds (high compute)
    REVIEWER = "reviewer"     # Quality gates, code review
    ORCHESTRATOR = "orchestrator"  # Coordinates work across nodes
    WORKER = "worker"         # General-purpose agent runner
    OBSERVER = "observer"     # Monitoring only, no agent execution


class NodeStatus(Enum):
    ONLINE = "online"
    BUSY = "busy"
    OFFLINE = "offline"
    UNKNOWN = "unknown"


@dataclass
class NodeInfo:
    """Identity and capabilities of a Foundry node on the network."""

    node_id: str
    hostname: str = ""
    display_name: str = ""
    roles: list[NodeRole] = field(default_factory=list)
    ip_addresses: list[str] = field(default_factory=list)
    port: int = 9420  # Default Foundry orchestration port
    version: str = ""
    status: NodeStatus = NodeStatus.UNKNOWN

    # Capability flags
    backends: list[str] = field(default_factory=list)  # e.g. ["omlx", "llama_cpp"]
    max_concurrent_agents: int = 4
    current_agent_count: int = 0
    capabilities: dict[str, Any] = field(default_factory=dict)

    # Discovery metadata
    last_seen: float = 0.0
    first_seen: float = 0.0

    @classmethod
    def local(cls, port: int = 9420) -> NodeInfo:
        """Create a NodeInfo for the current machine."""
        hostname = socket.gethostname()
        node_id = hashlib.sha256(
            f"{hostname}-{uuid.getnode()}".encode()
        ).hexdigest()[:16]

        # Get local IPs
        ips = []
        try:
            for info in socket.getaddrinfo(hostname, None):
                ip = info[4][0]
                if ip not in ips and not ip.startswith("127."):
                    ips.append(ip)
        except Exception:
            pass

        return cls(
            node_id=node_id,
            hostname=hostname,
            display_name=hostname,
            roles=[NodeRole.WORKER],
            ip_addresses=ips or ["127.0.0.1"],
            port=port,
            version=cls._get_version(),
            status=NodeStatus.ONLINE,
            first_seen=time.time(),
        )

    @staticmethod
    def _get_version() -> str:
        try:
            from foundry import __version__
            return __version__
        except ImportError:
            return "0.1.0"

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "hostname": self.hostname,
            "display_name": self.display_name,
            "roles": [r.value for r in self.roles],
            "ip_addresses": self.ip_addresses,
            "port": self.port,
            "version": self.version,
            "status": self.status.value,
            "backends": self.backends,
            "max_concurrent_agents": self.max_concurrent_agents,
            "current_agent_count": self.current_agent_count,
            "capabilities": self.capabilities,
        }

    @classmethod
    def from_dict(cls, data: dict) -> NodeInfo:
        return cls(
            node_id=data.get("node_id", ""),
            hostname=data.get("hostname", ""),
            display_name=data.get("display_name", ""),
            roles=[NodeRole(r) for r in data.get("roles", [])],
            ip_addresses=data.get("ip_addresses", []),
            port=data.get("port", 9420),
            version=data.get("version", ""),
            status=NodeStatus(data.get("status", "unknown")),
            backends=data.get("backends", []),
            max_concurrent_agents=data.get("max_concurrent_agents", 4),
            current_agent_count=data.get("current_agent_count", 0),
            capabilities=data.get("capabilities", {}),
        )

    @property
    def is_available(self) -> bool:
        """Node can accept new work."""
        if self.status not in (NodeStatus.ONLINE, NodeStatus.BUSY):
            return False
        return self.current_agent_count < self.max_concurrent_agents

    @property
    def address(self) -> str:
        """Best address to reach this node."""
        for ip in self.ip_addresses:
            if not ip.startswith("127."):
                return f"http://{ip}:{self.port}"
        return f"http://{self.ip_addresses[0]}:{self.port}" if self.ip_addresses else ""


class NodeRegistry:
    """Local registry of known peer nodes.

    Nodes are discovered via mDNS or added statically.
    The registry is the source of truth for multi-machine handoff routing.
    """

    def __init__(self, storage_path: Path | str = ".foundry/nodes.json"):
        self.storage_path = Path(storage_path)
        self._nodes: dict[str, NodeInfo] = {}
        self._local_node: NodeInfo | None = None
        self._load()

    def _load(self) -> None:
        """Load persisted nodes from disk."""
        if self.storage_path.exists():
            try:
                data = json.loads(self.storage_path.read_text())
                local_data = data.get("local")
                if local_data:
                    self._local_node = NodeInfo.from_dict(local_data)
                for node_data in data.get("peers", []):
                    node = NodeInfo.from_dict(node_data)
                    self._nodes[node.node_id] = node
            except (json.JSONDecodeError, KeyError):
                pass

    def _save(self) -> None:
        """Persist node registry to disk."""
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "local": self._local_node.to_dict() if self._local_node else None,
            "peers": [n.to_dict() for n in self._nodes.values()],
        }
        self.storage_path.write_text(json.dumps(data, indent=2))

    def set_local(self, node: NodeInfo) -> None:
        """Register the local node."""
        self._local_node = node
        self._save()

    def add_peer(self, node: NodeInfo) -> None:
        """Add a discovered or static peer."""
        node.last_seen = time.time()
        if node.first_seen == 0:
            node.first_seen = time.time()
        self._nodes[node.node_id] = node
        self._save()

    def update_peer(self, node_id: str, **updates) -> NodeInfo | None:
        """Update peer status/fields."""
        node = self._nodes.get(node_id)
        if node is None:
            return None
        for key, value in updates.items():
            if hasattr(node, key):
                setattr(node, key, value)
        # Only auto-set last_seen if caller didn't explicitly set it
        if "last_seen" not in updates:
            node.last_seen = time.time()
        return node

    def remove_peer(self, node_id: str) -> bool:
        """Remove a peer from the registry."""
        if node_id in self._nodes:
            del self._nodes[node_id]
            self._save()
            return True
        return False

    def get_peer(self, node_id: str) -> NodeInfo | None:
        return self._nodes.get(node_id)

    def list_peers(self, status: NodeStatus | None = None) -> list[NodeInfo]:
        """List peers, optionally filtered by status."""
        nodes = list(self._nodes.values())
        if status:
            nodes = [n for n in nodes if n.status == status]
        return sorted(nodes, key=lambda n: n.last_seen, reverse=True)

    def find_available(self, role: NodeRole | None = None) -> list[NodeInfo]:
        """Find available peers, optionally filtered by role."""
        available = [n for n in self._nodes.values() if n.is_available]
        if role:
            available = [n for n in available if role in n.roles]
        return sorted(available, key=lambda n: n.current_agent_count)

    def mark_offline_stale(self, timeout_seconds: float = 300) -> list[str]:
        """Mark peers as offline if not seen recently. Returns list of node IDs."""
        now = time.time()
        stale = []
        for node_id, node in self._nodes.items():
            if now - node.last_seen > timeout_seconds:
                node.status = NodeStatus.OFFLINE
                stale.append(node_id)
        return stale

    @property
    def local_node(self) -> NodeInfo | None:
        return self._local_node

    @property
    def peer_count(self) -> int:
        return len(self._nodes)
