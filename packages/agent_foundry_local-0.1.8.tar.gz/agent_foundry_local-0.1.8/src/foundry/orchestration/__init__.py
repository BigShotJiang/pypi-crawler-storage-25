"""Multi-machine orchestration — peer discovery, cross-machine handoffs.

Enables Foundry instances on different machines to discover each other
and transfer work via the handoff protocol. Zero-config LAN discovery
via mDNS, or static peer configuration for VPN/air-gapped deployments.
"""

from foundry.orchestration.discovery import DiscoveryConfig, DiscoveryService
from foundry.orchestration.node import NodeInfo, NodeRegistry, NodeRole
from foundry.orchestration.transport import HandoffTransport, TransportClient

__all__ = [
    "NodeInfo",
    "NodeRegistry",
    "NodeRole",
    "DiscoveryService",
    "DiscoveryConfig",
    "TransportClient",
    "HandoffTransport",
]
