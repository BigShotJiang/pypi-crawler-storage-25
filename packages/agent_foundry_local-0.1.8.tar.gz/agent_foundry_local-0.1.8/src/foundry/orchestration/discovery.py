"""Node discovery — mDNS/Bonjour for zero-config LAN, plus static peer config.

Two modes:
1. mDNS: Nodes advertise themselves as _foundry._tcp on the local network.
   Other nodes discover them automatically. Zero configuration required.
2. Static: Nodes configured manually via `foundry cluster peer add <address>`.
   For VPNs, air-gapped networks, or cross-subnet deployments.
"""

from __future__ import annotations

import asyncio
import contextlib
import socket
import time
from collections.abc import Callable
from dataclasses import dataclass

import httpx

from foundry.orchestration.node import NodeInfo, NodeRegistry, NodeRole, NodeStatus

# Zeroconf is optional — graceful degradation if not installed
try:
    from zeroconf import ServiceInfo, Zeroconf
    from zeroconf.asyncio import AsyncServiceBrowser, AsyncZeroconf
    HAS_ZEROCONF = True
except ImportError:
    HAS_ZEROCONF = False

FOUNDRY_SERVICE_TYPE = "_foundry._tcp.local."
FOUNDRY_DISCOVERY_PORT = 9421  # Separate from transport port


@dataclass
class DiscoveryConfig:
    """Configuration for node discovery."""

    enabled: bool = True
    mode: str = "mdns"  # "mdns" | "static" | "both"
    port: int = FOUNDRY_DISCOVERY_PORT
    static_peers: list[str] = None  # e.g. ["http://192.168.1.10:9420", "http://node2:9420"]
    heartbeat_interval: float = 30.0  # seconds between heartbeat announcements
    stale_timeout: float = 120.0  # seconds before marking peer offline
    service_name: str = ""  # Optional: override mDNS service name

    def __post_init__(self):
        if self.static_peers is None:
            self.static_peers = []


class DiscoveryService:
    """Advertise and discover Foundry nodes on the local network.

    Usage:
        service = DiscoveryService(local_node, registry)
        await service.start()
        # ... nodes appear in registry
        await service.stop()
    """

    def __init__(
        self,
        local_node: NodeInfo,
        registry: NodeRegistry,
        config: DiscoveryConfig | None = None,
    ):
        self.local_node = local_node
        self.registry = registry
        self.config = config or DiscoveryConfig()
        self._running = False
        self._zeroconf: Zeroconf | None = None
        self._service_info: ServiceInfo | None = None
        self._browser: AsyncServiceBrowser | None = None
        self._http_client: httpx.AsyncClient | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._on_peer_discovered: Callable[[NodeInfo], None] | None = None

    @property
    def running(self) -> bool:
        return self._running

    async def start(self, on_peer_discovered: Callable[[NodeInfo], None] | None = None) -> None:
        """Start discovery — advertise this node and find peers."""
        self._on_peer_discovered = on_peer_discovered

        if self.config.mode in ("mdns", "both"):
            await self._start_mdns()

        if self.config.mode in ("static", "both") and self.config.static_peers:
            await self._probe_static_peers()

        self._running = True
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def stop(self) -> None:
        """Stop discovery."""
        self._running = False

        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task

        if self._browser:
            await self._browser.async_cancel()

        if self._zeroconf:
            await self._zeroconf.async_close()

        if self._http_client:
            await self._http_client.aclose()

    # ── mDNS ───────────────────────────────────────────────────────

    async def _start_mdns(self) -> None:
        """Register this node as a Zeroconf service and start browsing."""
        if not HAS_ZEROCONF:
            return

        self._zeroconf = AsyncZeroconf()

        # Advertise this node
        props = {
            b"node_id": self.local_node.node_id.encode(),
            b"version": self.local_node.version.encode(),
            b"roles": ",".join(r.value for r in self.local_node.roles).encode(),
        }
        service_name = self.config.service_name or f"Foundry-{self.local_node.hostname}"

        self._service_info = ServiceInfo(
            type_=FOUNDRY_SERVICE_TYPE,
            name=f"{service_name}.{FOUNDRY_SERVICE_TYPE}",
            addresses=[socket.inet_aton(ip) for ip in self.local_node.ip_addresses if ip],
            port=self.config.port,
            properties=props,
        )
        await self._zeroconf.async_register_service(self._service_info)

        # Browse for other nodes
        self._browser = AsyncServiceBrowser(
            self._zeroconf.zeroconf,
            FOUNDRY_SERVICE_TYPE,
            handlers=[self._on_mdns_state_change],
        )

    def _on_mdns_state_change(self, zeroconf, service_type, name, state_change) -> None:
        """Handle mDNS discovery events."""
        if state_change.name == "Added":
            info = zeroconf.get_service_info(service_type, name)
            if info and info.properties:
                node = self._mdns_to_node(info)
                if node and node.node_id != self.local_node.node_id:
                    self.registry.add_peer(node)
                    if self._on_peer_discovered:
                        self._on_peer_discovered(node)

    def _mdns_to_node(self, info) -> NodeInfo | None:
        """Convert Zeroconf ServiceInfo to NodeInfo."""
        try:
            props = info.properties
            node_id = props.get(b"node_id", b"").decode()
            if not node_id:
                return None

            roles_str = props.get(b"roles", b"").decode()
            roles = [NodeRole(r) for r in roles_str.split(",") if r]

            ips = []
            for addr in info.addresses:
                ips.append(socket.inet_ntoa(addr))

            return NodeInfo(
                node_id=node_id,
                hostname=info.server.rstrip("."),
                display_name=info.name.split(".")[0],
                roles=roles,
                ip_addresses=ips or ["127.0.0.1"],
                port=info.port or 9420,
                version=props.get(b"version", b"").decode(),
                status=NodeStatus.ONLINE,
                last_seen=time.time(),
            )
        except Exception:
            return None

    # ── Static Peers ───────────────────────────────────────────────

    async def _probe_static_peers(self) -> None:
        """Try to reach each configured static peer."""
        if not self._http_client:
            self._http_client = httpx.AsyncClient(timeout=5.0)

        for peer_url in self.config.static_peers:
            try:
                resp = await self._http_client.get(f"{peer_url}/.foundry/node-info")
                if resp.status_code == 200:
                    node = NodeInfo.from_dict(resp.json())
                    if node.node_id != self.local_node.node_id:
                        self.registry.add_peer(node)
                        if self._on_peer_discovered:
                            self._on_peer_discovered(node)
            except Exception:
                pass

    # ── Heartbeat ──────────────────────────────────────────────────

    async def _heartbeat_loop(self) -> None:
        """Periodically check peer health and mark stale nodes offline."""
        while self._running:
            await asyncio.sleep(self.config.heartbeat_interval)

            # Mark stale nodes
            self.registry.mark_offline_stale(self.config.stale_timeout)

            # Re-probe static peers
            if self.config.static_peers:
                await self._probe_static_peers()

            # Touch local node
            self.local_node.last_seen = time.time()
