"""Agent engine — lifecycle manager for AI agents.

Each agent: model + tools + skills + working dir + role.
Agents run as async tasks with state tracking and observability hooks.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

from foundry.runtime import (
    BackendType,
    GenerationRequest,
    ModelBackend,
    RuntimeRegistry,
    ToolDefinition,
)

logger = logging.getLogger(__name__)


class AgentState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    WAITING_FOR_TOOLS = "waiting_for_tools"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"


class AgentRole(Enum):
    BUILDER = "builder"
    REVIEWER = "reviewer"
    TESTER = "tester"
    DOCUMENTOR = "documentor"
    ORCHESTRATOR = "orchestrator"
    CUSTOM = "custom"


@dataclass
class AgentConfig:
    """Configuration for creating an agent."""
    name: str
    role: AgentRole = AgentRole.CUSTOM
    model: str = "qwen-8b"  # model name as known to the backend
    backend: BackendType = BackendType.OMLX
    tools: list[str] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    working_dir: str = ""
    system_prompt: str = ""
    max_iterations: int = 10  # max ReAct loop iterations
    max_tokens: int = 4096
    temperature: float = 0.7


@dataclass
class AgentTask:
    """A task assigned to an agent."""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    goal: str = ""
    context: dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    completed_at: float | None = None
    result: str | None = None
    error: str | None = None


@dataclass
class AgentEvent:
    """Observability event emitted by an agent."""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_name: str = ""
    event_type: str = ""  # state_change, tool_call, task_start, task_complete, error
    timestamp: float = field(default_factory=time.time)
    details: dict[str, Any] = field(default_factory=dict)


class Agent:
    """A single AI agent with lifecycle management.

    Agents are async — they run tasks concurrently.
    State transitions: IDLE → RUNNING → IDLE | ERROR | STOPPED
    """

    def __init__(
        self,
        config: AgentConfig,
        runtime: RuntimeRegistry,
        tools: list[ToolDefinition] | None = None,
        tool_registry = None,  # ToolRegistry | None
    ):
        from foundry.registry import ToolRegistry
        self.config = config
        self.runtime = runtime
        self._tools = tools or []
        self._tool_registry: ToolRegistry | None = tool_registry
        self.state = AgentState.IDLE
        self.current_task: AgentTask | None = None
        self._task: asyncio.Task | None = None
        self._stop_event = asyncio.Event()
        self._event_listeners: list[callable] = []
        self._created_at = time.time()
        self._task_history: list[AgentTask] = []
        self._error_count = 0
        self._total_tokens = 0
        self._total_latency_ms = 0.0

    @property
    def name(self) -> str:
        return self.config.name

    @property
    def role(self) -> AgentRole:
        return self.config.role

    @property
    def is_busy(self) -> bool:
        return self.state in (AgentState.RUNNING, AgentState.WAITING_FOR_TOOLS)

    def on_event(self, listener: callable) -> None:
        """Register an event listener. Called with AgentEvent."""
        self._event_listeners.append(listener)

    def _emit(self, event_type: str, details: dict | None = None) -> None:
        event = AgentEvent(
            agent_name=self.name,
            event_type=event_type,
            details=details or {},
        )
        for listener in self._event_listeners:
            with contextlib.suppress(Exception):
                listener(event)

    async def start(self) -> None:
        """Bring agent to IDLE state (ready to accept tasks)."""
        if self.state != AgentState.STOPPED:
            return
        self.state = AgentState.IDLE
        self._emit("state_change", {"state": "idle"})

    async def stop(self) -> None:
        """Stop the agent and cancel any running task."""
        self._stop_event.set()
        if self._task and not self._task.done():
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
        self.state = AgentState.STOPPED
        self._emit("state_change", {"state": "stopped"})

    async def pause(self) -> None:
        """Pause the agent (graceful)."""
        if self.state == AgentState.RUNNING:
            self.state = AgentState.PAUSED
            self._emit("state_change", {"state": "paused"})

    async def resume(self) -> None:
        """Resume a paused agent."""
        if self.state == AgentState.PAUSED:
            self.state = AgentState.RUNNING
            self._emit("state_change", {"state": "running"})

    async def run_task(self, task: AgentTask) -> AgentTask:
        """Assign and run a task on this agent.

        The agent enters a ReAct loop: think → act → observe → repeat.
        Returns the completed task with result or error.
        """
        if self.is_busy:
            raise RuntimeError(f"Agent {self.name} is busy ({self.state.value})")

        self.current_task = task
        self.state = AgentState.RUNNING
        self._stop_event.clear()
        self._emit("task_start", {"task_id": task.task_id, "goal": task.goal})

        try:
            backend = self._get_backend()
            if backend is None:
                task.error = f"No backend available: {self.config.backend.value}"
                self._error_count += 1
                return task

            # Build the system prompt
            system_prompt = self._build_system_prompt()

            # Build initial user prompt with task
            prompt = self._build_task_prompt(task)

            for _iteration in range(self.config.max_iterations):
                if self._stop_event.is_set():
                    task.result = "Stopped by user."
                    break

                # Generate
                request = GenerationRequest(
                    prompt=prompt,
                    system_prompt=system_prompt,
                    tools=self._tools,
                    max_tokens=self.config.max_tokens,
                    temperature=self.config.temperature,
                )

                response = await backend.generate(request)
                self._total_tokens += response.tokens_used
                self._total_latency_ms += response.latency_ms

                if response.finish_reason == "error":
                    task.error = response.text
                    break

                # If the model wants to call tools
                if response.tool_calls:
                    self.state = AgentState.WAITING_FOR_TOOLS
                    tool_results = await self._execute_tools(response.tool_calls)

                    # Feed tool results back to the model
                    tool_feedback = self._format_tool_results(tool_results)
                    prompt = (
                        f"Tool results:\n{tool_feedback}\n\n"
                        f"Continue working on: {task.goal}\n"
                        f"If the task is complete, respond with only 'DONE: <summary>'."
                    )
                    self.state = AgentState.RUNNING
                    continue

                # Model returned text — check if done
                text = response.text.strip()
                if text.upper().startswith("DONE:"):
                    task.result = text[5:].strip()
                    break

                # Model wants to continue — feed its thoughts back
                prompt = (
                    f"Your response: {text}\n\n"
                    f"Continue working on: {task.goal}\n"
                    f"If you have completed the task, respond with 'DONE: <summary>'.\n"
                    f"If you need to use tools, describe what tool you need."
                )

            else:
                # Max iterations reached
                resp_preview = response.text[:500] if 'response' in dir() else 'No response'
                task.result = (
                    f"Max iterations ({self.config.max_iterations}) reached. "
                    f"Last response: {resp_preview}"
                )

        except asyncio.CancelledError:
            task.error = "Cancelled"
        except Exception as e:
            logger.exception(f"Agent {self.name} error")
            self._error_count += 1
            task.error = str(e)
        finally:
            task.completed_at = time.time()
            self.state = AgentState.IDLE
            self._task_history.append(task)
            self.current_task = None
            if task.error:
                self._emit("task_error", {"task_id": task.task_id, "error": task.error})
            else:
                self._emit("task_complete", {"task_id": task.task_id, "result": task.result})

        return task

    def run_task_background(self, task: AgentTask) -> asyncio.Task:
        """Run a task in the background. Returns the asyncio Task handle."""
        self._task = asyncio.create_task(self.run_task(task))
        return self._task

    def _get_backend(self) -> ModelBackend | None:
        return self.runtime.get(self.config.backend)

    def _build_system_prompt(self) -> str:
        parts = [self.config.system_prompt] if self.config.system_prompt else []

        parts.append(f"You are agent '{self.name}' with role '{self.config.role.value}'.")
        parts.append(f"Working directory: {self.config.working_dir or 'current directory'}")

        if self._tools:
            tool_list = "\n".join(
                f"  - {t.name}: {t.description}" for t in self._tools
            )
            parts.append(f"Available tools:\n{tool_list}")
            parts.append("When you need a tool, describe the tool name and arguments clearly.")

        return "\n\n".join(parts)

    def _build_task_prompt(self, task: AgentTask) -> str:
        context_str = ""
        if task.context:
            context_str = "\nContext:\n" + json.dumps(task.context, indent=2)

        return (
            f"# Task\n{task.goal}\n{context_str}\n\n"
            f"When you have completed this task, respond with 'DONE: <summary of what was done>'.\n"
            f"Begin working now."
        )

    async def _execute_tools(self, tool_calls: list) -> dict[str, str]:
        """Execute tool calls using the ToolRegistry and return results."""
        results = {}
        for tc in tool_calls:
            self._emit("tool_call", {
                "tool": tc.tool_name,
                "arguments": tc.arguments,
            })

            if self._tool_registry is None:
                results[tc.tool_name] = f"Tool '{tc.tool_name}' called with {tc.arguments} (no registry)"
                continue

            tool = self._tool_registry.get(tc.tool_name)
            if tool is None:
                results[tc.tool_name] = (
                    f"Tool '{tc.tool_name}' not found in registry. "
                    f"Available tools: {list(self._tool_registry.tools.keys())}"
                )
                continue

            try:
                result = await tool.execute(tc.arguments)
                results[tc.tool_name] = result
            except Exception as e:
                results[tc.tool_name] = f"Tool '{tc.tool_name}' failed: {e}"

        return results

    def _format_tool_results(self, results: dict[str, str]) -> str:
        lines = []
        for tool_name, result in results.items():
            lines.append(f"### {tool_name}\n{result}")
        return "\n\n".join(lines)

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "role": self.config.role.value,
            "state": self.state.value,
            "tasks_completed": len([t for t in self._task_history if t.result]),
            "tasks_failed": len([t for t in self._task_history if t.error]),
            "total_tokens": self._total_tokens,
            "total_latency_ms": round(self._total_latency_ms, 2),
            "error_count": self._error_count,
            "uptime_seconds": round(time.time() - self._created_at, 0),
        }


class AgentEngine:
    """Manages multiple agents — start, stop, handoff, observe.

    Persists agent registry to disk so agents survive CLI restarts.
    """

    STATE_FILE = ".foundry/agents.json"

    def __init__(self, runtime: RuntimeRegistry, tool_registry=None):
        from foundry.registry import ToolRegistry
        self.runtime = runtime
        self.tool_registry: ToolRegistry | None = tool_registry
        self._agents: dict[str, Agent] = {}
        self._load_state()

    def create_agent(self, config: AgentConfig, tools: list[ToolDefinition] | None = None) -> Agent:
        """Create and register a new agent."""
        agent = Agent(
            config=config, runtime=self.runtime, tools=tools,
            tool_registry=self.tool_registry,
        )
        self._agents[config.name] = agent
        self._save_state()
        return agent

    def get_agent(self, name: str) -> Agent | None:
        return self._agents.get(name)

    def list_agents(self) -> list[Agent]:
        return list(self._agents.values())

    async def stop_all(self) -> None:
        """Stop all agents."""
        for agent in self._agents.values():
            await agent.stop()

    def remove_agent(self, name: str) -> bool:
        """Remove an agent from the engine."""
        if name in self._agents:
            del self._agents[name]
            self._save_state()
            return True
        return False

    def _save_state(self) -> None:
        """Persist agent configs to disk."""
        state = {
            "agents": {
                name: {
                    "name": a.config.name,
                    "role": a.config.role.value,
                    "model": a.config.model,
                    "backend": a.config.backend.value,
                    "tools": a.config.tools,
                    "skills": a.config.skills,
                    "working_dir": a.config.working_dir,
                    "system_prompt": a.config.system_prompt,
                    "stats": a.stats,
                }
                for name, a in self._agents.items()
            }
        }
        Path(self.STATE_FILE).parent.mkdir(parents=True, exist_ok=True)
        Path(self.STATE_FILE).write_text(json.dumps(state, indent=2))

    def _load_state(self) -> None:
        """Restore agent configs from disk."""
        state_path = Path(self.STATE_FILE)
        if not state_path.exists():
            return

        try:
            state = json.loads(state_path.read_text())
            for agent_data in state.get("agents", {}).values():
                config = AgentConfig(
                    name=agent_data["name"],
                    role=AgentRole(agent_data.get("role", "custom")),
                    model=agent_data.get("model", "qwen-8b"),
                    backend=BackendType(agent_data.get("backend", "omlx")),
                    tools=agent_data.get("tools", []),
                    skills=agent_data.get("skills", []),
                    working_dir=agent_data.get("working_dir", ""),
                    system_prompt=agent_data.get("system_prompt", ""),
                )
                agent = Agent(config=config, runtime=self.runtime)
                self._agents[config.name] = agent
        except Exception:
            pass
