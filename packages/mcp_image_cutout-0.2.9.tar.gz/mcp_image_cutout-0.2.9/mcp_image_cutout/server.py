# coding:utf-8
import asyncio
import base64
import io
import json
import logging
import os
import sys
import tempfile
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse, urlsplit, urlunsplit, quote, unquote

import httpx
import webbrowser
from PIL import Image
from volcengine.visual.VisualService import VisualService
from mcp.server.fastmcp import FastMCP


logging.basicConfig(
    level=logging.INFO if os.getenv('MCP_DEBUG') == '1' else logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler() if os.getenv('MCP_DEBUG') == '1' else logging.NullHandler()
    ]
)

logger = logging.getLogger(__name__)


class MCPImageCutoutConfig:
    """Configuration manager."""

    def __init__(self):
        self.volc_access_key = os.getenv('VOLC_ACCESS_KEY')
        self.volc_secret_key = os.getenv('VOLC_SECRET_KEY')
        self.upload_url = os.getenv(
            'MCP_UPLOAD_URL',
            'https://www.mcpcn.cc/api/fileUploadAndDownload/uploadMcpFile'
        )
        self.debug_mode = os.getenv('MCP_DEBUG') == '1'
        self.disable_proxies = os.getenv('MCP_DISABLE_PROXIES') == '1'
        self.max_file_size = int(os.getenv('MCP_MAX_FILE_SIZE', '52428800'))  # 50 MB
        self.request_timeout = int(os.getenv('MCP_REQUEST_TIMEOUT', '30'))
        self.allowed_domains = self._get_allowed_domains()
        self._validate_config()

    def _get_allowed_domains(self) -> List[str]:
        """Parse allowed domain whitelist from environment."""
        domains = os.getenv('MCP_ALLOWED_DOMAINS', '')
        if domains:
            return [d.strip() for d in domains.split(',')]
        return []

    def _validate_config(self):
        """Validate required configuration."""
        if not self.volc_access_key or not self.volc_secret_key:
            logger.warning("Volcengine API credentials are not configured; some features may be unavailable.")
        if self.allowed_domains:
            logger.info(f"Domain whitelist configured: {self.allowed_domains}")
        else:
            logger.warning("No domain whitelist set. Consider configuring MCP_ALLOWED_DOMAINS in production.")


class MCPImageCutoutError(Exception):
    """Base exception for image cutout errors."""
    pass


class SecurityError(MCPImageCutoutError):
    """Security-related error."""
    pass


class APIError(MCPImageCutoutError):
    """API call error."""
    pass


class VolcImageCutter:
    """Image background removal handler using Volcengine Visual API."""

    def __init__(self, config: MCPImageCutoutConfig):
        self.config = config
        self._setup_visual_service()
        self._temp_dir = None
        self._http_client = None

    def _setup_visual_service(self):
        """Initialize Volcengine visual service."""
        try:
            self.visual_service = VisualService()
            if self.config.volc_access_key and self.config.volc_secret_key:
                self.visual_service.set_ak(self.config.volc_access_key)
                self.visual_service.set_sk(self.config.volc_secret_key)
                logger.info("Volcengine API credentials configured.")
            else:
                logger.warning("Volcengine API credentials not configured.")
        except Exception as e:
            logger.error(f"Failed to initialize Volcengine service: {e}")
            raise MCPImageCutoutError(f"Failed to initialize Volcengine service: {e}")

    @asynccontextmanager
    async def _get_http_client(self):
        """Context manager for reusable HTTP client."""
        if self._http_client is None:
            timeout = httpx.Timeout(self.config.request_timeout)
            self._http_client = httpx.AsyncClient(
                timeout=timeout,
                trust_env=not self.config.disable_proxies,
                limits=httpx.Limits(max_connections=10)
            )
        try:
            yield self._http_client
        finally:
            pass  # Keep connection alive for reuse

    async def _cleanup(self):
        """Release resources."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

        if self._temp_dir and self._temp_dir.exists():
            try:
                import shutil
                shutil.rmtree(self._temp_dir)
                logger.debug(f"Cleaned up temp directory: {self._temp_dir}")
            except Exception as e:
                logger.error(f"Failed to clean up temp directory: {e}")

    def _get_temp_dir(self) -> Path:
        """Get or create a temporary directory."""
        if self._temp_dir is None or not self._temp_dir.exists():
            self._temp_dir = Path(tempfile.mkdtemp(prefix="mcp_cutout_"))
            logger.debug(f"Created temp directory: {self._temp_dir}")
        return self._temp_dir

    def _validate_url(self, url: str) -> str:
        """Validate and normalize a URL."""
        try:
            parsed = urlparse(url)

            if not parsed.scheme or not parsed.netloc:
                raise SecurityError(f"Invalid URL format: {url}")

            if parsed.scheme not in ['http', 'https']:
                raise SecurityError(f"Unsupported protocol: {parsed.scheme}")

            if self.config.allowed_domains:
                if parsed.netloc not in self.config.allowed_domains:
                    raise SecurityError(f"Domain {parsed.netloc} is not in the allowed whitelist")

            parts = urlsplit(url)

            try:
                decoded_path = unquote(parts.path)
                if decoded_path == parts.path:
                    encoded_path = quote(parts.path, safe="/-_.~")
                else:
                    encoded_path = parts.path
            except Exception:
                encoded_path = parts.path

            if parts.query and '&' in parts.query:
                encoded_query = parts.query
            else:
                encoded_query = quote(parts.query, safe="=&-_.~") if parts.query else ""

            encoded_fragment = quote(parts.fragment, safe="-_.~") if parts.fragment else ""

            normalized_url = urlunsplit((
                parts.scheme,
                parts.netloc,
                encoded_path,
                encoded_query,
                encoded_fragment
            ))

            logger.debug(f"URL validated: {url[:100]} -> {normalized_url[:100]}")
            return normalized_url

        except SecurityError:
            raise
        except Exception as e:
            raise SecurityError(f"URL validation failed for {url}: {e}")

    def _generate_secure_filename(self, prefix: str = "cutout", suffix: str = ".png") -> str:
        """Generate a secure unique filename."""
        timestamp = int(time.time() * 1000)
        random_id = uuid.uuid4().hex[:8]
        return f"{prefix}_{timestamp}_{random_id}{suffix}"

    async def saliency_segmentation(self, image_urls: List[str]) -> List[Path]:
        """
        Run saliency-based segmentation (background removal) on the given image URLs.

        Args:
            image_urls: List of image URLs (currently only one image is supported)

        Returns:
            List of temporary file paths containing the processed images.

        Raises:
            SecurityError: URL validation failed.
            APIError: Volcengine API call failed.
            MCPImageCutoutError: Other processing errors.
        """
        if not image_urls:
            raise MCPImageCutoutError("image_urls must not be empty")

        if len(image_urls) > 1:
            raise MCPImageCutoutError("Only one image URL is supported at a time")

        try:
            validated_urls = []
            for url in image_urls:
                try:
                    validated_url = self._validate_url(url)
                    validated_urls.append(validated_url)
                except SecurityError as e:
                    logger.error(f"URL validation failed: {url}, {e}")
                    raise

            form = {
                "req_key": "saliency_seg",
                "image_urls": validated_urls,
            }

            try:
                proxy_backup = {}
                if self.config.disable_proxies:
                    proxy_keys = ["HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                                  "http_proxy", "https_proxy", "all_proxy"]
                    for key in proxy_keys:
                        if key in os.environ:
                            proxy_backup[key] = os.environ.pop(key)

                logger.info(f"Starting cutout for {len(validated_urls)} image(s)")
                resp = self.visual_service.cv_process(form)

                for key, value in proxy_backup.items():
                    os.environ[key] = value

            except Exception as e:
                logger.error(f"Volcengine API call failed: {e}")
                raise APIError(f"Volcengine API call failed: {e}")

            if not resp:
                raise APIError("API returned an empty response")

            base64_images = self._extract_base64_images(resp)
            if not base64_images:
                logger.error(f"No image data found in API response: {json.dumps(resp, ensure_ascii=False)}")
                raise APIError("No valid image data found in API response")

            temp_files = []
            temp_dir = self._get_temp_dir()

            for i, base64_data in enumerate(base64_images):
                try:
                    if not base64_data:
                        continue

                    image_data = base64.b64decode(base64_data)

                    if len(image_data) > self.config.max_file_size:
                        logger.warning(f"Image {i+1} exceeds size limit ({len(image_data)} bytes)")
                        continue

                    filename = self._generate_secure_filename(f"cutout_{i+1}")
                    temp_path = temp_dir / filename
                    temp_path.write_bytes(image_data)
                    temp_files.append(temp_path)
                    logger.debug(f"Saved cutout result: {temp_path}")

                except Exception as e:
                    logger.error(f"Error processing image {i+1}: {e}")
                    continue

            if not temp_files:
                raise MCPImageCutoutError("All images failed to process")

            logger.info(f"Successfully processed {len(temp_files)} image(s)")
            return temp_files

        except (SecurityError, APIError, MCPImageCutoutError):
            raise
        except Exception as e:
            logger.error(f"Unexpected error during cutout: {e}")
            raise MCPImageCutoutError(f"Cutout processing failed: {e}")

    def _extract_base64_images(self, resp: Dict[str, Any]) -> List[str]:
        """Extract base64-encoded image data from an API response dict."""
        base64_images = []

        possible_fields = [
            'binary_data_base64', 'base64_images', 'images',
            'result_images', 'image_base64', 'data'
        ]

        if 'data' in resp and isinstance(resp['data'], dict):
            data = resp['data']
            for field in possible_fields[:-1]:
                if field in data:
                    result = data[field]
                    if isinstance(result, list):
                        base64_images.extend([img for img in result if img])
                    elif isinstance(result, str) and result:
                        base64_images.append(result)
                    break

        if not base64_images:
            for field in possible_fields[:-1]:
                if field in resp:
                    result = resp[field]
                    if isinstance(result, list):
                        base64_images.extend([img for img in result if img])
                    elif isinstance(result, str) and result:
                        base64_images.append(result)
                    break

        return base64_images

    async def upload_image_from_file(self, file_path: Path, filename: str) -> Dict[str, Any]:
        """
        Upload an image file to the configured upload endpoint.

        Args:
            file_path: Local file path to upload.
            filename: Filename to use in the upload request.

        Returns:
            Dict with 'success' bool and 'url' (on success) or 'error' (on failure).
        """
        if not file_path.exists():
            return {"success": False, "error": f"File not found: {file_path}"}

        if file_path.stat().st_size > self.config.max_file_size:
            return {"success": False, "error": f"File size exceeds limit: {self.config.max_file_size} bytes"}

        try:
            with Image.open(file_path) as img:
                width, height = img.size
                logger.debug(f"Image size: {width}x{height}")
        except Exception as e:
            return {"success": False, "error": f"Invalid image file: {e}"}

        try:
            async with self._get_http_client() as client:
                with open(file_path, 'rb') as f:
                    files = {'file': (filename, f, 'image/png')}
                    response = await client.post(self.config.upload_url, files=files)

                if response.status_code == 200:
                    result = response.json()
                    if result.get('code') == 0:
                        logger.info(f"File uploaded successfully: {filename}")
                        return {"success": True, "url": result['data']['url']}
                    else:
                        error_msg = result.get('msg', 'Unknown error')
                        logger.error(f"Upload failed: {error_msg}")
                        return {"success": False, "error": error_msg}
                else:
                    error_msg = f"HTTP {response.status_code}: {response.text}"
                    logger.error(f"Upload request failed: {error_msg}")
                    return {"success": False, "error": error_msg}

        except httpx.TimeoutException:
            return {"success": False, "error": "Upload timed out"}
        except Exception as e:
            logger.error(f"Error during upload: {e}")
            return {"success": False, "error": f"Upload failed: {e}"}


# Initialize config and services
config = MCPImageCutoutConfig()
mcp = FastMCP("image-cutout")
cutter = VolcImageCutter(config)


@mcp.tool()
async def image_cutout(image_urls: List[str], open_in_browser: bool = False) -> Dict[str, Any]:
    """
    Remove the background from an image using saliency segmentation.

    Args:
        image_urls: List of image URLs to process (currently only one image is supported per call).
        open_in_browser: Whether to open the result URL(s) in a browser tab. Default: False.

    Returns:
        A dict with success status, processed image URL(s), and details.
    """
    if not image_urls:
        raise MCPImageCutoutError("image_urls must not be empty")

    if len(image_urls) > 1:
        raise MCPImageCutoutError("Only one image URL is supported at a time")

    try:
        temp_files = await cutter.saliency_segmentation(image_urls)

        if not temp_files:
            raise MCPImageCutoutError("Cutout processing failed: no valid result")

        uploaded_urls = []
        upload_results = []

        for i, temp_file in enumerate(temp_files):
            try:
                with Image.open(temp_file) as img:
                    width, height = img.size
                    logger.debug(f"Result {i+1}: {width}x{height}")

                filename = f"cutout_{i+1}_{int(time.time())}.png"
                upload_result = await cutter.upload_image_from_file(temp_file, filename)

                if upload_result.get('success'):
                    uploaded_urls.append(upload_result['url'])
                    upload_results.append(f"Image {i+1}: success")
                    logger.info(f"Image {i+1} processed: {upload_result['url']}")
                else:
                    upload_results.append(f"Image {i+1}: {upload_result.get('error', 'Unknown error')}")
                    logger.error(f"Image {i+1} upload failed: {upload_result.get('error')}")

            except Exception as e:
                upload_results.append(f"Image {i+1}: failed - {str(e)}")
                logger.error(f"Error processing image {i+1}: {e}")
            finally:
                try:
                    if temp_file.exists():
                        temp_file.unlink()
                        logger.debug(f"Deleted temp file: {temp_file}")
                except Exception as e:
                    logger.error(f"Failed to delete temp file: {e}")

        if open_in_browser and uploaded_urls:
            try:
                for url in uploaded_urls[:3]:
                    webbrowser.open_new_tab(url)
                    await asyncio.sleep(0.5)
                logger.info(f"Opened {min(len(uploaded_urls), 3)} result(s) in browser")
            except Exception as e:
                logger.error(f"Failed to open browser: {e}")

        if uploaded_urls:
            return {
                "success": True,
                "data": uploaded_urls[0] if len(uploaded_urls) == 1 else uploaded_urls,
                "message": "\n".join(upload_results),
                "processed_count": len(uploaded_urls),
                "total_count": len(temp_files)
            }
        else:
            error_msg = "All images failed to process\n" + "\n".join(upload_results)
            raise MCPImageCutoutError(error_msg)

    except (SecurityError, APIError, MCPImageCutoutError):
        raise
    except Exception as e:
        logger.error(f"Unexpected error during processing: {e}")
        raise MCPImageCutoutError(f"Processing failed: {e}")


async def cleanup_on_exit():
    """Clean up resources on server exit."""
    try:
        await cutter._cleanup()
        logger.info("Resources cleaned up successfully")
    except Exception as e:
        logger.error(f"Resource cleanup failed: {e}")


def main():
    """Server entry point."""
    import argparse
    import signal

    parser = argparse.ArgumentParser(description='MCP Image Cutout Server')
    parser.add_argument('transport', nargs='?', default='stdio',
                        choices=['stdio', 'sse'],
                        help='Transport protocol type')
    args = parser.parse_args()

    def signal_handler(sig, frame):
        logger.info("Received exit signal, cleaning up...")
        asyncio.create_task(cleanup_on_exit())
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        logger.info(f"Starting MCP Image Cutout Server (transport: {args.transport})")

        if args.transport == 'sse':
            mcp.run(transport='sse', sse_host='127.0.0.1', sse_port=8080)
        else:
            mcp.run(transport='stdio')

    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    except Exception as e:
        logger.error(f"Server runtime error: {e}")
        raise
    finally:
        asyncio.run(cleanup_on_exit())


if __name__ == "__main__":
    main()
