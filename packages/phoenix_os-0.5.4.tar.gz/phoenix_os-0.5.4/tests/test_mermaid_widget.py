"""Tests for phoenix.tui.mermaid_widget.MermaidDiagramW.

The widget is now a plain Static wrapping a Rich Text -- no animation,
no timer. Static's internals need an active App context for render
introspection, so these tests stay at the "construction doesn't
crash" level; the render pipeline itself is covered by
`test_mermaid_render.py` (output text is correct) and by manual
smoke testing of the full TUI.
"""

from rich.text import Text

from phoenix.tui.mermaid_widget import MermaidDiagramW


class TestInit:
    def test_empty_string_does_not_crash(self):
        w = MermaidDiagramW("")
        assert w is not None

    def test_simple_chart_constructs(self):
        w = MermaidDiagramW("alpha\nbeta\ngamma")
        assert w is not None

    def test_unicode_box_drawing_constructs(self):
        chart = "┌─────┐\n│  X  │\n└──┬──┘\n   │\n   ▼"
        w = MermaidDiagramW(chart)
        assert w is not None

    def test_brackets_and_pipes_construct(self):
        # markup=False is set on construction so label-heavy charts
        # with [Start] / {Decision} / ((Circle)) don't trip Rich's
        # markup parser. Construction must succeed.
        chart = "[Start] --> [End] | {Maybe}"
        w = MermaidDiagramW(chart)
        assert w is not None

    def test_id_passes_through(self):
        w = MermaidDiagramW("x", id="chart-1")
        assert w.id == "chart-1"


class TestInternalContent:
    """Verify the widget wraps its input in a Rich Text (not a raw str)
    so Textual doesn't re-interpret brackets as markup. We probe the
    private Static._content attribute -- brittle but the only stable
    signal at unit-test level without an App context. If Textual 9.x
    breaks this, skip/drop the test; the integration test catches the
    real failure mode."""

    def test_content_is_rich_text(self):
        w = MermaidDiagramW("hello [world]")
        # Static stores the constructor arg on a mangled private attr.
        # Find it without hardcoding the mangle if possible.
        content = None
        for attr in dir(w):
            if attr.endswith("__content") or attr == "_Static__content":
                content = getattr(w, attr, None)
                if content is not None:
                    break
        if content is None:
            # Version mismatch -- skip assertion, trust the integration test
            return
        assert isinstance(content, Text)
        assert "hello [world]" in str(content)
