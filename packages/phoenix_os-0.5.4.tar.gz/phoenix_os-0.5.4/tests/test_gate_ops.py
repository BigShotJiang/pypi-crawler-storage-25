"""Tests for the v0.5 gate action vocabulary (ADD/NOOP/UPDATE/FILTER).

The gate's return value drives `MemorySystem.post_turn` -- any drift in
the action strings silently breaks storage. These tests pin the four
automatic ops. DELETE is user-explicit only (`/memory forget <q>`) and is
covered by `test_memory_commands.py`.
"""

import os
import tempfile

# Use temp DB for all tests in this module.
_TEMP_DB = tempfile.mktemp(suffix=".db")
os.environ["PHOENIX_MEMORY_DB"] = _TEMP_DB


from phoenix.memory.config import MINILM_PRESET, MemoryParams  # noqa: E402
from phoenix.memory.embeddings import EmbeddingService  # noqa: E402
from phoenix.memory.gate import NoveltyGate  # noqa: E402
from phoenix.memory.store import MemoryStore  # noqa: E402

_PARAMS = MemoryParams(**MINILM_PRESET)


def _embedder():
    return EmbeddingService(_PARAMS)


def _store():
    return MemoryStore(_PARAMS)


class TestGateActionVocabulary:
    async def test_first_fact_returns_add(self):
        store = _store()
        await store.connect()
        emb = _embedder()
        gate = NoveltyGate(_PARAMS, emb, store)
        vec = emb.embed("I prefer Python over Go")
        result = await gate.evaluate("I prefer Python over Go", vec, namespace="ns_add")
        assert result["action"] == "ADD"
        assert "gate" in result
        await store.close()

    async def test_near_duplicate_returns_noop(self):
        store = _store()
        await store.connect()
        emb = _embedder()
        gate = NoveltyGate(_PARAMS, emb, store)

        original = "I like dark mode for the editor"
        v1 = emb.embed(original)
        await store.add(
            content=original,
            category="preference",
            namespace="ns_noop",
            embedding=v1,
            strength=1.0,
        )
        # Re-evaluate the exact same content -- best_sim ~= 1.0 triggers
        # the near-duplicate branch (>= 0.85).
        result = await gate.evaluate(original, v1, namespace="ns_noop")
        assert result["action"] == "NOOP"
        assert result.get("existing_id")
        await store.close()

    async def test_handle_contradiction_returns_update(self):
        store = _store()
        await store.connect()
        emb = _embedder()
        gate = NoveltyGate(_PARAMS, emb, store)

        # Seed an old fact, then route through handle_contradiction directly.
        old_vec = emb.embed("Boss lives in Mumbai")
        old_id = await store.add(
            content="Boss lives in Mumbai",
            category="fact",
            namespace="ns_update",
            embedding=old_vec,
            strength=1.0,
        )
        new_content = "Boss lives in Bangalore"
        new_vec = emb.embed(new_content)
        result = await gate.handle_contradiction(
            old_id=old_id,
            new_content=new_content,
            embedding=new_vec,
            category="fact",
            namespace="ns_update",
        )
        assert result["action"] == "UPDATE"
        assert result["old_id"] == old_id
        assert result["new_id"] != old_id
        await store.close()

    async def test_action_keys_are_uppercase_strings(self):
        """Vocabulary contract -- callers in `memory/__init__.py` pattern-match
        on the exact strings ADD / NOOP / UPDATE / FILTER. Lowercase or
        legacy strings (`store`, `strengthen`, `contradict`, `filter`) must
        not appear as gate actions.
        """
        store = _store()
        await store.connect()
        emb = _embedder()
        gate = NoveltyGate(_PARAMS, emb, store)
        vec = emb.embed("a single fresh fact")
        result = await gate.evaluate("a single fresh fact", vec, namespace="ns_contract")
        # Whatever path the gate took, action must be in the new vocabulary.
        assert result["action"] in {"ADD", "NOOP", "UPDATE", "FILTER"}
        legacy = {"store", "strengthen", "contradict", "filter", "contradicted"}
        assert result["action"] not in legacy
        await store.close()
