"""Tests for the research-agent personality.

Pins the prompt contract for deep internet research:
- YAML loads + parses cleanly
- System prompt contains the load-bearing directives (plan loop,
  citation discipline, 15-search cap, sources section, no-fabrication)
- Abilities include web_search + read_pdf, exclude bash / write_file /
  delegate / coder-style tools
- Registry discovers it

Prompt is the contract with the model. Drifting any of the marker
strings below means a behavior change -- regressions here should
be caught before they ship.
"""

from pathlib import Path

import pytest
import yaml

from phoenix.core.registry import Registry
from phoenix.personality.parser import build_agent_prompt, parse_agent

AGENTS_DIR = Path(__file__).parent.parent / "phoenix" / "personality" / "agents"
RESEARCH_YAML = AGENTS_DIR / "research-agent.yaml"


class TestResearchYaml:
    def test_yaml_file_exists(self):
        assert RESEARCH_YAML.exists(), f"research-agent.yaml missing at {RESEARCH_YAML}"

    def test_yaml_parses(self):
        with open(RESEARCH_YAML) as f:
            data = yaml.safe_load(f)
        assert data["name"] == "research-agent"
        assert isinstance(data["rules"], list)
        assert len(data["rules"]) >= 10

    def test_agent_config_loads_via_parser(self):
        config = parse_agent(RESEARCH_YAML)
        assert config.name == "research-agent"
        assert "analytical" in config.tone
        assert config.behaviors.delegation is False
        assert config.behaviors.ask_permission is False


class TestResearchPrompt:
    @pytest.fixture
    def prompt(self) -> str:
        return build_agent_prompt("research-agent", project_context="")

    def test_mission_declared(self, prompt):
        # Research-agent is a pure researcher -- not a coder. The mission
        # line is what keeps it from drifting into editing files when
        # the model gets creative.
        lowered = prompt.lower()
        assert "research agent" in lowered
        assert "do not write code" in lowered
        assert "do not edit files" in lowered

    def test_plan_loop_documented(self, prompt):
        # The plan -> search -> synthesize -> re-query -> finalize loop
        # is the behavior that distinguishes research-agent from regular
        # web_search. All five phase markers must be present.
        lowered = prompt.lower()
        assert "plan:" in lowered
        assert "search broad first" in lowered
        assert "synthesize" in lowered
        assert "re-query" in lowered
        assert "finalize" in lowered

    def test_citation_discipline_present(self, prompt):
        # The "no claim without a source" rule is load-bearing. Without
        # it, research-agent becomes a glorified summarizer with
        # hallucinated citations (the failure mode Anthropic's post
        # dedicated the CitationAgent to solving).
        lowered = prompt.lower()
        assert "every factual claim" in lowered
        assert "[source title](url)" in prompt or "[title](url)" in prompt
        assert "no claim without a source" in lowered

    def test_conflict_surfacing_rule(self, prompt):
        # When sources disagree, the model must surface it explicitly
        # rather than picking one silently.
        assert "conflict" in prompt.lower()
        assert "disagreement" in prompt.lower() or "contradictions" in prompt.lower()

    def test_cost_gate_present(self, prompt):
        # Hard cap at 15 web_search calls. Without this the agent can
        # run unbounded and blow the token budget. Matches the
        # "stop padding the call count" guidance from the research doc.
        lowered = prompt.lower()
        assert "15 web_search" in lowered
        assert "hard cap" in lowered or "stop and finalize" in lowered

    def test_sources_section_required(self, prompt):
        # Every report ends with a deduplicated sources list. This is
        # what lets Boss audit the research afterwards.
        lowered = prompt.lower()
        assert "## sources" in lowered or "sources section" in lowered

    def test_primary_vs_secondary_source_guidance(self, prompt):
        # Prefer vendor docs over third-party recaps. Without this
        # rule, research-agent pulls from SEO-blog mirrors.
        assert "primary" in prompt.lower()
        assert "secondary" in prompt.lower()

    def test_no_fabrication_rule(self, prompt):
        # Thin search results must be reported honestly, not padded.
        lowered = prompt.lower()
        assert "do not fabricate" in lowered or "don't fabricate" in lowered


class TestResearchAbilities:
    @pytest.fixture
    def registry(self) -> Registry:
        r = Registry()
        r.discover_all()
        return r

    def test_registered_in_registry(self, registry):
        assert "research-agent" in registry.list_agents()

    def test_web_search_declared(self, registry):
        # Declared in yaml even when the ability itself isn't registered
        # (missing BRAVE_API_KEY). Registry logs a warning and the agent
        # runs without it -- graceful degradation, not an error.
        config = registry.get_agent_config("research-agent")
        assert "web_search" in config.abilities

    def test_read_pdf_declared(self, registry):
        # For source PDFs (papers, vendor docs).
        config = registry.get_agent_config("research-agent")
        assert "read_pdf" in config.abilities

    def test_no_write_abilities(self, registry):
        # Research-agent is read-only. Any write ability here would
        # contradict the "do not write code / edit files" mission.
        config = registry.get_agent_config("research-agent")
        for forbidden in ("bash", "bash_bg", "write_file", "search_replace"):
            assert forbidden not in config.abilities, (
                f"{forbidden} must not be in research-agent abilities"
            )

    def test_no_nested_delegation(self, registry):
        # Research-agent is a leaf. Brain -> research-agent is 1 hop;
        # allowing research-agent to delegate further creates a
        # 3-level tree that the sequential delegate path can't handle
        # well. Pin it off.
        config = registry.get_agent_config("research-agent")
        assert "delegate" not in config.abilities
        assert config.behaviors.delegation is False
