"""Tests for `phoenix.context.repo_map` -- Aider-style symbol map."""

from pathlib import Path

from phoenix.context.intent import intent_from_input
from phoenix.context.providers import TurnState
from phoenix.context.ranking import page_rank
from phoenix.context.repo_map import (
    RepoMapProvider,
    extract_symbols,
    render_repo_map,
    scan_repository,
)

# -- ranking.page_rank --


class TestPageRank:
    def test_empty_graph_returns_empty(self):
        assert page_rank({}) == {}

    def test_single_node_no_edges(self):
        # Without dangling-node redistribution, an isolated node converges
        # to the random-teleport floor (1-d)/n = 0.15. That's the documented
        # behavior of this simpler variant -- correct for ranking-relative-
        # to-itself use cases like the repo map.
        ranks = page_rank({"a": set()})
        assert "a" in ranks
        assert 0.0 < ranks["a"] <= 1.0

    def test_two_node_chain(self):
        # a -> b. b should rank higher than a (a sends rank to b).
        ranks = page_rank({"a": {"b"}, "b": set()})
        assert ranks["b"] > ranks["a"]

    def test_target_only_node_scored(self):
        # 'b' never appears as key, only as target of 'a' -- still ranked.
        ranks = page_rank({"a": {"b"}})
        assert "b" in ranks
        assert ranks["b"] > 0.0

    def test_scores_sum_close_to_one(self):
        ranks = page_rank({"a": {"b"}, "b": {"c"}, "c": {"a"}})
        total = sum(ranks.values())
        assert 0.95 < total < 1.05

    def test_high_indegree_outranks_low(self):
        graph = {
            "popular": set(),
            "f1": {"popular"},
            "f2": {"popular"},
            "f3": {"popular"},
            "obscure": set(),
        }
        ranks = page_rank(graph)
        assert ranks["popular"] > ranks["obscure"]


# -- extract_symbols --


class TestExtractSymbols:
    def test_extracts_classes_and_functions(self, tmp_path: Path):
        f = tmp_path / "x.py"
        f.write_text(
            "class Foo:\n    pass\n\ndef bar():\n    return 1\n\nasync def baz():\n    return 2\n"
        )
        defined, refs = extract_symbols(f)
        names = {s.name: s.kind for s in defined}
        assert names == {"Foo": "class", "bar": "function", "baz": "async_function"}

    def test_collects_referenced_names(self, tmp_path: Path):
        f = tmp_path / "x.py"
        f.write_text("def x():\n    return Foo() + bar.baz\n")
        defined, refs = extract_symbols(f)
        assert "Foo" in refs
        assert "baz" in refs

    def test_skips_nested_defs(self, tmp_path: Path):
        f = tmp_path / "x.py"
        f.write_text("def outer():\n    def inner():\n        return 1\n    return inner\n")
        defined, _ = extract_symbols(f)
        names = {s.name for s in defined}
        assert "outer" in names
        assert "inner" not in names

    def test_syntax_error_returns_empty(self, tmp_path: Path):
        f = tmp_path / "broken.py"
        f.write_text("def x(:\n  pass")
        defined, refs = extract_symbols(f)
        assert defined == []
        assert refs == set()


# -- scan_repository --


class TestScanRepository:
    def test_walks_python_files(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("class A: pass\n")
        (tmp_path / "b.py").write_text("def b(): pass\n")
        scan = scan_repository(tmp_path)
        assert "A" in scan.symbols_by_name
        assert "b" in scan.symbols_by_name

    def test_skips_venv_and_pycache(self, tmp_path: Path):
        (tmp_path / "real.py").write_text("class Real: pass\n")
        venv = tmp_path / ".venv" / "lib"
        venv.mkdir(parents=True)
        (venv / "stub.py").write_text("class Stub: pass\n")
        cache = tmp_path / "__pycache__"
        cache.mkdir()
        (cache / "junk.py").write_text("class Junk: pass\n")
        scan = scan_repository(tmp_path)
        assert "Real" in scan.symbols_by_name
        assert "Stub" not in scan.symbols_by_name
        assert "Junk" not in scan.symbols_by_name

    def test_records_file_defines_and_references(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("class A: pass\n")
        (tmp_path / "b.py").write_text("def b():\n    return A()\n")
        scan = scan_repository(tmp_path)
        # b references A
        assert "A" in scan.file_references["b.py"]


# -- render_repo_map --


class TestRenderRepoMap:
    def test_empty_scan_returns_empty(self):
        from phoenix.context.repo_map import RepoScan

        out = render_repo_map(RepoScan())
        assert out == ""

    def test_renders_top_symbols_with_header(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("class Popular: pass\n")
        (tmp_path / "b.py").write_text(
            "from a import Popular\n"
            "def f1():\n    return Popular()\n"
            "def f2():\n    return Popular()\n"
        )
        scan = scan_repository(tmp_path)
        out = render_repo_map(scan)
        assert "[Project map" in out
        assert "Popular" in out

    def test_truncates_to_budget(self, tmp_path: Path):
        for i in range(20):
            (tmp_path / f"f{i}.py").write_text(f"class C{i}: pass\n")
        scan = scan_repository(tmp_path)
        out = render_repo_map(scan, budget=200)
        assert len(out) <= 200


# -- RepoMapProvider integration --


class TestRepoMapProvider:
    def _state(self, technical: bool = True, depth: int = 3) -> TurnState:
        intent = intent_from_input("x")
        intent.is_technical = technical
        intent.depth = depth
        return TurnState(user_input="x", intent=intent)

    def test_skips_non_technical(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("class A: pass\n")
        p = RepoMapProvider(cwd=tmp_path)
        assert p.should_inject(self._state(technical=False)) is False

    def test_skips_low_depth(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("class A: pass\n")
        p = RepoMapProvider(cwd=tmp_path)
        assert p.should_inject(self._state(technical=True, depth=1)) is False

    def test_fires_on_technical_deep(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("class A: pass\n")
        p = RepoMapProvider(cwd=tmp_path)
        assert p.should_inject(self._state(technical=True, depth=3)) is True

    def test_skips_when_no_symbols_found(self, tmp_path: Path):
        # Empty cwd -> no .py files -> scan empty -> never inject.
        p = RepoMapProvider(cwd=tmp_path)
        assert p.should_inject(self._state()) is False

    def test_priority_is_4_unprotected(self):
        # Below MemoryRecall(2) and Conflict(3); not protected.
        assert RepoMapProvider().priority == 4

    def test_truncates_to_per_provider_max(self, tmp_path: Path):
        for i in range(20):
            (tmp_path / f"f{i}.py").write_text(f"class C{i}: pass\n")
        p = RepoMapProvider(cwd=tmp_path, max_chars=200)
        out = p.render(self._state(), 100_000)
        assert len(out) <= 200
