"""Tests for the unified `notes` façade.

Phase 2 of notes-unification: `notes.py` no longer owns SQLite. Every
action routes through `MemorySystem` so notes inherit gate dedup,
contradiction supersession, strength decay, and consolidation.

The decorator wraps `notes` with the interceptor; tests call the raw
function via `__wrapped__` to bypass approval + hook machinery.
"""

from __future__ import annotations

import os
import tempfile

os.environ["PHOENIX_MEMORY_DB"] = tempfile.mktemp(suffix=".db")

import pytest  # noqa: E402

from phoenix.abilities import PhoenixContext  # noqa: E402
from phoenix.abilities.notes import notes as _notes_ability  # noqa: E402
from phoenix.memory import MemorySystem  # noqa: E402
from phoenix.memory.config import MINILM_PRESET, MemoryParams  # noqa: E402

_TEST_PARAMS = MemoryParams(**MINILM_PRESET)


# The decorator wraps notes; unwrap to call the raw coroutine directly.
_notes = getattr(_notes_ability, "__wrapped__", _notes_ability)


async def _fresh_ctx() -> tuple[PhoenixContext, MemorySystem]:
    mem = MemorySystem(_TEST_PARAMS)
    ctx = PhoenixContext(config={}, memory=mem, agent_name="test")
    return ctx, mem


class TestNotesWrite:
    async def test_write_adds_a_note_memory(self):
        ctx, mem = await _fresh_ctx()
        out = await _notes(
            ctx, "write", title="Hyperfocus pattern", content="holds 3h on one thing"
        )
        assert "Noted" in out
        # Round-trip via list.
        listing = await _notes(ctx, "list")
        assert "Hyperfocus" in listing or "hyperfocus" in listing
        await mem.close()

    async def test_write_missing_content_refuses(self):
        ctx, mem = await _fresh_ctx()
        out = await _notes(ctx, "write")
        assert "empty" in out.lower() or "refused" in out.lower()
        await mem.close()

    async def test_duplicate_write_reinforces(self):
        ctx, mem = await _fresh_ctx()
        first = await _notes(ctx, "write", title="same note", content="same body")
        second = await _notes(ctx, "write", title="same note", content="same body")
        assert "Noted" in first
        # Second write: NOOP reinforce, UPDATE supersede, or ADD -- any
        # of these is acceptable as long as we don't crash and the listing
        # doesn't double.
        assert any(tok in second for tok in ("reinforced", "Already", "Superseded", "Noted"))
        await mem.close()


class TestNotesList:
    async def test_list_returns_no_match_for_unrelated_topic(self):
        # The test DB is shared across tests in this session, so we can't
        # assert an empty global listing. Filter by a unique topic string
        # to exercise the "no notes" path deterministically.
        ctx, mem = await _fresh_ctx()
        out = await _notes(ctx, "list", related_topic="definitely_not_a_real_topic_xyz123")
        assert "No notes" in out
        await mem.close()

    async def test_listing_returns_only_category_note(self):
        """Non-note memories must not leak into a /notes list call."""
        ctx, mem = await _fresh_ctx()
        # Drop a plain fact directly -- should not show up.
        await mem._ensure_initialized()
        await mem.store.add(
            "pi is three point one four",
            category="fact",
            embedding=mem.embedder.embed_document("pi is three point one four"),
            namespace="global",
        )
        await _notes(ctx, "write", title="real note", content="actual observation")
        listing = await _notes(ctx, "list")
        assert "real note" in listing or "actual observation" in listing
        assert "pi is three" not in listing
        await mem.close()


class TestNotesSearch:
    async def test_search_matches_semantically(self):
        ctx, mem = await _fresh_ctx()
        await _notes(
            ctx, "write", title="working on memory pipeline", content="architectural rewrite"
        )
        out = await _notes(ctx, "search", query="memory architecture")
        assert (
            "matching" in out.lower() or "architectural" in out.lower() or "memory" in out.lower()
        )
        await mem.close()

    async def test_search_empty_query_rejects(self):
        ctx, mem = await _fresh_ctx()
        out = await _notes(ctx, "search")
        assert "query" in out.lower()
        await mem.close()


class TestNotesWeakenAndDelete:
    async def test_resolve_reduces_strength(self):
        ctx, mem = await _fresh_ctx()
        await _notes(ctx, "write", title="pending finance", content="mumbai budget help")
        await mem._ensure_initialized()
        # Pick up the id from the DB directly.
        rows = await mem.store.search_text("mumbai", namespace="global", limit=5)
        assert rows, "setup failed: note not persisted"
        note_id = rows[0]["id"]
        before = float(rows[0]["strength"])
        out = await _notes(ctx, "resolve", note_id=note_id)
        assert "Resolved" in out or "resolved" in out
        after = await mem.store.get(note_id)
        assert after is not None
        assert float(after["strength"]) < before
        await mem.close()

    async def test_resolve_nonexistent_is_graceful(self):
        ctx, mem = await _fresh_ctx()
        out = await _notes(ctx, "resolve", note_id="deadbeef")
        assert "No such note" in out
        await mem.close()

    async def test_resolve_refuses_on_non_note_category(self):
        ctx, mem = await _fresh_ctx()
        await mem._ensure_initialized()
        fid = await mem.store.add(
            "pi = 3.14",
            category="fact",
            embedding=mem.embedder.embed_document("pi = 3.14"),
            namespace="global",
        )
        out = await _notes(ctx, "resolve", note_id=fid)
        assert "not a note" in out
        await mem.close()

    async def test_delete_hard_removes(self):
        ctx, mem = await _fresh_ctx()
        await _notes(ctx, "write", title="throwaway", content="will be deleted")
        rows = await mem.store.search_text("throwaway", namespace="global", limit=5)
        assert rows
        note_id = rows[0]["id"]
        out = await _notes(ctx, "delete", note_id=note_id)
        assert "Deleted" in out
        gone = await mem.store.get(note_id)
        assert gone is None
        await mem.close()


class TestNotesUpdate:
    async def test_update_replaces_content(self):
        ctx, mem = await _fresh_ctx()
        await _notes(ctx, "write", title="target", content="v1 of the thought")
        rows = await mem.store.search_text("v1 of the thought", namespace="global", limit=5)
        assert rows
        old_id = rows[0]["id"]
        out = await _notes(ctx, "update", note_id=old_id, title="target", content="v2 revised")
        assert "Updated" in out or "rewrote" in out
        # Old id should be gone; v2 should be findable.
        gone = await mem.store.get(old_id)
        assert gone is None
        rows2 = await mem.store.search_text("v2 revised", namespace="global", limit=5)
        assert rows2
        await mem.close()

    async def test_update_missing_id_refuses(self):
        ctx, mem = await _fresh_ctx()
        out = await _notes(ctx, "update", content="does not matter")
        assert "Provide note_id" in out
        await mem.close()

    async def test_update_preserves_original_on_gate_filter(self, monkeypatch):
        """If ingest_intentional returns FILTER, the old note must stay.
        Pre-fix: `_update` deleted the old before ingest, silently losing
        the note when the gate rejected the new write.
        """
        ctx, mem = await _fresh_ctx()
        await _notes(ctx, "write", title="important", content="keep this around")
        rows = await mem.store.search_text("keep this around", namespace="global", limit=5)
        assert rows
        note_id = rows[0]["id"]

        # Force the gate into FILTER for the update write.
        async def fake_ingest(content, **kw):
            return {"action": "FILTER", "reason": "forced for test"}

        monkeypatch.setattr(mem, "ingest_intentional", fake_ingest)
        out = await _notes(ctx, "update", note_id=note_id, content="rewrite attempt")
        assert "preserved" in out or "rejected" in out
        still_there = await mem.store.get(note_id)
        assert still_there is not None, "update must not delete on FILTER"
        await mem.close()


class TestNotesIntentPropagation:
    """The deliberate-write path must carry `intent="intentional"` all the
    way from the ability to the gate. Unit tests cover each stage; this
    integration test pins the end-to-end wiring."""

    async def test_write_tags_stored_row_intentional(self):
        ctx, mem = await _fresh_ctx()
        await _notes(ctx, "write", title="int-prop-test", content="deliberate observation")
        rows = await mem.store.search_text("deliberate observation", namespace="global", limit=5)
        assert rows
        assert rows[0].get("intent") == "intentional"
        assert rows[0].get("category") == "note"
        await mem.close()

    async def test_gate_sees_intentional_intent(self, monkeypatch):
        """Assert gate.evaluate receives intent='intentional' when called
        via the notes ability. Protects against a future refactor silently
        stripping the kwarg."""
        ctx, mem = await _fresh_ctx()
        await mem._ensure_initialized()
        captured: dict = {}
        orig = mem._gate.evaluate

        async def spy(content, embedding, namespace="global", ai_output_text="", intent=None):
            captured["intent"] = intent
            return await orig(
                content,
                embedding,
                namespace=namespace,
                ai_output_text=ai_output_text,
                intent=intent,
            )

        monkeypatch.setattr(mem._gate, "evaluate", spy)
        await _notes(ctx, "write", title="spy probe", content="checking intent hits gate")
        assert captured.get("intent") == "intentional"
        await mem.close()


class TestNotesUnknownAction:
    async def test_unknown_action_returns_guidance(self):
        ctx, mem = await _fresh_ctx()
        out = await _notes(ctx, "yolo")
        assert "Unknown action" in out
        await mem.close()


@pytest.fixture(autouse=True, scope="session")
def _cleanup():
    yield
    import contextlib

    with contextlib.suppress(FileNotFoundError):
        os.unlink(os.environ["PHOENIX_MEMORY_DB"])
