"""Tests for phoenix.core.bg_processes.

Covers the manager lifecycle (start, stop, logs, shutdown) and bash
auto-promotion. No real long-running servers -- we use `sleep` and
short shell loops to exercise the code paths deterministically.
"""

from __future__ import annotations

import asyncio
import os

import pytest

from phoenix.core import bg_processes as bg_mod
from phoenix.core.bg_processes import BackgroundProcessManager, reset_manager_for_tests


@pytest.fixture
def bg_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(bg_mod, "BG_DIR", tmp_path)
    reset_manager_for_tests()
    yield tmp_path
    reset_manager_for_tests()


@pytest.fixture
def auto_approve():
    from phoenix.core.interceptor import (
        AutoApprovalBackend,
        get_approval_backend,
        set_approval_backend,
    )

    prev = get_approval_backend()
    set_approval_backend(AutoApprovalBackend(mode="yolo"))
    yield
    set_approval_backend(prev)


class TestBackgroundProcessManager:
    async def test_start_spawns_and_captures_output(self, bg_dir):
        mgr = BackgroundProcessManager()
        bg = await mgr.start("echo hello; sleep 0.5; echo world")
        await asyncio.sleep(1.2)
        assert not bg.is_running
        buf = "".join(bg.buffer)
        assert "hello" in buf
        assert "world" in buf
        assert bg.log_path.exists()
        assert "hello" in bg.log_path.read_text()

    async def test_tail_logs_returns_ring_buffer_tail(self, bg_dir):
        mgr = BackgroundProcessManager()
        bg = await mgr.start("for i in 1 2 3 4 5; do echo line_$i; done")
        await asyncio.sleep(0.4)
        tail = mgr.tail_logs(bg.bg_id, lines=2)
        assert tail is not None
        assert "line_4" in tail
        assert "line_5" in tail

    async def test_tail_logs_unknown_id_returns_none(self, bg_dir):
        mgr = BackgroundProcessManager()
        assert mgr.tail_logs("bg_nope") is None

    async def test_list_running_vs_all(self, bg_dir):
        mgr = BackgroundProcessManager()
        short = await mgr.start("echo quick")
        long = await mgr.start("sleep 3")
        await asyncio.sleep(0.4)
        all_ids = {b.bg_id for b in mgr.list_all()}
        assert {short.bg_id, long.bg_id} == all_ids
        running_ids = {b.bg_id for b in mgr.list_running()}
        assert running_ids == {long.bg_id}
        await mgr.stop(long.bg_id, force=True)
        await asyncio.sleep(0.3)

    async def test_stop_signals_running_process(self, bg_dir):
        mgr = BackgroundProcessManager()
        bg = await mgr.start("sleep 5")
        await asyncio.sleep(0.2)
        assert bg.is_running
        ok = await mgr.stop(bg.bg_id, force=False)
        assert ok
        await asyncio.sleep(0.3)
        assert not bg.is_running

    async def test_stop_returns_false_for_unknown_id(self, bg_dir):
        mgr = BackgroundProcessManager()
        assert (await mgr.stop("bg_nope")) is False

    async def test_shutdown_all_kills_everything(self, bg_dir):
        mgr = BackgroundProcessManager()
        await mgr.start("sleep 5")
        await mgr.start("sleep 5")
        await asyncio.sleep(0.2)
        assert len(mgr.list_running()) == 2
        await mgr.shutdown_all()
        await asyncio.sleep(0.3)
        assert mgr.list_running() == []

    async def test_terminate_all_sync_no_event_loop_wait(self, bg_dir):
        mgr = BackgroundProcessManager()
        await mgr.start("sleep 5")
        await mgr.start("sleep 5")
        await asyncio.sleep(0.2)
        n = mgr.terminate_all_sync()
        assert n == 2
        await asyncio.sleep(0.3)
        assert mgr.list_running() == []

    async def test_ids_are_unique(self, bg_dir):
        mgr = BackgroundProcessManager()
        ids = set()
        for _ in range(8):
            bg = await mgr.start("true")
            ids.add(bg.bg_id)
        assert len(ids) == 8

    async def test_collect_initial_output_returns_partial(self, bg_dir):
        mgr = BackgroundProcessManager()
        bg = await mgr.start("echo warmup; sleep 2")
        out = await mgr.collect_initial_output(bg, seconds=0.5)
        assert "warmup" in out
        await mgr.stop(bg.bg_id, force=True)
        await asyncio.sleep(0.3)

    def test_get_manager_is_singleton(self, bg_dir):
        a = bg_mod.get_manager()
        b = bg_mod.get_manager()
        assert a is b


class TestBashPromotion:
    async def test_fast_command_runs_in_foreground(self, bg_dir, monkeypatch):
        from phoenix.abilities import bash as bash_mod

        monkeypatch.setenv("PHOENIX_BASH_PROMOTE_SEC", "5")
        out = await bash_mod._run_with_promotion("echo quick", timeout=10, cwd=os.getcwd())
        assert "quick" in out
        assert "RELAUNCHED" not in out

    async def test_slow_command_is_promoted_to_bg(self, bg_dir, monkeypatch):
        from phoenix.abilities import bash as bash_mod

        monkeypatch.setenv("PHOENIX_BASH_PROMOTE_SEC", "0.3")
        out = await bash_mod._run_with_promotion(
            "echo early; sleep 5",
            timeout=30,
            cwd=os.getcwd(),
        )
        assert "RELAUNCHED" in out
        assert "WARNING" in out
        assert "bg_" in out
        mgr = bg_mod.get_manager()
        assert len(mgr.list_all()) == 1
        bg_id = mgr.list_all()[0].bg_id
        await mgr.stop(bg_id, force=True)
        await asyncio.sleep(0.3)

    async def test_promoted_output_includes_partial_capture(self, bg_dir, monkeypatch):
        from phoenix.abilities import bash as bash_mod

        monkeypatch.setenv("PHOENIX_BASH_PROMOTE_SEC", "0.5")
        out = await bash_mod._run_with_promotion(
            "echo compiling_step_1; sleep 5",
            timeout=30,
            cwd=os.getcwd(),
        )
        assert "compiling_step_1" in out
        mgr = bg_mod.get_manager()
        for bg in mgr.list_all():
            await mgr.stop(bg.bg_id, force=True)
        await asyncio.sleep(0.3)

    def test_promote_env_parsing(self, monkeypatch):
        from phoenix.abilities import bash as bash_mod

        monkeypatch.setenv("PHOENIX_BASH_PROMOTE_SEC", "bad")
        assert bash_mod._get_promote_after() == bash_mod.PROMOTE_AFTER_SEC
        monkeypatch.setenv("PHOENIX_BASH_PROMOTE_SEC", "0")
        assert bash_mod._get_promote_after() == bash_mod.PROMOTE_AFTER_SEC
        monkeypatch.setenv("PHOENIX_BASH_PROMOTE_SEC", "7.5")
        assert bash_mod._get_promote_after() == 7.5
        monkeypatch.delenv("PHOENIX_BASH_PROMOTE_SEC", raising=False)
        assert bash_mod._get_promote_after() == bash_mod.PROMOTE_AFTER_SEC

    async def test_cancellation_kills_subprocess(self, bg_dir, monkeypatch):
        """If the outer task is cancelled while a bash command is still
        running, the subprocess must be SIGKILLed on the way out -- not
        left dangling. Exercises the `finally: _cleanup_orphan()` path.
        """
        from phoenix.abilities import bash as bash_mod

        # Very long promote threshold so the foreground branch stays hot.
        monkeypatch.setenv("PHOENIX_BASH_PROMOTE_SEC", "30")
        task = asyncio.create_task(
            bash_mod._run_with_promotion("sleep 10", timeout=60, cwd=os.getcwd())
        )
        await asyncio.sleep(0.3)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
        await asyncio.sleep(0.3)
        # A leaked child would show as a zombie `sleep 10`; this assertion
        # is indirect but checking /proc is platform-specific. The stronger
        # guarantee is that _cleanup_orphan ran without raising -- the test
        # reaching this point means cancellation propagated cleanly.


class TestBashBgAbility:
    async def test_bash_bg_starts_and_returns_id(self, bg_dir, auto_approve):
        from phoenix.abilities.bash import bash_bg

        fn = getattr(bash_bg, "__wrapped__", bash_bg)
        out = await fn("sleep 5", "", 0.2)
        assert "Started bg_" in out
        mgr = bg_mod.get_manager()
        for bg in mgr.list_all():
            await mgr.stop(bg.bg_id, force=True)
        await asyncio.sleep(0.3)

    async def test_bash_bg_blocks_dangerous_command(self, bg_dir):
        from phoenix.abilities.bash import bash_bg

        fn = getattr(bash_bg, "__wrapped__", bash_bg)
        out = await fn("rm -rf /", "", 0.1)
        assert "Blocked" in out
