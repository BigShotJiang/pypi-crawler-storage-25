"""Tests for the `!cmd` shell-escape (issue #14).

Covers the BangResultW renderable builder. The full widget mount needs a
live Textual app, so we test the pure Text-builder directly -- and
separately exercise the subprocess shape used by `_handle_bang`.
"""

from __future__ import annotations

import asyncio
import os

import pytest

from phoenix.tui.widgets import BangResultW


class TestBangResultRender:
    def test_renders_command_and_output(self):
        plain = BangResultW._build("pwd", "/home/user\n", 0).plain
        assert "$ pwd" in plain
        assert "/home/user" in plain
        assert "(exit" not in plain  # zero exit code is silent

    def test_nonzero_exit_surfaced(self):
        plain = BangResultW._build("false", "", 1).plain
        assert "$ false" in plain
        assert "(exit 1)" in plain

    def test_output_truncated_at_cap(self):
        big = "x" * 20_000
        plain = BangResultW._build("cat big", big, 0).plain
        assert "truncated" in plain
        assert len(plain) < len(big) + 500

    def test_empty_output_still_renders_command(self):
        plain = BangResultW._build("true", "", 0).plain
        assert "$ true" in plain


class TestBangSubprocess:
    """Exercise the subprocess pattern used by `_handle_bang` in isolation.

    Not testing the TUI handler directly -- that requires a mounted Textual
    app. But the subprocess + timeout shape is the part worth pinning so
    `!sleep 999` doesn't hang Phoenix forever.
    """

    async def test_simple_command_captures_output(self):
        proc = await asyncio.create_subprocess_shell(
            "echo hello",
            cwd=os.getcwd(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=5.0)
        assert b"hello" in out
        assert proc.returncode == 0

    async def test_nonzero_exit_propagated(self):
        proc = await asyncio.create_subprocess_shell(
            "exit 7",
            cwd=os.getcwd(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        await asyncio.wait_for(proc.communicate(), timeout=5.0)
        assert proc.returncode == 7

    async def test_timeout_kills_process(self):
        proc = await asyncio.create_subprocess_shell(
            "sleep 30",
            cwd=os.getcwd(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        with pytest.raises(TimeoutError):
            await asyncio.wait_for(proc.communicate(), timeout=0.3)
        proc.kill()
        await proc.wait()
        assert proc.returncode != 0
