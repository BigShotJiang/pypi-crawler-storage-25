"""Tests for `BudgetArbiter` and `DCBP` orchestrator."""

from dataclasses import dataclass

from phoenix.context.arbiter import BudgetArbiter
from phoenix.context.intent import TurnIntent, intent_from_input
from phoenix.context.pipeline import DCBP
from phoenix.context.providers import MemoryRecallProvider, TurnState


class _FakeTopicTracker:
    def __init__(self, context: str = ""):
        self._context = context

    def build_context(self) -> str:
        return self._context


@dataclass
class _FakeProvider:
    priority: int
    _content: str = ""
    _inject: bool = True

    def should_inject(self, state: TurnState) -> bool:
        return self._inject

    def render(self, state: TurnState, budget: int) -> str:
        return self._content


def _make_state(
    user_input: str = "hi",
    memory_context: str = "",
    session_summary: str = "",
    topic_context: str = "",
    intent: TurnIntent | None = None,
) -> TurnState:
    return TurnState(
        user_input=user_input,
        intent=intent or intent_from_input(user_input),
        memory_context=memory_context,
        session_summary=session_summary,
        topic_context=topic_context,
    )


class TestBudgetArbiter:
    def test_empty_providers_returns_empty(self):
        arb = BudgetArbiter()
        result = arb.plan([], _make_state())
        assert result.rendered == []
        assert result.total_chars == 0
        assert result.dropped == []

    def test_skips_providers_where_should_inject_false(self):
        arb = BudgetArbiter()
        providers = [_FakeProvider(priority=5, _content="x" * 10, _inject=False)]
        result = arb.plan(providers, _make_state())
        assert result.rendered == []

    def test_includes_providers_where_should_inject_true(self):
        arb = BudgetArbiter()
        providers = [_FakeProvider(priority=5, _content="abc", _inject=True)]
        result = arb.plan(providers, _make_state())
        assert len(result.rendered) == 1
        assert result.rendered[0][1] == "abc"
        assert result.total_chars == 3

    def test_orders_by_priority_ascending(self):
        arb = BudgetArbiter()
        providers = [
            _FakeProvider(priority=8, _content="third"),
            _FakeProvider(priority=1, _content="first"),
            _FakeProvider(priority=5, _content="second"),
        ]
        result = arb.plan(providers, _make_state())
        contents = [c for _, c in result.rendered]
        assert contents == ["first", "second", "third"]

    def test_drops_lowest_priority_when_over_budget(self):
        arb = BudgetArbiter(total_budget=10)
        providers = [
            _FakeProvider(priority=1, _content="x" * 5),
            _FakeProvider(priority=5, _content="y" * 5),
            _FakeProvider(priority=8, _content="z" * 5),
        ]
        result = arb.plan(providers, _make_state())
        # P1 is protected (<=3). P5 and P8 can drop. Drop from P8 first.
        contents = [c for _, c in result.rendered]
        assert "x" * 5 in contents
        assert result.total_chars <= 10
        assert result.dropped != []

    def test_protected_priority_never_dropped(self):
        arb = BudgetArbiter(total_budget=5)
        # Two protected providers totaling 10 chars cannot be dropped
        # even though we exceed the budget.
        providers = [
            _FakeProvider(priority=1, _content="x" * 5),
            _FakeProvider(priority=2, _content="y" * 5),
            _FakeProvider(priority=8, _content="z" * 5),
        ]
        result = arb.plan(providers, _make_state())
        contents = [c for _, c in result.rendered]
        assert "x" * 5 in contents
        assert "y" * 5 in contents
        assert "z" * 5 not in contents

    def test_empty_render_output_not_included(self):
        arb = BudgetArbiter()
        providers = [_FakeProvider(priority=5, _content="", _inject=True)]
        result = arb.plan(providers, _make_state())
        assert result.rendered == []


class TestDCBP:
    def test_social_input_renders_only_user_message(self):
        dcbp = DCBP()
        prompt, result = dcbp.run("hello")
        assert prompt == "hello"
        assert result.total_chars == 0

    def test_with_memory_context(self):
        dcbp = DCBP()
        prompt, _ = dcbp.run("hello", memory_context="[M] Boss likes X")
        assert prompt == "[M] Boss likes X\n\nhello"

    def test_with_session_summary_and_memory(self):
        dcbp = DCBP()
        prompt, _ = dcbp.run(
            "what's next",
            memory_context="recalled fact",
            session_summary="yesterday we did X",
        )
        expected = "[Previous session]\nyesterday we did X\n\nrecalled fact\n\nwhat's next"
        assert prompt == expected

    def test_with_topic_tracker(self):
        dcbp = DCBP()
        prompt, _ = dcbp.run(
            "next",
            topic_tracker=_FakeTopicTracker(context="T1 done"),
        )
        assert "[Session context]\nT1 done" in prompt
        assert prompt.endswith("next")

    def test_complex_query_includes_reasoning_instruction(self):
        dcbp = DCBP()
        prompt, _ = dcbp.run("compare X and Y")
        assert "[Reasoning mode:" in prompt
        assert prompt.endswith("compare X and Y")

    def test_user_input_always_last(self):
        dcbp = DCBP()
        prompt, _ = dcbp.run(
            "final question",
            memory_context="facts",
            session_summary="prior",
            topic_tracker=_FakeTopicTracker(context="topic"),
        )
        assert prompt.endswith("final question")

    def test_returns_arbiter_result_for_metrics(self):
        dcbp = DCBP()
        _, result = dcbp.run("compare", memory_context="x" * 100)
        assert len(result.rendered) >= 2

    def test_custom_budget_respected(self):
        dcbp = DCBP(budget=20)
        _, result = dcbp.run("compare", memory_context="y" * 200)
        assert result.total_chars <= 20 or "ReasoningModeProvider" in result.dropped

    def test_custom_providers_list(self):
        dcbp = DCBP(providers=[MemoryRecallProvider()])
        prompt, _ = dcbp.run("compare X and Y", memory_context="Mem")
        assert "[Reasoning mode:" not in prompt
        assert prompt == "Mem\n\ncompare X and Y"
