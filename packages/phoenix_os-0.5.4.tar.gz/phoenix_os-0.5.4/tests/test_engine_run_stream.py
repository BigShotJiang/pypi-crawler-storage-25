"""End-to-end test for `PhoenixEngine.run_stream`.

Exercises the real run_stream event loop with a mocked pydantic-ai Agent
that emits a controlled sequence of stream events. Verifies:
- text deltas yield ("text", delta) tuples
- FunctionToolCallEvent yields ("tool_call", id, name, args)
- FunctionToolResultEvent yields ("tool_result", id, content, is_error)
- AgentRunResultEvent captures usage + messages on engine state
- turn_cache resets between turns
- web_context + ambient_summary integration paths
"""

from __future__ import annotations

from dataclasses import dataclass

import pytest

from phoenix.abilities import PhoenixContext
from phoenix.core.engine import PhoenixEngine

# -- Fakes for pydantic-ai event types --


@dataclass
class _FakeUsage:
    request_tokens: int = 100
    response_tokens: int = 50


@dataclass
class _FakeRunResult:
    _usage: _FakeUsage
    _messages: list

    def usage(self):
        return self._usage

    def all_messages(self):
        return self._messages


def _build_text_event(delta: str):
    """Construct a real PartDeltaEvent so isinstance checks in
    `stream_events.translate_event` succeed."""
    from pydantic_ai.messages import PartDeltaEvent, TextPartDelta

    return PartDeltaEvent(index=0, delta=TextPartDelta(content_delta=delta))


def _build_tool_call_event(call_id: str, name: str, args: dict):
    from pydantic_ai.messages import FunctionToolCallEvent, ToolCallPart

    part = ToolCallPart(tool_name=name, args=args, tool_call_id=call_id)
    return FunctionToolCallEvent(part=part)


def _build_tool_result_event(call_id: str, content: str, is_error: bool = False):
    from pydantic_ai.messages import (
        FunctionToolResultEvent,
        RetryPromptPart,
        ToolReturnPart,
    )

    if is_error:
        result = RetryPromptPart(content=content, tool_call_id=call_id, tool_name="x")
    else:
        result = ToolReturnPart(tool_name="x", content=content, tool_call_id=call_id)
    return FunctionToolResultEvent(result=result)


def _build_run_result_event(usage: _FakeUsage, messages: list):
    from pydantic_ai.run import AgentRunResultEvent

    return AgentRunResultEvent(result=_FakeRunResult(usage, messages))


class _FakeAgent:
    """Stand-in for `pydantic_ai.Agent` -- yields a canned event sequence."""

    def __init__(self, events: list):
        self._events = events

    async def run_stream_events(self, prompt: str, message_history=None):
        for event in self._events:
            yield event


def _make_engine() -> PhoenixEngine:
    eng = PhoenixEngine()
    eng._phoenix_context = PhoenixContext()
    return eng


# -- Tests --


class TestRunStreamEvents:
    async def test_text_delta_yields_text_tuple(self):
        eng = _make_engine()
        eng._agent = _FakeAgent([_build_text_event("hello ")])
        out = [item async for item in eng.run_stream("hi")]
        assert ("text", "hello ") in out

    async def test_text_chunks_concatenated_into_last_output(self):
        eng = _make_engine()
        eng._agent = _FakeAgent(
            [
                _build_text_event("Hello, "),
                _build_text_event("Boss"),
                _build_run_result_event(_FakeUsage(), []),
            ]
        )
        async for _ in eng.run_stream("hi"):
            pass
        assert eng.last_output == "Hello, Boss"

    async def test_tool_call_event_yields_tool_call_tuple(self):
        eng = _make_engine()
        eng._agent = _FakeAgent([_build_tool_call_event("call-1", "bash", {"cmd": "ls"})])
        out = [item async for item in eng.run_stream("run ls")]
        tool_calls = [t for t in out if t[0] == "tool_call"]
        assert len(tool_calls) == 1
        kind, call_id, name, args = tool_calls[0]
        assert call_id == "call-1"
        assert name == "bash"
        assert args == {"cmd": "ls"}

    async def test_tool_result_event_yields_tool_result_tuple(self):
        eng = _make_engine()
        eng._agent = _FakeAgent([_build_tool_result_event("call-1", "file.txt\n", is_error=False)])
        out = [item async for item in eng.run_stream("ls")]
        tool_results = [t for t in out if t[0] == "tool_result"]
        assert len(tool_results) == 1
        kind, call_id, content, is_error = tool_results[0]
        assert call_id == "call-1"
        assert content == "file.txt\n"
        assert is_error is False

    async def test_retry_prompt_marked_as_error(self):
        eng = _make_engine()
        eng._agent = _FakeAgent(
            [_build_tool_result_event("call-1", "tool exploded", is_error=True)]
        )
        out = [item async for item in eng.run_stream("ls")]
        tool_results = [t for t in out if t[0] == "tool_result"]
        assert tool_results[0][3] is True

    async def test_run_result_event_captures_usage(self):
        eng = _make_engine()
        usage = _FakeUsage(request_tokens=42, response_tokens=17)
        eng._agent = _FakeAgent(
            [
                _build_text_event("ok"),
                _build_run_result_event(usage, []),
            ]
        )
        async for _ in eng.run_stream("anything"):
            pass
        assert eng.last_usage is usage

    async def test_run_result_event_captures_messages(self):
        eng = _make_engine()
        messages = ["m1", "m2"]
        eng._agent = _FakeAgent([_build_run_result_event(_FakeUsage(), messages)])
        async for _ in eng.run_stream("anything"):
            pass
        assert eng.last_history == messages


class TestRunStreamIntegration:
    async def test_turn_cache_clears_at_start(self):
        eng = _make_engine()
        eng._phoenix_context.turn_cache["stale"] = "old data"
        eng._agent = _FakeAgent([])
        async for _ in eng.run_stream("hi"):
            pass
        # Cache cleared at the top of run_stream.
        assert "stale" not in eng._phoenix_context.turn_cache

    async def test_no_phoenix_context_does_not_crash(self):
        eng = PhoenixEngine()  # _phoenix_context stays None
        eng._agent = _FakeAgent([_build_text_event("hi")])
        out = [item async for item in eng.run_stream("anything")]
        assert ("text", "hi") in out

    async def test_stakes_keyword_prepends_caveat(self):
        eng = _make_engine()
        eng._agent = _FakeAgent(
            [_build_text_event("Yes."), _build_run_result_event(_FakeUsage(), [])]
        )
        async for _ in eng.run_stream("should i accept the job offer?"):
            pass
        assert "important decision" in eng.last_output
        assert "Yes." in eng.last_output

    async def test_empty_text_delta_not_yielded(self):
        eng = _make_engine()
        eng._agent = _FakeAgent([_build_text_event(""), _build_text_event("real")])
        out = [item async for item in eng.run_stream("hi")]
        text_events = [t for t in out if t[0] == "text"]
        # Empty delta filtered; only "real" is yielded.
        assert text_events == [("text", "real")]

    async def test_active_history_capped_to_max(self):
        """Regression: MAX_ACTIVE_HISTORY=20 must be enforced every turn,
        not just on topic shift. v0.8 bug -- a notes-heavy session was
        hitting 36k input tokens by turn 5 because the cap was declared
        but never applied on the normal path. See engine.py module docstring.
        """
        from phoenix.core.engine import MAX_ACTIVE_HISTORY

        eng = _make_engine()
        # 50 fake messages -- well over the 20 cap.
        many_messages = [f"msg-{i}" for i in range(50)]
        eng._agent = _FakeAgent([_build_run_result_event(_FakeUsage(), many_messages)])
        async for _ in eng.run_stream("anything"):
            pass
        # _trim_history may scan forward to a safe cut point; final length
        # must be <= MAX_ACTIVE_HISTORY (and ideally close to it).
        assert len(eng.last_history) <= MAX_ACTIVE_HISTORY


@pytest.fixture
def eng():
    return _make_engine()
