"""Tests for `RecallEngine.format_for_prompt` -- the per-memory render line.

Surfacing recall confidence (`conf:0.XX`) is a v0.6 contract: the LLM
needs to see how strongly Phoenix matched a memory so it can hedge on
weak recalls instead of stating every entry as ground truth.
"""

import os
import tempfile
import time

_TEMP_DB = tempfile.mktemp(suffix=".db")
os.environ["PHOENIX_MEMORY_DB"] = _TEMP_DB


from phoenix.memory.config import MINILM_PRESET, MemoryParams  # noqa: E402
from phoenix.memory.embeddings import EmbeddingService  # noqa: E402
from phoenix.memory.recall import RecallEngine  # noqa: E402
from phoenix.memory.store import MemoryStore  # noqa: E402

_PARAMS = MemoryParams(**MINILM_PRESET)


def _engine() -> RecallEngine:
    store = MemoryStore(_PARAMS)
    embedder = EmbeddingService(_PARAMS)
    return RecallEngine(_PARAMS, embedder, store)


class TestFormatForPromptConfidence:
    def test_includes_conf_when_relevance_set(self):
        eng = _engine()
        memories = [
            {
                "content": "Boss prefers direct feedback",
                "category": "preference",
                "strength": 1.2,
                "access_count": 3,
                "created_at": time.time() - 7200,
                "relevance": 0.78,
            }
        ]
        out = eng.format_for_prompt(memories, max_tokens=400)
        assert "conf:0.78" in out
        assert "Boss prefers direct feedback" in out

    def test_omits_conf_when_relevance_missing(self):
        eng = _engine()
        memories = [
            {
                "content": "stale entry without scoring",
                "category": "fact",
                "strength": 1.0,
                "access_count": 0,
                "created_at": time.time(),
            }
        ]
        out = eng.format_for_prompt(memories, max_tokens=400)
        assert "conf:" not in out

    def test_conf_renders_two_decimals(self):
        eng = _engine()
        memories = [
            {
                "content": "x",
                "category": "fact",
                "strength": 1.0,
                "access_count": 0,
                "created_at": time.time(),
                "relevance": 0.5,
            }
        ]
        out = eng.format_for_prompt(memories, max_tokens=400)
        assert "conf:0.50" in out

    def test_conf_position_after_type(self):
        """`conf:` must come AFTER `type:` and BEFORE the optional flag block.

        That ordering is what the LLM is going to be primed to scan -- if
        future recall additions slot something in between, callers that
        regex-extract conf will break.
        """
        eng = _engine()
        memories = [
            {
                "content": "x",
                "category": "fact",
                "strength": 1.0,
                "access_count": 0,
                "created_at": time.time(),
                "relevance": 0.42,
                "pinned": True,
            }
        ]
        out = eng.format_for_prompt(memories, max_tokens=400)
        type_idx = out.find("type:fact")
        conf_idx = out.find("conf:0.42")
        pinned_idx = out.find("PINNED")
        assert type_idx < conf_idx < pinned_idx


class TestFormatForPromptCwd:
    def test_includes_working_in_line(self):
        """v0.4.1: model sees cwd the same way it sees current time --
        ambient context for cross-project recall disambiguation."""
        eng = _engine()
        memories = [
            {
                "content": "a memory",
                "category": "fact",
                "strength": 1.0,
                "access_count": 1,
                "created_at": time.time(),
                "relevance": 0.5,
            }
        ]
        out = eng.format_for_prompt(memories, max_tokens=400)
        assert "Working in:" in out

    def test_cwd_appears_after_time(self):
        """Ordering: current time -> working in -> memory entries.

        Both are ambient signals; the model scans them together as turn
        preamble before reading memories.
        """
        eng = _engine()
        memories = [
            {
                "content": "a memory",
                "category": "fact",
                "strength": 1.0,
                "access_count": 1,
                "created_at": time.time(),
                "relevance": 0.5,
            }
        ]
        out = eng.format_for_prompt(memories, max_tokens=400)
        time_idx = out.find("Current time:")
        cwd_idx = out.find("Working in:")
        assert 0 <= time_idx < cwd_idx
