"""Tests for phoenix.tui.clipboard.

No real Textual app -- we stub `app.query` + `app.notify` and monkey-patch
every clipboard writer, so tests run headless on CI without a display server,
tmux, or pbcopy.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from phoenix.tui import clipboard as clip


class _FakeWidget:
    def __init__(self, selection, selected_text: str | None):
        self.text_selection = selection
        self._text = selected_text

    def get_selection(self, _sel):
        if self._text is None:
            return None
        return (self._text, None)


class _BrokenWidget:
    @property
    def text_selection(self):
        raise RuntimeError("oops")


class _FakeApp:
    def __init__(self, widgets):
        self._widgets = widgets
        self.notify = MagicMock()

    def query(self, _pattern):
        return self._widgets


@pytest.fixture(autouse=True)
def patch_writers(monkeypatch):
    """Redirect every copy strategy into an in-memory buffer."""
    buf = {"value": None}

    def fake_write(text):
        buf["value"] = text

    def fake_read():
        return buf["value"]

    monkeypatch.setattr(clip, "_COPY_METHODS", [fake_write])
    monkeypatch.setattr(clip, "_PASTE_METHODS", [fake_read])
    return buf


class TestHarvestSelections:
    def test_collects_selected_fragments(self):
        app = _FakeApp(
            [
                _FakeWidget("sel_a", "hello"),
                _FakeWidget("sel_b", "world"),
            ]
        )
        assert clip._harvest_selections(app) == ["hello", "world"]

    def test_skips_widgets_with_no_selection(self):
        app = _FakeApp(
            [
                _FakeWidget(None, None),
                _FakeWidget("sel", "picked"),
            ]
        )
        assert clip._harvest_selections(app) == ["picked"]

    def test_skips_empty_and_whitespace(self):
        app = _FakeApp(
            [
                _FakeWidget("sel", "   "),
                _FakeWidget("sel", ""),
                _FakeWidget("sel", "ok"),
            ]
        )
        assert clip._harvest_selections(app) == ["ok"]

    def test_swallows_widget_exceptions(self):
        app = _FakeApp([_BrokenWidget(), _FakeWidget("sel", "survives")])
        assert clip._harvest_selections(app) == ["survives"]


class TestCopySelectionToClipboard:
    def test_copies_and_toasts_on_success(self, patch_writers):
        app = _FakeApp([_FakeWidget("sel", "phoenix rocks")])
        out = clip.copy_selection_to_clipboard(app, show_toast=True)
        assert out == "phoenix rocks"
        assert patch_writers["value"] == "phoenix rocks"
        app.notify.assert_called_once()

    def test_returns_none_when_no_selection(self, patch_writers):
        app = _FakeApp([_FakeWidget(None, None)])
        out = clip.copy_selection_to_clipboard(app)
        assert out is None
        assert patch_writers["value"] is None
        app.notify.assert_not_called()

    def test_joins_multiple_fragments_with_newline(self, patch_writers):
        app = _FakeApp(
            [
                _FakeWidget("a", "line one"),
                _FakeWidget("b", "line two"),
            ]
        )
        out = clip.copy_selection_to_clipboard(app, show_toast=False)
        assert out == "line one\nline two"
        assert patch_writers["value"] == "line one\nline two"

    def test_all_writers_fail_notifies_warning(self, monkeypatch):
        def boom(_text):
            raise RuntimeError("no clipboard")

        monkeypatch.setattr(clip, "_COPY_METHODS", [boom])
        monkeypatch.setattr(clip, "_PASTE_METHODS", [])
        app = _FakeApp([_FakeWidget("sel", "text")])
        out = clip.copy_selection_to_clipboard(app, show_toast=True)
        assert out is None
        app.notify.assert_called_once()
        args, kwargs = app.notify.call_args
        # Severity kwarg present, signalling warning.
        assert kwargs.get("severity") == "warning"


class TestNonSelectableMixin:
    def test_widget_with_mixin_returns_none(self):
        from phoenix.tui.widgets import NonSelectableMixin

        class FakeChrome(NonSelectableMixin):
            pass

        w = FakeChrome()
        assert w.text_selection is None
        assert w.get_selection("anything") is None
        # Setter swallows writes (does not raise).
        w.text_selection = "ignored"
        assert w.text_selection is None
