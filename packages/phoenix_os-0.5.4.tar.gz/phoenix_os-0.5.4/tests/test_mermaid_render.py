"""Tests for phoenix.tui.mermaid_render.

Uses the vendored `beautiful_mermaid` renderer directly -- no subprocess,
no optional dep. Tests cover: empty-source short-circuit, header
normalization (force `flowchart TD` when missing), per-session cache,
graceful None on render failure.
"""

import pytest

from phoenix.tui import mermaid_render


@pytest.fixture(autouse=True)
def _clean_cache():
    mermaid_render.clear_cache()
    yield
    mermaid_render.clear_cache()


class TestRender:
    def test_is_available_true_in_dev(self):
        # Vendored file ships with the package; should always import.
        assert mermaid_render.is_available() is True

    def test_empty_source_returns_none(self):
        assert mermaid_render.render_mermaid("") is None
        assert mermaid_render.render_mermaid("   \n  ") is None

    def test_real_flowchart_renders(self):
        src = """flowchart TD
            A[Start] --> B{OK?}
            B -->|Yes| C[Done]
            B -->|No| D[Retry]"""
        out = mermaid_render.render_mermaid(src)
        assert out is not None
        # Unicode box-drawing chars indicate a real render, not raw source
        assert "│" in out or "┌" in out
        # Labels come through without the bracket leak that plagued the
        # Go binary (the regression this whole swap exists to fix).
        assert "Start" in out
        assert "Done" in out
        assert "[Start]" not in out  # brackets must NOT leak into boxes

    def test_graceful_none_on_bad_source(self, monkeypatch):
        # Simulate a render raising -- callers get None, not an exception
        def _bad_render(_src):
            raise RuntimeError("parser blew up")

        from phoenix.tui.vendor import beautiful_mermaid

        monkeypatch.setattr(beautiful_mermaid, "render_mermaid_ascii", _bad_render)
        assert mermaid_render.render_mermaid("flowchart TD\nA-->B") is None


class TestHeaderNormalization:
    def test_adds_flowchart_td_when_missing(self):
        # Bare edge list with no `flowchart` / `graph` header -- renderer
        # would otherwise return an empty canvas.
        src = "A --> B\nB --> C"
        out = mermaid_render.render_mermaid(src)
        assert out is not None
        assert "│" in out or "┌" in out  # real render happened

    def test_preserves_explicit_flowchart_lr(self):
        # Boss explicitly wrote LR -- we must NOT rewrite it to TD.
        src = "flowchart LR\n    A[One] --> B[Two]"
        out = mermaid_render.render_mermaid(src)
        assert out is not None
        assert "One" in out and "Two" in out

    def test_preserves_explicit_graph_header(self):
        src = "graph TD\n    A --> B"
        out = mermaid_render.render_mermaid(src)
        assert out is not None


class TestCache:
    def test_same_source_hits_cache(self, monkeypatch):
        call_count = {"n": 0}

        original = mermaid_render
        from phoenix.tui.vendor import beautiful_mermaid

        real = beautiful_mermaid.render_mermaid_ascii

        def _counting(src):
            call_count["n"] += 1
            return real(src)

        monkeypatch.setattr(beautiful_mermaid, "render_mermaid_ascii", _counting)

        src = "flowchart TD\nA --> B"
        original.render_mermaid(src)
        original.render_mermaid(src)  # cache hit
        assert call_count["n"] == 1

    def test_different_source_misses_cache(self, monkeypatch):
        call_count = {"n": 0}
        from phoenix.tui.vendor import beautiful_mermaid

        real = beautiful_mermaid.render_mermaid_ascii

        def _counting(src):
            call_count["n"] += 1
            return real(src)

        monkeypatch.setattr(beautiful_mermaid, "render_mermaid_ascii", _counting)

        mermaid_render.render_mermaid("flowchart TD\nA --> B")
        mermaid_render.render_mermaid("flowchart TD\nX --> Y")
        assert call_count["n"] == 2

    def test_clear_cache_works(self, monkeypatch):
        call_count = {"n": 0}
        from phoenix.tui.vendor import beautiful_mermaid

        real = beautiful_mermaid.render_mermaid_ascii

        def _counting(src):
            call_count["n"] += 1
            return real(src)

        monkeypatch.setattr(beautiful_mermaid, "render_mermaid_ascii", _counting)

        src = "flowchart TD\nA --> B"
        mermaid_render.render_mermaid(src)
        mermaid_render.clear_cache()
        mermaid_render.render_mermaid(src)  # cache was cleared, re-renders
        assert call_count["n"] == 2
