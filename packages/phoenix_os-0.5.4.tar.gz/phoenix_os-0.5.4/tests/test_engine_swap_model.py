"""Tests for engine.swap_model -- mid-session model switch without wiping state.

Covers issue #6: before this path, `/model set` only updated the
persisted config. The cached Agent instance kept using the old model,
forcing users to restart Phoenix to switch models -- which wiped their
in-memory conversation history.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from phoenix.abilities import PhoenixContext
from phoenix.core.engine import PhoenixEngine


@pytest.fixture
def booted_engine():
    """A PhoenixEngine with just enough state for swap_model to run.

    Full boot() requires network (memory embedder warm-up, DCBP, topic
    tracker). This fixture fakes the minimum surface swap_model touches.
    """
    from phoenix.core.registry import get_registry

    eng = PhoenixEngine()
    eng._registry = get_registry()
    eng._registry.discover_all()
    eng._project_context = "(test project context)"
    eng._phoenix_context = PhoenixContext(
        config={"phoenix_dir": "/tmp"}, memory=None, agent_name="brain"
    )
    eng._hook_runner = None
    # Seed an initial agent so we can verify swap replaces it with a
    # DIFFERENT instance.
    from phoenix.core.factory import build_agent

    # Use ollama:* for the seed agent so pydantic-ai's eager provider
    # validation doesn't require a real OPENAI_API_KEY / ANTHROPIC_API_KEY
    # in CI. Ollama routes to localhost via OpenAIChatModel without an
    # auth check.
    eng._agent = build_agent(
        agent_name="brain",
        registry=eng._registry,
        project_context=eng._project_context,
        phoenix_context=eng._phoenix_context,
        model_override="ollama:seed-test-model",
    )
    return eng


_SWAP_TARGET = "ollama:next-test-model"


class TestSwapModel:
    def test_swap_returns_new_model_string(self, booted_engine):
        out = booted_engine.swap_model(_SWAP_TARGET)
        assert out == _SWAP_TARGET

    def test_swap_replaces_agent_instance(self, booted_engine):
        original = booted_engine.agent
        booted_engine.swap_model(_SWAP_TARGET)
        assert booted_engine.agent is not original, (
            "swap_model must construct a fresh Agent; old one would keep "
            "using the previous model on next turn"
        )

    def test_swap_preserves_registry(self, booted_engine):
        reg_before = booted_engine._registry
        booted_engine.swap_model(_SWAP_TARGET)
        assert booted_engine._registry is reg_before, (
            "swap_model must not wipe the ability/agent registry"
        )

    def test_swap_preserves_phoenix_context(self, booted_engine):
        ctx_before = booted_engine._phoenix_context
        booted_engine.swap_model(_SWAP_TARGET)
        assert booted_engine._phoenix_context is ctx_before, (
            "swap_model must not drop the PhoenixContext (memory, config)"
        )

    def test_swap_before_boot_raises(self):
        bare = PhoenixEngine()
        with pytest.raises(RuntimeError, match="Engine not booted"):
            bare.swap_model(_SWAP_TARGET)


class TestCmdModelWiresSwap:
    """`/model set` must call engine.swap_model so the next turn uses
    the new model without a restart."""

    def test_cmd_model_calls_engine_swap(self, booted_engine, tmp_path, monkeypatch):
        # Point config.yaml at a tmp dir so the persist path can't mutate
        # the real user config during tests.
        monkeypatch.setenv("PHOENIX_DIR", str(tmp_path))
        monkeypatch.setattr("phoenix.config.settings.PHOENIX_DIR", tmp_path)

        from phoenix.shell.commands import CommandContext, cmd_model

        ctx = CommandContext(history=[], engine=booted_engine)

        called_with = {}
        orig = booted_engine.swap_model

        def spy(new_model: str) -> str:
            called_with["model"] = new_model
            return orig(new_model)

        with patch.object(booted_engine, "swap_model", side_effect=spy):
            out = cmd_model(f"set {_SWAP_TARGET}", ctx)

        assert called_with.get("model") == _SWAP_TARGET
        assert "session live" in out or "persisted" in out
