"""Tests for `phoenix.core.critic.critique` -- adversarial review pass."""

import asyncio
from dataclasses import dataclass

from phoenix.core.critic import CritiqueResult, _parse_flags, critique


@dataclass
class _FakeAgent:
    """Stand-in for `pydantic_ai.Agent` -- returns a pre-set string."""

    canned: str = "OK"
    delay_s: float = 0.0
    raise_exc: Exception | None = None

    async def run(self, prompt: str):
        if self.raise_exc:
            raise self.raise_exc
        if self.delay_s:
            await asyncio.sleep(self.delay_s)
        return _FakeResult(self.canned)


@dataclass
class _FakeResult:
    output: str


def _factory(canned: str = "OK", delay_s: float = 0.0, exc: Exception | None = None):
    return lambda: _FakeAgent(canned=canned, delay_s=delay_s, raise_exc=exc)


class TestParseFlags:
    def test_ok_alone_returns_empty(self):
        assert _parse_flags("OK") == []
        assert _parse_flags("ok") == []
        assert _parse_flags("  OK  ") == []

    def test_single_flag(self):
        flags = _parse_flags("FLAG: assumes Vercel deployment")
        assert flags == ["assumes Vercel deployment"]

    def test_multiple_flags(self):
        text = "FLAG: env not stated\nFLAG: pattern-matched without verification"
        flags = _parse_flags(text)
        assert len(flags) == 2
        assert "env not stated" in flags
        assert "pattern-matched without verification" in flags

    def test_mixed_lines_picks_only_flag_lines(self):
        text = "Some preamble\nFLAG: real concern\nNot a flag line\nFLAG: another"
        assert _parse_flags(text) == ["real concern", "another"]

    def test_lowercase_flag_prefix(self):
        # Robust to model-formatted casing
        assert _parse_flags("flag: lowercase prefix") == ["lowercase prefix"]


class TestCritique:
    async def test_empty_output_skips_call(self):
        # Empty output should not trigger any agent call -- check via factory
        # that would raise if invoked.
        called = []

        def factory():
            called.append(True)
            return _FakeAgent()

        result = await critique("hello", "", agent_factory=factory)
        assert isinstance(result, CritiqueResult)
        assert result.flags == []
        assert called == []

    async def test_ok_response_yields_no_flags(self):
        result = await critique("user", "output", agent_factory=_factory("OK"))
        assert result.flags == []
        assert result.has_flags is False

    async def test_flag_response_parsed(self):
        canned = "FLAG: assumes Vercel target\nFLAG: inherited DIRECT_URL pref"
        result = await critique("u", "o", agent_factory=_factory(canned))
        assert len(result.flags) == 2
        assert result.has_flags is True

    async def test_timeout_returns_empty_flags(self):
        result = await critique(
            "u",
            "o",
            timeout_s=0.05,
            agent_factory=_factory("OK", delay_s=1.0),
        )
        assert result.flags == []
        assert result.timed_out is True

    async def test_exception_in_critic_returns_empty_flags(self):
        result = await critique(
            "u",
            "o",
            agent_factory=_factory(exc=RuntimeError("boom")),
        )
        assert result.flags == []
        assert result.timed_out is False
        assert result.error == "boom"

    async def test_factory_default_is_lazy(self):
        """Ensure no API client is built when output is empty -- factory is
        only called when there's something to review."""
        result = await critique("hi", "")
        assert result.flags == []
