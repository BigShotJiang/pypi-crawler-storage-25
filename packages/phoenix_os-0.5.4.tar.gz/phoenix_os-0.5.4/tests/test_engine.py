"""Tests for phoenix.core.engine helpers.

Focus: _trim_history must never leave an orphan tool_result or dangling
tool_use at index 0 of the trimmed slice. The Anthropic API rejects such
histories with status 400 (see issue #9).
"""

from pydantic_ai.messages import (
    ModelRequest,
    ModelResponse,
    TextPart,
    ToolCallPart,
    ToolReturnPart,
    UserPromptPart,
)

from phoenix.core.engine import _trim_history


def _user(text: str) -> ModelRequest:
    return ModelRequest(parts=[UserPromptPart(content=text)])


def _assistant_text(text: str) -> ModelResponse:
    return ModelResponse(parts=[TextPart(content=text)])


def _assistant_tool_call(tool_name: str, tool_call_id: str, args: str = "{}") -> ModelResponse:
    return ModelResponse(
        parts=[ToolCallPart(tool_name=tool_name, args=args, tool_call_id=tool_call_id)]
    )


def _tool_return(tool_name: str, tool_call_id: str, content: str = "ok") -> ModelRequest:
    return ModelRequest(
        parts=[ToolReturnPart(tool_name=tool_name, tool_call_id=tool_call_id, content=content)]
    )


def _starts_with_user_prompt(history: list) -> bool:
    if not history:
        return True
    first = history[0]
    return isinstance(first, ModelRequest) and any(
        isinstance(p, UserPromptPart) for p in first.parts
    )


class TestTrimHistory:
    def test_short_history_returned_unchanged(self):
        h = [_user("hi"), _assistant_text("hello")]
        assert _trim_history(h, keep_last=4) is h

    def test_clean_cut_at_user_turn(self):
        h = [
            _user("first"),
            _assistant_text("ok"),
            _user("second"),
            _assistant_text("done"),
        ]
        out = _trim_history(h, keep_last=2)
        assert out == h[2:]
        assert _starts_with_user_prompt(out)

    def test_naive_cut_lands_on_tool_return_advances_to_user(self):
        # Naive cut would land on a tool_return (orphan). Must skip ahead.
        h = [
            _user("q1"),
            _assistant_tool_call("bash", "t1"),
            _tool_return("bash", "t1"),
            _assistant_text("answer"),
            _user("q2"),
            _assistant_text("answer2"),
        ]
        out = _trim_history(h, keep_last=4)
        assert _starts_with_user_prompt(out)
        assert out[0].parts[0].content == "q2"

    def test_naive_cut_lands_on_assistant_tool_call_advances_to_user(self):
        h = [
            _user("q1"),
            _assistant_tool_call("bash", "t1"),
            _tool_return("bash", "t1"),
            _assistant_text("done"),
            _user("q2"),
            _assistant_text("done2"),
        ]
        # keep_last=5 puts naive start at index 1 (assistant tool_call) -- orphan tool_use.
        out = _trim_history(h, keep_last=5)
        assert _starts_with_user_prompt(out)
        assert out[0].parts[0].content == "q2"

    def test_no_user_turn_after_cut_returns_empty(self):
        # Pathological: after the cut there's only a tool_return + assistant
        # and no user turn. Must drop everything rather than emit orphan.
        h = [
            _user("q1"),
            _assistant_tool_call("bash", "t1"),
            _tool_return("bash", "t1"),
            _assistant_text("answer"),
        ]
        out = _trim_history(h, keep_last=2)
        assert out == []

    def test_multi_tool_chain_trimmed_safely(self):
        # Realistic chain from issue #9: several tool calls in one turn.
        h = [
            _user("do many things"),
            _assistant_tool_call("read_file", "tA"),
            _tool_return("read_file", "tA"),
            _assistant_tool_call("grep", "tB"),
            _tool_return("grep", "tB"),
            _assistant_text("here is the result"),
            _user("now what"),
            _assistant_text("more"),
        ]
        out = _trim_history(h, keep_last=4)
        assert _starts_with_user_prompt(out)
        # Bridge messages should land on the last user turn.
        assert out[0].parts[0].content == "now what"

    def test_keep_last_larger_than_history(self):
        h = [_user("only"), _assistant_text("reply")]
        assert _trim_history(h, keep_last=100) is h

    def test_trim_to_zero_returns_empty(self):
        h = [_user("a"), _assistant_text("b")]
        assert _trim_history(h, keep_last=0) == []
