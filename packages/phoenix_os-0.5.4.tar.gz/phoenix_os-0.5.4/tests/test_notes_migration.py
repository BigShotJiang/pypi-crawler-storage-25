"""Tests for the one-shot notes.db + insights.md -> memory.db migration.

Phase 3 of the notes-unification: legacy data lands in memory.db with the
same gate/strength/decay semantics as ordinary memories. Migration is
sentinel-guarded so a second boot is a no-op.
"""

from __future__ import annotations

import os
import sqlite3
import time
from pathlib import Path

import pytest

from phoenix.memory import MemorySystem
from phoenix.memory.config import MINILM_PRESET, MemoryParams
from phoenix.memory.migrate_notes import SENTINEL_NAME, run_migration


def _seed_notes_db(path: Path, rows: list[dict]) -> None:
    conn = sqlite3.connect(str(path))
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS notes (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                category TEXT DEFAULT 'observation',
                content TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                related_topic TEXT,
                tags TEXT,
                created_at REAL,
                updated_at REAL
            );
            """
        )
        now = time.time()
        for r in rows:
            conn.execute(
                "INSERT INTO notes (id, title, category, content, status, "
                "related_topic, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)",
                (
                    r["id"],
                    r.get("title", ""),
                    r.get("category", "observation"),
                    r.get("content", ""),
                    r.get("status", "active"),
                    r.get("related_topic"),
                    now,
                    now,
                ),
            )
        conn.commit()
    finally:
        conn.close()


@pytest.fixture
def phoenix_dir(tmp_path):
    """Isolated ~/.phoenix pointing at tmp_path."""
    yield tmp_path


@pytest.fixture
def mem(tmp_path):
    """MemorySystem with a unique temp DB per test."""
    params = MemoryParams(**{**MINILM_PRESET, "db_path": str(tmp_path / "memory.db")})
    yield MemorySystem(params)


class TestMigration:
    async def test_fresh_install_writes_sentinel_and_nothing_else(self, phoenix_dir, mem):
        stats = await run_migration(mem, phoenix_dir)
        assert stats["status"] == "ok"
        assert stats["notes"] == 0
        assert stats["insights"] == 0
        # Sentinel present so second run is a no-op.
        db = mem.store._require_db()
        cursor = await db.execute("SELECT 1 FROM _migrations WHERE name = ?", (SENTINEL_NAME,))
        assert await cursor.fetchone() is not None
        await cursor.close()

    async def test_notes_db_rows_migrated_and_file_renamed(self, phoenix_dir, mem):
        notes_path = phoenix_dir / "notes.db"
        _seed_notes_db(
            notes_path,
            [
                {
                    "id": "n1",
                    "title": "Hyperfocus pattern",
                    "content": "holds focus for hours",
                    "category": "observation",
                    "status": "active",
                    "related_topic": "harshal",
                },
                {
                    "id": "n2",
                    "title": "Finance help",
                    "content": "mumbai student budget question",
                    "status": "resolved",
                },
            ],
        )
        stats = await run_migration(mem, phoenix_dir)
        assert stats["status"] == "ok"
        assert stats["notes"] == 2
        # File renamed, not deleted.
        assert not notes_path.exists()
        assert (phoenix_dir / "notes.db.migrated").exists()
        # Rows reachable via memory.store as category="note" / intent="intentional".
        rows = await mem.store.search_text("hyperfocus", namespace="global", limit=5)
        assert any(r["category"] == "note" and r["intent"] == "intentional" for r in rows)

    async def test_resolved_notes_land_with_reduced_strength(self, phoenix_dir, mem):
        _seed_notes_db(
            phoenix_dir / "notes.db",
            [
                {
                    "id": "active1",
                    "title": "active note",
                    "content": "deliberate observation",
                    "status": "active",
                },
                {
                    "id": "resolved1",
                    "title": "resolved note",
                    "content": "older request resolved",
                    "status": "resolved",
                },
            ],
        )
        await run_migration(mem, phoenix_dir)
        active_rows = await mem.store.search_text("deliberate observation", namespace="global")
        resolved_rows = await mem.store.search_text("older request resolved", namespace="global")
        assert active_rows and resolved_rows
        assert float(active_rows[0]["strength"]) > float(resolved_rows[0]["strength"])

    async def test_insights_md_bullets_migrated_and_file_renamed(self, phoenix_dir, mem):
        md = phoenix_dir / "insights.md"
        md.write_text(
            "\n".join(
                [
                    "## 2026-04-14 00:33",
                    "- first real insight about patterns",
                    "- second consolidated observation",
                    "",
                    "## heading without bullets",
                ]
            ),
            encoding="utf-8",
        )
        stats = await run_migration(mem, phoenix_dir)
        assert stats["insights"] == 2
        assert not md.exists()
        assert (phoenix_dir / "insights.md.migrated").exists()
        rows = await mem.store.search_text("consolidated observation", namespace="global")
        assert any(r["category"] == "insight" for r in rows)

    async def test_second_run_is_noop(self, phoenix_dir, mem):
        _seed_notes_db(
            phoenix_dir / "notes.db",
            [{"id": "once", "title": "one", "content": "only once"}],
        )
        first = await run_migration(mem, phoenix_dir)
        assert first["notes"] == 1
        # Second run: no files, sentinel present.
        second = await run_migration(mem, phoenix_dir)
        assert second["status"] == "already_migrated"
        assert second["notes"] == 0

    async def test_corrupt_notes_db_does_not_write_sentinel(self, phoenix_dir, mem):
        # Write nonsense bytes as the "db".
        (phoenix_dir / "notes.db").write_bytes(b"not a sqlite file")
        stats = await run_migration(mem, phoenix_dir)
        assert stats["status"] == "partial"
        assert stats["errors"] >= 1
        # Sentinel NOT written -- next boot can retry.
        db = mem.store._require_db()
        cursor = await db.execute("SELECT 1 FROM _migrations WHERE name = ?", (SENTINEL_NAME,))
        assert await cursor.fetchone() is None
        await cursor.close()

    async def test_rename_failure_does_not_block_sentinel(self, phoenix_dir, mem, monkeypatch):
        """If ingest succeeds but the rename raises (symlink, perms, read-only),
        the sentinel must still be written so we don't re-ingest on next boot.
        The gate would NOOP duplicates anyway, but writing the sentinel gives
        the user a clean "retry impossible" signal + a warning to move the
        source file manually.
        """
        _seed_notes_db(
            phoenix_dir / "notes.db",
            [{"id": "keepable", "title": "a note", "content": "post-rename durability"}],
        )

        real_rename = Path.rename

        def flaky_rename(self, target):
            if str(self).endswith("notes.db"):
                raise OSError("simulated rename failure")
            return real_rename(self, target)

        monkeypatch.setattr(Path, "rename", flaky_rename)
        stats = await run_migration(mem, phoenix_dir)
        assert stats["status"] == "ok"
        assert stats["notes"] == 1
        # notes.db still exists (rename failed), but sentinel was written.
        assert (phoenix_dir / "notes.db").exists()
        db = mem.store._require_db()
        cursor = await db.execute("SELECT 1 FROM _migrations WHERE name = ?", (SENTINEL_NAME,))
        assert await cursor.fetchone() is not None
        await cursor.close()

    async def test_duplicate_notes_collapse_through_gate(self, phoenix_dir, mem):
        """Two notes with identical content should collapse to one row --
        the whole point of routing through the gate instead of a raw INSERT.
        """
        _seed_notes_db(
            phoenix_dir / "notes.db",
            [
                {"id": "dup1", "title": "same", "content": "exactly the same body"},
                {"id": "dup2", "title": "same", "content": "exactly the same body"},
            ],
        )
        await run_migration(mem, phoenix_dir)
        rows = await mem.store.search_text("exactly the same body", namespace="global", limit=10)
        # At most one ADD; the second hits the NOOP branch of the gate.
        added = [r for r in rows if r["category"] == "note"]
        assert len(added) == 1


@pytest.fixture(autouse=True, scope="session")
def _cleanup_default_db():
    # Ensure per-test tmp_path cleanup doesn't collide with any ambient
    # PHOENIX_MEMORY_DB env var set by other test modules.
    yield
    default_db = os.environ.get("PHOENIX_MEMORY_DB")
    if default_db and os.path.exists(default_db):
        import contextlib

        with contextlib.suppress(FileNotFoundError):
            os.unlink(default_db)
