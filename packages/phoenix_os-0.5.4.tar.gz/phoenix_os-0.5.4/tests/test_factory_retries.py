"""Tests for factory.py's tool-retry configuration.

Covers issue #10: weak local models (`ollama:gpt-oss:20b`) emit
malformed tool calls; pydantic-ai's default `retries=1` exhausts on
the same mistake and a bare `pydantic_core.ValidationError` crashes the
turn. Phoenix bumps the default to 3 and honours `PHOENIX_TOOL_RETRIES`.
"""

from __future__ import annotations

from phoenix.core import factory


class TestToolRetries:
    def test_default_is_three(self, monkeypatch):
        monkeypatch.delenv("PHOENIX_TOOL_RETRIES", raising=False)
        assert factory._get_tool_retries() == 3

    def test_env_override_respected(self, monkeypatch):
        monkeypatch.setenv("PHOENIX_TOOL_RETRIES", "5")
        assert factory._get_tool_retries() == 5

    def test_zero_allowed(self, monkeypatch):
        # Some users may want zero retries to fail fast.
        monkeypatch.setenv("PHOENIX_TOOL_RETRIES", "0")
        assert factory._get_tool_retries() == 0

    def test_negative_clamps_to_zero(self, monkeypatch):
        monkeypatch.setenv("PHOENIX_TOOL_RETRIES", "-3")
        assert factory._get_tool_retries() == 0

    def test_garbage_falls_back_to_default(self, monkeypatch):
        monkeypatch.setenv("PHOENIX_TOOL_RETRIES", "not-a-number")
        assert factory._get_tool_retries() == 3

    def test_built_agent_carries_retries_kwarg(self, monkeypatch):
        """The Agent built by the factory should reflect _get_tool_retries.
        We don't construct a real model here -- we just verify the
        codepath that wires retries into the Agent constructor exists.
        """
        from inspect import signature

        from pydantic_ai import Agent

        # Sanity: pydantic-ai Agent accepts a `retries` kwarg in this version.
        params = signature(Agent.__init__).parameters
        assert "retries" in params
