"""Tests for ambient NudgeEngine -- circuit breaker on auth failure."""

from unittest.mock import AsyncMock, patch

import pytest

from phoenix.ambient.nudge import NudgeEngine, _looks_like_auth_failure
from phoenix.ambient.sentinel import Signal


def _signal() -> Signal:
    return Signal(signal_type="test", priority=1.0, payload={"k": "v"})


class TestAuthFailureDetection:
    def test_gemini_api_key_invalid(self):
        assert _looks_like_auth_failure(
            RuntimeError(
                "status_code: 400, body: {'error': {'message': 'API key not valid.', "
                "'status': 'INVALID_ARGUMENT', 'reason': 'API_KEY_INVALID'}}"
            )
        )

    def test_openai_incorrect_api_key(self):
        assert _looks_like_auth_failure(RuntimeError("Error 401: Incorrect API key provided"))

    def test_anthropic_authentication_error(self):
        assert _looks_like_auth_failure(RuntimeError("authentication_error: invalid x-api-key"))

    def test_unrelated_error_not_auth(self):
        assert not _looks_like_auth_failure(RuntimeError("connection timeout after 30s"))
        assert not _looks_like_auth_failure(RuntimeError("rate limit exceeded, retry after 60s"))


class TestCircuitBreaker:
    async def test_auth_failure_disables_engine_permanently(self):
        """First auth failure must flip the breaker; subsequent decide()
        calls short-circuit without another LLM attempt."""
        engine = NudgeEngine("gemini-nonexistent")
        auth_err = RuntimeError("API_KEY_INVALID: API key not valid")

        with patch("pydantic_ai.Agent") as mock_agent_cls:
            mock_agent = mock_agent_cls.return_value
            mock_agent.run = AsyncMock(side_effect=auth_err)

            result1 = await engine.decide([_signal()])
            assert result1 is None
            assert engine._auth_disabled is True
            assert mock_agent.run.await_count == 1

            # Second call must not even construct an Agent -- breaker tripped.
            result2 = await engine.decide([_signal()])
            assert result2 is None
            # agent.run was NOT called again
            assert mock_agent.run.await_count == 1

    async def test_non_auth_failure_keeps_engine_live(self):
        """Transient errors (network, rate limit) must NOT trip the breaker,
        so nudge recovers on the next tick."""
        engine = NudgeEngine("gemini-flash")

        with patch("pydantic_ai.Agent") as mock_agent_cls:
            mock_agent = mock_agent_cls.return_value
            mock_agent.run = AsyncMock(side_effect=RuntimeError("connection reset"))

            result = await engine.decide([_signal()])
            assert result is None
            assert engine._auth_disabled is False

    async def test_empty_signals_short_circuit(self):
        engine = NudgeEngine("gemini-flash")
        assert await engine.decide([]) is None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
