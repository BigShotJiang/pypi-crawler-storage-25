"""Tests for `verify_ollama_model` -- catches bad model tags before they
reach pydantic-ai and leak an internal streaming task (issue #18)."""

from __future__ import annotations

import json
from unittest.mock import patch

from phoenix.config.setup_verify import verify_ollama_model


def _tags_body(names: list[str]) -> str:
    return json.dumps({"models": [{"name": n} for n in names]})


class TestVerifyOllamaModel:
    def test_exact_tag_match_ok(self):
        with patch(
            "phoenix.config.setup_verify._get",
            return_value=(200, _tags_body(["llama3:latest", "gemma2:27b"])),
        ):
            r = verify_ollama_model("gemma2:27b")
        assert r.ok
        assert r.message == "ok"

    def test_auto_expand_latest_when_tag_omitted(self):
        """`gemma2` should match `gemma2:latest` -- Ollama does this same
        expansion internally, so Phoenix must too."""
        with patch(
            "phoenix.config.setup_verify._get",
            return_value=(200, _tags_body(["llama3:latest", "gemma2:latest"])),
        ):
            r = verify_ollama_model("gemma2")
        assert r.ok

    def test_typo_tag_rejected_with_helpful_message(self):
        """Regression for #18: `ollama:gemma4:26b` (typo for `gemma2:27b`)
        must fail loudly at launch, not leak a pending task mid-stream."""
        with patch(
            "phoenix.config.setup_verify._get",
            return_value=(200, _tags_body(["gemma2:27b", "llama3:latest"])),
        ):
            r = verify_ollama_model("gemma4:26b")
        assert not r.ok
        assert "gemma4:26b" in r.message
        assert "gemma2:27b" in r.message  # hints at the real tag
        assert "ollama pull" in r.message

    def test_empty_installed_list_rejected(self):
        with patch(
            "phoenix.config.setup_verify._get",
            return_value=(200, _tags_body([])),
        ):
            r = verify_ollama_model("llama3")
        assert not r.ok
        assert "none installed" in r.message

    def test_daemon_unreachable_skips_check(self):
        """When /api/tags is dead, defer to the reachability verifier and
        pass this check -- avoids duplicate error messaging."""
        with patch("phoenix.config.setup_verify._get", return_value=(0, "connect failed")):
            r = verify_ollama_model("llama3")
        assert r.ok  # skipped, not failed

    def test_malformed_tags_response_skips_check(self):
        """Defensive: if /api/tags returns non-JSON (e.g. an HTML error page
        from a misconfigured reverse proxy), skip rather than crash."""
        with patch("phoenix.config.setup_verify._get", return_value=(200, "<html>oops</html>")):
            r = verify_ollama_model("llama3")
        assert r.ok  # skipped
