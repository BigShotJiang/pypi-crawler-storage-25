"""Unit tests for the v0.6/v0.7 DCBP providers.

- `EnvironmentProvider`     project AGENTS.md + global env doc          (v0.6)
- `WebRetrievalProvider`    pre-fetched web context render              (v0.6)
- `ConflictSurfaceProvider` tension signal from recall pairs            (v0.6)
- `InsightsProvider`        consolidation insights from insights.md     (v0.7)

Engine-level integration (pre-fetch wiring, contradiction extraction) is
covered indirectly by `test_context_pipeline.py` once those tests grow.
"""

from pathlib import Path

from phoenix.context.intent import intent_from_input
from phoenix.context.providers import (
    AmbientInsightProvider,
    ConflictSurfaceProvider,
    EnvironmentProvider,
    InsightsProvider,
    TurnState,
    WebRetrievalProvider,
)


class TestEnvironmentProvider:
    def _state(self) -> TurnState:
        return TurnState(user_input="x", intent=intent_from_input("x"))

    def test_skips_when_both_files_missing(self, tmp_path: Path):
        p = EnvironmentProvider(cwd=tmp_path, global_path=tmp_path / "no_global.md")
        assert p.should_inject(self._state()) is False
        assert p.render(self._state(), 1000) == ""

    def test_loads_project_agents_md(self, tmp_path: Path):
        (tmp_path / "AGENTS.md").write_text("Vercel serverless. IPv4 outbound only.")
        p = EnvironmentProvider(cwd=tmp_path, global_path=tmp_path / "missing.md")
        assert p.should_inject(self._state()) is True
        out = p.render(self._state(), 1000)
        assert "[Runtime constraints (AGENTS.md)]" in out
        assert "Vercel serverless" in out
        assert "[Personal context]" not in out

    def test_loads_global_env_md(self, tmp_path: Path):
        global_md = tmp_path / "env.md"
        global_md.write_text("Boss: solo dev. Prefers local-first tools.")
        p = EnvironmentProvider(cwd=tmp_path, global_path=global_md)
        assert p.should_inject(self._state()) is True
        out = p.render(self._state(), 1000)
        assert "[Personal context]" in out
        assert "solo dev" in out
        assert "[Runtime constraints" not in out

    def test_both_files_render_project_first(self, tmp_path: Path):
        (tmp_path / "AGENTS.md").write_text("Project rules here.")
        global_md = tmp_path / "env.md"
        global_md.write_text("Personal rules here.")
        p = EnvironmentProvider(cwd=tmp_path, global_path=global_md)
        out = p.render(self._state(), 5000)
        proj_idx = out.find("[Runtime constraints")
        pers_idx = out.find("[Personal context]")
        assert proj_idx >= 0 and pers_idx >= 0
        assert proj_idx < pers_idx

    def test_priority_is_3_protected(self):
        # Priority <= 3 = protected floor in the arbiter.
        assert EnvironmentProvider().priority == 3

    def test_truncates_to_per_provider_max(self, tmp_path: Path):
        (tmp_path / "AGENTS.md").write_text("x" * 10_000)
        p = EnvironmentProvider(
            cwd=tmp_path,
            global_path=tmp_path / "missing.md",
            max_chars=500,
        )
        out = p.render(self._state(), 100_000)  # arbiter generous
        assert len(out) <= 500

    def test_truncates_to_arbiter_budget_when_smaller(self, tmp_path: Path):
        (tmp_path / "AGENTS.md").write_text("x" * 10_000)
        p = EnvironmentProvider(
            cwd=tmp_path,
            global_path=tmp_path / "missing.md",
            max_chars=5000,
        )
        out = p.render(self._state(), 100)  # arbiter tight
        assert len(out) <= 100

    def test_unreadable_project_file_does_not_raise(self, tmp_path: Path):
        # Path that exists but as a directory, not file -- exercises the
        # is_file() guard.
        (tmp_path / "AGENTS.md").mkdir()
        p = EnvironmentProvider(cwd=tmp_path, global_path=tmp_path / "missing.md")
        assert p.should_inject(self._state()) is False


class TestWebRetrievalProvider:
    def _state(self, web_context: str = "") -> TurnState:
        return TurnState(
            user_input="x",
            intent=intent_from_input("x"),
            web_context=web_context,
        )

    def test_skips_when_web_context_empty(self):
        p = WebRetrievalProvider()
        assert p.should_inject(self._state(web_context="")) is False

    def test_injects_when_web_context_present(self):
        p = WebRetrievalProvider()
        state = self._state(web_context="[Web search: x]\n-- title\n  url")
        assert p.should_inject(state) is True
        out = p.render(state, 5000)
        assert "[Web context (auto-fetched" in out
        assert "[Web search: x]" in out

    def test_priority_is_4(self):
        # Below MemoryRecall(2) but above TopicSummary(7); not protected.
        assert WebRetrievalProvider().priority == 4

    def test_truncates_to_per_provider_max(self):
        p = WebRetrievalProvider(max_chars=200)
        state = self._state(web_context="x" * 5000)
        out = p.render(state, 100_000)
        assert len(out) <= 200

    def test_truncates_to_arbiter_budget_when_smaller(self):
        p = WebRetrievalProvider(max_chars=5000)
        state = self._state(web_context="x" * 5000)
        out = p.render(state, 50)
        assert len(out) <= 50


class TestConflictSurfaceProvider:
    def _state(
        self,
        score: float = 0.0,
        pairs: list | None = None,
    ) -> TurnState:
        return TurnState(
            user_input="x",
            intent=intent_from_input("x"),
            contradiction_score=score,
            contradiction_pairs=pairs or [],
        )

    def test_skips_below_threshold(self):
        p = ConflictSurfaceProvider()
        # Default threshold is 0.4
        assert p.should_inject(self._state(score=0.0)) is False
        assert p.should_inject(self._state(score=0.3)) is False
        assert p.should_inject(self._state(score=0.4)) is False  # strict >

    def test_fires_above_threshold(self):
        p = ConflictSurfaceProvider()
        assert p.should_inject(self._state(score=0.41)) is True
        assert p.should_inject(self._state(score=1.0)) is True

    def test_priority_is_3_protected(self):
        # Protected floor: contradictions must not be silently displaced.
        assert ConflictSurfaceProvider().priority == 3

    def test_render_includes_score_and_pair_count(self):
        p = ConflictSurfaceProvider()
        state = self._state(score=0.7, pairs=[("a", "b"), ("c", "d")])
        out = p.render(state, 1000)
        assert "[Tension signal]" in out
        assert "0.70" in out
        assert "2 pairs" in out

    def test_render_handles_singular_pair(self):
        p = ConflictSurfaceProvider()
        state = self._state(score=0.5, pairs=[("a", "b")])
        out = p.render(state, 1000)
        assert "1 pair)" in out  # singular, no trailing 's'
        assert "1 pairs" not in out

    def test_custom_threshold(self):
        p = ConflictSurfaceProvider(threshold=0.7)
        assert p.should_inject(self._state(score=0.5)) is False
        assert p.should_inject(self._state(score=0.71)) is True

    def test_render_truncates_to_budget(self):
        p = ConflictSurfaceProvider()
        out = p.render(self._state(score=0.9, pairs=[("a", "b")]), budget=20)
        assert len(out) <= 20


class TestInsightsProvider:
    """Post notes-unification: InsightsProvider reads `state.insights`
    (pre-fetched by the engine from memory.db category="insight") instead
    of `~/.phoenix/insights.md`. The engine -> pipeline -> state path is
    covered separately; these tests verify only the provider surface.
    """

    def _state(self, insights: list[str] | None = None) -> TurnState:
        return TurnState(
            user_input="x",
            intent=intent_from_input("x"),
            insights=insights or [],
        )

    def test_skips_when_insights_empty(self):
        p = InsightsProvider()
        assert p.should_inject(self._state()) is False

    def test_injects_when_insights_populated(self):
        p = InsightsProvider()
        assert p.should_inject(self._state(["pattern A", "pattern B"])) is True

    def test_renders_as_bulleted_block(self):
        p = InsightsProvider()
        out = p.render(self._state(["pattern A", "pattern B", "pattern C"]), 5000)
        assert "[Patterns Phoenix has noticed]" in out
        assert "- pattern A" in out
        assert "- pattern B" in out
        assert "- pattern C" in out

    def test_keeps_only_last_n(self):
        p = InsightsProvider(last_n=3)
        bullets = [f"pattern {i}" for i in range(10)]
        out = p.render(self._state(bullets), 5000)
        # Last 3 = patterns 7, 8, 9
        assert "pattern 7" in out
        assert "pattern 8" in out
        assert "pattern 9" in out
        assert "pattern 6" not in out

    def test_priority_is_5(self):
        # Between MemoryRecall(2) and TopicSummary(7).
        assert InsightsProvider().priority == 5

    def test_truncates_to_per_provider_max(self):
        p = InsightsProvider(max_chars=200, last_n=20)
        out = p.render(self._state(["x" * 200 for _ in range(20)]), 100_000)
        assert len(out) <= 200

    def test_truncates_to_arbiter_budget_when_smaller(self):
        p = InsightsProvider()
        out = p.render(self._state(["something"]), 30)
        assert len(out) <= 30


class TestAmbientInsightProvider:
    def _state(
        self,
        ambient_summary: str = "",
        stakes: bool = False,
    ) -> TurnState:
        intent = intent_from_input("x")
        intent.stakes = stakes
        return TurnState(user_input="x", intent=intent, ambient_summary=ambient_summary)

    def test_skips_when_summary_empty(self):
        p = AmbientInsightProvider()
        assert p.should_inject(self._state(ambient_summary="")) is False

    def test_skips_on_high_stakes(self):
        p = AmbientInsightProvider()
        # Even with a summary, ambient should NOT fire on high-stakes turns.
        state = self._state(ambient_summary="2 signals pending", stakes=True)
        assert p.should_inject(state) is False

    def test_fires_on_low_stakes_with_summary(self):
        p = AmbientInsightProvider()
        state = self._state(ambient_summary="2 signals pending", stakes=False)
        assert p.should_inject(state) is True
        out = p.render(state, 1000)
        assert "[Ambient signal]" in out
        assert "2 signals pending" in out

    def test_priority_is_6(self):
        # Above TopicSummary(7), below MemoryRecall(2) and Insights(5).
        assert AmbientInsightProvider().priority == 6

    def test_truncates_to_per_provider_max(self):
        p = AmbientInsightProvider(max_chars=100)
        state = self._state(ambient_summary="x" * 5000)
        out = p.render(state, 100_000)
        assert len(out) <= 100

    def test_truncates_to_arbiter_budget_when_smaller(self):
        p = AmbientInsightProvider()
        state = self._state(ambient_summary="x" * 5000)
        out = p.render(state, 30)
        assert len(out) <= 30
