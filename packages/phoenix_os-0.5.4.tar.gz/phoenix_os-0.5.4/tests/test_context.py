"""Intent + provider unit tests for the DCBP.

Arbiter + `DCBP.run` integration tests live in `test_context_pipeline.py`.
End-to-end parity against the old `_build_engineered_context` lives in
`test_context_parity.py`.
"""

from phoenix.context.intent import TurnIntent, intent_from_input
from phoenix.context.providers import (
    MemoryRecallProvider,
    ReasoningModeProvider,
    SessionSummaryProvider,
    TopicSummaryProvider,
    TurnState,
    default_providers,
)
from phoenix.core.reasoning import QueryType


class TestIntentFromInput:
    def test_social_greeting(self):
        ti = intent_from_input("hello")
        assert ti.query_type == QueryType.CHAT
        assert ti.depth == 0
        assert ti.stakes is False
        assert ti.temporal_ref is None
        assert ti.is_technical is False
        assert ti.has_memory_signal is False

    def test_factual_simple_depth_is_1(self):
        ti = intent_from_input("what is the capital of France")
        assert ti.query_type == QueryType.FACTUAL_SIMPLE
        assert ti.depth == 1

    def test_opinion_depth_is_2(self):
        ti = intent_from_input("what do you think of Rust")
        assert ti.query_type == QueryType.OPINION
        assert ti.depth == 2

    def test_recommendation_depth_is_2(self):
        ti = intent_from_input("should i use FastAPI or Django")
        assert ti.query_type == QueryType.RECOMMENDATION
        assert ti.depth == 2

    def test_complex_reasoning_depth_is_3(self):
        ti = intent_from_input("compare Python and Go for backends")
        assert ti.query_type == QueryType.COMPLEX_REASONING
        assert ti.depth == 3

    def test_code_block_bumps_depth_to_3(self):
        ti = intent_from_input("what does this do:\n```\nprint(1)\n```")
        assert ti.depth == 3

    def test_long_elaboration_bumps_depth_to_3(self):
        long_text = " ".join(["hello"] * 60)
        ti = intent_from_input(long_text)
        assert ti.depth == 3

    def test_temporal_ref_yesterday(self):
        ti = intent_from_input("what did I say yesterday")
        assert ti.temporal_ref == "yesterday"

    def test_temporal_ref_last_week(self):
        ti = intent_from_input("the bug we fixed last week")
        assert ti.temporal_ref == "last week"

    def test_temporal_ref_none_for_plain_input(self):
        ti = intent_from_input("build a function")
        assert ti.temporal_ref is None

    def test_memory_signal_you_mentioned(self):
        ti = intent_from_input("you mentioned my preference for dark mode")
        assert ti.has_memory_signal is True

    def test_memory_signal_my_project_is(self):
        ti = intent_from_input("my project is called Phoenix-OS")
        assert ti.has_memory_signal is True

    def test_memory_signal_i_am_working_on(self):
        ti = intent_from_input("i am working on the memory pipeline")
        assert ti.has_memory_signal is True

    def test_no_memory_signal_on_social(self):
        ti = intent_from_input("i'm fine thanks")
        assert ti.has_memory_signal is False

    def test_technical_marker_api(self):
        ti = intent_from_input("the api endpoint is returning 500")
        assert ti.is_technical is True

    def test_technical_marker_code_block(self):
        ti = intent_from_input("```\ndef foo(): pass\n```")
        assert ti.is_technical is True

    def test_technical_false_on_chat(self):
        ti = intent_from_input("how are you")
        assert ti.is_technical is False

    def test_stakes_from_keyword(self):
        ti = intent_from_input("should i accept the job offer")
        assert ti.stakes is True

    def test_continuation_and_session_depth_passthrough(self):
        ti = intent_from_input(
            "where were we",
            is_continuation=True,
            session_depth=7,
        )
        assert ti.is_continuation is True
        assert ti.session_depth == 7

    def test_contradiction_score_default_is_zero(self):
        ti = intent_from_input("anything")
        assert ti.contradiction_score == 0.0

    def test_contradiction_score_is_writable(self):
        """Providers write this back after recall; dataclass must allow it."""
        ti = intent_from_input("anything")
        ti.contradiction_score = 0.73
        assert ti.contradiction_score == 0.73

    def test_returns_turnintent_instance(self):
        ti = intent_from_input("test")
        assert isinstance(ti, TurnIntent)

    def test_chat_query_with_memory_signal_still_chat(self):
        """CHAT classification wins over memory-signal heuristics for depth."""
        # "hey" alone is CHAT per reasoning.py. memory signal is independent.
        ti = intent_from_input("hey")
        assert ti.query_type == QueryType.CHAT
        assert ti.depth == 0


def _make_state(
    user_input: str = "hi",
    memory_context: str = "",
    session_summary: str = "",
    topic_context: str = "",
    intent: TurnIntent | None = None,
) -> TurnState:
    return TurnState(
        user_input=user_input,
        intent=intent or intent_from_input(user_input),
        memory_context=memory_context,
        session_summary=session_summary,
        topic_context=topic_context,
    )


class TestSessionSummaryProvider:
    def test_skips_when_empty(self):
        p = SessionSummaryProvider()
        assert p.should_inject(_make_state(session_summary="")) is False

    def test_injects_when_present(self):
        p = SessionSummaryProvider()
        state = _make_state(session_summary="prior work")
        assert p.should_inject(state) is True
        assert p.render(state, 1000) == "[Previous session]\nprior work"

    def test_priority_is_1(self):
        assert SessionSummaryProvider().priority == 1

    def test_truncates_to_budget(self):
        p = SessionSummaryProvider()
        state = _make_state(session_summary="x" * 500)
        out = p.render(state, budget=50)
        assert len(out) <= 50 + len("[Previous session]\n")


class TestMemoryRecallProvider:
    def test_skips_when_empty(self):
        p = MemoryRecallProvider()
        assert p.should_inject(_make_state(memory_context="")) is False

    def test_injects_when_present(self):
        p = MemoryRecallProvider()
        state = _make_state(memory_context="[Memory Context]\nBoss likes X")
        assert p.should_inject(state) is True
        assert p.render(state, 1000) == "[Memory Context]\nBoss likes X"

    def test_priority_is_2(self):
        assert MemoryRecallProvider().priority == 2


class TestTopicSummaryProvider:
    def test_skips_when_empty_topic_context(self):
        p = TopicSummaryProvider()
        assert p.should_inject(_make_state(topic_context="")) is False

    def test_injects_when_present(self):
        p = TopicSummaryProvider()
        state = _make_state(topic_context="T1: done")
        assert p.should_inject(state) is True
        assert p.render(state, 1000) == "[Session context]\nT1: done"

    def test_priority_is_7(self):
        assert TopicSummaryProvider().priority == 7


class TestReasoningModeProvider:
    def test_skips_for_chat(self):
        p = ReasoningModeProvider()
        state = _make_state(user_input="hello")
        assert p.should_inject(state) is False

    def test_skips_for_factual_simple(self):
        p = ReasoningModeProvider()
        state = _make_state(user_input="what is Python")
        assert p.should_inject(state) is False

    def test_fires_for_complex(self):
        p = ReasoningModeProvider()
        state = _make_state(user_input="compare X and Y")
        assert p.should_inject(state) is True
        assert p.render(state, 1000).startswith("[Reasoning mode:")

    def test_fires_for_recommendation(self):
        p = ReasoningModeProvider()
        state = _make_state(user_input="should i use A or B")
        assert p.should_inject(state) is True

    def test_priority_is_8(self):
        assert ReasoningModeProvider().priority == 8


class TestDefaultProviders:
    def test_returns_four_providers_priority_ordered(self):
        providers = default_providers()
        assert len(providers) == 4
        priorities = [p.priority for p in providers]
        assert priorities == sorted(priorities)

    def test_contains_expected_provider_types(self):
        providers = default_providers()
        types = {type(p).__name__ for p in providers}
        assert types == {
            "SessionSummaryProvider",
            "MemoryRecallProvider",
            "TopicSummaryProvider",
            "ReasoningModeProvider",
        }
