"""Tests for `PhoenixContext` -- specifically the v0.6 `turn_cache` field.

`turn_cache` is the seam between pre-turn pipelines (WebRetrievalProvider)
and abilities (`web_search`) so duplicate fetches in the same turn don't
happen. The engine resets it at the top of `run_stream`; the contract is
'per-turn lifetime, not session'.
"""

from phoenix.abilities import PhoenixContext


class TestTurnCache:
    def test_default_is_empty_dict(self):
        ctx = PhoenixContext()
        assert ctx.turn_cache == {}

    def test_independent_per_instance(self):
        a = PhoenixContext()
        b = PhoenixContext()
        a.turn_cache["web"] = {"q": "result"}
        assert b.turn_cache == {}

    def test_writes_persist_within_instance(self):
        ctx = PhoenixContext()
        ctx.turn_cache.setdefault("web", {})["latest supabase"] = "[Web context]..."
        ctx.turn_cache["env"] = "loaded"
        assert ctx.turn_cache["web"]["latest supabase"] == "[Web context]..."
        assert ctx.turn_cache["env"] == "loaded"

    def test_clear_empties_the_cache(self):
        ctx = PhoenixContext()
        ctx.turn_cache["x"] = 1
        ctx.turn_cache["y"] = 2
        ctx.turn_cache.clear()
        assert ctx.turn_cache == {}

    def test_dataclass_default_factory_does_not_share_dict(self):
        """Regression guard: a mutable default without `field(default_factory=...)`
        would alias one dict across all PhoenixContext instances. Make sure
        that's not the case.
        """
        a = PhoenixContext()
        b = PhoenixContext()
        assert a.turn_cache is not b.turn_cache
