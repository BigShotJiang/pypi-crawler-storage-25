"""Tests for `web_search` per-turn cache dedupe.

Boss's WebRetrievalProvider may pre-fetch a query before the model decides
to call the `web_search` tool. The dedupe contract: same (query, params)
within a turn returns cached, no second API call.
"""

import os

# web_search uses @ability(requires_env=["BRAVE_API_KEY"]) -- without the
# env var set BEFORE import, the decorator skips registration AND the
# function still exists as a plain coroutine. Both branches work for these
# tests; we exercise the function directly via its module attribute.
os.environ.setdefault("BRAVE_API_KEY", "test-stub-not-used")


import phoenix.abilities.web_search as ws_mod  # noqa: E402
from phoenix.abilities import PhoenixContext  # noqa: E402


class TestWebSearchCache:
    async def test_cache_miss_calls_underlying_fetch(self, monkeypatch):
        calls = []

        def fake_llm_context(*a, **kw):
            calls.append(("llm", a))
            return "[Web context: test result]"

        monkeypatch.setattr(ws_mod, "_search_llm_context", fake_llm_context)

        ctx = PhoenixContext()
        out = await ws_mod.web_search(ctx, "what changed in pydantic-ai 1.80")
        assert out == "[Web context: test result]"
        assert len(calls) == 1

    async def test_cache_hit_skips_underlying_fetch(self, monkeypatch):
        calls = []

        def fake_llm_context(*a, **kw):
            calls.append(("llm", a))
            return "[Web context: fresh]"

        monkeypatch.setattr(ws_mod, "_search_llm_context", fake_llm_context)

        ctx = PhoenixContext()
        await ws_mod.web_search(ctx, "latest supabase changelog")
        await ws_mod.web_search(ctx, "latest supabase changelog")
        # Second identical call should hit cache, not invoke fetch again.
        assert len(calls) == 1

    async def test_different_query_does_not_collide(self, monkeypatch):
        calls = []

        def fake_llm_context(*a, **kw):
            calls.append(a[0])  # the query
            return f"[Web context for: {a[0]}]"

        monkeypatch.setattr(ws_mod, "_search_llm_context", fake_llm_context)

        ctx = PhoenixContext()
        a = await ws_mod.web_search(ctx, "query A")
        b = await ws_mod.web_search(ctx, "query B")
        assert a != b
        assert len(calls) == 2
        assert calls == ["query A", "query B"]

    async def test_different_params_does_not_collide(self, monkeypatch):
        """Cache key includes (query, max_results, freshness, context_mode)
        so a tool re-call with different freshness re-fetches."""
        calls = []

        def fake_llm_context(*a, **kw):
            # a = (query, api_key, max_results, max_tokens, freshness, context_mode)
            calls.append((a[0], a[4]))
            return "stub"

        monkeypatch.setattr(ws_mod, "_search_llm_context", fake_llm_context)

        ctx = PhoenixContext()
        await ws_mod.web_search(ctx, "Q", freshness="pd")
        await ws_mod.web_search(ctx, "Q", freshness="pw")
        assert len(calls) == 2

    async def test_cache_isolation_across_contexts(self, monkeypatch):
        calls = []

        def fake_llm_context(*a, **kw):
            calls.append("hit")
            return "result"

        monkeypatch.setattr(ws_mod, "_search_llm_context", fake_llm_context)

        ctx_a = PhoenixContext()
        ctx_b = PhoenixContext()
        await ws_mod.web_search(ctx_a, "Q")
        await ws_mod.web_search(ctx_b, "Q")
        # Different ctx -> independent cache -> two fetches.
        assert len(calls) == 2

    async def test_cache_clear_invalidates(self, monkeypatch):
        """Engine clears `ctx.turn_cache` between turns. After clear, the
        next call must hit the wire again.
        """
        calls = []

        def fake_llm_context(*a, **kw):
            calls.append("hit")
            return "result"

        monkeypatch.setattr(ws_mod, "_search_llm_context", fake_llm_context)

        ctx = PhoenixContext()
        await ws_mod.web_search(ctx, "Q")
        ctx.turn_cache.clear()  # simulate end-of-turn reset
        await ws_mod.web_search(ctx, "Q")
        assert len(calls) == 2
