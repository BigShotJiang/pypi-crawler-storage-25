"""Parity tests for `_build_engineered_context`.

Captures exact output of the current implementation so the v0.4 refactor
(`_build_engineered_context` -> `DCBP.run`) can be verified against a
golden baseline. Remove this file once DCBP has shipped and the old path
is gone.
"""

from phoenix.core.engine import PhoenixEngine


class _FakeTopicTracker:
    """Minimal stand-in returning a fixed context string."""

    def __init__(self, context: str = ""):
        self._context = context

    def build_context(self) -> str:
        return self._context


def _make_engine(session_summary: str = "", topic_context: str = "") -> PhoenixEngine:
    """Construct a `PhoenixEngine` bypassing `boot()` for pure-function testing.

    `_build_engineered_context` only reads `_session_summary` and
    `_topic_tracker` off self; no registry / agent / memory needed.
    """
    eng = PhoenixEngine()
    eng._session_summary = session_summary
    eng._topic_tracker = _FakeTopicTracker(topic_context) if topic_context else None
    return eng


class TestBuildEngineeredContextParity:
    def test_social_query_no_memory_no_topic(self):
        eng = _make_engine()
        out = eng._build_engineered_context("hello", memory_context="")
        assert out == "hello"

    def test_social_query_with_memory(self):
        eng = _make_engine()
        out = eng._build_engineered_context(
            "hello",
            memory_context="[Memory Context -- 1 entries]\nBoss prefers dark mode",
        )
        assert out == "[Memory Context -- 1 entries]\nBoss prefers dark mode\n\nhello"

    def test_complex_query_triggers_reasoning_instruction(self):
        eng = _make_engine()
        out = eng._build_engineered_context(
            "explain why Python is better than Go",
            memory_context="",
        )
        assert "[Reasoning mode:" in out
        assert out.endswith("explain why Python is better than Go")
        assert out.find("[Reasoning mode:") < out.find("explain why Python")

    def test_all_layers_present(self):
        eng = _make_engine(
            session_summary="Last session: we discussed memory architecture.",
            topic_context="Topic 1: memory pipeline (resolved)",
        )
        out = eng._build_engineered_context(
            "compare mem0 vs Phoenix memory",
            memory_context="[Memory Context -- 1 entries]\nBoss is building Phoenix-OS",
        )
        parts = out.split("\n\n")
        assert parts[0].startswith("[Previous session]")
        assert parts[1].startswith("[Memory Context")
        assert parts[2].startswith("[Session context]")
        assert parts[3].startswith("[Reasoning mode:")
        assert parts[4] == "compare mem0 vs Phoenix memory"

    def test_recommendation_query_triggers_reasoning(self):
        eng = _make_engine()
        out = eng._build_engineered_context(
            "should i use FastAPI or Django",
            memory_context="",
        )
        assert "[Reasoning mode:" in out

    def test_factual_simple_no_reasoning_instruction(self):
        eng = _make_engine()
        out = eng._build_engineered_context(
            "what is the capital of France",
            memory_context="",
        )
        assert "[Reasoning mode:" not in out
        assert out == "what is the capital of France"

    def test_session_summary_only(self):
        eng = _make_engine(session_summary="Yesterday: we set up the DCBP plan.")
        out = eng._build_engineered_context("let's continue", memory_context="")
        assert out == ("[Previous session]\nYesterday: we set up the DCBP plan.\n\nlet's continue")

    def test_topic_context_wrapped_in_header(self):
        eng = _make_engine(topic_context="Topic summaries go here")
        out = eng._build_engineered_context("next", memory_context="")
        assert "[Session context]\nTopic summaries go here" in out

    def test_empty_layers_produce_no_dangling_blanks(self):
        eng = _make_engine()
        out = eng._build_engineered_context("test", memory_context="")
        assert not out.startswith("\n")
        assert "\n\n\n" not in out

    def test_layers_joined_with_double_newline(self):
        eng = _make_engine(session_summary="A", topic_context="B")
        out = eng._build_engineered_context("explain why", memory_context="C")
        assert "[Previous session]\nA\n\nC\n\n[Session context]\nB" in out

    def test_topic_tracker_returns_empty_is_skipped(self):
        eng = _make_engine(topic_context="")
        # topic_tracker is None when topic_context is "" per _make_engine
        # verify the None branch also skips cleanly
        out = eng._build_engineered_context("hi", memory_context="")
        assert "[Session context]" not in out

    def test_topic_tracker_present_but_empty_build_context(self):
        eng = PhoenixEngine()
        eng._session_summary = ""
        eng._topic_tracker = _FakeTopicTracker(context="")
        out = eng._build_engineered_context("hi", memory_context="")
        # tracker exists but build_context() returns "" -> layer is skipped
        assert "[Session context]" not in out
        assert out == "hi"
