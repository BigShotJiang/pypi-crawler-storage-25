"""Tests for phoenix.core.delegate.

Focus: the timeout path. A runaway sub-agent must not stall the brain
indefinitely (see issue #9 follow-up).

v0.5.3 rewired delegate to stream events instead of awaiting .run(), so
the fake agent yields a sequence of stream events matching pydantic-ai
1.80's AgentStreamEvent / AgentRunResultEvent shape. Text parts get
accumulated into the final output, mirroring what .run() would return.
"""

import asyncio
from dataclasses import dataclass

import pytest

from phoenix.core import delegate as delegate_mod
from phoenix.core import delegate_events


@dataclass
class _FakeTextPart:
    content: str


@dataclass
class _FakeTextPartStart:
    part: _FakeTextPart


@dataclass
class _FakeUsage:
    input_tokens: int = 100
    output_tokens: int = 20


class _FakeAgentRunResult:
    def __init__(self):
        self._usage = _FakeUsage()

    def usage(self):
        return self._usage


class _FakeAgent:
    """Minimal stand-in for pydantic-ai Agent. Only run_stream_events is used."""

    def __init__(
        self, *, delay: float = 0.0, output: str = "done", raise_exc: Exception | None = None
    ):
        self._delay = delay
        self._output = output
        self._raise = raise_exc

    async def run_stream_events(self, task: str):
        # Lazy import so the fixture isn't imported before pydantic-ai is
        # available in the test environment.
        from pydantic_ai import AgentRunResultEvent
        from pydantic_ai.messages import PartStartEvent, TextPart

        if self._delay:
            await asyncio.sleep(self._delay)
        if self._raise:
            raise self._raise
        # One PartStartEvent carrying the whole text -- matches the
        # Anthropic "opening tokens in part-start" case delegate handles.
        yield PartStartEvent(index=0, part=TextPart(content=self._output))
        yield AgentRunResultEvent(result=_FakeAgentRunResult())


class _FakeStreamingAgent:
    """Agent that yields text across multiple delta events + a tool call
    in the middle, to pin the accumulation contract that a simple
    single-event fake can't catch.
    """

    def __init__(self, *, parts: list[str], tool_name: str = "") -> None:
        self._parts = parts
        self._tool_name = tool_name

    async def run_stream_events(self, task: str):
        from pydantic_ai import AgentRunResultEvent
        from pydantic_ai.messages import (
            PartDeltaEvent,
            PartStartEvent,
            TextPart,
            TextPartDelta,
        )

        if not self._parts:
            yield AgentRunResultEvent(result=_FakeAgentRunResult())
            return

        yield PartStartEvent(index=0, part=TextPart(content=self._parts[0]))
        for delta in self._parts[1:]:
            yield PartDeltaEvent(index=0, delta=TextPartDelta(content_delta=delta))
        yield AgentRunResultEvent(result=_FakeAgentRunResult())


class _FakeStructuredAgent:
    """Agent that emits no TextPart at all -- only returns a final result
    with `.output`. Mirrors the pydantic-ai "structured output" shape.
    Delegate must fall back to `result.output` here; otherwise the
    rewrite from `run()` -> `run_stream_events()` silently drops output.
    """

    def __init__(self, *, output=None) -> None:
        self._output = output if output is not None else ""

    async def run_stream_events(self, task: str):
        from pydantic_ai import AgentRunResultEvent

        class _Result:
            def __init__(self, out):
                self.output = out

            def usage(self):
                return _FakeUsage()

        yield AgentRunResultEvent(result=_Result(self._output))


class _FakeRegistry:
    def __init__(self, agents: list[str]):
        self._agents = agents

    def list_agents(self) -> list[str]:
        return self._agents


@pytest.fixture
def patch_registry_and_agent(monkeypatch):
    def _apply(agents: list[str], fake_agent: _FakeAgent):
        monkeypatch.setattr(delegate_mod, "get_registry", lambda: _FakeRegistry(agents))
        monkeypatch.setattr(delegate_mod, "build_agent", lambda **kwargs: fake_agent)

    return _apply


class TestDelegate:
    async def test_success_returns_output(self, patch_registry_and_agent):
        patch_registry_and_agent(["worker", "brain"], _FakeAgent(output="hello"))
        out = await delegate_mod.delegate(ctx=None, task="do the thing", agent="worker")
        assert out == "hello"

    async def test_unknown_agent_returns_error(self, patch_registry_and_agent):
        patch_registry_and_agent(["worker"], _FakeAgent())
        out = await delegate_mod.delegate(ctx=None, task="x", agent="nope")
        assert "Unknown agent" in out
        assert "worker" in out

    async def test_brain_cannot_delegate_to_self(self, patch_registry_and_agent):
        patch_registry_and_agent(["brain", "worker"], _FakeAgent())
        out = await delegate_mod.delegate(ctx=None, task="x", agent="brain")
        assert "Cannot delegate to self" in out

    async def test_exception_becomes_error_string(self, patch_registry_and_agent):
        patch_registry_and_agent(["worker"], _FakeAgent(raise_exc=RuntimeError("boom")))
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert "failed" in out
        assert "boom" in out

    async def test_timeout_returns_actionable_message(self, patch_registry_and_agent, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "0.05")
        patch_registry_and_agent(["worker"], _FakeAgent(delay=5.0))
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert "timed out" in out
        assert "PHOENIX_DELEGATE_TIMEOUT" in out

    async def test_timeout_env_override_respected(self, patch_registry_and_agent, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "10")
        patch_registry_and_agent(["worker"], _FakeAgent(delay=0.01, output="ok"))
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert out == "ok"

    def test_invalid_timeout_env_falls_back_to_default(self, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "not-a-number")
        assert delegate_mod._get_timeout() == delegate_mod.DEFAULT_DELEGATE_TIMEOUT_SEC

    def test_zero_or_negative_timeout_falls_back_to_default(self, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "0")
        assert delegate_mod._get_timeout() == delegate_mod.DEFAULT_DELEGATE_TIMEOUT_SEC
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "-5")
        assert delegate_mod._get_timeout() == delegate_mod.DEFAULT_DELEGATE_TIMEOUT_SEC

    def test_default_timeout_is_300s(self, monkeypatch):
        monkeypatch.delenv("PHOENIX_DELEGATE_TIMEOUT", raising=False)
        assert delegate_mod._get_timeout() == 300.0


class TestDelegateEmitsEvents:
    """Delegate must publish started + done events to the event bus so the
    Ctrl+O panel can track activity. Covers the happy path + the error
    path; tool-call event coverage lives in the integration test below
    since fabricating FunctionToolCallEvent in a fake is version-coupled.
    """

    @pytest.fixture(autouse=True)
    def _clear_bus(self):
        delegate_events.clear()
        yield
        delegate_events.clear()

    async def test_started_and_done_events_published(self, patch_registry_and_agent):
        received: list[delegate_events.DelegateEvent] = []
        delegate_events.subscribe(received.append)
        patch_registry_and_agent(["worker"], _FakeAgent(output="ok"))
        out = await delegate_mod.delegate(ctx=None, task="refactor login", agent="worker")
        assert out == "ok"

        types = [e.type for e in received]
        assert types[0] == "started"
        assert types[-1] == "done"
        assert received[0].task_preview.startswith("refactor login")
        assert received[0].agent == "worker"
        assert received[-1].duration >= 0.0

    async def test_error_event_on_failure(self, patch_registry_and_agent):
        received: list[delegate_events.DelegateEvent] = []
        delegate_events.subscribe(received.append)
        patch_registry_and_agent(["worker"], _FakeAgent(raise_exc=RuntimeError("boom")))
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert "failed" in out
        assert any(e.type == "error" for e in received)
        err = next(e for e in received if e.type == "error")
        assert "boom" in err.error_message

    async def test_timeout_event_on_timeout(self, patch_registry_and_agent, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "0.05")
        received: list[delegate_events.DelegateEvent] = []
        delegate_events.subscribe(received.append)
        patch_registry_and_agent(["worker"], _FakeAgent(delay=5.0))
        await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert any(e.type == "error" and "timed out" in e.error_message for e in received)


class TestArgsPreview:
    """One-line arg repr for the live panel. Trimmed hard, tolerant of
    junk input. The panel's legibility under a chatty agent depends on
    this staying short."""

    def test_string_truncated(self):
        long = "x" * 300
        out = delegate_mod._args_preview(long)
        assert len(out) <= delegate_mod._ARGS_PREVIEW_MAX
        assert out.endswith("\u2026")

    def test_dict_serialized(self):
        out = delegate_mod._args_preview({"file": "a.py", "line": 42})
        assert "file" in out and "a.py" in out

    def test_none_returns_empty(self):
        assert delegate_mod._args_preview(None) == ""

    def test_non_serializable_falls_back_to_str(self):
        class Weird:
            def __repr__(self):
                return "Weird()"

        out = delegate_mod._args_preview(Weird())
        assert "Weird" in out or out  # never raises, always returns a string


class TestStreamAccumulation:
    """Output must rebuild correctly from the stream. The simple happy-path
    fake only emits one PartStartEvent; these tests pin the multi-delta
    and structured-output branches that the rewrite from `.run()` to
    `.run_stream_events()` could silently regress.
    """

    async def test_multi_delta_accumulation(self, monkeypatch):
        monkeypatch.setattr(delegate_mod, "get_registry", lambda: _FakeRegistry(["worker"]))
        monkeypatch.setattr(
            delegate_mod,
            "build_agent",
            lambda **kwargs: _FakeStreamingAgent(parts=["foo", "bar", "baz"]),
        )
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert out == "foobarbaz"

    async def test_empty_chunks_fallback_to_result_output(self, monkeypatch):
        # Agent emits zero text events. Delegate must fall back to
        # AgentRunResultEvent.result.output or the string would be "".
        monkeypatch.setattr(delegate_mod, "get_registry", lambda: _FakeRegistry(["worker"]))
        monkeypatch.setattr(
            delegate_mod,
            "build_agent",
            lambda **kwargs: _FakeStructuredAgent(output="final-report-string"),
        )
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert out == "final-report-string"

    async def test_pydantic_model_fallback_uses_model_dump_json(self, monkeypatch):
        # Pydantic BaseModel's `str()` gives "Model(field='x')" which is
        # readable but not parseable. Fallback must prefer
        # model_dump_json so structured outputs round-trip cleanly.
        from pydantic import BaseModel

        class Report(BaseModel):
            title: str
            body: str

        monkeypatch.setattr(delegate_mod, "get_registry", lambda: _FakeRegistry(["worker"]))
        monkeypatch.setattr(
            delegate_mod,
            "build_agent",
            lambda **kwargs: _FakeStructuredAgent(output=Report(title="t", body="b")),
        )
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        # model_dump_json output is deterministic for simple models.
        assert out == '{"title":"t","body":"b"}'
