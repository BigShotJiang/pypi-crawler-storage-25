"""Tests for `phoenix.core.prefetch` -- pre-DCBP signal helpers."""

from types import SimpleNamespace

from phoenix.abilities import PhoenixContext
from phoenix.core.prefetch import (
    build_ambient_summary,
    extract_contradiction_signal,
    maybe_fetch_web,
)


class TestExtractContradictionSignal:
    def test_none_memory_returns_zero(self):
        score, pairs = extract_contradiction_signal(None)
        assert score == 0.0
        assert pairs == []

    def test_no_recall_engine_returns_zero(self):
        memory = SimpleNamespace(_recall=None)
        score, pairs = extract_contradiction_signal(memory)
        assert score == 0.0
        assert pairs == []

    def test_empty_recall_returns_zero(self):
        memory = SimpleNamespace(_recall=SimpleNamespace(_last_recalled=[]))
        score, pairs = extract_contradiction_signal(memory)
        assert score == 0.0
        assert pairs == []

    def test_no_tensions_returns_zero(self):
        recall = SimpleNamespace(_last_recalled=[{"id": "a"}, {"id": "b"}])
        memory = SimpleNamespace(_recall=recall)
        score, pairs = extract_contradiction_signal(memory)
        assert score == 0.0
        assert pairs == []

    def test_score_is_fraction_of_tensioned(self):
        recall = SimpleNamespace(
            _last_recalled=[
                {"id": "a", "tension_with": ["b"]},
                {"id": "b", "tension_with": ["a"]},
                {"id": "c"},
                {"id": "d"},
            ]
        )
        memory = SimpleNamespace(_recall=recall)
        score, pairs = extract_contradiction_signal(memory)
        assert score == 0.5  # 2 out of 4 tensioned
        assert pairs == [("a", "b")]

    def test_pairs_dedup_across_directions(self):
        """`tension_with` is symmetric -- a points to b, b points to a.
        The pair list should not contain both ('a','b') and ('b','a').
        """
        recall = SimpleNamespace(
            _last_recalled=[
                {"id": "a", "tension_with": ["b", "c"]},
                {"id": "b", "tension_with": ["a"]},
                {"id": "c", "tension_with": ["a"]},
            ]
        )
        memory = SimpleNamespace(_recall=recall)
        _, pairs = extract_contradiction_signal(memory)
        assert ("a", "b") in pairs
        assert ("a", "c") in pairs
        assert len(pairs) == 2

    def test_pairs_sorted_canonically(self):
        """Pair tuples are sorted so dedup is order-independent."""
        recall = SimpleNamespace(
            _last_recalled=[
                {"id": "z", "tension_with": ["a"]},
                {"id": "a", "tension_with": ["z"]},
            ]
        )
        memory = SimpleNamespace(_recall=recall)
        _, pairs = extract_contradiction_signal(memory)
        assert pairs == [("a", "z")]


class TestMaybeFetchWeb:
    async def test_none_ctx_returns_empty(self):
        result = await maybe_fetch_web(None, "what changed yesterday")
        assert result == ""

    async def test_no_temporal_ref_skips_fetch(self, monkeypatch):
        # Should not even try to call _get_api_key when intent has no temporal_ref.
        called = []

        def fake_get_api_key():
            called.append(True)
            return "key"

        import phoenix.abilities.web_search as ws_mod

        monkeypatch.setattr(ws_mod, "_get_api_key", fake_get_api_key)
        ctx = PhoenixContext()
        result = await maybe_fetch_web(ctx, "what is python")  # no temporal ref
        assert result == ""
        # Either intent gating short-circuits (called empty) or the fetch
        # returns empty string -- both satisfy the contract.

    async def test_no_api_key_returns_empty(self, monkeypatch):
        import phoenix.abilities.web_search as ws_mod

        monkeypatch.setattr(ws_mod, "_get_api_key", lambda: "")
        ctx = PhoenixContext()
        result = await maybe_fetch_web(ctx, "latest changes yesterday")
        assert result == ""

    async def test_temporal_ref_with_key_invokes_fetch(self, monkeypatch):
        import phoenix.abilities.web_search as ws_mod

        monkeypatch.setattr(ws_mod, "_get_api_key", lambda: "test-key")
        monkeypatch.setattr(
            ws_mod,
            "_search_llm_context",
            lambda *a, **kw: "[Web search: x]\nresult",
        )
        ctx = PhoenixContext()
        result = await maybe_fetch_web(ctx, "what changed yesterday")
        assert "[Web search: x]" in result

    async def test_fetch_failure_returns_empty(self, monkeypatch):
        import phoenix.abilities.web_search as ws_mod

        monkeypatch.setattr(ws_mod, "_get_api_key", lambda: "test-key")

        async def fake_web_search(*a, **kw):
            raise RuntimeError("network down")

        # `maybe_fetch_web` does a runtime `from phoenix.abilities.web_search
        # import _get_api_key, web_search` -- patching the module attribute
        # is what the deferred import resolves against.
        monkeypatch.setattr(ws_mod, "web_search", fake_web_search)
        ctx = PhoenixContext()
        result = await maybe_fetch_web(ctx, "what changed yesterday")
        assert result == ""


class _FakeAwareness:
    def __init__(self, patterns):
        self._patterns = patterns

    async def get_patterns(self):
        return self._patterns


def _fake_daemon(
    *,
    enabled: bool = True,
    pending: int = 0,
    responsibilities: int = 0,
    patterns=None,
):
    awareness = _FakeAwareness(patterns) if patterns is not None else None
    return SimpleNamespace(
        is_enabled=enabled,
        status=lambda: {
            "pending_signals": pending,
            "responsibilities": responsibilities,
        },
        awareness=awareness,
    )


class TestBuildAmbientSummary:
    async def test_none_daemon_returns_empty(self):
        assert (await build_ambient_summary(None)) == ""

    async def test_disabled_daemon_returns_empty(self):
        d = _fake_daemon(enabled=False, pending=5, responsibilities=2)
        assert (await build_ambient_summary(d)) == ""

    async def test_no_signals_no_responsibilities_returns_empty(self):
        d = _fake_daemon(pending=0, responsibilities=0)
        assert (await build_ambient_summary(d)) == ""

    async def test_pending_signals_alone_render(self):
        d = _fake_daemon(pending=3, responsibilities=0)
        out = await build_ambient_summary(d)
        assert "3 ambient signal(s) pending" in out
        assert "responsibility" not in out

    async def test_responsibilities_alone_render(self):
        d = _fake_daemon(pending=0, responsibilities=2)
        out = await build_ambient_summary(d)
        assert "2 responsibility" in out

    async def test_combined_with_string_patterns(self):
        d = _fake_daemon(pending=1, responsibilities=1, patterns="Boss heads-down 90 min.")
        out = await build_ambient_summary(d)
        assert "1 ambient signal" in out
        assert "1 responsibility" in out
        assert "Boss heads-down" in out

    async def test_list_patterns_joined(self):
        d = _fake_daemon(pending=1, patterns=["pattern A", "pattern B", "pattern C"])
        out = await build_ambient_summary(d)
        assert "pattern A" in out
        assert "pattern B" in out

    async def test_status_failure_returns_empty(self):
        d = SimpleNamespace(
            is_enabled=True,
            status=lambda: (_ for _ in ()).throw(RuntimeError("boom")),
        )
        # status() raises; helper swallows.
        assert (await build_ambient_summary(d)) == ""

    async def test_sync_get_patterns_handled(self):
        """`AwarenessEngine.get_patterns` may be sync. Helper must not
        TypeError on `await <list>`. Guard via `inspect.iscoroutine`.
        """

        class _SyncAwareness:
            def get_patterns(self):  # NOT async
                return ["sync pattern"]

        d = SimpleNamespace(
            is_enabled=True,
            status=lambda: {"pending_signals": 1, "responsibilities": 0},
            awareness=_SyncAwareness(),
        )
        out = await build_ambient_summary(d)
        assert "sync pattern" in out
