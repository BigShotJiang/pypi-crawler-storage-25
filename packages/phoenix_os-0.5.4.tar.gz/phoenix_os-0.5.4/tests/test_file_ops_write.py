"""Tests for `write_file` size limits (issue #13 -- coder choking on large writes)."""

from __future__ import annotations

import os
import tempfile

import pytest

from phoenix.abilities.file_ops import MAX_WRITE_BYTES, write_file


@pytest.fixture
def auto_approve():
    from phoenix.core.interceptor import (
        AutoApprovalBackend,
        get_approval_backend,
        set_approval_backend,
    )

    prev = get_approval_backend()
    set_approval_backend(AutoApprovalBackend(mode="yolo"))
    yield
    set_approval_backend(prev)


class TestWriteFileLimits:
    async def test_moderate_size_write_accepted(self, auto_approve):
        """Files up to a few hundred KB are legitimate generated output
        (schemas, test fixtures, large modules) and must not be rejected."""
        path = tempfile.mktemp(suffix=".txt")
        content = "x" * 200_000  # 200 KB
        try:
            result = await write_file(path, content)
            assert "Error" not in result
            assert os.path.exists(path)
            assert os.path.getsize(path) == 200_000
        finally:
            if os.path.exists(path):
                os.unlink(path)

    async def test_oversize_write_rejected_with_actionable_message(self, auto_approve):
        """A write past the cap must fail cleanly with a message that
        suggests search_replace or multi-write split -- not leave the coder
        agent guessing."""
        path = tempfile.mktemp(suffix=".txt")
        content = "x" * (MAX_WRITE_BYTES + 1)
        result = await write_file(path, content)
        assert "Error" in result
        assert "exceeds" in result
        assert "search_replace" in result  # hint for existing files
        assert "split" in result  # hint for new files
        assert not os.path.exists(path)  # nothing written

    def test_cap_raised_above_old_64kb(self):
        """Regression guard: #13 was caused by a 64KB cap that rejected
        normal generated writes. Keep the cap well above that."""
        assert MAX_WRITE_BYTES >= 500_000
