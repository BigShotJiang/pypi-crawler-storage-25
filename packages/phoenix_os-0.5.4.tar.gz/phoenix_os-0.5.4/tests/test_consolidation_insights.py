"""Tests for consolidation -> insight memories.

Post notes-unification (Phase 4): consolidation no longer appends to
`~/.phoenix/insights.md`. It writes `[consolidated]` rows directly to
memory.db with `category="insight"`, and the engine pre-fetches them
into `state.insights` for `InsightsProvider` to render.

These tests pin the contract: consolidation produces category=insight
rows, `_append_to_insights_file` is gone, and `build_insights_snapshot`
surfaces the results cleanly.
"""

import os
import tempfile

_TEMP_DB = tempfile.mktemp(suffix=".db")
os.environ["PHOENIX_MEMORY_DB"] = _TEMP_DB


import pytest  # noqa: E402

from phoenix.core.prefetch import build_insights_snapshot  # noqa: E402
from phoenix.memory import MemorySystem  # noqa: E402
from phoenix.memory.config import MINILM_PRESET, MemoryParams  # noqa: E402
from phoenix.memory.consolidation import ConsolidationEngine  # noqa: E402

_PARAMS = MemoryParams(**MINILM_PRESET)


class TestFileSinkRemoved:
    def test_append_helper_no_longer_exists(self):
        """The notes-unification removed `_append_to_insights_file`.
        If it comes back, the single-substrate invariant is broken."""
        assert not hasattr(ConsolidationEngine, "_append_to_insights_file")


class TestInsightsSnapshot:
    async def test_snapshot_empty_when_no_insights(self):
        mem = MemorySystem(_PARAMS)
        bullets = await build_insights_snapshot(mem)
        assert bullets == []
        await mem.close()

    async def test_snapshot_returns_consolidated_rows(self):
        mem = MemorySystem(_PARAMS)
        await mem._ensure_initialized()
        content = "[consolidated] Boss prefers direct concise answers"
        await mem.store.add(
            content=content,
            category="insight",
            namespace="global",
            embedding=mem.embedder.embed_document(content),
            strength=2.0,
        )
        bullets = await build_insights_snapshot(mem)
        assert len(bullets) == 1
        # Snapshot strips the prefix so the prompt reads cleanly.
        assert bullets[0] == "Boss prefers direct concise answers"
        await mem.close()

    async def test_snapshot_skips_non_insight_categories(self):
        mem = MemorySystem(_PARAMS)
        await mem._ensure_initialized()
        ns = "global"
        await mem.store.add(
            content="a plain fact",
            category="fact",
            namespace=ns,
            embedding=mem.embedder.embed_document("a plain fact"),
        )
        await mem.store.add(
            content="[consolidated] actual insight",
            category="insight",
            namespace=ns,
            embedding=mem.embedder.embed_document("[consolidated] actual insight"),
            strength=2.0,
        )
        bullets = await build_insights_snapshot(mem)
        assert all("fact" not in b for b in bullets)
        assert any("insight" in b for b in bullets)
        await mem.close()

    async def test_snapshot_caps_at_last_n(self):
        mem = MemorySystem(_PARAMS)
        await mem._ensure_initialized()
        for i in range(10):
            body = f"[consolidated] insight number {i}"
            await mem.store.add(
                content=body,
                category="insight",
                namespace="global",
                embedding=mem.embedder.embed_document(body),
                strength=2.0 + i * 0.01,
            )
        bullets = await build_insights_snapshot(mem, last_n=3)
        assert len(bullets) == 3
        await mem.close()


@pytest.fixture(autouse=True, scope="session")
def _cleanup():
    yield
    import contextlib

    with contextlib.suppress(FileNotFoundError):
        os.unlink(_TEMP_DB)
