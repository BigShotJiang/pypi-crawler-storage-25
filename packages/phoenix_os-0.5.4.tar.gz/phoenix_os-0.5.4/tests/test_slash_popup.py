"""Tests for the slash-command picker (phoenix.tui.slash_popup).

Pure-logic coverage: catalog build, filter prefix matching, selection
index wrap. The widget-mounted behaviour (CSS `display: none`, on_mount
catalog load) is harder to exercise outside a live Textual app -- we
cover the arithmetic here and rely on manual TUI testing for the
visual rendering.
"""

from __future__ import annotations

from phoenix.tui.slash_popup import (
    CommandEntry,
    _extract_description,
    build_command_catalog,
    filter_catalog,
)


class TestBuildCatalog:
    def test_catalog_non_empty_and_sorted(self):
        cat = build_command_catalog()
        assert len(cat) >= 10
        names = [e.name for e in cat]
        assert names == sorted(names), "catalog must be sorted alphabetically"

    def test_all_entries_start_with_slash(self):
        for e in build_command_catalog():
            assert e.name.startswith("/"), f"{e.name!r} missing leading slash"

    def test_common_commands_present(self):
        names = {e.name for e in build_command_catalog()}
        for expected in ("/help", "/model", "/memory", "/bg", "/bye"):
            assert expected in names, f"{expected} missing from picker catalog"

    def test_descriptions_extracted_from_docstrings(self):
        cat = build_command_catalog()
        model_entry = next(e for e in cat if e.name == "/model")
        # Description should be non-empty and not just boilerplate.
        assert len(model_entry.description) > 0
        assert model_entry.description != "/model"

    def test_bye_is_surfaced_even_though_not_in_commands_dict(self):
        """`/bye` is handled as a special case in handle_command -- it's
        not a key in COMMANDS. The picker still lists it so users can
        discover it alongside everything else."""
        names = {e.name for e in build_command_catalog()}
        assert "/bye" in names


class TestExtractDescription:
    def test_first_nonblank_line_wins(self):
        def f():
            """
            First real line.
            Second line is irrelevant.
            """

        assert _extract_description(f) == "First real line."

    def test_backticks_stripped(self):
        def f():
            """`/memory` -- stats."""

        out = _extract_description(f)
        assert "`" not in out
        assert "memory" in out

    def test_missing_docstring_returns_empty(self):
        def f():
            pass

        assert _extract_description(f) == ""

    def test_truncates_at_96_chars(self):
        long = "x " * 100

        def f():
            """placeholder"""

        f.__doc__ = long
        out = _extract_description(f)
        assert len(out) <= 96


class TestFilterCatalog:
    def _cat(self) -> list[CommandEntry]:
        return [
            CommandEntry("/help", "d"),
            CommandEntry("/memory", "d"),
            CommandEntry("/model", "d"),
            CommandEntry("/mode", "d"),
            CommandEntry("/bg", "d"),
        ]

    def test_empty_prefix_returns_all(self):
        out = filter_catalog(self._cat(), "")
        assert len(out) == 5

    def test_slash_only_returns_all(self):
        out = filter_catalog(self._cat(), "/")
        assert len(out) == 5

    def test_prefix_filters_by_name_start(self):
        # `/me` matches only `/memory` -- `/mode` starts with `/mo`.
        out = filter_catalog(self._cat(), "/me")
        assert [e.name for e in out] == ["/memory"]

    def test_prefix_matches_multiple(self):
        out = filter_catalog(self._cat(), "/mo")
        assert {e.name for e in out} == {"/model", "/mode"}

    def test_prefix_is_case_insensitive(self):
        out = filter_catalog(self._cat(), "/MODEL")
        assert [e.name for e in out] == ["/model"]

    def test_exact_match_returns_single(self):
        out = filter_catalog(self._cat(), "/help")
        assert [e.name for e in out] == ["/help"]

    def test_nonmatching_prefix_returns_empty(self):
        out = filter_catalog(self._cat(), "/xyz")
        assert out == []


class TestPopupNavigation:
    """Navigation clamps at the list ends (no wrap) and the viewport
    scrolls to keep the selection visible. These tests exercise the
    widget's selection/viewport state directly without mounting it."""

    def _fresh_popup(self):
        from phoenix.tui.slash_popup import SlashCommandPopup

        p = SlashCommandPopup()
        # Seed state manually (compose + on_mount run inside a Textual
        # app). We only exercise index/viewport math here, so replace
        # _refresh with a no-op to skip the child Static.update calls
        # that require an app context.
        p.entries = [CommandEntry(f"/c{i}", f"desc {i}") for i in range(8)]
        p._catalog = list(p.entries)
        p._refresh = lambda: None  # type: ignore[assignment]
        return p

    def test_down_advances_within_bounds(self):
        p = self._fresh_popup()
        p.down()
        assert p._index == 1

    def test_down_wraps_from_last_to_first(self):
        """Claude-Code-style circular navigation."""
        p = self._fresh_popup()
        p._index = 7  # last
        p.down()
        assert p._index == 0
        assert p._view_start == 0, "viewport should reset on wrap to first"

    def test_up_wraps_from_first_to_last(self):
        p = self._fresh_popup()
        p._index = 0
        p.up()
        assert p._index == 7
        from phoenix.tui.slash_popup import VIEWPORT_ROWS

        assert p._view_start == 8 - VIEWPORT_ROWS, (
            "viewport should reset to show the last entries on wrap up"
        )

    def test_prescroll_down_when_selection_reaches_second_last_row(self):
        """At position VIEWPORT_ROWS - 2 within the window, the next
        row should already be visible (viewport starts to slide)."""
        from phoenix.tui.slash_popup import SCROLL_MARGIN, VIEWPORT_ROWS

        p = self._fresh_popup()
        # Move down to the pre-scroll trigger position.
        target = VIEWPORT_ROWS - SCROLL_MARGIN - 1  # 2nd-last visible row
        for _ in range(target):
            p.down()
        # Still inside the initial window.
        assert p._view_start == 0

        # One more down -> should pre-scroll.
        p.down()
        assert p._view_start > 0, (
            "viewport must pre-scroll before selection reaches the last visible row"
        )

    def test_prescroll_up_when_selection_reaches_second_row(self):
        from phoenix.tui.slash_popup import SCROLL_MARGIN, VIEWPORT_ROWS

        p = self._fresh_popup()
        # Seed selection at the end, window at the bottom.
        p._index = 7
        p._view_start = 8 - VIEWPORT_ROWS
        # Walk up; when selection reaches the 2nd-row of the window,
        # viewport should slide up one position.
        for _ in range(VIEWPORT_ROWS - SCROLL_MARGIN):
            p.up()
        assert p._view_start < 8 - VIEWPORT_ROWS, (
            "viewport must pre-scroll up before selection reaches the top visible row"
        )

    def test_viewport_stays_put_when_selection_in_middle(self):
        p = self._fresh_popup()
        # One step down shouldn't shift the viewport.
        p.down()
        assert p._view_start == 0
