"""Tests for `/model list`'s Ollama live-probe (issue #11).

The probe hits `http://localhost:11434/api/tags` with a short timeout
and returns the installed model names. If Ollama isn't running (most
users), the probe silently returns [] so `/model list` stays snappy.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from phoenix.shell.commands import _probe_ollama_models


class TestProbeOllama:
    def test_returns_empty_when_unreachable(self, monkeypatch):
        # Point at a port nothing is listening on. httpx will raise quickly.
        monkeypatch.setenv("OLLAMA_BASE_URL", "http://127.0.0.1:9/v1")
        assert _probe_ollama_models(timeout=0.1) == []

    def test_parses_live_response(self):
        """Successful 200 + models list -> sorted, deduped names."""
        payload = {
            "models": [
                {"name": "qwen2.5-coder:latest", "size": 12345},
                {"name": "llama3.2:latest"},
                {"name": "qwen2.5-coder:latest"},  # duplicate
                {"no_name_key": "skipped"},
            ]
        }
        fake_resp = MagicMock(status_code=200)
        fake_resp.json.return_value = payload
        with patch("httpx.get", return_value=fake_resp):
            out = _probe_ollama_models(timeout=0.5)
        assert out == ["llama3.2:latest", "qwen2.5-coder:latest"]

    def test_non_200_returns_empty(self):
        fake_resp = MagicMock(status_code=500)
        fake_resp.json.return_value = {"error": "oops"}
        with patch("httpx.get", return_value=fake_resp):
            assert _probe_ollama_models(timeout=0.5) == []

    def test_exception_swallowed(self):
        with patch("httpx.get", side_effect=ConnectionError("refused")):
            assert _probe_ollama_models(timeout=0.5) == []

    def test_strips_v1_suffix_from_base_url(self, monkeypatch):
        """OLLAMA_BASE_URL usually ends in /v1 (OpenAI-compat path); the
        /api/tags probe lives on the root."""
        monkeypatch.setenv("OLLAMA_BASE_URL", "http://example.com:11434/v1")
        captured_url = {}

        def fake_get(url, *a, **kw):
            captured_url["url"] = url
            resp = MagicMock(status_code=200)
            resp.json.return_value = {"models": []}
            return resp

        with patch("httpx.get", side_effect=fake_get):
            _probe_ollama_models(timeout=0.5)

        assert captured_url["url"] == "http://example.com:11434/api/tags"
