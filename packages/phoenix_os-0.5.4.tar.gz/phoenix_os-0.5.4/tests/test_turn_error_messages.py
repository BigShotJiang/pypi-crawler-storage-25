"""Tests for the TUI's exception-rewriting branches in `_turn_worker_fn`.

Real exception paths fire from inside a Textual worker, which is hard
to set up. These tests exercise the pure-string detection logic
directly: given a real-world traceback string, the rewriter should
recognise the failure shape and emit actionable guidance instead of
the raw exception text.

Covers:
- Tool-call validation errors from weak local models (#10)
- 429 rate-limit / quota errors (#6, #7, #8)
- Google edge-400 HTML errors (#2 -- existing branch)
"""

from __future__ import annotations


def _rewrite_detail(detail: str, exc_name: str = "Exception") -> str:
    """Standalone copy of the rewrite logic from `app.py:_turn_worker_fn`.

    Kept in sync manually -- if either side changes, tests should catch
    the divergence. We don't import the worker because that requires
    the full Textual app in scope.
    """
    if exc_name in (
        "ValidationError",
        "UnexpectedModelBehavior",
        "IncompleteToolCall",
    ) and ("Field required" in detail and ("input_value={}" in detail or "type=missing" in detail)):
        return "TOOL_VALIDATION_HINT"
    # Expired/invalid key runs FIRST so a 401 with rate-limit-flavored
    # body doesn't fall into the quota branch below.
    if (
        "API key expired" in detail
        or "API_KEY_INVALID" in detail
        or "API_KEY_EXPIRED" in detail
        or "invalid api key" in detail.lower()
        or "status_code: 401" in detail
        or "invalid_api_key" in detail.lower()
    ):
        return "EXPIRED_KEY_HINT"
    # 429 requires an explicit status-code marker -- the old loose
    # `"rate limit" in detail.lower()` match false-positived on bare
    # prose and auth-throttle responses.
    if (
        "RESOURCE_EXHAUSTED" in detail
        or "status_code: 429" in detail
        or "exceeded your current quota" in detail
    ):
        if "gemini" in detail.lower() or "google" in detail.lower():
            return "QUOTA_HINT_GEMINI"
        if "anthropic" in detail.lower() or "claude" in detail.lower():
            return "QUOTA_HINT_ANTHROPIC"
        if "openai" in detail.lower() or "gpt" in detail.lower():
            return "QUOTA_HINT_OPENAI"
        return "QUOTA_HINT_GENERIC"
    if (
        "503 UNAVAILABLE" in detail
        or "status_code: 503" in detail
        or "currently experiencing high demand" in detail
    ):
        return "OVERLOAD_HINT"
    if "reached your specified API usage limits" in detail or "regain access on" in detail:
        return "SPENDING_CAP_HINT"
    if "Error 400 (Bad Request)!!1" in detail or "<title>Error 400" in detail:
        return "EDGE_400_HINT"
    return "GENERIC"


class TestToolValidationDetection:
    def test_pydantic_validation_error_caught(self):
        detail = (
            "1 validation error for bash\ncommand\n  Field required "
            "[type=missing, input_value={}, input_type=dict]"
        )
        assert _rewrite_detail(detail, "ValidationError") == "TOOL_VALIDATION_HINT"

    def test_unexpected_model_behavior_caught(self):
        # Needs both `Field required` AND a missing-value marker.
        detail = "1 validation error for bash command Field required [type=missing, input_value={}]"
        assert _rewrite_detail(detail, "UnexpectedModelBehavior") == "TOOL_VALIDATION_HINT"

    def test_unrelated_validation_error_passes_through(self):
        # Pydantic validation error not related to a tool call -- should
        # NOT trigger the tool-validation rewrite. (Falls to default.)
        detail = "1 validation error for SomeModel\nfield\n  String too long"
        assert _rewrite_detail(detail, "ValidationError") == "GENERIC"


class TestRateLimitDetection:
    def test_gemini_429_resource_exhausted(self):
        # Real shape from issues #6, #7, #8.
        detail = (
            "status_code: 429, model_name: gemini-2.0-flash, body: "
            "{'error': {'code': 429, 'message': 'You exceeded your current quota...'}}"
        )
        assert _rewrite_detail(detail, "ModelHTTPError") == "QUOTA_HINT_GEMINI"

    def test_anthropic_429(self):
        detail = (
            "status_code: 429, model_name: claude-haiku-4-5-20251001, body: "
            "{'error': {'type': 'rate_limit_error'}}"
        )
        assert _rewrite_detail(detail, "ModelHTTPError") == "QUOTA_HINT_ANTHROPIC"

    def test_openai_429(self):
        detail = "status_code: 429, model_name: gpt-4o, body: rate limit"
        assert _rewrite_detail(detail, "ModelHTTPError") == "QUOTA_HINT_OPENAI"

    def test_loose_rate_limit_phrase_no_longer_false_positives(self):
        # Pre-fix, `"rate limit" in detail.lower()` caught bare prose and
        # mis-routed to the quota branch. Now the detector requires an
        # explicit 429 marker.
        detail = "Rate limit exceeded by upstream"
        assert _rewrite_detail(detail, "Exception") == "GENERIC"

    def test_generic_429_with_explicit_status(self):
        detail = "status_code: 429 from an unknown provider"
        assert _rewrite_detail(detail, "Exception") == "QUOTA_HINT_GENERIC"

    def test_normal_400_does_not_trigger_quota(self):
        # 400 is not 429.
        detail = "status_code: 400, model_name: gemini-2.5-flash"
        assert _rewrite_detail(detail, "ModelHTTPError") == "GENERIC"


class TestOverloadDetection:
    """Issue #11: 503 UNAVAILABLE from Gemini ("high demand")."""

    def test_gemini_503_high_demand(self):
        detail = (
            "status_code: 503, model_name: gemini-2.5-flash, body: "
            "{'error': {'code': 503, 'message': 'This model is currently "
            "experiencing high demand. Spikes in demand are usually "
            "temporary.', 'status': 'UNAVAILABLE'}}"
        )
        assert _rewrite_detail(detail, "ModelHTTPError") == "OVERLOAD_HINT"

    def test_503_without_high_demand_phrase(self):
        detail = "status_code: 503, model_name: claude-haiku, body: upstream down"
        assert _rewrite_detail(detail, "ModelHTTPError") == "OVERLOAD_HINT"


class TestSpendingCapDetection:
    """Issue #11: Anthropic 400 with 'regain access on YYYY-MM-DD' --
    distinct from auth failures and rate limits."""

    def test_anthropic_spending_cap(self):
        detail = (
            "Error code: 400 - {'type': 'error', 'error': {'type': "
            "'invalid_request_error', 'message': 'You have reached your "
            "specified API usage limits. You will regain access on "
            "2026-05-01 at 00:00 UTC.'}}"
        )
        assert _rewrite_detail(detail, "BadRequestError") == "SPENDING_CAP_HINT"


class TestExpiredKeyDetection:
    """Issue #5: real traceback is `ClientError: 400 INVALID_ARGUMENT.
    API key expired. Please renew the API key.` -- not the edge-400 HTML
    shape, so a dedicated branch is needed."""

    def test_google_api_key_expired(self):
        detail = (
            "400 INVALID_ARGUMENT. {'error': {'code': 400, 'message': "
            "'API key expired. Please renew the API key.', 'status': "
            "'INVALID_ARGUMENT', 'details': [{'reason': 'API_KEY_INVALID'}]}}"
        )
        assert _rewrite_detail(detail, "ClientError") == "EXPIRED_KEY_HINT"

    def test_openai_401_unauthorized(self):
        detail = "status_code: 401, model_name: gpt-4o, body: {'error': {'message': 'Incorrect API key provided: sk-...'}}"
        assert _rewrite_detail(detail, "ModelHTTPError") == "EXPIRED_KEY_HINT"

    def test_anthropic_invalid_api_key(self):
        detail = "Invalid API key. Check https://console.anthropic.com/settings/keys"
        assert _rewrite_detail(detail, "Exception") == "EXPIRED_KEY_HINT"


class TestEdge400Detection:
    def test_google_edge_html_caught(self):
        detail = "<html><title>Error 400 (Bad Request)!!1</title></html>"
        assert _rewrite_detail(detail) == "EDGE_400_HINT"

    def test_edge_400_html_beats_generic(self):
        """Purely HTML-shaped 400s are distinct from expired-key 400s --
        don't mis-route HTML edge errors to the expired-key branch."""
        detail = "<html><title>Error 400 (Bad Request)!!1</title></html>"
        assert _rewrite_detail(detail) == "EDGE_400_HINT"


class TestPriorityOrder:
    """If a single error matches multiple branches, the earlier (more
    specific) branch wins. Tool-validation > quota > edge-400 > generic."""

    def test_tool_validation_beats_quota_when_both_present(self):
        # Synthetic edge case: quota wording embedded in a validation error.
        detail = (
            "1 validation error for bash\ncommand\n  Field required "
            "[type=missing, input_value={}] -- rate limit hit also"
        )
        assert _rewrite_detail(detail, "ValidationError") == "TOOL_VALIDATION_HINT"

    def test_quota_beats_edge_400_for_gemini(self):
        detail = (
            "status_code: 429, model_name: gemini-2.5-flash. Also saw "
            "Error 400 (Bad Request)!!1 earlier"
        )
        assert _rewrite_detail(detail, "ModelHTTPError") == "QUOTA_HINT_GEMINI"

    def test_401_with_rate_limit_wording_routes_to_expired_key_not_quota(self):
        """Some providers throttle auth with rate-limit-flavored
        language; don't mis-route those to the quota branch. Expired-
        key branch runs FIRST and catches the 401."""
        detail = (
            "status_code: 401, model_name: claude-haiku-4-5-20251001. "
            "Auth rate limit applied; invalid_api_key in header."
        )
        assert _rewrite_detail(detail, "AuthenticationError") == "EXPIRED_KEY_HINT"
