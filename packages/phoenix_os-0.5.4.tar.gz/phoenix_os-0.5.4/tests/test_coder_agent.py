"""Tests for the coder agent personality.

Verifies:
- YAML parses cleanly via registry
- Generated system prompt contains the load-bearing caveman + safety markers
- Declared abilities are all real and discoverable
- Authority boundaries (never commit / never push) are expressed in the prompt

The coder agent is Phoenix's dedicated coding executor. Its system prompt is
the contract with the model; regressions here are behavior regressions. Pin
the markers so prompt edits stay intentional.
"""

from pathlib import Path

import pytest
import yaml

from phoenix.core.registry import Registry
from phoenix.personality.parser import build_agent_prompt, parse_agent

AGENTS_DIR = Path(__file__).parent.parent / "phoenix" / "personality" / "agents"
CODER_YAML = AGENTS_DIR / "coder.yaml"


class TestCoderYaml:
    def test_yaml_file_exists(self):
        assert CODER_YAML.exists(), f"coder.yaml missing at {CODER_YAML}"

    def test_yaml_parses(self):
        with open(CODER_YAML) as f:
            data = yaml.safe_load(f)
        assert data["name"] == "coder"
        assert isinstance(data["rules"], list)
        assert len(data["rules"]) >= 10

    def test_agent_config_loads_via_parser(self):
        config = parse_agent(CODER_YAML)
        assert config.name == "coder"
        assert "terse" in config.tone
        assert config.behaviors.delegation is False
        assert config.behaviors.ask_permission is False


class TestCoderPrompt:
    """The generated system prompt is the actual contract with the model."""

    @pytest.fixture
    def prompt(self) -> str:
        return build_agent_prompt("coder", project_context="")

    def test_caveman_body_present(self, prompt):
        # Exact phrasing from JuliusBrussee/caveman SKILL.md -- the ~50%
        # measured reduction on their eval snapshot came from this ruleset.
        assert "terse like smart caveman" in prompt.lower()
        assert "articles (a/an/the)" in prompt
        assert "fragments ok" in prompt.lower()

    def test_auto_clarity_clause_present(self, prompt):
        # Auto-Clarity is the safety clause: caveman reverts to normal prose
        # for destructive ops and errors. Without this, terse fragments get
        # dangerous on rm / DROP / force-push.
        assert "auto-clarity" in prompt.lower()
        assert "destructive" in prompt.lower()
        assert "git reset --hard" in prompt.lower()

    def test_never_commits_boundary(self, prompt):
        # Boss-gated commit discipline: coder executes, Phoenix orchestrates,
        # Boss approves. Coder must never cross that line. All four
        # write-side boundaries are pinned -- dropping any one of them in
        # a prompt refactor should break this test.
        lowered = prompt.lower()
        assert "never commit" in lowered
        assert "never push" in lowered
        assert "never tag" in lowered
        assert "never open prs" in lowered

    def test_retry_cap_present(self, prompt):
        # 2-retry cap + wait-on-error is the contract against runaway loops.
        assert "retry max 2" in prompt.lower()

    def test_json_hint_parsing_documented(self, prompt):
        # Phoenix may send tasks as JSON with surgical fields; prompt must
        # teach the model to parse that shape. All hint fields except task
        # and reason are optional.
        assert "json" in prompt.lower()
        assert "task" in prompt.lower()
        assert "reason" in prompt.lower()

    def test_report_pattern_documented(self, prompt):
        # Caveman pattern: [file:line] [action] | [reason]. [next step].
        assert "[file:line]" in prompt or "file:line" in prompt
        assert "next:" in prompt.lower() or "next step" in prompt.lower()

    def test_no_reasoning_framework_leaked(self, prompt):
        # Coder sets inherit_reasoning=false. If phoenix.yaml's 9-step
        # framework leaks in, the model hedges and explains instead of
        # executing terse -- directly eroding the measured ~50% output
        # savings. Any regression that flips the flag or removes the
        # parser gate should surface here.
        assert "draw 3-4 interpretations" not in prompt
        assert "How you operate" not in prompt
        assert "best 3 cases" not in prompt

    def test_no_orchestrator_global_rules_leaked(self, prompt):
        # Coder sets inherit_global_rules=false. The global "do it via
        # delegate" rule is contradictory for a leaf agent that cannot
        # delegate, and the global reasoning rules fight caveman output.
        assert "YOU DO IT via delegate" not in prompt
        assert "Act first, report back" not in prompt

    def test_prompt_length_bounded(self, prompt):
        # Pin a soft bound so phoenix.yaml bloat (or accidental inheritance
        # re-enablement) can't quietly double the prompt and evaporate the
        # caveman savings. Current observed length ~3100 chars; bound
        # generously at 5000 with a floor at 1500 to catch under-building.
        assert 1500 < len(prompt) < 5000, (
            f"coder prompt length {len(prompt)} is outside the expected band -- "
            "check phoenix.yaml defaults and inherit_* flags."
        )


class TestCoderAbilities:
    """Every declared ability must resolve against the real registry."""

    @pytest.fixture
    def registry(self) -> Registry:
        r = Registry()
        r.discover_all()
        return r

    def test_registered_in_registry(self, registry):
        assert "coder" in registry.list_agents()

    def test_all_abilities_resolve(self, registry):
        config = registry.get_agent_config("coder")
        assert config is not None
        resolved = registry.get_agent_abilities("coder")
        resolved_names = {a.name for a in resolved}
        # Every declared ability we expect in coder's toolkit must exist in
        # the registry. web_search may be absent without BRAVE_API_KEY so it
        # is deliberately NOT in coder.yaml.
        for required in ("bash", "read_file", "write_file", "search_replace", "grep"):
            assert required in resolved_names, f"{required} missing from coder abilities"

    def test_no_web_search_by_default(self, registry):
        # Coder is an executor, not a researcher. Keep its toolkit tight.
        config = registry.get_agent_config("coder")
        assert "web_search" not in config.abilities

    def test_no_delegate_ability(self, registry):
        # Coder is a leaf agent. Nested delegation would invert the
        # Phoenix-orchestrates-coder-executes contract.
        config = registry.get_agent_config("coder")
        assert "delegate" not in config.abilities
