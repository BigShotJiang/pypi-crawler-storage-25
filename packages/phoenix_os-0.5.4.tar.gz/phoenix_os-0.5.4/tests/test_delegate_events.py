"""Tests for phoenix.core.delegate_events (the pub/sub bus).

The bus is load-bearing for the Ctrl+O panel; regressions here mean
silent panels, not crashes, so pin the contracts:
- subscribe / unsubscribe are idempotent
- publish fans out to all listeners
- subscriber exceptions don't poison the bus
- active-registry folds events in the expected shape
- history is capped so runaway delegates don't balloon memory
"""

import pytest

from phoenix.core import delegate_events as bus


@pytest.fixture(autouse=True)
def _clean_bus():
    bus.clear()
    yield
    bus.clear()


class TestSubscribe:
    def test_subscribe_and_publish(self):
        received: list[bus.DelegateEvent] = []
        bus.subscribe(received.append)
        evt = bus.DelegateEvent(type="started", delegate_id="x-1", agent="coder", ts=1.0)
        bus.publish(evt)
        assert received == [evt]

    def test_subscribe_is_idempotent(self):
        received: list[bus.DelegateEvent] = []
        bus.subscribe(received.append)
        bus.subscribe(received.append)
        bus.publish(bus.DelegateEvent(type="started", delegate_id="x-1", agent="coder", ts=1.0))
        assert len(received) == 1

    def test_unsubscribe(self):
        received: list[bus.DelegateEvent] = []
        bus.subscribe(received.append)
        bus.unsubscribe(received.append)
        bus.publish(bus.DelegateEvent(type="started", delegate_id="x-1", agent="coder", ts=1.0))
        assert received == []

    def test_unsubscribe_silent_on_missing(self):
        # Must not raise if the callback was never registered.
        bus.unsubscribe(lambda e: None)


class TestErrorIsolation:
    def test_raising_subscriber_does_not_block_others(self):
        received: list[bus.DelegateEvent] = []

        def broken(_e):
            raise RuntimeError("bad subscriber")

        bus.subscribe(broken)
        bus.subscribe(received.append)
        bus.publish(bus.DelegateEvent(type="started", delegate_id="x-1", agent="coder", ts=1.0))
        assert len(received) == 1

    def test_subscriber_can_unsubscribe_itself_mid_dispatch(self):
        received: list[bus.DelegateEvent] = []

        def once(e: bus.DelegateEvent):
            received.append(e)
            bus.unsubscribe(once)

        bus.subscribe(once)
        bus.publish(bus.DelegateEvent(type="started", delegate_id="x-1", agent="coder", ts=1.0))
        bus.publish(bus.DelegateEvent(type="done", delegate_id="x-1", agent="coder", ts=2.0))
        assert len(received) == 1


class TestActiveRegistry:
    def test_started_creates_record(self):
        bus.publish(
            bus.DelegateEvent(
                type="started",
                delegate_id="coder-abc",
                agent="coder",
                ts=100.0,
                task_preview="Refactor login",
            )
        )
        active = bus.list_active()
        assert len(active) == 1
        assert active[0].agent == "coder"
        assert active[0].task_preview == "Refactor login"
        assert active[0].started_at == 100.0

    def test_tool_call_updates_last_tool_and_count(self):
        bus.publish(bus.DelegateEvent(type="started", delegate_id="c-1", agent="coder", ts=100.0))
        bus.publish(
            bus.DelegateEvent(
                type="tool_call",
                delegate_id="c-1",
                agent="coder",
                ts=101.0,
                tool_name="read_file",
            )
        )
        bus.publish(
            bus.DelegateEvent(
                type="tool_call",
                delegate_id="c-1",
                agent="coder",
                ts=102.0,
                tool_name="write_file",
            )
        )
        rec = bus.list_active()[0]
        assert rec.last_tool == "write_file"
        assert rec.tool_count == 2

    def test_done_removes_record(self):
        bus.publish(bus.DelegateEvent(type="started", delegate_id="c-1", agent="coder", ts=100.0))
        bus.publish(
            bus.DelegateEvent(type="done", delegate_id="c-1", agent="coder", ts=105.0, duration=5.0)
        )
        assert bus.list_active() == []

    def test_error_removes_record(self):
        bus.publish(bus.DelegateEvent(type="started", delegate_id="c-1", agent="coder", ts=100.0))
        bus.publish(
            bus.DelegateEvent(
                type="error", delegate_id="c-1", agent="coder", ts=105.0, error_message="boom"
            )
        )
        assert bus.list_active() == []

    def test_event_for_unknown_delegate_is_ignored(self):
        # No "started" event -- subsequent events must not synthesize a partial record.
        bus.publish(
            bus.DelegateEvent(
                type="tool_call", delegate_id="ghost-1", agent="coder", ts=1.0, tool_name="bash"
            )
        )
        assert bus.list_active() == []

    def test_list_active_sorted_oldest_first(self):
        bus.publish(bus.DelegateEvent(type="started", delegate_id="a-1", agent="coder", ts=200.0))
        bus.publish(bus.DelegateEvent(type="started", delegate_id="b-1", agent="worker", ts=100.0))
        active = bus.list_active()
        assert [a.delegate_id for a in active] == ["b-1", "a-1"]


class TestHistory:
    def test_history_is_capped(self):
        bus.publish(bus.DelegateEvent(type="started", delegate_id="c-1", agent="coder", ts=0.0))
        for i in range(200):
            bus.publish(
                bus.DelegateEvent(
                    type="tool_call",
                    delegate_id="c-1",
                    agent="coder",
                    ts=float(i),
                    tool_name=f"t{i}",
                )
            )
        rec = bus.list_active()[0]
        # _MAX_HISTORY is 50 (private); assert we stay within a sane cap.
        assert len(rec.history) <= 51  # +1 for the started event

    def test_history_preserves_newest(self):
        bus.publish(bus.DelegateEvent(type="started", delegate_id="c-1", agent="coder", ts=0.0))
        for i in range(60):
            bus.publish(
                bus.DelegateEvent(
                    type="tool_call",
                    delegate_id="c-1",
                    agent="coder",
                    ts=float(i),
                    tool_name=f"t{i}",
                )
            )
        rec = bus.list_active()[0]
        last_event = rec.history[-1]
        assert last_event.tool_name == "t59"


class TestHelpers:
    def test_make_id_is_unique(self):
        ids = {bus.make_id("coder") for _ in range(100)}
        assert len(ids) == 100

    def test_make_id_is_agent_prefixed(self):
        assert bus.make_id("coder").startswith("coder-")
        assert bus.make_id("worker").startswith("worker-")
