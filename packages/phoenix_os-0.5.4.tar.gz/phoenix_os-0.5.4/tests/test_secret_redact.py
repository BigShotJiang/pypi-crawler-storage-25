"""Tests for phoenix.abilities._secret_redact.

The redactor runs at the bash / read_file / bash_bg output boundary so
`cat .env.local` / `read_file .env` / a dev server printing loaded env
on startup can't leak real API keys and Supabase URLs back to the LLM.
"""

from __future__ import annotations

from pathlib import Path

from phoenix.abilities._secret_redact import redact_secrets, with_notice


class TestEnvLineRedaction:
    def test_unquoted_value_masked(self):
        out, n = redact_secrets("NEXT_PUBLIC_SUPABASE_URL=https://abc123.supabase.co")
        assert n == 1
        assert "https://abc123.supabase.co" not in out
        assert "NEXT_PUBLIC_SUPABASE_URL" in out
        assert "<REDACTED" in out

    def test_double_quoted_value_masked(self):
        out, n = redact_secrets('API_KEY="sk_live_abcdef123456"')
        assert n >= 1
        assert "sk_live_abcdef123456" not in out
        assert "API_KEY" in out

    def test_single_quoted_value_masked(self):
        out, n = redact_secrets("SECRET='hunter2mysecret'")
        assert n >= 1
        assert "hunter2mysecret" not in out

    def test_export_prefix_handled(self):
        out, n = redact_secrets("export AWS_SECRET_ACCESS_KEY=abcd1234")
        assert n == 1
        assert "abcd1234" not in out

    def test_multiple_lines(self):
        raw = "\n".join(
            [
                "# comment not redacted",
                "KEY_A=value_a",
                "KEY_B=value_b",
                "no_env_line_here",
                "KEY_C=value_c",
            ]
        )
        out, n = redact_secrets(raw)
        assert n == 3
        assert "value_a" not in out
        assert "value_b" not in out
        assert "value_c" not in out
        # Non-env lines preserved
        assert "no_env_line_here" in out
        assert "# comment not redacted" in out

    def test_lowercase_key_is_not_matched(self):
        """Only ALL-CAPS-ish env keys are matched. Regular text like
        `db_url=...` in prose shouldn't be masked."""
        out, n = redact_secrets("the config is db_url=postgres://x")
        assert n == 0


class TestApiKeyPatterns:
    def test_anthropic_key(self):
        out, n = redact_secrets("token: sk-ant-api03-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
        assert n == 1
        assert "sk-ant-api03-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" not in out
        assert "sk-a<REDACTED" in out

    def test_openai_legacy_key(self):
        key = "sk-" + "A" * 48
        out, n = redact_secrets(f"x={key} y=ok")
        assert n >= 1
        assert key not in out

    def test_google_aiza_key(self):
        key = "AIza" + "B" * 35
        out, n = redact_secrets(f"use {key} for this")
        assert n == 1
        assert key not in out

    def test_github_pat(self):
        key = "ghp_" + "C" * 36
        out, n = redact_secrets(key)
        assert n == 1
        assert key not in out

    def test_jwt_like_token(self):
        jwt = (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJzdWIiOiIxMjM0NTY3ODkwIn0."
            "SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        )
        out, n = redact_secrets(f"supabase-anon: {jwt}")
        assert n == 1
        assert jwt not in out


class TestJsonCredFields:
    def test_api_key_json(self):
        out, n = redact_secrets('{"api_key": "aaaaa-very-secret"}')
        assert n == 1
        assert "aaaaa-very-secret" not in out
        assert "api_key" in out

    def test_password_yaml(self):
        out, n = redact_secrets('{"password": "hunter2mysecret"}')
        assert n == 1
        assert "hunter2mysecret" not in out


class TestWithNotice:
    def test_notice_prepended_when_redacted(self):
        out = with_notice("KEY=secretvalue123")
        assert out.startswith("[phoenix: redacted")
        assert "secretvalue123" not in out

    def test_notice_absent_on_clean_input(self):
        out = with_notice("nothing to redact here")
        assert out == "nothing to redact here"


class TestReadFileRedactsEnv:
    """read_file must run its output through the redactor so
    `read_file .env.local` doesn't leak values."""

    def test_env_file_read_is_redacted(self, tmp_path: Path):
        from phoenix.abilities.file_ops import read_file

        env = tmp_path / ".env.local"
        env.write_text("API_KEY=sk-very-real-key-xyz123456\n")
        fn = getattr(read_file, "__wrapped__", read_file)
        out = fn(str(env))
        assert "sk-very-real-key-xyz123456" not in out
        assert "API_KEY" in out
        assert "REDACTED" in out
