"""PageRank via power iteration -- stdlib only.

Used by `repo_map.py` to score code symbols by how much "important" code
references them. Aider-style: symbols defined in heavily-used files
propagate their importance to the symbols they reference.

Pure: takes a directed graph (`{node: set(outgoing)}`) and returns
`{node: score}` summing to ~1.0. No deps.
"""

from __future__ import annotations


def page_rank(
    graph: dict[str, set[str]],
    *,
    damping: float = 0.85,
    iterations: int = 20,
) -> dict[str, float]:
    """Standard power-iteration PageRank.

    Args:
        graph: outgoing edges -- `graph[node]` is the set of nodes `node`
            points to. Nodes that only appear as targets (never as keys)
            are still scored; they just have no outgoing edges.
        damping: random-walk damping factor (typical 0.85).
        iterations: power-iteration count. 20 converges for most graphs.

    Returns: `{node: score}`, scores sum to ~1.0. Empty input -> empty out.
    """
    nodes: set[str] = set(graph.keys())
    for outs in graph.values():
        nodes.update(outs)
    n = len(nodes)
    if n == 0:
        return {}

    rank: dict[str, float] = {node: 1.0 / n for node in nodes}

    incoming: dict[str, list[str]] = {node: [] for node in nodes}
    out_degree: dict[str, int] = {node: 0 for node in nodes}
    for src, dsts in graph.items():
        # Treat dangling nodes (no out-edges) as if they pointed to all
        # nodes equally; the power-iteration loop handles this implicitly
        # by giving them out_degree=n. Simpler: skip the divide-by-zero
        # by using max(1, ...) below.
        out_degree[src] = len(dsts)
        for dst in dsts:
            incoming[dst].append(src)

    base = (1.0 - damping) / n
    for _ in range(iterations):
        new_rank: dict[str, float] = {}
        for node in nodes:
            contrib = 0.0
            for src in incoming[node]:
                deg = out_degree[src] or 1
                contrib += rank[src] / deg
            new_rank[node] = base + damping * contrib
        rank = new_rank

    return rank
