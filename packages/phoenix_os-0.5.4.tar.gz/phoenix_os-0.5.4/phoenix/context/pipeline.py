"""DCBP orchestrator -- assembles the engineered prompt per turn."""

from __future__ import annotations

from phoenix.context.arbiter import ArbiterResult, BudgetArbiter
from phoenix.context.intent import intent_from_input
from phoenix.context.providers import TurnState, default_providers


class DCBP:
    """Dynamic Context Building Pipeline.

    One instance per `PhoenixEngine`. Per turn, `run()` classifies intent,
    gathers per-turn data, asks the arbiter to plan a budgeted assembly,
    and concatenates the rendered provider outputs with the user message.

    Returns the prompt string plus the `ArbiterResult` so callers can log
    per-provider token breakdowns (`/cost breakdown`).
    """

    def __init__(self, providers: list | None = None, budget: int = 32000):
        self.providers = providers if providers is not None else default_providers()
        self.arbiter = BudgetArbiter(total_budget=budget)

    def run(
        self,
        user_input: str,
        *,
        memory_context: str = "",
        session_summary: str = "",
        topic_tracker: object | None = None,
        web_context: str = "",
        contradiction_score: float = 0.0,
        contradiction_pairs: list | None = None,
        ambient_summary: str = "",
        insights: list[str] | None = None,
        is_continuation: bool = False,
        session_depth: int = 0,
    ) -> tuple[str, ArbiterResult]:
        intent = intent_from_input(
            user_input,
            is_continuation=is_continuation,
            session_depth=session_depth,
        )

        topic_context = ""
        if topic_tracker is not None:
            topic_context = topic_tracker.build_context() or ""

        state = TurnState(
            user_input=user_input,
            intent=intent,
            memory_context=memory_context,
            session_summary=session_summary,
            topic_context=topic_context,
            web_context=web_context,
            contradiction_score=contradiction_score,
            contradiction_pairs=contradiction_pairs or [],
            ambient_summary=ambient_summary,
            insights=insights or [],
        )

        result = self.arbiter.plan(self.providers, state)

        parts = [content for _, content in result.rendered]
        parts.append(user_input)
        prompt = "\n\n".join(parts)

        return prompt, result
