"""Dynamic Context Building Pipeline (DCBP).

Assembles the engineered prompt per turn based on classified intent.
Replaces the hardcoded layer order that lived in
`engine.py::_build_engineered_context`.

Providers register for cache zones and declare when they want to inject
content. An arbiter allocates a per-turn budget across providers by
priority, with a protected floor for the load-bearing providers
(Persona, MemoryRecall, ConflictSurface -- priority <= 3).
"""

from phoenix.context.arbiter import ArbiterResult, BudgetArbiter
from phoenix.context.intent import TurnIntent, intent_from_input
from phoenix.context.pipeline import DCBP
from phoenix.context.providers import (
    AmbientInsightProvider,
    ConflictSurfaceProvider,
    EnvironmentProvider,
    InsightsProvider,
    MemoryRecallProvider,
    ReasoningModeProvider,
    SessionSummaryProvider,
    TopicSummaryProvider,
    TurnState,
    WebRetrievalProvider,
    default_providers,
    production_providers,
)
from phoenix.context.repo_map import RepoMapProvider

__all__ = [
    "AmbientInsightProvider",
    "ArbiterResult",
    "BudgetArbiter",
    "ConflictSurfaceProvider",
    "DCBP",
    "EnvironmentProvider",
    "InsightsProvider",
    "MemoryRecallProvider",
    "ReasoningModeProvider",
    "RepoMapProvider",
    "SessionSummaryProvider",
    "TopicSummaryProvider",
    "TurnIntent",
    "TurnState",
    "WebRetrievalProvider",
    "default_providers",
    "intent_from_input",
    "production_providers",
]
