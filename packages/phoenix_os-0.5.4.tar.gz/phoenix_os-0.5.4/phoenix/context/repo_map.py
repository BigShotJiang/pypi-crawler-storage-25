"""Aider-style repo map -- top symbols ranked by reference importance.

Walks `.py` files under the project root with stdlib `ast` (zero deps),
extracts class / function definitions and top-level reference names, then
runs PageRank over a "symbols defined in F propagate rank to symbols F
references" graph. Heavily-referenced symbols in heavily-used files float
to the top.

Replaces the always-on `phoenix/core/context.py::scan_project` for the
per-turn context slot. The system prompt keeps a one-liner identity stub;
this provider injects the real symbol map only when the turn is technical
and deep enough to need it (`intent.is_technical and intent.depth >= 2`).

Multi-language polish (TS / JS / Go via regex) is deferred to v0.9.
Phoenix is Python; Boss's daily code is mostly Python; ship that first.
"""

from __future__ import annotations

import ast
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from phoenix.context.ranking import page_rank

if TYPE_CHECKING:
    from phoenix.context.providers import TurnState

log = logging.getLogger(__name__)


_SKIP_DIR_NAMES = {
    ".venv",
    "venv",
    "__pycache__",
    ".git",
    "node_modules",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "build",
    "dist",
    ".tox",
    ".eggs",
}


@dataclass
class Symbol:
    name: str
    file: str
    line: int
    kind: str  # "class" | "function" | "async_function"


def _is_skipped(path: Path) -> bool:
    return any(part in _SKIP_DIR_NAMES for part in path.parts)


def extract_symbols(path: Path) -> tuple[list[Symbol], set[str]]:
    """Return (defined symbols, names referenced) for a Python file.

    Best-effort: unreadable files / syntax errors return ([], set()).
    Top-level `class` / `def` / `async def` only -- nested defs are
    skipped to keep the graph small and signal-rich.
    """
    try:
        source = path.read_text(errors="replace")
    except OSError:
        return [], set()
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return [], set()

    defined: list[Symbol] = []
    referenced: set[str] = set()

    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            defined.append(Symbol(node.name, str(path), node.lineno, "class"))
        elif isinstance(node, ast.FunctionDef):
            defined.append(Symbol(node.name, str(path), node.lineno, "function"))
        elif isinstance(node, ast.AsyncFunctionDef):
            defined.append(Symbol(node.name, str(path), node.lineno, "async_function"))

    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            referenced.add(node.id)
        elif isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Load):
            referenced.add(node.attr)

    return defined, referenced


@dataclass
class RepoScan:
    symbols_by_name: dict[str, list[Symbol]] = field(default_factory=dict)
    file_defines: dict[str, list[str]] = field(default_factory=dict)
    file_references: dict[str, set[str]] = field(default_factory=dict)


def scan_repository(root: Path, max_files: int = 200) -> RepoScan:
    """Walk `.py` files under root; build defines + references maps.

    `max_files` caps work on huge monorepos; on a typical 50-file project
    it's never reached. Skipped dirs (`.venv`, `__pycache__`, etc.) don't
    count toward the cap.
    """
    scan = RepoScan()
    files = []
    for p in root.rglob("*.py"):
        if _is_skipped(p):
            continue
        files.append(p)
        if len(files) >= max_files:
            break

    for f in files:
        defined, referenced = extract_symbols(f)
        rel = str(f.relative_to(root)) if f.is_relative_to(root) else str(f)
        for s in defined:
            s.file = rel
            scan.symbols_by_name.setdefault(s.name, []).append(s)
        scan.file_defines[rel] = [s.name for s in defined]
        scan.file_references[rel] = referenced

    return scan


def _build_pagerank_graph(scan: RepoScan) -> dict[str, set[str]]:
    """Symbol → symbol edges.

    Each file F that defines symbols `D` and references names `R`
    contributes an edge from every `d in D` to every `r in R` that names
    a known symbol. Importance flows from "things F provides" to "things
    F uses." Symbols defined in heavily-used files thus boost the symbols
    they reference.
    """
    known = set(scan.symbols_by_name.keys())
    graph: dict[str, set[str]] = {}
    for f, defs in scan.file_defines.items():
        refs = scan.file_references.get(f, set()) & known
        for d in defs:
            graph.setdefault(d, set()).update(refs - {d})
    return graph


def render_repo_map(
    scan: RepoScan,
    *,
    top_k: int = 20,
    budget: int | None = None,
) -> str:
    """Return a top-K symbol map grouped by file, ranked by PageRank.

    `budget` is a char cap; truncates the rendered string if exceeded.
    """
    if not scan.symbols_by_name:
        return ""

    graph = _build_pagerank_graph(scan)
    ranks = page_rank(graph) if graph else {n: 0.0 for n in scan.symbols_by_name}

    scored = sorted(
        scan.symbols_by_name.items(),
        key=lambda item: -max(ranks.get(item[0], 0.0), 0.0),
    )
    top = scored[:top_k]

    by_file: dict[str, list[tuple[Symbol, float]]] = {}
    for name, defs in top:
        score = ranks.get(name, 0.0)
        for s in defs:
            by_file.setdefault(s.file, []).append((s, score))

    file_order = sorted(
        by_file.items(),
        key=lambda kv: -max(score for _, score in kv[1]),
    )

    lines = ["[Project map -- top symbols by reference rank]"]
    for f, items in file_order:
        lines.append("")
        lines.append(f)
        for s, _score in items:
            ref_count = len([1 for refs in scan.file_references.values() if s.name in refs])
            ref_str = f" -- referenced {ref_count}x" if ref_count else ""
            lines.append(f"- {s.name} ({s.kind}){ref_str}")

    out = "\n".join(lines)
    if budget is not None and len(out) > budget:
        out = out[:budget]
    return out


@dataclass
class RepoMapProvider:
    """Per-turn injection of the top-K Python symbols from cwd.

    Scans the project once at construction (provider lifetime = session).
    Renders only on technical, depth>=2 turns -- "how are you" doesn't
    pay the symbol-map cost; "explain trade-offs in `engine.py`" does.

    Priority 4 (unprotected): memory, environment, conflict outrank it.
    """

    priority: int = 4
    max_chars: int = 3000
    top_k: int = 20
    cwd: Path | None = None
    _scan: RepoScan = field(default_factory=RepoScan, init=False)

    def __post_init__(self) -> None:
        root = self.cwd or Path.cwd()
        try:
            self._scan = scan_repository(root)
        except Exception as e:
            log.warning("RepoMapProvider scan failed: %s", e)
            self._scan = RepoScan()

    def should_inject(self, state: TurnState) -> bool:
        if not self._scan.symbols_by_name:
            return False
        return state.intent.is_technical and state.intent.depth >= 2

    def render(self, state: TurnState, budget: int) -> str:
        cap = min(budget, self.max_chars)
        return render_repo_map(self._scan, top_k=self.top_k, budget=cap)
