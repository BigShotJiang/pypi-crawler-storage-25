"""Intent layer for the DCBP -- classifies a user turn for provider gating.

Zero LLM, zero embeddings. Pure regex + existing reasoning primitives.
Callers pass session signals (`is_continuation`, `session_depth`) that
the DCBP already knows; everything else is derived from the input text.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from phoenix.core.reasoning import QueryType, classify_query, detect_stakes

_TEMPORAL_RE = re.compile(
    r"\b("
    r"yesterday|today|tonight|"
    r"last (week|month|year|time|session|night)|"
    r"this (morning|afternoon|evening|week)|"
    r"earlier|just now|recently|a while back|back then|before"
    r")\b",
    re.IGNORECASE,
)

# Narrow on purpose: false positives here fire MemoryRecallProvider
# unnecessarily, costing tokens. Prefer precision over recall.
_MEMORY_SIGNAL_RE = re.compile(
    r"\b("
    r"you (mentioned|said|told me)|"
    r"we (discussed|talked about|agreed)|"
    r"remember (when|that|what)|"
    r"my (name|project|job|role|partner|wife|husband) is|"
    r"i (am|'m) (working on|building|currently)"
    r")\b",
    re.IGNORECASE,
)

# Unambiguous technical markers. "test" / "code" are deliberately excluded
# (too polysemous in conversational use).
_TECHNICAL_RE = re.compile(
    r"("
    r"```|"
    r"\b("
    r"bug|function|class|module|endpoint|api|database|migration|"
    r"refactor|pytest|typescript|javascript|nextjs|next\.js|"
    r"docker|kubernetes|k8s|vercel|npm|pip|uv|cargo|pyproject|"
    r"repo|commit|branch|merge|pull request|\bpr\b"
    r")\b"
    r")",
    re.IGNORECASE,
)


@dataclass
class TurnIntent:
    """Classified signals for a single user turn.

    Consumers: providers in `phoenix/context/providers.py`, the arbiter,
    and the reasoning-mode selector. New fields should be derivable with
    zero LLM cost so the intent pass stays free.
    """

    query_type: QueryType
    stakes: bool
    temporal_ref: str | None
    is_continuation: bool
    session_depth: int
    has_memory_signal: bool
    is_technical: bool
    depth: int
    # 0 = social ("hi"), 1 = factual, 2 = analytical (opinion/recommendation),
    # 3 = architectural (complex reasoning, long elaboration, code blocks).

    # Written back by `MemoryRecallProvider` after recall runs, so
    # `ConflictSurfaceProvider` (lower priority) can gate on it.
    contradiction_score: float = 0.0


def _compute_depth(text: str, qt: QueryType) -> int:
    if qt == QueryType.CHAT:
        return 0
    if qt == QueryType.COMPLEX_REASONING:
        return 3
    if "```" in text or len(text.split()) > 50:
        return 3
    if qt in (QueryType.OPINION, QueryType.RECOMMENDATION):
        return 2
    return 1


def intent_from_input(
    user_input: str,
    *,
    is_continuation: bool = False,
    session_depth: int = 0,
) -> TurnIntent:
    """Classify a user turn into a `TurnIntent`.

    Args:
        user_input: raw user message.
        is_continuation: set when the session was launched with `--continue`
            or resumed from a prior state.
        session_depth: completed-topic count in the current session.
    """
    qt = classify_query(user_input)
    stakes = detect_stakes(user_input) is not None

    temporal_match = _TEMPORAL_RE.search(user_input)
    temporal_ref = temporal_match.group(0).lower() if temporal_match else None

    return TurnIntent(
        query_type=qt,
        stakes=stakes,
        temporal_ref=temporal_ref,
        is_continuation=is_continuation,
        session_depth=session_depth,
        has_memory_signal=bool(_MEMORY_SIGNAL_RE.search(user_input)),
        is_technical=bool(_TECHNICAL_RE.search(user_input)),
        depth=_compute_depth(user_input, qt),
    )
