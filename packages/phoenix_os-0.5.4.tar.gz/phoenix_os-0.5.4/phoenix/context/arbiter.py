"""Budget arbiter -- allocates a char budget across providers by priority.

Rules:
- Providers with `priority <= PROTECTED_PRIORITY` cannot be dropped. These
  carry product guarantees (Recognition, Correction, identity) that must
  not be displaced by lower-priority web snippets or ambient hints.
- Everything else drops from the lowest priority (highest number) down
  until the total fits.
- Default budget is generous (32k chars ~= 8k tokens) so v0.4 providers
  rarely truncate. Later releases tighten it alongside prompt caching.
"""

from __future__ import annotations

from dataclasses import dataclass

from phoenix.context.providers import TurnState


@dataclass
class ArbiterResult:
    rendered: list[tuple[object, str]]
    total_chars: int
    dropped: list[str]


class BudgetArbiter:
    PROTECTED_PRIORITY = 3

    def __init__(self, total_budget: int = 32000):
        self.total_budget = total_budget

    def plan(self, providers: list, state: TurnState) -> ArbiterResult:
        sorted_providers = sorted(providers, key=lambda p: p.priority)

        rendered: list[tuple[object, str]] = []
        for p in sorted_providers:
            if p.should_inject(state):
                content = p.render(state, self.total_budget)
                if content:
                    rendered.append((p, content))

        total = sum(len(c) for _, c in rendered)
        if total <= self.total_budget:
            return ArbiterResult(rendered=rendered, total_chars=total, dropped=[])

        dropped: list[str] = []
        # Drop from the lowest-priority end (highest priority number first).
        # Walk the priority-sorted list in reverse; skip protected entries.
        for i in range(len(rendered) - 1, -1, -1):
            if total <= self.total_budget:
                break
            p, c = rendered[i]
            if p.priority <= self.PROTECTED_PRIORITY:
                continue
            total -= len(c)
            dropped.append(type(p).__name__)
            rendered.pop(i)

        return ArbiterResult(rendered=rendered, total_chars=total, dropped=dropped)
