"""Phoenix configuration -- model resolution, logging, paths."""

import logging
import os
from pathlib import Path

try:
    from dotenv import load_dotenv

    _env_path = Path.cwd() / ".env"
    if _env_path.exists():
        load_dotenv(_env_path)
except ImportError:
    pass


PHOENIX_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix"))

DEFAULT_MODEL = "anthropic:claude-sonnet-4-20250514"
MODEL = os.environ.get("PHOENIX_MODEL", DEFAULT_MODEL)

OLLAMA_CLOUD_API_KEY = os.environ.get("OLLAMA_CLOUD_API_KEY", "")
OLLAMA_CLOUD_BASE_URL = os.environ.get("OLLAMA_CLOUD_BASE_URL", "https://ollama.com/v1")

# Ollama's default local server (https://docs.ollama.com/api/openai-compatibility).
# Hardcoded so `ollama:<any-model>` works out of the box on any machine that
# has `ollama serve` running -- no env var, no config, no setup step. Override
# via OLLAMA_BASE_URL for remote/container setups.
_OLLAMA_LOCAL_URL = "http://localhost:11434/v1"


def get_model() -> str:
    return MODEL


def get_provider(model: str | None = None) -> str:
    m = model or MODEL
    return m.split(":")[0] if ":" in m else "unknown"


def get_model_name(model: str | None = None) -> str:
    m = model or MODEL
    return m.split(":", 1)[1] if ":" in m else m


def resolve_model(model: str | None = None):
    """Resolve a model string to a pydantic-ai compatible model.

    - `ollama:<anything>`  -> routed to Ollama's local OpenAI-compatible
      endpoint at http://localhost:11434/v1. Works out of the box on any
      machine running `ollama serve` -- no env var, no setup step.
      Override via OLLAMA_BASE_URL for remote / container setups.
    - `ollama:<model>` with `OLLAMA_CLOUD_API_KEY` set -> Ollama Cloud.
    - anything else -> returned unchanged for pydantic-ai to resolve
      (anthropic:, openai:, google-gla:, groq:, etc).
    """
    m = model or MODEL

    if m.startswith("ollama:"):
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider

        if OLLAMA_CLOUD_API_KEY:
            return OpenAIChatModel(
                model_name=get_model_name(m),
                provider=OpenAIProvider(
                    base_url=OLLAMA_CLOUD_BASE_URL,
                    api_key=OLLAMA_CLOUD_API_KEY,
                ),
            )

        # Local. Any env-var override wins (remote Ollama, Docker port map),
        # but the default is hardcoded so a fresh machine Just Works.
        base_url = os.environ.get("OLLAMA_BASE_URL", _OLLAMA_LOCAL_URL)
        return OpenAIChatModel(
            model_name=get_model_name(m),
            provider=OpenAIProvider(base_url=base_url, api_key="ollama"),
        )

    return m


def set_model(model: str):
    global MODEL
    MODEL = model
    if model.startswith("ollama:") and not OLLAMA_CLOUD_API_KEY:
        os.environ.setdefault("OLLAMA_BASE_URL", "http://localhost:11434/v1")


def setup_logging():
    level = os.environ.get("PHOENIX_LOG_LEVEL", "WARNING").upper()
    logging.basicConfig(
        level=getattr(logging, level, logging.WARNING),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    for name in ("httpx", "httpcore", "openai", "anthropic", "urllib3"):
        logging.getLogger(name).setLevel(logging.WARNING)
