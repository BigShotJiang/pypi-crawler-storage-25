"""Embedding backend setup -- Hugging Face auth flow for EmbeddingGemma.

Guides the user through accepting the Gemma license, creating an HF token,
and pre-downloading the model. Called from the main setup wizard after the
LLM provider has been configured.

Hard-fail per design: if HF auth fails, print manual retry + fastembed
escape hatch and raise. The caller exits non-zero. No silent fallback.
"""

import contextlib
import getpass
import logging
import os
import webbrowser

from phoenix.config.secrets import get_secret, store_secret

log = logging.getLogger(__name__)

_GEMMA_REPO = "google/embeddinggemma-300m"
_LICENSE_URL = f"https://huggingface.co/{_GEMMA_REPO}"
_TOKEN_URL = "https://huggingface.co/settings/tokens"

# Colors (mirror setup.py; duplicated to keep this module standalone)
DIM = "\033[2m"
BOLD = "\033[1m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
BRIGHT_BLACK = "\033[90m"
RESET = "\033[0m"
ICON_OK = "\u2713"


class HFSetupError(Exception):
    """Raised when HF auth or Gemma pre-warm cannot complete."""


def setup_gemma_auth() -> None:
    """Run the full HF auth flow. Returns None on success, raises on failure.

    Steps:
      1. Reuse existing HF_TOKEN if it validates via whoami.
      2. Otherwise open license page + token page, read pasted token.
      3. Verify token via whoami.
      4. Pre-download the Gemma model so first run doesn't stall.
    """
    token = _existing_token()
    if token and _verify_token(token):
        print(f"    {GREEN}{ICON_OK} Existing HF token verified{RESET}")
        os.environ["HF_TOKEN"] = token
    else:
        token = _paste_new_token()  # raises HFSetupError on empty / invalid
        store_secret("HF_TOKEN", token)
        os.environ["HF_TOKEN"] = token
        print(f"    {GREEN}{ICON_OK} Token verified and stored in OS keychain{RESET}")

    _prewarm_gemma(token)


def _existing_token() -> str | None:
    """Pull HF_TOKEN from env or keyring. Strips whitespace."""
    raw = os.environ.get("HF_TOKEN") or get_secret("HF_TOKEN")
    return raw.strip() if raw else None


def _verify_token(token: str) -> bool:
    """Call whoami to confirm the token is live. False on any failure."""
    try:
        from huggingface_hub import HfApi

        HfApi().whoami(token=token)
        return True
    except Exception as e:
        log.debug("HF whoami rejected token: %s", e)
        return False


def _paste_new_token() -> str:
    """Guide the user through license acceptance and token creation. Raises on failure."""
    print()
    print(f"    {BRIGHT_BLACK}EmbeddingGemma-300M requires a Hugging Face account.{RESET}")
    print(f"    {BRIGHT_BLACK}You need to:{RESET}")
    print(f"      {BRIGHT_BLACK}1. Accept the Gemma license (opens in browser){RESET}")
    print(f"      {BRIGHT_BLACK}2. Create a read-scope token (opens in browser){RESET}")
    print(f"      {BRIGHT_BLACK}3. Paste the token here{RESET}")
    print()

    try:
        input(f"  {GREEN}{BOLD}>{RESET} Press Enter to open the Gemma license page... ")
    except (KeyboardInterrupt, EOFError) as e:
        raise HFSetupError("cancelled at license step") from e

    _open_browser(_LICENSE_URL)
    print(f"    {BRIGHT_BLACK}Click 'Agree and access repository' on the page.{RESET}")

    try:
        input(f"  {GREEN}{BOLD}>{RESET} Press Enter to open the token creation page... ")
    except (KeyboardInterrupt, EOFError) as e:
        raise HFSetupError("cancelled at token step") from e

    _open_browser(_TOKEN_URL)
    print(f"    {BRIGHT_BLACK}Create a new token with 'read' scope, then copy it.{RESET}")
    print()

    try:
        token = getpass.getpass(f"  {GREEN}{BOLD}>{RESET} Paste HF token (hf_...): ")
    except (KeyboardInterrupt, EOFError) as e:
        raise HFSetupError("cancelled at paste") from e

    token = token.strip()
    if not token:
        print_retry_instructions("no token entered")
        raise HFSetupError("empty token")

    if not _verify_token(token):
        print_retry_instructions("HF whoami rejected the token")
        raise HFSetupError("token verification failed")

    return token


def _open_browser(url: str) -> None:
    """Open URL in the user's default browser. Always prints the URL too -- in
    SSH / headless sessions `webbrowser.open` often reports success while
    doing nothing visible, leaving the user at a blank prompt."""
    with contextlib.suppress(Exception):
        webbrowser.open(url)
    print(f"    {BRIGHT_BLACK}URL:{RESET} {url}")


def _prewarm_gemma(token: str) -> None:
    """Download the Gemma snapshot so first run is instant. Raises on failure.

    Downloads the full repo -- `allow_patterns` filters like `*.json` use
    fnmatch and do NOT recurse into module subfolders (1_Pooling/, 2_Dense/,
    etc), so a partial snapshot would cause sentence-transformers to re-fetch
    on first load and defeat the pre-warm. The repo is small (<1 GB); the
    metadata overhead is negligible.
    """
    print(f"    {BRIGHT_BLACK}Downloading EmbeddingGemma-300M (~600MB, one-time)...{RESET}")
    try:
        from huggingface_hub import snapshot_download

        snapshot_download(_GEMMA_REPO, token=token)
    except Exception as e:
        _explain_prewarm_error(e)
        print_retry_instructions("model download failed")
        raise HFSetupError("gemma download failed") from e

    print(f"    {GREEN}{ICON_OK} Gemma model cached{RESET}")


def _explain_prewarm_error(e: Exception) -> None:
    """Print a targeted hint for the most common download-failure modes."""
    msg = str(e).lower()
    is_gated = False
    try:
        from huggingface_hub.errors import GatedRepoError

        is_gated = isinstance(e, GatedRepoError)
    except ImportError:
        pass
    if not is_gated and ("gated" in msg or "403" in msg):
        is_gated = True

    if is_gated:
        print(f"    {RED}Hugging Face rejected the download with 'gated repo'.{RESET}")
        print(
            f"    {BRIGHT_BLACK}Your token works, but the Gemma license is not "
            f"accepted on this account yet.{RESET}"
        )
        print(f"    {BRIGHT_BLACK}Visit {_LICENSE_URL}{RESET}")
        print(f"    {BRIGHT_BLACK}and click 'Agree and access repository'.{RESET}")
    else:
        print(f"    {RED}Download failed: {type(e).__name__}: {e}{RESET}")


def print_retry_instructions(reason: str) -> None:
    """Print manual retry steps + the FastEmbed escape hatch."""
    print()
    print(f"  {YELLOW}{BOLD}Setup did not complete:{RESET} {BRIGHT_BLACK}{reason}{RESET}")
    print()
    print(f"  {BOLD}To retry:{RESET}")
    print(f"    1. Visit {_LICENSE_URL}")
    print("       and click 'Agree and access repository'")
    print(f"    2. Visit {_TOKEN_URL}")
    print("       and create a token with 'read' scope")
    print("    3. Run:  phoenix --setup")
    print()
    print(f"  {BOLD}Or, if you cannot use Hugging Face:{RESET}")
    print(f"    phoenix --embedder fastembed   {BRIGHT_BLACK}(English-only MiniLM, no auth){RESET}")
    print()
