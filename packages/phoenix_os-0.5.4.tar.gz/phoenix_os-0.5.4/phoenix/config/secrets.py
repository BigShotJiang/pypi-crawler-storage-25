"""Secure secret storage -- OS keychain via keyring library.

Uses the native OS secret store:
  macOS: Keychain
  Linux: Secret Service (GNOME Keyring / KDE Wallet)
  Windows: Windows Credential Locker

Falls back to encrypted file in ~/.phoenix/secrets if keyring unavailable.
"""

import json
import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)

_SERVICE_NAME = "phoenix-os"
_PHOENIX_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix"))
_FALLBACK_FILE = _PHOENIX_DIR / "secrets.json"


def _use_keyring() -> bool:
    """Check if keyring backend is available and functional."""
    try:
        import keyring

        backend = keyring.get_keyring()
        name = type(backend).__name__
        return not ("fail" in name.lower() or "null" in name.lower())
    except Exception as e:
        log.debug("keyring backend unavailable: %s: %s", type(e).__name__, e)
        return False


def diagnose_backend() -> str:
    """Return a human-readable summary of the current secret backend. For logs / --doctor."""
    try:
        import keyring

        backend = keyring.get_keyring()
        return f"keyring backend: {type(backend).__name__}"
    except ImportError:
        return "keyring: not installed"
    except Exception as e:
        return f"keyring: error -- {type(e).__name__}: {e}"


def store_secret(key: str, value: str):
    """Store a secret securely."""
    value = value.strip()
    if _use_keyring():
        import keyring

        keyring.set_password(_SERVICE_NAME, key, value)
        log.debug("Stored secret '%s' in OS keychain", key)
    else:
        _fallback_store(key, value)


def get_secret(key: str) -> str | None:
    """Retrieve a secret. Returns None if not found."""
    if _use_keyring():
        try:
            import keyring

            val = keyring.get_password(_SERVICE_NAME, key)
            return val
        except Exception:
            return _fallback_get(key)
    return _fallback_get(key)


def delete_secret(key: str):
    """Delete a stored secret."""
    if _use_keyring():
        try:
            import keyring

            keyring.delete_password(_SERVICE_NAME, key)
        except Exception:
            pass
    _fallback_delete(key)


def list_secrets() -> list[str]:
    """List all stored secret keys (not values)."""
    keys = []
    if _fallback_exists():
        data = _fallback_load()
        keys.extend(data.keys())
    return keys


def load_secrets_to_env():
    """Load all stored secrets into environment variables.

    Called at startup to make API keys available to the system.
    Resolution order, per key:
      1. If env var already set -> keep it (highest priority)
      2. Else try OS keychain via `keyring`
      3. Else try encrypted fallback file (~/.phoenix/secrets.json)

    On Windows, keyring may silently fail or return None even when keys were
    stored earlier in the same session. We log when that happens so users
    can diagnose via `phoenix --doctor` or the PHOENIX_LOG_LEVEL=INFO env var.
    """
    key_map = {
        "ANTHROPIC_API_KEY": "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY": "OPENAI_API_KEY",
        "GROQ_API_KEY": "GROQ_API_KEY",
        "GEMINI_API_KEY": "GEMINI_API_KEY",
        "MISTRAL_API_KEY": "MISTRAL_API_KEY",
        "DEEPSEEK_API_KEY": "DEEPSEEK_API_KEY",
        "OPENROUTER_API_KEY": "OPENROUTER_API_KEY",
        "BRAVE_API_KEY": "BRAVE_API_KEY",
        "PICOVOICE_ACCESS_KEY": "PICOVOICE_ACCESS_KEY",
        "ELEVENLABS_API_KEY": "ELEVENLABS_API_KEY",
        "HF_TOKEN": "HF_TOKEN",
    }

    keyring_ok = _use_keyring()
    log.info("Secret backend: %s", diagnose_backend())

    loaded_from_keyring = 0
    loaded_from_fallback = 0
    missing: list[str] = []

    for secret_key, env_var in key_map.items():
        # If the env var is ALREADY set (shell profile, Windows system env,
        # python-dotenv), strip whitespace in place and move on. Without this
        # a CRLF-contaminated key from a Windows paste into System env vars
        # silently stays malformed -- exactly the root cause of the Google
        # edge HTML 400s (see issue #2).
        preset = os.environ.get(env_var)
        if preset:
            cleaned = preset.strip()
            if cleaned != preset:
                os.environ[env_var] = cleaned
                log.warning(
                    "Stripped whitespace/CRLF from externally-set %s. "
                    "Check your shell profile or `setx %s`.",
                    env_var,
                    env_var,
                )
            _validate_key_format(env_var, cleaned)
            continue

        value = None
        if keyring_ok:
            try:
                import keyring

                value = keyring.get_password(_SERVICE_NAME, secret_key)
                if value:
                    loaded_from_keyring += 1
            except Exception as e:
                log.warning("keyring.get_password('%s') failed: %s", secret_key, e)

        if not value:
            value = _fallback_get(secret_key)
            if value:
                loaded_from_fallback += 1

        if value:
            cleaned = value.strip()
            if cleaned != value:
                # Re-save the cleaned value so the warning is one-shot, not every boot.
                # store_secret strips again (idempotent) and routes to the same backend.
                # If the re-save itself fails (read-only FS, full disk, broken keyring),
                # drop to DEBUG -- the user has bigger problems and repeating the same
                # WARNING on every boot adds noise without giving them an action item.
                try:
                    store_secret(secret_key, cleaned)
                    log.warning(
                        "Stripped and re-saved %s (CRLF or padding in stored secret)",
                        env_var,
                    )
                except Exception as e:
                    log.debug(
                        "Stripped whitespace from %s; re-save failed (%s: %s)",
                        env_var,
                        type(e).__name__,
                        e,
                    )
            os.environ[env_var] = cleaned
            _validate_key_format(env_var, cleaned)
        else:
            missing.append(env_var)

    log.info(
        "Secrets loaded: %d from keyring, %d from fallback file; %d missing",
        loaded_from_keyring,
        loaded_from_fallback,
        len(missing),
    )


# -- Key-format validators --
# Each provider publishes a distinctive prefix + length. When a loaded key
# doesn't match, we emit a warning so the user can diagnose before they hit
# the opaque Google-edge HTML 400 that motivated issue #2. The prefixes /
# lengths are permissive -- just tight enough to catch obvious paste-errors
# (CRLF, half-pasted keys, wrong provider's key in the wrong slot).

_KEY_HEURISTICS: dict[str, tuple[str, str]] = {
    # env_var: (expected_prefix, human_description)
    "ANTHROPIC_API_KEY": ("sk-ant-", "Anthropic keys begin with `sk-ant-`"),
    "OPENAI_API_KEY": ("sk-", "OpenAI keys begin with `sk-`"),
    "OPENROUTER_API_KEY": ("sk-or-", "OpenRouter keys begin with `sk-or-`"),
    "GEMINI_API_KEY": ("AIza", "Gemini keys begin with `AIza` and are 39 chars"),
    "GOOGLE_API_KEY": ("AIza", "Google keys begin with `AIza` and are 39 chars"),
    "GROQ_API_KEY": ("gsk_", "Groq keys begin with `gsk_`"),
    "HF_TOKEN": ("hf_", "HuggingFace tokens begin with `hf_`"),
    "BRAVE_API_KEY": ("BSA", "Brave keys begin with `BSA`"),
}


def _validate_key_format(env_var: str, value: str) -> None:
    """Emit a warning if `value` looks malformed for `env_var`.

    Deliberately a warning, not an error -- providers can change prefixes,
    users may have legitimate non-matching keys, and we don't want to block
    startup over heuristics. The goal is to surface issues BEFORE the
    provider returns an opaque HTML 400, not to enforce a contract.
    """
    heuristic = _KEY_HEURISTICS.get(env_var)
    if not heuristic:
        return
    prefix, description = heuristic

    if " " in value or "\t" in value or "\n" in value or "\r" in value:
        log.warning(
            "%s contains embedded whitespace AFTER strip. "
            "Check for invisible unicode or mid-string newlines.",
            env_var,
        )
    if not value.startswith(prefix):
        log.warning(
            "%s does not start with %r -- %s. Loaded key (first 8 chars): %r",
            env_var,
            prefix,
            description,
            value[:8],
        )
    # Gemini/Google keys are exactly 39 chars; OpenAI-style are longer-variable.
    # Only check length for the fixed-length family.
    if env_var in ("GEMINI_API_KEY", "GOOGLE_API_KEY") and len(value) != 39:
        log.warning(
            "%s is %d chars (expected 39). Likely truncated or has extra chars.",
            env_var,
            len(value),
        )


# -- Fallback: encrypted file storage --


def _fallback_exists() -> bool:
    return _FALLBACK_FILE.exists()


def _fallback_load() -> dict:
    if not _FALLBACK_FILE.exists():
        return {}
    try:
        return json.loads(_FALLBACK_FILE.read_text())
    except Exception:
        return {}


def _fallback_save(data: dict):
    _PHOENIX_DIR.mkdir(parents=True, exist_ok=True)
    _FALLBACK_FILE.write_text(json.dumps(data, indent=2))
    os.chmod(_FALLBACK_FILE, 0o600)


def _fallback_store(key: str, value: str):
    data = _fallback_load()
    data[key] = value
    _fallback_save(data)
    log.debug("Stored secret '%s' in %s", key, _FALLBACK_FILE)


def _fallback_get(key: str) -> str | None:
    data = _fallback_load()
    return data.get(key)


def _fallback_delete(key: str):
    data = _fallback_load()
    if key in data:
        del data[key]
        _fallback_save(data)
