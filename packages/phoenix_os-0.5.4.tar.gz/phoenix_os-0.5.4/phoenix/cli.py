"""Phoenix CLI entry point."""

import os

# huggingface_hub freezes these timeouts at module import, so they must be
# set before any import path pulls in `huggingface_hub.constants` (transitively
# via sentence-transformers / fastembed). Default 10s HEAD-check is too tight
# on slow networks -- reported on Windows first-run where the HEAD to
# processor_config.json times out before any bytes move.
os.environ.setdefault("HF_HUB_ETAG_TIMEOUT", "30")
os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "60")


def main():
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass

    from phoenix.main import run

    run()


if __name__ == "__main__":
    main()
