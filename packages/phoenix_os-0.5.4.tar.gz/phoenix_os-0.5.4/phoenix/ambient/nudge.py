"""Nudge engine -- single LLM call to decide: speak or SKIP."""

import logging

from .sentinel import Signal

log = logging.getLogger(__name__)


def format_signals(signals: list[Signal]) -> str:
    """Format signals into a compact list for the LLM."""
    lines = []
    for s in signals:
        payload_str = ", ".join(f"{k}={v}" for k, v in s.payload.items())
        lines.append(f"- {s.signal_type}: {payload_str} (priority: {s.priority})")
    return "\n".join(lines)


def _looks_like_auth_failure(err: BaseException) -> bool:
    """Heuristic: does this exception look like invalid credentials?

    Covers Gemini (`API_KEY_INVALID`, `API key not valid`), OpenAI (`401`,
    `Incorrect API key`), Anthropic (`authentication_error`). Conservative on
    purpose -- false positives permanently disable the nudge loop until
    restart, so we only trip on unambiguous signals.
    """
    text = str(err).lower()
    if "api_key_invalid" in text or "api key not valid" in text:
        return True
    if "incorrect api key" in text or "invalid api key" in text:
        return True
    if "authentication_error" in text or "authentication failed" in text:
        return True
    # `"401" in text` alone would match unrelated 4xx bodies that happen to
    # mention "api"; require the unambiguous "unauthor" stem.
    return "401" in text and "unauthor" in text


class NudgeEngine:
    """Decides whether to nudge the user. One LLM call, ~100 tokens."""

    def __init__(self, model: str):
        self._model = model
        # Trips permanently on the first auth-failure-class error so a bad
        # key doesn't loop every tick. Survives the session; user restarts
        # after fixing credentials.
        self._auth_disabled = False

    async def decide(
        self,
        signals: list[Signal],
        patterns: str = "",
    ) -> str | None:
        """Evaluate signals and return a nudge sentence, or None to skip.

        Returns:
            A single sentence to show the user, or None if not worth interrupting.
        """
        if self._auth_disabled or not signals:
            return None

        signal_text = format_signals(signals)

        prompt = f"""Background signals right now:
{signal_text}

{f"What you know about Boss's patterns:{chr(10)}{patterns}{chr(10)}" if patterns else ""}
You are Phoenix's ambient layer. Based on these signals, should you say something to Boss?
Rules:
- Only speak if genuinely useful. Do not be annoying.
- If you speak, ONE sentence max. Warm but direct.
- If not worth interrupting, respond with exactly: SKIP

Your response (one sentence or SKIP):"""

        try:
            from pydantic_ai import Agent

            agent = Agent(
                self._model,
                instructions="You are a minimal ambient notification system. Be concise.",
            )
            result = await agent.run(prompt)
            output = str(result.output).strip()

            if "SKIP" in output.upper():
                log.debug("Nudge engine: SKIP")
                return None

            nudge = output.strip().split("\n")[0][:200]
            log.info("Nudge: %s", nudge)
            return nudge

        except Exception as e:
            if _looks_like_auth_failure(e):
                self._auth_disabled = True
                log.warning(
                    "Nudge engine disabled: authentication failed (%s). "
                    "Fix the API key for model %r and restart Phoenix.",
                    e,
                    self._model,
                )
            else:
                log.warning("Nudge engine failed: %s", e)
            return None
