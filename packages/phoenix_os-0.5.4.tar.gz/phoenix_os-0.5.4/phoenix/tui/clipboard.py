"""Clipboard integration for Textual selection -> system clipboard.

Pattern adapted from mistral-vibe (vibe/cli/clipboard.py): layered
strategy list so copy works across SSH (OSC 52), macOS (pbcopy),
Linux X (xclip), Linux Wayland (wl-copy), and anywhere else pyperclip
knows how to reach the system clipboard.

`copy_selection_to_clipboard(app)` is the entry point. It walks every
widget in the app, harvests `widget.text_selection` / `get_selection()`
output (Textual 8.x in-app selection API), joins the fragments, and
writes them. Widgets that should never appear in copied output override
`text_selection` to return None -- see `NonSelectableMixin` in widgets.py.
"""

from __future__ import annotations

import base64
import logging
import os
import shutil
import subprocess
import sys
from collections.abc import Callable

from textual.app import App

log = logging.getLogger(__name__)

try:
    import pyperclip  # type: ignore[import-untyped]
except Exception:  # pragma: no cover - optional dep
    pyperclip = None


def _osc52_available() -> bool:
    # Windows has no /dev/tty; non-TTY contexts (piped stdin, CI, tests)
    # can't emit escape sequences to a terminal.
    if sys.platform == "win32":
        return False
    try:
        return os.path.exists("/dev/tty") and sys.stdout.isatty()
    except Exception:
        return False


def _copy_osc52(text: str) -> None:
    if not _osc52_available():
        raise RuntimeError("OSC 52 not available in this environment")
    encoded = base64.b64encode(text.encode("utf-8")).decode("ascii")
    seq = f"\033]52;c;{encoded}\a"
    if os.environ.get("TMUX"):
        seq = f"\033Ptmux;\033{seq}\033\\"
    with open("/dev/tty", "w") as tty:
        tty.write(seq)
        tty.flush()


def _copy_pyperclip(text: str) -> None:
    if pyperclip is None:
        raise RuntimeError("pyperclip not installed")
    pyperclip.copy(text)


def _copy_pbcopy(text: str) -> None:
    subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=True)


def _copy_xclip(text: str) -> None:
    subprocess.run(
        ["xclip", "-selection", "clipboard"],
        input=text.encode("utf-8"),
        check=True,
    )


def _copy_wl_copy(text: str) -> None:
    subprocess.run(["wl-copy"], input=text.encode("utf-8"), check=True)


def _paste_pyperclip() -> str:
    if pyperclip is None:
        raise RuntimeError("pyperclip not installed")
    return pyperclip.paste()


def _paste_pbpaste() -> str:
    return subprocess.run(["pbpaste"], capture_output=True, check=True).stdout.decode("utf-8")


def _paste_xclip() -> str:
    return subprocess.run(
        ["xclip", "-selection", "clipboard", "-o"],
        capture_output=True,
        check=True,
    ).stdout.decode("utf-8")


def _paste_wl_paste() -> str:
    return subprocess.run(["wl-paste"], capture_output=True, check=True).stdout.decode("utf-8")


def _has(cmd: str) -> bool:
    return shutil.which(cmd) is not None


# Strategy order matters. OSC 52 writes to the user's terminal-forwarded
# clipboard (the right answer over SSH) but has no reliable local readback
# -- the clipboard it writes to lives on the user's box, not inside
# Phoenix's process. If OSC 52 ran first and the verify step failed (it
# will, since we can't read what we wrote), the next writer would clobber
# the remote clipboard with a local-only value. So try readable writers
# first (pbcopy / xclip / wl-copy / pyperclip) and only fall back to
# OSC 52 when nothing else is installed.
_COPY_METHODS: list[Callable[[str], None]] = [
    m
    for m, ok in (
        (_copy_pbcopy, _has("pbcopy")),
        (_copy_xclip, _has("xclip")),
        (_copy_wl_copy, _has("wl-copy")),
        (_copy_pyperclip, pyperclip is not None),
        (_copy_osc52, _osc52_available()),
    )
    if ok
]

_PASTE_METHODS: list[Callable[[], str]] = [
    m
    for m, ok in (
        (_paste_pyperclip, pyperclip is not None),
        (_paste_pbpaste, _has("pbpaste")),
        (_paste_xclip, _has("xclip")),
        (_paste_wl_paste, _has("wl-paste")),
    )
    if ok
]


def _read_clipboard() -> str | None:
    for reader in _PASTE_METHODS:
        try:
            return reader()
        except Exception:
            continue
    return None


def _write_clipboard(text: str) -> None:
    """Try writers in order; stop on the first that readback-verifies.

    OSC 52 is special-cased: when it's the only writer that succeeded,
    trust it without readback (can't verify a remote terminal clipboard
    from here).
    """
    any_succeeded = False
    osc52_only_success = False
    for writer in _COPY_METHODS:
        try:
            writer(text)
        except Exception:
            continue
        any_succeeded = True
        if writer is _copy_osc52:
            osc52_only_success = True
            continue
        osc52_only_success = False
        if _read_clipboard() == text:
            return
    if osc52_only_success:
        return
    if not any_succeeded:
        raise RuntimeError("All clipboard strategies failed")


def _harvest_selections(app: App) -> list[str]:
    out: list[str] = []
    for widget in app.query("*"):
        try:
            selection = getattr(widget, "text_selection", None)
            if not selection:
                continue
            result = widget.get_selection(selection)
        except Exception:
            continue
        if not result:
            continue
        text = result[0] if isinstance(result, tuple) else result
        if isinstance(text, str) and text.strip():
            out.append(text)
    return out


def copy_selection_to_clipboard(app: App, show_toast: bool = True) -> str | None:
    """Harvest the current Textual selection, push to system clipboard.

    Returns the copied string on success, None if there was no selection
    or every clipboard strategy failed. Optional toast notifies the user.
    """
    fragments = _harvest_selections(app)
    if not fragments:
        return None
    combined = "\n".join(fragments)
    try:
        _write_clipboard(combined)
    except Exception as e:
        log.warning("clipboard copy failed: %s", e)
        if show_toast:
            app.notify(
                "Failed to copy -- clipboard not available",
                severity="warning",
                timeout=3,
            )
        return None
    if show_toast:
        app.notify(
            f"Copied {len(combined)} chars",
            severity="information",
            timeout=2,
            markup=False,
        )
    return combined
