"""Slash-command picker popup.

Appears when the user types `/` at the start of `ChatTextArea`, shows
a filtered list of available commands with their one-line descriptions,
and supports arrow-key navigation + Enter to insert the command into
the input. Esc dismisses. Modeled after the Claude Code slash picker.

Uses a Vertical container with pre-mounted Static rows (one per
viewport slot + two hint rows). Earlier revisions used a single Static
with multi-line Rich Text; Textual's auto-height caching on that
pattern collapsed the popup to one row after the first render.
Mounting fixed-count children is the reliable pattern for dropdowns.
"""

from __future__ import annotations

import inspect
import logging
from dataclasses import dataclass

from rich.text import Text
from textual.containers import Vertical
from textual.widgets import Static

log = logging.getLogger(__name__)

#: How many rows to show at once. Smaller windows feel like a proper
#: dropdown (Claude Code shows ~5); larger windows drown the input.
VIEWPORT_ROWS = 5

#: When the selection gets this close to either edge of the window, the
#: viewport pre-scrolls so the "next" row is already visible before the
#: user reaches it. Matches Claude Code's picker feel.
SCROLL_MARGIN = 1


@dataclass(frozen=True)
class CommandEntry:
    """One line in the picker: `/name <space> description`."""

    name: str
    description: str


def build_command_catalog() -> list[CommandEntry]:
    """Collect (name, description) pairs from every registered slash command."""
    from phoenix.shell.commands import COMMANDS

    catalog: list[CommandEntry] = []
    for name, handler in COMMANDS.items():
        catalog.append(CommandEntry(name=name, description=_extract_description(handler)))

    if not any(e.name == "/bye" for e in catalog):
        catalog.append(CommandEntry(name="/bye", description="Exit Phoenix (or Ctrl+D)"))

    catalog.sort(key=lambda e: e.name)
    return catalog


def _extract_description(handler) -> str:
    """First usable line of the handler's docstring, trimmed."""
    doc = inspect.getdoc(handler) or ""
    for line in doc.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("`") and "`" in s[1:]:
            s = s.replace("`", "")
        return s[:96]
    return ""


def filter_catalog(catalog: list[CommandEntry], prefix: str) -> list[CommandEntry]:
    """Return entries whose name starts with `prefix` (case-insensitive)."""
    q = (prefix or "").strip().lower()
    if not q or q == "/":
        return list(catalog)
    return [e for e in catalog if e.name.lower().startswith(q)]


class SlashCommandPopup(Vertical):
    """Bottom-docked dropdown listing matching slash commands.

    Children (mounted at compose time):
      - `_hint_above` Static -- "↑ N more" indicator
      - VIEWPORT_ROWS row Statics -- one per visible entry
      - `_hint_below` Static -- "↓ N more" indicator

    Each row is hidden (`display: none`) when unused, so the popup
    shrinks to exactly fit the filtered entry count. No multi-line
    text tricks, no auto-height caching to fight.
    """

    DEFAULT_CSS = """
    SlashCommandPopup {
        dock: bottom;
        height: auto;
        background: $surface;
        border-top: solid $primary-darken-1;
        padding: 0 1;
        display: none;
    }
    SlashCommandPopup.-active {
        display: block;
    }
    SlashCommandPopup > Static {
        height: 1;
    }
    """

    def __init__(self) -> None:
        super().__init__(id="slash-popup")
        self._catalog: list[CommandEntry] = []
        self.entries: list[CommandEntry] = []
        self._index: int = 0
        self._view_start: int = 0
        self._hint_above: Static | None = None
        self._hint_below: Static | None = None
        self._row_statics: list[Static] = []

    def compose(self):
        # Clear references in case compose() ever fires twice (screen
        # switch / parent recomposition). The render path guards slot
        # access with a bounds check, but duplicate mounts would leak
        # Statics that never get display=False'd.
        self._row_statics.clear()
        self._hint_above = Static("", id="slash-hint-above", markup=False)
        yield self._hint_above
        for i in range(VIEWPORT_ROWS):
            s = Static("", id=f"slash-row-{i}", markup=False)
            self._row_statics.append(s)
            yield s
        self._hint_below = Static("", id="slash-hint-below", markup=False)
        yield self._hint_below

    def on_mount(self) -> None:
        self._catalog = build_command_catalog()
        self.entries = list(self._catalog)

    @property
    def is_active(self) -> bool:
        return "-active" in self.classes

    def update_for(self, text: str) -> None:
        """Recompute entries for the current input and show/hide."""
        if not text.startswith("/"):
            self.hide()
            return
        self.entries = filter_catalog(self._catalog, text)
        if not self.entries:
            self.hide()
            return
        self._index = 0
        self._view_start = 0
        self._refresh()
        self.add_class("-active")

    def hide(self) -> None:
        self.remove_class("-active")
        self._index = 0
        self._view_start = 0

    def up(self) -> None:
        if not self.entries:
            return
        self._index = (self._index - 1) % len(self.entries)
        self._clamp_viewport()
        self._refresh()

    def down(self) -> None:
        if not self.entries:
            return
        self._index = (self._index + 1) % len(self.entries)
        self._clamp_viewport()
        self._refresh()

    def selected(self) -> str | None:
        if not self.entries:
            return None
        return self.entries[self._index].name

    def _clamp_viewport(self) -> None:
        """Slide the visible window so the selection stays at least
        SCROLL_MARGIN rows from each edge (so the next row is visible
        before the user reaches the last visible one)."""
        total = len(self.entries)
        if total <= VIEWPORT_ROWS:
            self._view_start = 0
            return

        if self._index >= self._view_start + VIEWPORT_ROWS - SCROLL_MARGIN:
            self._view_start = self._index - VIEWPORT_ROWS + SCROLL_MARGIN + 1
        elif self._index < self._view_start + SCROLL_MARGIN:
            self._view_start = self._index - SCROLL_MARGIN

        max_start = total - VIEWPORT_ROWS
        self._view_start = max(0, min(self._view_start, max_start))

    def _refresh(self) -> None:
        """Repaint each pre-mounted row based on current state.

        Uses `.display` on each child directly rather than CSS class
        toggling. The `SlashCommandPopup > Static.-visible` selector
        wasn't reliably re-matching after `add_class` on individual
        children in a Vertical container, so rows stayed invisible
        even though the logic path ran.
        """
        log.debug(
            "slash_popup._refresh: entries=%d rows_mounted=%d index=%d view_start=%d",
            len(self.entries),
            len(self._row_statics),
            self._index,
            self._view_start,
        )

        # Default everything to hidden; selectively show below.
        if self._hint_above is not None:
            self._hint_above.display = False
        if self._hint_below is not None:
            self._hint_below.display = False
        for row in self._row_statics:
            row.display = False

        if not self.entries:
            return

        start = self._view_start
        end = min(start + VIEWPORT_ROWS, len(self.entries))
        visible = self.entries[start:end]
        name_width = max(len(e.name) for e in self.entries) + 2

        hidden_above = start
        if hidden_above > 0 and self._hint_above is not None:
            t = Text(f"  ↑ {hidden_above} more", style="dim #a8a8a8")
            self._hint_above.update(t)
            self._hint_above.display = True

        for slot_i, entry in enumerate(visible):
            abs_idx = start + slot_i
            selected = abs_idx == self._index
            line = Text()
            if selected:
                line.append("> ", style="bold #7dcfff")
                name_style = "bold #7dcfff"
                desc_style = "#d7d7d7"
            else:
                line.append("  ", style="")
                name_style = "bold cyan"
                desc_style = "#808080"
            line.append(entry.name.ljust(name_width), style=name_style)
            if entry.description:
                line.append(entry.description, style=desc_style)

            if slot_i < len(self._row_statics):
                self._row_statics[slot_i].update(line)
                self._row_statics[slot_i].display = True
            else:
                log.warning(
                    "slash_popup: slot %d exceeds row_statics len %d -- skipping entry %r",
                    slot_i,
                    len(self._row_statics),
                    entry.name,
                )

        hidden_below = len(self.entries) - end
        if hidden_below > 0 and self._hint_below is not None:
            t = Text(f"  ↓ {hidden_below} more", style="dim #a8a8a8")
            self._hint_below.update(t)
            self._hint_below.display = True
