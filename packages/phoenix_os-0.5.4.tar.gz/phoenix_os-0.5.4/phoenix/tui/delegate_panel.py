"""Live sub-agent activity panel -- toggled by Ctrl+O.

Docks above the input bar (same slot as the slash popup, but they
never coexist). Hidden by default; becomes visible when Boss presses
Ctrl+O and hides again on the second press.

Subscribes to `phoenix.core.delegate_events` on mount and re-renders
on every event. No timer -- elapsed time ticks whenever the next
event fires, which is plenty for the MVP. If a longer-running delegate
ever feels stale between tool calls, add a `set_interval(1.0)` here.

Visibility is driven by the `-active` CSS class, NOT by
`self.display = True/False`. Early versions used the property-style
toggle and hit `'NoneType' has no attribute 'render_strips'` during
the first render frame (before compose finished mounting the child).
The slash popup uses the CSS-class pattern and never sees the crash;
we mirror it here for the same reason.

Layout per delegate:
    delegate: coder-3a4f  12.4s  tools: 5
      task: Refactor login handler to use new auth middleware...
      18:42:03  read_file(login.py)
      18:42:05  write_file(login.py)   <- in flight
"""

from __future__ import annotations

import logging
import time

from rich.text import Text
from textual.containers import Vertical
from textual.widgets import Static

from phoenix.core import delegate_events as bus

log = logging.getLogger(__name__)

# How many recent history entries to show per delegate. Small by design;
# the panel is a glance, not a transcript.
HISTORY_ROWS = 6


class DelegatePanel(Vertical):
    """Dock-bottom panel showing live delegate activity."""

    DEFAULT_CSS = """
    DelegatePanel {
        dock: bottom;
        height: 0;
        background: $surface;
        padding: 0;
        border: none;
        display: none;
    }
    DelegatePanel.-active {
        display: block;
        height: auto;
        max-height: 12;
        border-top: solid $accent;
        padding: 0 3;
    }
    DelegatePanel > Static {
        height: auto;
        width: 1fr;
    }
    """

    def __init__(self, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._body: Static | None = None

    # ----------------------------------------------------------- lifecycle

    def compose(self):
        # markup=False: we hand Static a Rich Text object whose styling
        # is already baked in. Leaving markup on would double-interpret
        # any stray [brackets] in task previews or tool-arg snippets.
        body = Static("", id="delegate-body", markup=False)
        self._body = body
        yield body

    def on_mount(self) -> None:
        bus.subscribe(self._on_event)

    def on_unmount(self) -> None:
        bus.unsubscribe(self._on_event)

    # ------------------------------------------------------------- toggle

    def toggle(self) -> None:
        if self.has_class("-active"):
            self.remove_class("-active")
            # Clear the body before collapsing so no ghost text survives
            # in Textual's render cache. Without this, an old render can
            # leave a 1-cell border-top visible after the panel hides
            # (observed with dock:bottom + conditional border CSS).
            if self._body is not None:
                self._body.update("")
        else:
            self.add_class("-active")
            # Defer the first refresh to the next tick so the layout has
            # settled after adding `.-active`. Calling `_refresh_body`
            # synchronously before Textual has re-laid-out the widget
            # can re-enter the render path mid-transition; the
            # earlier first-render crash class lived right here.
            self.call_later(self._refresh_body)

    # ------------------------------------------------------- event handler

    def _on_event(self, event: bus.DelegateEvent) -> None:
        # Re-render only when the panel is actually visible. Hidden
        # events still update the bus's active-registry, so the next
        # `toggle()` will pick them up.
        if not self.has_class("-active"):
            return
        try:
            if event.type in ("done", "error") and not bus.list_active():
                # Last delegate just finished -- collapse the panel so
                # the orange border-top does not linger on-screen with
                # a "no active delegate" placeholder. The user can
                # always Ctrl+O again to see the next one.
                self.call_later(self._auto_hide)
            else:
                self.call_later(self._refresh_body)
        except Exception:
            log.exception("delegate panel render failed")

    def _auto_hide(self) -> None:
        # Race recheck: a new delegate can start between the "done"
        # event that scheduled this hide and the hide actually firing.
        # Brain-delegates-A -> A finishes -> scheduler queues hide ->
        # brain-delegates-B (sub-second later) -> hide fires, panel
        # collapses, B runs invisible until Boss hits Ctrl+O again.
        # If anything's still active, re-render instead of hiding.
        if bus.list_active():
            self._refresh_body()
            return
        self.remove_class("-active")
        if self._body is not None:
            self._body.update("")

    # ------------------------------------------------------------- render
    #
    # NOTE: do NOT name this `_render` -- Textual's Widget._render() is an
    # internal that must return a Visual. Overriding it breaks the render
    # loop with "'NoneType' has no attribute 'render_strips'" on every
    # frame. `_refresh_body` is the Phoenix-specific redraw hook; it
    # updates the body Static and leaves Textual's own render path alone.

    def _refresh_body(self) -> None:
        if self._body is None:
            return
        active = bus.list_active()
        if not active:
            self._body.update(Text("no active delegate", style="dim"))
            return

        now = time.time()
        text = Text()
        for i, record in enumerate(active):
            if i > 0:
                text.append("\n")
            _render_delegate(text, record, now)
        self._body.update(text)


def _render_delegate(text: Text, record: bus.ActiveDelegate, now: float) -> None:
    """One delegate's block: header, task, recent tool log."""
    elapsed = now - record.started_at

    # Header row
    text.append("delegate: ", style="bold")
    text.append(f"{record.agent}-{record.delegate_id.split('-', 1)[-1]}", style="bold cyan")
    text.append(f"  {elapsed:.1f}s", style="yellow")
    text.append(f"  tools: {record.tool_count}", style="dim")
    text.append("\n")

    # Task preview
    if record.task_preview:
        text.append("  task: ", style="dim")
        text.append(record.task_preview, style="italic")
        text.append("\n")

    # Recent tool-call log (filter to tool_call events, newest last)
    tool_events = [e for e in record.history if e.type == "tool_call"]
    recent = tool_events[-HISTORY_ROWS:]
    if not recent:
        text.append("  waiting...", style="dim")
        return
    for j, ev in enumerate(recent):
        ts = time.strftime("%H:%M:%S", time.localtime(ev.ts))
        is_last = j == len(recent) - 1 and record.last_tool == ev.tool_name
        text.append(f"  {ts}  ", style="dim")
        text.append(ev.tool_name, style="green" if not is_last else "bold green")
        if ev.tool_args_preview:
            text.append(f"({ev.tool_args_preview})", style="dim")
        if is_last:
            text.append("  <- in flight", style="yellow")
        if j < len(recent) - 1:
            text.append("\n")
