"""Custom Textual widgets for the Phoenix TUI."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import re
from pathlib import Path

from rich.console import RenderableType
from rich.text import Text
from textual import events
from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.widgets import Markdown, Static, TextArea
from textual.widgets._markdown import MarkdownStream

from phoenix.tui.messages import ChatInputSubmitted


def _cwd_label() -> str:
    cwd = Path.cwd()
    home = Path.home()
    if cwd == home:
        return "~"
    try:
        return f"~/{cwd.relative_to(home)}"
    except ValueError:
        return str(cwd)


class NonSelectableMixin:
    """Opt a widget out of Textual's in-app text selection.

    Drags across widgets with this mixin will not contribute to the
    string harvested by `phoenix.tui.clipboard.copy_selection_to_clipboard`.
    Use on chrome that updates on a timer (HeaderBar, StatusBar, spinners)
    or pure layout affordances (input bar). See mistral-vibe's
    NonSelectableStatic for the pattern.
    """

    @property
    def text_selection(self):  # type: ignore[override]
        return None

    @text_selection.setter
    def text_selection(self, _value) -> None:  # type: ignore[override]
        pass

    def get_selection(self, _selection):  # type: ignore[override]
        return None


# ----------------------------------------------------------------- Header


class HeaderBar(NonSelectableMixin, Static):
    """Top bar showing title, version, model and cwd."""

    DEFAULT_CSS = """
    HeaderBar {
        dock: top;
        height: 2;
        padding: 0 2;
        background: $surface;
    }
    """

    def __init__(self) -> None:
        super().__init__(id="header-bar")

    def on_mount(self) -> None:
        self._refresh()

    def _refresh(self) -> None:
        from phoenix import __version__
        from phoenix.config.settings import get_model

        model = get_model()
        t = Text()
        t.append("Phoenix", style="bold #ff6b35")
        t.append(f"  v{__version__}", style="#6c6c6c")
        t.append("    ")
        if ":" in model:
            prov, name = model.split(":", 1)
            t.append(prov, style="#5fafff")
            t.append(":", style="#6c6c6c")
            t.append(name, style="")
        else:
            t.append(model, style="#5fafff")
        t.append("\n")
        t.append(f"  {_cwd_label()}", style="#6c6c6c")
        self.update(t)


# ----------------------------------------------------------------- StatusBar


class StatusBar(NonSelectableMixin, Static):
    """Bottom status line -- mode, bg tasks, topic, tokens, turn."""

    DEFAULT_CSS = """
    StatusBar {
        dock: bottom;
        height: 1;
        padding: 0 1;
        background: #1c1c1c;
        color: #d7d7d7;
    }
    """

    def __init__(self, engine, state) -> None:
        super().__init__(id="status-bar")
        self._engine = engine
        self._state = state
        self._spinner_frames = [
            "\u28f7",
            "\u28ef",
            "\u28df",
            "\u287f",
            "\u28bf",
            "\u28fb",
            "\u28fd",
            "\u28fe",
        ]
        self._spin = 0

    def on_mount(self) -> None:
        self.set_interval(0.3, self._tick)
        self._tick()

    def _tick(self) -> None:
        from phoenix.core.interceptor import (
            AutoApprovalBackend,
            get_approval_backend,
        )

        backend = get_approval_backend()
        mode = "safe"
        if isinstance(backend, AutoApprovalBackend):
            mode = backend.mode

        t = Text()
        # Mode
        mode_color = {"safe": "#00af5f", "auto": "#ffaf00", "yolo": "#ff5f5f"}.get(mode, "#d7d7d7")
        t.append("\u25cf ", style=mode_color)
        t.append(mode, style=mode_color)
        t.append("  \u2022  ", style="#555555")

        # Turn phase
        phase = getattr(self._state, "stream_phase", "idle")
        if phase != "idle":
            frame = self._spinner_frames[self._spin % len(self._spinner_frames)]
            self._spin += 1
            if phase == "thinking":
                label = "thinking"
            elif phase == "streaming":
                label = "streaming"
            elif phase == "working":
                label = "running tool"
            else:
                label = phase
            t.append(f"{frame} {label}", style="#ffaf5f italic")
            t.append("  \u2022  ", style="#555555")

        # Queue depth
        queued = getattr(self._state, "queued", 0)
        if queued:
            t.append(f"{queued} queued", style="#d75fd7")
            t.append("  \u2022  ", style="#555555")

        # Topic
        tt = getattr(self._engine, "topic_tracker", None)
        if tt and getattr(tt, "active_topic", None):
            title = getattr(tt.active_topic, "title", "") or ""
            if title:
                t.append(f"topic: {title[:28]}", style="#6c6c6c")
                t.append("  \u2022  ", style="#555555")

        # Memory
        mem = getattr(self._engine, "_memory", None)
        if mem:
            try:
                n = mem.stats().get("total", 0)
                if n:
                    t.append(f"{n} mem", style="#6c6c6c")
                    t.append("  \u2022  ", style="#555555")
            except Exception:
                pass

        # Tokens
        total = self._state.usage_input + self._state.usage_output
        if total:
            t.append(f"{total:,} tok", style="#6c6c6c")
            t.append("  \u2022  ", style="#555555")

        # Turn counter
        if self._state.turn_count:
            t.append(f"turn {self._state.turn_count}", style="#6c6c6c")
            t.append("  \u2022  ", style="#555555")

        t.append("^d exit · ^c cancel · ^l clear · \u21e7tab mode", style="#555555")

        self.update(t)


# ----------------------------------------------------------------- Message widgets


class ChatMessage(Static):
    """Base class for all chat entries. Each entry gets its own widget."""

    DEFAULT_CSS = """
    ChatMessage {
        height: auto;
        width: 1fr;
        margin: 0 0 1 0;
        padding: 0 0;
    }
    """

    def __init__(self, renderable: RenderableType = "") -> None:
        super().__init__(renderable, markup=False)


class UserMessageW(ChatMessage):
    def __init__(self, text: str) -> None:
        t = Text()
        t.append("\u203a ", style="bold #87d75f")
        t.append(text, style="#87d75f")
        super().__init__(t)


class AssistantMessageW(ChatMessage):
    """Live-streaming assistant message via Textual's MarkdownStream (8.x).

    Replaces the per-chunk `self.update(Text(buffer))` pattern (O(N^2) in
    stream length) with a Markdown widget + MarkdownStream that coalesces
    fragments in a background task and parses only unparsed lines. Per-token
    cost becomes O(1). Pattern adapted from mistralai/mistral-vibe.
    """

    DEFAULT_CSS = """
    AssistantMessageW {
        margin: 0 0 1 0;
    }
    """

    def __init__(self) -> None:
        super().__init__("")
        self._markdown: Markdown | None = None
        self._stream: MarkdownStream | None = None
        self._content: str = ""
        self._finalized: bool = False
        # Serialises append_content and finalize. Textual dispatches async
        # message handlers concurrently on the same widget, so StreamEnd's
        # finalize() could race with an in-flight final StreamChunk's
        # append_content() and stop the MarkdownStream mid-write -- dropping
        # the last token.
        self._write_lock = asyncio.Lock()

    def compose(self) -> ComposeResult:
        self._markdown = Markdown("")
        yield self._markdown

    async def append_content(self, chunk: str) -> None:
        """Append a streaming chunk. Lazy-initialises the MarkdownStream.

        If `compose()` has not yet run (widget mid-mount), content accumulates
        in `self._content` and is flushed on the first call made after mount.
        """
        if self._finalized or not chunk:
            return
        async with self._write_lock:
            if self._finalized:
                return
            self._content += chunk
            if self._markdown is None:
                return  # mount hasn't completed; next call after mount will flush
            if self._stream is None:
                # First write after mount -- create stream, write accumulated
                self._stream = Markdown.get_stream(self._markdown)
                await self._stream.write(self._content)
            else:
                await self._stream.write(chunk)

    async def finalize(self, full_text: str | None = None) -> None:
        """Close the stream. Called on StreamEnd. Waits for any in-flight
        append_content() to finish before stopping the MarkdownStream."""
        if self._finalized:
            return
        async with self._write_lock:
            if self._finalized:
                return
            self._finalized = True
            # If caller provided full_text (authoritative), make sure any
            # trailing delta that didn't make it into the stream gets written.
            if full_text is not None and full_text != self._content:
                tail = (
                    full_text[len(self._content) :] if full_text.startswith(self._content) else ""
                )
                if tail:
                    self._content = full_text
                    if self._stream is None and self._markdown is not None:
                        self._stream = Markdown.get_stream(self._markdown)
                        await self._stream.write(self._content)
                    elif self._stream is not None:
                        await self._stream.write(tail)
            # Safety net for the Windows starting-token-truncation case: if
            # every append_content() landed before compose() ran, self._stream
            # stays None but self._content holds the full text. Create the
            # stream here and flush, so the text actually renders instead of
            # vanishing when we set self._finalized.
            if self._stream is None and self._content and self._markdown is not None:
                self._stream = Markdown.get_stream(self._markdown)
                await self._stream.write(self._content)
            if self._stream is not None:
                await self._stream.stop()
                self._stream = None
            if not self._content.strip():
                self.display = False
            else:
                # Scan finalized content for mermaid code blocks. For each
                # block we can render, mount a MermaidDiagramW under the
                # markdown so it animates in below the prose. Raw code
                # block stays visible above the diagram -- if rendering
                # fails (binary missing, malformed source) the user still
                # sees the source they could copy-paste elsewhere.
                await self._mount_mermaid_diagrams()

    _MERMAID_BLOCK_RE = re.compile(
        r"```mermaid\s*\n(.*?)\n```",
        re.DOTALL | re.IGNORECASE,
    )

    async def _mount_mermaid_diagrams(self) -> None:
        from phoenix.tui.mermaid_render import render_mermaid
        from phoenix.tui.mermaid_widget import MermaidDiagramW

        for match in self._MERMAID_BLOCK_RE.finditer(self._content):
            source = match.group(1).strip()
            if not source:
                continue
            rendered = render_mermaid(source)
            if rendered is None:
                # Optional dep missing or render failed; raw code block
                # is still visible in the markdown above. No-op.
                continue
            try:
                await self.mount(MermaidDiagramW(rendered))
            except Exception:
                log = logging.getLogger(__name__)
                log.exception("MermaidDiagramW mount failed")


class ToolCallMessageW(ChatMessage):
    """Unified tool-call widget. Starts in "pending" state (call header + live
    spinner), transitions in place to "done" (call header + result body) when
    the matching result arrives. The two states were previously separate
    widgets (ToolCallMessageW + ToolResultMessageW) which rendered out-of-
    order because tool events were reconstructed from stream.all_messages()
    after the stream finished. Now events arrive live via
    agent.run_stream_events so one widget per call is the natural shape.
    """

    DEFAULT_CSS = """
    ToolCallMessageW {
        height: auto;
        width: 1fr;
        margin: 0 0 1 0;
    }
    """

    _SPINNER_FRAMES = [
        "\u28f7",
        "\u28ef",
        "\u28df",
        "\u287f",
        "\u28bf",
        "\u28fb",
        "\u28fd",
        "\u28fe",
    ]

    def __init__(self, name: str, args, tool_call_id: str = "") -> None:
        import time as _t

        self.tool_call_id = tool_call_id
        self._tool_name = name
        self._args_blob = self._format_args(args)
        self._state: str = "pending"  # pending | done | error
        self._result_text: str = ""
        self._spinner_i: int = 0
        self._start_time: float = _t.monotonic()
        self._spinner_interval = None
        # Render the initial header synchronously so Textual's first layout
        # pass has a real Text renderable (passing "" then deferring update
        # until on_mount causes a None-visual race during mount).
        super().__init__(self._build_renderable())

    @staticmethod
    def _format_args(args) -> str:
        import json

        if isinstance(args, str):
            with contextlib.suppress(Exception):
                args = json.loads(args)
        if isinstance(args, dict):
            try:
                blob = json.dumps(args, ensure_ascii=False, default=str)
            except Exception:
                blob = str(args)
        else:
            blob = str(args)
        if len(blob) > 160:
            blob = blob[:157] + "\u2026"
        return blob

    def on_mount(self) -> None:
        # Only tick the spinner while pending; 0.1s is cheap.
        self._spinner_interval = self.set_interval(0.1, self._tick_spinner)

    def on_unmount(self) -> None:
        # Defensive cleanup: stop the interval so no late tick fires
        # self._render() against a torn-down widget (produces a NoneType
        # get_height error during test teardown or turn cancellation).
        if self._spinner_interval is not None:
            with contextlib.suppress(Exception):
                self._spinner_interval.stop()
            self._spinner_interval = None

    def _tick_spinner(self) -> None:
        if self._state != "pending":
            return
        # Guard against a stray tick after unmount.
        if not self.is_mounted:
            return
        self._spinner_i += 1
        self._refresh_view()

    def set_result(self, content: str, is_error: bool = False) -> None:
        """Called by the TUI when the matching FunctionToolResultEvent lands."""
        self._result_text = content or ""
        self._state = "error" if is_error else "done"
        if self._spinner_interval is not None:
            with contextlib.suppress(Exception):
                self._spinner_interval.stop()
            self._spinner_interval = None
        self._refresh_view()

    def _refresh_view(self) -> None:
        self.update(self._build_renderable())
        # Force re-measure: height was measured as 1 line during "pending"
        # state; once we append the result body the widget needs to grow.
        # Without refresh(layout=True) the body clips under the header.
        with contextlib.suppress(Exception):
            self.refresh(layout=True)

    def _build_renderable(self) -> Text:
        import time as _t

        t = Text()
        # --- header: glyph + name + condensed args ---
        if self._state == "pending":
            glyph = self._SPINNER_FRAMES[self._spinner_i % len(self._SPINNER_FRAMES)]
            glyph_style = "#ffaf5f"
            name_style = "bold #ffaf5f"
        elif self._state == "error":
            glyph = "\u2717"  # cross
            glyph_style = "bold #ff5f5f"
            name_style = "bold #ff5f5f"
        else:  # done
            glyph = "\u2713"  # check
            glyph_style = "#87d75f"
            name_style = "bold #5fafff"

        t.append(f"{glyph} ", style=glyph_style)
        t.append(self._tool_name, style=name_style)
        if self._args_blob:
            t.append("  ")
            t.append(self._args_blob, style="#888888")

        # elapsed timer while pending, after 1s
        if self._state == "pending":
            elapsed = _t.monotonic() - self._start_time
            if elapsed >= 1.0:
                t.append(f"  ({int(elapsed)}s)", style="#6c6c6c")

        # --- body: result preview when done/error ---
        if self._state in ("done", "error"):
            lines = self._result_text.rstrip().splitlines()
            body_style = "#ff8787" if self._state == "error" else "#87afaf"
            if not lines:
                t.append("\n")
                t.append("  \u2514 ", style="#555555")
                t.append("(empty)", style="#555555")
            else:
                limit = 6
                visible = lines[:limit]
                for i, line in enumerate(visible):
                    last = i == len(visible) - 1 and len(lines) <= limit
                    prefix = "  \u2514 " if last else "  \u2502 "
                    t.append("\n")
                    t.append(prefix, style="#555555")
                    t.append(line[:400], style=body_style)
                if len(lines) > limit:
                    t.append("\n")
                    t.append("  \u2514 ", style="#555555")
                    t.append(f"\u2026 (+{len(lines) - limit} lines)", style="#555555")

        return t


# Back-compat shim: kept importable for any external caller. No longer
# mounted by the app; tool results fold into ToolCallMessageW.
class ToolResultMessageW(ChatMessage):
    DEFAULT_CSS = """
    ToolResultMessageW {
        margin: 0 0 1 0;
    }
    """

    def __init__(self, name: str, result: str) -> None:
        t = Text()
        t.append("  \u2514 ", style="#555555")
        t.append((result or "(empty)").splitlines()[0][:200], style="#87afaf")
        super().__init__(t)


class StatusLineW(ChatMessage):
    DEFAULT_CSS = """
    StatusLineW {
        margin: 0;
    }
    """

    def __init__(self, text: str) -> None:
        t = Text()
        t.append("  \u00b7 ", style="#6c6c6c")
        t.append(text, style="#87afaf")
        super().__init__(t)


class BangResultW(ChatMessage):
    """Output of a `!cmd` shell-escape invocation.

    Renders the echoed command and its stdout/stderr in a compact block --
    distinct from assistant output so the user sees it's a direct shell
    result, not a tool-call. Exit code surfaces on non-zero only.
    """

    DEFAULT_CSS = """
    BangResultW {
        margin: 0 0 1 0;
    }
    """

    MAX_OUTPUT_CHARS = 8_000

    def __init__(self, cmd: str, output: str, returncode: int) -> None:
        super().__init__(self._build(cmd, output, returncode))

    @classmethod
    def _build(cls, cmd: str, output: str, returncode: int) -> Text:
        t = Text()
        t.append("$ ", style="bold #87d75f")
        t.append(cmd, style="#87d75f")
        body = output.rstrip("\n")
        if len(body) > cls.MAX_OUTPUT_CHARS:
            body = body[: cls.MAX_OUTPUT_CHARS] + f"\n... (truncated at {cls.MAX_OUTPUT_CHARS})"
        if body:
            t.append("\n")
            t.append(body, style="#bcbcbc")
        if returncode != 0:
            t.append(f"\n(exit {returncode})", style="#d75f5f")
        return t


class NotifyLineW(ChatMessage):
    def __init__(self, text: str) -> None:
        t = Text()
        t.append("  \u26a1 ", style="#ffd75f")
        t.append(text, style="")
        super().__init__(t)


class AskUserLineW(ChatMessage):
    """Rendered when `ask_user` is awaiting an answer. The next input line
    goes to the ability's future instead of starting a new turn."""

    def __init__(self, question: str, options: str = "") -> None:
        t = Text()
        t.append("  ? ", style="bold #ffaf5f")
        t.append(question, style="bold")
        if options:
            t.append("\n      options: ", style="#6c6c6c")
            t.append(options, style="#ffd75f")
        t.append("\n      ", style="")
        t.append("type your answer below -- ESC to cancel", style="#6c6c6c italic")
        super().__init__(t)


class ErrorLineW(ChatMessage):
    def __init__(self, text: str) -> None:
        t = Text()
        t.append("  \u2717 ", style="bold #ff5f5f")
        t.append(text, style="#ff5f5f")
        super().__init__(t)


class UsageLineW(ChatMessage):
    def __init__(self, inp: int, out: int) -> None:
        total = inp + out
        t = Text()
        t.append(f"  tokens: {total:,} ", style="#6c6c6c")
        t.append(f"(in {inp:,} · out {out:,})", style="#555555")
        super().__init__(t)


class WorkingLineW(NonSelectableMixin, ChatMessage):
    """Live indicator shown while the stream is stalled (tool in flight)."""

    DEFAULT_CSS = """
    WorkingLineW {
        margin: 0 0 1 0;
    }
    """

    _FRAMES = ["\u28f7", "\u28ef", "\u28df", "\u287f", "\u28bf", "\u28fb", "\u28fd", "\u28fe"]

    def __init__(self, label: str = "working") -> None:
        super().__init__("")
        self._label = label
        self._i = 0
        self._start: float = 0.0

    def on_mount(self) -> None:
        import time as _t

        self._start = _t.monotonic()
        self.set_interval(0.1, self._tick)
        self._tick()

    def _tick(self) -> None:
        import time as _t

        frame = self._FRAMES[self._i % len(self._FRAMES)]
        self._i += 1
        elapsed = _t.monotonic() - self._start
        t = Text()
        t.append(f"  {frame} ", style="#ffaf5f")
        t.append(self._label, style="#ffaf5f italic")
        if elapsed >= 1:
            t.append(f"  ({int(elapsed)}s)", style="#6c6c6c")
        self.update(t)


class WelcomeW(ChatMessage):
    def __init__(
        self, version: str, model: str, cwd: str, abilities: int, agents: int, memories: int = 0
    ) -> None:
        self._abilities = abilities
        self._agents = agents
        self._memories = memories
        super().__init__(self._build())

    def _build(self) -> Text:
        t = Text()
        parts = [f"{self._abilities} abilities", f"{self._agents} agents"]
        if self._memories:
            parts.append(f"{self._memories} memories")
        t.append("  \u00b7  ".join(parts), style="#87afaf")
        return t

    def update_memories(self, n: int) -> None:
        """Patch the memory count after async stats() returns."""
        self._memories = n
        self.update(self._build())


# ----------------------------------------------------------------- ChatInput


class ChatTextArea(TextArea):
    """Multi-line chat input with history, paste support, slash picker.

    Why TextArea instead of Input: `Input` is single-line by construction
    and cannot word-wrap or accept multi-line paste. Users writing
    prompts that span multiple lines (code snippets, logs, prose) need
    the content to wrap within the input area and submit as a single
    message. TextArea handles all of that natively; the submit gesture
    just has to be remapped since Enter is TextArea's default "insert
    newline".

    Key bindings:
      - Enter                  -> submit the current text
      - Shift+Enter / Ctrl+J   -> insert a literal newline
      - Up (when empty or at line 0) -> command history back
      - Down (when in history) -> command history forward
      - / at doc position 0    -> open SlashCommandPopup
    """

    DEFAULT_CSS = """
    ChatTextArea {
        height: auto;
        min-height: 1;
        max-height: 8;
        border: none;
        padding: 0;
        scrollbar-size-vertical: 0;
    }
    """

    def __init__(self, history: list[str] | None = None) -> None:
        super().__init__(
            "",
            id="chat-input",
            soft_wrap=True,
            show_line_numbers=False,
        )
        self._history: list[str] = history if history is not None else []
        self._history_idx: int | None = None
        self._draft_before_history: str = ""

    def _popup(self):
        """Lazy lookup so construction order doesn't matter."""
        with contextlib.suppress(Exception):
            from phoenix.tui.slash_popup import SlashCommandPopup

            return self.app.query_one(SlashCommandPopup)
        return None

    def _submit_current(self) -> None:
        """Fire `ChatInputSubmitted` with the current text and clear it."""
        text = self.text.rstrip()
        if not text:
            return
        self._history.append(text)
        self._history_idx = None
        self.text = ""
        popup = self._popup()
        if popup is not None:
            popup.hide()
        self.post_message(ChatInputSubmitted(text))

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        """Every edit updates the slash-picker based on the current text.

        The picker only cares about `/`-prefixed single-line input, so
        we pass the full text through -- `update_for` filters on its
        own. Enables the dropdown on `/`, filters as more chars are
        typed, hides once the user backspaces past the slash or adds
        a newline (text no longer starts with `/`).
        """
        popup = self._popup()
        if popup is not None:
            popup.update_for(self.text)

    def on_key(self, event: events.Key) -> None:
        popup = self._popup()
        picker_active = popup is not None and popup.is_active

        # --- slash-picker navigation ---
        if picker_active:
            if event.key == "up":
                popup.up()
                event.stop()
                event.prevent_default()
                return
            if event.key == "down":
                popup.down()
                event.stop()
                event.prevent_default()
                return
            if event.key == "escape":
                popup.hide()
                event.stop()
                event.prevent_default()
                return
            if event.key == "enter":
                chosen = popup.selected()
                if chosen:
                    self.text = chosen + " "
                    self.cursor_location = self.document.end
                    popup.hide()
                event.stop()
                event.prevent_default()
                return

        # --- submit / newline ---
        # Shift+Enter and Ctrl+J insert a literal newline so the user
        # can compose multi-line messages. Plain Enter submits.
        if event.key in ("shift+enter", "ctrl+j"):
            self.insert("\n")
            event.stop()
            event.prevent_default()
            return
        if event.key == "enter":
            self._submit_current()
            event.stop()
            event.prevent_default()
            return

        # --- history navigation ---
        # Only hijack Up/Down when we're at the edges of the document.
        # Inside a multi-line buffer the user needs the arrows to move
        # the cursor around. `cursor_at_first_line` / `_last_line`
        # check row index; column doesn't matter.
        at_first_row = self.cursor_location[0] == 0
        at_last_row = self.cursor_location[0] == self.document.line_count - 1

        if event.key == "up" and at_first_row:
            if self._history:
                if self._history_idx is None:
                    self._draft_before_history = self.text
                    self._history_idx = len(self._history)
                if self._history_idx > 0:
                    self._history_idx -= 1
                    self.text = self._history[self._history_idx]
                    self.cursor_location = self.document.end
            event.stop()
            event.prevent_default()
            return

        if event.key == "down" and at_last_row and self._history_idx is not None:
            if self._history_idx < len(self._history) - 1:
                self._history_idx += 1
                self.text = self._history[self._history_idx]
            else:
                self._history_idx = None
                self.text = self._draft_before_history
                self._draft_before_history = ""
            self.cursor_location = self.document.end
            event.stop()
            event.prevent_default()
            return


class ChatInputBar(NonSelectableMixin, Horizontal):
    """Bottom input bar: '>' prompt + ChatTextArea."""

    DEFAULT_CSS = """
    ChatInputBar {
        dock: bottom;
        height: auto;
        max-height: 8;
        min-height: 1;
        background: $surface;
        padding: 0 1 0 1;
    }
    #input-prompt {
        width: 3;
        color: #ff6b35;
        text-style: bold;
        content-align: left top;
    }
    """

    def __init__(self, history: list[str] | None = None) -> None:
        super().__init__(id="input-bar")
        self._history = history if history is not None else []

    def compose(self):
        yield Static("\u203a ", id="input-prompt")
        yield ChatTextArea(history=self._history)

    def focus_input(self) -> None:
        self.query_one(ChatTextArea).focus()
