"""Static mermaid-flowchart widget.

Takes a pre-rendered ASCII frame from `mermaid_render.render_mermaid`
and shows it plain. Earlier revisions line-by-line-revealed via
`set_interval`; Boss asked for plain (no animation) after comparing
the animated reveal to the final frame.

Layout concerns:
- mermaid-ascii output is wider than it is tall for branchy charts.
  Widget has `overflow-x: auto` so wide charts scroll horizontally
  instead of overflowing / wrapping into garbage.
- markup=False on the Static -- brackets / braces / pipes in labels
  must not be reinterpreted as Rich markup.
"""

from __future__ import annotations

import logging

from rich.text import Text
from textual.widgets import Static

log = logging.getLogger(__name__)


class MermaidDiagramW(Static):
    """Rendered mermaid ASCII chart, shown plain below an assistant message."""

    DEFAULT_CSS = """
    MermaidDiagramW {
        height: auto;
        width: 1fr;
        padding: 1 2;
        background: $surface;
        color: $text;
        /* Branchy charts frequently exceed terminal width; let the chart
           scroll horizontally instead of breaking layout. The vertical
           axis is unlimited -- chat already scrolls on the outer pane. */
        overflow-x: auto;
        overflow-y: hidden;
        scrollbar-size-horizontal: 1;
    }
    """

    def __init__(self, rendered: str, *, id: str | None = None) -> None:
        # Pass the Text renderable directly; markup=False keeps node
        # labels with brackets / braces from being reinterpreted.
        super().__init__(Text(rendered), id=id, markup=False)
