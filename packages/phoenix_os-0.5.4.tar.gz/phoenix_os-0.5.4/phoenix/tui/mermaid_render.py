"""Mermaid -> Unicode-box ASCII via the vendored beautiful-mermaid-py.

We vendor a pure-Python port of Craft.do's `beautiful-mermaid` renderer
(MIT). It uses a grid layout + A* pathfinding and honors `flowchart TD`
correctly. The prior approach (subprocess to `osl-packages/mermaid-ascii`
Go binary) hit two upstream bugs -- multi-root node duplication and
style-declaration leak -- that have been unfixed for 15+ months.

Vendored from:
  https://github.com/Orbiter/beautiful-mermaid-py
  Commit pinned: d5daa97c8e3f (2026-04-15)

Per-session cache keyed on a hash of the source so the same diagram
re-renders for free if the model emits it twice.
"""

from __future__ import annotations

import hashlib
import logging
import re

log = logging.getLogger(__name__)

_cache: dict[str, str] = {}

# Forces `flowchart TD` if the model emitted nothing, or `graph` without
# direction. Does NOT override an explicit `flowchart LR` -- the model
# may have a reason, and LR charts can still be valid under horizontal
# scroll. The brain prompt already pushes hard for TD.
_MISSING_HEADER_RE = re.compile(r"^\s*(?:flowchart|graph)\b", re.MULTILINE)


def is_available() -> bool:
    """True iff the vendored renderer imports cleanly. Should always be
    True in a shipping install; the probe exists so callers can fall
    back to raw code in the unlikely case of an import error."""
    try:
        from phoenix.tui.vendor import beautiful_mermaid  # noqa: F401

        return True
    except Exception:
        return False


def _normalize_header(source: str) -> str:
    """Ensure the source declares a flowchart direction.

    Upstream expects a `flowchart TD` / `graph LR` / etc. header line.
    If the model forgot, prepend `flowchart TD` so the parser has
    something to work with instead of silently rendering an empty
    canvas.
    """
    if _MISSING_HEADER_RE.search(source):
        return source
    return "flowchart TD\n" + source


def render_mermaid(source: str) -> str | None:
    """Render a mermaid source string to a Unicode-box ASCII diagram.

    Returns None if the source is empty or the renderer raises -- callers
    should treat None as "fall back to showing the raw code block".
    Never raises.
    """
    if not source or not source.strip():
        return None

    key = hashlib.sha1(source.encode("utf-8"), usedforsecurity=False).hexdigest()
    if key in _cache:
        return _cache[key]

    try:
        from phoenix.tui.vendor.beautiful_mermaid import render_mermaid_ascii
    except Exception as e:
        log.debug("mermaid_render: vendored module import failed: %s", e)
        return None

    try:
        rendered = render_mermaid_ascii(_normalize_header(source))
    except Exception as e:
        # The vendored parser is defensive but not bulletproof -- malformed
        # source can still raise. Log and fall back so the chat doesn't
        # break on a bad diagram.
        log.info("mermaid_render: parse/render raised: %s", e)
        return None

    if not rendered or not rendered.strip():
        return None

    _cache[key] = rendered
    return rendered


def clear_cache() -> None:
    """Drop the per-session cache. Test helper."""
    _cache.clear()
