"""Ask the user a question -- human-in-the-loop ability."""

from phoenix.abilities import ability
from phoenix.abilities._ask_bridge import ask


@ability(name="ask_user", description="Ask the user a question when genuinely ambiguous")
async def ask_user(question: str, options: str = "") -> str:
    """Ask Boss a question. Use sparingly -- only when genuinely ambiguous.

    Args:
        question: The question to ask.
        options: Comma-separated choices (optional). Empty = free-text answer.
    """
    return (await ask(question, options)).strip()
