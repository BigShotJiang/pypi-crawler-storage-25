"""Abilities framework -- @ability decorator, registry, and PhoenixContext."""

import inspect
import logging
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


@dataclass
class AbilityInfo:
    name: str
    description: str
    func: Callable
    is_async: bool
    needs_context: bool


@dataclass
class PhoenixContext:
    """Injected into abilities that declare a ctx: PhoenixContext parameter."""

    config: dict = field(default_factory=dict)
    memory: Any = None
    log: Callable = field(default_factory=lambda: print)
    agent_name: str = ""
    work_dir: Path = field(default_factory=Path.cwd)
    # Per-turn scratch space. Engine clears this at the top of `run_stream`.
    # Lets pre-turn pipelines (e.g. WebRetrievalProvider) deposit results
    # that abilities (`web_search`) can read to dedupe redundant fetches in
    # the same turn. Outside that window, the cache is empty.
    turn_cache: dict = field(default_factory=dict)


_ABILITY_REGISTRY: dict[str, AbilityInfo] = {}


def ability(
    name: str,
    description: str,
    requires_env: list[str] | None = None,
):
    """Register a function as a Phoenix ability.

    The decorator stores metadata and returns the function unchanged.
    Pydantic-ai reads function signatures and docstrings natively.

    Args:
        name: tool name exposed to the LLM
        description: short description exposed to the LLM
        requires_env: if any listed env var is missing at decoration time,
            the ability is NOT registered. The LLM never sees it as a
            tool option, so it can't attempt to call something that will
            just fail. Registration is resolved ONCE at import time by
            `registry.discover_abilities()` (which runs after
            `load_secrets_to_env()` and `apply_config()`), so keyring-
            stored keys count as "set".

    Usage:
        @ability(name="bash", description="Execute shell commands")
        async def bash(command: str) -> str:
            ...

        @ability(
            name="web_search",
            description="Search the web",
            requires_env=["BRAVE_API_KEY"],
        )
        async def web_search(query: str) -> str:
            ...
    """

    def decorator(func: Callable) -> Callable:
        if requires_env:
            missing = [v for v in requires_env if not os.environ.get(v)]
            if missing:
                log.info(
                    "ability.skip: %s not registered (missing env: %s)",
                    name,
                    ", ".join(missing),
                )
                return func

        sig = inspect.signature(func)
        needs_ctx = any(
            p.annotation is PhoenixContext or p.annotation == "PhoenixContext"
            for p in sig.parameters.values()
        )

        _ABILITY_REGISTRY[name] = AbilityInfo(
            name=name,
            description=description,
            func=func,
            is_async=inspect.iscoroutinefunction(func),
            needs_context=needs_ctx,
        )
        return func

    return decorator


def get_ability_registry() -> dict[str, AbilityInfo]:
    return _ABILITY_REGISTRY
