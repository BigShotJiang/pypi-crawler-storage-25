"""Shell command execution with safety checks."""

import asyncio
import contextlib
import logging
import os
import re
import subprocess
import time

from phoenix.abilities import ability
from phoenix.abilities._secret_redact import with_notice as _redact

log = logging.getLogger(__name__)

TIMEOUT = 120
MAX_OUTPUT = 16_000

# If a foreground `bash` command is still running past this many seconds we
# assume it's a server / watcher / long build and promote it to a background
# process so the brain gets control back. The model sees a promotion string
# instead of sitting on the 120s timeout. Override with PHOENIX_BASH_PROMOTE_SEC.
PROMOTE_AFTER_SEC = 20.0

DENY_PATTERNS = [
    r"\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+.*)?/\s*$",
    r"\bmkfs\b",
    r"\bdd\s+if=",
    r":\(\)\{.*\}",
    r"\bchmod\s+-R\s+777\s+/\s*$",
    r"\b(shutdown|reboot|halt|poweroff)\b",
    r">\s*/dev/sd[a-z]",
    # Destructive git writes. Phoenix never commits/pushes/tags on its own
    # -- Boss drives those via the host shell's /commit and /commit-sync
    # skills. Denying at the bash layer closes the coder-with-yolo-approval
    # gap the python-code-analyzer flagged (prompt-only boundaries were the
    # sole guard; yolo mode auto-approves bash). Read-only git (status,
    # log, diff, branch, remote, show, rev-parse, describe) stays on the
    # ALLOWLIST and works as before via the `git_info` ability.
    r"\bgit\s+commit\b",
    r"\bgit\s+push\b",
    r"\bgit\s+tag\b",
    r"\bgit\s+reset\s+--hard\b",
    r"\bgit\s+rebase\b",
    r"\bgit\s+checkout\s+--",
    r"\bgit\s+clean\s+-[a-zA-Z]*f",
    r"\bgit\s+branch\s+-D\b",
]

ALLOWLIST = [
    "ls",
    "pwd",
    "echo",
    "cat",
    "head",
    "tail",
    "wc",
    "date",
    "whoami",
    "which",
    "type",
    "file",
    "stat",
    "du",
    "df",
    "uname",
    "env",
    "printenv",
    "python3 -c",
    "python -c",
    "node -e",
    "uptime",
    "vm_stat",
    "ps",
    "top -l",
    "sysctl",
    "sw_vers",
    "system_profiler",
    "hostinfo",
    "arch",
    "nproc",
    "free",
    "lscpu",
    "mount",
    "ifconfig",
    "hostname",
    "id",
    "groups",
    "lsof",
    "find",
    "tree",
    "curl -s",
    "wget -q",
    "dig",
    "nslookup",
    "ping -c",
    "traceroute",
    "md5",
    "shasum",
    "sort",
    "uniq",
    "diff",
    "less",
    "more",
    "grep",
    "rg",
    "jq",
    "xargs",
    "dirname",
    "basename",
    "realpath",
    "git status",
    "git log",
    "git diff",
    "git branch",
    "git remote",
    "git show",
    "git rev-parse",
    "git describe",
    "pip list",
    "pip show",
    "pip freeze",
    "pip3 list",
    "pip3 show",
    "npm list",
    "npm ls",
    "npm view",
    "npm info",
    "brew list",
    "brew info",
    "brew doctor",
]

DANGEROUS_OPERATORS = re.compile(r"[;&`$\(]")


def _is_safe(command: str) -> bool:
    cmd = command.strip()

    # Block truly dangerous chaining: ; && ` $() backticks
    if DANGEROUS_OPERATORS.search(cmd):
        return False

    # Allow pipes if every segment starts with an allowlisted command
    if "|" in cmd:
        segments = [s.strip() for s in cmd.split("|")]
        return all(any(seg.startswith(prefix) for prefix in ALLOWLIST) for seg in segments)

    return any(cmd.startswith(prefix) for prefix in ALLOWLIST)


def _safe_env():
    env = os.environ.copy()
    env["CI"] = "true"
    env["NONINTERACTIVE"] = "1"
    return env


def _get_promote_after() -> float:
    raw = os.environ.get("PHOENIX_BASH_PROMOTE_SEC")
    if not raw:
        return PROMOTE_AFTER_SEC
    try:
        value = float(raw)
    except ValueError:
        return PROMOTE_AFTER_SEC
    return value if value > 0 else PROMOTE_AFTER_SEC


def _run_subprocess(command: str, timeout: int, cwd: str) -> str:
    run_cwd = cwd if cwd and os.path.isdir(cwd) else os.getcwd()
    start = time.monotonic()
    log.info("bash.exec: cwd=%s cmd=%s", run_cwd, command[:200])
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=run_cwd,
            env=_safe_env(),
        )
        elapsed = time.monotonic() - start
        stdout = result.stdout[:MAX_OUTPUT]
        stderr = result.stderr[:MAX_OUTPUT]
        output = stdout.strip()
        if result.returncode != 0 and stderr.strip():
            output += f"\n[stderr]: {stderr.strip()}"
        log.info(
            "bash.done: exit=%d dur=%.2fs stdout=%dB stderr=%dB",
            result.returncode,
            elapsed,
            len(stdout),
            len(stderr),
        )
        # Redact secret-looking values (env-file lines, API-key tokens,
        # JSON credential fields) before the output reaches the model.
        # See phoenix/abilities/_secret_redact.py for the rules.
        if output:
            return _redact(output)
        return f"(no output, exit code {result.returncode})"
    except subprocess.TimeoutExpired:
        log.warning("bash.timeout: cmd=%s after %ds", command[:200], timeout)
        return f"Error: command timed out after {timeout}s"
    except Exception as e:
        log.exception("bash.error: cmd=%s", command[:200])
        return f"Error: {e}"


async def _run_with_promotion(command: str, timeout: int, cwd: str) -> str:
    """Run a command in the foreground but promote to background if it
    outlasts PROMOTE_AFTER_SEC. Returns either the normal bash output or a
    promotion string pointing at the new bg_id.

    Relaunch semantics (read before trusting): on the promotion branch we
    kill the foreground subprocess and RELAUNCH the SAME command under
    the background manager. Dev servers, `tail -f`, watchers, and
    idempotent build steps (cmake with a warm cache) tolerate this. But
    commands that are doing side-effectful work mid-flight -- `pip
    install`, `npm install`, `apt`, `docker build`, database migrations,
    `git clone` into an existing dir -- can have their partial state
    corrupted by a restart. The model should pick `bash_bg` explicitly
    for those cases. The promotion return string warns the caller; the
    TUI surfaces it verbatim so the user sees what happened.
    """
    from phoenix.core.bg_processes import get_manager

    run_cwd = cwd if cwd and os.path.isdir(cwd) else os.getcwd()
    promote_at = _get_promote_after()
    start = time.monotonic()
    log.info("bash.exec: cwd=%s cmd=%s (promote@%.0fs)", run_cwd, command[:200], promote_at)

    proc = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        cwd=run_cwd,
        env=_safe_env(),
        start_new_session=True,
    )

    captured: list[str] = []

    async def _drain() -> None:
        assert proc.stdout is not None
        while True:
            line = await proc.stdout.readline()
            if not line:
                return
            captured.append(line.decode("utf-8", errors="replace"))

    drain_task = asyncio.create_task(_drain())

    def _cleanup_orphan() -> None:
        # Called from the outer `finally` if we bail mid-run (cancelled
        # by parent timeout, unexpected exception). Don't leak the
        # subprocess or the drain task.
        if proc.returncode is None:
            with contextlib.suppress(Exception):
                os.killpg(proc.pid, 9)
        if not drain_task.done():
            drain_task.cancel()

    try:
        with contextlib.suppress(TimeoutError):
            await asyncio.wait_for(proc.wait(), timeout=promote_at)

        if proc.returncode is None:
            partial_raw = "".join(captured)[-MAX_OUTPUT:].rstrip()
            partial = _redact(partial_raw) if partial_raw else partial_raw
            # `start_new_session=True` above made proc.pid the new session's
            # pgid, so signal the pgid directly rather than round-tripping
            # through getpgid() -- a race where getpgid() returns Phoenix's
            # own pgid would SIGKILL us. Suppressed on a dead group.
            with contextlib.suppress(Exception):
                os.killpg(proc.pid, 9)
            with contextlib.suppress(Exception):
                await proc.wait()
            drain_task.cancel()
            with contextlib.suppress(Exception):
                await drain_task

            manager = get_manager()
            bg = await manager.start(command, workdir=run_cwd)
            log.info("bash.promoted: %s -> %s after %.1fs", bg.bg_id, command[:80], promote_at)
            partial_block = f"\n\n--- captured before promotion ---\n{partial}" if partial else ""
            return (
                f"Command still running at {promote_at:.0f}s; the foreground "
                f"process was TERMINATED and the same command RELAUNCHED as "
                f"background {bg.bg_id}. WARNING: this is safe for dev servers, "
                f"watchers, and idempotent builds, but mid-flight installs / "
                f"migrations / `docker build` / `git clone` may be left in a "
                f"partial state by the restart. For known long-running commands "
                f"use `bash_bg` next time so there's no restart. Use "
                f"`bash('bg logs {bg.bg_id}')` (or /bg in the shell) to see "
                f"output, `bash('bg stop {bg.bg_id}')` to kill.{partial_block}"
            )

        try:
            await asyncio.wait_for(drain_task, timeout=1.0)
        except TimeoutError:
            drain_task.cancel()

        elapsed = time.monotonic() - start
        code = proc.returncode
        output = "".join(captured)[:MAX_OUTPUT].rstrip()
        log.info(
            "bash.done: exit=%d dur=%.2fs out=%dB",
            code,
            elapsed,
            len(output),
        )
        if not output:
            return f"(no output, exit code {code})"
        return _redact(output)
    except Exception as e:
        log.exception("bash.error: cmd=%s", command[:200])
        return f"Error: {e}"
    finally:
        # Covers asyncio.CancelledError (e.g. parent delegate timed out
        # while this bash call was mid-flight) -- Exception above does not
        # catch it, so without this finally the subprocess would linger.
        _cleanup_orphan()


@ability(name="bash", description="Execute shell commands with safety checks")
async def bash(command: str, workdir: str = "", timeout: int = TIMEOUT) -> str:
    """Run a shell command and return output.

    If the command is still running after ~20s (`PHOENIX_BASH_PROMOTE_SEC`)
    it is auto-promoted to a background process so the brain gets control
    back. Use `bash_bg` for commands you already know are long-running
    (dev servers, watchers, daemons).

    Args:
        command: The shell command to execute.
        workdir: Working directory. Empty = the directory Phoenix was launched from.
        timeout: Max seconds before kill. Default 120. Only applies to
            commands that finish in the foreground (promoted commands ignore it).
    """
    for pattern in DENY_PATTERNS:
        if re.search(pattern, command):
            return "Blocked: command matches dangerous pattern"

    if not _is_safe(command):
        from phoenix.core.interceptor import get_approval_backend

        backend = get_approval_backend()
        desc = f"$ {command}" + (f"  (in {workdir})" if workdir else "")
        approved = await backend.request_approval("bash", desc, {"command": command})
        if not approved:
            return "(command rejected by user)"

    cwd = workdir if workdir else os.getcwd()
    return await _run_with_promotion(command, timeout, cwd)


@ability(
    name="bash_bg",
    description=(
        "Run a long-lived shell command (dev server, watcher, daemon) in "
        "the background and return a bg_id. Use this for `npm run dev`, "
        "`flask run`, `uvicorn`, `tail -f`, `docker compose up`, etc. For "
        "one-shot commands use `bash` instead."
    ),
)
async def bash_bg(command: str, workdir: str = "", warmup_sec: float = 3.0) -> str:
    """Launch a command as a background process and return its id + warmup output.

    Args:
        command: The shell command to run. Subject to the same deny-patterns
            and approval gate as `bash`.
        workdir: Working directory. Empty = Phoenix's launch dir.
        warmup_sec: Seconds to wait before returning so the output preview
            has something useful (e.g. "vite ready on :5173"). Default 3.
    """
    from phoenix.core.bg_processes import get_manager

    for pattern in DENY_PATTERNS:
        if re.search(pattern, command):
            return "Blocked: command matches dangerous pattern"

    if not _is_safe(command):
        from phoenix.core.interceptor import get_approval_backend

        backend = get_approval_backend()
        desc = f"[bg] $ {command}" + (f"  (in {workdir})" if workdir else "")
        approved = await backend.request_approval(
            "bash_bg", desc, {"command": command, "workdir": workdir}
        )
        if not approved:
            return "(command rejected by user)"

    manager = get_manager()
    bg = await manager.start(command, workdir=workdir)
    preview = await manager.collect_initial_output(bg, seconds=max(0.0, float(warmup_sec)))
    # Redact any env-file or token-shaped secrets that showed up in the
    # warmup output (e.g. dev server printing loaded env on startup).
    preview_safe = _redact(preview) if preview else preview
    if not bg.is_running:
        code = bg._exit_code if bg._exit_code is not None else bg.proc.returncode
        tail = preview_safe or "(no output)"
        return f"bg process {bg.bg_id} exited immediately (code={code}).\n{tail}"
    snippet = f"\n--- first {warmup_sec:.0f}s ---\n{preview_safe}" if preview_safe else ""
    return (
        f"Started {bg.bg_id}: {command}\n"
        f"Status: running. Use `bash('bg logs {bg.bg_id}')` or /bg to tail, "
        f"`bash('bg stop {bg.bg_id}')` to kill.{snippet}"
    )
