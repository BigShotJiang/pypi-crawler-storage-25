"""Notes -- Phoenix's deliberate observation surface, backed by memory.

Thin façade over `MemorySystem.ingest_intentional` + `RecallEngine.recall`.
There is no separate `notes.db` any more; notes live in `memory.db` with
`category="note"` and `intent="intentional"`, so they inherit the full
cognitive pipeline -- gate dedup, contradiction supersession, access-count
strengthening, decay on neglect, and consolidation clustering.

Why it matters (principle.md: "memory is the nervous system, not storage"):
- Three copies of "Finance Help" collapse through the gate's contradiction
  branch instead of accumulating forever.
- Stale notes like "Saturday Morning Check-in" lose strength across days
  and drop below the recall threshold without anyone pruning them.
- Durable observations like "Harshal's hyperfocus pattern" strengthen on
  every access and compound into load-bearing recall signal.
- `/memory why`, `/memory trace`, `/memory forget` work on notes too.

From the model's side the action surface is unchanged:
  write  -- record a deliberate note
  list   -- show active notes (sorted by strength desc)
  search -- semantic query over notes only
  update -- rewrite a note (routes through gate; contradiction supersedes)
  resolve / archive -- drop strength so the note decays out of recall
  delete -- hard-delete (user-explicit only, like `/memory forget`)
"""

from phoenix.abilities import PhoenixContext, ability

# Factor applied to strength on resolve/archive. Leaves the row in place but
# pushes it below the recall threshold. Decay finishes the job naturally.
_RESOLVE_STRENGTH_FACTOR = 0.3

_LIST_LIMIT = 50  # cap active notes surfaced per list call


@ability(
    name="notes",
    description=(
        "Phoenix's deliberate notebook. Unified with memory: notes are "
        "high-salience memories with category='note'. Actions: write, list, "
        "search, update, resolve, archive, delete."
    ),
)
async def notes(
    ctx: PhoenixContext,
    action: str,
    title: str = "",
    content: str = "",
    category: str = "",
    related_topic: str = "",
    note_id: str = "",
    status: str = "",
    query: str = "",
) -> str:
    """Manage Phoenix's deliberate notes.

    Args:
        action: write | list | search | update | resolve | archive | delete
        title: Short heading (combined with content when writing)
        content: Main body (for write/update)
        category: Subcategory hint -- prefixed onto content for recall
                  (observation, decision, project, reference, todo, insight)
                  The memory-side category is always "note"; this is a label.
        related_topic: Topic link -- prefixed onto content so it matches on recall
        note_id: Target memory id (for update/resolve/archive/delete)
        status: IGNORED -- legacy field; resolved/archived notes just
                have low strength, they're not a separate state
        query: Search string (search action)
    """
    memory = ctx.memory if ctx is not None else None
    if memory is None:
        return "Memory system not available."

    # Every path below hits `memory.store.*` directly. Connect the DB once
    # up front; `_ensure_initialized` is cheap after the first call.
    await memory._ensure_initialized()

    act = action.strip().lower()
    if act == "write":
        return await _write(memory, title, content, category, related_topic)
    if act == "list":
        return await _list(memory, related_topic, category)
    if act == "search":
        q = query or content or title
        return await _search(memory, q, category)
    if act == "update":
        return await _update(memory, note_id, title, content, category, related_topic)
    if act in ("resolve", "archive"):
        return await _weaken(memory, note_id, act)
    if act == "delete":
        return await _delete(memory, note_id)
    return f"Unknown action: {action}. Use: write, list, search, update, resolve, archive, delete"


def _compose(title: str, content: str, category: str = "", related_topic: str = "") -> str:
    """Merge the structured fields into a single searchable body.

    Keeps the title-then-content shape the old SQLite version stored, and
    prefixes category / topic so recall can match on them semantically.
    """
    parts = []
    if category:
        parts.append(f"[{category}]")
    if related_topic:
        parts.append(f"({related_topic})")
    head = " ".join(parts)
    # A nested ternary here is harder to read; keep the block form.
    if title and content and title != content:  # noqa: SIM108
        body = f"{title}: {content}"
    else:
        body = content or title
    return f"{head} {body}".strip() if head else body


async def _write(memory, title: str, content: str, category: str, related_topic: str) -> str:
    body = _compose(title, content, category, related_topic)
    if not body:
        return "Refused: empty note. Provide title and/or content."
    result = await memory.ingest_intentional(body, category="note")
    action = result["action"]
    if action == "ADD":
        return f"Noted [{result['id'][:10]}]: {body[:120]}"
    if action == "UPDATE":
        return f"Superseded prior note; new id [{result['id'][:10]}]: {body[:120]}"
    if action == "NOOP":
        return f"Already noted (reinforced existing id [{result.get('existing_id', '')[:10]}])"
    return f"Skipped: {result.get('reason', 'not novel enough')}"


async def _list(memory, related_topic: str, category: str) -> str:
    # Server-side category filter so the limit applies to notes only --
    # without this, notes with lower strength than 150 unrelated facts
    # vanish from the listing entirely on an active DB.
    rows = await memory.store.search_text(
        "", namespace="global", limit=_LIST_LIMIT, category="note"
    )
    if related_topic:
        rows = [r for r in rows if related_topic.lower() in (r.get("content") or "").lower()]
    if category:
        rows = [r for r in rows if category.lower() in (r.get("content") or "").lower()]
    notes_only = rows
    if not notes_only:
        return "No notes yet."
    lines = [f"Notes ({len(notes_only)}):"]
    for r in notes_only:
        mid = r.get("id", "")[:10]
        strength = float(r.get("strength", 0.0))
        low_strength_marker = " (fading)" if strength < 0.5 else ""
        preview = (r.get("content") or "").replace("\n", " ")[:120]
        lines.append(f"  [{mid}] {preview}{low_strength_marker}")
    return "\n".join(lines)


async def _search(memory, query: str, category: str) -> str:
    q = query.strip()
    if not q:
        return "Provide a query string."
    results = await memory._recall.recall(
        q, namespace="global", category_filter="note", record_access=False
    )
    if not results:
        return f"No notes matching '{q[:60]}'."
    lines = [f"Notes matching '{q[:60]}' ({len(results)}):"]
    for r in results:
        mid = r.get("id", "")[:10]
        rel = r.get("relevance", 0.0)
        preview = (r.get("content") or "").replace("\n", " ")[:120]
        lines.append(f"  [{mid}] ({rel:.2f}) {preview}")
    return "\n".join(lines)


async def _update(
    memory, note_id: str, title: str, content: str, category: str, related_topic: str
) -> str:
    if not note_id:
        return "Provide note_id to update."
    old = await memory.store.get(note_id)
    if old is None:
        return f"No such note: [{note_id}]"
    body = _compose(title, content, category, related_topic)
    if not body:
        return "Refused: empty update."
    # Ingest FIRST, then delete the old -- if the gate returns FILTER
    # ("not novel" or output-overlap), we'd otherwise delete the old
    # note with no replacement written, silent data loss.
    result = await memory.ingest_intentional(body, category="note")
    action = result["action"]
    if action in ("ADD", "UPDATE"):
        await memory.store.delete(note_id)
        return f"Updated [{note_id[:10]} -> {result['id'][:10]}]: {body[:120]}"
    if action == "NOOP":
        # Gate said "we already have this" -- safe to drop the old since
        # the existing row now represents both.
        await memory.store.delete(note_id)
        return f"Update matched existing note; consolidated [{note_id[:10]}]."
    # FILTER: keep the old, tell the caller the write was rejected.
    return f"Update rejected by memory gate (action={action}); original [{note_id[:10]}] preserved."


async def _weaken(memory, note_id: str, verb: str) -> str:
    if not note_id:
        return f"Provide note_id to {verb}."
    row = await memory.store.get(note_id)
    if row is None:
        return f"No such note: [{note_id}]"
    if row.get("category") != "note":
        return f"[{note_id[:10]}] is not a note (category={row.get('category')})."
    new_strength = max(0.0, float(row.get("strength", 1.0)) * _RESOLVE_STRENGTH_FACTOR)
    await memory.store.update_strength(note_id, new_strength)
    return f"{verb.capitalize()}d [{note_id[:10]}] (strength {new_strength:.2f} -- will fade from recall)."


async def _delete(memory, note_id: str) -> str:
    if not note_id:
        return "Provide note_id to delete."
    row = await memory.store.get(note_id)
    if row is None:
        return f"No such note: [{note_id}]"
    await memory.store.delete(note_id)
    return f"Deleted [{note_id[:10]}]"
