"""Secret redaction for tool output.

Prevents `bash cat .env`, `read_file .env.local`, or an incautious
`bash_bg` log from leaking API keys and credentials back to the LLM
(and into memory / transcripts / bug reports). Applied at the point
where tool output leaves the ability and enters the agent loop --
intentionally conservative, favouring false positives over misses.

Three redaction strategies, in order:

1. **env-assignment lines** (`KEY=value`, `export KEY=value`) -- the common
   `.env` / `.env.local` / shell-profile shape. Key name is kept so the
   model retains structural awareness; value is replaced with a length
   marker. Matches whether or not the value is quoted.
2. **known API-key prefixes** -- unambiguous vendor-issued tokens
   (`sk-...`, `sk-ant-...`, `AIza...`, `ghp_...`, `gsk_...`, `xai-...`,
   etc.). Replaced inline anywhere in the text.
3. **JSON credential fields** -- common schema `"key": "value"` where
   the key name is itself a secret-indicator (`api_key`, `secret`,
   `token`, `password`, `credential`). Value replaced.

Not covered (by design): long opaque base64/hex blobs (too many false
positives against URLs, hashes, content); nested binary; custom app
token shapes. Callers that handle structured credential stores should
not pipe that content through bash output in the first place.
"""

from __future__ import annotations

import re

# Env-assignment: optional `export `, ALL-CAPS key (>= 2 chars), `=`,
# then the value to end-of-line. Value may be quoted. We capture the
# key so we can preserve it in the redacted output.
_ENV_LINE = re.compile(
    r"""(?mx)                      # multiline + verbose
    ^\s*(?:export\s+)?             # optional leading export
    ([A-Z_][A-Z0-9_]{1,63})        # captured key (ALL CAPS-ish)
    \s*=\s*                        # assignment
    (                              # captured value
        "[^"\n]*"                  # double-quoted
        | '[^'\n]*'                # single-quoted
        | [^\s#][^\n#]*            # unquoted (no leading whitespace/#)
    )
    """,
)

# Known API-key token shapes. Anchored to non-alphanumeric on each side
# so we don't redact matching substrings inside larger identifiers.
_API_KEY_PATTERNS = [
    re.compile(r"\bsk-ant-[A-Za-z0-9_-]{20,}\b"),  # Anthropic
    re.compile(r"\bsk-proj-[A-Za-z0-9_-]{20,}\b"),  # OpenAI project
    re.compile(r"\bsk-[A-Za-z0-9]{32,}\b"),  # OpenAI legacy
    re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b"),  # Google
    re.compile(r"\bgsk_[A-Za-z0-9]{40,}\b"),  # Groq
    re.compile(r"\bghp_[A-Za-z0-9]{30,}\b"),  # GitHub PAT
    re.compile(r"\bgho_[A-Za-z0-9]{30,}\b"),  # GitHub OAuth
    re.compile(r"\bghu_[A-Za-z0-9]{30,}\b"),  # GitHub user-to-server
    re.compile(r"\bghs_[A-Za-z0-9]{30,}\b"),  # GitHub server-to-server
    re.compile(r"\bghr_[A-Za-z0-9]{30,}\b"),  # GitHub refresh
    re.compile(r"\bxai-[A-Za-z0-9]{40,}\b"),  # xAI
    re.compile(r"\bhf_[A-Za-z0-9]{30,}\b"),  # Hugging Face
    re.compile(r"\br8_[A-Za-z0-9]{36,}\b"),  # Replicate
    re.compile(r"\bdp_[A-Za-z0-9]{30,}\b"),  # DeepSeek (observed)
    # Supabase service-role / anon keys are JWTs; redact anything that
    # smells like a long three-segment JWT.
    re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
]

# JSON / YAML credential fields: key name hints at secret. Handles
# `"api_key": "v"`, `'secret': 'v'`, `API_KEY: v` (YAML).
_JSON_CRED = re.compile(
    r"""(?ix)
    (['"]?)                        # optional quote around key
    ( [a-z_]*(?:                   # key name contains a secret hint
        api[_-]?key | secret | token | password | passwd
        | credential | auth | bearer | private[_-]?key
    )[a-z_]* )
    \1                             # matching quote
    \s*[:=]\s*                     # separator (JSON/YAML both)
    (['"])                         # opening quote of value
    ([^'"\n]{4,})                  # the secret value itself
    \3                             # matching close quote
    """,
)


def _mark(value: str) -> str:
    """Standard redaction marker that preserves length hint."""
    stripped = value.strip()
    # Strip surrounding quotes if present so the length is value-only.
    if len(stripped) >= 2 and stripped[0] in ("'", '"') and stripped[-1] == stripped[0]:
        quote = stripped[0]
        inner = stripped[1:-1]
        return f"{quote}<REDACTED {len(inner)} chars>{quote}"
    return f"<REDACTED {len(stripped)} chars>"


def redact_secrets(text: str) -> tuple[str, int]:
    """Return (redacted_text, num_redactions).

    Caller should prepend a user-facing notice when the count is > 0
    so downstream (model + user) can tell that the raw output was
    sanitised. Redaction is idempotent -- running twice has no effect
    beyond the first pass.
    """
    if not text:
        return text, 0

    count = 0

    def _env_sub(match: re.Match) -> str:
        nonlocal count
        count += 1
        key = match.group(1)
        value = match.group(2)
        return f"{key}={_mark(value)}"

    out = _ENV_LINE.sub(_env_sub, text)

    for pattern in _API_KEY_PATTERNS:

        def _tok_sub(match: re.Match) -> str:
            nonlocal count
            count += 1
            tok = match.group(0)
            prefix = tok[:4]
            return f"{prefix}<REDACTED {len(tok)} chars>"

        out = pattern.sub(_tok_sub, out)

    def _json_sub(match: re.Match) -> str:
        nonlocal count
        count += 1
        key_quote = match.group(1)
        key_name = match.group(2)
        val_quote = match.group(3)
        value = match.group(4)
        return (
            f"{key_quote}{key_name}{key_quote}: {val_quote}<REDACTED {len(value)} chars>{val_quote}"
        )

    out = _JSON_CRED.sub(_json_sub, out)

    return out, count


def with_notice(text: str) -> str:
    """Redact `text` and, if anything was masked, prepend a one-line
    notice so the model and the user both know redaction happened.
    """
    redacted, n = redact_secrets(text)
    if n > 0:
        return f"[phoenix: redacted {n} secret-looking value(s) from this output]\n" + redacted
    return redacted
