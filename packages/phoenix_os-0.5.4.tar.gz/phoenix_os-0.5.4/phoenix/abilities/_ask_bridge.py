"""Bridge that lets the `ask_user` ability route its prompt through the UI.

`input()` from inside a tool call deadlocks under Textual because the TUI owns
stdin -- the agent blocks forever waiting for a newline that can never land.
This module is a tiny indirection: the TUI installs an async handler at mount
time, and `ask_user` awaits it. Headless / test code that never installs a
handler falls back to stdin, which is correct for non-TUI contexts.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable

AskHandler = Callable[[str, str], Awaitable[str]]

_handler: AskHandler | None = None


def set_ask_handler(handler: AskHandler | None) -> None:
    """Install a coroutine that renders the prompt in the UI and returns the answer."""
    global _handler
    _handler = handler


async def ask(question: str, options: str = "") -> str:
    """Ask the user a question via the installed handler, or fall back to stdin."""
    if _handler is not None:
        return await _handler(question, options)
    prompt = (
        f"\n  [Phoenix asks] {question}\n  Options: {options}\n  > "
        if options
        else f"\n  [Phoenix asks] {question}\n  > "
    )
    answer = await asyncio.to_thread(input, prompt)
    return answer.strip()
