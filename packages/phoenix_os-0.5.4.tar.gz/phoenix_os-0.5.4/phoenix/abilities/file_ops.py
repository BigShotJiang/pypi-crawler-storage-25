"""File operations -- read, write, search/replace."""

import difflib
import os
import re

from phoenix.abilities import ability
from phoenix.abilities._secret_redact import with_notice as _redact_secrets

MAX_READ_BYTES = 64_000
# Write cap is defensive, not budget-based: model output tokens already cap
# realistic writes (~128 KB for a max-output Opus turn). 1 MB catches
# pathological LLM output without blocking normal generated-file writes, which
# routinely run 32-200 KB for test fixtures, schemas, and large modules.
# Previous 64 KB cap caused coder/worker to fail large writes and exhaust
# retries (issue #13).
MAX_WRITE_BYTES = 1_000_000

_RAW_PROTECTED = [
    "/etc",
    "/usr",
    "/bin",
    "/sbin",
    "/boot",
    "/dev",
    "/proc",
    "/sys",
    "/var/log",
    "/var/run",
    os.path.expanduser("~/.ssh"),
    os.path.expanduser("~/.gnupg"),
    os.path.expanduser("~/.aws/credentials"),
]
PROTECTED_PATHS = list({os.path.realpath(p) for p in _RAW_PROTECTED} | set(_RAW_PROTECTED))

BLOCK_PATTERN = re.compile(
    r"<<<<<<< SEARCH\n(.*?)\n=======\n(.*?)\n>>>>>>> REPLACE",
    re.DOTALL,
)


def _resolve_path(path: str) -> str:
    path = os.path.expanduser(path)
    if not os.path.isabs(path):
        path = os.path.abspath(path)
    return path


@ability(name="read_file", description="Read a file's contents")
def read_file(path: str, offset: int = 0, limit: int = 0) -> str:
    """Read file contents with optional line offset and limit.

    Args:
        path: Path to file.
        offset: Start from this line (0-indexed).
        limit: Max lines to return. 0 = all.
    """
    path = _resolve_path(path)
    if not os.path.exists(path):
        return f"Error: file not found: {path}"
    if os.path.isdir(path):
        return f"Error: path is a directory: {path}"

    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except Exception as e:
        return f"Error reading file: {e}"

    total = len(lines)
    start = min(offset, total)
    end = total if limit == 0 else min(start + limit, total)
    selected = lines[start:end]

    result_lines = []
    byte_count = 0
    truncated = False
    for line in selected:
        line_bytes = len(line.encode("utf-8"))
        if byte_count + line_bytes > MAX_READ_BYTES:
            truncated = True
            break
        result_lines.append(line)
        byte_count += line_bytes

    content = "".join(result_lines)
    lines_read = len(result_lines)
    header = f"[{path}] lines {start + 1}-{start + lines_read} of {total}"
    if truncated:
        header += " (truncated at 64KB)"
    # Redact secret-looking lines before the content reaches the model.
    # See phoenix/abilities/_secret_redact.py; same rules apply to
    # anything that gets there via `cat .env` through bash.
    return f"{header}\n{_redact_secrets(content)}"


@ability(name="write_file", description="Write content to a file")
async def write_file(path: str, content: str, overwrite: bool = False) -> str:
    """Write content to a file. Creates parent directories if needed.

    Args:
        path: File path to write to.
        content: Text content to write.
        overwrite: Must be True to overwrite existing file.
    """
    path = _resolve_path(path)
    resolved = os.path.realpath(path)
    for protected in PROTECTED_PATHS:
        if resolved.startswith(protected):
            return f"Error: writing to {protected} is not allowed for safety"

    content_bytes = len(content.encode("utf-8"))
    if content_bytes > MAX_WRITE_BYTES:
        return (
            f"Error: content is {content_bytes} bytes, exceeds "
            f"{MAX_WRITE_BYTES} byte limit. For edits to existing files "
            f"use search_replace. For new files, split into multiple "
            f"write_file calls (second call overwrite=True after an "
            f"append to a temp file, then bash `cat tmp1 tmp2 > {path}`)."
        )

    existed = os.path.exists(path)
    if existed and not overwrite:
        return f"Error: file exists: {path}. Set overwrite=True to replace."

    action = "Overwrite" if existed else "Create"
    lines = content.count("\n") + 1

    from phoenix.core.interceptor import get_approval_backend

    backend = get_approval_backend()
    approved = await backend.request_approval(
        "write_file",
        f"{action} {path} ({lines} lines)",
        {"action": action, "path": path, "lines": lines},
    )
    if not approved:
        return "(file write rejected by user)"

    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception as e:
        return f"Error writing file: {e}"

    return f"{action}d {path} ({len(content.encode('utf-8'))} bytes, {lines} lines)"


def _fuzzy_find(text: str, search: str, threshold: float = 0.8) -> str | None:
    search_lines = search.splitlines()
    text_lines = text.splitlines()
    window = len(search_lines)
    if window == 0 or len(text_lines) < window:
        return None
    best_ratio = 0.0
    best_match = None
    for i in range(len(text_lines) - window + 1):
        candidate = "\n".join(text_lines[i : i + window])
        ratio = difflib.SequenceMatcher(None, search, candidate).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_match = candidate
    return best_match if best_ratio >= threshold else None


@ability(name="search_replace", description="Precisely edit files with SEARCH/REPLACE blocks")
async def search_replace(file_path: str, content: str) -> str:
    """Apply SEARCH/REPLACE blocks to edit a file.

    Format:
        <<<<<<< SEARCH
        exact text to find
        =======
        replacement text
        >>>>>>> REPLACE

    Args:
        file_path: Path to file to edit.
        content: One or more SEARCH/REPLACE blocks.
    """
    file_path = _resolve_path(file_path)
    if not os.path.isfile(file_path):
        return f"Error: file not found: {file_path}"

    blocks = BLOCK_PATTERN.findall(content)
    if not blocks:
        return "Error: no valid SEARCH/REPLACE blocks found"

    try:
        with open(file_path, encoding="utf-8", errors="ignore") as f:
            current = f.read()
    except Exception as e:
        return f"Error reading file: {e}"

    from phoenix.core.interceptor import get_approval_backend

    backend = get_approval_backend()
    approved = await backend.request_approval(
        "search_replace",
        f"Edit {file_path} ({len(blocks)} block(s))",
        {"file_path": file_path, "blocks": len(blocks)},
    )
    if not approved:
        return "(edit rejected by user)"

    applied = 0
    warnings = []
    for search, replace in blocks:
        if search not in current:
            close = _fuzzy_find(current, search)
            if close:
                diff = "\n".join(
                    difflib.unified_diff(
                        search.splitlines(),
                        close.splitlines(),
                        lineterm="",
                        fromfile="expected",
                        tofile="found",
                    )
                )
                return f"Error: SEARCH block not found. Closest match:\n{diff[:2000]}"
            return f"Error: SEARCH block not found in file:\n{search[:500]}"

        count = current.count(search)
        if count > 1:
            warnings.append(f"'{search[:50]}...' matched {count}x, replacing first only")
        current = current.replace(search, replace, 1)
        applied += 1

    try:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(current)
    except Exception as e:
        return f"Error writing file: {e}"

    result = f"Applied {applied} block(s) to {file_path}"
    if warnings:
        result += "\nWarnings: " + "; ".join(warnings)
    return result
