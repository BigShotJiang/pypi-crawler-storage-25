"""Pub/sub bus for delegate activity -- feeds the TUI's Ctrl+O panel.

Events are emitted by `phoenix.core.delegate.delegate()` as a sub-agent
runs. Subscribers (the TUI panel) register a callback and get every
event; the bus itself never blocks the delegate path -- subscriber
errors are caught and logged, not raised.

The active-delegates registry (`list_active()`) lets the panel render
something useful even if it opens mid-run: it re-plays the latest known
state of each in-flight delegate instead of waiting for the next event.

Thread model: events are published from within the same event loop as
the sub-agent. The Textual TUI reads from the same loop. No cross-
thread hop needed, so no locks.
"""

from __future__ import annotations

import contextlib
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class DelegateEvent:
    """Single snapshot of delegate activity. Immutable, serializable."""

    type: str  # "started" | "tool_call" | "tool_result" | "done" | "error"
    delegate_id: str  # unique id for this delegate run
    agent: str
    ts: float  # epoch seconds
    # Optional payload fields -- only populated for the relevant event type
    task_preview: str = ""  # first ~120 chars of the task (on "started")
    tool_name: str = ""  # tool name (on "tool_call" / "tool_result")
    tool_args_preview: str = ""  # truncated args repr (on "tool_call")
    tool_is_error: bool = False  # (on "tool_result")
    duration: float = 0.0  # elapsed seconds (on "done" / "error")
    error_message: str = ""  # (on "error")


@dataclass
class ActiveDelegate:
    """Latest-known state for a delegate run still in flight.

    Panel uses this to render a useful first frame when it opens mid-run
    instead of waiting for the next event.
    """

    delegate_id: str
    agent: str
    task_preview: str
    started_at: float
    last_tool: str = ""
    last_tool_at: float = 0.0
    tool_count: int = 0
    history: list[DelegateEvent] = field(default_factory=list)


# Module-level state. Small by design -- the panel is the only consumer
# today and it owns lifecycle. If a second consumer ever shows up we'll
# revisit with a proper Broker class.
_listeners: list[Callable[[DelegateEvent], None]] = []
_active: dict[str, ActiveDelegate] = {}

# Cap the per-delegate history so a runaway 1000-tool-call agent does
# not balloon memory. Newest events win.
_MAX_HISTORY = 50


def subscribe(callback: Callable[[DelegateEvent], None]) -> None:
    """Register a callback for every future event. Idempotent -- registering
    the same callable twice adds it once."""
    if callback in _listeners:
        return
    _listeners.append(callback)


def unsubscribe(callback: Callable[[DelegateEvent], None]) -> None:
    """Remove a previously-registered callback. Silent no-op if absent."""
    with contextlib.suppress(ValueError):
        _listeners.remove(callback)


def publish(event: DelegateEvent) -> None:
    """Notify every listener + update the active-registry.

    Subscriber exceptions are caught and logged. A broken panel must
    never take down a running delegate.

    Subscribers must be SYNC callables. An `async def` subscriber would
    silently return a coroutine that never runs, leaving you debugging
    a panel that never updates; we log.warning and keep going so the
    failure mode is loud. Use `call_later` from a sync callback if you
    need to do async work.

    Subscribers must not call `publish()` synchronously inside their
    own callback -- the `_update_active` mutation and the dispatch loop
    would interleave unsafely. Defer re-publishes via `call_later`.
    """
    import inspect

    _update_active(event)

    # Copy the list so a callback unsubscribing itself mid-dispatch does
    # not mutate the iterable we're walking.
    for cb in list(_listeners):
        try:
            result = cb(event)
            if inspect.iscoroutine(result):
                # Async subscriber: the coroutine is now orphaned and
                # will never await. Close it to suppress the pending-
                # task warning from the event loop, and shout about
                # the bug so it's findable.
                with contextlib.suppress(Exception):
                    result.close()
                log.warning(
                    "delegate_events subscriber %r is async; sync callbacks only",
                    cb,
                )
        except Exception:
            log.exception("delegate_events subscriber raised; continuing")


def list_active() -> list[ActiveDelegate]:
    """Snapshot of currently in-flight delegates. Ordered oldest-first."""
    return sorted(_active.values(), key=lambda a: a.started_at)


def clear() -> None:
    """Drop all listeners + active state. Test helper."""
    _listeners.clear()
    _active.clear()


def make_id(agent: str) -> str:
    """Short unique id for a delegate run. Agent-prefixed so the panel
    can show 'coder-3a4f' without extra plumbing."""
    import uuid

    return f"{agent}-{uuid.uuid4().hex[:6]}"


def now() -> float:
    return time.time()


# -- internal -----------------------------------------------------------


def _update_active(event: DelegateEvent) -> None:
    """Fold the event into the per-delegate active record."""
    if event.type == "started":
        _active[event.delegate_id] = ActiveDelegate(
            delegate_id=event.delegate_id,
            agent=event.agent,
            task_preview=event.task_preview,
            started_at=event.ts,
        )
        _append_history(event.delegate_id, event)
        return

    record = _active.get(event.delegate_id)
    if record is None:
        # Event for a delegate we didn't see start. Happens if the bus
        # was cleared mid-run (tests) or subscribe raced with publish.
        # Skip silently rather than synthesize a partial record.
        return

    if event.type == "tool_call":
        record.last_tool = event.tool_name
        record.last_tool_at = event.ts
        record.tool_count += 1

    _append_history(event.delegate_id, event)

    if event.type in ("done", "error"):
        # Keep the record briefly so the panel can render the final
        # "done in 14s" frame, then evict.
        _active.pop(event.delegate_id, None)


def _append_history(delegate_id: str, event: DelegateEvent) -> None:
    record = _active.get(delegate_id)
    if record is None:
        return
    record.history.append(event)
    if len(record.history) > _MAX_HISTORY:
        # Drop oldest so the view stays useful under long runs.
        del record.history[0 : len(record.history) - _MAX_HISTORY]
