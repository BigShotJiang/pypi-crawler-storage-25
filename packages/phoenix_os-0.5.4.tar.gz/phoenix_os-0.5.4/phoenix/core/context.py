"""Project context scanning -- detects languages, structure, git info."""

import subprocess
from pathlib import Path

MAX_DEPTH = 3
MAX_FILES = 80
MAX_CONTEXT_CHARS = 4000
KEY_FILES = ["README.md", "pyproject.toml", "package.json", "Cargo.toml", "go.mod", "Makefile"]
SNIPPET_CHARS = 500

LANG_MAP = {
    ".py": "Python",
    ".js": "JavaScript",
    ".ts": "TypeScript",
    ".tsx": "TypeScript",
    ".jsx": "JavaScript",
    ".rs": "Rust",
    ".go": "Go",
    ".java": "Java",
    ".rb": "Ruby",
    ".cpp": "C++",
    ".c": "C",
    ".cs": "C#",
    ".swift": "Swift",
    ".kt": "Kotlin",
    ".php": "PHP",
    ".sh": "Shell",
    ".lua": "Lua",
}

DEFAULT_IGNORE = {
    ".git",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".tox",
    "dist",
    "build",
    ".next",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
    "egg-info",
    ".eggs",
}


def _get_gitignore_patterns(root: Path) -> set[str]:
    patterns = set(DEFAULT_IGNORE)
    gitignore = root / ".gitignore"
    if gitignore.exists():
        for line in gitignore.read_text(errors="ignore").splitlines():
            line = line.strip().rstrip("/")
            if line and not line.startswith("#"):
                patterns.add(line)
    return patterns


def _file_tree(root: Path, ignore: set[str], max_depth: int = MAX_DEPTH) -> list[str]:
    lines: list[str] = []
    count = 0

    def _walk(directory: Path, depth: int):
        nonlocal count
        if depth > max_depth or count >= MAX_FILES:
            return
        try:
            entries = sorted(directory.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            return
        for entry in entries:
            if entry.name in ignore or entry.name.startswith("."):
                continue
            if count >= MAX_FILES:
                lines.append(f"{'  ' * depth}... (truncated)")
                return
            prefix = "  " * depth
            if entry.is_dir():
                lines.append(f"{prefix}{entry.name}/")
                count += 1
                _walk(entry, depth + 1)
            else:
                lines.append(f"{prefix}{entry.name}")
                count += 1

    _walk(root, 0)
    return lines


def _detect_languages(root: Path, ignore: set[str]) -> list[str]:
    langs = set()
    count = 0
    for path in root.rglob("*"):
        if count > 500:
            break
        if any(part in ignore for part in path.parts):
            continue
        if path.is_file() and path.suffix in LANG_MAP:
            langs.add(LANG_MAP[path.suffix])
            count += 1
    return sorted(langs)


def _key_file_snippets(root: Path) -> list[str]:
    snippets = []
    for name in KEY_FILES:
        path = root / name
        if path.exists():
            try:
                content = path.read_text(errors="ignore")[:SNIPPET_CHARS]
                snippets.append(f"--- {name} ---\n{content}")
            except (OSError, UnicodeDecodeError):
                pass
    return snippets


def _git_info(root: Path) -> str:
    try:
        branch = subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=root,
        )
        log = subprocess.run(
            ["git", "log", "--oneline", "-5"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=root,
        )
        parts = []
        if branch.returncode == 0 and branch.stdout.strip():
            parts.append(f"Branch: {branch.stdout.strip()}")
        if log.returncode == 0 and log.stdout.strip():
            parts.append(f"Recent commits:\n{log.stdout.strip()}")
        return "\n".join(parts)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return ""


def scan_project_identity(directory: str | Path | None = None) -> str:
    """Slim project identity for the system prompt -- name, languages, git.

    v0.8 retired the always-on file tree + key-file snippets from the
    system prompt (~4000 chars per session); per-turn symbol-level context
    is now handled by `phoenix/context/repo_map.py::RepoMapProvider`,
    which fires only on technical/depth>=2 turns.

    Returns a 2-4 line stub. Empty string if `directory` is not a dir.
    """
    root = Path(directory) if directory else Path.cwd()
    if not root.is_dir():
        return ""
    ignore = _get_gitignore_patterns(root)
    parts: list[str] = [f"Project: {root.name} ({root})"]
    langs = _detect_languages(root, ignore)
    if langs:
        parts.append(f"Languages: {', '.join(langs)}")
    git = _git_info(root)
    if git:
        parts.append(git)
    return "\n\n".join(parts)


def scan_project(directory: str | Path | None = None) -> str:
    """Legacy full project scan (file tree + key-file snippets).

    Retained for any external caller; engine.boot uses
    `scan_project_identity()` as of v0.8 to keep the system prompt lean.
    """
    root = Path(directory) if directory else Path.cwd()
    if not root.is_dir():
        return ""

    ignore = _get_gitignore_patterns(root)
    parts: list[str] = []

    parts.append(f"Project: {root.name} ({root})")

    langs = _detect_languages(root, ignore)
    if langs:
        parts.append(f"Languages: {', '.join(langs)}")

    git = _git_info(root)
    if git:
        parts.append(git)

    tree = _file_tree(root, ignore)
    if tree:
        parts.append("File structure:\n" + "\n".join(tree))

    snippets = _key_file_snippets(root)
    for s in snippets:
        parts.append(s)

    result = "\n\n".join(parts)
    if len(result) > MAX_CONTEXT_CHARS:
        result = result[:MAX_CONTEXT_CHARS] + "\n... (truncated)"
    return result
