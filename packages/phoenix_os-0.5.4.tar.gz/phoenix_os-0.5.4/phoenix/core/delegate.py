"""Delegate -- the brain's tool for routing tasks to specialized agents.

Sequential only: runs the sub-agent to completion, returns the result.
No background processing, no retry loops.

Streams events through pydantic-ai's `run_stream_events` so we can
publish progress (started / tool_call / done) on `delegate_events`
for the TUI's Ctrl+O live panel. The final string is rebuilt from
accumulated text parts, matching what `run()` would have returned.
"""

import asyncio
import json
import logging
import os

from pydantic_ai import RunContext

from phoenix.core import delegate_events as bus
from phoenix.core.factory import build_agent
from phoenix.core.registry import get_registry

log = logging.getLogger(__name__)

DEFAULT_DELEGATE_TIMEOUT_SEC = 300.0

_TASK_PREVIEW_MAX = 120
_ARGS_PREVIEW_MAX = 100


def _log_usage(agent: str, output: str, usage) -> None:
    """Emit one telemetry line per delegate run so we can measure caveman savings.

    Scope is tight on purpose: just tokens + chars + chars-per-output-token.
    Aggregation happens offline (grep the logs).
    """
    chars = len(output)
    if usage is None:
        log.info("Delegate '%s' done | chars=%d (usage unavailable)", agent, chars)
        return
    try:
        in_tok = usage.input_tokens
        out_tok = usage.output_tokens
        cpt = chars / out_tok if out_tok else 0.0
        log.info(
            "Delegate '%s' done | chars=%d input_tokens=%d output_tokens=%d chars_per_out_tok=%.2f",
            agent,
            chars,
            in_tok,
            out_tok,
            cpt,
        )
    except Exception:
        log.info("Delegate '%s' done | chars=%d (usage unavailable)", agent, chars)


def _get_timeout() -> float:
    raw = os.environ.get("PHOENIX_DELEGATE_TIMEOUT")
    if not raw:
        return DEFAULT_DELEGATE_TIMEOUT_SEC
    try:
        value = float(raw)
    except ValueError:
        log.warning("PHOENIX_DELEGATE_TIMEOUT=%r is not a number; using default", raw)
        return DEFAULT_DELEGATE_TIMEOUT_SEC
    return value if value > 0 else DEFAULT_DELEGATE_TIMEOUT_SEC


def _truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "\u2026"


def _args_preview(args) -> str:
    """Compact one-line repr of tool args for the live panel."""
    if args is None:
        return ""
    if isinstance(args, str):
        return _truncate(args.replace("\n", " "), _ARGS_PREVIEW_MAX)
    try:
        rendered = json.dumps(args, default=str, separators=(",", ":"))
    except Exception:
        rendered = str(args)
    return _truncate(rendered, _ARGS_PREVIEW_MAX)


async def _run_and_stream(subagent, task: str, delegate_id: str, agent: str) -> tuple[str, object]:
    """Iterate the sub-agent's event stream, publish progress events,
    accumulate text parts, and return (final_output, usage).

    Ordinary-looking code -- the entire streaming loop is on the delegate
    side. The panel just consumes `delegate_events`, so swapping this
    implementation (e.g. for parallel delegates) later won't touch UI.
    """
    # Imported lazily so the delegate module loads even if pydantic-ai's
    # event types move between versions -- matches engine.py's approach.
    # AgentRunResultEvent lives on pydantic_ai.run in 1.80 (re-exported
    # from the package root); everything else is in .messages.
    from pydantic_ai import AgentRunResultEvent
    from pydantic_ai.messages import (
        FunctionToolCallEvent,
        FunctionToolResultEvent,
        PartDeltaEvent,
        PartStartEvent,
        RetryPromptPart,
        TextPart,
        TextPartDelta,
    )

    chunks: list[str] = []
    final_usage = None
    final_output_fallback: str | None = None

    # Builtin provider tools (Anthropic web_search, OpenAI code_interpreter,
    # etc.) emit BuiltinToolCallEvent, which we do NOT surface on the
    # delegate_events bus today. None of Phoenix's current agents use
    # builtin tools -- web_search is Brave/custom -- but if we adopt any,
    # add BuiltinToolCallEvent to the isinstance chain below so the panel
    # does not silently show `tools: 0` while the agent is working.

    async for event in subagent.run_stream_events(task):
        if isinstance(event, AgentRunResultEvent):
            try:
                final_usage = event.result.usage()
            except Exception:
                final_usage = None
            # Fallback for agents that don't emit TextPart at all
            # (structured output, tool-only responses). `run()` would
            # have stringified result.output; mirror that so swapping
            # run -> run_stream_events doesn't silently return "".
            #
            # Pydantic BaseModel's `str()` gives a dataclass-ish repr
            # ("Model(field='x', ...)") which is readable but not
            # parseable. Prefer `model_dump_json()` so structured
            # outputs round-trip cleanly when a downstream step wants
            # to parse them.
            try:
                output = getattr(event.result, "output", None)
                if output is None:
                    pass
                elif isinstance(output, str):
                    final_output_fallback = output
                elif hasattr(output, "model_dump_json"):
                    final_output_fallback = output.model_dump_json()
                else:
                    final_output_fallback = str(output)
            except Exception:
                pass
            continue

        if isinstance(event, PartStartEvent) and isinstance(event.part, TextPart):
            # Anthropic sometimes packs the opening tokens into the
            # part-start event rather than a delta; mirror engine.py's
            # handling so the final string is whole.
            if event.part.content:
                chunks.append(event.part.content)
            continue

        if isinstance(event, PartDeltaEvent) and isinstance(event.delta, TextPartDelta):
            if event.delta.content_delta:
                chunks.append(event.delta.content_delta)
            continue

        if isinstance(event, FunctionToolCallEvent):
            bus.publish(
                bus.DelegateEvent(
                    type="tool_call",
                    delegate_id=delegate_id,
                    agent=agent,
                    ts=bus.now(),
                    tool_name=event.part.tool_name,
                    tool_args_preview=_args_preview(event.part.args),
                )
            )
            continue

        if isinstance(event, FunctionToolResultEvent):
            is_error = isinstance(event.result, RetryPromptPart)
            bus.publish(
                bus.DelegateEvent(
                    type="tool_result",
                    delegate_id=delegate_id,
                    agent=agent,
                    ts=bus.now(),
                    tool_name=getattr(event.result, "tool_name", ""),
                    tool_is_error=is_error,
                )
            )
            continue

    text = "".join(chunks)
    if not text and final_output_fallback is not None:
        text = final_output_fallback
    return text, final_usage


async def delegate(
    ctx: RunContext,
    task: str,
    agent: str = "worker",
) -> str:
    """Delegate a task to a specialized agent and return its result.

    USE ONLY FOR SIMPLE, SCOPED TASKS. A sub-agent starts with fresh
    context, a separate tool budget, and no view of the ongoing
    conversation -- the overhead is only worth it when the task is
    small enough to describe completely in one paragraph. Complex or
    multi-step work (architectural changes, multi-file refactors,
    debugging across the stack, exploratory investigations, anything
    that needs back-and-forth with Boss mid-flight) should stay on the
    brain, which has Boss's full context and the direct abilities to do
    the work. Break big tasks into phases and delegate only the simplest
    phases, one at a time.

    Aborts with a timeout message if the sub-agent doesn't finish within
    PHOENIX_DELEGATE_TIMEOUT seconds (default 300). Prevents the brain
    from stalling indefinitely on a run-away sub-agent (see issue #9).

    Routing (when the task is small enough to delegate at all):
        - coder: single surgical code edit with a clear target. Terse
          (caveman), safer (cannot commit/push/tag). Accepts JSON hint
          shape {task, reason, file?, line?, from?, to?, after?}.
        - worker: one-shot general coding chore with fresh context --
          small script, quick diff check, mechanical cleanup.
        - explorer: bounded research query about the LOCAL CODEBASE
          (what does X do, where is Y defined). Not for internet
          research.
        - research-agent: deep internet research with citation
          discipline -- iterative plan/search/synthesize/re-query loop,
          capped at 15 web_search calls. For 'research X' style asks
          that need cross-verified multi-source answers. NOT for quick
          factual lookups (use web_search directly) or codebase
          questions (use explorer).
        - planner: break one clearly-defined goal into steps. Not for
          open-ended strategy.

    Args:
        task: Description of what needs to be done.
        agent: Agent name (worker, coder, explorer, planner, etc.).
    """
    registry = get_registry()

    if agent not in registry.list_agents():
        available = ", ".join(registry.list_agents())
        return f"Unknown agent '{agent}'. Available agents: {available}"

    if agent == "brain":
        return "Cannot delegate to self. Choose a specialized agent."

    timeout = _get_timeout()
    log.info("Delegating to '%s' (timeout=%.0fs): %s", agent, timeout, task[:80])

    delegate_id = bus.make_id(agent)
    started_at = bus.now()
    bus.publish(
        bus.DelegateEvent(
            type="started",
            delegate_id=delegate_id,
            agent=agent,
            ts=started_at,
            task_preview=_truncate(task.replace("\n", " "), _TASK_PREVIEW_MAX),
        )
    )

    try:
        subagent = build_agent(
            agent_name=agent,
            registry=registry,
            project_context="",
        )
        output, usage = await asyncio.wait_for(
            _run_and_stream(subagent, task, delegate_id, agent), timeout=timeout
        )
        _log_usage(agent, output, usage)
        bus.publish(
            bus.DelegateEvent(
                type="done",
                delegate_id=delegate_id,
                agent=agent,
                ts=bus.now(),
                duration=bus.now() - started_at,
            )
        )
        return output
    except TimeoutError:
        log.warning("Delegate '%s' timed out after %.0fs", agent, timeout)
        bus.publish(
            bus.DelegateEvent(
                type="error",
                delegate_id=delegate_id,
                agent=agent,
                ts=bus.now(),
                duration=bus.now() - started_at,
                error_message=f"timed out after {timeout:.0f}s",
            )
        )
        return (
            f"Delegation to '{agent}' timed out after {timeout:.0f}s. "
            f"The sub-agent may be stuck in a loop or waiting on a slow tool. "
            f"Consider narrowing the task, or raise PHOENIX_DELEGATE_TIMEOUT."
        )
    except Exception as e:
        log.error("Delegation to '%s' failed: %s", agent, e)
        bus.publish(
            bus.DelegateEvent(
                type="error",
                delegate_id=delegate_id,
                agent=agent,
                ts=bus.now(),
                duration=bus.now() - started_at,
                error_message=str(e),
            )
        )
        return f"Delegation to '{agent}' failed: {e}"
