"""Engine -- the central orchestrator that boots and runs Phoenix.

Context architecture:
  - Each request is nearly stateless. No full conversation history passed.
  - Context is ENGINEERED from three layers:
    1. Memory recall (cross-session facts, preferences, skills)
    2. Topic summaries (completed topics from this session)
    3. Active topic messages (only the current topic's messages)
  - Cost is FLAT: ~5-6k tokens per turn regardless of session length.
  - One LLM call per topic shift (~every 10 turns) for summarization.
"""

import logging
from typing import Any

from pydantic_ai import Agent

from phoenix.abilities import PhoenixContext
from phoenix.config.settings import PHOENIX_DIR, get_model
from phoenix.context import DCBP, ArbiterResult, production_providers
from phoenix.core.context import scan_project_identity
from phoenix.core.delegate import delegate
from phoenix.core.factory import build_agent
from phoenix.core.prefetch import (
    build_ambient_summary,
    extract_contradiction_signal,
    maybe_fetch_web,
)
from phoenix.core.reasoning import detect_stakes
from phoenix.core.registry import Registry, get_registry

log = logging.getLogger(__name__)

# Max pydantic-ai messages to keep in active history within a topic.
# ~10 turns = 20 messages (request + response per turn).
MAX_ACTIVE_HISTORY = 20

# On topic shift, keep only last N messages as bridge.
BRIDGE_MESSAGES = 4  # 2 turns


def _trim_history(history: list, keep_last: int) -> list:
    """Trim pydantic-ai message history to roughly the last N messages.

    The trimmed slice MUST start on a ModelRequest whose parts contain a
    UserPromptPart -- otherwise we leave an orphan tool_result (or a
    dangling tool_use from the prior response) at index 0, which the
    Anthropic API rejects with:
        "Each tool_result block must have a corresponding tool_use block
        in the previous message."
    (see GitHub issue #9).

    Scans forward from the naive cut point and returns the slice starting
    at the first user turn. If no clean user turn exists at or after the
    cut, returns [] -- better to drop history than poison the next request.
    """
    if len(history) <= keep_last:
        return history

    try:
        from pydantic_ai.messages import ModelRequest, UserPromptPart
    except ImportError:
        start = max(0, len(history) - keep_last)
        if start % 2 != 0:
            start += 1
        return history[start:]

    start = max(0, len(history) - keep_last)
    for i in range(start, len(history)):
        msg = history[i]
        if isinstance(msg, ModelRequest) and any(isinstance(p, UserPromptPart) for p in msg.parts):
            return history[i:]

    return []


class PhoenixEngine:
    """Central orchestrator -- boots the system, manages the agent lifecycle."""

    def __init__(self):
        self._registry: Registry | None = None
        self._agent: Agent | None = None
        self._project_context: str = ""
        self._memory: Any = None
        self._topic_tracker: Any = None
        self._session_summary: str = ""
        self._dcbp = DCBP()
        self._last_context_breakdown: ArbiterResult | None = None
        self._phoenix_context: PhoenixContext | None = None
        self._last_critique: Any = None  # phoenix.core.critic.CritiqueResult
        self._ambient: Any = None  # phoenix.ambient.daemon.AmbientDaemon | None

    def attach_ambient(self, daemon: Any) -> None:
        """Wire the ambient daemon so `AmbientInsightProvider` can surface
        signals in low-stakes turns. Optional -- engine works without it.
        """
        self._ambient = daemon

    async def boot(
        self,
        memory: Any = None,
        hook_runner=None,
        session_id: str = "",
        session_summary: str = "",
    ):
        """Initialize the engine: discover plugins, build brain agent."""
        self._memory = memory
        self._hook_runner = hook_runner
        self._session_summary = session_summary
        self._registry = get_registry()
        self._registry.discover_all()

        # Slim identity stub for the frozen system prompt (~200 chars).
        # Per-turn symbol context is handled by `RepoMapProvider`, which
        # only fires on technical, depth>=2 turns.
        self._project_context = scan_project_identity()

        # Swap in the production provider set (adds EnvironmentProvider etc.
        # that __init__ skipped to keep unit tests isolated). Reads AGENTS.md
        # from the cwd Phoenix was launched in -- that's the project Boss is
        # working on, which is the right runtime constraints to inject.
        self._dcbp = DCBP(providers=production_providers())

        # Initialize topic tracker
        from phoenix.memory.session import TopicTracker

        self._topic_tracker = TopicTracker(
            model=get_model(),
            session_id=session_id,
        )

        context = PhoenixContext(
            config={"phoenix_dir": str(PHOENIX_DIR), "model": get_model()},
            memory=self._memory,
            agent_name="brain",
        )
        self._phoenix_context = context

        self._agent = build_agent(
            agent_name="brain",
            registry=self._registry,
            project_context=self._project_context,
            extra_tools=[delegate],
            phoenix_context=context,
            hook_runner=hook_runner,
        )

        abilities = self._registry.list_abilities()
        agents = self._registry.list_agents()
        log.info(
            "Phoenix booted: %d abilities, %d agents",
            len(abilities),
            len(agents),
        )

    @property
    def agent(self) -> Agent:
        if self._agent is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        return self._agent

    def swap_model(self, new_model: str) -> str:
        """Rebuild the brain agent with a different model, preserving the
        session (memory, history, topic tracker, tool set).

        `/model set <name>` calls this so switching models mid-session
        works without restarting Phoenix. Before this path existed the
        only way to change models was to quit and relaunch, which wiped
        the in-memory session state -- see issue #6.

        Returns the newly-active model string.
        """
        if self._registry is None or self._phoenix_context is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        self._agent = build_agent(
            agent_name="brain",
            registry=self._registry,
            project_context=self._project_context,
            extra_tools=[delegate],
            phoenix_context=self._phoenix_context,
            hook_runner=getattr(self, "_hook_runner", None),
            model_override=new_model,
        )
        log.info("Engine model swapped to %s (session preserved)", new_model)
        return new_model

    @property
    def registry(self) -> Registry:
        if self._registry is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        return self._registry

    @property
    def topic_tracker(self):
        return self._topic_tracker

    def _build_engineered_context(
        self,
        user_input: str,
        memory_context: str,
        *,
        web_context: str = "",
        ambient_summary: str = "",
        insights: list[str] | None = None,
    ) -> str:
        """Build the engineered context via the DCBP.

        Delegates layer assembly, intent classification, and budget
        arbitration to `phoenix.context.DCBP`. Stashes the arbiter result
        on `_last_context_breakdown` for `/cost breakdown`.
        """
        score, pairs = extract_contradiction_signal(self._memory)
        prompt, result = self._dcbp.run(
            user_input,
            memory_context=memory_context,
            session_summary=self._session_summary,
            topic_tracker=self._topic_tracker,
            web_context=web_context,
            contradiction_score=score,
            contradiction_pairs=pairs,
            ambient_summary=ambient_summary,
            insights=insights or [],
        )
        self._last_context_breakdown = result
        return prompt

    async def run_stream(
        self,
        user_input: str,
        history: list | None = None,
    ):
        """Execute a turn and yield live events.

        Yields typed tuples (kind, *payload) for the TUI to dispatch:
          ("text", delta: str)
              A streaming text chunk from the assistant response.
          ("tool_call", tool_call_id: str, name: str, args: Any)
              Model decided to call a tool. Render a spinner widget keyed by id.
          ("tool_result", tool_call_id: str, content: str, is_error: bool)
              Tool returned. Transition the spinner widget into a result body.
              is_error=True when pydantic-ai wrapped the tool return in a
              RetryPromptPart (tool raised or returned a retry).

        Uses pydantic-ai 1.80 `run_stream_events` so tool events appear in
        order while streaming, instead of being reconstructed retroactively
        from `stream.all_messages()` after the fact (which put tool widgets
        below the assistant response in the UI).

        The history parameter is the ACTIVE TOPIC's messages only, not the
        full conversation history.
        """
        from pydantic_ai.run import AgentRunResultEvent

        from phoenix.core.stream_events import translate_event

        # Reset per-turn context cache so this turn's pre-fetched data
        # (e.g. WebRetrievalProvider) doesn't leak into the next turn.
        # Abilities that share state with pre-turn pipelines read this cache
        # via `ctx.turn_cache` to dedupe redundant fetches.
        if self._phoenix_context is not None:
            self._phoenix_context.turn_cache.clear()

        # Memory pre-turn -- native async via aiosqlite. SQLite runs on
        # aiosqlite's single internal worker thread, so the event loop isn't
        # blocked. No more asyncio.to_thread wrapper needed.
        memory_context = ""
        if self._memory and hasattr(self._memory, "pre_turn"):
            try:
                memory_context = await self._memory.pre_turn(user_input)
            except Exception as e:
                log.warning("Memory pre_turn failed: %s", e)

        # Ambient web grounding -- pre-fetched only when intent flags a
        # temporal reference. Result is also written to `ctx.turn_cache`,
        # so a redundant model-invoked `web_search` short-circuits.
        web_context = await maybe_fetch_web(self._phoenix_context, user_input)

        # Ambient daemon synopsis (zero LLM cost; pure status snapshot).
        # AmbientInsightProvider gates on low-stakes turns inside the DCBP.
        ambient_summary = await build_ambient_summary(self._ambient)

        # Consolidated insights pre-fetch (post notes-unification).
        # InsightsProvider no longer reads insights.md -- source of truth
        # is memory.db (category="insight"). Cheap DB read; if it fails
        # the turn still runs with empty insights.
        from phoenix.core.prefetch import build_insights_snapshot

        insights = await build_insights_snapshot(self._memory)

        # Build engineered context (replaces raw history)
        prompt = self._build_engineered_context(
            user_input,
            memory_context,
            web_context=web_context,
            ambient_summary=ambient_summary,
            insights=insights,
        )

        # Use only active topic messages as history (not full conversation)
        active_history = history or []

        import time as _time

        chunks: list[str] = []
        final_usage = None
        final_messages: list = []

        turn_start = _time.monotonic()
        log.info(
            "turn.start: model=%s history=%d mem_ctx=%dB prompt=%dB",
            get_model(),
            len(active_history),
            len(memory_context),
            len(prompt),
        )
        if self._last_context_breakdown is not None:
            breakdown = ", ".join(
                f"{type(p).__name__}={len(c)}B" for p, c in self._last_context_breakdown.rendered
            )
            log.info("turn.ctx: %s dropped=%s", breakdown, self._last_context_breakdown.dropped)

        async for event in self.agent.run_stream_events(prompt, message_history=active_history):
            if isinstance(event, AgentRunResultEvent):
                try:
                    final_usage = event.result.usage()
                except Exception:
                    final_usage = None
                try:
                    final_messages = event.result.all_messages()
                except Exception:
                    final_messages = []
                continue
            translated = translate_event(event)
            if translated is None:
                continue
            if translated[0] == "text":
                chunks.append(translated[1])
            yield translated

        full_output = "".join(chunks)
        stakes = detect_stakes(user_input)
        if stakes:
            full_output = f"{stakes}\n\n{full_output}"

        self._last_usage = final_usage
        self._last_output = full_output
        # Enforce MAX_ACTIVE_HISTORY every turn, not just on topic shift.
        # Without this, tool_call/tool_result pairs accumulate unboundedly
        # within a single topic and the engine's "flat per-turn cost"
        # promise (see module docstring) silently breaks. A notes-heavy
        # session was hitting 36k input tokens by turn 5.
        self._last_history = _trim_history(final_messages, keep_last=MAX_ACTIVE_HISTORY)
        self._last_user_input = user_input

        inp_tok = getattr(final_usage, "request_tokens", 0) or 0
        out_tok = getattr(final_usage, "response_tokens", 0) or 0
        log.info(
            "turn.done: dur=%.2fs out=%dB in_tok=%d out_tok=%d",
            _time.monotonic() - turn_start,
            len(full_output),
            inp_tok,
            out_tok,
        )

    async def run_after_stream(self) -> None:
        """Post-stream work (memory consolidation + topic tracking + history
        trimming). Called by the TUI worker AFTER run_stream's async-for loop
        exits, so the heartbeat indicator can be stopped first. No UI updates
        are implied by this method -- it's bookkeeping only.
        """
        user_input = getattr(self, "_last_user_input", "")
        full_output = getattr(self, "_last_output", "")
        if not user_input:
            return

        # Adversarial review fires in the background. Skipped on chat /
        # low-stakes turns -- "how are you" doesn't earn a 15s critic call.
        # On qualifying turns the critic settles via `asyncio.create_task`
        # so memory.post_turn doesn't wait on it.
        from phoenix.core.critic import maybe_launch_critic

        def _stash_critique(result):
            self._last_critique = result

        maybe_launch_critic(user_input, full_output, _stash_critique)

        if self._memory and hasattr(self._memory, "post_turn"):
            try:
                await self._memory.post_turn(user_input, full_output)
            except Exception as e:
                log.warning("Memory post_turn failed: %s", e)

        if self._topic_tracker:
            completed_before = self._topic_tracker.completed_count
            try:
                await self._topic_tracker.process_turn(
                    user_input=user_input,
                    ai_output=full_output,
                )
            except Exception as e:
                log.warning("Topic tracker failed: %s", e)

            if self._topic_tracker.completed_count > completed_before:
                self._last_history = _trim_history(self._last_history, keep_last=BRIDGE_MESSAGES)
                log.info(
                    "Topic shifted -> trimmed history to %d messages",
                    len(self._last_history),
                )

    async def create_session_summary(self) -> str | None:
        """Create a session summary on exit. Store in memory."""
        if not self._topic_tracker:
            return None

        summary = await self._topic_tracker.create_session_summary()
        if summary and self._memory:
            try:
                await self._memory.post_turn(
                    user_input=f"[Session summary] {summary}",
                    ai_output="",
                    namespace="sessions",
                )
            except Exception as e:
                log.warning("Failed to store session summary: %s", e)

        return summary

    @property
    def last_output(self) -> str:
        return getattr(self, "_last_output", "")

    @property
    def last_history(self) -> list:
        return getattr(self, "_last_history", [])

    @property
    def last_usage(self):
        return getattr(self, "_last_usage", None)
