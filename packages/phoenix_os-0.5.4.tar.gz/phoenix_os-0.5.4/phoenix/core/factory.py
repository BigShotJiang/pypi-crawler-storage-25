"""Factory -- builds pydantic-ai Agent instances from YAML personality configs."""

import logging
import os

from pydantic_ai import Agent
from pydantic_ai.settings import ModelSettings

from phoenix.abilities import PhoenixContext
from phoenix.config.settings import resolve_model
from phoenix.core.interceptor import Interceptor
from phoenix.core.registry import Registry
from phoenix.personality.parser import (
    build_system_prompt,
    load_defaults,
    merge_config,
)

log = logging.getLogger(__name__)

# Default retries for tool-call validation errors and output-validator
# failures. pydantic-ai's default is 1, which is too tight for weak
# local models (observed with `ollama:gpt-oss:20b` -- emits `bash({})`
# with no `command`, burns the single retry on the same mistake, then
# raises a bare pydantic_core.ValidationError that crashes the turn;
# see issue #10). Three gives the model a real shot at self-correcting.
# Override with `PHOENIX_TOOL_RETRIES=<n>`.
_DEFAULT_TOOL_RETRIES = 3


def _get_tool_retries() -> int:
    raw = os.environ.get("PHOENIX_TOOL_RETRIES")
    if not raw:
        return _DEFAULT_TOOL_RETRIES
    try:
        n = int(raw)
    except ValueError:
        return _DEFAULT_TOOL_RETRIES
    return max(0, n)


def build_agent(
    agent_name: str,
    registry: Registry,
    project_context: str = "",
    extra_tools: list | None = None,
    phoenix_context: PhoenixContext | None = None,
    model_override: str | None = None,
    hook_runner=None,
) -> Agent:
    """Build a pydantic-ai Agent from a YAML personality config.

    1. Reads AgentConfig from registry
    2. Merges with phoenix.yaml defaults
    3. Builds system prompt
    4. Resolves abilities, wraps with interceptor
    5. Returns configured pydantic_ai.Agent
    """
    config = registry.get_agent_config(agent_name)
    if config is None:
        raise ValueError(f"Unknown agent '{agent_name}'. Available: {registry.list_agents()}")

    defaults = load_defaults()
    merged = merge_config(defaults, config)
    prompt = build_system_prompt(merged, defaults, project_context)

    model = resolve_model(model_override or merged.model)

    interceptor = Interceptor(hook_runner=hook_runner)
    tools = []

    for ability_info in registry.get_agent_abilities(agent_name):
        wrapped = interceptor.wrap(ability_info, context=phoenix_context)
        tools.append(wrapped)

    if extra_tools:
        tools.extend(extra_tools)

    log.info(
        "Built agent '%s' with %d tools, model=%s",
        agent_name,
        len(tools),
        model if isinstance(model, str) else type(model).__name__,
    )

    try:
        return Agent(
            model,
            instructions=prompt,
            tools=tools,
            end_strategy="exhaustive",
            model_settings=ModelSettings(parallel_tool_calls=True),
            retries=_get_tool_retries(),
        )
    except ImportError as e:
        # pydantic-ai lazy-imports provider SDKs (mistralai, google-genai, ...)
        # on Agent construction. A broken or shadowed install in the user's
        # environment surfaces as a cryptic ImportError here -- turn it into
        # actionable guidance instead of crashing the boot.
        provider = (
            model.split(":", 1)[0]
            if isinstance(model, str) and ":" in model
            else type(model).__name__
        )
        raise RuntimeError(
            f"Provider client for '{provider}' failed to import: {e}\n\n"
            f"Fix options:\n"
            f"  pip install --upgrade --force-reinstall phoenix-os\n"
            f"  phoenix --setup   (switch to a different provider)"
        ) from e
