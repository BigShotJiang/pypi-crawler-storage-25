"""Background process manager.

Long-running commands (dev servers, watchers, builds that exec a binary)
live here so the brain does not wait on them. Each process gets a short
hex id, a rolling in-memory ring buffer of recent output, and an
append-only log file at ``~/.phoenix/bg/<id>.log``.

Two entry points:
  - `bash_bg` ability -- the model chooses this for servers/watchers.
  - `_run_subprocess` auto-promotion in `bash.py` -- safety net when a
    plain `bash` command is still running past the promotion threshold.

No PID files, no crash recovery. Phoenix is a foreground TUI; when it
dies the dev server dies with it. Shutdown sends SIGTERM then SIGKILL.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import secrets
import signal
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

from phoenix.config.settings import PHOENIX_DIR

log = logging.getLogger(__name__)

BG_DIR: Path = PHOENIX_DIR / "bg"
RING_BUFFER_LINES = 2000
SHUTDOWN_GRACE_SEC = 2.0
LOG_FILES_TO_KEEP = 5


@dataclass
class BgProc:
    bg_id: str
    command: str
    workdir: str
    proc: asyncio.subprocess.Process
    started_at: float
    log_path: Path
    buffer: deque[str] = field(default_factory=lambda: deque(maxlen=RING_BUFFER_LINES))
    reader_task: asyncio.Task | None = None
    _log_fh: object = None
    _stopped_at: float | None = None
    _exit_code: int | None = None

    @property
    def runtime_sec(self) -> float:
        end = self._stopped_at if self._stopped_at is not None else time.monotonic()
        return end - self.started_at

    @property
    def status(self) -> str:
        if self._exit_code is not None:
            return f"exited({self._exit_code})"
        if self.proc.returncode is not None:
            return f"exited({self.proc.returncode})"
        return "running"

    @property
    def is_running(self) -> bool:
        return self.proc.returncode is None and self._exit_code is None


class BackgroundProcessManager:
    def __init__(self) -> None:
        self._procs: dict[str, BgProc] = {}
        self._lock = asyncio.Lock()
        BG_DIR.mkdir(parents=True, exist_ok=True)
        self._prune_old_logs()

    def _prune_old_logs(self) -> None:
        try:
            logs = sorted(BG_DIR.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
            for stale in logs[LOG_FILES_TO_KEEP:]:
                stale.unlink(missing_ok=True)
        except Exception as e:
            log.debug("bg log prune skipped: %s", e)

    @staticmethod
    def _new_id() -> str:
        return f"bg_{secrets.token_hex(2)}"

    async def start(self, command: str, workdir: str = "") -> BgProc:
        """Spawn a command as a background process. Returns the BgProc handle."""
        run_cwd = workdir if workdir and os.path.isdir(workdir) else os.getcwd()
        bg_id = self._new_id()
        log_path = BG_DIR / f"{bg_id}.log"

        env = os.environ.copy()
        env.setdefault("CI", "true")
        env.setdefault("NONINTERACTIVE", "1")

        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=run_cwd,
            env=env,
            start_new_session=True,
        )

        log_fh = log_path.open("w", buffering=1, encoding="utf-8", errors="replace")
        log_fh.write(f"# {bg_id}  $ {command}\n# cwd: {run_cwd}\n\n")

        bg = BgProc(
            bg_id=bg_id,
            command=command,
            workdir=run_cwd,
            proc=proc,
            started_at=time.monotonic(),
            log_path=log_path,
        )
        bg._log_fh = log_fh
        bg.reader_task = asyncio.create_task(self._reader(bg))

        async with self._lock:
            self._procs[bg_id] = bg
        log.info("bg.start: %s pid=%s cmd=%s", bg_id, proc.pid, command[:200])
        return bg

    async def _reader(self, bg: BgProc) -> None:
        assert bg.proc.stdout is not None
        try:
            while True:
                line = await bg.proc.stdout.readline()
                if not line:
                    break
                text = line.decode("utf-8", errors="replace")
                bg.buffer.append(text)
                with contextlib.suppress(Exception):
                    bg._log_fh.write(text)  # type: ignore[union-attr]
            code = await bg.proc.wait()
            bg._exit_code = code
            bg._stopped_at = time.monotonic()
            log.info(
                "bg.exit: %s code=%d runtime=%.1fs",
                bg.bg_id,
                code,
                bg.runtime_sec,
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("bg.reader failed for %s: %s", bg.bg_id, e)
        finally:
            with contextlib.suppress(Exception):
                bg._log_fh.close()  # type: ignore[union-attr]

    async def collect_initial_output(self, bg: BgProc, seconds: float) -> str:
        """Wait up to `seconds`, return buffered output so far.

        Used by `bash_bg` to give the model a snippet (e.g. 'vite ready on :5173')
        without blocking for the full run.
        """
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline and bg.is_running:
            await asyncio.sleep(0.1)
        return "".join(bg.buffer).rstrip()

    def get(self, bg_id: str) -> BgProc | None:
        return self._procs.get(bg_id)

    def list_all(self) -> list[BgProc]:
        return list(self._procs.values())

    def list_running(self) -> list[BgProc]:
        return [b for b in self._procs.values() if b.is_running]

    def tail_logs(self, bg_id: str, lines: int = 100) -> str | None:
        bg = self._procs.get(bg_id)
        if bg is None:
            return None
        buf = list(bg.buffer)
        return "".join(buf[-lines:])

    async def stop(self, bg_id: str, force: bool = False) -> bool:
        bg = self._procs.get(bg_id)
        if bg is None or not bg.is_running:
            return False
        sig = signal.SIGKILL if force else signal.SIGTERM
        # `start_new_session=True` in start() made proc.pid the new session's
        # pgid; signal it directly rather than round-tripping through
        # getpgid() (which could theoretically return Phoenix's own pgid).
        try:
            if bg.proc.pid is not None:
                os.killpg(bg.proc.pid, sig)
        except ProcessLookupError:
            return False
        except Exception as e:
            log.warning("bg.stop %s signal failed: %s", bg_id, e)
            try:
                bg.proc.send_signal(sig)
            except Exception:
                return False
        log.info("bg.stop: %s signal=%s", bg_id, sig.name)
        return True

    def terminate_all_sync(self) -> int:
        """Best-effort synchronous SIGTERM of every running bg process.

        Safe to call from non-async hooks (atexit, Textual on_unmount). Does
        NOT wait for exit or escalate to SIGKILL -- use `shutdown_all` for
        the graceful path when there's an event loop available.
        """
        n = 0
        for bg in self.list_running():
            if bg.proc.pid is None:
                continue
            try:
                os.killpg(bg.proc.pid, signal.SIGTERM)
                n += 1
            except ProcessLookupError:
                continue
            except Exception as e:
                log.debug("bg.terminate_all_sync %s failed: %s", bg.bg_id, e)
        if n:
            log.info("bg.shutdown sync: SIGTERM to %d", n)
        return n

    async def shutdown_all(self) -> None:
        """Called on TUI exit. SIGTERM, wait, SIGKILL stragglers.

        Also cancels reader tasks so the event loop doesn't emit pending-task
        warnings during interpreter shutdown.
        """
        running = self.list_running()
        if not running:
            return
        log.info("bg.shutdown: %d running", len(running))
        for bg in running:
            await self.stop(bg.bg_id, force=False)
        with contextlib.suppress(TimeoutError):
            await asyncio.wait_for(
                asyncio.gather(*(self._wait_exit(bg) for bg in running), return_exceptions=True),
                timeout=SHUTDOWN_GRACE_SEC,
            )
        for bg in self.list_running():
            await self.stop(bg.bg_id, force=True)
        for bg in self._procs.values():
            if bg.reader_task is not None and not bg.reader_task.done():
                bg.reader_task.cancel()
                with contextlib.suppress(Exception):
                    await bg.reader_task

    async def _wait_exit(self, bg: BgProc) -> None:
        with contextlib.suppress(Exception):
            await bg.proc.wait()


_manager: BackgroundProcessManager | None = None


def get_manager() -> BackgroundProcessManager:
    global _manager
    if _manager is None:
        _manager = BackgroundProcessManager()
    return _manager


def reset_manager_for_tests() -> None:
    global _manager
    _manager = None
