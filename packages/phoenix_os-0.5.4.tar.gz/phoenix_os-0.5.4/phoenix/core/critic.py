"""PostTurnCritic -- adversarial review of model output post-stream.

Runs a critic agent on the (user_input, model_output) pair to flag claims
that depend on unstated assumptions, deployment targets, or inherited
code comments. Best-effort by design: a 15s timeout, no exceptions
escape; if the critic call fails the turn proceeds normally with an
empty flag list.

Pillars closed: doubt-on-generated (vision.md Correction), partial cover
on causal-derivation (catches pattern-matched claims the model didn't
re-derive).
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from dataclasses import dataclass, field

from phoenix.config.settings import get_model

log = logging.getLogger(__name__)


_CRITIC_INSTRUCTIONS = (
    "You are a terse output reviewer. You read the assistant's last "
    "response and flag claims that: "
    "(1) depend on unstated assumptions about the user's environment, "
    "deployment target, or platform; "
    "(2) are confidently asserted but unverified by the user's input or "
    "available context; "
    "(3) inherit reasoning from existing code comments or documentation "
    "without re-deriving it (these may be wrong). "
    "Output one flag per line, each prefixed with 'FLAG:'. If nothing "
    "concerning, output exactly 'OK'. Be terse. Do not rewrite. Do not "
    "suggest fixes."
)

_CRITIC_PROMPT = """User input:
{user_input}

Assistant output:
{output}"""


@dataclass
class CritiqueResult:
    flags: list[str] = field(default_factory=list)
    timed_out: bool = False
    error: str = ""

    @property
    def has_flags(self) -> bool:
        return bool(self.flags)


def _default_agent_factory():
    """Build a fresh pydantic-ai Agent for the critic call.

    Lives behind a factory so tests can swap in a fake without spinning
    up the real model client.
    """
    from pydantic_ai import Agent

    return Agent(get_model(), instructions=_CRITIC_INSTRUCTIONS)


async def critique(
    user_input: str,
    output: str,
    *,
    timeout_s: float = 15.0,
    agent_factory: Callable | None = None,
) -> CritiqueResult:
    """Adversarially review the model's output.

    Best-effort: timeouts and errors are swallowed, returning an empty
    flag list so the turn always proceeds.
    """
    if not output.strip():
        return CritiqueResult()

    factory = agent_factory or _default_agent_factory
    prompt = _CRITIC_PROMPT.format(user_input=user_input, output=output)

    try:
        agent = factory()
        result = await asyncio.wait_for(agent.run(prompt), timeout=timeout_s)
        text = str(getattr(result, "output", result)).strip()
        return CritiqueResult(flags=_parse_flags(text))
    except TimeoutError:
        log.info("PostTurnCritic timed out after %.1fs", timeout_s)
        return CritiqueResult(timed_out=True)
    except Exception as e:
        log.warning("PostTurnCritic failed: %s", e)
        return CritiqueResult(error=str(e))


def _parse_flags(text: str) -> list[str]:
    """Extract `FLAG:` lines from critic output. `OK` alone = no flags."""
    if text.strip().upper() == "OK":
        return []
    flags: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if line.upper().startswith("FLAG:"):
            flags.append(line[5:].strip())
    return flags


def maybe_launch_critic(
    user_input: str,
    full_output: str,
    on_result: Callable[[CritiqueResult | None], None],
) -> None:
    """Fire the critic in the background on qualifying turns.

    Skips `QueryType.CHAT` and low-stakes turns -- "thanks" doesn't earn a
    15s critic call. On qualifying turns, schedules `critique()` via
    `asyncio.create_task` so the caller's post-turn pipeline doesn't wait.

    `on_result` receives the `CritiqueResult` (or None when skipped) so
    callers can stash it for later UX surfaces without coupling to this
    module.
    """
    import asyncio

    from phoenix.context import intent_from_input
    from phoenix.core.reasoning import QueryType

    intent = intent_from_input(user_input)
    if intent.query_type == QueryType.CHAT or not intent.stakes:
        on_result(None)
        return

    async def _run():
        result = await critique(user_input, full_output)
        on_result(result)
        if result.has_flags:
            log.warning(
                "PostTurnCritic flagged %d concern(s): %s",
                len(result.flags),
                "; ".join(result.flags[:3]),
            )

    try:
        asyncio.create_task(_run())
    except RuntimeError as e:
        log.debug("critic task not scheduled: %s", e)
