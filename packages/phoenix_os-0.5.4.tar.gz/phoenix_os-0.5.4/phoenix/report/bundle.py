"""Builds a ReportBundle -- the payload that gets sent to the Cloudflare Worker."""

from __future__ import annotations

import platform as _platform
import sys
from dataclasses import dataclass, field

from phoenix import __version__
from phoenix.report.scrub import scrub_env_summary, scrub_text

# How many tail lines of ~/.phoenix/logs/phoenix.log to attach. Matches the
# default log rotation's file size so we cover roughly "one session".
DEFAULT_LOG_TAIL = 500


@dataclass
class ReportBundle:
    """Everything we send. Keep this small + flat so Worker-side parsing is trivial."""

    description: str
    phoenix_version: str
    python_version: str
    platform: str
    model: str
    env: dict[str, str]
    log_tail: str
    log_lines_included: int
    transcript: str = ""
    transcript_turns: int = 0

    # Internal flag set by scrub; prevents double-scrubbing downstream.
    scrubbed: bool = field(default=True)

    def to_dict(self) -> dict:
        return {
            "description": self.description,
            "phoenix_version": self.phoenix_version,
            "python_version": self.python_version,
            "platform": self.platform,
            "model": self.model,
            "env": self.env,
            "log_tail": self.log_tail,
            "log_lines_included": self.log_lines_included,
            "transcript": self.transcript,
            "transcript_turns": self.transcript_turns,
            "scrubbed": self.scrubbed,
        }

    def to_markdown(self) -> str:
        """Human-readable rendering. Used for the GitHub issue body and the
        in-TUI preview before submit."""
        env_list = "\n".join(f"- `{k}`: {v}" for k, v in self.env.items())
        parts = [
            f"## What went wrong\n{self.description}\n",
            f"## Environment\n"
            f"- Phoenix: `{self.phoenix_version}`\n"
            f"- Python: `{self.python_version}`\n"
            f"- Platform: `{self.platform}`\n"
            f"- Model: `{self.model}`\n",
            f"## Env keys\n{env_list}\n",
            f"## Log tail ({self.log_lines_included} lines, scrubbed)\n```\n{self.log_tail}\n```\n",
        ]
        if self.transcript:
            parts.append(
                f"## Conversation transcript ({self.transcript_turns} turns, scrubbed)\n"
                f"```\n{self.transcript}\n```\n"
            )
        return "\n".join(parts)


def _render_transcript(history: list) -> tuple[str, int]:
    """Flatten pydantic-ai message history into a scrubbed, role-tagged text block.

    Returns (rendered, turn_count). Tool calls and results are included so bugs
    like "assistant streamed the wrong first token" are diagnosable from the
    transcript alone. Long tool outputs are trimmed to 400 chars to keep the
    GitHub issue body under GitHub's 65k limit.
    """
    if not history:
        return "", 0

    lines: list[str] = []
    turns = 0
    for msg in history:
        kind = type(msg).__name__
        parts = getattr(msg, "parts", None) or []
        for part in parts:
            ptype = type(part).__name__
            if ptype == "UserPromptPart":
                content = getattr(part, "content", "")
                lines.append(f"USER: {content}")
                turns += 1
            elif ptype == "TextPart":
                content = getattr(part, "content", "")
                if content.strip():
                    lines.append(f"ASSISTANT: {content}")
            elif ptype in ("ToolCallPart", "FunctionToolCallPart"):
                name = getattr(part, "tool_name", "") or getattr(part, "name", "")
                args = getattr(part, "args", "") or ""
                if isinstance(args, dict):
                    args = str(args)
                lines.append(f"TOOL_CALL {name}: {args[:200]}")
            elif ptype in ("ToolReturnPart", "FunctionToolResultPart"):
                name = getattr(part, "tool_name", "") or getattr(part, "name", "")
                content = getattr(part, "content", "") or ""
                if not isinstance(content, str):
                    content = str(content)
                if len(content) > 400:
                    content = content[:400] + f"... <+{len(content) - 400} chars>"
                lines.append(f"TOOL_RESULT {name}: {content}")
            elif ptype == "SystemPromptPart":
                # Skip system prompts -- they leak the full agent wiring
                # and aren't useful for user-reported bugs.
                continue
            else:
                lines.append(f"{kind}.{ptype}: <skipped>")

    scrubbed = scrub_text("\n".join(lines))
    return scrubbed, turns


def build_bundle(
    description: str,
    tail_lines: int = DEFAULT_LOG_TAIL,
    history: list | None = None,
) -> ReportBundle:
    """Collect system info + scrubbed log tail. Safe to call from anywhere.

    When `history` is provided, a scrubbed transcript of the conversation is
    included too. Pass None (the default) to omit the transcript -- the
    caller is responsible for getting user consent before attaching it.
    """
    from phoenix.config.settings import get_model
    from phoenix.logging_setup import tail

    try:
        model = get_model()
    except Exception:
        model = "<unknown>"

    raw_log = tail(tail_lines)
    scrubbed_log = scrub_text(raw_log)
    scrubbed_desc = scrub_text(description.strip())
    log_lines = len(scrubbed_log.splitlines()) if scrubbed_log else 0

    transcript, turns = _render_transcript(history or [])

    return ReportBundle(
        description=scrubbed_desc,
        phoenix_version=__version__,
        python_version=sys.version.split()[0],
        platform=f"{_platform.system()} {_platform.release()} ({_platform.machine()})",
        model=model,
        env=scrub_env_summary(),
        log_tail=scrubbed_log,
        log_lines_included=log_lines,
        transcript=transcript,
        transcript_turns=turns,
    )
