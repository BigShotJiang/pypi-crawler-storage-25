"""Submit a ReportBundle to the Cloudflare Worker.

On network failure / worker-down / rate-limit, falls back to writing the
bundle locally so the user can still attach it to an issue manually.
"""

from __future__ import annotations

import contextlib
import datetime as _dt
import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path

import httpx

from phoenix.report.bundle import ReportBundle

log = logging.getLogger(__name__)

# Deployed Cloudflare Worker endpoint. Override with PHOENIX_BUG_REPORT_URL
# for testing against a local wrangler dev server or a fork's worker.
_DEFAULT_URL = "https://phoenix-os-bug-report.harshalmore2468.workers.dev/report"

LOCAL_REPORT_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix")) / "bug-reports"


def _endpoint() -> str:
    return os.environ.get("PHOENIX_BUG_REPORT_URL", _DEFAULT_URL).rstrip("/")


@dataclass
class SubmitResult:
    """Outcome of a submit call. Branches on `ok`:
    - ok + issue_url: Worker created the issue
    - not ok + local_path: saved locally, user should file manually
    - not ok + local_path is None: save also failed; user has no artifact
    - retry_after_seconds > 0: Worker rate-limited; user should try later
    """

    ok: bool
    issue_url: str = ""
    issue_number: int = 0
    local_path: Path | None = None
    error: str = ""
    retry_after_seconds: int = 0


def _save_local(bundle: ReportBundle, reason: str) -> Path | None:
    """Write the bundle to ~/.phoenix/bug-reports/. Returns None if the
    write fails (disk full, read-only fs, permission denied) -- callers must
    handle None and show the user a clear fallback message."""
    try:
        LOCAL_REPORT_DIR.mkdir(parents=True, exist_ok=True)
        stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        path = LOCAL_REPORT_DIR / f"report-{stamp}.md"

        header = (
            f"<!-- Phoenix bug report, saved locally because: {reason} -->\n"
            f"<!-- Open an issue at https://github.com/harshalmore31/phoenix-os/issues/new -->\n"
            f"<!-- and paste this file's content as the body. -->\n\n"
        )
        path.write_text(header + bundle.to_markdown(), encoding="utf-8")
        return path
    except (OSError, PermissionError) as e:
        log.warning("bug-report._save_local failed: %s: %s", type(e).__name__, e)
        return None


async def submit(bundle: ReportBundle, timeout: float = 15.0) -> SubmitResult:
    """POST the bundle to the Worker. On any failure, save locally and return."""
    endpoint = _endpoint()
    payload = bundle.to_dict()

    log.info(
        "bug-report.submit: endpoint=%s desc_len=%d log_lines=%d",
        endpoint,
        len(bundle.description),
        bundle.log_lines_included,
    )

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                endpoint,
                json=payload,
                headers={
                    "content-type": "application/json",
                    "user-agent": f"phoenix-os/{bundle.phoenix_version}",
                },
            )
    except Exception as e:
        log.warning("bug-report.transport-failed: %s", e)
        path = _save_local(bundle, f"transport error: {type(e).__name__}: {e}")
        return SubmitResult(ok=False, local_path=path, error=str(e))

    if resp.status_code == 429:
        retry_after = 0
        with contextlib.suppress(ValueError):
            retry_after = int(resp.headers.get("retry-after", "0"))
        log.warning(
            "bug-report.rate-limited: retry_after=%ds body=%s",
            retry_after,
            resp.text[:200],
        )
        path = _save_local(bundle, "rate-limited by worker")
        hours = max(1, retry_after // 3600) if retry_after else 0
        hint = f"try again in ~{hours}h" if hours else "try again tomorrow"
        return SubmitResult(
            ok=False,
            local_path=path,
            error=f"Rate limit hit -- {hint} or file manually.",
            retry_after_seconds=retry_after,
        )

    if resp.status_code >= 400:
        log.warning("bug-report.worker-rejected: %d %s", resp.status_code, resp.text[:200])
        path = _save_local(bundle, f"worker returned {resp.status_code}")
        return SubmitResult(
            ok=False,
            local_path=path,
            error=f"Worker returned HTTP {resp.status_code}.",
        )

    try:
        data = resp.json()
    except json.JSONDecodeError:
        log.warning("bug-report.bad-response: not-json body=%s", resp.text[:200])
        path = _save_local(bundle, "worker returned non-JSON")
        return SubmitResult(ok=False, local_path=path, error="Worker returned unexpected response.")

    issue_url = data.get("issue_url", "")
    issue_number = int(data.get("issue_number", 0) or 0)

    if not issue_url:
        path = _save_local(bundle, "worker response missing issue_url")
        return SubmitResult(ok=False, local_path=path, error="Worker did not return an issue URL.")

    log.info("bug-report.created: %s", issue_url)
    return SubmitResult(ok=True, issue_url=issue_url, issue_number=issue_number)
