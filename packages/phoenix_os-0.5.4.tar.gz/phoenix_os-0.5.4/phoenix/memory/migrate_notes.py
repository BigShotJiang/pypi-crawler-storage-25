"""One-shot migration: notes.db + insights.md -> memory.db.

Runs on first boot after the notes-unification release. Reads the legacy
SQLite table and the append-only markdown file, batches every row through
`MemorySystem.ingest_intentional`, then renames both source files to
`.migrated` so they're preserved for rollback but no longer read.

The migration is guarded by a sentinel row in the existing `_migrations`
table (same mechanism ordinary SQL migrations use). A partial failure
(e.g. corrupt notes.db mid-batch) leaves the sentinel unwritten so the
next boot retries -- files are renamed only AFTER the rows they contained
have been successfully ingested.

Why this file exists and not a SQL migration: the ingest path must go
through the cognitive gate (dedup, contradiction) so duplicate legacy
notes collapse into one. A SQL migration can't embed-and-gate. This
module bridges the gap.
"""

from __future__ import annotations

import logging
import sqlite3
import time
from pathlib import Path

log = logging.getLogger(__name__)

SENTINEL_NAME = "notes_unification_v1"


async def run_migration(memory, phoenix_dir: Path) -> dict:
    """Migrate legacy notes.db + insights.md into memory.db.

    Returns a stats dict: {"status": ..., "notes": N, "insights": M, "errors": K}.
    Status is "already_migrated", "ok", or "partial". Safe to call on every
    boot -- sentinel check is cheap and every subsequent run is a no-op.

    Arguments are passed explicitly rather than read from config.settings so
    tests can point the migration at a fixture directory.
    """
    # Ensure memory is up so ingest_intentional (gate + embed + store.add)
    # has everything it needs. Warm boots short-circuit this cheaply.
    await memory._ensure_initialized()
    store = memory.store
    db = store._require_db()

    # Sentinel check
    cursor = await db.execute("SELECT 1 FROM _migrations WHERE name = ?", (SENTINEL_NAME,))
    if await cursor.fetchone():
        await cursor.close()
        return {"status": "already_migrated", "notes": 0, "insights": 0, "errors": 0}
    await cursor.close()

    stats = {"status": "ok", "notes": 0, "insights": 0, "errors": 0}

    notes_db_path = phoenix_dir / "notes.db"
    insights_md_path = phoenix_dir / "insights.md"

    # Nothing to do on a fresh install. Write the sentinel anyway so we
    # don't re-scan these paths on every boot forever.
    if not notes_db_path.exists() and not insights_md_path.exists():
        await _write_sentinel(db)
        return stats

    # --- Notes ---
    if notes_db_path.exists():
        try:
            notes_added = await _migrate_notes(memory, notes_db_path)
            stats["notes"] = notes_added
        except Exception as e:
            log.warning("notes migration failed: %s", e)
            stats["errors"] += 1
            stats["status"] = "partial"
            return stats  # ingest failed; do NOT write sentinel; retry next boot
        # Rename AFTER ingest succeeds, in its own try -- a rename failure
        # (symlink, perms) must not cause double-ingest on retry. We log it
        # and keep going; the sentinel will still be written, because the
        # ingest already happened and the rows are in memory.db. Boss can
        # manually delete the source file if the rename fails.
        try:
            notes_db_path.rename(notes_db_path.with_suffix(".db.migrated"))
        except OSError as e:
            log.warning(
                "notes.db rename failed (%s); manually move %s to avoid re-ingest",
                e,
                notes_db_path,
            )

    # --- Insights ---
    if insights_md_path.exists():
        try:
            insights_added = await _migrate_insights(memory, insights_md_path)
            stats["insights"] = insights_added
        except Exception as e:
            log.warning("insights migration failed: %s", e)
            stats["errors"] += 1
            stats["status"] = "partial"
            return stats  # sentinel unwritten; next boot retries insights
        try:
            insights_md_path.rename(insights_md_path.with_suffix(".md.migrated"))
        except OSError as e:
            log.warning(
                "insights.md rename failed (%s); manually move %s to avoid re-ingest",
                e,
                insights_md_path,
            )

    await _write_sentinel(db)
    log.info(
        "notes unification migration: %d notes + %d insights -> memory.db",
        stats["notes"],
        stats["insights"],
    )
    return stats


async def _write_sentinel(db) -> None:
    await db.execute(
        "INSERT OR IGNORE INTO _migrations (name, applied_at) VALUES (?, ?)",
        (SENTINEL_NAME, time.time()),
    )
    await db.commit()


async def _migrate_notes(memory, notes_db_path: Path) -> int:
    """Read the legacy notes table, route each row through the gate.

    Uses sync sqlite3 for the read because aiosqlite on a foreign DB is
    overkill for a one-shot read of ~20 rows.
    """
    conn = sqlite3.connect(str(notes_db_path))
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            "SELECT id, title, content, category, status, related_topic, "
            "created_at, updated_at FROM notes"
        ).fetchall()
    finally:
        conn.close()

    added = 0
    for r in rows:
        body = _compose_note_body(
            title=r["title"] or "",
            content=r["content"] or "",
            category=r["category"] or "",
            related_topic=r["related_topic"] or "",
        )
        if not body:
            continue

        result = await memory.ingest_intentional(
            content=body,
            category="note",
            namespace="global",
            source_session=f"migration:notes:{r['id']}",
        )

        # Resolved / archived legacy notes shouldn't recall as strongly as
        # active ones. Apply the same strength penalty the new /resolve does.
        if result.get("action") == "ADD" and r["status"] in ("resolved", "archived"):
            new_id = result.get("id")
            if new_id:
                existing = await memory.store.get(new_id)
                if existing is not None:
                    await memory.store.update_strength(new_id, float(existing["strength"]) * 0.3)

        if result.get("action") in ("ADD", "UPDATE"):
            added += 1

    return added


def _compose_note_body(title: str, content: str, category: str, related_topic: str) -> str:
    parts = []
    if category:
        parts.append(f"[{category}]")
    if related_topic:
        parts.append(f"({related_topic})")
    head = " ".join(parts)
    # A nested ternary here is harder to read; keep the block form.
    if title and content and title != content:  # noqa: SIM108
        body = f"{title}: {content}"
    else:
        body = content or title
    return f"{head} {body}".strip() if head else body


async def _migrate_insights(memory, insights_md_path: Path) -> int:
    """Parse `- ` bullets from the append-only markdown, ingest each as
    `category="insight"`. Headers and blank lines skipped.
    """
    text = insights_md_path.read_text(encoding="utf-8", errors="replace")
    added = 0
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped.startswith("- "):
            continue
        body = stripped[2:].strip()
        if not body:
            continue
        # Legacy insights were written by consolidation with the
        # `[consolidated]` prefix; preserve it so the gate treats them
        # consistently with future consolidation output.
        content = body if body.startswith("[consolidated]") else f"[consolidated] {body}"
        result = await memory.ingest_intentional(
            content=content,
            category="insight",
            namespace="global",
            source_session="migration:insights.md",
        )
        if result.get("action") in ("ADD", "UPDATE"):
            added += 1
    return added
