"""Async SQLite storage layer for Phoenix memory.

Backed by `aiosqlite` -- all methods are async. A single connection is
opened on `connect()` and reused; aiosqlite serialises queries on its
own internal worker thread, so there are no cross-thread SQLite errors
and no per-thread bookkeeping.

Migrations live as `.sql` files in `phoenix/memory/migrations/`. They
are applied in lexicographic order on first `connect()` and each file
runs in a single transaction. A tiny `_migrations` table tracks which
files have been applied so reconnecting to an existing DB is a no-op.

Rows are returned as `dict` (same shape as the previous sync store so
callers don't need to change). A later pass may introduce Pydantic row
models; keeping dicts for now keeps the blast radius of this change
small.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import time
import uuid
from pathlib import Path

import aiosqlite
import numpy as np

from .config import MemoryParams

log = logging.getLogger(__name__)

MIGRATIONS_DIR = Path(__file__).parent / "migrations"


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


class MemoryStore:
    """Async SQLite store. Call `await store.connect()` before use."""

    def __init__(self, config: MemoryParams | None = None):
        self.config = config or MemoryParams()
        self._db: aiosqlite.Connection | None = None
        # Flipped once on first dim-mismatch encountered during reads so the
        # log doesn't spam every row. Startup guard should catch the bulk
        # case; this covers stray transitional rows only.
        self._dim_mismatch_logged = False
        # Guards the open-and-migrate path against concurrent callers. Without
        # it, two coroutines can both pass the `self._db is not None` fast
        # check before either `aiosqlite.connect` await returns -- the loser
        # orphans its connection AND re-enters `_apply_migrations`, where the
        # second `INSERT INTO _migrations` raises IntegrityError on the PK
        # collision. The happy path (subsequent calls) is still lock-free
        # thanks to the outer `self._db is not None` check.
        self._connect_lock = asyncio.Lock()

    # -- lifecycle --

    async def connect(self) -> None:
        """Open the DB connection, apply any pending migrations. Idempotent
        and safe to call concurrently -- the lock serialises the slow path."""
        if self._db is not None:
            return
        async with self._connect_lock:
            # Re-check inside the lock; a prior caller may have just finished.
            if self._db is not None:
                return
            os.makedirs(os.path.dirname(self.config.db_path), exist_ok=True)
            db = await aiosqlite.connect(self.config.db_path)
            db.row_factory = aiosqlite.Row
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA foreign_keys=ON")
            # Assign to self._db AFTER pragmas but BEFORE migrations so
            # _apply_migrations can use the same connection; keep assignment
            # last in the "publish" sense (nobody can read self._db until
            # the lock is released, and by then migrations are done).
            self._db = db
            try:
                await self._apply_migrations()
                await self._check_embedding_dim()
            except Exception:
                # Migrations failed -- tear down so the next call retries
                # cleanly instead of inheriting a half-built state.
                with contextlib.suppress(Exception):
                    await db.close()
                self._db = None
                raise

    async def close(self) -> None:
        if self._db is not None:
            with contextlib.suppress(Exception):
                await self._db.close()
            self._db = None

    async def _apply_migrations(self) -> None:
        """Apply any `.sql` files in MIGRATIONS_DIR that haven't run yet.

        NOT atomic across script + _migrations row today. `executescript`
        auto-commits at the end of the SQL it runs; the `_migrations` INSERT
        is a second transaction that follows. A crash in that gap leaves the
        schema applied without being recorded, so the migration runs again
        on next boot -- which is fine ONLY because every shipped migration
        must be idempotent (`IF NOT EXISTS` on CREATE, etc.).

        If a future migration needs true atomicity with its tracking row,
        split it into explicit statements and wrap them in a single
        `BEGIN IMMEDIATE ... COMMIT` inside the loop below instead of using
        `executescript`. For 001_initial.sql this doesn't matter -- every
        DDL is `IF NOT EXISTS`-guarded.
        """
        assert self._db is not None
        await self._db.execute(
            "CREATE TABLE IF NOT EXISTS _migrations ("
            " name TEXT PRIMARY KEY, applied_at REAL NOT NULL)"
        )
        await self._db.commit()

        cursor = await self._db.execute("SELECT name FROM _migrations")
        rows = await cursor.fetchall()
        applied = {r["name"] for r in rows}
        await cursor.close()

        files = sorted(p for p in MIGRATIONS_DIR.glob("*.sql") if p.is_file())
        for path in files:
            if path.name in applied:
                continue
            sql = path.read_text(encoding="utf-8")
            try:
                # executescript implicitly commits any open tx first and runs
                # its own. After it returns we explicitly record the migration
                # and commit again. If the insert/commit fails, the script
                # side-effects are already durable -- which is fine ONLY
                # because every shipped migration must be idempotent (`IF NOT
                # EXISTS` guards on CREATE, etc.). If a future migration
                # needs true atomicity with the tracking insert, split it
                # into separate statements and execute them here inside a
                # `BEGIN IMMEDIATE ... COMMIT` instead of executescript.
                await self._db.executescript(sql)
                await self._db.execute(
                    "INSERT INTO _migrations (name, applied_at) VALUES (?, ?)",
                    (path.name, time.time()),
                )
                await self._db.commit()
            except Exception:
                # On partial failure, roll back whatever's still open and
                # bubble up so the caller can tear down the connection.
                with contextlib.suppress(Exception):
                    await self._db.rollback()
                raise

    async def _check_embedding_dim(self) -> None:
        """Verify stored embeddings match the configured dim.

        Switching embedding backends (gemma 768 <-> fastembed 384) after the
        DB has accumulated vectors leaves every read crashing inside
        np.frombuffer(...).reshape(dim). Catch it at boot with an actionable
        message instead of surfacing as a silent per-turn warning.
        """
        assert self._db is not None
        # Sample the most recent write -- it represents the active backend's
        # current state. Sampling an arbitrary row could false-pass on a DB
        # with one stray current-dim row sitting ahead of bulk old-dim rows.
        cursor = await self._db.execute(
            "SELECT embedding FROM memories WHERE embedding IS NOT NULL "
            "ORDER BY created_at DESC LIMIT 1"
        )
        row = await cursor.fetchone()
        await cursor.close()
        if row is None or row[0] is None:
            return
        blob = row[0]
        stored_dim = len(blob) // 4  # float32 = 4 bytes
        if stored_dim == self.config.embedding_dim:
            return
        raise RuntimeError(
            f"Embedding dimension mismatch in {self.config.db_path}:\n"
            f"  stored vectors: dim {stored_dim}\n"
            f"  current backend: dim {self.config.embedding_dim}\n"
            f"\n"
            f"The embedding backend was changed after memories accumulated.\n"
            f"Fix with one of:\n"
            f"  - Run `phoenix --setup` and pick the backend that matches\n"
            f"    the stored dim (gemma=768, fastembed=384).\n"
            f"  - Or set PHOENIX_EMBEDDING_BACKEND to match.\n"
            f"  - Or delete {self.config.db_path} to start fresh under\n"
            f"    the new backend (loses existing memories)."
        )

    def _require_db(self) -> aiosqlite.Connection:
        if self._db is None:
            raise RuntimeError(
                "MemoryStore.connect() must be awaited before any query. "
                "MemorySystem.warm_up() handles this on boot."
            )
        return self._db

    # -- memory CRUD --

    async def add(
        self,
        content: str,
        category: str = "fact",
        namespace: str = "global",
        embedding: np.ndarray | None = None,
        strength: float | None = None,
        source_session: str = "",
        intent: str | None = None,
        prior_value: str | None = None,
        prior_date: float | None = None,
        dimension: str | None = None,
    ) -> str:
        db = self._require_db()
        mid = _new_id()
        now = time.time()
        emb_blob = embedding.astype(np.float32).tobytes() if embedding is not None else None
        strength = strength if strength is not None else self.config.initial_strength

        await db.execute(
            "INSERT INTO memories (id, content, category, namespace, embedding, strength, "
            "access_count, source_session, created_at, last_accessed, intent, "
            "prior_value, prior_date, dimension) "
            "VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)",
            (
                mid,
                content,
                category,
                namespace,
                emb_blob,
                strength,
                source_session,
                now,
                now,
                intent,
                prior_value,
                prior_date,
                dimension,
            ),
        )
        await db.commit()
        return mid

    async def get(self, memory_id: str) -> dict | None:
        db = self._require_db()
        cursor = await db.execute("SELECT * FROM memories WHERE id = ?", (memory_id,))
        row = await cursor.fetchone()
        await cursor.close()
        return self._row_to_dict(row) if row else None

    async def search_text(
        self,
        query: str,
        namespace: str | None = None,
        limit: int = 20,
        category: str | None = None,
    ) -> list[dict]:
        """SELECT memories matching `content LIKE "%query%"` ordered by strength.

        `category` filters server-side so callers that want a scoped view
        (e.g. `notes list`, `build_insights_snapshot`) don't paginate through
        unrelated rows in Python. Leaving it None preserves the
        pre-unification behaviour.
        """
        db = self._require_db()
        sql = "SELECT * FROM memories WHERE content LIKE ? AND superseded_by IS NULL"
        params: list = [f"%{query}%"]
        if namespace:
            sql += " AND namespace = ?"
            params.append(namespace)
        if category:
            sql += " AND category = ?"
            params.append(category)
        sql += " ORDER BY strength DESC LIMIT ?"
        params.append(limit)
        cursor = await db.execute(sql, params)
        rows = await cursor.fetchall()
        await cursor.close()
        return [self._row_to_dict(r) for r in rows]

    async def delete(self, memory_id: str) -> None:
        db = self._require_db()
        await db.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
        await db.execute(
            "DELETE FROM memory_graph WHERE source_id = ? OR target_id = ?",
            (memory_id, memory_id),
        )
        await db.commit()

    async def update_strength(self, memory_id: str, new_strength: float) -> None:
        db = self._require_db()
        await db.execute(
            "UPDATE memories SET strength = ?, last_accessed = ? WHERE id = ?",
            (new_strength, time.time(), memory_id),
        )
        await db.commit()

    async def increment_access(self, memory_id: str) -> None:
        db = self._require_db()
        await db.execute(
            "UPDATE memories SET access_count = access_count + 1, last_accessed = ? WHERE id = ?",
            (time.time(), memory_id),
        )
        await db.commit()

    async def set_pinned(self, memory_id: str, pinned: bool = True) -> None:
        db = self._require_db()
        await db.execute(
            "UPDATE memories SET pinned = ? WHERE id = ?",
            (1 if pinned else 0, memory_id),
        )
        await db.commit()

    async def get_pinned(self, namespace: str | None = None) -> list[dict]:
        db = self._require_db()
        if namespace:
            cursor = await db.execute(
                "SELECT * FROM memories WHERE pinned = 1 "
                "AND (namespace = ? OR namespace = 'global') AND superseded_by IS NULL",
                (namespace,),
            )
        else:
            cursor = await db.execute(
                "SELECT * FROM memories WHERE pinned = 1 AND superseded_by IS NULL"
            )
        rows = await cursor.fetchall()
        await cursor.close()
        return [self._row_to_dict(r) for r in rows]

    async def supersede(self, old_id: str, new_id: str, weaken_factor: float = 0.5) -> None:
        db = self._require_db()
        await db.execute(
            "UPDATE memories SET superseded_by = ?, strength = strength * ? WHERE id = ?",
            (new_id, weaken_factor, old_id),
        )
        await db.commit()

    async def count(self, namespace: str | None = None) -> int:
        db = self._require_db()
        if namespace:
            cursor = await db.execute(
                "SELECT COUNT(*) FROM memories WHERE namespace = ?", (namespace,)
            )
        else:
            cursor = await db.execute("SELECT COUNT(*) FROM memories")
        row = await cursor.fetchone()
        await cursor.close()
        return row[0] if row else 0

    async def stats(self, namespace: str | None = None) -> dict:
        db = self._require_db()
        ns_filter = " WHERE namespace = ?" if namespace else ""
        params: tuple = (namespace,) if namespace else ()

        cursor = await db.execute(f"SELECT COUNT(*) FROM memories{ns_filter}", params)
        total = (await cursor.fetchone())[0]
        await cursor.close()

        if total == 0:
            return {
                "total": 0,
                "by_category": {},
                "by_namespace": {},
                "avg_strength": 0,
                "edge_count": 0,
                "episodes": 0,
                "clusters": 0,
                "pinned": 0,
            }

        cursor = await db.execute(
            f"SELECT category, COUNT(*) FROM memories{ns_filter} GROUP BY category", params
        )
        cats = await cursor.fetchall()
        await cursor.close()

        cursor = await db.execute("SELECT namespace, COUNT(*) FROM memories GROUP BY namespace")
        nss = await cursor.fetchall()
        await cursor.close()

        cursor = await db.execute(f"SELECT AVG(strength) FROM memories{ns_filter}", params)
        avg_str = (await cursor.fetchone())[0]
        await cursor.close()

        cursor = await db.execute("SELECT COUNT(*) FROM memory_graph")
        edges = (await cursor.fetchone())[0]
        await cursor.close()

        cursor = await db.execute("SELECT COUNT(*) FROM episodes")
        episodes = (await cursor.fetchone())[0]
        await cursor.close()

        cursor = await db.execute(
            "SELECT COUNT(*) FROM memories"
            " WHERE content LIKE '[consolidated]%'"
            " AND superseded_by IS NULL"
        )
        clusters = (await cursor.fetchone())[0]
        await cursor.close()

        ns_clause = " AND namespace = ?" if namespace else ""
        cursor = await db.execute(
            f"SELECT COUNT(*) FROM memories WHERE pinned = 1{ns_clause}", params
        )
        pinned = (await cursor.fetchone())[0]
        await cursor.close()

        return {
            "total": total,
            "by_category": {r[0]: r[1] for r in cats},
            "by_namespace": {r[0]: r[1] for r in nss},
            "avg_strength": round(avg_str or 0, 3),
            "edge_count": edges,
            "episodes": episodes,
            "clusters": clusters,
            "pinned": pinned,
        }

    # -- decay --

    async def decay_edges(self, decay_rate: float = 0.02, min_weight: float = 0.01) -> None:
        db = self._require_db()
        await db.execute("UPDATE memory_graph SET weight = weight - ?", (decay_rate,))
        await db.execute("DELETE FROM memory_graph WHERE weight < ?", (min_weight,))
        await db.commit()

    # -- graph --

    async def add_edge(
        self,
        source_id: str,
        target_id: str,
        weight: float,
        reinforce_amount: float = 0.1,
    ) -> None:
        db = self._require_db()
        a, b = (source_id, target_id) if source_id < target_id else (target_id, source_id)
        await db.execute(
            "INSERT INTO memory_graph (source_id, target_id, weight) VALUES (?, ?, ?) "
            "ON CONFLICT(source_id, target_id) DO UPDATE SET weight = MIN(weight + ?, 1.0)",
            (a, b, weight, reinforce_amount),
        )
        await db.commit()

    async def get_neighbors(self, memory_id: str) -> list[tuple[str, float]]:
        db = self._require_db()
        cursor = await db.execute(
            "SELECT source_id, target_id, weight FROM memory_graph "
            "WHERE source_id = ? OR target_id = ?",
            (memory_id, memory_id),
        )
        rows = await cursor.fetchall()
        await cursor.close()
        return [
            (r["target_id"] if r["source_id"] == memory_id else r["source_id"], r["weight"])
            for r in rows
        ]

    async def get_neighbors_many(self, memory_ids: list[str]) -> dict[str, list[tuple[str, float]]]:
        """Batched variant of `get_neighbors` -- one query per call regardless
        of how many ids. Returns a mapping from each input id to its neighbor
        list. Used by RecallEngine's spreading-activation BFS to collapse
        up to N per-node round-trips into one per-BFS-level.

        SQLite's SQLITE_MAX_VARIABLE_NUMBER defaults to 999; we chunk at 400
        ids per query (each id appears twice in the query, once for source
        and once for target) to stay well under the limit.
        """
        db = self._require_db()
        result: dict[str, list[tuple[str, float]]] = {mid: [] for mid in memory_ids}
        if not memory_ids:
            return result

        id_set = set(memory_ids)
        CHUNK = 400
        for start in range(0, len(memory_ids), CHUNK):
            batch = memory_ids[start : start + CHUNK]
            placeholders = ",".join("?" * len(batch))
            cursor = await db.execute(
                f"SELECT source_id, target_id, weight FROM memory_graph "
                f"WHERE source_id IN ({placeholders}) "
                f"OR target_id IN ({placeholders})",
                tuple(batch) + tuple(batch),
            )
            rows = await cursor.fetchall()
            await cursor.close()
            for r in rows:
                src, tgt, w = r["source_id"], r["target_id"], r["weight"]
                # The edge (src, tgt) might match one, both, or neither of
                # our requested ids -- only append to the side(s) that were
                # requested. (Both sides requested is possible when two ids
                # in the batch are directly connected.)
                if src in id_set:
                    result[src].append((tgt, w))
                if tgt in id_set and tgt != src:
                    result[tgt].append((src, w))
        return result

    # -- embeddings --

    async def get_all_embeddings(
        self, namespace: str | None = None
    ) -> tuple[list[str], np.ndarray, list[dict]]:
        """Fetch all live embeddings in a namespace AND their full rows.

        Returns ``(ids, matrix, rows)`` where ``rows[i]`` is the full memory
        dict for ``ids[i]`` with ``embedding`` rewritten as a view into
        ``matrix`` (zero-copy). Callers can index into ``rows`` directly in
        their scoring loop instead of re-fetching each row via
        ``store.get(mid)`` -- that round-trip storm was the dominant
        per-recall latency at N >= 100.

        The third tuple element is a new addition in this release. Callers
        that only need ``(ids, matrix)`` can still unpack with
        ``ids, matrix, _ = await store.get_all_embeddings(ns)``.
        """
        db = self._require_db()
        if namespace:
            cursor = await db.execute(
                "SELECT * FROM memories WHERE embedding IS NOT NULL "
                "AND (namespace = ? OR namespace = 'global') "
                "AND superseded_by IS NULL ORDER BY strength DESC",
                (namespace,),
            )
        else:
            cursor = await db.execute(
                "SELECT * FROM memories WHERE embedding IS NOT NULL "
                "AND superseded_by IS NULL ORDER BY strength DESC"
            )
        raw_rows = await cursor.fetchall()
        await cursor.close()
        if not raw_rows:
            return [], np.array([]).reshape(0, self.config.embedding_dim), []

        dim = self.config.embedding_dim
        expected_bytes = dim * 4
        ids: list[str] = []
        vecs: list[np.ndarray] = []
        dicts: list[dict] = []
        for r in raw_rows:
            d = dict(r)
            blob = d["embedding"]
            if len(blob) != expected_bytes:
                self._log_dim_mismatch_once(len(blob) // 4)
                continue
            ids.append(d["id"])
            vec = np.frombuffer(blob, dtype=np.float32).reshape(dim)
            vecs.append(vec)
            dicts.append(d)
        if not vecs:
            return [], np.array([]).reshape(0, dim), []
        matrix = np.stack(vecs)
        # Flag the backing buffer read-only so any caller that *tries* to
        # mutate `mem["embedding"]` (or `matrix` itself) raises ValueError
        # instead of silently scribbling on every row's view. Views inherit
        # the parent's writeable flag -- one line, closes R3 from the audit.
        matrix.setflags(write=False)
        # Rewrite each row's embedding as a view into the stacked matrix so
        # callers get zero-copy access; `mem["embedding"]` is now matrix[i],
        # not a freshly-decoded buffer.
        for i, d in enumerate(dicts):
            d["embedding"] = matrix[i]
        return ids, matrix, dicts

    # -- episodes --

    async def add_episode(
        self,
        user_input: str,
        ai_output: str,
        namespace: str = "global",
        session_id: str = "",
        turn_number: int = 0,
    ) -> str:
        db = self._require_db()
        eid = _new_id()
        # ai_output stored in full -- no truncation. `episodes` is the
        # permanent transcript table (schema TEXT, unbounded), used by the
        # --continue session-restore path. Truncating here silently lost
        # the tail of every response >500 chars. Storage cost is modest:
        # typical AI response is 1-3 KB, so 1k episodes ~ 3 MB, and
        # SQLite TEXT compresses well at rest.
        await db.execute(
            "INSERT INTO episodes (id, user_input, ai_output, namespace, session_id, "
            "turn_number, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (eid, user_input, ai_output, namespace, session_id, turn_number, time.time()),
        )
        await db.commit()
        return eid

    async def get_episode_timestamps(self, limit: int = 200) -> list[float]:
        db = self._require_db()
        cursor = await db.execute(
            "SELECT created_at FROM episodes ORDER BY created_at DESC LIMIT ?", (limit,)
        )
        rows = await cursor.fetchall()
        await cursor.close()
        return [r[0] for r in rows if r[0]]

    # -- internal --

    def _row_to_dict(self, row: aiosqlite.Row) -> dict:
        d = dict(row)
        # `is not None` rather than truthiness: an all-zero BLOB (possible
        # from TF-IDF backend on stopword-only text) is falsy but valid.
        if d.get("embedding") is not None:
            blob = d["embedding"]
            expected_bytes = self.config.embedding_dim * 4
            if len(blob) != expected_bytes:
                self._log_dim_mismatch_once(len(blob) // 4)
                d["embedding"] = None
            else:
                d["embedding"] = np.frombuffer(blob, dtype=np.float32).reshape(
                    self.config.embedding_dim
                )
        return d

    def _log_dim_mismatch_once(self, stored_dim: int) -> None:
        if self._dim_mismatch_logged:
            return
        self._dim_mismatch_logged = True
        log.warning(
            "Skipping memory rows with embedding dim %d (current backend expects %d). "
            "Startup guard passed but stray rows exist -- run setup to reconcile.",
            stored_dim,
            self.config.embedding_dim,
        )
