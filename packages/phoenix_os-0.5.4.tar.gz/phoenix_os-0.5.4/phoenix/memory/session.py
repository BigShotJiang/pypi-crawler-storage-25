"""Topic-based session context -- tracks topic boundaries, summarizes completed topics.

Architecture:
  - Each conversation is a sequence of TOPICS, not a flat list of messages
  - Within the active topic: full messages kept (model needs the detail)
  - Completed topics: LLM-summarized into structured TopicAnalysis
  - On session exit: all topic summaries compacted into one session summary
  - On --continue: session summary loaded from memory, full context restored

Cost model:
  - One LLM call per topic shift (~2.2k tokens every ~10 turns)
  - Per-turn context is FLAT (~4-5k tokens regardless of session length)
  - Full history approach: O(n^2). This approach: O(n).
"""

import logging
import re
import time
from dataclasses import dataclass, field

from pydantic import BaseModel, Field

log = logging.getLogger(__name__)

# Trigger topic analysis every N turns, or when active topic exceeds token budget
ANALYSIS_INTERVAL = 5
ACTIVE_TOKEN_BUDGET = 3000
MIN_TOPIC_TURNS = 3

# Explicit topic shift signals
_SHIFT_PATTERNS = re.compile(
    r"(?:^|\b)("
    r"now let'?s|moving on|next thing|switch(?:ing)? to|"
    r"let'?s move|different topic|change topic|"
    r"ok next|alright now|anyway|"
    r"new task|on to|let'?s talk about"
    r")(?:\b|$)",
    re.IGNORECASE,
)


class TopicAnalysis(BaseModel):
    """Structured output from LLM topic analysis."""

    same_topic: bool = Field(description="True if the conversation is still on the same topic")
    topic_label: str = Field(description="Short label for the topic (3-6 words)")
    summary: str = Field(
        default="",
        description="Summary of the completed topic. Only if same_topic is False.",
    )
    key_decisions: list[str] = Field(
        default_factory=list,
        description="Key decisions made during this topic",
    )
    files_involved: list[str] = Field(
        default_factory=list,
        description="Files that were read, edited, or discussed",
    )
    open_threads: list[str] = Field(
        default_factory=list,
        description="Unresolved questions or next steps to carry forward",
    )


class SessionSummary(BaseModel):
    """Compact summary of an entire session."""

    summary: str = Field(description="2-3 sentence summary of the session")
    topics_covered: list[str] = Field(
        default_factory=list,
        description="List of topic labels covered",
    )
    key_outcomes: list[str] = Field(
        default_factory=list,
        description="Main things accomplished",
    )
    open_threads: list[str] = Field(
        default_factory=list,
        description="Unresolved items to carry to next session",
    )


@dataclass
class CompletedTopic:
    """A summarized, completed topic."""

    label: str
    summary: str
    decisions: list[str]
    files: list[str]
    open_threads: list[str]
    turn_count: int
    started_at: float
    ended_at: float
    # Full, untruncated (user_input, ai_output) of the last exchange in
    # this topic. Rendered verbatim in build_context() on the NEXT turn
    # after a topic shift so the model inherits the concrete handoff
    # state, not just the abstract summary. `None` only if the topic
    # completed without ever adding a turn (edge case).
    last_exchange: tuple[str, str] | None = None


@dataclass
class ActiveTopic:
    """The currently active topic with full message history."""

    messages: list[tuple[str, str]] = field(default_factory=list)
    tool_actions: list[str] = field(default_factory=list)
    files_touched: set[str] = field(default_factory=set)
    turn_count: int = 0
    started_at: float = field(default_factory=time.time)
    label: str = ""
    # Full-fidelity last (user_input, ai_output) pair. `messages` stores
    # a 500-char-truncated copy of ai_output to keep the topic-classifier
    # LLM input cheap; `last_exchange` keeps the full text so the bridge
    # into the next topic doesn't smudge right where continuity matters
    # most. Reset to None when a new ActiveTopic starts after a shift.
    last_exchange: tuple[str, str] | None = None

    def add_turn(
        self,
        user_input: str,
        ai_output: str,
        tool_calls: list[dict] | None = None,
    ):
        self.messages.append((user_input, ai_output[:500]))
        self.last_exchange = (user_input, ai_output)
        self.turn_count += 1

        if tool_calls:
            for tc in tool_calls:
                if not isinstance(tc, dict):
                    continue
                name = tc.get("name", "") or ""
                args = tc.get("args") or {}
                result = str(tc.get("result", "") or "")[:100]
                if name:
                    self.tool_actions.append(f"{name}: {result}")

                if name in ("read_file", "write_file", "search_replace") and isinstance(args, dict):
                    path = args.get("path", args.get("file_path", ""))
                    if path:
                        self.files_touched.add(path)

        # Keep tool actions bounded
        if len(self.tool_actions) > 20:
            self.tool_actions = self.tool_actions[-15:]

    def estimate_tokens(self) -> int:
        """Rough token estimate for active messages."""
        total = 0
        for user, ai in self.messages:
            total += len(user.split()) + len(ai.split())
        return int(total * 1.3)

    def format_for_history(self) -> list[tuple[str, str]]:
        """Return messages for pydantic-ai message_history."""
        return list(self.messages)

    def format_for_analysis(self) -> str:
        """Format messages for the LLM topic analysis call."""
        lines = []
        for i, (user, ai) in enumerate(self.messages, 1):
            lines.append(f"Turn {i}:")
            lines.append(f"  User: {user}")
            ai_short = ai[:300] + "..." if len(ai) > 300 else ai
            lines.append(f"  Phoenix: {ai_short}")
        if self.tool_actions:
            lines.append("\nTool actions:")
            for action in self.tool_actions[-10:]:
                lines.append(f"  - {action}")
        return "\n".join(lines)


_ANALYSIS_PROMPT = """Analyze this conversation segment from an AI assistant session.

Conversation:
{conversation}

Previous topic label: {prev_label}

Determine:
1. Is this still the same topic as "{prev_label}", or has the user shifted to a new topic?
2. Give a short label for the current/new topic (3-6 words).
3. If shifted: summarize the COMPLETED topic (what was discussed, done, decided).
4. List key decisions made.
5. List files that were involved.
6. List any unresolved questions or next steps."""


class TopicTracker:
    """Tracks topic boundaries, manages summaries, builds context."""

    def __init__(self, model: str, session_id: str = ""):
        self._model = model
        self._session_id = session_id
        self._active = ActiveTopic()
        self._completed: list[CompletedTopic] = []
        self._total_turns = 0
        self._turns_since_analysis = 0

    async def process_turn(
        self,
        user_input: str,
        ai_output: str,
        tool_calls: list[dict] | None = None,
    ):
        """Called after each turn. Detects topic shift, updates state."""
        self._active.add_turn(user_input, ai_output, tool_calls)
        self._total_turns += 1
        self._turns_since_analysis += 1

        should_check = (
            self._turns_since_analysis >= ANALYSIS_INTERVAL
            or self._active.estimate_tokens() > ACTIVE_TOKEN_BUDGET
            or self._has_explicit_shift(user_input)
        )

        if should_check and self._active.turn_count >= MIN_TOPIC_TURNS:
            await self._analyze_and_maybe_split()

    async def _analyze_and_maybe_split(self):
        """Run LLM analysis to detect topic shift."""
        self._turns_since_analysis = 0

        try:
            from pydantic_ai import Agent

            conversation = self._active.format_for_analysis()
            prev_label = self._active.label or "start of conversation"

            prompt = _ANALYSIS_PROMPT.format(
                conversation=conversation,
                prev_label=prev_label,
            )

            agent = Agent(
                self._model,
                output_type=TopicAnalysis,
                instructions=(
                    "You analyze conversation segments to detect topic shifts. "
                    "Be concise in summaries. Focus on what was DONE and DECIDED."
                ),
            )
            result = await agent.run(prompt)
            analysis = result.output

            if analysis.same_topic:
                # Update label if we didn't have one
                if not self._active.label:
                    self._active.label = analysis.topic_label
                log.debug("Topic continues: %s", analysis.topic_label)
            else:
                # Topic shifted -- summarize and archive
                completed = CompletedTopic(
                    label=analysis.topic_label or self._active.label or "untitled",
                    summary=analysis.summary,
                    decisions=analysis.key_decisions,
                    files=analysis.files_involved,
                    open_threads=analysis.open_threads,
                    turn_count=self._active.turn_count,
                    started_at=self._active.started_at,
                    ended_at=time.time(),
                    last_exchange=self._active.last_exchange,
                )
                self._completed.append(completed)
                log.info(
                    "Topic completed: '%s' (%d turns) -> new topic",
                    completed.label,
                    completed.turn_count,
                )

                # Keep last 2 messages as bridge to new topic
                msgs = self._active.messages
                bridge = msgs[-2:] if len(msgs) >= 2 else msgs
                self._active = ActiveTopic(
                    messages=list(bridge),
                    turn_count=len(bridge),
                    started_at=time.time(),
                    label="",
                )

        except Exception as e:
            log.warning("Topic analysis failed: %s", e)

    def build_context(self) -> str:
        """Build context string: completed topic summaries.

        The MOST RECENT completed topic also gets a verbatim
        `--- Last exchange ---` block (full user_input + ai_output of
        the final turn before the shift). This bundles abstract
        (summary) + concrete (last exchange) into one handoff artifact
        so the new topic inherits the live state, not just the gist.

        Older topics: summary only -- their last exchange is stale and
        carrying it forward forever bloats the context block.
        """
        if not self._completed:
            return ""

        parts = []
        # Show last 5 completed topics
        recent = self._completed[-5:]
        for topic in recent:
            section = [f"[Completed: {topic.label}]"]
            if topic.summary:
                section.append(f"  {topic.summary}")
            if topic.decisions:
                section.append(f"  Decisions: {'; '.join(topic.decisions[:5])}")
            if topic.files:
                section.append(f"  Files: {', '.join(topic.files[:8])}")
            if topic.open_threads:
                section.append(f"  Open: {'; '.join(topic.open_threads[:3])}")
            # Full last exchange ONLY on the most recent completed
            # topic -- it's the one we just bridged from.
            if topic is recent[-1] and topic.last_exchange is not None:
                user_msg, ai_msg = topic.last_exchange
                section.append("  --- Last exchange ---")
                section.append(f"  Boss: {user_msg}")
                section.append(f"  Phoenix: {ai_msg}")
            parts.append("\n".join(section))

        return "\n\n".join(parts)

    def get_active_messages(self) -> list[tuple[str, str]]:
        """Get current topic's messages for pydantic-ai history."""
        return self._active.format_for_history()

    async def create_session_summary(self) -> str | None:
        """On session exit: compact all topics into one summary."""
        # Summarize active topic first if it has content
        if self._active.turn_count >= MIN_TOPIC_TURNS:
            await self._analyze_and_maybe_split()

        if not self._completed:
            return None

        try:
            from pydantic_ai import Agent

            topics_text = "\n".join(f"- {t.label}: {t.summary}" for t in self._completed)

            agent = Agent(
                self._model,
                output_type=SessionSummary,
                instructions=(
                    "Summarize this session into a compact overview. "
                    "Focus on what was accomplished and what's pending."
                ),
            )
            result = await agent.run(
                f"Session topics:\n{topics_text}\n\nTotal turns: {self._total_turns}"
            )
            summary = result.output

            text_parts = [summary.summary]
            if summary.key_outcomes:
                text_parts.append("Done: " + "; ".join(summary.key_outcomes))
            if summary.open_threads:
                text_parts.append("Pending: " + "; ".join(summary.open_threads))
            return "\n".join(text_parts)

        except Exception as e:
            log.warning("Session summary failed: %s", e)
            # Fallback: concatenate topic summaries
            return "\n".join(f"- {t.label}: {t.summary}" for t in self._completed)

    def _has_explicit_shift(self, text: str) -> bool:
        return bool(_SHIFT_PATTERNS.search(text))

    @property
    def active_topic_label(self) -> str:
        return self._active.label

    @property
    def completed_count(self) -> int:
        return len(self._completed)

    @property
    def total_turns(self) -> int:
        return self._total_turns

    @property
    def active_turn_count(self) -> int:
        return self._active.turn_count
