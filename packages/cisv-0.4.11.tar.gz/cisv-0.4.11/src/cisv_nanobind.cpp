/**
 * CISV Python Bindings using nanobind
 *
 * High-performance bindings that use the batch API to eliminate
 * per-field callback overhead. This provides 10-100x speedup over
 * ctypes-based bindings.
 */

#include <nanobind/nanobind.h>
#include <nanobind/stl/string.h>
#include <nanobind/stl/vector.h>
#include <nanobind/ndarray.h>
#include <stdexcept>
#include <string>
#include <cstring>
#include <thread>
#include <vector>
#include <atomic>
#if (defined(__x86_64__) || defined(__amd64__) || defined(_M_X64)) && (defined(__GNUC__) || defined(__clang__))
#include <immintrin.h>
#endif

extern "C" {
#include "cisv/parser.h"
}

namespace nb = nanobind;

static void validate_char_option(const char *name, const std::string &value) {
    if (value.empty() || value.size() > 1) {
        throw std::invalid_argument(std::string(name) + " must be a single character");
    }
    if (value[0] == '\0' || value[0] == '\n' || value[0] == '\r') {
        throw std::invalid_argument(std::string(name) + " cannot be NUL or newline");
    }
}

static void validate_optional_char_option(const char *name, const std::string &value) {
    if (value.size() > 1) {
        throw std::invalid_argument(std::string(name) + " must be empty or a single character");
    }
    if (!value.empty() && (value[0] == '\0' || value[0] == '\n' || value[0] == '\r')) {
        throw std::invalid_argument(std::string(name) + " cannot be NUL or newline");
    }
}

static void validate_num_threads(int num_threads) {
    if (num_threads < 0) {
        throw std::invalid_argument("num_threads must be >= 0");
    }
}

static cisv_config make_config(
    const std::string &delimiter,
    const std::string &quote,
    const std::string &escape,
    const std::string &comment,
    bool trim,
    bool skip_empty_lines,
    bool relaxed,
    bool skip_lines_with_error,
    size_t max_row_size,
    int from_line,
    int to_line
) {
    validate_char_option("Delimiter", delimiter);
    validate_char_option("Quote", quote);
    validate_optional_char_option("Escape", escape);
    validate_optional_char_option("Comment", comment);

    if (from_line < 0) {
        throw std::invalid_argument("from_line must be >= 0");
    }
    if (to_line < 0) {
        throw std::invalid_argument("to_line must be >= 0");
    }

    int effective_from = from_line > 0 ? from_line : 1;
    if (to_line != 0 && to_line < effective_from) {
        throw std::invalid_argument("to_line must be >= from_line");
    }

    char delimiter_char = delimiter[0];
    char quote_char = quote[0];
    char escape_char = escape.empty() ? '\0' : escape[0];
    char comment_char = comment.empty() ? '\0' : comment[0];

    if (delimiter_char == quote_char) {
        throw std::invalid_argument("delimiter and quote cannot be the same");
    }
    if (escape_char != '\0' && escape_char == delimiter_char) {
        throw std::invalid_argument("escape and delimiter cannot be the same");
    }
    if (escape_char != '\0' && escape_char == quote_char) {
        throw std::invalid_argument("escape and quote cannot be the same");
    }
    if (comment_char != '\0' &&
        (comment_char == delimiter_char || comment_char == quote_char || comment_char == escape_char)) {
        throw std::invalid_argument("comment cannot conflict with delimiter, quote, or escape");
    }

    cisv_config config;
    cisv_config_init(&config);
    config.delimiter = delimiter_char;
    config.quote = quote_char;
    config.escape = escape_char;
    config.comment = comment_char;
    config.trim = trim;
    config.skip_empty_lines = skip_empty_lines;
    config.relaxed = relaxed;
    config.skip_lines_with_error = skip_lines_with_error;
    config.max_row_size = max_row_size;
    config.from_line = from_line;
    config.to_line = to_line;
    return config;
}

static bool can_use_simple_raw_fast_path(const cisv_config &config) {
    return config.escape == '\0' &&
           config.comment == '\0' &&
           !config.trim &&
           !config.skip_empty_lines &&
           !config.relaxed &&
           !config.skip_lines_with_error &&
           config.max_row_size == 0 &&
           config.from_line <= 1 &&
           config.to_line == 0;
}

static nb::tuple make_raw_arrays(
    uint8_t *data_buf,
    size_t total_data_size,
    uint64_t *field_offsets,
    uint32_t *field_lengths,
    size_t total_fields,
    uint64_t *row_offsets,
    size_t total_rows,
    nb::capsule data_owner
) {
    nb::capsule offsets_owner(field_offsets, [](void *p) noexcept { delete[] (uint64_t*)p; });
    nb::capsule lengths_owner(field_lengths, [](void *p) noexcept { delete[] (uint32_t*)p; });
    nb::capsule rows_owner(row_offsets, [](void *p) noexcept { delete[] (uint64_t*)p; });

    size_t data_shape[1] = {total_data_size};
    size_t fields_shape[1] = {total_fields};
    size_t rows_shape[1] = {total_rows + 1};

    auto data_arr = nb::ndarray<nb::numpy, uint8_t, nb::shape<-1>>(
        data_buf, 1, data_shape, data_owner);
    auto offsets_arr = nb::ndarray<nb::numpy, uint64_t, nb::shape<-1>>(
        field_offsets, 1, fields_shape, offsets_owner);
    auto lengths_arr = nb::ndarray<nb::numpy, uint32_t, nb::shape<-1>>(
        field_lengths, 1, fields_shape, lengths_owner);
    auto rows_arr = nb::ndarray<nb::numpy, uint64_t, nb::shape<-1>>(
        row_offsets, 1, rows_shape, rows_owner);

    return nb::make_tuple(data_arr, offsets_arr, lengths_arr, rows_arr);
}

static nb::tuple make_raw_arrays_from_vectors(
    uint8_t *data_buf,
    size_t total_data_size,
    std::vector<uint64_t> &&field_offsets,
    std::vector<uint32_t> &&field_lengths,
    std::vector<uint64_t> &&row_offsets,
    nb::capsule data_owner
) {
    auto *offsets_vec = new std::vector<uint64_t>(std::move(field_offsets));
    auto *lengths_vec = new std::vector<uint32_t>(std::move(field_lengths));
    auto *rows_vec = new std::vector<uint64_t>(std::move(row_offsets));

    nb::capsule offsets_owner(offsets_vec, [](void *p) noexcept {
        delete (std::vector<uint64_t>*)p;
    });
    nb::capsule lengths_owner(lengths_vec, [](void *p) noexcept {
        delete (std::vector<uint32_t>*)p;
    });
    nb::capsule rows_owner(rows_vec, [](void *p) noexcept {
        delete (std::vector<uint64_t>*)p;
    });

    size_t data_shape[1] = {total_data_size};
    size_t fields_shape[1] = {offsets_vec->size()};
    size_t rows_shape[1] = {rows_vec->size()};

    auto data_arr = nb::ndarray<nb::numpy, uint8_t, nb::shape<-1>>(
        data_buf, 1, data_shape, data_owner);
    auto offsets_arr = nb::ndarray<nb::numpy, uint64_t, nb::shape<-1>>(
        offsets_vec->data(), 1, fields_shape, offsets_owner);
    auto lengths_arr = nb::ndarray<nb::numpy, uint32_t, nb::shape<-1>>(
        lengths_vec->data(), 1, fields_shape, lengths_owner);
    auto rows_arr = nb::ndarray<nb::numpy, uint64_t, nb::shape<-1>>(
        rows_vec->data(), 1, rows_shape, rows_owner);

    return nb::make_tuple(data_arr, offsets_arr, lengths_arr, rows_arr);
}

static inline void push_simple_field(
    std::vector<uint64_t> &field_offsets,
    std::vector<uint32_t> &field_lengths,
    std::vector<uint64_t> &row_offsets,
    size_t field_start,
    size_t pos,
    size_t size,
    bool is_newline
) {
    field_offsets.push_back(static_cast<uint64_t>(field_start));
    field_lengths.push_back(static_cast<uint32_t>(pos - field_start));
    if (is_newline && pos + 1 < size) {
        row_offsets.push_back(static_cast<uint64_t>(field_offsets.size()));
    }
}

static bool index_simple_scalar(
    const uint8_t *data,
    size_t size,
    uint8_t delimiter,
    uint8_t quote,
    std::vector<uint64_t> &field_offsets,
    std::vector<uint32_t> &field_lengths,
    std::vector<uint64_t> &row_offsets
) {
    size_t field_start = 0;
    for (size_t i = 0; i < size; i++) {
        const uint8_t c = data[i];
        if (c == quote || c == '\r') {
            return false;
        }
        if (c == delimiter || c == '\n') {
            push_simple_field(
                field_offsets,
                field_lengths,
                row_offsets,
                field_start,
                i,
                size,
                c == '\n');
            field_start = i + 1;
        }
    }
    if (data[size - 1] != '\n') {
        field_offsets.push_back(static_cast<uint64_t>(field_start));
        field_lengths.push_back(static_cast<uint32_t>(size - field_start));
    }
    row_offsets.push_back(static_cast<uint64_t>(field_offsets.size()));
    return true;
}

#if (defined(__x86_64__) || defined(__amd64__) || defined(_M_X64)) && (defined(__GNUC__) || defined(__clang__))
__attribute__((target("avx2")))
static bool index_simple_avx2(
    const uint8_t *data,
    size_t size,
    uint8_t delimiter,
    uint8_t quote,
    std::vector<uint64_t> &field_offsets,
    std::vector<uint32_t> &field_lengths,
    std::vector<uint64_t> &row_offsets
) {
    const __m256i delimiter_v = _mm256_set1_epi8(static_cast<char>(delimiter));
    const __m256i newline_v = _mm256_set1_epi8('\n');
    const __m256i quote_v = _mm256_set1_epi8(static_cast<char>(quote));
    const __m256i cr_v = _mm256_set1_epi8('\r');

    size_t field_start = 0;
    size_t i = 0;
    while (i + 32 <= size) {
        const __m256i chunk = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(data + i));
        const uint32_t bad_mask = static_cast<uint32_t>(_mm256_movemask_epi8(
            _mm256_or_si256(
                _mm256_cmpeq_epi8(chunk, quote_v),
                _mm256_cmpeq_epi8(chunk, cr_v))));
        if (bad_mask != 0) {
            return false;
        }

        uint32_t delimiter_mask = static_cast<uint32_t>(_mm256_movemask_epi8(
            _mm256_cmpeq_epi8(chunk, delimiter_v)));
        uint32_t newline_mask = static_cast<uint32_t>(_mm256_movemask_epi8(
            _mm256_cmpeq_epi8(chunk, newline_v)));
        uint32_t structural_mask = delimiter_mask | newline_mask;

        while (structural_mask != 0) {
            const uint32_t bit = static_cast<uint32_t>(__builtin_ctz(structural_mask));
            const size_t pos = i + bit;
            const uint32_t bit_mask = 1U << bit;
            push_simple_field(
                field_offsets,
                field_lengths,
                row_offsets,
                field_start,
                pos,
                size,
                (newline_mask & bit_mask) != 0);
            field_start = pos + 1;
            structural_mask &= structural_mask - 1;
        }

        i += 32;
    }

    for (; i < size; i++) {
        const uint8_t c = data[i];
        if (c == quote || c == '\r') {
            return false;
        }
        if (c == delimiter || c == '\n') {
            push_simple_field(
                field_offsets,
                field_lengths,
                row_offsets,
                field_start,
                i,
                size,
                c == '\n');
            field_start = i + 1;
        }
    }

    if (data[size - 1] != '\n') {
        field_offsets.push_back(static_cast<uint64_t>(field_start));
        field_lengths.push_back(static_cast<uint32_t>(size - field_start));
    }
    row_offsets.push_back(static_cast<uint64_t>(field_offsets.size()));
    return true;
}
#endif

static bool index_simple_csv(
    const uint8_t *data,
    size_t size,
    uint8_t delimiter,
    uint8_t quote,
    std::vector<uint64_t> &field_offsets,
    std::vector<uint32_t> &field_lengths,
    std::vector<uint64_t> &row_offsets
) {
#if (defined(__x86_64__) || defined(__amd64__) || defined(_M_X64)) && (defined(__GNUC__) || defined(__clang__))
    if (__builtin_cpu_supports("avx2")) {
        return index_simple_avx2(
            data, size, delimiter, quote, field_offsets, field_lengths, row_offsets);
    }
#endif
    return index_simple_scalar(
        data, size, delimiter, quote, field_offsets, field_lengths, row_offsets);
}

static bool try_parse_file_raw_simple(
    const std::string &path,
    const cisv_config &config,
    nb::tuple *out
) {
    if (!can_use_simple_raw_fast_path(config)) {
        return false;
    }

    cisv_mmap_file_t *mmap_file = cisv_mmap_open(path.c_str());
    if (!mmap_file) {
        return false;
    }
    std::unique_ptr<cisv_mmap_file_t, decltype(&cisv_mmap_close)> mmap_guard(
        mmap_file, cisv_mmap_close);
    if (mmap_file->size == 0) {
        return false;
    }

    const uint8_t *data = mmap_file->data;
    const size_t size = mmap_file->size;
    if (size >= 3 && data[0] == 0xEF && data[1] == 0xBB && data[2] == 0xBF) {
        return false;
    }

    std::vector<uint64_t> field_offsets;
    std::vector<uint32_t> field_lengths;
    std::vector<uint64_t> row_offsets;

    size_t reserve_fields = (size / 12) + 1024;
    if (reserve_fields < 1024) {
        reserve_fields = 1024;
    }
    field_offsets.reserve(reserve_fields);
    field_lengths.reserve(reserve_fields);
    row_offsets.reserve((size / 64) + 1024);
    row_offsets.push_back(0);

    if (!index_simple_csv(
            data,
            size,
            static_cast<uint8_t>(config.delimiter),
            static_cast<uint8_t>(config.quote),
            field_offsets,
            field_lengths,
            row_offsets)) {
        return false;
    }

    nb::capsule data_owner(mmap_guard.release(), [](void *p) noexcept {
        cisv_mmap_close((cisv_mmap_file_t*)p);
    });
    *out = make_raw_arrays_from_vectors(
        mmap_file->data,
        mmap_file->size,
        std::move(field_offsets),
        std::move(field_lengths),
        std::move(row_offsets),
        data_owner);
    return true;
}

/**
 * Parse a CSV file and return all rows at once.
 *
 * Uses the batch API to collect all data in C, then converts to Python
 * in a single pass. This eliminates the per-field callback overhead
 * that makes ctypes bindings slow.
 */
static nb::list parse_file(
    const std::string &path,
    const std::string &delimiter = ",",
    const std::string &quote = "\"",
    bool trim = false,
    bool skip_empty_lines = false,
    const std::string &escape = "",
    const std::string &comment = "",
    bool relaxed = false,
    bool skip_lines_with_error = false,
    size_t max_row_size = 0,
    int from_line = 1,
    int to_line = 0
) {
    // Validate inputs
    if (path.empty()) {
        throw std::invalid_argument("Path cannot be empty");
    }

    // Setup config
    cisv_config config = make_config(
        delimiter, quote, escape, comment, trim, skip_empty_lines,
        relaxed, skip_lines_with_error, max_row_size, from_line, to_line);

    // Parse file using batch API
    cisv_result_t *result = nullptr;
    {
        nb::gil_scoped_release release;
        result = cisv_parse_file_batch(path.c_str(), &config);
    }

    if (!result) {
        throw std::runtime_error("Failed to parse file: " + std::string(strerror(errno)));
    }

    if (result->error_code != 0) {
        std::string msg = result->error_message;
        cisv_result_free(result);
        throw std::runtime_error(msg);
    }

    // Convert to Python list (single conversion pass)
    nb::list rows;
    for (size_t i = 0; i < result->row_count; i++) {
        nb::list row;
        cisv_row_t *r = &result->rows[i];
        for (size_t j = 0; j < r->field_count; j++) {
            // Create Python string from field data
            row.append(nb::str(r->fields[j], r->field_lengths[j]));
        }
        rows.append(row);
    }

    cisv_result_free(result);
    return rows;
}

/**
 * Parse a CSV string and return all rows at once.
 */
static nb::list parse_string(
    const std::string &data,
    const std::string &delimiter = ",",
    const std::string &quote = "\"",
    bool trim = false,
    bool skip_empty_lines = false,
    const std::string &escape = "",
    const std::string &comment = "",
    bool relaxed = false,
    bool skip_lines_with_error = false,
    size_t max_row_size = 0,
    int from_line = 1,
    int to_line = 0
) {
    // Setup config
    cisv_config config = make_config(
        delimiter, quote, escape, comment, trim, skip_empty_lines,
        relaxed, skip_lines_with_error, max_row_size, from_line, to_line);

    // Parse string using batch API
    cisv_result_t *result = nullptr;
    {
        nb::gil_scoped_release release;
        result = cisv_parse_string_batch(data.c_str(), data.size(), &config);
    }

    if (!result) {
        throw std::runtime_error("Failed to parse string: " + std::string(strerror(errno)));
    }

    if (result->error_code != 0) {
        std::string msg = result->error_message;
        cisv_result_free(result);
        throw std::runtime_error(msg);
    }

    // Convert to Python list
    nb::list rows;
    for (size_t i = 0; i < result->row_count; i++) {
        nb::list row;
        cisv_row_t *r = &result->rows[i];
        for (size_t j = 0; j < r->field_count; j++) {
            row.append(nb::str(r->fields[j], r->field_lengths[j]));
        }
        rows.append(row);
    }

    cisv_result_free(result);
    return rows;
}

/**
 * Parse a CSV file using multiple threads for maximum performance.
 *
 * Returns a single merged list of all rows. The parsing is done in
 * parallel, but the results are merged in order.
 */
static nb::list parse_file_parallel(
    const std::string &path,
    int num_threads = 0,
    const std::string &delimiter = ",",
    const std::string &quote = "\"",
    bool trim = false,
    bool skip_empty_lines = false,
    const std::string &escape = "",
    const std::string &comment = "",
    bool relaxed = false,
    bool skip_lines_with_error = false,
    size_t max_row_size = 0,
    int from_line = 1,
    int to_line = 0
) {
    if (path.empty()) {
        throw std::invalid_argument("Path cannot be empty");
    }
    validate_num_threads(num_threads);

    // Setup config
    cisv_config config = make_config(
        delimiter, quote, escape, comment, trim, skip_empty_lines,
        relaxed, skip_lines_with_error, max_row_size, from_line, to_line);

    // Release GIL during C parsing
    int result_count = 0;
    cisv_result_t **results = nullptr;

    {
        nb::gil_scoped_release release;
        results = cisv_parse_file_parallel(path.c_str(), &config, num_threads, &result_count);
    }

    if (!results) {
        throw std::runtime_error("Failed to parse file in parallel: " + std::string(strerror(errno)));
    }

    // Merge all results into a single list
    nb::list rows;
    for (int chunk = 0; chunk < result_count; chunk++) {
        cisv_result_t *result = results[chunk];
        if (!result) continue;

        if (result->error_code != 0) {
            std::string msg = result->error_message;
            cisv_results_free(results, result_count);
            throw std::runtime_error(msg);
        }

        for (size_t i = 0; i < result->row_count; i++) {
            nb::list row;
            cisv_row_t *r = &result->rows[i];
            for (size_t j = 0; j < r->field_count; j++) {
                row.append(nb::str(r->fields[j], r->field_lengths[j]));
            }
            rows.append(row);
        }
    }

    cisv_results_free(results, result_count);
    return rows;
}

/**
 * Ultra-fast parallel parsing that returns raw data for maximum performance.
 * Returns a tuple of (data_bytes, field_offsets, field_lengths, row_offsets)
 * where field data can be extracted via: data[offset:offset+length].decode()
 *
 * This avoids creating millions of Python string objects upfront.
 */
static nb::tuple parse_file_raw(
    const std::string &path,
    int num_threads = 0,
    const std::string &delimiter = ",",
    const std::string &quote = "\"",
    bool trim = false,
    bool skip_empty_lines = false,
    const std::string &escape = "",
    const std::string &comment = "",
    bool relaxed = false,
    bool skip_lines_with_error = false,
    size_t max_row_size = 0,
    int from_line = 1,
    int to_line = 0
) {
    if (path.empty()) {
        throw std::invalid_argument("Path cannot be empty");
    }
    validate_num_threads(num_threads);

    // Setup config
    cisv_config config = make_config(
        delimiter, quote, escape, comment, trim, skip_empty_lines,
        relaxed, skip_lines_with_error, max_row_size, from_line, to_line);

    nb::tuple simple_result;
    if (try_parse_file_raw_simple(path, config, &simple_result)) {
        return simple_result;
    }

    // Parse file with parallel processing
    int result_count = 0;
    cisv_result_t **results = nullptr;

    {
        nb::gil_scoped_release release;
        results = cisv_parse_file_parallel(path.c_str(), &config,
                                           num_threads > 0 ? num_threads : 0, &result_count);
    }

    if (!results) {
        throw std::runtime_error("Failed to parse file: " + std::string(strerror(errno)));
    }

    // Calculate total sizes
    size_t total_data_size = 0;
    size_t total_fields = 0;
    size_t total_rows = 0;

    for (int chunk = 0; chunk < result_count; chunk++) {
        if (!results[chunk]) continue;
        if (results[chunk]->error_code != 0) {
            std::string msg = results[chunk]->error_message;
            cisv_results_free(results, result_count);
            throw std::runtime_error(msg);
        }
        total_data_size += results[chunk]->field_data_size;
        total_fields += results[chunk]->total_fields;
        total_rows += results[chunk]->row_count;
    }

    // Allocate arrays
    uint8_t *data_buf = new uint8_t[total_data_size];
    uint64_t *field_offsets = new uint64_t[total_fields];
    uint32_t *field_lengths = new uint32_t[total_fields];
    uint64_t *row_offsets = new uint64_t[total_rows + 1];  // +1 for end sentinel

    // Parallel data combining using OpenMP-style threading
    // First pass: calculate per-chunk offsets
    std::vector<size_t> chunk_data_offsets(result_count + 1);
    std::vector<size_t> chunk_field_offsets(result_count + 1);
    std::vector<size_t> chunk_row_offsets(result_count + 1);

    chunk_data_offsets[0] = 0;
    chunk_field_offsets[0] = 0;
    chunk_row_offsets[0] = 0;

    for (int chunk = 0; chunk < result_count; chunk++) {
        cisv_result_t *r = results[chunk];
        if (r) {
            chunk_data_offsets[chunk + 1] = chunk_data_offsets[chunk] + r->field_data_size;
            chunk_field_offsets[chunk + 1] = chunk_field_offsets[chunk] + r->total_fields;
            chunk_row_offsets[chunk + 1] = chunk_row_offsets[chunk] + r->row_count;
        } else {
            chunk_data_offsets[chunk + 1] = chunk_data_offsets[chunk];
            chunk_field_offsets[chunk + 1] = chunk_field_offsets[chunk];
            chunk_row_offsets[chunk + 1] = chunk_row_offsets[chunk];
        }
    }

    // Second pass: parallel copy using threads
    std::vector<std::thread> workers;
    workers.reserve(result_count);

    for (int chunk = 0; chunk < result_count; chunk++) {
        cisv_result_t *r = results[chunk];
        if (!r) continue;

        workers.emplace_back([=, &data_buf, &field_offsets, &field_lengths, &row_offsets]() {
            size_t data_pos = chunk_data_offsets[chunk];
            size_t field_idx = chunk_field_offsets[chunk];
            size_t row_idx = chunk_row_offsets[chunk];

            // Copy field data
            memcpy(data_buf + data_pos, r->field_data, r->field_data_size);

            // Build indices for this chunk
            for (size_t i = 0; i < r->row_count; i++) {
                row_offsets[row_idx++] = field_idx;
                cisv_row_t *row = &r->rows[i];

                for (size_t j = 0; j < row->field_count; j++) {
                    size_t field_offset_in_chunk = row->fields[j] - r->field_data;
                    field_offsets[field_idx] = data_pos + field_offset_in_chunk;
                    field_lengths[field_idx] = (uint32_t)row->field_lengths[j];
                    field_idx++;
                }
            }
        });
    }

    // Wait for all workers
    for (auto &w : workers) {
        w.join();
    }

    row_offsets[total_rows] = total_fields;  // End sentinel

    cisv_results_free(results, result_count);

    nb::capsule data_owner(data_buf, [](void *p) noexcept { delete[] (uint8_t*)p; });
    return make_raw_arrays(
        data_buf,
        total_data_size,
        field_offsets,
        field_lengths,
        total_fields,
        row_offsets,
        total_rows,
        data_owner);
}

/**
 * Ultra-fast parallel parsing that only returns row/field counts.
 * This is used for benchmarking raw parsing speed without data marshaling.
 */
static nb::tuple parse_file_count_only(
    const std::string &path,
    int num_threads = 0,
    const std::string &delimiter = ",",
    const std::string &quote = "\""
) {
    if (path.empty()) {
        throw std::invalid_argument("Path cannot be empty");
    }
    validate_char_option("Delimiter", delimiter);
    validate_char_option("Quote", quote);
    validate_num_threads(num_threads);

    // Setup config
    cisv_config config;
    cisv_config_init(&config);
    config.delimiter = delimiter[0];
    config.quote = quote[0];

    // Parse file with parallel processing
    int result_count = 0;
    cisv_result_t **results = nullptr;

    {
        nb::gil_scoped_release release;
        results = cisv_parse_file_parallel(path.c_str(), &config,
                                           num_threads > 0 ? num_threads : 0, &result_count);
    }

    if (!results) {
        throw std::runtime_error("Failed to parse file: " + std::string(strerror(errno)));
    }

    // Just count totals, don't copy data
    size_t total_fields = 0;
    size_t total_rows = 0;
    size_t first_row_cols = 0;

    for (int chunk = 0; chunk < result_count; chunk++) {
        if (!results[chunk]) continue;
        if (results[chunk]->error_code != 0) {
            std::string msg = results[chunk]->error_message;
            cisv_results_free(results, result_count);
            throw std::runtime_error(msg);
        }
        if (total_rows == 0 && results[chunk]->row_count > 0) {
            first_row_cols = results[chunk]->rows[0].field_count;
        }
        total_fields += results[chunk]->total_fields;
        total_rows += results[chunk]->row_count;
    }

    cisv_results_free(results, result_count);

    return nb::make_tuple(total_rows, total_fields, first_row_cols);
}

/**
 * Count the number of rows in a CSV file without full parsing.
 * This is very fast as it only scans for newlines.
 */
static size_t count_rows(
    const std::string &path,
    const std::string &delimiter = ",",
    const std::string &quote = "\"",
    const std::string &escape = "",
    const std::string &comment = "",
    bool trim = false,
    bool skip_empty_lines = false,
    bool relaxed = false,
    bool skip_lines_with_error = false,
    size_t max_row_size = 0,
    int from_line = 1,
    int to_line = 0
) {
    if (path.empty()) {
        throw std::invalid_argument("Path cannot be empty");
    }

    cisv_config config = make_config(
        delimiter, quote, escape, comment, trim, skip_empty_lines,
        relaxed, skip_lines_with_error, max_row_size, from_line, to_line);

    size_t row_count = 0;
    {
        nb::gil_scoped_release release;
        row_count = cisv_parser_count_rows_with_config(path.c_str(), &config);
    }
    return row_count;
}

/**
 * Row-by-row iterator for streaming CSV parsing.
 *
 * Provides fgetcsv-style iteration with minimal memory footprint.
 * Supports early exit - no wasted work when breaking mid-file.
 */
class CisvIterator {
private:
    cisv_iterator_t *it_;
    bool closed_;
    std::string path_;

public:
    CisvIterator(const std::string &path,
                 const std::string &delimiter = ",",
                 const std::string &quote = "\"",
                 bool trim = false,
                 bool skip_empty_lines = false,
                 const std::string &escape = "",
                 const std::string &comment = "",
                 bool relaxed = false,
                 bool skip_lines_with_error = false,
                 size_t max_row_size = 0,
                 int from_line = 1,
                 int to_line = 0)
        : it_(nullptr), closed_(false), path_(path)
    {
        if (path.empty()) {
            throw std::invalid_argument("Path cannot be empty");
        }
        cisv_config config = make_config(
            delimiter, quote, escape, comment, trim, skip_empty_lines,
            relaxed, skip_lines_with_error, max_row_size, from_line, to_line);

        {
            nb::gil_scoped_release release;
            it_ = cisv_iterator_open(path.c_str(), &config);
        }
        if (!it_) {
            throw std::runtime_error("Failed to open file: " + path);
        }
    }

    ~CisvIterator() {
        close();
    }

    // Disable copy
    CisvIterator(const CisvIterator&) = delete;
    CisvIterator& operator=(const CisvIterator&) = delete;

    /**
     * Get the next row, or None if at end of file.
     */
    nb::object next() {
        if (closed_ || !it_) {
            return nb::none();
        }

        const char **fields;
        const size_t *lengths;
        size_t field_count;

        int result;
        {
            nb::gil_scoped_release release;
            result = cisv_iterator_next(it_, &fields, &lengths, &field_count);
        }

        if (result == CISV_ITER_EOF) {
            return nb::none();
        }
        if (result == CISV_ITER_ERROR) {
            throw std::runtime_error("Error reading CSV row from: " + path_);
        }

        nb::list row;
        for (size_t i = 0; i < field_count; i++) {
            row.append(nb::str(fields[i], lengths[i]));
        }
        return row;
    }

    /**
     * Close the iterator and release resources.
     */
    void close() {
        if (!closed_ && it_) {
            cisv_iterator_close(it_);
            it_ = nullptr;
            closed_ = true;
        }
    }

    /**
     * Check if the iterator is closed.
     */
    bool is_closed() const {
        return closed_;
    }

    // Python iterator protocol - __iter__
    CisvIterator& iter() {
        return *this;
    }

    // Python iterator protocol - __next__
    nb::object iternext() {
        nb::object row = next();
        if (row.is_none()) {
            throw nb::stop_iteration();
        }
        return row;
    }

    // Context manager protocol - __enter__
    CisvIterator& enter() {
        return *this;
    }

    // Context manager protocol - __exit__
    // Note: Returns false to indicate exception should propagate (if any)
    bool exit(nb::object /*exc_type*/, nb::object /*exc_val*/, nb::object /*exc_tb*/) {
        close();
        return false;  // Don't suppress exceptions
    }
};

// Module definition
NB_MODULE(_core, m) {
    m.doc() = "High-performance CSV parser with SIMD optimizations";

    // Register the CisvIterator class
    nb::class_<CisvIterator>(m, "CisvIterator",
        "Row-by-row iterator for streaming CSV parsing.\n\n"
        "Provides fgetcsv-style iteration with minimal memory footprint.\n"
        "Supports early exit - no wasted work when breaking mid-file.\n\n"
        "Example:\n"
        "    with CisvIterator('/path/to/file.csv') as reader:\n"
        "        for row in reader:\n"
        "            print(row)  # List[str]\n"
        "            if row[0] == 'stop':\n"
        "                break  # Early exit - no wasted work")
        .def(nb::init<const std::string &, const std::string &,
                      const std::string &, bool, bool,
                      const std::string &, const std::string &,
                      bool, bool, size_t, int, int>(),
             nb::arg("path"),
             nb::arg("delimiter") = ",",
             nb::arg("quote") = "\"",
             nb::arg("trim") = false,
             nb::arg("skip_empty_lines") = false,
             nb::arg("escape") = "",
             nb::arg("comment") = "",
             nb::arg("relaxed") = false,
             nb::arg("skip_lines_with_error") = false,
             nb::arg("max_row_size") = 0,
             nb::arg("from_line") = 1,
             nb::arg("to_line") = 0,
             "Create a new CSV iterator.\n\n"
             "Args:\n"
             "    path: Path to the CSV file\n"
             "    delimiter: Field delimiter character (default: ',')\n"
             "    quote: Quote character (default: '\"')\n"
             "    trim: Whether to trim whitespace from fields\n"
             "    skip_empty_lines: Whether to skip empty lines\n"
             "    escape: Optional escape character\n"
             "    comment: Optional comment character\n"
             "    relaxed: Keep parsing through relaxed quote errors when core supports it\n"
             "    skip_lines_with_error: Skip malformed rows when core supports it\n"
             "    max_row_size: Maximum row size in bytes, 0 for default/adaptive\n"
             "    from_line: First 1-based line to return\n"
             "    to_line: Last 1-based line to return, 0 for no upper bound")
        .def("next", &CisvIterator::next,
             "Get the next row as a list of strings, or None if at end of file.")
        .def("close", &CisvIterator::close,
             "Close the iterator and release resources.")
        .def_prop_ro("closed", &CisvIterator::is_closed,
             "Whether the iterator has been closed.")
        .def("__iter__", &CisvIterator::iter, nb::rv_policy::reference)
        .def("__next__", &CisvIterator::iternext)
        .def("__enter__", &CisvIterator::enter, nb::rv_policy::reference)
        .def("__exit__", [](CisvIterator &self, nb::args) {
            self.close();
            return false;  // Don't suppress exceptions
        });

    m.def("parse_file", &parse_file,
          nb::arg("path"),
          nb::arg("delimiter") = ",",
          nb::arg("quote") = "\"",
          nb::arg("trim") = false,
          nb::arg("skip_empty_lines") = false,
          nb::arg("escape") = "",
          nb::arg("comment") = "",
          nb::arg("relaxed") = false,
          nb::arg("skip_lines_with_error") = false,
          nb::arg("max_row_size") = 0,
          nb::arg("from_line") = 1,
          nb::arg("to_line") = 0,
          "Parse a CSV file and return all rows as a list of lists.\n\n"
          "Args:\n"
          "    path: Path to the CSV file\n"
          "    delimiter: Field delimiter character (default: ',')\n"
          "    quote: Quote character (default: '\"')\n"
          "    trim: Whether to trim whitespace from fields\n"
          "    skip_empty_lines: Whether to skip empty lines\n"
          "    escape: Optional escape character, empty string for RFC doubled quotes\n"
          "    comment: Optional comment prefix character\n"
          "    relaxed: Keep parsing through relaxed parse errors when core supports it\n"
          "    skip_lines_with_error: Skip malformed lines when core supports it\n"
          "    max_row_size: Maximum row size, 0 for default/adaptive core behavior\n"
          "    from_line: First 1-based line to parse\n"
          "    to_line: Last 1-based line to parse, 0 for no upper bound\n\n"
          "Returns:\n"
          "    List of rows, where each row is a list of field values");

    m.def("parse_string", &parse_string,
          nb::arg("data"),
          nb::arg("delimiter") = ",",
          nb::arg("quote") = "\"",
          nb::arg("trim") = false,
          nb::arg("skip_empty_lines") = false,
          nb::arg("escape") = "",
          nb::arg("comment") = "",
          nb::arg("relaxed") = false,
          nb::arg("skip_lines_with_error") = false,
          nb::arg("max_row_size") = 0,
          nb::arg("from_line") = 1,
          nb::arg("to_line") = 0,
          "Parse a CSV string and return all rows as a list of lists.\n\n"
          "Args:\n"
          "    data: CSV content as a string\n"
          "    delimiter: Field delimiter character (default: ',')\n"
          "    quote: Quote character (default: '\"')\n"
          "    trim: Whether to trim whitespace from fields\n"
          "    skip_empty_lines: Whether to skip empty lines\n"
          "    escape: Optional escape character, empty string for RFC doubled quotes\n"
          "    comment: Optional comment prefix character\n"
          "    relaxed: Keep parsing through relaxed parse errors when core supports it\n"
          "    skip_lines_with_error: Skip malformed lines when core supports it\n"
          "    max_row_size: Maximum row size, 0 for default/adaptive core behavior\n"
          "    from_line: First 1-based line to parse\n"
          "    to_line: Last 1-based line to parse, 0 for no upper bound\n\n"
          "Returns:\n"
          "    List of rows, where each row is a list of field values");

    m.def("parse_file_parallel", &parse_file_parallel,
          nb::arg("path"),
          nb::arg("num_threads") = 0,
          nb::arg("delimiter") = ",",
          nb::arg("quote") = "\"",
          nb::arg("trim") = false,
          nb::arg("skip_empty_lines") = false,
          nb::arg("escape") = "",
          nb::arg("comment") = "",
          nb::arg("relaxed") = false,
          nb::arg("skip_lines_with_error") = false,
          nb::arg("max_row_size") = 0,
          nb::arg("from_line") = 1,
          nb::arg("to_line") = 0,
          "Parse a CSV file using multiple threads for maximum performance.\n\n"
          "Args:\n"
          "    path: Path to the CSV file\n"
          "    num_threads: Number of threads to use (0 = auto-detect)\n"
          "    delimiter: Field delimiter character (default: ',')\n"
          "    quote: Quote character (default: '\"')\n"
          "    trim: Whether to trim whitespace from fields\n"
          "    skip_empty_lines: Whether to skip empty lines\n"
          "    escape: Optional escape character, empty string for RFC doubled quotes\n"
          "    comment: Optional comment prefix character\n"
          "    relaxed: Keep parsing through relaxed parse errors when core supports it\n"
          "    skip_lines_with_error: Skip malformed lines when core supports it\n"
          "    max_row_size: Maximum row size, 0 for default/adaptive core behavior\n"
          "    from_line: First 1-based line to parse\n"
          "    to_line: Last 1-based line to parse, 0 for no upper bound\n\n"
          "Returns:\n"
          "    List of rows, where each row is a list of field values");

    m.def("parse_file_raw", &parse_file_raw,
          nb::arg("path"),
          nb::arg("num_threads") = 0,
          nb::arg("delimiter") = ",",
          nb::arg("quote") = "\"",
          nb::arg("trim") = false,
          nb::arg("skip_empty_lines") = false,
          nb::arg("escape") = "",
          nb::arg("comment") = "",
          nb::arg("relaxed") = false,
          nb::arg("skip_lines_with_error") = false,
          nb::arg("max_row_size") = 0,
          nb::arg("from_line") = 1,
          nb::arg("to_line") = 0,
          "Ultra-fast parallel parsing that returns raw numpy arrays.\n\n"
          "This is the fastest parsing mode, avoiding Python string creation.\n"
          "Returns (data, field_offsets, field_lengths, row_offsets) where:\n"
          "  - data: uint8 array of all field bytes\n"
          "  - field_offsets: uint64 array of byte offsets for each field\n"
          "  - field_lengths: uint32 array of byte lengths for each field\n"
          "  - row_offsets: uint64 array of field indices for each row\n\n"
          "To access field i: data[field_offsets[i]:field_offsets[i]+field_lengths[i]].tobytes().decode()\n"
          "To access row r fields: range(row_offsets[r], row_offsets[r+1])");

    m.def("parse_file_count_only", &parse_file_count_only,
          nb::arg("path"),
          nb::arg("num_threads") = 0,
          nb::arg("delimiter") = ",",
          nb::arg("quote") = "\"",
          "Ultra-fast parallel parsing that only returns counts (for benchmarking).\n\n"
          "Returns (row_count, field_count, first_row_cols) without data marshaling.");

    m.def("count_rows", &count_rows,
          nb::arg("path"),
          nb::arg("delimiter") = ",",
          nb::arg("quote") = "\"",
          nb::arg("escape") = "",
          nb::arg("comment") = "",
          nb::arg("trim") = false,
          nb::arg("skip_empty_lines") = false,
          nb::arg("relaxed") = false,
          nb::arg("skip_lines_with_error") = false,
          nb::arg("max_row_size") = 0,
          nb::arg("from_line") = 1,
          nb::arg("to_line") = 0,
          "Count the number of rows in a CSV file without full parsing.\n\n"
          "This uses core fast paths for simple, quoted, and semantic row-control counts.\n\n"
          "Args:\n"
          "    path: Path to the CSV file\n"
          "    delimiter: Field delimiter character\n"
          "    quote: Quote character\n"
          "    escape: Optional escape character, empty string for RFC doubled quotes\n"
          "    comment: Optional comment prefix character\n"
          "    trim: Trim unquoted fields before comment checks\n"
          "    skip_empty_lines: Skip physically empty rows\n"
          "    relaxed: Keep counting through relaxed parse errors when core supports it\n"
          "    skip_lines_with_error: Skip malformed lines when core supports it\n"
          "    max_row_size: Maximum row size, 0 for default/adaptive core behavior\n"
          "    from_line: First 1-based line to count\n"
          "    to_line: Last 1-based line to count, 0 for no upper bound\n\n"
          "Returns:\n"
          "    Number of rows in the file");
}
