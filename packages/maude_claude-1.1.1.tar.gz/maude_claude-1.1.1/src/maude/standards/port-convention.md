---
title: Port Convention Standard
type: standard
version: 1.1.0
authors:
  - "John Broadway <271895126+john-broadway@users.noreply.github.com>"
  - "Claude (Anthropic) <noreply@anthropic.com>"
updated: 2026-03-29
status: MANDATORY
---

# Port Convention Standard

## Purpose

Self-documenting port assignments for all Maude Room MCP servers. CTID = port
eliminates the need for a port allocation registry and makes firewall rules
predictable across sites. Implements Art. II Sec. 3 (sanctioned interfaces) and
Art. III Sec. 3 (traceability — self-documenting port allocation).

## Rules

**CTID = MCP Port.** Every Maude Room daemon MUST listen on a port equal to its Proxmox CTID. This makes the port self-documenting: if you know the CTID, you know the port.

## Site Ranges

Each site occupies a distinct port range derived from the CTID numbering scheme:

| Site | CTID Range | MCP Port Range | Example |
|------|-----------|----------------|---------|
| HP-SLC | 1000–1099 | 1000–1099 | grafana (CTID 1040) → port 1040 |
| HP-PA | 2000–2099 | 2000–2099 | pa-proxmox (CTID 2080) → port 2080 |
| AIM | 3000–3099 | 3000–3099 | Reserved |
| SBM | 4000–4099 | 4000–4099 | sbm-proxmox (CTID 4080) → port 4080 |

## Multi-Service Hosts

When a single CTID hosts multiple MCP services (e.g., Maude), the primary service uses the CTID as its port and additional services use sequential offsets:

| CTID | Service | Port | Rule |
|------|---------|------|------|
| 1080 | proxmox | 1080 | CTID (primary) |
| 1080 | unifi | 1081 | CTID + 1 |
| 1080 | unas | 1082 | CTID + 2 |

The ordering MUST be: infrastructure first (proxmox), then network (unifi), then storage (unas).

## Exceptions

| Host | Port | Reason |
|------|------|--------|
| control-plane (1971) | 1971 | CTID = port (follows convention) |
| sparky (standalone) | 9300 | Not a Proxmox LXC — no CTID |
| sparked (standalone) | 9301 | Not a Proxmox LXC — no CTID |

## Implementation

The port MUST be set in two places per service:

1. **`/app/{service}/maude.env`** — `MAUDE_PORT={ctid}` (used by systemd ExecStart)
2. **`/app/{service}/config-local.yaml`** — `port: {ctid}` (metadata, used by health loop)

The systemd template `maude@.service` reads `MAUDE_PORT` from the env file and passes it as `--port` to the Python server.

## Examples

**Standard mapping:**
- Grafana SLC (CTID 1040) → MCP port 1040
- PostgreSQL PA (CTID 2030) → MCP port 2030
- DNS SBM (CTID 4053) → MCP port 4053

**Multi-service host:**
- Maude SLC (CTID 1080): proxmox=1080, unifi=1081, unas=1082

**Exception (standalone GPU):**
- sparky → port 9300 (not a Proxmox LXC, no CTID)

## Enforcement

Enforced by `validate-registry.py` which checks that `mcp_port` matches CTID
in `registry/rooms.yaml` for standard Maude Rooms. Exceptions MUST be
documented in the Exceptions table above.
