# SPDX-FileCopyrightText: 2026 Alexey Bogdanenko <alexey@bogdanenko.com>
#
# SPDX-License-Identifier: MIT

"""This module contains shared constants."""

QEMU_SERIAL_PORT = 2023
"""Default TCP port for QEMU to listen on and redirect virtual serial port to"""
