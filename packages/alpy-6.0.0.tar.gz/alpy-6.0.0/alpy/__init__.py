# SPDX-FileCopyrightText: 2026 Alexey Bogdanenko <alexey@bogdanenko.com>
#
# SPDX-License-Identifier: MIT

"""Library for testing network virtual appliances using Docker"""

__version__ = "6.0.0"
