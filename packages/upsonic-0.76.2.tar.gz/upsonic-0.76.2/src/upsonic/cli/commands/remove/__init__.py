# Remove command module
