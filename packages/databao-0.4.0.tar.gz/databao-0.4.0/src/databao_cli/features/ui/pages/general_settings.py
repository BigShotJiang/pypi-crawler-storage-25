"""General settings page - Storage and app-wide configuration."""

import logging

import streamlit as st

from databao_cli.features.ui.app import _clear_all_chat_threads
from databao_cli.features.ui.services.chat_persistence import delete_all_chats
from databao_cli.features.ui.services.settings_persistence import delete_settings
from databao_cli.features.ui.services.storage import get_cache_dir, get_chats_dir, get_storage_base_path
from databao_cli.shared.executor_utils import DEFAULT_EXECUTOR

logger = logging.getLogger(__name__)


@st.dialog("Clear All Chats")
def _confirm_clear_chats() -> None:
    """Dialog to confirm clearing all chats."""
    st.warning("⚠️ This will permanently delete all chat history and cached data.")
    st.markdown("This action cannot be undone.")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Cancel", use_container_width=True):
            st.rerun()
    with col2:
        if st.button("🗑️ Delete All", type="primary", use_container_width=True):
            deleted = delete_all_chats()
            st.session_state.chats = {}
            st.session_state.current_chat_id = None
            st.session_state.agent = None
            st.session_state.disk_cache = None
            _clear_all_chat_threads()
            st.success(f"Deleted {deleted} chats")
            st.rerun()


@st.dialog("Reset to Defaults")
def _confirm_reset_settings() -> None:
    """Dialog to confirm resetting settings to defaults."""
    st.warning("⚠️ This will reset all settings to their default values.")
    st.markdown("Your chat history will be preserved.")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Cancel", use_container_width=True):
            st.rerun()
    with col2:
        if st.button("🔄 Reset", type="primary", use_container_width=True):
            delete_settings()
            st.session_state.executor_type = DEFAULT_EXECUTOR
            st.session_state.databao_project = None
            st.session_state.agent = None
            _clear_all_chat_threads()
            st.session_state.app_settings = None
            st.session_state.pop("welcome_completed", None)
            st.session_state.pop("_setup_mode_active", None)
            st.success("Settings reset to defaults")
            st.rerun()


def render_general_settings_page() -> None:
    """Render the General settings page."""
    st.title("General settings")
    st.markdown("Configure application storage and manage data.")

    st.markdown("---")

    st.subheader("📁 Storage location")

    base_path = get_storage_base_path()
    chats_dir = get_chats_dir()
    cache_dir = get_cache_dir()

    st.markdown("**Base path** (read-only)")
    st.code(str(base_path), language=None)

    with st.expander("📂 Storage details", expanded=False):
        st.markdown("**Chat directory**")
        st.code(str(chats_dir), language=None)

        st.markdown("**Cache directory**")
        st.code(str(cache_dir), language=None)

        try:
            chats = st.session_state.get("chats", {})
            num_chats = len(chats)
            st.metric("Saved chats", num_chats)
        except Exception:
            logger.debug("Failed to display storage statistics", exc_info=True)

    st.markdown("---")

    st.subheader("⚠️ Data management")

    st.markdown(
        """
        These actions affect your stored data. Use them with caution.
        """
    )

    col1, col2 = st.columns(2)

    with col1:
        if st.button(
            "🗑️ Clear all chats",
            use_container_width=True,
            type="secondary",
            help="Delete all chat history and cached data. This cannot be undone.",
        ):
            _confirm_clear_chats()

    with col2:
        if st.button(
            "🔄 Reset settings",
            use_container_width=True,
            type="secondary",
            help="Restore default settings. Your chats will remain unchanged.",
        ):
            _confirm_reset_settings()
