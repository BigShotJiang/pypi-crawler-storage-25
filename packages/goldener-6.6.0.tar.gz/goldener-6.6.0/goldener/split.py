from collections import defaultdict
from dataclasses import dataclass
from logging import getLogger
from typing import Callable

import pixeltable as pxt
import torch
from pixeltable.catalog import Table
from torch.utils.data import Dataset, DataLoader

from goldener.clusterize import GoldClusterizer
from goldener.describe import GoldDescriptor
from goldener.pxt_utils import (
    get_expr_from_column_name,
    set_value_to_idx_rows,
    GoldPxtTorchDataset,
    pxt_torch_dataset_collate_fn,
)
from goldener.select import GoldSelector
from goldener.utils import (
    check_sampling_size,
    check_all_same_type,
    get_sampling_count_from_size,
    split_sampling_among_chunks,
)
from goldener.vectorize import GoldVectorizer


logger = getLogger(__name__)


@dataclass
class GoldSet:
    """Configuration for a gold set used for splitting.

    Attributes:
        name: Name of the gold set (None if the set is for not selected data).
        size: Size (ratio or actual number) of samples to assign to this set (between 0 and 1). If a ratio, this value
        cannot be one of 0 or 1 (goal is to select a subset of the full dataset). If a number, it must be strictly
        positive and less than the total number of samples in the dataset.
    """

    name: str | None
    size: float | int

    def __post_init__(self) -> None:
        """Validate the GoldSet configuration after initialization.

        Raises:
            ValueError: If ratio is not between 0 and 1 (exclusive).
        """
        if isinstance(self.size, float) and not (0 < self.size < 1):
            raise ValueError("Size as float must be between 0 and 1.")
        elif isinstance(self.size, int) and self.size <= 0:
            raise ValueError("Size as int must be strictly positive.")


def check_sets_validity(
    sets: list[GoldSet], total: int | None = None, force_max: bool = True
) -> None:
    """Validate the sets configuration.

    This function ensures that the sum of ratios is valid and that set names are unique.

    Args:
        sets: List of GoldSet configurations to validate.
        total: Optional total number of samples (used if sizes are integers).
        force_max: Whether to enforce that the sum of ratios equals 1.0 (for float sizes) or total (for int sizes).

    Raises:
        ValueError: If the set's sizes are not valid, or if set names are not unique.
    """
    sizes = [s.size for s in sets]
    check_all_same_type(sizes)
    check_sampling_size(sum(sizes), total_size=total, force_max=force_max)

    set_names = [s.name for s in sets]
    if len(set_names) != len(set(set_names)):
        raise ValueError(f"Set names must be unique, got {set_names}")


class GoldSplitter:
    """Split a dataset into multiple sets based on embeddings.

    The GoldSplitter leverages a GoldDescriptor to compute embeddings from the dataset,
    a GoldVectorizer to vectorize these embeddings, a GoldClusterizer to cluster them and a GoldSelector to select samples
    for each set based on specified ratios.

    The splitting can operate in a sequential (single-process) mode or a
    distributed mode (not implemented).

    At least 2 sets are required to split the data. Every sample
    will be associated with exactly one set using a GoldSelector. The last set is filled with any remaining elements.
    Every set is at least associated with at least 1 points (the ratio might not be fully matched for small data regimes).

    See GoldDescriptor, GoldVectorizer, and GoldSelector for more details on each component.

    Attributes:
        sets: List of GoldSet configurations defining the splits.
            They are required to split all the samples among them.
        selector: GoldSelector used to select samples for each set.
        descriptor: Optional GoldDescriptor used to describe the dataset.
        vectorizer: Optional GoldVectorizer used to vectorize the described dataset.
        clusterizer: Optional GoldClusterizer used to clusterize the described dataset.
        n_clusters: Number of clusters to use for clusterized selection (if clusterizer is provided).
        in_described_table: Whether to return the splitting in the described table or the selected table.
        allow_existing: Whether to allow existing tables in all components.
        drop_table: Whether to drop intermediate tables. Defaults to False.
        max_batches: Optional maximum number of batches to process in both descriptor and selector. Useful for testing on a small subset of the dataset.
    """

    def __init__(
        self,
        sets: list[GoldSet],
        selector: GoldSelector,
        descriptor: GoldDescriptor | None = None,
        vectorizer: GoldVectorizer | None = None,
        clusterizer: GoldClusterizer | None = None,
        n_clusters: int = 0,
        in_described_table: bool = False,
        allow_existing: bool = True,
        drop_table: bool = False,
        max_batches: int | None = None,
    ) -> None:
        """Initialize the GoldSplitter.

        Args:
            sets: List of GoldSet configurations defining the splits.
                They are required to split all the samples among them.
            selector: GoldSelector used to select samples for each set.
            descriptor: Optional GoldDescriptor used to describe the dataset.
            vectorizer: Optional GoldVectorizer used to vectorize the described dataset.
            clusterizer: Optional GoldClusterizer used to clusterize the described dataset.
            n_clusters: Number of clusters to use for clusterized selection (if clusterizer is provided).
            in_described_table: Whether to return the splitting in the described table or the selected table.
            allow_existing: Whether to allow existing tables in all components.
            drop_table: Whether to drop intermediate tables. Defaults to False.
            max_batches: Optional maximum number of batches to process for the selection.
            Useful for testing on a small subset of the dataset.

        Raises:
            ValueError: If `in_described_table` is True but no `descriptor` is provided.
            ValueError: If `vectorizer.vectorized_key` does not match `selector.vectorized_key`.
            ValueError: If `descriptor.description_key` does not match `vectorizer.data_key` (when vectorizer is set).
            ValueError: If `descriptor.description_key` does not match `selector.vectorized_key` (when no vectorizer).
            ValueError: If `clusterizer.vectorized_key` does not match `selector.vectorized_key`.
            ValueError: If the `sets` configuration is invalid (for example, invalid sum of sizes/ratios or duplicate set names).
        """
        if descriptor is None and in_described_table:
            raise ValueError(
                "in_described_table is set to True, but no descriptor is provided."
            )

        if vectorizer is not None:
            if vectorizer.vectorized_key != selector.vectorized_key:
                raise ValueError(
                    f"Vectorizer vectorized_key '{vectorizer.vectorized_key}' does not match "
                    f"selector's vectorized_key '{selector.vectorized_key}'. They must be the same."
                )

            if (
                descriptor is not None
                and descriptor.description_key != vectorizer.data_key
            ):
                raise ValueError(
                    f"Descriptor description_key '{descriptor.description_key}' does not match "
                    f"vectorizer's data_key '{vectorizer.data_key}'. They must be the same."
                )

        elif (
            descriptor is not None
            and descriptor.description_key != selector.vectorized_key
        ):
            raise ValueError(
                f"Descriptor description_key '{descriptor.description_key}' does not match "
                f"selector's vectorized_key '{selector.vectorized_key}'. They must be the same."
            )

        if clusterizer is not None:
            if n_clusters <= 1:
                logger.info(
                    f"Clusterizer is provided but n_clusters is set to {n_clusters}. "
                    f"Clusterizer will not be effective. Please set n_clusters to a value greater than 1 to enable clustering."
                )

            if clusterizer.vectorized_key != selector.vectorized_key:
                raise ValueError(
                    f"Clusterizer vectorized_key '{clusterizer.vectorized_key}' does not match "
                    f"selector's vectorized_key '{selector.vectorized_key}'. They must be the same."
                )

            clusterizer.include_vectorized_in_table = True
            logger.info(
                "Clusterizer's include_vectorized_in_table is set to True to keep the "
                "vectorized embeddings in the table for the selection step. "
                "This is necessary to perform cluster-wise selection. "
            )

        self.sets = sets
        self.descriptor = descriptor
        self.vectorizer = vectorizer
        self.clusterizer = clusterizer
        self.n_clusters = n_clusters
        self.selector = selector
        self.in_described_table = in_described_table
        self.drop_table = drop_table
        self._max_batches = max_batches
        self.allow_existing = allow_existing
        self.max_batches = max_batches

    @property
    def max_batches(self) -> int | None:
        """Get the maximum number of batches to process."""
        return self._max_batches

    @max_batches.setter
    def max_batches(self, value: int | None) -> None:
        """Set the maximum number of batches to process during splitting."""
        self._max_batches = value
        if self.descriptor is not None:
            self.descriptor.max_batches = value
        else:
            if self.vectorizer is not None:
                self.vectorizer.max_batches = value
            else:
                self.selector.max_batches = value

    @property
    def allow_existing(self) -> bool:
        """Get whether existing tables are allowed in all components."""
        return self._allow_existing

    @allow_existing.setter
    def allow_existing(self, value: bool) -> None:
        """Set whether existing tables are allowed in all components."""
        self._allow_existing = value
        if self.descriptor is not None:
            self.descriptor.allow_existing = value
        if self.vectorizer is not None:
            self.vectorizer.allow_existing = value
        self.selector.allow_existing = value

    @property
    def sets(self) -> list[GoldSet]:
        """Get the current sets configuration for the splitter."""
        return self._sets

    @sets.setter
    def sets(self, sets: list[GoldSet]) -> None:
        """Set the sets configuration for the splitter.

        Args:
            sets: New list of GoldSet configurations defining the splits.

        Raises:
            ValueError: If fewer than two sets are provided.
            ValueError: If the set sizes are not all of the same type.
            ValueError: If the set sizes or ratios are invalid.
            ValueError: If the set names are not unique.
        """
        if len(sets) < 2:
            raise ValueError("Splitting data requires at least two sets.")

        size_types = [type(s.size) for s in sets]

        if len(set(size_types)) > 1:
            raise ValueError(
                f"All set sizes must be of the same type, got types {size_types}."
            )

        # in case of integers, the max completion will be checked later
        # based on the actual total number of samples in the dataset at query time
        check_sets_validity(
            sets, force_max=True if issubclass(size_types[0], float) else False
        )
        self._sets = sets

    @property
    def clustering_enable(self):
        return self.clusterizer is not None and self.n_clusters > 1

    @staticmethod
    def get_split_indices(
        split_data: Table | Dataset,
        selection_key: str,
        idx_key: str = "idx",
        batch_size: int = 1024,
        num_workers: int = 0,
        collate_fn: Callable | None = None,
    ) -> dict[str, set[int]]:
        """Get the indices of samples for each set from a split table.

        Args:
            split_table: PixelTable Table containing the split information.
            selection_key: Column name in the table indicating the set assignment.
            idx_key: Column name in the table indicating the sample indices.
            batch_size: Batch size to use when processing the input as dataset.
            num_workers: Number of workers to use when processing the input as dataset.
            collate_fn: Collate function to use when processing the input as dataset. It should
                return a dictionary with at least the keys specified by `idx_key` and `selection_key`.

        Returns:
            A dictionary mapping each set name to a set of sample indices.
        """

        set_indices: dict[str, set[int]] = defaultdict(set)

        if isinstance(split_data, Dataset):
            dataloader = DataLoader(
                split_data,
                batch_size=batch_size,
                num_workers=num_workers,
                collate_fn=collate_fn,
            )

            for batch in dataloader:
                batch_indices = batch[idx_key]
                batch_selections = batch[selection_key]
                for idx_value, set_name in zip(batch_indices, batch_selections):
                    if set_name is None:
                        continue
                    set_indices[set_name].add(
                        int(idx_value.item())
                        if isinstance(idx_value, torch.Tensor)
                        else idx_value
                    )
        else:
            selection_col = get_expr_from_column_name(split_data, selection_key)
            for row in split_data.select(selection_col).distinct().collect():
                set_name = row[selection_key]
                if set_name is None:
                    continue

                set_indices[set_name] = GoldSelector.get_selection_indices(
                    split_data,
                    selection_key=selection_key,
                    value=set_name,
                    idx_key=idx_key,
                )

        return set_indices

    def split_in_dataset(
        self,
        to_split: Dataset | Table,
    ) -> GoldPxtTorchDataset:
        """Split the dataset into multiple sets in a PixelTable table.

        The dataset is first described using the gold descriptor (computes embeddings), and then samples are selected
        for each set based on the specified ratios after vectorization.

        At least 2 sets are required to split the data. Every sample
        will be associated with exactly one set using a GoldSelector. The last set is filled with any remaining elements.
        Every set is at least associated with at least 1 points (the ratio might not be fully matched for small data regimes).

        This method is idempotent (i.e. failure proof), meaning that if it is called
        multiple times on the same dataset or table, it will not duplicate or recompute the splitting decisions
        already present in the PixelTable table.

        Args:
            to_split: Dataset or Table to be split. If a Dataset is provided, each item should be a
            dictionary with at least the key specified by descriptor `data_key` after applying the collate_fn.
            If the collate_fn is None, the dataset is expected to directly provide such batches. If a Table is provided,
            it should contain both 'idx' and `data_key` column for the descriptor.

        Returns:
            A GoldPxtTorchDataset dataset containing at least the set assignation in the `selection_key` column. Then
            the other columns are either from the described table (if `in_described_table` is True)
            or from the selected table (if `in_described_table` is False).
        """
        split_table = self.split_in_table(to_split)

        split_dataset = GoldPxtTorchDataset(split_table, keep_cache=True)

        self._drop_tables(drop_all=True)

        return split_dataset

    def split_in_table(self, to_split: Dataset | Table) -> Table:
        """Split the dataset into multiple sets in a PixelTable table.

        The dataset is first described using the gold descriptor (computes embeddings), and then samples are selected
        for each set based on the specified ratios after vectorization.

        At least 2 sets are required to split the data. Every sample
        will be associated with exactly one set using a GoldSelector. The last set is filled with any remaining elements.
        Every set is at least associated with at least 1 points (the ratio might not be fully matched for small data regimes).

        This method is idempotent (i.e. failure proof), meaning that if it is called
        multiple times on the same dataset or table, it will not duplicate or recompute the splitting decisions
        already present in the PixelTable table.

        See describe_in_table, vectorize_in_table, and select_in_table for more details on each step.

        Args:
            to_split: Dataset or Table to be split. If a Dataset is provided, each item should be a
            dictionary with at least the key specified by descriptor `data_key` after applying the collate_fn.
            If the collate_fn is None, the dataset is expected to directly provide such batches. If a Table is provided,
            it should contain both 'idx' and `data_key` column for the descriptor.

        Returns:
            A PixelTable Table containing at least the set assignation in the `selection_key` column. Then
            the other columns are either from the described table (if `in_described_table` is True)
            or from the selected table (if `in_described_table` is False).

        Raises:
            ValueError: If any set results in zero samples due to its ratio, if label_key is not found,
            or if label stratification results in zero samples for any label in a set.
        """
        description = (
            self.descriptor.describe_in_table(to_split)
            if self.descriptor is not None
            else to_split
        )

        vectorized = (
            self.vectorizer.vectorize_in_table(description)
            if self.vectorizer is not None
            else description
        )

        clusterized = None
        if self.clustering_enable:
            assert self.clusterizer is not None and self.n_clusters > 1
            clusterized = self.clusterizer.cluster_in_table(vectorized, self.n_clusters)

        selection_table = self.selector.setup_selection_table(vectorized)
        sample_count = selection_table.select(selection_table.idx).distinct().count()

        if sample_count is not None:
            check_sets_validity(self._sets, total=sample_count, force_max=True)

        # select data for all sets
        for idx_set, gold_set in enumerate(self._sets):
            set_count = get_sampling_count_from_size(
                sampling_size=gold_set.size, total_size=sample_count
            )
            already_selected_count = self.selector.get_selection_count(
                selection_table,
                selection_key=self.selector.selection_key,
                value=gold_set.name,
            )
            if already_selected_count == set_count:
                logger.info(f"{gold_set.name} has already been fully selected.")
                continue

            if already_selected_count > set_count:
                raise ValueError(
                    f"{gold_set.name} already contains selected samples and the size is above the specified size."
                )

            logger.info(
                f"Selecting samples for set '{gold_set.name}' with size {set_count} over {sample_count} samples."
            )

            # the first sets are selected based on the specified ratios,
            # while the last one gathers all the remaining samples,
            # so we don't need to select it explicitly
            if idx_set < len(self._sets) - 1:
                selection_table = (
                    self._clusterized_selection(
                        clusterized, selection_table, set_count, gold_set
                    )
                    if clusterized is not None
                    else self.selector.select_in_table(
                        vectorized, set_count, value=gold_set.name
                    )
                )
            else:
                logger.info(
                    f"{gold_set.name} is the last set, all the remaining samples will be assigned to it."
                )
                # The last set is gathering all the remaining samples
                selection_col = get_expr_from_column_name(
                    selection_table, self.selector.selection_key
                )
                already_in_set_count = self.selector.get_selection_count(
                    table=selection_table,
                    selection_key=self.selector.selection_key,
                    value=gold_set.name,
                )
                not_yet_selected = selection_table.where(selection_col == None)  # noqa: E711
                not_yet_selected_count = (
                    not_yet_selected.select(selection_table.idx).distinct().count()
                )
                if not_yet_selected_count == 0 and already_in_set_count == 0:
                    raise ValueError(
                        f"Not enough data to split among {len(self._sets)} sets."
                    )

                if (already_in_set_count + not_yet_selected_count) != set_count:
                    logger.warning(
                        f"For the set '{gold_set.name}', the expected count was {set_count}, "
                        f"but got {already_in_set_count} already selected and {not_yet_selected_count} not yet selected samples. "
                        f"This might be due to rounding issues or the presence of already selected samples before splitting."
                    )

                not_yet_selected.update(  # noqa: E711
                    {self.selector.selection_key: gold_set.name}
                )

        # Depending on the `in_described_table` flag, move the selection column to the described table
        # or keep it in the selected table.
        split_table = selection_table
        if self.in_described_table:
            logger.info(
                "in_described_table is set to True, moving the selection column to the described table "
                "and returning the described table as the final split table."
            )
            if not isinstance(description, Table):
                raise ValueError(
                    "in_described_table is set to True, but description is not a PixelTable Table."
                )
            for set_cfg in self._sets:
                set_name = set_cfg.name
                set_indices = self.selector.get_selection_indices(
                    selection_table,
                    selection_key=self.selector.selection_key,
                    value=set_name,
                )
                if self.selector.selection_key not in description.columns():
                    description.add_column(
                        if_exists="error",
                        **{self.selector.selection_key: pxt.String},
                    )
                set_value_to_idx_rows(
                    description,
                    col_expr=get_expr_from_column_name(
                        description, self.selector.selection_key
                    ),
                    idx_expr=description.idx,
                    indices=set_indices,
                    value=set_name,
                )
            split_table = description

        self._drop_tables(drop_all=False)

        return split_table

    def _clusterized_selection(
        self,
        clusterized: Table,
        selection_table: Table,
        set_count: int,
        gold_set: GoldSet,
    ) -> Table:
        assert self.clusterizer is not None
        # the table for each cluster are processed sequentially, and sent as GoldPxtTorchDataset
        # to the selector, so the collate_fn of the selector is temporarily updated to `pxt_torch_dataset_collate_fn,
        # and reset to the original collate_fn after the cluster-wise selection is done
        selection_collate_fn = self.selector.collate_fn
        logger.info(
            "Clusterized selection is enabled. Temporarily setting selector's collate_fn "
            "to pxt_torch_dataset_collate_fn to process cluster-wise selection. "
            "It will be reset to the original collate_fn after the cluster-wise selection is done."
        )
        self.selector.collate_fn = pxt_torch_dataset_collate_fn

        try:
            # validate the clustering has been run
            cluster_col = get_expr_from_column_name(
                clusterized, self.clusterizer.cluster_key
            )
            if clusterized.where(cluster_col == None).count():  # noqa: E711
                raise ValueError(
                    f"Clusterizer output column '{self.clusterizer.cluster_key}' contains null values."
                )

            # track the initial indices per cluster
            initial_clusters = [
                self.clusterizer.get_cluster_indices(
                    table=clusterized,
                    cluster_key=self.clusterizer.cluster_key,
                    cluster_idx=cluster_idx,
                    idx_key="idx",
                )
                for cluster_idx in range(self.n_clusters)
            ]

            # samples can be split across different clusters,
            # so the selection might require multiple iterations to select the
            # expected number of samples for the set, cluster after cluster, based
            # on the number of available samples in each cluster at each iteration
            already_selected: set[int] = self.selector.get_selection_indices(
                selection_table,
                selection_key=self.selector.selection_key,
                value=gold_set.name,
            )
            selected_count = len(already_selected)
            force_all_clusters = (
                True  # the first loop is done like nothing is already selected
            )
            initial_cluster_selected_counts = {
                cluster_idx: clusterized.where(
                    (clusterized.idx.isin(already_selected))
                    & (cluster_col == cluster_idx)
                )
                .select(clusterized.idx)
                .distinct()
                .count()
                for cluster_idx in range(self.n_clusters)
            }
            while selected_count < set_count:
                loop_start = selected_count

                # the numbers of samples per cluster to select for the loop are computed
                # from the samples not yet selected except for the first loop which take all the samples
                # (make the process as much idempotent as possible )
                cluster_select_counts = split_sampling_among_chunks(
                    to_split=(
                        set_count if force_all_clusters else set_count - selected_count
                    ),
                    chunk_sizes=[
                        clusterized.where(
                            cluster_col == cluster_idx
                            if force_all_clusters
                            else (
                                (cluster_col == cluster_idx)
                                & (~clusterized.idx.isin(already_selected))
                            )
                        )
                        .select(clusterized.idx)
                        .distinct()
                        .count()
                        for cluster_idx in range(self.n_clusters)
                    ],
                )
                # The monitoring of the selected count per cluster starts from the already selected
                # count for the 1st loop (make the process as much idempotent as possible ).
                # Then, it starts with a 0 value.
                loop_cluster_selected_counts = (
                    initial_cluster_selected_counts
                    if force_all_clusters
                    else {cluster_idx: 0 for cluster_idx in range(self.n_clusters)}
                )

                for cluster_idx, (
                    cluster_select_count,
                    initial_cluster,
                ) in enumerate(
                    zip(
                        cluster_select_counts,
                        initial_clusters,
                        strict=True,
                    )
                ):
                    if loop_cluster_selected_counts[cluster_idx] > cluster_select_count:
                        logger.info(
                            f"Cluster {cluster_idx} has {loop_cluster_selected_counts[cluster_idx]} samples "
                            f"which is equal or above the target for the current selection loop. Skipping this cluster."
                        )

                    if selected_count >= set_count:
                        break

                    cluster_select_count = (
                        cluster_select_count - loop_cluster_selected_counts[cluster_idx]
                    )
                    if cluster_select_count <= 0:
                        logger.info(
                            f"Cluster {cluster_idx} has no more samples to select. Skipping this cluster."
                        )
                        continue

                    # some samples from the cluster might have been already selected
                    # from previous clusters ending up with nothing to select in a given cluster
                    available_in_cluster = initial_cluster - already_selected
                    if len(available_in_cluster) == 0:
                        logger.info(
                            f"Cluster {cluster_idx} has no more available samples for selection. Skipping this cluster."
                        )
                        continue

                    # when all samples can be selected, force the selector to take everything
                    if cluster_select_count > len(available_in_cluster):
                        logger.info(
                            f"Cluster {cluster_idx} has only {len(available_in_cluster)} available samples, "
                            f"but {cluster_select_count} samples are expected to be selected based on the clusterized sampling. "
                            f"All the remaining samples in this cluster will be selected."
                        )
                        cluster_select_count = len(available_in_cluster)

                    logger.info(
                        f"Selecting {cluster_select_count} samples for set '{gold_set.name}' in "
                        f"cluster {cluster_idx} with {len(available_in_cluster)} available samples."
                    )
                    cluster_pool = clusterized.where(
                        (cluster_col == cluster_idx)
                        & (clusterized.idx.isin(available_in_cluster))
                    )
                    remaining_vectors = set(
                        [
                            row["idx_vector"]
                            for row in cluster_pool.select(
                                clusterized.idx_vector
                            ).collect()
                        ]
                    )

                    selection_table = self.selector.select_in_table(
                        select_from=GoldPxtTorchDataset(cluster_pool),
                        select_size=cluster_select_count,
                        value=gold_set.name,
                        restrict_to=remaining_vectors,
                        restriction_idx_key="idx_vector",
                    )

                    # update the elements allowing to compute the selection specs for the next clusters
                    already_selected = self.selector.get_selection_indices(
                        selection_table,
                        selection_key=self.selector.selection_key,
                        value=gold_set.name,
                    )
                    selected_count = len(already_selected)
                    loop_cluster_selected_counts = {
                        cluster_idx: loop_cluster_selected_counts[cluster_idx]
                        + clusterized.where(
                            (cluster_col == cluster_idx)
                            & (clusterized.idx.isin(already_selected))
                            & (clusterized.idx_vector.isin(remaining_vectors))
                        )
                        .select(clusterized.idx)
                        .distinct()
                        .count()
                        for cluster_idx in range(self.n_clusters)
                    }
                    force_all_clusters = (
                        False  # only the first loop ignore the already selected samples
                    )

                if selected_count == loop_start:
                    # if after going through all the clusters, no new sample has been selected, it means that there is not enough data to select from
                    raise ValueError(
                        f"Could not select any new sample for set '{gold_set.name}' during clusterized selection. "
                        f"This might be due to not enough data to select from, or issues in the clusterizer output."
                    )

        finally:
            # restore the original collate_fn of the selector after cluster-wise selection is done
            self.selector.collate_fn = selection_collate_fn

        return selection_table

    def _drop_tables(self, drop_all: bool = True) -> None:
        """Drop all intermediate tables created during the splitting process.

        Args:
            drop_all: Whether to drop all tables including the selected table.
            The selected table is either the selector's table or the descriptor's table
            depending on the `in_described_table` flag.
        """
        if self.drop_table:
            table_names = [
                self.selector.table_path,
                *([self.descriptor.table_path] if self.descriptor is not None else []),
                *([self.vectorizer.table_path] if self.vectorizer is not None else []),
                *(
                    [self.clusterizer.table_path]
                    if self.clusterizer is not None
                    else []
                ),
            ]

            to_not_drop = (
                self.descriptor.table_path
                if self.in_described_table and self.descriptor is not None
                else self.selector.table_path
            )

            for table in table_names:
                if table != to_not_drop or drop_all:
                    pxt.drop_table(table, if_not_exists="ignore")
