import os

from .base import AIBackend
from .claude_backend import ClaudeBackend
from .openai_backend import OpenAIBackend
from .ricky_backend import RickyBackend
from .mcp_backend import MCPBackend

__all__ = ["AIBackend", "ClaudeBackend", "OpenAIBackend", "RickyBackend", "MCPBackend", "make_backend"]


def make_backend(
    backend: str = "llama",
    api_key: str | None = None,
    ricky_url: str = "http://localhost:8000/mcp",
    mcp_url: str = "http://localhost:8001/mcp",
    model: str | None = None,
) -> AIBackend:
    if backend == "claude":
        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise ValueError("Claude backend requires ANTHROPIC_API_KEY or --api-key")
        return ClaudeBackend(api_key=key, **{"model": model} if model else {})
    if backend == "openai":
        key = api_key or os.environ.get("OPENAI_API_KEY")
        if not key:
            raise ValueError("OpenAI backend requires OPENAI_API_KEY or --api-key")
        return OpenAIBackend(api_key=key, **{"model": model} if model else {})
    if backend == "mcp":
        return MCPBackend(url=mcp_url)
    if backend == "llama":
        return RickyBackend(url=ricky_url)
    raise ValueError(f"Unknown backend {backend!r}. Choose: llama, claude, openai, mcp")
