# -*- coding: utf-8 -*-
import os

import yt_dlp
import sys
import threading
try:

    def progress_hook(d):
        if d['status'] == 'downloading':
            percent = d.get('_percent_str', '0%')
            speed = d.get('_speed_str', 'N/A')
            eta = d.get('_eta_str', 'N/A')
            print(f"\r📥 {percent} | ⚡ {speed} | ⏳ {eta}", end='', flush=True)

        elif d['status'] == 'finished':
            print("\n✅ Download complete! Processing file...")


    def download_video(url, audio_only=False):
        downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
        ydl_opts = {
            'format': 'bestaudio/best' if audio_only else 'bestvideo+bestaudio/best',
            'outtmpl': os.path.join(downloads_dir, '%(title).200s.%(ext)s'),
            'restrictfilenames': True,
            'progress_hooks': [progress_hook],
            'noplaylist': True,
            'quiet': True,
            'ffmpeg_location': 'ffmpeg',
        }

        if not audio_only:
            ydl_opts['merge_output_format'] = 'mp4'

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                print(f"\n🚀 Starting: Downloading {info['title']} ")
                ydl.download([url])

        except yt_dlp.utils.DownloadError:
            print(f"\n❌ Failed: {url}")

        except Exception as e:
            print(f"\n💀 Error ({url}): {str(e)}")


    if __name__ == "__main__":
        urls = []
        audio_mode = False

        # CLI MODE
        if len(sys.argv) > 1:
            for arg in sys.argv[1:]:
                if arg == "--audio":
                    audio_mode = True
                else:
                    urls.append(arg)
        else:
           
            print("Paste URLs (one per line). Type 'done' to start:")
            while True:
                u = input("> ").strip()
                if u.lower() == "done":
                    break
                if u.startswith(("http://", "https://")):
                    urls.append(u)
                else:
                    print(" Invalid URL, skipped.")

        if not urls:
            print("No valid URLs provided.")
            sys.exit()

        threads = []

        for url in urls:
            t = threading.Thread(target=download_video, args=(url, audio_mode))
            t.start()
            threads.append(t)

        for t in threads:
            t.join()

        print("\n🎉 All downloads completed.")

except KeyboardInterrupt:
    print("\n🚪 Exiting...")
    sys.exit()
except ConnectionError:
    print("\n🌐 Network error. Please check your connection.")
    sys.exit()
except Exception as e:
    print(f"\n💀 Unexpected error: {str(e)}")
    sys.exit()