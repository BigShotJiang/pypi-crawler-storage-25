from setuptools import setup, find_packages

setup(
    name="pillarola",
    version="1.0.0",
    description="Video downloader",
    author="Pillar",
    packages=find_packages(),
    install_requires=[
        "yt-dlp",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "download=pillarola.main:main",
        ],
    },
)