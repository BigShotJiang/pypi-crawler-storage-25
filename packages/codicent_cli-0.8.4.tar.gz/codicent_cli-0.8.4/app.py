import sys
import os
import logging
import glob
import requests
import base64
import json
import re
import subprocess
from codicentpy import Codicent
from rich.console import Console
from rich.markdown import Markdown
from prompt_toolkit import prompt
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import Keys
from prompt_toolkit.filters import Condition
from auth import CodicentAuth

# Configure logging
logging.basicConfig(level=logging.WARNING, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def show_help():
    """Display help information."""
    help_text = """
Codicent CLI - Command-line interface for the Codicent API

USAGE:
    codicent [OPTIONS] [QUESTION]
    codicent [OPTIONS] < file.txt
    echo "question" | codicent [OPTIONS]
    codicent upload <file_pattern> [<file_pattern> ...]

OPTIONS:
    -t, --interactive    Start interactive chat mode
    -h, --help          Show this help message
    -v, --version       Show version information
    --verbose           Enable verbose logging
    --quiet             Suppress non-essential output

AUTHENTICATION:
    auth                Authenticate using device flow (project selected during web auth)
    auth --local        Authenticate and store token in the current directory (.codicent_token)
    logout              Clear stored global authentication
    logout --local      Clear only the local (.codicent_token) token in the current directory
    status              Check authentication status (shows whether local or global token is used)

FILE UPLOAD:
    upload              Upload files and post messages with tags
    
    Example:
        codicent upload file.txt *.log
        
    This uploads the files and posts a message for each file with:
        @project #index #summarize #file:FILE_GUID

    PROJECT INIT:
    init                Initialize current project with a template
    
        --list              List available templates with descriptions
        --template NAME     Use a specific template (default: 'default')
        --dry-run           Preview messages without posting (no auth needed)
        --force             Re-initialize even if project already has #instructions
    
    Templates:
        default             General-purpose: task workflow + auto-summarize notes
        koi-studio          CRM: lead extraction + follow-up email drafting pipeline
        document-processing Document intake: extract, structure, and review documents
    
    Examples:
        codicent init
        codicent init --template koi-studio
        codicent init --template document-processing --dry-run
        codicent init --list
        codicent init --force

WRAP (AI CLI Remote Bridge):
    wrap                Bridge a local AI CLI tool to a remote codicent chat session.
                        Remote users and AI can interact with the locally running tool.
    
        <tool>              Tool to wrap: claude, codex, opencode, or any CLI tool
        [tool-args...]      Arguments passed through to the wrapped tool
        --label TEXT        Session label shown in codicent UI (default: "<tool> session")
        --binary PATH       Explicit path to the tool binary
        --poll-interval N   Seconds between input polls (default: 2)
    
    How it works:
        1. Starts the tool as a local subprocess
        2. Posts tool output to codicent tagged #wrap #wrap_<id> #output
        3. Polls for messages tagged #wrap #wrap_<id> #input and writes them to stdin
        4. Remote users tag messages with #wrap_<id> #input to send text to the tool
    
    Config file (~/.codicent/wrap-config.yaml):
        poll_interval: 2
        output_batch_ms: 500
        tools:
          claude:
            binary: claude
        auto_responses:
          - pattern: "Do you want to continue"
            reply: "y"
    
    Examples:
        codicent wrap claude
        codicent wrap --label "Refactor session" opencode
        codicent wrap --poll-interval 5 codex
        codicent wrap --binary /usr/local/bin/claude claude --model claude-opus-4-5

TERMINAL (Web Terminal Host):
    terminal            Start a local shell and host it as a Codicent terminal session.
                        Browser users can connect to it via the Codicent web UI.

        [shell]         Shell to run (default: $SHELL or bash)

    How it works:
        1. Spawns the shell locally using a PTY
        2. Connects to the Codicent server as a "terminal host" via WebSocket
        3. Relays shell I/O to any browser that connects to the session
        4. Session output is logged as #terminal-session in Codicent when done

    Examples:
        codicent terminal
        codicent terminal bash
        codicent terminal zsh

EXAMPLES:
    codicent auth
    codicent "What is Python?"
    codicent -t
    codicent "@mention Hello there"
    codicent upload document.txt *.log
    codicent init --template koi-studio
    codicent wrap claude
    codicent terminal
    codicent daemon
    codicent update
    codicent update --install
    echo "Help me debug this" | codicent

DAEMON (Remote AI Outpost):
    daemon              Run as a long-lived background agent that polls for and
                        executes delegated commands from the AI (execute_command,
                        fs_read, fs_write, fs_list, fs_search). Use this to turn a
                        CLI instance into a persistent remote outpost for maintenance.
    
    The daemon watches the Codicent project for function_result messages containing
    delegation markers and executes them on behalf of the AI. Session identity ensures
    only commands posted by THIS daemon instance are picked up when multiple daemons
    run against the same project.

    Config (~/.codicent/wrap-config.yaml):
        autopilot_level: 0   # 0=always confirm, 1=confirm risky, 2=fully autonomous
        allowed_paths:       # Restrict fs_* tool access (empty = all paths allowed)
          - /var/log
          - /home/user/project

UPDATE:
    update              Check if a newer version is available on PyPI
        --install       Also upgrade immediately via pip

ENVIRONMENT:
    CODICENT_TOKEN     Your Codicent API token (fallback if no cached auth)

For more information, visit: https://github.com/izaxon/codicent-cli
"""
    print(help_text.strip())

CURRENT_VERSION = "0.8.4"

def show_version():
    """Display version information."""
    print(f"Codicent CLI v{CURRENT_VERSION}")

def validate_input(question):
    """Validate user input."""
    if not question or not question.strip():
        return False, "Empty question provided"
    
    if len(question) > 10000:  # Reasonable limit
        return False, "Question too long (max 10,000 characters)"
    
    return True, None


# ---------------------------------------------------------------------------
# CLI config (shares ~/.codicent/wrap-config.yaml with the wrap command)
# ---------------------------------------------------------------------------
CLI_CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".codicent", "wrap-config.yaml")

def load_cli_config():
    """Load CLI config from ~/.codicent/wrap-config.yaml."""
    config = {"autopilot_level": 0, "allowed_paths": []}
    if os.path.exists(CLI_CONFIG_PATH):
        try:
            import yaml
            with open(CLI_CONFIG_PATH, "r") as f:
                user_config = yaml.safe_load(f) or {}
            config.update(user_config)
        except Exception as e:
            logger.warning(f"Could not load CLI config: {e}")
    return config


# ---------------------------------------------------------------------------
# Delegation helpers
# ---------------------------------------------------------------------------
DELEGATION_PREFIXES = (
    "#execute_command\n",
    "#fs_read\n",
    "#fs_write\n",
    "#fs_list\n",
    "#fs_search\n",
)


def _check_allowed_path(path, allowed_paths):
    """Return True if path is within any of the allowed_paths (or if list is empty)."""
    if not allowed_paths:
        return True
    import pathlib
    try:
        target = pathlib.Path(path).resolve()
    except Exception:
        return False
    for allowed in allowed_paths:
        try:
            allowed_abs = pathlib.Path(allowed).resolve()
            target.relative_to(allowed_abs)
            return True
        except ValueError:
            continue
    return False


def _parse_delegation(function_result_content):
    """
    Parse a raw #function_result message content and return
    (function_name, delegation_prefix, data_dict, tool_id) if it is a delegation,
    or None otherwise.

    function_result_content: the full message content string from GetMessageHistory,
    e.g. '@project\\n#function_result\\n{"role":"function","name":"execute_command","content":"#execute_command\\n{...}","id":"..."}' 
    """
    # Strip @mention and leading tags
    body = re.sub(r"^@\S+\s*", "", function_result_content).strip()
    body = re.sub(r"^#function_result\s*\n?", "", body).strip()
    try:
        fr = json.loads(body)
    except Exception:
        return None
    fc = fr.get("content", "")
    for prefix in DELEGATION_PREFIXES:
        if fc.startswith(prefix):
            try:
                data = json.loads(fc[len(prefix):])
            except Exception:
                return None
            return fr.get("name", ""), prefix.rstrip("\n").lstrip("#"), data, fr.get("id", "")
    return None


def _execute_fs_delegation(function_name, data, allowed_paths):
    """Execute a filesystem delegation and return a result string."""
    import pathlib
    import fnmatch

    if function_name == "fs_read":
        path = data.get("path", "")
        if not _check_allowed_path(path, allowed_paths):
            return f"Error: path '{path}' is not within allowed_paths"
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            return content
        except Exception as e:
            return f"Error reading file: {e}"

    elif function_name == "fs_write":
        path = data.get("path", "")
        content = data.get("content", "")
        if not _check_allowed_path(path, allowed_paths):
            return f"Error: path '{path}' is not within allowed_paths"
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            return f"Written {len(content)} characters to '{path}'"
        except Exception as e:
            return f"Error writing file: {e}"

    elif function_name == "fs_list":
        path = data.get("path", "")
        if not _check_allowed_path(path, allowed_paths):
            return f"Error: path '{path}' is not within allowed_paths"
        try:
            entries = os.listdir(path)
            lines = []
            for entry in sorted(entries):
                full = os.path.join(path, entry)
                suffix = "/" if os.path.isdir(full) else ""
                lines.append(entry + suffix)
            return "\n".join(lines) if lines else "(empty)"
        except Exception as e:
            return f"Error listing directory: {e}"

    elif function_name == "fs_search":
        base = data.get("path", "")
        pattern = data.get("pattern", "*")
        query = data.get("query")
        if not _check_allowed_path(base, allowed_paths):
            return f"Error: path '{base}' is not within allowed_paths"
        try:
            matched = []
            for root, dirs, files in os.walk(base):
                # Prune hidden dirs
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                for fname in files:
                    if fnmatch.fnmatch(fname, pattern):
                        fpath = os.path.join(root, fname)
                        if query:
                            try:
                                with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                                    if query.lower() in f.read().lower():
                                        matched.append(fpath)
                            except Exception:
                                pass
                        else:
                            matched.append(fpath)
            return "\n".join(matched[:500]) if matched else "(no matches)"
        except Exception as e:
            return f"Error searching: {e}"

    return f"Error: unknown fs function '{function_name}'"


def _execute_shell_delegation(data, allowed_paths, autopilot_level, console, interactive, require_confirm_fn=None):
    """
    Execute a shell command delegation.
    Returns (output_str, success_bool).
    require_confirm_fn: callable(cmd) -> bool, called when autopilot_level < 2.
    If None, always executes (daemon mode trusts autopilot_level).
    """
    cmd = data.get("command", "")
    working_dir = data.get("working_directory")
    timeout = data.get("timeout_seconds", 30)

    if not cmd:
        return "Error: empty command", False

    # Autopilot gate
    if require_confirm_fn is not None and autopilot_level < 2:
        if not require_confirm_fn(cmd):
            return "Command skipped by user.", False

    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=working_dir,
            encoding="utf-8",
            errors="replace",
        )
        parts = []
        if result.stdout:
            parts.append(result.stdout.strip())
        if result.stderr:
            parts.append(f"stderr: {result.stderr.strip()}")
        parts.append(f"exit_code: {result.returncode}")
        return "\n".join(parts), result.returncode == 0
    except subprocess.TimeoutExpired:
        return f"Error: command timed out after {timeout}s", False
    except Exception as e:
        return f"Error: {e}", False


def _post_function_result_msg(base_url, token, verify_https, project, parent_id, function_name, result_content, tool_id):
    """Post a #function_result message as a child of parent_id (the delegation message)."""
    fr = {"role": "function", "name": function_name, "content": result_content, "id": tool_id or ""}
    body = f"@{project}\n#function_result\n{json.dumps(fr)}"
    url = f"{base_url}app/AddChatMessage"
    payload = {"content": body, "type": "ai-chat-answer2", "parentId": str(parent_id)}
    try:
        resp = requests.post(
            url,
            json=payload,
            headers={"Authorization": f"Bearer {token}"},
            verify=verify_https,
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error(f"Failed to post function result: {e}")
        return None


def _start_chat_async(base_url, token, verify_https, project, message, conversation_id=None):
    """Post chat message via StartAi2ChatAsync and return the promptMessageId."""
    payload = {"message": message, "project": project}
    if conversation_id:
        payload["messageId"] = str(conversation_id)
    url = f"{base_url}app/StartAi2ChatAsync"
    resp = requests.post(
        url,
        json=payload,
        headers={"Authorization": f"Bearer {token}"},
        verify=verify_https,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("promptMessageId")


def _fetch_history(base_url, token, verify_https, message_id):
    """Fetch conversation history chain for the given message_id."""
    url = f"{base_url}app/GetMessageHistory"
    resp = requests.get(
        url,
        params={"messageId": str(message_id)},
        headers={"Authorization": f"Bearer {token}"},
        verify=verify_https,
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json() if resp.text else []


def _wait_for_ai_reply_with_delegation(
    base_url, token, verify_https, project, prompt_message_id,
    on_delegation, poll_interval=1.5, timeout=360
):
    """
    Poll GetMessageHistory until a final text reply is found.
    Calls on_delegation(msg_content, msg_id) when a delegation is detected.
    Returns {id, content} of the final text message, or None on timeout.
    """
    import time
    deadline = time.time() + timeout
    last_seen_id = None

    while time.time() < deadline:
        try:
            history = _fetch_history(base_url, token, verify_https, prompt_message_id)
        except Exception as e:
            logger.warning(f"History fetch error: {e}")
            time.sleep(poll_interval)
            continue

        if not history or len(history) < 2:
            time.sleep(poll_interval)
            continue

        # Latest message in the chain (leaf)
        last = history[-1]
        last_id = last.get("id") or last.get("Id")
        content = last.get("content") or last.get("Content", "")

        if last_id == last_seen_id:
            time.sleep(poll_interval)
            continue
        last_seen_id = last_id

        # Check for delegation in function_result messages
        if "#function_result" in content:
            delegation = _parse_delegation(content)
            if delegation:
                on_delegation(content, last_id)
                time.sleep(poll_interval)
                continue

        # Check if this is an intermediate (non-finished) engine state
        intermediate_markers = [
            "#chat2", "#finish_reason_function_call", "#finish_reason_tool_calls_batch",
            "#function_result", "#function_results_batch",
        ]
        if any(m in content for m in intermediate_markers):
            time.sleep(poll_interval)
            continue

        # Finished: strip @mention and leading tags for display
        clean = re.sub(r"^@\S+\s*", "", content).strip()
        clean = re.sub(r"^(#\S+\s*)+", "", clean).strip()
        return {"id": last_id, "content": clean}

    return None  # timeout

def main():
    console = Console()
    
    # Parse command line arguments
    if "-h" in sys.argv or "--help" in sys.argv:
        show_help()
        return 0
    
    if "-v" in sys.argv or "--version" in sys.argv:
        show_version()
        return 0
    
    # Set logging level based on flags
    if "--verbose" in sys.argv:
        logging.getLogger().setLevel(logging.INFO)
        sys.argv.remove("--verbose")
        logger.info("Verbose logging enabled")
    
    if "--quiet" in sys.argv:
        logging.getLogger().setLevel(logging.ERROR)
        sys.argv.remove("--quiet")
    
    # Parse --local flag (store/remove token in current working directory)
    use_local = "--local" in sys.argv
    if use_local:
        sys.argv.remove("--local")
    
    # Initialize auth handler
    auth = CodicentAuth()
    
    # Handle authentication commands
    if len(sys.argv) > 1 and sys.argv[1] in ["auth", "logout", "status"]:
        command = sys.argv[1]
        
        if command == "auth":
            token = auth.get_token(force_reauth=True, local=use_local)
            if token:
                console.print("[green]✅ Authentication successful![/green]")
                return 0
            else:
                console.print("[red]❌ Authentication failed[/red]")
                return 1
        
        elif command == "logout":
            auth.logout(local=use_local)
            return 0
        
        elif command == "status":
            source = auth.get_token_source()
            if source:
                console.print(f"[green]✅ Authenticated[/green] [dim]({source})[/dim]")
                return 0
            else:
                env_token = os.getenv("CODICENT_TOKEN")
                if env_token:
                    console.print("[yellow]⚠ Using CODICENT_TOKEN environment variable[/yellow]")
                    console.print("[dim]Consider running 'codicent auth' to use persistent authentication[/dim]")
                    return 0
                else:
                    console.print("[red]❌ Not authenticated[/red]")
                    console.print("[dim]Run 'codicent auth' to authenticate[/dim]")
                    return 1
    
    # Handle update command
    if len(sys.argv) > 1 and sys.argv[1] == "update":
        do_install = "--install" in sys.argv
        try:
            resp = requests.get(
                "https://pypi.org/pypi/codicent-cli/json",
                timeout=10,
            )
            resp.raise_for_status()
            latest = resp.json()["info"]["version"]
        except Exception as e:
            console.print(f"[red]❌ Could not check PyPI: {e}[/red]")
            return 1

        from packaging.version import Version

        # Detect whether we're running inside a pipx-managed environment
        is_pipx = "pipx" in sys.executable.replace("\\", "/")

        if Version(latest) > Version(CURRENT_VERSION):
            console.print(
                f"[yellow]⬆ New version available:[/yellow] "
                f"[bold]{latest}[/bold] (you have {CURRENT_VERSION})"
            )
            if do_install:
                if is_pipx:
                    console.print("[dim]Running pipx upgrade codicent-cli...[/dim]")
                    result = subprocess.run(
                        ["pipx", "upgrade", "codicent-cli"],
                        capture_output=False,
                    )
                else:
                    console.print("[dim]Running pip install --upgrade codicent-cli...[/dim]")
                    result = subprocess.run(
                        [sys.executable, "-m", "pip", "install", "--upgrade", "codicent-cli"],
                        capture_output=False,
                    )
                return result.returncode
            else:
                upgrade_cmd = "pipx upgrade codicent-cli" if is_pipx else "pip install --upgrade codicent-cli"
                console.print(
                    f"[dim]Run [bold]codicent update --install[/bold] to upgrade, "
                    f"or [bold]{upgrade_cmd}[/bold][/dim]"
                )
        else:
            console.print(f"[green]✅ Already up to date (v{CURRENT_VERSION})[/green]")
        return 0

    # Handle upload command
    if len(sys.argv) > 1 and sys.argv[1] == "upload":
        if len(sys.argv) < 3:
            console.print("[red]❌ Error: No files specified for upload[/red]")
            console.print("[dim]Usage: codicent upload <file_pattern> [<file_pattern> ...][/dim]")
            console.print("[dim]Example: codicent upload file.txt *.log[/dim]")
            return 1
        
        # Get authentication token
        token = auth.get_cached_token()
        if not token:
            # Fallback to environment variable
            token = os.getenv("CODICENT_TOKEN")
            if not token:
                console.print("[red]❌ No authentication found.[/red]")
                console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN environment variable[/dim]")
                return 1
            else:
                logger.info("Using CODICENT_TOKEN environment variable")
        
        # Initialize API client with error handling
        try:
            codicent = Codicent(token)
            logger.info("Codicent API client initialized successfully")
        except Exception as e:
            console.print(f"[red]❌ Failed to initialize Codicent API client: {e}[/red]")
            logger.error(f"API client initialization failed: {e}")
            console.print("[dim]Try running 'codicent auth' to re-authenticate[/dim]")
            return 1
        
        # Extract project from JWT token
        try:
            payload = token.split(".")[1]
            payload += '=' * (-len(payload) % 4)
            decoded_payload = base64.urlsafe_b64decode(payload).decode('utf-8')
            jwt_data = json.loads(decoded_payload)
            project = jwt_data["project"]
        except Exception as e:
            console.print(f"[red]❌ Failed to extract project from token: {e}[/red]")
            return 1
        
        # Collect all files from patterns
        file_patterns = sys.argv[2:]
        files_to_upload = []
        
        for pattern in file_patterns:
            matched_files = glob.glob(pattern)
            if matched_files:
                files_to_upload.extend(matched_files)
            else:
                # If no glob match, check if it's a direct file path
                if os.path.isfile(pattern):
                    files_to_upload.append(pattern)
                else:
                    console.print(f"[yellow]⚠ Warning: No files found matching pattern '{pattern}'[/yellow]")
        
        if not files_to_upload:
            console.print("[red]❌ Error: No files found to upload[/red]")
            return 1
        
        # Remove duplicates while preserving order
        files_to_upload = list(dict.fromkeys(files_to_upload))
        
        console.print(f"[dim]Found {len(files_to_upload)} file(s) to upload[/dim]")
        
        # Upload each file and post a message
        uploaded_count = 0
        failed_count = 0
        
        for filepath in files_to_upload:
            try:
                filename = os.path.basename(filepath)
                console.print(f"[dim]Uploading {filename}...[/dim]")
                
                with console.status(f"[dim]Uploading {filename}...[/dim]", spinner="dots"):
                    # Upload the file
                    with open(filepath, 'rb') as file:
                        url = f"{codicent.base_url}app/UploadFile"
                        files = {"file": file}
                        params = {"filename": filename}
                        response = requests.post(url, files=files, params=params, verify=codicent.verify_https)
                        if response.ok:
                            file_guid = response.json()
                        else:
                            raise Exception(f"Upload failed: {response.status_code} - {response.text}")

                    # Post a message with the file reference
                    # Get project name from first @ mention if available, otherwise use @myproject
                    message = f"@{project} #index #summarize #file:{file_guid}"
                    codicent.post_message(message, type="info")
                
                console.print(f"[green]✅ Uploaded: {filename} (File ID: {file_guid})[/green]")
                uploaded_count += 1
                
            except FileNotFoundError:
                console.print(f"[red]❌ File not found: {filepath}[/red]")
                failed_count += 1
            except PermissionError:
                console.print(f"[red]❌ Permission denied: {filepath}[/red]")
                failed_count += 1
            except Exception as e:
                console.print(f"[red]❌ Failed to upload {filename}: {e}[/red]")
                logger.error(f"Upload failed for {filepath}: {e}")
                failed_count += 1
        
        # Summary
        console.print()
        console.print(f"[bold]Upload Summary:[/bold]")
        console.print(f"  [green]✅ Uploaded: {uploaded_count}[/green]")
        if failed_count > 0:
            console.print(f"  [red]❌ Failed: {failed_count}[/red]")
        
        return 0 if failed_count == 0 else 1

    # Handle init command
    if len(sys.argv) > 1 and sys.argv[1] == "init":
        templates_dir = os.path.join(os.path.dirname(__file__), "templates")

        dry_run = "--dry-run" in sys.argv
        force = "--force" in sys.argv

        # --list: show available templates
        if "--list" in sys.argv:
            try:
                available = [os.path.splitext(f)[0] for f in os.listdir(templates_dir) if f.endswith(".json")]
                console.print("[bold]Available templates:[/bold]")
                for name in sorted(available):
                    template_path = os.path.join(templates_dir, f"{name}.json")
                    with open(template_path, encoding="utf-8") as fh:
                        meta = json.load(fh)
                    vars_info = ""
                    if meta.get("variables"):
                        vars_info = f" [dim]({len(meta['variables'])} variable(s))[/dim]"
                    console.print(f"  [bold bright_cyan]{name}[/bold bright_cyan]{vars_info} — {meta.get('description', '')}")
            except Exception as e:
                console.print(f"[red]❌ Error listing templates: {e}[/red]")
            return 0

        # Resolve template name
        template_name = "default"
        if "--template" in sys.argv:
            idx = sys.argv.index("--template")
            if idx + 1 < len(sys.argv):
                template_name = sys.argv[idx + 1]
            else:
                console.print("[red]❌ --template requires a name. Use 'codicent init --list' to see options.[/red]")
                return 1

        template_path = os.path.join(templates_dir, f"{template_name}.json")
        if not os.path.isfile(template_path):
            console.print(f"[red]❌ Template '{template_name}' not found. Use 'codicent init --list' to see options.[/red]")
            return 1

        with open(template_path, encoding="utf-8") as fh:
            template = json.load(fh)

        # Resolve variables: prompt for any without defaults
        variable_values = {}
        template_variables = template.get("variables", {})
        for var_name, var_meta in template_variables.items():
            default = var_meta.get("default", "")
            description = var_meta.get("description", var_name)
            if dry_run:
                # In dry-run, use defaults without prompting
                variable_values[var_name] = default or f"{{{var_name}}}"
            elif default:
                variable_values[var_name] = default
                console.print(f"[dim]  {var_name}: {default} (default)[/dim]")
            else:
                value = input(f"  {description}: ").strip()
                if not value:
                    console.print(f"[red]❌ Variable '{var_name}' is required.[/red]")
                    return 1
                variable_values[var_name] = value

        def apply_variables(text, project):
            result = text.replace("{project}", project)
            for var_name, var_value in variable_values.items():
                result = result.replace("{" + var_name + "}", var_value)
            return result

        # --- Dry-run mode: print plan without calling API ---
        if dry_run:
            messages = template.get("messages", [])
            console.print(f"\n[bold]Dry run — template [bright_cyan]{template_name}[/bright_cyan] ({len(messages)} messages)[/bold]")
            console.print(f"[dim]No messages will be posted. Remove --dry-run to execute.[/dim]\n")
            for i, entry in enumerate(messages, 1):
                label = entry.get("label", f"Message {i}")
                content = apply_variables(entry["content"], "{project}")
                # Show first 120 chars of content
                preview = content.replace("\n", "  ↵  ")
                if len(preview) > 120:
                    preview = preview[:117] + "..."
                console.print(f"  [bold]{i}.[/bold] [bright_cyan]{label}[/bright_cyan]")
                console.print(f"     [dim]{preview}[/dim]")
            console.print()
            return 0

        # Get authentication token
        token = auth.get_cached_token()
        if not token:
            token = os.getenv("CODICENT_TOKEN")
            if not token:
                console.print("[red]❌ No authentication found.[/red]")
                console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN environment variable[/dim]")
                return 1

        # Extract project from JWT token
        try:
            payload = token.split(".")[1]
            payload += '=' * (-len(payload) % 4)
            decoded_payload = base64.urlsafe_b64decode(payload).decode('utf-8')
            jwt_data = json.loads(decoded_payload)
            project = jwt_data["project"]
        except Exception as e:
            console.print(f"[red]❌ Failed to extract project from token: {e}[/red]")
            return 1

        try:
            codicent = Codicent(token)
        except Exception as e:
            console.print(f"[red]❌ Failed to initialize Codicent API client: {e}[/red]")
            return 1

        # Idempotency check: warn if #instructions already exists in this project
        if not force:
            try:
                headers = {"Authorization": f"Bearer {token}"}
                check_url = f"{codicent.base_url}api/GetMessages"
                resp = requests.get(
                    check_url,
                    params={"mention": project, "tags": "instructions", "length": "1"},
                    headers=headers,
                    verify=codicent.verify_https,
                    timeout=10,
                )
                if resp.ok and resp.json():
                    console.print(f"[yellow]⚠ Project [bold]{project}[/bold] already has #instructions — it may have been initialized before.[/yellow]")
                    console.print("[dim]Pass --force to initialize anyway, or --dry-run to preview what would be posted.[/dim]")
                    return 1
            except Exception:
                logger.debug("Idempotency check failed (skipping)")

        messages = template.get("messages", [])
        console.print(f"Initializing [bold]{project}[/bold] with template [bold bright_cyan]{template_name}[/bold bright_cyan] ({len(messages)} messages)...")

        posted = 0
        failed = 0
        for i, entry in enumerate(messages, 1):
            label = entry.get("label", f"Message {i}")
            content = apply_variables(entry["content"], project)
            msg_type = entry.get("type", "info")
            try:
                with console.status(f"[dim]({i}/{len(messages)}) {label}...[/dim]", spinner="dots"):
                    codicent.post_message(content, type=msg_type)
                console.print(f"  [green]✓[/green] [dim]{label}[/dim]")
                posted += 1
            except Exception as e:
                console.print(f"  [red]✗ {label}: {e}[/red]")
                failed += 1

        console.print()
        console.print(f"[green]✅ Done — {posted} message(s) posted to {project}.[/green]")
        if failed:
            console.print(f"[red]❌ {failed} message(s) failed.[/red]")
        return 0 if failed == 0 else 1

    # Handle wrap command
    # -----------------------------------------------------------------------
    # daemon subcommand — persistent remote AI outpost
    # -----------------------------------------------------------------------
    if len(sys.argv) > 1 and sys.argv[1] == "daemon":
        import time
        import uuid

        daemon_token = auth.get_cached_token()
        if not daemon_token:
            daemon_token = os.getenv("CODICENT_TOKEN")
        if not daemon_token:
            console.print("[red]❌ No authentication found.[/red]")
            console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN[/dim]")
            return 1

        try:
            dp = daemon_token.split(".")[1]
            dp += '=' * (-len(dp) % 4)
            daemon_jwt = json.loads(base64.urlsafe_b64decode(dp).decode('utf-8'))
            daemon_project = daemon_jwt["project"]
            daemon_base_url = daemon_jwt.get("baseUrl", "https://codicent.com/")
            daemon_verify = True
        except Exception as e:
            console.print(f"[red]❌ Failed to extract project from token: {e}[/red]")
            return 1

        daemon_config = load_cli_config()
        daemon_autopilot = daemon_config.get("autopilot_level", 0)
        daemon_allowed = daemon_config.get("allowed_paths", [])
        daemon_poll_interval = daemon_config.get("daemon", {}).get("poll_interval", 5)

        # Stable session identity — persistent across restarts when using the same token
        session_id = daemon_jwt.get("sub", "")[:16] or str(uuid.uuid4())[:8]
        console.print(f"[bold green]🤖 Codicent Daemon started[/bold green] (session={session_id})")
        console.print(f"[dim]Project: {daemon_project} | Autopilot level: {daemon_autopilot} | Poll: {daemon_poll_interval}s[/dim]")
        if daemon_allowed:
            console.print(f"[dim]Allowed paths: {daemon_allowed}[/dim]")

        # Track delegation messages we have posted results for (avoid double-execution)
        executed_ids = set()

        # We watch for delegation markers in "pending" messages addressed via session_id
        # The engine embeds session_id in every delegation JSON if provided in the tool call.
        # Format: @project #function_result {"role":"function","name":"...","content":"#execute_command\n{...session_id:...}","id":"..."}

        def _fetch_pending_delegations():
            """Fetch unhandled (leaf) function_result messages for this project."""
            url = f"{daemon_base_url}app/GetPendingDelegations"
            try:
                resp = requests.get(
                    url,
                    params={"project": daemon_project, "maxMessages": 50},
                    headers={"Authorization": f"Bearer {daemon_token}"},
                    verify=daemon_verify,
                    timeout=15,
                )
                resp.raise_for_status()
                return resp.json() if resp.text else []
            except Exception as e:
                logger.debug(f"Daemon poll error: {e}")
                return []

        try:
            while True:
                msgs = _fetch_pending_delegations()
                for msg in msgs:
                    msg_id = msg.get("id") or msg.get("Id")
                    if not msg_id or msg_id in executed_ids:
                        continue
                    content = msg.get("content") or msg.get("Content", "")
                    if "#function_result" not in content:
                        continue

                    delegation = _parse_delegation(content)
                    if not delegation:
                        continue

                    func_name, op, data, tool_id = delegation

                    # Filter by session_id if present in the delegation data
                    msg_session = data.get("session_id", "")
                    if msg_session and msg_session != session_id:
                        continue

                    # Mark as handled immediately to avoid duplicate execution
                    executed_ids.add(msg_id)

                    console.print(f"\n[bold cyan]→ Delegation:[/bold cyan] {op} | msg_id={msg_id}")

                    if op == "execute_command":
                        cmd = data.get("command", "")
                        console.print(f"  cmd: {cmd}")
                        if daemon_autopilot < 1:
                            # Non-interactive: always require autopilot_level >= 1 for daemon
                            result_str = "Daemon requires autopilot_level >= 1 for execute_command. Set in ~/.codicent/wrap-config.yaml."
                        else:
                            result_str, _ = _execute_shell_delegation(
                                data, daemon_allowed, daemon_autopilot, console, False, None
                            )
                    else:
                        result_str = _execute_fs_delegation(op, data, daemon_allowed)

                    console.print(f"  result: {result_str[:160]}{'…' if len(result_str) > 160 else ''}")
                    _post_function_result_msg(
                        daemon_base_url, daemon_token, daemon_verify,
                        daemon_project, msg_id, func_name, result_str, tool_id
                    )

                # Trim executed_ids if it gets large
                if len(executed_ids) > 2000:
                    executed_ids = set(list(executed_ids)[-1000:])

                time.sleep(daemon_poll_interval)

        except KeyboardInterrupt:
            console.print("\n[yellow]Daemon stopped.[/yellow]")
            return 0

    if len(sys.argv) > 1 and sys.argv[1] == "wrap":
        from wrap import run_wrap_command

        wrap_token = auth.get_cached_token()
        if not wrap_token:
            wrap_token = os.getenv("CODICENT_TOKEN")
        if not wrap_token:
            console.print("[red]❌ No authentication found.[/red]")
            console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN environment variable[/dim]")
            return 1

        # Extract project and base_url from JWT token
        try:
            wrap_payload = wrap_token.split(".")[1]
            wrap_payload += '=' * (-len(wrap_payload) % 4)
            wrap_jwt = json.loads(base64.urlsafe_b64decode(wrap_payload).decode('utf-8'))
            wrap_project = wrap_jwt["project"]
            wrap_base_url = wrap_jwt.get("baseUrl", "https://codicent.com/")
        except Exception as e:
            console.print(f"[red]❌ Failed to extract project from token: {e}[/red]")
            return 1

        # Pass everything after "wrap" as args
        wrap_args = sys.argv[2:]
        return run_wrap_command(
            args=wrap_args,
            token=wrap_token,
            base_url=wrap_base_url,
            project=wrap_project,
        )

    # Handle terminal command
    if len(sys.argv) > 1 and sys.argv[1] == "terminal":
        from terminal import run_terminal_host

        term_token = auth.get_cached_token()
        if not term_token:
            term_token = os.getenv("CODICENT_TOKEN")
        if not term_token:
            console.print("[red]❌ No authentication found.[/red]")
            console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN[/dim]")
            return 1

        try:
            term_payload = term_token.split(".")[1]
            term_payload += '=' * (-len(term_payload) % 4)
            term_jwt = json.loads(base64.urlsafe_b64decode(term_payload).decode('utf-8'))
            term_project = term_jwt["project"]
            term_base_url = term_jwt.get("baseUrl", "https://codicent.com/")
        except Exception as e:
            console.print(f"[red]❌ Failed to extract project from token: {e}[/red]")
            return 1

        shell_arg = sys.argv[2] if len(sys.argv) > 2 else None
        run_terminal_host(
            token=term_token,
            base_url=term_base_url,
            project=term_project,
            shell=shell_arg,
        )
        return 0

    # Get authentication token
    token = auth.get_cached_token()
    if not token:
        # Fallback to environment variable
        token = os.getenv("CODICENT_TOKEN")
        if not token:
            console.print("[red]❌ No authentication found.[/red]")
            console.print("[dim]Run 'codicent auth' to authenticate, or set CODICENT_TOKEN environment variable[/dim]")
            return 1
        else:
            logger.info("Using CODICENT_TOKEN environment variable")
    
    # Initialize API client with error handling
    try:
        codicent = Codicent(token)
        logger.info("Codicent API client initialized successfully")
    except Exception as e:
        console.print(f"[red]❌ Failed to initialize Codicent API client: {e}[/red]")
        logger.error(f"API client initialization failed: {e}")
        console.print("[dim]Try running 'codicent auth' to re-authenticate[/dim]")
        return 1
    
    conversationId = None
    cli_config = load_cli_config()
    autopilot_level = cli_config.get("autopilot_level", 0)
    allowed_paths = cli_config.get("allowed_paths", [])

    # Parse interactive mode flags
    interactive = False
    if "-t" in sys.argv or "--interactive" in sys.argv:
        interactive = True
        if "-t" in sys.argv:
            sys.argv.remove("-t")
        if "--interactive" in sys.argv:
            sys.argv.remove("--interactive")
    elif len(sys.argv) == 1:
        interactive = True
        
    # Get input based on mode (skip if we already handled auth commands)
    question = ""
    if not interactive:
        if len(sys.argv) < 2:
            if sys.stdin.isatty():
                console.print("Usage: codicent <question> or codicent < chat.txt or cat chat.txt | codicent or codicent (equal to codicent -t)")
                console.print("Use 'codicent --help' for more information.")
                return 1
            try:
                question = sys.stdin.read().strip()
            except (KeyboardInterrupt, EOFError):
                return 1
        else:
            question = " ".join(sys.argv[1:])
    else:
        if len(sys.argv) > 1:
            question = " ".join(sys.argv[1:])
        elif not sys.stdin.isatty():
            try:
                question = sys.stdin.read().strip()
            except (KeyboardInterrupt, EOFError):
                return 1

    def handle_question(question):
        nonlocal conversationId
        
        # Validate input
        is_valid, error_msg = validate_input(question)
        if not is_valid:
            print(f"Error: {error_msg}")
            logger.warning(f"Invalid input: {error_msg}")
            return False
        
        console = Console()
        
        try:
            if question.strip().startswith("@"):
                logger.info("Sending message to Codicent API")
                with console.status("[dim]Sending message...[/dim]", spinner="dots"):
                    response = codicent.post_message(question, type="info")
                console.print("[green]✅ Message posted successfully.[/green]")
            else:
                logger.info("Sending chat reply to Codicent API")

                # --- Async delegation loop ---
                def handle_delegation(msg_content, msg_id):
                    """Called when a delegation message is found during inline wait."""
                    delegation = _parse_delegation(msg_content)
                    if not delegation:
                        return
                    func_name, op, data, tool_id = delegation

                    if op == "execute_command":
                        cmd = data.get("command", "")
                        console.print(f"\n[bold yellow]⚡ AI wants to run:[/bold yellow] {cmd}")

                        def confirm_fn(c):
                            if autopilot_level >= 2:
                                return True
                            if not interactive:
                                return autopilot_level >= 1
                            try:
                                ans = prompt("Allow? (y/N) ")
                                return ans.strip().lower() == "y"
                            except (KeyboardInterrupt, EOFError):
                                return False

                        with console.status("[dim]Running command...[/dim]", spinner="dots"):
                            result_str, _ = _execute_shell_delegation(
                                data, allowed_paths, autopilot_level, console, interactive, confirm_fn
                            )
                        console.print(f"[dim]Result: {result_str[:200]}{'…' if len(result_str) > 200 else ''}[/dim]")
                        _post_function_result_msg(
                            codicent.base_url, token, codicent.verify_https,
                            project, msg_id, func_name, result_str, tool_id
                        )

                    elif op in ("fs_read", "fs_write", "fs_list", "fs_search"):
                        path = data.get("path", "")
                        console.print(f"\n[bold yellow]📂 AI filesystem op:[/bold yellow] {op} {path}")
                        if not _check_allowed_path(path, allowed_paths):
                            result_str = f"Error: path '{path}' is not within allowed_paths"
                        else:
                            with console.status("[dim]Executing...[/dim]", spinner="dots"):
                                result_str = _execute_fs_delegation(op, data, allowed_paths)
                        console.print(f"[dim]{result_str[:200]}{'…' if len(result_str) > 200 else ''}[/dim]")
                        _post_function_result_msg(
                            codicent.base_url, token, codicent.verify_https,
                            project, msg_id, func_name, result_str, tool_id
                        )

                try:
                    prompt_id = _start_chat_async(
                        codicent.base_url, token, codicent.verify_https,
                        project, question, conversationId
                    )
                except Exception:
                    # Fallback to synchronous post_chat_reply (no delegation support)
                    with console.status("[dim]🤔 Thinking...[/dim]", spinner="dots"):
                        response = codicent.post_chat_reply(question, conversationId)
                    conversationId = response["id"]
                    content = response["content"]
                else:
                    with console.status("[dim]🤔 Thinking...[/dim]", spinner="dots"):
                        response = _wait_for_ai_reply_with_delegation(
                            codicent.base_url, token, codicent.verify_https,
                            project, prompt_id, handle_delegation
                        )
                    if response is None:
                        console.print("[red]⏱ Request timed out or no reply received.[/red]")
                        return False
                    conversationId = response["id"]
                    content = response["content"]

                logger.info(f"Updated conversation ID: {conversationId}")

                # Show bot response with markdown formatting in green
                if interactive:
                    console.print()

                # Backward-compat: detect legacy shell: markers in AI response
                shell_commands = re.findall(r'^shell:(.+)$', content, re.MULTILINE)
                shell_blocks = re.findall(r'```shell\n(.*?)```', content, re.DOTALL)

                from rich.text import Text
                markdown_content = Markdown(content)
                console.print(markdown_content, style="green")
                console.print()

                all_commands = shell_commands + [block.strip() for block in shell_blocks]
                for cmd in all_commands:
                    cmd = cmd.strip()
                    if not cmd:
                        continue
                    console.print(f"[bold yellow]Shell command detected:[/bold yellow] {cmd}")
                    if interactive:
                        try:
                            confirm = prompt("Run this command? (y/N) ")
                        except (KeyboardInterrupt, EOFError):
                            confirm = "n"
                        if confirm.strip().lower() == 'y':
                            console.print(f"[dim]Running: {cmd}[/dim]")
                            try:
                                result = subprocess.run(
                                    cmd,
                                    shell=True,
                                    capture_output=True,
                                    text=True,
                                    timeout=60,
                                    encoding='utf-8',
                                    errors='replace'
                                )

                                if result.stdout:
                                    console.print(result.stdout)
                                if result.stderr:
                                    console.print(f"[red]{result.stderr}[/red]")
                                if result.returncode == 0:
                                    console.print(f"[green]Exit code: {result.returncode}[/green]")
                                else:
                                    console.print(f"[red]Exit code: {result.returncode}[/red]")

                                output_parts = [f"Command executed: `{cmd}`", ""]
                                if result.stdout:
                                    output_parts += ["Output:", "```", result.stdout.strip(), "```"]
                                if result.stderr:
                                    output_parts += ["Errors:", "```", result.stderr.strip(), "```"]
                                output_parts.append(f"Exit code: {result.returncode}")
                                command_output = "\n".join(output_parts)

                                try:
                                    prompt_id2 = _start_chat_async(
                                        codicent.base_url, token, codicent.verify_https,
                                        project, command_output, conversationId
                                    )
                                    with console.status("[dim]Sending output to AI...[/dim]", spinner="dots"):
                                        resp2 = _wait_for_ai_reply_with_delegation(
                                            codicent.base_url, token, codicent.verify_https,
                                            project, prompt_id2, handle_delegation
                                        )
                                    if resp2:
                                        conversationId = resp2["id"]
                                        console.print()
                                        console.print("[dim]AI response:[/dim]")
                                        console.print(Markdown(resp2["content"]), style="green")
                                        console.print()
                                except Exception as e:
                                    logger.warning(f"Could not send shell output back to AI: {e}")

                            except subprocess.TimeoutExpired:
                                console.print("[red]Command timed out after 60 seconds[/red]")
                            except Exception as e:
                                console.print(f"[red]Error: {e}[/red]")
                        else:
                            console.print("[dim]Skipped.[/dim]")
                    else:
                        console.print("[dim]Use interactive mode (-t) to execute commands.[/dim]")
            
            return True
            
        except KeyboardInterrupt:
            console.print("\n[yellow]Operation cancelled by user[/yellow]")
            return False
        except ConnectionError as e:
            console.print(f"[red]Network error: Unable to connect to Codicent API[/red]")
            logger.error(f"Connection error: {e}")
            return False
        except Exception as e:
            console.print(f"[red]API error: {e}[/red]")
            logger.error(f"API call failed (CODICENT_API_TOKEN expired?): {e}")
            return False

    # Handle initial question if provided
    if question != "":
        success = handle_question(question)
        if not success and not interactive:
            return 1
    
    # Interactive mode loop
    if interactive:
        from rich.panel import Panel
        from rich.text import Text
        from rich.columns import Columns
        console = Console()

        logo = Text()
        logo.append("██", style="bold bright_cyan")
        logo.append("██\n", style="bold green")
        logo.append("██", style="bold green")
        logo.append("██", style="bold bright_cyan")

        header = Text()
        header.append("Codicent CLI", style="bold bright_cyan")
        header.append(f" v{CURRENT_VERSION}\n", style="bright_cyan")
        header.append("Type your questions or use Ctrl+C to exit.\n", style="dim")
        header.append("\n")
        header.append("Tip: ", style="bold dim")
        header.append("@message", style="bold bright_cyan")
        header.append(" to post an info message to your project\n", style="dim")
        header.append("Codicent uses AI, so always check for mistakes.", style="dim")

        content = Columns([logo, header], padding=(0, 2))
        console.print(Panel(content, border_style="bright_cyan", padding=(1, 2)))
        console.print("[dim]Enter: send | Alt+Enter: new line | Paste: multi-line supported[/dim]")
        
        # Create custom key bindings
        bindings = KeyBindings()

        @bindings.add(Keys.Enter)
        def _(event):
            """Enter submits the input."""
            event.current_buffer.validate_and_handle()

        @bindings.add(Keys.Escape, Keys.Enter)  # Alt+Enter
        def _(event):
            """Alt+Enter inserts a newline."""
            event.current_buffer.insert_text('\n')

        while True:
            try:
                # Use prompt_toolkit's prompt instead of input()
                question = prompt(
                    "¤ ",
                    multiline=True,
                    key_bindings=bindings,
                    prompt_continuation=""  # No continuation prompt for clean look
                )
            except KeyboardInterrupt:
                console.print("\n[yellow]👋 Goodbye![/yellow]")
                break
            except EOFError:
                break
            
            if question.strip() != "":
                handle_question(question)
                # Add a separator line after each interaction
                if question.strip() != "" and not question.strip().startswith("@"):
                    console.print("[dim]" + "─" * 50 + "[/dim]")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
