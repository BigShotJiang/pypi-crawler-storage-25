"""
codicent wrap — AI CLI Remote Chat Bridge

Wraps a local AI CLI tool (claude, codex, opencode, etc.) and bridges its
stdin/stdout to a Codicent chat conversation. Remote users can chat with the
locally running tool in real time via the Codicent web UI or ClientApp chat.

Conversation model:
  The session-open message (type "wrap-session") becomes the conversation root.
  Its returned id is the conversation_id = originalMessageId for all messages.
  All subsequent messages chain via parentId — forming a native Codicent chat.

Message types:
  Session root:  type="wrap-session"      (engine uses this to skip LLM processing)
  Tool output:   type="ai-chat-answer2"   (renders as bot bubble in ChatPage)
  User input:    type="ai-chat-prompt2"   (sent by ChatPage, detected by type prefix)
"""

import os
import sys
import time
import logging
import threading
import subprocess
import shutil
import re
import select
import signal

import requests

# PTY support is available on POSIX (Linux, macOS, WSL) but not native Windows
try:
    import pty
    import termios
    import fcntl
    import struct
    _HAS_PTY = True
except ImportError:
    _HAS_PTY = False

# pyte renders the VT100 virtual screen so we get clean text without fighting
# escape sequences.  Optional — falls back to raw byte accumulation if missing.
try:
    import pyte
    _HAS_PYTE = True
except ImportError:
    _HAS_PYTE = False

# Comprehensive ANSI/VT sequence stripper:
# - CSI sequences:  ESC [ ... final    (cursor, color, mouse events, private modes, etc.)
# - OSC sequences:  ESC ] ... BEL/ST   (window title, palette, etc.)
# - G0/G1 charsets: ESC ( x / ESC ) x
# - Other 2-char Fe:  ESC [A-Z\^_`] etc.
# - Standalone BEL, SO, SI
_ANSI_RE = re.compile(
    r'\x1b(?:'
    r'\[[\x30-\x3f]*[\x20-\x2f]*[\x40-\x7e]'  # CSI  (covers mouse M/m, all cursor ops)
    r'|\][^\x07\x1b]*(?:\x07|\x1b\\)'       # OSC  (title, color queries)
    r'|[()].'
    r'|[A-Z\\^_`a-z{|}~]'
    r')'
    r'|\x07|\x0e|\x0f'  # BEL, SO, SI
)


def _strip_ansi(text: str) -> str:
    """Remove ALL terminal control/escape sequences from a string."""
    return _ANSI_RE.sub("", text)


# Unicode ranges used by TUI spinners/progress bars:
# Box Drawing, Block Elements, Geometric Shapes, Braille, Misc Symbols, Arrows, etc.
_TUI_SYMBOLS_RE = re.compile(
    r'[\u2500-\u27FF'   # Box Drawing + Block Elements + Geometric + Misc + Arrows + Braille
    r'\u2B00-\u2BFF'   # Misc Symbols and Arrows
    r'\u2900-\u297F'   # Supplemental Arrows-B
    r'\uFE10-\uFE1F'   # Vertical Forms
    r'\uFF00-\uFFEF]'  # Halfwidth/Fullwidth
)


def _clean_tui_text(raw: str) -> str:
    """Strip ANSI, TUI spinner symbols, and normalize to readable lines."""
    text = _strip_ansi(raw)
    # Replace TUI symbol characters with a space
    text = _TUI_SYMBOLS_RE.sub(" ", text)
    # Collapse multiple spaces/tabs
    text = re.sub(r"[ \t]{2,}", " ", text)
    # Split on any CR/LF, strip, deduplicate, drop noise lines
    seen: set[str] = set()
    lines: list[str] = []
    for line in re.split(r"[\r\n]+", text):
        line = line.strip()
        # Strip leading/trailing ASCII spinner chars (|, -, =, /, \, *)
        line = re.sub(r"^[\|\-=\/\\\*\s]+", "", line)
        line = re.sub(r"[\|\-=\/\\\*\s]+$", "", line)
        line = line.strip()
        # Drop lines with fewer than 3 alphanumeric chars
        if sum(1 for c in line if c.isalnum()) < 3:
            continue
        # Drop lines that are pure TUI status-bar chrome.
        # A status bar line contains MULTIPLE of these markers simultaneously
        # (git branch + model + % requests).  We only drop when it's clearly
        # a combined status line, not user-facing content that happens to
        # share one token (e.g. a folder-trust dialog that shows a path).
        status_markers = sum([
            bool(re.search(r"Remaining reqs\.", line)),
            bool(re.search(r"Environment loaded:", line)),
            bool(re.search(r"custom instructions", line)),
            bool(re.search(r"MCP server", line)),
            bool(re.search(r"shift\+tab switch mode", line)),
            bool(re.search(r"Type @ to mention", line)),
            bool(re.search(r"\d+\.\d+%", line)),          # "90.8%"
        ])
        if status_markers >= 2:
            continue
        # Also drop pure loading-spinner lines
        if re.search(r"Loading environment:\s+\d+\s+custom", line):
            continue
        if line not in seen:
            seen.add(line)
            lines.append(line)

    # Collapse repeated sentences within the joined text.
    # Copilot renders hint text (e.g. "Describe a task to get started.")
    # wrapping across the full PTY width — so the same sentence appears many times.
    joined = "\n".join(lines)
    # Split on sentence boundaries, then remove consecutive duplicates
    sentences = re.split(r"(?<=[.!?])\s+", joined)
    deduped_s: list[str] = []
    for s in sentences:
        if not deduped_s or s.strip() != deduped_s[-1].strip():
            deduped_s.append(s)
    joined = " ".join(deduped_s)
    # Also collapse pure-duplicate lines that survived the first pass
    final_lines: list[str] = []
    final_seen: set[str] = set()
    for line in joined.split("\n"):
        line = line.strip()
        if line and line not in final_seen:
            final_seen.add(line)
            final_lines.append(line)

    return "\n".join(final_lines).strip()


def _text_fingerprint(text: str) -> frozenset[str]:
    """Return a set of significant words (4+ letters) for dedup comparison.

    Two texts with the same set of meaningful words are treated as equivalent
    even if the surrounding spinner chars or ordering differs slightly.
    Strips HTML tags before computing so colored and plain text compare equal.
    """
    plain = re.sub(r"<[^>]+>", "", text)
    return frozenset(re.findall(r"[a-z]{4,}", plain.lower()))


# ---------------------------------------------------------------------------
# pyte color / style → HTML helpers
# ---------------------------------------------------------------------------

# Map pyte's named colors to CSS hex values (standard xterm dark-theme palette)
_PYTE_TO_CSS: dict[str, str] = {
    "black":         "#000000",
    "red":           "#cd0000",
    "green":         "#00cd00",
    "brown":         "#cdcd00",   # pyte uses "brown" for yellow
    "blue":          "#0000ee",
    "magenta":       "#cd00cd",
    "cyan":          "#00cdcd",
    "white":         "#e5e5e5",
    "brightblack":   "#7f7f7f",
    "brightred":     "#ff0000",
    "brightgreen":   "#00ff00",
    "brightbrown":   "#ffff00",
    "brightblue":    "#5c5cff",
    "brightmagenta": "#ff00ff",
    "brightcyan":    "#00ffff",
    "brightwhite":   "#ffffff",
}


def _pyte_color_to_css(color: str) -> str | None:
    """Convert a pyte color string to a CSS color value, or None for default."""
    if not color or color == "default":
        return None
    if color in _PYTE_TO_CSS:
        return _PYTE_TO_CSS[color]
    # 256-color or truecolor: stored as 6-char lowercase hex (no leading #)
    if len(color) == 6 and all(c in "0123456789abcdef" for c in color.lower()):
        return f"#{color.lower()}"
    return None


def _format_run(text: str, fg: str, bold: bool, italics: bool, underscore: bool) -> str:
    """Wrap a text run in an HTML span for color and style.

    We use only HTML spans (no markdown ** / * markers) to avoid the parsing
    ambiguity where marked treats **<span>...</span>** as literal text instead
    of bold because the bold delimiters wrap inline HTML.
    """
    if not text:
        return ""
    styles: list[str] = []
    css = _pyte_color_to_css(fg)
    if css:
        styles.append(f"color:{css}")
    if bold:
        styles.append("font-weight:bold")
    if italics:
        styles.append("font-style:italic")
    if underscore:
        styles.append("text-decoration:underline")
    if styles:
        return f'<span style="{";".join(styles)}">{text}</span>'
    return text


# Terminal size used for the PTY window
_PTY_COLS = 220
_PTY_ROWS = 50

_WRAP_DEBUG = os.environ.get("WRAP_DEBUG", "").strip() == "1"


def _dbg(msg: str):
    """Print a debug line to stderr when WRAP_DEBUG=1."""
    if _WRAP_DEBUG:
        print(f"[wrap-dbg] {msg}", file=sys.stderr, flush=True)


logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_CONFIG = {
    "poll_interval": 2,
    "output_batch_ms": 500,
    "tools": {},
    "auto_responses": [],
}

CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".codicent", "wrap-config.yaml")


def load_config():
    """Load wrap config from ~/.codicent/wrap-config.yaml, falling back to defaults."""
    config = dict(DEFAULT_CONFIG)
    config["auto_responses"] = list(DEFAULT_CONFIG["auto_responses"])
    config["tools"] = dict(DEFAULT_CONFIG["tools"])

    if os.path.exists(CONFIG_PATH):
        try:
            import yaml
            with open(CONFIG_PATH, "r") as f:
                user_config = yaml.safe_load(f) or {}
            config.update(user_config)
            logger.info(f"Loaded wrap config from {CONFIG_PATH}")
        except Exception as e:
            logger.warning(f"Could not load wrap config from {CONFIG_PATH}: {e}")

    return config


def resolve_binary(tool_name, config, explicit_binary=None):
    """Resolve the binary path for a tool name."""
    if explicit_binary:
        return explicit_binary
    tool_config = config.get("tools", {}).get(tool_name, {})
    if isinstance(tool_config, dict):
        binary = tool_config.get("binary", tool_name)
    else:
        binary = str(tool_config)
    resolved = shutil.which(binary)
    if resolved:
        return resolved
    return binary


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

class WrapSession:
    """
    Manages a single wrap session: subprocess lifecycle, output capture,
    remote input polling, and codicent message posting.
    """

    def __init__(self, tool_name, tool_args, token, base_url, project,
                 label=None, explicit_binary=None, poll_interval=None,
                 verify_https=True):
        self.tool_name = tool_name
        self.tool_args = tool_args or []
        self.token = token
        self.base_url = base_url.rstrip("/") + "/"
        self.project = project
        self.verify_https = verify_https

        self.config = load_config()
        self.poll_interval = poll_interval or self.config.get("poll_interval", 2)
        self.output_batch_ms = self.config.get("output_batch_ms", 500)

        self.label = label or f"{tool_name} session"
        self.binary = resolve_binary(tool_name, self.config, explicit_binary)

        self._process = None
        self._running = False
        # Conversation model: _conversation_id is set after the first post;
        # _last_message_id is updated after every post for parentId chaining.
        self._conversation_id: str | None = None
        self._last_message_id: str | None = None
        self._seen_input_ids: set = set()

        self._master_fd: int | None = None
        self._last_posted_fp: frozenset[str] = frozenset()
        self._output_thread = None
        self._input_thread = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self):
        """Start the wrap session. Blocks until the subprocess exits."""
        from rich.console import Console
        console = Console()

        console.print(f"\n[bold bright_cyan]🔗 Wrap session starting…[/bold bright_cyan]")
        console.print(f"   Project:    [bold]{self.project}[/bold]")
        console.print(f"   Tool:       [bold]{self.tool_name}[/bold]  ([dim]{self.binary}[/dim])")
        console.print(f"   [dim]Press Ctrl+C to stop the session.[/dim]\n")

        try:
            self._post_session_message(f"🔗 Wrap session started: {self.label}\nTool: `{self.tool_name}`")
        except Exception as e:
            logger.warning(f"Could not post session-open message: {e}")

        # Print the chat URL now that _conversation_id is set
        chat_url = f"{self.base_url}chat/{self.project}/{self._conversation_id}"
        console.print(f"   Chat URL:   [bold bright_cyan]{chat_url}[/bold bright_cyan]\n")

        try:
            self._start_subprocess()
        except FileNotFoundError:
            console.print(f"[red]❌ Could not start '{self.binary}'. Is it installed and on your PATH?[/red]")
            return 1
        except Exception as e:
            console.print(f"[red]❌ Failed to start subprocess: {e}[/red]")
            return 1

        self._running = True

        self._output_thread = threading.Thread(target=self._output_reader, daemon=True, name="wrap-output")
        # Input poller started after _conversation_id is guaranteed to be set
        self._input_thread = threading.Thread(target=self._input_poller, daemon=True, name="wrap-input")

        self._output_thread.start()
        self._input_thread.start()

        exit_code = 0
        try:
            exit_code = self._process.wait()
        except KeyboardInterrupt:
            console.print("\n[yellow]⚠ Interrupted — closing session…[/yellow]")
            self._terminate_process()

        self._running = False
        self._output_thread.join(timeout=3)
        self._input_thread.join(timeout=3)

        if self._master_fd is not None:
            try:
                os.close(self._master_fd)
            except OSError:
                pass
            self._master_fd = None

        try:
            self._post_session_message(f"🔒 Wrap session closed (exit code: {exit_code})")
        except Exception as e:
            logger.warning(f"Could not post session-close message: {e}")

        console.print(f"\n[dim]Wrap session ended (exit code: {exit_code}).[/dim]")
        return exit_code

    # ------------------------------------------------------------------
    # Subprocess management
    # ------------------------------------------------------------------

    def _terminate_process(self):
        """Terminate the subprocess, using process group kill on POSIX so Node.js loaders don't orphan."""
        if self._process is None:
            return
        try:
            if _HAS_PTY:
                os.killpg(os.getpgid(self._process.pid), signal.SIGTERM)
            else:
                self._process.terminate()
        except (OSError, ProcessLookupError):
            pass
        try:
            self._process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                self._process.kill()
            except (OSError, ProcessLookupError):
                pass

    def _start_subprocess(self):
        cmd = [self.binary] + self.tool_args
        logger.info(f"Starting subprocess: {cmd}")

        if _HAS_PTY:
            # Open a PTY so the child tool sees a real terminal (isTTY=true).
            # This prevents Node.js / similar runtimes from switching to
            # block-buffering or non-interactive mode.
            master_fd, slave_fd = pty.openpty()
            _dbg(f"PTY opened: master_fd={master_fd} slave_fd={slave_fd}")

            # Disable echo on the slave side so that text we write to master
            # is NOT echoed back as output (which would double-post user input).
            try:
                attrs = termios.tcgetattr(slave_fd)
                attrs[3] &= ~termios.ECHO  # lflags — clear ECHO bit
                termios.tcsetattr(slave_fd, termios.TCSANOW, attrs)
                _dbg("Echo disabled on slave pty")
            except termios.error as e:
                _dbg(f"Could not disable echo: {e}")

            self._process = subprocess.Popen(
                cmd,
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                close_fds=True,
                start_new_session=True,  # own process group → killpg works
            )
            os.close(slave_fd)  # parent only needs the master end
            self._master_fd = master_fd
            _dbg(f"Subprocess PID={self._process.pid}, using PTY")
            # Tell the PTY its window size so ncurses/TUI apps lay out correctly
            try:
                winsize = struct.pack('HHHH', _PTY_ROWS, _PTY_COLS, 0, 0)
                fcntl.ioctl(master_fd, termios.TIOCSWINSZ, winsize)
                _dbg(f"PTY window size set to {_PTY_COLS}x{_PTY_ROWS}")
            except Exception as e:
                _dbg(f"Could not set PTY window size: {e}")
        else:
            # Fallback for native Windows (no pty module)
            _dbg("PTY not available, using pipes")
            self._process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )

    # ------------------------------------------------------------------
    # Output reader — reads subprocess stdout, batches, posts to codicent
    # ------------------------------------------------------------------

    def _output_reader(self):
        """Reads subprocess output and posts clean screen snapshots to codicent.

        Uses pyte (VT100 emulator) to render the virtual screen, sampled on a
        fixed timer.  This handles TUI apps that emit continuous spinner/cursor
        bytes with no quiet periods, making settle-based approaches unreliable.
        """
        SAMPLE_INTERVAL = 3.0  # seconds between screen snapshots

        def screen_to_markdown(screen) -> str:
            """Render the pyte Screen to colored markdown using per-character style data."""
            seen_plain: set[str] = set()
            md_lines: list[str] = []

            for row_idx, display_line in enumerate(screen.display):
                plain = display_line.rstrip()
                if not plain.strip():
                    continue
                if sum(1 for c in plain if c.isalnum()) < 3:
                    continue
                # Drop combined status-bar chrome lines (must match 2+ markers)
                markers = sum([
                    bool(re.search(r"Remaining reqs\.", plain)),
                    bool(re.search(r"Environment loaded:", plain)),
                    bool(re.search(r"custom instructions", plain)),
                    bool(re.search(r"MCP server", plain)),
                    bool(re.search(r"shift\+tab", plain)),
                    bool(re.search(r"Type @ to mention", plain)),
                    bool(re.search(r"\d{2,3}\.\d%", plain)),
                    bool(re.search(r"Loading environment:", plain)),
                ])
                if markers >= 2:
                    continue
                if plain in seen_plain:
                    continue
                seen_plain.add(plain)

                # Build a colored/styled line from pyte's buffer
                row = screen.buffer[row_idx]
                run_text = ""
                run_fg = ""
                run_bold = False
                run_italics = False
                run_under = False
                md_parts: list[str] = []

                for col in range(len(plain)):  # only up to stripped width
                    char = row[col]
                    ch_data = char.data if char.data else " "
                    ch_fg = char.fg
                    ch_bold = char.bold
                    ch_italics = char.italics
                    ch_under = char.underscore

                    same_style = (
                        ch_fg == run_fg
                        and ch_bold == run_bold
                        and ch_italics == run_italics
                        and ch_under == run_under
                    )
                    if same_style:
                        run_text += ch_data
                    else:
                        if run_text:
                            md_parts.append(
                                _format_run(run_text, run_fg, run_bold, run_italics, run_under)
                            )
                        run_text = ch_data
                        run_fg = ch_fg
                        run_bold = ch_bold
                        run_italics = ch_italics
                        run_under = ch_under

                if run_text:
                    md_parts.append(
                        _format_run(run_text, run_fg, run_bold, run_italics, run_under)
                    )

                md_line = "".join(md_parts).rstrip()
                if md_line:
                    md_lines.append(md_line)

            # Deduplicate consecutive repeated sentences
            joined = "\n".join(md_lines)
            sentences = re.split(r"(?<=[.!?])\s+", joined)
            deduped: list[str] = []
            for s in sentences:
                if not deduped or s.strip() != deduped[-1].strip():
                    deduped.append(s)
            return " ".join(deduped).strip()

        if _HAS_PTY and self._master_fd is not None:
            if _HAS_PYTE:
                _dbg(f"PTY+pyte output reader started (sample={SAMPLE_INTERVAL}s)")
                screen = pyte.Screen(_PTY_COLS, _PTY_ROWS)
                vt_stream = pyte.ByteStream(screen)
                last_sample = time.monotonic()

                while self._running:
                    try:
                        ready = select.select([self._master_fd], [], [], 0.1)[0]
                    except (OSError, ValueError):
                        break
                    if ready:
                        try:
                            chunk = os.read(self._master_fd, 4096)
                        except OSError:
                            _dbg("PTY read OSError (child exited)")
                            break
                        if not chunk:
                            break
                        _dbg(f"PTY read {len(chunk)} bytes: {chunk[:60]!r}")
                        vt_stream.feed(chunk)

                    now = time.monotonic()
                    if now - last_sample >= SAMPLE_INTERVAL:
                        last_sample = now
                        text = screen_to_markdown(screen)
                        if not text:
                            continue
                        fp = _text_fingerprint(text)
                        if fp and fp == self._last_posted_fp:
                            _dbg("Screen fingerprint unchanged, skipping")
                            continue
                        self._last_posted_fp = fp
                        _dbg(f"Posting screen snapshot ({len(text)} chars)")
                        plain = re.sub(r"<[^>]+>", "", text)
                        print(plain, flush=True)
                        self._maybe_auto_respond(plain)
                        try:
                            self._post_output_message(text)
                        except Exception as e:
                            logger.warning(f"Failed to post output: {e}")

                # Final snapshot on exit
                text = screen_to_markdown(screen)
                if text:
                    fp = _text_fingerprint(text)
                    if fp != self._last_posted_fp:
                        self._last_posted_fp = fp
                        try:
                            self._post_output_message(text)
                        except Exception:
                            pass
            else:
                # pyte not installed — settle-based raw byte accumulation fallback
                _dbg("pyte not available, using settle-based accumulation")
                SETTLE_S = 3.0
                accum = b""
                while self._running:
                    try:
                        ready = select.select([self._master_fd], [], [], SETTLE_S)[0]
                    except (OSError, ValueError):
                        break
                    if ready:
                        try:
                            chunk = os.read(self._master_fd, 4096)
                        except OSError:
                            break
                        accum += chunk
                    else:
                        if accum:
                            text = _clean_tui_text(accum.decode("utf-8", errors="replace"))
                            accum = b""
                            if text:
                                fp = _text_fingerprint(text)
                                if fp != self._last_posted_fp:
                                    self._last_posted_fp = fp
                                    print(text, flush=True)
                                    self._maybe_auto_respond(text)
                                    try:
                                        self._post_output_message(text)
                                    except Exception as e:
                                        logger.warning(f"Failed to post: {e}")
        else:
            # Pipe path (Windows fallback)
            _dbg("Pipe output reader started")
            accum = b""
            try:
                for line in self._process.stdout:
                    chunk = line.encode("utf-8") if isinstance(line, str) else line
                    accum += chunk
                    try:
                        fd = self._process.stdout.fileno()
                        if not select.select([fd], [], [], 0.3)[0]:
                            text = _clean_tui_text(accum.decode("utf-8", errors="replace"))
                            accum = b""
                            if text:
                                fp = _text_fingerprint(text)
                                if fp != self._last_posted_fp:
                                    self._last_posted_fp = fp
                                    print(text, flush=True)
                                    self._maybe_auto_respond(text)
                                    try:
                                        self._post_output_message(text)
                                    except Exception as e:
                                        logger.warning(f"Failed to post: {e}")
                    except (OSError, ValueError):
                        pass
                if accum:
                    text = _clean_tui_text(accum.decode("utf-8", errors="replace"))
                    if text:
                        try:
                            self._post_output_message(text)
                        except Exception:
                            pass
            except Exception as e:
                logger.error(f"Output reader error: {e}")

    # ------------------------------------------------------------------
    # Input poller — polls GetMessages API, writes new ones to subprocess stdin
    # ------------------------------------------------------------------

    def _input_poller(self):
        """Polls GetMessageHistory for user messages (ai-chat-prompt*) and forwards them to subprocess stdin."""
        while self._running:
            try:
                if self._conversation_id:
                    messages = self._fetch_conversation_messages()
                    for msg in messages:
                        msg_id = msg.get("id")
                        if msg_id in self._seen_input_ids:
                            continue
                        msg_type = msg.get("type") or ""
                        # Only forward user input messages — not wrap's own output
                        if not msg_type.startswith("ai-chat-prompt"):
                            continue
                        self._seen_input_ids.add(msg_id)
                        # Update chain so tool output is posted as reply to user's message
                        self._last_message_id = msg_id
                        # Reset output fingerprint so the response to this input
                        # is always posted even if it shares words with previous output
                        self._last_posted_fp = frozenset()
                        content = self._extract_input_text(msg)
                        if content:
                            logger.info(f"Received remote input: {content[:80]}")
                            from rich.console import Console
                            Console().print(f"[dim]  ← Remote input:[/dim] [cyan]{content}[/cyan]")
                            try:
                                self._write_to_process(content)
                            except (BrokenPipeError, OSError) as e:
                                logger.warning(f"Subprocess stdin closed: {e}")
                                self._running = False
                                break
            except Exception as e:
                logger.warning(f"Input poller error: {e}")
            time.sleep(self.poll_interval)

    def _fetch_conversation_messages(self):
        """Fetch the full conversation thread via GetMessageHistory."""
        url = f"{self.base_url}app/GetMessageHistory"
        headers = {
            "Authorization": f"Bearer {self.token}",
        }
        resp = requests.get(url, params={"messageId": self._conversation_id},
                            headers=headers, verify=self.verify_https, timeout=10)
        resp.raise_for_status()
        return resp.json() if resp.text else []

    def _extract_input_text(self, message):
        """Strip tags and @mention from a message to get the bare input text."""
        content = message.get("content") or ""
        # Remove @mention at start
        content = re.sub(r"^@\S+\s*", "", content)
        # Remove #tags
        content = re.sub(r"#\S+", "", content)
        # Strip whitespace and Windows carriage returns
        return content.strip().replace("\r", "")

    # ------------------------------------------------------------------
    # Auto-response rules
    # ------------------------------------------------------------------

    def _write_to_process(self, text: str):
        """Write a line of text to the subprocess stdin (PTY or pipe)."""
        if _HAS_PTY and self._master_fd is not None:
            # TUI apps run in raw mode: they expect \r (carriage return) as the
            # Enter/submit key — NOT \n.  Sending \n is silently ignored by most
            # TUI input handlers (readline, crossterm, ratatui, etc.).
            data = (text + "\r").encode("utf-8")
            _dbg(f"Writing to PTY (\\r): {data!r}")
            os.write(self._master_fd, data)
        else:
            data = (text + "\n").encode("utf-8")
            _dbg(f"Writing to pipe (\\n): {data!r}")
            self._process.stdin.buffer.write(data)
            self._process.stdin.buffer.flush()

    def _maybe_auto_respond(self, output_text):
        """Check output against auto-response rules and send reply if matched."""
        for rule in self.config.get("auto_responses", []):
            pattern = rule.get("pattern", "")
            reply = rule.get("reply", "")
            if pattern and reply and re.search(pattern, output_text, re.IGNORECASE):
                logger.info(f"Auto-responding to pattern '{pattern}' with '{reply}'")
                from rich.console import Console
                Console().print(f"[dim]  ↩ Auto-response:[/dim] [yellow]{reply}[/yellow]")
                try:
                    self._write_to_process(reply)
                except (BrokenPipeError, OSError):
                    pass
                break

    # ------------------------------------------------------------------
    # Codicent API helpers
    # ------------------------------------------------------------------

    def _post_output_message(self, text):
        """Post tool output as a bot message, chained into the conversation."""
        content = f"@{self.project}\n{text}"
        self._post_raw(content, msg_type="ai-chat-answer2")

    def _post_session_message(self, text):
        """Post a session lifecycle event."""
        content = f"@{self.project}\n{text}"
        # The very first post uses type "wrap-session" so the engine can detect and skip LLM.
        # Subsequent session messages (e.g. close) reuse ai-chat-answer2 to stay in the conversation.
        msg_type = "wrap-session" if self._conversation_id is None else "ai-chat-answer2"
        self._post_raw(content, msg_type=msg_type)

    def _post_raw(self, content, msg_type="ai-chat-answer2") -> str:
        """POST a message to AddChatMessage, chain it via parentId, and return the new message id."""
        url = f"{self.base_url}app/AddChatMessage"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        payload: dict = {"content": content, "type": msg_type}
        if self._last_message_id:
            payload["parentId"] = self._last_message_id
        resp = requests.post(url, json=payload, headers=headers,
                             verify=self.verify_https, timeout=15)
        resp.raise_for_status()
        new_id = resp.json().get("id") or resp.json().get("Id")
        if new_id:
            self._last_message_id = new_id
            if self._conversation_id is None:
                self._conversation_id = new_id
        return new_id or ""


# ---------------------------------------------------------------------------
# Entry point called from app.py
# ---------------------------------------------------------------------------

def run_wrap_command(args, token, base_url, project, verify_https=True):
    """
    Parse wrap sub-command args and run the session.

    args: sys.argv after "wrap" has been consumed, e.g.:
        ["claude", "--model", "claude-opus-4-5"]
        ["--label", "My session", "opencode"]
        ["--binary", "/usr/local/bin/claude", "claude"]
        ["--poll-interval", "5", "codex"]
    """
    from rich.console import Console
    console = Console()

    # Parse wrap-specific flags
    label = None
    explicit_binary = None
    poll_interval = None
    remaining = list(args)

    i = 0
    while i < len(remaining):
        arg = remaining[i]
        if arg in ("--label",) and i + 1 < len(remaining):
            label = remaining[i + 1]
            remaining = remaining[:i] + remaining[i + 2:]
            continue
        if arg in ("--binary",) and i + 1 < len(remaining):
            explicit_binary = remaining[i + 1]
            remaining = remaining[:i] + remaining[i + 2:]
            continue
        if arg in ("--poll-interval",) and i + 1 < len(remaining):
            try:
                poll_interval = float(remaining[i + 1])
            except ValueError:
                console.print(f"[red]❌ --poll-interval must be a number[/red]")
                return 1
            remaining = remaining[:i] + remaining[i + 2:]
            continue
        i += 1

    if not remaining:
        console.print("[red]❌ Usage: codicent wrap <tool> [tool-args...][/red]")
        console.print("[dim]Examples:[/dim]")
        console.print("[dim]  codicent wrap claude[/dim]")
        console.print("[dim]  codicent wrap claude --model claude-opus-4-5[/dim]")
        console.print("[dim]  codicent wrap opencode[/dim]")
        console.print("[dim]  codicent wrap --label 'Refactor session' codex[/dim]")
        return 1

    tool_name = remaining[0]
    tool_args = remaining[1:]

    session = WrapSession(
        tool_name=tool_name,
        tool_args=tool_args,
        token=token,
        base_url=base_url,
        project=project,
        label=label,
        explicit_binary=explicit_binary,
        poll_interval=poll_interval,
        verify_https=verify_https,
    )

    return session.run()
