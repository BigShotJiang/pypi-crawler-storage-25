import logging
import sys
from typing import Optional

STATUS_LOGGER_NAME = "verbatim.status"


def get_status_logger() -> logging.Logger:
    return logging.getLogger(STATUS_LOGGER_NAME)


def status_enabled() -> bool:
    logger = get_status_logger()
    if not logger.handlers and not logger.propagate:
        return False
    return logger.isEnabledFor(logging.DEBUG)


def configure_status_logger(*, verbose: int, fmt: str, datefmt: Optional[str], file_handler: Optional[logging.Handler] = None) -> None:
    logger = get_status_logger()
    logger.handlers.clear()
    logger.propagate = False

    if verbose <= 0:
        logger.setLevel(logging.CRITICAL + 1)
        return

    logger.setLevel(logging.DEBUG if verbose >= 2 else logging.INFO)
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(logging.DEBUG if verbose >= 2 else logging.INFO)
    handler.setFormatter(logging.Formatter(fmt=fmt, datefmt=datefmt))
    logger.addHandler(handler)
    if file_handler is not None:
        logger.addHandler(file_handler)
