# -*- encoding: utf-8 -*-
"""
owebui enhanced API
--------------------------------------

"""
import os
import json
import requests
import magic

class OwebuiAPI:

    def __init__(self, apikey, url_base='http://127.0.0.1:8080',
            connect_timeout=120, read_timeout=600):
        self.apikey = apikey
        self.url_base = url_base
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.session = None
        self.cache_uploaded = {}
        self.cache_failed = {}
        self.cache_sync = None

    @property
    def headers(self):
        return {
            'Authorization': f'Bearer {self.apikey}',
            'Accept': 'application/json'
        }

    def app_version(self):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/_app/version.json'

        response = self.session.get(
            url,
            headers=self.headers,
            timeout=(self.connect_timeout, self.read_timeout)
        )
        return response.json()

    def api_list_files(self, content=True):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/files/'
        params = [('content', content)]

        response = self.session.get(
            url,
            headers=self.headers,
            params=params,
            timeout=(self.connect_timeout, self.read_timeout)
        )
        return response.json()

    def api_delete_files(self):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/files/all'

        response = self.session.delete(
            url,
            headers=self.headers,
            timeout=(self.connect_timeout, self.read_timeout)
        )
        return response.json()

    def api_delete_file(self, fileid):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/files/{fileid}'

        response = self.session.delete(
            url,
            headers=self.headers,
            timeout=(self.connect_timeout, self.read_timeout)
        )
        return response.json()

    def api_upload_file(self, fileobj=None, filename=None, metadata=None):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/files/'

        need_close = False
        if fileobj is None:
            fileobj = os.open(filename, 'rb', mode=0o444)
            need_close = True
        fileobj.seek(0)
        mime_type = magic.from_buffer(fileobj.read(2048), mime=True)
        if mime_type is None:
            mime_type = 'application/octet-stream'

        if metadata is None:
            data = {}
        else:
            data = { "metadata": json.dumps(metadata)}

        fileobj.seek(0)
        response = self.session.post(
            url,
            headers=self.headers,
            files={'file': (filename, fileobj, mime_type)},
            data=data,
            timeout=(self.connect_timeout, self.read_timeout)
        )
        if need_close is True:
            fileobj.close()
        return response.json()

    def api_get_file(self, fileid):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/files/{fileid}'

        response = self.session.get(
            url,
            headers=self.headers,
            timeout=(self.connect_timeout, self.read_timeout)
        )
        return response.json()

    def api_status_file(self, fileid):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/files/{fileid}/process/status'

        response = self.session.get(
            url,
            headers=self.headers,
            timeout=(self.connect_timeout, self.read_timeout)
        )
        return response.json()

    def api_wait_file(self, fileid):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/files/{fileid}/process/status?stream=true'
        with self.session.get(url, headers=self.headers, stream=True) as response:
            for line in response.iter_lines():
                if line:
                    line = line.decode('utf-8')
                    if line.startswith('data: '):
                        data = json.loads(line[6:])
                        status = data.get('status')

                        if status == 'completed':
                            return True, data
                        elif status == 'failed':
                            return False, data

        raise Exception("Stream ended unexpectedly")

    def api_know_add_file(self, fileid, knowledgeid):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/knowledge/{knowledgeid}/file/add'
        payload = {'file_id': fileid}
        response = self.session.post(url, headers=self.headers, json=payload)
        return response.json()

    def api_know_remove_file(self, fileid, knowledgeid, delete_file=False):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/knowledge/{knowledgeid}/file/remove'
        payload = {'file_id': fileid, 'delete_file': delete_file}
        response = self.session.post(url, headers=self.headers, json=payload)
        return response.json()

    def api_know_update_file(self, fileid, knowledgeid):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/knowledge/{knowledgeid}/file/update'
        payload = {'file_id': fileid}
        response = self.session.post(url, headers=self.headers, json=payload)
        return response.json()

    def api_know_list_files(self, knowledgeid, content=True):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/knowledge/{knowledgeid}/files'
        response = self.session.get(url, headers=self.headers)
        rep = response.json()
        if content is True:
            return rep
        for r in rep['items']:
            del r['data']['content']
        return rep

    def api_know_create(self, payload):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/knowledge/create'
        response = self.session.post(url, headers=self.headers, json=payload)
        return response.json()

    def api_model_create(self, payload):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/models/create'
        response = self.session.post(url, headers=self.headers, json=payload)
        return response.json()

    def api_ollama_satus(self):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/ollama/'
        response = self.session.get(url, headers=self.headers)
        return response.json()

    def upload_file(self, fileobj=None, filename=None, metadata=None,
            knowledgeid=None, wait=False, retries=3, retry_wait=1):
        current = retries
        # ~ while current > 0:
        try:
            ret = self.api_upload_file(fileobj=fileobj, filename=filename, metadata=metadata)
        except Exception:
            import traceback
            self.cache_failed[filename] = {
                "detail" : traceback.format_exc().splitlines(),
                "filename" : filename,
            }
        # ~ print(ret)
        if knowledgeid is None and wait is False:
            return True, ret
        fileid = ret['id']
        self.cache_uploaded[fileid] = ret
        retw = self.api_wait_file(fileid)
        if retw[0] is False:
            self.cache_failed[fileid] = {
                "error" : retw[1],
                "file" : self.api_get_file(fileid),
            }
            return retw
        if knowledgeid is not None:
            self.api_know_add_file(fileid, knowledgeid)
        ret = self.api_get_file(fileid)
        return True, ret

    def add_file_to_knowledge(self, fileid, knowledgeid):
        try:
            retw = self.api_wait_file(fileid)
        except Exception:
            import traceback
            self.cache_failed[fileid] = {
                "detail" : traceback.format_exc().splitlines(),
                "knowledgeid" : knowledgeid,
                "fileid" : fileid,
            }
        if retw[0] is False:
            self.cache_failed[fileid] = {
                "error" : retw[1],
                "file" : self.api_get_file(fileid),
            }
            return retw
        ret = self.api_know_add_file(fileid, knowledgeid)
        return True, ret

    def clean_all(self):
        return self.api_delete_files()

    def clean_orphans(self):
        for f in self.list_files(orphans=True)['items']:
            self.api_delete_file(f['id'])
        return self.list_files(orphans=True)

    def create_knowledge(self, name: str, description: str) -> dict:
        payload = {
            "name": name,
            "description": description,
            "data": {},
            "access_control": {},
        }
        return self.api_know_create(payload)

    def clean_knowledge(self, knowledgeid, delete_files=False):
        ret = self.api_know_list_files(knowledgeid)
        for f in ret['items']:
            ret = self.api_know_remove_file(f['id'], knowledgeid, delete_file=delete_files)
        return self.api_know_list_files(knowledgeid)

    def list_files(self, knowledgeid=None, orphans=False, content=True):
        if orphans is True:
            rep = self.api_list_files(content=content)
            ret = [f for f in rep['items'] if 'collection_name' not in f['meta']]
            return {'items': ret, 'total': len(ret)}
        if knowledgeid is None:
            rep = self.api_list_files(content=content)
            return {'items': rep, 'total': len(rep)}
        return self.api_know_list_files(knowledgeid, content=content)

    def search_files(self, pattern, knowledgeid=None, content=False, limit=0, skip=0):
        if self.session is None:
            self.session = requests.Session()

        url = f'{self.url_base}/api/v1/files/search'

        if limit != 0:
            params = [('filename', pattern), ('content', content), ('limit', limit), ('skip', skip)]
            response = self.session.get(
                url,
                headers=self.headers,
                params=params,
                timeout=(self.connect_timeout, self.read_timeout)
            )
            ret = response.json()
            if knowledgeid is not None:
                ret = [r for r in ret if 'collection_name' in r['meta'] and r['meta']['collection_name']==knowledgeid]
            return {"items": ret, "total": len(ret)}
        else:
            more = True
            skip = 0
            limit = 500
            ret = []
            while more is True:
                params = [('filename', pattern), ('content', content), ('limit', limit), ('skip', skip)]
                response = self.session.get(
                    url,
                    headers=self.headers,
                    params=params,
                    timeout=(self.connect_timeout, self.read_timeout)
                )
                rep = response.json()
                ret += rep
                if len(rep) == limit:
                    skip += limit
                else:
                    more = False
            if knowledgeid is not None:
                ret = [r for r in ret if 'collection_name' in r['meta'] and r['meta']['collection_name']==knowledgeid]
            return {"items": ret, "total": len(ret)}

    def create_model(self, name: str, description: str, knowledgeid: str,
            prompt: str, base_model: str, num_ctx: int = 16000) -> dict:
        payload = {
            "id": name,
            "name": name,
            "base_model_id": base_model,
            "meta": {
                "description": description,
               "knowledge": [
                    {
                        "id": knowledgeid,
                        "type": "collection",
                    }
                ],
            },
            "params": {
                "system": prompt,
                "num_ctx": num_ctx,
            },
        }
        return self.api_model_create(payload)

    def status(self) -> dict:
        ok = True
        ret = {}
        rep = self.api_ollama_satus()
        if 'status' in rep and rep['status'] is True:
            ret['ollama'] = True
        else:
            ok = False
        rep = self.app_version()
        if 'version' in rep:
            ret['app'] = True
        else:
            ok = False
        return ok, ret
