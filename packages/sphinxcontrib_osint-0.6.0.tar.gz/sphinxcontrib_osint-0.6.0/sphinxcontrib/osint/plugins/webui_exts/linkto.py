"""
title: Replace Text with Config Option
author: Your Name
version: 1.0
description: Remplace un texte spécifique dans la réponse par une valeur définie dans les options.

<span class="line-clamp-1">country__UA.txt</span></button>

"""
import re
from typing import Optional
from pydantic import BaseModel

class Filter:
    class Valves(BaseModel):
        osint_regexp: str = r">(?P<prefix>\w+)__(?P<name>\w+).txt<\/span><\/button>"
        osint_uri: str = "http://127.0.0.1:8000"

    def __init__(self):
        self.valves = self.Valves()

    async def outlet(
        self,
        body: dict,
        user: Optional[dict] = None,
    ) -> dict:

        if "choices" in body:
            motif = re.compile(self.valves.osint_regexp)
            for choice in body["choices"]:
                if "message" in choice and "content" in choice["message"]:
                    content = choice["message"]["content"]
                    found = motif.search(content)
                    if found is not None:
                        prefix = found.group('prefix')
                        name = found.group('name')
                        url = f"{self.valves.osint_uri}/{prefix}/{name}"
                        idx = found.span()[1]
                        content = content[:idx] + f'<a href="{url}" target="_blank" rel="noopener noreferrer">🔗</a>'+ content[idx:]

                    choice["message"]["content"] = content

        return body
