from __future__ import annotations

from collections.abc import Iterable


class Condition:
    __slots__ = ("k", "op", "v")

    def __init__(self, k: str, op: str, v=None):
        self.k = k
        self.op = op
        self.v = v

    def expand(self) -> list[tuple[str, str, object]]:
        if isinstance(self.v, (list | tuple)):
            return [(self.k, self.op, v) for v in self.v]
        return [(self.k, self.op, self.v)]


class Prop:
    __slots__ = ("k",)

    def __init__(self, k: str):
        self.k = k

    def __eq__(self, v):
        return Condition(self.k, "=", v)

    def __ne__(self, v):
        return Condition(self.k, "!=", v)

    def __gt__(self, v):
        return Condition(self.k, ">", v)

    def __lt__(self, v):
        return Condition(self.k, "<", v)

    def __ge__(self, v):
        return Condition(self.k, ">=", v)

    def __le__(self, v):
        return Condition(self.k, "<=", v)

    def eq(self, v):
        return Condition(self.k, "=", v)

    def gt(self, v):
        return Condition(self.k, ">", v)

    def lt(self, v):
        return Condition(self.k, "<", v)

    def gte(self, v):
        return Condition(self.k, ">=", v)

    def lte(self, v):
        return Condition(self.k, "<=", v)

    def is_(self, v):
        return self.eq(v)

    def contains(self, v):
        return Condition(self.k, "~", v)

    def not_contains(self, v):
        return Condition(self.k, "!~", v)

    def startswith(self, v):
        return Condition(self.k, "~=", v)

    def endswith(self, v):
        return Condition(self.k, "=~", v)

    def empty(self):
        return Condition(self.k, "=", None)

    def __invert__(self):
        return Condition(self.k, "=", False)


class Filter:
    def __getattr__(self, k: str) -> Prop:
        return Prop(k)


def resolve_filter_parts(conditions: Condition | Iterable[Condition]) -> str:
    if isinstance(conditions, Condition):
        conditions = [conditions]

    parts: list[str] = []

    for cond in conditions:
        for k, op, v in cond.expand():
            if v is None:
                parts.append(f"{k}{op}")
            else:
                parts.append(f"{k}{op}{str(v).lower()}")

    return ";".join(parts)
