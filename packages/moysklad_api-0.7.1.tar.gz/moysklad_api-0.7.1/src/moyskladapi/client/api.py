from collections.abc import Sequence

from ..client.session import BaseSession
from ..methods import (
    CreateBonusprogram,
    CreateBonustransaction,
    CreateBundle,
    CreateCashin,
    CreateCashout,
    CreateCommissionreportin,
    CreateCommissionreportout,
    CreateConsignment,
    CreateContract,
    CreateCounterparty,
    CreateCounterpartyadjustment,
    CreateCountry,
    CreateCustomentity,
    CreateCustomerorder,
    CreateDemand,
    CreateDiscount,
    CreateEmissionorder,
    CreateEmployee,
    CreateEnter,
    CreateExpenseitem,
    CreateFacturein,
    CreateFactureout,
    CreateGroup,
    CreateInternalorder,
    CreateInventory,
    CreateInvoicein,
    CreateInvoiceout,
    CreateLoss,
    CreateMove,
    CreateOrganization,
    CreatePaymentin,
    CreatePaymentout,
    CreatePricelist,
    CreateProcessing,
    CreateProcessingorder,
    CreateProcessingplan,
    CreateProcessingplanfolder,
    CreateProcessingprocess,
    CreateProcessingstage,
    CreateProduct,
    CreateProductfolder,
    CreateProductionstagecompletion,
    CreateProductiontask,
    CreateProject,
    CreatePurchaseorder,
    CreatePurchasereturn,
    CreateRetaildemand,
    CreateRetailsalesreturn,
    CreateRetailshift,
    CreateRetailstore,
    CreateRetireorder,
    CreateSaleschannel,
    CreateSalesreturn,
    CreateService,
    CreateStore,
    CreateSupply,
    CreateTask,
    CreateTaxrate,
    CreateUom,
    CreateVariant,
    CreateWebhook,
    CreateWebhookstock,
    DeleteBonusprogram,
    DeleteBonustransaction,
    DeleteBundle,
    DeleteCashin,
    DeleteCashout,
    DeleteCommissionreportin,
    DeleteCommissionreportout,
    DeleteConsignment,
    DeleteContract,
    DeleteCounterparty,
    DeleteCounterpartyadjustment,
    DeleteCountry,
    DeleteCurrency,
    DeleteCustomentity,
    DeleteCustomerorder,
    DeleteDemand,
    DeleteDiscount,
    DeleteEmployee,
    DeleteEnter,
    DeleteExpenseitem,
    DeleteFacturein,
    DeleteFactureout,
    DeleteFile,
    DeleteGroup,
    DeleteImage,
    DeleteInternalorder,
    DeleteInventory,
    DeleteInvoicein,
    DeleteInvoiceout,
    DeleteLoss,
    DeleteMove,
    DeleteNotes,
    DeleteOrganization,
    DeletePaymentin,
    DeletePaymentout,
    DeletePrepayment,
    DeletePrepaymentreturn,
    DeletePricelist,
    DeleteProcessing,
    DeleteProcessingorder,
    DeleteProcessingplan,
    DeleteProcessingplanfolder,
    DeleteProcessingprocess,
    DeleteProcessingstage,
    DeleteProduct,
    DeleteProductfolder,
    DeleteProductionstagecompletion,
    DeleteProductiontask,
    DeleteProject,
    DeletePublication,
    DeletePurchaseorder,
    DeletePurchasereturn,
    DeleteRetaildemand,
    DeleteRetaildrawercashin,
    DeleteRetaildrawercashout,
    DeleteRetailsalesreturn,
    DeleteRetailshift,
    DeleteRetailstore,
    DeleteRetireorder,
    DeleteRole,
    DeleteSaleschannel,
    DeleteSalesreturn,
    DeleteService,
    DeleteStore,
    DeleteSupply,
    DeleteTask,
    DeleteTaxrate,
    DeleteUom,
    DeleteVariant,
    DeleteWebhook,
    DeleteWebhookstock,
    GetAssortment,
    GetAssortments,
    GetAudit,
    GetBonusprogram,
    GetBonusprograms,
    GetBonustransaction,
    GetBonustransactions,
    GetBundle,
    GetBundles,
    GetCashier,
    GetCashin,
    GetCashins,
    GetCashout,
    GetCashouts,
    GetCommissionreportin,
    GetCommissionreportins,
    GetCommissionreportout,
    GetCommissionreportouts,
    GetCompanysettings,
    GetConsignment,
    GetConsignments,
    GetContentcard,
    GetContentcards,
    GetContract,
    GetContracts,
    GetCounterparties,
    GetCounterparty,
    GetCounterpartyadjustment,
    GetCounterpartyadjustments,
    GetCountries,
    GetCountry,
    GetCurrency,
    GetCustomentities,
    GetCustomentity,
    GetCustomerorder,
    GetCustomerorders,
    GetDemand,
    GetDemands,
    GetDiscount,
    GetDiscounts,
    GetEmissionorder,
    GetEmissionorders,
    GetEmployee,
    GetEmployees,
    GetEnter,
    GetEnters,
    GetExpenseitem,
    GetExpenseitems,
    GetFacturein,
    GetFactureins,
    GetFactureout,
    GetFactureouts,
    GetFiles,
    GetGroup,
    GetGroups,
    GetInternalorder,
    GetInternalorders,
    GetInventories,
    GetInventory,
    GetInvoicein,
    GetInvoiceins,
    GetInvoiceout,
    GetInvoiceouts,
    GetLoss,
    GetLosses,
    GetMove,
    GetMoves,
    GetNamedfilter,
    GetNotes,
    GetOrganization,
    GetOrganizations,
    GetPaymentin,
    GetPaymentins,
    GetPaymentout,
    GetPaymentouts,
    GetPrepayment,
    GetPrepaymentreturn,
    GetPrepaymentreturns,
    GetPrepayments,
    GetPricelist,
    GetPricelists,
    GetProcessing,
    GetProcessingorder,
    GetProcessingorders,
    GetProcessingplan,
    GetProcessingplanfolder,
    GetProcessingplanfolders,
    GetProcessingplans,
    GetProcessingprocess,
    GetProcessingprocesses,
    GetProcessings,
    GetProcessingstage,
    GetProcessingstages,
    GetProduct,
    GetProductfolder,
    GetProductfolders,
    GetProductionstagecompletion,
    GetProductionstagecompletions,
    GetProductiontask,
    GetProductiontasks,
    GetProducts,
    GetProfitByProduct,
    GetProfitByVariant,
    GetProject,
    GetProjects,
    GetPurchaseorder,
    GetPurchaseorders,
    GetPurchasereturn,
    GetPurchasereturns,
    GetRegion,
    GetRegions,
    GetRetaildemand,
    GetRetaildemands,
    GetRetaildrawercashin,
    GetRetaildrawercashout,
    GetRetailsalesreturn,
    GetRetailsalesreturns,
    GetRetailshift,
    GetRetailshifts,
    GetRetailstore,
    GetRetailstores,
    GetRetireorder,
    GetRetireorders,
    GetRole,
    GetSaleplatform,
    GetSaleplatforms,
    GetSaleschannel,
    GetSaleschannels,
    GetSalesreturn,
    GetSalesreturns,
    GetService,
    GetServices,
    GetStock,
    GetStockCurrent,
    GetStore,
    GetStores,
    GetSupplies,
    GetSupply,
    GetTask,
    GetTasks,
    GetTaxrate,
    GetTaxrates,
    GetThing,
    GetThings,
    GetUom,
    GetUoms,
    GetUsersettings,
    GetVariant,
    GetVariants,
    GetWebhook,
    GetWebhooks,
    GetWebhookstock,
    GetWebhookstocks,
    UpdateBonusprogram,
    UpdateBonustransaction,
    UpdateBonustransactions,
    UpdateBundle,
    UpdateBundles,
    UpdateCashin,
    UpdateCashins,
    UpdateCashout,
    UpdateCashouts,
    UpdateCommissionreportin,
    UpdateCommissionreportins,
    UpdateCommissionreportouts,
    UpdateConsignment,
    UpdateConsignments,
    UpdateContract,
    UpdateContracts,
    UpdateCounterparties,
    UpdateCounterparty,
    UpdateCounterpartyadjustment,
    UpdateCounterpartyadjustments,
    UpdateCountries,
    UpdateCountry,
    UpdateCurrencies,
    UpdateCurrency,
    UpdateCustomentity,
    UpdateCustomerorder,
    UpdateCustomerorders,
    UpdateDemand,
    UpdateDemands,
    UpdateDiscount,
    UpdateEmissionorder,
    UpdateEmissionorders,
    UpdateEmployee,
    UpdateEnter,
    UpdateEnters,
    UpdateExpenseitem,
    UpdateExpenseitems,
    UpdateFacturein,
    UpdateFactureins,
    UpdateFactureout,
    UpdateFactureouts,
    UpdateGroup,
    UpdateInternalorder,
    UpdateInternalorders,
    UpdateInventories,
    UpdateInventory,
    UpdateInvoicein,
    UpdateInvoiceins,
    UpdateInvoiceout,
    UpdateInvoiceouts,
    UpdateLoss,
    UpdateLosses,
    UpdateMove,
    UpdateMoves,
    UpdateOrganization,
    UpdateOrganizations,
    UpdatePaymentin,
    UpdatePaymentins,
    UpdatePaymentout,
    UpdatePaymentouts,
    UpdatePricelist,
    UpdatePricelists,
    UpdateProcessing,
    UpdateProcessingorder,
    UpdateProcessingorders,
    UpdateProcessingplan,
    UpdateProcessingplanfolder,
    UpdateProcessingplanfolders,
    UpdateProcessingplans,
    UpdateProcessingprocess,
    UpdateProcessingprocesses,
    UpdateProcessings,
    UpdateProcessingstage,
    UpdateProcessingstages,
    UpdateProduct,
    UpdateProductfolder,
    UpdateProductfolders,
    UpdateProductionstagecompletion,
    UpdateProductionstagecompletions,
    UpdateProductiontask,
    UpdateProductiontasks,
    UpdateProducts,
    UpdateProject,
    UpdateProjects,
    UpdatePurchaseorder,
    UpdatePurchaseorders,
    UpdatePurchasereturn,
    UpdatePurchasereturns,
    UpdateRetaildemand,
    UpdateRetaildemands,
    UpdateRetaildrawercashins,
    UpdateRetaildrawercashouts,
    UpdateRetailsalesreturn,
    UpdateRetailsalesreturns,
    UpdateRetailshift,
    UpdateRetailstore,
    UpdateRetailstores,
    UpdateRetireorder,
    UpdateRetireorders,
    UpdateRole,
    UpdateSaleschannel,
    UpdateSaleschannels,
    UpdateSalesreturn,
    UpdateSalesreturns,
    UpdateService,
    UpdateServices,
    UpdateStates,
    UpdateStore,
    UpdateStores,
    UpdateSupplies,
    UpdateSupply,
    UpdateTask,
    UpdateTasks,
    UpdateTaxrate,
    UpdateTaxrates,
    UpdateTrackingcodeses,
    UpdateUom,
    UpdateUoms,
    UpdateVariant,
    UpdateVariants,
    UpdateWebhook,
    UpdateWebhooks,
    UpdateWebhookstock,
    UpdateWebhookstocks,
    UploadFiles,
)
from ..methods.base import MSMethod
from ..types import (
    Assortment,
    Audit,
    Bonusprogram,
    Bonustransaction,
    Bundle,
    Cashier,
    Cashin,
    Cashout,
    Commissionreportin,
    Commissionreportout,
    Companysettings,
    Consignment,
    Contentcard,
    Contract,
    Counterparty,
    Counterpartyadjustment,
    Country,
    Currency,
    Customentity,
    Customerorder,
    Demand,
    Discount,
    Emissionorder,
    Employee,
    Enter,
    Expenseitem,
    Facturein,
    Factureout,
    File,
    FileInput,
    Group,
    Internalorder,
    Inventory,
    Invoicein,
    Invoiceout,
    Loss,
    Move,
    Namedfilter,
    Notes,
    Organization,
    Paymentin,
    Paymentout,
    Prepayment,
    Prepaymentreturn,
    Pricelist,
    Processing,
    Processingorder,
    Processingplan,
    Processingplanfolder,
    Processingprocess,
    Processingstage,
    Product,
    Productfolder,
    Productionstagecompletion,
    Productiontask,
    Profit,
    Project,
    Publication,  # noqa: F401
    Purchaseorder,
    Purchasereturn,
    Region,
    Retaildemand,
    Retaildrawercashin,
    Retaildrawercashout,
    Retailsalesreturn,
    Retailshift,
    Retailstore,
    Retireorder,
    Role,
    Saleplatform,
    Saleschannel,
    Salesreturn,
    Service,
    State,
    Stock,
    StockCurrent,
    Store,
    Supply,
    Task,
    Taxrate,
    Thing,
    Trackingcodes,
    Uom,
    Usersettings,
    Variant,
    Webhook,
    Webhookstock,
)
from ..types.meta import MetaArray
from .filters import Condition


class MoyskladAPI:
    def __init__(
        self,
        token: str,
        session: BaseSession | None = None,
        **kwargs,
    ) -> None:
        if session is not None:
            self.session = session
        else:
            self.session = BaseSession(**kwargs)
        self.session.headers.set_token(token)

    async def __call__[T](self, method: MSMethod[T]) -> T:
        return await method.emit(self)

    async def close(self) -> None:
        await self.session.close()

    async def __aenter__(self) -> "MoyskladAPI":
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()

    async def create_bonusprogram(self, bonusprogram: Bonusprogram) -> Bonusprogram:
        """
        Кодом сущности для Бонусных программ в составе JSON API является ключевое слово
        bonusprogram. Перед работой со скидками настоятельно рекомендуем вам прочитать
        вот эту статью на портале поддержки МоегоСклада.

        :param bonusprogram: Объект Bonusprogram для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-program
        """
        call = CreateBonusprogram(data=bonusprogram)
        return await self(call)

    async def create_bonustransaction(
        self, bonustransaction: Bonustransaction
    ) -> Bonustransaction:
        """
        Средствами JSON API можно создавать и обновлять сведения о Бонусных операциях,
        запрашивать списки Бонусных операций и сведения по отдельным Бонусым операциям.
        Кодом сущности для Бонусной операции в составе JSON API является ключевое слово
        bonustransaction.

        :param bonustransaction: Объект Bonustransaction для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-operation
        """
        call = CreateBonustransaction(data=bonustransaction)
        return await self(call)

    async def create_bundle(self, bundle: Bundle) -> Bundle:
        """
        Средствами JSON API можно создавать и обновлять сведения о Комплектах,
        запрашивать списки Комплектов и сведения по отдельным Комплектам. Кодом сущности
        для Комплекта в составе JSON API является ключевое слово bundle.

        :param bundle: Объект Bundle для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bundle
        """
        call = CreateBundle(data=bundle)
        return await self(call)

    async def create_cashin(self, cashin: Cashin) -> Cashin:
        """
        Средствами JSON API можно создавать и обновлять сведения о Приходном ордере,
        запрашивать списки Приходных ордеров и сведения по отдельным Приходным
        ордерам.Кодом сущности для Приходного ордера в составе JSON API является
        ключевое слово cashin.

        :param cashin: Объект Cashin для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashin
        """
        call = CreateCashin(data=cashin)
        return await self(call)

    async def create_cashout(self, cashout: Cashout) -> Cashout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Расходном ордере,
        запрашивать списки Расходных ордеров  и сведения по отдельным Расходных ордеров.
        Кодом сущности для Расходного ордера  в составе JSON API является ключевое слово
        cashout.

        :param cashout: Объект Cashout для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashout
        """
        call = CreateCashout(data=cashout)
        return await self(call)

    async def create_commissionreportin(
        self, commissionreportin: Commissionreportin
    ) -> Commissionreportin:
        """
        Средствами JSON API можно создавать и обновлять сведения о Полученных отчетах
        комиссионера, запрашивать списки Полученных отчетов комиссионера и сведения по
        отдельным Полученным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Полученного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportin. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportin: Объект Commissionreportin для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportin
        """
        call = CreateCommissionreportin(data=commissionreportin)
        return await self(call)

    async def create_commissionreportout(
        self, commissionreportout: Commissionreportout
    ) -> Commissionreportout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выданных отчетах
        комиссионера, запрашивать списки Выданных отчетов комиссионера и сведения по
        отдельным Выданным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Выданного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportout. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportout: Объект Commissionreportout для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportout
        """
        call = CreateCommissionreportout(data=commissionreportout)
        return await self(call)

    async def create_consignment(self, consignment: Consignment) -> Consignment:
        """
        Кодом сущности для Партии в составе JSON API является ключевое слово
        consignment. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param consignment: Объект Consignment для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/consignment
        """
        call = CreateConsignment(data=consignment)
        return await self(call)

    async def create_contract(self, contract: Contract) -> Contract:
        """
        Средствами JSON API можно создавать и обновлять сведения о Договорах,
        запрашивать списки Договоров и сведения по отдельным Договорам. Кодом сущности
        для Договора в составе JSON API является ключевое слово contract. Больше о
        Договорах и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
        не префиксный, без токенизации и идет только по одному полю одновременно. Ищет
        такие строки, в которые входит значение строки поиска.

        :param contract: Объект Contract для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contract
        """
        call = CreateContract(data=contract)
        return await self(call)

    async def create_counterparty(self, counterparty: Counterparty) -> Counterparty:
        """
        Средствами JSON API можно создавать и обновлять сведения о Контрагентах,
        запрашивать списки Контрагентов и сведения по отдельным Контрагентам. Счетами
        Контрагента и его контактными лицами можно управлять как в составе отдельного
        Контрагента, так и отдельно - с помощью специальных ресурсов для управления
        счетами и контактными лицами Контрагента. Кодом сущности для Контрагента в
        составе JSON API является ключевое слово counterparty. Больше о Контрагентах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке. По данной сущности можно осуществлять контекстный поиск с
        помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный и без
        токенизации. Ищет такие строки, в которые входит значение строки поиска.

        :param counterparty: Объект Counterparty для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty
        """
        call = CreateCounterparty(data=counterparty)
        return await self(call)

    async def create_counterpartyadjustment(
        self, counterpartyadjustment: Counterpartyadjustment
    ) -> Counterpartyadjustment:
        """
        Средствами JSON API можно создавать и обновлять сведения о Корректировках
        взаиморасчетов, запрашивать списки Корректировок взаиморасчетов и сведения по
        отдельным Корректировкам взаиморасчетов. Кодом сущности для Корректировки
        взаиморасчетов в составе JSON API является ключевое слово
        counterpartyadjustment. Больше о Корректировках взаиморасчетов и работе с ними в
        основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param counterpartyadjustment: Объект Counterpartyadjustment для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/counterpartyadjustment
        """
        call = CreateCounterpartyadjustment(data=counterpartyadjustment)
        return await self(call)

    async def create_country(self, country: Country) -> Country:
        """
        Средствами JSON API можно создавать и обновлять сведения о Странах, запрашивать
        списки Стран и сведения по отдельным Странам. Кодом сущности для Страны в
        составе JSON API является ключевое слово country. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param country: Объект Country для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/country
        """
        call = CreateCountry(data=country)
        return await self(call)

    async def create_customentity(self, customentity: Customentity) -> Customentity:
        """
        Кодом сущности для Пользовательских справочников в составе JSON API является
        ключевое слово customentity.

        :param customentity: Объект Customentity для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity
        """
        call = CreateCustomentity(data=customentity)
        return await self(call)

    async def create_customerorder(self, customerorder: Customerorder) -> Customerorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах покупателя,
        запрашивать списки Заказов и сведения по отдельным Заказам покупателей.
        Позициями Заказов можно управлять как в составе отдельного Заказа покупателя,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа покупателя в составе JSON API является ключевое слово
        customerorder. Больше о Заказах покупателей и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. Также в
        Заказе покупателя поддерживается протокол оповещения об изменениях виджетов
        вендоров - change-handler. Подробнее см. в документации для вендоров о виджетах.

        :param customerorder: Объект Customerorder для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/customerOrder
        """
        call = CreateCustomerorder(data=customerorder)
        return await self(call)

    async def create_demand(self, demand: Demand) -> Demand:
        """
        Средствами JSON API можно создавать и обновлять сведения об Отгрузках,
        запрашивать списки Отгрузок и сведения по отдельным Отгрузкам. Позициями
        Отгрузок можно управлять как в составе отдельной Отгрузки, так и отдельно - с
        помощью специальных ресурсов для управления позициями Отгрузки. Кодом сущности
        для Отгрузки в составе JSON API является ключевое слово demand. Больше об
        Отгрузках и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param demand: Объект Demand для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand
        """
        call = CreateDemand(data=demand)
        return await self(call)

    async def create_discount(self, discount: Discount) -> Discount:
        """
        Кодом сущности для Скидок в составе JSON API является ключевое слово discount.
        Операции создания, изменения и удаления не поддерживаются. Перед работой со
        скидками настоятельно рекомендуем вам прочитать вот эту статью на портале
        поддержки МоегоСклада.

        :param discount: Объект Discount для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/discount
        """
        call = CreateDiscount(data=discount)
        return await self(call)

    async def create_emissionorder(self, emissionorder: Emissionorder) -> Emissionorder:
        """
        Для создания/изменения Заказов кодов маркировки необходима тарифная опция
        Маркировка для аккаунтов из RU региона и расширение Честный знак для остальных
        регионов.

        :param emissionorder: Объект Emissionorder для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder
        """
        call = CreateEmissionorder(data=emissionorder)
        return await self(call)

    async def create_employee(self, employee: Employee) -> Employee:
        """
        Средствами JSON API можно запрашивать списки Сотрудников и сведения по отдельным
        Сотрудникам. Кодом сущности для Сотрудника в составе JSON API является ключевое
        слово employee. Больше о Сотрудниках и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке.

        :param employee: Объект Employee для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/employee
        """
        call = CreateEmployee(data=employee)
        return await self(call)

    async def create_enter(self, enter: Enter) -> Enter:
        """
        Средствами JSON API можно создавать и обновлять сведения об Оприходованиях,
        запрашивать списки Оприходований и сведения по отдельным Оприходованиям.
        Позициями Оприходований можно управлять как в составе отдельного Оприходования,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Оприходования. Кодом сущности для Оприходования в составе JSON API является
        ключевое слово enter. Больше об Оприходованиях можно прочитать этой ссылке.

        :param enter: Объект Enter для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/enter
        """
        call = CreateEnter(data=enter)
        return await self(call)

    async def create_expenseitem(self, expenseitem: Expenseitem) -> Expenseitem:
        """
        Средствами JSON API можно запрашивать списки Статей расходов и сведения по
        отдельным Статьям расходов. Кодом сущности для Статей расходов в составе JSON
        API является ключевое слово expenseitem. Больше о Статьях расходов и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param expenseitem: Объект Expenseitem для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/expenseitem
        """
        call = CreateExpenseitem(data=expenseitem)
        return await self(call)

    async def create_facturein(self, facturein: Facturein) -> Facturein:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры полученные,
        запрашивать списки Счетов-фактур полученных, сведения по отдельным Счетам-
        фактурам и удалять Счета-фактуры. Счет-фактура может быть создана только на
        основании приемки или исходящего платежа, без документа-основания счет-фактуру
        создать нельзя.  Кодом сущности для Счета-фактуры полученного в составе JSON API
        является ключевое слово facturein.

        :param facturein: Объект Facturein для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/facturein
        """
        call = CreateFacturein(data=facturein)
        return await self(call)

    async def create_factureout(self, factureout: Factureout) -> Factureout:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры выданные,
        запрашивать списки Счетов-фактур выданных, сведения по отдельным Счетам-фактурам
        и удалять Счета-фактуры. Счет-фактура может быть создана только на основании
        отгрузки, возврата поставщику или входящего платежа, без документа-основания
        счет-фактуру создать нельзя. Кодом сущности для Счета-фактуры выданного в
        составе JSON API является ключевое слово factureout.

        :param factureout: Объект Factureout для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/factureout
        """
        call = CreateFactureout(data=factureout)
        return await self(call)

    async def create_group(self, group: Group) -> Group:
        """
        Средствами JSON API можно запрашивать и изменять списки Отделов и сведения по
        отдельным Отделам. Кодом сущности для Отдела в составе JSON API является
        ключевое слово group. Больше об Отделах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по  этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param group: Объект Group для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group
        """
        call = CreateGroup(data=group)
        return await self(call)

    async def create_internalorder(self, internalorder: Internalorder) -> Internalorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внутренних заказах,
        запрашивать списки Внутренних заказов и сведения по отдельным Внутренним
        заказам. Позициями Внутренних заказов можно управлять как в составе отдельного
        заказа, так и с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Внутреннего заказа в составе JSON API является ключевое слово
        internalorder.

        :param internalorder: Объект Internalorder для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/internalOrder
        """
        call = CreateInternalorder(data=internalorder)
        return await self(call)

    async def create_inventory(self, inventory: Inventory) -> Inventory:
        """
        Средствами JSON API можно создавать и обновлять сведения о Инвентаризации,
        запрашивать списки Инвентаризаций и сведения по отдельным Инвентаризациям.
        Позициями Инвентаризации можно управлять как в составе отдельной Инвентаризации,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Инвентаризации. Кодом сущности для Инвентаризации в составе JSON API является
        ключевое слово inventory. Больше о Инвентаризациях можно прочитать этой ссылке.

        :param inventory: Объект Inventory для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/inventory
        """
        call = CreateInventory(data=inventory)
        return await self(call)

    async def create_invoicein(self, invoicein: Invoicein) -> Invoicein:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете поставщика,
        запрашивать списки Счетов и сведения по отдельным Счетам Поставщиков. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета поставщика в составе JSON API является ключевое слово invoicein. Больше о
        Счетах Поставщиков и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoicein: Объект Invoicein для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-in
        """
        call = CreateInvoicein(data=invoicein)
        return await self(call)

    async def create_invoiceout(self, invoiceout: Invoiceout) -> Invoiceout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете покупателю,
        запрашивать списки Счетов и сведения по отдельным Счетам Покупателям. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета покупателю в составе JSON API является ключевое слово invoiceout. Больше о
        Счетах Покупателям и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoiceout: Объект Invoiceout для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-out
        """
        call = CreateInvoiceout(data=invoiceout)
        return await self(call)

    async def create_loss(self, loss: Loss) -> Loss:
        """
        Средствами JSON API можно создавать и обновлять сведения о Списаниях,
        запрашивать списки Списаний и сведения по отдельным Списаниям. Позициями
        Списаний можно управлять как в составе отдельного Списания, так и отдельно - с
        помощью специальных ресурсов для управления позициями Списания. Кодом сущности
        для Списания в составе JSON API является ключевое слово loss. Больше о Списаниях
        можно прочитать этой ссылке.

        :param loss: Объект Loss для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/loss
        """
        call = CreateLoss(data=loss)
        return await self(call)

    async def create_move(self, move: Move) -> Move:
        """
        Средствами JSON API можно создавать и обновлять сведения о Перемещениях,
        запрашивать списки Перемещений и сведения по отдельным Перемещениям. Позициями
        Перемещений можно управлять как в составе отдельного Перемещения, так и отдельно
        - с помощью специальных ресурсов для управления позициями Перемещения. Кодом
        сущности для Перемещения в составе JSON API является ключевое слово move.

        :param move: Объект Move для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/move
        """
        call = CreateMove(data=move)
        return await self(call)

    async def create_organization(self, organization: Organization) -> Organization:
        """
        Средствами JSON API можно создавать и обновлять сведения о юрлицах, запрашивать
        списки юрлиц и сведения по отдельным юрлицам. С помощью специального ресурса
        можно управлять счетами отдельного юрлица. Кодом сущности для юрлица в составе
        JSON API является ключевое слово organization. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный и без токенизации. Ищет такие строки, в которые
        входит значение строки поиска

        :param organization: Объект Organization для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/organization
        """
        call = CreateOrganization(data=organization)
        return await self(call)

    async def create_paymentin(self, paymentin: Paymentin) -> Paymentin:
        """
        Средствами JSON API можно создавать и обновлять сведения о платеже , запрашивать
        списки Входящих платежей и сведения по отдельным Входящим платежам. Кодом
        сущности для Входящего платежа в составе JSON API является ключевое слово
        paymentin. Больше о платежах  и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке.

        :param paymentin: Объект Paymentin для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-in
        """
        call = CreatePaymentin(data=paymentin)
        return await self(call)

    async def create_paymentout(self, paymentout: Paymentout) -> Paymentout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Исходящем платеже,
        запрашивать списки Исходящих платежей  и сведения по отдельным Исходящим
        платежам. Кодом сущности для Исходящего платежа  в составе JSON API является
        ключевое слово paymentout. Больше о платежа х и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param paymentout: Объект Paymentout для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-out
        """
        call = CreatePaymentout(data=paymentout)
        return await self(call)

    async def create_pricelist(self, pricelist: Pricelist) -> Pricelist:
        """
        Средствами JSON API можно создавать и обновлять сведения о Прайс-листах,
        запрашивать списки Прайс-листов и сведения по отдельным Прайс-листам. Позициями
        Прайс-листов можно управлять как в составе отдельного Прайс-листа, так и
        отдельно - с помощью специальных ресурсов для управления позициями Прайс-листа.
        Кодом сущности для Прайс-листа в составе JSON API является ключевое слово
        pricelist. Больше о Прайс-листах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по  этой ссылке.

        :param pricelist: Объект Pricelist для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/pricelist
        """
        call = CreatePricelist(data=pricelist)
        return await self(call)

    async def create_processing(self, processing: Processing) -> Processing:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техоперациях,
        запрашивать списки Техопераций и сведения по отдельным Техоперациям. Позициями
        Техопераций можно управлять как в составе отдельной Техоперации, так и отдельно
        - с помощью специальных ресурсов для управления материалами и продуктами
        Техоперации. Кодом сущности для Техоперации в составе JSON API является ключевое
        слово processing. Больше о Техоперациях и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processing: Объект Processing для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processing
        """
        call = CreateProcessing(data=processing)
        return await self(call)

    async def create_processingorder(self, processingorder: Processingorder) -> Processingorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах на
        производство, запрашивать списки Заказов и сведения по отдельным Заказам на
        производство. Позициями Заказов можно управлять как в составе отдельного Заказа
        на производство, так и отдельно - с помощью специальных ресурсов для управления
        позициями Заказа. Кодом сущности для Заказа на производство в составе JSON API
        является ключевое слово processingorder. Больше о Заказах на производство и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке.

        :param processingorder: Объект Processingorder для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processingorder
        """
        call = CreateProcessingorder(data=processingorder)
        return await self(call)

    async def create_processingplan(self, processingplan: Processingplan) -> Processingplan:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техкартах,
        запрашивать списки Техкарт и сведения по отдельным Техкартам. Позициями Техкарт
        можно управлять как в составе отдельной Техкарты, так и отдельно - с помощью
        специальных ресурсов для управления материалами и продуктами Техкарты. Кодом
        сущности для Техкарты в составе JSON API является ключевое слово processingplan.
        Больше о Техкартах и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке.

        :param processingplan: Объект Processingplan для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplan
        """
        call = CreateProcessingplan(data=processingplan)
        return await self(call)

    async def create_processingplanfolder(
        self, processingplanfolder: Processingplanfolder
    ) -> Processingplanfolder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах техкарт,
        запрашивать списки Групп техкарт и сведения по отдельным Группам техкарт. Кодом
        сущности для Группы техкарт в составе JSON API является ключевое слово
        processingplanfolder.

        :param processingplanfolder: Объект Processingplanfolder для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplanfolder
        """
        call = CreateProcessingplanfolder(data=processingplanfolder)
        return await self(call)

    async def create_processingprocess(
        self, processingprocess: Processingprocess
    ) -> Processingprocess:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техпроцессах,
        запрашивать списки Техпроцессов и сведения по отдельным Техпроцессам. Позициями
        Техпроцессов можно управлять как в составе отдельного Техпроцесса, так и
        отдельно - с помощью специальных ресурсов для управления позициями Техпроцессов.
        Кодом сущности для Техпроцессов в составе JSON API является ключевое слово
        processingprocess. Больше о Техпроцессах и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingprocess: Объект Processingprocess для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingprocess
        """
        call = CreateProcessingprocess(data=processingprocess)
        return await self(call)

    async def create_processingstage(self, processingstage: Processingstage) -> Processingstage:
        """
        Средствами JSON API можно запрашивать и обновлять списки Этапов и сведения по
        отдельным Этапам. Кодом сущности для Этапов в составе JSON API является ключевое
        слово processingstage. Больше об Этапах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingstage: Объект Processingstage для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingstage
        """
        call = CreateProcessingstage(data=processingstage)
        return await self(call)

    async def create_product(self, product: Product) -> Product:
        """
        Средствами JSON API можно создавать и обновлять сведения о Товарах, запрашивать
        списки Товаров и сведения по отдельным Товарам. Кодом сущности для Товара в
        составе JSON API является ключевое слово product. Больше о Товарах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке.

        :param product: Объект Product для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/product
        """
        call = CreateProduct(data=product)
        return await self(call)

    async def create_productfolder(self, productfolder: Productfolder) -> Productfolder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах товаров,
        запрашивать списки Групп товаров и сведения по отдельным Группам товаров. Кодом
        сущности для Группы товаров в составе JSON API является ключевое слово
        productfolder. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке.

        :param productfolder: Объект Productfolder для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/productFolder
        """
        call = CreateProductfolder(data=productfolder)
        return await self(call)

    async def create_productionstagecompletion(
        self, productionstagecompletion: Productionstagecompletion
    ) -> Productionstagecompletion:
        """
        Кодом сущности для Выполнения этапа производства в составе JSON API является
        ключевое слово productionstagecompletion.

        :param productionstagecompletion: Объект Productionstagecompletion для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionStageCompletion
        """
        call = CreateProductionstagecompletion(data=productionstagecompletion)
        return await self(call)

    async def create_productiontask(self, productiontask: Productiontask) -> Productiontask:
        """
        Средствами JSON API можно обновлять сведения о Производственных заданиях,
        запрашивать списки Производственных заданий и сведения по отдельным
        Производственным заданиям. Позициями Производственных заданий можно управлять
        как в составе отдельного Производственного задания, так и отдельно - с помощью
        специальных ресурсов для управления позициями Производственных заданий. Кодом
        сущности для Производственных заданий в составе JSON API является ключевое слово
        productiontask. Больше о Производстве и Производственном задании и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке.

        :param productiontask: Объект Productiontask для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionTask
        """
        call = CreateProductiontask(data=productiontask)
        return await self(call)

    async def create_project(self, project: Project) -> Project:
        """
        Средствами JSON API можно создавать и обновлять сведения о Проектах, запрашивать
        списки Проектов и сведения по отдельным Проектам. Кодом сущности для Проекта в
        составе JSON API является ключевое слово project. Больше о Проектах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param project: Объект Project для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/project
        """
        call = CreateProject(data=project)
        return await self(call)

    async def create_purchaseorder(self, purchaseorder: Purchaseorder) -> Purchaseorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах поставщику,
        запрашивать списки Заказов и сведения по отдельным Заказам Поставщикам.
        Позициями Заказов можно управлять как в составе отдельного Заказа поставщику,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа поставщику в составе JSON API является ключевое слово
        purchaseorder. Больше о Заказах Поставщикам и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param purchaseorder: Объект Purchaseorder для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseOrder
        """
        call = CreatePurchaseorder(data=purchaseorder)
        return await self(call)

    async def create_purchasereturn(self, purchasereturn: Purchasereturn) -> Purchasereturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        поставщикам, запрашивать списки Возвратов поставщикам и сведения по отдельным
        Возвратам поставщикам. Позициями Возвратов поставщикам можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата поставщику. Кодом сущности для Возврата поставщику
        в составе JSON API является ключевое слово purchasereturn.

        :param purchasereturn: Объект Purchasereturn для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchase-return
        """
        call = CreatePurchasereturn(data=purchasereturn)
        return await self(call)

    async def create_retaildemand(self, retaildemand: Retaildemand) -> Retaildemand:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных продажах,
        запрашивать списки Розничных продаж и сведения по отдельным Розничным продажам.
        Позициями Розничных продаж можно управлять как в составе отдельной Розничной
        продажи, так и отдельно - с помощью специальных ресурсов для управления
        позициями Розничными продажами. Кодом сущности для Розничной продажи в составе
        JSON API является ключевое слово retaildemand. Больше о Розничных продажах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке в разделе Оформление продажи.

        :param retaildemand: Объект Retaildemand для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildemand
        """
        call = CreateRetaildemand(data=retaildemand)
        return await self(call)

    async def create_retailsalesreturn(
        self, retailsalesreturn: Retailsalesreturn
    ) -> Retailsalesreturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных возвратах,
        запрашивать списки Розничных возвратов и сведения по отдельным Розничным
        возвратам. Позициями Розничных возвратов  можно управлять как в составе
        отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Розничного возврата. Кодом сущности для Розничного возврата
        в составе JSON API является ключевое слово retailsalesreturn.

        :param retailsalesreturn: Объект Retailsalesreturn для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retail-sales-return
        """
        call = CreateRetailsalesreturn(data=retailsalesreturn)
        return await self(call)

    async def create_retailshift(self, retailshift: Retailshift) -> Retailshift:
        """
        Средствами JSON API можно запрашивать списки Розничных смен и сведения по
        отдельным Розничным сменам. Кодом сущности для Розничной смены в составе JSON
        API является ключевое слово retailshift.

        :param retailshift: Объект Retailshift для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retailshift
        """
        call = CreateRetailshift(data=retailshift)
        return await self(call)

    async def create_retailstore(self, retailstore: Retailstore) -> Retailstore:
        """
        Средствами JSON API можно создавать и обновлять сведения о Точках продаж,
        запрашивать списки Точек продаж и сведения по отдельным Точкам продаж. Также
        можно получить доступ к специальному ресурсу для управления кассирами точки
        продаж. Кодом сущности для точки продаж в составе JSON API является ключевое
        слово retailstore. Больше о точках продаж и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке в разделе "Создание
        точки продаж в основном интерфейсе". По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать

        :param retailstore: Объект Retailstore для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/retailstore
        """
        call = CreateRetailstore(data=retailstore)
        return await self(call)

    async def create_retireorder(self, retireorder: Retireorder) -> Retireorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выводе кодов
        маркировки из оборота, а также запрашивать списки документов и информацию о
        конкретных Выводах. Позициями можно управлять как в составе документа Вывода,
        так и отдельно - с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Вывода из оборота в составе JSON API является ключевое слово
        retireorder. Больше о Выводах кодов из оборота можно прочитать здесь.

        :param retireorder: Объект Retireorder для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retireorder
        """
        call = CreateRetireorder(data=retireorder)
        return await self(call)

    async def create_saleschannel(self, saleschannel: Saleschannel) -> Saleschannel:
        """
        Средствами JSON API можно создавать и обновлять сведения о Каналах продаж,
        запрашивать списки Каналов продаж и сведения по отдельным Каналам продаж. Кодом
        сущности для Канала продаж в составе JSON API является ключевое слово
        saleschannel. Больше о Каналах продаж и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param saleschannel: Объект Saleschannel для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleschannel
        """
        call = CreateSaleschannel(data=saleschannel)
        return await self(call)

    async def create_salesreturn(self, salesreturn: Salesreturn) -> Salesreturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        покупателей, запрашивать списки Возвратов покупателей и сведения по отдельным
        Возвратам покупателей. Позициями Возвратов покупателей можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата покупателя. Кодом сущности для Возврата покупателя
        в составе JSON API является ключевое слово salesreturn.

        :param salesreturn: Объект Salesreturn для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/sales-return
        """
        call = CreateSalesreturn(data=salesreturn)
        return await self(call)

    async def create_service(self, service: Service) -> Service:
        """
        Средствами JSON API можно создавать и обновлять сведения об Услугах, запрашивать
        списки Услуг и сведения по отдельным Услугам. Кодом сущности для Услуги в
        составе JSON API является ключевое слово service. Услуга - специальная
        разновидность товара, без закупочной цены и упаковок. Больше о Товарах и работе
        с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад.

        :param service: Объект Service для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/service
        """
        call = CreateService(data=service)
        return await self(call)

    async def create_store(self, store: Store) -> Store:
        """
        Кодом сущности для Складов в составе JSON API является ключевое слово store.

        :param store: Объект Store для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store
        """
        call = CreateStore(data=store)
        return await self(call)

    async def create_supply(self, supply: Supply) -> Supply:
        """
        Средствами JSON API можно создавать и обновлять сведения об Приемках,
        запрашивать списки Приемок и сведения по отдельным Приемкам. Позициями Приемок
        можно управлять как в составе отдельной Приемки, так и отдельно - с помощью
        специальных ресурсов для управления позициями Приемки. Кодом сущности для
        Приемки в составе JSON API является ключевое слово supply. Больше об Приемках и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке.

        :param supply: Объект Supply для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply
        """
        call = CreateSupply(data=supply)
        return await self(call)

    async def create_task(self, task: Task) -> Task:
        """
        Средствами JSON API можно создавать и обновлять сведения о задачах, запрашивать
        списки задач и сведения по отдельным задачам. Кодом сущности для задачи в
        составе JSON API является ключевое слово task. Больше о задачах и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param task: Объект Task для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/task
        """
        call = CreateTask(data=task)
        return await self(call)

    async def create_taxrate(self, taxrate: Taxrate) -> Taxrate:
        """
        Средствами JSON API можно создавать и обновлять сведения о налоговых ставках,
        запрашивать списки ставок и сведения по отдельным ставкам. Кодом сущности для
        налоговой ставки в составе JSON API является ключевое слово taxrate. По данной
        сущности можно осуществлять контекстный поиск с помощью специального параметра
        search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается
        от других тем, что поиск не префиксный, без токенизации и идет только по одному
        полю одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param taxrate: Объект Taxrate для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/taxrate
        """
        call = CreateTaxrate(data=taxrate)
        return await self(call)

    async def create_uom(self, uom: Uom) -> Uom:
        """
        Кодом сущности для Единиц измерения в составе JSON API является ключевое слово
        uom. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param uom: Объект Uom для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/uom
        """
        call = CreateUom(data=uom)
        return await self(call)

    async def create_variant(self, variant: Variant) -> Variant:
        """
        Средствами JSON API можно создавать и обновлять сведения о Модификациях товаров,
        запрашивать списки Модификаций товаров и сведения по отдельным Модификациям.
        Кодом сущности для Модификации в составе JSON API является ключевое слово
        variant. Больше о Модификациях товаров и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке, а также больше о
        работе с товарами здесь. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск
        с параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param variant: Объект Variant для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/variant
        """
        call = CreateVariant(data=variant)
        return await self(call)

    async def create_webhook(self, webhook: Webhook) -> Webhook:
        """
        Пример того, в каком виде будут передаваться данные:

        :param webhook: Объект Webhook для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhook
        """
        call = CreateWebhook(data=webhook)
        return await self(call)

    async def create_webhookstock(self, webhookstock: Webhookstock) -> Webhookstock:
        """
        > Пример того, в каком виде будут передаваться данные: POST
        https://example.com/webhook_path?requestId=640569eb-522d-427a-b07e-fa757c5d4217

        :param webhookstock: Объект Webhookstock для создания

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhookstock
        """
        call = CreateWebhookstock(data=webhookstock)
        return await self(call)

    async def delete_bonusprogram(self, bonusprogram_id: str) -> None:
        """
        Кодом сущности для Бонусных программ в составе JSON API является ключевое слово
        bonusprogram. Перед работой со скидками настоятельно рекомендуем вам прочитать
        вот эту статью на портале поддержки МоегоСклада.

        :param bonusprogram_id: Идентификатор Bonusprogram для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-program
        """
        call = DeleteBonusprogram(bonusprogram_id=bonusprogram_id)
        return await self(call)

    async def delete_bonustransaction(self, bonustransaction_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Бонусных операциях,
        запрашивать списки Бонусных операций и сведения по отдельным Бонусым операциям.
        Кодом сущности для Бонусной операции в составе JSON API является ключевое слово
        bonustransaction.

        :param bonustransaction_id: Идентификатор Bonustransaction для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-operation
        """
        call = DeleteBonustransaction(bonustransaction_id=bonustransaction_id)
        return await self(call)

    async def delete_bundle(self, bundle_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Комплектах,
        запрашивать списки Комплектов и сведения по отдельным Комплектам. Кодом сущности
        для Комплекта в составе JSON API является ключевое слово bundle.

        :param bundle_id: Идентификатор Bundle для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bundle
        """
        call = DeleteBundle(bundle_id=bundle_id)
        return await self(call)

    async def delete_cashin(self, cashin_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Приходном ордере,
        запрашивать списки Приходных ордеров и сведения по отдельным Приходным
        ордерам.Кодом сущности для Приходного ордера в составе JSON API является
        ключевое слово cashin.

        :param cashin_id: Идентификатор Cashin для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashin
        """
        call = DeleteCashin(cashin_id=cashin_id)
        return await self(call)

    async def delete_cashout(self, cashout_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Расходном ордере,
        запрашивать списки Расходных ордеров  и сведения по отдельным Расходных ордеров.
        Кодом сущности для Расходного ордера  в составе JSON API является ключевое слово
        cashout.

        :param cashout_id: Идентификатор Cashout для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashout
        """
        call = DeleteCashout(cashout_id=cashout_id)
        return await self(call)

    async def delete_commissionreportin(self, commissionreportin_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Полученных отчетах
        комиссионера, запрашивать списки Полученных отчетов комиссионера и сведения по
        отдельным Полученным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Полученного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportin. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportin_id: Идентификатор Commissionreportin для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportin
        """
        call = DeleteCommissionreportin(commissionreportin_id=commissionreportin_id)
        return await self(call)

    async def delete_commissionreportout(self, commissionreportout_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выданных отчетах
        комиссионера, запрашивать списки Выданных отчетов комиссионера и сведения по
        отдельным Выданным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Выданного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportout. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportout_id: Идентификатор Commissionreportout для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportout
        """
        call = DeleteCommissionreportout(commissionreportout_id=commissionreportout_id)
        return await self(call)

    async def delete_consignment(self, consignment_id: str) -> None:
        """
        Кодом сущности для Партии в составе JSON API является ключевое слово
        consignment. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param consignment_id: Идентификатор Consignment для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/consignment
        """
        call = DeleteConsignment(consignment_id=consignment_id)
        return await self(call)

    async def delete_contract(self, contract_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Договорах,
        запрашивать списки Договоров и сведения по отдельным Договорам. Кодом сущности
        для Договора в составе JSON API является ключевое слово contract. Больше о
        Договорах и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
        не префиксный, без токенизации и идет только по одному полю одновременно. Ищет
        такие строки, в которые входит значение строки поиска.

        :param contract_id: Идентификатор Contract для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contract
        """
        call = DeleteContract(contract_id=contract_id)
        return await self(call)

    async def delete_counterparty(self, counterparty_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Контрагентах,
        запрашивать списки Контрагентов и сведения по отдельным Контрагентам. Счетами
        Контрагента и его контактными лицами можно управлять как в составе отдельного
        Контрагента, так и отдельно - с помощью специальных ресурсов для управления
        счетами и контактными лицами Контрагента. Кодом сущности для Контрагента в
        составе JSON API является ключевое слово counterparty. Больше о Контрагентах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке. По данной сущности можно осуществлять контекстный поиск с
        помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный и без
        токенизации. Ищет такие строки, в которые входит значение строки поиска.

        :param counterparty_id: Идентификатор Counterparty для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty
        """
        call = DeleteCounterparty(counterparty_id=counterparty_id)
        return await self(call)

    async def delete_counterpartyadjustment(self, counterpartyadjustment_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Корректировках
        взаиморасчетов, запрашивать списки Корректировок взаиморасчетов и сведения по
        отдельным Корректировкам взаиморасчетов. Кодом сущности для Корректировки
        взаиморасчетов в составе JSON API является ключевое слово
        counterpartyadjustment. Больше о Корректировках взаиморасчетов и работе с ними в
        основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param counterpartyadjustment_id: Идентификатор Counterpartyadjustment для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/counterpartyadjustment
        """
        call = DeleteCounterpartyadjustment(counterpartyadjustment_id=counterpartyadjustment_id)
        return await self(call)

    async def delete_country(self, country_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Странах, запрашивать
        списки Стран и сведения по отдельным Странам. Кодом сущности для Страны в
        составе JSON API является ключевое слово country. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param country_id: Идентификатор Country для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/country
        """
        call = DeleteCountry(country_id=country_id)
        return await self(call)

    async def delete_currency(self, currency_id: str) -> None:
        """
        Средствами JSON API можно запрашивать списки валют и сведения по отдельным
        валютам, а также создавать новые и обновлять сведения по уже существующим
        валютам. Кодом сущности для валют в составе JSON API является ключевое слово
        currency. Больше о валютах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param currency_id: Идентификатор Currency для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/currency
        """
        call = DeleteCurrency(currency_id=currency_id)
        return await self(call)

    async def delete_customentity(self, customentity_id: str) -> None:
        """
        Кодом сущности для Пользовательских справочников в составе JSON API является
        ключевое слово customentity.

        :param customentity_id: Идентификатор Customentity для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity
        """
        call = DeleteCustomentity(customentity_id=customentity_id)
        return await self(call)

    async def delete_customerorder(self, customerorder_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах покупателя,
        запрашивать списки Заказов и сведения по отдельным Заказам покупателей.
        Позициями Заказов можно управлять как в составе отдельного Заказа покупателя,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа покупателя в составе JSON API является ключевое слово
        customerorder. Больше о Заказах покупателей и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. Также в
        Заказе покупателя поддерживается протокол оповещения об изменениях виджетов
        вендоров - change-handler. Подробнее см. в документации для вендоров о виджетах.

        :param customerorder_id: Идентификатор Customerorder для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/customerOrder
        """
        call = DeleteCustomerorder(customerorder_id=customerorder_id)
        return await self(call)

    async def delete_demand(self, demand_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения об Отгрузках,
        запрашивать списки Отгрузок и сведения по отдельным Отгрузкам. Позициями
        Отгрузок можно управлять как в составе отдельной Отгрузки, так и отдельно - с
        помощью специальных ресурсов для управления позициями Отгрузки. Кодом сущности
        для Отгрузки в составе JSON API является ключевое слово demand. Больше об
        Отгрузках и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param demand_id: Идентификатор Demand для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand
        """
        call = DeleteDemand(demand_id=demand_id)
        return await self(call)

    async def delete_discount(self, discount_id: str) -> None:
        """
        Кодом сущности для Скидок в составе JSON API является ключевое слово discount.
        Операции создания, изменения и удаления не поддерживаются. Перед работой со
        скидками настоятельно рекомендуем вам прочитать вот эту статью на портале
        поддержки МоегоСклада.

        :param discount_id: Идентификатор Discount для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/discount
        """
        call = DeleteDiscount(discount_id=discount_id)
        return await self(call)

    async def delete_employee(self, employee_id: str) -> None:
        """
        Средствами JSON API можно запрашивать списки Сотрудников и сведения по отдельным
        Сотрудникам. Кодом сущности для Сотрудника в составе JSON API является ключевое
        слово employee. Больше о Сотрудниках и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке.

        :param employee_id: Идентификатор Employee для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/employee
        """
        call = DeleteEmployee(employee_id=employee_id)
        return await self(call)

    async def delete_enter(self, enter_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения об Оприходованиях,
        запрашивать списки Оприходований и сведения по отдельным Оприходованиям.
        Позициями Оприходований можно управлять как в составе отдельного Оприходования,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Оприходования. Кодом сущности для Оприходования в составе JSON API является
        ключевое слово enter. Больше об Оприходованиях можно прочитать этой ссылке.

        :param enter_id: Идентификатор Enter для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/enter
        """
        call = DeleteEnter(enter_id=enter_id)
        return await self(call)

    async def delete_expenseitem(self, expenseitem_id: str) -> None:
        """
        Средствами JSON API можно запрашивать списки Статей расходов и сведения по
        отдельным Статьям расходов. Кодом сущности для Статей расходов в составе JSON
        API является ключевое слово expenseitem. Больше о Статьях расходов и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param expenseitem_id: Идентификатор Expenseitem для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/expenseitem
        """
        call = DeleteExpenseitem(expenseitem_id=expenseitem_id)
        return await self(call)

    async def delete_facturein(self, facturein_id: str) -> None:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры полученные,
        запрашивать списки Счетов-фактур полученных, сведения по отдельным Счетам-
        фактурам и удалять Счета-фактуры. Счет-фактура может быть создана только на
        основании приемки или исходящего платежа, без документа-основания счет-фактуру
        создать нельзя.  Кодом сущности для Счета-фактуры полученного в составе JSON API
        является ключевое слово facturein.

        :param facturein_id: Идентификатор Facturein для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/facturein
        """
        call = DeleteFacturein(facturein_id=facturein_id)
        return await self(call)

    async def delete_factureout(self, factureout_id: str) -> None:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры выданные,
        запрашивать списки Счетов-фактур выданных, сведения по отдельным Счетам-фактурам
        и удалять Счета-фактуры. Счет-фактура может быть создана только на основании
        отгрузки, возврата поставщику или входящего платежа, без документа-основания
        счет-фактуру создать нельзя. Кодом сущности для Счета-фактуры выданного в
        составе JSON API является ключевое слово factureout.

        :param factureout_id: Идентификатор Factureout для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/factureout
        """
        call = DeleteFactureout(factureout_id=factureout_id)
        return await self(call)

    async def delete_group(self, group_id: str) -> None:
        """
        Средствами JSON API можно запрашивать и изменять списки Отделов и сведения по
        отдельным Отделам. Кодом сущности для Отдела в составе JSON API является
        ключевое слово group. Больше об Отделах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по  этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param group_id: Идентификатор Group для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group
        """
        call = DeleteGroup(group_id=group_id)
        return await self(call)

    async def delete_image(self, image_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения по Изображениям для
        Товаров, Комплектов и Модификаций, запрашивать списки Изображений, а также
        сведения по отдельным Изображениям. Кодом сущности для Изображения в составе
        JSON API является ключевое слово image.

        :param image_id: Идентификатор Image для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/images
        """
        call = DeleteImage(image_id=image_id)
        return await self(call)

    async def delete_internalorder(self, internalorder_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внутренних заказах,
        запрашивать списки Внутренних заказов и сведения по отдельным Внутренним
        заказам. Позициями Внутренних заказов можно управлять как в составе отдельного
        заказа, так и с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Внутреннего заказа в составе JSON API является ключевое слово
        internalorder.

        :param internalorder_id: Идентификатор Internalorder для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/internalOrder
        """
        call = DeleteInternalorder(internalorder_id=internalorder_id)
        return await self(call)

    async def delete_inventory(self, inventory_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Инвентаризации,
        запрашивать списки Инвентаризаций и сведения по отдельным Инвентаризациям.
        Позициями Инвентаризации можно управлять как в составе отдельной Инвентаризации,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Инвентаризации. Кодом сущности для Инвентаризации в составе JSON API является
        ключевое слово inventory. Больше о Инвентаризациях можно прочитать этой ссылке.

        :param inventory_id: Идентификатор Inventory для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/inventory
        """
        call = DeleteInventory(inventory_id=inventory_id)
        return await self(call)

    async def delete_invoicein(self, invoicein_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете поставщика,
        запрашивать списки Счетов и сведения по отдельным Счетам Поставщиков. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета поставщика в составе JSON API является ключевое слово invoicein. Больше о
        Счетах Поставщиков и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoicein_id: Идентификатор Invoicein для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-in
        """
        call = DeleteInvoicein(invoicein_id=invoicein_id)
        return await self(call)

    async def delete_invoiceout(self, invoiceout_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете покупателю,
        запрашивать списки Счетов и сведения по отдельным Счетам Покупателям. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета покупателю в составе JSON API является ключевое слово invoiceout. Больше о
        Счетах Покупателям и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoiceout_id: Идентификатор Invoiceout для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-out
        """
        call = DeleteInvoiceout(invoiceout_id=invoiceout_id)
        return await self(call)

    async def delete_loss(self, loss_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Списаниях,
        запрашивать списки Списаний и сведения по отдельным Списаниям. Позициями
        Списаний можно управлять как в составе отдельного Списания, так и отдельно - с
        помощью специальных ресурсов для управления позициями Списания. Кодом сущности
        для Списания в составе JSON API является ключевое слово loss. Больше о Списаниях
        можно прочитать этой ссылке.

        :param loss_id: Идентификатор Loss для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/loss
        """
        call = DeleteLoss(loss_id=loss_id)
        return await self(call)

    async def delete_move(self, move_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Перемещениях,
        запрашивать списки Перемещений и сведения по отдельным Перемещениям. Позициями
        Перемещений можно управлять как в составе отдельного Перемещения, так и отдельно
        - с помощью специальных ресурсов для управления позициями Перемещения. Кодом
        сущности для Перемещения в составе JSON API является ключевое слово move.

        :param move_id: Идентификатор Move для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/move
        """
        call = DeleteMove(move_id=move_id)
        return await self(call)

    async def delete_notes(self, notes_id: str) -> None:
        """
        Кодом сущности для Ленты событий в составе JSON API является ключевое слово
        notes.

        :param notes_id: Идентификатор Notes для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/eventfeed
        """
        call = DeleteNotes(notes_id=notes_id)
        return await self(call)

    async def delete_organization(self, organization_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о юрлицах, запрашивать
        списки юрлиц и сведения по отдельным юрлицам. С помощью специального ресурса
        можно управлять счетами отдельного юрлица. Кодом сущности для юрлица в составе
        JSON API является ключевое слово organization. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный и без токенизации. Ищет такие строки, в которые
        входит значение строки поиска

        :param organization_id: Идентификатор Organization для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/organization
        """
        call = DeleteOrganization(organization_id=organization_id)
        return await self(call)

    async def delete_paymentin(self, paymentin_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о платеже , запрашивать
        списки Входящих платежей и сведения по отдельным Входящим платежам. Кодом
        сущности для Входящего платежа в составе JSON API является ключевое слово
        paymentin. Больше о платежах  и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке.

        :param paymentin_id: Идентификатор Paymentin для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-in
        """
        call = DeletePaymentin(paymentin_id=paymentin_id)
        return await self(call)

    async def delete_paymentout(self, paymentout_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Исходящем платеже,
        запрашивать списки Исходящих платежей  и сведения по отдельным Исходящим
        платежам. Кодом сущности для Исходящего платежа  в составе JSON API является
        ключевое слово paymentout. Больше о платежа х и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param paymentout_id: Идентификатор Paymentout для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-out
        """
        call = DeletePaymentout(paymentout_id=paymentout_id)
        return await self(call)

    async def delete_prepayment(self, prepayment_id: str) -> None:
        """
        Средствами JSON API можно запрашивать списки Предоплат и сведения по отдельным
        Предоплатам. Кодом сущности для Предоплаты в составе JSON API является ключевое
        слово prepayment. Больше о Предоплатах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param prepayment_id: Идентификатор Prepayment для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment
        """
        call = DeletePrepayment(prepayment_id=prepayment_id)
        return await self(call)

    async def delete_prepaymentreturn(self, prepaymentreturn_id: str) -> None:
        """
        Средствами JSON API можно запрашивать списки Возвратов предоплат и сведения по
        отдельным Возвратам предоплат. Кодом сущности для Возврата предоплаты в составе
        JSON API является ключевое слово prepaymentreturn.

        :param prepaymentreturn_id: Идентификатор Prepaymentreturn для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return
        """
        call = DeletePrepaymentreturn(prepaymentreturn_id=prepaymentreturn_id)
        return await self(call)

    async def delete_pricelist(self, pricelist_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Прайс-листах,
        запрашивать списки Прайс-листов и сведения по отдельным Прайс-листам. Позициями
        Прайс-листов можно управлять как в составе отдельного Прайс-листа, так и
        отдельно - с помощью специальных ресурсов для управления позициями Прайс-листа.
        Кодом сущности для Прайс-листа в составе JSON API является ключевое слово
        pricelist. Больше о Прайс-листах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по  этой ссылке.

        :param pricelist_id: Идентификатор Pricelist для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/pricelist
        """
        call = DeletePricelist(pricelist_id=pricelist_id)
        return await self(call)

    async def delete_processing(self, processing_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техоперациях,
        запрашивать списки Техопераций и сведения по отдельным Техоперациям. Позициями
        Техопераций можно управлять как в составе отдельной Техоперации, так и отдельно
        - с помощью специальных ресурсов для управления материалами и продуктами
        Техоперации. Кодом сущности для Техоперации в составе JSON API является ключевое
        слово processing. Больше о Техоперациях и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processing_id: Идентификатор Processing для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processing
        """
        call = DeleteProcessing(processing_id=processing_id)
        return await self(call)

    async def delete_processingorder(self, processingorder_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах на
        производство, запрашивать списки Заказов и сведения по отдельным Заказам на
        производство. Позициями Заказов можно управлять как в составе отдельного Заказа
        на производство, так и отдельно - с помощью специальных ресурсов для управления
        позициями Заказа. Кодом сущности для Заказа на производство в составе JSON API
        является ключевое слово processingorder. Больше о Заказах на производство и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке.

        :param processingorder_id: Идентификатор Processingorder для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processingorder
        """
        call = DeleteProcessingorder(processingorder_id=processingorder_id)
        return await self(call)

    async def delete_processingplan(self, processingplan_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техкартах,
        запрашивать списки Техкарт и сведения по отдельным Техкартам. Позициями Техкарт
        можно управлять как в составе отдельной Техкарты, так и отдельно - с помощью
        специальных ресурсов для управления материалами и продуктами Техкарты. Кодом
        сущности для Техкарты в составе JSON API является ключевое слово processingplan.
        Больше о Техкартах и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке.

        :param processingplan_id: Идентификатор Processingplan для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplan
        """
        call = DeleteProcessingplan(processingplan_id=processingplan_id)
        return await self(call)

    async def delete_processingplanfolder(self, processingplanfolder_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах техкарт,
        запрашивать списки Групп техкарт и сведения по отдельным Группам техкарт. Кодом
        сущности для Группы техкарт в составе JSON API является ключевое слово
        processingplanfolder.

        :param processingplanfolder_id: Идентификатор Processingplanfolder для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplanfolder
        """
        call = DeleteProcessingplanfolder(processingplanfolder_id=processingplanfolder_id)
        return await self(call)

    async def delete_processingprocess(self, processingprocess_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техпроцессах,
        запрашивать списки Техпроцессов и сведения по отдельным Техпроцессам. Позициями
        Техпроцессов можно управлять как в составе отдельного Техпроцесса, так и
        отдельно - с помощью специальных ресурсов для управления позициями Техпроцессов.
        Кодом сущности для Техпроцессов в составе JSON API является ключевое слово
        processingprocess. Больше о Техпроцессах и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingprocess_id: Идентификатор Processingprocess для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingprocess
        """
        call = DeleteProcessingprocess(processingprocess_id=processingprocess_id)
        return await self(call)

    async def delete_processingstage(self, processingstage_id: str) -> None:
        """
        Средствами JSON API можно запрашивать и обновлять списки Этапов и сведения по
        отдельным Этапам. Кодом сущности для Этапов в составе JSON API является ключевое
        слово processingstage. Больше об Этапах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingstage_id: Идентификатор Processingstage для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingstage
        """
        call = DeleteProcessingstage(processingstage_id=processingstage_id)
        return await self(call)

    async def delete_product(self, product_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Товарах, запрашивать
        списки Товаров и сведения по отдельным Товарам. Кодом сущности для Товара в
        составе JSON API является ключевое слово product. Больше о Товарах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке.

        :param product_id: Идентификатор Product для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/product
        """
        call = DeleteProduct(product_id=product_id)
        return await self(call)

    async def delete_productfolder(self, productfolder_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах товаров,
        запрашивать списки Групп товаров и сведения по отдельным Группам товаров. Кодом
        сущности для Группы товаров в составе JSON API является ключевое слово
        productfolder. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке.

        :param productfolder_id: Идентификатор Productfolder для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/productFolder
        """
        call = DeleteProductfolder(productfolder_id=productfolder_id)
        return await self(call)

    async def delete_productionstagecompletion(self, productionstagecompletion_id: str) -> None:
        """
        Кодом сущности для Выполнения этапа производства в составе JSON API является
        ключевое слово productionstagecompletion.

        :param productionstagecompletion_id: Идентификатор Productionstagecompletion для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionStageCompletion
        """
        call = DeleteProductionstagecompletion(
            productionstagecompletion_id=productionstagecompletion_id
        )
        return await self(call)

    async def delete_productiontask(self, productiontask_id: str) -> None:
        """
        Средствами JSON API можно обновлять сведения о Производственных заданиях,
        запрашивать списки Производственных заданий и сведения по отдельным
        Производственным заданиям. Позициями Производственных заданий можно управлять
        как в составе отдельного Производственного задания, так и отдельно - с помощью
        специальных ресурсов для управления позициями Производственных заданий. Кодом
        сущности для Производственных заданий в составе JSON API является ключевое слово
        productiontask. Больше о Производстве и Производственном задании и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке.

        :param productiontask_id: Идентификатор Productiontask для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionTask
        """
        call = DeleteProductiontask(productiontask_id=productiontask_id)
        return await self(call)

    async def delete_project(self, project_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Проектах, запрашивать
        списки Проектов и сведения по отдельным Проектам. Кодом сущности для Проекта в
        составе JSON API является ключевое слово project. Больше о Проектах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param project_id: Идентификатор Project для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/project
        """
        call = DeleteProject(project_id=project_id)
        return await self(call)

    async def delete_publication(self, publication_id: str) -> None:
        """
        JSON API позволяет опубликовать для общего пользования печатную форму документа,
        созданную на основе шаблона печатной формы. Кодом сущности для публикации в
        составе JSON API является ключевое слово publication.

        :param publication_id: Идентификатор Publication для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/publication
        """
        call = DeletePublication(publication_id=publication_id)
        return await self(call)

    async def delete_purchaseorder(self, purchaseorder_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах поставщику,
        запрашивать списки Заказов и сведения по отдельным Заказам Поставщикам.
        Позициями Заказов можно управлять как в составе отдельного Заказа поставщику,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа поставщику в составе JSON API является ключевое слово
        purchaseorder. Больше о Заказах Поставщикам и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param purchaseorder_id: Идентификатор Purchaseorder для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseOrder
        """
        call = DeletePurchaseorder(purchaseorder_id=purchaseorder_id)
        return await self(call)

    async def delete_purchasereturn(self, purchasereturn_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        поставщикам, запрашивать списки Возвратов поставщикам и сведения по отдельным
        Возвратам поставщикам. Позициями Возвратов поставщикам можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата поставщику. Кодом сущности для Возврата поставщику
        в составе JSON API является ключевое слово purchasereturn.

        :param purchasereturn_id: Идентификатор Purchasereturn для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchase-return
        """
        call = DeletePurchasereturn(purchasereturn_id=purchasereturn_id)
        return await self(call)

    async def delete_retaildemand(self, retaildemand_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных продажах,
        запрашивать списки Розничных продаж и сведения по отдельным Розничным продажам.
        Позициями Розничных продаж можно управлять как в составе отдельной Розничной
        продажи, так и отдельно - с помощью специальных ресурсов для управления
        позициями Розничными продажами. Кодом сущности для Розничной продажи в составе
        JSON API является ключевое слово retaildemand. Больше о Розничных продажах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке в разделе Оформление продажи.

        :param retaildemand_id: Идентификатор Retaildemand для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildemand
        """
        call = DeleteRetaildemand(retaildemand_id=retaildemand_id)
        return await self(call)

    async def delete_retaildrawercashin(self, retaildrawercashin_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внесениях денег,
        запрашивать списки Внесений денег и сведения по отдельным Внесениям денег. Кодом
        сущности для Внесения денег в составе JSON API является ключевое слово
        retaildrawercashin. Больше о Внесениях денег и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке.

        :param retaildrawercashin_id: Идентификатор Retaildrawercashin для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashin
        """
        call = DeleteRetaildrawercashin(retaildrawercashin_id=retaildrawercashin_id)
        return await self(call)

    async def delete_retaildrawercashout(self, retaildrawercashout_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выплатах денег,
        запрашивать списки Выплат денег и сведения по отдельным Выплатам денег. Кодом
        сущности для внесения денег в составе JSON API является ключевое слово
        retaildrawercashout. Больше о Выплатах денег и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке

        :param retaildrawercashout_id: Идентификатор Retaildrawercashout для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashout
        """
        call = DeleteRetaildrawercashout(retaildrawercashout_id=retaildrawercashout_id)
        return await self(call)

    async def delete_retailsalesreturn(self, retailsalesreturn_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных возвратах,
        запрашивать списки Розничных возвратов и сведения по отдельным Розничным
        возвратам. Позициями Розничных возвратов  можно управлять как в составе
        отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Розничного возврата. Кодом сущности для Розничного возврата
        в составе JSON API является ключевое слово retailsalesreturn.

        :param retailsalesreturn_id: Идентификатор Retailsalesreturn для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retail-sales-return
        """
        call = DeleteRetailsalesreturn(retailsalesreturn_id=retailsalesreturn_id)
        return await self(call)

    async def delete_retailshift(self, retailshift_id: str) -> None:
        """
        Средствами JSON API можно запрашивать списки Розничных смен и сведения по
        отдельным Розничным сменам. Кодом сущности для Розничной смены в составе JSON
        API является ключевое слово retailshift.

        :param retailshift_id: Идентификатор Retailshift для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retailshift
        """
        call = DeleteRetailshift(retailshift_id=retailshift_id)
        return await self(call)

    async def delete_retailstore(self, retailstore_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Точках продаж,
        запрашивать списки Точек продаж и сведения по отдельным Точкам продаж. Также
        можно получить доступ к специальному ресурсу для управления кассирами точки
        продаж. Кодом сущности для точки продаж в составе JSON API является ключевое
        слово retailstore. Больше о точках продаж и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке в разделе "Создание
        точки продаж в основном интерфейсе". По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать

        :param retailstore_id: Идентификатор Retailstore для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/retailstore
        """
        call = DeleteRetailstore(retailstore_id=retailstore_id)
        return await self(call)

    async def delete_retireorder(self, retireorder_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выводе кодов
        маркировки из оборота, а также запрашивать списки документов и информацию о
        конкретных Выводах. Позициями можно управлять как в составе документа Вывода,
        так и отдельно - с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Вывода из оборота в составе JSON API является ключевое слово
        retireorder. Больше о Выводах кодов из оборота можно прочитать здесь.

        :param retireorder_id: Идентификатор Retireorder для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retireorder
        """
        call = DeleteRetireorder(retireorder_id=retireorder_id)
        return await self(call)

    async def delete_role(self, role_id: str) -> None:
        """
        Кодом сущности для Пользовательской роли в составе JSON API является ключевое
        слово role.

        :param role_id: Идентификатор Role для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/custom-role
        """
        call = DeleteRole(role_id=role_id)
        return await self(call)

    async def delete_saleschannel(self, saleschannel_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Каналах продаж,
        запрашивать списки Каналов продаж и сведения по отдельным Каналам продаж. Кодом
        сущности для Канала продаж в составе JSON API является ключевое слово
        saleschannel. Больше о Каналах продаж и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param saleschannel_id: Идентификатор Saleschannel для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleschannel
        """
        call = DeleteSaleschannel(saleschannel_id=saleschannel_id)
        return await self(call)

    async def delete_salesreturn(self, salesreturn_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        покупателей, запрашивать списки Возвратов покупателей и сведения по отдельным
        Возвратам покупателей. Позициями Возвратов покупателей можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата покупателя. Кодом сущности для Возврата покупателя
        в составе JSON API является ключевое слово salesreturn.

        :param salesreturn_id: Идентификатор Salesreturn для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/sales-return
        """
        call = DeleteSalesreturn(salesreturn_id=salesreturn_id)
        return await self(call)

    async def delete_service(self, service_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения об Услугах, запрашивать
        списки Услуг и сведения по отдельным Услугам. Кодом сущности для Услуги в
        составе JSON API является ключевое слово service. Услуга - специальная
        разновидность товара, без закупочной цены и упаковок. Больше о Товарах и работе
        с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад.

        :param service_id: Идентификатор Service для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/service
        """
        call = DeleteService(service_id=service_id)
        return await self(call)

    async def delete_store(self, store_id: str) -> None:
        """
        Кодом сущности для Складов в составе JSON API является ключевое слово store.

        :param store_id: Идентификатор Store для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store
        """
        call = DeleteStore(store_id=store_id)
        return await self(call)

    async def delete_supply(self, supply_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения об Приемках,
        запрашивать списки Приемок и сведения по отдельным Приемкам. Позициями Приемок
        можно управлять как в составе отдельной Приемки, так и отдельно - с помощью
        специальных ресурсов для управления позициями Приемки. Кодом сущности для
        Приемки в составе JSON API является ключевое слово supply. Больше об Приемках и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке.

        :param supply_id: Идентификатор Supply для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply
        """
        call = DeleteSupply(supply_id=supply_id)
        return await self(call)

    async def delete_task(self, task_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о задачах, запрашивать
        списки задач и сведения по отдельным задачам. Кодом сущности для задачи в
        составе JSON API является ключевое слово task. Больше о задачах и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param task_id: Идентификатор Task для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/task
        """
        call = DeleteTask(task_id=task_id)
        return await self(call)

    async def delete_taxrate(self, taxrate_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о налоговых ставках,
        запрашивать списки ставок и сведения по отдельным ставкам. Кодом сущности для
        налоговой ставки в составе JSON API является ключевое слово taxrate. По данной
        сущности можно осуществлять контекстный поиск с помощью специального параметра
        search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается
        от других тем, что поиск не префиксный, без токенизации и идет только по одному
        полю одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param taxrate_id: Идентификатор Taxrate для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/taxrate
        """
        call = DeleteTaxrate(taxrate_id=taxrate_id)
        return await self(call)

    async def delete_uom(self, uom_id: str) -> None:
        """
        Кодом сущности для Единиц измерения в составе JSON API является ключевое слово
        uom. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param uom_id: Идентификатор Uom для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/uom
        """
        call = DeleteUom(uom_id=uom_id)
        return await self(call)

    async def delete_variant(self, variant_id: str) -> None:
        """
        Средствами JSON API можно создавать и обновлять сведения о Модификациях товаров,
        запрашивать списки Модификаций товаров и сведения по отдельным Модификациям.
        Кодом сущности для Модификации в составе JSON API является ключевое слово
        variant. Больше о Модификациях товаров и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке, а также больше о
        работе с товарами здесь. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск
        с параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param variant_id: Идентификатор Variant для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/variant
        """
        call = DeleteVariant(variant_id=variant_id)
        return await self(call)

    async def delete_webhook(self, webhook_id: str) -> None:
        """
        Пример того, в каком виде будут передаваться данные:

        :param webhook_id: Идентификатор Webhook для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhook
        """
        call = DeleteWebhook(webhook_id=webhook_id)
        return await self(call)

    async def delete_webhookstock(self, webhookstock_id: str) -> None:
        """
        > Пример того, в каком виде будут передаваться данные: POST
        https://example.com/webhook_path?requestId=640569eb-522d-427a-b07e-fa757c5d4217

        :param webhookstock_id: Идентификатор Webhookstock для удаления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhookstock
        """
        call = DeleteWebhookstock(webhookstock_id=webhookstock_id)
        return await self(call)

    async def get_assortment(
        self,
        assortment_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Assortment:
        """
        Результаты запроса можно отфильтровать, используя параметр filter.

        :param assortment_id: Идентификатор Assortment
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/assortment
        """
        call = GetAssortment(
            assortment_id=assortment_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_assortments(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Assortment]:
        """
        Результаты запроса можно отфильтровать, используя параметр filter.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/assortment
        """
        call = GetAssortments(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_audit(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Audit]:
        """
        В аудите под контекстом подразумевается одно или несколько связанных событий,
        например, массовое обновление товаров. События отражают конкретные произошедшие
        изменения, например, изменение значения поля. Контекст же содержит только общую
        информацию событий, относящихся к нему.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/audit/audit
        """
        call = GetAudit(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_bonusprogram(
        self,
        bonusprogram_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Bonusprogram:
        """
        Кодом сущности для Бонусных программ в составе JSON API является ключевое слово
        bonusprogram. Перед работой со скидками настоятельно рекомендуем вам прочитать
        вот эту статью на портале поддержки МоегоСклада.

        :param bonusprogram_id: Идентификатор Bonusprogram
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-program
        """
        call = GetBonusprogram(
            bonusprogram_id=bonusprogram_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_bonusprograms(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Bonusprogram]:
        """
        Кодом сущности для Бонусных программ в составе JSON API является ключевое слово
        bonusprogram. Перед работой со скидками настоятельно рекомендуем вам прочитать
        вот эту статью на портале поддержки МоегоСклада.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-program
        """
        call = GetBonusprograms(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_bonustransaction(
        self,
        bonustransaction_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Bonustransaction:
        """
        Средствами JSON API можно создавать и обновлять сведения о Бонусных операциях,
        запрашивать списки Бонусных операций и сведения по отдельным Бонусым операциям.
        Кодом сущности для Бонусной операции в составе JSON API является ключевое слово
        bonustransaction.

        :param bonustransaction_id: Идентификатор Bonustransaction
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-operation
        """
        call = GetBonustransaction(
            bonustransaction_id=bonustransaction_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_bonustransactions(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Bonustransaction]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Бонусных операциях,
        запрашивать списки Бонусных операций и сведения по отдельным Бонусым операциям.
        Кодом сущности для Бонусной операции в составе JSON API является ключевое слово
        bonustransaction.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-operation
        """
        call = GetBonustransactions(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_bundle(
        self,
        bundle_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Bundle:
        """
        Средствами JSON API можно создавать и обновлять сведения о Комплектах,
        запрашивать списки Комплектов и сведения по отдельным Комплектам. Кодом сущности
        для Комплекта в составе JSON API является ключевое слово bundle.

        :param bundle_id: Идентификатор Bundle
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bundle
        """
        call = GetBundle(
            bundle_id=bundle_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_bundles(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Bundle]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Комплектах,
        запрашивать списки Комплектов и сведения по отдельным Комплектам. Кодом сущности
        для Комплекта в составе JSON API является ключевое слово bundle.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bundle
        """
        call = GetBundles(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_cashier(
        self,
        cashier_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Cashier:
        """
        Средствами JSON API можно запрашивать списки Кассиров и сведения по отдельным
        кассирам. Кодом сущности для кассира в составе JSON API является ключевое слово
        cashier.

        :param cashier_id: Идентификатор Cashier
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/cashier
        """
        call = GetCashier(
            cashier_id=cashier_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_cashin(
        self,
        cashin_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Cashin:
        """
        Средствами JSON API можно создавать и обновлять сведения о Приходном ордере,
        запрашивать списки Приходных ордеров и сведения по отдельным Приходным
        ордерам.Кодом сущности для Приходного ордера в составе JSON API является
        ключевое слово cashin.

        :param cashin_id: Идентификатор Cashin
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashin
        """
        call = GetCashin(
            cashin_id=cashin_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_cashins(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Cashin]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Приходном ордере,
        запрашивать списки Приходных ордеров и сведения по отдельным Приходным
        ордерам.Кодом сущности для Приходного ордера в составе JSON API является
        ключевое слово cashin.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashin
        """
        call = GetCashins(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_cashout(
        self,
        cashout_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Cashout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Расходном ордере,
        запрашивать списки Расходных ордеров  и сведения по отдельным Расходных ордеров.
        Кодом сущности для Расходного ордера  в составе JSON API является ключевое слово
        cashout.

        :param cashout_id: Идентификатор Cashout
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashout
        """
        call = GetCashout(
            cashout_id=cashout_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_cashouts(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Cashout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Расходном ордере,
        запрашивать списки Расходных ордеров  и сведения по отдельным Расходных ордеров.
        Кодом сущности для Расходного ордера  в составе JSON API является ключевое слово
        cashout.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashout
        """
        call = GetCashouts(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_commissionreportin(
        self,
        commissionreportin_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Commissionreportin:
        """
        Средствами JSON API можно создавать и обновлять сведения о Полученных отчетах
        комиссионера, запрашивать списки Полученных отчетов комиссионера и сведения по
        отдельным Полученным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Полученного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportin. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportin_id: Идентификатор Commissionreportin
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportin
        """
        call = GetCommissionreportin(
            commissionreportin_id=commissionreportin_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_commissionreportins(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Commissionreportin]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Полученных отчетах
        комиссионера, запрашивать списки Полученных отчетов комиссионера и сведения по
        отдельным Полученным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Полученного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportin. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportin
        """
        call = GetCommissionreportins(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_commissionreportout(
        self,
        commissionreportout_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Commissionreportout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выданных отчетах
        комиссионера, запрашивать списки Выданных отчетов комиссионера и сведения по
        отдельным Выданным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Выданного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportout. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportout_id: Идентификатор Commissionreportout
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportout
        """
        call = GetCommissionreportout(
            commissionreportout_id=commissionreportout_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_commissionreportouts(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Commissionreportout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выданных отчетах
        комиссионера, запрашивать списки Выданных отчетов комиссионера и сведения по
        отдельным Выданным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Выданного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportout. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportout
        """
        call = GetCommissionreportouts(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_companysettings(
        self,
        companysettings_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Companysettings:
        """
        Кодом сущности для Настройки компании в составе JSON API является ключевое слово
        companysettings. На данный момент можно получить информацию о текущих настройках
        компании и типах цен товаров.

        :param companysettings_id: Идентификатор Companysettings
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/companysettings
        """
        call = GetCompanysettings(
            companysettings_id=companysettings_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_consignment(
        self,
        consignment_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Consignment:
        """
        Кодом сущности для Партии в составе JSON API является ключевое слово
        consignment. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param consignment_id: Идентификатор Consignment
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/consignment
        """
        call = GetConsignment(
            consignment_id=consignment_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_consignments(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Consignment]:
        """
        Кодом сущности для Партии в составе JSON API является ключевое слово
        consignment. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/consignment
        """
        call = GetConsignments(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_contentcard(
        self,
        contentcard_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Contentcard:
        """
        Средствами JSON API можно просматривать сведения о Карточках контента,
        запрашивать списки Карточек контента и сведения по отдельным Карточкам контента.
        Кодом сущности для Карточки контента в составе JSON API является ключевое слово
        contentcard.

        :param contentcard_id: Идентификатор Contentcard
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contentcard
        """
        call = GetContentcard(
            contentcard_id=contentcard_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_contentcards(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Contentcard]:
        """
        Средствами JSON API можно просматривать сведения о Карточках контента,
        запрашивать списки Карточек контента и сведения по отдельным Карточкам контента.
        Кодом сущности для Карточки контента в составе JSON API является ключевое слово
        contentcard.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contentcard
        """
        call = GetContentcards(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_contract(
        self,
        contract_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Contract:
        """
        Средствами JSON API можно создавать и обновлять сведения о Договорах,
        запрашивать списки Договоров и сведения по отдельным Договорам. Кодом сущности
        для Договора в составе JSON API является ключевое слово contract. Больше о
        Договорах и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
        не префиксный, без токенизации и идет только по одному полю одновременно. Ищет
        такие строки, в которые входит значение строки поиска.

        :param contract_id: Идентификатор Contract
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contract
        """
        call = GetContract(
            contract_id=contract_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_contracts(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Contract]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Договорах,
        запрашивать списки Договоров и сведения по отдельным Договорам. Кодом сущности
        для Договора в составе JSON API является ключевое слово contract. Больше о
        Договорах и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
        не префиксный, без токенизации и идет только по одному полю одновременно. Ищет
        такие строки, в которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contract
        """
        call = GetContracts(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_counterparties(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Counterparty]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Контрагентах,
        запрашивать списки Контрагентов и сведения по отдельным Контрагентам. Счетами
        Контрагента и его контактными лицами можно управлять как в составе отдельного
        Контрагента, так и отдельно - с помощью специальных ресурсов для управления
        счетами и контактными лицами Контрагента. Кодом сущности для Контрагента в
        составе JSON API является ключевое слово counterparty. Больше о Контрагентах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке. По данной сущности можно осуществлять контекстный поиск с
        помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный и без
        токенизации. Ищет такие строки, в которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty
        """
        call = GetCounterparties(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_counterparty(
        self,
        counterparty_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Counterparty:
        """
        Средствами JSON API можно создавать и обновлять сведения о Контрагентах,
        запрашивать списки Контрагентов и сведения по отдельным Контрагентам. Счетами
        Контрагента и его контактными лицами можно управлять как в составе отдельного
        Контрагента, так и отдельно - с помощью специальных ресурсов для управления
        счетами и контактными лицами Контрагента. Кодом сущности для Контрагента в
        составе JSON API является ключевое слово counterparty. Больше о Контрагентах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке. По данной сущности можно осуществлять контекстный поиск с
        помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный и без
        токенизации. Ищет такие строки, в которые входит значение строки поиска.

        :param counterparty_id: Идентификатор Counterparty
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty
        """
        call = GetCounterparty(
            counterparty_id=counterparty_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_counterpartyadjustment(
        self,
        counterpartyadjustment_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Counterpartyadjustment:
        """
        Средствами JSON API можно создавать и обновлять сведения о Корректировках
        взаиморасчетов, запрашивать списки Корректировок взаиморасчетов и сведения по
        отдельным Корректировкам взаиморасчетов. Кодом сущности для Корректировки
        взаиморасчетов в составе JSON API является ключевое слово
        counterpartyadjustment. Больше о Корректировках взаиморасчетов и работе с ними в
        основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param counterpartyadjustment_id: Идентификатор Counterpartyadjustment
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/counterpartyadjustment
        """
        call = GetCounterpartyadjustment(
            counterpartyadjustment_id=counterpartyadjustment_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_counterpartyadjustments(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Counterpartyadjustment]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Корректировках
        взаиморасчетов, запрашивать списки Корректировок взаиморасчетов и сведения по
        отдельным Корректировкам взаиморасчетов. Кодом сущности для Корректировки
        взаиморасчетов в составе JSON API является ключевое слово
        counterpartyadjustment. Больше о Корректировках взаиморасчетов и работе с ними в
        основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/counterpartyadjustment
        """
        call = GetCounterpartyadjustments(
            limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_countries(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Country]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Странах, запрашивать
        списки Стран и сведения по отдельным Странам. Кодом сущности для Страны в
        составе JSON API является ключевое слово country. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/country
        """
        call = GetCountries(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_country(
        self,
        country_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Country:
        """
        Средствами JSON API можно создавать и обновлять сведения о Странах, запрашивать
        списки Стран и сведения по отдельным Странам. Кодом сущности для Страны в
        составе JSON API является ключевое слово country. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param country_id: Идентификатор Country
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/country
        """
        call = GetCountry(
            country_id=country_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_currency(
        self,
        currency_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Currency:
        """
        Средствами JSON API можно запрашивать списки валют и сведения по отдельным
        валютам, а также создавать новые и обновлять сведения по уже существующим
        валютам. Кодом сущности для валют в составе JSON API является ключевое слово
        currency. Больше о валютах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param currency_id: Идентификатор Currency
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/currency
        """
        call = GetCurrency(
            currency_id=currency_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_customentities(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Customentity]:
        """
        Кодом сущности для Пользовательских справочников в составе JSON API является
        ключевое слово customentity.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity
        """
        call = GetCustomentities(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_customentity(
        self,
        customentity_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Customentity:
        """
        Кодом сущности для Пользовательских справочников в составе JSON API является
        ключевое слово customentity.

        :param customentity_id: Идентификатор Customentity
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity
        """
        call = GetCustomentity(
            customentity_id=customentity_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_customerorder(
        self,
        customerorder_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Customerorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах покупателя,
        запрашивать списки Заказов и сведения по отдельным Заказам покупателей.
        Позициями Заказов можно управлять как в составе отдельного Заказа покупателя,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа покупателя в составе JSON API является ключевое слово
        customerorder. Больше о Заказах покупателей и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. Также в
        Заказе покупателя поддерживается протокол оповещения об изменениях виджетов
        вендоров - change-handler. Подробнее см. в документации для вендоров о виджетах.

        :param customerorder_id: Идентификатор Customerorder
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/customerOrder
        """
        call = GetCustomerorder(
            customerorder_id=customerorder_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_customerorders(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Customerorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах покупателя,
        запрашивать списки Заказов и сведения по отдельным Заказам покупателей.
        Позициями Заказов можно управлять как в составе отдельного Заказа покупателя,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа покупателя в составе JSON API является ключевое слово
        customerorder. Больше о Заказах покупателей и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. Также в
        Заказе покупателя поддерживается протокол оповещения об изменениях виджетов
        вендоров - change-handler. Подробнее см. в документации для вендоров о виджетах.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/customerOrder
        """
        call = GetCustomerorders(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_demand(
        self,
        demand_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Demand:
        """
        Средствами JSON API можно создавать и обновлять сведения об Отгрузках,
        запрашивать списки Отгрузок и сведения по отдельным Отгрузкам. Позициями
        Отгрузок можно управлять как в составе отдельной Отгрузки, так и отдельно - с
        помощью специальных ресурсов для управления позициями Отгрузки. Кодом сущности
        для Отгрузки в составе JSON API является ключевое слово demand. Больше об
        Отгрузках и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param demand_id: Идентификатор Demand
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand
        """
        call = GetDemand(
            demand_id=demand_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_demands(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Demand]:
        """
        Средствами JSON API можно создавать и обновлять сведения об Отгрузках,
        запрашивать списки Отгрузок и сведения по отдельным Отгрузкам. Позициями
        Отгрузок можно управлять как в составе отдельной Отгрузки, так и отдельно - с
        помощью специальных ресурсов для управления позициями Отгрузки. Кодом сущности
        для Отгрузки в составе JSON API является ключевое слово demand. Больше об
        Отгрузках и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand
        """
        call = GetDemands(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_discount(
        self,
        discount_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Discount:
        """
        Кодом сущности для Скидок в составе JSON API является ключевое слово discount.
        Операции создания, изменения и удаления не поддерживаются. Перед работой со
        скидками настоятельно рекомендуем вам прочитать вот эту статью на портале
        поддержки МоегоСклада.

        :param discount_id: Идентификатор Discount
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/discount
        """
        call = GetDiscount(
            discount_id=discount_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_discounts(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Discount]:
        """
        Кодом сущности для Скидок в составе JSON API является ключевое слово discount.
        Операции создания, изменения и удаления не поддерживаются. Перед работой со
        скидками настоятельно рекомендуем вам прочитать вот эту статью на портале
        поддержки МоегоСклада.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/discount
        """
        call = GetDiscounts(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_emissionorder(
        self,
        emissionorder_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Emissionorder:
        """
        Для создания/изменения Заказов кодов маркировки необходима тарифная опция
        Маркировка для аккаунтов из RU региона и расширение Честный знак для остальных
        регионов.

        :param emissionorder_id: Идентификатор Emissionorder
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder
        """
        call = GetEmissionorder(
            emissionorder_id=emissionorder_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_emissionorders(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Emissionorder]:
        """
        Для создания/изменения Заказов кодов маркировки необходима тарифная опция
        Маркировка для аккаунтов из RU региона и расширение Честный знак для остальных
        регионов.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder
        """
        call = GetEmissionorders(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_employee(
        self,
        employee_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Employee:
        """
        Средствами JSON API можно запрашивать списки Сотрудников и сведения по отдельным
        Сотрудникам. Кодом сущности для Сотрудника в составе JSON API является ключевое
        слово employee. Больше о Сотрудниках и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке.

        :param employee_id: Идентификатор Employee
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/employee
        """
        call = GetEmployee(
            employee_id=employee_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_employees(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Employee]:
        """
        Средствами JSON API можно запрашивать списки Сотрудников и сведения по отдельным
        Сотрудникам. Кодом сущности для Сотрудника в составе JSON API является ключевое
        слово employee. Больше о Сотрудниках и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/employee
        """
        call = GetEmployees(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_enter(
        self,
        enter_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Enter:
        """
        Средствами JSON API можно создавать и обновлять сведения об Оприходованиях,
        запрашивать списки Оприходований и сведения по отдельным Оприходованиям.
        Позициями Оприходований можно управлять как в составе отдельного Оприходования,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Оприходования. Кодом сущности для Оприходования в составе JSON API является
        ключевое слово enter. Больше об Оприходованиях можно прочитать этой ссылке.

        :param enter_id: Идентификатор Enter
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/enter
        """
        call = GetEnter(
            enter_id=enter_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_enters(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Enter]:
        """
        Средствами JSON API можно создавать и обновлять сведения об Оприходованиях,
        запрашивать списки Оприходований и сведения по отдельным Оприходованиям.
        Позициями Оприходований можно управлять как в составе отдельного Оприходования,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Оприходования. Кодом сущности для Оприходования в составе JSON API является
        ключевое слово enter. Больше об Оприходованиях можно прочитать этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/enter
        """
        call = GetEnters(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_expenseitem(
        self,
        expenseitem_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Expenseitem:
        """
        Средствами JSON API можно запрашивать списки Статей расходов и сведения по
        отдельным Статьям расходов. Кодом сущности для Статей расходов в составе JSON
        API является ключевое слово expenseitem. Больше о Статьях расходов и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param expenseitem_id: Идентификатор Expenseitem
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/expenseitem
        """
        call = GetExpenseitem(
            expenseitem_id=expenseitem_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_expenseitems(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Expenseitem]:
        """
        Средствами JSON API можно запрашивать списки Статей расходов и сведения по
        отдельным Статьям расходов. Кодом сущности для Статей расходов в составе JSON
        API является ключевое слово expenseitem. Больше о Статьях расходов и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/expenseitem
        """
        call = GetExpenseitems(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_facturein(
        self,
        facturein_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Facturein:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры полученные,
        запрашивать списки Счетов-фактур полученных, сведения по отдельным Счетам-
        фактурам и удалять Счета-фактуры. Счет-фактура может быть создана только на
        основании приемки или исходящего платежа, без документа-основания счет-фактуру
        создать нельзя.  Кодом сущности для Счета-фактуры полученного в составе JSON API
        является ключевое слово facturein.

        :param facturein_id: Идентификатор Facturein
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/facturein
        """
        call = GetFacturein(
            facturein_id=facturein_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_factureins(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Facturein]:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры полученные,
        запрашивать списки Счетов-фактур полученных, сведения по отдельным Счетам-
        фактурам и удалять Счета-фактуры. Счет-фактура может быть создана только на
        основании приемки или исходящего платежа, без документа-основания счет-фактуру
        создать нельзя.  Кодом сущности для Счета-фактуры полученного в составе JSON API
        является ключевое слово facturein.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/facturein
        """
        call = GetFactureins(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_factureout(
        self,
        factureout_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Factureout:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры выданные,
        запрашивать списки Счетов-фактур выданных, сведения по отдельным Счетам-фактурам
        и удалять Счета-фактуры. Счет-фактура может быть создана только на основании
        отгрузки, возврата поставщику или входящего платежа, без документа-основания
        счет-фактуру создать нельзя. Кодом сущности для Счета-фактуры выданного в
        составе JSON API является ключевое слово factureout.

        :param factureout_id: Идентификатор Factureout
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/factureout
        """
        call = GetFactureout(
            factureout_id=factureout_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_factureouts(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Factureout]:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры выданные,
        запрашивать списки Счетов-фактур выданных, сведения по отдельным Счетам-фактурам
        и удалять Счета-фактуры. Счет-фактура может быть создана только на основании
        отгрузки, возврата поставщику или входящего платежа, без документа-основания
        счет-фактуру создать нельзя. Кодом сущности для Счета-фактуры выданного в
        составе JSON API является ключевое слово factureout.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/factureout
        """
        call = GetFactureouts(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_group(
        self,
        group_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Group:
        """
        Средствами JSON API можно запрашивать и изменять списки Отделов и сведения по
        отдельным Отделам. Кодом сущности для Отдела в составе JSON API является
        ключевое слово group. Больше об Отделах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по  этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param group_id: Идентификатор Group
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group
        """
        call = GetGroup(
            group_id=group_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_groups(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Group]:
        """
        Средствами JSON API можно запрашивать и изменять списки Отделов и сведения по
        отдельным Отделам. Кодом сущности для Отдела в составе JSON API является
        ключевое слово group. Больше об Отделах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по  этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group
        """
        call = GetGroups(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_internalorder(
        self,
        internalorder_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Internalorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внутренних заказах,
        запрашивать списки Внутренних заказов и сведения по отдельным Внутренним
        заказам. Позициями Внутренних заказов можно управлять как в составе отдельного
        заказа, так и с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Внутреннего заказа в составе JSON API является ключевое слово
        internalorder.

        :param internalorder_id: Идентификатор Internalorder
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/internalOrder
        """
        call = GetInternalorder(
            internalorder_id=internalorder_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_internalorders(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Internalorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внутренних заказах,
        запрашивать списки Внутренних заказов и сведения по отдельным Внутренним
        заказам. Позициями Внутренних заказов можно управлять как в составе отдельного
        заказа, так и с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Внутреннего заказа в составе JSON API является ключевое слово
        internalorder.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/internalOrder
        """
        call = GetInternalorders(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_inventories(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Inventory]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Инвентаризации,
        запрашивать списки Инвентаризаций и сведения по отдельным Инвентаризациям.
        Позициями Инвентаризации можно управлять как в составе отдельной Инвентаризации,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Инвентаризации. Кодом сущности для Инвентаризации в составе JSON API является
        ключевое слово inventory. Больше о Инвентаризациях можно прочитать этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/inventory
        """
        call = GetInventories(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_inventory(
        self,
        inventory_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Inventory:
        """
        Средствами JSON API можно создавать и обновлять сведения о Инвентаризации,
        запрашивать списки Инвентаризаций и сведения по отдельным Инвентаризациям.
        Позициями Инвентаризации можно управлять как в составе отдельной Инвентаризации,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Инвентаризации. Кодом сущности для Инвентаризации в составе JSON API является
        ключевое слово inventory. Больше о Инвентаризациях можно прочитать этой ссылке.

        :param inventory_id: Идентификатор Inventory
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/inventory
        """
        call = GetInventory(
            inventory_id=inventory_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_invoicein(
        self,
        invoicein_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Invoicein:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете поставщика,
        запрашивать списки Счетов и сведения по отдельным Счетам Поставщиков. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета поставщика в составе JSON API является ключевое слово invoicein. Больше о
        Счетах Поставщиков и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoicein_id: Идентификатор Invoicein
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-in
        """
        call = GetInvoicein(
            invoicein_id=invoicein_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_invoiceins(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Invoicein]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете поставщика,
        запрашивать списки Счетов и сведения по отдельным Счетам Поставщиков. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета поставщика в составе JSON API является ключевое слово invoicein. Больше о
        Счетах Поставщиков и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-in
        """
        call = GetInvoiceins(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_invoiceout(
        self,
        invoiceout_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Invoiceout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете покупателю,
        запрашивать списки Счетов и сведения по отдельным Счетам Покупателям. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета покупателю в составе JSON API является ключевое слово invoiceout. Больше о
        Счетах Покупателям и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoiceout_id: Идентификатор Invoiceout
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-out
        """
        call = GetInvoiceout(
            invoiceout_id=invoiceout_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_invoiceouts(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Invoiceout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете покупателю,
        запрашивать списки Счетов и сведения по отдельным Счетам Покупателям. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета покупателю в составе JSON API является ключевое слово invoiceout. Больше о
        Счетах Покупателям и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-out
        """
        call = GetInvoiceouts(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_loss(
        self,
        loss_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Loss:
        """
        Средствами JSON API можно создавать и обновлять сведения о Списаниях,
        запрашивать списки Списаний и сведения по отдельным Списаниям. Позициями
        Списаний можно управлять как в составе отдельного Списания, так и отдельно - с
        помощью специальных ресурсов для управления позициями Списания. Кодом сущности
        для Списания в составе JSON API является ключевое слово loss. Больше о Списаниях
        можно прочитать этой ссылке.

        :param loss_id: Идентификатор Loss
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/loss
        """
        call = GetLoss(
            loss_id=loss_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
            order=order,
        )
        return await self(call)

    async def get_losses(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Loss]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Списаниях,
        запрашивать списки Списаний и сведения по отдельным Списаниям. Позициями
        Списаний можно управлять как в составе отдельного Списания, так и отдельно - с
        помощью специальных ресурсов для управления позициями Списания. Кодом сущности
        для Списания в составе JSON API является ключевое слово loss. Больше о Списаниях
        можно прочитать этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/loss
        """
        call = GetLosses(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_move(
        self,
        move_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Move:
        """
        Средствами JSON API можно создавать и обновлять сведения о Перемещениях,
        запрашивать списки Перемещений и сведения по отдельным Перемещениям. Позициями
        Перемещений можно управлять как в составе отдельного Перемещения, так и отдельно
        - с помощью специальных ресурсов для управления позициями Перемещения. Кодом
        сущности для Перемещения в составе JSON API является ключевое слово move.

        :param move_id: Идентификатор Move
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/move
        """
        call = GetMove(
            move_id=move_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
            order=order,
        )
        return await self(call)

    async def get_moves(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Move]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Перемещениях,
        запрашивать списки Перемещений и сведения по отдельным Перемещениям. Позициями
        Перемещений можно управлять как в составе отдельного Перемещения, так и отдельно
        - с помощью специальных ресурсов для управления позициями Перемещения. Кодом
        сущности для Перемещения в составе JSON API является ключевое слово move.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/move
        """
        call = GetMoves(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_namedfilter(
        self,
        namedfilter_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Namedfilter:
        """
        Кодом сущности для Сохраненных фильтров в составе JSON API является ключевое
        слово namedfilter.

        :param namedfilter_id: Идентификатор Namedfilter
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/named-filter
        """
        call = GetNamedfilter(
            namedfilter_id=namedfilter_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_notes(
        self,
        notes_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Notes:
        """
        Кодом сущности для Ленты событий в составе JSON API является ключевое слово
        notes.

        :param notes_id: Идентификатор Notes
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/eventfeed
        """
        call = GetNotes(
            notes_id=notes_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_organization(
        self,
        organization_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Organization:
        """
        Средствами JSON API можно создавать и обновлять сведения о юрлицах, запрашивать
        списки юрлиц и сведения по отдельным юрлицам. С помощью специального ресурса
        можно управлять счетами отдельного юрлица. Кодом сущности для юрлица в составе
        JSON API является ключевое слово organization. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный и без токенизации. Ищет такие строки, в которые
        входит значение строки поиска

        :param organization_id: Идентификатор Organization
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/organization
        """
        call = GetOrganization(
            organization_id=organization_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_organizations(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Organization]:
        """
        Средствами JSON API можно создавать и обновлять сведения о юрлицах, запрашивать
        списки юрлиц и сведения по отдельным юрлицам. С помощью специального ресурса
        можно управлять счетами отдельного юрлица. Кодом сущности для юрлица в составе
        JSON API является ключевое слово organization. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный и без токенизации. Ищет такие строки, в которые
        входит значение строки поиска

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/organization
        """
        call = GetOrganizations(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_paymentin(
        self,
        paymentin_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Paymentin:
        """
        Средствами JSON API можно создавать и обновлять сведения о платеже , запрашивать
        списки Входящих платежей и сведения по отдельным Входящим платежам. Кодом
        сущности для Входящего платежа в составе JSON API является ключевое слово
        paymentin. Больше о платежах  и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке.

        :param paymentin_id: Идентификатор Paymentin
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-in
        """
        call = GetPaymentin(
            paymentin_id=paymentin_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_paymentins(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Paymentin]:
        """
        Средствами JSON API можно создавать и обновлять сведения о платеже , запрашивать
        списки Входящих платежей и сведения по отдельным Входящим платежам. Кодом
        сущности для Входящего платежа в составе JSON API является ключевое слово
        paymentin. Больше о платежах  и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-in
        """
        call = GetPaymentins(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_paymentout(
        self,
        paymentout_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Paymentout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Исходящем платеже,
        запрашивать списки Исходящих платежей  и сведения по отдельным Исходящим
        платежам. Кодом сущности для Исходящего платежа  в составе JSON API является
        ключевое слово paymentout. Больше о платежа х и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param paymentout_id: Идентификатор Paymentout
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-out
        """
        call = GetPaymentout(
            paymentout_id=paymentout_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_paymentouts(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Paymentout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Исходящем платеже,
        запрашивать списки Исходящих платежей  и сведения по отдельным Исходящим
        платежам. Кодом сущности для Исходящего платежа  в составе JSON API является
        ключевое слово paymentout. Больше о платежа х и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-out
        """
        call = GetPaymentouts(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_prepayment(
        self,
        prepayment_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Prepayment:
        """
        Средствами JSON API можно запрашивать списки Предоплат и сведения по отдельным
        Предоплатам. Кодом сущности для Предоплаты в составе JSON API является ключевое
        слово prepayment. Больше о Предоплатах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param prepayment_id: Идентификатор Prepayment
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment
        """
        call = GetPrepayment(
            prepayment_id=prepayment_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_prepaymentreturn(
        self,
        prepaymentreturn_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Prepaymentreturn:
        """
        Средствами JSON API можно запрашивать списки Возвратов предоплат и сведения по
        отдельным Возвратам предоплат. Кодом сущности для Возврата предоплаты в составе
        JSON API является ключевое слово prepaymentreturn.

        :param prepaymentreturn_id: Идентификатор Prepaymentreturn
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return
        """
        call = GetPrepaymentreturn(
            prepaymentreturn_id=prepaymentreturn_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_prepaymentreturns(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Prepaymentreturn]:
        """
        Средствами JSON API можно запрашивать списки Возвратов предоплат и сведения по
        отдельным Возвратам предоплат. Кодом сущности для Возврата предоплаты в составе
        JSON API является ключевое слово prepaymentreturn.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return
        """
        call = GetPrepaymentreturns(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_prepayments(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Prepayment]:
        """
        Средствами JSON API можно запрашивать списки Предоплат и сведения по отдельным
        Предоплатам. Кодом сущности для Предоплаты в составе JSON API является ключевое
        слово prepayment. Больше о Предоплатах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment
        """
        call = GetPrepayments(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_pricelist(
        self,
        pricelist_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Pricelist:
        """
        Средствами JSON API можно создавать и обновлять сведения о Прайс-листах,
        запрашивать списки Прайс-листов и сведения по отдельным Прайс-листам. Позициями
        Прайс-листов можно управлять как в составе отдельного Прайс-листа, так и
        отдельно - с помощью специальных ресурсов для управления позициями Прайс-листа.
        Кодом сущности для Прайс-листа в составе JSON API является ключевое слово
        pricelist. Больше о Прайс-листах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по  этой ссылке.

        :param pricelist_id: Идентификатор Pricelist
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/pricelist
        """
        call = GetPricelist(
            pricelist_id=pricelist_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_pricelists(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Pricelist]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Прайс-листах,
        запрашивать списки Прайс-листов и сведения по отдельным Прайс-листам. Позициями
        Прайс-листов можно управлять как в составе отдельного Прайс-листа, так и
        отдельно - с помощью специальных ресурсов для управления позициями Прайс-листа.
        Кодом сущности для Прайс-листа в составе JSON API является ключевое слово
        pricelist. Больше о Прайс-листах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по  этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/pricelist
        """
        call = GetPricelists(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_processing(
        self,
        processing_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Processing:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техоперациях,
        запрашивать списки Техопераций и сведения по отдельным Техоперациям. Позициями
        Техопераций можно управлять как в составе отдельной Техоперации, так и отдельно
        - с помощью специальных ресурсов для управления материалами и продуктами
        Техоперации. Кодом сущности для Техоперации в составе JSON API является ключевое
        слово processing. Больше о Техоперациях и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processing_id: Идентификатор Processing
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processing
        """
        call = GetProcessing(
            processing_id=processing_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_processingorder(
        self,
        processingorder_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Processingorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах на
        производство, запрашивать списки Заказов и сведения по отдельным Заказам на
        производство. Позициями Заказов можно управлять как в составе отдельного Заказа
        на производство, так и отдельно - с помощью специальных ресурсов для управления
        позициями Заказа. Кодом сущности для Заказа на производство в составе JSON API
        является ключевое слово processingorder. Больше о Заказах на производство и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке.

        :param processingorder_id: Идентификатор Processingorder
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processingorder
        """
        call = GetProcessingorder(
            processingorder_id=processingorder_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_processingorders(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Processingorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах на
        производство, запрашивать списки Заказов и сведения по отдельным Заказам на
        производство. Позициями Заказов можно управлять как в составе отдельного Заказа
        на производство, так и отдельно - с помощью специальных ресурсов для управления
        позициями Заказа. Кодом сущности для Заказа на производство в составе JSON API
        является ключевое слово processingorder. Больше о Заказах на производство и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processingorder
        """
        call = GetProcessingorders(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_processingplan(
        self,
        processingplan_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Processingplan:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техкартах,
        запрашивать списки Техкарт и сведения по отдельным Техкартам. Позициями Техкарт
        можно управлять как в составе отдельной Техкарты, так и отдельно - с помощью
        специальных ресурсов для управления материалами и продуктами Техкарты. Кодом
        сущности для Техкарты в составе JSON API является ключевое слово processingplan.
        Больше о Техкартах и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке.

        :param processingplan_id: Идентификатор Processingplan
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplan
        """
        call = GetProcessingplan(
            processingplan_id=processingplan_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_processingplanfolder(
        self,
        processingplanfolder_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Processingplanfolder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах техкарт,
        запрашивать списки Групп техкарт и сведения по отдельным Группам техкарт. Кодом
        сущности для Группы техкарт в составе JSON API является ключевое слово
        processingplanfolder.

        :param processingplanfolder_id: Идентификатор Processingplanfolder
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplanfolder
        """
        call = GetProcessingplanfolder(
            processingplanfolder_id=processingplanfolder_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_processingplanfolders(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Processingplanfolder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах техкарт,
        запрашивать списки Групп техкарт и сведения по отдельным Группам техкарт. Кодом
        сущности для Группы техкарт в составе JSON API является ключевое слово
        processingplanfolder.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplanfolder
        """
        call = GetProcessingplanfolders(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_processingplans(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Processingplan]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техкартах,
        запрашивать списки Техкарт и сведения по отдельным Техкартам. Позициями Техкарт
        можно управлять как в составе отдельной Техкарты, так и отдельно - с помощью
        специальных ресурсов для управления материалами и продуктами Техкарты. Кодом
        сущности для Техкарты в составе JSON API является ключевое слово processingplan.
        Больше о Техкартах и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplan
        """
        call = GetProcessingplans(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_processingprocess(
        self,
        processingprocess_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Processingprocess:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техпроцессах,
        запрашивать списки Техпроцессов и сведения по отдельным Техпроцессам. Позициями
        Техпроцессов можно управлять как в составе отдельного Техпроцесса, так и
        отдельно - с помощью специальных ресурсов для управления позициями Техпроцессов.
        Кодом сущности для Техпроцессов в составе JSON API является ключевое слово
        processingprocess. Больше о Техпроцессах и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingprocess_id: Идентификатор Processingprocess
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingprocess
        """
        call = GetProcessingprocess(
            processingprocess_id=processingprocess_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_processingprocesses(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Processingprocess]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техпроцессах,
        запрашивать списки Техпроцессов и сведения по отдельным Техпроцессам. Позициями
        Техпроцессов можно управлять как в составе отдельного Техпроцесса, так и
        отдельно - с помощью специальных ресурсов для управления позициями Техпроцессов.
        Кодом сущности для Техпроцессов в составе JSON API является ключевое слово
        processingprocess. Больше о Техпроцессах и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingprocess
        """
        call = GetProcessingprocesses(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_processings(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Processing]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техоперациях,
        запрашивать списки Техопераций и сведения по отдельным Техоперациям. Позициями
        Техопераций можно управлять как в составе отдельной Техоперации, так и отдельно
        - с помощью специальных ресурсов для управления материалами и продуктами
        Техоперации. Кодом сущности для Техоперации в составе JSON API является ключевое
        слово processing. Больше о Техоперациях и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processing
        """
        call = GetProcessings(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_processingstage(
        self,
        processingstage_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Processingstage:
        """
        Средствами JSON API можно запрашивать и обновлять списки Этапов и сведения по
        отдельным Этапам. Кодом сущности для Этапов в составе JSON API является ключевое
        слово processingstage. Больше об Этапах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingstage_id: Идентификатор Processingstage
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingstage
        """
        call = GetProcessingstage(
            processingstage_id=processingstage_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_processingstages(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Processingstage]:
        """
        Средствами JSON API можно запрашивать и обновлять списки Этапов и сведения по
        отдельным Этапам. Кодом сущности для Этапов в составе JSON API является ключевое
        слово processingstage. Больше об Этапах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingstage
        """
        call = GetProcessingstages(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_product(
        self,
        product_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Product:
        """
        Средствами JSON API можно создавать и обновлять сведения о Товарах, запрашивать
        списки Товаров и сведения по отдельным Товарам. Кодом сущности для Товара в
        составе JSON API является ключевое слово product. Больше о Товарах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке.

        :param product_id: Идентификатор Product
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/product
        """
        call = GetProduct(
            product_id=product_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_productfolder(
        self,
        productfolder_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Productfolder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах товаров,
        запрашивать списки Групп товаров и сведения по отдельным Группам товаров. Кодом
        сущности для Группы товаров в составе JSON API является ключевое слово
        productfolder. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке.

        :param productfolder_id: Идентификатор Productfolder
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/productFolder
        """
        call = GetProductfolder(
            productfolder_id=productfolder_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_productfolders(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Productfolder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах товаров,
        запрашивать списки Групп товаров и сведения по отдельным Группам товаров. Кодом
        сущности для Группы товаров в составе JSON API является ключевое слово
        productfolder. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/productFolder
        """
        call = GetProductfolders(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_productionstagecompletion(
        self,
        productionstagecompletion_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Productionstagecompletion:
        """
        Кодом сущности для Выполнения этапа производства в составе JSON API является
        ключевое слово productionstagecompletion.

        :param productionstagecompletion_id: Идентификатор Productionstagecompletion
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionStageCompletion
        """
        call = GetProductionstagecompletion(
            productionstagecompletion_id=productionstagecompletion_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_productionstagecompletions(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Productionstagecompletion]:
        """
        Кодом сущности для Выполнения этапа производства в составе JSON API является
        ключевое слово productionstagecompletion.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionStageCompletion
        """
        call = GetProductionstagecompletions(
            limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_productiontask(
        self,
        productiontask_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Productiontask:
        """
        Средствами JSON API можно обновлять сведения о Производственных заданиях,
        запрашивать списки Производственных заданий и сведения по отдельным
        Производственным заданиям. Позициями Производственных заданий можно управлять
        как в составе отдельного Производственного задания, так и отдельно - с помощью
        специальных ресурсов для управления позициями Производственных заданий. Кодом
        сущности для Производственных заданий в составе JSON API является ключевое слово
        productiontask. Больше о Производстве и Производственном задании и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке.

        :param productiontask_id: Идентификатор Productiontask
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionTask
        """
        call = GetProductiontask(
            productiontask_id=productiontask_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_productiontasks(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Productiontask]:
        """
        Средствами JSON API можно обновлять сведения о Производственных заданиях,
        запрашивать списки Производственных заданий и сведения по отдельным
        Производственным заданиям. Позициями Производственных заданий можно управлять
        как в составе отдельного Производственного задания, так и отдельно - с помощью
        специальных ресурсов для управления позициями Производственных заданий. Кодом
        сущности для Производственных заданий в составе JSON API является ключевое слово
        productiontask. Больше о Производстве и Производственном задании и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionTask
        """
        call = GetProductiontasks(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_products(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Product]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Товарах, запрашивать
        списки Товаров и сведения по отдельным Товарам. Кодом сущности для Товара в
        составе JSON API является ключевое слово product. Больше о Товарах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/product
        """
        call = GetProducts(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_profit_by_product(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        order: str | None = None,
    ) -> MetaArray[Profit]:
        """
        Прибыльность по товарам.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-pnl
        """
        call = GetProfitByProduct(limit=limit, offset=offset, filters=filters, order=order)
        return await self(call)

    async def get_profit_by_variant(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        order: str | None = None,
    ) -> MetaArray[Profit]:
        """
        Прибыльность по модификациям.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-pnl
        """
        call = GetProfitByVariant(limit=limit, offset=offset, filters=filters, order=order)
        return await self(call)

    async def get_project(
        self,
        project_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Project:
        """
        Средствами JSON API можно создавать и обновлять сведения о Проектах, запрашивать
        списки Проектов и сведения по отдельным Проектам. Кодом сущности для Проекта в
        составе JSON API является ключевое слово project. Больше о Проектах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param project_id: Идентификатор Project
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/project
        """
        call = GetProject(
            project_id=project_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_projects(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Project]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Проектах, запрашивать
        списки Проектов и сведения по отдельным Проектам. Кодом сущности для Проекта в
        составе JSON API является ключевое слово project. Больше о Проектах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/project
        """
        call = GetProjects(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_purchaseorder(
        self,
        purchaseorder_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Purchaseorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах поставщику,
        запрашивать списки Заказов и сведения по отдельным Заказам Поставщикам.
        Позициями Заказов можно управлять как в составе отдельного Заказа поставщику,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа поставщику в составе JSON API является ключевое слово
        purchaseorder. Больше о Заказах Поставщикам и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param purchaseorder_id: Идентификатор Purchaseorder
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseOrder
        """
        call = GetPurchaseorder(
            purchaseorder_id=purchaseorder_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_purchaseorders(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Purchaseorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах поставщику,
        запрашивать списки Заказов и сведения по отдельным Заказам Поставщикам.
        Позициями Заказов можно управлять как в составе отдельного Заказа поставщику,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа поставщику в составе JSON API является ключевое слово
        purchaseorder. Больше о Заказах Поставщикам и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseOrder
        """
        call = GetPurchaseorders(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_purchasereturn(
        self,
        purchasereturn_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Purchasereturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        поставщикам, запрашивать списки Возвратов поставщикам и сведения по отдельным
        Возвратам поставщикам. Позициями Возвратов поставщикам можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата поставщику. Кодом сущности для Возврата поставщику
        в составе JSON API является ключевое слово purchasereturn.

        :param purchasereturn_id: Идентификатор Purchasereturn
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchase-return
        """
        call = GetPurchasereturn(
            purchasereturn_id=purchasereturn_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_purchasereturns(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Purchasereturn]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        поставщикам, запрашивать списки Возвратов поставщикам и сведения по отдельным
        Возвратам поставщикам. Позициями Возвратов поставщикам можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата поставщику. Кодом сущности для Возврата поставщику
        в составе JSON API является ключевое слово purchasereturn.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchase-return
        """
        call = GetPurchasereturns(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_region(
        self,
        region_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Region:
        """
        Средствами JSON API можно запрашивать список регионов России и сведения по
        отдельным регионам. Кодом сущности для Регионов в составе JSON API является
        ключевое слово region.

        :param region_id: Идентификатор Region
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/region
        """
        call = GetRegion(
            region_id=region_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_regions(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Region]:
        """
        Средствами JSON API можно запрашивать список регионов России и сведения по
        отдельным регионам. Кодом сущности для Регионов в составе JSON API является
        ключевое слово region.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/region
        """
        call = GetRegions(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_retaildemand(
        self,
        retaildemand_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Retaildemand:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных продажах,
        запрашивать списки Розничных продаж и сведения по отдельным Розничным продажам.
        Позициями Розничных продаж можно управлять как в составе отдельной Розничной
        продажи, так и отдельно - с помощью специальных ресурсов для управления
        позициями Розничными продажами. Кодом сущности для Розничной продажи в составе
        JSON API является ключевое слово retaildemand. Больше о Розничных продажах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке в разделе Оформление продажи.

        :param retaildemand_id: Идентификатор Retaildemand
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildemand
        """
        call = GetRetaildemand(
            retaildemand_id=retaildemand_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_retaildemands(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Retaildemand]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных продажах,
        запрашивать списки Розничных продаж и сведения по отдельным Розничным продажам.
        Позициями Розничных продаж можно управлять как в составе отдельной Розничной
        продажи, так и отдельно - с помощью специальных ресурсов для управления
        позициями Розничными продажами. Кодом сущности для Розничной продажи в составе
        JSON API является ключевое слово retaildemand. Больше о Розничных продажах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке в разделе Оформление продажи.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildemand
        """
        call = GetRetaildemands(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_retaildrawercashin(
        self,
        retaildrawercashin_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Retaildrawercashin:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внесениях денег,
        запрашивать списки Внесений денег и сведения по отдельным Внесениям денег. Кодом
        сущности для Внесения денег в составе JSON API является ключевое слово
        retaildrawercashin. Больше о Внесениях денег и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке.

        :param retaildrawercashin_id: Идентификатор Retaildrawercashin
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashin
        """
        call = GetRetaildrawercashin(
            retaildrawercashin_id=retaildrawercashin_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_retaildrawercashout(
        self,
        retaildrawercashout_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Retaildrawercashout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выплатах денег,
        запрашивать списки Выплат денег и сведения по отдельным Выплатам денег. Кодом
        сущности для внесения денег в составе JSON API является ключевое слово
        retaildrawercashout. Больше о Выплатах денег и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке

        :param retaildrawercashout_id: Идентификатор Retaildrawercashout
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashout
        """
        call = GetRetaildrawercashout(
            retaildrawercashout_id=retaildrawercashout_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_retailsalesreturn(
        self,
        retailsalesreturn_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Retailsalesreturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных возвратах,
        запрашивать списки Розничных возвратов и сведения по отдельным Розничным
        возвратам. Позициями Розничных возвратов  можно управлять как в составе
        отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Розничного возврата. Кодом сущности для Розничного возврата
        в составе JSON API является ключевое слово retailsalesreturn.

        :param retailsalesreturn_id: Идентификатор Retailsalesreturn
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retail-sales-return
        """
        call = GetRetailsalesreturn(
            retailsalesreturn_id=retailsalesreturn_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_retailsalesreturns(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Retailsalesreturn]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных возвратах,
        запрашивать списки Розничных возвратов и сведения по отдельным Розничным
        возвратам. Позициями Розничных возвратов  можно управлять как в составе
        отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Розничного возврата. Кодом сущности для Розничного возврата
        в составе JSON API является ключевое слово retailsalesreturn.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retail-sales-return
        """
        call = GetRetailsalesreturns(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_retailshift(
        self,
        retailshift_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Retailshift:
        """
        Средствами JSON API можно запрашивать списки Розничных смен и сведения по
        отдельным Розничным сменам. Кодом сущности для Розничной смены в составе JSON
        API является ключевое слово retailshift.

        :param retailshift_id: Идентификатор Retailshift
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retailshift
        """
        call = GetRetailshift(
            retailshift_id=retailshift_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_retailshifts(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Retailshift]:
        """
        Средствами JSON API можно запрашивать списки Розничных смен и сведения по
        отдельным Розничным сменам. Кодом сущности для Розничной смены в составе JSON
        API является ключевое слово retailshift.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retailshift
        """
        call = GetRetailshifts(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_retailstore(
        self,
        retailstore_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Retailstore:
        """
        Средствами JSON API можно создавать и обновлять сведения о Точках продаж,
        запрашивать списки Точек продаж и сведения по отдельным Точкам продаж. Также
        можно получить доступ к специальному ресурсу для управления кассирами точки
        продаж. Кодом сущности для точки продаж в составе JSON API является ключевое
        слово retailstore. Больше о точках продаж и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке в разделе "Создание
        точки продаж в основном интерфейсе". По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать

        :param retailstore_id: Идентификатор Retailstore
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/retailstore
        """
        call = GetRetailstore(
            retailstore_id=retailstore_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_retailstores(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Retailstore]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Точках продаж,
        запрашивать списки Точек продаж и сведения по отдельным Точкам продаж. Также
        можно получить доступ к специальному ресурсу для управления кассирами точки
        продаж. Кодом сущности для точки продаж в составе JSON API является ключевое
        слово retailstore. Больше о точках продаж и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке в разделе "Создание
        точки продаж в основном интерфейсе". По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/retailstore
        """
        call = GetRetailstores(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_retireorder(
        self,
        retireorder_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Retireorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выводе кодов
        маркировки из оборота, а также запрашивать списки документов и информацию о
        конкретных Выводах. Позициями можно управлять как в составе документа Вывода,
        так и отдельно - с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Вывода из оборота в составе JSON API является ключевое слово
        retireorder. Больше о Выводах кодов из оборота можно прочитать здесь.

        :param retireorder_id: Идентификатор Retireorder
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retireorder
        """
        call = GetRetireorder(
            retireorder_id=retireorder_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_retireorders(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Retireorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выводе кодов
        маркировки из оборота, а также запрашивать списки документов и информацию о
        конкретных Выводах. Позициями можно управлять как в составе документа Вывода,
        так и отдельно - с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Вывода из оборота в составе JSON API является ключевое слово
        retireorder. Больше о Выводах кодов из оборота можно прочитать здесь.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retireorder
        """
        call = GetRetireorders(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_role(
        self,
        role_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Role:
        """
        Кодом сущности для Пользовательской роли в составе JSON API является ключевое
        слово role.

        :param role_id: Идентификатор Role
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/custom-role
        """
        call = GetRole(
            role_id=role_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
            order=order,
        )
        return await self(call)

    async def get_saleplatform(
        self,
        saleplatform_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Saleplatform:
        """
        Средствами JSON API можно просматривать сведения о Площадках для продаж,
        запрашивать списки Площадок для продаж и сведения по отдельным Площадкам для
        продаж. Кодом сущности для Площадки для продаж в составе JSON API является
        ключевое слово saleplatform.

        :param saleplatform_id: Идентификатор Saleplatform
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleplatform
        """
        call = GetSaleplatform(
            saleplatform_id=saleplatform_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_saleplatforms(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Saleplatform]:
        """
        Средствами JSON API можно просматривать сведения о Площадках для продаж,
        запрашивать списки Площадок для продаж и сведения по отдельным Площадкам для
        продаж. Кодом сущности для Площадки для продаж в составе JSON API является
        ключевое слово saleplatform.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleplatform
        """
        call = GetSaleplatforms(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_saleschannel(
        self,
        saleschannel_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Saleschannel:
        """
        Средствами JSON API можно создавать и обновлять сведения о Каналах продаж,
        запрашивать списки Каналов продаж и сведения по отдельным Каналам продаж. Кодом
        сущности для Канала продаж в составе JSON API является ключевое слово
        saleschannel. Больше о Каналах продаж и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param saleschannel_id: Идентификатор Saleschannel
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleschannel
        """
        call = GetSaleschannel(
            saleschannel_id=saleschannel_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_saleschannels(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Saleschannel]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Каналах продаж,
        запрашивать списки Каналов продаж и сведения по отдельным Каналам продаж. Кодом
        сущности для Канала продаж в составе JSON API является ключевое слово
        saleschannel. Больше о Каналах продаж и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleschannel
        """
        call = GetSaleschannels(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_salesreturn(
        self,
        salesreturn_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Salesreturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        покупателей, запрашивать списки Возвратов покупателей и сведения по отдельным
        Возвратам покупателей. Позициями Возвратов покупателей можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата покупателя. Кодом сущности для Возврата покупателя
        в составе JSON API является ключевое слово salesreturn.

        :param salesreturn_id: Идентификатор Salesreturn
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/sales-return
        """
        call = GetSalesreturn(
            salesreturn_id=salesreturn_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_salesreturns(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Salesreturn]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        покупателей, запрашивать списки Возвратов покупателей и сведения по отдельным
        Возвратам покупателей. Позициями Возвратов покупателей можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата покупателя. Кодом сущности для Возврата покупателя
        в составе JSON API является ключевое слово salesreturn.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/sales-return
        """
        call = GetSalesreturns(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_service(
        self,
        service_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Service:
        """
        Средствами JSON API можно создавать и обновлять сведения об Услугах, запрашивать
        списки Услуг и сведения по отдельным Услугам. Кодом сущности для Услуги в
        составе JSON API является ключевое слово service. Услуга - специальная
        разновидность товара, без закупочной цены и упаковок. Больше о Товарах и работе
        с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад.

        :param service_id: Идентификатор Service
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/service
        """
        call = GetService(
            service_id=service_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_services(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Service]:
        """
        Средствами JSON API можно создавать и обновлять сведения об Услугах, запрашивать
        списки Услуг и сведения по отдельным Услугам. Кодом сущности для Услуги в
        составе JSON API является ключевое слово service. Услуга - специальная
        разновидность товара, без закупочной цены и упаковок. Больше о Товарах и работе
        с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/service
        """
        call = GetServices(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_stock(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        group_by: str | None = None,
        include_related: bool | None = None,
        order: str | None = None,
    ) -> MetaArray[Stock]:
        """
        Расширенный отчёт об остатках.

        :param filters: Фильтрация выборки
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param group_by: Группировка: product, variant (по умолчанию), consignment
        :param include_related: Вывод остатков по модификациям и партиям товаров
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-stock
        """
        call = GetStock(
            limit=limit,
            offset=offset,
            filters=filters,
            group_by=group_by,
            include_related=include_related,
            order=order,
        )
        return await self(call)

    async def get_stock_current(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        changed_since: str | None = None,
        stock_type: str | None = None,
        include: str | None = None,
    ) -> list[StockCurrent]:
        """
        Краткий отчет об остатках (текущие остатки).

        :param filters: Фильтрация по assortmentId и storeId
        :param changed_since: Остатки, изменившиеся с указанного момента
            (формат: 'гггг-мм-дд чч:мм:сс')
        :param stock_type: Тип остатка: stock, freeStock, quantity, reserve, inTransit
        :param include: Передайте 'zeroLines' для вывода нулевых остатков

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-stock
        """
        call = GetStockCurrent(
            filters=filters,
            changed_since=changed_since,
            stock_type=stock_type,
            include=include,
        )
        return await self(call)

    async def get_store(
        self,
        store_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Store:
        """
        Кодом сущности для Складов в составе JSON API является ключевое слово store.

        :param store_id: Идентификатор Store
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store
        """
        call = GetStore(
            store_id=store_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_stores(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Store]:
        """
        Кодом сущности для Складов в составе JSON API является ключевое слово store.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store
        """
        call = GetStores(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_supplies(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Supply]:
        """
        Средствами JSON API можно создавать и обновлять сведения об Приемках,
        запрашивать списки Приемок и сведения по отдельным Приемкам. Позициями Приемок
        можно управлять как в составе отдельной Приемки, так и отдельно - с помощью
        специальных ресурсов для управления позициями Приемки. Кодом сущности для
        Приемки в составе JSON API является ключевое слово supply. Больше об Приемках и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply
        """
        call = GetSupplies(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_supply(
        self,
        supply_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Supply:
        """
        Средствами JSON API можно создавать и обновлять сведения об Приемках,
        запрашивать списки Приемок и сведения по отдельным Приемкам. Позициями Приемок
        можно управлять как в составе отдельной Приемки, так и отдельно - с помощью
        специальных ресурсов для управления позициями Приемки. Кодом сущности для
        Приемки в составе JSON API является ключевое слово supply. Больше об Приемках и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке.

        :param supply_id: Идентификатор Supply
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply
        """
        call = GetSupply(
            supply_id=supply_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_task(
        self,
        task_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Task:
        """
        Средствами JSON API можно создавать и обновлять сведения о задачах, запрашивать
        списки задач и сведения по отдельным задачам. Кодом сущности для задачи в
        составе JSON API является ключевое слово task. Больше о задачах и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param task_id: Идентификатор Task
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/task
        """
        call = GetTask(
            task_id=task_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
            order=order,
        )
        return await self(call)

    async def get_tasks(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Task]:
        """
        Средствами JSON API можно создавать и обновлять сведения о задачах, запрашивать
        списки задач и сведения по отдельным задачам. Кодом сущности для задачи в
        составе JSON API является ключевое слово task. Больше о задачах и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/task
        """
        call = GetTasks(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_taxrate(
        self,
        taxrate_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Taxrate:
        """
        Средствами JSON API можно создавать и обновлять сведения о налоговых ставках,
        запрашивать списки ставок и сведения по отдельным ставкам. Кодом сущности для
        налоговой ставки в составе JSON API является ключевое слово taxrate. По данной
        сущности можно осуществлять контекстный поиск с помощью специального параметра
        search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается
        от других тем, что поиск не префиксный, без токенизации и идет только по одному
        полю одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param taxrate_id: Идентификатор Taxrate
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/taxrate
        """
        call = GetTaxrate(
            taxrate_id=taxrate_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_taxrates(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Taxrate]:
        """
        Средствами JSON API можно создавать и обновлять сведения о налоговых ставках,
        запрашивать списки ставок и сведения по отдельным ставкам. Кодом сущности для
        налоговой ставки в составе JSON API является ключевое слово taxrate. По данной
        сущности можно осуществлять контекстный поиск с помощью специального параметра
        search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается
        от других тем, что поиск не префиксный, без токенизации и идет только по одному
        полю одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/taxrate
        """
        call = GetTaxrates(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_thing(
        self,
        thing_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Thing:
        """
        Средствами JSON API можно запрашивать списки Серийных номеров и сведения по
        отдельным Серийным номерам. Кодом сущности для Серийного номера в составе JSON
        API является ключевое слово thing.

        :param thing_id: Идентификатор Thing
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/thing
        """
        call = GetThing(
            thing_id=thing_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_things(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Thing]:
        """
        Средствами JSON API можно запрашивать списки Серийных номеров и сведения по
        отдельным Серийным номерам. Кодом сущности для Серийного номера в составе JSON
        API является ключевое слово thing.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/thing
        """
        call = GetThings(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_uom(
        self,
        uom_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Uom:
        """
        Кодом сущности для Единиц измерения в составе JSON API является ключевое слово
        uom. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param uom_id: Идентификатор Uom
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/uom
        """
        call = GetUom(
            uom_id=uom_id, limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def get_uoms(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Uom]:
        """
        Кодом сущности для Единиц измерения в составе JSON API является ключевое слово
        uom. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/uom
        """
        call = GetUoms(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_usersettings(
        self,
        usersettings_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Usersettings:
        """
        Кодом сущности для Настройки пользователя в составе JSON API является ключевое
        слово usersettings.

        :param usersettings_id: Идентификатор Usersettings
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/usersettings
        """
        call = GetUsersettings(
            usersettings_id=usersettings_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_variant(
        self,
        variant_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Variant:
        """
        Средствами JSON API можно создавать и обновлять сведения о Модификациях товаров,
        запрашивать списки Модификаций товаров и сведения по отдельным Модификациям.
        Кодом сущности для Модификации в составе JSON API является ключевое слово
        variant. Больше о Модификациях товаров и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке, а также больше о
        работе с товарами здесь. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск
        с параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param variant_id: Идентификатор Variant
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/variant
        """
        call = GetVariant(
            variant_id=variant_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_variants(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Variant]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Модификациях товаров,
        запрашивать списки Модификаций товаров и сведения по отдельным Модификациям.
        Кодом сущности для Модификации в составе JSON API является ключевое слово
        variant. Больше о Модификациях товаров и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке, а также больше о
        работе с товарами здесь. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск
        с параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/variant
        """
        call = GetVariants(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_webhook(
        self,
        webhook_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Webhook:
        """
        Пример того, в каком виде будут передаваться данные:

        :param webhook_id: Идентификатор Webhook
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhook
        """
        call = GetWebhook(
            webhook_id=webhook_id, limit=limit, offset=offset, expand=expand, filters=filters
        )
        return await self(call)

    async def get_webhooks(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Webhook]:
        """
        Пример того, в каком виде будут передаваться данные:

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhook
        """
        call = GetWebhooks(limit=limit, offset=offset, expand=expand, filters=filters, order=order)
        return await self(call)

    async def get_webhookstock(
        self,
        webhookstock_id: str,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> Webhookstock:
        """
        > Пример того, в каком виде будут передаваться данные: POST
        https://example.com/webhook_path?requestId=640569eb-522d-427a-b07e-fa757c5d4217

        :param webhookstock_id: Идентификатор Webhookstock
        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhookstock
        """
        call = GetWebhookstock(
            webhookstock_id=webhookstock_id,
            limit=limit,
            offset=offset,
            expand=expand,
            filters=filters,
        )
        return await self(call)

    async def get_webhookstocks(
        self,
        filters: Condition | Sequence[Condition] | None = None,
        limit: int | None = 1000,
        offset: int | None = None,
        expand: Sequence[str] | str | None = None,
        order: str | None = None,
    ) -> MetaArray[Webhookstock]:
        """
        > Пример того, в каком виде будут передаваться данные: POST
        https://example.com/webhook_path?requestId=640569eb-522d-427a-b07e-fa757c5d4217

        :param filters: Фильтрация выборки с помощью параметра filter
        :param limit: Максимальное количество элементов в выданном списке. Максимум 1000.
        :param offset: Отступ в выданном списке
        :param expand: Замена ссылок объектами через expand. Максимальный уровень вложенности: 3
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhookstock
        """
        call = GetWebhookstocks(
            limit=limit, offset=offset, expand=expand, filters=filters, order=order
        )
        return await self(call)

    async def update_bonusprogram(
        self, bonusprogram_id: str, bonusprogram: Bonusprogram
    ) -> Bonusprogram:
        """
        Кодом сущности для Бонусных программ в составе JSON API является ключевое слово
        bonusprogram. Перед работой со скидками настоятельно рекомендуем вам прочитать
        вот эту статью на портале поддержки МоегоСклада.

        :param bonusprogram_id: Идентификатор Bonusprogram
        :param bonusprogram: Объект Bonusprogram с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-program
        """
        call = UpdateBonusprogram(bonusprogram_id=bonusprogram_id, data=bonusprogram)
        return await self(call)

    async def update_bonustransaction(
        self, bonustransaction_id: str, bonustransaction: Bonustransaction
    ) -> Bonustransaction:
        """
        Средствами JSON API можно создавать и обновлять сведения о Бонусных операциях,
        запрашивать списки Бонусных операций и сведения по отдельным Бонусым операциям.
        Кодом сущности для Бонусной операции в составе JSON API является ключевое слово
        bonustransaction.

        :param bonustransaction_id: Идентификатор Bonustransaction
        :param bonustransaction: Объект Bonustransaction с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-operation
        """
        call = UpdateBonustransaction(
            bonustransaction_id=bonustransaction_id, data=bonustransaction
        )
        return await self(call)

    async def update_bonustransactions(
        self, bonustransactions: list[Bonustransaction]
    ) -> list[Bonustransaction]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Бонусных операциях,
        запрашивать списки Бонусных операций и сведения по отдельным Бонусым операциям.
        Кодом сущности для Бонусной операции в составе JSON API является ключевое слово
        bonustransaction.

        :param bonustransactions: Список объектов Bonustransaction для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-operation
        """
        call = UpdateBonustransactions(data=bonustransactions)
        return await self(call)

    async def update_bundle(self, bundle_id: str, bundle: Bundle) -> Bundle:
        """
        Средствами JSON API можно создавать и обновлять сведения о Комплектах,
        запрашивать списки Комплектов и сведения по отдельным Комплектам. Кодом сущности
        для Комплекта в составе JSON API является ключевое слово bundle.

        :param bundle_id: Идентификатор Bundle
        :param bundle: Объект Bundle с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bundle
        """
        call = UpdateBundle(bundle_id=bundle_id, data=bundle)
        return await self(call)

    async def update_bundles(self, bundles: list[Bundle]) -> list[Bundle]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Комплектах,
        запрашивать списки Комплектов и сведения по отдельным Комплектам. Кодом сущности
        для Комплекта в составе JSON API является ключевое слово bundle.

        :param bundles: Список объектов Bundle для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bundle
        """
        call = UpdateBundles(data=bundles)
        return await self(call)

    async def update_cashin(self, cashin_id: str, cashin: Cashin) -> Cashin:
        """
        Средствами JSON API можно создавать и обновлять сведения о Приходном ордере,
        запрашивать списки Приходных ордеров и сведения по отдельным Приходным
        ордерам.Кодом сущности для Приходного ордера в составе JSON API является
        ключевое слово cashin.

        :param cashin_id: Идентификатор Cashin
        :param cashin: Объект Cashin с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashin
        """
        call = UpdateCashin(cashin_id=cashin_id, data=cashin)
        return await self(call)

    async def update_cashins(self, cashins: list[Cashin]) -> list[Cashin]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Приходном ордере,
        запрашивать списки Приходных ордеров и сведения по отдельным Приходным
        ордерам.Кодом сущности для Приходного ордера в составе JSON API является
        ключевое слово cashin.

        :param cashins: Список объектов Cashin для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashin
        """
        call = UpdateCashins(data=cashins)
        return await self(call)

    async def update_cashout(self, cashout_id: str, cashout: Cashout) -> Cashout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Расходном ордере,
        запрашивать списки Расходных ордеров  и сведения по отдельным Расходных ордеров.
        Кодом сущности для Расходного ордера  в составе JSON API является ключевое слово
        cashout.

        :param cashout_id: Идентификатор Cashout
        :param cashout: Объект Cashout с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashout
        """
        call = UpdateCashout(cashout_id=cashout_id, data=cashout)
        return await self(call)

    async def update_cashouts(self, cashouts: list[Cashout]) -> list[Cashout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Расходном ордере,
        запрашивать списки Расходных ордеров  и сведения по отдельным Расходных ордеров.
        Кодом сущности для Расходного ордера  в составе JSON API является ключевое слово
        cashout.

        :param cashouts: Список объектов Cashout для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashout
        """
        call = UpdateCashouts(data=cashouts)
        return await self(call)

    async def update_commissionreportin(
        self, commissionreportin_id: str, commissionreportin: Commissionreportin
    ) -> Commissionreportin:
        """
        Средствами JSON API можно создавать и обновлять сведения о Полученных отчетах
        комиссионера, запрашивать списки Полученных отчетов комиссионера и сведения по
        отдельным Полученным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Полученного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportin. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportin_id: Идентификатор Commissionreportin
        :param commissionreportin: Объект Commissionreportin с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportin
        """
        call = UpdateCommissionreportin(
            commissionreportin_id=commissionreportin_id, data=commissionreportin
        )
        return await self(call)

    async def update_commissionreportins(
        self, commissionreportins: list[Commissionreportin]
    ) -> list[Commissionreportin]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Полученных отчетах
        комиссионера, запрашивать списки Полученных отчетов комиссионера и сведения по
        отдельным Полученным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Полученного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportin. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportins: Список объектов Commissionreportin для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportin
        """
        call = UpdateCommissionreportins(data=commissionreportins)
        return await self(call)

    async def update_commissionreportouts(
        self, commissionreportouts: list[Commissionreportout]
    ) -> list[Commissionreportout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выданных отчетах
        комиссионера, запрашивать списки Выданных отчетов комиссионера и сведения по
        отдельным Выданным отчетам комиссионера. Позициями отчетов комиссионера можно
        управлять как в составе отдельного отчета, так и с помощью специальных ресурсов
        для управления позициями. Кодом сущности для Выданного отчета комиссионера в
        составе JSON API является ключевое слово commissionreportout. Больше об отчетах
        комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param commissionreportouts: Список объектов Commissionreportout для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportout
        """
        call = UpdateCommissionreportouts(data=commissionreportouts)
        return await self(call)

    async def update_consignment(
        self, consignment_id: str, consignment: Consignment
    ) -> Consignment:
        """
        Кодом сущности для Партии в составе JSON API является ключевое слово
        consignment. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param consignment_id: Идентификатор Consignment
        :param consignment: Объект Consignment с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/consignment
        """
        call = UpdateConsignment(consignment_id=consignment_id, data=consignment)
        return await self(call)

    async def update_consignments(self, consignments: list[Consignment]) -> list[Consignment]:
        """
        Кодом сущности для Партии в составе JSON API является ключевое слово
        consignment. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param consignments: Список объектов Consignment для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/consignment
        """
        call = UpdateConsignments(data=consignments)
        return await self(call)

    async def update_contract(self, contract_id: str, contract: Contract) -> Contract:
        """
        Средствами JSON API можно создавать и обновлять сведения о Договорах,
        запрашивать списки Договоров и сведения по отдельным Договорам. Кодом сущности
        для Договора в составе JSON API является ключевое слово contract. Больше о
        Договорах и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
        не префиксный, без токенизации и идет только по одному полю одновременно. Ищет
        такие строки, в которые входит значение строки поиска.

        :param contract_id: Идентификатор Contract
        :param contract: Объект Contract с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contract
        """
        call = UpdateContract(contract_id=contract_id, data=contract)
        return await self(call)

    async def update_contracts(self, contracts: list[Contract]) -> list[Contract]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Договорах,
        запрашивать списки Договоров и сведения по отдельным Договорам. Кодом сущности
        для Договора в составе JSON API является ключевое слово contract. Больше о
        Договорах и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
        не префиксный, без токенизации и идет только по одному полю одновременно. Ищет
        такие строки, в которые входит значение строки поиска.

        :param contracts: Список объектов Contract для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contract
        """
        call = UpdateContracts(data=contracts)
        return await self(call)

    async def update_counterparties(
        self, counterparties: list[Counterparty]
    ) -> list[Counterparty]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Контрагентах,
        запрашивать списки Контрагентов и сведения по отдельным Контрагентам. Счетами
        Контрагента и его контактными лицами можно управлять как в составе отдельного
        Контрагента, так и отдельно - с помощью специальных ресурсов для управления
        счетами и контактными лицами Контрагента. Кодом сущности для Контрагента в
        составе JSON API является ключевое слово counterparty. Больше о Контрагентах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке. По данной сущности можно осуществлять контекстный поиск с
        помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный и без
        токенизации. Ищет такие строки, в которые входит значение строки поиска.

        :param counterparties: Список объектов Counterparty для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty
        """
        call = UpdateCounterparties(data=counterparties)
        return await self(call)

    async def update_counterparty(
        self, counterparty_id: str, counterparty: Counterparty
    ) -> Counterparty:
        """
        Средствами JSON API можно создавать и обновлять сведения о Контрагентах,
        запрашивать списки Контрагентов и сведения по отдельным Контрагентам. Счетами
        Контрагента и его контактными лицами можно управлять как в составе отдельного
        Контрагента, так и отдельно - с помощью специальных ресурсов для управления
        счетами и контактными лицами Контрагента. Кодом сущности для Контрагента в
        составе JSON API является ключевое слово counterparty. Больше о Контрагентах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке. По данной сущности можно осуществлять контекстный поиск с
        помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный и без
        токенизации. Ищет такие строки, в которые входит значение строки поиска.

        :param counterparty_id: Идентификатор Counterparty
        :param counterparty: Объект Counterparty с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty
        """
        call = UpdateCounterparty(counterparty_id=counterparty_id, data=counterparty)
        return await self(call)

    async def update_counterpartyadjustment(
        self, counterpartyadjustment_id: str, counterpartyadjustment: Counterpartyadjustment
    ) -> Counterpartyadjustment:
        """
        Средствами JSON API можно создавать и обновлять сведения о Корректировках
        взаиморасчетов, запрашивать списки Корректировок взаиморасчетов и сведения по
        отдельным Корректировкам взаиморасчетов. Кодом сущности для Корректировки
        взаиморасчетов в составе JSON API является ключевое слово
        counterpartyadjustment. Больше о Корректировках взаиморасчетов и работе с ними в
        основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param counterpartyadjustment_id: Идентификатор Counterpartyadjustment
        :param counterpartyadjustment: Объект Counterpartyadjustment с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/counterpartyadjustment
        """
        call = UpdateCounterpartyadjustment(
            counterpartyadjustment_id=counterpartyadjustment_id, data=counterpartyadjustment
        )
        return await self(call)

    async def update_counterpartyadjustments(
        self, counterpartyadjustments: list[Counterpartyadjustment]
    ) -> list[Counterpartyadjustment]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Корректировках
        взаиморасчетов, запрашивать списки Корректировок взаиморасчетов и сведения по
        отдельным Корректировкам взаиморасчетов. Кодом сущности для Корректировки
        взаиморасчетов в составе JSON API является ключевое слово
        counterpartyadjustment. Больше о Корректировках взаиморасчетов и работе с ними в
        основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param counterpartyadjustments: Список объектов Counterpartyadjustment для массового
            обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/counterpartyadjustment
        """
        call = UpdateCounterpartyadjustments(data=counterpartyadjustments)
        return await self(call)

    async def update_countries(self, countries: list[Country]) -> list[Country]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Странах, запрашивать
        списки Стран и сведения по отдельным Странам. Кодом сущности для Страны в
        составе JSON API является ключевое слово country. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param countries: Список объектов Country для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/country
        """
        call = UpdateCountries(data=countries)
        return await self(call)

    async def update_country(self, country_id: str, country: Country) -> Country:
        """
        Средствами JSON API можно создавать и обновлять сведения о Странах, запрашивать
        списки Стран и сведения по отдельным Странам. Кодом сущности для Страны в
        составе JSON API является ключевое слово country. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param country_id: Идентификатор Country
        :param country: Объект Country с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/country
        """
        call = UpdateCountry(country_id=country_id, data=country)
        return await self(call)

    async def update_currencies(self, currencies: list[Currency]) -> list[Currency]:
        """
        Средствами JSON API можно запрашивать списки валют и сведения по отдельным
        валютам, а также создавать новые и обновлять сведения по уже существующим
        валютам. Кодом сущности для валют в составе JSON API является ключевое слово
        currency. Больше о валютах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param currencies: Список объектов Currency для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/currency
        """
        call = UpdateCurrencies(data=currencies)
        return await self(call)

    async def update_currency(self, currency_id: str, currency: Currency) -> Currency:
        """
        Средствами JSON API можно запрашивать списки валют и сведения по отдельным
        валютам, а также создавать новые и обновлять сведения по уже существующим
        валютам. Кодом сущности для валют в составе JSON API является ключевое слово
        currency. Больше о валютах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param currency_id: Идентификатор Currency
        :param currency: Объект Currency с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/currency
        """
        call = UpdateCurrency(currency_id=currency_id, data=currency)
        return await self(call)

    async def update_customentity(
        self, customentity_id: str, customentity: Customentity
    ) -> Customentity:
        """
        Кодом сущности для Пользовательских справочников в составе JSON API является
        ключевое слово customentity.

        :param customentity_id: Идентификатор Customentity
        :param customentity: Объект Customentity с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity
        """
        call = UpdateCustomentity(customentity_id=customentity_id, data=customentity)
        return await self(call)

    async def update_customerorder(
        self, customerorder_id: str, customerorder: Customerorder
    ) -> Customerorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах покупателя,
        запрашивать списки Заказов и сведения по отдельным Заказам покупателей.
        Позициями Заказов можно управлять как в составе отдельного Заказа покупателя,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа покупателя в составе JSON API является ключевое слово
        customerorder. Больше о Заказах покупателей и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. Также в
        Заказе покупателя поддерживается протокол оповещения об изменениях виджетов
        вендоров - change-handler. Подробнее см. в документации для вендоров о виджетах.

        :param customerorder_id: Идентификатор Customerorder
        :param customerorder: Объект Customerorder с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/customerOrder
        """
        call = UpdateCustomerorder(customerorder_id=customerorder_id, data=customerorder)
        return await self(call)

    async def update_customerorders(
        self, customerorders: list[Customerorder]
    ) -> list[Customerorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах покупателя,
        запрашивать списки Заказов и сведения по отдельным Заказам покупателей.
        Позициями Заказов можно управлять как в составе отдельного Заказа покупателя,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа покупателя в составе JSON API является ключевое слово
        customerorder. Больше о Заказах покупателей и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. Также в
        Заказе покупателя поддерживается протокол оповещения об изменениях виджетов
        вендоров - change-handler. Подробнее см. в документации для вендоров о виджетах.

        :param customerorders: Список объектов Customerorder для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/customerOrder
        """
        call = UpdateCustomerorders(data=customerorders)
        return await self(call)

    async def update_demand(self, demand_id: str, demand: Demand) -> Demand:
        """
        Средствами JSON API можно создавать и обновлять сведения об Отгрузках,
        запрашивать списки Отгрузок и сведения по отдельным Отгрузкам. Позициями
        Отгрузок можно управлять как в составе отдельной Отгрузки, так и отдельно - с
        помощью специальных ресурсов для управления позициями Отгрузки. Кодом сущности
        для Отгрузки в составе JSON API является ключевое слово demand. Больше об
        Отгрузках и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param demand_id: Идентификатор Demand
        :param demand: Объект Demand с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand
        """
        call = UpdateDemand(demand_id=demand_id, data=demand)
        return await self(call)

    async def update_demands(self, demands: list[Demand]) -> list[Demand]:
        """
        Средствами JSON API можно создавать и обновлять сведения об Отгрузках,
        запрашивать списки Отгрузок и сведения по отдельным Отгрузкам. Позициями
        Отгрузок можно управлять как в составе отдельной Отгрузки, так и отдельно - с
        помощью специальных ресурсов для управления позициями Отгрузки. Кодом сущности
        для Отгрузки в составе JSON API является ключевое слово demand. Больше об
        Отгрузках и работе с ними в основном интерфейсе вы можете прочитать в нашей
        службе поддержки по  этой ссылке.

        :param demands: Список объектов Demand для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand
        """
        call = UpdateDemands(data=demands)
        return await self(call)

    async def update_discount(self, discount_id: str, discount: Discount) -> Discount:
        """
        Кодом сущности для Скидок в составе JSON API является ключевое слово discount.
        Операции создания, изменения и удаления не поддерживаются. Перед работой со
        скидками настоятельно рекомендуем вам прочитать вот эту статью на портале
        поддержки МоегоСклада.

        :param discount_id: Идентификатор Discount
        :param discount: Объект Discount с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/discount
        """
        call = UpdateDiscount(discount_id=discount_id, data=discount)
        return await self(call)

    async def update_emissionorder(
        self, emissionorder_id: str, emissionorder: Emissionorder
    ) -> Emissionorder:
        """
        Для создания/изменения Заказов кодов маркировки необходима тарифная опция
        Маркировка для аккаунтов из RU региона и расширение Честный знак для остальных
        регионов.

        :param emissionorder_id: Идентификатор Emissionorder
        :param emissionorder: Объект Emissionorder с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder
        """
        call = UpdateEmissionorder(emissionorder_id=emissionorder_id, data=emissionorder)
        return await self(call)

    async def update_emissionorders(
        self, emissionorders: list[Emissionorder]
    ) -> list[Emissionorder]:
        """
        Для создания/изменения Заказов кодов маркировки необходима тарифная опция
        Маркировка для аккаунтов из RU региона и расширение Честный знак для остальных
        регионов.

        :param emissionorders: Список объектов Emissionorder для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder
        """
        call = UpdateEmissionorders(data=emissionorders)
        return await self(call)

    async def update_employee(self, employee_id: str, employee: Employee) -> Employee:
        """
        Средствами JSON API можно запрашивать списки Сотрудников и сведения по отдельным
        Сотрудникам. Кодом сущности для Сотрудника в составе JSON API является ключевое
        слово employee. Больше о Сотрудниках и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке.

        :param employee_id: Идентификатор Employee
        :param employee: Объект Employee с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/employee
        """
        call = UpdateEmployee(employee_id=employee_id, data=employee)
        return await self(call)

    async def update_enter(self, enter_id: str, enter: Enter) -> Enter:
        """
        Средствами JSON API можно создавать и обновлять сведения об Оприходованиях,
        запрашивать списки Оприходований и сведения по отдельным Оприходованиям.
        Позициями Оприходований можно управлять как в составе отдельного Оприходования,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Оприходования. Кодом сущности для Оприходования в составе JSON API является
        ключевое слово enter. Больше об Оприходованиях можно прочитать этой ссылке.

        :param enter_id: Идентификатор Enter
        :param enter: Объект Enter с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/enter
        """
        call = UpdateEnter(enter_id=enter_id, data=enter)
        return await self(call)

    async def update_enters(self, enters: list[Enter]) -> list[Enter]:
        """
        Средствами JSON API можно создавать и обновлять сведения об Оприходованиях,
        запрашивать списки Оприходований и сведения по отдельным Оприходованиям.
        Позициями Оприходований можно управлять как в составе отдельного Оприходования,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Оприходования. Кодом сущности для Оприходования в составе JSON API является
        ключевое слово enter. Больше об Оприходованиях можно прочитать этой ссылке.

        :param enters: Список объектов Enter для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/enter
        """
        call = UpdateEnters(data=enters)
        return await self(call)

    async def update_expenseitem(
        self, expenseitem_id: str, expenseitem: Expenseitem
    ) -> Expenseitem:
        """
        Средствами JSON API можно запрашивать списки Статей расходов и сведения по
        отдельным Статьям расходов. Кодом сущности для Статей расходов в составе JSON
        API является ключевое слово expenseitem. Больше о Статьях расходов и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param expenseitem_id: Идентификатор Expenseitem
        :param expenseitem: Объект Expenseitem с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/expenseitem
        """
        call = UpdateExpenseitem(expenseitem_id=expenseitem_id, data=expenseitem)
        return await self(call)

    async def update_expenseitems(self, expenseitems: list[Expenseitem]) -> list[Expenseitem]:
        """
        Средствами JSON API можно запрашивать списки Статей расходов и сведения по
        отдельным Статьям расходов. Кодом сущности для Статей расходов в составе JSON
        API является ключевое слово expenseitem. Больше о Статьях расходов и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param expenseitems: Список объектов Expenseitem для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/expenseitem
        """
        call = UpdateExpenseitems(data=expenseitems)
        return await self(call)

    async def update_facturein(self, facturein_id: str, facturein: Facturein) -> Facturein:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры полученные,
        запрашивать списки Счетов-фактур полученных, сведения по отдельным Счетам-
        фактурам и удалять Счета-фактуры. Счет-фактура может быть создана только на
        основании приемки или исходящего платежа, без документа-основания счет-фактуру
        создать нельзя.  Кодом сущности для Счета-фактуры полученного в составе JSON API
        является ключевое слово facturein.

        :param facturein_id: Идентификатор Facturein
        :param facturein: Объект Facturein с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/facturein
        """
        call = UpdateFacturein(facturein_id=facturein_id, data=facturein)
        return await self(call)

    async def update_factureins(self, factureins: list[Facturein]) -> list[Facturein]:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры полученные,
        запрашивать списки Счетов-фактур полученных, сведения по отдельным Счетам-
        фактурам и удалять Счета-фактуры. Счет-фактура может быть создана только на
        основании приемки или исходящего платежа, без документа-основания счет-фактуру
        создать нельзя.  Кодом сущности для Счета-фактуры полученного в составе JSON API
        является ключевое слово facturein.

        :param factureins: Список объектов Facturein для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/facturein
        """
        call = UpdateFactureins(data=factureins)
        return await self(call)

    async def update_factureout(self, factureout_id: str, factureout: Factureout) -> Factureout:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры выданные,
        запрашивать списки Счетов-фактур выданных, сведения по отдельным Счетам-фактурам
        и удалять Счета-фактуры. Счет-фактура может быть создана только на основании
        отгрузки, возврата поставщику или входящего платежа, без документа-основания
        счет-фактуру создать нельзя. Кодом сущности для Счета-фактуры выданного в
        составе JSON API является ключевое слово factureout.

        :param factureout_id: Идентификатор Factureout
        :param factureout: Объект Factureout с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/factureout
        """
        call = UpdateFactureout(factureout_id=factureout_id, data=factureout)
        return await self(call)

    async def update_factureouts(self, factureouts: list[Factureout]) -> list[Factureout]:
        """
        Средствами JSON API можно создавать и изменять Счета-фактуры выданные,
        запрашивать списки Счетов-фактур выданных, сведения по отдельным Счетам-фактурам
        и удалять Счета-фактуры. Счет-фактура может быть создана только на основании
        отгрузки, возврата поставщику или входящего платежа, без документа-основания
        счет-фактуру создать нельзя. Кодом сущности для Счета-фактуры выданного в
        составе JSON API является ключевое слово factureout.

        :param factureouts: Список объектов Factureout для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/factureout
        """
        call = UpdateFactureouts(data=factureouts)
        return await self(call)

    async def update_group(self, group_id: str, group: Group) -> Group:
        """
        Средствами JSON API можно запрашивать и изменять списки Отделов и сведения по
        отдельным Отделам. Кодом сущности для Отдела в составе JSON API является
        ключевое слово group. Больше об Отделах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по  этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param group_id: Идентификатор Group
        :param group: Объект Group с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group
        """
        call = UpdateGroup(group_id=group_id, data=group)
        return await self(call)

    async def update_internalorder(
        self, internalorder_id: str, internalorder: Internalorder
    ) -> Internalorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внутренних заказах,
        запрашивать списки Внутренних заказов и сведения по отдельным Внутренним
        заказам. Позициями Внутренних заказов можно управлять как в составе отдельного
        заказа, так и с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Внутреннего заказа в составе JSON API является ключевое слово
        internalorder.

        :param internalorder_id: Идентификатор Internalorder
        :param internalorder: Объект Internalorder с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/internalOrder
        """
        call = UpdateInternalorder(internalorder_id=internalorder_id, data=internalorder)
        return await self(call)

    async def update_internalorders(
        self, internalorders: list[Internalorder]
    ) -> list[Internalorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внутренних заказах,
        запрашивать списки Внутренних заказов и сведения по отдельным Внутренним
        заказам. Позициями Внутренних заказов можно управлять как в составе отдельного
        заказа, так и с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Внутреннего заказа в составе JSON API является ключевое слово
        internalorder.

        :param internalorders: Список объектов Internalorder для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/internalOrder
        """
        call = UpdateInternalorders(data=internalorders)
        return await self(call)

    async def update_inventories(self, inventories: list[Inventory]) -> list[Inventory]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Инвентаризации,
        запрашивать списки Инвентаризаций и сведения по отдельным Инвентаризациям.
        Позициями Инвентаризации можно управлять как в составе отдельной Инвентаризации,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Инвентаризации. Кодом сущности для Инвентаризации в составе JSON API является
        ключевое слово inventory. Больше о Инвентаризациях можно прочитать этой ссылке.

        :param inventories: Список объектов Inventory для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/inventory
        """
        call = UpdateInventories(data=inventories)
        return await self(call)

    async def update_inventory(self, inventory_id: str, inventory: Inventory) -> Inventory:
        """
        Средствами JSON API можно создавать и обновлять сведения о Инвентаризации,
        запрашивать списки Инвентаризаций и сведения по отдельным Инвентаризациям.
        Позициями Инвентаризации можно управлять как в составе отдельной Инвентаризации,
        так и отдельно - с помощью специальных ресурсов для управления позициями
        Инвентаризации. Кодом сущности для Инвентаризации в составе JSON API является
        ключевое слово inventory. Больше о Инвентаризациях можно прочитать этой ссылке.

        :param inventory_id: Идентификатор Inventory
        :param inventory: Объект Inventory с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/inventory
        """
        call = UpdateInventory(inventory_id=inventory_id, data=inventory)
        return await self(call)

    async def update_invoicein(self, invoicein_id: str, invoicein: Invoicein) -> Invoicein:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете поставщика,
        запрашивать списки Счетов и сведения по отдельным Счетам Поставщиков. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета поставщика в составе JSON API является ключевое слово invoicein. Больше о
        Счетах Поставщиков и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoicein_id: Идентификатор Invoicein
        :param invoicein: Объект Invoicein с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-in
        """
        call = UpdateInvoicein(invoicein_id=invoicein_id, data=invoicein)
        return await self(call)

    async def update_invoiceins(self, invoiceins: list[Invoicein]) -> list[Invoicein]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете поставщика,
        запрашивать списки Счетов и сведения по отдельным Счетам Поставщиков. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета поставщика в составе JSON API является ключевое слово invoicein. Больше о
        Счетах Поставщиков и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoiceins: Список объектов Invoicein для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-in
        """
        call = UpdateInvoiceins(data=invoiceins)
        return await self(call)

    async def update_invoiceout(self, invoiceout_id: str, invoiceout: Invoiceout) -> Invoiceout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете покупателю,
        запрашивать списки Счетов и сведения по отдельным Счетам Покупателям. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета покупателю в составе JSON API является ключевое слово invoiceout. Больше о
        Счетах Покупателям и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoiceout_id: Идентификатор Invoiceout
        :param invoiceout: Объект Invoiceout с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-out
        """
        call = UpdateInvoiceout(invoiceout_id=invoiceout_id, data=invoiceout)
        return await self(call)

    async def update_invoiceouts(self, invoiceouts: list[Invoiceout]) -> list[Invoiceout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Счете покупателю,
        запрашивать списки Счетов и сведения по отдельным Счетам Покупателям. Позициями
        Счетов можно управлять как в составе отдельного Счета, так и отдельно - с
        помощью специальных ресурсов для управления позициями Счета. Кодом сущности для
        Счета покупателю в составе JSON API является ключевое слово invoiceout. Больше о
        Счетах Покупателям и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке.

        :param invoiceouts: Список объектов Invoiceout для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-out
        """
        call = UpdateInvoiceouts(data=invoiceouts)
        return await self(call)

    async def update_loss(self, loss_id: str, loss: Loss) -> Loss:
        """
        Средствами JSON API можно создавать и обновлять сведения о Списаниях,
        запрашивать списки Списаний и сведения по отдельным Списаниям. Позициями
        Списаний можно управлять как в составе отдельного Списания, так и отдельно - с
        помощью специальных ресурсов для управления позициями Списания. Кодом сущности
        для Списания в составе JSON API является ключевое слово loss. Больше о Списаниях
        можно прочитать этой ссылке.

        :param loss_id: Идентификатор Loss
        :param loss: Объект Loss с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/loss
        """
        call = UpdateLoss(loss_id=loss_id, data=loss)
        return await self(call)

    async def update_losses(self, losses: list[Loss]) -> list[Loss]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Списаниях,
        запрашивать списки Списаний и сведения по отдельным Списаниям. Позициями
        Списаний можно управлять как в составе отдельного Списания, так и отдельно - с
        помощью специальных ресурсов для управления позициями Списания. Кодом сущности
        для Списания в составе JSON API является ключевое слово loss. Больше о Списаниях
        можно прочитать этой ссылке.

        :param losses: Список объектов Loss для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/loss
        """
        call = UpdateLosses(data=losses)
        return await self(call)

    async def update_move(self, move_id: str, move: Move) -> Move:
        """
        Средствами JSON API можно создавать и обновлять сведения о Перемещениях,
        запрашивать списки Перемещений и сведения по отдельным Перемещениям. Позициями
        Перемещений можно управлять как в составе отдельного Перемещения, так и отдельно
        - с помощью специальных ресурсов для управления позициями Перемещения. Кодом
        сущности для Перемещения в составе JSON API является ключевое слово move.

        :param move_id: Идентификатор Move
        :param move: Объект Move с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/move
        """
        call = UpdateMove(move_id=move_id, data=move)
        return await self(call)

    async def update_moves(self, moves: list[Move]) -> list[Move]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Перемещениях,
        запрашивать списки Перемещений и сведения по отдельным Перемещениям. Позициями
        Перемещений можно управлять как в составе отдельного Перемещения, так и отдельно
        - с помощью специальных ресурсов для управления позициями Перемещения. Кодом
        сущности для Перемещения в составе JSON API является ключевое слово move.

        :param moves: Список объектов Move для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/move
        """
        call = UpdateMoves(data=moves)
        return await self(call)

    async def update_organization(
        self, organization_id: str, organization: Organization
    ) -> Organization:
        """
        Средствами JSON API можно создавать и обновлять сведения о юрлицах, запрашивать
        списки юрлиц и сведения по отдельным юрлицам. С помощью специального ресурса
        можно управлять счетами отдельного юрлица. Кодом сущности для юрлица в составе
        JSON API является ключевое слово organization. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный и без токенизации. Ищет такие строки, в которые
        входит значение строки поиска

        :param organization_id: Идентификатор Organization
        :param organization: Объект Organization с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/organization
        """
        call = UpdateOrganization(organization_id=organization_id, data=organization)
        return await self(call)

    async def update_organizations(self, organizations: list[Organization]) -> list[Organization]:
        """
        Средствами JSON API можно создавать и обновлять сведения о юрлицах, запрашивать
        списки юрлиц и сведения по отдельным юрлицам. С помощью специального ресурса
        можно управлять счетами отдельного юрлица. Кодом сущности для юрлица в составе
        JSON API является ключевое слово organization. По данной сущности можно
        осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный и без токенизации. Ищет такие строки, в которые
        входит значение строки поиска

        :param organizations: Список объектов Organization для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/organization
        """
        call = UpdateOrganizations(data=organizations)
        return await self(call)

    async def update_paymentin(self, paymentin_id: str, paymentin: Paymentin) -> Paymentin:
        """
        Средствами JSON API можно создавать и обновлять сведения о платеже , запрашивать
        списки Входящих платежей и сведения по отдельным Входящим платежам. Кодом
        сущности для Входящего платежа в составе JSON API является ключевое слово
        paymentin. Больше о платежах  и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке.

        :param paymentin_id: Идентификатор Paymentin
        :param paymentin: Объект Paymentin с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-in
        """
        call = UpdatePaymentin(paymentin_id=paymentin_id, data=paymentin)
        return await self(call)

    async def update_paymentins(self, paymentins: list[Paymentin]) -> list[Paymentin]:
        """
        Средствами JSON API можно создавать и обновлять сведения о платеже , запрашивать
        списки Входящих платежей и сведения по отдельным Входящим платежам. Кодом
        сущности для Входящего платежа в составе JSON API является ключевое слово
        paymentin. Больше о платежах  и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по этой ссылке.

        :param paymentins: Список объектов Paymentin для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-in
        """
        call = UpdatePaymentins(data=paymentins)
        return await self(call)

    async def update_paymentout(self, paymentout_id: str, paymentout: Paymentout) -> Paymentout:
        """
        Средствами JSON API можно создавать и обновлять сведения о Исходящем платеже,
        запрашивать списки Исходящих платежей  и сведения по отдельным Исходящим
        платежам. Кодом сущности для Исходящего платежа  в составе JSON API является
        ключевое слово paymentout. Больше о платежа х и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param paymentout_id: Идентификатор Paymentout
        :param paymentout: Объект Paymentout с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-out
        """
        call = UpdatePaymentout(paymentout_id=paymentout_id, data=paymentout)
        return await self(call)

    async def update_paymentouts(self, paymentouts: list[Paymentout]) -> list[Paymentout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Исходящем платеже,
        запрашивать списки Исходящих платежей  и сведения по отдельным Исходящим
        платежам. Кодом сущности для Исходящего платежа  в составе JSON API является
        ключевое слово paymentout. Больше о платежа х и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param paymentouts: Список объектов Paymentout для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-out
        """
        call = UpdatePaymentouts(data=paymentouts)
        return await self(call)

    async def update_pricelist(self, pricelist_id: str, pricelist: Pricelist) -> Pricelist:
        """
        Средствами JSON API можно создавать и обновлять сведения о Прайс-листах,
        запрашивать списки Прайс-листов и сведения по отдельным Прайс-листам. Позициями
        Прайс-листов можно управлять как в составе отдельного Прайс-листа, так и
        отдельно - с помощью специальных ресурсов для управления позициями Прайс-листа.
        Кодом сущности для Прайс-листа в составе JSON API является ключевое слово
        pricelist. Больше о Прайс-листах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по  этой ссылке.

        :param pricelist_id: Идентификатор Pricelist
        :param pricelist: Объект Pricelist с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/pricelist
        """
        call = UpdatePricelist(pricelist_id=pricelist_id, data=pricelist)
        return await self(call)

    async def update_pricelists(self, pricelists: list[Pricelist]) -> list[Pricelist]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Прайс-листах,
        запрашивать списки Прайс-листов и сведения по отдельным Прайс-листам. Позициями
        Прайс-листов можно управлять как в составе отдельного Прайс-листа, так и
        отдельно - с помощью специальных ресурсов для управления позициями Прайс-листа.
        Кодом сущности для Прайс-листа в составе JSON API является ключевое слово
        pricelist. Больше о Прайс-листах и работе с ними в основном интерфейсе вы можете
        прочитать в нашей службе поддержки по  этой ссылке.

        :param pricelists: Список объектов Pricelist для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/pricelist
        """
        call = UpdatePricelists(data=pricelists)
        return await self(call)

    async def update_processing(self, processing_id: str, processing: Processing) -> Processing:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техоперациях,
        запрашивать списки Техопераций и сведения по отдельным Техоперациям. Позициями
        Техопераций можно управлять как в составе отдельной Техоперации, так и отдельно
        - с помощью специальных ресурсов для управления материалами и продуктами
        Техоперации. Кодом сущности для Техоперации в составе JSON API является ключевое
        слово processing. Больше о Техоперациях и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processing_id: Идентификатор Processing
        :param processing: Объект Processing с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processing
        """
        call = UpdateProcessing(processing_id=processing_id, data=processing)
        return await self(call)

    async def update_processingorder(
        self, processingorder_id: str, processingorder: Processingorder
    ) -> Processingorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах на
        производство, запрашивать списки Заказов и сведения по отдельным Заказам на
        производство. Позициями Заказов можно управлять как в составе отдельного Заказа
        на производство, так и отдельно - с помощью специальных ресурсов для управления
        позициями Заказа. Кодом сущности для Заказа на производство в составе JSON API
        является ключевое слово processingorder. Больше о Заказах на производство и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке.

        :param processingorder_id: Идентификатор Processingorder
        :param processingorder: Объект Processingorder с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processingorder
        """
        call = UpdateProcessingorder(processingorder_id=processingorder_id, data=processingorder)
        return await self(call)

    async def update_processingorders(
        self, processingorders: list[Processingorder]
    ) -> list[Processingorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах на
        производство, запрашивать списки Заказов и сведения по отдельным Заказам на
        производство. Позициями Заказов можно управлять как в составе отдельного Заказа
        на производство, так и отдельно - с помощью специальных ресурсов для управления
        позициями Заказа. Кодом сущности для Заказа на производство в составе JSON API
        является ключевое слово processingorder. Больше о Заказах на производство и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по этой ссылке.

        :param processingorders: Список объектов Processingorder для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processingorder
        """
        call = UpdateProcessingorders(data=processingorders)
        return await self(call)

    async def update_processingplan(
        self, processingplan_id: str, processingplan: Processingplan
    ) -> Processingplan:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техкартах,
        запрашивать списки Техкарт и сведения по отдельным Техкартам. Позициями Техкарт
        можно управлять как в составе отдельной Техкарты, так и отдельно - с помощью
        специальных ресурсов для управления материалами и продуктами Техкарты. Кодом
        сущности для Техкарты в составе JSON API является ключевое слово processingplan.
        Больше о Техкартах и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке.

        :param processingplan_id: Идентификатор Processingplan
        :param processingplan: Объект Processingplan с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplan
        """
        call = UpdateProcessingplan(processingplan_id=processingplan_id, data=processingplan)
        return await self(call)

    async def update_processingplanfolder(
        self, processingplanfolder_id: str, processingplanfolder: Processingplanfolder
    ) -> Processingplanfolder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах техкарт,
        запрашивать списки Групп техкарт и сведения по отдельным Группам техкарт. Кодом
        сущности для Группы техкарт в составе JSON API является ключевое слово
        processingplanfolder.

        :param processingplanfolder_id: Идентификатор Processingplanfolder
        :param processingplanfolder: Объект Processingplanfolder с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplanfolder
        """
        call = UpdateProcessingplanfolder(
            processingplanfolder_id=processingplanfolder_id, data=processingplanfolder
        )
        return await self(call)

    async def update_processingplanfolders(
        self, processingplanfolders: list[Processingplanfolder]
    ) -> list[Processingplanfolder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах техкарт,
        запрашивать списки Групп техкарт и сведения по отдельным Группам техкарт. Кодом
        сущности для Группы техкарт в составе JSON API является ключевое слово
        processingplanfolder.

        :param processingplanfolders: Список объектов Processingplanfolder для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplanfolder
        """
        call = UpdateProcessingplanfolders(data=processingplanfolders)
        return await self(call)

    async def update_processingplans(
        self, processingplans: list[Processingplan]
    ) -> list[Processingplan]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техкартах,
        запрашивать списки Техкарт и сведения по отдельным Техкартам. Позициями Техкарт
        можно управлять как в составе отдельной Техкарты, так и отдельно - с помощью
        специальных ресурсов для управления материалами и продуктами Техкарты. Кодом
        сущности для Техкарты в составе JSON API является ключевое слово processingplan.
        Больше о Техкартах и работе с ними в основном интерфейсе вы можете прочитать в
        нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать по ссылке.

        :param processingplans: Список объектов Processingplan для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplan
        """
        call = UpdateProcessingplans(data=processingplans)
        return await self(call)

    async def update_processingprocess(
        self, processingprocess_id: str, processingprocess: Processingprocess
    ) -> Processingprocess:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техпроцессах,
        запрашивать списки Техпроцессов и сведения по отдельным Техпроцессам. Позициями
        Техпроцессов можно управлять как в составе отдельного Техпроцесса, так и
        отдельно - с помощью специальных ресурсов для управления позициями Техпроцессов.
        Кодом сущности для Техпроцессов в составе JSON API является ключевое слово
        processingprocess. Больше о Техпроцессах и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingprocess_id: Идентификатор Processingprocess
        :param processingprocess: Объект Processingprocess с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingprocess
        """
        call = UpdateProcessingprocess(
            processingprocess_id=processingprocess_id, data=processingprocess
        )
        return await self(call)

    async def update_processingprocesses(
        self, processingprocesses: list[Processingprocess]
    ) -> list[Processingprocess]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техпроцессах,
        запрашивать списки Техпроцессов и сведения по отдельным Техпроцессам. Позициями
        Техпроцессов можно управлять как в составе отдельного Техпроцесса, так и
        отдельно - с помощью специальных ресурсов для управления позициями Техпроцессов.
        Кодом сущности для Техпроцессов в составе JSON API является ключевое слово
        processingprocess. Больше о Техпроцессах и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingprocesses: Список объектов Processingprocess для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingprocess
        """
        call = UpdateProcessingprocesses(data=processingprocesses)
        return await self(call)

    async def update_processings(self, processings: list[Processing]) -> list[Processing]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Техоперациях,
        запрашивать списки Техопераций и сведения по отдельным Техоперациям. Позициями
        Техопераций можно управлять как в составе отдельной Техоперации, так и отдельно
        - с помощью специальных ресурсов для управления материалами и продуктами
        Техоперации. Кодом сущности для Техоперации в составе JSON API является ключевое
        слово processing. Больше о Техоперациях и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processings: Список объектов Processing для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processing
        """
        call = UpdateProcessings(data=processings)
        return await self(call)

    async def update_processingstage(
        self, processingstage_id: str, processingstage: Processingstage
    ) -> Processingstage:
        """
        Средствами JSON API можно запрашивать и обновлять списки Этапов и сведения по
        отдельным Этапам. Кодом сущности для Этапов в составе JSON API является ключевое
        слово processingstage. Больше об Этапах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingstage_id: Идентификатор Processingstage
        :param processingstage: Объект Processingstage с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingstage
        """
        call = UpdateProcessingstage(processingstage_id=processingstage_id, data=processingstage)
        return await self(call)

    async def update_processingstages(
        self, processingstages: list[Processingstage]
    ) -> list[Processingstage]:
        """
        Средствами JSON API можно запрашивать и обновлять списки Этапов и сведения по
        отдельным Этапам. Кодом сущности для Этапов в составе JSON API является ключевое
        слово processingstage. Больше об Этапах и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке.

        :param processingstages: Список объектов Processingstage для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingstage
        """
        call = UpdateProcessingstages(data=processingstages)
        return await self(call)

    async def update_product(self, product_id: str, product: Product) -> Product:
        """
        Средствами JSON API можно создавать и обновлять сведения о Товарах, запрашивать
        списки Товаров и сведения по отдельным Товарам. Кодом сущности для Товара в
        составе JSON API является ключевое слово product. Больше о Товарах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке.

        :param product_id: Идентификатор Product
        :param product: Объект Product с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/product
        """
        call = UpdateProduct(product_id=product_id, data=product)
        return await self(call)

    async def update_productfolder(
        self, productfolder_id: str, productfolder: Productfolder
    ) -> Productfolder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах товаров,
        запрашивать списки Групп товаров и сведения по отдельным Группам товаров. Кодом
        сущности для Группы товаров в составе JSON API является ключевое слово
        productfolder. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке.

        :param productfolder_id: Идентификатор Productfolder
        :param productfolder: Объект Productfolder с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/productFolder
        """
        call = UpdateProductfolder(productfolder_id=productfolder_id, data=productfolder)
        return await self(call)

    async def update_productfolders(
        self, productfolders: list[Productfolder]
    ) -> list[Productfolder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Группах товаров,
        запрашивать списки Групп товаров и сведения по отдельным Группам товаров. Кодом
        сущности для Группы товаров в составе JSON API является ключевое слово
        productfolder. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке.

        :param productfolders: Список объектов Productfolder для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/productFolder
        """
        call = UpdateProductfolders(data=productfolders)
        return await self(call)

    async def update_productionstagecompletion(
        self,
        productionstagecompletion_id: str,
        productionstagecompletion: Productionstagecompletion,
    ) -> Productionstagecompletion:
        """
        Кодом сущности для Выполнения этапа производства в составе JSON API является
        ключевое слово productionstagecompletion.

        :param productionstagecompletion_id: Идентификатор Productionstagecompletion
        :param productionstagecompletion: Объект Productionstagecompletion с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionStageCompletion
        """
        call = UpdateProductionstagecompletion(
            productionstagecompletion_id=productionstagecompletion_id,
            data=productionstagecompletion,
        )
        return await self(call)

    async def update_productionstagecompletions(
        self, productionstagecompletions: list[Productionstagecompletion]
    ) -> list[Productionstagecompletion]:
        """
        Кодом сущности для Выполнения этапа производства в составе JSON API является
        ключевое слово productionstagecompletion.

        :param productionstagecompletions: Список объектов Productionstagecompletion для массового
            обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionStageCompletion
        """
        call = UpdateProductionstagecompletions(data=productionstagecompletions)
        return await self(call)

    async def update_productiontask(
        self, productiontask_id: str, productiontask: Productiontask
    ) -> Productiontask:
        """
        Средствами JSON API можно обновлять сведения о Производственных заданиях,
        запрашивать списки Производственных заданий и сведения по отдельным
        Производственным заданиям. Позициями Производственных заданий можно управлять
        как в составе отдельного Производственного задания, так и отдельно - с помощью
        специальных ресурсов для управления позициями Производственных заданий. Кодом
        сущности для Производственных заданий в составе JSON API является ключевое слово
        productiontask. Больше о Производстве и Производственном задании и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке.

        :param productiontask_id: Идентификатор Productiontask
        :param productiontask: Объект Productiontask с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionTask
        """
        call = UpdateProductiontask(productiontask_id=productiontask_id, data=productiontask)
        return await self(call)

    async def update_productiontasks(
        self, productiontasks: list[Productiontask]
    ) -> list[Productiontask]:
        """
        Средствами JSON API можно обновлять сведения о Производственных заданиях,
        запрашивать списки Производственных заданий и сведения по отдельным
        Производственным заданиям. Позициями Производственных заданий можно управлять
        как в составе отдельного Производственного задания, так и отдельно - с помощью
        специальных ресурсов для управления позициями Производственных заданий. Кодом
        сущности для Производственных заданий в составе JSON API является ключевое слово
        productiontask. Больше о Производстве и Производственном задании и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке.

        :param productiontasks: Список объектов Productiontask для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionTask
        """
        call = UpdateProductiontasks(data=productiontasks)
        return await self(call)

    async def update_products(self, products: list[Product]) -> list[Product]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Товарах, запрашивать
        списки Товаров и сведения по отдельным Товарам. Кодом сущности для Товара в
        составе JSON API является ключевое слово product. Больше о Товарах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке.

        :param products: Список объектов Product для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/product
        """
        call = UpdateProducts(data=products)
        return await self(call)

    async def update_project(self, project_id: str, project: Project) -> Project:
        """
        Средствами JSON API можно создавать и обновлять сведения о Проектах, запрашивать
        списки Проектов и сведения по отдельным Проектам. Кодом сущности для Проекта в
        составе JSON API является ключевое слово project. Больше о Проектах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param project_id: Идентификатор Project
        :param project: Объект Project с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/project
        """
        call = UpdateProject(project_id=project_id, data=project)
        return await self(call)

    async def update_projects(self, projects: list[Project]) -> list[Project]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Проектах, запрашивать
        списки Проектов и сведения по отдельным Проектам. Кодом сущности для Проекта в
        составе JSON API является ключевое слово project. Больше о Проектах и работе с
        ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
        ссылке. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param projects: Список объектов Project для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/project
        """
        call = UpdateProjects(data=projects)
        return await self(call)

    async def update_purchaseorder(
        self, purchaseorder_id: str, purchaseorder: Purchaseorder
    ) -> Purchaseorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах поставщику,
        запрашивать списки Заказов и сведения по отдельным Заказам Поставщикам.
        Позициями Заказов можно управлять как в составе отдельного Заказа поставщику,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа поставщику в составе JSON API является ключевое слово
        purchaseorder. Больше о Заказах Поставщикам и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param purchaseorder_id: Идентификатор Purchaseorder
        :param purchaseorder: Объект Purchaseorder с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseOrder
        """
        call = UpdatePurchaseorder(purchaseorder_id=purchaseorder_id, data=purchaseorder)
        return await self(call)

    async def update_purchaseorders(
        self, purchaseorders: list[Purchaseorder]
    ) -> list[Purchaseorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Заказах поставщику,
        запрашивать списки Заказов и сведения по отдельным Заказам Поставщикам.
        Позициями Заказов можно управлять как в составе отдельного Заказа поставщику,
        так и отдельно - с помощью специальных ресурсов для управления позициями Заказа.
        Кодом сущности для Заказа поставщику в составе JSON API является ключевое слово
        purchaseorder. Больше о Заказах Поставщикам и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

        :param purchaseorders: Список объектов Purchaseorder для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseOrder
        """
        call = UpdatePurchaseorders(data=purchaseorders)
        return await self(call)

    async def update_purchasereturn(
        self, purchasereturn_id: str, purchasereturn: Purchasereturn
    ) -> Purchasereturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        поставщикам, запрашивать списки Возвратов поставщикам и сведения по отдельным
        Возвратам поставщикам. Позициями Возвратов поставщикам можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата поставщику. Кодом сущности для Возврата поставщику
        в составе JSON API является ключевое слово purchasereturn.

        :param purchasereturn_id: Идентификатор Purchasereturn
        :param purchasereturn: Объект Purchasereturn с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchase-return
        """
        call = UpdatePurchasereturn(purchasereturn_id=purchasereturn_id, data=purchasereturn)
        return await self(call)

    async def update_purchasereturns(
        self, purchasereturns: list[Purchasereturn]
    ) -> list[Purchasereturn]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        поставщикам, запрашивать списки Возвратов поставщикам и сведения по отдельным
        Возвратам поставщикам. Позициями Возвратов поставщикам можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата поставщику. Кодом сущности для Возврата поставщику
        в составе JSON API является ключевое слово purchasereturn.

        :param purchasereturns: Список объектов Purchasereturn для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchase-return
        """
        call = UpdatePurchasereturns(data=purchasereturns)
        return await self(call)

    async def update_retaildemand(
        self, retaildemand_id: str, retaildemand: Retaildemand
    ) -> Retaildemand:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных продажах,
        запрашивать списки Розничных продаж и сведения по отдельным Розничным продажам.
        Позициями Розничных продаж можно управлять как в составе отдельной Розничной
        продажи, так и отдельно - с помощью специальных ресурсов для управления
        позициями Розничными продажами. Кодом сущности для Розничной продажи в составе
        JSON API является ключевое слово retaildemand. Больше о Розничных продажах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке в разделе Оформление продажи.

        :param retaildemand_id: Идентификатор Retaildemand
        :param retaildemand: Объект Retaildemand с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildemand
        """
        call = UpdateRetaildemand(retaildemand_id=retaildemand_id, data=retaildemand)
        return await self(call)

    async def update_retaildemands(self, retaildemands: list[Retaildemand]) -> list[Retaildemand]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных продажах,
        запрашивать списки Розничных продаж и сведения по отдельным Розничным продажам.
        Позициями Розничных продаж можно управлять как в составе отдельной Розничной
        продажи, так и отдельно - с помощью специальных ресурсов для управления
        позициями Розничными продажами. Кодом сущности для Розничной продажи в составе
        JSON API является ключевое слово retaildemand. Больше о Розничных продажах и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке в разделе Оформление продажи.

        :param retaildemands: Список объектов Retaildemand для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildemand
        """
        call = UpdateRetaildemands(data=retaildemands)
        return await self(call)

    async def update_retaildrawercashins(
        self, retaildrawercashins: list[Retaildrawercashin]
    ) -> list[Retaildrawercashin]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Внесениях денег,
        запрашивать списки Внесений денег и сведения по отдельным Внесениям денег. Кодом
        сущности для Внесения денег в составе JSON API является ключевое слово
        retaildrawercashin. Больше о Внесениях денег и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке.

        :param retaildrawercashins: Список объектов Retaildrawercashin для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashin
        """
        call = UpdateRetaildrawercashins(data=retaildrawercashins)
        return await self(call)

    async def update_retaildrawercashouts(
        self, retaildrawercashouts: list[Retaildrawercashout]
    ) -> list[Retaildrawercashout]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выплатах денег,
        запрашивать списки Выплат денег и сведения по отдельным Выплатам денег. Кодом
        сущности для внесения денег в составе JSON API является ключевое слово
        retaildrawercashout. Больше о Выплатах денег и работе с ними в основном
        интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке

        :param retaildrawercashouts: Список объектов Retaildrawercashout для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashout
        """
        call = UpdateRetaildrawercashouts(data=retaildrawercashouts)
        return await self(call)

    async def update_retailsalesreturn(
        self, retailsalesreturn_id: str, retailsalesreturn: Retailsalesreturn
    ) -> Retailsalesreturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных возвратах,
        запрашивать списки Розничных возвратов и сведения по отдельным Розничным
        возвратам. Позициями Розничных возвратов  можно управлять как в составе
        отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Розничного возврата. Кодом сущности для Розничного возврата
        в составе JSON API является ключевое слово retailsalesreturn.

        :param retailsalesreturn_id: Идентификатор Retailsalesreturn
        :param retailsalesreturn: Объект Retailsalesreturn с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retail-sales-return
        """
        call = UpdateRetailsalesreturn(
            retailsalesreturn_id=retailsalesreturn_id, data=retailsalesreturn
        )
        return await self(call)

    async def update_retailsalesreturns(
        self, retailsalesreturns: list[Retailsalesreturn]
    ) -> list[Retailsalesreturn]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Розничных возвратах,
        запрашивать списки Розничных возвратов и сведения по отдельным Розничным
        возвратам. Позициями Розничных возвратов  можно управлять как в составе
        отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Розничного возврата. Кодом сущности для Розничного возврата
        в составе JSON API является ключевое слово retailsalesreturn.

        :param retailsalesreturns: Список объектов Retailsalesreturn для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retail-sales-return
        """
        call = UpdateRetailsalesreturns(data=retailsalesreturns)
        return await self(call)

    async def update_retailshift(
        self, retailshift_id: str, retailshift: Retailshift
    ) -> Retailshift:
        """
        Средствами JSON API можно запрашивать списки Розничных смен и сведения по
        отдельным Розничным сменам. Кодом сущности для Розничной смены в составе JSON
        API является ключевое слово retailshift.

        :param retailshift_id: Идентификатор Retailshift
        :param retailshift: Объект Retailshift с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retailshift
        """
        call = UpdateRetailshift(retailshift_id=retailshift_id, data=retailshift)
        return await self(call)

    async def update_retailstore(
        self, retailstore_id: str, retailstore: Retailstore
    ) -> Retailstore:
        """
        Средствами JSON API можно создавать и обновлять сведения о Точках продаж,
        запрашивать списки Точек продаж и сведения по отдельным Точкам продаж. Также
        можно получить доступ к специальному ресурсу для управления кассирами точки
        продаж. Кодом сущности для точки продаж в составе JSON API является ключевое
        слово retailstore. Больше о точках продаж и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке в разделе "Создание
        точки продаж в основном интерфейсе". По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать

        :param retailstore_id: Идентификатор Retailstore
        :param retailstore: Объект Retailstore с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/retailstore
        """
        call = UpdateRetailstore(retailstore_id=retailstore_id, data=retailstore)
        return await self(call)

    async def update_retailstores(self, retailstores: list[Retailstore]) -> list[Retailstore]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Точках продаж,
        запрашивать списки Точек продаж и сведения по отдельным Точкам продаж. Также
        можно получить доступ к специальному ресурсу для управления кассирами точки
        продаж. Кодом сущности для точки продаж в составе JSON API является ключевое
        слово retailstore. Больше о точках продаж и работе с ними в основном интерфейсе
        вы можете прочитать в нашей службе поддержки по этой ссылке в разделе "Создание
        точки продаж в основном интерфейсе". По данной сущности можно осуществлять
        контекстный поиск с помощью специального параметра search. Подробнее можно
        узнать

        :param retailstores: Список объектов Retailstore для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/retailstore
        """
        call = UpdateRetailstores(data=retailstores)
        return await self(call)

    async def update_retireorder(
        self, retireorder_id: str, retireorder: Retireorder
    ) -> Retireorder:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выводе кодов
        маркировки из оборота, а также запрашивать списки документов и информацию о
        конкретных Выводах. Позициями можно управлять как в составе документа Вывода,
        так и отдельно - с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Вывода из оборота в составе JSON API является ключевое слово
        retireorder. Больше о Выводах кодов из оборота можно прочитать здесь.

        :param retireorder_id: Идентификатор Retireorder
        :param retireorder: Объект Retireorder с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retireorder
        """
        call = UpdateRetireorder(retireorder_id=retireorder_id, data=retireorder)
        return await self(call)

    async def update_retireorders(self, retireorders: list[Retireorder]) -> list[Retireorder]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Выводе кодов
        маркировки из оборота, а также запрашивать списки документов и информацию о
        конкретных Выводах. Позициями можно управлять как в составе документа Вывода,
        так и отдельно - с помощью специальных ресурсов для управления позициями. Кодом
        сущности для Вывода из оборота в составе JSON API является ключевое слово
        retireorder. Больше о Выводах кодов из оборота можно прочитать здесь.

        :param retireorders: Список объектов Retireorder для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retireorder
        """
        call = UpdateRetireorders(data=retireorders)
        return await self(call)

    async def update_role(self, role_id: str, role: Role) -> Role:
        """
        Кодом сущности для Пользовательской роли в составе JSON API является ключевое
        слово role.

        :param role_id: Идентификатор Role
        :param role: Объект Role с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/custom-role
        """
        call = UpdateRole(role_id=role_id, data=role)
        return await self(call)

    async def update_saleschannel(
        self, saleschannel_id: str, saleschannel: Saleschannel
    ) -> Saleschannel:
        """
        Средствами JSON API можно создавать и обновлять сведения о Каналах продаж,
        запрашивать списки Каналов продаж и сведения по отдельным Каналам продаж. Кодом
        сущности для Канала продаж в составе JSON API является ключевое слово
        saleschannel. Больше о Каналах продаж и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param saleschannel_id: Идентификатор Saleschannel
        :param saleschannel: Объект Saleschannel с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleschannel
        """
        call = UpdateSaleschannel(saleschannel_id=saleschannel_id, data=saleschannel)
        return await self(call)

    async def update_saleschannels(self, saleschannels: list[Saleschannel]) -> list[Saleschannel]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Каналах продаж,
        запрашивать списки Каналов продаж и сведения по отдельным Каналам продаж. Кодом
        сущности для Канала продаж в составе JSON API является ключевое слово
        saleschannel. Больше о Каналах продаж и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
        можно осуществлять контекстный поиск с помощью специального параметра search.
        Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других
        тем, что поиск не префиксный, без токенизации и идет только по одному полю
        одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param saleschannels: Список объектов Saleschannel для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleschannel
        """
        call = UpdateSaleschannels(data=saleschannels)
        return await self(call)

    async def update_salesreturn(
        self, salesreturn_id: str, salesreturn: Salesreturn
    ) -> Salesreturn:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        покупателей, запрашивать списки Возвратов покупателей и сведения по отдельным
        Возвратам покупателей. Позициями Возвратов покупателей можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата покупателя. Кодом сущности для Возврата покупателя
        в составе JSON API является ключевое слово salesreturn.

        :param salesreturn_id: Идентификатор Salesreturn
        :param salesreturn: Объект Salesreturn с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/sales-return
        """
        call = UpdateSalesreturn(salesreturn_id=salesreturn_id, data=salesreturn)
        return await self(call)

    async def update_salesreturns(self, salesreturns: list[Salesreturn]) -> list[Salesreturn]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Возвратах
        покупателей, запрашивать списки Возвратов покупателей и сведения по отдельным
        Возвратам покупателей. Позициями Возвратов покупателей можно управлять как в
        составе отдельного Возврата, так и отдельно - с помощью специальных ресурсов для
        управления позициями Возврата покупателя. Кодом сущности для Возврата покупателя
        в составе JSON API является ключевое слово salesreturn.

        :param salesreturns: Список объектов Salesreturn для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/sales-return
        """
        call = UpdateSalesreturns(data=salesreturns)
        return await self(call)

    async def update_service(self, service_id: str, service: Service) -> Service:
        """
        Средствами JSON API можно создавать и обновлять сведения об Услугах, запрашивать
        списки Услуг и сведения по отдельным Услугам. Кодом сущности для Услуги в
        составе JSON API является ключевое слово service. Услуга - специальная
        разновидность товара, без закупочной цены и упаковок. Больше о Товарах и работе
        с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад.

        :param service_id: Идентификатор Service
        :param service: Объект Service с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/service
        """
        call = UpdateService(service_id=service_id, data=service)
        return await self(call)

    async def update_services(self, services: list[Service]) -> list[Service]:
        """
        Средствами JSON API можно создавать и обновлять сведения об Услугах, запрашивать
        списки Услуг и сведения по отдельным Услугам. Кодом сущности для Услуги в
        составе JSON API является ключевое слово service. Услуга - специальная
        разновидность товара, без закупочной цены и упаковок. Больше о Товарах и работе
        с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки в
        разделе Товары и склад.

        :param services: Список объектов Service для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/service
        """
        call = UpdateServices(data=services)
        return await self(call)

    async def update_states(self, states: list[State]) -> list[State]:
        """
        Кодом сущности для Статусов документов в составе JSON API является ключевое
        слово state.

        :param states: Список объектов State для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/states
        """
        call = UpdateStates(data=states)
        return await self(call)

    async def update_store(self, store_id: str, store: Store) -> Store:
        """
        Кодом сущности для Складов в составе JSON API является ключевое слово store.

        :param store_id: Идентификатор Store
        :param store: Объект Store с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store
        """
        call = UpdateStore(store_id=store_id, data=store)
        return await self(call)

    async def update_stores(self, stores: list[Store]) -> list[Store]:
        """
        Кодом сущности для Складов в составе JSON API является ключевое слово store.

        :param stores: Список объектов Store для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store
        """
        call = UpdateStores(data=stores)
        return await self(call)

    async def update_supplies(self, supplies: list[Supply]) -> list[Supply]:
        """
        Средствами JSON API можно создавать и обновлять сведения об Приемках,
        запрашивать списки Приемок и сведения по отдельным Приемкам. Позициями Приемок
        можно управлять как в составе отдельной Приемки, так и отдельно - с помощью
        специальных ресурсов для управления позициями Приемки. Кодом сущности для
        Приемки в составе JSON API является ключевое слово supply. Больше об Приемках и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке.

        :param supplies: Список объектов Supply для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply
        """
        call = UpdateSupplies(data=supplies)
        return await self(call)

    async def update_supply(self, supply_id: str, supply: Supply) -> Supply:
        """
        Средствами JSON API можно создавать и обновлять сведения об Приемках,
        запрашивать списки Приемок и сведения по отдельным Приемкам. Позициями Приемок
        можно управлять как в составе отдельной Приемки, так и отдельно - с помощью
        специальных ресурсов для управления позициями Приемки. Кодом сущности для
        Приемки в составе JSON API является ключевое слово supply. Больше об Приемках и
        работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
        по  этой ссылке.

        :param supply_id: Идентификатор Supply
        :param supply: Объект Supply с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply
        """
        call = UpdateSupply(supply_id=supply_id, data=supply)
        return await self(call)

    async def update_task(self, task_id: str, task: Task) -> Task:
        """
        Средствами JSON API можно создавать и обновлять сведения о задачах, запрашивать
        списки задач и сведения по отдельным задачам. Кодом сущности для задачи в
        составе JSON API является ключевое слово task. Больше о задачах и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param task_id: Идентификатор Task
        :param task: Объект Task с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/task
        """
        call = UpdateTask(task_id=task_id, data=task)
        return await self(call)

    async def update_tasks(self, tasks: list[Task]) -> list[Task]:
        """
        Средствами JSON API можно создавать и обновлять сведения о задачах, запрашивать
        списки задач и сведения по отдельным задачам. Кодом сущности для задачи в
        составе JSON API является ключевое слово task. Больше о задачах и работе с ними
        в основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой
        ссылке.

        :param tasks: Список объектов Task для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/task
        """
        call = UpdateTasks(data=tasks)
        return await self(call)

    async def update_taxrate(self, taxrate_id: str, taxrate: Taxrate) -> Taxrate:
        """
        Средствами JSON API можно создавать и обновлять сведения о налоговых ставках,
        запрашивать списки ставок и сведения по отдельным ставкам. Кодом сущности для
        налоговой ставки в составе JSON API является ключевое слово taxrate. По данной
        сущности можно осуществлять контекстный поиск с помощью специального параметра
        search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается
        от других тем, что поиск не префиксный, без токенизации и идет только по одному
        полю одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param taxrate_id: Идентификатор Taxrate
        :param taxrate: Объект Taxrate с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/taxrate
        """
        call = UpdateTaxrate(taxrate_id=taxrate_id, data=taxrate)
        return await self(call)

    async def update_taxrates(self, taxrates: list[Taxrate]) -> list[Taxrate]:
        """
        Средствами JSON API можно создавать и обновлять сведения о налоговых ставках,
        запрашивать списки ставок и сведения по отдельным ставкам. Кодом сущности для
        налоговой ставки в составе JSON API является ключевое слово taxrate. По данной
        сущности можно осуществлять контекстный поиск с помощью специального параметра
        search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается
        от других тем, что поиск не префиксный, без токенизации и идет только по одному
        полю одновременно. Ищет такие строки, в которые входит значение строки поиска.

        :param taxrates: Список объектов Taxrate для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/taxrate
        """
        call = UpdateTaxrates(data=taxrates)
        return await self(call)

    async def update_trackingcodeses(
        self, trackingcodeses: list[Trackingcodes]
    ) -> list[Trackingcodes]:
        """
        Средствами JSON API можно получать, создавать, редактировать и удалять Коды
        маркировки. Кодом сущности для Кодов маркировки в составе JSON API является
        ключевое слово trackingCodes. Сущность представлена в виде идентификатора,
        текстового кода, типа кода и массива вложенных Кодов маркировки. Коды маркировки
        относятся к отдельной позиции конкретного документа. Порядок вывода КМ первого
        уровня фиксирован - вложенные КМ могут выводиться в случайном порядке.

        :param trackingcodeses: Список объектов Trackingcodes для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/tracking-code
        """
        call = UpdateTrackingcodeses(data=trackingcodeses)
        return await self(call)

    async def update_uom(self, uom_id: str, uom: Uom) -> Uom:
        """
        Кодом сущности для Единиц измерения в составе JSON API является ключевое слово
        uom. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param uom_id: Идентификатор Uom
        :param uom: Объект Uom с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/uom
        """
        call = UpdateUom(uom_id=uom_id, data=uom)
        return await self(call)

    async def update_uoms(self, uoms: list[Uom]) -> list[Uom]:
        """
        Кодом сущности для Единиц измерения в составе JSON API является ключевое слово
        uom. По данной сущности можно осуществлять контекстный поиск с помощью
        специального параметра search. Подробнее можно узнать по ссылке. Поиск с
        параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param uoms: Список объектов Uom для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/uom
        """
        call = UpdateUoms(data=uoms)
        return await self(call)

    async def update_variant(self, variant_id: str, variant: Variant) -> Variant:
        """
        Средствами JSON API можно создавать и обновлять сведения о Модификациях товаров,
        запрашивать списки Модификаций товаров и сведения по отдельным Модификациям.
        Кодом сущности для Модификации в составе JSON API является ключевое слово
        variant. Больше о Модификациях товаров и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке, а также больше о
        работе с товарами здесь. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск
        с параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param variant_id: Идентификатор Variant
        :param variant: Объект Variant с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/variant
        """
        call = UpdateVariant(variant_id=variant_id, data=variant)
        return await self(call)

    async def update_variants(self, variants: list[Variant]) -> list[Variant]:
        """
        Средствами JSON API можно создавать и обновлять сведения о Модификациях товаров,
        запрашивать списки Модификаций товаров и сведения по отдельным Модификациям.
        Кодом сущности для Модификации в составе JSON API является ключевое слово
        variant. Больше о Модификациях товаров и работе с ними в основном интерфейсе вы
        можете прочитать в нашей службе поддержки по этой ссылке, а также больше о
        работе с товарами здесь. По данной сущности можно осуществлять контекстный поиск
        с помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск
        с параметром search отличается от других тем, что поиск не префиксный, без
        токенизации и идет только по одному полю одновременно. Ищет такие строки, в
        которые входит значение строки поиска.

        :param variants: Список объектов Variant для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/variant
        """
        call = UpdateVariants(data=variants)
        return await self(call)

    async def update_webhook(self, webhook_id: str, webhook: Webhook) -> Webhook:
        """
        Пример того, в каком виде будут передаваться данные:

        :param webhook_id: Идентификатор Webhook
        :param webhook: Объект Webhook с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhook
        """
        call = UpdateWebhook(webhook_id=webhook_id, data=webhook)
        return await self(call)

    async def update_webhooks(self, webhooks: list[Webhook]) -> list[Webhook]:
        """
        Пример того, в каком виде будут передаваться данные:

        :param webhooks: Список объектов Webhook для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhook
        """
        call = UpdateWebhooks(data=webhooks)
        return await self(call)

    async def update_webhookstock(
        self, webhookstock_id: str, webhookstock: Webhookstock
    ) -> Webhookstock:
        """
        > Пример того, в каком виде будут передаваться данные: POST
        https://example.com/webhook_path?requestId=640569eb-522d-427a-b07e-fa757c5d4217

        :param webhookstock_id: Идентификатор Webhookstock
        :param webhookstock: Объект Webhookstock с обновлёнными полями

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhookstock
        """
        call = UpdateWebhookstock(webhookstock_id=webhookstock_id, data=webhookstock)
        return await self(call)

    async def update_webhookstocks(self, webhookstocks: list[Webhookstock]) -> list[Webhookstock]:
        """
        > Пример того, в каком виде будут передаваться данные: POST
        https://example.com/webhook_path?requestId=640569eb-522d-427a-b07e-fa757c5d4217

        :param webhookstocks: Список объектов Webhookstock для массового обновления

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhookstock
        """
        call = UpdateWebhookstocks(data=webhookstocks)
        return await self(call)

    async def get_files(
        self,
        entity_type: str,
        entity_id: str,
        limit: int | None = None,
        offset: int | None = None,
        order: str | None = None,
    ) -> list[File]:
        """
        Запрос на получение всех Файлов Операции, Номенклатуры, Задачи или Контрагента
        для данной учетной записи.

        :param entity_type: Тип сущности, для которой запрашиваются Файлы
            (например 'product', 'customerorder')
        :param entity_id: id сущности с Файлами
        :param limit: Максимальное количество сущностей для извлечения.
            Допустимые значения 1 - 1000.
        :param offset: Отступ в выдаваемом списке сущностей.
        :param order: Сортировка выборки (например: "name,desc;code,asc")

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files
        """
        call = GetFiles(type=entity_type, id=entity_id, limit=limit, offset=offset, order=order)
        result = await self(call)
        return result.rows if hasattr(result, "rows") else result

    async def upload_files(
        self,
        entity_type: str,
        entity_id: str,
        files: list[FileInput],
    ) -> list[File]:
        """
        Добавить новые Файлы к Операции, Номенклатуре или Контрагенту.
        Файлы загружаются и добавляются к Файлам на основе переданного объекта JSON,
        который содержит массив с представлениями новых Файлов.
        В одном запросе можно добавить максимум 10 Файлов.

        :param entity_type: Тип сущности, к которой добавляются Файлы
            (например 'product', 'customerorder')
        :param entity_id: id сущности, к которой добавляются Файлы
        :param files: Массив объектов FileInput с полями filename и content (Base64)

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files
        """
        call = UploadFiles(type=entity_type, id=entity_id, data=files)
        return await self(call)

    async def delete_file(
        self,
        entity_type: str,
        entity_id: str,
        file_id: str,
    ) -> None:
        """
        При удалении Файла удаляется первый найденный с данным идентификатором Файла
        у Операции, Номенклатуры, Задачи или Контрагента.

        :param entity_type: Тип сущности с Файлом
            (например 'product', 'customerorder')
        :param entity_id: id сущности с Файлом
        :param file_id: id Файла

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files
        """
        call = DeleteFile(type=entity_type, id=entity_id, file_id=file_id)
        return await self(call)

    async def download_file(self, download_href: str) -> bytes:
        """
        Скачать Файл по ссылке downloadHref из метаданных Файла.
        Запрос на скачивание возвращает содержимое файла в байтах.
        Заголовок Authorization не требуется для ссылки на скачивание.

        :param download_href: Ссылка downloadHref из meta Файла

        Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files
        """
        return await self.session.download(download_href)
