from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.profit import Profit
from .base import MSMethod


class GetProfitByProduct(MSMethod):
    """Прибыльность по товарам."""

    __return__ = MetaArray[Profit]
    __api_method__ = "report/profit/byproduct"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-pnl"

    limit: int | None = None
    offset: int | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
