from .base import MSMethod
from .create_bonusprogram import CreateBonusprogram
from .create_bonustransaction import CreateBonustransaction
from .create_bundle import CreateBundle
from .create_cashin import CreateCashin
from .create_cashout import CreateCashout
from .create_commissionreportin import CreateCommissionreportin
from .create_commissionreportout import CreateCommissionreportout
from .create_consignment import CreateConsignment
from .create_contract import CreateContract
from .create_counterparty import CreateCounterparty
from .create_counterpartyadjustment import CreateCounterpartyadjustment
from .create_country import CreateCountry
from .create_customentity import CreateCustomentity
from .create_customerorder import CreateCustomerorder
from .create_demand import CreateDemand
from .create_discount import CreateDiscount
from .create_emissionorder import CreateEmissionorder
from .create_employee import CreateEmployee
from .create_enter import CreateEnter
from .create_expenseitem import CreateExpenseitem
from .create_facturein import CreateFacturein
from .create_factureout import CreateFactureout
from .create_group import CreateGroup
from .create_internalorder import CreateInternalorder
from .create_inventory import CreateInventory
from .create_invoicein import CreateInvoicein
from .create_invoiceout import CreateInvoiceout
from .create_loss import CreateLoss
from .create_move import CreateMove
from .create_organization import CreateOrganization
from .create_paymentin import CreatePaymentin
from .create_paymentout import CreatePaymentout
from .create_pricelist import CreatePricelist
from .create_processing import CreateProcessing
from .create_processingorder import CreateProcessingorder
from .create_processingplan import CreateProcessingplan
from .create_processingplanfolder import CreateProcessingplanfolder
from .create_processingprocess import CreateProcessingprocess
from .create_processingstage import CreateProcessingstage
from .create_product import CreateProduct
from .create_productfolder import CreateProductfolder
from .create_productionstagecompletion import CreateProductionstagecompletion
from .create_productiontask import CreateProductiontask
from .create_project import CreateProject
from .create_purchaseorder import CreatePurchaseorder
from .create_purchasereturn import CreatePurchasereturn
from .create_retaildemand import CreateRetaildemand
from .create_retailsalesreturn import CreateRetailsalesreturn
from .create_retailshift import CreateRetailshift
from .create_retailstore import CreateRetailstore
from .create_retireorder import CreateRetireorder
from .create_saleschannel import CreateSaleschannel
from .create_salesreturn import CreateSalesreturn
from .create_service import CreateService
from .create_store import CreateStore
from .create_supply import CreateSupply
from .create_task import CreateTask
from .create_taxrate import CreateTaxrate
from .create_uom import CreateUom
from .create_variant import CreateVariant
from .create_webhook import CreateWebhook
from .create_webhookstock import CreateWebhookstock
from .delete_bonusprogram import DeleteBonusprogram
from .delete_bonustransaction import DeleteBonustransaction
from .delete_bundle import DeleteBundle
from .delete_cashin import DeleteCashin
from .delete_cashout import DeleteCashout
from .delete_commissionreportin import DeleteCommissionreportin
from .delete_commissionreportout import DeleteCommissionreportout
from .delete_consignment import DeleteConsignment
from .delete_contract import DeleteContract
from .delete_counterparty import DeleteCounterparty
from .delete_counterpartyadjustment import DeleteCounterpartyadjustment
from .delete_country import DeleteCountry
from .delete_currency import DeleteCurrency
from .delete_customentity import DeleteCustomentity
from .delete_customerorder import DeleteCustomerorder
from .delete_demand import DeleteDemand
from .delete_discount import DeleteDiscount
from .delete_employee import DeleteEmployee
from .delete_enter import DeleteEnter
from .delete_expenseitem import DeleteExpenseitem
from .delete_facturein import DeleteFacturein
from .delete_factureout import DeleteFactureout
from .delete_file import DeleteFile
from .delete_group import DeleteGroup
from .delete_image import DeleteImage
from .delete_internalorder import DeleteInternalorder
from .delete_inventory import DeleteInventory
from .delete_invoicein import DeleteInvoicein
from .delete_invoiceout import DeleteInvoiceout
from .delete_loss import DeleteLoss
from .delete_move import DeleteMove
from .delete_notes import DeleteNotes
from .delete_organization import DeleteOrganization
from .delete_paymentin import DeletePaymentin
from .delete_paymentout import DeletePaymentout
from .delete_prepayment import DeletePrepayment
from .delete_prepaymentreturn import DeletePrepaymentreturn
from .delete_pricelist import DeletePricelist
from .delete_processing import DeleteProcessing
from .delete_processingorder import DeleteProcessingorder
from .delete_processingplan import DeleteProcessingplan
from .delete_processingplanfolder import DeleteProcessingplanfolder
from .delete_processingprocess import DeleteProcessingprocess
from .delete_processingstage import DeleteProcessingstage
from .delete_product import DeleteProduct
from .delete_productfolder import DeleteProductfolder
from .delete_productionstagecompletion import DeleteProductionstagecompletion
from .delete_productiontask import DeleteProductiontask
from .delete_project import DeleteProject
from .delete_publication import DeletePublication
from .delete_purchaseorder import DeletePurchaseorder
from .delete_purchasereturn import DeletePurchasereturn
from .delete_retaildemand import DeleteRetaildemand
from .delete_retaildrawercashin import DeleteRetaildrawercashin
from .delete_retaildrawercashout import DeleteRetaildrawercashout
from .delete_retailsalesreturn import DeleteRetailsalesreturn
from .delete_retailshift import DeleteRetailshift
from .delete_retailstore import DeleteRetailstore
from .delete_retireorder import DeleteRetireorder
from .delete_role import DeleteRole
from .delete_saleschannel import DeleteSaleschannel
from .delete_salesreturn import DeleteSalesreturn
from .delete_service import DeleteService
from .delete_store import DeleteStore
from .delete_supply import DeleteSupply
from .delete_task import DeleteTask
from .delete_taxrate import DeleteTaxrate
from .delete_uom import DeleteUom
from .delete_variant import DeleteVariant
from .delete_webhook import DeleteWebhook
from .delete_webhookstock import DeleteWebhookstock
from .get_assortment import GetAssortment
from .get_assortments import GetAssortments
from .get_audit import GetAudit
from .get_audits import GetAudits
from .get_bonusprogram import GetBonusprogram
from .get_bonusprograms import GetBonusprograms
from .get_bonustransaction import GetBonustransaction
from .get_bonustransactions import GetBonustransactions
from .get_bundle import GetBundle
from .get_bundles import GetBundles
from .get_cashier import GetCashier
from .get_cashin import GetCashin
from .get_cashins import GetCashins
from .get_cashout import GetCashout
from .get_cashouts import GetCashouts
from .get_commissionreportin import GetCommissionreportin
from .get_commissionreportins import GetCommissionreportins
from .get_commissionreportout import GetCommissionreportout
from .get_commissionreportouts import GetCommissionreportouts
from .get_companysettings import GetCompanysettings
from .get_consignment import GetConsignment
from .get_consignments import GetConsignments
from .get_contentcard import GetContentcard
from .get_contentcards import GetContentcards
from .get_contract import GetContract
from .get_contracts import GetContracts
from .get_counterparties import GetCounterparties
from .get_counterparty import GetCounterparty
from .get_counterpartyadjustment import GetCounterpartyadjustment
from .get_counterpartyadjustments import GetCounterpartyadjustments
from .get_countries import GetCountries
from .get_country import GetCountry
from .get_currency import GetCurrency
from .get_customentities import GetCustomentities
from .get_customentity import GetCustomentity
from .get_customerorder import GetCustomerorder
from .get_customerorders import GetCustomerorders
from .get_demand import GetDemand
from .get_demands import GetDemands
from .get_discount import GetDiscount
from .get_discounts import GetDiscounts
from .get_emissionorder import GetEmissionorder
from .get_emissionorders import GetEmissionorders
from .get_employee import GetEmployee
from .get_employees import GetEmployees
from .get_enter import GetEnter
from .get_enters import GetEnters
from .get_expenseitem import GetExpenseitem
from .get_expenseitems import GetExpenseitems
from .get_facturein import GetFacturein
from .get_factureins import GetFactureins
from .get_factureout import GetFactureout
from .get_factureouts import GetFactureouts
from .get_files import GetFiles
from .get_group import GetGroup
from .get_groups import GetGroups
from .get_internalorder import GetInternalorder
from .get_internalorders import GetInternalorders
from .get_inventories import GetInventories
from .get_inventory import GetInventory
from .get_invoicein import GetInvoicein
from .get_invoiceins import GetInvoiceins
from .get_invoiceout import GetInvoiceout
from .get_invoiceouts import GetInvoiceouts
from .get_loss import GetLoss
from .get_losses import GetLosses
from .get_move import GetMove
from .get_moves import GetMoves
from .get_namedfilter import GetNamedfilter
from .get_notes import GetNotes
from .get_organization import GetOrganization
from .get_organizations import GetOrganizations
from .get_paymentin import GetPaymentin
from .get_paymentins import GetPaymentins
from .get_paymentout import GetPaymentout
from .get_paymentouts import GetPaymentouts
from .get_prepayment import GetPrepayment
from .get_prepaymentreturn import GetPrepaymentreturn
from .get_prepaymentreturns import GetPrepaymentreturns
from .get_prepayments import GetPrepayments
from .get_pricelist import GetPricelist
from .get_pricelists import GetPricelists
from .get_processing import GetProcessing
from .get_processingorder import GetProcessingorder
from .get_processingorders import GetProcessingorders
from .get_processingplan import GetProcessingplan
from .get_processingplanfolder import GetProcessingplanfolder
from .get_processingplanfolders import GetProcessingplanfolders
from .get_processingplans import GetProcessingplans
from .get_processingprocess import GetProcessingprocess
from .get_processingprocesses import GetProcessingprocesses
from .get_processings import GetProcessings
from .get_processingstage import GetProcessingstage
from .get_processingstages import GetProcessingstages
from .get_product import GetProduct
from .get_productfolder import GetProductfolder
from .get_productfolders import GetProductfolders
from .get_productionstagecompletion import GetProductionstagecompletion
from .get_productionstagecompletions import GetProductionstagecompletions
from .get_productiontask import GetProductiontask
from .get_productiontasks import GetProductiontasks
from .get_products import GetProducts
from .get_profit_by_product import GetProfitByProduct
from .get_profit_by_variant import GetProfitByVariant
from .get_project import GetProject
from .get_projects import GetProjects
from .get_purchaseorder import GetPurchaseorder
from .get_purchaseorders import GetPurchaseorders
from .get_purchasereturn import GetPurchasereturn
from .get_purchasereturns import GetPurchasereturns
from .get_region import GetRegion
from .get_regions import GetRegions
from .get_retaildemand import GetRetaildemand
from .get_retaildemands import GetRetaildemands
from .get_retaildrawercashin import GetRetaildrawercashin
from .get_retaildrawercashout import GetRetaildrawercashout
from .get_retailsalesreturn import GetRetailsalesreturn
from .get_retailsalesreturns import GetRetailsalesreturns
from .get_retailshift import GetRetailshift
from .get_retailshifts import GetRetailshifts
from .get_retailstore import GetRetailstore
from .get_retailstores import GetRetailstores
from .get_retireorder import GetRetireorder
from .get_retireorders import GetRetireorders
from .get_role import GetRole
from .get_saleplatform import GetSaleplatform
from .get_saleplatforms import GetSaleplatforms
from .get_saleschannel import GetSaleschannel
from .get_saleschannels import GetSaleschannels
from .get_salesreturn import GetSalesreturn
from .get_salesreturns import GetSalesreturns
from .get_service import GetService
from .get_services import GetServices
from .get_stock import GetStock
from .get_stock_current import GetStockCurrent
from .get_store import GetStore
from .get_stores import GetStores
from .get_supplies import GetSupplies
from .get_supply import GetSupply
from .get_task import GetTask
from .get_tasks import GetTasks
from .get_taxrate import GetTaxrate
from .get_taxrates import GetTaxrates
from .get_thing import GetThing
from .get_things import GetThings
from .get_uom import GetUom
from .get_uoms import GetUoms
from .get_usersettings import GetUsersettings
from .get_variant import GetVariant
from .get_variants import GetVariants
from .get_webhook import GetWebhook
from .get_webhooks import GetWebhooks
from .get_webhookstock import GetWebhookstock
from .get_webhookstocks import GetWebhookstocks
from .update_bonusprogram import UpdateBonusprogram
from .update_bonustransaction import UpdateBonustransaction
from .update_bonustransactions import UpdateBonustransactions
from .update_bundle import UpdateBundle
from .update_bundles import UpdateBundles
from .update_cashin import UpdateCashin
from .update_cashins import UpdateCashins
from .update_cashout import UpdateCashout
from .update_cashouts import UpdateCashouts
from .update_commissionreportin import UpdateCommissionreportin
from .update_commissionreportins import UpdateCommissionreportins
from .update_commissionreportouts import UpdateCommissionreportouts
from .update_consignment import UpdateConsignment
from .update_consignments import UpdateConsignments
from .update_contract import UpdateContract
from .update_contracts import UpdateContracts
from .update_counterparties import UpdateCounterparties
from .update_counterparty import UpdateCounterparty
from .update_counterpartyadjustment import UpdateCounterpartyadjustment
from .update_counterpartyadjustments import UpdateCounterpartyadjustments
from .update_countries import UpdateCountries
from .update_country import UpdateCountry
from .update_currencies import UpdateCurrencies
from .update_currency import UpdateCurrency
from .update_customentity import UpdateCustomentity
from .update_customerorder import UpdateCustomerorder
from .update_customerorders import UpdateCustomerorders
from .update_demand import UpdateDemand
from .update_demands import UpdateDemands
from .update_discount import UpdateDiscount
from .update_emissionorder import UpdateEmissionorder
from .update_emissionorders import UpdateEmissionorders
from .update_employee import UpdateEmployee
from .update_enter import UpdateEnter
from .update_enters import UpdateEnters
from .update_expenseitem import UpdateExpenseitem
from .update_expenseitems import UpdateExpenseitems
from .update_facturein import UpdateFacturein
from .update_factureins import UpdateFactureins
from .update_factureout import UpdateFactureout
from .update_factureouts import UpdateFactureouts
from .update_group import UpdateGroup
from .update_internalorder import UpdateInternalorder
from .update_internalorders import UpdateInternalorders
from .update_inventories import UpdateInventories
from .update_inventory import UpdateInventory
from .update_invoicein import UpdateInvoicein
from .update_invoiceins import UpdateInvoiceins
from .update_invoiceout import UpdateInvoiceout
from .update_invoiceouts import UpdateInvoiceouts
from .update_loss import UpdateLoss
from .update_losses import UpdateLosses
from .update_move import UpdateMove
from .update_moves import UpdateMoves
from .update_organization import UpdateOrganization
from .update_organizations import UpdateOrganizations
from .update_paymentin import UpdatePaymentin
from .update_paymentins import UpdatePaymentins
from .update_paymentout import UpdatePaymentout
from .update_paymentouts import UpdatePaymentouts
from .update_pricelist import UpdatePricelist
from .update_pricelists import UpdatePricelists
from .update_processing import UpdateProcessing
from .update_processingorder import UpdateProcessingorder
from .update_processingorders import UpdateProcessingorders
from .update_processingplan import UpdateProcessingplan
from .update_processingplanfolder import UpdateProcessingplanfolder
from .update_processingplanfolders import UpdateProcessingplanfolders
from .update_processingplans import UpdateProcessingplans
from .update_processingprocess import UpdateProcessingprocess
from .update_processingprocesses import UpdateProcessingprocesses
from .update_processings import UpdateProcessings
from .update_processingstage import UpdateProcessingstage
from .update_processingstages import UpdateProcessingstages
from .update_product import UpdateProduct
from .update_productfolder import UpdateProductfolder
from .update_productfolders import UpdateProductfolders
from .update_productionstagecompletion import UpdateProductionstagecompletion
from .update_productionstagecompletions import UpdateProductionstagecompletions
from .update_productiontask import UpdateProductiontask
from .update_productiontasks import UpdateProductiontasks
from .update_products import UpdateProducts
from .update_project import UpdateProject
from .update_projects import UpdateProjects
from .update_purchaseorder import UpdatePurchaseorder
from .update_purchaseorders import UpdatePurchaseorders
from .update_purchasereturn import UpdatePurchasereturn
from .update_purchasereturns import UpdatePurchasereturns
from .update_retaildemand import UpdateRetaildemand
from .update_retaildemands import UpdateRetaildemands
from .update_retaildrawercashins import UpdateRetaildrawercashins
from .update_retaildrawercashouts import UpdateRetaildrawercashouts
from .update_retailsalesreturn import UpdateRetailsalesreturn
from .update_retailsalesreturns import UpdateRetailsalesreturns
from .update_retailshift import UpdateRetailshift
from .update_retailstore import UpdateRetailstore
from .update_retailstores import UpdateRetailstores
from .update_retireorder import UpdateRetireorder
from .update_retireorders import UpdateRetireorders
from .update_role import UpdateRole
from .update_saleschannel import UpdateSaleschannel
from .update_saleschannels import UpdateSaleschannels
from .update_salesreturn import UpdateSalesreturn
from .update_salesreturns import UpdateSalesreturns
from .update_service import UpdateService
from .update_services import UpdateServices
from .update_states import UpdateStates
from .update_store import UpdateStore
from .update_stores import UpdateStores
from .update_supplies import UpdateSupplies
from .update_supply import UpdateSupply
from .update_task import UpdateTask
from .update_tasks import UpdateTasks
from .update_taxrate import UpdateTaxrate
from .update_taxrates import UpdateTaxrates
from .update_trackingcodeses import UpdateTrackingcodeses
from .update_uom import UpdateUom
from .update_uoms import UpdateUoms
from .update_variant import UpdateVariant
from .update_variants import UpdateVariants
from .update_webhook import UpdateWebhook
from .update_webhooks import UpdateWebhooks
from .update_webhookstock import UpdateWebhookstock
from .update_webhookstocks import UpdateWebhookstocks
from .upload_files import UploadFiles


__all__ = (
    "MSMethod",
    "CreateBonusprogram",
    "CreateBonustransaction",
    "CreateBundle",
    "CreateCashin",
    "CreateCashout",
    "CreateCommissionreportin",
    "CreateCommissionreportout",
    "CreateConsignment",
    "CreateContract",
    "CreateCounterparty",
    "CreateCounterpartyadjustment",
    "CreateCountry",
    "CreateCustomentity",
    "CreateCustomerorder",
    "CreateDemand",
    "CreateDiscount",
    "CreateEmissionorder",
    "CreateEmployee",
    "CreateEnter",
    "CreateExpenseitem",
    "CreateFacturein",
    "CreateFactureout",
    "CreateGroup",
    "CreateInternalorder",
    "CreateInventory",
    "CreateInvoicein",
    "CreateInvoiceout",
    "CreateLoss",
    "CreateMove",
    "CreateOrganization",
    "CreatePaymentin",
    "CreatePaymentout",
    "CreatePricelist",
    "CreateProcessing",
    "CreateProcessingorder",
    "CreateProcessingplan",
    "CreateProcessingplanfolder",
    "CreateProcessingprocess",
    "CreateProcessingstage",
    "CreateProduct",
    "CreateProductfolder",
    "CreateProductionstagecompletion",
    "CreateProductiontask",
    "CreateProject",
    "CreatePurchaseorder",
    "CreatePurchasereturn",
    "CreateRetaildemand",
    "CreateRetailsalesreturn",
    "CreateRetailshift",
    "CreateRetailstore",
    "CreateRetireorder",
    "CreateSaleschannel",
    "CreateSalesreturn",
    "CreateService",
    "CreateStore",
    "CreateSupply",
    "CreateTask",
    "CreateTaxrate",
    "CreateUom",
    "CreateVariant",
    "CreateWebhook",
    "CreateWebhookstock",
    "DeleteBonusprogram",
    "DeleteBonustransaction",
    "DeleteBundle",
    "DeleteCashin",
    "DeleteCashout",
    "DeleteCommissionreportin",
    "DeleteCommissionreportout",
    "DeleteConsignment",
    "DeleteContract",
    "DeleteCounterparty",
    "DeleteCounterpartyadjustment",
    "DeleteCountry",
    "DeleteCurrency",
    "DeleteCustomentity",
    "DeleteCustomerorder",
    "DeleteDemand",
    "DeleteDiscount",
    "DeleteEmployee",
    "DeleteEnter",
    "DeleteExpenseitem",
    "DeleteFacturein",
    "DeleteFactureout",
    "DeleteFile",
    "DeleteGroup",
    "DeleteImage",
    "DeleteInternalorder",
    "DeleteInventory",
    "DeleteInvoicein",
    "DeleteInvoiceout",
    "DeleteLoss",
    "DeleteMove",
    "DeleteNotes",
    "DeleteOrganization",
    "DeletePaymentin",
    "DeletePaymentout",
    "DeletePrepayment",
    "DeletePrepaymentreturn",
    "DeletePricelist",
    "DeleteProcessing",
    "DeleteProcessingorder",
    "DeleteProcessingplan",
    "DeleteProcessingplanfolder",
    "DeleteProcessingprocess",
    "DeleteProcessingstage",
    "DeleteProduct",
    "DeleteProductfolder",
    "DeleteProductionstagecompletion",
    "DeleteProductiontask",
    "DeleteProject",
    "DeletePublication",
    "DeletePurchaseorder",
    "DeletePurchasereturn",
    "DeleteRetaildemand",
    "DeleteRetaildrawercashin",
    "DeleteRetaildrawercashout",
    "DeleteRetailsalesreturn",
    "DeleteRetailshift",
    "DeleteRetailstore",
    "DeleteRetireorder",
    "DeleteRole",
    "DeleteSaleschannel",
    "DeleteSalesreturn",
    "DeleteService",
    "DeleteStore",
    "DeleteSupply",
    "DeleteTask",
    "DeleteTaxrate",
    "DeleteUom",
    "DeleteVariant",
    "DeleteWebhook",
    "DeleteWebhookstock",
    "GetAssortment",
    "GetAssortments",
    "GetAudit",
    "GetAudits",
    "GetBonusprogram",
    "GetBonusprograms",
    "GetBonustransaction",
    "GetBonustransactions",
    "GetBundle",
    "GetBundles",
    "GetCashier",
    "GetCashin",
    "GetCashins",
    "GetCashout",
    "GetCashouts",
    "GetCommissionreportin",
    "GetCommissionreportins",
    "GetCommissionreportout",
    "GetCommissionreportouts",
    "GetCompanysettings",
    "GetConsignment",
    "GetConsignments",
    "GetContentcard",
    "GetContentcards",
    "GetContract",
    "GetContracts",
    "GetCounterparties",
    "GetCounterparty",
    "GetCounterpartyadjustment",
    "GetCounterpartyadjustments",
    "GetCountries",
    "GetCountry",
    "GetCurrency",
    "GetCustomentities",
    "GetCustomentity",
    "GetCustomerorder",
    "GetCustomerorders",
    "GetDemand",
    "GetDemands",
    "GetDiscount",
    "GetDiscounts",
    "GetEmissionorder",
    "GetEmissionorders",
    "GetEmployee",
    "GetEmployees",
    "GetEnter",
    "GetEnters",
    "GetExpenseitem",
    "GetExpenseitems",
    "GetFacturein",
    "GetFactureins",
    "GetFactureout",
    "GetFactureouts",
    "GetFiles",
    "GetGroup",
    "GetGroups",
    "GetInternalorder",
    "GetInternalorders",
    "GetInventories",
    "GetInventory",
    "GetInvoicein",
    "GetInvoiceins",
    "GetInvoiceout",
    "GetInvoiceouts",
    "GetLoss",
    "GetLosses",
    "GetMove",
    "GetMoves",
    "GetNamedfilter",
    "GetNotes",
    "GetOrganization",
    "GetOrganizations",
    "GetPaymentin",
    "GetPaymentins",
    "GetPaymentout",
    "GetPaymentouts",
    "GetPrepayment",
    "GetPrepaymentreturn",
    "GetPrepaymentreturns",
    "GetPrepayments",
    "GetPricelist",
    "GetPricelists",
    "GetProcessing",
    "GetProcessingorder",
    "GetProcessingorders",
    "GetProcessingplan",
    "GetProcessingplanfolder",
    "GetProcessingplanfolders",
    "GetProcessingplans",
    "GetProcessingprocess",
    "GetProcessingprocesses",
    "GetProcessings",
    "GetProcessingstage",
    "GetProcessingstages",
    "GetProduct",
    "GetProductfolder",
    "GetProductfolders",
    "GetProductionstagecompletion",
    "GetProductionstagecompletions",
    "GetProductiontask",
    "GetProductiontasks",
    "GetProducts",
    "GetProfitByProduct",
    "GetProfitByVariant",
    "GetProject",
    "GetProjects",
    "GetPurchaseorder",
    "GetPurchaseorders",
    "GetPurchasereturn",
    "GetPurchasereturns",
    "GetRegion",
    "GetRegions",
    "GetRetaildemand",
    "GetRetaildemands",
    "GetRetaildrawercashin",
    "GetRetaildrawercashout",
    "GetRetailsalesreturn",
    "GetRetailsalesreturns",
    "GetRetailshift",
    "GetRetailshifts",
    "GetRetailstore",
    "GetRetailstores",
    "GetRetireorder",
    "GetRetireorders",
    "GetRole",
    "GetSaleplatform",
    "GetSaleplatforms",
    "GetSaleschannel",
    "GetSaleschannels",
    "GetSalesreturn",
    "GetSalesreturns",
    "GetService",
    "GetServices",
    "GetStock",
    "GetStockCurrent",
    "GetStore",
    "GetStores",
    "GetSupplies",
    "GetSupply",
    "GetTask",
    "GetTasks",
    "GetTaxrate",
    "GetTaxrates",
    "GetThing",
    "GetThings",
    "GetUom",
    "GetUoms",
    "GetUsersettings",
    "GetVariant",
    "GetVariants",
    "GetWebhook",
    "GetWebhooks",
    "GetWebhookstock",
    "GetWebhookstocks",
    "UpdateBonusprogram",
    "UpdateBonustransaction",
    "UpdateBonustransactions",
    "UpdateBundle",
    "UpdateBundles",
    "UpdateCashin",
    "UpdateCashins",
    "UpdateCashout",
    "UpdateCashouts",
    "UpdateCommissionreportin",
    "UpdateCommissionreportins",
    "UpdateCommissionreportouts",
    "UpdateConsignment",
    "UpdateConsignments",
    "UpdateContract",
    "UpdateContracts",
    "UpdateCounterparties",
    "UpdateCounterparty",
    "UpdateCounterpartyadjustment",
    "UpdateCounterpartyadjustments",
    "UpdateCountries",
    "UpdateCountry",
    "UpdateCurrencies",
    "UpdateCurrency",
    "UpdateCustomentity",
    "UpdateCustomerorder",
    "UpdateCustomerorders",
    "UpdateDemand",
    "UpdateDemands",
    "UpdateDiscount",
    "UpdateEmissionorder",
    "UpdateEmissionorders",
    "UpdateEmployee",
    "UpdateEnter",
    "UpdateEnters",
    "UpdateExpenseitem",
    "UpdateExpenseitems",
    "UpdateFacturein",
    "UpdateFactureins",
    "UpdateFactureout",
    "UpdateFactureouts",
    "UpdateGroup",
    "UpdateInternalorder",
    "UpdateInternalorders",
    "UpdateInventories",
    "UpdateInventory",
    "UpdateInvoicein",
    "UpdateInvoiceins",
    "UpdateInvoiceout",
    "UpdateInvoiceouts",
    "UpdateLoss",
    "UpdateLosses",
    "UpdateMove",
    "UpdateMoves",
    "UpdateOrganization",
    "UpdateOrganizations",
    "UpdatePaymentin",
    "UpdatePaymentins",
    "UpdatePaymentout",
    "UpdatePaymentouts",
    "UpdatePricelist",
    "UpdatePricelists",
    "UpdateProcessing",
    "UpdateProcessingorder",
    "UpdateProcessingorders",
    "UpdateProcessingplan",
    "UpdateProcessingplanfolder",
    "UpdateProcessingplanfolders",
    "UpdateProcessingplans",
    "UpdateProcessingprocess",
    "UpdateProcessingprocesses",
    "UpdateProcessings",
    "UpdateProcessingstage",
    "UpdateProcessingstages",
    "UpdateProduct",
    "UpdateProductfolder",
    "UpdateProductfolders",
    "UpdateProductionstagecompletion",
    "UpdateProductionstagecompletions",
    "UpdateProductiontask",
    "UpdateProductiontasks",
    "UpdateProducts",
    "UpdateProject",
    "UpdateProjects",
    "UpdatePurchaseorder",
    "UpdatePurchaseorders",
    "UpdatePurchasereturn",
    "UpdatePurchasereturns",
    "UpdateRetaildemand",
    "UpdateRetaildemands",
    "UpdateRetaildrawercashins",
    "UpdateRetaildrawercashouts",
    "UpdateRetailsalesreturn",
    "UpdateRetailsalesreturns",
    "UpdateRetailshift",
    "UpdateRetailstore",
    "UpdateRetailstores",
    "UpdateRetireorder",
    "UpdateRetireorders",
    "UpdateRole",
    "UpdateSaleschannel",
    "UpdateSaleschannels",
    "UpdateSalesreturn",
    "UpdateSalesreturns",
    "UpdateService",
    "UpdateServices",
    "UpdateStates",
    "UpdateStore",
    "UpdateStores",
    "UpdateSupplies",
    "UpdateSupply",
    "UpdateTask",
    "UpdateTasks",
    "UpdateTaxrate",
    "UpdateTaxrates",
    "UpdateTrackingcodeses",
    "UpdateUom",
    "UpdateUoms",
    "UpdateVariant",
    "UpdateVariants",
    "UpdateWebhook",
    "UpdateWebhooks",
    "UpdateWebhookstock",
    "UpdateWebhookstocks",
    "UploadFiles",
)
