from datetime import datetime

from pydantic import Field

from ..enums.cost_distribution_type import CostDistributionType
from .assortment import Assortment
from .group import Group
from .meta import Entity, MetaArray
from .product import Product


class Processingplan(Entity):
    archived: bool | None = Field(None, alias="archived")
    code: str | None = Field(None, alias="code")
    cost: float | None = Field(None, alias="cost")
    cost_distribution_type: CostDistributionType | None = Field(None, alias="costDistributionType")
    external_code: str | None = Field(None, alias="externalCode")
    group: Group | None = Field(None, alias="group")
    stages: dict | list | None = Field(None, alias="stages")
    materials: dict | list | None = Field(None, alias="materials")
    name: str | None = Field(None, alias="name")
    owner: dict | None = Field(None, alias="owner")
    parent: dict | None = Field(None, alias="parent")
    path_name: str | None = Field(None, alias="pathName")
    processing_process: dict | list | None = Field(None, alias="processingProcess")
    products: MetaArray[Product] | list[Product] | None = Field(None, alias="products")
    shared: bool | None = Field(None, alias="shared")
    updated: datetime | None = Field(None, alias="updated")
    enable_hour_accounting: bool | None = Field(None, alias="enableHourAccounting")
    labour_cost: float | None = Field(None, alias="labourCost")
    standard_hour: float | None = Field(None, alias="standardHour")
    processing_process_position: dict | None = Field(None, alias="processingProcessPosition")
    standard_hour_cost: float | None = Field(None, alias="standardHourCost")
    assortment: Assortment | None = Field(None, alias="assortment")
    product: Product | None = Field(None, alias="product")
    quantity: float | None = Field(None, alias="quantity")
    material_processing_plan: dict | None = Field(None, alias="materialProcessingPlan")
