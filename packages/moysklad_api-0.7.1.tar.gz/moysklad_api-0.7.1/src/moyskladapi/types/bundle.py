from datetime import datetime

from pydantic import Field

from ..enums.payment_item_type import PaymentItemType
from ..enums.tax_system import TaxSystem
from ..enums.tracking_type import TrackingType
from .assortment import Assortment
from .attribute import Attribute
from .barcode import Barcode
from .country import Country
from .currency import Currency
from .group import Group
from .image import Image
from .meta import Entity, MetaArray
from .uom import Uom


class Bundle(Entity):
    archived: bool | None = Field(None, alias="archived")
    article: str | None = Field(None, alias="article")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    barcodes: list[Barcode] | None = Field(None, alias="barcodes")
    code: str | None = Field(None, alias="code")
    components: dict | list | None = Field(None, alias="components")
    country: Country | None = Field(None, alias="country")
    description: str | None = Field(None, alias="description")
    discount_prohibited: bool | None = Field(None, alias="discountProhibited")
    effective_vat: int | None = Field(None, alias="effectiveVat")
    effective_vat_enabled: bool | None = Field(None, alias="effectiveVatEnabled")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    images: MetaArray[Image] | list[Image] | None = Field(None, alias="images")
    min_price: dict | None = Field(None, alias="minPrice")
    name: str | None = Field(None, alias="name")
    overhead: dict | None = Field(None, alias="overhead")
    owner: dict | None = Field(None, alias="owner")
    partial_disposal: bool | None = Field(None, alias="partialDisposal")
    path_name: str | None = Field(None, alias="pathName")
    payment_item_type: PaymentItemType | None = Field(None, alias="paymentItemType")
    product_folder: dict | None = Field(None, alias="productFolder")
    sale_prices: list | None = Field(None, alias="salePrices")
    shared: bool | None = Field(None, alias="shared")
    sync_id: str | None = Field(None, alias="syncId")
    tax_system: TaxSystem | None = Field(None, alias="taxSystem")
    tnved: str | None = Field(None, alias="tnved")
    tracking_type: TrackingType | None = Field(None, alias="trackingType")
    uom: Uom | None = Field(None, alias="uom")
    updated: datetime | None = Field(None, alias="updated")
    use_parent_vat: bool | None = Field(None, alias="useParentVat")
    vat: int | None = Field(None, alias="vat")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    volume: float | None = Field(None, alias="volume")
    weight: float | None = Field(None, alias="weight")
    ikpu: str | None = Field(None, alias="ikpu")
    pack_code: str | None = Field(None, alias="packCode")
    barcode_tasnif: str | None = Field(None, alias="barcodeTasnif")
    value: float | None = Field(None, alias="value")
    currency: Currency | None = Field(None, alias="currency")
    assortment: Assortment | None = Field(None, alias="assortment")
    quantity: float | None = Field(None, alias="quantity")
    ean13: dict | None = Field(None, alias="ean13")
    ean8: dict | None = Field(None, alias="ean8")
    code128: dict | None = Field(None, alias="code128")
    gtin: dict | None = Field(None, alias="gtin")
    upc: dict | None = Field(None, alias="upc")
    filename: str | None = Field(None, alias="filename")
    miniature: dict | None = Field(None, alias="miniature")
    tiny: dict | None = Field(None, alias="tiny")
    title: str | None = Field(None, alias="title")
    content: dict | None = Field(None, alias="content")
