from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .group import Group
from .meta import Entity
from .organization import Organization
from .processing import Processing
from .project import Project
from .state import State
from .store import Store


class Processingorder(Entity):
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    delivery_planned_moment: datetime | None = Field(None, alias="deliveryPlannedMoment")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    positions: dict | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    processing_plan: dict | None = Field(None, alias="processingPlan")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    quantity: float | None = Field(None, alias="quantity")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    store: Store | None = Field(None, alias="store")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    processings: list[Processing] | None = Field(None, alias="processings")
