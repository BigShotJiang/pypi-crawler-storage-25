from datetime import datetime

from pydantic import Field

from .assortment import Assortment
from .attribute import Attribute
from .group import Group
from .meta import Entity, MetaArray
from .organization import Organization
from .product import Product
from .project import Project
from .state import State


class Processing(Entity):
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    materials: dict | list | None = Field(None, alias="materials")
    materials_store: dict | None = Field(None, alias="materialsStore")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    organization_account: dict | None = Field(None, alias="organizationAccount")
    owner: dict | None = Field(None, alias="owner")
    printed: bool | None = Field(None, alias="printed")
    processing_plan: dict | None = Field(None, alias="processingPlan")
    processing_sum: int | None = Field(None, alias="processingSum")
    products: MetaArray[Product] | list[Product] | None = Field(None, alias="products")
    products_store: dict | None = Field(None, alias="productsStore")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    quantity: float | None = Field(None, alias="quantity")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    processing_order: dict | None = Field(None, alias="processingOrder")
    assortment: Assortment | None = Field(None, alias="assortment")
