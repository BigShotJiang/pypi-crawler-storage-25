from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import cast
from urllib.parse import quote, urlparse

from niquests.models import Response
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from syvain_metrics_collector.utils import (
    JsonObject,
    JsonPayload,
    JsonValue,
    normalize_query_values,
    query_string,
)


class MetricsCollectorError(RuntimeError):
    """Raised when the SDK cannot establish required experiment state."""


class MetricsRequestError(MetricsCollectorError):
    """Raised when a metrics HTTP request fails."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        retryable: bool,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.retryable = retryable


class ExperimentResponseModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    url: str
    slug: str
    description: str = ""
    metadata: JsonObject = Field(default_factory=dict)


class ExperimentCreateResponseModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    experiment: ExperimentResponseModel


class FolderResponseModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    folder_id: str
    path_name: str


class FoldersResponseModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    folders: list[FolderResponseModel]


class IngestionKeyModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    experiment_id: str
    name: str
    created_at_ms: int
    expires_at_ms: int
    revoked_at_ms: int | None = None
    last_used_at_ms: int | None = None


class IngestionKeyCreateResponseModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    key: IngestionKeyModel
    token: str


@dataclass(frozen=True)
class MetricCatalogItem:
    metric_name: str
    metadata_keys: tuple[str, ...] = ()


@dataclass(frozen=True)
class MetricCatalogMetadataValue:
    key: str
    values: tuple[JsonValue, ...]
    value_count: int


@dataclass(frozen=True)
class MetricCatalogValues:
    metric_name: str
    scanned_event_count: int
    keys: tuple[MetricCatalogMetadataValue, ...]


class MetricCatalogItemModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    metric_name: str
    metadata_keys: list[str] = Field(default_factory=list)


class MetricCatalogResponseModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    metrics: list[MetricCatalogItemModel]


class MetricCatalogMetadataValueModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    key: str
    values: list[JsonValue] = Field(default_factory=list)
    value_count: int


class MetricCatalogValuesModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    metric_name: str
    scanned_event_count: int
    keys: list[MetricCatalogMetadataValueModel] = Field(default_factory=list)


class MetricCatalogValuesResponseModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    metadata: MetricCatalogValuesModel


@dataclass(frozen=True)
class ApiExperiment:
    id: str
    url: str
    slug: str
    description: str
    metadata: JsonObject


@dataclass(frozen=True)
class IngestionCredential:
    token: str
    expires_at_ms: int


def _error_message_from_envelope(data: object) -> str | None:
    if not isinstance(data, Mapping):
        return None
    envelope = cast(Mapping[str, object], data)
    error = envelope.get("error")
    if not isinstance(error, Mapping):
        return error if isinstance(error, str) else None

    error_body = cast(Mapping[str, object], error)
    message_value = error_body.get("message")
    details_value = error_body.get("details")
    message = (
        message_value
        if isinstance(message_value, str) and message_value
        else "Metrics API request failed"
    )
    if isinstance(details_value, str) and details_value:
        return f"{message}: {details_value}"
    return message


def _response_error_message(response: Response) -> str:
    try:
        envelope_message = _error_message_from_envelope(response.json())
    except Exception:  # noqa: BLE001
        envelope_message = None
    if envelope_message:
        return envelope_message
    body = response.text or ""
    return body[:500] if body else "Metrics API request failed"


def _raise_for_metrics_response(response: Response) -> None:
    status_code = response.status_code
    if status_code is None:
        raise MetricsRequestError(
            "HTTP response did not include a status code",
            retryable=True,
        )
    if status_code >= 400:
        retryable = status_code in {408, 425, 429} or status_code >= 500
        raise MetricsRequestError(
            f"HTTP {status_code}: {_response_error_message(response)}",
            status_code=status_code,
            retryable=retryable,
        )


def _unwrap_metrics_response(data: object) -> JsonObject:
    if not isinstance(data, Mapping):
        raise MetricsCollectorError("Metrics API response must be a JSON object.")
    envelope = cast(Mapping[str, object], data)
    envelope_message = _error_message_from_envelope(data)
    if envelope_message:
        raise MetricsCollectorError(f"Metrics API error: {envelope_message}")
    if envelope.get("error") is not None:
        raise MetricsCollectorError("Metrics API response error must be null.")
    response_data = envelope.get("data")
    if not isinstance(response_data, Mapping):
        raise MetricsCollectorError("Metrics API response data must be a JSON object.")
    return cast(JsonObject, response_data)


def request_error(error: Exception, *, context: str) -> MetricsRequestError:
    if isinstance(error, MetricsRequestError):
        return error
    retryable = not isinstance(error, (TypeError, ValueError))
    return MetricsRequestError(
        f"{context} failed: {error}",
        retryable=retryable,
    )


@dataclass(frozen=True)
class MetricsApiClient:
    api_key: str
    host: str
    timeout: float
    ingest_timeout: float
    request: Callable[..., Response]

    def absolute_url(self, url: str) -> str:
        parsed = urlparse(url)
        if parsed.scheme and parsed.netloc:
            return url
        path = url if url.startswith("/") else f"/{url}"
        return f"{self.host.rstrip('/')}{path}"

    def headers(self, token: str | None = None) -> dict[str, str]:
        return {
            "authorization": f"Bearer {token or self.api_key}",
            "content-type": "application/json",
            "accept": "application/json",
        }

    def request_or_raise(
        self,
        method: str,
        path: str,
        payload: JsonObject | None,
        *,
        context: str = "creating experiment",
    ) -> JsonObject:
        try:
            if payload is None:
                response = self.request(
                    method,
                    f"{self.host}{path}",
                    headers=self.headers(),
                    timeout=self.timeout,
                )
            else:
                response = self.request(
                    method,
                    f"{self.host}{path}",
                    headers=self.headers(),
                    json=payload,
                    timeout=self.timeout,
                )
            _raise_for_metrics_response(response)
            data = response.json()
        except MetricsCollectorError:
            raise
        except Exception as error:
            raise MetricsCollectorError(
                f"Metrics API request failed while {context}: {error}"
            ) from error
        return _unwrap_metrics_response(data)

    def create_experiment(
        self,
        slug: str,
        description: str,
        metadata: JsonObject,
        *,
        folder_id: str | None = None,
    ) -> ApiExperiment:
        payload: JsonPayload = {
            "slug": slug,
            "description": description,
            "metadata": dict(metadata),
        }
        if folder_id is not None:
            payload["folder_id"] = folder_id
        data = self.request_or_raise("POST", "/api/v1/experiments", payload)
        try:
            response_model = ExperimentCreateResponseModel.model_validate(data)
        except ValidationError as error:
            raise MetricsCollectorError(
                "Experiment creation response did not match the expected schema."
            ) from error

        experiment = response_model.experiment
        return ApiExperiment(
            id=experiment.id,
            url=self.absolute_url(experiment.url),
            slug=experiment.slug,
            description=experiment.description,
            metadata=experiment.metadata,
        )

    def folder_id_for_path(self, folder_path: str) -> str:
        data = self.request_or_raise(
            "GET",
            f"/api/v1/folders{query_string({'path': folder_path})}",
            None,
            context="resolving experiment folder path",
        )
        try:
            folders = FoldersResponseModel.model_validate(data).folders
        except ValidationError as error:
            raise MetricsCollectorError(
                "Folder list response did not match the expected schema."
            ) from error
        if len(folders) == 0:
            raise MetricsCollectorError(
                f"No metrics folder found for path {folder_path!r}."
            )
        if len(folders) > 1:
            raise MetricsCollectorError(
                f"Expected one metrics folder for path {folder_path!r}, "
                f"but found {len(folders)}."
            )
        return folders[0].folder_id

    def create_ingestion_credential(self, experiment_id: str) -> IngestionCredential:
        data = self.request_or_raise(
            "POST",
            f"/api/v1/experiments/{quote(experiment_id, safe='')}/ingestion-keys",
            {"name": "SDK ingestion key"},
            context="minting ingestion key",
        )
        try:
            response_model = IngestionKeyCreateResponseModel.model_validate(data)
        except ValidationError as error:
            raise MetricsCollectorError(
                "Ingestion key response did not match the expected schema."
            ) from error
        return IngestionCredential(
            token=response_model.token,
            expires_at_ms=response_model.key.expires_at_ms,
        )

    def list_metric_catalog(
        self,
        experiment_id: str,
        *,
        limit: int | None = None,
    ) -> tuple[MetricCatalogItem, ...]:
        query = query_string({"limit": limit})
        data = self.request_or_raise(
            "GET",
            f"/api/v1/experiments/{quote(experiment_id, safe='')}/catalog{query}",
            None,
            context="listing metric catalog",
        )
        try:
            response_model = MetricCatalogResponseModel.model_validate(data)
        except ValidationError as error:
            raise MetricsCollectorError(
                "Metric catalog response did not match the expected schema."
            ) from error
        return tuple(
            MetricCatalogItem(
                metric_name=item.metric_name,
                metadata_keys=tuple(item.metadata_keys),
            )
            for item in response_model.metrics
        )

    def inspect_metric_catalog_values(
        self,
        experiment_id: str,
        metric_name: str,
        *,
        keys: str | list[str] | tuple[str, ...] | None = None,
        limit: int | None = None,
    ) -> MetricCatalogValues:
        key_values = normalize_query_values(keys)
        query = query_string({"key": key_values, "limit": limit})
        data = self.request_or_raise(
            "GET",
            "/api/v1/experiments/"
            f"{quote(experiment_id, safe='')}/catalog/{quote(metric_name, safe='')}{query}",
            None,
            context="inspecting metric catalog values",
        )
        try:
            response_model = MetricCatalogValuesResponseModel.model_validate(data)
        except ValidationError as error:
            raise MetricsCollectorError(
                "Metric catalog values response did not match the expected schema."
            ) from error
        metadata = response_model.metadata
        return MetricCatalogValues(
            metric_name=metadata.metric_name,
            scanned_event_count=metadata.scanned_event_count,
            keys=tuple(
                MetricCatalogMetadataValue(
                    key=item.key,
                    values=tuple(item.values),
                    value_count=item.value_count,
                )
                for item in metadata.keys
            ),
        )

    def post_ingest(
        self,
        experiment_id: str,
        token: str,
        payload: JsonPayload,
    ) -> None:
        response = self.request(
            "POST",
            f"{self.host}/api/v1/experiments/{experiment_id}/ingest",
            headers=self.headers(token),
            json=payload,
            timeout=self.ingest_timeout,
        )
        _raise_for_metrics_response(response)

    def post_annotation(
        self,
        experiment_id: str,
        token: str,
        payload: JsonPayload,
    ) -> None:
        response = self.request(
            "POST",
            f"{self.host}/api/v1/experiments/{experiment_id}/annotations",
            headers=self.headers(token),
            json=payload,
            timeout=self.timeout,
        )
        _raise_for_metrics_response(response)

    def post_status(
        self,
        experiment_id: str,
        payload: JsonObject,
    ) -> None:
        response = self.request(
            "POST",
            f"{self.host}/api/v1/experiments/{experiment_id}",
            headers=self.headers(),
            json=payload,
            timeout=self.timeout,
        )
        _raise_for_metrics_response(response)
