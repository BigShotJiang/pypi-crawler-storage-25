from __future__ import annotations

import time
from collections.abc import Mapping
from typing import Optional
from urllib.parse import urlencode

from typing_extensions import TypeAliasType

JsonValue = TypeAliasType(
    "JsonValue",
    str | int | float | bool | None | list["JsonValue"] | Mapping[str, "JsonValue"],
)
JsonObject = TypeAliasType("JsonObject", Mapping[str, JsonValue])
JsonPayload = TypeAliasType("JsonPayload", dict[str, JsonValue])


def now_ms() -> int:
    return int(time.time() * 1000)


def timestamp_ms(timestamp: Optional[float | int]) -> Optional[int]:
    if timestamp is None:
        return None
    if isinstance(timestamp, float) and timestamp < 10_000_000_000:
        return int(timestamp * 1000)
    return int(timestamp)


def normalize_query_values(
    value: str | list[str] | tuple[str, ...] | None,
) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return list(value)


def query_string(values: Mapping[str, int | str | list[str] | None]) -> str:
    params: list[tuple[str, str]] = []
    for key, value in values.items():
        if value is None:
            continue
        if isinstance(value, list):
            params.extend((key, item) for item in value if item)
            continue
        params.append((key, str(value)))

    query = urlencode(params)
    return f"?{query}" if query else ""
