from __future__ import annotations

import atexit
import hashlib
import json
import logging
import math
import sys
import threading
import traceback
from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from types import TracebackType
from typing import Callable, Generator, Optional, cast

import niquests

from syvain_metrics_collector.api import (
    IngestionCredential,
    MetricsApiClient,
    MetricsCollectorError,
    MetricsRequestError,
    request_error,
)
from syvain_metrics_collector.utils import (
    JsonObject,
    JsonPayload,
    now_ms,
    timestamp_ms,
)

Logger = logging.Logger


INGESTION_KEY_RENEWAL_SKEW_MS = 5 * 60 * 1000

__all__ = [
    "BaseCollector",
    "Collector",
    "Experiment",
    "FlushResult",
    "JsonObject",
    "JsonlCollector",
    "MetricsCollectorError",
    "NoopCollector",
]


@dataclass(frozen=True)
class FlushResult:
    delivered_metrics: int = 0
    delivered_annotations: int = 0
    delivered_statuses: int = 0
    dropped_metrics: int = 0
    dropped_annotations: int = 0
    dropped_statuses: int = 0
    retryable_failures: int = 0
    permanent_failures: int = 0
    pending_metrics: int = 0
    pending_annotations: int = 0
    pending_statuses: int = 0
    errors: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return (
            self.retryable_failures == 0
            and self.permanent_failures == 0
            and self.pending_metrics == 0
            and self.pending_annotations == 0
            and self.pending_statuses == 0
        )

    def merged(self, other: "FlushResult") -> "FlushResult":
        return FlushResult(
            delivered_metrics=self.delivered_metrics + other.delivered_metrics,
            delivered_annotations=self.delivered_annotations
            + other.delivered_annotations,
            delivered_statuses=self.delivered_statuses + other.delivered_statuses,
            dropped_metrics=self.dropped_metrics + other.dropped_metrics,
            dropped_annotations=self.dropped_annotations + other.dropped_annotations,
            dropped_statuses=self.dropped_statuses + other.dropped_statuses,
            retryable_failures=self.retryable_failures + other.retryable_failures,
            permanent_failures=self.permanent_failures + other.permanent_failures,
            pending_metrics=self.pending_metrics + other.pending_metrics,
            pending_annotations=self.pending_annotations + other.pending_annotations,
            pending_statuses=self.pending_statuses + other.pending_statuses,
            errors=(*self.errors, *other.errors),
        )

    def with_pending(
        self,
        *,
        metrics: int,
        annotations: int,
        statuses: int,
    ) -> "FlushResult":
        return FlushResult(
            delivered_metrics=self.delivered_metrics,
            delivered_annotations=self.delivered_annotations,
            delivered_statuses=self.delivered_statuses,
            dropped_metrics=self.dropped_metrics,
            dropped_annotations=self.dropped_annotations,
            dropped_statuses=self.dropped_statuses,
            retryable_failures=self.retryable_failures,
            permanent_failures=self.permanent_failures,
            pending_metrics=metrics,
            pending_annotations=annotations,
            pending_statuses=statuses,
            errors=self.errors,
        )

    def raise_for_failure(self) -> None:
        if self.ok:
            return
        details = "; ".join(self.errors[:3])
        suffix = f": {details}" if details else ""
        raise MetricsCollectorError(
            "Metrics flush incomplete "
            f"(pending_metrics={self.pending_metrics}, "
            f"pending_annotations={self.pending_annotations}, "
            f"pending_statuses={self.pending_statuses}, "
            f"retryable_failures={self.retryable_failures}, "
            f"permanent_failures={self.permanent_failures})"
            f"{suffix}"
        )


@dataclass
class _BufferedPayload:
    payload: JsonPayload
    failed_attempts: int = 0


@dataclass
class _IngestBuffer:
    experiment: "Experiment"
    metrics: list[_BufferedPayload] = field(default_factory=list)
    annotations: list[_BufferedPayload] = field(default_factory=list)
    timer: Optional[threading.Timer] = None


@dataclass
class _StatusBuffer:
    experiment: "Experiment"
    status: str
    payload: JsonPayload
    failed_attempts: int = 0
    timer: Optional[threading.Timer] = None


@dataclass(frozen=True)
class _DeliveryOutcome:
    success: bool
    error: MetricsRequestError | None = None


@dataclass(kw_only=True)
class BaseCollector(ABC):
    max_retries: int | None = None
    flush_delay_seconds: float = 0.25
    max_queue_items: int = 100_000
    max_batch_items: int = 500
    logger: Logger = field(default_factory=lambda: logging.getLogger("syvain.metrics"))
    _ingest_lock: threading.RLock = field(default_factory=threading.RLock, init=False)
    _ingest_buffers: dict[str, _IngestBuffer] = field(default_factory=dict, init=False)
    _experiments: dict[str, Experiment] = field(default_factory=dict, init=False)
    _experiments_lock: threading.RLock = field(
        default_factory=threading.RLock, init=False
    )
    _active_experiment: "Experiment | None" = field(
        default=None, init=False, repr=False
    )
    _pending_statuses: dict[str, _StatusBuffer] = field(
        default_factory=dict, init=False
    )

    def __post_init__(self) -> None:
        if self.max_retries is not None and self.max_retries < 0:
            raise ValueError("max_retries must be None or non-negative")
        if self.flush_delay_seconds < 0:
            raise ValueError("flush_delay_seconds must be non-negative")
        if self.max_queue_items < 1:
            raise ValueError("max_queue_items must be at least 1")
        if self.max_batch_items < 1:
            raise ValueError("max_batch_items must be at least 1")

    def experiment(
        self,
        slug: str,
        description: str = "",
        meta: Optional[JsonObject] = None,
        *,
        folder_id: str | None = None,
        folder_path: str | None = None,
    ) -> Experiment:
        if folder_id is not None and folder_path is not None:
            raise ValueError("folder_id and folder_path cannot both be provided")

        with self._experiments_lock:
            cached = self._experiments.get(slug)
            if cached is not None:
                return cached
            experiment = self._create_experiment(
                slug,
                description,
                dict(meta or {}),
                folder_id=folder_id,
                folder_path=folder_path,
            )
            self._experiments[slug] = experiment
            return experiment

    @abstractmethod
    def _create_experiment(
        self,
        slug: str,
        description: str,
        meta: JsonObject,
        *,
        folder_id: str | None,
        folder_path: str | None,
    ) -> Experiment:
        raise NotImplementedError

    def _activate_experiment(self, experiment: "Experiment") -> None:
        with self._experiments_lock:
            active = self._active_experiment
            if active is None:
                self._active_experiment = experiment
                return
            raise MetricsCollectorError(
                "Cannot start experiment "
                f"{experiment.slug!r} while experiment {active.slug!r} is active "
                "on the same collector."
            )

    def _deactivate_experiment(self, experiment: "Experiment") -> None:
        with self._experiments_lock:
            if self._active_experiment is experiment:
                self._active_experiment = None

    @abstractmethod
    def _write_metrics(
        self, experiment: "Experiment", payloads: list[JsonPayload]
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    def _write_annotation(self, experiment: "Experiment", payload: JsonPayload) -> None:
        raise NotImplementedError

    @abstractmethod
    def _write_status(self, experiment: "Experiment", payload: JsonObject) -> None:
        raise NotImplementedError

    def _handle_ingest_delivery_error(
        self,
        experiment: "Experiment",
        error: Exception,
    ) -> Exception:
        return error

    def _experiment_has_pending_ingest(self, experiment_id: str) -> bool:
        with self._ingest_lock:
            buffer = self._ingest_buffers.get(experiment_id)
            return buffer is not None and bool(buffer.metrics or buffer.annotations)

    def _deliver_status(
        self,
        experiment_id: str,
        payload: JsonObject,
    ) -> _DeliveryOutcome:
        with self._experiments_lock:
            experiment = next(
                (
                    candidate
                    for candidate in self._experiments.values()
                    if candidate.id == experiment_id
                ),
                None,
            )
        if experiment is None:
            return _DeliveryOutcome(
                success=False,
                error=MetricsRequestError(
                    f"unknown experiment id {experiment_id!r}",
                    retryable=False,
                ),
            )
        try:
            self._write_status(experiment, payload)
            return _DeliveryOutcome(success=True)
        except Exception as error:  # noqa: BLE001
            error_info = request_error(error, context="metrics status update")
            self.logger.warning("syvain metrics status update failed: %s", error_info)
            return _DeliveryOutcome(success=False, error=error_info)

    def _enqueue_metric(self, experiment: "Experiment", payload: JsonPayload) -> None:
        self._enqueue_ingest(experiment, metrics=[payload], annotations=[])

    def _enqueue_annotation(
        self, experiment: "Experiment", payload: JsonPayload
    ) -> None:
        self._enqueue_ingest(experiment, metrics=[], annotations=[payload])

    def _enqueue_ingest(
        self,
        experiment: "Experiment",
        *,
        metrics: list[JsonPayload],
        annotations: list[JsonPayload],
    ) -> None:
        with self._ingest_lock:
            buffer = self._ingest_buffers.setdefault(
                experiment.id, _IngestBuffer(experiment=experiment)
            )
            buffer.metrics.extend(_BufferedPayload(payload) for payload in metrics)
            buffer.annotations.extend(
                _BufferedPayload(payload) for payload in annotations
            )
            self._enforce_queue_limit_locked(experiment.id, buffer)
            self._schedule_ingest_flush_locked(experiment.id, buffer)

    def _enforce_queue_limit_locked(
        self,
        experiment_id: str,
        buffer: _IngestBuffer,
    ) -> None:
        overflow = len(buffer.metrics) + len(buffer.annotations) - self.max_queue_items
        if overflow <= 0:
            return

        dropped_metrics = min(overflow, len(buffer.metrics))
        if dropped_metrics:
            del buffer.metrics[:dropped_metrics]
            overflow -= dropped_metrics

        dropped_annotations = min(overflow, len(buffer.annotations))
        if dropped_annotations:
            del buffer.annotations[:dropped_annotations]

        self.logger.warning(
            "syvain metrics queue limit reached for experiment %s; "
            "dropped %s metrics and %s annotations",
            experiment_id,
            dropped_metrics,
            dropped_annotations,
        )

    def _schedule_ingest_flush_locked(
        self,
        experiment_id: str,
        buffer: _IngestBuffer,
    ) -> None:
        if buffer.timer is not None or not (buffer.metrics or buffer.annotations):
            return
        timer = threading.Timer(
            self.flush_delay_seconds,
            self._flush_experiment_ingest,
            args=(experiment_id,),
        )
        timer.daemon = True
        buffer.timer = timer
        timer.start()

    def _schedule_remaining_ingest(self, experiment_id: str) -> None:
        with self._ingest_lock:
            buffer = self._ingest_buffers.get(experiment_id)
            if buffer is not None:
                self._schedule_ingest_flush_locked(experiment_id, buffer)

    def _flush_ingest(self) -> FlushResult:
        result = FlushResult()
        failed_experiment_ids: set[str] = set()
        while True:
            with self._ingest_lock:
                experiment_ids = [
                    experiment_id
                    for experiment_id, buffer in self._ingest_buffers.items()
                    if experiment_id not in failed_experiment_ids
                    and (buffer.metrics or buffer.annotations)
                ]
            if not experiment_ids:
                return result

            for experiment_id in experiment_ids:
                batch_result = self._flush_experiment_ingest(experiment_id)
                result = result.merged(batch_result)
                if batch_result.retryable_failures:
                    failed_experiment_ids.add(experiment_id)

    def _pending_ingest_counts(self) -> tuple[int, int]:
        with self._ingest_lock:
            metrics = sum(
                len(buffer.metrics) for buffer in self._ingest_buffers.values()
            )
            annotations = sum(
                len(buffer.annotations) for buffer in self._ingest_buffers.values()
            )
            return metrics, annotations

    def _take_ingest_batch(
        self, experiment_id: str
    ) -> tuple[
        "Experiment | None",
        list[_BufferedPayload],
        list[_BufferedPayload],
    ]:
        with self._ingest_lock:
            buffer = self._ingest_buffers.get(experiment_id)
            if buffer is None:
                return None, [], []

            if buffer.timer is not None:
                buffer.timer.cancel()
                buffer.timer = None

            experiment = buffer.experiment
            remaining = self.max_batch_items
            metric_count = min(len(buffer.metrics), remaining)
            metrics = list(buffer.metrics[:metric_count])
            del buffer.metrics[:metric_count]
            remaining -= metric_count

            annotation_count = min(len(buffer.annotations), remaining)
            annotations = list(buffer.annotations[:annotation_count])
            del buffer.annotations[:annotation_count]

            if not buffer.metrics and not buffer.annotations:
                self._ingest_buffers.pop(experiment_id, None)

            return experiment, metrics, annotations

    def _requeue_ingest_batch(
        self,
        experiment: "Experiment",
        *,
        metrics: list[_BufferedPayload],
        annotations: list[_BufferedPayload],
    ) -> tuple[int, int]:
        requeued_metrics: list[_BufferedPayload] = []
        requeued_annotations: list[_BufferedPayload] = []
        dropped_metrics = 0
        dropped_annotations = 0

        for item in metrics:
            failed_attempts = item.failed_attempts + 1
            if self.max_retries is not None and failed_attempts > self.max_retries:
                dropped_metrics += 1
            else:
                requeued_metrics.append(
                    _BufferedPayload(item.payload, failed_attempts=failed_attempts)
                )

        for item in annotations:
            failed_attempts = item.failed_attempts + 1
            if self.max_retries is not None and failed_attempts > self.max_retries:
                dropped_annotations += 1
            else:
                requeued_annotations.append(
                    _BufferedPayload(item.payload, failed_attempts=failed_attempts)
                )

        with self._ingest_lock:
            if requeued_metrics or requeued_annotations:
                buffer = self._ingest_buffers.setdefault(
                    experiment.id, _IngestBuffer(experiment=experiment)
                )
                buffer.metrics = [*requeued_metrics, *buffer.metrics]
                buffer.annotations = [*requeued_annotations, *buffer.annotations]
                self._enforce_queue_limit_locked(experiment.id, buffer)
                self._schedule_ingest_flush_locked(experiment.id, buffer)

        if dropped_metrics or dropped_annotations:
            self.logger.warning(
                "syvain metrics retry limit reached for experiment %s; "
                "dropped %s metrics and %s annotations",
                experiment.id,
                dropped_metrics,
                dropped_annotations,
            )
        return dropped_metrics, dropped_annotations

    def _flush_experiment_ingest(self, experiment_id: str) -> FlushResult:
        experiment, metrics, annotations = self._take_ingest_batch(experiment_id)
        if experiment is None or (not metrics and not annotations):
            return FlushResult()

        pending_metrics = metrics
        pending_annotations = annotations
        delivered_metrics = 0
        delivered_annotations = 0

        try:
            if metrics:
                self._write_metrics(
                    experiment,
                    [item.payload for item in metrics],
                )
                pending_metrics = []
                delivered_metrics = len(metrics)

            for index, annotation in enumerate(annotations):
                pending_annotations = annotations[index:]
                self._write_annotation(experiment, annotation.payload)
                delivered_annotations += 1
            pending_annotations = []

            with self._ingest_lock:
                buffer = self._ingest_buffers.get(experiment.id)
                if buffer is not None:
                    self._schedule_ingest_flush_locked(experiment.id, buffer)
            return FlushResult(
                delivered_metrics=delivered_metrics,
                delivered_annotations=delivered_annotations,
            )
        except Exception as error:  # noqa: BLE001
            error = self._handle_ingest_delivery_error(experiment, error)
            error_info = request_error(error, context="metrics ingest flush")
            self.logger.warning("syvain metrics ingest flush failed: %s", error_info)
            if error_info.retryable:
                dropped_metrics, dropped_annotations = self._requeue_ingest_batch(
                    experiment,
                    metrics=pending_metrics,
                    annotations=pending_annotations,
                )
                self._schedule_remaining_ingest(experiment.id)
                return FlushResult(
                    delivered_metrics=delivered_metrics,
                    delivered_annotations=delivered_annotations,
                    dropped_metrics=dropped_metrics,
                    dropped_annotations=dropped_annotations,
                    retryable_failures=1,
                    errors=(str(error_info),),
                )
            self._schedule_remaining_ingest(experiment.id)
            return FlushResult(
                delivered_metrics=delivered_metrics,
                delivered_annotations=delivered_annotations,
                dropped_metrics=len(pending_metrics),
                dropped_annotations=len(pending_annotations),
                permanent_failures=1,
                errors=(str(error_info),),
            )

    def _enqueue_status(
        self,
        experiment: "Experiment",
        status: str,
        payload: JsonPayload,
        *,
        failed_attempts: int = 0,
    ) -> None:
        with self._ingest_lock:
            pending = self._pending_statuses.get(experiment.id)
            if pending is not None and pending.timer is not None:
                pending.timer.cancel()
            self._pending_statuses[experiment.id] = _StatusBuffer(
                experiment=experiment,
                status=status,
                payload=payload,
                failed_attempts=failed_attempts,
            )
            self._schedule_status_flush_locked(experiment.id)

    def _clear_pending_status(self, experiment_id: str) -> None:
        with self._ingest_lock:
            pending = self._pending_statuses.pop(experiment_id, None)
            if pending is not None and pending.timer is not None:
                pending.timer.cancel()

    def _clear_pending_terminal_status(self, experiment_id: str) -> None:
        with self._ingest_lock:
            pending = self._pending_statuses.get(experiment_id)
            if pending is not None and pending.status in {"done", "error"}:
                if pending.timer is not None:
                    pending.timer.cancel()
                self._pending_statuses.pop(experiment_id, None)

    def _has_pending_terminal_status(self, experiment_id: str) -> bool:
        with self._ingest_lock:
            pending = self._pending_statuses.get(experiment_id)
            return pending is not None and pending.status in {"done", "error"}

    def _pending_status_count(self) -> int:
        with self._ingest_lock:
            return len(self._pending_statuses)

    def _schedule_status_flush_locked(self, experiment_id: str) -> None:
        pending = self._pending_statuses.get(experiment_id)
        if pending is None or pending.timer is not None:
            return
        timer = threading.Timer(getattr(self, "flush_delay_seconds", 0.25), self.flush)
        timer.daemon = True
        pending.timer = timer
        timer.start()

    def _schedule_remaining_status(self, experiment_id: str) -> None:
        with self._ingest_lock:
            self._schedule_status_flush_locked(experiment_id)

    def flush(self) -> FlushResult:
        result = self._flush_ingest()
        result = result.merged(self._flush_pending_statuses())
        metrics, annotations = self._pending_ingest_counts()
        statuses = self._pending_status_count()
        return result.with_pending(
            metrics=metrics,
            annotations=annotations,
            statuses=statuses,
        )

    def flush_or_raise(self) -> FlushResult:
        result = self.flush()
        result.raise_for_failure()
        return result

    def _flush_pending_statuses(self) -> FlushResult:
        result = FlushResult()
        failed_experiment_ids: set[str] = set()
        while True:
            with self._ingest_lock:
                pending_statuses = [
                    (experiment_id, pending)
                    for experiment_id, pending in self._pending_statuses.items()
                    if experiment_id not in failed_experiment_ids
                ]
            if not pending_statuses:
                return result

            for experiment_id, pending in pending_statuses:
                if self._experiment_has_pending_ingest(experiment_id):
                    with self._ingest_lock:
                        if self._pending_statuses.get(experiment_id) is pending:
                            if pending.timer is not None:
                                pending.timer.cancel()
                            pending.timer = None
                            self._schedule_status_flush_locked(experiment_id)
                    failed_experiment_ids.add(experiment_id)
                    continue

                with self._ingest_lock:
                    if self._pending_statuses.get(experiment_id) is pending:
                        if pending.timer is not None:
                            pending.timer.cancel()
                        pending.timer = None

                outcome = self._deliver_status(experiment_id, pending.payload)
                if outcome.success:
                    with self._ingest_lock:
                        if self._pending_statuses.get(experiment_id) is pending:
                            self._pending_statuses.pop(experiment_id, None)
                    pending.experiment._mark_delivered_status(pending.status)
                    result = result.merged(FlushResult(delivered_statuses=1))
                    continue

                error = outcome.error
                if error is None:
                    error = MetricsRequestError(
                        "metrics status update failed without error details",
                        retryable=True,
                    )
                if error.retryable:
                    failed_attempts = pending.failed_attempts + 1
                    if (
                        self.max_retries is not None
                        and failed_attempts > self.max_retries
                    ):
                        with self._ingest_lock:
                            if self._pending_statuses.get(experiment_id) is pending:
                                self._pending_statuses.pop(experiment_id, None)
                        result = result.merged(
                            FlushResult(
                                dropped_statuses=1,
                                retryable_failures=1,
                                errors=(str(error),),
                            )
                        )
                    else:
                        pending.failed_attempts = failed_attempts
                        failed_experiment_ids.add(experiment_id)
                        self._schedule_remaining_status(experiment_id)
                        result = result.merged(
                            FlushResult(
                                retryable_failures=1,
                                errors=(str(error),),
                            )
                        )
                    continue

                with self._ingest_lock:
                    if self._pending_statuses.get(experiment_id) is pending:
                        self._pending_statuses.pop(experiment_id, None)
                result = result.merged(
                    FlushResult(
                        dropped_statuses=1,
                        permanent_failures=1,
                        errors=(str(error),),
                    )
                )


@dataclass
class Collector(BaseCollector):
    api_key: str
    host: str = "https://metrics.syvain.com"
    timeout: float = 10.0
    ingest_timeout: float = 60.0
    _client: MetricsApiClient = field(init=False, repr=False)
    _ingestion_credentials: dict[str, IngestionCredential] = field(
        default_factory=dict, init=False, repr=False
    )

    def __post_init__(self) -> None:
        super().__post_init__()
        self.host = self.host.rstrip("/")
        if self.timeout <= 0:
            raise ValueError("timeout must be greater than 0")
        if self.ingest_timeout <= 0:
            raise ValueError("ingest_timeout must be greater than 0")
        self._client = MetricsApiClient(
            api_key=self.api_key,
            host=self.host,
            timeout=self.timeout,
            ingest_timeout=self.ingest_timeout,
            request=niquests.request,
        )

    def _create_experiment(
        self,
        slug: str,
        description: str,
        meta: JsonObject,
        *,
        folder_id: str | None,
        folder_path: str | None,
    ) -> Experiment:
        resolved_folder_id = folder_id
        if folder_path is not None:
            resolved_folder_id = self._client.folder_id_for_path(folder_path)

        response_experiment = self._client.create_experiment(
            slug,
            description,
            meta,
            folder_id=resolved_folder_id,
        )
        experiment = Experiment(
            collector=self,
            id=response_experiment.id,
            url=response_experiment.url,
            slug=response_experiment.slug,
            description=response_experiment.description,
            meta=response_experiment.metadata,
        )
        self._ensure_ingestion_credential(experiment.id)
        return experiment

    def _ensure_ingestion_credential(self, experiment_id: str) -> IngestionCredential:
        with self._ingest_lock:
            cached = self._ingestion_credentials.get(experiment_id)
            if (
                cached is not None
                and cached.expires_at_ms - INGESTION_KEY_RENEWAL_SKEW_MS > now_ms()
            ):
                return cached

        credential = self._client.create_ingestion_credential(experiment_id)
        with self._ingest_lock:
            self._ingestion_credentials[experiment_id] = credential
        return credential

    def _forget_ingestion_credential(self, experiment_id: str) -> None:
        with self._ingest_lock:
            self._ingestion_credentials.pop(experiment_id, None)

    def _write_metrics(
        self, experiment: "Experiment", payloads: list[JsonPayload]
    ) -> None:
        payload = cast(JsonPayload, {"data": payloads})
        self._client.post_ingest(
            experiment.id,
            self._ensure_ingestion_credential(experiment.id).token,
            payload,
        )

    def _write_annotation(self, experiment: "Experiment", payload: JsonPayload) -> None:
        self._client.post_annotation(
            experiment.id,
            self._ensure_ingestion_credential(experiment.id).token,
            payload,
        )

    def _write_status(self, experiment: "Experiment", payload: JsonObject) -> None:
        self._client.post_status(experiment.id, payload)

    def _handle_ingest_delivery_error(
        self,
        experiment: "Experiment",
        error: Exception,
    ) -> Exception:
        if isinstance(error, MetricsRequestError) and error.status_code in {401, 403}:
            self._forget_ingestion_credential(experiment.id)
            return MetricsRequestError(
                str(error),
                status_code=error.status_code,
                retryable=True,
            )
        return error


def _local_experiment_id(slug: str) -> str:
    digest = hashlib.sha256(slug.encode("utf-8")).hexdigest()[:16]
    return f"local_{digest}"


@dataclass
class NoopCollector(BaseCollector):
    def _create_experiment(
        self,
        slug: str,
        description: str,
        meta: JsonObject,
        *,
        folder_id: str | None,
        folder_path: str | None,
    ) -> Experiment:
        experiment_id = _local_experiment_id(slug)
        return Experiment(
            collector=self,
            id=experiment_id,
            url=f"local://syvain-metrics/experiments/{experiment_id}",
            slug=slug,
            description=description,
            meta=meta,
        )

    def _write_metrics(
        self, experiment: "Experiment", payloads: list[JsonPayload]
    ) -> None:
        return

    def _write_annotation(self, experiment: "Experiment", payload: JsonPayload) -> None:
        return

    def _write_status(self, experiment: "Experiment", payload: JsonObject) -> None:
        return


@dataclass
class JsonlCollector(NoopCollector):
    path: Path = field(default_factory=lambda: Path("metrics.jsonl"))

    def __post_init__(self) -> None:
        super().__post_init__()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _write(self, payload: JsonPayload) -> None:
        line = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        with self._ingest_lock:
            with self.path.open("a", encoding="utf-8") as file:
                file.write(line + "\n")

    def _write_metrics(
        self, experiment: "Experiment", payloads: list[JsonPayload]
    ) -> None:
        for payload in payloads:
            self._write(
                {
                    "type": "metric",
                    "slug": experiment.slug,
                    **payload,
                }
            )

    def _write_annotation(self, experiment: "Experiment", payload: JsonPayload) -> None:
        self._write(
            {
                "type": "annotation",
                "slug": experiment.slug,
                **payload,
            }
        )

    def _write_status(self, experiment: "Experiment", payload: JsonObject) -> None:
        self._write(
            {
                "type": "status",
                "slug": experiment.slug,
                **payload,
            }
        )


@dataclass
class Experiment:
    collector: BaseCollector
    id: str
    url: str
    slug: str
    description: str = ""
    meta: JsonObject = field(default_factory=dict)
    started: bool = False
    terminal: bool = False
    _state_lock: threading.RLock = field(
        default_factory=threading.RLock,
        init=False,
        repr=False,
    )
    _hooks_lock: threading.RLock = field(
        default_factory=threading.RLock,
        init=False,
        repr=False,
    )
    _installed_hooks: bool = field(default=False, init=False, repr=False)
    _previous_excepthook: Callable[
        [type[BaseException], BaseException, Optional[TracebackType]], None
    ] = field(default=sys.excepthook, init=False, repr=False)
    _installed_excepthook: (
        Callable[[type[BaseException], BaseException, Optional[TracebackType]], None]
        | None
    ) = field(default=None, init=False, repr=False)

    def start(
        self,
        *,
        install_hooks: bool = True,
    ) -> None:
        self.collector._activate_experiment(self)
        try:
            if install_hooks:
                self._install_terminal_hooks()
            self._status("running")
        except BaseException:
            self.collector._deactivate_experiment(self)
            self._remove_terminal_hooks()
            raise

    @contextmanager
    def run(self, *, install_hooks: bool = True) -> Generator["Experiment", None, None]:
        self.start(install_hooks=install_hooks)
        try:
            yield self
        except BaseException as error:
            self.error(error)
            raise
        else:
            self.done()

    def metric(
        self,
        name: str,
        value: float,
        step: int | None,
        metadata: Optional[JsonObject] = None,
        timestamp: Optional[float | int] = None,
    ) -> None:
        metric_value = float(value)
        if not math.isfinite(metric_value):
            self.collector.logger.warning(
                "syvain metrics dropped non-finite metric value for %s: %s",
                name,
                metric_value,
            )
            return
        payload: JsonPayload = {
            "name": name,
            "value": metric_value,
            "step": step,
            "metadata": dict(metadata or {}),
        }
        normalized_timestamp_ms = timestamp_ms(timestamp)
        if normalized_timestamp_ms is not None:
            payload["timestamp_ms"] = normalized_timestamp_ms
        self.collector._clear_pending_terminal_status(self.id)
        self.collector._enqueue_metric(self, payload)
        with self._state_lock:
            self.started = True
            self.terminal = False

    def annotation(
        self,
        annotation: str,
        metadata: Optional[JsonObject] = None,
    ) -> None:
        payload: JsonPayload = {
            "annotation": annotation,
            "metadata": dict(metadata or {}),
        }
        self.collector._enqueue_annotation(self, payload)

    def flush(self) -> FlushResult:
        return self.collector.flush()

    def flush_or_raise(self) -> FlushResult:
        return self.collector.flush_or_raise()

    def done(self) -> None:
        try:
            self._status("done")
        finally:
            self._remove_terminal_hooks()
            self.collector._deactivate_experiment(self)

    def error(
        self,
        error: BaseException | str,
    ) -> None:
        if isinstance(error, BaseException):
            detail = "".join(
                traceback.format_exception(type(error), error, error.__traceback__)
            )
            name = type(error).__name__
        else:
            detail = error
            name = "Error"
        try:
            self._status(
                "error",
                error_payload={"name": name, "detail": detail},
            )
        finally:
            self._remove_terminal_hooks()
            self.collector._deactivate_experiment(self)

    def _status(
        self,
        status: str,
        *,
        error_payload: Optional[JsonObject] = None,
    ) -> None:
        payload: JsonPayload = {"status": status}
        if error_payload is not None:
            payload["error"] = dict(error_payload)
        self.collector._enqueue_status(self, status, payload)
        self._mark_requested_status(status)

    def _mark_requested_status(self, status: str) -> None:
        with self._state_lock:
            self.started = self.started or status == "running"
            self.terminal = status in {"done", "error"}

    def _mark_delivered_status(self, status: str) -> None:
        with self._state_lock:
            self.started = self.started or status == "running"
            self.terminal = status in {"done", "error"}

    def _install_terminal_hooks(self) -> None:
        with self._hooks_lock:
            if self._installed_hooks:
                return
            self._installed_hooks = True
            self._previous_excepthook = sys.excepthook
            atexit.register(self._on_exit)

            def hook(
                exc_type: type[BaseException],
                exc: BaseException,
                tb: Optional[TracebackType],
            ) -> None:
                self.error(exc)
                self._previous_excepthook(exc_type, exc, tb)

            self._installed_excepthook = hook
            sys.excepthook = hook

    def _remove_terminal_hooks(self) -> None:
        with self._hooks_lock:
            if not self._installed_hooks:
                return
            self._installed_hooks = False
            try:
                atexit.unregister(self._on_exit)
            except ValueError:
                pass
            if sys.excepthook is self._installed_excepthook:
                sys.excepthook = self._previous_excepthook
            self._installed_excepthook = None

    def _on_exit(self) -> None:
        if (
            self.started
            and not self.terminal
            and not self.collector._has_pending_terminal_status(self.id)
        ):
            self.done()
        self.collector.flush()
