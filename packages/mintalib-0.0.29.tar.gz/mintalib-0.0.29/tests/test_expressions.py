import pytest

from mintalib import expressions
from mintalib.samples import sample_prices
from mintalib.testing import sample_params

pl = None
try:
    import polars as pl
except ImportError:
    pass


def list_expressions():
    return [k for k, v in vars(expressions).items() if k.isupper() and callable(v)]


@pytest.fixture(scope="module")
def prices():
    if pl is None:
        pytest.skip("requires polars")
    data = sample_prices()
    return pl.from_pandas(data, include_index=True, nan_to_null=True)


@pytest.mark.skipif(pl is None, reason="requires polars")
@pytest.mark.parametrize("name", list_expressions())
def test_expression(name, prices):
    func = getattr(expressions, name)
    kwds = sample_params(func)
    expr = func(**kwds)
    if isinstance(expr, tuple):
        result = prices.select(*expr)
    else:
        result = prices.select(expr)
    assert result is not None
    assert len(result) > 0
