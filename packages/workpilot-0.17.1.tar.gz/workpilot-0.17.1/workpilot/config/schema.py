"""
Configuration schema — Pydantic v2 models for WorkPilot.

All sensitive fields use SecretStr so they are never accidentally logged or serialised.
"""

from __future__ import annotations

from enum import Enum, StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, SecretStr, model_validator

# ── Enums ────────────────────────────────────────────────────────────────────


class LogLevel(str, Enum):
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class ChannelType(StrEnum):
    CLI = "cli"
    WEB = "web"
    CLOUD = "cloud"

    @classmethod
    def of(cls, value: str | None, default: ChannelType | None = None) -> ChannelType:
        """Convert a string to ChannelType. Returns *default* (or CLI) for None/empty/unknown."""
        if not value:
            return default if default is not None else cls.CLI
        try:
            return cls(value)
        except ValueError:
            return default if default is not None else cls.CLI


class SecurityProfile(str, Enum):
    """Security profile presets — higher = more restrictive."""

    OPEN = "open"
    STANDARD = "standard"
    CONTROLLED = "controlled"
    RESTRICTED = "restricted"


class AutonomyLevel(int, Enum):
    """Progressive autonomy levels for agent actions."""

    FORBIDDEN = 0  # Level 0: action is prohibited
    APPROVAL = 1  # Level 1: agent executes after human confirms
    NOTIFY = 2  # Level 2: agent executes, then notifies
    AUTONOMOUS = 3  # Level 3: agent executes silently (audit log only)


# ── Provider configs ─────────────────────────────────────────────────────────


class ProviderConfig(BaseModel):
    """OpenAI-compatible provider config.

    Works for OpenAI, Azure OpenAI, Azure AI Foundry, and any OpenAI-compatible endpoint.
    WorkPilot detects the service from the endpoint URL:
    - no endpoint           → OpenAI direct          (model prefix: openai/)
    - *.openai.azure.com    → Azure OpenAI Service   (model prefix: azure/)
    - anything else         → Azure AI Foundry        (model prefix: azure_ai/)
    """

    api_key: SecretStr | None = Field(
        default=None,
        description="API key for OpenAI/Azure OpenAI-compatible endpoint.",
    )
    endpoint: str | None = Field(
        default=None,
        description=(
            "Base endpoint URL. Leave empty for OpenAI direct; set Azure endpoint "
            "for Azure OpenAI (for example: https://xxx.openai.azure.com)."
        ),
    )
    api_version: str = Field(
        default="2024-10-21",
        description="Azure OpenAI / Azure AI Foundry API version (used for azure/* and azure_ai/* models).",
    )


class GitHubCopilotConfig(BaseModel):
    """GitHub Copilot authentication settings."""

    token: SecretStr | None = Field(
        default=None,
        description="GitHub OAuth token used to exchange a Copilot session token.",
    )


class ModelAlias(BaseModel):
    """Named model aliases for convenience.

    Use "auto" to let WorkPilot pick the best available model
    based on configured provider credentials.
    """

    default: str | list[str] = Field(
        default="auto",
        description=(
            "Primary model alias. Use a concrete model ID, 'auto', or an ordered "
            "list for fallback (for example: ['github/gpt-5.4', 'github/gpt-5.2'])."
        ),
    )
    fast: str | list[str] = Field(
        default="auto",
        description=(
            "Low-latency alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )
    reasoning: str | list[str] = Field(
        default="auto",
        description=(
            "Deep-reasoning alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )
    coding: str | list[str] = Field(
        default="auto",
        description=(
            "Coding-optimized alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )


class ModelRouting(BaseModel):
    """Alias candidate chains used when alias values are set to "auto".

    Supported candidate item formats:
    - concrete model id: github/gpt-5.4, openai/gpt-4o-mini, azure/gpt-4o
    - smart OpenAI tokens: openai:auto, openai:fast, openai:reasoning

    Resolution rule: pick the first candidate with available credentials,
    then continue with the rest as runtime fallback candidates.
    """

    default_candidates: list[str] = Field(
        default_factory=lambda: ["github/gpt-5.4", "github/gpt-5.2", "openai:auto"],
        description="Candidate chain for alias 'auto' (and 'coding' when coding=auto).",
    )
    fast_candidates: list[str] = Field(
        default_factory=lambda: [
            "github/gpt-5-mini",
            "github/claude-haiku-4.5",
            "openai:fast",
        ],
        description="Candidate chain for alias 'fast'.",
    )
    reasoning_candidates: list[str] = Field(
        default_factory=lambda: ["github/o3", "openai:reasoning"],
        description="Candidate chain for alias 'reasoning'.",
    )


class ProvidersConfig(BaseModel):
    """Top-level provider configuration used by model routing and auth.

    Minimal examples:

    1) GitHub-only:
         providers:
             github_copilot:
                 token: ${GITHUB_TOKEN}

    2) GitHub + Azure OpenAI:
         providers:
             github_copilot:
                 token: ${GITHUB_TOKEN}
             openai:
                 api_key: ${AZURE_OPENAI_API_KEY}
                 endpoint: ${AZURE_OPENAI_ENDPOINT}

    3) Custom routing order:
         providers:
             routing:
                 default_candidates: [github/gpt-5.4, github/gpt-5.2, openai:auto]
                 fast_candidates: [github/gpt-5-mini, openai:fast]
    """

    openai: ProviderConfig = Field(default_factory=ProviderConfig)
    github_copilot: GitHubCopilotConfig = Field(default_factory=GitHubCopilotConfig)
    aliases: ModelAlias = Field(default_factory=ModelAlias)
    routing: ModelRouting = Field(default_factory=ModelRouting)


# ── Agent config ─────────────────────────────────────────────────────────────


class AgentConfig(BaseModel):
    name: str = "WorkPilot"
    description: str = ""
    model: str = "auto"
    instructions: str = Field(
        default="",
        description="Agent instructions. For built-in agents (explorer, default), prefer ~/.workpilot/EXPLORER.md or AGENTS.md instead.",
    )
    max_iterations: int = Field(default=40, ge=1)
    timeout: int = Field(default=1200, ge=0)
    memory_window: int = Field(default=50, ge=1)
    memory_writable: bool = True
    compaction_keep_min_turns: int = Field(default=5, ge=1)
    compaction_keep_min_msgs: int = Field(default=15, ge=1)
    compaction_topic_threshold: float = Field(default=0.3, ge=0.0, le=1.0)
    context_limit: int | None = Field(
        default=None, ge=1
    )  # None = auto-detect from model; set explicitly to override
    reminder_interval: int = Field(
        default=10, ge=0
    )  # Inject a system reminder every N tool calls (0 = disabled)
    max_spawn_depth: int = Field(default=2, ge=0)
    tools: list[str] | None = Field(
        default_factory=list
    )  # None=all tools; default [] for YAML safety
    skills: list[str] = Field(default_factory=list)
    chat: bool = True
    enabled: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)
    # Identity files
    soul_file: str | None = None  # SOUL.md path
    user_file: str | None = None  # USER.md path (auto-learning)
    agents_file: str | None = None  # AGENTS.md path (multi-agent rules)
    # Per-agent permissions
    permissions: AgentPermissions | None = None


class AgentPermissions(BaseModel):
    """Per-agent permission overrides."""

    allow_shell: bool = True
    allow_file_write: bool = True
    allow_file_read: bool = True
    allow_network: bool = True
    allow_browser: bool = False
    allow_spawn: bool = False
    allowed_tools: list[str] = Field(default_factory=lambda: ["*"])
    denied_tools: list[str] = Field(default_factory=list)


# Update forward reference
AgentConfig.model_rebuild()


class AgentsConfig(BaseModel):
    default: AgentConfig = Field(default_factory=AgentConfig)
    agents: dict[str, AgentConfig] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def _flatten_agents(cls, data: Any) -> Any:
        """Allow extra agents at the top level instead of under an 'agents' key.

        Both formats are accepted:
          agents:            agents:
            reviewer: ...      agents:
                                 reviewer: ...
        """
        if not isinstance(data, dict):
            return data
        data = dict(data)
        extra: dict[str, Any] = {}
        reserved = {"default", "agents"}
        for key in list(data):
            if key not in reserved:
                extra[key] = data.pop(key)
        if extra:
            nested = data.get("agents", {})
            if not isinstance(nested, dict):
                raise ValueError(f"'agents' must be a mapping, got {type(nested).__name__}")
            duplicates = set(nested).intersection(extra)
            if duplicates:
                raise ValueError(
                    f"Agent(s) defined both at top level and under 'agents': "
                    f"{', '.join(sorted(duplicates))}. Remove the duplicate."
                )
            nested.update(extra)
            data["agents"] = nested
        return data


# ── Tools config ─────────────────────────────────────────────────────────────


class ShellConfig(BaseModel):
    """Shell execution guardrails."""

    timeout: int = Field(default=120, ge=1)
    deny_patterns: list[str] = Field(
        default_factory=lambda: [
            r"rm\s+-rf\s+/",
            r":\(\)\s*\{\s*:\|:&\s*\}\s*;",
            r"\bformat\b.*[A-Z]:",
            r"\bshutdown\b",
            r"\breboot\b",
            r"\bmkfs\b",
            r"\bdd\b\s+if=.*/dev/",
            r"\b(curl|wget)\b.*\|\s*(ba)?sh",
            r"\bchmod\b\s+777\b",
            r"\bchown\b\s+-R\s+root",
        ]
    )
    allow_patterns: list[str] = Field(default_factory=list)


class FileSystemConfig(BaseModel):
    """File system tool settings."""

    max_file_size_bytes: int = 10 * 1024 * 1024  # 10 MB


class BrowserConfig(BaseModel):
    """Browser automation (Playwright) settings."""

    enabled: bool = True
    browser: Literal["msedge", "chrome", "chromium", "firefox"] = "msedge"
    headless: bool = True
    timeout: int = Field(default=30_000, ge=0)
    viewport_width: int = Field(default=1280, ge=1)
    viewport_height: int = Field(default=720, ge=1)
    evaluate_enabled: bool = True  # allow JS evaluation
    allowed_domains: list[str] = Field(default_factory=list)  # empty = all (with SSRF rules)
    # Profile mode:
    #   auto      — default; resolved at runtime: workpilot in open/standard,
    #               ephemeral in controlled/restricted
    #   ephemeral — fresh context each run, nothing persisted
    #   workpilot — isolated ~/.workpilot/browser-profile/<engine>, persists logins;
    #               <engine> follows the Playwright engine actually writing to the
    #               dir. Initial launch uses the configured OS binary
    #               (browser=msedge → .../msedge); only after an OS-binary launch
    #               fails does the tool reroute to bundled chromium and the dir
    #               follows to .../chromium to avoid schema collisions. The
    #               cdp_attach launch_mode uses a `-cdp` suffix (.../msedge-cdp)
    #               so subprocess-launched browsers never share a dir with
    #               managed launches. Allowed explicitly under any security
    #               profile.
    #   system    — user's real browser user-data-dir. HIGH RISK: exposes every
    #               logged-in session. Hard-rejected in controlled/restricted at
    #               config-load AND runtime; gated by score=8 approval in open/standard.
    profile_mode: Literal["auto", "ephemeral", "workpilot", "system"] = "auto"
    persistent_profile: str | None = None  # explicit path override (bypasses profile_mode)
    recording_dir: str | None = None  # where start_recording writes .webm files
    mark_content_untrusted: bool = True  # wrap extracted content as untrusted
    # Launch mode — how the OS browser process is started and reached:
    #   managed    — Playwright's launch_persistent_context. Standard path;
    #                Playwright owns the process and injects debug flags.
    #   cdp_attach — Subprocess-spawn the OS browser with
    #                --remote-debugging-port and connect_over_cdp. Minimal
    #                flags, so Windows Credential Manager / WAM / corporate
    #                MDM sign-in policies apply naturally. Chromium-family
    #                only (msedge/chrome/chromium — firefox is unsupported
    #                because Playwright's Firefox protocol is BiDi, not CDP).
    #                Loses Playwright's video recording (record_video_dir).
    #   auto       — Default. Try managed OS binary first; if it fails and
    #                the engine is Chromium-family, try cdp_attach; final
    #                fallback is managed bundled Chromium. Covers both
    #                personal machines (managed wins immediately) and
    #                corporate-managed Windows (managed fails on MDM
    #                BrowserSignin, cdp_attach succeeds via silent WAM SSO).
    launch_mode: Literal["managed", "cdp_attach", "auto"] = "auto"


class MCPAuthConfig(BaseModel):
    """Authentication config for HTTP MCP servers."""

    type: Literal["none", "implicit", "bearer", "oauth"] = "none"
    token: SecretStr | None = None
    token_env: str | None = None
    client_id: str | None = None
    client_secret: SecretStr | None = None
    scopes: list[str] = Field(default_factory=list)
    grant_type: Literal["authorization_code", "client_credentials"] | None = None
    callback_port: int | None = Field(default=None, ge=0, le=65535)
    auth_server_url: str | None = None


class MCPServerConfig(BaseModel):
    """Configuration for a single MCP server."""

    # Connection
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    url: str | None = None
    env: dict[str, str] = Field(default_factory=dict)

    # Metadata
    description: str | None = Field(None, max_length=100)  # one-line summary (≤100 chars)
    enabled: bool | Literal["auto"] = True  # True/False/"auto" (auto = connect if token cached)

    # Per-server overrides (all optional)
    timeout: int | None = Field(default=None, ge=1)
    risk: int | str | None = Field(
        None, description="Server default risk: int (score) or str (LLM prompt)"
    )
    tool_risks: dict[str, int | str] = Field(
        default_factory=dict,
        description="Per-tool risk overrides. Key=tool_name, value=int (score) or str (prompt).",
    )
    risk_rules: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Conditional risk rules. [{match: {tool: regex, arg: regex}, risk: int|str}]",
    )
    # Auth (HTTP transport only)
    auth: MCPAuthConfig = Field(default_factory=MCPAuthConfig)
    # Extra static HTTP headers merged with auth headers (HTTP transport only)
    headers: dict[str, str] = Field(default_factory=dict)

    @property
    def is_agency(self) -> bool:
        """Auto-detect Agency-proxied servers by command name."""
        return self.command == "agency"


class CopilotModelPolicyConfig(BaseModel):
    """Per-task-type default model. Overrides default_model when set."""

    code: str = "claude-sonnet-4.6"
    review: str = "claude-sonnet-4.6"
    test: str = "claude-haiku-4.5"
    refactor: str = "claude-sonnet-4.6"


class CopilotRetryConfig(BaseModel):
    enabled: bool = False
    max_attempts: int = Field(default=2, ge=1)


class CopilotHooksConfig(BaseModel):
    block_copilot_tools: list[str] = Field(default_factory=list)
    # Controls the SDK permission callback's grey-area decision — i.e., tool
    # requests the Copilot CLI didn't already resolve via its own allow/deny
    # rules in ``~/.copilot/``. When True (default), grey-area requests are
    # approved; False denies them. Either way, the CLI's own allow-list may
    # still permit a tool, and ``block_copilot_tools`` remains an additional
    # WorkPilot-side deny layer applied in ``on_pre_tool_use``. A per-task
    # ``auto_approve`` arg on the ``github_copilot`` tool overrides this.
    auto_approve: bool = True


class CopilotToolConfig(BaseModel):
    """GitHub Copilot CLI delegate tool settings."""

    enabled: bool = True
    cli_path: str | None = (
        None  # None = use SDK bundled binary; set to override (e.g. "/usr/local/bin/copilot")
    )
    default_model: str = "claude-sonnet-4.6"
    task_timeout: int = Field(default=0, ge=0)  # seconds; 0 = use 1h cap (SDK default is only 60s)
    # Soft cap for ``mode=wait`` — after this many seconds the tool returns a
    # "task detached to background" result so the agent turn doesn't block
    # indefinitely. The underlying Copilot session keeps running and its
    # result is delivered via the outbound persistence mechanism (see
    # ``design/core/outbound-persistence.md``).
    wait_timeout: int = Field(default=900, ge=60)  # 15 min default
    max_concurrent: int = Field(default=5, ge=1)  # max parallel background tasks; must be >= 1
    # Soft cap on the delegate's result body included in the user-visible
    # notification. ``0`` = no truncation (default) — since results are now
    # persisted into session JSONL and rendered via markdown, preserving the
    # full text is the right default. Set to a positive value only if you
    # have a specific channel constraint (e.g. a downstream push frame limit).
    notification_max_chars: int = Field(default=0, ge=0)
    model_policy: CopilotModelPolicyConfig = Field(default_factory=CopilotModelPolicyConfig)
    retry: CopilotRetryConfig = Field(default_factory=CopilotRetryConfig)
    hooks: CopilotHooksConfig = Field(default_factory=CopilotHooksConfig)


class ClaudeCodeModelPolicyConfig(BaseModel):
    """Per-task-type default model for Claude Code CLI tasks."""

    code: str = "sonnet"
    review: str = "sonnet"
    test: str = "sonnet"
    refactor: str = "sonnet"
    research: str = "sonnet"


class ClaudeCodeToolConfig(BaseModel):
    """Claude Code CLI delegate tool settings."""

    enabled: bool = True
    cli_path: str | None = None  # None = use SDK default; set to override
    default_model: str = "sonnet"
    task_timeout: int = Field(default=1800, ge=0)  # seconds; 0 = use 1h cap
    # Soft cap for ``mode=wait`` — after this many seconds the tool returns a
    # "task detached to background" result so the agent turn doesn't block
    # indefinitely. The underlying Claude SDK task keeps running and its
    # result is delivered via the outbound persistence mechanism (see
    # ``design/core/outbound-persistence.md``).
    wait_timeout: int = Field(default=900, ge=60)  # 15 min default
    max_concurrent: int = Field(default=3, ge=1)
    # Soft cap on the delegate's result body included in the user-visible
    # notification. ``0`` = no truncation (default) — since results are now
    # persisted into session JSONL and rendered via markdown, preserving the
    # full text is the right default. Set to a positive value only if you
    # have a specific channel constraint (e.g. a downstream push frame limit).
    notification_max_chars: int = Field(default=0, ge=0)
    model_policy: ClaudeCodeModelPolicyConfig = Field(default_factory=ClaudeCodeModelPolicyConfig)
    dangerously_skip_permissions: bool = False
    # SDK setting sources — include 'local' so .claude/settings.local.json
    # (which has enabledPlugins for Agency plugins) is loaded
    setting_sources: list[Literal["user", "project", "local"]] = Field(
        default_factory=lambda: ["user", "project", "local"]  # type: ignore[arg-type]
    )
    # Whether to instruct Claude to use Agency plugins (/review-pr, /code-review)
    use_plugins: bool = True


class SkillsConfig(BaseModel):
    """Skills system configuration."""

    inject_threshold: int = Field(
        default=20,
        ge=0,
        description="Minimum score to auto-inject a skill into user context.",
    )
    max_inject: int = Field(
        default=1,
        ge=0,
        description="Maximum number of skills to auto-inject per message.",
    )
    summary_budget: int = Field(
        default=8000,
        ge=0,
        description="Max chars for skills summary section in system prompt.",
    )
    always_budget: int = Field(
        default=8000,
        ge=0,
        description="Max chars for always-loaded skills content in system prompt.",
    )
    inject_budget: int = Field(
        default=8000,
        ge=0,
        description="Max chars for auto-injected skill content in user message.",
    )


class ToolOutputConfig(BaseModel):
    """Global defaults for tool output truncation."""

    max_chars: int = Field(
        default=32_000,
        ge=1_000,
        description="Default max output chars for tools that don't declare their own limit.",
    )
    llm_compression_enabled: bool = Field(
        default=True,
        description="Use fast LLM for intelligent compression. Falls back to smart_truncate if False.",
    )


class ToolsConfig(BaseModel):
    output: ToolOutputConfig = Field(default_factory=ToolOutputConfig)
    shell: ShellConfig = Field(default_factory=ShellConfig)
    filesystem: FileSystemConfig = Field(default_factory=FileSystemConfig)
    browser: BrowserConfig = Field(default_factory=BrowserConfig)
    copilot: CopilotToolConfig = Field(default_factory=lambda: CopilotToolConfig())
    claude_code: ClaudeCodeToolConfig = Field(default_factory=ClaudeCodeToolConfig)
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    mcp_risk_policy: dict[str, Any] = Field(
        default_factory=dict,
        description="MCP risk policy. _default_risk, _rules at top level; server blocks with tool scores and _rules.",
    )

    @model_validator(mode="before")
    @classmethod
    def _coerce_none(cls, data: Any) -> Any:
        """Accept `tools: null` in YAML as empty ToolsConfig."""
        if data is None:
            return {}
        return data


# ── Security config ──────────────────────────────────────────────────────────


class AuditConfig(BaseModel):
    enabled: bool = True
    log_file: str | None = "~/.workpilot/audit/audit.jsonl"
    redact_secrets: bool = True


class RBACRole(BaseModel):
    """Role-based access control role."""

    name: str
    allowed_tools: list[str] = Field(default_factory=lambda: ["*"])
    denied_tools: list[str] = Field(default_factory=list)
    allowed_channels: list[str] = Field(default_factory=lambda: ["*"])
    max_iterations: int = Field(default=25, ge=1)


class ToolAutonomyConfig(BaseModel):
    """Per-tool autonomy level override."""

    level: AutonomyLevel = AutonomyLevel.AUTONOMOUS


class PathAutonomyConfig(BaseModel):
    """Per-path autonomy override."""

    read: AutonomyLevel = AutonomyLevel.AUTONOMOUS
    write: AutonomyLevel = AutonomyLevel.NOTIFY


class ApprovalConfig(BaseModel):
    """Approval workflow settings."""

    timeout_seconds: int = Field(default=900, ge=0)  # 15 min before escalation
    auto_approve_timeout: int = Field(
        default=180, ge=0
    )  # 3 min auto-approve for low-risk escalations
    escalation_channels: list[ChannelType] = Field(default_factory=lambda: [ChannelType.CLOUD])
    default_channel: ChannelType = ChannelType.CLI


class AllowlistEntry(BaseModel):
    """A single allowlist rule — tool name + per-field match patterns.

    Each key in ``match`` is checked against the corresponding arg value
    via ``re.search(pattern, str(value))``.  All must pass (AND logic).
    Fields not in ``match`` are ignored (content can vary freely).
    Empty or absent ``match`` means all args pass (full tool bypass).
    """

    tool: str
    match: dict[str, str] = Field(default_factory=dict)  # arg_key → regex pattern
    added_by: str = ""
    note: str = ""


class AllowlistConfig(BaseModel):
    """Per-user tool approval allowlist settings.

    Entries can be auto-added via "Always Allow" or manually edited in
    ``workpilot.local.yaml`` under ``security.allowlist.entries``.
    """

    enabled: bool = True
    entries: list[AllowlistEntry] = Field(default_factory=list)


class SecurityOverrides(BaseModel):
    """Fine-grained security overrides on top of profile."""

    tools: dict[str, int] = Field(default_factory=dict)  # tool_name → autonomy level
    paths: dict[str, PathAutonomyConfig] = Field(default_factory=dict)  # glob → config
    agents: dict[str, dict[str, Any]] = Field(default_factory=dict)  # agent → restrictions


class EStopConfig(BaseModel):
    """Emergency stop configuration."""

    enabled: bool = True
    trigger_on_leak: bool = True
    notify_channels: list[str] = Field(default_factory=list)


class SecurityConfig(BaseModel):
    profile: SecurityProfile = SecurityProfile.STANDARD
    allowed_paths: list[str] | None = None  # None = use profile defaults
    denied_paths: list[str] | None = None  # None = use profile defaults
    audit: AuditConfig = Field(default_factory=AuditConfig)
    estop: EStopConfig = Field(default_factory=EStopConfig)
    roles: dict[str, RBACRole] = Field(default_factory=dict)
    default_role: str = "user"
    require_auth: bool = False
    approval: ApprovalConfig = Field(default_factory=ApprovalConfig)
    allowlist: AllowlistConfig = Field(default_factory=AllowlistConfig)
    overrides: SecurityOverrides = Field(default_factory=SecurityOverrides)
    secret_backend: Literal["auto", "keyring", "fernet", "env"] = "auto"
    auto_migrate_secrets: bool = True
    risk_context: str | None = Field(
        default=None,
        description="Environment-specific risk hints injected into LLM scorer prompts.",
    )


# ── Web server config ────────────────────────────────────────────────────────


class WebServerConfig(BaseModel):
    """Self-hosted HTTP web server (web channel)."""

    enabled: bool = False
    host: str = "localhost"
    port: int = Field(default=3003, ge=1, le=65535)
    api_key: SecretStr | None = None
    cors_origins: list[str] = Field(default_factory=list)  # empty = same-origin only

    @model_validator(mode="after")
    def _coerce_empty_api_key(self) -> WebServerConfig:
        """Treat empty/whitespace API key as unset (None)."""
        if self.api_key is not None and not self.api_key.get_secret_value().strip():
            self.api_key = None
        return self

    rate_limit_per_minute: int = Field(default=60, ge=1)
    request_timeout: int = Field(default=300, ge=0)  # Per-request timeout in seconds
    attachments_enabled: bool | None = Field(
        default=None,
        description=(
            "Override attachments feature flag surfaced via /api/auth/config. "
            "None (default) = derive from security profile (off only for "
            "restricted). True/False = explicit override."
        ),
    )
    entra_tenant_id: str = ""  # must be configured explicitly
    entra_client_id: str = ""  # must be configured explicitly
    entra_client_id_legacy: list[str] = Field(
        default_factory=list,
        description="Additional client IDs to accept during app registration migration",
    )
    owner_oid: str = Field(default="", exclude=True)  # runtime-only; never serialized


# ── Channel configs ──────────────────────────────────────────────────────────


class BaseChannelConfig(BaseModel):
    enabled: bool = False
    allow_from: list[str] = Field(default_factory=list)


class CLIChannelConfig(BaseChannelConfig):
    enabled: bool = True
    prompt: str = "you> "


class CloudChannelConfig(BaseChannelConfig):
    """WorkPilot Cloud Gateway relay channel.

    Connects outbound to wss://<url>/connect using an Entra ID access token.
    Enables Teams / Web Chat messages to reach the local agent without
    inbound firewall rules.

    login_method:
      auto    — (default) browser PKCE only
      browser — same as auto (explicit)
      wam     — WAM broker → browser PKCE fallback (requires msal[broker] on Windows)
      device  — device code flow (visit URL + enter code); only when explicitly configured
                (many tenants disable device code via Conditional Access)
    """

    enabled: bool = True  # auto-connect on every workpilot startup (silent auth only)

    # Defaults are empty here; bundled workpilot.yaml provides pre-configured values.
    # If url/client_id are still empty after config merge, cloud channel is disabled.
    url: str = ""
    tenant_id: str = ""
    client_id: str = ""
    scope: str = ""
    login_method: Literal["auto", "browser", "wam", "device"] = "auto"
    login_port: int = Field(
        default=49215, ge=0, le=65535
    )  # localhost port for MSAL PKCE callback; 0 = OS-assigned
    auto_reconnect: bool = True
    reconnect_max: int = Field(default=60, ge=1)
    # Teams bot app ID (MicrosoftAppId). Used for:
    # - Teams direct-chat URL: https://teams.microsoft.com/l/chat/0/0?users=28:<bot_app_id>
    # - SSO id_token audience validation
    bot_app_id: str = ""
    enable_github: bool = Field(
        default=True, title="Enable GitHub"
    )  # register GitHub identity for WebChat authentication
    require_relay_auth: bool = False  # Step 3 flips to True


class ChannelsConfig(BaseModel):
    cli: CLIChannelConfig = Field(default_factory=CLIChannelConfig)
    cloud: CloudChannelConfig = Field(default_factory=CloudChannelConfig)
    web: WebServerConfig = Field(default_factory=WebServerConfig)


# ── Cron config ──────────────────────────────────────────────────────────────


class HeartbeatConfig(BaseModel):
    """Built-in heartbeat job configuration."""

    enabled: bool = True
    interval: int = Field(default=1800, ge=1)  # 30 minutes, in seconds


class CronConfig(BaseModel):
    enabled: bool = False
    heartbeat: HeartbeatConfig = Field(default_factory=HeartbeatConfig)
    max_concurrent_jobs: int = Field(default=5, ge=1)


# ── Logging config ───────────────────────────────────────────────────────────


class LoggingConfig(BaseModel):
    level: LogLevel = LogLevel.WARNING
    format: Literal["pretty", "json"] = "pretty"
    file: str | None = None


# ── Top-level config ─────────────────────────────────────────────────────────


class AppConfig(BaseModel):
    """Root configuration for WorkPilot."""

    model_config = ConfigDict(extra="forbid")

    name: str = "workpilot"
    entrypoint: str = "default"
    workspace: str = "."

    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    skills: SkillsConfig = Field(default_factory=SkillsConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    cron: CronConfig = Field(default_factory=CronConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    @model_validator(mode="after")
    def _validate_browser_profile_vs_security(self) -> AppConfig:
        """Reject system-browser targets in controlled/restricted profiles.

        A "system target" is either ``profile_mode: system`` or a
        ``persistent_profile`` path that resolves to a known OS browser
        user-data-dir. Both expose every logged-in session in the user's
        real browser, so they are disallowed under high-security profiles.
        ``workpilot`` (isolated) and ``ephemeral`` remain available; the
        default (``auto``) lands on ``ephemeral`` for these profiles but
        an explicit ``workpilot`` opt-in is honoured.

        Skipped when the browser tool is disabled — there is no code path
        that would ever act on the value.
        """
        if not self.tools.browser.enabled:
            return self

        if self.security.profile not in (
            SecurityProfile.CONTROLLED,
            SecurityProfile.RESTRICTED,
        ):
            return self

        # Cheap check: profile_mode=='system'.
        if self.tools.browser.profile_mode == "system":
            raise ValueError(
                f"browser.profile_mode='system' is not available under "
                f"security.profile='{self.security.profile.value}'. "
                "Use 'workpilot' (persistent, isolated) or 'ephemeral' (fresh each run) instead."
            )

        # Path-based check: does persistent_profile point at a real browser?
        # Deferred import — the detector lives in the tool module so the
        # schema file stays free of runtime dependencies.
        pp = self.tools.browser.persistent_profile
        if pp:
            from workpilot.agent.tools.browser import _path_targets_system_profile

            if _path_targets_system_profile(pp):
                raise ValueError(
                    f"browser.persistent_profile={pp!r} resolves to the user's real "
                    f"browser user-data-dir, which is not available under "
                    f"security.profile='{self.security.profile.value}'. "
                    "Point it at an isolated directory instead."
                )
        return self
