"""Extract ``workpilot-image://`` refs from an assistant reply.

Single choke point for the agent's outbound image protocol. Called once
by ``AgentLoop`` before the final assistant turn is persisted / dispatched.

Protocol (taught to the LLM via TOOLS.md):

    ![alt](workpilot-image:///absolute/path.png)        # absolute local file
    ![alt](workpilot-image://docs/arch.png)             # workspace-relative file
    ![alt](workpilot-image://<64-hex-sha>)               # echo an existing image
    ![alt](data:image/png;base64,iVBOR...)               # inline tiny image (≤16 KB b64)

All forms are rewritten in place to the canonical sha-form sentinel
(``![alt](workpilot-image://<sha>)``) so the frontend can render the
image inline at exactly the LLM-specified position.

The bare form (without the markdown ``![]()`` wrapper) is also accepted — the
scheme is unique enough that false positives are effectively zero.

Returns ``(rewritten_text, attachment_refs)``:

* ``rewritten_text`` has successfully-hoisted sentinels **rewritten in
  place** to the canonical ``![alt](workpilot-image://<sha>)`` form so
  the frontend can render the image inline at exactly the LLM-specified
  position. Failed hoists (invalid sha, out-of-sandbox path, MIME
  reject) are left literal so the LLM/user can see the failure.
* ``attachment_refs`` is a list of dicts matching the
  ``OutboundMessage.attachments`` wire shape (sha256 + metadata, no
  bytes). Bytes are base64-encoded later at the channel layer
  (``resolve_outbound_refs``).

See design/cloud-gateway/attachments.md §4.5 for the outbound wire shape.
"""

from __future__ import annotations

import re
import tempfile
from pathlib import Path
from typing import Any

from loguru import logger

# Wrapped form: ``![alt](workpilot-image://<ref>)``. Non-greedy URL match so two
# sentinels on one line don't merge; ``)`` terminates (can't appear unescaped
# inside a URL).
_WRAPPED_RE = re.compile(r"!\[([^\]]*)\]\(workpilot-image://([^)\s]+)\)")

# Bare form: ``workpilot-image://<ref>`` anywhere in prose. Unique scheme →
# false-positive rate is zero for practical purposes. The negative lookbehind
# ``(?<!\()`` skips matches inside an already-wrapped sentinel — otherwise
# this regex would re-match the ``workpilot-image://<sha>`` URL produced by
# ``_WRAPPED_RE`` and double-process it (which dedup-blanks because the sha
# is already in ``seen_sha``).
_BARE_RE = re.compile(r"(?<!\()workpilot-image://([^\s)]+)")

# Inline data URI: ``![alt](data:image/png;base64,...)``. LLMs sometimes emit
# tiny inline images this way (icons, sparklines). We decode + save_attachment
# + rewrite to canonical sha form so JSONL stays compact and persistence
# behaves identically to path/sha forms. Hard cap at 16 KB base64 (~12 KB raw)
# to prevent LLMs from pasting large blobs into prose.
_DATA_URI_RE = re.compile(
    r"!\[([^\]]*)\]\(data:(image/[a-zA-Z0-9+\-.]+);base64,([A-Za-z0-9+/=]+)\)"
)
_MAX_DATA_URI_BASE64 = 16 * 1024

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _is_within(path: Path, root: Path) -> bool:
    """True when *path* is *root* itself or a descendant."""
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _resolve_safe_path(raw: str, workspace: Path) -> Path | None:
    """Return the resolved path iff it's inside an allowed root.

    Accepts two forms:

    * **Absolute path** (``/tmp/x.png``, ``C:/Users/.../x.png``, or a
      ``~/…`` path that expands to absolute) — used as-is.
    * **Workspace-relative path** (``reports/q4.png``, ``docs/arch.png``)
      — joined against ``workspace`` **not** ``Path.cwd()``. We
      deliberately avoid cwd because the agent can ``cd`` via shell tools
      mid-conversation, which would make the same sentinel resolve to
      different files depending on timing.

    Allowed roots for the resolved path (kept deliberately small — this
    is the outbound path, not a general file-access tool):

    * ``workspace`` — the agent's project root
    * system temp dir (``/tmp`` on Unix, ``%TEMP%`` on Windows) — the
      canonical scratch space for agent-produced artifacts
    * the attachment store under ``~/.workpilot/data/attachments`` — lets
      ``workpilot-image:///path/.../<sha>.png`` also work in addition to
      the sha form

    Returns ``None`` when the resolved path escapes all three (typical
    for ``..`` escapes, ``/etc/...``, or home-relative paths outside the
    workspace), so the caller keeps the sentinel literal in the reply.
    """
    try:
        p = Path(raw).expanduser()
    except (OSError, ValueError):
        return None
    # Workspace-relative disambiguation happens HERE, before ``resolve()``,
    # so cwd is never a factor. ``Path.is_absolute()`` handles both Unix
    # ``/tmp/...`` and Windows ``C:/Users/...`` natively.
    if not p.is_absolute():
        p = workspace / p
    try:
        resolved = p.resolve(strict=False)
    except (OSError, RuntimeError):
        return None

    try:
        from workpilot.utils.helpers import get_data_dir

        attachment_root = (get_data_dir() / "data" / "attachments").resolve()
    except Exception:
        attachment_root = None

    allowed_roots: list[Path] = [workspace.resolve()]
    try:
        allowed_roots.append(Path(tempfile.gettempdir()).resolve())
    except OSError:
        pass
    if attachment_root is not None:
        allowed_roots.append(attachment_root)

    if any(_is_within(resolved, root) for root in allowed_roots):
        return resolved
    return None


def _hoist_path(raw: str, workspace: Path) -> dict[str, Any] | None:
    """Read bytes + save_attachment. Returns ref dict or None on any failure."""
    from workpilot.security.attachments import MAX_IMAGE_BYTES

    resolved = _resolve_safe_path(raw, workspace)
    if resolved is None:
        logger.warning("workpilot-image hoist: path outside sandbox: {}", raw)
        return None
    if not resolved.is_file():
        logger.warning("workpilot-image hoist: not a file: {}", resolved)
        return None

    # Pre-check size before ``read_bytes()`` — an LLM-emitted path
    # pointing at a multi-GB file inside the sandbox should not allocate
    # that much RAM just to have ``save_attachment`` reject it after the
    # read. ``MAX_IMAGE_BYTES`` (20 MB) is the LARGER of the image /
    # text caps, so files above this can't pass either path-kind check;
    # files below may still be rejected by ``save_attachment``'s
    # finer-grained per-kind caps (e.g. 500 KB for text), but reading a
    # ≤20 MB file into memory is tolerable.
    try:
        file_size = resolved.stat().st_size
    except OSError as exc:
        logger.warning("workpilot-image hoist: stat failed {}: {}", resolved, exc)
        return None
    if file_size > MAX_IMAGE_BYTES:
        logger.warning(
            "workpilot-image hoist: file exceeds max hoist size {} > {}",
            file_size,
            MAX_IMAGE_BYTES,
        )
        return None

    try:
        data = resolved.read_bytes()
    except OSError as exc:
        logger.warning("workpilot-image hoist: read failed {}: {}", resolved, exc)
        return None

    # Classify MIME from extension — save_attachment normalises + validates
    # against its own allowlist, so we only need a best-effort guess here.
    import mimetypes

    content_type, _ = mimetypes.guess_type(resolved.name)
    if not content_type:
        content_type = "application/octet-stream"

    try:
        from workpilot.security.attachments import AttachmentError, save_attachment

        ref = save_attachment(data, content_type, name=resolved.name)
    except AttachmentError as exc:
        logger.warning("workpilot-image hoist: save_attachment rejected {}: {}", resolved, exc)
        return None
    except Exception as exc:
        logger.warning("workpilot-image hoist: unexpected error {}: {}", resolved, exc)
        return None

    ref_dict: dict[str, Any] = {
        "sha256": ref.sha256,
        "content_type": ref.content_type,
        "size": ref.size,
        "kind": ref.kind,
    }
    if ref.name:
        ref_dict["name"] = ref.name
    return ref_dict


def _echo_sha(sha: str) -> dict[str, Any] | None:
    """Resolve an existing sha256 from the attachment store. Returns ref or None."""
    from workpilot.security.attachments import load_ref

    ref = load_ref(sha.lower())
    if ref is None:
        logger.warning("workpilot-image echo: sha not in local store: {}", sha[:12])
        return None

    ref_dict: dict[str, Any] = {
        "sha256": ref.sha256,
        "content_type": ref.content_type,
        "size": ref.size,
        "kind": ref.kind,
    }
    if ref.name:
        ref_dict["name"] = ref.name
    return ref_dict


def extract_outputs(
    text: str,
    *,
    workspace: Path,
) -> tuple[str, list[dict[str, Any]]]:
    """Hoist ``workpilot-image://`` refs out of an assistant reply.

    Returns ``(rewritten_text, refs)``. Successful hoists are
    **rewritten in place** to a canonical sha-form markdown sentinel
    (``![alt](workpilot-image://<sha>)``) so positional info is
    preserved — the frontend can render the image inline at exactly
    where the LLM put it. Failed hoists (invalid sha, unsafe path,
    MIME reject) leave the sentinel literal so the user / LLM see the
    failure — better debug signal than silent drop.

    Bare-form sentinels (no markdown wrapper) are wrapped with an
    empty ``![]()`` after rewrite so they also render inline rather
    than appear as a raw URL string in prose. Markdown wrapper around
    a successful hoist preserves the LLM's alt text.

    Dedup: if the same sha appears in multiple sentinels within one
    reply, only the first occurrence is kept; later duplicates are
    blanked (the image is content-addressed — no point rendering it
    twice).
    """
    has_scheme = "workpilot-image://" in text
    has_data_uri = "](data:image/" in text
    if not text or (not has_scheme and not has_data_uri):
        return text, []

    collected: list[dict[str, Any]] = []
    seen_sha: set[str] = set()

    def _try_ref(raw: str) -> dict[str, Any] | None:
        # sha64 matches first — a 64-char hex happens to be a valid
        # filename on most systems, so we only fall to path-hoist if
        # the sha lookup failed (not-in-store) AND the string is not
        # hex (i.e. looks like a path).
        if _SHA256_RE.match(raw.lower()):
            return _echo_sha(raw)
        # Any other shape: try as a filesystem path. Bogus strings
        # fail ``is_file()`` inside ``_hoist_path`` → None → kept literal.
        return _hoist_path(raw, workspace)

    def _data_uri_sub(match: re.Match[str]) -> str:
        """``![alt](data:image/png;base64,...)`` → save_attachment + rewrite
        to canonical sha-form sentinel. Oversize / malformed → keep literal.

        Translation only — does NOT touch ``seen_sha`` / ``collected``.
        The downstream ``_wrapped_sub`` pass handles dedup + ref
        collection uniformly for the resulting sha-form sentinel.
        """
        import base64

        alt = match.group(1)
        content_type = match.group(2)
        b64 = match.group(3)
        if len(b64) > _MAX_DATA_URI_BASE64:
            logger.warning(
                "workpilot-image data-URI: oversize payload kept literal (b64_len={} cap={})",
                len(b64),
                _MAX_DATA_URI_BASE64,
            )
            return match.group(0)
        try:
            data = base64.b64decode(b64, validate=True)
        except Exception as exc:
            logger.warning("workpilot-image data-URI: malformed base64: {}", exc)
            return match.group(0)
        try:
            from workpilot.security.attachments import (
                AttachmentError,
                save_attachment,
            )

            ref_obj = save_attachment(data, content_type)
        except AttachmentError as exc:
            logger.warning("workpilot-image data-URI: save_attachment rejected: {}", exc)
            return match.group(0)
        except Exception as exc:
            logger.warning("workpilot-image data-URI: unexpected error: {}", exc)
            return match.group(0)
        return f"![{alt}](workpilot-image://{ref_obj.sha256})"

    # Run data-URI pass FIRST so the resulting wrapped sha sentinels are
    # canonicalised by the wrapped pass below.
    rewritten = _DATA_URI_RE.sub(_data_uri_sub, text)

    def _wrapped_sub(match: re.Match[str]) -> str:
        alt = match.group(1)
        raw = match.group(2)
        ref = _try_ref(raw)
        if ref is None:
            return match.group(0)  # keep literal so the failure is visible
        if ref["sha256"] in seen_sha:
            return ""  # dedupe within one reply
        seen_sha.add(ref["sha256"])
        collected.append(ref)
        # Rewrite to canonical sha-form, preserving LLM's alt text.
        return f"![{alt}](workpilot-image://{ref['sha256']})"

    rewritten = _WRAPPED_RE.sub(_wrapped_sub, rewritten)

    def _bare_sub(match: re.Match[str]) -> str:
        raw = match.group(1)
        ref = _try_ref(raw)
        if ref is None:
            return match.group(0)
        if ref["sha256"] in seen_sha:
            return ""
        seen_sha.add(ref["sha256"])
        collected.append(ref)
        # Wrap bare sentinels into markdown so the frontend renders them
        # inline (otherwise users would see a raw ``workpilot-image://<sha>``
        # URL string in prose).
        return f"![](workpilot-image://{ref['sha256']})"

    rewritten = _BARE_RE.sub(_bare_sub, rewritten)

    # Tidy excess blank lines left by deduped sentinels. A plain
    # ``\n{3,}`` collapse suffices; never touch single newlines
    # (preserves prose structure). Only trim leading/trailing
    # **newlines** — a full ``.strip()`` would also eat significant
    # leading spaces (e.g. a message that starts with a 4-space-indented
    # code block) or trailing indentation the LLM emitted deliberately.
    rewritten = re.sub(r"\n{3,}", "\n\n", rewritten).strip("\n")

    return rewritten, collected
