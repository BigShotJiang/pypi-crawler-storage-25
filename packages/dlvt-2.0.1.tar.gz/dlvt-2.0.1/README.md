# Dynamic Leadership Vitality Theory (DLVT) — Python Package

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Tests](https://img.shields.io/badge/tests-38%20passed-brightgreen.svg)](#running-the-tests)
[![MIT License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

**Author:** William Bendinelli
**Paper:** *Dynamic Leadership Vitality Theory: A Formal Model of the Zombie-Leader Equilibrium*
**Target Journal:** *The Leadership Quarterly* (2026)

---

## Overview

This package implements the **Dynamic Leadership Vitality Theory (DLVT)** model — a two-dimensional autonomous dynamical system that formalizes how leaders who accumulate career capital simultaneously generate the organizational complexity that drains the vitality they need to deploy it.

The model predicts a single robust attractor: a **zombie-leader equilibrium** at $(V^{*} \approx 4.7,\; C^{*} \approx 32)$ in which the leader retains authority and reputation but permanently lacks the energetic bandwidth for strategic work. The zombie equilibrium is globally asymptotically stable (proved via Bendixson–Dulac + Poincaré–Bendixson on a trapping rectangle).

**Three outcome regimes** emerge from the parameter space:

- **Sustainable** — the leader reaches equilibrium with $V^{*} > V_{\mathrm{strategic}}$
- **Zombie** — the leader converges to $V^{*} < V_{\mathrm{strategic}}$ (the default attractor)
- **Collapse-Prone** — unsustainable trajectory where burnout is inevitable

## Quick Start

### Installation

```bash
git clone https://github.com/wbendinelli/dlvt.git
cd dlvt
pip install -e .
```

**Requirements:** Python ≥ 3.8, NumPy ≥ 1.24, SciPy ≥ 1.10, Matplotlib ≥ 3.7

### Basic Usage

```python
from dlvt import make_params, simulate
from dlvt.analysis import find_interior_equilibria, carrying_capacity

# Create parameter set (defaults match Table 1 of the paper)
p = make_params()

# Simulate from initial state (V₀=8.0, C₀=5.0) over T=120 time units
t, V, C, O, I, G = simulate(p, V0=8.0, C0=5.0, T=120)
# V — vitality, C — career capital, O — complexity, I — impact, G — depletion ratio

# Find equilibria and classify stability
equilibria = find_interior_equilibria(p)
for eq in equilibria:
    status = "stable" if eq['stable'] else "unstable"
    print(f"V*={eq['V']:.2f}, C*={eq['C']:.2f} ({status})")

# Maximum sustainable career capital (Proposition 3)
C_max = carrying_capacity(p)
print(f"Carrying capacity: C*_max = {C_max:.2f}")
```

### Scenario Analysis

```python
from dlvt import make_params, simulate
from dlvt.analysis import classify_regime

# What happens if we increase recovery support?
p_high_R = make_params(R=5.0)
regime = classify_regime(p_high_R)
print(f"Regime with R=5.0: {regime}")

# What if complexity coupling is halved?
p_low_beta = make_params(beta=0.125)
t, V, C, O, I, G = simulate(p_low_beta, V0=8.0, C0=5.0, T=200)
print(f"Final V={V[-1]:.2f}, C={C[-1]:.2f}")
```

## The Dynamical System

The DLVT model is governed by two coupled ODEs:

$$\frac{dV}{dt} = R \left(1 - \frac{V}{V_{\max}}\right) - \delta \cdot O^{\gamma} \cdot \frac{V}{V + \varepsilon}$$

$$\frac{dC}{dt} = \alpha \cdot I - \mu \cdot C$$

with derived quantities:

- **Organisational Complexity:** $O(t) = O_0 + \beta \cdot C(t)^{\eta}$
- **Leadership Impact:** $I(t) = C \cdot V \,/\, (1 + \phi \cdot O)$ — energy-gated effectiveness
- **Depletion Ratio:** $\Gamma(t) = \delta \cdot O^{\gamma} \,/\, R$ — net drain when $\Gamma > 1$

The first equation balances bounded vitality recovery against complexity-driven drain. The second models career capital accumulation through impact feedback minus depreciation. The smooth barrier $V/(V+\varepsilon)$ ensures positive invariance of the state space.

## Parameter Table

All parameters from **Table 1** of the paper (baseline calibration, $C_0 = 5.0$):

| Symbol | Key | Default | Description |
|:------:|:---:|:-------:|:------------|
| $R$ | `R` | 3.0 | Vitality recovery rate |
| $V_{\max}$ | `Vmax` | 10.0 | Maximum vitality capacity |
| $\delta$ | `delta` | 0.02 | Energetic cost coefficient |
| $\gamma$ | `gamma` | 2.0 | Complexity exponent in drain |
| $O_0$ | `O0` | 1.0 | Baseline organisational complexity |
| $\beta$ | `beta` | 0.25 | Capital–complexity coupling |
| $\eta$ | `eta` | 1.0 | Capital scaling exponent |
| $\alpha$ | `alpha` | 0.1 | Capital accumulation rate |
| $\phi$ | `phi` | 0.15 | Complexity–impact suppression |
| $\mu$ | `mu` | 0.2 | Capital depreciation rate |
| $\varepsilon$ | `eps` | 0.1 | Smooth barrier regularisation |

## Key Theoretical Results

**Theorem 1 (Finite-Time Depletion):** Under exogenous complexity growth that creates a persistent deficit ($\Gamma > 1$), vitality reaches the $\varepsilon$-neighborhood of zero in finite time.

**Theorem 2 (Global Asymptotic Stability):** The zombie equilibrium $(V^{*}, C^{*})$ is the unique interior attractor. Proved via Bendixson–Dulac (no closed orbits), trapping rectangle $[0, V_{\max}] \times [0, C_{\max}]$, and Poincaré–Bendixson.

**Lemma 2 (Scope Absorption):** $V^{*}(\beta) \equiv V^{*}_0$ for all $\beta$ in the structurally interior region; the invariant $\beta C^{*} \approx 8.008$ is preserved. Scope reduction alone does not raise equilibrium vitality.

**Proposition 3 (Carrying Capacity):** $C^{*}_{\max} = \left[\left(R/\delta\right)^{1/\gamma} - O_0\right]^{1/\eta} / \beta$

## API Reference

### `dlvt.model` — Core ODE System

```python
from dlvt import make_params, simulate, complexity, impact
```

| Function | Description |
|:---------|:------------|
| `make_params(**overrides)` | Create parameter dict with keyword overrides |
| `complexity(C, p)` | $O = O_0 + \beta C^{\eta}$ |
| `impact(V, C, O, p)` | $I = CV/(1 + \phi O)$ |
| `dlvt_system(t, y, p)` | ODE right-hand side for `scipy.integrate.solve_ivp` |
| `dlvt_exogenous(t, y, p, C_func)` | Variant with exogenous career capital path |
| `simulate(p, V0, C0, T, max_step)` | Integrate ODE; returns `(t, V, C, O, I, G)` |

### `dlvt.analysis` — Equilibrium Theory & Stability

```python
from dlvt.analysis import (
    find_interior_equilibria, carrying_capacity,
    jacobian_eigenvalues, is_zombie, classify_regime, regime_map
)
```

| Function | Description |
|:---------|:------------|
| `find_interior_equilibria(p)` | Find all $(V^{*}, C^{*}) > 0$ fixed points |
| `carrying_capacity(p)` | Maximum sustainable capital $C^{*}_{\max}$ |
| `jacobian_eigenvalues(V, C, p)` | Eigenvalue structure and stability class |
| `is_zombie(V, p)` | Check $V^{*} < V_{\mathrm{strategic}}$ |
| `classify_regime(p)` | Returns `'sustainable'`, `'zombie'`, or `'collapse-prone'` |
| `regime_map(betas, deltas)` | $(\beta, \delta)$ regime classification grid |

### `dlvt.figures` — Publication Figure Generation

```python
from dlvt.figures import fig1, fig2, fig3, fig4, fig5, fig6, fig7

fig3(output_dir='figures/')  # Phase portrait
```

| Figure | Content |
|:-------|:--------|
| Fig 1 | Temporal evolution of $V(t)$, $C(t)$, $O(t)$, $\Gamma(t)$ |
| Fig 2 | Three outcome scenarios (sustainable, zombie, collapse) |
| Fig 3 | Phase portrait with nullclines and equilibria |
| Fig 4 | Bifurcation diagrams: $C^{*}$ and $V^{*}$ vs $\beta$, $R$ |
| Fig 5 | Impact comparison: DLVT vs Human Capital Theory (Becker) |
| Fig 6 | Carrying capacity heatmap $C^{*}_{\max}(\beta, R)$ |
| Fig 7 | Regime map in $(\beta, \delta)$ space |

## Reproducing All Paper Figures

```bash
python3 scripts/run_all_figures.py             # All 10 figures (PDF + PNG)
python3 scripts/run_all_figures.py --fig 1-7   # Core only
python3 scripts/run_all_figures.py --fig 8-10  # Extended analysis only
```

Extended figures (standalone scripts):

```bash
python3 scripts/fig8_bifurcation_hysteresis.py    # Hysteresis detection
python3 scripts/fig9_robustness.py                # Structural robustness
python3 scripts/fig10_intervention_comparison.py   # Recovery vs redesign
```

## Running the Tests

```bash
pytest tests/ -q          # 38 tests, all must pass
pytest tests/ -v --tb=short  # verbose with tracebacks
```

The test suite pins every numerical claim in the paper (equilibrium values, carrying capacity, scope-absorption invariant, eigenvalue signs, basin-of-attraction convergence) so that any code change that breaks paper–code consistency is caught immediately.

## Project Structure

```
dlvt/
├── dlvt/                     # Core package
│   ├── __init__.py           # Public API exports
│   ├── model.py              # ODE system, parameters, integration
│   ├── analysis.py           # Equilibria, stability, bifurcation, regimes
│   └── figures.py            # Publication figures 1–7
├── tests/                    # 38 pinning tests
│   ├── test_model.py         # Model numerics, simulation, positive invariance
│   └── test_analysis.py      # Equilibria, carrying capacity, regimes
├── scripts/                  # Figure generation (8–10) and robustness grid
├── figures/                  # Generated output (PDF + PNG)
├── pyproject.toml            # Package metadata and dependencies
├── setup.py                  # Legacy installer
└── LICENSE                   # MIT
```

## Citation

```bibtex
@article{bendinelli2026dlvt,
  title   = {Dynamic Leadership Vitality Theory:
             A Formal Model of the Zombie-Leader Equilibrium},
  author  = {Bendinelli, William},
  year    = {2026},
  note    = {Manuscript submitted to The Leadership Quarterly}
}
```

## License

MIT License — see [LICENSE](LICENSE) for details.

Copyright 2026 William Bendinelli

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Issues, feature requests, and pull requests are welcome.
