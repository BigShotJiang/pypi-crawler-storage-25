from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import Any, Sequence

from codebase_ast_core.settings import Settings

logger = logging.getLogger(__name__)


def make_client(settings: Settings) -> Any:
    try:
        from qdrant_client import QdrantClient
    except ImportError as e:
        raise RuntimeError(
            "qdrant-client is required for VECTOR_STORE_TARGET=qdrant or both. "
            "Install with: pip install qdrant-client"
        ) from e
    kwargs: dict[str, Any] = {"url": settings.qdrant_url.strip()}
    key = (settings.qdrant_api_key or "").strip()
    if key:
        kwargs["api_key"] = key
    if not settings.qdrant_tls_verify:
        kwargs["verify"] = False
    return QdrantClient(**kwargs)


def _vector_config(settings: Settings, vector_size: int) -> dict[str, Any]:
    from qdrant_client.models import Distance, VectorParams

    name = settings.qdrant_vector_name.strip() or "code_vector"
    return {name: VectorParams(size=vector_size, distance=Distance.COSINE)}


def ensure_collection(
    client: Any, settings: Settings, *, vector_size: int | None = None
) -> None:
    coll = settings.qdrant_collection.strip()
    if not coll:
        raise ValueError("QDRANT_COLLECTION must be set when using Qdrant.")
    if client.collection_exists(collection_name=coll):
        return
    size = vector_size if vector_size is not None else settings.embedding_dimension
    logger.info(
        "Creating Qdrant collection %r (vector %r, dim=%s).",
        coll,
        settings.qdrant_vector_name,
        size,
    )
    client.create_collection(
        collection_name=coll, vectors_config=_vector_config(settings, size)
    )


def _posix_to_display_path(posix_path: str) -> str:
    p = posix_path.replace("\\", "/").lstrip("/")
    return "/" + p if p else "/"


def _chunk_type_for_path(posix_path: str) -> str:
    suf = Path(posix_path).suffix.lower().lstrip(".")
    return suf if suf else "text"


def build_file_chunk_payload(
    *,
    service_name: str,
    posix_path: str,
    page_content: str,
) -> dict[str, Any]:
    """Payload keys aligned with codebase_shipper (optional json_path only for JSON chunks)."""
    chunk_type = _chunk_type_for_path(posix_path)
    payload: dict[str, Any] = {
        "file_name": Path(posix_path.replace("\\", "/")).name,
        "relative_file_path": _posix_to_display_path(posix_path),
        "service_name": service_name,
        "chunk_type": chunk_type,
        "page_content": page_content,
    }
    if chunk_type == "json":
        payload["json_path"] = "$"
    return payload


def stable_point_id(service_name: str, posix_path: str) -> str:
    """Deterministic UUID so upserts replace the same logical file chunk."""
    key = f"{service_name}\0{posix_path.replace(chr(92), '/')}"
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "reindex_logic:file:" + key))


def upsert_file_embeddings(
    client: Any,
    settings: Settings,
    *,
    service_name: str,
    rows: Sequence[dict[str, Any]],
    embed_texts: Sequence[str],
    vector_size: int | None = None,
) -> int:
    """
    rows: path, content, embedding (same shape as Neo4j upsert).
    embed_texts: strings actually embedded (parallel to rows).
    """
    from qdrant_client.models import PointStruct

    coll = settings.qdrant_collection.strip()
    vname = settings.qdrant_vector_name.strip() or "code_vector"
    expected_len = vector_size if vector_size is not None else settings.embedding_dimension
    if not rows:
        return 0
    points: list[Any] = []
    for row, text_in in zip(rows, embed_texts):
        pid = stable_point_id(service_name, row["path"])
        payload = build_file_chunk_payload(
            service_name=service_name,
            posix_path=row["path"],
            page_content=text_in,
        )
        vec = row["embedding"]
        if len(vec) != expected_len:
            logger.warning(
                "Vector length %s != expected %s for %s",
                len(vec),
                expected_len,
                row["path"],
            )
        points.append(
            PointStruct(
                id=pid,
                vector={vname: list(float(x) for x in vec)},
                payload=payload,
            )
        )
    client.upsert(collection_name=coll, points=points, wait=True)
    return len(points)


def stable_loader_chunk_point_id(service_name: str, source_path: str, chunk: dict[str, Any]) -> str:
    """Deterministic id per shipper chunk (replaces legacy one-point-per-file ids)."""
    name = (
        chunk.get("name")
        or chunk.get("python_name")
        or chunk.get("config_key")
        or chunk.get("json_path")
        or chunk.get("route_id")
        or chunk.get("chunk_type")
        or ""
    )
    key = (
        f"{service_name}\0{source_path.replace(chr(92), '/')}\0"
        f"{chunk.get('chunk_type', '')}\0{chunk.get('start_line', '')}\0{name}"
    )
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "reindex_logic:loader_chunk:" + key))


def build_loader_chunk_payload(
    chunk: dict[str, Any], *, service_name: str, posix_path: str
) -> dict[str, Any]:
    """Payload aligned with codebase_shipper Qdrant ingestion."""
    rel = chunk.get("relative_file_path")
    if rel and not str(rel).startswith("/"):
        rel = "/" + str(rel).lstrip("/")
    payload: dict[str, Any] = {
        "file_name": chunk.get("file_name") or Path(posix_path).name,
        "relative_file_path": rel or _posix_to_display_path(posix_path),
        "service_name": chunk.get("service_name") or service_name,
        "chunk_type": chunk.get("chunk_type", _chunk_type_for_path(posix_path)),
        "page_content": (chunk.get("page_content") or "").strip(),
    }
    for optional in (
        "json_path",
        "schema_property",
        "config_key",
        "route_id",
        "tag",
        "xml_path",
        "node_type",
        "name",
        "python_name",
        "python_container",
    ):
        if optional in chunk and chunk[optional] is not None:
            payload[optional] = chunk[optional]
    return payload


def upsert_loader_chunks(
    client: Any,
    settings: Settings,
    *,
    service_name: str,
    chunks: Sequence[dict[str, Any]],
    embeddings: Sequence[Sequence[float]],
    vector_size: int | None = None,
) -> int:
    """Upsert one Qdrant point per shipper loader chunk."""
    from qdrant_client.models import PointStruct

    if not chunks:
        return 0
    coll = settings.qdrant_collection.strip()
    vname = settings.qdrant_vector_name.strip() or "code_vector"
    expected_len = vector_size if vector_size is not None else settings.embedding_dimension
    points: list[Any] = []
    for chunk, vec in zip(chunks, embeddings):
        src = chunk.get("_source_path") or chunk.get("relative_file_path") or ""
        posix_path = str(src).replace("\\", "/")
        pid = stable_loader_chunk_point_id(service_name, posix_path, chunk)
        text = (chunk.get("page_content") or "").strip()
        if not text:
            continue
        payload = build_loader_chunk_payload(
            chunk, service_name=service_name, posix_path=posix_path
        )
        if len(vec) != expected_len:
            logger.warning(
                "Vector length %s != expected %s for chunk %s",
                len(vec),
                expected_len,
                pid,
            )
        points.append(
            PointStruct(
                id=pid,
                vector={vname: [float(x) for x in vec]},
                payload=payload,
            )
        )
    if not points:
        return 0
    client.upsert(collection_name=coll, points=points, wait=True)
    return len(points)


def delete_paths(client: Any, settings: Settings, *, service_name: str, posix_paths: Sequence[str]) -> int:
    """Remove legacy file points and all loader chunks for deleted paths."""
    if not posix_paths:
        return 0
    coll = settings.qdrant_collection.strip()
    from qdrant_client.models import FieldCondition, Filter, FilterSelector, MatchValue, PointIdsList

    total = 0
    ids = [stable_point_id(service_name, p.replace("\\", "/")) for p in posix_paths]
    client.delete(collection_name=coll, points_selector=PointIdsList(points=ids), wait=True)
    total += len(ids)

    for p in posix_paths:
        display = _posix_to_display_path(p.replace("\\", "/"))
        client.delete(
            collection_name=coll,
            points_selector=FilterSelector(
                filter=Filter(
                    must=[
                        FieldCondition(
                            key="relative_file_path",
                            match=MatchValue(value=display),
                        )
                    ]
                )
            ),
            wait=True,
        )
        total += 1
    return total
