"""
Shared Git helpers: diff between two refs (e.g. pre-merge vs post-merge on main).
"""

from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

EMPTY_TREE_SHA = "4b825dc642cb6eb9a060e54bf8d69288fbee4904"


def run_git(cwd: Path, args: list[str]) -> str:
    r = subprocess.run(
        ["git", *args],
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return r.stdout


def git_toplevel(cwd: Path) -> Path:
    out = run_git(cwd, ["rev-parse", "--show-toplevel"]).strip()
    return Path(out)


def git_ls_files_py(repo: Path) -> list[str]:
    out = run_git(repo, ["ls-files", "-z", "*.py"])
    return [p.replace("/", os.sep) for p in out.split("\0") if p]


def git_ls_all_tracked(repo: Path) -> list[tuple[str, str]]:
    """Return (status, path) with status 'M' for full sync upsert."""
    out = run_git(repo, ["ls-files", "-z"])
    paths = [p.replace("/", os.sep) for p in out.split("\0") if p]
    return [("M", p) for p in paths]


def parse_name_status(repo: Path, base: str, head: str) -> list[tuple[str, str]]:
    """
    git diff --name-status base..head
    Yields (status_one_letter, path) for simple A/M/D; renames as D + M.
    """
    raw = run_git(repo, ["diff", "--name-status", f"{base}..{head}"])
    result: list[tuple[str, str]] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split("\t")
        tag = parts[0]
        status = tag[0]
        if status == "R" or status == "C":
            if len(parts) >= 3:
                old_p, new_p = parts[1], parts[2]
                result.append(("D", old_p.replace("/", os.sep)))
                result.append(("M", new_p.replace("/", os.sep)))
            continue
        if len(parts) < 2:
            continue
        path = parts[1].replace("/", os.sep)
        result.append((status, path))
    return result


def is_zero_sha(s: str) -> bool:
    t = s.strip().lower().replace("0", "")
    return len(s) >= 8 and t == ""


def resolve_base_head(
    repo: Path, explicit_base: str | None, full: bool
) -> tuple[str | None, str]:
    head = os.environ.get("SYNC_HEAD_REF") or run_git(repo, ["rev-parse", "HEAD"]).strip()
    if full:
        return None, head

    base = explicit_base or os.environ.get("SYNC_BASE_REF")
    if base and is_zero_sha(base):
        logger.info("SYNC_BASE_REF is zero/empty parent; indexing full tree.")
        return None, head

    if base:
        return base.strip(), head

    try:
        parent = run_git(repo, ["rev-parse", "HEAD^"]).strip()
        return parent, head
    except subprocess.CalledProcessError:
        logger.info("No parent commit; indexing full tree.")
        return None, head


def collect_changes(
    repo: Path, base: str | None, head: str, full: bool
) -> tuple[list[str], list[str]]:
    if full or base is None:
        pairs = git_ls_all_tracked(repo)
    else:
        pairs = parse_name_status(repo, base, head)

    deleted: list[str] = []
    touched: list[str] = []
    seen_touched: set[str] = set()
    for status, path in pairs:
        if status == "D":
            deleted.append(path)
            seen_touched.discard(path)
        elif status in ("A", "M"):
            if path not in seen_touched:
                seen_touched.add(path)
                touched.append(path)
        else:
            logger.debug("Ignoring diff status %s for %s", status, path)
    return deleted, touched


def rev_parse(repo: Path, ref: str) -> str:
    return run_git(repo, ["rev-parse", ref]).strip()


def commit_subject(repo: Path, ref: str) -> str:
    return run_git(repo, ["log", "-1", "--format=%s", ref]).strip()


def is_merge_commit(repo: Path, ref: str) -> bool:
    r = subprocess.run(
        ["git", "rev-parse", f"{ref}^2"],
        cwd=repo,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return r.returncode == 0


def diff_stat(repo: Path, base: str, head: str) -> str:
    return run_git(repo, ["diff", "--stat", f"{base}..{head}"])


def diff_shortstat(repo: Path, base: str, head: str) -> str:
    return run_git(repo, ["diff", "--shortstat", f"{base}..{head}"]).strip()
