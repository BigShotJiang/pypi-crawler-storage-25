from __future__ import annotations

from codebase_ast_core.settings import Settings


def vector_store_targets(settings: Settings) -> frozenset[str]:
    """
    Parse VECTOR_STORE_TARGET: neo4j | qdrant | both (case-insensitive).

    ``neo4j`` means the AST Neo4j pipeline should run; ``qdrant`` means the local EMBED_MODEL->Qdrant pipeline.
    """
    raw = (getattr(settings, "vector_store_target", None) or "neo4j").strip().lower()
    if raw == "both":
        return frozenset({"neo4j", "qdrant"})
    if raw in ("neo4j", "qdrant"):
        return frozenset({raw})
    raise ValueError(
        f"Invalid VECTOR_STORE_TARGET={raw!r}; expected neo4j, qdrant, or both."
    )


def wants_neo4j(settings: Settings) -> bool:
    return "neo4j" in vector_store_targets(settings)


def wants_qdrant(settings: Settings) -> bool:
    return "qdrant" in vector_store_targets(settings)
