"""Load chunks via codebase-ast-core loaders."""

from __future__ import annotations

from pathlib import Path

from codebase_ast_core.loaders.orchestrator import extract_file, index_codebase


def collect_chunks_for_repo(
    repo: Path, *, rel_paths: list[str] | None = None, full: bool = False
) -> list[dict]:
    """Return shipper chunk dicts for ``rel_paths`` or entire repo when ``full``."""
    repo = repo.resolve()
    if full or rel_paths is None:
        return index_codebase(str(repo), ui_app_root=str(repo))

    chunks: list[dict] = []
    for rel in rel_paths:
        abs_path = (repo / rel).resolve()
        if not abs_path.is_file():
            continue
        chunks.extend(extract_file(abs_path, repo_root=repo))
    return chunks
