"""
Qdrant file-level embeddings via ``langchain_huggingface.HuggingFaceEmbeddings``.

Matches codebase_shipper ``QdrantEmbeddingManager`` (``model_name=EMBED_MODEL`` path,
``embed_documents`` for batches, ``_client.get_sentence_embedding_dimension()``).

HF hub snapshot pointer files are still materialized here (Windows-friendly) before
passing the directory to LangChain.
"""

from __future__ import annotations

import hashlib
import logging
import shutil
import time
from functools import lru_cache
from pathlib import Path
from typing import Sequence

from codebase_ast_core.settings import Settings

logger = logging.getLogger(__name__)


def _is_hf_blob_pointer_file(path: Path) -> bool:
    """HF hub layout: small text file whose sole line is a relative path into ``blobs/``."""
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return False
    text = raw.strip()
    if not text or "\n" in text or text.startswith("{"):
        return False
    if not (text.startswith("../") or text.startswith("./")):
        return False
    target = (path.parent / text).resolve()
    return target.is_file()


def _materialize_hf_snapshot(snapshot_dir: Path, cache_root: Path) -> str:
    """
    Copy snapshot files, resolving ``blobs/`` pointers into real files (Windows-friendly).

    Cached under ``codebase_reindexer/.cache/embed_model_materialized/<key>/``.
    """
    key = hashlib.sha256(str(snapshot_dir.resolve()).encode()).hexdigest()[:20]
    dest = cache_root / "embed_model_materialized" / key
    done = dest / ".materialized_complete"
    if done.is_file():
        return str(dest.resolve())

    if not snapshot_dir.is_dir():
        raise RuntimeError(f"EMBED_MODEL is not a directory: {snapshot_dir}")

    logger.info("Materializing HF snapshot %s -> %s (one-time copy)", snapshot_dir, dest)
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)

    for src in sorted(snapshot_dir.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(snapshot_dir)
        out = dest / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        if _is_hf_blob_pointer_file(src):
            blob = (src.parent / src.read_text(encoding="utf-8").strip()).resolve()
            shutil.copy2(blob, out)
        else:
            shutil.copy2(src, out)

    done.write_text(str(snapshot_dir.resolve()), encoding="utf-8")
    return str(dest.resolve())


def _resolved_embed_model_path(settings: Settings) -> str:
    """
    Return a directory loadable by ``HuggingFaceEmbeddings`` / ``SentenceTransformer``.

    Plain model folders pass through. Hugging Face hub ``snapshots/<rev>/`` trees often use
    one-line pointer files; those are materialized into ``.cache/embed_model_materialized/``.
    """
    p = Path(settings.embed_model).expanduser().resolve()
    cfg = p / "config.json"
    if cfg.is_file():
        head = cfg.read_text(encoding="utf-8", errors="ignore").lstrip()
        if head.startswith("{"):
            return str(p)
    if cfg.is_file() and _is_hf_blob_pointer_file(cfg):
        reindexer_root = Path(__file__).resolve().parents[2]
        return _materialize_hf_snapshot(p, reindexer_root / ".cache")
    return str(p)


@lru_cache(maxsize=4)
def _get_huggingface_embeddings(resolved_path: str):
    """Same construction as codebase_shipper ``QdrantEmbeddingManager``."""
    root = Path(resolved_path)
    if not root.is_dir():
        raise RuntimeError(
            f"EMBED_MODEL is not a directory or does not exist: {resolved_path!r}. "
            "Point EMBED_MODEL at a sentence-transformers snapshot folder "
            "(contains config.json, model weights, tokenizer)."
        )
    from langchain_huggingface import HuggingFaceEmbeddings

    return HuggingFaceEmbeddings(model_name=resolved_path)


def get_sentence_embedding_dimension(settings: Settings) -> int:
    """Vector size from the loaded model (e.g. 384 for all-MiniLM-L6-v2)."""
    path = _resolved_embed_model_path(settings)
    emb = _get_huggingface_embeddings(path)
    return int(emb._client.get_sentence_embedding_dimension())


def _non_empty_prompt(text: str) -> str:
    return text if text.strip() else " "


def _validate_dims(
    vectors: list[list[float]], expected: int, model_path: str
) -> list[list[float]]:
    for v in vectors:
        if len(v) != expected:
            raise RuntimeError(
                f"Embedding length {len(v)} != model dimension {expected} "
                f"(EMBED_MODEL={model_path!r})."
            )
    return vectors


def embed_texts_batched(texts: Sequence[str], settings: Settings) -> list[list[float]]:
    """Return one embedding per input string (order preserved)."""
    if not texts:
        return []
    path = _resolved_embed_model_path(settings)
    dim = get_sentence_embedding_dimension(settings)
    if settings.embedding_dry_vector:
        return [[0.0] * dim for _ in texts]

    normalized = [_non_empty_prompt(t) for t in texts]
    batch_size = max(1, settings.embedding_batch_size)
    hf = _get_huggingface_embeddings(path)
    out: list[list[float]] = []
    for start in range(0, len(normalized), batch_size):
        chunk = normalized[start : start + batch_size]
        dense = hf.embed_documents(list(chunk))
        rows = [
            list(map(float, row.tolist() if hasattr(row, "tolist") else row))
            for row in dense
        ]
        out.extend(_validate_dims(rows, dim, path))
        if start + batch_size < len(normalized):
            time.sleep(0.02)
    return out
