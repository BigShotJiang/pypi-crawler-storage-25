from __future__ import annotations

import argparse
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from codebase_ast_core.settings import get_settings
from codebase_qdrant_sync import qdrant_ops
from codebase_qdrant_sync.embeddings_qdrant_hf import (
    embed_texts_batched,
    get_sentence_embedding_dimension,
)
from codebase_qdrant_sync.git_diff import (
    EMPTY_TREE_SHA,
    collect_changes,
    diff_stat,
    git_toplevel,
    resolve_base_head,
    rev_parse,
)
from codebase_qdrant_sync.loader_bridge import collect_chunks_for_repo
from codebase_qdrant_sync.vector_targets import vector_store_targets, wants_qdrant

logger = logging.getLogger(__name__)

TEXT_SUFFIXES = {".py", ".txt", ".md", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg"}
MAX_EMBED_CHARS = 50_000
MAX_STORE_CHARS = 2_000_000


def _ensure_qdrant_target(settings: Any) -> None:
    """Neo4j graph indexing is AST-only; this pipeline writes Qdrant only."""
    vector_store_targets(settings)
    if not wants_qdrant(settings):
        raise ValueError(
            "Qdrant indexer requires VECTOR_STORE_TARGET=qdrant or both "
            "(neo4j-only targets use the AST indexer: python -m src.cli.sync_ast)."
        )


def read_file_text(repo: Path, rel: str) -> tuple[str, bool]:
    abs_path = repo / rel
    try:
        data = abs_path.read_bytes()
    except OSError as e:
        logger.warning("Could not read %s: %s", rel, e)
        return "", False
    if b"\0" in data[:8192]:
        return "", False
    text = data.decode("utf-8", errors="replace")
    if len(text) > MAX_STORE_CHARS:
        text = text[:MAX_STORE_CHARS] + "\n\n[truncated for storage]\n"
    return text, True


def should_embed_path(rel: str) -> bool:
    suf = Path(rel).suffix.lower()
    return suf in TEXT_SUFFIXES or suf == ""


def _default_service_name(repo: Path) -> str:
    base = repo.name or "project"
    safe = "".join(c if c.isalnum() else "_" for c in base)[:48].strip("_") or "project"
    return safe


def run_sync(
    repo_cwd: Path,
    *,
    full: bool = False,
    dry_run: bool = False,
    explicit_base: str | None = None,
    embedding_preview_dims: int = 8,
    input_preview_chars: int = 200,
    diff_stat_max_chars: int = 32_000,
) -> dict[str, Any]:
    """
    Git diff -> local sentence-transformers embeddings -> Qdrant upserts/deletes.

    Same model snapshot as codebase_shipper (``EMBED_MODEL`` + ``sentence_transformers``).
    Requires ``VECTOR_STORE_TARGET`` ``qdrant`` or ``both``. Neo4j is not written here.
    """
    cwd = repo_cwd.resolve()
    try:
        repo = git_toplevel(cwd)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            "Not a git repository (run from repo root or pass a path inside the clone)."
        ) from e

    settings = get_settings()
    _ensure_qdrant_target(settings)

    base, head = resolve_base_head(repo, explicit_base, full)
    deleted, touched = collect_changes(repo, base, head, full)

    head_sha = rev_parse(repo, head)
    base_sha: str | None
    try:
        base_sha = rev_parse(repo, base) if base else None
    except Exception:
        base_sha = base

    stat_text = ""
    try:
        if base is None:
            stat_text = diff_stat(repo, EMPTY_TREE_SHA, head_sha)
        else:
            stat_text = diff_stat(repo, base, head)
    except Exception as e:
        logger.debug("diff_stat skipped: %s", e)
        stat_text = ""
    if len(stat_text) > diff_stat_max_chars:
        stat_text = stat_text[: diff_stat_max_chars - 40] + "\n...[diff_stat truncated]...\n"

    deleted_posix = [p.replace(os.sep, "/") for p in deleted]
    touched_posix = [p.replace(os.sep, "/") for p in touched]

    sync_mode = "full" if (full or base is None) else "incremental"
    use_loader_chunks = True
    loader_chunks: list[dict] = []
    rows: list[dict] = []
    embed_texts: list[str] = []

    if use_loader_chunks:
        try:
            loader_chunks = collect_chunks_for_repo(
                repo,
                rel_paths=touched_posix if sync_mode == "incremental" else None,
                full=sync_mode == "full",
            )
        except Exception as e:
            logger.warning("Loader chunk extraction failed, falling back to file embed: %s", e)
            loader_chunks = []

    valid_loader_chunks: list[dict] = []
    if loader_chunks:
        for chunk in loader_chunks:
            text = (chunk.get("page_content") or "").strip()
            if not text:
                continue
            if len(text) > MAX_EMBED_CHARS:
                text = text[:MAX_EMBED_CHARS]
            valid_loader_chunks.append(chunk)
            embed_texts.append(text)
        loader_chunks = valid_loader_chunks
    else:
        for rel in touched:
            content, ok = read_file_text(repo, rel)
            if not ok and not content:
                logger.info("Skipping unreadable or binary file: %s", rel)
                continue
            text_for_embed = content[:MAX_EMBED_CHARS] if should_embed_path(rel) else ""
            rows.append(
                {"path": rel.replace(os.sep, "/"), "content": content, "_embed": text_for_embed}
            )
        for row in rows:
            embed_texts.append(row["_embed"] if row["_embed"] else row["path"])

    embed_dim = get_sentence_embedding_dimension(settings)
    vectors = embed_texts_batched(embed_texts, settings) if embed_texts else []

    per_file: list[dict[str, Any]] = []
    if loader_chunks:
        for chunk, vec, text_in in zip(loader_chunks, vectors, embed_texts):
            src = chunk.get("_source_path", "")
            prev_n = min(embedding_preview_dims, len(vec))
            preview = text_in[:input_preview_chars] + (
                "..." if len(text_in) > input_preview_chars else ""
            )
            per_file.append(
                {
                    "path": str(src).replace(os.sep, "/"),
                    "chunk_type": chunk.get("chunk_type"),
                    "input_preview": preview,
                    "vector_preview": [float(x) for x in vec[:prev_n]],
                }
            )
    else:
        for row, vec, text_in in zip(rows, vectors, embed_texts):
            row["embedding"] = vec
            del row["_embed"]
            prev_n = min(embedding_preview_dims, len(vec))
            preview = text_in[:input_preview_chars] + (
                "..." if len(text_in) > input_preview_chars else ""
            )
            per_file.append(
                {
                    "path": row["path"],
                    "input_preview": preview,
                    "vector_preview": [float(x) for x in vec[:prev_n]],
                }
            )

    service_name = settings.reindex_service_name or _default_service_name(repo)

    report: dict[str, Any] = {
        "version": 2,
        "indexer": "qdrant_loader_chunks",
        "vector_store_target": settings.vector_store_target,
        "repo_root": str(repo),
        "sync_mode": sync_mode,
        "resolved_refs": {"base": base_sha, "head": head_sha},
        "diff": {
            "deleted_paths": deleted_posix,
            "touched_paths": touched_posix,
            "diff_stat": stat_text or None,
        },
        "embeddings": {
            "backend": "sentence_transformers",
            "embed_model": settings.embed_model,
            "dimension": embed_dim,
            "files": per_file,
        },
        "qdrant": {
            "dry_run": dry_run,
            "writes_completed": False,
            "service_name": service_name,
            "collection": settings.qdrant_collection,
            "vector_name": settings.qdrant_vector_name,
            "deleted_points": 0,
            "upserted_points": 0,
        },
    }

    if dry_run:
        n_upsert = len(loader_chunks) if loader_chunks else len(rows)
        logger.info(
            "Dry run: would upsert %d points, delete %d paths in Qdrant.",
            n_upsert,
            len(deleted),
        )
        report["qdrant"]["writes_completed"] = False
        return report

    qclient = qdrant_ops.make_client(settings)
    try:
        qdrant_ops.ensure_collection(qclient, settings, vector_size=embed_dim)
        if deleted:
            del_posix = [p.replace(os.sep, "/") for p in deleted]
            n_del = qdrant_ops.delete_paths(
                qclient, settings, service_name=service_name, posix_paths=del_posix
            )
            report["qdrant"]["deleted_points"] = n_del
            logger.info("Removed %d points from Qdrant.", n_del)
        if loader_chunks and vectors:
            n_up = qdrant_ops.upsert_loader_chunks(
                qclient,
                settings,
                service_name=service_name,
                chunks=loader_chunks,
                embeddings=vectors,
                vector_size=embed_dim,
            )
            report["qdrant"]["upserted_points"] = n_up
            logger.info("Upserted %d loader chunk points in Qdrant.", n_up)
        elif rows:
            for row, vec in zip(rows, vectors):
                row["embedding"] = vec
            n_up = qdrant_ops.upsert_file_embeddings(
                qclient,
                settings,
                service_name=service_name,
                rows=rows,
                embed_texts=embed_texts,
                vector_size=embed_dim,
            )
            report["qdrant"]["upserted_points"] = n_up
            logger.info("Upserted %d file points in Qdrant.", n_up)
    finally:
        qclient.close()
    report["qdrant"]["writes_completed"] = True

    return report


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(
        description="Differential Git -> Qdrant via local EMBED_MODEL (VECTOR_STORE_TARGET qdrant or both)."
    )
    parser.add_argument(
        "--full",
        action="store_true",
        help="Index all tracked files (cold start / rebuild).",
    )
    parser.add_argument(
        "--base",
        default=None,
        help="Git ref for diff base (default: HEAD^ or SYNC_BASE_REF).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Compute diff and embeddings only; skip Qdrant writes.",
    )
    args = parser.parse_args()

    try:
        run_sync(
            Path.cwd(),
            full=args.full,
            dry_run=args.dry_run,
            explicit_base=args.base,
        )
    except Exception as e:
        logger.exception("Sync failed: %s", e)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
