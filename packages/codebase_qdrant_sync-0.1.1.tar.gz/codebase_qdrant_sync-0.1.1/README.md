# codebase-qdrant-sync

Differential Qdrant indexer (depends on **codebase-ast-core** for loaders).

## Install

```bash
pip install codebase-qdrant-sync
```

## CLI

```bash
codebase-sync-qdrant --help
```

Requires `VECTOR_STORE_TARGET=qdrant` or `both`, plus `EMBED_MODEL` and Qdrant env vars (see ast-core settings).
