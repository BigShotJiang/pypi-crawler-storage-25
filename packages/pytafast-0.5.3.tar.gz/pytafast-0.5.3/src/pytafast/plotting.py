import importlib.util

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

import pytafast


class Chart:
    """
    A quantmod-inspired chaining chart builder for pytafast using Plotly.
    """

    THEMES = {
        "light": "plotly_white",
        "dark": "plotly_dark",
        "ggplot2": "ggplot2",
        "seaborn": "seaborn",
        "simple": "simple_white",
    }

    def __init__(
        self,
        df,
        date_col="Date",
        open_col="Open",
        high_col="High",
        low_col="Low",
        close_col="Close",
        vol_col="Volume",
    ):
        self.df = df.copy()
        if not pd.api.types.is_datetime64_any_dtype(self.df[date_col]):
            self.df[date_col] = pd.to_datetime(self.df[date_col])

        self.dt = self.df[date_col]
        self.O = self.df[open_col].values
        self.H = self.df[high_col].values
        self.L = self.df[low_col].values
        self.C = self.df[close_col].values
        self.V = self.df[vol_col].values if vol_col in self.df.columns else None

        self.main_traces = []
        self.subplots = []
        self.shapes = []  # For shading, lines, etc.
        self.title = "pytafast Analysis"
        self.theme = "plotly_white"
        self._has_main_price = False

    def set_theme(self, theme_name):
        """Set the chart theme (light, dark, ggplot2, seaborn)."""
        if theme_name in self.THEMES:
            self.theme = self.THEMES[theme_name]
        else:
            self.theme = theme_name  # Allow direct plotly template names
        return self

    # --- Internal Helpers ---
    def _add_overlay(self, y, name, color=None, width=1.5, dash=None):
        trace = go.Scatter(
            x=self.dt,
            y=y,
            mode="lines",
            name=name,
            line=dict(color=color, width=width, dash=dash),
        )
        self.main_traces.append(trace)
        return self

    def _add_subplot(self, traces, name, height=0.2, yrange=None):
        self.subplots.append(
            {"traces": traces, "height": height, "name": name, "yrange": yrange}
        )
        return self

    # --- Core Plots ---
    def add_candlestick(self, name="Price"):
        # Determine colors based on theme
        is_dark = "dark" in self.theme
        inc = "#26a69a" if not is_dark else "#00ffad"
        dec = "#ef5350" if not is_dark else "#ff5e5e"

        self.main_traces.append(
            go.Candlestick(
                x=self.dt,
                open=self.O,
                high=self.H,
                low=self.L,
                close=self.C,
                name=name,
                increasing_line_color=inc,
                decreasing_line_color=dec,
                increasing_fillcolor=inc,
                decreasing_fillcolor=dec,
            )
        )
        self._has_main_price = True
        return self

    def add_line(self, name="Close Price", color=None):
        if color is None:
            color = (
                "#1f77b4" if "white" in self.theme or "light" in self.theme else "white"
            )
        self._add_overlay(self.C, name, color, width=2)
        self._has_main_price = True
        return self

    def add_volume(self, height=0.15):
        if self.V is None:
            return self
        is_dark = "dark" in self.theme
        inc = "#26a69a" if not is_dark else "#00ffad"
        dec = "#ef5350" if not is_dark else "#ff5e5e"
        colors = np.where(self.C >= self.O, inc, dec)
        return self._add_subplot(
            [
                go.Bar(
                    x=self.dt,
                    y=self.V,
                    name="Volume",
                    marker_color=colors,
                    opacity=0.5,
                )
            ],
            "Volume",
            height,
        )

    # --- Overlap (Main Chart) ---
    def add_sma(self, n=20, color="#f29d4b"):
        return self._add_overlay(pytafast.SMA(self.C, n), f"SMA({n})", color)

    def add_ema(self, n=20, color="#5d62b5"):
        return self._add_overlay(pytafast.EMA(self.C, n), f"EMA({n})", color)

    def add_wma(self, n=20, color="#33a02c"):
        return self._add_overlay(pytafast.WMA(self.C, n), f"WMA({n})", color)

    def add_dema(self, n=20, color="#e31a1c"):
        return self._add_overlay(pytafast.DEMA(self.C, n), f"DEMA({n})", color)

    def add_tema(self, n=20, color="#fb9a99"):
        return self._add_overlay(pytafast.TEMA(self.C, n), f"TEMA({n})", color)

    def add_kama(self, n=20, color="#6a3d9a"):
        return self._add_overlay(pytafast.KAMA(self.C, n), f"KAMA({n})", color)

    def add_hma(self, n=20, color="#b15928"):
        return self._add_overlay(pytafast.HMA(self.C, n), f"HMA({n})", color)

    def add_alma(self, n=9, offset=0.85, sigma=6.0):
        return self._add_overlay(
            pytafast.ALMA(self.C, n, offset, sigma), f"ALMA({n})", "#1f78b4"
        )

    def add_zlema(self, n=30):
        return self._add_overlay(pytafast.ZLEMA(self.C, n), f"ZLEMA({n})", "#ff7f00")

    def add_evwma(self, n=30):
        return self._add_overlay(
            pytafast.EVWMA(self.C, self.V, n), f"EVWMA({n})", "#b2df8a"
        )

    def add_sar(self, accel=0.02, max_step=0.2):
        s = pytafast.SAR(self.H, self.L, accel, max_step)
        color = "black" if "white" in self.theme or "light" in self.theme else "white"
        trace = go.Scatter(
            x=self.dt, y=s, mode="markers", name="SAR", marker=dict(color=color, size=4)
        )
        self.main_traces.append(trace)
        return self

    def add_bbands(self, n=20, sd=2.0, color="rgba(173, 216, 230, 0.15)"):
        u, m, low_val = pytafast.BBANDS(self.C, n, sd, sd)
        self._add_overlay(u, "BB Upper", "rgba(173, 216, 230, 0.4)", 1)
        self._add_overlay(low_val, "BB Lower", "rgba(173, 216, 230, 0.4)", 1)
        self.main_traces[-1].fill = "tonexty"
        self.main_traces[-1].fillcolor = color
        return self._add_overlay(m, "BB Mid", "rgba(128, 128, 128, 0.5)", 1, "dash")

    def add_keltner(self, n=20, mult=2.0):
        u, m, low_val = pytafast.keltnerChannels(self.H, self.L, self.C, n, mult)
        self._add_overlay(u, "Keltner Upper", "rgba(255,165,0,0.3)", 1)
        self._add_overlay(low_val, "Keltner Lower", "rgba(255,165,0,0.3)", 1)
        self.main_traces[-1].fill = "tonexty"
        self.main_traces[-1].fillcolor = "rgba(255,165,0,0.1)"
        return self._add_overlay(m, "Keltner Mid", "orange", 1, "dot")

    def add_donchian(self, n=10):
        u, m, low_val = pytafast.DonchianChannel(self.H, self.L, n)
        self._add_overlay(u, "Donchian High", "rgba(200,200,200,0.3)", 1)
        self._add_overlay(low_val, "Donchian Low", "rgba(200,200,200,0.3)", 1)
        self.main_traces[-1].fill = "tonexty"
        self.main_traces[-1].fillcolor = "rgba(200,200,200,0.05)"
        return self._add_overlay(m, "Donchian Mid", "rgba(128, 128, 128, 0.5)", 1, "dash")

    def add_ichimoku(self, n1=9, n2=26, n3=52):
        """Add Ichimoku Kinko Hyo (Cloud) to the main chart."""
        # Tenkan-sen (9-period high + 9-period low) / 2
        t_high = pytafast.MAX(self.H, n1)
        t_low = pytafast.MIN(self.L, n1)
        tenkan = (t_high + t_low) / 2

        # Kijun-sen (26-period high + 26-period low) / 2
        k_high = pytafast.MAX(self.H, n2)
        k_low = pytafast.MIN(self.L, n2)
        kijun = (k_high + k_low) / 2

        # Senkou Span A (Leading Span A): (Tenkan + Kijun) / 2, shifted forward n2 periods
        ssa = (tenkan + kijun) / 2
        # Senkou Span B (Leading Span B): (52-period high + 52-period low) / 2, shifted forward n2 periods
        b_high = pytafast.MAX(self.H, n3)
        b_low = pytafast.MIN(self.L, n3)
        ssb = (b_high + b_low) / 2

        # Shift forward
        dt_shifted = pd.to_datetime(self.dt)
        # Calculate time delta
        delta = dt_shifted.diff().median()
        # Create future index
        future_dt = [dt_shifted.iloc[-1] + (i * delta) for i in range(1, n2 + 1)]
        all_dt = np.concatenate([self.dt.values, np.array(future_dt)])

        # Create padded series for spans
        ssa_padded = np.full(len(all_dt), np.nan)
        ssb_padded = np.full(len(all_dt), np.nan)
        ssa_padded[n2 : n2 + len(ssa)] = ssa
        ssb_padded[n2 : n2 + len(ssb)] = ssb

        # Plots
        self._add_overlay(tenkan, "Tenkan", "blue", 1)
        self._add_overlay(kijun, "Kijun", "red", 1)

        # Plot Spans (only on the extended timeframe if needed, or truncated)
        # Note: plotly handles X-axis expansion if we provide new X values
        self.main_traces.append(
            go.Scatter(
                x=all_dt,
                y=ssa_padded,
                name="Senkou Span A",
                line=dict(color="rgba(0, 255, 0, 0.3)", width=1),
            )
        )
        self.main_traces.append(
            go.Scatter(
                x=all_dt,
                y=ssb_padded,
                name="Senkou Span B",
                line=dict(color="rgba(255, 0, 0, 0.3)", width=1),
                fill="tonexty",
                fillcolor="rgba(144, 238, 144, 0.1)",
            )
        )

        return self

    def add_zigzag(self, change=5.0, percent=True):
        zz = pytafast.ZIGZAG(self.H, self.L, change, percent)
        return self._add_overlay(zz, "ZigZag", "blue", 2, "dashdot")

    def add_envelope(self, n=20, p=2.5, color="rgba(0, 0, 255, 0.1)"):
        """Add Moving Average Envelope around SMA."""
        ma = pytafast.SMA(self.C, n)
        u = ma * (1 + p / 100)
        low_val = ma * (1 - p / 100)
        self._add_overlay(u, "Env Upper", "rgba(0, 0, 255, 0.3)", 1, "dot")
        self._add_overlay(low_val, "Env Lower", "rgba(0, 0, 255, 0.3)", 1, "dot")
        self.main_traces[-1].fill = "tonexty"
        self.main_traces[-1].fillcolor = color
        return self

    def add_shading(self, start, end, color="rgba(128, 128, 128, 0.2)"):
        """Highlight a vertical time region (start/end can be dates or indices)."""
        self.shapes.append(
            {"type": "rect", "x0": start, "x1": end, "color": color, "axis": "x"}
        )
        return self

    def add_hline(self, y, color="gray", dash="dash"):
        """Add a horizontal line to the main chart."""
        self.shapes.append(
            {
                "type": "line",
                "y0": y,
                "y1": y,
                "color": color,
                "dash": dash,
                "axis": "y",
            }
        )
        return self

    def add_vline(self, x, color="gray", dash="dash"):
        """Add a vertical line to the main chart."""
        self.shapes.append(
            {
                "type": "line",
                "x0": x,
                "x1": x,
                "color": color,
                "dash": dash,
                "axis": "x",
            }
        )
        return self

    def add_last(self, color="red"):
        """Add a horizontal line at the last closing price."""
        last_price = self.C[-1]
        self.add_hline(last_price, color=color, dash="dash")
        # Add annotation for the price
        self.shapes.append(
            {
                "type": "text",
                "x": self.dt.iloc[-1],
                "y": last_price,
                "text": f"{last_price:.2f}",
                "color": color,
            }
        )
        return self

    def add_points(self, x, y, name="Points", color="black", symbol="circle", size=8):
        """Add custom scatter points to the main chart."""
        if not isinstance(x, (list, np.ndarray, pd.Series)):
            x = [x]
        if not isinstance(y, (list, np.ndarray, pd.Series)):
            y = [y]
        self.main_traces.append(
            go.Scatter(
                x=x,
                y=y,
                mode="markers",
                name=name,
                marker=dict(color=color, symbol=symbol, size=size),
            )
        )
        return self

    def add_text(self, x, y, text, color="black", position="top center"):
        """Add custom text annotations to the main chart."""
        if not isinstance(x, (list, np.ndarray, pd.Series)):
            x = [x]
        if not isinstance(y, (list, np.ndarray, pd.Series)):
            y = [y]
        if not isinstance(text, (list, np.ndarray, pd.Series)):
            text = [text]
        self.main_traces.append(
            go.Scatter(
                x=x,
                y=y,
                mode="text",
                text=text,
                textposition=position,
                showlegend=False,
                textfont=dict(color=color),
            )
        )
        return self

    # --- Momentum (Subplots) ---
    def add_rsi(self, n=14, height=0.2):
        v = pytafast.RSI(self.C, n)
        color = "#9467bd"
        traces = [
            go.Scatter(x=self.dt, y=v, name=f"RSI({n})", line=dict(color=color)),
            go.Scatter(
                x=self.dt,
                y=[70] * len(self.dt),
                showlegend=False,
                line=dict(color="red", dash="dash"),
            ),
            go.Scatter(
                x=self.dt,
                y=[30] * len(self.dt),
                showlegend=False,
                line=dict(color="green", dash="dash"),
            ),
        ]
        return self._add_subplot(traces, "RSI", height, [0, 100])

    def add_macd(self, f=12, s=26, sig=9, height=0.2):
        m, signal, h = pytafast.MACD(self.C, f, s, sig)
        inc = "#26a69a"
        dec = "#ef5350"
        traces = [
            go.Bar(
                x=self.dt,
                y=h,
                name="MACD Hist",
                marker_color=np.where(h >= 0, inc, dec),
            ),
            go.Scatter(x=self.dt, y=m, name="MACD"),
            go.Scatter(x=self.dt, y=signal, name="Signal"),
        ]
        return self._add_subplot(traces, "MACD", height)

    def add_stoch(self, k=5, d=3, height=0.2):
        sk, sd = pytafast.STOCH(self.H, self.L, self.C, k, d)
        return self._add_subplot(
            [
                go.Scatter(x=self.dt, y=sk, name="%K"),
                go.Scatter(x=self.dt, y=sd, name="%D"),
            ],
            "Stoch",
            height,
            [0, 100],
        )

    def add_willr(self, n=14, height=0.2):
        return self._add_subplot(
            [
                go.Scatter(
                    x=self.dt, y=pytafast.WILLR(self.H, self.L, self.C, n), name="WILLR"
                )
            ],
            "Williams %R",
            height,
            [-100, 0],
        )

    def add_cci(self, n=14, height=0.2):
        return self._add_subplot(
            [
                go.Scatter(
                    x=self.dt, y=pytafast.CCI(self.H, self.L, self.C, n), name="CCI"
                )
            ],
            "CCI",
            height,
        )

    def add_adx(self, n=14, height=0.2):
        adx = pytafast.ADX(self.H, self.L, self.C, n)
        pdi = pytafast.PLUS_DI(self.H, self.L, self.C, n)
        mdi = pytafast.MINUS_DI(self.H, self.L, self.C, n)
        traces = [
            go.Scatter(x=self.dt, y=adx, name=f"ADX({n})", line=dict(color="black")),
            go.Scatter(
                x=self.dt, y=pdi, name=f"+DI({n})", line=dict(color="green", dash="dot")
            ),
            go.Scatter(
                x=self.dt, y=mdi, name=f"-DI({n})", line=dict(color="red", dash="dot")
            ),
        ]
        return self._add_subplot(traces, "ADX", height)

    def add_momentum(self, n=10, height=0.2):
        v = pytafast.MOM(self.C, n)
        return self._add_subplot(
            [go.Scatter(x=self.dt, y=v, name=f"Mom({n})")], "Momentum", height
        )

    def add_mfi(self, n=14, height=0.2):
        return self._add_subplot(
            [
                go.Scatter(
                    x=self.dt,
                    y=pytafast.MFI(self.H, self.L, self.C, self.V, n),
                    name="MFI",
                )
            ],
            "MFI",
            height,
            [0, 100],
        )

    def add_cmf(self, n=20, height=0.2):
        return self._add_subplot(
            [
                go.Scatter(
                    x=self.dt,
                    y=pytafast.CMF(self.H, self.L, self.C, self.V, n),
                    name="CMF",
                )
            ],
            "CMF",
            height,
        )

    def add_chaikin_osc(self, fast=3, slow=10, height=0.2):
        v = pytafast.ADOSC(self.H, self.L, self.C, self.V, fast, slow)
        return self._add_subplot(
            [go.Scatter(x=self.dt, y=v, name=f"ChaikinOsc({fast},{slow})")],
            "Chaikin Osc",
            height,
        )

    def add_clv(self, height=0.15):
        # CLV = ((C-L)-(H-C))/(H-L)
        denom = self.H - self.L
        v = np.where(denom != 0, ((self.C - self.L) - (self.H - self.C)) / denom, 0.0)
        return self._add_subplot(
            [go.Scatter(x=self.dt, y=v, name="CLV")], "CLV", height
        )

    def add_tdi(self, n=13, rsi_ma1=2, rsi_ma2=7, bb_n=34, bb_sd=1.6185, height=0.25):
        """Traders Dynamic Index (TDI)."""
        rsi = pytafast.RSI(self.C, n)
        rsi_price_line = pytafast.SMA(rsi, rsi_ma1)
        trade_signal_line = pytafast.SMA(rsi, rsi_ma2)

        # Volatility Band around RSI
        u, m, low_val = pytafast.BBANDS(rsi, bb_n, bb_sd, bb_sd)

        traces = [
            go.Scatter(
                x=self.dt,
                y=rsi_price_line,
                name="RSI Price Line",
                line=dict(color="green", width=1.5),
            ),
            go.Scatter(
                x=self.dt,
                y=trade_signal_line,
                name="Trade Signal",
                line=dict(color="red", width=1.5),
            ),
            go.Scatter(
                x=self.dt,
                y=m,
                name="Market Base Line",
                line=dict(color="orange", width=2),
            ),
            go.Scatter(
                x=self.dt,
                y=u,
                name="VB Upper",
                line=dict(color="rgba(0,0,255,0.2)", width=1),
            ),
            go.Scatter(
                x=self.dt,
                y=low_val,
                name="VB Lower",
                line=dict(color="rgba(0,0,255,0.2)", width=1),
                fill="tonexty",
                fillcolor="rgba(0,0,255,0.05)",
            ),
        ]
        return self._add_subplot(traces, "TDI", height)

    def add_kst(self, height=0.2):
        k, s = pytafast.KST(self.C)
        return self._add_subplot(
            [
                go.Scatter(x=self.dt, y=k, name="KST"),
                go.Scatter(x=self.dt, y=s, name="Signal"),
            ],
            "KST",
            height,
        )

    def add_obv(self, height=0.15):
        v = pytafast.OBV(self.C, self.V)
        return self._add_subplot(
            [go.Scatter(x=self.dt, y=v, name="OBV", fill="tozeroy")], "OBV", height
        )

    def add_aroon(self, n=14, height=0.2):
        dn, up = pytafast.AROON(self.H, self.L, n)
        return self._add_subplot(
            [
                go.Scatter(x=self.dt, y=up, name="Aroon Up", line=dict(color="green")),
                go.Scatter(x=self.dt, y=dn, name="Aroon Down", line=dict(color="red")),
            ],
            "Aroon",
            height,
            [0, 100],
        )

    def add_smi(self, n=13, nFast=2, nSlow=25, nSig=9, height=0.2):
        smi, signal = pytafast.SMI(self.H, self.L, self.C, n, nFast, nSlow, nSig)
        return self._add_subplot(
            [
                go.Scatter(x=self.dt, y=smi, name="SMI"),
                go.Scatter(x=self.dt, y=signal, name="Signal", line=dict(dash="dash")),
            ],
            "SMI",
            height,
            [-100, 100],
        )

    def add_roc(self, n=10, height=0.2):
        v = pytafast.ROC(self.C, n)
        return self._add_subplot(
            [
                go.Scatter(x=self.dt, y=v, name=f"ROC({n})"),
                go.Scatter(
                    x=self.dt,
                    y=[0] * len(self.dt),
                    showlegend=False,
                    line=dict(color="gray", dash="dot"),
                ),
            ],
            "ROC",
            height,
        )

    def add_cmo(self, n=14, height=0.2):
        v = pytafast.CMO(self.C, n)
        return self._add_subplot(
            [
                go.Scatter(x=self.dt, y=v, name=f"CMO({n})"),
                go.Scatter(
                    x=self.dt,
                    y=[50] * len(self.dt),
                    showlegend=False,
                    line=dict(color="red", dash="dash"),
                ),
                go.Scatter(
                    x=self.dt,
                    y=[-50] * len(self.dt),
                    showlegend=False,
                    line=dict(color="green", dash="dash"),
                ),
            ],
            "CMO",
            height,
            [-100, 100],
        )

    def add_emv(self, n=9, height=0.2):
        v, sv = pytafast.EMV(self.H, self.L, self.V, n)
        return self._add_subplot(
            [
                go.Scatter(x=self.dt, y=v, name="EMV", line=dict(width=1), opacity=0.5),
                go.Scatter(x=self.dt, y=sv, name=f"Signal({n})", line=dict(width=2)),
            ],
            "EMV",
            height,
        )

    def add_trix(self, n=30, height=0.2):
        v = pytafast.TRIX(self.C, n)
        return self._add_subplot(
            [go.Scatter(x=self.dt, y=v, name=f"TRIX({n})")], "TRIX", height
        )

    def add_dpo(self, n=10, height=0.2):
        v = pytafast.DPO(self.C, n)
        return self._add_subplot(
            [
                go.Bar(
                    x=self.dt,
                    y=v,
                    name=f"DPO({n})",
                    marker_color=np.where(v >= 0, "green", "red"),
                )
            ],
            "DPO",
            height,
        )

    # --- Volatility (Subplots) ---
    def add_atr(self, n=14, height=0.15):
        return self._add_subplot(
            [
                go.Scatter(
                    x=self.dt, y=pytafast.ATR(self.H, self.L, self.C, n), name="ATR"
                )
            ],
            "ATR",
            height,
        )

    def add_volatility(self, n=10, height=0.2):
        """Chaikin Volatility: percent change in EMA of (High-Low) range."""
        hl = self.H - self.L
        ema_hl = pytafast.EMA(hl, n)
        # (EMA_HL / EMA_HL_prev_n) - 1
        v = np.full_like(ema_hl, np.nan)
        if len(ema_hl) > n:
            v[n:] = (ema_hl[n:] / ema_hl[:-n]) - 1.0
        return self._add_subplot(
            [go.Scatter(x=self.dt, y=v * 100, name=f"ChaikinVol({n})")],
            "Chaikin Vol %",
            height,
        )

    def add_patterns(self):
        """Automatically find and label all recognized candlestick patterns."""
        patterns = [m for m in dir(pytafast) if m.startswith("CDL")]
        first_pattern = True
        for p_name in patterns:
            res = getattr(pytafast, p_name)(self.O, self.H, self.L, self.C)
            # Find indices where pattern is detected (100 or -100)
            hit_idx = np.where(res != 0)[0]
            if len(hit_idx) > 0:
                self.main_traces.append(
                    go.Scatter(
                        x=self.dt.iloc[hit_idx],
                        y=self.H[hit_idx] * 1.02,
                        mode="markers",
                        name="Candlestick Patterns" if first_pattern else p_name,
                        legendgroup="candlestick_patterns",
                        showlegend=first_pattern,
                        text=[p_name[3:]] * len(hit_idx),
                        hovertext=[f"{p_name[3:]} ({'Bullish' if res[idx] > 0 else 'Bearish'})" for idx in hit_idx],
                        hoverinfo="text",
                        marker=dict(symbol="triangle-down", size=8),
                    )
                )
                first_pattern = False
        return self

    # --- Render Engine ---
    def render(self):
        if not self._has_main_price:
            self.add_candlestick()
        n_subplots = len(self.subplots)
        sub_heights = [sp["height"] for sp in self.subplots]

        # Calculate total subplot weight
        total_sub_weight = sum(sub_heights)
        # Ensure main chart is at least 40% of the total height if possible,
        # otherwise scale everything down
        main_weight = max(0.4, 1.0 - total_sub_weight - (0.02 * n_subplots))

        # Normalize weights to sum to ~1.0
        total_weight = main_weight + total_sub_weight
        row_heights = [main_weight / total_weight] + [
            h / total_weight for h in sub_heights
        ]

        fig = make_subplots(
            rows=1 + n_subplots,
            cols=1,
            shared_xaxes=True,
            vertical_spacing=0.02,  # Tighter spacing
            row_heights=row_heights,
        )

        fig.update_yaxes(title_text="Price", row=1, col=1)

        for t in self.main_traces:
            fig.add_trace(t, row=1, col=1)
        for i, sp in enumerate(self.subplots):
            row_num = i + 2
            for t in sp["traces"]:
                fig.add_trace(t, row=row_num, col=1)
            fig.update_yaxes(title_text=sp["name"], row=row_num, col=1)
            if sp.get("yrange"):
                fig.update_yaxes(range=sp["yrange"], row=row_num, col=1)

        # Apply Shapes
        for s in self.shapes:
            if s.get("type") == "text":
                fig.add_annotation(
                    x=s["x"],
                    y=s["y"],
                    text=s["text"],
                    showarrow=True,
                    arrowhead=1,
                    ax=40,
                    ay=0,
                    font=dict(color=s["color"], size=12),
                    bgcolor="white",
                    bordercolor=s["color"],
                    row=1,
                    col=1,
                )
                continue

            if s["axis"] == "x":
                if s["type"] == "rect":
                    # Shading typically only on main price chart
                    fig.add_vrect(
                        x0=s["x0"],
                        x1=s["x1"],
                        fillcolor=s["color"],
                        opacity=1.0,
                        layer="below",
                        line_width=0,
                        row=1,
                        col=1,
                    )
                else:  # vline - apply to all rows
                    for r in range(1, 2 + n_subplots):
                        fig.add_vline(
                            x=s["x0"],
                            line=dict(color=s["color"], dash=s["dash"]),
                            row=r,
                            col=1,
                        )
            elif s["axis"] == "y":
                # Horizontal line only on main chart
                fig.add_hline(
                    y=s["y0"],
                    line=dict(color=s["color"], dash=s["dash"]),
                    row=1,
                    col=1,
                )

        fig.update_layout(
            title=self.title,
            template=self.theme,
            xaxis_rangeslider_visible=False,
            height=600 + (n_subplots * 150),
            margin=dict(l=60, r=40, t=60, b=40),
            hovermode="x unified",
            hoversubplots="axis",
        )
        fig.update_xaxes(
            showspikes=True,
            spikemode="across",
            spikesnap="cursor",
            spikethickness=1,
            spikedash="dash",
            spikecolor="rgba(128, 128, 128, 0.5)",
        )
        fig.update_yaxes(
            showspikes=True,
            spikemode="across",
            spikesnap="cursor",
            spikethickness=1,
            spikedash="dash",
            spikecolor="rgba(128, 128, 128, 0.5)",
        )
        fig.update_xaxes(rangeslider=dict(visible=True), row=1 + n_subplots, col=1)
        return fig

    def show(self):
        self.render().show()

    def save_html(self, filename="chart.html"):
        self.render().write_html(filename)

    def save_image(self, filename="chart.png", w=1200, h=800):
        """
        Renders and saves the chart to a static image (PNG, JPG, PDF, SVG).
        Requires 'kaleido' package (pip install kaleido).
        """
        if importlib.util.find_spec("kaleido") is None:
            raise ImportError(
                "The 'kaleido' package is required for saving images. "
                "Install it with 'pip install kaleido'."
            )

        import warnings

        f = self.render()
        f.update_layout(width=w, height=h)
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                category=DeprecationWarning,
            )
            f.write_image(filename)
        print(f"Chart image saved to {filename}")
