from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from chalk_remote_call._native import start_server
from chalk_remote_call.servicer import process_batches

logger = logging.getLogger(__name__)


def serve(
    handler: Callable[..., Any],
    host: str = "[::]",
    port: int = 6666,
    workers: int = 10,
    on_startup: Callable[[], None] | None = None,
    on_shutdown: Callable[[], None] | None = None,
    arg_names: list[str] | None = None,
) -> None:
    """Start the gRPC server implementing RemoteCallService.

    Args:
        handler: The user's handler function (event, context) -> result.
        host: The host to bind to.
        port: The port to bind to.
        workers: Number of worker threads for the tokio runtime.
        on_startup: Optional startup hook called before the server starts accepting requests.
        on_shutdown: Optional shutdown hook called after the server stops accepting requests.
        arg_names: Parsed CHALK_INPUT_ARGS column names, or None.
    """
    # Run startup hook before starting the Rust server
    if on_startup is not None:
        logger.info("Running startup hook...")
        on_startup()

    logger.info("Starting server on %s:%d", host, port)
    try:
        start_server(
            handler=handler,
            process_fn=process_batches,
            host=host,
            port=port,
            workers=workers,
            arg_names=arg_names,
        )
    finally:
        if on_shutdown is not None:
            logger.info("Running shutdown hook...")
            on_shutdown()
