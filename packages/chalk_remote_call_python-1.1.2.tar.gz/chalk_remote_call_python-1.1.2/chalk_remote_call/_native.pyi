from collections.abc import Callable
from typing import Any

def start_server(
    handler: Callable[..., Any],
    process_fn: Callable[[bytes, Callable[..., Any], list[str] | None, dict[str, Any]], list[bytes]],
    host: str,
    port: int,
    workers: int,
    arg_names: list[str] | None = None,
) -> None: ...
