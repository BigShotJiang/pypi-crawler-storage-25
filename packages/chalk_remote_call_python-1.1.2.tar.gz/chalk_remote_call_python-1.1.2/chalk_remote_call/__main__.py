from chalk_remote_call.cli import main

main()
