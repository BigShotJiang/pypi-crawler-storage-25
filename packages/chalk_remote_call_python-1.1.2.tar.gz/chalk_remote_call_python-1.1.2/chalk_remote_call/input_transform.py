from __future__ import annotations

import os

import pyarrow as pa


def parse_input_args() -> list[str] | None:
    """Parse CHALK_INPUT_ARGS env var into a list of column names.

    Returns None if the env var is unset or empty.
    """
    raw = os.environ.get("CHALK_INPUT_ARGS", "").strip()
    if not raw:
        return None
    return [name.strip() for name in raw.split(",") if name.strip()]


def transform(batch: pa.RecordBatch, arg_names: list[str] | None) -> dict[str, pa.Array]:
    """Transform a RecordBatch into a dict of named arrays.

    If arg_names is provided, columns are renamed by index to the given names
    (ignoring the original column names). If arg_names is None, the original
    column names are used.
    """
    if arg_names is not None:
        if len(arg_names) != batch.num_columns:
            raise ValueError(
                f"CHALK_INPUT_ARGS specifies {len(arg_names)} names but RecordBatch has {batch.num_columns} columns"
            )
        return {name: batch.column(i) for i, name in enumerate(arg_names)}
    return {batch.schema.field(i).name: batch.column(i) for i in range(batch.num_columns)}
