from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pyarrow as pa

from chalk_remote_call.arrow_utils import decode_ipc_stream, encode_record_batch
from chalk_remote_call.input_transform import transform


def _coerce_to_record_batch(result: Any) -> pa.RecordBatch:
    """Convert a handler result to a RecordBatch for the response stream."""
    if isinstance(result, pa.RecordBatch):
        return result
    if isinstance(result, pa.Table):
        if result.num_rows > 0:
            return result.combine_chunks().to_batches()[0]
        return pa.RecordBatch.from_pydict(
            {name: [] for name in result.schema.names},
            schema=result.schema,
        )
    if isinstance(result, pa.Array):
        return pa.record_batch([result], names=["result"])
    if isinstance(result, pa.ChunkedArray):
        return pa.record_batch([result.combine_chunks()], names=["result"])
    # For list, dict, scalar — convert via pa.array
    try:
        if isinstance(result, dict):
            # dict of column_name -> values
            arrays = []
            names = []
            for key, values in result.items():
                names.append(str(key))
                if isinstance(values, pa.Array):
                    arrays.append(values)
                else:
                    arrays.append(pa.array(values if isinstance(values, list) else [values]))
            return pa.record_batch(arrays, names=names)
        if isinstance(result, list):
            arr = pa.array(result)
            return pa.record_batch([arr], names=["result"])
        # Scalar
        arr = pa.array([result])
        return pa.record_batch([arr], names=["result"])
    except Exception as e:
        raise TypeError(f"Cannot convert handler result of type {type(result).__name__} to RecordBatch: {e}") from e


def process_batches(
    ipc_bytes: bytes,
    handler: Callable[..., Any],
    arg_names: list[str] | None,
    context_metadata: dict[str, Any],
) -> list[bytes]:
    """Bridge function called from Rust via PyO3.

    Decodes IPC stream, transforms each batch, calls the handler,
    coerces the result, and encodes the response.

    Returns a list of IPC-encoded response bytes (one per input batch).
    """
    batches = decode_ipc_stream(ipc_bytes)
    results = []
    for batch in batches:
        try:
            event = transform(batch, arg_names)
        except Exception as e:
            raise ValueError(f"Input transformation failed: {e}") from e

        try:
            result = handler(event, context_metadata)
        except Exception as e:
            raise RuntimeError(f"Exception raised during handler execution: {e}") from e

        try:
            result_batch = _coerce_to_record_batch(result)
            results.append(encode_record_batch(result_batch))
        except Exception as e:
            raise RuntimeError(f"Failed to encode response: {e}") from e

    return results
