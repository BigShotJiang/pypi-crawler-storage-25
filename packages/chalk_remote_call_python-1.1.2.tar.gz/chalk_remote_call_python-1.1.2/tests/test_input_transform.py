from __future__ import annotations

import pyarrow as pa
import pytest

from chalk_remote_call.input_transform import parse_input_args, transform


class TestParseInputArgs:
    def test_unset(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv("CHALK_INPUT_ARGS", raising=False)
        assert parse_input_args() is None

    def test_empty(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("CHALK_INPUT_ARGS", "")
        assert parse_input_args() is None

    def test_whitespace_only(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("CHALK_INPUT_ARGS", "   ")
        assert parse_input_args() is None

    def test_single_arg(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("CHALK_INPUT_ARGS", "x")
        assert parse_input_args() == ["x"]

    def test_multiple_args(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("CHALK_INPUT_ARGS", "x,y,z")
        assert parse_input_args() == ["x", "y", "z"]

    def test_whitespace_trimmed(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("CHALK_INPUT_ARGS", " x , y , z ")
        assert parse_input_args() == ["x", "y", "z"]


class TestTransform:
    def test_no_arg_names_uses_column_names(self):
        batch = pa.record_batch(
            [pa.array([1, 2]), pa.array([3, 4])],
            names=["col_a", "col_b"],
        )
        result = transform(batch, None)
        assert list(result.keys()) == ["col_a", "col_b"]
        assert result["col_a"].equals(pa.array([1, 2]))
        assert result["col_b"].equals(pa.array([3, 4]))

    def test_arg_names_rename_by_index(self):
        batch = pa.record_batch(
            [pa.array([10, 20]), pa.array([30, 40])],
            names=["original_a", "original_b"],
        )
        result = transform(batch, ["x", "y"])
        assert list(result.keys()) == ["x", "y"]
        assert result["x"].equals(pa.array([10, 20]))
        assert result["y"].equals(pa.array([30, 40]))

    def test_arg_names_count_mismatch(self):
        batch = pa.record_batch(
            [pa.array([1]), pa.array([2]), pa.array([3])],
            names=["a", "b", "c"],
        )
        with pytest.raises(ValueError, match="specifies 2 names but RecordBatch has 3 columns"):
            transform(batch, ["x", "y"])
