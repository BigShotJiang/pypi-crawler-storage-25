"""Tests for handler_loader: load_handler and load_function."""

from __future__ import annotations

import types

import pytest

from chalk_remote_call.handler_loader import load_function, load_handler


def _make_module(name: str, **attrs: object) -> types.ModuleType:
    """Create a throwaway module with the given attributes."""
    mod = types.ModuleType(name)
    for k, v in attrs.items():
        setattr(mod, k, v)
    return mod


# ---------------------------------------------------------------------------
# load_function
# ---------------------------------------------------------------------------


class TestLoadFunction:
    def test_missing_dot_raises(self):
        with pytest.raises(ValueError, match="dotted path"):
            load_function("nodot", label="Test")

    def test_nonexistent_module_raises(self):
        with pytest.raises(ModuleNotFoundError):
            load_function("nonexistent_module_xyz.func", label="Test")

    def test_nonexistent_attr_raises(self):
        with pytest.raises(AttributeError, match="no attribute"):
            load_function("os.nonexistent_func_xyz", label="Test")

    def test_not_callable_raises(self):
        with pytest.raises(TypeError, match="not callable"):
            load_function("os.sep", label="Test")

    def test_loads_callable(self):
        fn = load_function("os.path.exists", label="Test")
        assert callable(fn)

    def test_label_appears_in_error(self):
        with pytest.raises(ValueError, match="Shutdown"):
            load_function("nodot", label="Shutdown")


# ---------------------------------------------------------------------------
# load_handler — auto-discovery of on_startup / on_shutdown
# ---------------------------------------------------------------------------


class TestLoadHandlerAutoDiscovery:
    def test_discovers_on_startup(self, monkeypatch):
        startup = lambda: None  # noqa: E731
        mod = _make_module("fake_mod", handler=lambda e, c: e, on_startup=startup)
        monkeypatch.setitem(__import__("sys").modules, "fake_mod", mod)

        _handler, on_startup, on_shutdown = load_handler("fake_mod.handler")
        assert on_startup is startup
        assert on_shutdown is None

    def test_discovers_on_shutdown(self, monkeypatch):
        shutdown = lambda: None  # noqa: E731
        mod = _make_module("fake_mod", handler=lambda e, c: e, on_shutdown=shutdown)
        monkeypatch.setitem(__import__("sys").modules, "fake_mod", mod)

        _handler, on_startup, on_shutdown = load_handler("fake_mod.handler")
        assert on_startup is None
        assert on_shutdown is shutdown

    def test_discovers_both(self, monkeypatch):
        startup = lambda: None  # noqa: E731
        shutdown = lambda: None  # noqa: E731
        mod = _make_module("fake_mod", handler=lambda e, c: e, on_startup=startup, on_shutdown=shutdown)
        monkeypatch.setitem(__import__("sys").modules, "fake_mod", mod)

        _handler, on_startup, on_shutdown = load_handler("fake_mod.handler")
        assert on_startup is startup
        assert on_shutdown is shutdown

    def test_ignores_non_callable(self, monkeypatch):
        mod = _make_module("fake_mod", handler=lambda e, c: e, on_startup="not callable", on_shutdown=42)
        monkeypatch.setitem(__import__("sys").modules, "fake_mod", mod)

        _handler, on_startup, on_shutdown = load_handler("fake_mod.handler")
        assert on_startup is None
        assert on_shutdown is None

    def test_neither_defined(self, monkeypatch):
        mod = _make_module("fake_mod", handler=lambda e, c: e)
        monkeypatch.setitem(__import__("sys").modules, "fake_mod", mod)

        _handler, on_startup, on_shutdown = load_handler("fake_mod.handler")
        assert on_startup is None
        assert on_shutdown is None
