from __future__ import annotations

import socket
import threading
import time
from typing import Any

import grpc
import pyarrow as pa
import pyarrow.compute as pc
import pytest
from grpc_health.v1 import health_pb2, health_pb2_grpc
from grpc_reflection.v1alpha import reflection_pb2, reflection_pb2_grpc

from chalk_remote_call._gen.chalk.runtime.v1 import remote_python_call_pb2 as pb2
from chalk_remote_call._gen.chalk.runtime.v1.remote_python_call_pb2_grpc import (
    RemoteCallServiceStub,
)
from chalk_remote_call.arrow_utils import decode_ipc_stream, encode_record_batch
from chalk_remote_call.server import serve


def _multiply_handler(event: dict[str, pa.Array], context: Any) -> pa.Array:
    keys = list(event.keys())
    return pc.multiply(event[keys[0]], event[keys[1]])


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


@pytest.fixture()
def server_with_health_and_reflection():
    """Start the Rust-backed server with health and reflection."""
    port = _find_free_port()

    thread = threading.Thread(
        target=serve,
        kwargs={
            "handler": _multiply_handler,
            "host": "[::1]",
            "port": port,
            "workers": 4,
        },
        daemon=True,
    )
    thread.start()

    channel = grpc.insecure_channel(f"localhost:{port}")

    # Wait for server to be ready
    deadline = time.monotonic() + 10.0
    health_stub = health_pb2_grpc.HealthStub(channel)
    while time.monotonic() < deadline:
        try:
            response = health_stub.Check(
                health_pb2.HealthCheckRequest(service=""),
                timeout=1.0,
            )
            if response.status == health_pb2.HealthCheckResponse.SERVING:
                break
        except grpc.RpcError:
            pass
        time.sleep(0.1)
    else:
        raise TimeoutError("Server did not become ready")

    try:
        yield thread, channel, port
    finally:
        channel.close()


def test_health_check(server_with_health_and_reflection):
    _, channel, _ = server_with_health_and_reflection
    health_stub = health_pb2_grpc.HealthStub(channel)
    response = health_stub.Check(health_pb2.HealthCheckRequest(service=""))
    assert response.status == health_pb2.HealthCheckResponse.SERVING


def test_reflection_lists_services(server_with_health_and_reflection):
    _, channel, _ = server_with_health_and_reflection
    reflection_stub = reflection_pb2_grpc.ServerReflectionStub(channel)

    def requests():
        yield reflection_pb2.ServerReflectionRequest(list_services="")

    responses = list(reflection_stub.ServerReflectionInfo(requests()))
    assert len(responses) == 1
    service_names = [s.name for s in responses[0].list_services_response.service]
    assert "chalk.runtime.v1.RemoteCallService" in service_names


def test_multiply_end_to_end(server_with_health_and_reflection):
    _, channel, _ = server_with_health_and_reflection
    stub = RemoteCallServiceStub(channel)

    batch = pa.record_batch(
        [pa.array([2, 3, 4], type=pa.int64()), pa.array([5, 6, 7], type=pa.int64())],
        names=["x", "y"],
    )
    request_bytes = encode_record_batch(batch)

    def requests():
        yield pb2.CallFunctionRequest(name="handler", feather_stream=request_bytes)

    responses = list(stub.CallFunction(requests()))
    assert len(responses) == 1
    result_batches = decode_ipc_stream(responses[0].feather_stream)
    result = result_batches[0]
    assert result.column(0).to_pylist() == [10, 18, 28]
