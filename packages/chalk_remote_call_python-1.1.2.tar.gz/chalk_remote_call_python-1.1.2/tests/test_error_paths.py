"""Tests for error handling paths through the Rust-backed gRPC server."""

from __future__ import annotations

from typing import Any

import grpc
import pyarrow as pa
import pytest

from chalk_remote_call._gen.chalk.runtime.v1 import remote_python_call_pb2 as pb2
from chalk_remote_call._gen.chalk.runtime.v1.remote_python_call_pb2_grpc import (
    RemoteCallServiceStub,
)
from chalk_remote_call.arrow_utils import encode_record_batch
from chalk_remote_call.servicer import _coerce_to_record_batch

# ---------------------------------------------------------------------------
# Handlers that exercise error paths
# ---------------------------------------------------------------------------


def _raising_handler(event: dict[str, pa.Array], context: Any) -> pa.Array:
    raise ValueError("something went wrong in the handler")


def _returns_none_handler(event: dict[str, pa.Array], context: Any) -> None:
    return None


def _returns_unsupported_type(event: dict[str, pa.Array], context: Any) -> object:
    return object()


# ---------------------------------------------------------------------------
# Unit tests: _coerce_to_record_batch edge cases
# ---------------------------------------------------------------------------


class TestCoerceEdgeCases:
    def test_none_coerces_to_null_scalar(self):
        """None is treated as a scalar and wrapped in a single-row batch."""
        result = _coerce_to_record_batch(None)
        assert result.num_columns == 1
        assert result.num_rows == 1
        assert result.column(0).to_pylist() == [None]

    def test_unsupported_object_raises(self):
        with pytest.raises(TypeError, match="Cannot convert handler result"):
            _coerce_to_record_batch(object())

    def test_empty_table(self):
        table = pa.table({"x": pa.array([], type=pa.int64())})
        result = _coerce_to_record_batch(table)
        assert isinstance(result, pa.RecordBatch)
        assert result.num_rows == 0
        assert result.schema == table.schema

    def test_chunked_array(self):
        chunked = pa.chunked_array([[1, 2], [3, 4]])
        result = _coerce_to_record_batch(chunked)
        assert result.num_columns == 1
        assert result.column(0).to_pylist() == [1, 2, 3, 4]

    def test_dict_with_pyarrow_arrays(self):
        result = _coerce_to_record_batch({"a": pa.array([1, 2]), "b": pa.array([3, 4])})
        assert result.num_columns == 2
        assert result.column(0).to_pylist() == [1, 2]


# ---------------------------------------------------------------------------
# Integration tests: handler exceptions propagate as gRPC errors
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "grpc_server_and_channel",
    [{"handler": _raising_handler, "arg_names": None}],
    indirect=True,
)
def test_handler_exception_returns_grpc_error(grpc_server_and_channel):
    _thread, channel, _address = grpc_server_and_channel
    stub = RemoteCallServiceStub(channel)

    batch = pa.record_batch([pa.array([1, 2])], names=["x"])
    request_bytes = encode_record_batch(batch)

    def requests():
        yield pb2.CallFunctionRequest(name="handler", feather_stream=request_bytes)

    with pytest.raises(grpc.RpcError) as exc_info:
        list(stub.CallFunction(requests()))

    details = exc_info.value.details().lower()
    assert "handler execution" in details or "something went wrong" in details


@pytest.mark.parametrize(
    "grpc_server_and_channel",
    [{"handler": _returns_unsupported_type, "arg_names": None}],
    indirect=True,
)
def test_handler_returns_unsupported_type_returns_grpc_error(grpc_server_and_channel):
    _thread, channel, _address = grpc_server_and_channel
    stub = RemoteCallServiceStub(channel)

    batch = pa.record_batch([pa.array([1])], names=["x"])
    request_bytes = encode_record_batch(batch)

    def requests():
        yield pb2.CallFunctionRequest(name="handler", feather_stream=request_bytes)

    with pytest.raises(grpc.RpcError) as exc_info:
        list(stub.CallFunction(requests()))

    details = exc_info.value.details().lower()
    assert "encode response" in details or "cannot convert" in details


# ---------------------------------------------------------------------------
# Integration test: invalid IPC bytes
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "grpc_server_and_channel",
    [{"handler": lambda e, c: e, "arg_names": None}],
    indirect=True,
)
def test_invalid_ipc_bytes_returns_grpc_error(grpc_server_and_channel):
    _thread, channel, _address = grpc_server_and_channel
    stub = RemoteCallServiceStub(channel)

    def requests():
        yield pb2.CallFunctionRequest(name="handler", feather_stream=b"not valid ipc data")

    with pytest.raises(grpc.RpcError) as exc_info:
        list(stub.CallFunction(requests()))

    assert exc_info.value.code() == grpc.StatusCode.INTERNAL
    assert "arrow ipc" in exc_info.value.details().lower()
