from __future__ import annotations

import pyarrow as pa

from chalk_remote_call.arrow_utils import decode_ipc_stream, encode_record_batch


def test_round_trip_single_batch():
    batch = pa.record_batch(
        [pa.array([1, 2, 3]), pa.array([4, 5, 6])],
        names=["x", "y"],
    )
    encoded = encode_record_batch(batch)
    decoded = decode_ipc_stream(encoded)
    assert len(decoded) == 1
    assert decoded[0].equals(batch)


def test_round_trip_string_columns():
    batch = pa.record_batch(
        [pa.array(["hello", "world"]), pa.array([1.0, 2.0])],
        names=["text", "score"],
    )
    encoded = encode_record_batch(batch)
    decoded = decode_ipc_stream(encoded)
    assert len(decoded) == 1
    assert decoded[0].equals(batch)


def test_empty_batch():
    schema = pa.schema([("x", pa.int64())])
    batch = pa.record_batch([pa.array([], type=pa.int64())], schema=schema)
    encoded = encode_record_batch(batch)
    decoded = decode_ipc_stream(encoded)
    assert len(decoded) == 1
    assert decoded[0].schema.equals(schema)
    assert decoded[0].num_rows == 0
