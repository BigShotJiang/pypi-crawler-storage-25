from __future__ import annotations

from typing import Any

import pyarrow as pa
import pytest

from chalk_remote_call._gen.chalk.runtime.v1 import remote_python_call_pb2 as pb2
from chalk_remote_call._gen.chalk.runtime.v1.remote_python_call_pb2_grpc import (
    RemoteCallServiceStub,
)
from chalk_remote_call.arrow_utils import decode_ipc_stream, encode_record_batch
from chalk_remote_call.servicer import _coerce_to_record_batch


class TestCoerceToRecordBatch:
    def test_record_batch_passthrough(self):
        batch = pa.record_batch([pa.array([1, 2])], names=["x"])
        assert _coerce_to_record_batch(batch) is batch

    def test_array_wraps_in_result_column(self):
        arr = pa.array([10, 20, 30])
        result = _coerce_to_record_batch(arr)
        assert result.num_columns == 1
        assert result.schema.field(0).name == "result"
        assert result.column(0).equals(arr)

    def test_list_converts_to_array(self):
        result = _coerce_to_record_batch([1, 2, 3])
        assert result.num_columns == 1
        assert result.column(0).to_pylist() == [1, 2, 3]

    def test_dict_converts_to_multi_column(self):
        result = _coerce_to_record_batch({"a": [1, 2], "b": [3, 4]})
        assert result.num_columns == 2
        assert result.schema.field(0).name == "a"
        assert result.schema.field(1).name == "b"
        assert result.column(0).to_pylist() == [1, 2]
        assert result.column(1).to_pylist() == [3, 4]

    def test_scalar_wraps(self):
        result = _coerce_to_record_batch(42)
        assert result.num_columns == 1
        assert result.column(0).to_pylist() == [42]

    def test_table_converts(self):
        table = pa.table({"x": [1, 2], "y": [3, 4]})
        result = _coerce_to_record_batch(table)
        assert isinstance(result, pa.RecordBatch)
        assert result.column(0).to_pylist() == [1, 2]


def _make_request_bytes(batch: pa.RecordBatch) -> bytes:
    return encode_record_batch(batch)


def _echo_handler(event: dict[str, pa.Array], context: Any) -> pa.RecordBatch:
    """Handler that returns the input as-is."""
    arrays = list(event.values())
    names = list(event.keys())
    return pa.record_batch(arrays, names=names)


def _add_handler(event: dict[str, pa.Array], context: Any) -> pa.Array:
    """Handler that adds two columns."""
    import pyarrow.compute as pc

    keys = list(event.keys())
    return pc.add(event[keys[0]], event[keys[1]])


@pytest.mark.parametrize(
    "grpc_server_and_channel",
    [{"handler": _echo_handler, "arg_names": None}],
    indirect=True,
)
def test_echo_handler_round_trip(grpc_server_and_channel):
    _thread, channel, address = grpc_server_and_channel
    stub = RemoteCallServiceStub(channel)

    batch = pa.record_batch(
        [pa.array([1, 2, 3]), pa.array([4, 5, 6])],
        names=["x", "y"],
    )
    request_bytes = _make_request_bytes(batch)

    def requests():
        yield pb2.CallFunctionRequest(name="handler", feather_stream=request_bytes)

    responses = list(stub.CallFunction(requests()))
    assert len(responses) == 1
    result_batches = decode_ipc_stream(responses[0].feather_stream)
    assert len(result_batches) == 1
    result = result_batches[0]
    assert result.column(0).to_pylist() == [1, 2, 3]
    assert result.column(1).to_pylist() == [4, 5, 6]


@pytest.mark.parametrize(
    "grpc_server_and_channel",
    [{"handler": _add_handler, "arg_names": ["a", "b"]}],
    indirect=True,
)
def test_add_handler_with_renamed_args(grpc_server_and_channel):
    _thread, channel, address = grpc_server_and_channel
    stub = RemoteCallServiceStub(channel)

    batch = pa.record_batch(
        [pa.array([10, 20], type=pa.int64()), pa.array([3, 7], type=pa.int64())],
        names=["col_x", "col_y"],
    )
    request_bytes = _make_request_bytes(batch)

    def requests():
        yield pb2.CallFunctionRequest(name="handler", feather_stream=request_bytes)

    responses = list(stub.CallFunction(requests()))
    assert len(responses) == 1
    result_batches = decode_ipc_stream(responses[0].feather_stream)
    result = result_batches[0]
    assert result.column(0).to_pylist() == [13, 27]
