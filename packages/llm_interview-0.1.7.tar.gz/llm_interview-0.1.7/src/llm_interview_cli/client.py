import json
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen


class ApiError(RuntimeError):
    def __init__(self, status: int, message: str):
        self.status = status
        super().__init__(message)


class ApiClient:
    def __init__(self, server_url: str, token: str | None = None):
        self.server_url = _validated_http_url(server_url)
        self.token = token or ""

    def post_json(self, path: str, payload: dict) -> dict:
        return self._request("POST", path, payload)

    def get_json(self, path: str) -> dict:
        return self._request("GET", path, None)

    def _request(self, method: str, path: str, payload: dict | None) -> dict:
        data = None
        headers = {
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"

        url = urljoin(self.server_url, path.lstrip("/"))
        if urlparse(url).scheme not in {"http", "https"}:
            raise ApiError(0, "Server URL must use HTTP or HTTPS.")
        request = Request(url, data=data, headers=headers, method=method)
        try:
            # nosemgrep: python.lang.security.audit.dynamic-urllib-use-detected.dynamic-urllib-use-detected
            with urlopen(request, timeout=20) as response:  # nosec B310
                body = response.read().decode("utf-8")
        except HTTPError as exc:
            body = exc.read().decode("utf-8")
            try:
                message = json.loads(body).get("error", body)
            except json.JSONDecodeError:
                message = body or exc.reason
            raise ApiError(exc.code, message) from exc
        except URLError as exc:
            raise ApiError(0, f"Could not reach server: {exc.reason}") from exc

        return json.loads(body) if body else {}


def _validated_http_url(server_url: str) -> str:
    parsed = urlparse(server_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("Server URL must use HTTP or HTTPS.")
    return server_url.rstrip("/") + "/"
