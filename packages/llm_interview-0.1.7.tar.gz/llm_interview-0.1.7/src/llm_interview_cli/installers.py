import json
import os
from hashlib import sha256
from pathlib import Path


SUPPORTED_TARGETS = ["claude-code", "codex", "cursor", "vscode"]
SKILL_NAME = "llm-interview-history"
MANIFEST_VERSION = 2
VSCODE_TASK_LABELS = {"llm-interview info", "llm-interview submit"}
TARGET_ALIASES = {
    "claude": "claude-code",
    "claude-code": "claude-code",
    "codex": "codex",
    "cursor": "cursor",
    "code": "vscode",
    "vscode": "vscode",
}


def normalize_targets(target: str) -> list[str]:
    if target == "all":
        return SUPPORTED_TARGETS.copy()
    try:
        return [TARGET_ALIASES[target]]
    except KeyError as exc:
        raise ValueError(f"Unsupported install target: {target}") from exc


def install_targets(home: Path, target: str) -> dict:
    targets = normalize_targets(target)
    integrations = home / "integrations"
    workspace = Path.cwd()
    user_home = Path.home()
    files: list[dict] = _existing_manifest_entries(integrations, reinstalling=targets)

    for canonical in targets:
        if canonical == "claude-code":
            files.extend(_install_claude_code(user_home))
        elif canonical == "codex":
            files.extend(_install_codex(user_home))
        elif canonical == "cursor":
            files.extend(_install_cursor(workspace))
        elif canonical == "vscode":
            files.extend(_install_vscode(workspace))

    manifest_targets = [
        supported
        for supported in SUPPORTED_TARGETS
        if supported in {entry.get("target") for entry in files}
    ]
    manifest = {"version": MANIFEST_VERSION, "targets": manifest_targets, "files": files}
    integrations.mkdir(parents=True, exist_ok=True)
    (integrations / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True))
    return manifest


def _existing_manifest_entries(integrations: Path, reinstalling: list[str]) -> list[dict]:
    manifest_path = integrations / "manifest.json"
    if not manifest_path.exists():
        return []
    try:
        manifest = json.loads(manifest_path.read_text())
    except json.JSONDecodeError:
        return []
    entries = manifest.get("files", [])
    return [
        entry
        for entry in entries
        if (
            isinstance(entry, dict)
            and entry.get("target") in SUPPORTED_TARGETS
            and entry.get("target") not in reinstalling
        )
    ]


def _write_owned_file(target: str, path: Path, content: str) -> dict:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    os.chmod(path, 0o644)
    return {
        "kind": "owned_file",
        "target": target,
        "path": str(path),
        "sha256": _sha256_text(content),
    }


def _sha256_text(content: str) -> str:
    return sha256(content.encode()).hexdigest()


def _install_claude_code(user_home: Path) -> list[dict]:
    return [
        _write_owned_file(
            "claude-code",
            user_home / ".claude" / "skills" / SKILL_NAME / "SKILL.md",
            _skill_content("Claude Code"),
        )
    ]


def _install_codex(user_home: Path) -> list[dict]:
    return [
        _write_owned_file(
            "codex",
            user_home / ".codex" / "skills" / SKILL_NAME / "SKILL.md",
            _skill_content("Codex"),
        ),
        _write_owned_file(
            "codex",
            user_home / ".agents" / "skills" / SKILL_NAME / "SKILL.md",
            _skill_content("Codex"),
        ),
    ]


def _install_cursor(workspace: Path) -> list[dict]:
    return [
        _write_owned_file(
            "cursor",
            workspace / ".cursor" / "rules" / "llm-interview.mdc",
            """---
description: LLM interview history capture
alwaysApply: true
---
<!-- managed-by: llm-interview -->

Use the `llm-interview` CLI during interview work.

- Before interview work starts, run `llm-interview start <interview-code> --llm cursor` if no active session is visible.
- Preserve provider thread IDs when Cursor exposes them.
- Append important user and assistant messages to the active `history.jsonl` path as JSONL objects with `timestamp`, `role`, `content`, and `provider_thread_id` fields.
- When the interview thread is complete, run `llm-interview submit`.
""",
        )
    ]


def _install_vscode(workspace: Path) -> list[dict]:
    path = workspace / ".vscode" / "tasks.json"
    created_file = not path.exists()
    data = _read_vscode_tasks(path)
    tasks = [
        task
        for task in data.get("tasks", [])
        if task.get("label") not in VSCODE_TASK_LABELS
    ]
    data["version"] = data.get("version", "2.0.0")
    data["tasks"] = tasks + _vscode_tasks()
    content = json.dumps(data, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return [
        {
            "kind": "vscode_tasks",
            "target": "vscode",
            "path": str(path),
            "labels": sorted(VSCODE_TASK_LABELS),
            "created_file": created_file,
        }
    ]


def _read_vscode_tasks(path: Path) -> dict:
    if not path.exists():
        return {"version": "2.0.0", "tasks": []}
    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise ValueError(f"Cannot update invalid VS Code tasks JSON: {path}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"VS Code tasks JSON must be an object: {path}")
    tasks = data.setdefault("tasks", [])
    if not isinstance(tasks, list):
        raise ValueError(f"VS Code tasks JSON must contain a tasks list: {path}")
    return data


def _vscode_tasks() -> list[dict]:
    return [
        {
            "label": "llm-interview info",
            "type": "shell",
            "command": "llm-interview info",
            "problemMatcher": [],
        },
        {
            "label": "llm-interview submit",
            "type": "shell",
            "command": "llm-interview submit",
            "problemMatcher": [],
        },
    ]


def _skill_content(provider: str) -> str:
    return f"""---
name: llm-interview-history
description: Use when participating in an interview that requires recording and submitting LLM conversation history.
---
<!-- managed-by: llm-interview -->

# LLM Interview History

This {provider} environment is configured for an interview that needs LLM history capture.

Use the `llm-interview` CLI during interview work:

1. Before interview work starts, run `llm-interview start <interview-code> --llm {provider.lower().replace(" ", "-")}` if no active session is visible.
2. Keep track of the `History:` path printed by the start command.
3. Append important user and assistant messages to that `history.jsonl` file as JSONL objects with `timestamp`, `role`, `content`, and `provider_thread_id` fields.
4. Preserve provider thread IDs when this tool exposes them.
5. When the interview thread is complete, run `llm-interview submit`.

Do not include secrets or unrelated local files in the interview history.
"""
