from llm_interview_cli.cli import main


raise SystemExit(main())

