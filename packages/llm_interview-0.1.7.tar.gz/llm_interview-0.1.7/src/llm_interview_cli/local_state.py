import json
import os
import shutil
from hashlib import sha256
from pathlib import Path


MARKER_FILENAME = ".llm-interview-home"


def home_dir() -> Path:
    return Path(os.environ.get("LLM_INTERVIEW_HOME", Path.home() / ".llm-interview-history"))


def config_path(home: Path | None = None) -> Path:
    return (home or home_dir()) / "config.json"


def load_config(home: Path | None = None) -> dict:
    path = config_path(home)
    if not path.exists():
        raise FileNotFoundError("Run llm-interview install before using this command.")
    return json.loads(path.read_text())


def save_config(config: dict, home: Path | None = None) -> None:
    root = home or home_dir()
    root.mkdir(parents=True, exist_ok=True)
    os.chmod(root, 0o700)
    marker_path(root).write_text("llm-interview-history\n")
    os.chmod(marker_path(root), 0o600)
    path = config_path(root)
    path.write_text(json.dumps(config, indent=2, sort_keys=True))
    os.chmod(path, 0o600)


def marker_path(home: Path | None = None) -> Path:
    return (home or home_dir()) / MARKER_FILENAME


def session_dir(client_session_id: str, home: Path | None = None) -> Path:
    return (home or home_dir()) / "sessions" / client_session_id


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True))
    os.chmod(path, 0o600)


def touch_private(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    path.touch(exist_ok=True)
    os.chmod(path, 0o600)


def remove_integrations(home: Path | None = None) -> None:
    root = home or home_dir()
    integrations = root / "integrations"
    manifest_path = integrations / "manifest.json"
    if manifest_path.exists():
        _remove_manifest_entries(root, manifest_path)
    if integrations.exists():
        shutil.rmtree(integrations)


def _remove_manifest_entries(root: Path, manifest_path: Path) -> None:
    try:
        manifest = json.loads(manifest_path.read_text())
    except json.JSONDecodeError:
        return
    for entry in manifest.get("files", []):
        if isinstance(entry, str):
            _remove_old_private_file(root, entry)
            continue
        if not isinstance(entry, dict):
            continue
        kind = entry.get("kind")
        if kind == "owned_file":
            _remove_owned_file(entry)
        elif kind == "vscode_tasks":
            _remove_vscode_tasks(entry)


def _remove_old_private_file(root: Path, relative_path: str) -> None:
    path = root / relative_path
    try:
        resolved = path.resolve()
        resolved.relative_to(root.resolve())
    except ValueError:
        return
    if resolved.exists() and resolved.is_file():
        resolved.unlink()


def _remove_owned_file(entry: dict) -> None:
    path = Path(str(entry.get("path", ""))).expanduser()
    expected_hash = entry.get("sha256")
    if not path.exists() or not path.is_file() or not expected_hash:
        return
    content = path.read_bytes()
    if sha256(content).hexdigest() != expected_hash:
        return
    path.unlink()
    _prune_empty_parents(path.parent)


def _remove_vscode_tasks(entry: dict) -> None:
    path = Path(str(entry.get("path", ""))).expanduser()
    labels = set(entry.get("labels", []))
    if not path.exists() or not path.is_file() or not labels:
        return
    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError:
        return
    tasks = data.get("tasks", [])
    if not isinstance(tasks, list):
        return
    remaining_tasks = [task for task in tasks if task.get("label") not in labels]
    if not remaining_tasks and entry.get("created_file"):
        path.unlink()
        _prune_empty_parents(path.parent)
        return
    data["tasks"] = remaining_tasks
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def _prune_empty_parents(path: Path) -> None:
    if path == Path.home() or path == Path("/") or not path.exists():
        return
    try:
        path.rmdir()
    except OSError:
        return


def purge(home: Path | None = None) -> None:
    root = home or home_dir()
    resolved = root.resolve()
    forbidden = {Path("/").resolve(), Path.home().resolve(), Path.cwd().resolve()}
    if resolved in forbidden or not marker_path(root).exists():
        raise ValueError(f"Refusing to purge unmarked llm-interview directory: {root}")
    if root.exists():
        shutil.rmtree(root)
