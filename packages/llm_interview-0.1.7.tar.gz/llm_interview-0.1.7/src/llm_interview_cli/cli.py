import argparse
import os
import sys
import uuid
from urllib.parse import urlparse

from llm_interview_cli import __version__
from llm_interview_cli.client import ApiClient, ApiError
from llm_interview_cli.installers import install_targets
from llm_interview_cli.local_state import (
    home_dir,
    load_config,
    purge,
    remove_integrations,
    save_config,
    session_dir,
    touch_private,
    write_json,
)


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code)

    try:
        return args.func(args)
    except (ApiError, FileNotFoundError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="llm-interview")
    subparsers = parser.add_subparsers(dest="command", required=True)

    install = subparsers.add_parser("install")
    install.add_argument("--server", required=True)
    install.add_argument("--token")
    install.add_argument("--email")
    install.add_argument("--name", default="")
    install.add_argument("--interview-code")
    install.add_argument("--target", default="all")
    install.set_defaults(func=_install)

    start = subparsers.add_parser("start")
    start.add_argument("interview_code")
    start.add_argument("--llm", default="")
    start.add_argument("--thread-id", default="")
    start.set_defaults(func=_start)

    submit = subparsers.add_parser("submit")
    submit.add_argument("--raw", action="store_true")
    submit.set_defaults(func=_submit)

    info = subparsers.add_parser("info")
    info.set_defaults(func=_info)

    uninstall = subparsers.add_parser("uninstall")
    uninstall.add_argument("--purge", action="store_true")
    uninstall.set_defaults(func=_uninstall)

    return parser


def _install(args) -> int:
    root = home_dir()
    _validate_server_url(args.server)
    token = args.token or os.environ.get("LLM_INTERVIEW_TOKEN")
    candidate_email = ""
    registered_interview_code = ""
    if not token:
        if not args.email or not args.interview_code:
            raise ValueError(
                "Provide --token/LLM_INTERVIEW_TOKEN or register with --email and --interview-code."
            )
        client = ApiClient(args.server, "")
        response = client.post_json(
            "/api/candidates/register/",
            {
                "email": args.email,
                "name": args.name,
                "interview_code": args.interview_code,
            },
        )
        token = response["token"]
        candidate_email = response.get("candidate", {}).get("email", args.email)
        registered_interview_code = response.get("interview", {}).get("code", args.interview_code)
        print(f"Registered {candidate_email} for {registered_interview_code}.")
    config = {
        "server_url": args.server.rstrip("/"),
        "token": token,
        "active_session_id": None,
    }
    if candidate_email:
        config["candidate_email"] = candidate_email
    if registered_interview_code:
        config["registered_interview_code"] = registered_interview_code
    save_config(config, root)
    manifest = install_targets(root, args.target)
    print(f"Installed llm-interview for: {', '.join(manifest['targets'])}")
    return 0


def _validate_server_url(server_url: str) -> None:
    parsed = urlparse(server_url)
    if parsed.scheme == "https":
        return
    if parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "::1"}:
        return
    raise ValueError("Server URL must use HTTPS except for localhost development.")


def _start(args) -> int:
    root = home_dir()
    config = load_config(root)
    client_session_id = str(uuid.uuid4())
    payload = {
        "interview_code": args.interview_code,
        "client_session_id": client_session_id,
        "provider_thread_id": args.thread_id,
        "llm_name": args.llm,
        "metadata": {"cli_version": __version__},
    }
    client = ApiClient(config["server_url"], config["token"])
    response = client.post_json("/api/sessions/start/", payload)
    returned_session_id = response["session"]["client_session_id"]
    session_path = session_dir(returned_session_id, root)
    touch_private(session_path / "history.jsonl")
    write_json(
        session_path / "metadata.json",
        {
            "interview_code": args.interview_code,
            "client_session_id": returned_session_id,
            "provider_thread_id": response["session"].get("provider_thread_id", ""),
            "llm_name": args.llm,
        },
    )
    config["active_session_id"] = returned_session_id
    save_config(config, root)

    interview = response["interview"]
    print(f"Started {interview['code']} as {returned_session_id}")
    if interview.get("time_limit_minutes"):
        print(f"Time limit: {interview['time_limit_minutes']} minutes")
    print(interview["directions"])
    print(f"History: {session_path / 'history.jsonl'}")
    return 0


def _submit(args) -> int:
    root = home_dir()
    config = load_config(root)
    active_session_id = config.get("active_session_id")
    if not active_session_id:
        raise ValueError("No active session. Run llm-interview start <interview-code> first.")

    session_path = session_dir(active_session_id, root)
    history_path = session_path / "history.jsonl"
    if not history_path.exists():
        raise FileNotFoundError(f"Missing history file: {history_path}")

    content = history_path.read_text()
    content_type = "raw" if args.raw else "jsonl"
    client = ApiClient(config["server_url"], config["token"])
    response = client.post_json(
        f"/api/sessions/{active_session_id}/submit/",
        {"content": content, "content_type": content_type},
    )
    write_json(session_path / "receipt.json", response)
    config["active_session_id"] = None
    save_config(config, root)
    print(f"Submitted {active_session_id}: {response['submission']['content_sha256']}")
    return 0


def _info(args) -> int:
    config = load_config(home_dir())
    client = ApiClient(config["server_url"], config["token"])
    response = client.get_json("/api/sessions/")
    active = config.get("active_session_id")
    if active:
        print(f"Active local session: {active}")
    for session in response.get("sessions", []):
        thread = session.get("provider_thread_id") or session.get("conversation_group_key") or ""
        print(f"{session['client_session_id']} {session['interview_code']} {session['status']} {thread}".strip())
    return 0


def _uninstall(args) -> int:
    root = home_dir()
    if args.purge:
        remove_integrations(root)
        purge(root)
        print("Removed llm-interview local state.")
        return 0
    remove_integrations(root)
    print("Removed llm-interview integrations.")
    return 0
