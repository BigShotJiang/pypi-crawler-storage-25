# llm-interview

Candidate CLI for submitting LLM interview history.

## Install

```bash
pipx install llm-interview
```

## Use

Your interviewer will provide a server URL and interview code. Run install from the workspace where you will do the interview:

```bash
llm-interview install --server https://interviews.example.com --email you@example.com --name "Your Name" --interview-code ENG-1 --target all
llm-interview start ENG-1 --llm codex --thread-id optional-provider-thread-id
llm-interview submit
llm-interview info
llm-interview uninstall
```

The installer writes Claude Code skills, Codex skills in `~/.codex/skills` and `~/.agents/skills`, Cursor rules, and VS Code tasks. The package contains only the candidate CLI and local integration installers. It does not include the Django server application.
