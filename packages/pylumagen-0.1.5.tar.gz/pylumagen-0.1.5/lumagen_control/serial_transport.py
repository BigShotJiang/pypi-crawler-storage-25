"""Serial transport for local Lumagen RS232 connections."""

# Copyright (c) 2026 John Carey
# SPDX-License-Identifier: MIT

# pylint: disable=duplicate-code

from __future__ import annotations

import asyncio

import serial_asyncio_fast as serial_asyncio

from .transport import LumagenTransport


class SerialTransport(LumagenTransport):
    """Serial byte transport."""

    def __init__(
        self,
        device: str,
        baudrate: int = 9600,
        timeout: float = 2.0,
    ) -> None:
        self._device = device
        self._baudrate = baudrate
        self._timeout = timeout
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None

    @property
    def is_connected(self) -> bool:
        """Return true if the transport has an open reader and writer."""
        return self._reader is not None and self._writer is not None

    async def connect(self) -> None:
        """Open the serial device."""
        if self._reader is not None and self._writer is not None:
            return

        self._reader, self._writer = await serial_asyncio.open_serial_connection(
            url=self._device,
            baudrate=self._baudrate,
            bytesize=8,
            parity="N",
            stopbits=1,
        )

    async def disconnect(self) -> None:
        """Close the serial device."""
        if self._writer is not None:
            self._writer.close()

        self._reader = None
        self._writer = None

    async def write(self, data: bytes) -> None:
        """Write raw bytes."""
        await self.connect()

        if self._writer is None:
            raise RuntimeError("Serial transport is not connected")

        self._writer.write(data)
        await self._writer.drain()

    async def read(self, max_bytes: int = 1024) -> bytes:
        """Read raw bytes."""
        await self.connect()

        if self._reader is None:
            raise RuntimeError("Serial transport is not connected")

        return await asyncio.wait_for(
            self._reader.read(max_bytes),
            timeout=self._timeout,
        )

    async def read_until(self, separator: bytes) -> bytes:
        """Read until separator is received."""
        await self.connect()

        if self._reader is None:
            raise RuntimeError("Serial transport is not connected")

        return await asyncio.wait_for(
            self._reader.readuntil(separator),
            timeout=self._timeout,
        )
