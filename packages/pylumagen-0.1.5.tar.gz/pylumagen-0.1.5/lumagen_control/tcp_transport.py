"""TCP transport for Lumagen serial-over-IP connections."""

# Copyright (c) 2026 John Carey
# SPDX-License-Identifier: MIT

# pylint: disable=duplicate-code

from __future__ import annotations

import asyncio

from .transport import LumagenTransport


class TcpTransport(LumagenTransport):
    """TCP byte transport."""

    def __init__(self, host: str, port: int = 23, timeout: float = 2.0) -> None:
        self._host = host
        self._port = port
        self._timeout = timeout
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None

    @property
    def is_connected(self) -> bool:
        """Return true if the transport has an open reader and writer."""
        return self._reader is not None and self._writer is not None

    async def connect(self) -> None:
        """Connect to the TCP endpoint."""
        if self._reader is not None and self._writer is not None:
            return

        self._reader, self._writer = await asyncio.wait_for(
            asyncio.open_connection(self._host, self._port),
            timeout=self._timeout,
        )

    async def disconnect(self) -> None:
        """Disconnect from the TCP endpoint."""
        if self._writer is not None:
            self._writer.close()
            await self._writer.wait_closed()

        self._reader = None
        self._writer = None

    async def write(self, data: bytes) -> None:
        """Write raw bytes."""
        await self.connect()

        if self._writer is None:
            raise RuntimeError("TCP transport is not connected")

        self._writer.write(data)
        await self._writer.drain()

    async def read(self, max_bytes: int = 1024) -> bytes:
        """Read raw bytes."""
        await self.connect()

        if self._reader is None:
            raise RuntimeError("TCP transport is not connected")

        return await asyncio.wait_for(
            self._reader.read(max_bytes),
            timeout=self._timeout,
        )

    async def read_until(self, separator: bytes) -> bytes:
        """Read until separator is received."""
        await self.connect()

        if self._reader is None:
            raise RuntimeError("TCP transport is not connected")

        return await asyncio.wait_for(
            self._reader.readuntil(separator),
            timeout=self._timeout,
        )
