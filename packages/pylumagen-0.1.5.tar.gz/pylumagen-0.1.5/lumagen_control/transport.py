"""Transport abstraction for Lumagen RS232 byte I/O."""

# Copyright (c) 2026 John Carey
# SPDX-License-Identifier: MIT

from __future__ import annotations

from abc import ABC, abstractmethod


class LumagenTransport(ABC):
    """Abstract byte transport for Lumagen RS232 protocol."""

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Return true if the transport is connected."""

    @abstractmethod
    async def connect(self) -> None:
        """Connect the transport."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Disconnect the transport."""

    @abstractmethod
    async def write(self, data: bytes) -> None:
        """Write raw bytes."""

    @abstractmethod
    async def read(self, max_bytes: int = 1024) -> bytes:
        """Read raw bytes."""

    @abstractmethod
    async def read_until(self, separator: bytes) -> bytes:
        """Read until separator is received."""
