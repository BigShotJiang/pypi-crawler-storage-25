"""Lumagen value formatting helpers."""

# Copyright (c) 2026 John Carey
# SPDX-License-Identifier: MIT

from __future__ import annotations


def strip_leading_zeroes(value: str) -> str:
    """Strip leading zeroes while preserving a single zero."""
    return value.lstrip("0") or "0"


# --------------------------------------------------------------------
# Input / source status
# --------------------------------------------------------------------


def format_input_status(value: str) -> str:
    """Convert Lumagen input status code to a display value."""
    match value:
        case "0":
            return "No Source"
        case "1":
            return "Active Video"
        case "2":
            return "Internal Pattern"
        case _:
            return value


def format_dynamic_range(value: str) -> str:
    """Convert Lumagen source dynamic range code to a display value."""
    match value:
        case "0":
            return "SDR"
        case "1":
            return "HDR"
        case _:
            return value


def format_scan_mode(value: str) -> str | None:
    """Convert Lumagen scan mode field to a display value."""
    match value:
        case "i" | "I":
            return "Interlaced"
        case "p" | "P":
            return "Progressive"
        case "-" | "n" | "N" | "":
            return None
        case _:
            return value


def format_3d_mode(value: str) -> str | None:
    """Convert Lumagen 3D mode code to a display value."""
    match value:
        case "0":
            return "2D"
        case "1" | "2" | "4" | "8":
            return "3D"
        case "-" | "":
            return None
        case _:
            return value


# --------------------------------------------------------------------
# Rates / resolution
# --------------------------------------------------------------------


def format_scaled_rate(value: str) -> str:
    """Convert Lumagen scaled rate, e.g. 5994, to display Hz."""
    try:
        rate = int(value) / 100
    except ValueError:
        return value

    if rate.is_integer():
        return str(int(rate))

    return f"{rate:.2f}".rstrip("0").rstrip(".")


def format_vertical_rate(value: str) -> str:
    """Convert Lumagen vertical rate code to display rate."""
    rate_labels = {
        "000": "0",
        "023": "23.98",
        "024": "24",
        "025": "25",
        "029": "29.97",
        "030": "30",
        "050": "50",
        "059": "59.94",
        "060": "60",
    }

    return rate_labels.get(value, value.lstrip("0") or "0")


def format_raster_resolution(vertical: str, aspect: str, mode: str) -> str:
    """Convert vertical resolution and raster aspect to display resolution."""
    if vertical in {"0000", "000"} or mode in {"-", "n", "N"}:
        return "No Input"

    scan_mode = "i" if mode in {"I", "i"} else "p"

    try:
        height = int(vertical)
    except ValueError:
        return vertical.lstrip("0") or "0"

    try:
        aspect_value = int(aspect) / 100
    except ValueError:
        return f"{height}{scan_mode}"

    if aspect_value <= 0:
        return "No Input"

    width = round(height * aspect_value)
    common_widths = (640, 720, 1280, 1920, 3840, 4096)
    width = min(common_widths, key=lambda item: abs(item - width))

    return f"{width}x{height}{scan_mode}"


# --------------------------------------------------------------------
# Aspect / image processing status
# --------------------------------------------------------------------


def format_nls_active(value: str) -> str:
    """Convert Lumagen NLS active field to a display value."""
    match value:
        case "N":
            return "On"
        case "-":
            return "Off"
        case _:
            return value


def format_subtitle_shift_status(value: str) -> str:
    """Convert Lumagen subtitle shift status code to a display value."""
    match value:
        case "0":
            return "Off"
        case "1":
            return "3%"
        case "2":
            return "6%"
        case _:
            return value


def format_auto_aspect_status(value: str) -> str:
    """Convert Lumagen auto aspect status code to a display value."""
    match value:
        case "0":
            return "Off"
        case "1":
            return "Disabled"
        case "2":
            return "On"
        case _:
            return value


# --------------------------------------------------------------------
# Output configuration
# --------------------------------------------------------------------


def format_output_colorspace(value: str) -> str:
    """Convert Lumagen output colorspace code to a display value."""
    match value:
        case "0":
            return "SDR601"
        case "1":
            return "SDR709"
        case "2":
            return "SDR2020"
        case "3":
            return "HDR2020"
        case _:
            return value


def format_output_enabled_mask(value: str) -> str | None:
    """Convert Lumagen output enabled bitmask to a display value."""
    if not value:
        return None

    try:
        mask = int(value, 16)
    except ValueError:
        return value

    outputs = [f"HDMI {index + 1}" for index in range(16) if mask & (1 << index)]

    if not outputs:
        return "None"

    return ", ".join(outputs)


def format_active_output_cms(value: str) -> str | None:
    """Convert Lumagen active output CMS code to a display value."""
    if not value:
        return None

    return f"CMS{value}"


def format_active_output_style(value: str) -> str | None:
    """Convert Lumagen active output style code to a display value."""
    if not value:
        return None

    return f"Style{value}"


# --------------------------------------------------------------------
# OSD formatting
# --------------------------------------------------------------------


def format_osd_message(message: str) -> str:
    """Format an OSD message as two 30-character lines without splitting words."""
    clean_message = "".join(char for char in message if 0x20 <= ord(char) <= 0x7A)
    words = clean_message.split()

    lines: list[str] = []
    current_line = ""

    for word in words:
        if len(word) > 30:
            if current_line:
                lines.append(current_line)
                current_line = ""

            lines.append(word[:30])
            continue

        candidate = word if not current_line else f"{current_line} {word}"

        if len(candidate) <= 30:
            current_line = candidate
            continue

        lines.append(current_line)
        current_line = word

        if len(lines) == 2:
            break

    if current_line and len(lines) < 2:
        lines.append(current_line)

    if not lines:
        return ""

    first_line = lines[0][:30]
    second_line = lines[1][:30] if len(lines) > 1 else ""

    return f"{first_line:<30}{second_line}"
