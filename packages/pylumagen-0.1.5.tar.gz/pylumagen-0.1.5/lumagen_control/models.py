"""Typed Lumagen response models."""

# Copyright (c) 2026 John Carey
# SPDX-License-Identifier: MIT

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LumagenId:
    """Lumagen identity information."""

    model: str
    software: str
    model_number: str
    serial_number: str


@dataclass(frozen=True)
class LumagenInput:
    """Lumagen selected input information."""

    input_number: int
    memory: str
    physical_input: int


# pylint: disable=too-many-public-methods
@dataclass(frozen=True)
class LumagenFullStatus:
    """Parsed Lumagen full input/status response from ZQI21-ZQI25."""

    raw: str
    response_type: str
    parts: tuple[str, ...]

    @classmethod
    def from_response(cls, response: str) -> LumagenFullStatus | None:
        """Parse a Lumagen ZQI21-ZQI25 full status response."""
        parts = tuple(response.split(","))

        if not parts or parts[0] not in {"!I21", "!I22", "!I23", "!I24", "!I25"}:
            return None

        return cls(
            raw=response,
            response_type=parts[0],
            parts=parts,
        )

    def field(self, index: int, default: str = "") -> str:
        """Return a response field by index, or default if it is missing."""
        if len(self.parts) > index:
            return self.parts[index]

        return default

    @property
    def input_status_code(self) -> str:
        """Return input status code.

        Values are usually:
        0 = no source
        1 = active video
        2 = internal pattern
        """
        return self.field(1)

    @property
    def input_rate_code(self) -> str:
        """Return source vertical rate code.

        Example values include 059 for 59.94 Hz and 060 for 60.00 Hz.
        """
        return self.field(2)

    @property
    def input_vertical_resolution(self) -> str:
        """Return source vertical resolution code."""
        return self.field(3)

    @property
    def source_3d_mode(self) -> str:
        """Return source 3D mode code."""
        return self.field(4)

    @property
    def active_input_config(self) -> str:
        """Return active input config number for current input resolution."""
        return self.field(5)

    @property
    def input_raster_aspect(self) -> str:
        """Return source raster aspect code.

        Example values include 178 for 1.78 and 240 for 2.40.
        """
        return self.field(6)

    @property
    def current_source_content_aspect(self) -> str:
        """Return current source content aspect code.

        Example values include 178 for 1.78 and 240 for 2.40.
        """
        return self.field(7)

    @property
    def nls_active(self) -> str:
        """Return NLS status field."""
        return self.field(8)

    @property
    def output_3d_mode(self) -> str:
        """Return output 3D mode code."""
        return self.field(9)

    @property
    def output_enabled_mask(self) -> str:
        """Return output enabled bitmask/code."""
        return self.field(10)

    @property
    def active_output_cms(self) -> str:
        """Return active output CMS code."""
        return self.field(11)

    @property
    def active_output_style(self) -> str:
        """Return active output style code."""
        return self.field(12)

    @property
    def output_rate_code(self) -> str:
        """Return output vertical rate code."""
        return self.field(13)

    @property
    def output_vertical_resolution(self) -> str:
        """Return output vertical resolution code."""
        return self.field(14)

    @property
    def output_raster_aspect(self) -> str:
        """Return output raster aspect code."""
        return self.field(15)

    @property
    def output_colorspace_code(self) -> str:
        """Return output colorspace code."""
        return self.field(16)

    @property
    def input_dynamic_range_code(self) -> str:
        """Return input dynamic range code."""
        return self.field(17)

    @property
    def input_mode(self) -> str:
        """Return input scan/mode field.

        Common values are p/P for progressive, i/I for interlaced, and
        -/n/N for no input or unavailable input mode.
        """
        return self.field(18)

    @property
    def output_mode(self) -> str:
        """Return output scan/mode field.

        Common values are p/P for progressive and i/I for interlaced.
        """
        return self.field(19)

    @property
    def virtual_input_selected(self) -> str:
        """Return selected virtual input code."""
        return self.field(20)

    @property
    def physical_input_selected(self) -> str:
        """Return selected physical input code."""
        return self.field(21)

    @property
    def detected_source_raster_aspect(self) -> str:
        """Return detected source raster aspect code.

        Example values include 178 for 1.78 and 240 for 2.40.
        """
        return self.field(22)

    @property
    def detected_source_aspect(self) -> str:
        """Return detected source content aspect code.

        Example values include 178 for 1.78 and 240 for 2.40.
        """
        return self.field(23)

    @property
    def input_memory(self) -> str:
        """Return active input memory letter.

        Known values are usually A, B, C, or D.
        """
        return self.field(24)

    @property
    def subtitle_shift_status(self) -> str:
        """Return subtitle shift status code.

        Known values:
        0 = off
        1 = 3%
        2 = 6%
        """
        return self.field(26)

    @property
    def auto_aspect_status(self) -> str:
        """Return auto aspect status code.

        Known values:
        0 = off
        1 = disabled
        2 = on
        """
        return self.field(27)


@dataclass(frozen=True)
class LumagenPowerStatus:
    """Parsed Lumagen power status response from ZQS02 / !S02."""

    raw: str
    power_on: bool

    @classmethod
    def from_response(cls, response: str) -> LumagenPowerStatus | None:
        """Parse a Lumagen power status response."""
        parts = response.split(",")

        if len(parts) != 2 or parts[0] != "!S02":
            return None

        match parts[1]:
            case "0":
                power_on = False
            case "1":
                power_on = True
            case _:
                return None

        return cls(
            raw=response,
            power_on=power_on,
        )


@dataclass(frozen=True)
class LumagenOutputInfo:
    """Parsed Lumagen output info response from ZQO01 / !O01."""

    raw: str
    rate_code: str
    horizontal_resolution: str
    vertical_resolution: str
    interlaced_code: str
    output_3d_mode: str

    @classmethod
    def from_response(cls, response: str) -> LumagenOutputInfo | None:
        """Parse a Lumagen output info response."""
        parts = response.split(",")

        if len(parts) < 6 or parts[0] != "!O01":
            return None

        return cls(
            raw=response,
            rate_code=parts[1],
            horizontal_resolution=parts[2],
            vertical_resolution=parts[3],
            interlaced_code=parts[4],
            output_3d_mode=parts[5],
        )

    @property
    def scan_mode(self) -> str:
        """Return output scan mode."""
        return "i" if self.interlaced_code == "1" else "p"
