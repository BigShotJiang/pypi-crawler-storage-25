"""Lumagen RS232 protocol implementation."""

# Copyright (c) 2026 John Carey
# SPDX-License-Identifier: MIT

# pylint: disable=too-many-instance-attributes

from __future__ import annotations

import asyncio
import contextlib
import logging
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from time import monotonic

from .transport import LumagenTransport

_LOGGER = logging.getLogger(__name__)

LumagenEventCallback = Callable[[str], Awaitable[None]]

_RESPONSE_MARKER_RE = re.compile(rb"![SIO][A-Za-z0-9]{2}")
_POWER_RESPONSE_RE = re.compile(rb"!S02,[01]")

KEEPALIVE_INTERVAL = 30
EXTERNAL_KEEPALIVE_INTERVAL = 45
KEEPALIVE_RETRY_INTERVAL = 5
KEEPALIVE_FAILURE_LIMIT = 3
POWER_ON_KEEPALIVE_SUPPRESS_SECONDS = 15.0

SERIAL_COMMAND_SETTLE_DELAY = 0.05


@dataclass(slots=True)
class _QueuedCommand:
    """Queued Lumagen outbound command."""

    command: str
    expected_prefix: str | None
    timeout: float
    future: asyncio.Future[str | None]


class LumagenProtocol:
    """Lumagen ASCII protocol using delimiter mode off."""

    RESPONSE_TERMINATOR = b"\r\n"
    MAX_BUFFER_SIZE = 4096

    def __init__(self, transport: LumagenTransport) -> None:
        """Initialize the Lumagen protocol."""
        self._transport = transport
        self._command_queue: asyncio.Queue[_QueuedCommand] = asyncio.Queue()
        self._active_command: _QueuedCommand | None = None
        self._active_timeout_task: asyncio.Task[None] | None = None
        self._command_worker_task: asyncio.Task[None] | None = None
        self._reader_task: asyncio.Task[None] | None = None
        self._keepalive_task: asyncio.Task[None] | None = None
        self._event_callback: LumagenEventCallback | None = None
        self._buffer = b""
        self._keepalive_failures = 0
        self._external_keepalive_seen = asyncio.Event()
        self._suppress_keepalive_until = 0.0

    @property
    def is_connected(self) -> bool:
        """Return true if the Lumagen protocol is connected."""
        return (
            self._transport.is_connected
            and self._reader_task is not None
            and not self._reader_task.done()
            and self._command_worker_task is not None
            and not self._command_worker_task.done()
        )

    def set_event_callback(self, callback: LumagenEventCallback | None) -> None:
        """Set callback for unsolicited Lumagen events."""
        self._event_callback = callback

    async def connect(self) -> None:
        """Connect the underlying transport and start protocol tasks."""
        await self._transport.connect()

        if self._reader_task is None or self._reader_task.done():
            self._reader_task = asyncio.create_task(
                self._reader_loop(),
                name="lumagen_reader",
            )

        if self._command_worker_task is None or self._command_worker_task.done():
            self._command_worker_task = asyncio.create_task(
                self._command_worker_loop(),
                name="lumagen_command_worker",
            )

        if self._keepalive_task is None or self._keepalive_task.done():
            self._keepalive_task = asyncio.create_task(
                self._keepalive_loop(),
                name="lumagen_keepalive",
            )

    async def disconnect(self) -> None:
        """Disconnect the underlying transport."""
        current_task = asyncio.current_task()

        if (
            self._keepalive_task is not None
            and self._keepalive_task is not current_task
        ):
            self._keepalive_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._keepalive_task
        self._keepalive_task = None

        if (
            self._command_worker_task is not None
            and self._command_worker_task is not current_task
        ):
            self._command_worker_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._command_worker_task
        self._command_worker_task = None

        if self._reader_task is not None and self._reader_task is not current_task:
            self._reader_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._reader_task
        self._reader_task = None

        self._cancel_active_command()
        self._cancel_queued_commands()

        self._buffer = b""
        self._keepalive_failures = 0
        self._external_keepalive_seen.clear()
        self._suppress_keepalive_until = 0.0

        await self._transport.disconnect()

    async def _mark_disconnected(self) -> None:
        """Close protocol state after a transport/protocol failure."""
        with contextlib.suppress(Exception):
            await self.disconnect()

    async def send(self, command: str) -> None:
        """Queue a command that does not require a response."""
        try:
            await self.connect()

            loop = asyncio.get_running_loop()
            future: asyncio.Future[str | None] = loop.create_future()

            await self._command_queue.put(
                _QueuedCommand(
                    command=command,
                    expected_prefix=None,
                    timeout=0.0,
                    future=future,
                )
            )

            await future

        except (OSError, RuntimeError, asyncio.exceptions.TimeoutError):
            await self._mark_disconnected()
            raise

    async def query(
        self,
        command: str,
        timeout: float = 5.0,
        expected_prefix: str | None = None,
        disconnect_on_timeout: bool = True,
    ) -> str:
        """Queue a query command and return the matching response."""
        try:
            await self.connect()

            if expected_prefix is None:
                expected_prefix = f"!{command[-3:]}"

            loop = asyncio.get_running_loop()
            future: asyncio.Future[str | None] = loop.create_future()

            await self._command_queue.put(
                _QueuedCommand(
                    command=command,
                    expected_prefix=expected_prefix,
                    timeout=timeout,
                    future=future,
                )
            )

            response = await future

            if response is None:
                raise RuntimeError(f"Lumagen query returned no response: {command}")

            return response

        except asyncio.exceptions.TimeoutError:
            if disconnect_on_timeout:
                await self._mark_disconnected()
            raise

        except (OSError, RuntimeError):
            await self._mark_disconnected()
            raise

    async def _command_worker_loop(self) -> None:
        """Send queued Lumagen commands one at a time."""
        while True:
            queued_command = await self._command_queue.get()

            try:
                await self._run_queued_command(queued_command)

            except Exception as err:  # pylint: disable=broad-exception-caught
                if not queued_command.future.done():
                    queued_command.future.set_exception(err)
            finally:
                if self._active_timeout_task is not None:
                    self._active_timeout_task.cancel()
                    self._active_timeout_task = None

                if self._active_command is queued_command:
                    self._active_command = None

                self._command_queue.task_done()

    async def _run_queued_command(self, queued_command: _QueuedCommand) -> None:
        """Run one queued command transaction."""
        if queued_command.future.cancelled():
            return

        self._active_command = queued_command

        if queued_command.command == "%":
            self._suppress_keepalive_until = (
                monotonic() + POWER_ON_KEEPALIVE_SUPPRESS_SECONDS
            )

        if queued_command.command == "ZQS00":
            _LOGGER.log(5, "Lumagen keepalive send: %r", queued_command.command)
        else:
            _LOGGER.debug("Lumagen send: %r", queued_command.command)

        await self._transport.write(queued_command.command.encode("ascii"))

        if queued_command.expected_prefix is None:
            await asyncio.sleep(SERIAL_COMMAND_SETTLE_DELAY)

            if not queued_command.future.done():
                queued_command.future.set_result(None)

            return

        self._active_timeout_task = asyncio.create_task(
            self._timeout_active_command(queued_command),
            name="lumagen_command_timeout",
        )

        await queued_command.future

    async def _timeout_active_command(self, queued_command: _QueuedCommand) -> None:
        """Fail the active command if its expected response does not arrive."""
        await asyncio.sleep(queued_command.timeout)

        if self._active_command is not queued_command:
            return

        if queued_command.future.done():
            return

        queued_command.future.set_exception(
            asyncio.exceptions.TimeoutError(
                f"Timed out waiting for {queued_command.expected_prefix} "
                f"after {queued_command.command!r}"
            )
        )

    def _cancel_active_command(self) -> None:
        """Cancel active command and timeout task."""
        if self._active_timeout_task is not None:
            self._active_timeout_task.cancel()
            self._active_timeout_task = None

        if self._active_command is not None and not self._active_command.future.done():
            self._active_command.future.cancel()

        self._active_command = None

    def _cancel_queued_commands(self) -> None:
        """Cancel commands still waiting in the queue."""
        while True:
            try:
                queued_command = self._command_queue.get_nowait()
            except asyncio.QueueEmpty:
                return

            if not queued_command.future.done():
                queued_command.future.cancel()

            self._command_queue.task_done()

    async def _keepalive_loop(self) -> None:
        """Periodically verify the Lumagen protocol is still responsive."""
        timeout = KEEPALIVE_INTERVAL

        while True:
            try:
                self._external_keepalive_seen.clear()

                try:
                    await asyncio.wait_for(
                        self._external_keepalive_seen.wait(),
                        timeout=timeout,
                    )
                    timeout = EXTERNAL_KEEPALIVE_INTERVAL
                    continue
                except asyncio.exceptions.TimeoutError:
                    pass

                remaining_suppression = self._suppress_keepalive_until - monotonic()
                if remaining_suppression > 0:
                    _LOGGER.debug(
                        "Skipping Lumagen keepalive during power-on grace period"
                    )
                    await asyncio.sleep(remaining_suppression)
                    timeout = KEEPALIVE_INTERVAL
                    continue

                response = await self.query(
                    "ZQS00",
                    timeout=10.0,
                    disconnect_on_timeout=False,
                )
                if response == "!S00,Ok":
                    self._keepalive_failures = 0
                    timeout = KEEPALIVE_INTERVAL
                    continue

                _LOGGER.warning("Lumagen keepalive failed: %r", response)

            except asyncio.CancelledError:  # pylint: disable=try-except-raise
                raise
            except (OSError, RuntimeError, asyncio.exceptions.TimeoutError) as err:
                _LOGGER.warning("Lumagen keepalive failed: %s", err)

            self._keepalive_failures += 1
            timeout = KEEPALIVE_RETRY_INTERVAL

            if self._keepalive_failures < KEEPALIVE_FAILURE_LIMIT:
                continue

            _LOGGER.warning("Lumagen keepalive failure limit reached; disconnecting")
            await self._mark_disconnected()
            return

    async def _reader_loop(self) -> None:
        """Continuously read Lumagen bytes and route extracted responses."""
        try:
            while True:
                try:
                    chunk = await self._transport.read()
                except asyncio.exceptions.TimeoutError:
                    continue

                if not chunk:
                    raise OSError("Lumagen transport closed")

                self._buffer += chunk

                if len(self._buffer) > self.MAX_BUFFER_SIZE:
                    _LOGGER.debug("Trimming oversized Lumagen receive buffer")
                    self._buffer = self._buffer[-self.MAX_BUFFER_SIZE :]

                await self._process_buffer()

        except OSError as err:
            _LOGGER.debug("Lumagen reader stopped: %s", err)
            await self._mark_disconnected()

    async def _process_buffer(self) -> None:
        """Extract and route valid Lumagen responses from the byte buffer."""
        while True:
            power_match = _POWER_RESPONSE_RE.search(self._buffer)
            line_response = self._extract_crlf_response()

            if power_match is None and line_response is None:
                self._discard_noise_before_possible_response()
                return

            if power_match is not None and (
                line_response is None or power_match.start() <= line_response[0]
            ):
                response_bytes = power_match.group(0)
                self._buffer = (
                    self._buffer[: power_match.start()]
                    + self._buffer[power_match.end() :]
                )
                await self._handle_response_bytes(response_bytes)
                continue

            if line_response is not None:
                start, end, response_bytes = line_response
                self._buffer = self._buffer[:start] + self._buffer[end:]
                await self._handle_response_bytes(response_bytes)
                continue

    def _extract_crlf_response(self) -> tuple[int, int, bytes] | None:
        """Extract a CRLF-terminated Lumagen response from the buffer."""
        marker = _RESPONSE_MARKER_RE.search(self._buffer)

        if marker is None:
            return None

        terminator = self._buffer.find(self.RESPONSE_TERMINATOR, marker.start())

        if terminator == -1:
            return None

        end = terminator + len(self.RESPONSE_TERMINATOR)
        response = self._buffer[marker.start() : terminator].strip()

        return marker.start(), end, response

    def _discard_noise_before_possible_response(self) -> None:
        """Discard noise while preserving partial Lumagen response markers."""
        marker = _RESPONSE_MARKER_RE.search(self._buffer)

        if marker is not None:
            if marker.start() > 0:
                self._buffer = self._buffer[marker.start() :]
            return

        keep_from = self._find_partial_marker_start()

        if keep_from is None:
            self._buffer = b""
            return

        if keep_from > 0:
            self._buffer = self._buffer[keep_from:]

    def _find_partial_marker_start(self) -> int | None:
        """Return index of a partial response marker at the end of the buffer."""
        max_prefix_length = 3

        for length in range(min(max_prefix_length, len(self._buffer)), 0, -1):
            suffix = self._buffer[-length:]

            if not suffix.startswith(b"!"):
                continue

            if length == 1:
                return len(self._buffer) - length

            if suffix[1:2] in {b"S", b"I", b"O"}:
                return len(self._buffer) - length

        return None

    async def _handle_response_bytes(self, response_bytes: bytes) -> None:
        """Decode and route a Lumagen response."""
        response = response_bytes.decode("ascii", errors="replace").strip()

        if not response:
            return

        if response == "!S00,Ok":
            _LOGGER.log(5, "Lumagen keepalive recv: %r", response)
        else:
            _LOGGER.debug("Lumagen recv: %r", response)

        await self._handle_response(response)

    async def _handle_response(self, response: str) -> None:
        """Handle a decoded Lumagen response."""
        active_command = self._active_command

        if (
            active_command is not None
            and active_command.expected_prefix is not None
            and response.startswith(active_command.expected_prefix)
        ):
            if not active_command.future.done():
                active_command.future.set_result(response)
            return

        if response == "!S00,Ok":
            _LOGGER.log(5, "External Lumagen keepalive observed; delaying own keepalive")
            self._keepalive_failures = 0
            self._external_keepalive_seen.set()
            return

        await self._emit_unsolicited_event(response)

    async def _emit_unsolicited_event(self, response: str) -> None:
        """Emit an unsolicited Lumagen event without blocking the reader loop."""
        if self._event_callback is None:
            return

        task = asyncio.create_task(
            self._event_callback(response),
            name="lumagen_event_callback",
        )
        task.add_done_callback(
            lambda done_task: self._log_event_callback_result(done_task, response)
        )

    @staticmethod
    def _log_event_callback_result(
        task: asyncio.Task[None],
        response: str,
    ) -> None:
        """Log unexpected unsolicited event callback failures."""
        try:
            task.result()
        except asyncio.CancelledError:
            pass
        except Exception:  # pylint: disable=broad-except
            _LOGGER.exception("Error handling unsolicited Lumagen event: %r", response)
