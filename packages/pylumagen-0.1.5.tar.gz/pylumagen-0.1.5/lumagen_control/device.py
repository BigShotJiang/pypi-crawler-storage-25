"""High-level Lumagen device API."""

# Copyright (c) 2026 John Carey
# SPDX-License-Identifier: MIT

# pylint: disable=too-many-public-methods

from __future__ import annotations

from .formatters import format_osd_message
from .models import (
    LumagenFullStatus,
    LumagenId,
    LumagenInput,
    LumagenOutputInfo,
    LumagenPowerStatus,
)
from .protocol import LumagenEventCallback, LumagenProtocol


class LumagenDevice:
    """High-level Lumagen device handler."""

    def __init__(self, protocol: LumagenProtocol) -> None:
        """Initialize the Lumagen device."""
        self._protocol = protocol

    @property
    def is_connected(self) -> bool:
        """Return true if connected to the Lumagen."""
        return self._protocol.is_connected

    #
    # Connection lifecycle
    #

    async def connect(self) -> None:
        """Connect to the Lumagen."""
        await self._protocol.connect()

    async def disconnect(self) -> None:
        """Disconnect from the Lumagen."""
        await self._protocol.disconnect()

    def set_event_callback(self, callback: LumagenEventCallback | None) -> None:
        """Set callback for unsolicited Lumagen events."""
        self._protocol.set_event_callback(callback)

    #
    # Queries
    #

    async def query_alive(self) -> bool:
        """Return true if the Lumagen responds to the alive query."""
        return await self._protocol.query("ZQS00") == "!S00,Ok"

    async def query_id(self) -> LumagenId:
        """Return Lumagen model, software, model number, and serial number."""
        response = await self._protocol.query("ZQS01")
        parts = response.split(",")

        if len(parts) < 5 or parts[0] != "!S01":
            raise ValueError(f"Unexpected Lumagen ID response: {response}")

        return LumagenId(
            model=parts[1],
            software=parts[2],
            model_number=parts[3],
            serial_number=parts[4],
        )

    async def query_power(self) -> LumagenPowerStatus | None:
        """Return parsed Lumagen power status."""
        response = await self._protocol.query("ZQS02")
        return LumagenPowerStatus.from_response(response)

    async def query_input(self) -> LumagenInput | None:
        """Return current logical input, memory, and physical input."""
        response = await self._protocol.query("ZQI00")
        parts = response.split(",")

        if len(parts) < 4 or parts[0] != "!I00":
            return None

        try:
            return LumagenInput(
                input_number=int(parts[1]),
                memory=parts[2],
                physical_input=int(parts[3]),
            )
        except ValueError:
            return None

    async def query_input_info(self) -> str:
        """Return Lumagen input info."""
        return await self._protocol.query(
            "ZQI01",
            expected_prefix="!I01",
        )

    async def query_output_info(self, timeout: float = 5.0) -> LumagenOutputInfo | None:
        """Return parsed Lumagen output info."""
        response = await self._protocol.query(
            "ZQO01",
            timeout=timeout,
            expected_prefix="!O01",
        )
        return LumagenOutputInfo.from_response(response)

    async def query_full_status(self) -> LumagenFullStatus | None:
        """Return parsed Lumagen full status."""
        response = await self._protocol.query(
            "ZQI25",
            expected_prefix="!I25",
        )

        return LumagenFullStatus.from_response(response)

    async def query_input_label(self, memory: str, input_number: int) -> str | None:
        """Return the custom label for an input memory/input number."""
        if memory not in {"A", "B", "C", "D"}:
            raise ValueError("Lumagen input memory must be A, B, C, or D")

        if not 1 <= input_number <= 10:
            raise ValueError("Lumagen input label query only supports inputs 1-10")

        response = await self._protocol.query(
            f"ZQS1{memory}{input_number - 1}",
            expected_prefix=f"!S1{memory}",
        )
        parts = response.split(",", maxsplit=1)

        if len(parts) != 2 or parts[0] != f"!S1{memory}":
            return None

        label = parts[1].strip()

        if not label or label == "Input":
            return None

        return label

    async def query_input_labels(self, memory: str = "A") -> dict[int, str]:
        """Return custom labels for supported inputs in a memory."""
        labels: dict[int, str] = {}

        for input_number in range(1, 11):
            label = await self.query_input_label(memory, input_number)

            if label is not None:
                labels[input_number] = label

        return labels

    @staticmethod
    def parse_power_event(event: str) -> LumagenPowerStatus | None:
        """Parse an unsolicited Lumagen power status event."""
        return LumagenPowerStatus.from_response(event)

    @staticmethod
    def parse_full_status_event(event: str) -> LumagenFullStatus | None:
        """Parse an unsolicited Lumagen full status event."""
        return LumagenFullStatus.from_response(event)

    @staticmethod
    def parse_input_event(event: str) -> LumagenInput | None:
        """Parse an unsolicited Lumagen input event."""
        parts = event.split(",")

        if len(parts) < 4 or parts[0] != "!I00":
            return None

        try:
            return LumagenInput(
                input_number=int(parts[1]),
                memory=parts[2],
                physical_input=int(parts[3]),
            )
        except ValueError:
            return None

    @staticmethod
    def parse_output_info_event(event: str) -> LumagenOutputInfo | None:
        """Parse an unsolicited Lumagen output info event."""
        return LumagenOutputInfo.from_response(event)

    #
    # Power and configuration
    #

    async def power_on(self) -> None:
        """Power on the Lumagen."""
        await self._protocol.send("%")

    async def standby(self) -> None:
        """Put the Lumagen in standby."""
        await self._protocol.send("$")

    async def save_config(self) -> None:
        """Save Lumagen configuration to flash."""
        await self._protocol.send("ZY6SAVECONFIG\r")

    async def input_restart(self, input_number: int | str = "all") -> None:
        """Toggle HDMI hotplug for one input or all inputs.

        input_number 1-6 maps to Lumagen X values 0-5.
        input_number 7, "A", or "all" toggles all HDMI inputs.
        """
        if isinstance(input_number, str):
            if input_number.lower() not in {"all", "a"}:
                raise ValueError("HDMI hotplug input must be 1-6, 7, 'A', or 'all'")
            hotplug_input = "A"
        elif 1 <= input_number <= 6:
            hotplug_input = str(input_number - 1)
        elif input_number == 7:
            hotplug_input = "A"
        else:
            raise ValueError("HDMI hotplug input must be 1-6, 7, 'A', or 'all'")

        await self._protocol.send(f"ZY520{hotplug_input}\r")

    async def output_restart(self) -> None:
        """Restart HDMI output connection and acquire current input source."""
        await self._protocol.send("ZY554\r")

    #
    # Menu navigation
    #

    async def menu(self) -> None:
        """Open the Lumagen menu."""
        await self._protocol.send("M")

    async def exit(self) -> None:
        """Exit or cancel."""
        await self._protocol.send("X")

    async def clear(self) -> None:
        """Force menu off."""
        await self._protocol.send("!")

    async def ok(self) -> None:
        """Send OK."""
        await self._protocol.send("k")

    async def up(self) -> None:
        """Send up."""
        await self._protocol.send("^")

    async def down(self) -> None:
        """Send down."""
        await self._protocol.send("v")

    async def left(self) -> None:
        """Send left."""
        await self._protocol.send("<")

    async def right(self) -> None:
        """Send right."""
        await self._protocol.send(">")

    async def help(self) -> None:
        """Show help."""
        await self._protocol.send("U")

    async def alt(self) -> None:
        """Send ALT."""
        await self._protocol.send("#")

    #
    # Input selection and input memories
    #

    async def select_input(self, input_number: int) -> None:
        """Select input 1 through 18."""
        if not 1 <= input_number <= 18:
            raise ValueError("Lumagen input must be between 1 and 18")

        if input_number <= 9:
            await self._protocol.send(f"i{input_number}")
            return

        await self._protocol.send(f"i+{input_number - 10}")

    async def previous_input(self) -> None:
        """Select previous input."""
        await self._protocol.send("P")

    async def mema(self) -> None:
        """Select input memory A."""
        await self._protocol.send("a")

    async def memb(self) -> None:
        """Select input memory B."""
        await self._protocol.send("b")

    async def memc(self) -> None:
        """Select input memory C."""
        await self._protocol.send("c")

    async def memd(self) -> None:
        """Select input memory D."""
        await self._protocol.send("d")

    async def set_input_label(
        self,
        memory: str,
        input_number: int,
        label: str,
    ) -> None:
        """Set the custom label for an input memory/input number."""
        if memory not in {"A", "B", "C", "D"}:
            raise ValueError("Lumagen input memory must be A, B, C, or D")

        if not 1 <= input_number <= 8:
            raise ValueError("Lumagen input label setting only supports inputs 1-8")

        if len(label) > 10:
            raise ValueError("Lumagen input label must be 10 characters or fewer")

        await self._protocol.send(f"ZY524{memory}{input_number - 1}{label}\r")

    #
    # Aspect and NLS controls
    #

    async def auto_aspect_disable(self) -> None:
        """Disable auto aspect."""
        await self._protocol.send("V")

    async def auto_aspect_enable(self) -> None:
        """Enable auto aspect."""
        await self._protocol.send("~")

    async def reset_auto_aspect_detection(self) -> None:
        """Reset and reinitiate automatic aspect detection."""
        await self._protocol.send("ZY550\r")

    async def toggle_nls(self) -> None:
        """Toggle NLS."""
        await self._protocol.send("N")

    async def show_aspect(self) -> None:
        """Show aspect information on the Lumagen OSD."""
        await self._protocol.send("ZY811\r")

    async def set_aspect_4_3(self) -> None:
        """Set source aspect to 4:3."""
        await self._protocol.send("n")

    async def set_aspect_lbox(self) -> None:
        """Set source aspect to letterbox."""
        await self._protocol.send("l")

    async def set_aspect_16_9(self) -> None:
        """Set source aspect to 16:9."""
        await self._protocol.send("w")

    async def set_aspect_1_85(self) -> None:
        """Set source aspect to 1.85."""
        await self._protocol.send("j")

    async def set_aspect_1_90(self) -> None:
        """Set source aspect to 1.90."""
        await self._protocol.send("A")

    async def set_aspect_2_00(self) -> None:
        """Set source aspect to 2.00."""
        await self._protocol.send("C")

    async def set_aspect_2_10(self) -> None:
        """Set source aspect ratio to 2.10."""
        await self._protocol.send("+j")

    async def set_aspect_2_20(self) -> None:
        """Set source aspect to 2.20."""
        await self._protocol.send("E")

    async def set_aspect_2_35(self) -> None:
        """Set source aspect to 2.35."""
        await self._protocol.send("W")

    async def set_aspect_2_40(self) -> None:
        """Set source aspect to 2.40."""
        await self._protocol.send("G")

    async def set_aspect_2_55(self) -> None:
        """Set source aspect ratio to 2.55."""
        await self._protocol.send("+W")

    async def set_aspect_2_76(self) -> None:
        """Set source aspect ratio to 2.76."""
        await self._protocol.send("+N")

    #
    # On-screen menus and patterns
    #

    async def hdr(self) -> None:
        """Show HDR parameter menu."""
        await self._protocol.send("Y")

    async def pattern(self) -> None:
        """Show test pattern."""
        await self._protocol.send("H")

    #
    # On-screen display messages
    #

    async def display_message(self, message: str, duration: int) -> None:
        """Display a message on the Lumagen OSD."""
        if not 0 <= duration <= 9:
            raise ValueError("Lumagen message duration must be 0 through 9")

        await self._protocol.send(f"ZT{duration}{format_osd_message(message)}\r")

    async def clear_message(self) -> None:
        """Clear Lumagen OSD message."""
        await self._protocol.send("ZC\r")
