# pylumagen

Async Python library for controlling a Lumagen Radiance Pro from Home Assistant.

This package is intended only for use in Home Assistant integrations. It is not designed or supported as a general-purpose end-user command line tool.

## Installation

```bash
pip install pylumagen
```

## Import

The PyPI package name is `pylumagen`, but the Python import package is `lumagen_control`:

```python
from lumagen_control import LumagenDevice, LumagenProtocol, TcpTransport
```

## License

MIT License