"""RewindClient — unified interface to the memory stack.

Free tier: L0 (FTS5), L1 (System), L3 (SQLite Graph), L4 (Vector).
Pro tier: extends with L5, L6, Bio, Feedback via rewind-memory-pro plugin.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from rewind.config import RewindConfig, default_config

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class Result:
    path: str = ""
    text: str = ""
    score: float = 0.0
    layer: str = ""
    source: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Plugin registry — Pro layers register themselves here
# ---------------------------------------------------------------------------

_PRO_PLUGIN: Optional[Any] = None


def register_pro_plugin(plugin: Any) -> None:
    """Called by rewind-memory-pro on import to extend the client."""
    global _PRO_PLUGIN
    _PRO_PLUGIN = plugin
    log.info("Rewind Pro plugin registered")


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class RewindClient:
    """Unified gateway to the memory architecture.

    Usage::

        from rewind.client import RewindClient
        from rewind.config import default_config

        client = RewindClient(default_config("free"))
        results = client.search("what is Hebbian learning")
        for r in results:
            print(f"{r.score:.2f} [{r.layer}] {r.text[:80]}")
    """

    def __init__(
        self,
        config: Optional[RewindConfig] = None,
        embedding_fn: Optional[Callable[[str], List[float]]] = None,
        api_key: Optional[str] = None,
    ) -> None:
        self.config = config or default_config()
        self._embedding_fn = embedding_fn
        self._api_key = api_key
        self._layers: Dict[str, Any] = {}
        self._orchestrator = None
        self._initialised = False

    # -- lazy init --------------------------------------------------------

    def _init_layers(self) -> None:
        if self._initialised:
            return

        cfg = self.config
        lf = cfg.layers

        workspace = os.path.expanduser(cfg.workspace_path)
        db_path = os.path.expanduser(cfg.vector_db_path)

        # -- L0: FTS5/BM25 keyword search --
        if lf.l0_sensory:
            try:
                from rewind.layers.l0_fts import L0FullTextSearch
                self._layers["l0"] = L0FullTextSearch(db_path)
                log.info("L0 (FTS5) initialised: %s", db_path)
            except Exception as exc:
                log.warning("L0 init failed: %s", exc)

        # -- L1: System files --
        if lf.l1_stm:
            try:
                from rewind.layers.l1_system import L1SystemFiles
                self._layers["l1"] = L1SystemFiles(workspace)
                log.info("L1 (System Files) initialised: %s", workspace)
            except Exception as exc:
                log.warning("L1 init failed: %s", exc)

        # -- L3: Knowledge graph (SQLite) --
        if lf.l3_graph:
            try:
                from rewind.layers.l3_graph_sqlite import L3GraphSQLite
                graph_db = str(Path(db_path).parent / "graph.db")
                self._layers["l3"] = L3GraphSQLite(graph_db)
                log.info("L3 (Graph/SQLite) initialised: %s", graph_db)
            except Exception as exc:
                log.warning("L3 init failed: %s", exc)

        # -- L4: Vector search (sqlite-vec) --
        if lf.l4_workspace:
            try:
                from rewind.layers.l4_vector import L4Vector
                self._layers["l4"] = L4Vector(
                    db_path=db_path,
                    embedding_fn=self._get_embedding_fn(),
                )
                log.info("L4 (Vector) initialised: %s", db_path)
            except Exception as exc:
                log.warning("L4 init failed: %s", exc)

        # -- Pro layers (via plugin) --
        if _PRO_PLUGIN and self._api_key:
            try:
                pro_layers = _PRO_PLUGIN.init_pro_layers(
                    config=cfg,
                    api_key=self._api_key,
                    db_path=db_path,
                    embedding_fn=self._get_embedding_fn(),
                )
                self._layers.update(pro_layers)
                log.info("Pro layers initialised: %s", list(pro_layers.keys()))
            except Exception as exc:
                log.warning("Pro layer init failed: %s", exc)
        elif any([lf.l5_comms, lf.l6_docs, lf.bio]):
            log.warning(
                "Pro features requested but rewind-memory-pro is not installed "
                "or no API key provided. Install with: "
                "pip install git+https://github.com/saraidefence/rewind-memory-pro.git"
            )

        # -- L2: Orchestrator --
        if self._layers:
            try:
                from rewind.layers.l2_orchestrator import L2Orchestrator
                orch_config = {f"enable_{k}": True for k in self._layers}
                self._orchestrator = L2Orchestrator(orch_config, self._layers)
                log.info("L2 (Orchestrator) initialised with layers: %s",
                         list(self._layers.keys()))
            except Exception as exc:
                log.warning("L2 orchestrator init failed: %s", exc)

        self._initialised = True

    def _get_embedding_fn(self) -> Optional[Callable[[str], List[float]]]:
        """Return the embedding function."""
        if self._embedding_fn:
            return self._embedding_fn

        cfg = self.config.embedding
        if cfg.provider == "ollama":
            return self._make_ollama_embedder(cfg.url, cfg.model)

        # Pro embedding providers handled by plugin
        if _PRO_PLUGIN and self._api_key:
            fn = _PRO_PLUGIN.get_embedding_fn(cfg, self._api_key)
            if fn:
                return fn

        return self._make_ollama_embedder(cfg.url, cfg.model)

    @staticmethod
    def _make_ollama_embedder(url: str, model: str) -> Callable[[str], List[float]]:
        def embed(text: str) -> List[float]:
            try:
                import httpx
                resp = httpx.post(
                    f"{url}/api/embed",
                    json={"model": model, "input": text},
                    timeout=10,
                )
                resp.raise_for_status()
                data = resp.json()
                return data["embeddings"][0] if "embeddings" in data else data["embedding"]
            except Exception:
                return []
        return embed

    # -- public API -------------------------------------------------------

    def search(
        self,
        query: str,
        limit: int = 16,
        namespace: Optional[str] = None,
    ) -> List[Result]:
        """Search across all enabled layers."""
        self._init_layers()

        if self._orchestrator:
            raw_results = self._orchestrator.search(
                query, limit=limit, namespace=namespace,
            )
            return [
                Result(
                    path=r.get("path", ""),
                    text=r.get("text", ""),
                    score=r.get("score", 0.0),
                    layer=r.get("layer", ""),
                    source=r.get("source", ""),
                    metadata={k: v for k, v in r.items()
                              if k not in ("path", "text", "score", "layer", "source")},
                )
                for r in raw_results
            ][:limit]

        # Fallback: sequential search
        results: List[Result] = []
        for name, layer in self._layers.items():
            try:
                layer_results = layer.search(query, limit=limit, namespace=namespace)
                if isinstance(layer_results, list):
                    for r in layer_results:
                        if isinstance(r, dict):
                            results.append(Result(
                                path=r.get("path", ""),
                                text=r.get("text", ""),
                                score=r.get("score", 0.0),
                                layer=r.get("layer", name),
                                source=r.get("source", ""),
                            ))
            except Exception as exc:
                log.warning("Search failed on %s: %s", name, exc)

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:limit]

    def ingest(self, path: str, arena: str = "general") -> dict:
        """Ingest a document through L0 sensory buffer."""
        self._init_layers()
        l0 = self._layers.get("l0")
        if l0 and hasattr(l0, "ingest"):
            return l0.ingest(path, arena)
        return {"status": "error", "detail": "L0 sensory layer not available"}

    def health(self) -> dict:
        """Health check across all enabled layers."""
        self._init_layers()
        report: Dict[str, Any] = {
            "tier": self.config.tier,
            "layers": {},
            "orchestrator": self._orchestrator is not None,
            "pro_installed": _PRO_PLUGIN is not None,
        }
        for key, layer in self._layers.items():
            try:
                if hasattr(layer, "health"):
                    report["layers"][key] = layer.health()
                else:
                    report["layers"][key] = {"status": "ok"}
            except Exception as exc:
                report["layers"][key] = {"status": "error", "detail": str(exc)}

        report["healthy"] = all(
            v.get("status") in ("ok", "degraded")
            for v in report["layers"].values()
        )
        return report

    def close(self) -> None:
        """Shut down all layer connections."""
        for name, layer in self._layers.items():
            try:
                if hasattr(layer, "close"):
                    layer.close()
            except Exception as exc:
                log.warning("Close failed on %s: %s", name, exc)
        self._layers.clear()
        self._orchestrator = None
        self._initialised = False
