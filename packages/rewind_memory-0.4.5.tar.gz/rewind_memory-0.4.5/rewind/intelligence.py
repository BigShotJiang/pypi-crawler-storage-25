#!/usr/bin/env python3
"""
Memory Intelligence Module — Claude Code-inspired improvements for HybridRAG.

1. LLM Relevance Filter: Re-rank fused results using cross-encoder or cheap LLM
2. Typed Memory Taxonomy: user/feedback/project/reference classification
3. Memory Drift Detection: Flag stale memories that reference files/services
4. Result Confidence Scoring: Weight by recency + type match

Integrated as post-fusion step in sequential-hybridrag-proxy.py
"""

import json
import logging
import os
import re
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("memory_intelligence")

# ── Memory Type Taxonomy (inspired by Claude Code) ────────────────────────────

MEMORY_TYPES = ["user", "feedback", "project", "reference"]

# Keywords that signal each memory type
TYPE_SIGNALS = {
    "user": [
        "preference", "prefers", "personality", "birthday", "timezone",
        "language", "spelling", "tone", "style", "vova", "human",
        "likes", "dislikes", "interests", "background",
    ],
    "feedback": [
        "lesson", "learned", "mistake", "rule", "never", "always",
        "don't", "stop", "correction", "fix", "bug", "error",
        "should have", "next time", "improvement", "feedback",
        "verified", "confirmed", "works", "approach",
    ],
    "project": [
        "decision", "deadline", "milestone", "deployed", "launched",
        "meeting", "sprint", "plan", "roadmap", "priority", "task",
        "buildengine", "pentatonic", "sarai", "rewind", "scraper",
        "commit", "pr", "release", "version",
    ],
    "reference": [
        "port", "ip", "ssh", "url", "endpoint", "api", "key",
        "path", "config", "credential", "login", "service",
        "dashboard", "docs", "documentation", "link",
        "contact", "phone", "email", "address",
        "8031", "8034", "8037", "8041", "7687", "localhost",
        "bolt://", "http://", "https://",
    ],
}


def classify_memory_type(text: str) -> Tuple[str, float]:
    """Classify a memory chunk into one of 4 types with confidence.
    
    Returns (type, confidence) where confidence is 0.0-1.0.
    """
    text_lower = text.lower()
    scores = {}
    
    for mtype, signals in TYPE_SIGNALS.items():
        score = sum(1 for s in signals if s in text_lower)
        # Normalise by number of signals
        scores[mtype] = score / len(signals) if signals else 0
    
    best_type = max(scores, key=scores.get)
    best_score = scores[best_type]
    
    # If no clear signal, default to "project" (most common)
    if best_score < 0.02:
        return "project", 0.3
    
    return best_type, min(1.0, best_score * 5)  # Scale up


# ── Recency Weighting ─────────────────────────────────────────────────────────

def recency_weight(result: Dict) -> float:
    """Apply time-decay weighting. Recent memories score higher.
    
    Half-life: 14 days for project memories, 90 days for user/reference.
    """
    mtype = result.get("memory_type", "project")
    half_life_days = 90 if mtype in ("user", "reference") else 14
    
    # Try to extract date from path or metadata
    path = result.get("path", "")
    date_match = re.search(r'(\d{4}-\d{2}-\d{2})', path)
    
    if date_match:
        try:
            mem_date = datetime.strptime(date_match.group(1), "%Y-%m-%d")
            age_days = (datetime.now() - mem_date).days
            # Exponential decay
            decay = 0.5 ** (age_days / half_life_days)
            return max(0.3, decay)  # Floor at 0.3
        except ValueError:
            pass
    
    return 0.8  # Unknown age — assume somewhat recent


# ── Memory Drift Detection ────────────────────────────────────────────────────

# Patterns that suggest a memory references something verifiable
VERIFIABLE_PATTERNS = [
    (r'port[:\s]+(\d{4,5})', "port"),
    (r'(?:http[s]?://[^\s]+)', "url"),
    (r'(?:/home/[^\s]+|~/[^\s]+)', "path"),
    (r'(?:PID|pid)[:\s]+(\d+)', "process"),
    (r'(?:service|daemon)[:\s]+([^\s,]+)', "service"),
]


def detect_drift_signals(text: str) -> List[Dict]:
    """Detect references in memory text that could be stale.
    
    Returns list of {type, value, verifiable} dicts.
    """
    signals = []
    
    for pattern, signal_type in VERIFIABLE_PATTERNS:
        matches = re.findall(pattern, text)
        for match in matches:
            signals.append({
                "type": signal_type,
                "value": match if isinstance(match, str) else match,
                "verifiable": True,
            })
    
    return signals


def check_drift(result: Dict) -> Dict:
    """Add drift metadata to a result.
    
    Adds:
    - drift_signals: list of verifiable references found
    - drift_risk: "low", "medium", "high" based on age + verifiable count
    """
    text = result.get("text", "")
    signals = detect_drift_signals(text)
    
    # Calculate drift risk
    path = result.get("path", "")
    date_match = re.search(r'(\d{4}-\d{2}-\d{2})', path)
    age_days = 0
    if date_match:
        try:
            mem_date = datetime.strptime(date_match.group(1), "%Y-%m-%d")
            age_days = (datetime.now() - mem_date).days
        except ValueError:
            pass
    
    if len(signals) == 0:
        risk = "low"
    elif age_days > 30 and len(signals) > 2:
        risk = "high"
    elif age_days > 14 or len(signals) > 1:
        risk = "medium"
    else:
        risk = "low"
    
    result["drift_signals"] = signals
    result["drift_risk"] = risk
    return result


# ── LLM Relevance Filter (lightweight) ───────────────────────────────────────

def relevance_rerank(query: str, results: List[Dict], top_k: int = 10) -> List[Dict]:
    """Re-rank results using query-result relevance scoring.
    
    Uses a lightweight approach:
    1. Classify query intent (what type of memory is being sought)
    2. Boost results that match the query intent type
    3. Apply recency weighting
    4. Add drift detection
    
    No LLM call — pure heuristic for <1ms overhead.
    For LLM-powered reranking, use relevance_rerank_llm() (async, slower).
    """
    if not results:
        return results
    
    # Classify query intent
    query_type, query_confidence = classify_memory_type(query)
    
    for r in results:
        # Classify the result
        text = r.get("text", "")
        mem_type, mem_confidence = classify_memory_type(text)
        r["memory_type"] = mem_type
        r["type_confidence"] = mem_confidence
        
        # Boost if query type matches result type
        type_boost = 1.15 if mem_type == query_type else 1.0
        
        # Apply recency weighting
        recency = recency_weight(r)
        
        # Combined score adjustment
        orig_score = r.get("score", 0.5)
        r["score"] = min(1.0, orig_score * type_boost * recency)
        r["query_type_match"] = mem_type == query_type
        
        # Add drift detection
        check_drift(r)
    
    # Re-sort by adjusted score
    results.sort(key=lambda x: x["score"], reverse=True)
    
    return results[:top_k]


# ── Integration Point ─────────────────────────────────────────────────────────

def post_fusion_enhance(query: str, results: List[Dict], limit: int = 16) -> List[Dict]:
    """Main entry point — called after L2 fusion in the HybridRAG proxy.
    
    Applies:
    1. Memory type classification
    2. Recency weighting  
    3. Type-intent matching (query type vs result type)
    4. Drift detection
    5. Re-ranking
    """
    start = time.time()
    enhanced = relevance_rerank(query, results, top_k=limit)
    elapsed_ms = (time.time() - start) * 1000
    
    # Log stats
    types_found = {}
    drift_counts = {"low": 0, "medium": 0, "high": 0}
    for r in enhanced:
        t = r.get("memory_type", "unknown")
        types_found[t] = types_found.get(t, 0) + 1
        dr = r.get("drift_risk", "low")
        drift_counts[dr] = drift_counts.get(dr, 0) + 1
    
    log.info(
        f"Post-fusion enhance: {len(enhanced)} results in {elapsed_ms:.1f}ms | "
        f"types={types_found} | drift={drift_counts}"
    )
    
    return enhanced


# ── Frontmatter Utilities ─────────────────────────────────────────────────────

def generate_frontmatter(filepath: str) -> Optional[str]:
    """Generate YAML frontmatter for a memory file based on its content.
    
    Returns frontmatter string or None if file already has frontmatter.
    """
    try:
        with open(filepath, 'r') as f:
            content = f.read()
    except (IOError, OSError):
        return None
    
    # Skip if already has frontmatter
    if content.strip().startswith("---"):
        return None
    
    # Classify
    mem_type, confidence = classify_memory_type(content)
    
    # Extract a title from the first heading or filename
    title_match = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
    if title_match:
        title = title_match.group(1).strip()
    else:
        title = Path(filepath).stem.replace("-", " ").replace("_", " ").title()
    
    # Generate one-line description from first non-heading paragraph
    desc_match = re.search(r'^(?!#)(.{10,150})$', content, re.MULTILINE)
    description = desc_match.group(1).strip() if desc_match else title
    
    frontmatter = f"""---
name: {title}
description: {description[:150]}
type: {mem_type}
confidence: {confidence:.2f}
classified_at: {datetime.now().isoformat()[:19]}
---

"""
    return frontmatter


def add_frontmatter_to_file(filepath: str, dry_run: bool = False) -> Dict:
    """Add typed frontmatter to a memory file if it doesn't have one.
    
    Returns {status, type, filepath} dict.
    """
    frontmatter = generate_frontmatter(filepath)
    
    if frontmatter is None:
        return {"status": "skipped", "reason": "already_has_frontmatter", "filepath": filepath}
    
    if dry_run:
        mem_type, _ = classify_memory_type(open(filepath).read())
        return {"status": "dry_run", "type": mem_type, "filepath": filepath}
    
    with open(filepath, 'r') as f:
        content = f.read()
    
    with open(filepath, 'w') as f:
        f.write(frontmatter + content)
    
    mem_type, confidence = classify_memory_type(content)
    return {"status": "added", "type": mem_type, "confidence": confidence, "filepath": filepath}


def batch_add_frontmatter(directory: str, dry_run: bool = False) -> List[Dict]:
    """Add frontmatter to all .md files in a directory tree."""
    results = []
    for root, dirs, files in os.walk(directory):
        for f in files:
            if f.endswith(".md") and f != "MEMORY.md" and f != "MANIFEST.md":
                filepath = os.path.join(root, f)
                result = add_frontmatter_to_file(filepath, dry_run=dry_run)
                if result["status"] != "skipped":
                    results.append(result)
    return results


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Memory Intelligence Module")
    sub = parser.add_subparsers(dest="command")
    
    # classify
    cls_cmd = sub.add_parser("classify", help="Classify a memory text")
    cls_cmd.add_argument("text", help="Text to classify")
    
    # frontmatter
    fm_cmd = sub.add_parser("frontmatter", help="Add frontmatter to memory files")
    fm_cmd.add_argument("directory", help="Directory to process")
    fm_cmd.add_argument("--dry-run", action="store_true")
    
    # drift
    drift_cmd = sub.add_parser("drift", help="Check a file for drift signals")
    drift_cmd.add_argument("filepath", help="File to check")
    
    args = parser.parse_args()
    
    if args.command == "classify":
        mtype, confidence = classify_memory_type(args.text)
        print(json.dumps({"type": mtype, "confidence": confidence}))
    
    elif args.command == "frontmatter":
        results = batch_add_frontmatter(args.directory, dry_run=args.dry_run)
        added = [r for r in results if r["status"] in ("added", "dry_run")]
        types = {}
        for r in added:
            t = r.get("type", "unknown")
            types[t] = types.get(t, 0) + 1
        print(json.dumps({
            "processed": len(added),
            "types": types,
            "results": added[:20],  # Show first 20
        }, indent=2))
    
    elif args.command == "drift":
        with open(args.filepath) as f:
            text = f.read()
        signals = detect_drift_signals(text)
        print(json.dumps({"signals": signals, "count": len(signals)}, indent=2))
    
    else:
        parser.print_help()
