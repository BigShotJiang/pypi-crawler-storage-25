"""Migration CLI — upgrade free tier SQLite backends to Neo4j/Qdrant.

Reads data from SQLite-based L3 graph and L4 vector stores and writes
to production backends (Neo4j for graph, Qdrant for vectors).

Usage::

    from rewind.migrate import Migrator

    m = Migrator(sqlite_db="/data/vector.db", graph_db="/data/graph.db")
    m.migrate_graph_to_neo4j("bolt://localhost:7687", "neo4j", "password")
    m.migrate_vectors_to_qdrant("http://localhost:6333", "rewind_chunks")
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import struct
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


class Migrator:
    """Migrate free tier SQLite data to production backends."""

    def __init__(
        self,
        sqlite_db: str,
        graph_db: Optional[str] = None,
    ) -> None:
        """Initialise migrator.

        Args:
            sqlite_db: Path to the SQLite vector/chunks DB.
            graph_db: Path to the SQLite graph DB. If None, looks for
                ``graph.db`` in the same directory as sqlite_db.
        """
        self.sqlite_db = sqlite_db
        self.graph_db = graph_db or str(
            Path(sqlite_db).parent / "graph.db"
        )

    # -- Graph migration: SQLite → Neo4j ----------------------------------

    def migrate_graph_to_neo4j(
        self,
        uri: str = "bolt://localhost:7687",
        user: str = "neo4j",
        password: str = "",
        batch_size: int = 500,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Migrate L3 SQLite graph to Neo4j.

        Args:
            uri: Neo4j bolt URI.
            user: Neo4j username.
            password: Neo4j password.
            batch_size: Number of records per batch write.
            dry_run: If True, only report counts without writing.

        Returns:
            Stats dict with node/edge counts and timing.
        """
        if not os.path.exists(self.graph_db):
            return {"error": f"Graph DB not found: {self.graph_db}"}

        conn = sqlite3.connect(self.graph_db)
        conn.row_factory = sqlite3.Row

        # Count
        node_count = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
        edge_count = conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]

        if dry_run:
            conn.close()
            return {
                "dry_run": True,
                "nodes": node_count,
                "edges": edge_count,
                "source": self.graph_db,
                "target": uri,
            }

        try:
            from neo4j import GraphDatabase
        except ImportError:
            conn.close()
            return {"error": "neo4j driver not installed. Run: pip install neo4j"}

        start = time.time()
        driver = GraphDatabase.driver(uri, auth=(user, password))

        # Migrate nodes
        nodes = conn.execute(
            "SELECT id, name, label, properties_json FROM nodes"
        ).fetchall()

        nodes_written = 0
        with driver.session() as session:
            for i in range(0, len(nodes), batch_size):
                batch = nodes[i:i + batch_size]
                params = []
                for n in batch:
                    props = {}
                    try:
                        props = json.loads(n["properties_json"] or "{}")
                    except json.JSONDecodeError:
                        pass
                    params.append({
                        "sqlite_id": n["id"],
                        "name": n["name"],
                        "label": n["label"],
                        "props": props,
                    })

                session.run("""
                    UNWIND $batch AS node
                    MERGE (n:Entity {name: node.name})
                    SET n.label = node.label,
                        n.sqlite_id = node.sqlite_id,
                        n += node.props
                """, batch=params)
                nodes_written += len(batch)

            # Migrate edges
            edges = conn.execute("""
                SELECT e.id, s.name as source_name, t.name as target_name,
                       e.rel_type, e.weight
                FROM edges e
                JOIN nodes s ON e.source_id = s.id
                JOIN nodes t ON e.target_id = t.id
            """).fetchall()

            edges_written = 0
            for i in range(0, len(edges), batch_size):
                batch = edges[i:i + batch_size]
                params = [{
                    "source": e["source_name"],
                    "target": e["target_name"],
                    "rel_type": e["rel_type"] or "RELATED_TO",
                    "weight": e["weight"] or 1.0,
                } for e in batch]

                session.run("""
                    UNWIND $batch AS edge
                    MATCH (s:Entity {name: edge.source})
                    MATCH (t:Entity {name: edge.target})
                    MERGE (s)-[r:RELATED_TO {type: edge.rel_type}]->(t)
                    SET r.weight = edge.weight
                """, batch=params)
                edges_written += len(batch)

        driver.close()
        conn.close()

        elapsed = time.time() - start
        return {
            "nodes_migrated": nodes_written,
            "edges_migrated": edges_written,
            "source": self.graph_db,
            "target": uri,
            "elapsed_seconds": round(elapsed, 2),
        }

    # -- Vector migration: sqlite-vec → Qdrant ----------------------------

    def migrate_vectors_to_qdrant(
        self,
        qdrant_url: str = "http://localhost:6333",
        collection: str = "rewind_chunks",
        batch_size: int = 100,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Migrate L4 sqlite-vec vectors to Qdrant.

        Args:
            qdrant_url: Qdrant HTTP URL.
            qdrant_collection: Target collection name.
            batch_size: Points per upsert batch.
            dry_run: If True, only report counts.

        Returns:
            Stats dict.
        """
        if not os.path.exists(self.sqlite_db):
            return {"error": f"SQLite DB not found: {self.sqlite_db}"}

        conn = sqlite3.connect(self.sqlite_db)
        conn.row_factory = sqlite3.Row

        # Count chunks
        chunk_count = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]

        # Try to detect vector dimension
        dim = None
        try:
            from rewind.utils import load_vec0
            load_vec0(conn)

            row = conn.execute(
                "SELECT embedding FROM chunks_vec LIMIT 1"
            ).fetchone()
            if row and row[0]:
                blob = row[0]
                dim = len(blob) // 4  # float32
        except Exception:
            pass

        if dry_run:
            conn.close()
            return {
                "dry_run": True,
                "chunks": chunk_count,
                "dimension": dim,
                "source": self.sqlite_db,
                "target": f"{qdrant_url}/{collection}",
            }

        try:
            import httpx
        except ImportError:
            conn.close()
            return {"error": "httpx not installed. Run: pip install httpx"}

        if not dim:
            conn.close()
            return {"error": "Could not detect vector dimension. No vectors in chunks_vec?"}

        start = time.time()
        client = httpx.Client(base_url=qdrant_url, timeout=30)

        # Create collection
        try:
            client.put(f"/collections/{collection}", json={
                "vectors": {"size": dim, "distance": "Cosine"},
            })
        except Exception as exc:
            log.warning("Collection creation: %s (may already exist)", exc)

        # Read all chunks with vectors
        rows = conn.execute("""
            SELECT c.id, c.path, c.text, c.heading, c.source, c.chunk_index
            FROM chunks c
        """).fetchall()

        points_written = 0
        batch: List[Dict] = []

        for row in rows:
            chunk_id = row["id"]
            try:
                vec_row = conn.execute(
                    "SELECT embedding FROM chunks_vec WHERE rowid = ?",
                    (chunk_id,),
                ).fetchone()
                if not vec_row or not vec_row[0]:
                    continue
                blob = vec_row[0]
                vector = list(struct.unpack(f"{dim}f", blob))
            except Exception:
                continue

            batch.append({
                "id": chunk_id,
                "vector": vector,
                "payload": {
                    "path": row["path"],
                    "text": row["text"][:2000],
                    "heading": row["heading"] or "",
                    "source": row["source"] or "file",
                    "chunk_index": row["chunk_index"] or 0,
                },
            })

            if len(batch) >= batch_size:
                resp = client.put(
                    f"/collections/{collection}/points",
                    json={"points": batch},
                )
                resp.raise_for_status()
                points_written += len(batch)
                batch = []

        # Flush remaining
        if batch:
            resp = client.put(
                f"/collections/{collection}/points",
                json={"points": batch},
            )
            resp.raise_for_status()
            points_written += len(batch)

        client.close()
        conn.close()

        elapsed = time.time() - start
        return {
            "points_migrated": points_written,
            "dimension": dim,
            "source": self.sqlite_db,
            "target": f"{qdrant_url}/{collection}",
            "elapsed_seconds": round(elapsed, 2),
        }

    # -- L5 Comms migration: collection → collection -----------------------

    def migrate_comms_to_qdrant(
        self,
        source_url: str = "http://localhost:6333",
        target_url: str = "http://localhost:6333",
        source_collection: str = "conversations",
        target_collection: Optional[str] = None,
        batch_size: int = 100,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Migrate or clone a Qdrant collection (L5 comms).

        Useful for: renaming collections, migrating between Qdrant instances,
        or backing up comms data.

        Args:
            source_url: Source Qdrant URL.
            target_url: Target Qdrant URL (can be different instance).
            source_collection: Source collection name.
            target_collection: Target collection name. Defaults to source_collection.
            batch_size: Points per scroll/upsert batch.
            dry_run: If True, only report counts.
        """
        target_collection = target_collection or source_collection

        try:
            import httpx
        except ImportError:
            return {"error": "httpx not installed. Run: pip install httpx"}

        client_src = httpx.Client(base_url=source_url, timeout=30)
        try:
            info = client_src.get(f"/collections/{source_collection}").json()
            point_count = info.get("result", {}).get("points_count", 0)
            vec_config = info.get("result", {}).get("config", {}).get("params", {}).get("vectors", {})
            dim = vec_config.get("size", 0)
        except Exception as exc:
            client_src.close()
            return {"error": f"Cannot read source collection: {exc}"}

        if dry_run:
            client_src.close()
            return {
                "dry_run": True,
                "source": f"{source_url}/{source_collection}",
                "target": f"{target_url}/{target_collection}",
                "points": point_count,
                "dimension": dim,
            }

        start = time.time()
        client_tgt = httpx.Client(base_url=target_url, timeout=30)

        # Create target collection
        if source_url != target_url or source_collection != target_collection:
            try:
                client_tgt.put(f"/collections/{target_collection}", json={
                    "vectors": {"size": dim, "distance": "Cosine"},
                })
            except Exception:
                pass  # may already exist

        # Scroll and upsert
        points_written = 0
        offset = None
        while True:
            scroll_body: Dict[str, Any] = {
                "limit": batch_size,
                "with_payload": True,
                "with_vector": True,
            }
            if offset is not None:
                scroll_body["offset"] = offset

            resp = client_src.post(
                f"/collections/{source_collection}/points/scroll",
                json=scroll_body,
            )
            data = resp.json().get("result", {})
            points = data.get("points", [])
            if not points:
                break

            # Upsert to target
            upsert_points = [{
                "id": p["id"],
                "vector": p.get("vector", []),
                "payload": p.get("payload", {}),
            } for p in points]

            client_tgt.put(
                f"/collections/{target_collection}/points",
                json={"points": upsert_points},
            )
            points_written += len(points)

            offset = data.get("next_page_offset")
            if offset is None:
                break

        client_src.close()
        client_tgt.close()

        return {
            "points_migrated": points_written,
            "dimension": dim,
            "source": f"{source_url}/{source_collection}",
            "target": f"{target_url}/{target_collection}",
            "elapsed_seconds": round(time.time() - start, 2),
        }

    # -- Status ------------------------------------------------------------

    def status(self) -> Dict[str, Any]:
        """Report current data status across all stores."""
        report: Dict[str, Any] = {}

        # Chunks DB
        if os.path.exists(self.sqlite_db):
            conn = sqlite3.connect(self.sqlite_db)
            report["chunks_db"] = {
                "path": self.sqlite_db,
                "chunks": conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0],
                "size_mb": round(os.path.getsize(self.sqlite_db) / 1024 / 1024, 2),
            }
            conn.close()
        else:
            report["chunks_db"] = {"status": "not found"}

        # Graph DB
        if os.path.exists(self.graph_db):
            conn = sqlite3.connect(self.graph_db)
            report["graph_db"] = {
                "path": self.graph_db,
                "nodes": conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0],
                "edges": conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0],
                "size_mb": round(os.path.getsize(self.graph_db) / 1024 / 1024, 2),
            }
            conn.close()
        else:
            report["graph_db"] = {"status": "not found"}

        return report
