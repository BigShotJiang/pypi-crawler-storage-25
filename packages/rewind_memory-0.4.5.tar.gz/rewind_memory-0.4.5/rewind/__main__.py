"""Rewind CLI — memory stack for AI agents.

Usage:
    rewind ingest <path> [--tier free|pro|enterprise] [--db ./data/vector.db]
    rewind search <query> [--tier free|pro|enterprise] [--limit 10]
    rewind health [--tier free|pro|enterprise]
    rewind stats
"""

from __future__ import annotations

import argparse
import json
import logging
import sys


def cmd_ingest(args: argparse.Namespace) -> None:
    """Ingest files into the memory stack."""
    from rewind.config import default_config
    from rewind.ingest import IngestPipeline
    from pathlib import Path

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    pipeline = IngestPipeline(cfg)

    path = Path(args.path)
    if path.is_dir():
        stats = pipeline.ingest_directory(str(path))
    elif path.is_file():
        stats = pipeline.ingest_file(str(path))
    else:
        print(f"Error: {args.path} not found", file=sys.stderr)
        sys.exit(1)

    pipeline.close()

    # Print summary
    print(f"Files:    {stats.get('files', 1)}")
    print(f"Chunks:   {stats.get('chunks', 0)}")
    print(f"Vectors:  {stats.get('vectors', 0)}")
    print(f"Entities: {stats.get('entities', 0)}")
    if "elapsed_seconds" in stats:
        print(f"Time:     {stats['elapsed_seconds']}s")
    if stats.get("errors"):
        print(f"Errors:   {stats['errors']}")


def cmd_search(args: argparse.Namespace) -> None:
    """Search the memory stack."""
    from rewind.client import RewindClient
    from rewind.config import default_config

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    client = RewindClient(cfg)
    results = client.search(args.query, limit=args.limit)
    client.close()

    if not results:
        print("No results found.")
        return

    if args.json:
        print(json.dumps([{
            "score": r.score, "layer": r.layer,
            "path": r.path, "text": r.text[:200],
        } for r in results], indent=2))
    else:
        for i, r in enumerate(results, 1):
            print(f"\n{'─' * 60}")
            print(f"  #{i}  score={r.score:.3f}  layer={r.layer}")
            if r.path:
                print(f"  path: {r.path}")
            print(f"  {r.text[:200]}")


def cmd_health(args: argparse.Namespace) -> None:
    """Health check."""
    from rewind.client import RewindClient
    from rewind.config import default_config

    cfg = default_config(args.tier)
    if args.db:
        cfg.vector_db_path = args.db

    client = RewindClient(cfg)
    health = client.health()
    client.close()

    print(f"Tier:         {health['tier']}")
    print(f"Orchestrator: {'✅' if health['orchestrator'] else '❌'}")
    print(f"Pro plugin:   {'✅' if health.get('pro_installed') else '❌ (Free tier)'}")
    print(f"Healthy:      {'✅' if health['healthy'] else '❌'}")
    print()
    for name, status in health.get("layers", {}).items():
        s = status.get("status", "unknown")
        icon = "✅" if s == "ok" else "❌" if s == "error" else "⚠️"
        extra = ""
        if "nodes" in status:
            extra = f" ({status['nodes']} nodes, {status.get('edges', 0)} edges)"
        elif "total_chunks" in status:
            extra = f" ({status['total_chunks']} chunks)"
        elif "backend" in status:
            extra = f" ({status['backend']})"
        print(f"  {icon} {name}: {s}{extra}")


def cmd_migrate(args: argparse.Namespace) -> None:
    """Migrate SQLite backends to Neo4j/Qdrant."""
    from rewind.migrate import Migrator

    db = args.db or "./data/vector.db"
    migrator = Migrator(sqlite_db=db)

    if args.subcmd == "status":
        import json
        print(json.dumps(migrator.status(), indent=2))
        return

    if args.subcmd == "graph":
        result = migrator.migrate_graph_to_neo4j(
            uri=args.uri or "bolt://localhost:7687",
            user=args.user or "neo4j",
            password=args.password or "",
            dry_run=args.dry_run,
        )
    elif args.subcmd == "vectors":
        result = migrator.migrate_vectors_to_qdrant(
            qdrant_url=args.uri or "http://localhost:6333",
            collection=args.collection or "rewind_chunks",
            dry_run=args.dry_run,
        )
    else:
        print("Usage: rewind migrate {status|graph|vectors}", file=sys.stderr)
        sys.exit(1)

    if "error" in result:
        print(f"Error: {result['error']}", file=sys.stderr)
        sys.exit(1)

    import json
    print(json.dumps(result, indent=2))


def cmd_proxy(args) -> None:
    """Start memory proxy."""
    from rewind.proxy import main as proxy_main
    import sys
    # Rebuild argv for proxy's own parser
    sys.argv = ["rewind-proxy",
                "--port", str(args.port),
                "--host", args.host,
                "--upstream", args.upstream]
    if args.upstream_key:
        sys.argv += ["--upstream-key", args.upstream_key]
    if args.proxy_db:
        sys.argv += ["--db", args.proxy_db]
    if args.no_auto_store:
        sys.argv.append("--no-auto-store")
    proxy_main()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="rewind",
        description="Rewind — bio-inspired memory stack for AI agents",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable debug logging",
    )

    sub = parser.add_subparsers(dest="command")

    # ingest
    p_ingest = sub.add_parser("ingest", help="Ingest files into memory")
    p_ingest.add_argument("path", help="File or directory to ingest")
    p_ingest.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_ingest.add_argument("--db", default=None, help="Path to vector DB")

    # search
    p_search = sub.add_parser("search", help="Search memory")
    p_search.add_argument("query", help="Search query")
    p_search.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_search.add_argument("--db", default=None, help="Path to vector DB")
    p_search.add_argument("--limit", type=int, default=10)
    p_search.add_argument("--json", action="store_true", help="Output JSON")

    # health
    p_health = sub.add_parser("health", help="Health check")
    p_health.add_argument("--tier", default="free", choices=["free", "pro", "enterprise"])
    p_health.add_argument("--db", default=None, help="Path to vector DB")

    # migrate
    p_proxy = sub.add_parser("proxy", help="Memory proxy — auto-inject memory into LLM calls")
    p_proxy.add_argument("--port", type=int, default=8080, help="Port (default: 8080)")
    p_proxy.add_argument("--host", default="127.0.0.1", help="Host (default: 127.0.0.1)")
    p_proxy.add_argument("--upstream", default="https://api.openai.com/v1",
                         help="Upstream LLM API URL")
    p_proxy.add_argument("--upstream-key", default="", help="Upstream API key")
    p_proxy.add_argument("--db", default=None, dest="proxy_db", help="Rewind database path")
    p_proxy.add_argument("--no-auto-store", action="store_true", help="Disable auto fact extraction")

    # serve (alias for proxy)
    p_serve = sub.add_parser("serve", help="Start memory API server (alias for proxy)")
    p_serve.add_argument("--port", type=int, default=8080, help="Port (default: 8080)")
    p_serve.add_argument("--host", default="127.0.0.1", help="Host (default: 127.0.0.1)")
    p_serve.add_argument("--upstream", default="https://api.openai.com/v1",
                         help="Upstream LLM API URL")
    p_serve.add_argument("--upstream-key", default="", help="Upstream API key")
    p_serve.add_argument("--db", default=None, dest="proxy_db", help="Rewind database path")
    p_serve.add_argument("--no-auto-store", action="store_true", help="Disable auto fact extraction")

    p_migrate = sub.add_parser("migrate", help="Migrate backends (Pro)")
    p_migrate.add_argument("subcmd", choices=["status", "graph", "vectors"],
                           help="Migration target")
    p_migrate.add_argument("--db", default=None, help="Path to SQLite DB")
    p_migrate.add_argument("--uri", default=None, help="Target URI (bolt:// or http://)")
    p_migrate.add_argument("--user", default="neo4j", help="Neo4j username")
    p_migrate.add_argument("--password", default="", help="Neo4j password")
    p_migrate.add_argument("--collection", default="rewind_chunks", help="Qdrant collection")
    p_migrate.add_argument("--dry-run", action="store_true", help="Report only, don't write")

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(name)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    if args.command == "ingest":
        cmd_ingest(args)
    elif args.command == "search":
        cmd_search(args)
    elif args.command == "health":
        cmd_health(args)
    elif args.command in ("proxy", "serve"):
        cmd_proxy(args)
    elif args.command == "migrate":
        cmd_migrate(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
