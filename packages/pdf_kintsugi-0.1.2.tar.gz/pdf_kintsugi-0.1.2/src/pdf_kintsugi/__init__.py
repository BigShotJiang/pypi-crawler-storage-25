"""pdf-kintsugi - Enhanced PDF table extraction with Docling and pdfplumber."""

from pdf_kintsugi.parser import PDFKintsugi

__version__ = "0.1.0"
__all__ = ["PDFKintsugi"]
