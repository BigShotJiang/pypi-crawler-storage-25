def is_same(coord1: float, coord2: float, tolerance=3.0):
    return abs(coord1 - coord2) < tolerance
