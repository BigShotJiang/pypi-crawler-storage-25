#
#  Copyright (c) 2018-2026 EPAM Systems Inc.
#
import os

from pydantic import ValidationError
from ruamel.yaml import YAML
from semver import VersionInfo as SemVerInfo

from aos_signer.cloud_common.schemas.v2.cloud_income import AosUploadMetaConfig
from aos_signer.signer.common import print_message
from aos_signer.signer.errors import SignerConfigError


CONFIG_NOT_FOUND_HELP = [  # noqa: WPS407
    "If you have configured bundle, run aos-signer tool from the bundle root directory (where config.yaml is located)",
    "If you are configuring service for the first time, run 'aos-signer init' first",
]


class UpdateBundleConfiguration:

    DEFAULT_CONFIG_FILE_NAME = 'config.yaml'

    def __init__(self, file_path=None):
        self._config_path = file_path

        if file_path is None:
            file_path = self.DEFAULT_CONFIG_FILE_NAME

        if not os.path.isfile(file_path):
            raise SignerConfigError(f'Config file {file_path} not found. Exiting...', CONFIG_NOT_FOUND_HELP)

        yaml = YAML()
        print_message('[bright_black]Starting CONFIG VALIDATION process...')
        print_message('Validating config...           ', end='')
        with open(file_path, 'r', encoding='utf-8') as meta_file:
            try:
                loaded_config = yaml.load(meta_file)
                self.upload_meta_config = AosUploadMetaConfig.model_validate(loaded_config)

                for config_item in self.upload_meta_config.items:
                    if config_item.configuration and config_item.configuration.skip_resource_limits:
                        publish_version = config_item.version
                        if not SemVerInfo.parse(publish_version).prerelease:
                            raise ValidationError(
                                f'Cannot ignore resource limits due to version: {publish_version} is not pre-release',
                            )

                print_message('[green]VALID')
            except (ValidationError, Exception) as exc:
                print_message('[red]ERROR')
                raise SignerConfigError(str(exc)) from exc

    @property
    def config_path(self):
        return self._config_path
