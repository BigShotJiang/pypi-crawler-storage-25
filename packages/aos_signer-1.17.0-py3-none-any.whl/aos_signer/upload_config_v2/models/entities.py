#
#  Copyright (c) 2018-2025 Renesas Inc.
#  Copyright (c) 2018-2025 EPAM Systems Inc.
#


from typing import Dict, List, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


PermissionMode = Literal["r", "w", "rw"]


class AosBaseModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)


class AosAlertRulePercents(AosBaseModel):
    """Schema alert triggering procedure in percents."""

    min_timeout: Optional[str] = Field(alias="minTimeout")
    min_threshold: Optional[float] = Field(alias="minThreshold")
    max_threshold: Optional[float] = Field(alias="maxThreshold")


class AosAlertRulePoints(AosBaseModel):
    """Schema alert triggering procedure (points)."""

    min_timeout: Optional[str] = Field(alias="minTimeout")
    min_threshold: Optional[int] = Field(alias="minThreshold")
    max_threshold: Optional[int] = Field(alias="maxThreshold")


class AosAlertRules(AosBaseModel):
    """Schema for all possible alert rules."""

    ram: Optional[AosAlertRulePercents] = None
    cpu: Optional[AosAlertRulePercents] = None
    storage: Optional[AosAlertRulePercents] = None
    upload: Optional[AosAlertRulePoints] = None
    download: Optional[AosAlertRulePoints] = None


class AosArchInfo(AosBaseModel):
    architecture: str
    variant: Optional[str] = None


class AosOsInfo(AosBaseModel):
    os: str
    version: Optional[str] = None
    features: Optional[List[str]] = None


class AosPublisher(AosBaseModel):
    author: Optional[str] = None
    company: Optional[str] = None


class AosPublish(AosBaseModel):
    tls_key: str = Field(alias="tlsKey")
    sign_key: Optional[str] = Field(default=None, alias="signKey")
    domain: Optional[str] = None


class AosQuotas(AosBaseModel):
    cpu_limit: Optional[int] = Field(default=None, alias="cpuLimit")
    ram_limit: Optional[int] = Field(default=None, alias="ramLimit")
    storage_limit: Optional[int] = Field(default=None, alias="storageLimit")
    state_limit: Optional[int] = Field(default=None, alias="stateLimit")
    tmp_limit: Optional[int] = Field(default=None, alias="tmpLimit")
    upload_speed: Optional[int] = Field(default=None, alias="uploadSpeed")
    download_speed: Optional[int] = Field(default=None, alias="downloadSpeed")
    no_file_limit: Optional[int] = Field(default=None, alias="noFileLimit")
    pids_limit: Optional[int] = Field(default=None, alias="pidsLimit")


class AosResourceAccess(AosBaseModel):
    name: str
    mode: PermissionMode = "r"


class AosRunParameters(AosBaseModel):
    start_interval: Optional[str] = Field(default=None, alias="startInterval")
    start_burst: Optional[int] = Field(default=None, alias="startBurst")
    restart_interval: Optional[str] = Field(default=None, alias="restartInterval")


class AosInstancesInfo(AosBaseModel):
    min_instances: int = Field(
        1, alias="minInstances", ge=1, le=100
    )  # exclusiveMinimum 1 + maximum 100
    priority: int = Field(0, ge=0)
    labels: Optional[List[str]] = None


class AosIdentity(AosBaseModel):
    id: Optional[UUID] = None
    type: Optional[
        Literal[
            "component",
            "service",
            "layer",
            "subject",
            "oem",
            "sp",
            "node",
            "runtime",
        ]
    ] = None
    version: Optional[str] = None  # TODO: recheck this
    codename: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    urn: Optional[str] = None


class AosDependency(AosBaseModel):
    identity: AosIdentity
    versions: str
    include_pre_release: bool = Field(
        default=False,
        alias="includePreRelease",
    )
    condition: Literal["started", "healthy", "completed", "before", "after"] = "completed"


class AosImage(AosBaseModel):
    source_folder: str = Field(alias="sourceFolder")
    os_info: AosOsInfo = Field(
        default_factory=lambda: AosOsInfo(os="Linux"),
        alias="osInfo",
    )
    arch_info: AosArchInfo = Field(alias="archInfo")
    env: Optional[List[str]] = None
    working_dir: Optional[str] = Field(default=None, alias="workingDir")
    cmd: Optional[str] = None


class AosUpdateItemConfiguration(AosBaseModel):
    env: Optional[List[str]] = None
    working_dir: Optional[str] = Field(default=None, alias="workingDir")
    instances: Optional[AosInstancesInfo] = None
    cmd: Optional[str] = None
    skip_resource_limits: bool = Field(
        default=False,
        alias="skipResourceLimits",
    )
    balancing_policy: Literal["enabled", "disabled"] = Field(
        default="enabled",
        alias="balancingPolicy",
    )
    base_layer_is_node_rootfs: Optional[bool] = Field(
        default=True,
        alias="baseLayerIsNodeRootfs",
    )
    hostname: Optional[str] = None
    exposed_ports: Optional[List[int]] = Field(default=None, alias="exposedPorts")
    runtimes: Optional[List[AosIdentity]] = None
    run_parameters: Optional[AosRunParameters] = Field(
        default=None,
        alias="runParameters",
    )
    offline_ttl: Optional[str] = Field(default=None, alias="offlineTTL")
    resources: Optional[List[AosResourceAccess]] = None
    allowed_connections: Optional[List[str]] = Field(
        default=None,
        alias="allowedConnections",
    )
    quotas: Optional[AosQuotas] = None
    alert_rules: Optional[AosAlertRules] = Field(
        default=None,
        alias="alertRules",
    )
    permissions: Optional[Dict[str, Dict[str, PermissionMode]]] = None


class AosUpdateItem(AosBaseModel):
    identity: AosIdentity
    source_folder: Optional[str] = Field(default=None, alias="sourceFolder")
    images: List[AosImage]
    configuration: Optional[AosUpdateItemConfiguration] = None
    dependencies: Optional[List[AosDependency]] = None


class AosUploadMetaConfig(AosBaseModel):
    schema_version: int = Field(
        default=2,
        alias="schemaVersion",
    )
    publisher: Optional[AosPublisher] = None
    publish: Optional[AosPublish]
    items: List[AosUpdateItem]
