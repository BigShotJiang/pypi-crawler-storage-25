from __future__ import annotations

import asyncio
import importlib.util
import py_compile
import subprocess
import sys
import tomllib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "src/agilab/apps/install.py"
BUILTIN_APPS_ROOT = ROOT / "src/agilab/apps/builtin"
APP_TEMPLATES_ROOT = ROOT / "src/agilab/apps/templates"
EXAMPLES_ROOT = ROOT / "src/agilab/examples"
EXAMPLE_APPS = {
    "data_io_2026": ("AGI_install_data_io_2026.py", "AGI_run_data_io_2026.py"),
    "flight": ("AGI_install_flight.py", "AGI_run_flight.py"),
    "meteo_forecast": ("AGI_install_meteo_forecast.py", "AGI_run_meteo_forecast.py"),
    "mycode": ("AGI_install_mycode.py", "AGI_run_mycode.py"),
}
EXAMPLE_PREVIEWS = {
    "inter_project_dag": ("preview_inter_project_dag.py", "flight_to_meteo_dag.json"),
    "notebook_to_dask": (
        "preview_notebook_to_dask.py",
        "notebook_to_dask_sample.ipynb",
        "lab_steps.toml",
        "pipeline_view.json",
    ),
    "service_mode": ("preview_service_mode.py", "sample_health_running.json"),
}
APP_SOURCE_SUFFIXES = {
    ".7z",
    ".csv",
    ".dot",
    ".ipynb",
    ".json",
    ".md",
    ".py",
    ".toml",
    ".txt",
}
APP_GENERATED_NAMES = {".coverage", ".DS_Store", "uv.lock"}
APP_GENERATED_DIRS = {
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "Modules",
    "agilab",
    "build",
    "dist",
}
APP_GENERATED_SUFFIXES = {".c", ".pyc", ".pyo", ".pyx", ".so"}


def _expected_script_paths() -> list[Path]:
    return sorted(
        EXAMPLES_ROOT / example_name / script_name
        for example_name, script_names in EXAMPLE_APPS.items()
        for script_name in script_names
    )


def _load_installer(monkeypatch, tmp_path: Path):
    sys.modules.pop("agilab_app_install_test_module", None)
    app_path = tmp_path / "demo_project"
    app_path.mkdir()
    monkeypatch.setattr(sys, "argv", ["install.py", str(app_path)])
    spec = importlib.util.spec_from_file_location("agilab_app_install_test_module", MODULE_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _builtin_app_dirs() -> list[Path]:
    return sorted(path for path in BUILTIN_APPS_ROOT.glob("*_project") if path.is_dir())


def _packaged_app_dirs() -> list[Path]:
    return [
        *_builtin_app_dirs(),
        *sorted(path for path in APP_TEMPLATES_ROOT.glob("*_template") if path.is_dir()),
    ]


def _git_paths(*args: str) -> set[str]:
    result = subprocess.run(
        ["git", *args],
        cwd=ROOT,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
    )
    return {line for line in result.stdout.splitlines() if line}


def _is_source_like_app_file(app_dir: Path, path: Path) -> bool:
    rel_parts = path.relative_to(app_dir).parts
    if path.name in APP_GENERATED_NAMES:
        return False
    if path.suffix in APP_GENERATED_SUFFIXES:
        return False
    if any(part in APP_GENERATED_DIRS or part.endswith(".egg-info") for part in rel_parts):
        return False
    return path.name == ".gitignore" or path.suffix in APP_SOURCE_SUFFIXES


def test_packaged_apps_include_required_project_assets() -> None:
    missing: list[str] = []
    for app_dir in _packaged_app_dirs():
        for rel_path in (
            "README.md",
            "pyproject.toml",
            "src/app_args_form.py",
            "src/app_settings.toml",
            "src/pre_prompt.json",
        ):
            candidate = app_dir / rel_path
            if not candidate.is_file():
                missing.append(candidate.relative_to(ROOT).as_posix())

    assert not missing, "Missing packaged app project assets:\n" + "\n".join(missing)


def test_packaged_app_source_assets_are_tracked_or_git_visible() -> None:
    tracked = _git_paths("ls-files")
    visible_untracked = _git_paths("ls-files", "--others", "--exclude-standard")
    git_visible = tracked | visible_untracked

    hidden_or_untracked: list[str] = []
    for app_dir in _packaged_app_dirs():
        for path in sorted(candidate for candidate in app_dir.rglob("*") if candidate.is_file()):
            if not _is_source_like_app_file(app_dir, path):
                continue
            rel_path = path.relative_to(ROOT).as_posix()
            if rel_path not in git_visible:
                hidden_or_untracked.append(rel_path)

    assert not hidden_or_untracked, (
        "Packaged app source assets are hidden by .gitignore or unavailable to git:\n"
        + "\n".join(hidden_or_untracked)
    )


def test_seed_example_scripts_uses_packaged_examples_dir(tmp_path: Path, monkeypatch) -> None:
    module = _load_installer(monkeypatch, tmp_path)
    package_root = tmp_path / "site-packages" / "agilab"
    examples_dir = package_root / "examples" / "flight"
    examples_dir.mkdir(parents=True)
    (examples_dir / "AGI_install_flight.py").write_text("# install\n", encoding="utf-8")
    (examples_dir / "AGI_run_flight.py").write_text("# run\n", encoding="utf-8")
    monkeypatch.setattr(module, "_package_root", lambda: package_root)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))

    module._seed_example_scripts("flight")

    execute_dir = tmp_path / "home" / "log" / "execute" / "flight"
    assert (execute_dir / "AGI_install_flight.py").read_text(encoding="utf-8") == "# install\n"
    assert (execute_dir / "AGI_run_flight.py").read_text(encoding="utf-8") == "# run\n"


def test_app_dir_candidates_prefer_packaged_builtin_apps(tmp_path: Path, monkeypatch) -> None:
    module = _load_installer(monkeypatch, tmp_path)
    package_root = tmp_path / "site-packages" / "agilab"
    monkeypatch.setattr(module, "_package_root", lambda: package_root)

    assert module._app_dir_candidates("flight") == [
        package_root / "apps" / "builtin" / "flight_project",
        package_root / "apps" / "flight_project",
    ]


def test_packaged_agi_example_scripts_are_compile_safe() -> None:
    scripts = sorted(EXAMPLES_ROOT.glob("*/AGI_*.py"))

    assert scripts
    for script in scripts:
        py_compile.compile(str(script), doraise=True)


def test_packaged_agi_example_scripts_avoid_cython_first_run_mode() -> None:
    scripts = sorted(EXAMPLES_ROOT.glob("*/AGI_*.py"))

    assert scripts
    for script in scripts:
        text = script.read_text(encoding="utf-8")
        assert "AGI.CYTHON_MODE" not in text


def test_packaged_preview_example_scripts_are_compile_safe() -> None:
    scripts = [
        EXAMPLES_ROOT / example_name / script_name
        for example_name, script_names in EXAMPLE_PREVIEWS.items()
        for script_name in script_names
        if script_name.endswith(".py")
    ]

    assert scripts
    for script in scripts:
        py_compile.compile(str(script), doraise=True)


def test_packaged_agi_example_catalog_matches_seeded_scripts() -> None:
    scripts = sorted(EXAMPLES_ROOT.glob("*/AGI_*.py"))

    assert scripts == _expected_script_paths()


def test_packaged_example_catalog_is_documented() -> None:
    catalog = EXAMPLES_ROOT / "README.md"
    assert catalog.is_file()
    catalog_text = catalog.read_text(encoding="utf-8")
    assert "## Learning Path" in catalog_text
    assert "## What To Notice" in catalog_text
    assert "## How To Read An Example" in catalog_text

    for example_name, script_names in EXAMPLE_APPS.items():
        example_dir = EXAMPLES_ROOT / example_name
        readme = example_dir / "README.md"
        assert readme.is_file()
        readme_text = readme.read_text(encoding="utf-8")
        assert example_name in catalog_text
        for script_name in script_names:
            assert (example_dir / script_name).is_file()
            assert script_name in readme_text
        for heading in (
            "## Purpose",
            "## What You Learn",
            "## Install",
            "## Run",
            "## Expected Input",
            "## Expected Output",
            "## Read The Script",
            "## Change One Thing",
            "## Troubleshooting",
        ):
            assert heading in readme_text

    for example_name, file_names in EXAMPLE_PREVIEWS.items():
        example_dir = EXAMPLES_ROOT / example_name
        readme = example_dir / "README.md"
        assert readme.is_file()
        readme_text = readme.read_text(encoding="utf-8")
        assert example_name in catalog_text
        for file_name in file_names:
            assert (example_dir / file_name).is_file()
            assert file_name in readme_text
        for heading in (
            "## Purpose",
            "## What You Learn",
            "## Install",
            "## Run",
            "## Expected Input",
            "## Expected Output",
            "## Read The Script",
            "## Change One Thing",
            "## Troubleshooting",
        ):
            assert heading in readme_text


def test_packaged_example_readmes_teach_safe_adaptation() -> None:
    for example_name in EXAMPLE_APPS:
        readme_text = (EXAMPLES_ROOT / example_name / "README.md").read_text(encoding="utf-8")

        assert "RunRequest" in readme_text
        assert "Change One Thing" in readme_text
        assert "Troubleshooting" in readme_text
        assert "Expected Output" in readme_text


def test_packaged_example_readmes_are_included_as_package_data() -> None:
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    package_data = pyproject["tool"]["setuptools"]["package-data"]["agilab"]

    assert "examples/README.md" in package_data
    assert "examples/*/README.md" in package_data
    assert "examples/*/AGI_*.py" in package_data
    assert "examples/inter_project_dag/*.py" in package_data
    assert "examples/inter_project_dag/*.json" in package_data
    assert "examples/notebook_to_dask/*.py" in package_data
    assert "examples/notebook_to_dask/*.json" in package_data
    assert "examples/notebook_to_dask/*.toml" in package_data
    assert "examples/notebook_to_dask/*.ipynb" in package_data
    assert "examples/notebook_migrations/*/README.md" in package_data
    assert "examples/notebook_migrations/*/analysis_artifacts/*.csv" in package_data
    assert "examples/notebook_migrations/*/analysis_artifacts/*.json" in package_data
    assert "examples/notebook_migrations/*/data/*.csv" in package_data
    assert "examples/notebook_migrations/*/migrated_project/*.dot" in package_data
    assert "examples/notebook_migrations/*/migrated_project/*.toml" in package_data
    assert "examples/notebook_migrations/*/notebooks/*.ipynb" in package_data
    assert "examples/service_mode/*.py" in package_data
    assert "examples/service_mode/*.json" in package_data


def test_packaged_builtin_app_prompt_seeds_are_included_as_package_data() -> None:
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    package_data = pyproject["tool"]["setuptools"]["package-data"]["agilab"]
    excluded_data = pyproject["tool"]["setuptools"]["exclude-package-data"]["agilab"]

    assert "apps/builtin/*/src/*.json" in package_data
    assert "apps/builtin/*/src/pre_prompt.json" not in excluded_data


def test_inter_project_dag_preview_builds_read_only_runner_state(tmp_path: Path) -> None:
    script = EXAMPLES_ROOT / "inter_project_dag" / "preview_inter_project_dag.py"
    module_name = "agilab_inter_project_dag_preview_test_module"
    sys.modules.pop(module_name, None)
    spec = importlib.util.spec_from_file_location(module_name, script)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    summary = module.build_preview(
        repo_root=ROOT,
        dag_path=EXAMPLES_ROOT / "inter_project_dag" / "flight_to_meteo_dag.json",
        output_path=tmp_path / "runner_state.json",
        now="2026-04-29T00:00:00Z",
    )

    assert summary["example"] == "inter_project_dag"
    assert summary["dag"]["ok"] is True
    assert summary["dag"]["execution_order"] == ["flight_context", "meteo_forecast_review"]
    assert summary["units"] == [
        {
            "app": "flight_project",
            "depends_on": [],
            "dispatch_status": "runnable",
            "id": "flight_context",
            "produces": ["flight_reduce_summary"],
        },
        {
            "app": "meteo_forecast_project",
            "depends_on": ["flight_context"],
            "dispatch_status": "blocked",
            "id": "meteo_forecast_review",
            "produces": ["forecast_metrics"],
        },
    ]
    assert summary["artifact_handoffs"] == [
        {
            "artifact": "flight_reduce_summary",
            "from": "flight_context",
            "from_app": "flight_project",
            "handoff": "Use flight trajectory reduce summary as the forecast-review context.",
            "producer_status": "runnable",
            "source_path": "flight_analysis/reduce_summary_worker_0.json",
            "to": "meteo_forecast_review",
            "to_app": "meteo_forecast_project",
        }
    ]
    assert summary["runner_state"]["round_trip_ok"] is True
    assert summary["runner_state"]["summary"]["runnable_unit_ids"] == ["flight_context"]
    assert summary["runner_state"]["summary"]["blocked_unit_ids"] == ["meteo_forecast_review"]
    assert summary["after_first_dispatch"]["dispatched_unit_id"] == "flight_context"
    assert summary["after_first_dispatch"]["run_status"] == "running"
    assert summary["real_app_execution"] is False
    assert (tmp_path / "runner_state.json").is_file()


def test_service_mode_preview_builds_health_gate_operator_summary(tmp_path: Path) -> None:
    script = EXAMPLES_ROOT / "service_mode" / "preview_service_mode.py"
    module_name = "agilab_service_mode_preview_test_module"
    sys.modules.pop(module_name, None)
    spec = importlib.util.spec_from_file_location(module_name, script)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    summary = module.build_preview(
        health_payload_path=EXAMPLES_ROOT / "service_mode" / "sample_health_running.json",
        output_path=tmp_path / "service_operator_preview.json",
    )

    assert summary["example"] == "service_mode"
    assert summary["target_app"] == "mycode_project"
    assert [step["action"] for step in summary["operator_sequence"]] == [
        "start",
        "status",
        "health",
        "stop",
    ]
    assert summary["health_gate"] == {
        "details": {
            "restart_rate": 0.0,
            "status": "running",
            "workers_restarted_count": 0,
            "workers_running_count": 1,
            "workers_unhealthy_count": 0,
        },
        "ok": True,
        "reason": "ok",
        "thresholds": {
            "allow_idle": False,
            "max_restart_rate": 0.25,
            "max_unhealthy": 0,
        },
    }
    assert summary["artifacts"]["health_json"] == "service/mycode/health.json"
    assert summary["real_service_execution"] is False
    assert (tmp_path / "service_operator_preview.json").is_file()


def test_notebook_to_dask_preview_builds_migration_contract(tmp_path: Path) -> None:
    script = EXAMPLES_ROOT / "notebook_to_dask" / "preview_notebook_to_dask.py"
    module_name = "agilab_notebook_to_dask_preview_test_module"
    sys.modules.pop(module_name, None)
    spec = importlib.util.spec_from_file_location(module_name, script)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    summary = module.build_preview(output_path=tmp_path / "notebook_to_dask_preview.json")

    assert summary["example"] == "notebook_to_dask"
    assert summary["notebook_import"]["execution_mode"] == "not_executed_import"
    assert summary["notebook_import"]["summary"]["pipeline_step_count"] == 3
    assert summary["notebook_import"]["env_hints"] == ["dask", "json", "pandas", "pathlib"]
    assert summary["artifact_contract"] == {
        "analysis_consumes": [
            "artifacts/daily_orders.parquet",
            "artifacts/dask_summary.json",
        ],
        "inputs": ["data/orders.csv"],
        "outputs": [
            "artifacts/daily_orders.parquet",
            "artifacts/dask_summary.json",
        ],
    }
    assert summary["dask_solution"]["engine"] == "dask.dataframe"
    assert summary["dask_solution"]["step_ids"] == ["cell-4", "cell-6"]
    assert summary["dask_solution"]["real_execution"] is False
    assert summary["lab_steps_preview"]["matches_generated"] is True
    assert summary["pipeline_view"]["node_count"] == 4
    assert (tmp_path / "notebook_to_dask_preview.json").is_file()


def test_service_mode_health_gate_rejects_non_running_service() -> None:
    script = EXAMPLES_ROOT / "service_mode" / "preview_service_mode.py"
    module_name = "agilab_service_mode_preview_health_test_module"
    sys.modules.pop(module_name, None)
    spec = importlib.util.spec_from_file_location(module_name, script)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    stopped = module.evaluate_health_gate({"status": "stopped", "workers_running_count": 0})
    running_without_workers = module.evaluate_health_gate(
        {"status": "running", "workers_running_count": 0}
    )
    unhealthy = module.evaluate_health_gate(
        {
            "status": "running",
            "workers_running_count": 1,
            "workers_unhealthy_count": 1,
        }
    )

    assert stopped["ok"] is False
    assert stopped["reason"] == "service status is stopped"
    assert running_without_workers["ok"] is False
    assert running_without_workers["reason"] == "service has no running workers"
    assert unhealthy["ok"] is False
    assert unhealthy["reason"] == "unhealthy workers 1 exceeds limit 0"


def test_packaged_examples_avoid_magic_mode_literals() -> None:
    magic_mode_fragments = ("mode=13", "mode=15", "modes_enabled=13", "modes_enabled=15")
    scripts = sorted(EXAMPLES_ROOT.glob("*/AGI_*.py"))

    assert scripts
    for script in scripts:
        text = script.read_text(encoding="utf-8")
        for fragment in magic_mode_fragments:
            assert fragment not in text


def test_packaged_examples_use_public_api_and_modern_runner() -> None:
    for script in _expected_script_paths():
        text = script.read_text(encoding="utf-8")

        assert "AGI._" not in text
        assert "asyncio.get_event_loop()" not in text
        assert "asyncio.run(main())" in text
        assert "def agilab_apps_path() -> Path:" in text
        assert "open(f\"{Path.home()}" not in text


def test_packaged_builtin_examples_resolve_builtin_apps_root() -> None:
    stale_root = 'return Path(marker.read_text(encoding="utf-8").strip()) / "apps"\n'
    current_root = 'return Path(marker.read_text(encoding="utf-8").strip()) / "apps" / "builtin"'

    for script in _expected_script_paths():
        text = script.read_text(encoding="utf-8")

        assert current_root in text
        assert stale_root not in text


def test_seed_example_scripts_refreshes_stale_builtin_helper(tmp_path: Path, monkeypatch) -> None:
    module = _load_installer(monkeypatch, tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path))
    destination = tmp_path / "log" / "execute" / "flight" / "AGI_run_flight.py"
    destination.parent.mkdir(parents=True)
    destination.write_text(
        "\n".join(
            [
                "from pathlib import Path",
                "",
                "def agilab_apps_path() -> Path:",
                '    marker = Path.home() / ".local/share/agilab/.agilab-path"',
                '    return Path(marker.read_text(encoding="utf-8").strip()) / "apps"',
                "",
            ]
        ),
        encoding="utf-8",
    )

    module._seed_example_scripts("flight")

    text = destination.read_text(encoding="utf-8")
    assert ' / "apps" / "builtin"' in text
    assert text == (EXAMPLES_ROOT / "flight" / "AGI_run_flight.py").read_text(encoding="utf-8")


def test_packaged_run_and_install_examples_import_with_fake_home(tmp_path: Path, monkeypatch) -> None:
    agilab_path = tmp_path / ".local" / "share" / "agilab"
    agilab_path.mkdir(parents=True)
    (agilab_path / ".agilab-path").write_text(str(ROOT / "src/agilab"), encoding="utf-8")
    monkeypatch.setenv("HOME", str(tmp_path))

    scripts = sorted(
        script
        for script in EXAMPLES_ROOT.glob("*/AGI_*.py")
        if script.name.startswith(("AGI_install_", "AGI_run_"))
    )

    assert scripts
    for script in scripts:
        module_name = f"agilab_example_{script.parent.name}_{script.stem}"
        sys.modules.pop(module_name, None)
        spec = importlib.util.spec_from_file_location(module_name, script)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        assert callable(module.main)


def test_packaged_examples_fail_cleanly_without_agilab_marker(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))

    for script in _expected_script_paths():
        module_name = f"agilab_example_missing_marker_{script.parent.name}_{script.stem}"
        sys.modules.pop(module_name, None)
        spec = importlib.util.spec_from_file_location(module_name, script)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        try:
            module.agilab_apps_path()
        except SystemExit as exc:
            assert "AGILAB is not initialized" in str(exc)
        else:
            raise AssertionError(f"{script} did not fail cleanly without .agilab-path")


def test_packaged_example_main_bodies_build_public_requests(tmp_path: Path, monkeypatch) -> None:
    agilab_path = tmp_path / ".local" / "share" / "agilab"
    agilab_path.mkdir(parents=True)
    (agilab_path / ".agilab-path").write_text(str(ROOT / "src/agilab"), encoding="utf-8")
    monkeypatch.setenv("HOME", str(tmp_path))

    for script in _expected_script_paths():
        calls: dict[str, object] = {}

        class FakeEnv:
            def __init__(self, **kwargs):
                calls["env_kwargs"] = kwargs

        class FakeAGI:
            @staticmethod
            async def install(env, **kwargs):
                calls["operation"] = "install"
                calls["env"] = env
                calls["kwargs"] = kwargs
                return {"ok": True, "operation": "install"}

            @staticmethod
            async def run(env, request):
                calls["operation"] = "run"
                calls["env"] = env
                calls["request"] = request
                return {"ok": True, "operation": "run"}

        module_name = f"agilab_example_main_{script.parent.name}_{script.stem}"
        sys.modules.pop(module_name, None)
        spec = importlib.util.spec_from_file_location(module_name, script)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        module.AgiEnv = FakeEnv
        module.AGI = FakeAGI

        result = asyncio.run(module.main())

        assert result["ok"] is True
        env_kwargs = calls["env_kwargs"]
        assert env_kwargs["apps_path"] == ROOT / "src/agilab/apps/builtin"
        assert str(env_kwargs["app"]).endswith("_project")
        assert env_kwargs["verbose"] == 1
        if script.name.startswith("AGI_install_"):
            assert calls["operation"] == "install"
            kwargs = calls["kwargs"]
            assert kwargs["scheduler"] == "127.0.0.1"
            assert kwargs["workers"] == {"127.0.0.1": 1}
            assert isinstance(kwargs["modes_enabled"], int)
            assert kwargs["modes_enabled"] > 0
        else:
            assert calls["operation"] == "run"
            request = calls["request"]
            assert request.scheduler == "127.0.0.1"
            assert request.workers == {"127.0.0.1": 1}
            assert request.mode is not None
            assert "args" not in request.params
