# mcp-ccxt

Open-source MCP Server for Crypto Exchanges via CCXT.

**Status:** WIP — Build 1 of 9 (scaffold only).

## Links
- Repository: https://github.com/dante1989/mcp-ccxt
- Issues: https://github.com/dante1989/mcp-ccxt/issues
