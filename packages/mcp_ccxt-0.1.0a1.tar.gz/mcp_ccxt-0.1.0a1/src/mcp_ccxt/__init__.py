"""mcp-ccxt — Open-source MCP Server for Crypto Exchanges via CCXT."""
__version__ = "0.1.0a1"
