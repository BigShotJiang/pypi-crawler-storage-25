from __future__ import annotations

import sys

import typer

from mcp_ccxt import __version__
from mcp_ccxt.config import ServerConfig, load_accounts

app = typer.Typer(
    name="mcp-ccxt",
    help="MCP Server for Crypto Exchanges via CCXT",
    no_args_is_help=True,
)


@app.command()
def version() -> None:
    """Show mcp-ccxt + Python versions."""
    typer.echo(f"mcp-ccxt {__version__}")
    typer.echo(f"python   {sys.version.split()[0]}")


@app.command()
def run(
    config: str = typer.Option(..., "--config", "-c", help="Path to accounts JSON"),
    transport: str = typer.Option(None, "--transport", "-t"),
    port: int = typer.Option(None, "--port", "-p"),
) -> None:
    """Run MCP server (stub — full impl in Build 6)."""
    cfg = ServerConfig()
    if transport:
        cfg.transport = transport  # type: ignore[assignment]
    if port:
        cfg.port = port

    accounts = load_accounts(config)
    typer.echo(f"[Build 1 stub] Loaded {len(accounts)} account(s)")
    typer.echo(f"[Build 1 stub] Transport={cfg.transport} Host={cfg.host} Port={cfg.port}")
    typer.echo("[Build 1 stub] Server not implemented yet — wait Build 6.")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
