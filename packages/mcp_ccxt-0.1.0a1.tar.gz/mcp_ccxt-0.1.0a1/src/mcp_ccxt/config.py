from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict


class ExchangeAccount(BaseModel):
    """Single exchange account config. LOADED FROM JSON FILE ONLY."""
    name: str
    exchange_id: str
    api_key: str | None = None
    secret: str | None = None
    password: str | None = None              # OKX passphrase
    sandbox: bool = True
    default_type: Literal["spot", "future", "swap"] = "spot"


class ServerConfig(BaseSettings):
    """Server config. Scalar fields from env OK.
    Accounts MUST come from JSON file via load_accounts().
    """
    model_config = SettingsConfigDict(env_prefix="MCP_CCXT_", extra="ignore")

    transport: Literal["stdio", "streamable-http"] = "stdio"
    host: str = "0.0.0.0"
    port: int = 8000
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    cache_ttl_seconds: int = 5
    config_file: str | None = None


def load_accounts(config_path: str | Path) -> list[ExchangeAccount]:
    """Load exchange accounts from JSON file.
    NEVER parse accounts from env — too error-prone for nested config.
    """
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    accounts_raw = data.get("accounts", [])
    if not accounts_raw:
        raise ValueError(f"No accounts found in {path}")

    return [ExchangeAccount(**acc) for acc in accounts_raw]
