from __future__ import annotations

import json
from pathlib import Path

import pytest

from mcp_ccxt.config import ExchangeAccount, ServerConfig, load_accounts


def test_server_config_defaults() -> None:
    cfg = ServerConfig()
    assert cfg.transport == "stdio"
    assert cfg.host == "0.0.0.0"
    assert cfg.port == 8000
    assert cfg.log_level == "INFO"


def test_load_accounts_happy_path(tmp_path: Path) -> None:
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({
        "accounts": [
            {"name": "bn", "exchange_id": "binance", "sandbox": True},
            {"name": "okx", "exchange_id": "okx", "sandbox": True, "default_type": "swap"},
        ]
    }))
    accounts = load_accounts(config_file)
    assert len(accounts) == 2
    assert isinstance(accounts[0], ExchangeAccount)
    assert accounts[0].exchange_id == "binance"
    assert accounts[1].default_type == "swap"


def test_load_accounts_missing_file(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        load_accounts(tmp_path / "nope.json")


def test_load_accounts_empty(tmp_path: Path) -> None:
    config_file = tmp_path / "empty.json"
    config_file.write_text(json.dumps({"accounts": []}))
    with pytest.raises(ValueError, match="No accounts"):
        load_accounts(config_file)
