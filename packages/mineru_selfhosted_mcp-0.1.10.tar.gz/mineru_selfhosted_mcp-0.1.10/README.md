# mineru-selfhosted-mcp

`mineru-selfhosted-mcp` exposes a self-hosted MinerU service as an MCP server.

It is designed for setups where:

- MinerU is deployed on a remote GPU server
- Claude Desktop / Cursor / other MCP clients run elsewhere
- The client should only run a lightweight MCP bridge locally

## Environment variables

- `MINERU_BASE_URL`:
  Optional. Base URL of your self-hosted MinerU API. Defaults to `http://42.51.34.112:8192`
- `MINERU_API_TOKEN`:
  Optional token sent to the MinerU API as `Authorization: Bearer <token>`
- `MINERU_TIMEOUT`:
  Optional request timeout in seconds. Default: `1800`
- `MINERU_TRUST_ENV`:
  Optional. Set to `true` only if you want the bridge to inherit local proxy variables. Default: disabled.
- `MINERU_LOG_DIR`:
  Optional. Directory used by `clean_logs`. Defaults to `~/.mineru-selfhosted-mcp/logs`

## Exposed tools

- `mineru_health`: check the remote MinerU API
- `parse_document`: parse a single local file through the remote MinerU API
- `parse_documents`: parse one or more local files through the remote MinerU API
- `parse_directory`: parse all matching files in a directory through the remote MinerU API
- `get_ocr_languages`: list common OCR language codes supported by MinerU
- `clean_logs`: remove local MCP log files older than a chosen number of days

## Parsing result metadata

Parsing tools also return:

- `elapsed_seconds`
- `file_count`
- `completed_count`
- `failed_count`
- `progress`

`progress` is a stable completion summary for the current call rather than a live streaming progress feed.

## Notes

- To get only `middle_json`, set `middle_json_only=true` in parsing tools.
- `middle_json_only=true` automatically disables markdown in the MCP request wrapper.

## Example MCP config

```json
{
    "mcpServers": {
      "mineru-selfhosted": {
        "command": "uvx",
        "args": ["-y", "mineru-selfhosted-mcp"],
        "env": {
          "MINERU_API_TOKEN": "your_token",
          "MINERU_BASE_URL": "http://42.51.34.112:8192",
          "MINERU_DOWNLOAD_BASE_URL": "http://42.51.34.112:8192/downloads"
        }
      }
  }
}
```
