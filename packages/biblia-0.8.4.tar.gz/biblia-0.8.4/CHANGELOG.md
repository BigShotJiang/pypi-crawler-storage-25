# Changelog

All notable changes to Biblia are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [0.8.4] — 2026-04-08

### Fixed
- **Config key caching**: `Config.GEMINI_API_KEY / SERPER_API_KEY / ESV_API_KEY` were
  evaluated once at import time (dataclass defaults). Replaced with a metaclass-based class
  so every attribute access calls `os.getenv()` live — keyring updates are reflected
  immediately without restarting the process.
- **Gemini 429 quota errors**: `GeminiLLM.generate()` now retries up to 3 times on
  rate-limit responses, parsing `retry_delay { seconds: N }` from the error and sleeping
  the exact duration the API requests. Callers pass `_status_cb` to surface the wait to the UI.

### Added
- **Spinner animations**: `teach`, `verse`, and `reflect` commands show a Rich `dots2`
  spinner while fetching sources, generating content, and reflecting — one clean status
  line that updates through each phase (including the 429 wait countdown).

---

## [0.8.3] — 2026-04-08

### Changed
- `SERPER_API_KEY` and `ESV_API_KEY` are now **required** (same as `GEMINI_API_KEY`).
  First-run setup and `bible --setup` will prompt for all three without skip option.

---

## [0.8.2] — 2026-04-08

### Added
- **Key management** (`biblia/config/keys.py`): resolution chain env → keyring → `~/.biblia/.env`;
  `load_all()` called at startup so keys persist across shells without manual export.
- **Interactive setup** (`biblia/config/setup.py`): first-run prompt when `GEMINI_API_KEY` is
  missing; `bible --setup` re-runs it at any time; keys stored in system keyring (falls back
  to `~/.biblia/.env` if keyring unavailable).
- **`config` REPL command** (`cfg` alias): show key status with masked values, set or delete
  individual keys, reset all keys — without leaving the app.
- **`keyring>=24.0.0`** added as a dependency (OS credential store on Windows/macOS/Linux).

### Fixed
- `SerperService.search()` was calling `requests.post` without a timeout (`connect timeout=None`);
  now uses the configured 10-second timeout.
- `search_and_analyze` falls back to Gemini-only analysis when Serper is unavailable or has
  no key, so `teach` always produces output.

---

## [0.8.1] — 2026-04-08

### Fixed
- **ANSI rendering**: removed `console.capture()` → `console.print(string)` double-render
  pattern that leaked raw escape codes in PowerShell and non-256-colour terminals. All
  formatter methods now call `print_*()` directly; `format_*()` wrappers retained for tests.
- **Entry point**: renamed `biblia/cli.py` → `biblia/main.py`; entry point updated to
  `biblia.main:main`.

### Changed
- **TUI redesign**: removed broken ASCII art banner, all nested panel boxes, and "powered by
  Gemini" vendor tagline. Welcome screen is now a clean rule + command table (no boxes).
  Section headers replace nested panels throughout teach/verse/reflect/export output.
  Three themes retained (`dark`, `scholar`, `minimal`).

---

## [0.8.0] — 2026-04-08

### Changed
- **Package structure**: all source modules moved into a proper `biblia/` namespace package
  (`biblia.agent`, `biblia.config`, `biblia.models`, `biblia.services`, `biblia.utils`).
  Entry point changed from `main:main` to `biblia.cli:main`. Eliminates namespace collisions
  with other flat-layout packages installed in the same site-packages.
- **Version**: bumped to 0.8.0 to reflect the structural break (import paths changed).

### Fixed
- `ModuleNotFoundError` when running `bible` from any directory other than the project root,
  caused by the editable install finder appending rather than prepending to `sys.meta_path`,
  allowing a competing namespace `utils` package to shadow ours.

### Removed
- Root-level `__init__.py` and `setup.py` shim (no longer needed with `pyproject.toml`-only build).

---

## [0.7.0] — 2026-04-07

### Changed
- **Model**: upgraded backend from `gemini-1.5-flash` to `gemini-2.5-flash`.
- **Dependencies**: removed `torch`, `transformers`, `accelerate`, `huggingface_hub`,
  and `numpy` — install footprint reduced by ~95 % (from ~3 GB to ~50 MB).
- **PyPI publishing**: replaced `PYPI_API_TOKEN` secret with OIDC trusted publishing
  (`pypa/gh-action-pypi-publish`); no secret rotation required.
- **TUI**: replaced ad-hoc colour literals with a three-theme system (`dark`, `scholar`,
  `minimal`); selectable via `--theme` CLI flag.
- **Startup**: added `rich` spinner animation during agent initialisation.
- **Logging**: demoted model-init messages to `DEBUG`; suppressed noisy third-party
  loggers (`httpx`, `google`, `urllib3`) in normal mode; `--verbose` restores full output.
- **UI copy**: removed emoji decorations and marketing-style strings from all console
  output and documentation.
- **pyproject.toml**: migrated all project metadata from `setup.py`; `setup.py` is now
  a thin shim.

### Added
- `tests/test_integration.py`: full integration suite covering teach→reflect→export flow,
  verse command, theme rendering, and session management.
- `tests/conftest.py`: shared path setup so tests run without `PYTHONPATH` hacks.

### Fixed
- `transformers` cache migration warning no longer appears on startup (dependency removed).
- Duplicate `Initialized model` log entries eliminated.
- `test_bible_agent.py`: fixed broken `src.agent` import paths.

### Removed
- `services/llm/hf_llm.py` HuggingFace pipeline (stubbed for import safety).
- Dead model types `PHI` and `LLAMA` from `model_types.py` and `model_selector.py`.
- `numpy` dependency from `model_selector.py` (replaced with stdlib arithmetic).
- Fluffy/marketing copy from `main.py` welcome screen and exit messages.

---

## [0.6.0] — 2025-03-08

### Added
- ESV API verse fetching with JSON response persistence.
- Export study sessions to Markdown.
- Search agent with Serper integration and Gemini-enhanced theological analysis.
- `ConsoleFormatter` with Rich panels, tables, and Markdown rendering.

---

## [0.5.0] — 2025-01-23

### Added
- Initial TUI with `rich` library.
- Gemini 1.5-flash integration.
- Basic teach / verse / reflect / export command set.
- Session management via `StudySession` dataclass.
