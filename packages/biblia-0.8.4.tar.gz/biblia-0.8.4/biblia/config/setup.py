"""
Interactive key setup and config command handler.
"""

from __future__ import annotations

import getpass
from typing import Optional

from rich.console import Console
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from biblia.config.keys import (
    KEY_SPECS,
    delete_key,
    load_key,
    missing_required,
    save_key,
    status,
)


def _masked(value: Optional[str]) -> str:
    if not value:
        return "not set"
    visible = value[:4] if len(value) > 8 else value[:2]
    return visible + "•" * min(8, len(value) - len(visible))


def run_setup(console: Console, force: bool = False) -> bool:
    """
    Interactive first-run setup.

    Prompts for each key that is missing (or all keys if force=True).
    Returns True if the required key is now set.
    """
    t_accent = "cyan"
    t_dim = "dim white"
    t_ok = "bold green"
    t_warn = "yellow"

    console.print()
    console.print(Rule(f"[{t_accent}]biblia — initial setup[/{t_accent}]", style=t_dim))
    console.print()

    try:
        import keyring  # noqa: F401
        keyring_available = True
    except ImportError:
        keyring_available = False

    storage_note = (
        "Keys will be stored in the [bold]system keyring[/bold]."
        if keyring_available
        else f"Keys will be stored in [{t_dim}]~/.biblia/.env[/{t_dim}]  "
             f"(install [bold]keyring[/bold] for OS-level storage)."
    )
    console.print(f"  {storage_note}")
    console.print()

    saved_any = False

    for short, (env_var, required, description, url) in KEY_SPECS.items():
        current = load_key(env_var)
        if current and not force:
            continue  # already configured

        label = "[bold]required[/bold]" if required else f"[{t_dim}]optional[/{t_dim}]"
        console.print(f"  [{t_accent}]{env_var}[/{t_accent}]  {label}")
        console.print(f"  {description}")
        console.print(f"  [{t_dim}]{url}[/{t_dim}]")

        if current and force:
            console.print(f"  current: [{t_dim}]{_masked(current)}[/{t_dim}]")

        prompt_label = "  new value" if (current and force) else "  value"
        if not required:
            prompt_label += " (Enter to skip)"
        prompt_label += ": "

        try:
            value = getpass.getpass(prompt_label)
        except (EOFError, KeyboardInterrupt):
            console.print()
            console.print(f"  [{t_warn}]Setup cancelled.[/{t_warn}]")
            console.print()
            break

        if not value:
            if required:
                console.print(f"  [{t_warn}]{env_var} is required — skipping for now.[/{t_warn}]")
            console.print()
            continue

        backend = save_key(env_var, value, prefer_keyring=keyring_available)
        console.print(f"  [{t_ok}]saved[/{t_ok}]  [{t_dim}]({backend})[/{t_dim}]")
        console.print()
        saved_any = True

    if saved_any:
        console.print(Rule(f"[{t_ok}]setup complete[/{t_ok}]", style=t_dim))
    else:
        console.print(Rule(style=t_dim))
    console.print()

    return not missing_required()


def handle_config_command(console: Console) -> None:
    """
    Interactive config sub-menu: show status, set individual keys, reset.
    """
    t_accent = "cyan"
    t_dim = "dim white"
    t_ok = "bold green"
    t_warn = "yellow"
    t_err = "bold red"

    _config_commands = {
        "show":  "display current key status",
        "set":   "add or update a key",
        "del":   "remove a stored key",
        "reset": "clear all stored keys",
        "back":  "return to main prompt",
    }

    while True:
        console.print()
        console.print(Rule(f"[{t_accent}]config[/{t_accent}]", style=t_dim))

        tbl = Table(show_header=False, box=None, padding=(0, 2))
        tbl.add_column(style=f"bold {t_accent}", min_width=8, no_wrap=True)
        tbl.add_column(style=t_dim)
        for cmd, desc in _config_commands.items():
            tbl.add_row(cmd, desc)
        console.print(tbl)
        console.print()

        try:
            choice = input("  config> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break

        if choice in ("back", "b", "q", ""):
            break

        elif choice == "show":
            _print_status(console, t_accent, t_dim, t_ok, t_warn)

        elif choice == "set":
            _set_key_interactive(console, t_accent, t_dim, t_ok, t_warn)

        elif choice == "del":
            _delete_key_interactive(console, t_accent, t_dim, t_ok, t_warn, t_err)

        elif choice == "reset":
            try:
                confirm = input("  Reset ALL stored keys? [y/N]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                confirm = ""
            if confirm == "y":
                for _short, (env_var, *_) in KEY_SPECS.items():
                    delete_key(env_var)
                console.print(f"  [{t_warn}]All keys cleared.[/{t_warn}]")
            else:
                console.print(f"  [{t_dim}]Cancelled.[/{t_dim}]")

        else:
            console.print(f"  [{t_warn}]Unknown option.[/{t_warn}]")

    console.print()


def _print_status(console, t_accent, t_dim, t_ok, t_warn):
    s = status()
    tbl = Table(show_header=False, box=None, padding=(0, 2))
    tbl.add_column(style=f"bold {t_accent}", min_width=20, no_wrap=True)
    tbl.add_column(min_width=12)
    tbl.add_column(style=t_dim)

    source_style = {"env": t_ok, "keyring": t_ok, "file": t_ok, None: t_warn}
    source_label = {"env": "env var", "keyring": "keyring", "file": "~/.biblia/.env", None: "not set"}

    for short, (env_var, required, description, _) in KEY_SPECS.items():
        src = s[env_var]
        val_display = _masked(load_key(env_var)) if src else "—"
        req_label = "" if required else f"[{t_dim}]optional[/{t_dim}]"
        tbl.add_row(
            env_var,
            Text(source_label[src], style=source_style[src]),  # type: ignore[arg-type]
            f"{val_display}  {req_label}",
        )
    console.print()
    console.print(tbl)


def _set_key_interactive(console, t_accent, t_dim, t_ok, t_warn):
    names = [env_var for _, (env_var, *_) in KEY_SPECS.items()]
    console.print(f"  Keys: {', '.join(f'[{t_accent}]{n}[/{t_accent}]' for n in names)}")
    try:
        env_var = input("  Which key? ").strip().upper()
        if env_var not in names:
            console.print(f"  [{t_warn}]Unknown key.[/{t_warn}]")
            return
        value = getpass.getpass(f"  {env_var}: ")
    except (EOFError, KeyboardInterrupt):
        console.print()
        return
    if not value:
        console.print(f"  [{t_dim}]No change.[/{t_dim}]")
        return
    try:
        import keyring  # noqa: F401
        backend = save_key(env_var, value, prefer_keyring=True)
    except ImportError:
        backend = save_key(env_var, value, prefer_keyring=False)
    console.print(f"  [{t_ok}]saved[/{t_ok}]  [{t_dim}]({backend})[/{t_dim}]")


def _delete_key_interactive(console, t_accent, t_dim, t_ok, t_warn, t_err):
    names = [env_var for _, (env_var, *_) in KEY_SPECS.items()]
    console.print(f"  Keys: {', '.join(f'[{t_accent}]{n}[/{t_accent}]' for n in names)}")
    try:
        env_var = input("  Which key to remove? ").strip().upper()
    except (EOFError, KeyboardInterrupt):
        console.print()
        return
    if env_var not in names:
        console.print(f"  [{t_warn}]Unknown key.[/{t_warn}]")
        return
    delete_key(env_var)
    console.print(f"  [{t_ok}]removed[/{t_ok}]  [{t_dim}]{env_var}[/{t_dim}]")
