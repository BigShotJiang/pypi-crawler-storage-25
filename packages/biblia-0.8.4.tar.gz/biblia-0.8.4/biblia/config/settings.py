import os
from pathlib import Path

from dotenv import load_dotenv

# Load project-level .env first, then user-level ~/.biblia/.env
load_dotenv()
_user_env = Path.home() / ".biblia" / ".env"
if _user_env.exists():
    load_dotenv(_user_env, override=False)

# Load from keyring / file store into os.environ
from biblia.config.keys import load_all
load_all()

_PROJECT_ROOT = Path(__file__).parent.parent.parent


class _ConfigMeta(type):
    """Metaclass so API key attributes do a live os.getenv() on every access."""

    @property
    def GEMINI_API_KEY(cls) -> str:
        return os.getenv("GEMINI_API_KEY", "")

    @property
    def SERPER_API_KEY(cls) -> str:
        return os.getenv("SERPER_API_KEY", "")

    @property
    def ESV_API_KEY(cls) -> str:
        return os.getenv("ESV_API_KEY", "")

    @property
    def LOG_LEVEL(cls) -> str:
        return os.getenv("LOG_LEVEL", "WARNING")


class Config(metaclass=_ConfigMeta):
    # Model
    MAX_TOKENS:  int   = 2048
    TEMPERATURE: float = 0.7

    # Paths
    PROJECT_ROOT: Path = _PROJECT_ROOT
    DATA_DIR:     Path = _PROJECT_ROOT / "data"
    CACHE_DIR:    Path = _PROJECT_ROOT / "cache"
    VERSES_DIR:   Path = _PROJECT_ROOT / "data" / "verses"

    # Logging
    LOG_FILE: Path = _PROJECT_ROOT / "logs" / "biblia.log"

    # Search
    MAX_SEARCH_RESULTS: int = 5
    SEARCH_TIMEOUT:     int = 10

    # Session
    MAX_MEMORY_ITEMS: int = 100
    MAX_FAVORITES:    int = 50

    @classmethod
    def ensure_directories(cls) -> None:
        for d in [cls.DATA_DIR, cls.CACHE_DIR, cls.LOG_FILE.parent, cls.VERSES_DIR]:
            d.mkdir(parents=True, exist_ok=True)
