"""
API key management for Biblia.

Resolution order for any key:
  1. Environment variable (already set in shell / CI)
  2. System keyring  (OS credential store — preferred for interactive users)
  3. .env file in the project/user config dir

Writing order: keyring first, .env as fallback.
"""

from __future__ import annotations

import os
import logging
from pathlib import Path
from typing import Optional

log = logging.getLogger(__name__)

_SERVICE = "biblia"

# Keys metadata: name → (env_var, required, description, url)
KEY_SPECS: dict[str, tuple[str, bool, str, str]] = {
    "gemini": (
        "GEMINI_API_KEY",
        True,
        "Gemini AI  (powers all analysis)",
        "https://aistudio.google.com/apikey",
    ),
    "serper": (
        "SERPER_API_KEY",
        True,
        "Serper search  (web context for teachings)",
        "https://serper.dev",
    ),
    "esv": (
        "ESV_API_KEY",
        True,
        "ESV Bible API  (verse text)",
        "https://api.esv.org",
    ),
}

_ENV_FILE = Path.home() / ".biblia" / ".env"


# ---------------------------------------------------------------------------
# Low-level read / write
# ---------------------------------------------------------------------------

def _keyring_get(env_var: str) -> Optional[str]:
    try:
        import keyring  # type: ignore
        return keyring.get_password(_SERVICE, env_var) or None
    except Exception:
        return None


def _keyring_set(env_var: str, value: str) -> bool:
    try:
        import keyring  # type: ignore
        keyring.set_password(_SERVICE, env_var, value)
        return True
    except Exception:
        return False


def _keyring_delete(env_var: str) -> None:
    try:
        import keyring  # type: ignore
        keyring.delete_password(_SERVICE, env_var)
    except Exception:
        pass


def _env_file_get(env_var: str) -> Optional[str]:
    if not _ENV_FILE.exists():
        return None
    for line in _ENV_FILE.read_text().splitlines():
        line = line.strip()
        if line.startswith(f"{env_var}="):
            return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None


def _env_file_set(env_var: str, value: str) -> None:
    _ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    replaced = False
    if _ENV_FILE.exists():
        for line in _ENV_FILE.read_text().splitlines():
            if line.strip().startswith(f"{env_var}="):
                lines.append(f'{env_var}="{value}"')
                replaced = True
            else:
                lines.append(line)
    if not replaced:
        lines.append(f'{env_var}="{value}"')
    _ENV_FILE.write_text("\n".join(lines) + "\n")


def _env_file_delete(env_var: str) -> None:
    if not _ENV_FILE.exists():
        return
    lines = [
        l for l in _ENV_FILE.read_text().splitlines()
        if not l.strip().startswith(f"{env_var}=")
    ]
    _ENV_FILE.write_text("\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_key(env_var: str) -> Optional[str]:
    """Return a key value from env → keyring → .env file."""
    return (
        os.environ.get(env_var)
        or _keyring_get(env_var)
        or _env_file_get(env_var)
    )


def save_key(env_var: str, value: str, prefer_keyring: bool = True) -> str:
    """Persist a key. Returns 'keyring' or 'env_file'."""
    if prefer_keyring and _keyring_set(env_var, value):
        os.environ[env_var] = value
        return "keyring"
    _env_file_set(env_var, value)
    os.environ[env_var] = value
    return "env_file"


def delete_key(env_var: str) -> None:
    _keyring_delete(env_var)
    _env_file_delete(env_var)
    os.environ.pop(env_var, None)


def status() -> dict[str, Optional[str]]:
    """Return {env_var: source_or_None} for all known keys."""
    result: dict[str, Optional[str]] = {}
    for _short, (env_var, *_) in KEY_SPECS.items():
        if os.environ.get(env_var):
            result[env_var] = "env"
        elif _keyring_get(env_var):
            result[env_var] = "keyring"
        elif _env_file_get(env_var):
            result[env_var] = "file"
        else:
            result[env_var] = None
    return result


def load_all() -> None:
    """Load all stored keys into os.environ (called at startup)."""
    for _short, (env_var, *_) in KEY_SPECS.items():
        if not os.environ.get(env_var):
            val = _keyring_get(env_var) or _env_file_get(env_var)
            if val:
                os.environ[env_var] = val


def missing_required() -> list[str]:
    """Return list of required env_var names that have no value."""
    out = []
    for _short, (env_var, required, *_) in KEY_SPECS.items():
        if required and not load_key(env_var):
            out.append(env_var)
    return out
