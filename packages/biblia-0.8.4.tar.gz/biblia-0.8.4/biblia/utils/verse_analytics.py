from typing import List, Dict
from biblia.models.verse import Verse
from biblia.models.verse_categories import VerseCategory

class VerseAnalytics:
    @staticmethod
    def get_category_distribution(verses: List[Verse]) -> Dict[VerseCategory, int]:
        pass
        
    @staticmethod
    def get_review_recommendations(verses: List[Verse]) -> List[Verse]:
        pass