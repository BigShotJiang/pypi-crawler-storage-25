from datetime import datetime
from typing import Any, Dict, Optional
import textwrap

from rich.console import Console
from rich.markdown import Markdown
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

# ---------------------------------------------------------------------------
# Themes
# ---------------------------------------------------------------------------

THEMES: Dict[str, Dict[str, str]] = {
    "dark": {
        "accent":  "cyan",
        "cmd":     "bold cyan",
        "key":     "dim cyan",
        "desc":    "white",
        "dim":     "dim white",
        "section": "bold white",
        "rule":    "dim white",
        "error":   "bold red",
        "success": "bold green",
        "verse":   "italic white",
    },
    "scholar": {
        "accent":  "yellow",
        "cmd":     "bold yellow",
        "key":     "dim yellow",
        "desc":    "white",
        "dim":     "dim yellow",
        "section": "bold white",
        "rule":    "dim yellow",
        "error":   "bold red",
        "success": "bold green",
        "verse":   "italic yellow",
    },
    "minimal": {
        "accent":  "white",
        "cmd":     "bold white",
        "key":     "dim white",
        "desc":    "dim white",
        "dim":     "dim",
        "section": "bold",
        "rule":    "dim",
        "error":   "bold",
        "success": "bold",
        "verse":   "italic",
    },
}

DEFAULT_THEME = "dark"

_COMMANDS = [
    ("teach",   "t",    "biblical exegesis on any topic"),
    ("verse",   "v",    "daily passage with commentary"),
    ("reflect", "r",    "synthesise the current session"),
    ("export",  "e",    "write session notes to markdown"),
    ("config",  "cfg",  "manage API keys"),
    ("help",    "h",    "this reference"),
    ("exit",    "q",    "quit"),
]

VERSION = "0.8.4"


class ConsoleFormatter:
    def __init__(self, theme: str = DEFAULT_THEME, console: Optional[Console] = None):
        self.console = console or Console()
        self.t = THEMES.get(theme, THEMES[DEFAULT_THEME])

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _rule(self, title: str = "", **kwargs) -> None:
        style = kwargs.get("style", self.t["rule"])
        self.console.print(Rule(title, style=style))

    def _section(self, title: str) -> None:
        self.console.print()
        self.console.print(Text(title, style=self.t["section"]))
        self.console.print(Text("─" * len(title), style=self.t["rule"]))

    # ------------------------------------------------------------------
    # Welcome / help
    # ------------------------------------------------------------------

    def print_welcome(self) -> None:
        c, t = self.console, self.t
        c.print()
        c.print(Rule(
            f"[{t['accent']}]biblia[/{t['accent']}]  [{t['dim']}]v{VERSION}[/{t['dim']}]",
            style=t["rule"],
        ))
        c.print()

        tbl = Table(show_header=False, box=None, padding=(0, 2), expand=False)
        tbl.add_column(style=t["cmd"],  min_width=10, no_wrap=True)
        tbl.add_column(style=t["key"],  min_width=4,  no_wrap=True)
        tbl.add_column(style=t["desc"])

        for cmd, key, desc in _COMMANDS:
            tbl.add_row(cmd, key, desc)

        c.print(tbl)
        c.print()
        c.print(Rule(style=t["rule"]))
        c.print()

    def format_welcome(self) -> str:
        with self.console.capture() as cap:
            self.print_welcome()
        return cap.get()

    # ------------------------------------------------------------------
    # Teaching
    # ------------------------------------------------------------------

    def print_teaching(self, data: Dict) -> None:
        c, t = self.console, self.t
        c.print()
        self._rule(f"[{t['accent']}] {data['query'].upper()} [/{t['accent']}]")

        self._section("Insights")
        c.print(Markdown(data.get("insights", "")))

        if refs := data.get("references", []):
            self._section("References")
            for r in refs:
                c.print(f"  [{t['key']}]{r}[/{t['key']}]")

        if app := data.get("application", ""):
            self._section("Application")
            c.print(Markdown(app))

        if prayer := data.get("prayer", ""):
            self._section("Prayer")
            c.print(Markdown(prayer))

        if sources := data.get("sources", []):
            self._section("Sources")
            for s in sources:
                c.print(f"  [{t['dim']}]{textwrap.shorten(s.get('title',''), width=60)}[/{t['dim']}]")
                c.print(f"  [{t['key']}]{s.get('link','')}[/{t['key']}]")

        ts = datetime.fromisoformat(data["timestamp"]).strftime("%Y-%m-%d %H:%M")
        c.print()
        self._rule(f"[{t['dim']}]{ts}[/{t['dim']}]")
        c.print()

    def format_teaching(self, data: Dict) -> str:
        with self.console.capture() as cap:
            self.print_teaching(data)
        return cap.get()

    # ------------------------------------------------------------------
    # Verse
    # ------------------------------------------------------------------

    def print_verse(self, data: Dict) -> None:
        c, t = self.console, self.t
        c.print()
        self._rule(f"[{t['accent']}] {data['reference']} [/{t['accent']}]")
        c.print()
        c.print(Text(data["text"], style=t["verse"]))
        c.print(Text(
            f"  — {data['reference']}  ({data['translation']})",
            style=t["dim"], justify="right",
        ))
        if dev := data.get("devotional", ""):
            self._section("Commentary")
            c.print(Markdown(dev))
        c.print()
        self._rule(style=t["rule"])
        c.print()

    def format_verse(self, data: Dict) -> str:
        with self.console.capture() as cap:
            self.print_verse(data)
        return cap.get()

    # ------------------------------------------------------------------
    # Reflection
    # ------------------------------------------------------------------

    def print_reflection(self, data: Dict) -> None:
        c, t = self.console, self.t
        c.print()
        self._rule(f"[{t['accent']}] REFLECTION [/{t['accent']}]")
        self._section("Insights")
        c.print(Markdown(data.get("insights", "")))
        self._section("Application")
        c.print(Markdown(data.get("application", "")))
        self._section("Prayer")
        c.print(Markdown(data.get("prayer", "")))
        c.print()
        self._rule(style=t["rule"])
        c.print()

    def format_reflection(self, data: Dict) -> str:
        with self.console.capture() as cap:
            self.print_reflection(data)
        return cap.get()

    # ------------------------------------------------------------------
    # Export success
    # ------------------------------------------------------------------

    def print_export_success(self, filepath: str) -> None:
        c, t = self.console, self.t
        c.print()
        self._rule(f"[{t['success']}] exported [/{t['success']}]")
        c.print(Text(f"  {filepath}", style=t["dim"]))
        c.print()

    def format_export_success(self, filepath: str) -> str:
        with self.console.capture() as cap:
            self.print_export_success(filepath)
        return cap.get()

    # ------------------------------------------------------------------
    # Search results
    # ------------------------------------------------------------------

    def print_search_results(self, results: Dict[str, Any]) -> None:
        c, t = self.console, self.t
        c.print()
        self._rule(f"[{t['accent']}] {results['query'].upper()} [/{t['accent']}]")
        self._section("Insights")
        c.print(Markdown(results.get("insights", "")))
        if sources := results.get("sources", []):
            self._section("Sources")
            for s in sources:
                c.print(f"  [{t['dim']}]{textwrap.shorten(s.get('title',''), width=60)}[/{t['dim']}]")
                c.print(f"  [{t['key']}]{s.get('link','')}[/{t['key']}]")
        c.print()
        self._rule(style=t["rule"])
        c.print()

    def format_search_results(self, results: Dict[str, Any]) -> str:
        with self.console.capture() as cap:
            self.print_search_results(results)
        return cap.get()

    # ------------------------------------------------------------------
    # Passage analysis
    # ------------------------------------------------------------------

    def print_analysis(self, data: Dict[str, Any]) -> None:
        c, t = self.console, self.t
        c.print()
        self._rule(f"[{t['accent']}] ANALYSIS [/{t['accent']}]")
        self._section("Passage")
        c.print(Text(data.get("passage", ""), style=t["verse"]))
        self._section("Analysis")
        c.print(Markdown(data.get("analysis", "")))
        c.print()
        self._rule(style=t["rule"])
        c.print()

    def format_analysis(self, data: Dict[str, Any]) -> str:
        with self.console.capture() as cap:
            self.print_analysis(data)
        return cap.get()
