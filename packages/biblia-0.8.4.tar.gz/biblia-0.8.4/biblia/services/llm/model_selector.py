import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any

from .model_types import ModelType, TaskType
from .gemini_llm import GeminiLLM
from biblia.config.settings import Config

logger = logging.getLogger(__name__)


@dataclass
class ModelMetrics:
    success_count: int = 0
    fail_count: int = 0
    latencies: List[float] = field(default_factory=list)
    last_success: Optional[datetime] = None


class ModelSelector:
    """Route tasks to available models and track performance."""

    def __init__(self):
        self._model_instances: Dict[ModelType, Any] = {}
        self.metrics: Dict[ModelType, ModelMetrics] = {
            ModelType.GEMINI: ModelMetrics()
        }
        self.default_model = ModelType.GEMINI

    def select_model(self, task: TaskType, context: Optional[Dict] = None) -> ModelType:
        return ModelType.GEMINI

    def get_model(self, model_type: ModelType) -> Optional[GeminiLLM]:
        if model_type not in self._model_instances:
            try:
                if model_type == ModelType.GEMINI:
                    self._model_instances[model_type] = GeminiLLM(
                        api_key=Config.GEMINI_API_KEY
                    )
            except Exception as e:
                logger.error(f"Model init error for {model_type}: {e}")
                return None
        return self._model_instances.get(model_type)

    def select_and_get_model(
        self, task: TaskType, context: Optional[Dict] = None
    ) -> Optional[GeminiLLM]:
        model = self.get_model(ModelType.GEMINI)
        if not model:
            logger.error("Failed to initialise Gemini model")
        return model

    def update_performance(self, model: ModelType, success: bool, latency: float):
        m = self.metrics.get(model)
        if not m:
            return
        if success:
            m.success_count += 1
            m.last_success = datetime.now()
        else:
            m.fail_count += 1
        m.latencies.append(latency)
        if len(m.latencies) > 100:
            m.latencies.pop(0)

    def track_performance(self, model: ModelType, success: bool):
        self.update_performance(model, success, latency=0.0)
