import logging
import re
import time
from typing import Optional

import google.generativeai as genai

from .model_types import ModelType

logger = logging.getLogger(__name__)

_MAX_RETRIES = 3
_DEFAULT_RETRY_DELAY = 30  # seconds


def _parse_retry_delay(exc: Exception) -> int:
    """Extract retry_delay seconds from a Gemini 429 exception message."""
    text = str(exc)
    m = re.search(r"retry_delay\s*\{\s*seconds:\s*(\d+)", text)
    if m:
        return int(m.group(1))
    m = re.search(r"[Rr]etry after (\d+)", text)
    if m:
        return int(m.group(1))
    return _DEFAULT_RETRY_DELAY


class GeminiLLM:
    MODEL_ID = "gemini-2.5-flash"

    def __init__(self, api_key: str):
        try:
            self.model_type = ModelType.GEMINI
            self.model_id = self.MODEL_ID
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel(self.MODEL_ID)
        except Exception as e:
            logger.error(f"Failed to initialize Gemini: {e}")
            raise

    def generate(self, prompt: str, _status_cb=None) -> Optional[str]:
        """Generate content with automatic 429 retry-after backoff.

        _status_cb: optional callable(message: str) -- called before each wait
                    so callers can update a Rich status spinner message.
        """
        for attempt in range(1, _MAX_RETRIES + 1):
            try:
                response = self.model.generate_content(
                    prompt,
                    generation_config={
                        "temperature": 0.7,
                        "top_p": 0.8,
                        "top_k": 40,
                        "max_output_tokens": 2048,
                    },
                    safety_settings={
                        "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_NONE",
                        "HARM_CATEGORY_HATE_SPEECH": "BLOCK_ONLY_HIGH",
                        "HARM_CATEGORY_HARASSMENT": "BLOCK_ONLY_HIGH",
                        "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_ONLY_HIGH",
                    },
                )

                if not response.parts:
                    logger.debug("No content parts in Gemini response")
                    return None

                content = response.parts[0].text
                if not content:
                    logger.debug("Empty content in Gemini response")
                    return None

                return content

            except Exception as e:
                is_quota = (
                    "429" in str(e)
                    or "quota" in str(e).lower()
                    or "Resource has been exhausted" in str(e)
                )
                if is_quota and attempt < _MAX_RETRIES:
                    delay = _parse_retry_delay(e)
                    msg = f"Rate limit -- waiting {delay}s (retry {attempt}/{_MAX_RETRIES - 1})..."
                    logger.warning(msg)
                    if _status_cb:
                        _status_cb(msg)
                    time.sleep(delay)
                    continue

                logger.error(f"Gemini generation error: {e}")
                return None

        return None
