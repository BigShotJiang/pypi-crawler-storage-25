from enum import Enum, auto


class ModelType(Enum):
    GEMINI = auto()


class TaskType(Enum):
    TEACHING = auto()
    REFLECTION = auto()
    VERSE_ANALYSIS = auto()
