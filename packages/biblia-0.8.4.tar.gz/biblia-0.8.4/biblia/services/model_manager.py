import logging
from typing import Dict, Optional

from .llm.gemini_llm import GeminiLLM
from .llm.model_types import ModelType
from biblia.config.settings import Config

logger = logging.getLogger(__name__)


class ModelManager:
    """Singleton manager for LLM instances."""

    _instance = None
    _models: Dict = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def get_model(self, model_type: ModelType) -> Optional[GeminiLLM]:
        if model_type not in self._models:
            try:
                if model_type == ModelType.GEMINI:
                    self._models[model_type] = GeminiLLM(api_key=Config.GEMINI_API_KEY)
                    logger.debug(f"Initialized model: {model_type.name}")
            except Exception as e:
                logger.error(f"Failed to initialize model {model_type}: {e}")
                return None
        return self._models.get(model_type)
