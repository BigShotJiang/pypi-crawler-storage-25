from typing import Dict, List, Optional
import logging
from biblia.services.serper_service import SerperService
from biblia.services.model_manager import ModelManager
from biblia.config.settings import Config
from biblia.services.llm.gemini_llm import GeminiLLM
from biblia.services.llm.model_types import ModelType
from datetime import datetime

class SearchAgent:
    """Enhanced biblical search and analysis agent"""
    
    def __init__(self, model_manager: ModelManager):
        """Initialize with shared model manager"""
        self.model_manager = model_manager
        self.serper = SerperService(api_key=Config.SERPER_API_KEY)
        self.gemini = self.model_manager.get_model(ModelType.GEMINI)

    def search_and_analyze(self, query: str) -> Optional[Dict]:
        """Biblical analysis with web search enrichment.

        Serper is required. Falls back to Gemini-only on transient errors
        (timeout, quota) so the teach command doesn't hard-fail mid-session.
        """
        raw_results = []
        try:
            raw_results = self.serper.search(query)
        except Exception as e:
            logging.warning(f"Search unavailable, falling back to model-only: {e}")

        snippets = [r.get('snippet', '') for r in raw_results[:3]]
        source_context = f"\n\nWeb context:\n" + "\n".join(snippets) if snippets else ""

        prompt = (
            f"Provide a thorough biblical analysis of: {query}"
            f"{source_context}\n\n"
            "Structure your response to cover:\n"
            "1. Key biblical principles and relevant scripture\n"
            "2. Theological significance\n"
            "3. Practical application\n"
            "4. Historical or cultural context where relevant"
        )

        try:
            analysis = self.gemini.generate(prompt)
            if not analysis:
                raise ValueError("Empty response from model")
        except Exception as e:
            logging.error(f"Search and analysis failed: {e}")
            return None

        return {
            "query": query,
            "insights": analysis,
            "sources": [
                {"title": r.get('title', ''), "link": r.get('link', ''), "snippet": r.get('snippet', '')}
                for r in raw_results[:3]
            ],
            "timestamp": datetime.now().isoformat(),
        }

    def reflect_on_results(self, search_results: Dict) -> str:
        """Generate spiritual reflection on search results"""
        try:
            reflection_prompt = f"""Provide a spiritual reflection on: {search_results['query']}
            Based on: {search_results['insights']}
            
            Consider:
            1. Spiritual significance
            2. Personal application
            3. Prayer points
            4. Meditation focus
            """
            
            return self.gemini.generate(reflection_prompt)
            
        except Exception as e:
            logging.error(f"Reflection generation failed: {str(e)}")
            return ""

    def get_summary(self, text: str) -> Dict:
        """Generate a comprehensive biblical summary"""
        try:
            summary_prompt = f"""
            Provide a biblical analysis of this text:
            {text}
            
            Include:
            - Main theological themes
            - Key spiritual principles
            - Biblical cross-references
            - Practical applications
            """
            
            summary = self.gemini.generate(summary_prompt)
            
            return {
                "summary": summary,
                "key_points": self._extract_key_points(summary),
                "references": self._find_biblical_references(text),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logging.error(f"Summary generation failed: {str(e)}")
            raise

    def _validate_results(self, results: List[Dict]) -> List[Dict]:
        """Filter and validate search results"""
        valid_results = []
        for result in results:
            if self._is_reliable_source(result.get('link', '')):
                valid_results.append(result)
        return valid_results

    def _is_reliable_source(self, url: str) -> bool:
        """Check if source is from reliable biblical websites"""
        trusted_domains = [
            'biblehub.com',
            'biblegateway.com',
            'blueletterbible.org',
            'biblestudytools.com',
            'gotquestions.org'
        ]
        return any(domain in url.lower() for domain in trusted_domains)

    def _extract_key_points(self, text: str) -> List[str]:
        """Extract key theological points from analysis"""
        try:
            prompt = f"Extract the key theological points from this analysis: {text}"
            result = self.gemini.generate(prompt)
            return [point.strip() for point in result.split('\n') if point.strip()]
        except Exception as e:
            logging.error(f"Key point extraction failed: {str(e)}")
            return []

    def _find_biblical_references(self, text: str) -> List[str]:
        """Extract biblical references from text"""
        try:
            prompt = f"List all Bible verse references from this text: {text}"
            result = self.gemini.generate(prompt)
            return [ref.strip() for ref in result.split('\n') if ref.strip()]
        except Exception as e:
            logging.error(f"Reference extraction failed: {str(e)}")
            return []