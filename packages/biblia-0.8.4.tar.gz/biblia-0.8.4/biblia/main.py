import argparse
import logging
import os
import sys
from typing import Optional

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

from rich.console import Console

from biblia.utils.formatters.console_formatter import THEMES


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="bible",
        description="Biblia — biblical research assistant",
    )
    p.add_argument("--verbose", action="store_true", help="Enable debug-level logging")
    p.add_argument(
        "--theme",
        choices=list(THEMES.keys()),
        default="dark",
        help="UI colour theme (default: dark)",
    )
    p.add_argument(
        "--setup",
        action="store_true",
        help="Run interactive API key setup and exit",
    )
    return p


COMMAND_MAP = {
    "teach":   {"t"},
    "verse":   {"v", "daily"},
    "reflect": {"r", "meditate"},
    "export":  {"e", "save"},
    "config":  {"cfg", "keys"},
    "help":    {"h", "?"},
    "exit":    {"q", "quit", "bye"},
}


def resolve_command(raw: str) -> Optional[str]:
    raw = raw.lower().strip()
    if raw in COMMAND_MAP:
        return raw
    for cmd, aliases in COMMAND_MAP.items():
        if raw in aliases:
            return cmd
    return None


def main():
    console = Console()
    args, _ = build_parser().parse_known_args()

    log_level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(level=log_level, format="%(levelname)s:%(name)s:%(message)s")

    if not args.verbose:
        for noisy in ("httpx", "httpcore", "google", "urllib3"):
            logging.getLogger(noisy).setLevel(logging.ERROR)

    # --setup flag: run key setup and exit
    if args.setup:
        from biblia.config.setup import run_setup
        run_setup(console, force=True)
        return

    # First-run check: prompt for required keys before loading the agent
    from biblia.config.keys import missing_required
    from biblia.config.setup import run_setup

    if missing_required():
        ok = run_setup(console)
        if not ok:
            console.print("[bold red]GEMINI_API_KEY is required. Run 'bible --setup' to configure.[/bold red]")
            sys.exit(1)
        # Reload Config so the agent picks up the newly set key
        import importlib
        import biblia.config.settings as _cfg_mod
        importlib.reload(_cfg_mod)

    try:
        from biblia.agent.bible_agent import BibleAgent
        from biblia.config.setup import handle_config_command

        spinner_color = "cyan" if args.theme == "dark" else "yellow"
        with console.status(f"[{spinner_color}]loading...", spinner="dots2"):
            agent = BibleAgent(theme=args.theme)

        if not agent._models:
            console.print("[bold red]Model initialisation failed.[/bold red]")
            sys.exit(1)

        agent.console_formatter.print_welcome()

        while True:
            try:
                raw = input("Command (h for help): ").strip()
                cmd = resolve_command(raw)
                if cmd == "config":
                    handle_config_command(console)
                elif cmd:
                    result = agent.process_command(cmd)
                    if result is None and cmd not in ("reflect", "help"):
                        console.print("[bold red]Command failed — check logs or try again.[/bold red]")
                else:
                    console.print("[dim]Unknown command. Type 'h' for help.[/dim]")
            except KeyboardInterrupt:
                console.print("\nExiting.")
                sys.exit(0)

    except KeyboardInterrupt:
        console.print("\nExiting.")
        sys.exit(0)
    except Exception as e:
        logging.getLogger(__name__).error(f"Fatal error: {e}")
        console.print(f"[bold red]Fatal error:[/bold red] {e}")
        raise


if __name__ == "__main__":
    main()
