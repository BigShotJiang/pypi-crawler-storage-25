"""
Biblia — Biblical study assistant powered by Gemini AI.
"""

__version__ = "0.8.4"
