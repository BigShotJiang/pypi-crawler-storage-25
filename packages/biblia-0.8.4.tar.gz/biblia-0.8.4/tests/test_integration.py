"""
Integration tests for Biblia.

These tests wire the real agent, session, and formatter together,
mocking only the external network calls (Gemini API, Serper, ESV API).
"""
import pytest
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

from biblia.agent.bible_agent import BibleAgent
from biblia.agent.components.session import StudySession
from biblia.models.verse import Verse
from biblia.models.verse_categories import VerseCategory
from biblia.utils.formatters.console_formatter import ConsoleFormatter, THEMES


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def mock_llm():
    m = MagicMock()
    m.generate.return_value = (
        "INSIGHTS:\nKey spiritual insight.\n\n"
        "APPLICATION:\nApply to daily life.\n\n"
        "PRAYER:\nFocus on gratitude."
    )
    m.model_type = "GEMINI"
    m.model_id = "gemini-2.5-flash"
    return m


@pytest.fixture(scope="module")
def mock_search_result():
    return {
        "query": "faith",
        "insights": "Faith is the substance of things hoped for.",
        "sources": [
            {"title": "Hebrews 11", "link": "https://biblegateway.com/faith", "snippet": "..."}
        ],
        "timestamp": datetime.now().isoformat(),
    }


@pytest.fixture
def agent(mock_llm, mock_search_result):
    with patch("biblia.agent.bible_agent.ModelManager") as MockMM, \
         patch("biblia.agent.bible_agent.SearchAgent") as MockSA, \
         patch("biblia.services.model_manager.GeminiLLM"):

        MockMM.return_value.get_model.return_value = mock_llm
        MockSA.return_value.search_and_analyze.return_value = mock_search_result

        a = BibleAgent(theme="dark")
    return a


# ---------------------------------------------------------------------------
# Agent initialisation
# ---------------------------------------------------------------------------


class TestAgentInitialisation:
    def test_agent_creates_session(self, agent):
        assert isinstance(agent.current_session, StudySession)

    def test_agent_has_formatter(self, agent):
        assert isinstance(agent.console_formatter, ConsoleFormatter)

    def test_models_dict_populated(self, agent):
        assert agent._models


# ---------------------------------------------------------------------------
# Full teach → reflect → export flow
# ---------------------------------------------------------------------------


class TestTeachReflectExportFlow:
    def test_teach_populates_session(self, agent, mock_search_result, monkeypatch):
        monkeypatch.setattr("builtins.input", lambda _: "grace")
        agent.search_agent.search_and_analyze.return_value = {
            **mock_search_result,
            "query": "grace",
        }
        result = agent.process_command("teach")

        assert result is not None
        assert result["query"] == "grace"
        assert len(agent.current_session.teachings) >= 1

    def test_reflect_after_teach(self, agent, mock_search_result):
        # Seed the session so reflect has something to work with
        agent.current_session.add_teaching({**mock_search_result, "references": [], "application": "", "prayer": ""})
        result = agent.process_command("reflect")
        assert result is not None
        assert "insights" in result
        assert "application" in result
        assert "prayer" in result

    def test_export_writes_file(self, agent, tmp_path):
        with patch("biblia.agent.bible_agent.Config") as mock_cfg:
            mock_cfg.DATA_DIR = tmp_path
            result = agent.process_command("export")

        assert result is not None
        assert Path(result).exists()
        content = Path(result).read_text(encoding="utf-8")
        assert "Bible Study Session" in content


# ---------------------------------------------------------------------------
# Verse command
# ---------------------------------------------------------------------------


class TestVerseFlow:
    def test_verse_returns_data(self, agent):
        verse = Verse(
            text="For God so loved the world",
            reference="John 3:16",
            translation="ESV",
            category=VerseCategory.FAITH,
        )
        agent.get_daily_verse = MagicMock(return_value=verse)
        agent.model_manager.get_model.return_value.generate.return_value = "Short devotional."

        result = agent.process_command("verse")

        assert result is not None
        assert result["reference"] == "John 3:16"
        assert "devotional" in result
        assert len(agent.current_session.verses) >= 1

    def test_verse_fallback_on_api_failure(self, agent):
        agent.get_daily_verse = MagicMock(
            side_effect=Exception("API unavailable")
        )
        result = agent.process_command("verse")
        # Should not raise; returns None gracefully
        assert result is None


# ---------------------------------------------------------------------------
# Theme system
# ---------------------------------------------------------------------------


class TestThemes:
    @pytest.mark.parametrize("theme", list(THEMES.keys()))
    def test_formatter_renders_for_each_theme(self, theme):
        formatter = ConsoleFormatter(theme=theme)
        data = {
            "query": "hope",
            "insights": "Hope does not disappoint.",
            "references": ["Romans 5:5"],
            "application": "Trust in difficult seasons.",
            "prayer": "Lord, renew our hope.",
            "sources": [],
            "timestamp": datetime.now().isoformat(),
        }
        output = formatter.format_teaching(data)
        assert "HOPE" in output
        assert "Insights" in output

    def test_welcome_message_has_commands(self):
        formatter = ConsoleFormatter(theme="dark")
        welcome = formatter.format_welcome()
        assert "teach" in welcome
        assert "verse" in welcome
        assert "reflect" in welcome

    def test_unknown_theme_falls_back_to_dark(self):
        formatter = ConsoleFormatter(theme="nonexistent")
        assert formatter.t == THEMES["dark"]


# ---------------------------------------------------------------------------
# Session management
# ---------------------------------------------------------------------------


class TestStudySession:
    def test_teachings_accumulate(self):
        session = StudySession()
        entry = {
            "query": "mercy",
            "insights": "God's mercy is new every morning.",
            "references": ["Lamentations 3:23"],
            "application": "",
            "prayer": "",
            "sources": [],
            "timestamp": datetime.now().isoformat(),
        }
        session.add_teaching(entry)
        session.add_teaching(entry)
        assert len(session.teachings) == 2

    def test_get_latest_content_priority(self):
        session = StudySession()
        verse_data = {
            "text": "verse text",
            "reference": "Gen 1:1",
            "translation": "ESV",
            "devotional": "",
        }
        teaching_data = {
            "query": "creation",
            "insights": "...",
            "references": [],
            "application": "",
            "prayer": "",
            "sources": [],
            "timestamp": datetime.now().isoformat(),
        }
        session.add_verse(verse_data)
        session.add_teaching(teaching_data)

        latest = session.get_latest_content()
        # teaching added last but teachings take priority in get_latest_content
        assert latest["type"] == "teaching"

    def test_reflections_stored(self):
        session = StudySession()
        session.add_reflection({
            "context_type": "teaching",
            "insights": "Deep insight",
            "application": "Practice daily",
            "prayer": "Prayer point",
        })
        assert len(session.reflections) == 1
        assert session.reflections[0]["context_type"] == "teaching"
