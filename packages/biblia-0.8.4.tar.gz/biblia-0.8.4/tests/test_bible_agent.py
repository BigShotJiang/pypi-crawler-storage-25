"""Unit tests for BibleAgent command handling and session management."""
import pytest
from datetime import datetime
from unittest.mock import MagicMock, patch

from biblia.agent.bible_agent import BibleAgent
from biblia.models.verse import Verse
from biblia.models.verse_categories import VerseCategory
from biblia.utils.formatters.console_formatter import ConsoleFormatter


@pytest.fixture
def mock_model():
    m = MagicMock()
    m.generate.return_value = "Mock LLM response."
    return m


@pytest.fixture
def bible_agent(mock_model):
    with patch("biblia.agent.bible_agent.ModelManager") as MockMM:
        MockMM.return_value.get_model.return_value = mock_model
        with patch("biblia.agent.bible_agent.SearchAgent") as MockSA:
            MockSA.return_value.search_and_analyze.return_value = {
                "query": "test",
                "insights": "Test insights",
                "sources": [],
                "timestamp": datetime.now().isoformat(),
            }
            agent = BibleAgent(theme="dark")
    return agent


@pytest.fixture
def sample_teaching():
    return {
        "query": "love",
        "insights": "Biblical insights about love...",
        "references": ["John 3:16", "1 Corinthians 13:4-7"],
        "application": "How to apply love...",
        "prayer": "Prayer points about love...",
        "sources": [{"title": "Source 1", "link": "http://example.com"}],
        "timestamp": datetime.now().isoformat(),
    }


class TestBibleAgentInit:
    def test_has_required_attributes(self, bible_agent):
        assert hasattr(bible_agent, "model_manager")
        assert hasattr(bible_agent, "console_formatter")
        assert hasattr(bible_agent, "current_session")
        assert hasattr(bible_agent, "search_agent")

    def test_models_populated(self, bible_agent):
        assert bible_agent._models


class TestCommandProcessing:
    def test_help_command(self, bible_agent):
        result = bible_agent.process_command("help")
        assert result is not None
        assert result.get("command") == "help"

    def test_unknown_command_returns_none(self, bible_agent):
        result = bible_agent.process_command("nonexistent_command")
        assert result is None

    def test_teach_command(self, bible_agent, monkeypatch):
        monkeypatch.setattr("builtins.input", lambda _: "forgiveness")
        bible_agent.search_agent.search_and_analyze = MagicMock(return_value={
            "query": "forgiveness",
            "insights": "Insights on forgiveness",
            "sources": [],
            "timestamp": datetime.now().isoformat(),
        })
        bible_agent.model_manager.get_model.return_value.generate.return_value = (
            "Application text"
        )

        result = bible_agent.process_command("teach")
        assert result is not None
        assert result["query"] == "forgiveness"
        assert "insights" in result

    def test_verse_command(self, bible_agent):
        mock_verse = Verse(
            text="Test verse",
            reference="John 3:16",
            translation="ESV",
            category=VerseCategory.FAITH,
        )
        bible_agent.get_daily_verse = MagicMock(return_value=mock_verse)
        bible_agent.model_manager.get_model.return_value.generate.return_value = (
            "Devotional text"
        )

        result = bible_agent.process_command("verse")
        assert result is not None
        assert result["reference"] == "John 3:16"

    def test_reflect_with_no_session_content(self, bible_agent):
        # Empty session — should handle gracefully
        result = bible_agent.process_command("reflect")
        assert result is None

    def test_reflect_with_session_content(self, bible_agent, sample_teaching):
        bible_agent.current_session.add_teaching(sample_teaching)
        bible_agent.model_manager.get_model.return_value.generate.return_value = (
            "INSIGHTS:\nDeep insight.\n\nAPPLICATION:\nPractical steps.\n\nPRAYER:\nFocus."
        )
        result = bible_agent.process_command("reflect")
        assert result is not None
        assert "insights" in result
        assert "application" in result
        assert "prayer" in result


class TestSessionManagement:
    def test_add_teaching(self, bible_agent, sample_teaching):
        bible_agent.current_session.add_teaching(sample_teaching)
        assert len(bible_agent.current_session.teachings) == 1

    def test_get_latest_content_teaching(self, bible_agent, sample_teaching):
        bible_agent.current_session.add_teaching(sample_teaching)
        content = bible_agent.current_session.get_latest_content()
        assert content is not None
        assert content["type"] == "teaching"

    def test_get_latest_content_empty(self, bible_agent):
        content = bible_agent.current_session.get_latest_content()
        assert content is None

    def test_export_command(self, bible_agent, sample_teaching, tmp_path):
        bible_agent.current_session.add_teaching(sample_teaching)
        # Patch Config.DATA_DIR so files land in tmp_path
        with patch("biblia.agent.bible_agent.Config") as mock_cfg:
            mock_cfg.DATA_DIR = tmp_path
            result = bible_agent.process_command("export")
        assert result is not None
