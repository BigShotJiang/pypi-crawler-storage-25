import pytest
from biblia.agent.components.planner import Planner, ActionStep
from biblia.agent.components.goal_system import Goal, GoalPriority


@pytest.fixture
def planner():
    return Planner()


@pytest.fixture
def sample_goal():
    return Goal(
        description="Study the topic of forgiveness",
        priority=GoalPriority.HIGH,
        success_criteria=["Find relevant scripture", "Generate teaching"],
    )


@pytest.fixture
def sample_context():
    return {
        "model_type": "gemini",
        "translation": "ESV",
        "previous_studies": [],
    }


class TestPlanner:
    def test_create_plan_basic(self, planner, sample_goal, sample_context):
        plan = planner.create_plan(sample_goal, sample_context)
        assert isinstance(plan, list)

    def test_create_plan_steps_structure(self, planner, sample_goal, sample_context):
        plan = planner.create_plan(sample_goal, sample_context)
        for step in plan:
            assert hasattr(step, "tool")
            assert hasattr(step, "params")
            assert hasattr(step, "expected_outcome")
            assert isinstance(step.params, dict)
            assert isinstance(step.expected_outcome, str)

    def test_execute_plan(self, planner):
        steps = [
            ActionStep(tool="search", params={"query": "forgiveness"}, expected_outcome="Biblical references"),
            ActionStep(tool="teach", params={"topic": "forgiveness"}, expected_outcome="Teaching content"),
        ]
        results = planner.execute_plan(steps)
        assert isinstance(results, dict)
        assert "search" in results
        assert "teach" in results

    def test_plan_with_empty_goal(self, planner):
        empty_goal = Goal(
            description="",
            priority=GoalPriority.LOW,
            success_criteria=[],
        )
        plan = planner.create_plan(empty_goal, {})
        assert isinstance(plan, list)

    def test_plan_execution_error_handling(self, planner):
        invalid_step = ActionStep(tool="invalid_tool", params={}, expected_outcome="Should fail")
        with pytest.raises(Exception):
            planner.execute_plan([invalid_step])

    def test_plan_context_influence(self, planner, sample_goal):
        plan_a = planner.create_plan(sample_goal, {"previous_studies": ["love", "faith"]})
        plan_b = planner.create_plan(sample_goal, {"previous_studies": []})
        assert isinstance(plan_a, list)
        assert isinstance(plan_b, list)
