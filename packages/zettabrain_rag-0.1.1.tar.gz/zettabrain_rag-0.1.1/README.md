# ZettaBrain RAG

**Local private RAG pipeline — your documents, your hardware, zero cloud.**

---

## Install

```bash
pip install zettabrain-rag
```

Requires Python 3.10+ and [Ollama](https://ollama.com).

---

## One-time setup

### 1. Install Ollama and pull models
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3.1:8b
ollama pull nomic-embed-text
```

### 2. Mount NFS share and build vector store
```bash
sudo zettabrain-setup
```
Prompts for NFS server IP and export path, mounts at `/mnt/Rag-data`, then builds the vector store automatically.

### 3. Start chatting
```bash
zettabrain-chat
```

---

## Commands

| Command | What it does |
|---|---|
| `sudo zettabrain-setup` | NFS mount wizard + auto vector store build |
| `zettabrain-chat` | Start interactive RAG chat |
| `zettabrain-chat --rebuild` | Rebuild vector store then chat |
| `zettabrain-chat --debug` | Show retrieved chunks on every query |
| `zettabrain-ingest` | Ingest documents without starting chat |
| `zettabrain-ingest --file /path/to/file.pdf` | Ingest a single file |
| `zettabrain-ingest --stats` | Show what's in the vector store |
| `zettabrain-ingest --clear` | Wipe the vector store |
| `zettabrain-status` | Show install paths and store statistics |

---

## Directory structure after install

```
/zettabrain/
├── nfs_setup.sh              ← NFS mount wizard (run via sudo zettabrain-setup)
└── src/
    ├── 03_langchain_rag.py   ← main RAG pipeline
    ├── 05_ingest_documents.py← ingestion utility
    ├── 01_chromadb_setup.py  ← diagnostic: verify ChromaDB
    ├── 02_embeddings_test.py ← diagnostic: verify embeddings
    └── zettabrain_vectorstore/  ← auto-generated, do not commit
```

---

## Configuration via environment variables

```bash
export ZETTABRAIN_DOCS=/mnt/Rag-data          # documents folder (NFS mount)
export ZETTABRAIN_CHROMA=./zettabrain_vectorstore
export ZETTABRAIN_LLM_MODEL=llama3.1:8b
export ZETTABRAIN_EMBED_MODEL=nomic-embed-text
export ZETTABRAIN_CHUNK_SIZE=1500
export OLLAMA_HOST=http://localhost:11434
```

---

## Supported document formats

`.pdf`  `.txt`  `.md`  `.docx`

---

## Hardware guide

| RAM | Model | Notes |
|---|---|---|
| 8GB | llama3.2:3b | Basic |
| 16GB | llama3.1:8b | Recommended |
| 32GB | mistral-nemo:12b | Better reasoning |
| Apple M3/M4 | llama3.1:70b-q4 | Excellent |

---

## License

MIT — © ZettaBrain
