"""
ZettaBrain RAG — Local private retrieval-augmented generation.
100% on-device. Zero data leaves your machine.
"""

__version__ = "0.1.1"
__author__  = "Olajide"
__email__   = "olajide@zettabrain.io"
