"""
ZettaBrain RAG — CLI entry points.

Installed commands:
  zettabrain          — help / version
  zettabrain-chat     — start interactive RAG chat  (runs src/03_langchain_rag.py)
  zettabrain-ingest   — ingest documents            (runs src/05_ingest_documents.py)
  zettabrain-setup    — NFS mount wizard            (runs nfs_setup.sh)
  zettabrain-status   — vector store statistics
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path

from . import __version__

# -------------------------------------------------------
# Resolve the paths relative to this installed package
# -------------------------------------------------------
PKG_DIR  = Path(__file__).parent
REPO_DIR = PKG_DIR.parent          # project root  (/zettabrain)
SRC_DIR  = REPO_DIR / "src"        # /zettabrain/src

RAG_SCRIPT    = SRC_DIR / "03_langchain_rag.py"
INGEST_SCRIPT = SRC_DIR / "05_ingest_documents.py"
NFS_SCRIPT    = REPO_DIR / "nfs_setup.sh"

# -------------------------------------------------------
# Helpers
# -------------------------------------------------------
def _banner():
    print(f"\n╔══════════════════════════════════════════════════════╗")
    print(f"║        ZettaBrain RAG  v{__version__:<29}║")
    print(f"║  Local private AI — your data stays on device       ║")
    print(f"╚══════════════════════════════════════════════════════╝\n")


def _find_python():
    """Return the best available python3 binary."""
    # Prefer the active virtual environment interpreter
    venv = os.environ.get("VIRTUAL_ENV")
    if venv:
        venv_python = Path(venv) / "bin" / "python3"
        if venv_python.exists():
            return str(venv_python)
    # Fall back to the interpreter running this process
    return sys.executable


def _require_script(path: Path):
    if not path.exists():
        print(f"ERROR: Expected script not found: {path}")
        print("Make sure you installed from the correct repository.")
        sys.exit(1)


# -------------------------------------------------------
# zettabrain   (root help command)
# -------------------------------------------------------
def main():
    _banner()
    parser = argparse.ArgumentParser(
        prog="zettabrain",
        description="ZettaBrain RAG — local private AI over your documents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  zettabrain-setup    Run NFS mount wizard and build vector store  (requires sudo)
  zettabrain-ingest   Ingest documents into the vector store
  zettabrain-chat     Start interactive RAG chat session
  zettabrain-status   Show vector store statistics

Examples:
  sudo zettabrain-setup
  zettabrain-ingest --rebuild
  zettabrain-chat --model llama3.1:8b --debug
        """
    )
    parser.add_argument("--version", action="version", version=f"zettabrain-rag {__version__}")
    parser.parse_args()


# -------------------------------------------------------
# zettabrain-setup   (NFS wizard)
# -------------------------------------------------------
def setup_cmd():
    _banner()
    _require_script(NFS_SCRIPT)

    if os.geteuid() != 0:
        print("ERROR: NFS setup requires root privileges.")
        print("Run:   sudo zettabrain-setup\n")
        sys.exit(1)

    NFS_SCRIPT.chmod(0o755)
    result = subprocess.run(["bash", str(NFS_SCRIPT)])
    sys.exit(result.returncode)


# -------------------------------------------------------
# zettabrain-ingest
# -------------------------------------------------------
def ingest_cmd():
    _banner()
    _require_script(INGEST_SCRIPT)

    parser = argparse.ArgumentParser(
        prog="zettabrain-ingest",
        description="Ingest documents from NFS share into the vector store"
    )
    parser.add_argument("--folder", default=None,    help="Documents folder (default: /mnt/Rag-data)")
    parser.add_argument("--file",   default=None,    help="Ingest a single file")
    parser.add_argument("--clear",  action="store_true", help="Clear the entire vector store")
    parser.add_argument("--stats",  action="store_true", help="Show vector store statistics")
    args, unknown = parser.parse_known_args()

    python = _find_python()
    cmd = [python, str(INGEST_SCRIPT)]

    if args.folder: cmd += ["--folder", args.folder]
    if args.file:   cmd += ["--file",   args.file]
    if args.clear:  cmd += ["--clear"]
    if args.stats:  cmd += ["--stats"]

    os.chdir(SRC_DIR)
    result = subprocess.run(cmd)
    sys.exit(result.returncode)


# -------------------------------------------------------
# zettabrain-chat
# -------------------------------------------------------
def chat_cmd():
    _banner()
    _require_script(RAG_SCRIPT)

    parser = argparse.ArgumentParser(
        prog="zettabrain-chat",
        description="Start an interactive RAG chat session"
    )
    parser.add_argument("--rebuild", action="store_true", help="Force rebuild vector store before chatting")
    parser.add_argument("--debug",   action="store_true", help="Show retrieved chunks on every query")
    args, unknown = parser.parse_known_args()

    python = _find_python()
    cmd = [python, str(RAG_SCRIPT)]

    if args.rebuild: cmd += ["--rebuild"]
    if args.debug:   cmd += ["--debug"]

    os.chdir(SRC_DIR)
    result = subprocess.run(cmd)
    sys.exit(result.returncode)


# -------------------------------------------------------
# zettabrain-status
# -------------------------------------------------------
def status_cmd():
    _banner()

    chroma_path = SRC_DIR / "zettabrain_vectorstore"
    sqlite_db   = chroma_path / "chroma.sqlite3"
    ingest_log  = SRC_DIR / "ingested_files.json"
    nfs_config  = SRC_DIR / "nfs_config.env"

    print(f"Install root : {REPO_DIR}")
    print(f"Source dir   : {SRC_DIR}")
    print()

    # NFS config
    if nfs_config.exists():
        print("NFS Config:")
        for line in nfs_config.read_text().splitlines():
            if line and not line.startswith("#"):
                print(f"  {line}")
        print()

    # Vector store
    if sqlite_db.exists():
        size_mb = sqlite_db.stat().st_size / (1024 * 1024)
        print(f"Vector store : {chroma_path}")
        print(f"Database     : chroma.sqlite3 ({size_mb:.1f} MB)")

        import json
        if ingest_log.exists():
            data = json.loads(ingest_log.read_text())
            print(f"Tracked files: {len(data)}")
            for fp in sorted(data):
                print(f"  - {Path(fp).name}")
        print()
    else:
        print("Vector store : not built yet")
        print("Run: sudo zettabrain-setup   (or: zettabrain-ingest)\n")
