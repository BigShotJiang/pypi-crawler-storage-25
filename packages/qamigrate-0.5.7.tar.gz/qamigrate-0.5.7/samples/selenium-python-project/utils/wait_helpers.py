"""
Explicit wait utilities for reliable element interactions
"""
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from config.config import Config
from utils.logger import Logger

logger = Logger.get_logger(__name__)

class WaitHelpers:
    """Wait helper utilities"""
    
    @staticmethod
    def wait_for_element_present(driver: WebDriver, locator: tuple, timeout: int = None):
        """Wait for element to be present in DOM"""
        timeout = timeout or Config.EXPLICIT_WAIT
        try:
            return WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located(locator)
            )
        except TimeoutException:
            logger.error(f"Element not present after {timeout}s: {locator}")
            raise
    
    @staticmethod
    def wait_for_element_visible(driver: WebDriver, locator: tuple, timeout: int = None):
        """Wait for element to be visible"""
        timeout = timeout or Config.EXPLICIT_WAIT
        try:
            return WebDriverWait(driver, timeout).until(
                EC.visibility_of_element_located(locator)
            )
        except TimeoutException:
            logger.error(f"Element not visible after {timeout}s: {locator}")
            raise
    
    @staticmethod
    def wait_for_element_clickable(driver: WebDriver, locator: tuple, timeout: int = None):
        """Wait for element to be clickable"""
        timeout = timeout or Config.EXPLICIT_WAIT
        try:
            return WebDriverWait(driver, timeout).until(
                EC.element_to_be_clickable(locator)
            )
        except TimeoutException:
            logger.error(f"Element not clickable after {timeout}s: {locator}")
            raise
    
    @staticmethod
    def wait_for_text_present(driver: WebDriver, locator: tuple, text: str, timeout: int = None):
        """Wait for text to be present in element"""
        timeout = timeout or Config.EXPLICIT_WAIT
        try:
            return WebDriverWait(driver, timeout).until(
                EC.text_to_be_present_in_element(locator, text)
            )
        except TimeoutException:
            logger.error(f"Text '{text}' not present after {timeout}s in: {locator}")
            raise
    
    @staticmethod
    def wait_for_url_contains(driver: WebDriver, url_fragment: str, timeout: int = None):
        """Wait for URL to contain text"""
        timeout = timeout or Config.EXPLICIT_WAIT
        try:
            return WebDriverWait(driver, timeout).until(
                EC.url_contains(url_fragment)
            )
        except TimeoutException:
            logger.error(f"URL doesn't contain '{url_fragment}' after {timeout}s")
            raise
    
    @staticmethod
    def wait_for_title_contains(driver: WebDriver, title: str, timeout: int = None):
        """Wait for title to contain text"""
        timeout = timeout or Config.EXPLICIT_WAIT
        try:
            return WebDriverWait(driver, timeout).until(
                EC.title_contains(title)
            )
        except TimeoutException:
            logger.error(f"Title doesn't contain '{title}' after {timeout}s")
            raise
