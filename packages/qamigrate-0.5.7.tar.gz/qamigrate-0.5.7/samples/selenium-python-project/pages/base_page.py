"""
Base Page - Parent class for all page objects.

All page objects should extend this class to inherit common methods.
Uses centralized WaitHelpers for all explicit wait operations.
"""
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.common.by import By
from utils.driver_manager import DriverManager
from utils.logger import log
from utils.wait_helpers import WaitHelpers
from config.config_reader import config


class BasePage:
"""Base class for all page objects."""

def __init__(self):
self.driver: WebDriver = DriverManager.get_driver()

def click(self, locator: tuple):
"""Click an element."""
log.action(f"Click: {locator}")
WaitHelpers.wait_for_element_clickable(self.driver, locator).click()

def type_text(self, locator: tuple, text: str):
"""Type text into an element."""
log.action(f"Type into: {locator}")
element = WaitHelpers.wait_for_element_visible(self.driver, locator)
element.clear()
element.send_keys(text)

def get_text(self, locator: tuple) -> str:
"""Get text from an element."""
return WaitHelpers.wait_for_element_visible(self.driver, locator).text

def is_displayed(self, locator: tuple) -> bool:
"""Check if element is displayed."""
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
try:
return self.driver.find_element(*locator).is_displayed()
except (NoSuchElementException, StaleElementReferenceException):
return False

def wait_for_element(self, locator: tuple) -> WebElement:
"""Wait for element to be visible."""
return WaitHelpers.wait_for_element_visible(self.driver, locator)

def wait_for_clickable(self, locator: tuple) -> WebElement:
"""Wait for element to be clickable."""
return WaitHelpers.wait_for_element_clickable(self.driver, locator)

def get_title(self) -> str:
"""Get page title."""
return self.driver.title

def get_current_url(self) -> str:
"""Get current URL."""
return self.driver.current_url

def navigate_to(self, url: str):
"""Navigate to URL."""
log.step(f"Navigating to: {url}")
self.driver.get(url)

def log_action(self, message: str):
"""Log a page action."""
log.step(f"[{self.__class__.__name__}] {message}")