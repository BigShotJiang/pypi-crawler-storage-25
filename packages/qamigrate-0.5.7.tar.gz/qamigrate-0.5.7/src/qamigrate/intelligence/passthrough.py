"""
Detect files that should pass through migration untouched.

Some Java source files are pure data/config with zero Selenium-specific
syntax -- enums, interfaces, DTOs, constants classes. Running the LLM
on them is a waste: it hallucinates output that breaks code that was
already correct.

In v0.5.0 we observed this with `Environment.java`:
    - Original: standard enum with 4 constants and a fromString helper
    - Claude:   replaced `,` separators with `;`
    - GPT-4o:   dropped the constants entirely

Both failures traced back to the `generate_playwright_code` tool schema
not fitting enum syntax. The fix is not to prompt harder -- it's to
recognize these files and copy them through.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

# Regex-based detectors. Cheap, run before any LLM call.
#
# These are intentionally loose: a false POSITIVE (we treat something as
# passthrough when it could benefit from migration) is bad, so the rules
# only fire when we're certain there's nothing Selenium-related.

_ENUM_RE = re.compile(r"^\s*(?:public\s+|private\s+|protected\s+)?enum\s+\w+", re.MULTILINE)

# Matches the package declaration line so we can rewrite it.
_PACKAGE_DECL_RE = re.compile(r"^(\s*package\s+)([\w.]+)(\s*;)", re.MULTILINE)

# A file is "Selenium-free" when none of these appear.
_SELENIUM_MARKERS = (
    "org.openqa.selenium",
    "org.openqa.support",
    "org.openqa.selenium.support",
    "WebDriver",
    "WebElement",
    "@FindBy",
    "@FindBys",
    "@FindAll",
    "PageFactory",
    "org.testng",          # test class -- always migrate
    "org.junit",           # test class -- always migrate
    "Selenium",
)


def is_passthrough(file_path: Path) -> tuple[bool, str | None]:
    """
    Return (should_passthrough, reason).

    `reason` is a short human-readable string for logging when we skip.
    None when not a passthrough candidate.
    """
    try:
        src = file_path.read_text(encoding="utf-8")
    except OSError:
        return False, None

    # Never passthrough anything that mentions Selenium / WebDriver / test
    # framework annotations -- those need migration by definition.
    if any(marker in src for marker in _SELENIUM_MARKERS):
        return False, None

    # Enum: top-level `public enum Foo { ... }`. Even with no Selenium
    # content, enums deserve verbatim copy because the tool schema can't
    # represent them safely.
    if _ENUM_RE.search(src):
        return True, "enum (no Selenium markers; copying verbatim)"

    return False, None


def rewrite_package_for_passthrough(source: str) -> str:
    """Rewrite the package declaration to append `.playwright`.

    v0.5.4: passthrough files (enums, DTOs) are copied verbatim except for
    their package declaration. Without this rewrite they declare the same
    package as the original Selenium class and Maven sees two classes with
    identical FQNs, producing duplicate-symbol errors.

    `package com.example.config;`
    →  `package com.example.config.playwright;`

    If the source has no package declaration (default package), it is
    returned unchanged -- no `.playwright` prefix makes sense there.
    If the package already ends with `.playwright`, it is not doubled.
    """

    def _replace(m: re.Match) -> str:
        pkg = m.group(2)
        if pkg.endswith(".playwright"):
            return m.group(0)  # Already correct, leave unchanged.
        return f"{m.group(1)}{pkg}.playwright{m.group(3)}"

    rewritten, count = _PACKAGE_DECL_RE.subn(_replace, source)
    return rewritten if count else source


def build_signatures_from_class_info(class_info: dict[str, Any]) -> list[str]:
    """
    Produce a `sibling_signatures`-shaped list for a passthrough file.

    The cross-file hallucination detector keys off method-name substrings
    inside each signature line. For an enum like `Environment` we need
    the detector to recognize:
      - constants: `Environment.DEV`, `Environment.PROD`, ...
      - methods:   `Environment.fromString("dev")`, `Environment.getName()`

    We emit one line per constant (as a synthetic public static final
    field) and one line per declared method. The Coder prompt's sibling
    block renders these as-is, so the LLM sees the real API and stops
    inventing `Environment.DEVELOPMENT`.
    """
    sigs: list[str] = []

    # Enum constants -> "public static final Environment DEV"
    for field in class_info.get("fields", []):
        name = field.get("name")
        ftype = field.get("type") or ""
        mods = " ".join(field.get("modifiers") or [])
        if not name:
            continue
        sig = f"{mods} {ftype} {name}".strip()
        sigs.append(sig)

    # Methods -> full signature line
    for m in class_info.get("methods", []):
        name = m.get("name")
        if not name:
            continue
        mods = " ".join(m.get("modifiers") or [])
        ret = m.get("return_type") or "void"
        params = ", ".join(
            f"{p.get('type', '')} {p.get('name', '')}".strip()
            for p in (m.get("parameters") or [])
        )
        sig = f"{mods} {ret} {name}({params})".strip()
        sigs.append(sig)

    return sigs
