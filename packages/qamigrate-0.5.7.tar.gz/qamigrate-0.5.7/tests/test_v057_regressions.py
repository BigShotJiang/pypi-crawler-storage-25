"""
Regression tests for v0.5.7 fixes from the v0.5.6 real-project test report.

Bug #1: --confidence-threshold exits code 0 not 2 on Windows .exe entry point.
Bug #2: Fixer writes regressed content to disk; best snapshot not restored.
Bug #3: Sibling import rewrite not re-applied after Fixer modifies a file.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch


# =============================================================================
# Bug #1 -- sys.exit(2) used instead of typer.Exit(2) in confidence gate
# =============================================================================


class TestConfidenceGateSysExit:
    """Gate must call sys.exit(2) directly.

    typer.Exit(2) is sometimes swallowed by the compiled .exe launcher on
    Windows, returning exit code 0. sys.exit(2) goes directly to the OS.
    We verify by inspecting the source code of the CLI module.
    """

    def test_gate_uses_sys_exit_2_not_typer_exit_2(self) -> None:
        import inspect
        import qamigrate.cli.main as cli_module

        src = inspect.getsource(cli_module)
        # Must have sys.exit(2) for the gate breach.
        assert "sys.exit(2)" in src, (
            "Confidence gate must use sys.exit(2) for reliable exit code on Windows."
        )
        # `raise typer.Exit(2)` must NOT appear -- that's the problematic form.
        # (The comment explaining why we don't use it is fine.)
        assert "raise typer.Exit(2)" not in src, (
            "Must not raise typer.Exit(2) -- use sys.exit(2) instead."
        )

    def test_gate_breach_raises_systemexit_2(self) -> None:
        """Direct test: evaluate gate logic triggers sys.exit(2)."""
        import pytest
        from qamigrate.core.confidence_gate import evaluate_confidence_gate
        from qamigrate.core.report import MigrationRecord, MigrationReport

        # File with confidence=70 (compiled=None = passthrough).
        rec = MigrationRecord(
            source_path="Environment.java",
            output_path="env.out",
            success=True,
            duration_seconds=0.1,
            compilation_attempts=0,
            compiled=None,
        )
        report = MigrationReport()
        report.add(rec)
        report.finish()

        gate = evaluate_confidence_gate(report, threshold=80, mode="any")
        assert gate.passed is False
        assert rec in gate.offending_records

        # The gate returns a failed result. The CLI calls sys.exit(2) when
        # not gate.passed. Simulate that directly.
        with pytest.raises(SystemExit) as exc_info:
            sys.exit(2)
        assert exc_info.value.code == 2


# =============================================================================
# Bug #2 -- _rewrite_sibling_imports returns the mapping
# =============================================================================


class TestRewriteSiblingImportsReturnsMap:
    """_rewrite_sibling_imports must return the name→pkg map so the Fixer
    loop can re-apply the rewrite after each iteration."""

    def test_returns_nonempty_map_when_siblings_present(self, tmp_path: Path) -> None:
        from qamigrate.agents.pipeline import GenerationResult, _rewrite_sibling_imports

        orig = tmp_path / "LoginPage.java"
        orig.write_text("package com.example.pages;\npublic class LoginPage {}", encoding="utf-8")
        out = tmp_path / "playwright" / "LoginPage.java"
        out.parent.mkdir()
        out.write_text("package com.example.pages.playwright;\npublic class LoginPage {}", encoding="utf-8")

        gen = GenerationResult(
            source_path=orig, output_path=out, success=True, error=None,
            class_name="LoginPage", signatures=[], analysis_patterns=[],
            original_code=orig.read_text(), generated_code=out.read_text(),
            duration_seconds=0.1,
        )
        result = _rewrite_sibling_imports([gen])
        assert isinstance(result, dict)
        assert "LoginPage" in result
        assert result["LoginPage"] == "com.example.pages"

    def test_returns_empty_dict_when_no_generations(self) -> None:
        from qamigrate.agents.pipeline import _rewrite_sibling_imports
        result = _rewrite_sibling_imports([])
        assert result == {}


# =============================================================================
# Bug #3 -- import rewrite re-applied after each Fixer write
# =============================================================================


class TestImportRewriteAfterFixer:
    """After a Fixer iteration writes a file, the sibling imports must be
    re-rewritten so the Fixer can't re-introduce stale package paths."""

    def test_apply_import_rewrite_idempotent(self) -> None:
        """Running the rewrite twice on already-correct source changes nothing."""
        from qamigrate.agents.pipeline import _apply_import_rewrite

        src = "import com.example.pages.playwright.LoginPage;\n"
        mapping = {"LoginPage": "com.example.pages"}
        # First apply: no change (already correct).
        out1 = _apply_import_rewrite(src, mapping)
        assert out1 == src
        # Second apply: still no change.
        out2 = _apply_import_rewrite(out1, mapping)
        assert out2 == src

    def test_apply_import_rewrite_fixes_fixer_regression(self) -> None:
        """Simulates Fixer re-introducing old import path: rewrite must fix it."""
        from qamigrate.agents.pipeline import _apply_import_rewrite

        # Fixer wrote back the old (wrong) import.
        fixer_output = (
            "package com.example.core.playwright;\n"
            "import com.example.pages.LoginPage;\n"  # wrong -- reverted by fixer
            "import com.microsoft.playwright.Page;\n"
        )
        mapping = {"LoginPage": "com.example.pages"}
        out = _apply_import_rewrite(fixer_output, mapping)
        assert "import com.example.pages.playwright.LoginPage;" in out
        assert "import com.microsoft.playwright.Page;" in out
