"""Tests for SQLiteStore (requires sqlite-vec optional dependency).

Run with:
    pytest tests/test_sqlite_store.py -v
"""

from __future__ import annotations

import sqlite3

import pytest
from conftest import make_test_memory

from emotional_memory.interfaces import MemoryStore
from emotional_memory.stores.sqlite import SQLiteStore, _pack_embedding, _unpack_embedding

# Skip entire module if sqlite-vec is not installed.
# Placed after imports: stores/sqlite.py does not import sqlite-vec at module level,
# so the import above succeeds even without the optional dependency.
pytest.importorskip("sqlite_vec")

# ---------------------------------------------------------------------------
# Byte-packing helpers
# ---------------------------------------------------------------------------


class TestPackUnpackEmbedding:
    def test_round_trip(self):
        vec = [0.1, 0.5, -0.3, 1.0]
        unpacked = _unpack_embedding(_pack_embedding(vec))
        assert len(unpacked) == len(vec)
        for a, b in zip(unpacked, vec, strict=True):
            assert abs(a - b) < 1e-5

    def test_empty_embedding(self):
        assert _unpack_embedding(_pack_embedding([])) == []


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------


class TestSQLiteStoreInit:
    def test_in_memory_creates_store(self):
        store = SQLiteStore(":memory:")
        assert len(store) == 0

    def test_file_backed_creates_db(self, tmp_path):
        db_path = tmp_path / "test.db"
        store = SQLiteStore(db_path)
        assert db_path.exists()
        assert len(store) == 0
        store.close()

    def test_protocol_conformance(self):
        store = SQLiteStore(":memory:")
        assert isinstance(store, MemoryStore)


# ---------------------------------------------------------------------------
# Save / Get
# ---------------------------------------------------------------------------


class TestSQLiteStoreSaveGet:
    def test_save_and_get(self):
        store = SQLiteStore(":memory:")
        m = make_test_memory("hello")
        store.save(m)
        got = store.get(m.id)
        assert got is not None
        assert got.id == m.id
        assert got.content == m.content

    def test_save_with_embedding(self):
        store = SQLiteStore(":memory:")
        m = make_test_memory("embedded", embedding=[1.0, 0.0, 0.0])
        store.save(m)
        got = store.get(m.id)
        assert got is not None
        assert got.embedding is not None
        for a, b in zip(got.embedding, [1.0, 0.0, 0.0], strict=True):
            assert abs(a - b) < 1e-5

    def test_get_missing_returns_none(self):
        store = SQLiteStore(":memory:")
        assert store.get("does-not-exist") is None

    def test_save_replaces_existing(self):
        store = SQLiteStore(":memory:")
        m = make_test_memory("original")
        store.save(m)
        updated = m.model_copy(update={"content": "replaced"})
        store.save(updated)
        got = store.get(m.id)
        assert got is not None
        assert got.content == "replaced"
        assert len(store) == 1


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------


class TestSQLiteStoreUpdate:
    def test_update_existing(self):
        store = SQLiteStore(":memory:")
        m = make_test_memory("original")
        store.save(m)
        updated = m.model_copy(update={"content": "updated"})
        store.update(updated)
        got = store.get(m.id)
        assert got is not None
        assert got.content == "updated"

    def test_update_nonexistent_is_noop(self):
        store = SQLiteStore(":memory:")
        m = make_test_memory("ghost")
        store.update(m)  # no error, no new row
        assert len(store) == 0
        assert store.get(m.id) is None


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


class TestSQLiteStoreDelete:
    def test_delete_existing(self):
        store = SQLiteStore(":memory:")
        m = make_test_memory("bye")
        store.save(m)
        store.delete(m.id)
        assert store.get(m.id) is None
        assert len(store) == 0

    def test_delete_nonexistent_no_error(self):
        store = SQLiteStore(":memory:")
        store.delete("ghost-id")  # must not raise

    def test_delete_removes_from_vec_table(self):
        store = SQLiteStore(":memory:")
        m = make_test_memory("vec-entry", embedding=[1.0, 0.0])
        store.save(m)
        store.delete(m.id)
        results = store.search_by_embedding([1.0, 0.0], top_k=5)
        assert all(r.id != m.id for r in results)


# ---------------------------------------------------------------------------
# List all / Len
# ---------------------------------------------------------------------------


class TestSQLiteStoreListAll:
    def test_list_all_empty(self):
        store = SQLiteStore(":memory:")
        assert store.list_all() == []

    def test_list_all_returns_all(self):
        store = SQLiteStore(":memory:")
        m1 = make_test_memory("one")
        m2 = make_test_memory("two")
        m3 = make_test_memory("three")
        store.save(m1)
        store.save(m2)
        store.save(m3)
        ids = {m.id for m in store.list_all()}
        assert {m1.id, m2.id, m3.id} == ids


class TestSQLiteStoreLen:
    def test_len_empty(self):
        store = SQLiteStore(":memory:")
        assert len(store) == 0

    def test_len_after_saves(self):
        store = SQLiteStore(":memory:")
        store.save(make_test_memory("a"))
        store.save(make_test_memory("b"))
        assert len(store) == 2


# ---------------------------------------------------------------------------
# Vector search
# ---------------------------------------------------------------------------


class TestSQLiteStoreSearch:
    def test_search_returns_closest(self):
        store = SQLiteStore(":memory:")
        near = make_test_memory("near", embedding=[1.0, 0.0, 0.0])
        far = make_test_memory("far", embedding=[0.0, 0.0, 1.0])
        store.save(near)
        store.save(far)
        results = store.search_by_embedding([1.0, 0.0, 0.0], top_k=1)
        assert len(results) == 1
        assert results[0].id == near.id

    def test_search_respects_top_k(self):
        store = SQLiteStore(":memory:")
        for i in range(5):
            store.save(make_test_memory(f"item{i}", embedding=[float(i), 0.0]))
        results = store.search_by_embedding([1.0, 0.0], top_k=3)
        assert len(results) == 3

    def test_search_empty_store(self):
        store = SQLiteStore(":memory:")
        results = store.search_by_embedding([1.0, 0.0], top_k=5)
        assert results == []

    def test_brute_force_fallback(self):
        """With no vec table, falls back to brute-force cosine scan."""
        store = SQLiteStore(":memory:")
        # Save a memory without an embedding — vec table stays uninitialized
        store.save(make_test_memory("no-vec"))
        assert not store._vec_ready
        # Search runs brute-force; finds nothing since no memory has an embedding
        results = store.search_by_embedding([1.0, 0.0], top_k=5)
        assert results == []


# ---------------------------------------------------------------------------
# Context manager / close
# ---------------------------------------------------------------------------


class TestSQLiteStoreContextManager:
    def test_context_manager(self):
        with SQLiteStore(":memory:") as store:
            m = make_test_memory("ctx")
            store.save(m)
            assert store.get(m.id) is not None

    def test_close_closes_connection(self):
        store = SQLiteStore(":memory:")
        store.close()
        with pytest.raises(sqlite3.ProgrammingError):
            store.get("any-id")


# ---------------------------------------------------------------------------
# Persistence across sessions
# ---------------------------------------------------------------------------


class TestSQLiteStoreReopen:
    def test_reopen_existing_db(self, tmp_path):
        db_path = tmp_path / "persist.db"
        m = make_test_memory("persisted", embedding=[0.5, 0.5])

        # Session 1: write
        with SQLiteStore(db_path) as s1:
            s1.save(m)

        # Session 2: read
        with SQLiteStore(db_path) as s2:
            assert s2._vec_ready
            got = s2.get(m.id)
            assert got is not None
            assert got.content == "persisted"
            results = s2.search_by_embedding([0.5, 0.5], top_k=1)
            assert len(results) == 1
            assert results[0].id == m.id


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestSQLiteStoreEdgeCases:
    def test_save_without_then_with_embedding(self):
        store = SQLiteStore(":memory:")
        m_no_emb = make_test_memory("no-embedding")
        m_with_emb = make_test_memory("with-embedding", embedding=[1.0, 0.0])
        store.save(m_no_emb)
        assert not store._vec_ready
        store.save(m_with_emb)
        assert store._vec_ready
        assert store.get(m_no_emb.id) is not None
        assert store.get(m_with_emb.id) is not None

    def test_multiple_embeddings_same_dimension(self):
        store = SQLiteStore(":memory:")
        for i in range(4):
            store.save(make_test_memory(f"m{i}", embedding=[float(i), 0.0]))
        results = store.search_by_embedding([3.0, 0.0], top_k=2)
        assert len(results) == 2

    def test_update_replaces_embedding_in_vec_table(self, tmp_path):
        """update() must swap the embedding in memory_vec, not just memories."""
        store = SQLiteStore(":memory:")
        # Save with embedding [1.0, 0.0]
        m = make_test_memory("update-emb", embedding=[1.0, 0.0])
        store.save(m)

        # Search should return m as nearest to [1.0, 0.0]
        results_before = store.search_by_embedding([1.0, 0.0], top_k=1)
        assert len(results_before) == 1
        assert results_before[0].id == m.id

        # Update with embedding [0.0, 1.0]
        m_updated = m.model_copy(update={"embedding": [0.0, 1.0]})
        store.update(m_updated)

        # Search nearest to [0.0, 1.0] — should still find m
        results_after = store.search_by_embedding([0.0, 1.0], top_k=1)
        assert len(results_after) == 1
        assert results_after[0].id == m.id

    def test_dimension_mismatch_raises(self):
        """Saving a memory with a different embedding dimension must fail."""
        store = SQLiteStore(":memory:")
        store.save(make_test_memory("first", embedding=[1.0, 0.0]))  # dim=2

        # Second memory with dim=3 — sqlite-vec cannot accept mismatched dimensions
        with pytest.raises(sqlite3.OperationalError):
            store.save(make_test_memory("second", embedding=[1.0, 0.0, 0.5]))


# ---------------------------------------------------------------------------
# Concurrency (threading)
# ---------------------------------------------------------------------------


class TestSQLiteStoreConcurrency:
    def test_concurrent_reads_are_safe(self, tmp_path):
        """Multiple threads reading concurrently must not raise."""
        import threading

        db_path = tmp_path / "concurrent.db"
        store = SQLiteStore(str(db_path))
        for i in range(10):
            store.save(make_test_memory(f"mem-{i}", embedding=[float(i), 0.0]))

        errors: list[Exception] = []

        def reader() -> None:
            try:
                store.search_by_embedding([5.0, 0.0], top_k=3)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=reader) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Concurrent reads raised: {errors}"

    def test_concurrent_write_from_other_thread(self, tmp_path):
        """Writing from a different thread must not raise (check_same_thread=False)."""
        import threading

        db_path = tmp_path / "thread_write.db"
        store = SQLiteStore(str(db_path))

        errors: list[Exception] = []
        written: list[str] = []

        def writer(i: int) -> None:
            try:
                m = make_test_memory(f"thread-{i}")
                store.save(m)
                written.append(m.id)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=writer, args=(i,)) for i in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Cross-thread writes raised: {errors}"
        assert len(written) == 4


# ---------------------------------------------------------------------------
# __repr__
# ---------------------------------------------------------------------------


class TestSQLiteStoreRepr:
    def test_repr_contains_path_and_count(self):
        store = SQLiteStore(":memory:")
        store.save(make_test_memory("a"))
        r = repr(store)
        assert ":memory:" in r
        assert "1" in r


# ---------------------------------------------------------------------------
# Brute-force path with embeddings present
# ---------------------------------------------------------------------------


class TestSQLiteStoreBruteForce:
    def test_brute_force_ranks_by_cosine(self):
        """When _vec_ready=False but memories have embeddings, brute-force returns correct rank."""
        store = SQLiteStore(":memory:")
        near = make_test_memory("near", embedding=[1.0, 0.0, 0.0])
        far = make_test_memory("far", embedding=[0.0, 0.0, 1.0])
        # Insert directly into memories table (bypasses _ensure_vec → _vec_ready stays False)
        for m in (near, far):
            store._conn.execute(
                "INSERT INTO memories (id, content, data) VALUES (?, ?, ?)",
                (m.id, m.content, m.model_dump_json()),
            )
        store._conn.commit()
        assert not store._vec_ready

        results = store.search_by_embedding([1.0, 0.0, 0.0], top_k=1)
        assert len(results) == 1
        assert results[0].id == near.id


# ---------------------------------------------------------------------------
# _ensure_vec edge cases
# ---------------------------------------------------------------------------


class TestEnsureVec:
    def test_save_no_embedding_when_vec_ready_does_not_touch_vec_table(self):
        """Saving no-embedding memory when vec table exists leaves vec row count unchanged."""
        store = SQLiteStore(":memory:")
        # Seed the vec table
        store.save(make_test_memory("seed", embedding=[1.0, 0.0]))
        assert store._vec_ready

        # Save a memory without embedding — should not insert into memory_vec
        store.save(make_test_memory("no-emb"))
        # Only the seeded memory should be in the vec table
        results = store.search_by_embedding([1.0, 0.0], top_k=10)
        assert len(results) == 1, f"Expected 1 vec entry, got {len(results)}"

    def test_update_creates_vec_table(self):
        """update() with an embedding triggers vec table creation even when _vec_ready=False."""
        store = SQLiteStore(":memory:")
        # Save without embedding → _vec_ready=False
        m = make_test_memory("no-emb")
        store.save(m)
        assert not store._vec_ready

        # Now update with an embedding → _ensure_vec must create the vec table
        m_with_emb = m.model_copy(update={"embedding": [1.0, 0.0]})
        store.update(m_with_emb)
        assert store._vec_ready

        results = store.search_by_embedding([1.0, 0.0], top_k=1)
        assert len(results) == 1
        assert results[0].id == m.id

    def test_delete_when_vec_not_ready(self):
        """delete() must not raise when _vec_ready=False (vec table absent)."""
        store = SQLiteStore(":memory:")
        m = make_test_memory("no-emb")
        store.save(m)
        assert not store._vec_ready
        store.delete(m.id)  # must not raise
        assert store.get(m.id) is None


# ---------------------------------------------------------------------------
# _init_vec_from_db with empty vec table (Task 4 bug fix)
# ---------------------------------------------------------------------------


class TestInitVecFromDb:
    def test_empty_vec_table_sets_correct_dim(self, tmp_path):
        """Reopening a DB where memory_vec exists but is empty must set _dim from the schema."""
        db_path = tmp_path / "empty_vec.db"
        dim = 3

        # Session 1: save a memory with embedding (creates vec table with dim=3), then delete it
        with SQLiteStore(db_path) as s1:
            m = make_test_memory("transient", embedding=[1.0, 0.0, 0.0])
            s1.save(m)
            assert s1._dim == dim
            s1.delete(m.id)  # vec table now exists but is empty
            assert s1._vec_ready

        # Session 2: reopen — vec table exists, is empty
        with SQLiteStore(db_path) as s2:
            assert s2._vec_ready, "_vec_ready should be True (table exists)"
            assert s2._dim == dim, f"Expected _dim={dim} from schema, got {s2._dim}"


# ---------------------------------------------------------------------------
# WAL mode
# ---------------------------------------------------------------------------


class TestWALMode:
    def test_wal_mode_enabled_for_file_backed(self, tmp_path):
        db_path = tmp_path / "wal.db"
        with SQLiteStore(db_path) as store:
            row = store._conn.execute("PRAGMA journal_mode").fetchone()
            assert row[0] == "wal", f"Expected WAL mode, got {row[0]!r}"

    def test_no_wal_for_in_memory(self):
        """In-memory databases use memory journal (WAL pragma is not applied)."""
        store = SQLiteStore(":memory:")
        row = store._conn.execute("PRAGMA journal_mode").fetchone()
        # In-memory dbs use "memory" journal mode, not WAL
        assert row[0] == "memory"
