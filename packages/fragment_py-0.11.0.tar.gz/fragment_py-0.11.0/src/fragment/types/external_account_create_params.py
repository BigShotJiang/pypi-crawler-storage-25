# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ExternalAccountCreateParams"]


class ExternalAccountCreateParams(TypedDict, total=False):
    external_id: Required[str]
    """User-provided unique ID."""

    name: Required[str]
    """Name of the account."""
