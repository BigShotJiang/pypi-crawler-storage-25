"""
Sonny Labs Python SDK — public API surface.

Import everything users typically need from the top-level package; the
``client`` and ``errors`` submodules remain importable for advanced cases
(custom ``httpx`` transports, narrow exception catches).
"""

# Generated Pydantic v2 models for every schema in the OpenAPI spec.
# Re-exported here so callers can construct request bodies / parse responses
# with strict types: `from sonnylabs import Scan, ContentScanRequest`. The
# `sonnylabs._generated` namespace remains importable for direct use of the
# auto-generated `*Api` classes when you'd rather skip the hand-written
# `SonnyLabsClient` facade.
from ._generated.models.action import Action
from ._generated.models.api_key import ApiKey
from ._generated.models.api_key_created_response import ApiKeyCreatedResponse
from ._generated.models.api_key_scope import ApiKeyScope
from ._generated.models.audit_event import AuditEvent
from ._generated.models.content_container import ContentContainer
from ._generated.models.content_scan_request import ContentScanRequest
from ._generated.models.create_api_key_request import CreateApiKeyRequest
from ._generated.models.decision import Decision
from ._generated.models.detector import Detector
from ._generated.models.finding import Finding
from ._generated.models.policy import Policy
from ._generated.models.principal import Principal
from ._generated.models.problem import Problem
from ._generated.models.scan import Scan
from ._generated.models.scan_request import ScanRequest
from ._generated.models.surface import Surface
from ._generated.models.text_content import TextContent
from ._generated.models.webhook import Webhook
from ._generated.models.webhook_event_envelope import WebhookEventEnvelope
from ._webhooks import verify_webhook
from .client import SonnyLabsClient
from .errors import (
    AuthenticationError,
    IdempotencyConflictError,
    NotFoundError,
    RateLimitError,
    ScopeMissingError,
    ServerError,
    SonnyLabsError,
    ValidationError,
)

__all__ = [
    "SonnyLabsClient",
    "SonnyLabsError",
    "AuthenticationError",
    "ScopeMissingError",
    "RateLimitError",
    "IdempotencyConflictError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
    "verify_webhook",
    # Generated DTOs from the OpenAPI spec
    "Action",
    "ApiKey",
    "ApiKeyCreatedResponse",
    "ApiKeyScope",
    "AuditEvent",
    "ContentContainer",
    "ContentScanRequest",
    "CreateApiKeyRequest",
    "Decision",
    "Detector",
    "Finding",
    "Policy",
    "Principal",
    "Problem",
    "Scan",
    "ScanRequest",
    "Surface",
    "TextContent",
    "Webhook",
    "WebhookEventEnvelope",
]

__version__ = "0.2.0"
