"""
Typed exceptions for the Sonny Labs SDK.

Exceptions are mapped from RFC 9457 ``application/problem+json`` responses
returned by the API. The base class :class:`SonnyLabsError` carries the
machine-readable ``code`` field plus the surrounding metadata needed to
correlate a failure with server-side logs (``request_id``, ``trace_id``).
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

__all__ = [
    "SonnyLabsError",
    "AuthenticationError",
    "ScopeMissingError",
    "RateLimitError",
    "IdempotencyConflictError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
    "from_problem",
]


class SonnyLabsError(Exception):
    """
    Base exception for all SDK errors.

    Holds the parsed RFC 9457 ``problem+json`` envelope plus the surrounding
    HTTP context (status code, ``request_id`` echoed back from the server,
    ``trace_id`` if propagated). The machine-readable ``code`` field is the
    canonical way to branch on failure mode — never branch on the
    human-readable ``title`` or ``detail`` text.
    """

    def __init__(
        self,
        *,
        code: str,
        status: int,
        title: str = "",
        detail: str | None = None,
        request_id: str | None = None,
        trace_id: str | None = None,
        errors: Iterable[Mapping[str, Any]] | None = None,
        problem: Mapping[str, Any] | None = None,
    ) -> None:
        self.code = code
        self.status = status
        self.title = title
        self.detail = detail
        self.request_id = request_id
        self.trace_id = trace_id
        self.errors: list[Mapping[str, Any]] = list(errors) if errors else []
        self.problem: Mapping[str, Any] = dict(problem) if problem is not None else {}

        message = title or code or f"HTTP {status}"
        if detail:
            message = f"{message}: {detail}"
        if request_id:
            message = f"{message} (request_id={request_id})"
        super().__init__(message)

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}(code={self.code!r}, status={self.status}, "
            f"request_id={self.request_id!r})"
        )


class AuthenticationError(SonnyLabsError):
    """HTTP 401 — credential missing, invalid, or expired (``auth.*`` codes)."""


class ScopeMissingError(SonnyLabsError):
    """
    HTTP 403 — caller is authenticated but missing a required scope.

    Named ``ScopeMissingError`` rather than ``PermissionError`` to avoid
    shadowing the Python builtin of that name.
    """


class RateLimitError(SonnyLabsError):
    """
    HTTP 429 — caller exceeded their rate-limit budget.

    The :attr:`retry_after` attribute carries the integer ``Retry-After``
    seconds value when the server provided one.
    """

    def __init__(self, *, retry_after: int | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.retry_after = retry_after


class IdempotencyConflictError(SonnyLabsError):
    """HTTP 409 with an ``idempotency.*`` code — same key, different body."""


class ValidationError(SonnyLabsError):
    """HTTP 400 — request body or query parameters failed validation."""


class NotFoundError(SonnyLabsError):
    """HTTP 404 — resource is unknown to the caller's org."""


class ServerError(SonnyLabsError):
    """HTTP 5xx — backend failure. Safe to retry on 503 only."""


def from_problem(
    *,
    status: int,
    problem: Mapping[str, Any],
    request_id: str | None = None,
    retry_after: int | None = None,
) -> SonnyLabsError:
    """
    Map an RFC 9457 ``problem+json`` envelope to the most specific subclass.

    Selection priority:

    1. ``code`` namespace (``auth.*`` → :class:`AuthenticationError`,
       ``idempotency.*`` → :class:`IdempotencyConflictError`).
    2. HTTP ``status`` (403, 404, 429, 5xx).
    3. Fallback to :class:`SonnyLabsError`.
    """
    code = str(problem.get("code", "")) if problem else ""
    title = str(problem.get("title", "")) if problem else ""
    detail = problem.get("detail") if problem else None
    trace_id = problem.get("trace_id") if problem else None
    body_request_id = problem.get("request_id") if problem else None
    errors = problem.get("errors") if problem else None

    # Server header wins over body; both can be missing.
    resolved_request_id = request_id or body_request_id

    common: dict[str, Any] = {
        "code": code or f"http.{status}",
        "status": status,
        "title": title,
        "detail": detail,
        "request_id": resolved_request_id,
        "trace_id": trace_id,
        "errors": errors,
        "problem": problem,
    }

    if code.startswith("auth."):
        return AuthenticationError(**common)
    if code.startswith("idempotency."):
        return IdempotencyConflictError(**common)
    if status == 401:
        return AuthenticationError(**common)
    if status == 403:
        return ScopeMissingError(**common)
    if status == 404:
        return NotFoundError(**common)
    if status == 409:
        # Non-idempotency 409s — return generic conflict-like base error.
        return SonnyLabsError(**common)
    if status == 429:
        return RateLimitError(retry_after=retry_after, **common)
    if status == 400:
        return ValidationError(**common)
    if 500 <= status < 600:
        return ServerError(**common)
    return SonnyLabsError(**common)
