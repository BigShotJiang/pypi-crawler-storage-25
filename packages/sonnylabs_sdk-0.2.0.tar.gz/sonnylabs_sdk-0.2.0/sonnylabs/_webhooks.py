"""
Webhook signature verification.

Sonny Labs signs every outbound webhook with HMAC-SHA256 over the
canonical string ``"{timestamp}.{body}"`` and exposes the timestamp +
signature in the ``Sonny-Signature`` header as a comma-separated list of
``key=value`` pairs (``t=<unix_seconds>,v1=<hex_digest>``).

Receivers MUST:

1. Recompute the HMAC over the **raw** request body using the shared
   webhook secret. Do NOT JSON-parse and re-serialize first — the
   reformatted bytes will not match the digest.
2. Compare digests with a constant-time comparator
   (:func:`hmac.compare_digest`) to defeat timing attacks.
3. Reject deliveries whose ``t`` value falls outside a configurable
   replay window (default 300s / 5 min) so an attacker who once captures
   a delivery cannot replay it indefinitely.

This module exposes :func:`verify_webhook` as the public API.
"""

from __future__ import annotations

import hmac
import time
from hashlib import sha256

__all__ = ["verify_webhook"]


def _parse_signature_header(header: str) -> tuple[int | None, list[str]]:
    """
    Parse a ``Sonny-Signature`` header into ``(timestamp, [v1_signatures])``.

    The header is a comma-separated list of ``key=value`` pairs. Multiple
    ``v1=`` entries are allowed (used during signing-secret rotation: the
    server signs with the new secret and the old one in the same delivery
    so the receiver continues to verify against either).

    Returns ``(None, [])`` for any malformed input — callers treat that as
    a hard failure rather than raising, mirroring the
    constant-time-comparison pattern used elsewhere.
    """
    timestamp: int | None = None
    signatures: list[str] = []
    for raw_part in header.split(","):
        part = raw_part.strip()
        if not part or "=" not in part:
            continue
        key, _, value = part.partition("=")
        key = key.strip()
        value = value.strip()
        if key == "t":
            try:
                timestamp = int(value)
            except ValueError:
                # Malformed timestamp — surface as "no timestamp" so the
                # outer verify call rejects the delivery.
                return None, []
        elif key == "v1":
            if value:
                signatures.append(value)
    return timestamp, signatures


def verify_webhook(
    body: bytes,
    signature_header: str,
    secret: str,
    *,
    tolerance_s: int = 300,
    now: float | None = None,
) -> bool:
    """
    Verify an outbound webhook signature.

    Parameters
    ----------
    body:
        The exact bytes of the request body, untouched by any JSON
        normalisation.
    signature_header:
        Value of the ``Sonny-Signature`` header
        (e.g. ``"t=1717171717,v1=abcd..."``).
    secret:
        The webhook signing secret returned at webhook creation /
        rotation.
    tolerance_s:
        Replay-protection window in seconds. Deliveries older than this
        are rejected. Defaults to 300 (5 minutes).
    now:
        Override for the current unix time, in seconds. Tests inject a
        fixed value here; production callers should never set it.

    Returns
    -------
    bool
        ``True`` iff the timestamp is within tolerance AND at least one
        ``v1`` signature in the header matches the recomputed HMAC. Any
        malformed input — wrong header shape, missing timestamp, missing
        body, empty secret — returns ``False`` rather than raising, so
        upstream code can branch on the boolean without try/except
        nesting.
    """
    if not signature_header or not secret:
        return False
    if not isinstance(body, (bytes, bytearray)):
        return False

    timestamp, presented = _parse_signature_header(signature_header)
    if timestamp is None or not presented:
        return False

    current = int(now if now is not None else time.time())
    if abs(current - timestamp) > tolerance_s:
        return False

    signed_payload = f"{timestamp}.".encode() + bytes(body)
    expected = hmac.new(secret.encode("utf-8"), signed_payload, sha256).hexdigest()

    # Constant-time check against every presented v1 signature so secret
    # rotation (two valid signatures during the cutover window) keeps
    # working without leaking which one matched via timing.
    matched = False
    for candidate in presented:
        if hmac.compare_digest(expected, candidate):
            matched = True
    return matched
