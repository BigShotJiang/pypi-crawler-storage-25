"""
:class:`SonnyLabsClient` — synchronous Python client for the Sonny Labs API.

The client is hand-written until the OpenAPI codegen pipeline (Unit 3)
lands; method names mirror the spec ``operationId``s in snake_case so that
the eventual generated layer is a drop-in delegate. Until then this module
covers the operations the launch posture demands:

* Health probes — :meth:`get_liveness`, :meth:`get_readiness`,
  :meth:`get_health`.
* Identity — :meth:`get_me`.
* Hot path — :meth:`create_scan` (content scans only; toolset / SSE are
  deferred), :meth:`list_scans`, :meth:`get_scan`.
* Key management — :meth:`list_api_keys`, :meth:`create_api_key`,
  :meth:`revoke_api_key`.
* Discovery — :meth:`list_policies`.

Other operations from the spec are exposed as ``NotImplementedError`` stubs
so call sites get a clear failure mode (rather than a silent
``AttributeError``) until codegen ships.
"""

from __future__ import annotations

import json as _json
import time
import uuid
from collections.abc import Iterable, Mapping
from typing import Any

import httpx
from pydantic import ValidationError as _PydanticValidationError

from ._webhooks import verify_webhook
from .errors import (
    SonnyLabsError,
    from_problem,
)

__all__ = ["SonnyLabsClient", "USER_AGENT"]


_VERSION = "0.1.0"
USER_AGENT = f"sonnylabs-python/{_VERSION} httpx/{httpx.__version__}"

# Methods that are safe to retry without an idempotency key.
_RETRY_SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "DELETE", "PUT"})

# Status codes the SDK retries automatically (429 rate limit, 503 not
# ready). Other 5xx responses bubble up; the caller decides whether to
# replay.
_RETRYABLE_STATUSES = frozenset({429, 503})


def _coerce_retry_after(value: str | None) -> int | None:
    """
    Best-effort parse of ``Retry-After``.

    The header may be either ``delta-seconds`` (integer) or an HTTP-date.
    The SDK only honours the integer form for now — the HTTP-date form is
    rarely emitted by APIs and parsing it pulls in ``email.utils``;
    callers can fall back to the default backoff schedule when the
    parser cannot interpret the value.
    """
    if value is None:
        return None
    try:
        return max(0, int(value.strip()))
    except (TypeError, ValueError):
        return None


class SonnyLabsClient:
    """
    Synchronous client for the Sonny Labs API.

    Parameters
    ----------
    api_key:
        Bearer credential — either a scoped API key (``sk_live_...`` /
        ``sk_test_...``) or a WorkOS session JWT.
    base_url:
        API root. Defaults to the SaaS endpoint
        (``https://api.sonnylabs.ai``); self-hosted callers point at
        their own ingress.
    api_version:
        Optional date version pin (``2026-06-01`` shape). When omitted
        the server picks the latest stable.
    timeout_s:
        Per-request timeout in seconds. Default 30s; raise this for
        large content scans, lower it for health-probe call sites.
    max_retries:
        Cap on automatic retries for 429 / 503 responses. Set to ``0``
        to disable retries entirely; tests often want this so they can
        assert the first failed response surfaced.
    transport:
        Optional :class:`httpx.BaseTransport` for testing — lets the
        test suite swap in a recording transport without monkey-patching.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.sonnylabs.ai",
        api_version: str | None = None,
        timeout_s: float = 30.0,
        max_retries: int = 3,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        if max_retries < 0:
            raise ValueError("max_retries must be >= 0")

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._api_version = api_version
        self._timeout_s = timeout_s
        self._max_retries = max_retries

        headers: dict[str, str] = {
            "Authorization": f"Bearer {api_key}",
            "User-Agent": USER_AGENT,
            "Accept": "application/json, application/problem+json",
        }
        if api_version:
            headers["Sonny-Api-Version"] = api_version

        self._client = httpx.Client(
            base_url=self._base_url,
            headers=headers,
            timeout=timeout_s,
            transport=transport,
        )

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #

    def __enter__(self) -> SonnyLabsClient:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        """Release the underlying connection pool."""
        self._client.close()

    def __repr__(self) -> str:
        return (
            f"SonnyLabsClient(base_url={self._base_url!r}, "
            f"api_version={self._api_version!r})"
        )

    # ------------------------------------------------------------------ #
    # Webhook verification (re-exposed as a method for ergonomic discovery)
    # ------------------------------------------------------------------ #

    @staticmethod
    def verify_webhook(
        body: bytes,
        signature_header: str,
        secret: str,
        *,
        tolerance_s: int = 300,
    ) -> bool:
        """
        Verify a Sonny Labs webhook signature.

        Thin wrapper around :func:`sonnylabs.verify_webhook` so callers
        who already hold a client instance don't need a second import.
        """
        return verify_webhook(
            body, signature_header, secret, tolerance_s=tolerance_s
        )

    # ------------------------------------------------------------------ #
    # Internal request plumbing
    # ------------------------------------------------------------------ #

    def _build_extra_headers(
        self,
        *,
        method: str,
        idempotency_key: str | None,
        auto_idempotency: bool,
    ) -> dict[str, str]:
        """
        Compute per-call headers layered on top of the client defaults.

        For POSTs we mint an ``Idempotency-Key`` automatically when the
        caller didn't supply one (and didn't opt out via
        ``idempotency_key=None`` plus ``auto_idempotency=False``); this
        is what lets the SDK retry transient 429/503 failures on POST
        without risking duplicated side-effects.
        """
        headers: dict[str, str] = {}
        if method == "POST":
            if idempotency_key is not None:
                headers["Idempotency-Key"] = idempotency_key
            elif auto_idempotency:
                headers["Idempotency-Key"] = f"sdk-{uuid.uuid4()}"
        elif idempotency_key is not None:
            # Spec only declares Idempotency-Key on POSTs, but if a caller
            # explicitly passes one for some reason we still forward it.
            headers["Idempotency-Key"] = idempotency_key
        return headers

    def _retry_eligible(
        self,
        *,
        method: str,
        request_headers: Mapping[str, str],
        attempt: int,
        status: int,
    ) -> bool:
        """
        Decide whether to retry a failed response.

        We retry only on 429 / 503 to match the spec's ``Retry-After``
        contract; bare 5xx (500/502/504) is **not** retried because the
        API has not advertised those as safe to replay. POSTs are only
        retried when an ``Idempotency-Key`` is in flight, since that is
        the only way the server can dedup a replay safely.
        """
        if attempt >= self._max_retries:
            return False
        if status not in _RETRYABLE_STATUSES:
            return False
        if method in _RETRY_SAFE_METHODS:
            return True
        if method == "POST" and "Idempotency-Key" in request_headers:
            return True
        return False

    def _sleep_for_retry(
        self, *, attempt: int, retry_after: int | None
    ) -> None:
        """
        Block before the next attempt.

        Honours ``Retry-After`` when the server provided one; otherwise
        backs off as ``min(0.5 * 2 ** attempt, 8)`` seconds — capped
        well below the request timeout so a slow recovery never starves
        the call.
        """
        if retry_after is not None:
            time.sleep(retry_after)
            return
        time.sleep(min(0.5 * (2 ** attempt), 8.0))

    def _parse_problem(
        self, response: httpx.Response
    ) -> tuple[Mapping[str, Any], int | None]:
        """
        Pull a ``problem+json`` envelope (and ``Retry-After``) off a
        non-2xx response.

        Falls back to a synthesised problem when the server returns a
        non-JSON body (load balancer error pages etc.) so the caller
        always gets a typed exception.
        """
        retry_after = _coerce_retry_after(response.headers.get("Retry-After"))
        try:
            problem = response.json()
            if not isinstance(problem, dict):
                raise ValueError("non-object problem body")
        except (ValueError, _json.JSONDecodeError):
            problem = {
                "type": "about:blank",
                "title": response.reason_phrase or "HTTP error",
                "status": response.status_code,
                "code": f"http.{response.status_code}",
                "detail": response.text[:500] or None,
            }
        return problem, retry_after

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json: Any | None = None,
        idempotency_key: str | None = None,
        auto_idempotency: bool = True,
        extra_headers: Mapping[str, str] | None = None,
        expected_statuses: Iterable[int] = (200, 201, 204),
    ) -> Any | None:
        """
        Issue an HTTP request and return the parsed JSON body.

        Returns ``None`` for 204s. Raises a :class:`SonnyLabsError`
        subclass for any non-success status; the precise type is chosen
        from the problem+json ``code`` namespace and HTTP status by
        :func:`sonnylabs.errors.from_problem`.
        """
        # Same auto-generated Idempotency-Key is reused across retries on
        # purpose: the server is required to replay the original response,
        # which is what makes retrying a POST safe.
        per_call_headers = self._build_extra_headers(
            method=method,
            idempotency_key=idempotency_key,
            auto_idempotency=auto_idempotency,
        )
        if extra_headers:
            per_call_headers.update(extra_headers)

        # Drop None-valued query params so callers can pass kwargs directly.
        cleaned_params: dict[str, Any] | None = None
        if params is not None:
            cleaned_params = {k: v for k, v in params.items() if v is not None}
            if not cleaned_params:
                cleaned_params = None

        last_exc: BaseException | None = None
        attempts = self._max_retries + 1
        for attempt in range(attempts):
            try:
                response = self._client.request(
                    method,
                    path,
                    params=cleaned_params,
                    json=json,
                    headers=per_call_headers or None,
                )
            except httpx.HTTPError as exc:
                # Network-level failure — retry on the same conditions as
                # 503 (treat it as "service not ready") but never replay
                # a non-idempotent POST.
                last_exc = exc
                if self._retry_eligible(
                    method=method,
                    request_headers=per_call_headers,
                    attempt=attempt,
                    status=503,
                ):
                    self._sleep_for_retry(attempt=attempt, retry_after=None)
                    continue
                raise SonnyLabsError(
                    code="transport.error",
                    status=0,
                    title="Transport error",
                    detail=str(exc),
                ) from exc

            if response.status_code in expected_statuses:
                if response.status_code == 204 or not response.content:
                    return None
                try:
                    return response.json()
                except _json.JSONDecodeError as exc:
                    raise SonnyLabsError(
                        code="response.invalid_json",
                        status=response.status_code,
                        title="Server returned non-JSON body",
                        detail=str(exc),
                        request_id=response.headers.get("X-Request-Id"),
                    ) from exc

            # Error path
            problem, retry_after = self._parse_problem(response)
            if self._retry_eligible(
                method=method,
                request_headers=per_call_headers,
                attempt=attempt,
                status=response.status_code,
            ):
                self._sleep_for_retry(attempt=attempt, retry_after=retry_after)
                continue

            raise from_problem(
                status=response.status_code,
                problem=problem,
                request_id=response.headers.get("X-Request-Id"),
                retry_after=retry_after,
            )

        # Loop fell through without returning or raising — only reachable
        # when every attempt was a transport failure that we treated as
        # retryable. Re-raise the last exception.
        assert last_exc is not None  # nosec - branch is exhaustive otherwise
        raise SonnyLabsError(
            code="transport.error",
            status=0,
            title="Transport error",
            detail=str(last_exc),
        ) from last_exc

    # ------------------------------------------------------------------ #
    # Health
    # ------------------------------------------------------------------ #

    def get_health(self) -> Mapping[str, Any]:
        """``GET /health`` — legacy liveness probe."""
        result = self._request("GET", "/health")
        return _ensure_mapping(result, "get_health")

    def get_liveness(self) -> Mapping[str, Any]:
        """``GET /healthz`` — k8s-style liveness probe."""
        result = self._request("GET", "/healthz")
        return _ensure_mapping(result, "get_liveness")

    def get_readiness(self) -> Mapping[str, Any]:
        """``GET /readyz`` — readiness probe (DB + bundle loaded)."""
        result = self._request("GET", "/readyz")
        return _ensure_mapping(result, "get_readiness")

    # ------------------------------------------------------------------ #
    # Identity
    # ------------------------------------------------------------------ #

    def get_me(self) -> Mapping[str, Any]:
        """``GET /v1/me`` — return the resolved principal."""
        result = self._request("GET", "/v1/me")
        return _ensure_mapping(result, "get_me")

    # ------------------------------------------------------------------ #
    # API keys
    # ------------------------------------------------------------------ #

    def list_api_keys(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> Mapping[str, Any]:
        """``GET /v1/api-keys`` — paginated list of org-owned API keys."""
        result = self._request(
            "GET",
            "/v1/api-keys",
            params={"cursor": cursor, "limit": limit},
        )
        return _ensure_mapping(result, "list_api_keys")

    def create_api_key(
        self,
        *,
        name: str,
        scopes: list[str],
        environment: str | None = None,
        expires_at: str | None = None,
        no_expiry: bool | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        """
        ``POST /v1/api-keys`` — mint a scoped key.

        The plaintext ``secret`` is returned **once** in the response
        body. Persist it securely; subsequent reads only surface the
        prefix and last four characters.
        """
        body: dict[str, Any] = {"name": name, "scopes": list(scopes)}
        if environment is not None:
            body["environment"] = environment
        if expires_at is not None:
            body["expires_at"] = expires_at
        if no_expiry is not None:
            body["no_expiry"] = no_expiry
        result = self._request(
            "POST",
            "/v1/api-keys",
            json=body,
            idempotency_key=idempotency_key,
        )
        return _ensure_mapping(result, "create_api_key")

    def revoke_api_key(self, api_key_id: str) -> None:
        """``DELETE /v1/api-keys/{api_key_id}`` — revoke a key."""
        self._request("DELETE", f"/v1/api-keys/{api_key_id}")

    def rotate_api_key(
        self,
        api_key_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        """``POST /v1/api-keys/{api_key_id}/rotate`` — rotate a key."""
        result = self._request(
            "POST",
            f"/v1/api-keys/{api_key_id}/rotate",
            idempotency_key=idempotency_key,
        )
        return _ensure_mapping(result, "rotate_api_key")

    # ------------------------------------------------------------------ #
    # Scans (hot path)
    # ------------------------------------------------------------------ #

    def create_scan(
        self,
        *,
        surface: str,
        content: Mapping[str, Any],
        context: Mapping[str, Any] | None = None,
        options: Mapping[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> Mapping[str, Any]:
        """
        ``POST /v1/scans`` — run a content scan.

        Toolset scans and SSE streaming responses are out of scope for
        v0.1.0 of the SDK; pass ``kind="content"`` shape via the
        documented arguments and the SDK fills in the discriminator.
        """
        body: dict[str, Any] = {
            "kind": "content",
            "surface": surface,
            "content": dict(content),
        }
        if context is not None:
            body["context"] = dict(context)
        if options is not None:
            body["options"] = dict(options)
        result = self._request(
            "POST",
            "/v1/scans",
            json=body,
            idempotency_key=idempotency_key,
        )
        return _ensure_mapping(result, "create_scan")

    def list_scans(
        self,
        *,
        agent_id: str | None = None,
        session_id: str | None = None,
        action: str | None = None,
        surface: str | None = None,
        since: str | None = None,
        until: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> Mapping[str, Any]:
        """``GET /v1/scans`` — paginated, filterable scan history."""
        result = self._request(
            "GET",
            "/v1/scans",
            params={
                "agent_id": agent_id,
                "session_id": session_id,
                "action": action,
                "surface": surface,
                "since": since,
                "until": until,
                "cursor": cursor,
                "limit": limit,
            },
        )
        return _ensure_mapping(result, "list_scans")

    def get_scan(self, scan_id: str) -> Mapping[str, Any]:
        """``GET /v1/scans/{scan_id}`` — fetch a single scan record."""
        result = self._request("GET", f"/v1/scans/{scan_id}")
        return _ensure_mapping(result, "get_scan")

    # ------------------------------------------------------------------ #
    # Policies
    # ------------------------------------------------------------------ #

    def list_policies(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> Mapping[str, Any]:
        """``GET /v1/policies`` — paginated policy listing."""
        result = self._request(
            "GET",
            "/v1/policies",
            params={"cursor": cursor, "limit": limit},
        )
        return _ensure_mapping(result, "list_policies")

    # ------------------------------------------------------------------ #
    # Stubs — operations defined in the spec but not yet implemented in
    # the hand-rolled client. Each one raises NotImplementedError with the
    # exact operationId so future codegen runs (Unit 3) can grep for them.
    # ------------------------------------------------------------------ #

    def list_invites(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=listInvites — implement in codegen pass"
        )

    def create_invite(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=createInvite — implement in codegen pass"
        )

    def revoke_invite(self, *_: Any, **__: Any) -> None:
        raise NotImplementedError(
            "TODO operationId=revokeInvite — implement in codegen pass"
        )

    def accept_invite(self, *_: Any, **__: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=acceptInvite — implement in codegen pass"
        )

    def list_users(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=listUsers — implement in codegen pass"
        )

    def create_organization(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=createOrganization — implement in codegen pass"
        )

    def create_policy(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=createPolicy — implement in codegen pass"
        )

    def get_policy(self, *_: Any, **__: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=getPolicy — implement in codegen pass"
        )

    def replace_policy(self, *_: Any, **__: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=replacePolicy — implement in codegen pass"
        )

    def delete_policy(self, *_: Any, **__: Any) -> None:
        raise NotImplementedError(
            "TODO operationId=deletePolicy — implement in codegen pass"
        )

    def simulate_policy(self, *_: Any, **__: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=simulatePolicy — implement in codegen pass"
        )

    def list_webhooks(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=listWebhooks — implement in codegen pass"
        )

    def create_webhook(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=createWebhook — implement in codegen pass"
        )

    def get_webhook(self, *_: Any, **__: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=getWebhook — implement in codegen pass"
        )

    def delete_webhook(self, *_: Any, **__: Any) -> None:
        raise NotImplementedError(
            "TODO operationId=deleteWebhook — implement in codegen pass"
        )

    def rotate_webhook_secret(self, *_: Any, **__: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=rotateWebhookSecret — implement in codegen pass"
        )

    def list_webhook_deliveries(self, *_: Any, **__: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=listWebhookDeliveries — implement in codegen pass"
        )

    def redeliver_webhook(self, *_: Any, **__: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=redeliverWebhook — implement in codegen pass"
        )

    def list_audit_events(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=listAuditEvents — implement in codegen pass"
        )

    def list_detectors(self, **_: Any) -> Mapping[str, Any]:
        raise NotImplementedError(
            "TODO operationId=listDetectors — implement in codegen pass"
        )


def _ensure_mapping(value: Any, operation: str) -> Mapping[str, Any]:
    """
    Defensive guard: every operation in the spec returns a JSON object.

    If the server responds with a non-object body — ``[]`` or a bare
    string — surface a typed error rather than handing the caller a
    surprising shape. This is cheap insurance against gateway-level
    misconfigurations (e.g. an HTML error page slipping through with a
    200 status) and intentionally distinct from the ``Pydantic``-based
    deeper validation that codegen will introduce.
    """
    if isinstance(value, dict):
        return value
    raise SonnyLabsError(
        code="response.unexpected_shape",
        status=200,
        title=f"{operation} returned a non-object body",
        detail=f"got type {type(value).__name__}",
    )


# Re-export pydantic's ValidationError under its expected name so codegen
# users can `from sonnylabs.client import _PydanticValidationError`. Kept
# private (leading underscore) until codegen lands so we can rename
# without a deprecation cycle.
_PydanticValidationError = _PydanticValidationError  # noqa: PLW0127
