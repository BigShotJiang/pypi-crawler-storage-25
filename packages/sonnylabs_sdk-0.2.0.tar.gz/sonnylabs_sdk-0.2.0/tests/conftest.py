"""
Shared fixtures.

The integration tests run against ``pytest-httpserver``, a real local
HTTP server. Centralising the client wiring here means every test
exercises the same retry / header / auth path the production SDK uses —
no monkey-patches.
"""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from pytest_httpserver import HTTPServer

from sonnylabs import SonnyLabsClient


@pytest.fixture
def client(httpserver: HTTPServer) -> Iterator[SonnyLabsClient]:
    """A client pointed at the test HTTP server with retries disabled.

    Disabling retries (``max_retries=0``) keeps test failures crisp:
    every assertion sees the first response the server emitted, with no
    backoff masking the signal. Tests that explicitly need to exercise
    retry behaviour build their own client.
    """
    base_url = httpserver.url_for("").rstrip("/")
    client = SonnyLabsClient(
        api_key="sk_test_unit",
        base_url=base_url,
        max_retries=0,
    )
    try:
        yield client
    finally:
        client.close()
