"""
Unit tests for :mod:`sonnylabs.errors` — pure mapping logic, no network.
"""

from __future__ import annotations

from sonnylabs.errors import (
    AuthenticationError,
    IdempotencyConflictError,
    NotFoundError,
    RateLimitError,
    ScopeMissingError,
    ServerError,
    SonnyLabsError,
    ValidationError,
    from_problem,
)


def test_auth_namespace_routes_to_authentication_error() -> None:
    err = from_problem(
        status=401,
        problem={
            "type": "https://docs.sonnylabs.ai/errors/auth.api_key.expired",
            "title": "API key expired",
            "status": 401,
            "code": "auth.api_key.expired",
            "detail": "Rotate your key.",
        },
        request_id="req_123",
    )
    assert isinstance(err, AuthenticationError)
    assert err.code == "auth.api_key.expired"
    assert err.status == 401
    assert err.request_id == "req_123"
    assert err.detail == "Rotate your key."


def test_idempotency_namespace_routes_regardless_of_status() -> None:
    err = from_problem(
        status=409,
        problem={
            "type": "about:blank",
            "title": "Conflict",
            "status": 409,
            "code": "idempotency.key_reuse_mismatch",
        },
    )
    assert isinstance(err, IdempotencyConflictError)
    assert err.code == "idempotency.key_reuse_mismatch"


def test_403_routes_to_scope_missing_when_no_namespace_match() -> None:
    err = from_problem(
        status=403,
        problem={"type": "about:blank", "title": "Forbidden", "status": 403, "code": "scope.missing"},
    )
    assert isinstance(err, ScopeMissingError)


def test_404_routes_to_not_found() -> None:
    err = from_problem(
        status=404,
        problem={"type": "about:blank", "title": "Not found", "status": 404, "code": "scan.not_found"},
    )
    assert isinstance(err, NotFoundError)


def test_400_routes_to_validation_error_carrying_errors_list() -> None:
    err = from_problem(
        status=400,
        problem={
            "type": "about:blank",
            "title": "Validation failed",
            "status": 400,
            "code": "validation.error",
            "errors": [{"path": "/surface", "code": "validation.required"}],
        },
    )
    assert isinstance(err, ValidationError)
    assert err.errors == [{"path": "/surface", "code": "validation.required"}]


def test_429_routes_to_rate_limit_with_retry_after() -> None:
    err = from_problem(
        status=429,
        problem={"type": "about:blank", "title": "Slow down", "status": 429, "code": "rate_limit.exceeded"},
        retry_after=30,
    )
    assert isinstance(err, RateLimitError)
    assert err.retry_after == 30


def test_5xx_routes_to_server_error() -> None:
    err = from_problem(
        status=502,
        problem={"type": "about:blank", "title": "Bad gateway", "status": 502, "code": "upstream.bad_gateway"},
    )
    assert isinstance(err, ServerError)


def test_unmapped_status_falls_back_to_base_class() -> None:
    err = from_problem(
        status=418,
        problem={"type": "about:blank", "title": "Teapot", "status": 418, "code": "fun.teapot"},
    )
    # Not an instance of any of the specific subclasses, but still a
    # SonnyLabsError so callers can `except SonnyLabsError` once and
    # catch every failure mode.
    assert type(err) is SonnyLabsError
    assert err.code == "fun.teapot"


def test_synthetic_code_used_when_problem_omits_code() -> None:
    err = from_problem(status=500, problem={})
    assert err.code == "http.500"
    assert isinstance(err, ServerError)


def test_request_id_header_takes_precedence_over_body() -> None:
    err = from_problem(
        status=500,
        problem={
            "type": "about:blank",
            "title": "Boom",
            "status": 500,
            "code": "internal.error",
            "request_id": "from-body",
        },
        request_id="from-header",
    )
    assert err.request_id == "from-header"


def test_str_includes_code_detail_request_id() -> None:
    err = from_problem(
        status=401,
        problem={
            "type": "about:blank",
            "title": "API key expired",
            "status": 401,
            "code": "auth.api_key.expired",
            "detail": "Rotate it.",
        },
        request_id="req_999",
    )
    rendered = str(err)
    assert "API key expired" in rendered
    assert "Rotate it." in rendered
    assert "req_999" in rendered
