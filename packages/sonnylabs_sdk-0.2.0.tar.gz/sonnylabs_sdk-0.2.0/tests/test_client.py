"""
Integration tests for :class:`SonnyLabsClient` against ``pytest-httpserver``.

These exercise the full HTTP stack — headers, retry decisions, problem+json
decoding — rather than mocking out :mod:`httpx`. That's the only way to
catch regressions in the actual wire shape the API emits (e.g. spec drift
on header names, missing ``Idempotency-Key`` plumbing).
"""

from __future__ import annotations

import json

import httpx
import pytest
from pytest_httpserver import HTTPServer

from sonnylabs import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ScopeMissingError,
    SonnyLabsClient,
    SonnyLabsError,
    ValidationError,
)


def _problem(**kwargs: object) -> bytes:
    base = {"type": "about:blank", "title": "", "status": 0, "code": ""}
    base.update(kwargs)
    return json.dumps(base).encode("utf-8")


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


def test_client_constructs_and_repr_does_not_leak_api_key() -> None:
    c = SonnyLabsClient(api_key="sk_test_xxx", base_url="http://localhost:9999")
    rendered = repr(c)
    assert "sk_test_xxx" not in rendered
    assert "http://localhost:9999" in rendered
    c.close()


def test_client_rejects_empty_api_key() -> None:
    with pytest.raises(ValueError):
        SonnyLabsClient(api_key="")


def test_client_rejects_negative_max_retries() -> None:
    with pytest.raises(ValueError):
        SonnyLabsClient(api_key="sk_test_xxx", max_retries=-1)


# ---------------------------------------------------------------------------
# Headers
# ---------------------------------------------------------------------------


def test_default_headers_set_authorization_user_agent_and_accept(
    httpserver: HTTPServer,
) -> None:
    httpserver.expect_request("/healthz").respond_with_json({"status": "ok"})
    client = SonnyLabsClient(
        api_key="sk_live_abc",
        base_url=httpserver.url_for("").rstrip("/"),
        max_retries=0,
    )
    try:
        client.get_liveness()
    finally:
        client.close()
    request = httpserver.log[-1][0]
    assert request.headers["Authorization"] == "Bearer sk_live_abc"
    assert request.headers["User-Agent"].startswith("sonnylabs-python/0.1.0 httpx/")
    assert "application/json" in request.headers["Accept"]
    assert "application/problem+json" in request.headers["Accept"]
    # No version pin → header must not be present at all.
    assert "Sonny-Api-Version" not in request.headers


def test_api_version_header_set_when_provided(httpserver: HTTPServer) -> None:
    httpserver.expect_request("/healthz").respond_with_json({"status": "ok"})
    client = SonnyLabsClient(
        api_key="sk_live_abc",
        base_url=httpserver.url_for("").rstrip("/"),
        api_version="2026-06-01",
        max_retries=0,
    )
    try:
        client.get_liveness()
    finally:
        client.close()
    request = httpserver.log[-1][0]
    assert request.headers["Sonny-Api-Version"] == "2026-06-01"


# ---------------------------------------------------------------------------
# Health + identity
# ---------------------------------------------------------------------------


def test_get_liveness_returns_status(client: SonnyLabsClient, httpserver: HTTPServer) -> None:
    httpserver.expect_request("/healthz").respond_with_json({"status": "ok"})
    assert client.get_liveness() == {"status": "ok"}


def test_get_readiness_503_raises_server_error(
    client: SonnyLabsClient, httpserver: HTTPServer
) -> None:
    httpserver.expect_request("/readyz").respond_with_data(
        _problem(status=503, code="readiness.bundle_loading", title="Loading"),
        status=503,
        content_type="application/problem+json",
    )
    with pytest.raises(SonnyLabsError) as exc_info:
        client.get_readiness()
    assert exc_info.value.status == 503
    assert exc_info.value.code == "readiness.bundle_loading"


def test_get_me_returns_principal(client: SonnyLabsClient, httpserver: HTTPServer) -> None:
    body = {
        "type": "api_key",
        "org_id": "org_01H",
        "actor_id": "ak_01H",
        "scopes": ["scans:write"],
    }
    httpserver.expect_request("/v1/me").respond_with_json(body)
    assert client.get_me() == body


# ---------------------------------------------------------------------------
# Scans — the e2e happy + error paths required by the unit's recipe
# ---------------------------------------------------------------------------


def test_create_scan_happy_path(
    client: SonnyLabsClient, httpserver: HTTPServer
) -> None:
    response_body = {
        "id": "scan_01HABC",
        "created": "2026-05-06T00:00:00Z",
        "kind": "content",
        "findings": [],
        "decision": {"action": "allow", "reason": "no_detectors_fired"},
    }
    httpserver.expect_request(
        "/v1/scans", method="POST"
    ).respond_with_json(response_body, status=200)

    result = client.create_scan(
        surface="user_message",
        content={"type": "text", "text": "hello"},
    )
    assert result == response_body
    request = httpserver.log[-1][0]
    assert request.headers["Authorization"] == "Bearer sk_test_unit"
    # Auto-generated Idempotency-Key on POST
    assert request.headers["Idempotency-Key"].startswith("sdk-")
    sent_body = json.loads(request.get_data())
    assert sent_body == {
        "kind": "content",
        "surface": "user_message",
        "content": {"type": "text", "text": "hello"},
    }


def test_create_scan_401_problem_raises_authentication_error(
    client: SonnyLabsClient, httpserver: HTTPServer
) -> None:
    httpserver.expect_request("/v1/scans", method="POST").respond_with_data(
        _problem(
            type="https://docs.sonnylabs.ai/errors/auth.api_key.expired",
            title="API key expired",
            status=401,
            code="auth.api_key.expired",
            detail="API key has expired.",
        ),
        status=401,
        content_type="application/problem+json",
        headers={"X-Request-Id": "01HW8Q7K9XJ4N6T2V5Z3Y8B1RD"},
    )
    with pytest.raises(AuthenticationError) as exc_info:
        client.create_scan(surface="user_message", content={"type": "text", "text": "hi"})
    err = exc_info.value
    assert err.code == "auth.api_key.expired"
    assert err.status == 401
    assert err.request_id == "01HW8Q7K9XJ4N6T2V5Z3Y8B1RD"
    assert err.detail == "API key has expired."


def test_create_scan_with_idempotency_key_forwards_header(
    client: SonnyLabsClient, httpserver: HTTPServer
) -> None:
    httpserver.expect_request("/v1/scans", method="POST").respond_with_json(
        {"id": "scan_x", "created": "2026", "kind": "content", "findings": [], "decision": {"action": "allow", "reason": "no_detectors_fired"}}
    )
    client.create_scan(
        surface="user_message",
        content={"type": "text", "text": "hi"},
        idempotency_key="caller-supplied-123",
    )
    request = httpserver.log[-1][0]
    assert request.headers["Idempotency-Key"] == "caller-supplied-123"


def test_get_scan_404(client: SonnyLabsClient, httpserver: HTTPServer) -> None:
    httpserver.expect_request("/v1/scans/scan_missing").respond_with_data(
        _problem(status=404, code="scan.not_found", title="Not found"),
        status=404,
        content_type="application/problem+json",
    )
    with pytest.raises(NotFoundError):
        client.get_scan("scan_missing")


def test_list_scans_drops_none_query_params(
    client: SonnyLabsClient, httpserver: HTTPServer
) -> None:
    httpserver.expect_request("/v1/scans").respond_with_json(
        {"data": [], "next_cursor": None}
    )
    client.list_scans(limit=10)
    request = httpserver.log[-1][0]
    # Only `limit` should hit the wire — None-valued kwargs are filtered.
    assert request.query_string == b"limit=10"


# ---------------------------------------------------------------------------
# API keys
# ---------------------------------------------------------------------------


def test_list_api_keys_paginates(client: SonnyLabsClient, httpserver: HTTPServer) -> None:
    httpserver.expect_request("/v1/api-keys").respond_with_json(
        {"data": [], "next_cursor": None}
    )
    result = client.list_api_keys(limit=25)
    assert result["data"] == []


def test_create_api_key_201(client: SonnyLabsClient, httpserver: HTTPServer) -> None:
    body = {
        "id": "ak_01H",
        "name": "ci",
        "prefix": "sk_test",
        "last_four": "abcd",
        "scopes": ["scans:write"],
        "environment": "test",
        "created_at": "2026-05-06T00:00:00Z",
        "secret": "sk_test_xxxxxxxxxxxxxxxxxxxxxx",
    }
    httpserver.expect_request("/v1/api-keys", method="POST").respond_with_json(
        body, status=201
    )
    result = client.create_api_key(name="ci", scopes=["scans:write"])
    assert result == body


def test_create_api_key_403_raises_scope_missing(
    client: SonnyLabsClient, httpserver: HTTPServer
) -> None:
    httpserver.expect_request("/v1/api-keys", method="POST").respond_with_data(
        _problem(status=403, code="scope.missing", title="Forbidden"),
        status=403,
        content_type="application/problem+json",
    )
    with pytest.raises(ScopeMissingError):
        client.create_api_key(name="ci", scopes=["scans:write"])


def test_revoke_api_key_returns_none(client: SonnyLabsClient, httpserver: HTTPServer) -> None:
    httpserver.expect_request("/v1/api-keys/ak_01H", method="DELETE").respond_with_data(
        b"", status=204
    )
    assert client.revoke_api_key("ak_01H") is None


# ---------------------------------------------------------------------------
# Validation + rate-limit error mapping
# ---------------------------------------------------------------------------


def test_400_problem_raises_validation_error_with_errors_list(
    client: SonnyLabsClient, httpserver: HTTPServer
) -> None:
    httpserver.expect_request("/v1/scans", method="POST").respond_with_data(
        _problem(
            status=400,
            code="validation.error",
            title="Validation failed",
            errors=[{"path": "/surface", "code": "validation.required"}],
        ),
        status=400,
        content_type="application/problem+json",
    )
    with pytest.raises(ValidationError) as exc_info:
        client.create_scan(surface="user_message", content={"type": "text", "text": "hi"})
    assert exc_info.value.code == "validation.error"
    assert exc_info.value.errors == [
        {"path": "/surface", "code": "validation.required"}
    ]


def test_429_with_retry_after_attaches_retry_after_seconds(
    httpserver: HTTPServer,
) -> None:
    httpserver.expect_request("/v1/me").respond_with_data(
        _problem(status=429, code="rate_limit.exceeded", title="Slow down"),
        status=429,
        content_type="application/problem+json",
        headers={"Retry-After": "12"},
    )
    # Build a separate client with retries disabled so the test sees the
    # 429 directly rather than waiting through Retry-After.
    client = SonnyLabsClient(
        api_key="sk_test_unit",
        base_url=httpserver.url_for("").rstrip("/"),
        max_retries=0,
    )
    try:
        with pytest.raises(RateLimitError) as exc_info:
            client.get_me()
    finally:
        client.close()
    assert exc_info.value.retry_after == 12


# ---------------------------------------------------------------------------
# Retry behaviour
# ---------------------------------------------------------------------------


def test_503_retries_then_succeeds(httpserver: HTTPServer) -> None:
    httpserver.expect_ordered_request("/healthz").respond_with_data(
        _problem(status=503, code="readiness.bundle_loading", title="Loading"),
        status=503,
        content_type="application/problem+json",
        headers={"Retry-After": "0"},
    )
    httpserver.expect_ordered_request("/healthz").respond_with_json({"status": "ok"})
    client = SonnyLabsClient(
        api_key="sk_test_unit",
        base_url=httpserver.url_for("").rstrip("/"),
        max_retries=2,
    )
    try:
        assert client.get_liveness() == {"status": "ok"}
    finally:
        client.close()
    # Two total requests — the 503 then the success.
    assert len(httpserver.log) == 2


def test_post_without_idempotency_still_retries_because_sdk_auto_generates(
    httpserver: HTTPServer,
) -> None:
    """
    POSTs are retry-eligible only when an Idempotency-Key is in flight.
    The SDK auto-mints one by default, so a transient 503 on POST should
    still recover. This pins that behaviour against accidental regressions
    in :meth:`SonnyLabsClient._build_extra_headers`.
    """
    httpserver.expect_ordered_request("/v1/scans", method="POST").respond_with_data(
        _problem(status=503, code="upstream.unavailable", title="Try again"),
        status=503,
        content_type="application/problem+json",
        headers={"Retry-After": "0"},
    )
    httpserver.expect_ordered_request("/v1/scans", method="POST").respond_with_json(
        {
            "id": "scan_x",
            "created": "2026",
            "kind": "content",
            "findings": [],
            "decision": {"action": "allow", "reason": "no_detectors_fired"},
        }
    )
    client = SonnyLabsClient(
        api_key="sk_test_unit",
        base_url=httpserver.url_for("").rstrip("/"),
        max_retries=2,
    )
    try:
        client.create_scan(surface="user_message", content={"type": "text", "text": "hi"})
    finally:
        client.close()

    requests = [entry[0] for entry in httpserver.log]
    assert len(requests) == 2
    # Both attempts must carry the SAME Idempotency-Key — otherwise the
    # server can't dedup the replay.
    keys = {r.headers["Idempotency-Key"] for r in requests}
    assert len(keys) == 1
    assert next(iter(keys)).startswith("sdk-")


def test_post_with_auto_idempotency_disabled_does_not_retry_500(
    httpserver: HTTPServer,
) -> None:
    """
    Opting out of auto-idempotency disables the implicit retry-safety on
    POSTs — a transient 503 must surface to the caller rather than
    being silently replayed (potentially with side-effects).
    """
    httpserver.expect_request("/v1/scans", method="POST").respond_with_data(
        _problem(status=503, code="upstream.unavailable", title="Try again"),
        status=503,
        content_type="application/problem+json",
    )

    class _NoAutoIdempClient(SonnyLabsClient):
        def create_scan(self, **kwargs: object) -> object:  # type: ignore[override]
            # Bypass the normal helper so we can flip auto_idempotency off.
            return self._request(  # type: ignore[attr-defined]
                "POST",
                "/v1/scans",
                json={
                    "kind": "content",
                    "surface": "user_message",
                    "content": {"type": "text", "text": "hi"},
                },
                idempotency_key=None,
                auto_idempotency=False,
            )

    client = _NoAutoIdempClient(
        api_key="sk_test_unit",
        base_url=httpserver.url_for("").rstrip("/"),
        max_retries=2,
    )
    try:
        with pytest.raises(SonnyLabsError) as exc_info:
            client.create_scan()
    finally:
        client.close()
    assert exc_info.value.status == 503
    # Only one attempt — no retry because we opted out of auto-idempotency.
    assert len(httpserver.log) == 1


# ---------------------------------------------------------------------------
# Stubs raise NotImplementedError with a helpful message
# ---------------------------------------------------------------------------


def test_unimplemented_operations_raise_not_implemented(client: SonnyLabsClient) -> None:
    with pytest.raises(NotImplementedError) as exc_info:
        client.list_invites()
    assert "listInvites" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Non-JSON error body still gets mapped to a typed exception
# ---------------------------------------------------------------------------


def test_html_error_page_falls_back_to_synthetic_problem(
    client: SonnyLabsClient, httpserver: HTTPServer
) -> None:
    httpserver.expect_request("/healthz").respond_with_data(
        b"<html>504 Gateway Timeout</html>",
        status=504,
        content_type="text/html",
    )
    with pytest.raises(SonnyLabsError) as exc_info:
        client.get_liveness()
    assert exc_info.value.status == 504
    assert exc_info.value.code == "http.504"


# ---------------------------------------------------------------------------
# Transport: the client respects a caller-supplied transport
# ---------------------------------------------------------------------------


def test_custom_transport_is_used(monkeypatch: pytest.MonkeyPatch) -> None:
    """
    The ``transport=`` kwarg is the documented seam for testing without
    a real server. Verify the SDK actually wires it into ``httpx.Client``
    (rather than silently ignoring it) by handing in a transport that
    records every request.
    """
    captured: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(200, json={"status": "ok"})

    transport = httpx.MockTransport(handler)
    client = SonnyLabsClient(
        api_key="sk_test_xxx",
        base_url="http://stub.invalid",
        transport=transport,
        max_retries=0,
    )
    try:
        assert client.get_liveness() == {"status": "ok"}
    finally:
        client.close()
    assert len(captured) == 1
    assert str(captured[0].url) == "http://stub.invalid/healthz"
