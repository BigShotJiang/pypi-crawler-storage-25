"""
Unit tests for :func:`sonnylabs.verify_webhook`.
"""

from __future__ import annotations

import hmac
from hashlib import sha256

from sonnylabs import verify_webhook

SECRET = "whsec_test_secret_value"


def _sign(timestamp: int, body: bytes, secret: str = SECRET) -> str:
    payload = f"{timestamp}.".encode() + body
    return hmac.new(secret.encode("utf-8"), payload, sha256).hexdigest()


def test_valid_signature_within_tolerance_returns_true() -> None:
    body = b'{"event":"scan.completed"}'
    ts = 1_717_171_717
    digest = _sign(ts, body)
    header = f"t={ts},v1={digest}"
    assert verify_webhook(body, header, SECRET, tolerance_s=300, now=ts + 30) is True


def test_signature_outside_tolerance_returns_false() -> None:
    body = b'{"event":"scan.completed"}'
    ts = 1_717_171_717
    digest = _sign(ts, body)
    header = f"t={ts},v1={digest}"
    assert verify_webhook(body, header, SECRET, tolerance_s=60, now=ts + 600) is False


def test_tampered_body_fails_verification() -> None:
    body = b'{"event":"scan.completed"}'
    ts = 1_717_171_717
    digest = _sign(ts, body)
    header = f"t={ts},v1={digest}"
    tampered = b'{"event":"scan.allowed"}'
    assert verify_webhook(tampered, header, SECRET, now=ts) is False


def test_wrong_secret_fails_verification() -> None:
    body = b"hello"
    ts = 1_717_171_717
    digest = _sign(ts, body, secret="other_secret")
    header = f"t={ts},v1={digest}"
    assert verify_webhook(body, header, SECRET, now=ts) is False


def test_multiple_v1_entries_during_secret_rotation() -> None:
    """
    Server rotation emits two ``v1=`` entries — one signed with the old
    secret, one with the new — until the cutover completes. The receiver
    must accept either.
    """
    body = b"rotation"
    ts = 1_717_171_717
    new_digest = _sign(ts, body)
    old_digest = _sign(ts, body, secret="old_secret")
    header = f"t={ts},v1={old_digest},v1={new_digest}"
    assert verify_webhook(body, header, SECRET, now=ts) is True
    # Even when only the OLD secret was previously known, callers
    # rotating from "old_secret" → SECRET will still accept this delivery
    # using the old secret. We re-run with old_secret here to prove
    # symmetry.
    assert verify_webhook(body, header, "old_secret", now=ts) is True


def test_missing_timestamp_returns_false() -> None:
    digest = _sign(1, b"x")
    assert verify_webhook(b"x", f"v1={digest}", SECRET) is False


def test_missing_v1_signature_returns_false() -> None:
    assert verify_webhook(b"x", "t=1717171717", SECRET, now=1_717_171_717) is False


def test_malformed_header_returns_false() -> None:
    assert verify_webhook(b"x", "junk", SECRET, now=1_717_171_717) is False
    assert verify_webhook(b"x", "", SECRET, now=1_717_171_717) is False


def test_empty_secret_returns_false() -> None:
    body = b"x"
    ts = 1_717_171_717
    digest = _sign(ts, body)
    header = f"t={ts},v1={digest}"
    assert verify_webhook(body, header, "", now=ts) is False


def test_non_bytes_body_returns_false() -> None:
    # The signature is over raw bytes — passing a str silently
    # would risk a wrong-byte-encoding match on systems where the body
    # parser behaves differently. Reject the input explicitly.
    ts = 1_717_171_717
    digest = _sign(ts, b"x")
    header = f"t={ts},v1={digest}"
    assert verify_webhook("x", header, SECRET, now=ts) is False  # type: ignore[arg-type]


def test_malformed_timestamp_returns_false() -> None:
    digest = _sign(1, b"x")
    header = f"t=not-an-int,v1={digest}"
    assert verify_webhook(b"x", header, SECRET, now=1) is False
