from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


VALID_CAPABILITY_PROVENANCE_KINDS = (
    "native",
    "embodied",
    "delegated",
    "attached",
    "borrowed",
    "reachable",
)

VALID_CAPABILITY_BASIS = (
    "declared",
    "observed",
    "attested",
    "operator_declared",
    "inferred",
)

VALID_CAPABILITY_DURABILITY = (
    "stable",
    "conditional",
    "ephemeral",
    "revocable",
)


def _normalize_choice(value: Any, *, valid: tuple[str, ...], label: str) -> str:
    normalized = str(value or "").strip().lower()
    if normalized not in valid:
        raise ValueError(f"Invalid {label} '{value}'. Expected one of: {', '.join(valid)}.")
    return normalized


@dataclass(frozen=True)
class CapabilityClaim:
    capability: str
    provenance_kind: str
    basis: str = "declared"
    durability: str = "stable"
    scope: str | None = None
    provider: str | None = None

    def __post_init__(self) -> None:
        capability = str(self.capability or "").strip()
        if not capability:
            raise ValueError("capability is required")
        object.__setattr__(self, "capability", capability)
        object.__setattr__(
            self,
            "provenance_kind",
            _normalize_choice(self.provenance_kind, valid=VALID_CAPABILITY_PROVENANCE_KINDS, label="provenance_kind"),
        )
        object.__setattr__(
            self,
            "basis",
            _normalize_choice(self.basis, valid=VALID_CAPABILITY_BASIS, label="basis"),
        )
        object.__setattr__(
            self,
            "durability",
            _normalize_choice(self.durability, valid=VALID_CAPABILITY_DURABILITY, label="durability"),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def lives_inside_self(self) -> bool:
        return self.provenance_kind in {"native", "embodied"}

    def depends_on_external_boundary(self) -> bool:
        return self.provenance_kind in {"delegated", "attached", "borrowed", "reachable"}

    def requires_provider(self) -> bool:
        return self.provenance_kind in {"delegated", "attached", "borrowed", "reachable"}
