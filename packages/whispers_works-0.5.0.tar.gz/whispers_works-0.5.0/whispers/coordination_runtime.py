"""Structured coordination runtime helpers for assignments and review requests."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable


VALID_COORDINATION_KINDS = {"assignment", "review_request", "partner_sync"}
DIRECT_COORDINATION_WORKSPACE_ID = "__direct__"
DIRECT_COORDINATION_WORKSPACE_NAME = "Direct coordination"
CONFIRMATION_REQUIRED_COORDINATION_KINDS = {"assignment", "review_request"}
REPORTED_COMPLETE_STATUS = "reported_complete"


def _decode_jsonish(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value


def _boolish(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on"}
    return False


def _parse_created_at(value: Any) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    try:
        from whispers.time_utils import parse_timestamp
        return parse_timestamp(str(value))
    except Exception:
        return None


def _compute_age_seconds(created_at: Any) -> float | None:
    ts = _parse_created_at(created_at)
    if not ts:
        return None
    now = datetime.now(timezone.utc)
    delta = (now - ts).total_seconds()
    return max(0.0, delta)


def _format_age(seconds: float) -> str:
    if seconds < 60:
        return f"{int(seconds)}s"
    minutes = seconds / 60
    if minutes < 60:
        return f"{int(minutes)}m"
    hours = minutes / 60
    if hours < 24:
        return f"{hours:.1f}h"
    days = hours / 24
    return f"{days:.1f}d"


def _floatish(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


_REVIEW_VERDICTS = {"approve", "reject", "request_changes"}


def _normalize_coordination_status(value: Any) -> str | None:
    status = str(value or "").strip().lower()
    return status or None


def resolve_completion_transition(
    kind: str | None,
    *,
    actor_is_requester: bool,
    actor_is_recipient: bool,
) -> tuple[str, bool]:
    normalized_kind = str(kind or "").strip().lower()
    if (
        normalized_kind in CONFIRMATION_REQUIRED_COORDINATION_KINDS
        and actor_is_recipient
        and not actor_is_requester
    ):
        return REPORTED_COMPLETE_STATUS, False
    return "closed", True


def _derive_coordination_status(
    record: dict[str, Any],
    *,
    kind: str,
    blocking: bool,
) -> str:
    explicit = _normalize_coordination_status(record.get("coordination_status"))
    ack_state = _normalize_coordination_status(record.get("ack_state"))
    ack_detail = str(record.get("ack_detail") or "").strip().lower() or None
    read_at = str(record.get("read_at") or "").strip() or None
    has_reply = _boolish(record.get("has_reply")) or bool(record.get("reply_count"))

    # Coordination is only complete once the requester explicitly closes it.
    if explicit in {"closed", "completed"}:
        return "closed"
    if kind == "review_request" and ack_detail in _REVIEW_VERDICTS:
        return f"verdict:{ack_detail}"
    if explicit == REPORTED_COMPLETE_STATUS:
        return REPORTED_COMPLETE_STATUS
    if has_reply or explicit == "answered":
        return "answered"
    if explicit:
        return explicit

    if kind == "assignment":
        if ack_state == "declined":
            return "declined"
        if ack_state == "deferred":
            return "deferred"
        if ack_state == "accepted":
            return "accepted"
        if ack_state:
            return "acknowledged"
        if read_at:
            return "seen"
        return "pending"

    if ack_state:
        return "acknowledged"
    if read_at:
        return "seen"
    if blocking:
        return "waiting"
    return "pending"


def _coordination_status_for_item(item: "CoordinationItem") -> str:
    return _derive_coordination_status(
        {
            "coordination_status": item.coordination_status,
            "ack_state": item.ack_state,
            "ack_detail": item.ack_detail,
            "read_at": item.read_at,
            "status": "closed" if item.delivery_status == "closed" else "new",
            "has_reply": item.has_reply,
        },
        kind=item.kind,
        blocking=item.blocking,
    )


def _is_terminal_coordination_status(status: str, *, kind: str) -> bool:
    if status.startswith("verdict:"):
        return True
    if status in {"closed", "completed", "noted", REPORTED_COMPLETE_STATUS}:
        return True
    if kind == "assignment" and status in {"answered", "declined", "deferred"}:
        return True
    if kind == "review_request" and status == "answered":
        return True
    if kind == "partner_sync" and status in {"seen", "acknowledged", "accepted", "declined", "deferred", "answered"}:
        return True
    return False


def _is_open_coordination_item(item: "CoordinationItem") -> bool:
    status = _coordination_status_for_item(item)
    return not _is_terminal_coordination_status(status, kind=item.kind)


def _is_active_assignment_status(status: str | None) -> bool:
    normalized = _normalize_coordination_status(status)
    return normalized in {"picked_up", "accepted", "acknowledged", "active", "in_progress"}


def _format_coordination_status_label(status: str | None) -> str | None:
    normalized = _normalize_coordination_status(status)
    if not normalized or normalized in {"pending", "waiting"}:
        return None
    if normalized.startswith("verdict:"):
        normalized = normalized.split(":", 1)[1]
    return normalized.replace("_", " ")


def _coordination_label(kind: str) -> str:
    return {
        "assignment": "assignment",
        "review_request": "review request",
        "partner_sync": "partner sync",
    }.get(kind, kind.replace("_", " "))


def _coordination_default_subject(kind: str, *, counterpart: str, direction: str) -> str:
    label = _coordination_label(kind).title()
    preposition = "from" if direction == "incoming" else "to"
    return f"{label} {preposition} {counterpart}"


def _coordination_context_from_record(record: dict[str, Any]) -> dict[str, Any] | None:
    if not isinstance(record, dict):
        return None

    metadata = _decode_jsonish(record.get("metadata"))
    metadata = metadata if isinstance(metadata, dict) else {}
    payload = _decode_jsonish(record.get("payload"))
    coordination = payload.get("coordination") if isinstance(payload, dict) and isinstance(payload.get("coordination"), dict) else {}

    kind = str(
        metadata.get("whispers:coordination_kind")
        or coordination.get("kind")
        or ""
    ).strip()
    if kind not in VALID_COORDINATION_KINDS:
        return None

    blocking = _boolish(
        metadata.get("whispers:coordination_blocking")
        if "whispers:coordination_blocking" in metadata
        else coordination.get("blocking")
    )
    requested_action = (
        metadata.get("whispers:coordination_requested_action")
        or coordination.get("requested_action")
        or coordination.get("question")
        or coordination.get("next_action")
        or coordination.get("objective")
    )
    summary = (
        metadata.get("whispers:coordination_summary")
        or coordination.get("summary")
        or coordination.get("brief")
        or coordination.get("artifact")
        or coordination.get("slice")
    )
    workspace_id = coordination.get("workspace_id") or metadata.get("whispers:workspace_id")
    artifacts = coordination.get("artifacts")
    checkpoint_boundary = coordination.get("checkpoint_boundary")

    return {
        "kind": kind,
        "blocking": blocking,
        "requested_action": str(requested_action).strip() if requested_action else None,
        "summary": str(summary).strip() if summary else None,
        "workspace_id": str(workspace_id).strip() if workspace_id else None,
        "artifacts": artifacts if isinstance(artifacts, list) else None,
        "checkpoint_boundary": (
            checkpoint_boundary if isinstance(checkpoint_boundary, dict) else None
        ),
    }


@dataclass
class CoordinationItem:
    """A typed coordination obligation or wait surfaced from message traffic."""

    direction: str
    kind: str
    message_id: str
    counterpart: str
    subject: str
    priority: str = "routine"
    blocking: bool = False
    requested_action: str | None = None
    summary: str | None = None
    workspace_id: str | None = None
    created_at: str | None = None
    read_at: str | None = None
    ack_state: str | None = None
    ack_detail: str | None = None
    delivery_status: str | None = None
    coordination_status: str | None = None
    has_reply: bool = False
    replied_at: str | None = None
    age_seconds: float | None = None

    def to_dict(self) -> dict[str, Any]:
        d = {k: v for k, v in asdict(self).items() if v not in (None, "", [], {})}
        if self.age_seconds is not None:
            d["age_label"] = _format_age(self.age_seconds)
        return d


@dataclass
class CoordinationState:
    """Aggregated coordination truth for startup, status, and next-action inference."""

    active_assignments: int = 0
    pending_assignments: int = 0
    pending_review_requests: int = 0
    pending_partner_syncs: int = 0
    blocking_review_requests: int = 0
    blocked_waiting_for_review: int = 0
    answered_waiting_to_close: int = 0
    reported_complete_waiting_to_close: int = 0
    highlights: list[CoordinationItem] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "active_assignments": self.active_assignments,
            "pending_assignments": self.pending_assignments,
            "pending_review_requests": self.pending_review_requests,
            "pending_partner_syncs": self.pending_partner_syncs,
            "blocking_review_requests": self.blocking_review_requests,
            "blocked_waiting_for_review": self.blocked_waiting_for_review,
            "answered_waiting_to_close": self.answered_waiting_to_close,
            "reported_complete_waiting_to_close": self.reported_complete_waiting_to_close,
            "highlights": [item.to_dict() for item in self.highlights],
        }


def coordination_state_from_dict(raw: Any) -> CoordinationState:
    if not isinstance(raw, dict):
        return CoordinationState()
    highlights: list[CoordinationItem] = []
    for item in raw.get("highlights") or []:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "").strip()
        direction = str(item.get("direction") or "").strip() or "incoming"
        message_id = str(item.get("message_id") or "").strip()
        counterpart = str(item.get("counterpart") or "").strip()
        subject = str(item.get("subject") or "").strip()
        if not kind or not message_id or not counterpart or not subject:
            continue
        highlights.append(
            CoordinationItem(
                direction=direction,
                kind=kind,
                message_id=message_id,
                counterpart=counterpart,
                subject=subject,
                priority=str(item.get("priority") or "routine"),
                blocking=_boolish(item.get("blocking")),
                requested_action=item.get("requested_action"),
                summary=item.get("summary"),
                workspace_id=item.get("workspace_id"),
                created_at=item.get("created_at"),
                read_at=item.get("read_at"),
                ack_state=item.get("ack_state"),
                ack_detail=item.get("ack_detail"),
                delivery_status=item.get("delivery_status"),
                coordination_status=item.get("coordination_status"),
                has_reply=_boolish(item.get("has_reply")),
                replied_at=item.get("replied_at"),
                age_seconds=_floatish(item.get("age_seconds")),
            )
        )
    return CoordinationState(
        active_assignments=int(raw.get("active_assignments") or 0),
        pending_assignments=int(raw.get("pending_assignments") or 0),
        pending_review_requests=int(raw.get("pending_review_requests") or 0),
        pending_partner_syncs=int(raw.get("pending_partner_syncs") or 0),
        blocking_review_requests=int(raw.get("blocking_review_requests") or 0),
        blocked_waiting_for_review=int(raw.get("blocked_waiting_for_review") or 0),
        answered_waiting_to_close=int(raw.get("answered_waiting_to_close") or 0),
        reported_complete_waiting_to_close=int(raw.get("reported_complete_waiting_to_close") or 0),
        highlights=highlights,
    )


def extract_coordination_item(record: dict[str, Any], *, direction: str) -> CoordinationItem | None:
    if not isinstance(record, dict):
        return None

    context = _coordination_context_from_record(record)
    if not context:
        return None

    counterpart = (
        record.get("from_agent")
        if direction == "incoming"
        else record.get("recipient_callsign") or record.get("to_agent") or record.get("to")
    )
    counterpart = str(counterpart or "").strip()
    if not counterpart:
        return None

    subject = str(record.get("subject") or "").strip()
    if not subject:
        subject = _coordination_default_subject(
            context["kind"],
            counterpart=counterpart,
            direction=direction,
        )

    message_id = str(record.get("uuid") or record.get("message_id") or "").strip()
    if not message_id:
        return None

    return CoordinationItem(
        direction=direction,
        kind=context["kind"],
        message_id=message_id,
        counterpart=counterpart,
        subject=subject,
        priority=str(record.get("priority") or "routine"),
        blocking=bool(context["blocking"]),
        requested_action=context["requested_action"],
        summary=context["summary"],
        workspace_id=context["workspace_id"],
        created_at=record.get("created_at"),
        read_at=record.get("read_at"),
        ack_state=record.get("ack_state"),
        ack_detail=record.get("ack_detail"),
        delivery_status=record.get("delivery_status"),
        coordination_status=_derive_coordination_status(
            record,
            kind=context["kind"],
            blocking=bool(context["blocking"]),
        ),
        has_reply=_boolish(record.get("has_reply")) or bool(record.get("reply_count")),
        replied_at=record.get("replied_at"),
        age_seconds=_compute_age_seconds(record.get("created_at")),
    )


def coordination_activity_event_from_record(record: dict[str, Any]) -> dict[str, Any] | None:
    context = _coordination_context_from_record(record)
    if not context:
        return None

    sender = str(record.get("from_agent") or "").strip() or "unknown"
    receiver = str(
        record.get("recipient_callsign") or record.get("to_agent") or record.get("to") or ""
    ).strip() or "unknown"
    message_id = str(record.get("uuid") or record.get("message_id") or "").strip()
    if not message_id:
        return None

    ack_state = str(record.get("ack_state") or "").strip() or None
    ack_detail = str(record.get("ack_detail") or "").strip() or None
    read_at = str(record.get("read_at") or "").strip() or None
    acked_at = str(record.get("acked_at") or "").strip() or None
    message_status = str(record.get("status") or "new").strip().lower() or "new"
    created_at = str(record.get("created_at") or "").strip() or None
    priority = str(record.get("priority") or "routine").strip() or "routine"
    delivery_status = str(record.get("delivery_status") or "").strip() or None
    has_reply = _boolish(record.get("has_reply")) or bool(record.get("reply_count"))
    replied_at = str(record.get("replied_at") or "").strip() or None
    age_seconds = _compute_age_seconds(created_at)
    workspace_id = context["workspace_id"] or DIRECT_COORDINATION_WORKSPACE_ID

    status = _derive_coordination_status(
        record,
        kind=context["kind"],
        blocking=bool(context["blocking"]),
    )
    event_at = created_at
    if status == "closed":
        event_at = replied_at or acked_at or read_at or created_at
    elif status.startswith("verdict:"):
        event_at = acked_at or read_at or created_at
    elif status == REPORTED_COMPLETE_STATUS:
        event_at = acked_at or read_at or created_at
    elif status == "answered":
        event_at = replied_at or acked_at or read_at or created_at
    elif status in {"declined", "deferred", "accepted", "acknowledged"}:
        event_at = acked_at or read_at or created_at
    elif status in {"seen", "picked_up", "active", "in_progress", "noted"}:
        event_at = read_at or created_at

    subject = str(record.get("subject") or "").strip()
    detail = ack_detail or context["requested_action"] or context["summary"] or subject

    return {
        "workspace_id": workspace_id,
        "workspace_name": workspace_id if workspace_id != DIRECT_COORDINATION_WORKSPACE_ID else DIRECT_COORDINATION_WORKSPACE_NAME,
        "workspace_status": "direct" if workspace_id == DIRECT_COORDINATION_WORKSPACE_ID else "active",
        "sequence": int(record.get("recipient_row_id") or 0),
        "delta_kind": context["kind"],
        "actor": sender,
        "created_at": event_at or created_at,
        "message_created_at": created_at,
        "text": detail,
        "refs": None,
        "artifacts": context["artifacts"],
        "state_patch": {
            "coordination": {
                "kind": context["kind"],
                "status": status,
                "blocking": bool(context["blocking"]),
                "requested_action": context["requested_action"],
                "summary": context["summary"],
                "workspace_id": context["workspace_id"],
                "checkpoint_boundary": context["checkpoint_boundary"],
            }
        },
        "related_message_id": message_id,
        "type": "coordination",
        "summary": detail,
        "sender": sender,
        "receiver": receiver,
        "message_id": message_id,
        "priority": priority,
        "blocking": bool(context["blocking"]),
        "coordination_kind": context["kind"],
        "coordination_status": status,
        "requested_action": context["requested_action"],
        "ack_state": ack_state,
        "ack_detail": ack_detail,
        "delivery_status": delivery_status,
        "has_reply": has_reply,
        "replied_at": replied_at,
        "age_seconds": age_seconds,
        "age_label": _format_age(age_seconds) if age_seconds is not None else None,
        "checkpoint_boundary": context["checkpoint_boundary"],
    }


def summarize_coordination_state(
    inbound_items: Iterable[CoordinationItem | None],
    outbound_items: Iterable[CoordinationItem | None],
    *,
    max_highlights: int = 3,
) -> CoordinationState:
    inbound = [item for item in inbound_items if isinstance(item, CoordinationItem)]
    outbound = [item for item in outbound_items if isinstance(item, CoordinationItem)]
    answered_outbound = [
        item
        for item in outbound
        if _coordination_status_for_item(item) == "answered"
    ]
    reported_complete_outbound = [
        item
        for item in outbound
        if _coordination_status_for_item(item) == REPORTED_COMPLETE_STATUS
    ]
    inbound_pending = [
        item
        for item in inbound
        if _is_open_coordination_item(item)
    ]
    inbound_active_assignments = [
        item
        for item in inbound_pending
        if item.kind == "assignment" and _is_active_assignment_status(_coordination_status_for_item(item))
    ]
    inbound_waiting = [
        item
        for item in inbound_pending
        if not (
            item.kind == "assignment"
            and _is_active_assignment_status(_coordination_status_for_item(item))
        )
    ]

    state = CoordinationState(
        active_assignments=len(inbound_active_assignments),
        pending_assignments=sum(1 for item in inbound_waiting if item.kind == "assignment"),
        pending_review_requests=sum(1 for item in inbound_waiting if item.kind == "review_request"),
        pending_partner_syncs=sum(1 for item in inbound_waiting if item.kind == "partner_sync"),
        blocking_review_requests=sum(
            1 for item in inbound_waiting if item.kind == "review_request" and item.blocking
        ),
        blocked_waiting_for_review=sum(
            1
            for item in outbound
            if item.kind == "review_request" and item.blocking and _is_open_coordination_item(item)
        ),
        answered_waiting_to_close=len(answered_outbound),
        reported_complete_waiting_to_close=len(reported_complete_outbound),
    )

    highlights: list[CoordinationItem] = []
    highlights.extend(
        item for item in inbound_waiting if item.kind == "review_request" and item.blocking
    )
    highlights.extend(item for item in inbound_waiting if item.kind == "assignment")
    highlights.extend(item for item in inbound_active_assignments)
    highlights.extend(item for item in inbound_waiting if item.kind == "partner_sync")
    highlights.extend(
        item
        for item in inbound_waiting
        if item.kind == "review_request" and not item.blocking
    )
    highlights.extend(
        item
        for item in outbound
        if item.kind == "review_request" and item.blocking and _is_open_coordination_item(item)
    )
    highlights.extend(
        item
        for item in reported_complete_outbound
    )
    highlights.extend(
        item
        for item in answered_outbound
    )

    state.highlights = highlights[:max_highlights]
    return state


def format_coordination_item(item: CoordinationItem) -> str:
    label = _coordination_label(item.kind)
    status = _coordination_status_for_item(item)
    status_label = _format_coordination_status_label(status)

    # Show verdict if present on review requests
    verdict = None
    if status.startswith("verdict:"):
        verdict = status.split(":", 1)[1]
    elif item.kind == "review_request" and item.ack_detail:
        candidate = item.ack_detail.lower().strip()
        if candidate in _REVIEW_VERDICTS:
            verdict = candidate

    if item.kind == "review_request" and verdict:
        verdict_display = verdict.replace("_", " ")
        direction = "from" if item.direction == "incoming" else "to"
        return f"{label} {direction} {item.counterpart} [{verdict_display}] | {item.subject}"

    if item.direction == "incoming":
        headline = f"{label} from {item.counterpart}"
        if item.blocking and item.kind == "review_request":
            if status in {"pending", "waiting"}:
                age_tag = ""
                if item.age_seconds is not None:
                    age_tag = f" {_format_age(item.age_seconds)} waiting"
                headline += f" [blocking{age_tag}]"
            elif status_label:
                headline += f" [blocking, {status_label}]"
        elif status_label:
            headline += f" [{status_label}]"
    else:
        if item.kind == "review_request" and item.blocking and status not in {"answered", REPORTED_COMPLETE_STATUS, "closed"}:
            age_tag = ""
            if item.age_seconds is not None:
                age_tag = f" — {_format_age(item.age_seconds)} waiting"
            headline = f"blocking review wait on {item.counterpart}"
            if status_label:
                headline += f" [{status_label}]"
            headline += age_tag
        else:
            headline = f"{label} to {item.counterpart}"
            if status_label:
                headline += f" [{status_label}]"

    detail = item.requested_action or item.summary or item.subject
    if detail and detail != item.subject:
        return f"{headline} | {detail}"
    return f"{headline} | {item.subject}"


def render_coordination_lines(raw_state: Any, *, max_lines: int = 3) -> list[str]:
    state = raw_state if isinstance(raw_state, CoordinationState) else coordination_state_from_dict(raw_state)
    recently_completed = int(raw_state.get("recently_completed", 0)) if isinstance(raw_state, dict) else 0

    counts: list[str] = []
    if state.active_assignments:
        counts.append(f"active assignments {state.active_assignments}")
    if state.pending_assignments:
        counts.append(f"assignments {state.pending_assignments}")
    if state.pending_review_requests:
        counts.append(f"review requests {state.pending_review_requests}")
    if state.pending_partner_syncs:
        counts.append(f"partner syncs {state.pending_partner_syncs}")
    if state.blocking_review_requests:
        counts.append(f"blocking reviews {state.blocking_review_requests}")
    if state.blocked_waiting_for_review:
        counts.append(f"waiting on review {state.blocked_waiting_for_review}")
    if state.answered_waiting_to_close:
        counts.append(f"answers waiting to close {state.answered_waiting_to_close}")
    if state.reported_complete_waiting_to_close:
        counts.append(
            f"completion reports waiting to confirm {state.reported_complete_waiting_to_close}"
        )
    if recently_completed:
        counts.append(f"completed {recently_completed}")

    if not counts and not state.highlights:
        return []

    lines = [f"Coordination: {', '.join(counts)}"] if counts else []
    for item in state.highlights[:max_lines]:
        lines.append(f"Coordination now: {format_coordination_item(item)}")
    return lines
