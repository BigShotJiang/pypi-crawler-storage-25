from __future__ import annotations

import json
from typing import Any

from .frames import SEPARATOR, signal_line_prefix


def _decode_session_metadata(active_session: dict[str, Any] | None) -> dict[str, Any]:
    if not active_session:
        return {}
    raw = active_session.get("metadata")
    if isinstance(raw, dict):
        return dict(raw)
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return {}
        return dict(parsed) if isinstance(parsed, dict) else {}
    return {}


def build_operator_chrome(
    *,
    agent_name: str,
    participant_projection: dict[str, Any],
    effective_trust: dict[str, Any],
    wake_projection: dict[str, Any],
    active_session: dict[str, Any] | None,
    spaces: list[dict[str, Any]],
    primary_member: dict[str, Any] | None,
    message_summary: dict[str, int],
    work_summary: dict[str, int],
    startup_capsule: str,
    peers_section: dict[str, Any] | None = None,
) -> dict[str, Any]:
    session_metadata = _decode_session_metadata(active_session)
    session_name = (
        str(
            session_metadata.get("session_name")
            or session_metadata.get("display_name")
            or participant_projection.get("identity_label")
            or agent_name
        ).strip()
        or agent_name
    )
    primary_space = spaces[0] if spaces else None
    held_seats = list((primary_member or {}).get("held_seats") or [])
    space_projection = None
    if primary_space:
        space_projection = {
            "space_id": primary_space.get("space_id"),
            "name": primary_space.get("name"),
            "participation_name": (primary_member or {}).get("participation_name"),
            "held_seats": held_seats,
            "member_count": len(primary_space.get("members") or []) if isinstance(primary_space.get("members"), list) else None,
        }

    signal_parts = [signal_line_prefix(agent_name), f"session:{session_name}"]
    if participant_projection.get("summary"):
        signal_parts.append(str(participant_projection["summary"]))
    if primary_space and primary_space.get("name"):
        signal_parts.append(f"in {primary_space['name']}")
    # Slice 13: inline the top peers so the signal_line is first-touch
    # informative rather than a flat list of self-facts.
    if peers_section:
        top = peers_section.get("peers") or []
        if top:
            shown = [str(p.get("callsign")) for p in top[:3] if p.get("callsign")]
            if shown:
                omitted_total = max(0, len(top) - len(shown)) + int(
                    (peers_section.get("peers_omitted") or {}).get("count", 0)
                )
                label = "peers: " + ", ".join(shown)
                if omitted_total:
                    label += f" (+{omitted_total})"
                signal_parts.append(label)
    unread = int(message_summary.get("unread", 0) or 0)
    incoming_offers = int(work_summary.get("incoming_offers", 0) or 0)
    if unread:
        signal_parts.append(f"{unread} unread")
    if incoming_offers:
        signal_parts.append(f"{incoming_offers} offers")
    signal_parts.append(f"wake:{wake_projection.get('recommended_action', {}).get('action', 'unknown')}")

    return {
        "identity": {
            "agent_name": agent_name,
            "display_name": participant_projection.get("display_name"),
            "session_name": session_name,
            "participant_summary": participant_projection.get("summary"),
            "trust_tier": effective_trust.get("current_tier"),
        },
        "wake": {
            "reachability_mode": wake_projection.get("reachability_mode"),
            "wake_model": wake_projection.get("wake_model"),
            "card_wake_model": wake_projection.get("card_wake_model"),
            "listener_attached": bool(wake_projection.get("listener_attached")),
            "adapter_state": wake_projection.get("adapter", {}).get("state"),
            "recommended_action": wake_projection.get("recommended_action", {}).get("action"),
            "reasons": wake_projection.get("recommended_action", {}).get("reasons") or [],
        },
        "attention": {
            "unread": unread,
            "urgent": int(message_summary.get("urgent", 0) or 0),
            "incoming_offers": incoming_offers,
            "blocked": int(work_summary.get("blocked", 0) or 0),
            "owned_open": int(work_summary.get("owned_open", 0) or 0),
        },
        "space": space_projection,
        "session": {
            "session_name": session_name,
            "session_kind": active_session.get("session_kind") if active_session else None,
            "last_seen_at": active_session.get("last_seen_at") if active_session else None,
        },
        "signal_line": SEPARATOR.join(part for part in signal_parts if part),
        "capsule": startup_capsule,
    }
