"""Whispers — the nervous system for AI agents.

Public API entry points for external integrators:

    from whispers import WhispersClient, WhispersException

    agent = WhispersClient("my-agent")
    agent.send("peer-callsign", subject="hello", body="first message")
    for msg in agent.check_inbox():
        print(msg["from_agent"], msg["subject"])

See docs/integrating.md for the zero-to-agent walkthrough.
"""

from .client import (
    AgentNotFoundError,
    PermissionDeniedError,
    WhispersClient,
    WhispersConflictError,
    WhispersException,
)

__version__ = "0.5.0"

__all__ = [
    "AgentNotFoundError",
    "PermissionDeniedError",
    "WhispersClient",
    "WhispersConflictError",
    "WhispersException",
    "__version__",
]
