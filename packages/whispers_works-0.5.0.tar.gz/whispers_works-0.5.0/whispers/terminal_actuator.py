from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
import urllib.error
import urllib.request

from .identity import generate_callsign
from .path_utils import whispers_path

DEFAULT_LOCAL_SERVER = "http://127.0.0.1:8765"


def _resolved_server_url(server_url: str | None = None) -> str:
    candidate = str(
        server_url
        or os.getenv("WW_SERVER_URL")
        or os.getenv("WHISPERS_SERVER_URL")
        or DEFAULT_LOCAL_SERVER
    ).strip()
    return candidate.rstrip("/")


def _slugify(value: str | None) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().lower())
    return text.strip("-") or "default"



def _enum_token(value: str | None) -> str:
    normalized = str(value or "").strip().lower().replace("-", "_")
    normalized = re.sub(r"[^a-z0-9_]+", "_", normalized)
    return normalized.strip("_") or "default"



def _workspace_scope(workspace_root: str | None = None) -> tuple[str, str, str]:
    resolved = str(Path(workspace_root or os.getcwd()).resolve())
    leaf = _slugify(Path(resolved).name)
    digest = hashlib.sha1(resolved.encode("utf-8")).hexdigest()[:10]
    return resolved, leaf, digest



def _state_root() -> Path:
    override = str(os.getenv("WHISPERS_TERMINAL_ACTUATOR_STATE_DIR") or "").strip()
    if override:
        root = Path(override).expanduser().resolve()
    else:
        root = Path(whispers_path("terminal-actuator"))
    root.mkdir(parents=True, exist_ok=True)
    return root



def _bindings_dir() -> Path:
    path = _state_root() / "bindings"
    path.mkdir(parents=True, exist_ok=True)
    return path



def _companions_dir() -> Path:
    path = _state_root() / "companions"
    path.mkdir(parents=True, exist_ok=True)
    return path



def _binding_state_path(profile_name: str) -> Path:
    return _bindings_dir() / f"{profile_name}.json"



def _companion_state_path(profile_name: str) -> Path:
    return _companions_dir() / f"{profile_name}.json"



def _read_json(path: Path) -> dict[str, Any]:
    try:
        if not path.is_file():
            return {}
        payload = json.loads(path.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except (OSError, ValueError):
        return {}



def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")



def _short_session_token(raw: str | None) -> str:
    text = re.sub(r"[^a-z0-9]+", "", str(raw or "").strip().lower())
    return text[:32] or "session"



def _session_token_from_profile_name(profile_name: str | None) -> str | None:
    match = re.search(r"\.session\.([^.]+)$", str(profile_name or ""))
    return match.group(1) if match else None



def _session_token_from_context_hint(context_hint: str | None) -> str | None:
    match = re.search(r":sid:([^:]+)$", str(context_hint or ""))
    return match.group(1) if match else None



def resolve_session_discriminator(
    *,
    explicit: str | None = None,
    profile_name: str | None = None,
    existing_context_hint: str | None = None,
) -> str:
    for candidate in (
        explicit,
        os.getenv("WHISPERS_SESSION_DISCRIMINATOR"),
        _session_token_from_profile_name(profile_name),
        _session_token_from_context_hint(existing_context_hint),
        os.getenv("WT_SESSION"),
        os.getenv("PI_SESSION_ID"),
        os.getenv("TERM_SESSION_ID"),
    ):
        token = _short_session_token(candidate)
        if token and token != "session":
            return token
    return _short_session_token(str(os.getppid()))



def build_terminal_profile_name(
    *,
    harness: str,
    role: str,
    mode: str,
    preset: str,
    workspace_root: str | None = None,
    session_discriminator: str | None = None,
) -> str:
    _, workspace_leaf, workspace_digest = _workspace_scope(workspace_root)
    session_token = _short_session_token(session_discriminator)
    parts = (
        "terminal",
        _slugify(harness),
        workspace_leaf,
        workspace_digest,
        _slugify(mode),
        _slugify(preset),
        _slugify(role),
        "session",
        session_token,
    )
    return ".".join(parts)



def build_terminal_context_hint(
    *,
    identity_platform: str,
    harness: str,
    role: str,
    mode: str,
    preset: str,
    workspace_root: str | None = None,
    session_discriminator: str | None = None,
) -> str:
    _, workspace_leaf, workspace_digest = _workspace_scope(workspace_root)
    session_token = _short_session_token(session_discriminator)
    session_scope = ":".join(
        (
            _slugify(harness),
            workspace_leaf,
            workspace_digest,
            _slugify(mode),
            _slugify(preset),
            _slugify(role),
            "sid",
            session_token,
        )
    )
    return f"{_enum_token(identity_platform)}/session:{session_scope}"



def build_terminal_continuity_anchor(
    *,
    harness: str,
    role: str,
    mode: str,
    preset: str,
    workspace_root: str,
    identity_platform: str,
    session_discriminator: str,
) -> str:
    material = "|".join(
        [
            _slugify(harness),
            _slugify(role),
            _slugify(mode),
            _slugify(preset),
            str(Path(workspace_root).resolve()),
            _enum_token(identity_platform),
            _short_session_token(session_discriminator),
        ]
    )
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:24]
    return f"terminal:{digest}"



def default_terminal_display_name(*, harness: str, role: str, mode: str, preset: str) -> str:
    role_label = str(role or "").replace("-", " ").strip().title() or "Worker"
    harness_label = str(harness or "").replace("-", " ").strip().title() or "Terminal"
    return f"{harness_label} {role_label} ({mode}/{preset})"



def _bool_text(value: bool) -> str:
    return "true" if value else "false"



def _parse_bool(value: str | bool) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}



def _is_process_alive(pid: int | None) -> bool:
    if not pid or int(pid) <= 0:
        return False
    try:
        import psutil  # type: ignore

        proc = psutil.Process(int(pid))
        return proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE
    except Exception:
        return False



def _stop_process(pid: int | None) -> None:
    if not pid or int(pid) <= 0:
        return
    try:
        import psutil  # type: ignore

        proc = psutil.Process(int(pid))
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except psutil.TimeoutExpired:
            proc.kill()
    except Exception:
        return



def stop_terminal_companion(profile_name: str) -> None:
    state_path = _companion_state_path(profile_name)
    state = _read_json(state_path)
    _stop_process(int(state.get("pid") or 0) or None)
    try:
        state_path.unlink(missing_ok=True)
    except Exception:
        pass



def _connect_identity(
    server_url: str,
    *,
    requested_callsign: str,
    agent_type: str,
    display_name: str,
    platform_family: str,
    context_hint: str,
    continuity_anchor: str,
    reachability_mode: str,
    process_id: int | None = None,
    interaction_asks: list[str] | None = None,
) -> dict[str, Any]:
    payload = {
        "requested_callsign": requested_callsign,
        "agent_type": agent_type,
        "display_name": display_name,
        "platform_family": platform_family,
        "context_hint": context_hint,
        "continuity_anchor": continuity_anchor,
        "reachability_mode": reachability_mode,
        "interaction_asks": list(interaction_asks or []),
        "session_kind": f"{_slugify(platform_family)}_session",
        "process_id": process_id,
    }
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        f"{_resolved_server_url(server_url)}/identity/connect",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw)
        except ValueError:
            payload = {"error": raw or str(exc)}
        raise RuntimeError(payload.get("error") or str(payload)) from exc



def _fresh_callsign() -> str:
    for _ in range(32):
        candidate = generate_callsign()
        if candidate:
            return candidate
    raise RuntimeError("Unable to allocate a fresh terminal callsign.")



def _register_local_wake_adapter(
    *,
    server_url: str,
    agent_name: str,
    endpoint_url: str,
    supported_actions: list[str],
    fallback_action: str,
    state: str,
    detail: str | None,
    timeout: float = 10.0,
) -> dict[str, Any]:
    payload = {
        "adapter_kind": "local_http_connector",
        "supported_actions": list(supported_actions or ["notify"]),
        "fallback_action": fallback_action,
        "state": state,
        "detail": detail,
        "endpoint_url": endpoint_url,
    }
    request = urllib.request.Request(
        f"{_resolved_server_url(server_url)}/wake/{agent_name}/adapters",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))



def _spawn_local_wake_companion(
    *,
    server_url: str,
    agent_name: str,
    parent_pid: int,
    host: str,
    supported_actions: list[str],
    fallback_action: str,
    state: str,
    detail: str | None,
) -> dict[str, Any]:
    args = [
        sys.executable,
        "-m",
        "whispers.local_wake_runtime",
        "--server",
        server_url.rstrip("/"),
        "--agent",
        agent_name,
        "--host",
        host,
        "--fallback-action",
        fallback_action,
        "--state",
        state,
        "--parent-pid",
        str(parent_pid),
        # Slice 11: the bind_seat path writes adapter_registrations into
        # agent_sessions.metadata directly (via orientation.ensure_wake_
        # adapter_for_claude_code_session). The subprocess does NOT need
        # to HTTP-POST back to the server — doing so deadlocks because
        # the spawning parent IS the server.
        "--skip-http-register",
    ]
    for action in supported_actions:
        args.extend(["--supported-action", action])
    if detail:
        args.extend(["--detail", detail])

    repo_root = Path(__file__).resolve().parents[1]
    proc = subprocess.Popen(
        args,
        cwd=str(repo_root),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    assert proc.stdout is not None
    line = proc.stdout.readline().strip()
    if not line:
        stderr = ""
        if proc.stderr is not None:
            stderr = proc.stderr.read().strip()
        _stop_process(proc.pid)
        raise RuntimeError(stderr or "local_wake_runtime did not emit a startup payload")
    try:
        payload = json.loads(line)
    except ValueError as exc:
        _stop_process(proc.pid)
        raise RuntimeError(f"Invalid local_wake_runtime startup payload: {line}") from exc
    return {
        "pid": proc.pid,
        "endpoint_url": payload.get("endpoint_url"),
        "registration": payload.get("registration"),
        "parent_pid": parent_pid,
    }



def _ensure_local_wake_companion(
    *,
    profile_name: str,
    server_url: str,
    agent_name: str,
    parent_pid: int,
    supported_actions: list[str],
    fallback_action: str,
    state: str,
    detail: str | None,
    skip_http_register: bool = False,
) -> tuple[dict[str, Any] | None, str | None]:
    """
    skip_http_register: Caller will write adapter_registrations to the DB
    directly (e.g. orientation.ensure_wake_adapter_for_claude_code_session
    from within the server process). Skips the synchronous HTTP POST to
    /wake/<agent>/adapters both on new-spawn AND on companion reuse,
    eliminating the self-HTTP deadlock documented in Slice 11.
    """
    state_path = _companion_state_path(profile_name)
    existing = _read_json(state_path)
    existing_pid = int(existing.get("pid") or 0) or None
    existing_parent_pid = int(existing.get("parent_pid") or 0) or None
    if existing_pid and _is_process_alive(existing_pid) and existing_parent_pid == parent_pid:
        endpoint_url = str(existing.get("endpoint_url") or "").strip()
        if endpoint_url:
            if skip_http_register:
                existing.setdefault("registration", None)
                _write_json(state_path, existing)
                return existing, "reused_companion"
            registration = _register_local_wake_adapter(
                server_url=server_url,
                agent_name=agent_name,
                endpoint_url=endpoint_url,
                supported_actions=supported_actions,
                fallback_action=fallback_action,
                state=state,
                detail=detail,
            )
            existing["registration"] = registration
            _write_json(state_path, existing)
            return existing, "reused_companion"

    if existing_pid:
        _stop_process(existing_pid)
        try:
            state_path.unlink(missing_ok=True)
        except Exception:
            pass

    companion = _spawn_local_wake_companion(
        server_url=server_url,
        agent_name=agent_name,
        parent_pid=parent_pid,
        host="127.0.0.1",
        supported_actions=supported_actions,
        fallback_action=fallback_action,
        state=state,
        detail=detail,
    )
    _write_json(state_path, companion)
    return companion, "started_companion"


@dataclass
class TerminalActuatorBinding:
    harness: str
    role: str
    mode: str
    preset: str
    workspace_root: str
    workspace_leaf: str
    workspace_fingerprint: str
    server_url: str
    profile_name: str
    agent_type: str
    desired_agent_name: str
    agent_name: str
    display_name: str
    identity_host_agent: str
    identity_platform: str
    identity_context_hint: str
    continuity_anchor: str
    session_discriminator: str
    jolt_host_kind: str
    jolt_adapter_kind: str
    jolt_can_notify: bool
    jolt_can_stage_context: bool
    jolt_can_trigger_inference: bool
    name_source: str | None = None
    bootstrap_status: str | None = None
    companion_status: str | None = None
    companion_pid: int | None = None
    companion_endpoint_url: str | None = None
    session_id: str | None = None

    def env(self) -> dict[str, str]:
        env = {
            "WW_SERVER_URL": self.server_url,
            "WW_PROFILE_NAME": self.profile_name,
            "WW_AGENT_NAME": self.agent_name,
            "WHISPERS_AGENT_NAME": self.agent_name,
            "WHISPERS_CALLSIGN": self.agent_name,
            "WHISPERS_BINDING_KIND": "interactive_session",
            "WHISPERS_IDENTITY_HOST_AGENT": self.identity_host_agent,
            "WHISPERS_IDENTITY_PLATFORM": self.identity_platform,
            "WHISPERS_IDENTITY_CONTEXT_HINT": self.identity_context_hint,
            "WHISPERS_CONTINUITY_ANCHOR": self.continuity_anchor,
            "WHISPERS_SESSION_DISCRIMINATOR": self.session_discriminator,
            "WHISPERS_JOLT_HOST_KIND": self.jolt_host_kind,
            "WHISPERS_JOLT_ADAPTER_KIND": self.jolt_adapter_kind,
            "WHISPERS_JOLT_CAN_NOTIFY": _bool_text(self.jolt_can_notify),
            "WHISPERS_JOLT_CAN_STAGE_CONTEXT": _bool_text(self.jolt_can_stage_context),
            "WHISPERS_JOLT_CAN_TRIGGER_INFERENCE": _bool_text(self.jolt_can_trigger_inference),
            "WW_PI_ROLE": self.role,
            "WHISPERS_PI_ROLE": self.role,
        }
        if self.companion_pid:
            env["WHISPERS_LOCAL_WAKE_COMPANION_PID"] = str(self.companion_pid)
        if self.companion_endpoint_url:
            env["WHISPERS_LOCAL_WAKE_ENDPOINT_URL"] = self.companion_endpoint_url
        return env

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["env"] = self.env()
        return payload



def ensure_terminal_actuator(
    *,
    harness: str,
    role: str,
    mode: str = "work",
    preset: str = "default",
    workspace_root: str | None = None,
    server_url: str | None = None,
    profile_name: str | None = None,
    agent_type: str = "script",
    display_name: str | None = None,
    identity_host_agent: str | None = None,
    identity_platform: str = "plain_terminal",
    session_discriminator: str | None = None,
    jolt_host_kind: str = "plain_terminal",
    jolt_adapter_kind: str = "managed_pty",
    jolt_can_notify: bool = True,
    jolt_can_stage_context: bool = True,
    jolt_can_trigger_inference: bool = False,
) -> TerminalActuatorBinding:
    workspace_path, workspace_leaf, workspace_digest = _workspace_scope(workspace_root)
    effective_server_url = _resolved_server_url(server_url)
    effective_display_name = display_name or default_terminal_display_name(
        harness=harness,
        role=role,
        mode=mode,
        preset=preset,
    )
    effective_identity_platform = _enum_token(identity_platform)
    effective_jolt_host_kind = _enum_token(jolt_host_kind)
    effective_jolt_adapter_kind = _enum_token(jolt_adapter_kind)
    effective_identity_host = identity_host_agent or f"{_slugify(harness)}-{_slugify(role)}"

    existing_profile_state = _read_json(_binding_state_path(profile_name or "")) if profile_name else {}
    resolved_session_discriminator = resolve_session_discriminator(
        explicit=session_discriminator,
        profile_name=profile_name,
        existing_context_hint=str(existing_profile_state.get("identity_context_hint") or ""),
    )
    effective_profile_name = profile_name or build_terminal_profile_name(
        harness=harness,
        role=role,
        mode=mode,
        preset=preset,
        workspace_root=workspace_path,
        session_discriminator=resolved_session_discriminator,
    )
    binding_state_path = _binding_state_path(effective_profile_name)
    binding_state = _read_json(binding_state_path)

    context_hint = build_terminal_context_hint(
        identity_platform=effective_identity_platform,
        harness=harness,
        role=role,
        mode=mode,
        preset=preset,
        workspace_root=workspace_path,
        session_discriminator=resolved_session_discriminator,
    )
    continuity_anchor = build_terminal_continuity_anchor(
        harness=harness,
        role=role,
        mode=mode,
        preset=preset,
        workspace_root=workspace_path,
        identity_platform=effective_identity_platform,
        session_discriminator=resolved_session_discriminator,
    )

    desired_agent_name = str(binding_state.get("agent_name") or "").strip() or _fresh_callsign()
    name_source = "profile" if binding_state.get("agent_name") else "generated"

    host_process_id = os.getppid()

    response: dict[str, Any] | None = None
    for attempt in range(2):
        response = _connect_identity(
            effective_server_url,
            requested_callsign=desired_agent_name,
            agent_type=agent_type,
            display_name=effective_display_name,
            platform_family=_slugify(harness),
            context_hint=context_hint,
            continuity_anchor=continuity_anchor,
            reachability_mode="listener_backed" if effective_jolt_adapter_kind == "local_http_connector" else "manual_wake",
            process_id=host_process_id,
            interaction_asks=["review", "handoff", "exchange"],
        )
        resolved_callsign = str(((response.get("resolution") or {}).get("callsign") or desired_agent_name)).strip()
        if resolved_callsign:
            desired_agent_name = resolved_callsign
            break
        if attempt == 0:
            desired_agent_name = _fresh_callsign()
            name_source = "generated"
            continue
        raise RuntimeError("identity/connect returned no callsign")

    _write_json(
        binding_state_path,
        {
            "agent_name": desired_agent_name,
            "profile_name": effective_profile_name,
            "session_discriminator": resolved_session_discriminator,
            "identity_context_hint": context_hint,
            "continuity_anchor": continuity_anchor,
            "updated_at": time.time(),
        },
    )

    bootstrap_status = "bound"
    companion_status: str | None = None
    companion_state: dict[str, Any] | None = None
    if effective_jolt_adapter_kind == "local_http_connector":
        supported_actions: list[str] = []
        if jolt_can_notify:
            supported_actions.append("notify")
        if jolt_can_stage_context:
            supported_actions.append("stage_context")
        if jolt_can_trigger_inference:
            supported_actions.append("infer")
        fallback_action = "stage_context" if jolt_can_stage_context else "notify"
        companion_state, companion_status = _ensure_local_wake_companion(
            profile_name=effective_profile_name,
            server_url=effective_server_url,
            agent_name=desired_agent_name,
            parent_pid=host_process_id,
            supported_actions=supported_actions or ["notify"],
            fallback_action=fallback_action,
            state="supported",
            detail=f"terminal_actuator:{effective_profile_name}",
        )
        bootstrap_status = "bound_with_local_wake"
    else:
        stop_terminal_companion(effective_profile_name)

    session_id = str((response or {}).get("session_id") or "").strip() or None
    status_payload = (response or {}).get("status") or {}
    active_session = status_payload.get("active_session") if isinstance(status_payload, dict) else {}
    if not session_id and isinstance(active_session, dict):
        session_id = str(active_session.get("session_id") or "").strip() or None

    companion_pid = int((companion_state or {}).get("pid") or 0) or None
    companion_endpoint_url = str((companion_state or {}).get("endpoint_url") or "").strip() or None

    return TerminalActuatorBinding(
        harness=_slugify(harness),
        role=_slugify(role),
        mode=_slugify(mode),
        preset=_slugify(preset),
        workspace_root=workspace_path,
        workspace_leaf=workspace_leaf,
        workspace_fingerprint=workspace_digest,
        server_url=effective_server_url,
        profile_name=effective_profile_name,
        agent_type=agent_type,
        desired_agent_name=desired_agent_name,
        agent_name=desired_agent_name,
        display_name=effective_display_name,
        identity_host_agent=effective_identity_host,
        identity_platform=effective_identity_platform,
        identity_context_hint=context_hint,
        continuity_anchor=continuity_anchor,
        session_discriminator=resolved_session_discriminator,
        jolt_host_kind=effective_jolt_host_kind,
        jolt_adapter_kind=effective_jolt_adapter_kind,
        jolt_can_notify=bool(jolt_can_notify),
        jolt_can_stage_context=bool(jolt_can_stage_context),
        jolt_can_trigger_inference=bool(jolt_can_trigger_inference),
        name_source=name_source,
        bootstrap_status=bootstrap_status,
        companion_status=companion_status,
        companion_pid=companion_pid,
        companion_endpoint_url=companion_endpoint_url,
        session_id=session_id,
    )



def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m whispers.terminal_actuator",
        description="Provision or refresh a terminal/session actuator binding and optional local wake companion.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    ensure_parser = subparsers.add_parser("ensure", help="Provision or reclaim a terminal actuator binding.")
    ensure_parser.add_argument("--harness", required=True, help="Harness family, for example pi or codex.")
    ensure_parser.add_argument("--role", required=True, help="Role key, for example session or foreman.")
    ensure_parser.add_argument("--mode", default="work", help="Operational mode, for example work or lab.")
    ensure_parser.add_argument("--preset", default="default", help="Preset or cohort label.")
    ensure_parser.add_argument("--workspace-root", default=None, help="Workspace root used for stable scope hashing.")
    ensure_parser.add_argument("--server-url", default=None, help="Whispers server URL. Falls back to WW_SERVER_URL / WHISPERS_SERVER_URL / local default.")
    ensure_parser.add_argument("--profile-name", default=None, help="Optional explicit profile name.")
    ensure_parser.add_argument("--agent-type", default="script", help="Whispers agent type to register.")
    ensure_parser.add_argument("--display-name", default=None, help="Optional display name override.")
    ensure_parser.add_argument("--identity-host-agent", default=None, help="Stable local host identity label.")
    ensure_parser.add_argument("--identity-platform", default="plain_terminal", help="Stable identity platform family.")
    ensure_parser.add_argument("--session-discriminator", default=None, help="Explicit session discriminator override.")
    ensure_parser.add_argument("--jolt-host-kind", default="plain_terminal", help="Jolt host kind.")
    ensure_parser.add_argument("--jolt-adapter-kind", default="managed_pty", help="Jolt adapter kind.")
    ensure_parser.add_argument("--jolt-can-notify", default="true", help="Whether notify is supported.")
    ensure_parser.add_argument("--jolt-can-stage-context", default="true", help="Whether stage_context is supported.")
    ensure_parser.add_argument("--jolt-can-trigger-inference", default="false", help="Whether infer is supported.")
    ensure_parser.add_argument("--json-output", action="store_true", help="Emit JSON.")
    return parser



def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if args.command != "ensure":
        parser.error(f"Unsupported command: {args.command}")

    binding = ensure_terminal_actuator(
        harness=args.harness,
        role=args.role,
        mode=args.mode,
        preset=args.preset,
        workspace_root=args.workspace_root,
        server_url=args.server_url,
        profile_name=args.profile_name,
        agent_type=args.agent_type,
        display_name=args.display_name,
        identity_host_agent=args.identity_host_agent,
        identity_platform=args.identity_platform,
        session_discriminator=args.session_discriminator,
        jolt_host_kind=args.jolt_host_kind,
        jolt_adapter_kind=args.jolt_adapter_kind,
        jolt_can_notify=_parse_bool(args.jolt_can_notify),
        jolt_can_stage_context=_parse_bool(args.jolt_can_stage_context),
        jolt_can_trigger_inference=_parse_bool(args.jolt_can_trigger_inference),
    )
    payload = binding.to_dict()
    if args.json_output:
        print(json.dumps(payload, indent=2), flush=True)
    else:
        print(f"Agent: {payload['agent_name']}")
        print(f"Profile: {payload['profile_name']}")
        print(f"Context hint: {payload['identity_context_hint']}")
        print(f"Bootstrap: {payload.get('bootstrap_status') or 'prepared'}")
        print(f"Jolt: {payload['jolt_host_kind']}/{payload['jolt_adapter_kind']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
