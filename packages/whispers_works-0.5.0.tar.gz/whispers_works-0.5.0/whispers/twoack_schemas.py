from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal, Iterable

@dataclass(frozen=True)
class DeviceObservation:
    device_ref: str
    observation_kind: Literal["attribute", "event", "health", "derived_state"]
    reading_key: str
    value: Any
    observed_at: str
    basis: Literal["attested", "observed", "derived", "declared"]
    unit: str | None = None
    quality: str | None = None
    target: str | None = None
    summary: str | None = None
    evidence_refs: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "device_ref": self.device_ref,
            "observation_kind": self.observation_kind,
            "reading_key": self.reading_key,
            "value": self.value,
            "observed_at": self.observed_at,
            "basis": self.basis,
        }
        for field_name in ("unit", "quality", "target", "summary"):
            val = getattr(self, field_name)
            if val is not None:
                payload[field_name] = val
        if self.evidence_refs:
            payload["evidence_refs"] = list(self.evidence_refs)
        return payload


@dataclass(frozen=True)
class StatusUpdate:
    state: Literal["idle", "listening", "exploring", "building", "blocked", "eureka", "winding_down"]
    readiness: Literal["ready", "busy", "blocked", "warming", "paused_by_operator", "degraded"] | None = None
    current_task: str | None = None
    interruptibility: Literal["free", "defer", "urgent_only", "do_not_interrupt"] | None = None
    confidence: float | None = None
    working_set: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"state": self.state}
        if self.readiness is not None:
            payload["readiness"] = self.readiness
        if self.current_task is not None:
            payload["current_task"] = self.current_task
        if self.interruptibility is not None:
            payload["interruptibility"] = self.interruptibility
        if self.confidence is not None:
            payload["confidence"] = self.confidence
        if self.working_set:
            payload["working_set"] = list(self.working_set)
        return payload

@dataclass(frozen=True)
class HandoffBaton:
    # Goal (required)
    objective: str
    deliverable: str
    
    # Context
    workspace_id: str | None = None
    repo_focus: str | None = None
    working_scope: str | None = None
    
    # Goal (optional)
    handoff_contract: str | None = None
    
    # State
    completed: str | None = None
    remaining: str | None = None
    next_action: str | None = None
    
    # Knowledge
    decisions: tuple[str, ...] = ()
    assumptions: tuple[str, ...] = ()
    open_questions: tuple[str, ...] = ()
    dead_ends: tuple[str, ...] = ()
    
    # Execution context (what makes first-shot success possible)
    target_files: tuple[str, ...] = ()        # specific files to read/modify
    proof_bar: str | None = None              # what "done" looks like — test expectations, verification criteria
    blast_radius: str | None = None           # what else might break, what to watch for

    # Assets
    artifacts: tuple[str, ...] = ()
    risks: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, Any]:
        # Build payload in the strict narrative ordering
        payload: dict[str, Any] = {}
        
        # 1. Context
        if self.workspace_id is not None:
            payload["workspace_id"] = self.workspace_id
        if self.repo_focus is not None:
            payload["repo_focus"] = self.repo_focus
        if self.working_scope is not None:
            payload["working_scope"] = self.working_scope
            
        # 2. Goal
        payload["objective"] = self.objective
        payload["deliverable"] = self.deliverable
        if self.handoff_contract is not None:
            payload["handoff_contract"] = self.handoff_contract
            
        # 3. State
        for field_name in ("completed", "remaining", "next_action"):
            val = getattr(self, field_name)
            if val is not None:
                payload[field_name] = val
                
        # 4. Knowledge
        for field_name in ("decisions", "assumptions", "open_questions", "dead_ends"):
            val = getattr(self, field_name)
            if val:
                payload[field_name] = list(val)
                
        # 5. Execution context
        if self.target_files:
            payload["target_files"] = list(self.target_files)
        if self.proof_bar is not None:
            payload["proof_bar"] = self.proof_bar
        if self.blast_radius is not None:
            payload["blast_radius"] = self.blast_radius

        # 6. Assets
        for field_name in ("artifacts", "risks"):
            val = getattr(self, field_name)
            if val:
                payload[field_name] = list(val)

        return payload

@dataclass(frozen=True)
class DecisionRequest:
    question: str
    options: tuple[str, ...]
    recommended_option: str | None = None
    deadline: str | None = None
    blocking: bool | None = None
    why_now: str | None = None
    risk_if_wrong: str | None = None

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "question": self.question,
            "options": list(self.options),
        }
        for field_name in ("recommended_option", "deadline", "blocking", "why_now", "risk_if_wrong"):
            val = getattr(self, field_name)
            if val is not None:
                payload[field_name] = val
        return payload

@dataclass(frozen=True)
class DecisionResponse:
    decision: str
    confidence: float | None = None
    reason: str | None = None
    follow_up: str | None = None
    conditions: tuple[str, ...] = ()
    rejected_options: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"decision": self.decision}
        for field_name in ("confidence", "reason", "follow_up"):
            val = getattr(self, field_name)
            if val is not None:
                payload[field_name] = val
        for field_name in ("conditions", "rejected_options"):
            val = getattr(self, field_name)
            if val:
                payload[field_name] = list(val)
        return payload

@dataclass(frozen=True)
class ExternalActionRequest:
    action_class: str
    intent: str
    target: str | None = None
    audit_note: str | None = None
    risk_level: Literal["low", "elevated", "critical"] | None = None

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "action_class": self.action_class,
            "intent": self.intent,
        }
        for field_name in ("target", "audit_note", "risk_level"):
            val = getattr(self, field_name)
            if val is not None:
                payload[field_name] = val
        return payload

@dataclass(frozen=True)
class BatonAck:
    baton_ref: str
    decision: Literal["accepted", "conditionally_accepted", "rejected"]
    conditions: tuple[str, ...] = ()
    reason: str | None = None

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "baton_ref": self.baton_ref,
            "decision": self.decision,
        }
        if self.conditions:
            payload["conditions"] = list(self.conditions)
        if self.reason is not None:
            payload["reason"] = self.reason
        return payload

@dataclass(frozen=True)
class BatonUpdate:
    baton_ref: str
    state: Literal["in_progress", "blocked", "review_pending"]
    progress: str | None = None
    head_commit: str | None = None
    branch: str | None = None
    artifact_refs: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "baton_ref": self.baton_ref,
            "state": self.state,
        }
        for field_name in ("progress", "head_commit", "branch"):
            val = getattr(self, field_name)
            if val is not None:
                payload[field_name] = val
        if self.artifact_refs:
            payload["artifact_refs"] = list(self.artifact_refs)
        return payload

@dataclass(frozen=True)
class BatonClose:
    baton_ref: str
    outcome: Literal["completed", "merged", "blocked", "superseded", "expired"]
    summary: str | None = None
    head_commit: str | None = None
    branch: str | None = None
    artifact_refs: tuple[str, ...] = ()

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "baton_ref": self.baton_ref,
            "outcome": self.outcome,
        }
        for field_name in ("summary", "head_commit", "branch"):
            val = getattr(self, field_name)
            if val is not None:
                payload[field_name] = val
        if self.artifact_refs:
            payload["artifact_refs"] = list(self.artifact_refs)
        return payload

@dataclass(frozen=True)
class ExternalActionResult:
    action_ref: str
    outcome: Literal["success", "failure"]
    operator_override: bool | None = None
    override_reason: str | None = None
    override_expires_at: str | None = None
    override_closed_at: str | None = None
    override_closure_note: str | None = None
    execution_log: str | None = None

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "action_ref": self.action_ref,
            "outcome": self.outcome,
        }
        for field_name in (
            "operator_override",
            "override_reason",
            "override_expires_at",
            "override_closed_at",
            "override_closure_note",
            "execution_log",
        ):
            val = getattr(self, field_name)
            if val is not None:
                payload[field_name] = val
        return payload
