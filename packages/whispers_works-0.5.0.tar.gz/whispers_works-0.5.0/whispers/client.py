from __future__ import annotations

import json
import os
import uuid
from typing import Any, Dict, List, Optional

from .continuity import ContinuityConflictError, ContinuityService
from .coordination import CoordinationService
from .dispatcher import Dispatcher
from .messaging import MessagingService
from .participant_onboarding import build_participant_onboarding_kit, supported_onboarding_profiles
from .participant_profiles import build_participant_profile, participant_projection
from .projection import build_operator_chrome
from .residue import ResidueService
from .session_identity import stable_session_id
from .storage.db import WhispersDB, WhispersDBError
from .spaces import SpaceService
from .trust import TrustService
from .wake_runtime import build_wake_projection


class WhispersException(Exception):
    pass


class WhispersConflictError(WhispersException):
    """Raised when continuity resolution rejects a bind. Carries the
    original ContinuityConflictError's outcome and details so collision
    envelopes can be constructed at the tool surface without re-running
    the detection logic.
    """

    def __init__(
        self,
        message: str,
        *,
        outcome: str | None = None,
        details: dict | None = None,
    ):
        super().__init__(message)
        self.outcome = outcome
        self.details = dict(details or {})


class PermissionDeniedError(WhispersException):
    pass


class AgentNotFoundError(WhispersException):
    pass


class WhispersClient:
    """Fresh-start local embedded client.

    The client is now a thin shell over the canonical Space and Messaging
    services. Shells expose the system; they do not define its semantics.
    """

    def __init__(
        self,
        agent_name: Optional[str],
        db_path: Optional[str] = None,
        read_only: bool = False,
        agent_type: str = "script",
        model_id: Optional[str] = None,
        display_name: Optional[str] = None,
        session_name: Optional[str] = None,
        session_kind: Optional[str] = None,
        owner_id: Optional[str] = None,
        platform_family: Optional[str] = None,
        context_hint: Optional[str] = None,
        continuity_anchor: Optional[str] = None,
        allow_sibling: bool = False,
        sibling_label: Optional[str] = None,
        participant_profile: Optional[str] = None,
        participant_kind: str = "primary_agent",
        participant_shape: str = "atomic",
        agency_relation: Optional[str] = None,
        boundary_provenance: Optional[str] = None,
        recognition_basis: Optional[str] = None,
        reachability_mode: Optional[str] = None,
        interaction_asks: Optional[list[str]] = None,
        capability_claims: Optional[list[dict[str, Any]]] = None,
        composition_hints: Optional[list[dict[str, Any]]] = None,
        **_ignored: Any,
    ):
        if not agent_name:
            raise ValueError("agent_name is required")

        self.requested_agent_name = agent_name
        self.agent_name = agent_name
        self.agent_type = agent_type
        self.model_id = model_id
        self.display_name = display_name
        self.session_name = str(session_name or display_name or agent_name).strip() or agent_name
        self.owner_id = owner_id
        self.platform_family = platform_family or agent_type
        self.context_hint = context_hint
        self.continuity_anchor = continuity_anchor
        self.allow_sibling = allow_sibling
        self.sibling_label = sibling_label
        self.participant_profile = participant_profile
        profile_defaults = (
            build_participant_profile(participant_profile, source=agent_name)
            if participant_profile
            else {}
        )
        self.participant_kind = (
            profile_defaults.get("participant_kind", participant_kind)
            if participant_kind == "primary_agent"
            else participant_kind
        )
        self.participant_shape = (
            profile_defaults.get("participant_shape", participant_shape)
            if participant_shape == "atomic"
            else participant_shape
        )
        self.agency_relation = agency_relation or profile_defaults.get("agency_relation")
        self.boundary_provenance = boundary_provenance or profile_defaults.get("boundary_provenance")
        self.recognition_basis = recognition_basis or profile_defaults.get("recognition_basis")
        self.reachability_mode = reachability_mode or profile_defaults.get("reachability_mode")
        self.interaction_asks = list(interaction_asks if interaction_asks is not None else profile_defaults.get("interaction_asks") or [])
        self.capability_claims = list(
            capability_claims if capability_claims is not None else profile_defaults.get("capability_claims") or []
        )
        self.composition_hints = list(
            composition_hints if composition_hints is not None else profile_defaults.get("composition_hints") or []
        )
        self.read_only = read_only
        self.process_id = os.getpid()
        self.session_kind = session_kind or "local_client"
        self.session_id = None if read_only else str(uuid.uuid4())
        self.agent_id: Optional[str] = None
        self.identity_resolution: Optional[Dict[str, Any]] = None
        self.extra_session_metadata: Dict[str, Any] = {}

        self.db = WhispersDB(db_path=db_path, read_only=read_only)
        self.dispatcher = Dispatcher(self.db)
        self.spaces = SpaceService(self.db)
        self.messaging = MessagingService(self.db, spaces=self.spaces, dispatcher=self.dispatcher)
        self.coordination = CoordinationService(self.db, spaces=self.spaces, messaging=self.messaging)
        self.residue = ResidueService(self.db)

        from .registry import AgentRegistry

        self.registry = AgentRegistry(self.db)
        self.trust = TrustService(self.db)
        self.continuity = ContinuityService(self.db, registry=self.registry, trust=self.trust)

        if not self.read_only:
            try:
                resolution = self.continuity.connect(
                    requested_callsign=self.requested_agent_name,
                    agent_type=self.agent_type,
                    model_id=self.model_id,
                    display_name=self.display_name,
                    owner_id=self.owner_id,
                    platform_family=self.platform_family,
                    context_hint=self.context_hint,
                    continuity_anchor=self.continuity_anchor,
                    allow_sibling=self.allow_sibling,
                    sibling_label=self.sibling_label,
                    participant_kind=self.participant_kind,
                    participant_shape=self.participant_shape,
                )
            except ContinuityConflictError as exc:
                raise WhispersConflictError(
                    str(exc),
                    outcome=getattr(exc, "outcome", None),
                    details=getattr(exc, "details", None),
                ) from exc
            self.agent_name = resolution.callsign
            self.agent_id = resolution.agent_id
            self.continuity_anchor = resolution.continuity_anchor
            self.identity_resolution = resolution.to_dict()
            self.session_id = stable_session_id(
                continuity_anchor=self.continuity_anchor,
                session_kind=self.session_kind,
                process_id=self.process_id,
            ) or self.session_id
            if any(
                value is not None and value != []
                for value in (
                    self.agency_relation,
                    self.boundary_provenance,
                    self.recognition_basis,
                    self.reachability_mode,
                    self.interaction_asks,
                    self.capability_claims,
                    self.composition_hints,
                )
            ) or self.participant_kind != "primary_agent" or self.participant_shape != "atomic":
                self.registry.update_descriptor(
                    self.agent_name,
                    participant_kind=self.participant_kind,
                    participant_shape=self.participant_shape,
                    agency_relation=self.agency_relation,
                    boundary_provenance=self.boundary_provenance,
                    recognition_basis=self.recognition_basis,
                    reachability_mode=self.reachability_mode,
                    interaction_asks=self.interaction_asks or None,
                    capability_claims=self.capability_claims or None,
                    composition_hints=self.composition_hints or None,
                )
            self._touch_heartbeat()
            self.messaging.replay_dead_letters_for_recipient(
                self.agent_name,
                agent_id=self._agent_id(),
                delivery_session_id=self.session_id,
            )
            self.messaging.replay_dead_letters_for_sender(
                self.agent_name,
                agent_id=self._agent_id(),
                delivery_session_id=self.session_id,
            )

            # T4.23 — issue identity pollen and cache it on the client.
            # Stage A discipline: pollen issuance failure must NOT
            # break client construction; the pollen is informational
            # this slice (T4.24 verifies; T4.25 reissues).
            self.pollen_envelopes: List[Dict[str, Any]] = []
            self.pollen_identity: Optional[Dict[str, Any]] = None
            try:
                from .pollen.issuance import (
                    issue_identity_pollen,
                    signer_from_keypair,
                )
                from .pollen.keys import load_or_generate_issuer_keypair

                effective_trust = self.trust.resolve_for_callsign(self.agent_name)
                signer = signer_from_keypair(load_or_generate_issuer_keypair())
                identity_envelope = issue_identity_pollen(
                    callsign=self.agent_name,
                    stable_subject_id=str(
                        getattr(resolution, "stable_subject_id", None)
                        or self._agent_id()
                        or self.agent_name
                    ),
                    continuity_anchor=self.continuity_anchor or "",
                    trust_tier=effective_trust.current_tier,
                    signer=signer,
                )
                self.pollen_identity = identity_envelope
                self.pollen_envelopes = [identity_envelope]
            except Exception:
                # Stage A informational. Construction continues without
                # pollen; T4.24 logs verification failures honestly.
                pass

    def pollen_header_value(self) -> str:
        """Build the X-Whispers-Pollen header value from cached pollen.

        Returns empty string when no pollen is cached (caller may
        choose to omit the header entirely). Multi-pollen scenarios
        (Stage B membership, Stage C relation) extend the cached list
        without changing this method's surface.
        """
        from .pollen.presentation import serialize_pollen_list_header

        return serialize_pollen_list_header(self.pollen_envelopes)

    def _agent_id(self) -> Optional[str]:
        if self.agent_id:
            return self.agent_id
        card = self.registry.get_agent_by_callsign(self.agent_name)
        if not card:
            return None
        self.agent_id = str(card.get("agent_id"))
        return self.agent_id

    def _session_metadata(self) -> dict[str, Any]:
        metadata = {
            "requested_callsign": self.requested_agent_name,
            "display_name": self.display_name,
            "session_name": self.session_name,
            "platform_family": self.platform_family,
            "context_hint": self.context_hint,
            "continuity_anchor": self.continuity_anchor,
            "identity_resolution": self.identity_resolution,
            "participant_profile": self.participant_profile,
            "participant_kind": self.participant_kind,
            "participant_shape": self.participant_shape,
            "agency_relation": self.agency_relation,
            "boundary_provenance": self.boundary_provenance,
            "recognition_basis": self.recognition_basis,
            "reachability_mode": self.reachability_mode,
            "interaction_asks": self.interaction_asks,
        }
        metadata.update(self.extra_session_metadata)
        return metadata

    @staticmethod
    def _decode_session_metadata(raw: Any) -> dict[str, Any]:
        if isinstance(raw, dict):
            return dict(raw)
        if isinstance(raw, str):
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError:
                return {}
            return dict(parsed) if isinstance(parsed, dict) else {}
        return {}

    def _touch_heartbeat(self) -> None:
        if self.read_only or not self.session_id:
            return
        # Heartbeat extends the lease without rewriting metadata, so
        # out-of-band writers (e.g. adapter_registrations patched by
        # orientation.ensure_wake_adapter_for_claude_code_session) are
        # preserved. If the session row doesn't exist yet, fall back to
        # a full upsert so the first heartbeat after a manual session
        # insert still establishes state.
        if self.db.touch_agent_session_lease(self.session_id):
            return
        self.db.upsert_agent_session(
            session_id=self.session_id,
            agent_name=self.agent_name,
            agent_id=self._agent_id(),
            session_kind=self.session_kind,
            process_id=self.process_id,
            metadata=self._session_metadata(),
        )

    def send(
        self,
        to: str,
        subject: str,
        body: Optional[str] = None,
        *,
        msg_type: str = "inform",
        priority: str = "routine",
        payload: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        reply_to: Optional[str] = None,
        trace_id: Optional[str] = None,
        context_id: Optional[str] = None,
        space_id: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.messaging.send(
                sender=self.agent_name,
                recipient=to,
                subject=subject,
                body=body,
                msg_type=msg_type,
                priority=priority,
                payload=payload,
                metadata=metadata,
                reply_to=reply_to,
                trace_id=trace_id,
                context_id=context_id,
                space_id=space_id,
                thread_id=thread_id,
                sender_session_id=self.session_id,
            )
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def respond(
        self,
        message_id: str,
        body: str,
        *,
        subject: Optional[str] = None,
        priority: str = "routine",
        msg_type: str = "reply",
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.messaging.respond(
                sender=self.agent_name,
                message_id=message_id,
                body=body,
                subject=subject,
                priority=priority,
                msg_type=msg_type,
                sender_session_id=self.session_id,
            )
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def check_inbox(
        self,
        limit: int = 50,
        mark_seen: bool = True,
        pools: Optional[List[str]] = None,
        queue_class: Optional[str] = None,
        space_id: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        del pools, queue_class
        self._touch_heartbeat()
        return self.messaging.inbox(
            self.agent_name,
            limit=limit,
            mark_seen=mark_seen,
            space_id=space_id,
            thread_id=thread_id,
        )

    def outbox(
        self,
        limit: int = 20,
        *,
        space_id: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        self._touch_heartbeat()
        return self.messaging.outbox(
            self.agent_name,
            limit=limit,
            space_id=space_id,
            thread_id=thread_id,
        )

    def message_status(self, message_id: str) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.messaging.message_status(self.agent_name, message_id)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def message_thread(self, thread_id: str, *, limit: int = 100) -> List[Dict[str, Any]]:
        self._touch_heartbeat()
        try:
            return self.messaging.thread(self.agent_name, thread_id, limit=limit)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def space_create(
        self,
        name: str,
        *,
        purpose: Optional[str] = None,
        boundary_type: str = "hard",
        governance: str = "directed",
        visibility: str = "sealed",
        temporality: str = "persistent",
        naming_policy: str = "shared",
        naming_conflict_mode: str = "reject",
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        snapshot = self.spaces.create_space(
            created_by=self.agent_name,
            name=name,
            purpose=purpose,
            boundary_type=boundary_type,
            governance=governance,
            visibility=visibility,
            temporality=temporality,
            naming_policy=naming_policy,
            naming_conflict_mode=naming_conflict_mode,
        )
        return snapshot.to_dict()

    def space_join(self, space_id: str, *, membership_role: str = "member") -> Dict[str, Any]:
        self._touch_heartbeat()
        return self.spaces.join_space(space_id, self.agent_name, membership_role=membership_role).to_dict()

    def space_leave(self, space_id: str, *, reason: Optional[str] = None) -> Dict[str, Any]:
        self._touch_heartbeat()
        return self.spaces.leave_space(space_id, self.agent_name, reason=reason).to_dict()

    def space_members(self, space_id: str) -> List[Dict[str, Any]]:
        self._touch_heartbeat()
        return self.spaces.members(space_id)

    def space_presence(self, space_id: str) -> List[Dict[str, Any]]:
        self._touch_heartbeat()
        return self.spaces.presence(space_id)

    def space_name_self(self, space_id: str, participation_name: str | None) -> Dict[str, Any]:
        self._touch_heartbeat()
        return self.spaces.set_participation_name(space_id, self.agent_name, participation_name).to_dict()

    def space_bind_seat(
        self,
        space_id: str,
        seat_name: str,
        *,
        occupant_agent: str | None = None,
        note: str | None = None,
        binding_mode: str = "exclusive",
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        return self.spaces.bind_seat(
            space_id,
            seat_name,
            actor=self.agent_name,
            occupant_agent=occupant_agent,
            note=note,
            binding_mode=binding_mode,
        ).to_dict()

    def space_claim_seat(self, space_id: str, seat_name: str, *, note: str | None = None) -> Dict[str, Any]:
        self._touch_heartbeat()
        return self.spaces.claim_seat(space_id, seat_name, self.agent_name, note=note).to_dict()

    def space_release_seat(self, space_id: str, seat_name: str, *, note: str | None = None) -> Dict[str, Any]:
        self._touch_heartbeat()
        return self.spaces.release_seat(space_id, seat_name, actor=self.agent_name, note=note).to_dict()

    def space_seats(self, space_id: str) -> List[Dict[str, Any]]:
        self._touch_heartbeat()
        return self.spaces.seats(space_id)

    def spaces_list(self, *, include_inactive: bool = False) -> List[Dict[str, Any]]:
        self._touch_heartbeat()
        return self.spaces.list_spaces_for_agent(self.agent_name, include_inactive=include_inactive)

    def work_offer(
        self,
        to: str,
        title: str,
        *,
        description: Optional[str] = None,
        space_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.offer_work(
                creator=self.agent_name,
                assignee=to,
                title=title,
                description=description,
                space_id=space_id,
                metadata=metadata,
            )
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_baton(self, work_id: str) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.handoff_baton(work_id)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def baton_ack(
        self,
        baton_ref: str,
        *,
        decision: str,
        conditions: Optional[List[str]] = None,
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.apply_baton_ack(
                baton_ref,
                actor=self.agent_name,
                decision=decision,
                conditions=conditions or [],
                reason=reason,
            )
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def baton_update(
        self,
        baton_ref: str,
        *,
        state: str,
        progress: Optional[str] = None,
        artifact_refs: Optional[List[str]] = None,
        branch: Optional[str] = None,
        head_commit: Optional[str] = None,
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.apply_baton_update(
                baton_ref,
                actor=self.agent_name,
                state=state,
                progress=progress,
                artifact_refs=artifact_refs or [],
                branch=branch,
                head_commit=head_commit,
            )
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def baton_close(
        self,
        baton_ref: str,
        *,
        outcome: str,
        summary: Optional[str] = None,
        artifact_refs: Optional[List[str]] = None,
        branch: Optional[str] = None,
        head_commit: Optional[str] = None,
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.apply_baton_close(
                baton_ref,
                actor=self.agent_name,
                outcome=outcome,
                summary=summary,
                artifact_refs=artifact_refs or [],
                branch=branch,
                head_commit=head_commit,
            )
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_accept(self, work_id: str, *, note: Optional[str] = None) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.accept_work(work_id, actor=self.agent_name, note=note)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_start(self, work_id: str, *, note: Optional[str] = None) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.start_work(work_id, actor=self.agent_name, note=note)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_block(self, work_id: str, *, note: str) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.block_work(work_id, actor=self.agent_name, note=note)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_handoff(self, work_id: str, *, to: str, note: Optional[str] = None) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.request_handoff(work_id, actor=self.agent_name, new_owner=to, note=note)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_reject(self, work_id: str, *, note: Optional[str] = None) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.reject_work(work_id, actor=self.agent_name, note=note)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_close(self, work_id: str, *, note: Optional[str] = None) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.close_work(work_id, actor=self.agent_name, note=note)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_get(self, work_id: str) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            return self.coordination.get_work(work_id)
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc

    def work_list(
        self,
        *,
        space_id: Optional[str] = None,
        state: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        self._touch_heartbeat()
        return self.coordination.list_work(agent_name=self.agent_name, space_id=space_id, state=state)

    def trust_status(self) -> Dict[str, Any]:
        self._touch_heartbeat()
        resolution = self.trust.resolve_for_callsign(self.agent_name)
        return {
            "trust": resolution.to_dict(),
            "events": self.db.list_trust_events(stable_subject_id=resolution.stable_subject_id),
        }

    def presentation_history(self, *, limit: int = 20) -> List[Dict[str, Any]]:
        self._touch_heartbeat()
        return self.continuity.presentation_history(self.agent_name, limit=limit)

    def rename(
        self,
        new_callsign: str,
        *,
        actor: Optional[str] = None,
        reason: Optional[str] = None,
        display_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            resolution = self.continuity.rename_presentation(
                self.agent_name,
                new_callsign,
                actor=actor or self.agent_name,
                reason=reason,
                display_name=display_name,
            )
        except ContinuityConflictError as exc:
            raise WhispersConflictError(str(exc)) from exc
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc
        self.agent_name = resolution.callsign
        self.requested_agent_name = resolution.callsign
        self.agent_id = resolution.agent_id
        self.continuity_anchor = resolution.continuity_anchor
        self.identity_resolution = resolution.to_dict()
        self._touch_heartbeat()
        return {
            "resolution": resolution.to_dict(),
            "presentations": self.presentation_history(),
        }

    def trust_set(self, *, new_tier: int, actor: str, reason: str) -> Dict[str, Any]:
        self._touch_heartbeat()
        try:
            resolution = self.trust.set_tier_for_callsign(
                self.agent_name,
                new_tier=new_tier,
                actor=actor,
                reason=reason,
            )
        except WhispersDBError as exc:
            raise WhispersException(str(exc)) from exc
        return {
            "trust": resolution.to_dict(),
            "events": self.db.list_trust_events(stable_subject_id=resolution.stable_subject_id),
        }

    def describe_self(
        self,
        *,
        participant_profile: str | None = None,
        participant_kind: str | None = None,
        participant_shape: str | None = None,
        agency_relation: str | None = None,
        boundary_provenance: str | None = None,
        recognition_basis: str | None = None,
        reachability_mode: str | None = None,
        interaction_asks: list[str] | None = None,
        capability_claims: list[dict[str, Any]] | None = None,
        composition_hints: list[dict[str, Any]] | None = None,
    ) -> Dict[str, Any]:
        self._touch_heartbeat()
        profile_defaults = (
            build_participant_profile(participant_profile, source=self.agent_name)
            if participant_profile
            else {}
        )
        card = self.registry.update_descriptor(
            self.agent_name,
            participant_kind=participant_kind or profile_defaults.get("participant_kind"),
            participant_shape=participant_shape or profile_defaults.get("participant_shape"),
            agency_relation=agency_relation or profile_defaults.get("agency_relation"),
            boundary_provenance=boundary_provenance or profile_defaults.get("boundary_provenance"),
            recognition_basis=recognition_basis or profile_defaults.get("recognition_basis"),
            reachability_mode=reachability_mode or profile_defaults.get("reachability_mode"),
            interaction_asks=interaction_asks if interaction_asks is not None else profile_defaults.get("interaction_asks"),
            capability_claims=capability_claims if capability_claims is not None else profile_defaults.get("capability_claims"),
            composition_hints=composition_hints if composition_hints is not None else profile_defaults.get("composition_hints"),
        )
        self.participant_profile = participant_profile or self.participant_profile
        self.participant_kind = str(card.get("participant_kind") or self.participant_kind)
        self.participant_shape = str(card.get("participant_shape") or self.participant_shape)
        self.agency_relation = card.get("agency_relation") or self.agency_relation
        self.boundary_provenance = card.get("boundary_provenance") or self.boundary_provenance
        self.recognition_basis = card.get("recognition_basis") or self.recognition_basis
        self.reachability_mode = card.get("reachability_mode") or self.reachability_mode
        self.interaction_asks = list(card.get("interaction_asks") or self.interaction_asks)
        self.capability_claims = list(card.get("capability_claims") or self.capability_claims)
        self.composition_hints = list(card.get("composition_hints") or self.composition_hints)
        return card

    def apply_profile(self, participant_profile: str) -> Dict[str, Any]:
        return self.describe_self(participant_profile=participant_profile)

    def participant_profiles(self) -> List[str]:
        return supported_onboarding_profiles()

    def participant_kit(
        self,
        *,
        server: str,
        participant_profile: str,
        sender: str,
        recipient: str,
        subject: str,
        body: str | None = None,
        display_name: str | None = None,
        artifacts: List[str] | None = None,
        starter_artifact: str | None = None,
    ) -> Dict[str, Any]:
        return build_participant_onboarding_kit(
            server=server,
            participant_profile=participant_profile,
            sender=sender,
            recipient=recipient,
            subject=subject,
            body=body,
            display_name=display_name,
            artifacts=artifacts,
            starter_artifact=starter_artifact,
        )

    def whoami(self) -> Optional[Dict[str, Any]]:
        self._touch_heartbeat()
        card = self.registry.get_agent_by_callsign(self.agent_name)
        if card:
            card = dict(card)
            projection = participant_projection(card, fallback_name=self.agent_name)
            active_session = self.db.active_session_for_agent(self.agent_name)
            active_session_metadata = self._decode_session_metadata(
                (active_session or {}).get("metadata")
            )
            message_summary = self.messaging.summary(self.agent_name)
            work_summary = self.coordination.summary(self.agent_name)
            wake_projection = build_wake_projection(
                card=card,
                active_session=active_session,
                message_summary=message_summary,
                work_summary=work_summary,
            )
            card["effective_trust"] = self.trust.resolve_for_callsign(self.agent_name).to_dict()
            card["participant_summary"] = projection.get("summary")
            card["participant_projection"] = projection
            card["wake_projection"] = wake_projection
            card["display_name"] = card.get("display_name") or self.display_name
            card["session_name"] = (
                active_session_metadata.get("session_name")
                or active_session_metadata.get("display_name")
                or self.session_name
            )
            if self.identity_resolution:
                card["identity_resolution"] = self.identity_resolution
        return card

    def status(self, ephemeral_state: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
        del ephemeral_state
        self._touch_heartbeat()
        message_summary = self.messaging.summary(self.agent_name)
        work_summary = self.coordination.summary(self.agent_name)
        trust = self.trust.resolve_for_callsign(self.agent_name)
        card = self.registry.get_agent_by_callsign(self.agent_name) or {}
        projection = participant_projection(card, fallback_name=self.agent_name)
        active_session = self.db.active_session_for_agent(self.agent_name)
        active_session_metadata = self._decode_session_metadata(
            (active_session or {}).get("metadata")
        )
        spaces = self.spaces.list_spaces_for_agent(self.agent_name)
        startup_capsule = self.spaces.startup_capsule(
            self.agent_name,
            message_summary=message_summary,
            trust_tier=trust.current_tier,
            work_summary=work_summary,
        )
        wake_projection = build_wake_projection(
            card=card,
            active_session=active_session,
            message_summary=message_summary,
            work_summary=work_summary,
        )
        primary_member = None
        if spaces:
            members = self.spaces.members(spaces[0]["space_id"])
            primary_member = next((member for member in members if member.get("agent_name") == self.agent_name), None)
        peers_section = None
        try:
            from .orientation import build_peers_section as _build_peers
            db_path_hint = getattr(self.db, "db_path", None)
            if db_path_hint:
                peers_section = _build_peers(
                    db_path=str(db_path_hint),
                    self_callsign=self.agent_name,
                    budget=10,
                )
        except Exception:
            peers_section = None
        chrome = build_operator_chrome(
            agent_name=self.agent_name,
            participant_projection=projection,
            effective_trust=trust.to_dict(),
            wake_projection=wake_projection,
            active_session=active_session,
            spaces=spaces,
            primary_member=primary_member,
            message_summary=message_summary,
            work_summary=work_summary,
            startup_capsule=startup_capsule,
            peers_section=peers_section,
        )
        return {
            "healthy": True,
            "agent_name": self.agent_name,
            "requested_agent_name": self.requested_agent_name,
            "display_name": card.get("display_name") or self.display_name,
            "session_name": (
                active_session_metadata.get("session_name")
                or active_session_metadata.get("display_name")
                or self.session_name
            ),
            "session_id": self.session_id,
            "agent_id": self._agent_id(),
            "continuity_anchor": self.continuity_anchor,
            "identity_resolution": self.identity_resolution,
            "effective_trust": trust.to_dict(),
            "participant_kind": card.get("participant_kind"),
            "participant_shape": card.get("participant_shape"),
            "agency_relation": card.get("agency_relation"),
            "boundary_provenance": card.get("boundary_provenance"),
            "recognition_basis": card.get("recognition_basis"),
            "reachability_mode": wake_projection.get("reachability_mode") or card.get("reachability_mode"),
            "interaction_asks": card.get("interaction_asks") or [],
            "capability_claims": card.get("capability_claims") or [],
            "composition_hints": card.get("composition_hints") or [],
            "participant_summary": projection.get("summary"),
            "participant_projection": projection,
            "agents_registered": self.db.count_registered_agents(),
            "db_path": self.db.db_path,
            "active_session": active_session,
            "spaces": spaces,
            "message_summary": message_summary,
            "work_summary": work_summary,
            "wake_projection": wake_projection,
            "chrome": chrome,
            "startup_capsule": startup_capsule,
        }

    def wake_status(self) -> Dict[str, Any]:
        status = self.status()
        return {"agent_name": self.agent_name, "wake_projection": status["wake_projection"], "chrome": status["chrome"]}

    def wake_register_adapter(
        self,
        *,
        adapter_kind: str,
        supported_actions: List[str] | None = None,
        fallback_action: str | None = None,
        state: str | None = None,
        detail: str | None = None,
        endpoint_url: str | None = None,
    ) -> Dict[str, Any]:
        if not self.session_id:
            raise WhispersException("No active session is available for wake adapter registration.")
        patched = self.db.patch_agent_session_metadata(
            self.session_id,
            metadata_patch={
                "adapter_registrations": {
                    adapter_kind: {
                        "supported_actions": list(supported_actions or []),
                        "fallback_action": fallback_action,
                        "state": state,
                        "detail": detail,
                        "endpoint_url": endpoint_url,
                    }
                }
            },
        )
        metadata = patched.get("metadata") or {}
        if isinstance(metadata, str):
            import json as _json

            metadata = _json.loads(metadata)
        regs = metadata.get("adapter_registrations") if isinstance(metadata, dict) else {}
        return {"agent_name": self.agent_name, "session_id": self.session_id, "adapters": regs}

    def wake_events(self, *, limit: int = 20) -> List[Dict[str, Any]]:
        return self.db.list_wake_events(self.agent_name, limit=limit)

    def chrome_status(self) -> Dict[str, Any]:
        status = self.status()
        return {"agent_name": self.agent_name, "chrome": status["chrome"]}

    def close(self) -> None:
        return None
