from __future__ import annotations

import os
from typing import Any

# Fresh-start kernel baseline: trust begins small and explicit.
# The old anchor map is intentionally empty here; specific anchors can be added
# later when the new continuity model is rebuilt on purpose.
_BASELINE_TRUST_TIERS: dict[str, int] = {}

# 2026-04-17 put-the-bug-to-bed change:
# Default flipped from 1 → 5. Rationale: through this entire build
# cycle the tier-1 hard default has bitten the operator repeatedly on
# Pi and other non-supervised launches because WHISPERS_TRUSTED_ENV=1
# only reaches the server env when launched via the daemon supervisor
# path. Single-operator deployments (local Pi, loopback, personal dev
# machine) — which is every deployment today — hit the hard default
# instead of the umbrella, landed at tier 1, and couldn't message
# same-tier peers above them.
# New default: tier 5 ("trusted single-operator env" posture).
# Explicit downgrade paths preserved:
#   - WHISPERS_DEFAULT_TRUST_TIER=1 (exact tier override)
#   - WHISPERS_MULTI_TENANT=1 (declares a multi-tenant / public-facing
#     deployment; forces tier 1 default).
# Multi-tenant deployments MUST set one of those explicitly.
# See REGRESSION-LEDGER.md 2026-04-17 identity-stability entry.
_HARD_DEFAULT_TIER = 5
_TRUSTED_ENV_VAR = "WHISPERS_DEFAULT_TRUST_TIER"
_TRUSTED_ENV_UMBRELLA = "WHISPERS_TRUSTED_ENV"
_MULTI_TENANT_ENV_VAR = "WHISPERS_MULTI_TENANT"
_MULTI_TENANT_DEFAULT_TIER = 1
_UMBRELLA_IMPLIED_TIER = 5


def _explicit_env_tier() -> int | None:
    """Resolve WHISPERS_DEFAULT_TRUST_TIER if the operator set it explicitly.

    Returns the parsed tier for a well-formed value, None if unset/empty,
    and tier 1 if set but malformed. Fail-closed on bad input: a typo
    in the explicit tier must surface as tier 1 (most conservative),
    NOT the current hard default. The operator chose to be explicit —
    we honor that intent by failing closed when the explicit value is
    invalid, instead of silently falling through to the permissive
    hard default.
    """
    raw = os.environ.get(_TRUSTED_ENV_VAR)
    if raw is None or raw == "":
        return None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return _MULTI_TENANT_DEFAULT_TIER
    if value < 0 or value > 6:
        return _MULTI_TENANT_DEFAULT_TIER
    return value


def _umbrella_promotes() -> bool:
    """WHISPERS_TRUSTED_ENV=1 is the single-switch umbrella opt-in.

    Only the exact string "1" promotes. No soft truthy parsing — that keeps
    accidental values like "yes" or "true" from silently granting tier 5 in
    a context where the operator didn't mean to.

    Note: as of 2026-04-17, the hard default is tier 5 anyway, so the
    umbrella is effectively equivalent to "no explicit override." It
    stays supported for backwards-compat with existing deployments and
    operator muscle memory.
    """
    return os.environ.get(_TRUSTED_ENV_UMBRELLA) == "1"


def _multi_tenant_declared() -> bool:
    """WHISPERS_MULTI_TENANT=1 is the opt-DOWN to tier 1.

    Required for any deployment that exposes the daemon to untrusted
    peers (public Hub, multi-customer SaaS, federation node accepting
    unknown claimants). Without it, the daemon defaults to
    "trusted single-operator" posture.
    """
    return os.environ.get(_MULTI_TENANT_ENV_VAR) == "1"


def _env_default_tier() -> int:
    """Resolve the operator-declared default tier for fresh registrations.

    Order (2026-04-17 put-the-bug-to-bed ordering):
        1. WHISPERS_DEFAULT_TRUST_TIER (explicit) — wins if set; fails closed
           to MULTI_TENANT default on malformed input (conservative).
        2. WHISPERS_MULTI_TENANT=1 — explicit multi-tenant downgrade to
           tier 1. Required for any public-facing deployment.
        3. WHISPERS_TRUSTED_ENV=1 umbrella — kept for backwards-compat;
           promotes to tier 5.
        4. Hard default (tier 5) — trusted single-operator posture.
           Matches every deployment that exists today; eliminates the
           "tier 1 default silently eats messages" class of regression.
    """
    explicit = _explicit_env_tier()
    if explicit is not None:
        return explicit
    if _multi_tenant_declared():
        return _MULTI_TENANT_DEFAULT_TIER
    if _umbrella_promotes():
        return _UMBRELLA_IMPLIED_TIER
    return _HARD_DEFAULT_TIER


def baseline_trust_tier(
    callsign: str,
    *,
    agent_type: str | None = None,
    display_name: str | None = None,
) -> int:
    """Return the initial trust tier for a newly registered participant.

    Resolution order:
        1. _BASELINE_TRUST_TIERS[callsign] — explicit per-callsign overrides
        2. WHISPERS_DEFAULT_TRUST_TIER env var — trusted-env exact tier
        3. WHISPERS_TRUSTED_ENV=1 umbrella — implies tier 5
        4. Hard default (tier 1) — safe for external deployments
    """
    key = str(callsign or "").strip()
    if key in _BASELINE_TRUST_TIERS:
        return int(_BASELINE_TRUST_TIERS[key])
    return _env_default_tier()


def apply_trusted_env_bootstrap() -> None:
    """Normalize the trusted-env umbrella into an explicit tier for the process.

    Intended to be called once at daemon start (from ~/.whispers/_start.py) so
    the running server process has WHISPERS_DEFAULT_TRUST_TIER=5 visible in
    its environment whenever the operator has opted in via WHISPERS_TRUSTED_ENV=1.
    Subprocesses inherit the env; diagnostic tools that `echo $WHISPERS_DEFAULT_TRUST_TIER`
    against the daemon see the effective tier instead of the umbrella alias.

    Preserves any explicit WHISPERS_DEFAULT_TRUST_TIER set by the operator —
    the explicit knob always wins.
    """
    if os.environ.get(_TRUSTED_ENV_VAR):
        return
    if not _umbrella_promotes():
        return
    os.environ[_TRUSTED_ENV_VAR] = str(_UMBRELLA_IMPLIED_TIER)


def baseline_capabilities(trust_tier: int | None) -> dict[str, Any]:
    """Return the verified capability floor implied by a trust tier.

    This is intentionally tiny for the crawl-stage kernel.
    """
    tier = int(trust_tier or 1)
    return {
        "trust_tier": tier,
        "can_send_flash": tier >= 1,
    }
