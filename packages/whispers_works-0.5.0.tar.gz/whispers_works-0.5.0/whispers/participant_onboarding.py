from __future__ import annotations

from typing import Any

from .participant_kit import build_signal_participant_kit, filter_participant_kit, normalize_participant_profiles
from .participant_profiles import (
    PARTICIPANT_PROFILE_NAMES,
    build_participant_profile,
    participant_projection,
)


_KIT_PROFILE_MAP = {
    "approval_surface": ["approval_surface"],
    "status_source": ["status_source"],
    "gateway_bridge": ["bridge_gateway"],
}

_SIGNAL_TO_GUIDED_PROFILE = {
    "approval_surface": "approval_surface",
    "human_contact": "approval_surface",
    "status_source": "status_source",
    "sensor": "status_source",
    "bridge_gateway": "gateway_bridge",
    "action_target": "gateway_bridge",
}


def supported_onboarding_profiles() -> list[str]:
    return [name for name in PARTICIPANT_PROFILE_NAMES if name in _KIT_PROFILE_MAP]



def guided_profile_for_signal_profiles(raw_profiles: Any) -> str | None:
    profiles = normalize_participant_profiles(raw_profiles)
    for profile in profiles:
        guided = _SIGNAL_TO_GUIDED_PROFILE.get(profile)
        if guided:
            return guided
    return None


def build_participant_onboarding_kit(
    *,
    server: str,
    participant_profile: str,
    sender: str,
    recipient: str,
    subject: str,
    body: str | None = None,
    display_name: str | None = None,
    artifacts: list[str] | tuple[str, ...] | None = None,
    starter_artifact: str | None = None,
) -> dict[str, Any]:
    normalized_profile = str(participant_profile or "").strip().lower()
    if normalized_profile not in _KIT_PROFILE_MAP:
        raise ValueError(
            f"Participant profile '{participant_profile}' does not currently have a guided onboarding kit. "
            f"Supported profiles: {', '.join(supported_onboarding_profiles())}."
        )

    descriptor = build_participant_profile(normalized_profile, source=sender)
    projection = participant_projection(descriptor, fallback_name=sender)
    kit = build_signal_participant_kit(
        server=server,
        sender=sender,
        recipient=recipient,
        subject=subject,
        body=body,
        display_name=display_name,
        participant_profiles=_KIT_PROFILE_MAP[normalized_profile],
        starter_artifact=starter_artifact,
    )
    if artifacts:
        kit = filter_participant_kit(kit, artifacts)

    return {
        "participant_profile": normalized_profile,
        "descriptor": descriptor,
        "projection": projection,
        "kit": kit,
    }
