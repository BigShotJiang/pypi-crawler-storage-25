from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any, Iterable

from .messaging import MessagingService
from .participant_profiles import assess_capability_requirements, participant_projection
from .spaces import SpaceService
from .storage.db import WhispersDB, WhispersDBError
from .time_utils import to_utc_iso, utc_now
from .twoack_schemas import BatonAck, BatonClose, BatonUpdate, HandoffBaton


class WorkState(str, Enum):
    OFFERED = "offered"
    ACCEPTED = "accepted"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    HANDOFF_REQUESTED = "handoff_requested"
    REJECTED = "rejected"
    CLOSED = "closed"


_TRANSITIONS: dict[WorkState, set[WorkState]] = {
    WorkState.OFFERED: {WorkState.ACCEPTED, WorkState.REJECTED, WorkState.CLOSED},
    WorkState.ACCEPTED: {WorkState.IN_PROGRESS, WorkState.BLOCKED, WorkState.HANDOFF_REQUESTED, WorkState.CLOSED},
    WorkState.IN_PROGRESS: {WorkState.BLOCKED, WorkState.HANDOFF_REQUESTED, WorkState.CLOSED},
    WorkState.BLOCKED: {WorkState.IN_PROGRESS, WorkState.HANDOFF_REQUESTED, WorkState.CLOSED},
    WorkState.HANDOFF_REQUESTED: {WorkState.ACCEPTED, WorkState.CLOSED},
    WorkState.REJECTED: set(),
    WorkState.CLOSED: set(),
}


@dataclass(frozen=True)
class WorkItem:
    work_id: str
    space_id: str
    thread_id: str | None
    title: str
    description: str | None
    state: str
    created_by: str
    proposed_owner: str | None
    owner_agent: str | None
    linked_message_id: str | None
    created_at: str
    updated_at: str
    closed_at: str | None = None
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class WorkEvent:
    sequence: int
    event_kind: str
    actor: str
    created_at: str
    from_state: str | None = None
    to_state: str | None = None
    note: str | None = None
    related_message_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class CoordinationService:
    """Canonical work/coordination domain service.

    Work is not a message. A message may offer work, but ownership lives in the
    work state machine and must remain independently queryable.
    """

    def __init__(
        self,
        db: WhispersDB,
        *,
        spaces: SpaceService | None = None,
        messaging: MessagingService | None = None,
    ):
        self.db = db
        self.spaces = spaces or SpaceService(db)
        self.messaging = messaging or MessagingService(db, spaces=self.spaces)

    def _row_to_work_item(self, row: Any) -> WorkItem:
        metadata = row["metadata"]
        if metadata:
            try:
                metadata = json.loads(metadata)
            except Exception:
                metadata = None
        return WorkItem(
            work_id=row["work_id"],
            space_id=row["space_id"],
            thread_id=row["thread_id"],
            title=row["title"],
            description=row["description"],
            state=row["state"],
            created_by=row["created_by"],
            proposed_owner=row["proposed_owner"],
            owner_agent=row["owner_agent"],
            linked_message_id=row["linked_message_id"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            closed_at=row["closed_at"],
            metadata=metadata,
        )

    def _row_to_event(self, row: Any) -> WorkEvent:
        return WorkEvent(
            sequence=int(row["sequence"]),
            event_kind=row["event_kind"],
            actor=row["actor"],
            created_at=row["created_at"],
            from_state=row["from_state"],
            to_state=row["to_state"],
            note=row["note"],
            related_message_id=row["related_message_id"],
        )

    def _get_work_row(self, conn, work_id: str):
        return conn.execute("SELECT * FROM work_items WHERE work_id = ?", (work_id,)).fetchone()

    def _get_work_item(self, conn, work_id: str) -> WorkItem:
        row = self._get_work_row(conn, work_id)
        if not row:
            raise WhispersDBError(f"Work item {work_id} not found.")
        return self._row_to_work_item(row)

    def _get_work_item_by_baton_ref(self, conn, baton_ref: str) -> WorkItem:
        row = conn.execute(
            "SELECT * FROM work_items WHERE linked_message_id = ?",
            (baton_ref,),
        ).fetchone()
        if not row:
            raise WhispersDBError(f"No work item is linked to baton_ref {baton_ref}.")
        return self._row_to_work_item(row)

    def _merged_metadata(self, current: dict[str, Any] | None, patch: dict[str, Any] | None) -> dict[str, Any] | None:
        merged = dict(current or {})
        if patch:
            for key, value in patch.items():
                if value is None:
                    merged.pop(key, None)
                else:
                    merged[key] = value
        return merged or None

    def _next_sequence(self, conn, work_id: str) -> int:
        row = conn.execute(
            "SELECT COALESCE(MAX(sequence), 0) + 1 AS next_sequence FROM work_events WHERE work_id = ?",
            (work_id,),
        ).fetchone()
        return int(row["next_sequence"] if row else 1)

    def _record_event(
        self,
        conn,
        *,
        work_id: str,
        event_kind: str,
        actor: str,
        from_state: str | None,
        to_state: str | None,
        note: str | None,
        related_message_id: str | None = None,
    ) -> None:
        conn.execute(
            """
            INSERT INTO work_events (
                work_id, sequence, event_kind, actor, created_at,
                from_state, to_state, note, related_message_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                work_id,
                self._next_sequence(conn, work_id),
                event_kind,
                actor,
                to_utc_iso(utc_now()),
                from_state,
                to_state,
                note,
                related_message_id,
            ),
        )

    def _resolve_participant(self, callsign: str, *, space_id: str | None = None) -> str:
        if space_id:
            return self.spaces.resolve_participant_reference(space_id, callsign)
        resolved = self.db.resolve_callsign(callsign)
        if resolved and resolved.get("resolved_callsign"):
            return str(resolved["resolved_callsign"])
        return callsign

    def _resolve_space_for_offer(self, creator: str, assignee: str, space_id: str | None) -> tuple[str, str]:
        if not space_id:
            return self.spaces.ensure_pair_space(creator, assignee).space.space_id, assignee
        self.spaces.assert_member(space_id, creator)
        resolved_assignee = self.spaces.resolve_participant_reference(space_id, assignee)
        self.spaces.assert_member(space_id, resolved_assignee)
        return space_id, resolved_assignee

    def _normalize_required_capabilities(self, metadata: dict[str, Any] | None) -> list[str]:
        raw = None
        if metadata:
            raw = metadata.get("whispers:required_capabilities")
            if raw is None:
                raw = metadata.get("required_capabilities")
        requirements: list[str] = []
        seen = set()
        for item in list(raw or []):
            capability = str(item or "").strip()
            if not capability or capability in seen:
                continue
            seen.add(capability)
            requirements.append(capability)
        return requirements

    def _allow_external_capability_dependency(self, metadata: dict[str, Any] | None) -> bool:
        if not metadata:
            return False
        return bool(
            metadata.get("whispers:allow_external_capability_dependency")
            or metadata.get("allow_external_capability_dependency")
        )

    def _apply_capability_requirement_guardrails(
        self,
        *,
        assignee: str,
        metadata: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        requirements = self._normalize_required_capabilities(metadata)
        current = dict(metadata or {})
        if not requirements:
            return current or None

        from .registry import AgentRegistry

        card = AgentRegistry(self.db).get_agent_by_callsign(assignee) or {}
        assessment = assess_capability_requirements(card, requirements)
        projection = participant_projection(card, fallback_name=assignee)
        current["whispers:required_capabilities"] = requirements
        current["whispers:capability_requirement_report"] = assessment
        current["whispers:assignee_participant_summary"] = projection.get("summary")

        if assessment["missing_capabilities"]:
            missing = ", ".join(assessment["missing_capabilities"])
            raise WhispersDBError(
                f"{assignee} does not advertise required capability/capabilities: {missing}."
            )

        dependent = assessment["external_dependency_capabilities"]
        if dependent and not self._allow_external_capability_dependency(current):
            dependent_bits = []
            for item in dependent:
                capability = item["capability"]
                provenance = "/".join(item.get("provenance_kinds") or []) or "external"
                providers = ", ".join(item.get("providers") or [])
                if providers:
                    dependent_bits.append(f"{capability} ({provenance} via {providers})")
                else:
                    dependent_bits.append(f"{capability} ({provenance})")
            raise WhispersDBError(
                f"{assignee} only advertises boundary-dependent support for: {', '.join(dependent_bits)}. "
                "Set whispers:allow_external_capability_dependency=true if this dependency is intentional."
            )
        return current or None

    def _assert_transition(self, current: WorkState, target: WorkState) -> None:
        if target not in _TRANSITIONS[current]:
            allowed = ", ".join(sorted(state.value for state in _TRANSITIONS[current])) or "<terminal>"
            raise WhispersDBError(f"Cannot transition work item from {current.value} to {target.value}. Allowed: {allowed}")

    def _acknowledge_offer_message(self, conn, message_id: str | None) -> None:
        if not message_id:
            return
        conn.execute(
            """
            UPDATE messages
            SET status = CASE
                    WHEN status IN ('closed', 'dead_lettered', 'answered') THEN status
                    ELSE 'acknowledged'
                END,
                acked_at = COALESCE(acked_at, CURRENT_TIMESTAMP)
            WHERE uuid = ?
            """,
            (message_id,),
        )

    def _transition(
        self,
        *,
        work_id: str,
        actor: str,
        target_state: WorkState,
        note: str | None = None,
        proposed_owner: str | None = None,
        owner_agent: str | None = None,
        related_message_id: str | None = None,
        close_item: bool = False,
        acknowledge_offer: bool = False,
        event_kind: str | None = None,
        metadata_patch: dict[str, Any] | None = None,
    ) -> WorkItem:
        with self.db._db_op("Transition work item") as conn:
            current = self._get_work_item(conn, work_id)
            current_state = WorkState(current.state)
            self._assert_transition(current_state, target_state)
            now = to_utc_iso(utc_now())
            next_proposed_owner = proposed_owner if proposed_owner is not None else current.proposed_owner
            next_owner_agent = owner_agent if owner_agent is not None else current.owner_agent
            next_metadata = self._merged_metadata(current.metadata, metadata_patch)
            closed_at = now if close_item else None
            conn.execute(
                """
                UPDATE work_items
                SET state = ?,
                    proposed_owner = ?,
                    owner_agent = ?,
                    updated_at = ?,
                    closed_at = CASE WHEN ? THEN ? ELSE closed_at END,
                    metadata = ?
                WHERE work_id = ?
                """,
                (
                    target_state.value,
                    next_proposed_owner,
                    next_owner_agent,
                    now,
                    1 if close_item else 0,
                    closed_at,
                    json.dumps(next_metadata) if next_metadata else None,
                    work_id,
                ),
            )
            self._record_event(
                conn,
                work_id=work_id,
                event_kind=event_kind or target_state.value,
                actor=actor,
                from_state=current.state,
                to_state=target_state.value,
                note=note,
                related_message_id=related_message_id,
            )
            if acknowledge_offer:
                self._acknowledge_offer_message(conn, current.linked_message_id)
            conn.commit()
            item = self._get_work_item(conn, work_id)
        self.spaces.touch_member(item.space_id, actor)
        return item

    def _annotate(
        self,
        *,
        work_id: str,
        actor: str,
        event_kind: str,
        note: str | None = None,
        related_message_id: str | None = None,
        metadata_patch: dict[str, Any] | None = None,
    ) -> WorkItem:
        with self.db._db_op("Annotate work item") as conn:
            current = self._get_work_item(conn, work_id)
            now = to_utc_iso(utc_now())
            next_metadata = self._merged_metadata(current.metadata, metadata_patch)
            conn.execute(
                "UPDATE work_items SET updated_at = ?, metadata = ? WHERE work_id = ?",
                (now, json.dumps(next_metadata) if next_metadata else None, work_id),
            )
            self._record_event(
                conn,
                work_id=work_id,
                event_kind=event_kind,
                actor=actor,
                from_state=current.state,
                to_state=current.state,
                note=note,
                related_message_id=related_message_id,
            )
            conn.commit()
            item = self._get_work_item(conn, work_id)
        self.spaces.touch_member(item.space_id, actor)
        return item

    def offer_work(
        self,
        *,
        creator: str,
        assignee: str,
        title: str,
        description: str | None = None,
        space_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        resolved_space_id, assignee = self._resolve_space_for_offer(creator, assignee, space_id)
        metadata = self._apply_capability_requirement_guardrails(assignee=assignee, metadata=metadata)
        work_id = f"work_{uuid.uuid4().hex[:12]}"
        offer_message = self.messaging.send(
            sender=creator,
            recipient=assignee,
            subject=title,
            body=description,
            msg_type="handoff",
            priority="priority",
            metadata={**(metadata or {}), "whispers:work_id": work_id, "whispers:work_state": WorkState.OFFERED.value},
            space_id=resolved_space_id,
        )
        if offer_message["status"] == "dead_lettered":
            raise WhispersDBError(f"Unable to offer work to {assignee}; delivery was dead-lettered.")

        now = to_utc_iso(utc_now())
        with self.db._db_op("Offer work") as conn:
            conn.execute(
                """
                INSERT INTO work_items (
                    work_id, space_id, thread_id, title, description, state,
                    created_by, proposed_owner, owner_agent, linked_message_id,
                    created_at, updated_at, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?)
                """,
                (
                    work_id,
                    resolved_space_id,
                    offer_message["thread_id"],
                    title,
                    description,
                    WorkState.OFFERED.value,
                    creator,
                    assignee,
                    offer_message["message_id"],
                    now,
                    now,
                    json.dumps(metadata or {}) if metadata else None,
                ),
            )
            self._record_event(
                conn,
                work_id=work_id,
                event_kind="offered",
                actor=creator,
                from_state=None,
                to_state=WorkState.OFFERED.value,
                note=description,
                related_message_id=offer_message["message_id"],
            )
            item = self._get_work_item(conn, work_id)
            baton_artifact = self._derive_handoff_baton(item.to_dict())
            self._store_protocol_artifact(
                baton_artifact,
                work=item.to_dict(),
                actor=creator,
                related_message_id=offer_message["message_id"],
                conn=conn,
            )
            conn.commit()
        self.spaces.touch_member(resolved_space_id, creator)
        return {
            "work": item.to_dict(),
            "offer_message": offer_message,
            "baton": baton_artifact,
        }

    def _signal_id(self) -> str:
        return f"msg_{uuid.uuid4().hex[:12]}"

    def _derive_handoff_baton(self, work: dict[str, Any]) -> dict[str, Any]:
        metadata = work.get("metadata") or {}
        baton = HandoffBaton(
            objective=work["title"],
            deliverable=str(metadata.get("deliverable") or work.get("description") or work["title"]),
            workspace_id=work.get("space_id"),
            repo_focus=metadata.get("repo_focus"),
            working_scope=metadata.get("working_scope"),
            handoff_contract=metadata.get("handoff_contract"),
            completed=metadata.get("completed"),
            remaining=metadata.get("remaining") or work.get("description"),
            next_action=metadata.get("next_action"),
            decisions=tuple(metadata.get("decisions") or ()),
            assumptions=tuple(metadata.get("assumptions") or ()),
            open_questions=tuple(metadata.get("open_questions") or ()),
            dead_ends=tuple(metadata.get("dead_ends") or ()),
            target_files=tuple(metadata.get("target_files") or ()),
            proof_bar=metadata.get("proof_bar"),
            blast_radius=metadata.get("blast_radius"),
            artifacts=tuple(metadata.get("artifacts") or ()),
            risks=tuple(metadata.get("risks") or ()),
        )
        return {
            "schema": "handoff_baton.v1",
            "trace": {
                "message_id": work["linked_message_id"],
                "thread_id": work["thread_id"],
                "work_id": work["work_id"],
            },
            "accept_schemas": ["baton_ack.v1", "baton_update.v1", "baton_close.v1"],
            "payload": baton.to_payload(),
        }

    def _store_protocol_artifact(self, artifact: dict[str, Any], *, work: dict[str, Any], actor: str, related_message_id: str | None = None, conn=None) -> None:
        trace = artifact.get("trace") if isinstance(artifact.get("trace"), dict) else {}
        artifact_id = str(trace.get("message_id") or self._signal_id())
        self.db.store_protocol_artifact(
            artifact_id=artifact_id,
            schema_name=str(artifact.get("schema") or "unknown"),
            raw_artifact=artifact,
            trace_message_id=trace.get("message_id"),
            trace_thread_id=trace.get("thread_id"),
            work_id=work.get("work_id"),
            space_id=work.get("space_id"),
            related_message_id=related_message_id,
            actor=actor,
            conn=conn,
        )

    def handoff_baton(self, work_id: str) -> dict[str, Any]:
        with self.db.get_connection() as conn:
            work = self._get_work_item(conn, work_id).to_dict()
            linked_message_id = work.get("linked_message_id")
            if linked_message_id:
                existing = self.db.get_protocol_artifact(linked_message_id)
                if existing and existing.get("schema_name") == "handoff_baton.v1":
                    raw = existing.get("raw_artifact")
                    if isinstance(raw, dict):
                        return raw
        return self._derive_handoff_baton(work)

    def apply_baton_ack(
        self,
        baton_ref: str,
        *,
        actor: str,
        decision: str,
        conditions: Iterable[str] = (),
        reason: str | None = None,
    ) -> dict[str, Any]:
        ack = BatonAck(
            baton_ref=baton_ref,
            decision=decision,
            conditions=tuple(conditions),
            reason=reason,
        )
        with self.db.get_connection() as conn:
            current = self._get_work_item_by_baton_ref(conn, baton_ref)
        signal_note = json.dumps(ack.to_payload(), sort_keys=True)
        signal = {
            "schema": "baton_ack.v1",
            "trace": {
                "message_id": self._signal_id(),
                "in_reply_to": baton_ref,
                "thread_id": current.thread_id,
                "work_id": current.work_id,
            },
            "payload": ack.to_payload(),
        }
        metadata_patch = {
            "baton_last_signal": signal["schema"],
            "baton_decision": ack.decision,
            "baton_conditions": list(ack.conditions) if ack.conditions else None,
            "baton_reason": ack.reason,
        }
        if ack.decision in {"accepted", "conditionally_accepted"}:
            work = self._transition(
                work_id=current.work_id,
                actor=actor,
                target_state=WorkState.ACCEPTED,
                note=signal_note,
                proposed_owner=actor,
                owner_agent=actor,
                acknowledge_offer=True,
                event_kind="baton_ack",
                metadata_patch=metadata_patch,
                related_message_id=signal["trace"]["message_id"],
            )
        else:
            work = self._transition(
                work_id=current.work_id,
                actor=actor,
                target_state=WorkState.REJECTED,
                note=signal_note,
                close_item=True,
                acknowledge_offer=True,
                event_kind="baton_ack",
                metadata_patch=metadata_patch,
                related_message_id=signal["trace"]["message_id"],
            )
        self._store_protocol_artifact(signal, work=work.to_dict(), actor=actor, related_message_id=signal["trace"]["message_id"])
        return {
            "artifact": signal,
            **self.get_work(work.work_id),
        }

    def apply_baton_update(
        self,
        baton_ref: str,
        *,
        actor: str,
        state: str,
        progress: str | None = None,
        artifact_refs: Iterable[str] = (),
        branch: str | None = None,
        head_commit: str | None = None,
    ) -> dict[str, Any]:
        update = BatonUpdate(
            baton_ref=baton_ref,
            state=state,
            progress=progress,
            branch=branch,
            head_commit=head_commit,
            artifact_refs=tuple(artifact_refs),
        )
        with self.db.get_connection() as conn:
            current = self._get_work_item_by_baton_ref(conn, baton_ref)
        signal = {
            "schema": "baton_update.v1",
            "trace": {
                "message_id": self._signal_id(),
                "thread_id": current.thread_id,
                "work_id": current.work_id,
            },
            "payload": update.to_payload(),
        }
        metadata_patch = {
            "baton_last_signal": signal["schema"],
            "baton_state": update.state,
            "baton_progress": update.progress,
            "baton_artifact_refs": list(update.artifact_refs) if update.artifact_refs else None,
            "baton_branch": update.branch,
            "baton_head_commit": update.head_commit,
        }
        signal_note = json.dumps(update.to_payload(), sort_keys=True)
        current_state = WorkState(current.state)
        if update.state == "review_pending":
            work = self._annotate(
                work_id=current.work_id,
                actor=actor,
                event_kind="baton_update",
                note=signal_note,
                metadata_patch=metadata_patch,
                related_message_id=signal["trace"]["message_id"],
            )
        else:
            target_state = WorkState.IN_PROGRESS if update.state == "in_progress" else WorkState.BLOCKED
            if current_state == target_state:
                work = self._annotate(
                    work_id=current.work_id,
                    actor=actor,
                    event_kind="baton_update",
                    note=signal_note,
                    metadata_patch=metadata_patch,
                    related_message_id=signal["trace"]["message_id"],
                )
            else:
                work = self._transition(
                    work_id=current.work_id,
                    actor=actor,
                    target_state=target_state,
                    note=signal_note,
                    event_kind="baton_update",
                    metadata_patch=metadata_patch,
                    related_message_id=signal["trace"]["message_id"],
                )
        self._store_protocol_artifact(signal, work=work.to_dict(), actor=actor, related_message_id=signal["trace"]["message_id"])
        return {
            "artifact": signal,
            **self.get_work(work.work_id),
        }

    def apply_baton_close(
        self,
        baton_ref: str,
        *,
        actor: str,
        outcome: str,
        summary: str | None = None,
        artifact_refs: Iterable[str] = (),
        branch: str | None = None,
        head_commit: str | None = None,
    ) -> dict[str, Any]:
        close = BatonClose(
            baton_ref=baton_ref,
            outcome=outcome,
            summary=summary,
            branch=branch,
            head_commit=head_commit,
            artifact_refs=tuple(artifact_refs),
        )
        with self.db.get_connection() as conn:
            current = self._get_work_item_by_baton_ref(conn, baton_ref)
        signal = {
            "schema": "baton_close.v1",
            "trace": {
                "message_id": self._signal_id(),
                "thread_id": current.thread_id,
                "work_id": current.work_id,
            },
            "payload": close.to_payload(),
        }
        metadata_patch = {
            "baton_last_signal": signal["schema"],
            "baton_outcome": close.outcome,
            "baton_summary": close.summary,
            "baton_artifact_refs": list(close.artifact_refs) if close.artifact_refs else None,
            "baton_branch": close.branch,
            "baton_head_commit": close.head_commit,
        }
        signal_note = json.dumps(close.to_payload(), sort_keys=True)
        current_state = WorkState(current.state)
        if close.outcome in {"completed", "merged", "superseded", "expired"}:
            work = self._transition(
                work_id=current.work_id,
                actor=actor,
                target_state=WorkState.CLOSED,
                note=signal_note,
                close_item=True,
                event_kind="baton_close",
                metadata_patch=metadata_patch,
                related_message_id=signal["trace"]["message_id"],
            )
        else:
            if current_state == WorkState.BLOCKED:
                work = self._annotate(
                    work_id=current.work_id,
                    actor=actor,
                    event_kind="baton_close",
                    note=signal_note,
                    metadata_patch=metadata_patch,
                    related_message_id=signal["trace"]["message_id"],
                )
            else:
                work = self._transition(
                    work_id=current.work_id,
                    actor=actor,
                    target_state=WorkState.BLOCKED,
                    note=signal_note,
                    event_kind="baton_close",
                    metadata_patch=metadata_patch,
                    related_message_id=signal["trace"]["message_id"],
                )
        self._store_protocol_artifact(signal, work=work.to_dict(), actor=actor, related_message_id=signal["trace"]["message_id"])
        return {
            "artifact": signal,
            **self.get_work(work.work_id),
        }

    def accept_work(self, work_id: str, *, actor: str, note: str | None = None) -> dict[str, Any]:
        item = self.get_work(work_id)
        if item["work"]["proposed_owner"] != actor:
            raise WhispersDBError(f"{actor} is not the proposed owner of work item {work_id}.")
        metadata_patch = self._apply_capability_requirement_guardrails(
            assignee=actor,
            metadata=item["work"].get("metadata"),
        )
        work = self._transition(
            work_id=work_id,
            actor=actor,
            target_state=WorkState.ACCEPTED,
            note=note,
            proposed_owner=actor,
            owner_agent=actor,
            acknowledge_offer=True,
            metadata_patch=metadata_patch,
        )
        return self.get_work(work.work_id)

    def start_work(self, work_id: str, *, actor: str, note: str | None = None) -> dict[str, Any]:
        item = self.get_work(work_id)
        if item["work"]["owner_agent"] != actor:
            raise WhispersDBError(f"{actor} does not currently own work item {work_id}.")
        work = self._transition(
            work_id=work_id,
            actor=actor,
            target_state=WorkState.IN_PROGRESS,
            note=note,
        )
        return self.get_work(work.work_id)

    def block_work(self, work_id: str, *, actor: str, note: str) -> dict[str, Any]:
        item = self.get_work(work_id)
        if item["work"]["owner_agent"] != actor:
            raise WhispersDBError(f"{actor} does not currently own work item {work_id}.")
        work = self._transition(
            work_id=work_id,
            actor=actor,
            target_state=WorkState.BLOCKED,
            note=note,
        )
        return self.get_work(work.work_id)

    def request_handoff(
        self,
        work_id: str,
        *,
        actor: str,
        new_owner: str,
        note: str | None = None,
    ) -> dict[str, Any]:
        with self.db.get_connection() as conn:
            current = self._get_work_item(conn, work_id)
        new_owner = self._resolve_participant(new_owner, space_id=current.space_id)
        handoff_metadata = self._apply_capability_requirement_guardrails(
            assignee=new_owner,
            metadata=current.metadata,
        )
        if current.owner_agent != actor:
            raise WhispersDBError(f"{actor} does not currently own work item {work_id}.")
        self.spaces.assert_member(current.space_id, new_owner)
        handoff_message = self.messaging.send(
            sender=actor,
            recipient=new_owner,
            subject=f"Handoff requested: {current.title}",
            body=note or current.description,
            msg_type="handoff",
            priority="priority",
            metadata={
                **(handoff_metadata or {}),
                "whispers:work_id": work_id,
                "whispers:work_state": WorkState.HANDOFF_REQUESTED.value,
            },
            space_id=current.space_id,
            thread_id=current.thread_id,
        )
        if handoff_message["status"] == "dead_lettered":
            raise WhispersDBError(f"Unable to request handoff of {work_id} to {new_owner}; delivery was dead-lettered.")
        work = self._transition(
            work_id=work_id,
            actor=actor,
            target_state=WorkState.HANDOFF_REQUESTED,
            note=note,
            proposed_owner=new_owner,
            owner_agent=actor,
            related_message_id=handoff_message["message_id"],
            metadata_patch=handoff_metadata,
        )
        return self.get_work(work.work_id)

    def reject_work(self, work_id: str, *, actor: str, note: str | None = None) -> dict[str, Any]:
        item = self.get_work(work_id)
        work = item["work"]
        if work["state"] != WorkState.OFFERED.value:
            raise WhispersDBError("reject_work is only valid for offered work items in this tranche.")
        if work["proposed_owner"] != actor:
            raise WhispersDBError(f"{actor} is not the proposed owner of work item {work_id}.")
        transitioned = self._transition(
            work_id=work_id,
            actor=actor,
            target_state=WorkState.REJECTED,
            note=note,
            proposed_owner=actor,
            acknowledge_offer=True,
            close_item=True,
        )
        return self.get_work(transitioned.work_id)

    def close_work(self, work_id: str, *, actor: str, note: str | None = None) -> dict[str, Any]:
        item = self.get_work(work_id)
        work = item["work"]
        if actor not in {work["owner_agent"], work["created_by"]}:
            raise WhispersDBError(f"{actor} is not allowed to close work item {work_id}.")
        transitioned = self._transition(
            work_id=work_id,
            actor=actor,
            target_state=WorkState.CLOSED,
            note=note,
            close_item=True,
        )
        return self.get_work(transitioned.work_id)

    def get_work(self, work_id: str) -> dict[str, Any]:
        with self.db.get_connection() as conn:
            item = self._get_work_item(conn, work_id)
            events = conn.execute(
                "SELECT * FROM work_events WHERE work_id = ? ORDER BY sequence ASC",
                (work_id,),
            ).fetchall()
        work = item.to_dict()
        return {
            "work": work,
            "events": [self._row_to_event(row).to_dict() for row in events],
            "baton": self.handoff_baton(work_id) if work.get("linked_message_id") else None,
            "artifacts": self.db.list_protocol_artifacts_for_work(work_id),
        }

    def list_work(
        self,
        *,
        agent_name: str | None = None,
        space_id: str | None = None,
        state: str | None = None,
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM work_items WHERE 1=1"
        params: list[Any] = []
        if space_id:
            query += " AND space_id = ?"
            params.append(space_id)
        if state:
            query += " AND state = ?"
            params.append(state)
        if agent_name:
            query += " AND (created_by = ? OR owner_agent = ? OR proposed_owner = ?)"
            params.extend([agent_name, agent_name, agent_name])
        query += " ORDER BY updated_at DESC, created_at DESC"
        with self.db.get_connection() as conn:
            rows = conn.execute(query, params).fetchall()
            return [self._row_to_work_item(row).to_dict() for row in rows]

    def summary(self, agent_name: str) -> dict[str, int]:
        with self.db.get_connection() as conn:
            row = conn.execute(
                """
                SELECT
                    SUM(CASE WHEN proposed_owner = ? AND state = 'offered' THEN 1 ELSE 0 END) AS incoming_offers,
                    SUM(CASE WHEN owner_agent = ? AND state IN ('accepted', 'in_progress', 'blocked', 'handoff_requested') THEN 1 ELSE 0 END) AS owned_open,
                    SUM(CASE WHEN owner_agent = ? AND state = 'blocked' THEN 1 ELSE 0 END) AS blocked,
                    SUM(CASE WHEN proposed_owner = ? AND state = 'handoff_requested' THEN 1 ELSE 0 END) AS handoff_requests
                FROM work_items
                """,
                (agent_name, agent_name, agent_name, agent_name),
            ).fetchone()
        return {
            "incoming_offers": int(row["incoming_offers"] or 0) if row else 0,
            "owned_open": int(row["owned_open"] or 0) if row else 0,
            "blocked": int(row["blocked"] or 0) if row else 0,
            "handoff_requests": int(row["handoff_requests"] or 0) if row else 0,
        }
