from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


VALID_COMPOSITION_RELATIONS = (
    "contains",
    "part_of",
    "member_of",
    "facade_for",
    "presentation_of",
    "delegate_of",
    "represents",
    "instrument_of",
    "authorized_by",
    "attached_to",
    "reachable_via",
    "backed_by",
    "hosted_by",
    "selected_by",
    "cohort_of",
    "present_within",
)

VALID_COMPOSITION_BASIS = (
    "declared",
    "observed",
    "attested",
    "operator_declared",
    "inferred",
)

WHOLE_ESCALATION_RELATIONS = (
    "delegate_of",
    "represents",
    "instrument_of",
    "authorized_by",
)


def _normalize_choice(value: Any, *, valid: tuple[str, ...], label: str) -> str:
    normalized = str(value or "").strip().lower()
    if normalized not in valid:
        raise ValueError(f"Invalid {label} '{value}'. Expected one of: {', '.join(valid)}.")
    return normalized


@dataclass(frozen=True)
class CompositionEdge:
    source: str
    relation: str
    target: str
    basis: str = "declared"
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.source.strip():
            raise ValueError("source is required")
        if not self.target.strip():
            raise ValueError("target is required")
        object.__setattr__(self, "relation", _normalize_choice(self.relation, valid=VALID_COMPOSITION_RELATIONS, label="relation"))
        object.__setattr__(self, "basis", _normalize_choice(self.basis, valid=VALID_COMPOSITION_BASIS, label="basis"))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def is_structural(self) -> bool:
        return self.relation in {"contains", "part_of", "member_of", "hosted_by", "presentation_of"}

    def is_grouping_only(self) -> bool:
        return self.relation in {"selected_by", "cohort_of", "present_within"}

    def suggests_whole_escalation(self) -> bool:
        return self.relation in WHOLE_ESCALATION_RELATIONS
