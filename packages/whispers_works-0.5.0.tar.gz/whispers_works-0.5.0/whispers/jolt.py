"""Host-native wake decision substrate.

Jolt is the actuation layer between "this thread needs attention" and
"actually wake or invoke something." The core rule is conservative:

- deliver attention first
- stage local context second
- run full inference only when policy, trust, and budget allow it

This module is intentionally host-agnostic. It does not know how VS Code,
Cursor, or a PTY wrapper performs the wake. It only decides what level of
actuation is justified right now.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


JoltAction = Literal["suppress", "notify", "stage_context", "infer"]
JoltAdapterAction = Literal["notify", "stage_context", "infer"]
WakeModel = Literal["manual_wake", "listener_backed", "always_on"]
Interruptibility = Literal["free", "defer", "urgent_only", "do_not_interrupt"]
JoltTrigger = Literal[
    "operator_directed",
    "partner_handoff",
    "blocking_dependency",
    "hot_thread",
    "flash_message",
    "direct_assignment",
    "ambient_update",
]
JoltAdapterState = Literal["ready", "supported", "degraded", "unsupported"]

_JOLT_ADAPTER_VERSION = "jolt-host-adapter-v1"
_VALID_JOLT_ADAPTER_ACTIONS = ("notify", "stage_context", "infer")
_VALID_JOLT_ADAPTER_STATES = ("ready", "supported", "degraded", "unsupported")


def _clamp_nonnegative(value: int) -> int:
    return max(int(value), 0)


def _bool_or_default(value: object, default: bool) -> bool:
    if value is None:
        return default
    return bool(value)


def _normalize_jolt_adapter_actions(value: object) -> tuple[JoltAdapterAction, ...]:
    raw_actions = value if isinstance(value, (list, tuple, set)) else [value]
    normalized: list[JoltAdapterAction] = []
    seen = set()
    for item in raw_actions:
        action = str(item or "").strip().lower()
        if action not in _VALID_JOLT_ADAPTER_ACTIONS or action in seen:
            continue
        seen.add(action)
        normalized.append(action)  # type: ignore[arg-type]
    return tuple(normalized)


@dataclass(frozen=True)
class HostWakeCapabilities:
    host_kind: str
    can_notify: bool = True
    can_stage_context: bool = False
    can_trigger_inference: bool = False
    steals_focus: bool = False

    def to_dict(self) -> dict:
        return {
            "host_kind": self.host_kind,
            "can_notify": self.can_notify,
            "can_stage_context": self.can_stage_context,
            "can_trigger_inference": self.can_trigger_inference,
            "steals_focus": self.steals_focus,
        }


@dataclass(frozen=True)
class JoltHostAdapter:
    host_kind: str
    adapter_kind: str
    supported_actions: tuple[JoltAdapterAction, ...] = field(default_factory=tuple)
    fallback_action: JoltAction = "suppress"
    state: JoltAdapterState = "unsupported"
    version: str = _JOLT_ADAPTER_VERSION
    detail: str | None = None

    def to_dict(self) -> dict:
        payload = {
            "version": self.version,
            "host_kind": self.host_kind,
            "adapter_kind": self.adapter_kind,
            "supported_actions": list(self.supported_actions),
            "fallback_action": self.fallback_action,
            "state": self.state,
        }
        if self.detail:
            payload["detail"] = self.detail
        return payload


@dataclass(frozen=True)
class JoltBudget:
    max_inferences_per_hour: int = 0  # 0 = unlimited
    inferences_used_last_hour: int = 0
    cooldown_seconds: int = 0
    seconds_since_last_inference: int | None = None
    autonomous_inference_enabled: bool = True

    def to_dict(self) -> dict:
        return {
            "max_inferences_per_hour": self.max_inferences_per_hour,
            "inferences_used_last_hour": self.inferences_used_last_hour,
            "cooldown_seconds": self.cooldown_seconds,
            "seconds_since_last_inference": self.seconds_since_last_inference,
            "autonomous_inference_enabled": self.autonomous_inference_enabled,
        }

    def inference_budget_available(self) -> bool:
        cap = _clamp_nonnegative(self.max_inferences_per_hour)
        if cap == 0:
            return True  # 0 = unlimited
        return _clamp_nonnegative(self.inferences_used_last_hour) < cap

    def cooldown_satisfied(self) -> bool:
        if self.cooldown_seconds <= 0:
            return True
        if self.seconds_since_last_inference is None:
            return True
        return int(self.seconds_since_last_inference) >= int(self.cooldown_seconds)


@dataclass(frozen=True)
class JoltContext:
    trigger: JoltTrigger
    wake_model: WakeModel
    interruptibility: Interruptibility = "defer"
    priority: str = "routine"
    explicitly_addressed: bool = False
    blocking: bool = False
    operator_requested: bool = False
    message_size_tier: str = "message"
    estimated_tokens: int = 0
    already_hot: bool = False


@dataclass(frozen=True)
class JoltDecision:
    action: JoltAction
    reasons: list[str] = field(default_factory=list)
    budget_limited: bool = False
    fallback_used: bool = False

    def to_dict(self) -> dict:
        return {
            "action": self.action,
            "reasons": list(self.reasons),
            "budget_limited": self.budget_limited,
            "fallback_used": self.fallback_used,
        }


def baseline_capabilities_for_wake_model(wake_model: WakeModel | str | None) -> HostWakeCapabilities:
    normalized = str(wake_model or "").strip().lower()
    if normalized == "listener_backed":
        return HostWakeCapabilities(
            host_kind="listener_backed",
            can_notify=True,
            can_stage_context=True,
            can_trigger_inference=True,
        )
    if normalized == "always_on":
        return HostWakeCapabilities(
            host_kind="always_on",
            can_notify=True,
            can_stage_context=True,
            can_trigger_inference=True,
        )
    if normalized == "mixed":
        return HostWakeCapabilities(
            host_kind="mixed",
            can_notify=True,
            can_stage_context=True,
            can_trigger_inference=False,
        )
    return HostWakeCapabilities(
        host_kind=normalized or "manual_wake",
        can_notify=True,
        can_stage_context=False,
        can_trigger_inference=False,
    )


def _extract_jolt_payload(payload: dict | None) -> dict:
    raw = payload or {}
    if isinstance(raw.get("jolt"), dict):
        return raw["jolt"]
    return raw if isinstance(raw, dict) else {}


def _extract_jolt_adapter_payload(payload: dict | None) -> dict:
    raw = payload or {}
    if isinstance(raw.get("jolt_adapter"), dict):
        return raw["jolt_adapter"]
    if any(key in raw for key in ("supported_actions", "adapter_kind", "kind", "fallback_action")):
        return raw
    jolt_payload = _extract_jolt_payload(raw)
    adapter_payload = jolt_payload.get("adapter")
    return adapter_payload if isinstance(adapter_payload, dict) else {}


def _actions_from_capabilities(capabilities: HostWakeCapabilities) -> tuple[JoltAdapterAction, ...]:
    actions: list[JoltAdapterAction] = []
    if capabilities.can_notify:
        actions.append("notify")
    if capabilities.can_stage_context:
        actions.append("stage_context")
    if capabilities.can_trigger_inference:
        actions.append("infer")
    return tuple(actions)


def _fallback_action_for_supported_actions(actions: tuple[JoltAdapterAction, ...]) -> JoltAction:
    if "stage_context" in actions:
        return "stage_context"
    if "notify" in actions:
        return "notify"
    return "suppress"


def infer_jolt_adapter_kind(
    host_kind: str | None,
    wake_model: WakeModel | str | None = None,
) -> str:
    normalized = str(host_kind or "").strip().lower()
    wake = str(wake_model or "").strip().lower()
    if normalized in {"cursor", "vscode", "windsurf", "antigravity"}:
        return "native_extension"
    if normalized in {
        "codex",
        "codex_app",
        "codex-desktop",
        "codex_desktop",
        "claude",
        "claude_app",
        "claude-desktop",
        "claude_desktop",
    }:
        return "desktop_app"
    if normalized in {
        "claude_code",
        "claude-code",
        "claude_cli",
        "claude-cli",
        "codex_cli",
        "codex-cli",
        "pty",
        "terminal",
        "plain_terminal",
    }:
        return "managed_pty"
    if normalized in {"listener", "listener_backed", "always_on"} or wake in {"listener_backed", "always_on"}:
        return "listener_loop"
    if normalized in {"local_client", "manual_wake"} or wake == "manual_wake":
        return "notify_only"
    return normalized or "unknown"


def host_wake_capabilities_from_dict(
    wake_model: WakeModel | str | None,
    payload: dict | None,
) -> HostWakeCapabilities:
    baseline = baseline_capabilities_for_wake_model(wake_model)
    jolt_payload = _extract_jolt_payload(payload)
    if not isinstance(jolt_payload, dict):
        return baseline

    adapter_payload = _extract_jolt_adapter_payload(payload)
    host_kind = str(
        jolt_payload.get("host_kind")
        or adapter_payload.get("host_kind")
        or baseline.host_kind
    ).strip() or baseline.host_kind
    explicit_actions = _normalize_jolt_adapter_actions(adapter_payload.get("supported_actions"))
    if explicit_actions:
        return HostWakeCapabilities(
            host_kind=host_kind,
            can_notify="notify" in explicit_actions,
            can_stage_context="stage_context" in explicit_actions,
            can_trigger_inference="infer" in explicit_actions,
            steals_focus=_bool_or_default(jolt_payload.get("steals_focus"), baseline.steals_focus),
        )

    return HostWakeCapabilities(
        host_kind=host_kind,
        can_notify=_bool_or_default(jolt_payload.get("can_notify"), baseline.can_notify),
        can_stage_context=_bool_or_default(jolt_payload.get("can_stage_context"), baseline.can_stage_context),
        can_trigger_inference=_bool_or_default(
            jolt_payload.get("can_trigger_inference"),
            baseline.can_trigger_inference,
        ),
        steals_focus=_bool_or_default(jolt_payload.get("steals_focus"), baseline.steals_focus),
    )


def jolt_adapter_from_dict(
    wake_model: WakeModel | str | None,
    payload: dict | None,
) -> JoltHostAdapter:
    baseline = baseline_capabilities_for_wake_model(wake_model)
    baseline_actions = _actions_from_capabilities(baseline)
    adapter_payload = _extract_jolt_adapter_payload(payload)
    capabilities = host_wake_capabilities_from_dict(wake_model, payload)
    supported_actions = (
        _normalize_jolt_adapter_actions(adapter_payload.get("supported_actions"))
        or _actions_from_capabilities(capabilities)
    )

    adapter_kind = str(
        adapter_payload.get("adapter_kind")
        or adapter_payload.get("kind")
        or infer_jolt_adapter_kind(capabilities.host_kind, wake_model)
    ).strip() or infer_jolt_adapter_kind(capabilities.host_kind, wake_model)

    fallback_action = _fallback_action_for_supported_actions(supported_actions)
    explicit_fallback = str(adapter_payload.get("fallback_action") or "").strip().lower()
    if explicit_fallback in {"suppress", "notify", "stage_context"}:
        fallback_action = explicit_fallback  # type: ignore[assignment]

    state = str(adapter_payload.get("state") or "").strip().lower()
    if state not in _VALID_JOLT_ADAPTER_STATES:
        if not supported_actions:
            state = "unsupported"
        elif not set(baseline_actions).issubset(set(supported_actions)):
            state = "degraded"
        else:
            state = "supported"

    detail = str(adapter_payload.get("detail") or "").strip() or None
    if detail is None and state == "degraded":
        missing = [action for action in baseline_actions if action not in supported_actions]
        if missing:
            detail = f"missing {', '.join(missing)}"
    if detail is None and state == "unsupported":
        detail = "no supported host wake actions advertised"

    return JoltHostAdapter(
        host_kind=capabilities.host_kind,
        adapter_kind=adapter_kind,
        supported_actions=supported_actions,
        fallback_action=fallback_action,
        state=state,  # type: ignore[arg-type]
        detail=detail,
    )


def conservative_jolt_budget() -> JoltBudget:
    """Default: always respond when addressed.

    The 11th emergency could be the mission-critical one.
    Budget is opt-in operator restriction, not default-off gate.
    """
    return JoltBudget(
        max_inferences_per_hour=0,  # 0 = unlimited
        inferences_used_last_hour=0,
        cooldown_seconds=0,
        seconds_since_last_inference=None,
        autonomous_inference_enabled=True,
    )


def jolt_budget_from_dict(payload: dict | None) -> JoltBudget:
    baseline = conservative_jolt_budget()
    raw = payload or {}
    jolt_payload = raw.get("jolt") if isinstance(raw.get("jolt"), dict) else raw
    if not isinstance(jolt_payload, dict):
        return baseline

    return JoltBudget(
        max_inferences_per_hour=int(jolt_payload.get("max_inferences_per_hour") or baseline.max_inferences_per_hour),
        inferences_used_last_hour=int(
            jolt_payload.get("inferences_used_last_hour") or baseline.inferences_used_last_hour
        ),
        cooldown_seconds=int(jolt_payload.get("cooldown_seconds") or baseline.cooldown_seconds),
        seconds_since_last_inference=(
            int(jolt_payload["seconds_since_last_inference"])
            if jolt_payload.get("seconds_since_last_inference") is not None
            else baseline.seconds_since_last_inference
        ),
        autonomous_inference_enabled=_bool_or_default(
            jolt_payload.get("autonomous_inference_enabled"),
            baseline.autonomous_inference_enabled,
        ),
    )


def decide_jolt_action(
    context: JoltContext,
    capabilities: HostWakeCapabilities,
    budget: JoltBudget,
) -> JoltDecision:
    reasons: list[str] = []

    if context.interruptibility == "do_not_interrupt" and not context.operator_requested:
        reasons.append("agent is in do_not_interrupt posture")
        return JoltDecision("suppress", reasons=reasons)

    if context.priority == "system" and capabilities.can_notify:
        reasons.append("system priority always cuts through as attention delivery")
        return JoltDecision("notify", reasons=reasons)

    if context.trigger == "ambient_update" and not context.already_hot:
        reasons.append("ambient updates do not justify actuation by default")
        return JoltDecision("suppress", reasons=reasons)

    wants_attention = (
        context.operator_requested
        or context.blocking
        or context.explicitly_addressed
        or context.trigger in {"flash_message", "priority_message", "partner_handoff", "direct_assignment", "hot_thread"}
    )
    if not wants_attention:
        reasons.append("no explicit attention trigger present")
        return JoltDecision("suppress", reasons=reasons)

    if not capabilities.can_notify:
        reasons.append("host has no supported wake path")
        return JoltDecision("suppress", reasons=reasons)

    # manual_wake is NOT a capability ceiling. The adapter is the
    # source of truth about what the host can actually do.

    if context.interruptibility == "urgent_only" and not (
        context.blocking or context.priority in {"flash", "system"} or context.operator_requested
    ):
        reasons.append("interruptibility is urgent_only and trigger is not urgent")
        return JoltDecision("suppress", reasons=reasons)

    if not capabilities.can_trigger_inference:
        if capabilities.can_stage_context:
            reasons.append("host cannot trigger inference; staging local context instead")
            return JoltDecision("stage_context", reasons=reasons, fallback_used=True)
        reasons.append("host cannot trigger inference; notifying instead")
        return JoltDecision("notify", reasons=reasons, fallback_used=True)

    if not budget.autonomous_inference_enabled:
        if capabilities.can_stage_context:
            reasons.append("autonomous inference disabled by policy")
            return JoltDecision("stage_context", reasons=reasons, fallback_used=True)
        reasons.append("autonomous inference disabled by policy")
        return JoltDecision("notify", reasons=reasons, fallback_used=True)

    if not budget.inference_budget_available():
        if capabilities.can_stage_context:
            reasons.append("hourly inference budget exhausted")
            return JoltDecision(
                "stage_context",
                reasons=reasons,
                budget_limited=True,
                fallback_used=True,
            )
        reasons.append("hourly inference budget exhausted")
        return JoltDecision(
            "notify",
            reasons=reasons,
            budget_limited=True,
            fallback_used=True,
        )

    if not budget.cooldown_satisfied():
        if capabilities.can_stage_context:
            reasons.append("cooldown window still active")
            return JoltDecision(
                "stage_context",
                reasons=reasons,
                budget_limited=True,
                fallback_used=True,
            )
        reasons.append("cooldown window still active")
        return JoltDecision(
            "notify",
            reasons=reasons,
            budget_limited=True,
            fallback_used=True,
        )

    if context.message_size_tier in {"artifact", "bulk"}:
        reasons.append("large message should be staged before any autonomous inference")
        return JoltDecision("stage_context", reasons=reasons)

    reasons.append("policy, host capability, and budget all permit autonomous inference")
    return JoltDecision("infer", reasons=reasons)
