"""whispers echo-peer — test utility that echoes every incoming whisper.

Primary purpose: lets external integrators verify their agent code
without needing a second Claude Code or Codex window. A new developer
can run the daemon, spawn an echo-peer, and confirm their own
WhispersClient.send() reaches an identifiable peer and gets a reply.

Usage:
    whispers echo-peer [--callsign NAME] [--prefix PREFIX] [--once]

Binds as <callsign> (default: echo). For every unseen message it
receives, responds with the same body prefixed by PREFIX (default:
'echo: '). Runs until Ctrl-C, or until one message is echoed if --once.

The echo-peer is intentionally minimal — 40 lines. If a dev can get
their own agent working against it, they have the integration right.
"""

from __future__ import annotations

import signal
import sys
import time
from typing import Any

from .client import WhispersClient


def run_echo_peer(
    *,
    callsign: str = "echo",
    prefix: str = "echo: ",
    poll_interval: float = 0.5,
    once: bool = False,
    announce: bool = True,
) -> int:
    """Main loop. Returns exit code 0 on clean shutdown."""
    agent = WhispersClient(callsign)
    if announce:
        print(
            f"[echo-peer] bound as '{callsign}' "
            f"(agent_id={agent.agent_id[:8]}..., "
            f"session={agent.session_id[:12]}...)",
            flush=True,
        )
        print(f"[echo-peer] listening for whispers. Ctrl-C to stop.", flush=True)

    stop = {"flag": False}

    def _handle_signal(*_: Any) -> None:
        stop["flag"] = True

    try:
        signal.signal(signal.SIGINT, _handle_signal)
        signal.signal(signal.SIGTERM, _handle_signal)
    except (ValueError, AttributeError):
        # Non-main thread or platform quirk — Ctrl-C via KeyboardInterrupt still works
        pass

    echoed_count = 0
    try:
        while not stop["flag"]:
            try:
                inbox = agent.check_inbox(limit=20, mark_seen=True)
            except Exception as exc:
                print(f"[echo-peer] check_inbox failed: {exc}", file=sys.stderr, flush=True)
                time.sleep(poll_interval)
                continue

            for msg in inbox:
                sender = msg.get("from_agent") or ""
                if not sender or sender == callsign:
                    continue
                original_subject = msg.get("subject") or ""
                original_body = msg.get("body") or ""
                msg_uuid = msg.get("uuid")
                reply_subject = f"Re: {original_subject}" if original_subject else "echo"
                reply_body = f"{prefix}{original_body}"
                try:
                    if msg_uuid:
                        agent.respond(
                            message_id=str(msg_uuid),
                            body=reply_body,
                            subject=reply_subject,
                        )
                    else:
                        agent.send(sender, subject=reply_subject, body=reply_body)
                    echoed_count += 1
                    print(
                        f"[echo-peer] echoed '{original_subject[:40]}' -> {sender}",
                        flush=True,
                    )
                    if once:
                        return 0
                except Exception as exc:
                    print(
                        f"[echo-peer] send/respond failed to {sender}: {exc}",
                        file=sys.stderr,
                        flush=True,
                    )

            time.sleep(poll_interval)
    except KeyboardInterrupt:
        pass
    finally:
        print(f"[echo-peer] exiting. Echoed {echoed_count} message(s).", flush=True)
        try:
            agent.close()
        except Exception:
            pass
    return 0


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--callsign", default="echo", help="Bind under this callsign (default: echo)")
    parser.add_argument("--prefix", default="echo: ", help="Reply-body prefix (default: 'echo: ')")
    parser.add_argument("--poll-interval", type=float, default=0.5, help="Seconds between inbox checks")
    parser.add_argument("--once", action="store_true", help="Echo one message then exit (useful for scripts)")
    args = parser.parse_args(argv)
    return run_echo_peer(
        callsign=args.callsign,
        prefix=args.prefix,
        poll_interval=args.poll_interval,
        once=args.once,
    )


if __name__ == "__main__":
    raise SystemExit(main())
