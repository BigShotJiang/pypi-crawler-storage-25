from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .disclosure import VALID_DISCLOSURE_RINGS, normalize_disclosure_ring

_VALID_AGENCY_MODES = {"self", "delegate", "representative", "instrument"}


@dataclass(frozen=True)
class PublicPresentation:
    surface: str
    address: str
    protocol: str | None = None
    purpose: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class VerificationMethod:
    kind: str
    ref: str
    proof_hint: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ContactPath:
    kind: str
    address: str
    policy_ref: str | None = None
    rate_limited: bool = True

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PublicOperatorDescriptor:
    public_handle: str
    stable_anchor_ref: str
    display_name: str
    description: str
    presentations: tuple[PublicPresentation, ...] = field(default_factory=tuple)
    verification_methods: tuple[VerificationMethod, ...] = field(default_factory=tuple)
    contact_paths: tuple[ContactPath, ...] = field(default_factory=tuple)
    policy_refs: tuple[str, ...] = field(default_factory=tuple)
    disclosure_tier: str = "public"
    basis: str = "self_declared"
    freshness: str = "stable"
    agency_mode: str = "self"
    acting_for: str | None = None
    supported_proof_kinds: tuple[str, ...] = field(default_factory=tuple)
    service_migration_ref: str | None = None

    def __post_init__(self) -> None:
        if not self.public_handle.strip():
            raise ValueError("public_handle is required")
        if not self.stable_anchor_ref.strip():
            raise ValueError("stable_anchor_ref is required")
        if not self.display_name.strip():
            raise ValueError("display_name is required")
        if not self.description.strip():
            raise ValueError("description is required")

        object.__setattr__(self, "disclosure_tier", normalize_disclosure_ring(self.disclosure_tier))
        if self.disclosure_tier not in {"public", "spotlight", "trusted"}:
            raise ValueError(
                "PublicOperatorDescriptor disclosure_tier must be one of: public, trusted, spotlight"
            )

        agency_mode = str(self.agency_mode or "").strip().lower()
        if agency_mode not in _VALID_AGENCY_MODES:
            raise ValueError(
                f"Invalid agency_mode '{self.agency_mode}'. Expected one of: {', '.join(sorted(_VALID_AGENCY_MODES))}."
            )
        object.__setattr__(self, "agency_mode", agency_mode)

    def to_dict(self) -> dict[str, Any]:
        return {
            "public_handle": self.public_handle,
            "stable_anchor_ref": self.stable_anchor_ref,
            "display_name": self.display_name,
            "description": self.description,
            "presentations": [item.to_dict() for item in self.presentations],
            "verification_methods": [item.to_dict() for item in self.verification_methods],
            "contact_paths": [item.to_dict() for item in self.contact_paths],
            "policy_refs": list(self.policy_refs),
            "disclosure_tier": self.disclosure_tier,
            "basis": self.basis,
            "freshness": self.freshness,
            "agency_mode": self.agency_mode,
            "acting_for": self.acting_for,
            "supported_proof_kinds": list(self.supported_proof_kinds),
            "service_migration_ref": self.service_migration_ref,
        }

    def as_operator_card(self, *, card_kind: str = "scan") -> dict[str, Any]:
        kind = str(card_kind or "scan").strip().lower()
        base = {
            "card_kind": kind,
            "public_handle": self.public_handle,
            "display_name": self.display_name,
            "description": self.description,
            "disclosure_tier": self.disclosure_tier,
            "basis": self.basis,
            "freshness": self.freshness,
            "agency_mode": self.agency_mode,
        }
        if kind == "scan":
            return base
        if kind == "compact_agent":
            base["presentations"] = [item.to_dict() for item in self.presentations]
            base["supported_proof_kinds"] = list(self.supported_proof_kinds)
            return base
        if kind == "human_public":
            base["presentations"] = [item.to_dict() for item in self.presentations]
            base["contact_paths"] = [item.to_dict() for item in self.contact_paths]
            base["policy_refs"] = list(self.policy_refs)
            return base
        raise ValueError("Unsupported operator card kind. Expected: scan, compact_agent, human_public")


def operator_descriptor_from_dict(data: dict[str, Any]) -> PublicOperatorDescriptor:
    if not isinstance(data, dict):
        raise ValueError("operator descriptor payload must be an object")
    return PublicOperatorDescriptor(
        public_handle=str(data.get("public_handle") or ""),
        stable_anchor_ref=str(data.get("stable_anchor_ref") or ""),
        display_name=str(data.get("display_name") or ""),
        description=str(data.get("description") or ""),
        presentations=tuple(
            PublicPresentation(**item)
            for item in (data.get("presentations") or [])
        ),
        verification_methods=tuple(
            VerificationMethod(**item)
            for item in (data.get("verification_methods") or [])
        ),
        contact_paths=tuple(
            ContactPath(**item)
            for item in (data.get("contact_paths") or [])
        ),
        policy_refs=tuple(str(item) for item in (data.get("policy_refs") or [])),
        disclosure_tier=str(data.get("disclosure_tier") or "public"),
        basis=str(data.get("basis") or "self_declared"),
        freshness=str(data.get("freshness") or "stable"),
        agency_mode=str(data.get("agency_mode") or "self"),
        acting_for=data.get("acting_for"),
        supported_proof_kinds=tuple(str(item) for item in (data.get("supported_proof_kinds") or [])),
        service_migration_ref=data.get("service_migration_ref"),
    )


__all__ = [
    "ContactPath",
    "PublicOperatorDescriptor",
    "PublicPresentation",
    "VerificationMethod",
    "operator_descriptor_from_dict",
    "VALID_DISCLOSURE_RINGS",
]
