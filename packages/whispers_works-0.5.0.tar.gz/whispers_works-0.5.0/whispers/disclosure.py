from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


VALID_DISCLOSURE_RINGS = (
    "vault",
    "private",
    "personal",
    "trusted",
    "public",
    "spotlight",
)
_RING_RANK = {ring: index for index, ring in enumerate(VALID_DISCLOSURE_RINGS)}


def normalize_disclosure_ring(value: Any) -> str:
    ring = str(value or "").strip().lower()
    if ring not in _RING_RANK:
        raise ValueError(
            f"Invalid disclosure ring '{value}'. Expected one of: {', '.join(VALID_DISCLOSURE_RINGS)}."
        )
    return ring


def disclosure_ring_rank(value: Any) -> int:
    return _RING_RANK[normalize_disclosure_ring(value)]


def is_more_public(source_ring: Any, target_ring: Any) -> bool:
    return disclosure_ring_rank(target_ring) > disclosure_ring_rank(source_ring)


@dataclass(frozen=True)
class DisclosureLabel:
    ring: str
    basis: str | None = None
    as_of: str | None = None
    audience_hint: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "ring", normalize_disclosure_ring(self.ring))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
