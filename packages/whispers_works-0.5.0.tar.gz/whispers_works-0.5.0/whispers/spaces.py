from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from datetime import timedelta
from enum import Enum
from typing import Any, Callable, Iterable

from .participant_profiles import participant_projection
from .storage.db import WhispersDB, WhispersDBError
from .time_utils import parse_timestamp, to_utc_iso, utc_now


class BoundaryType(str, Enum):
    HARD = "hard"
    SOFT = "soft"
    PAIR = "pair"
    PUBLIC = "public"
    PRIVATE = "private"


class Governance(str, Enum):
    DIRECTED = "directed"
    OPEN = "open"
    SCOPED = "scoped"


class Visibility(str, Enum):
    SEALED = "sealed"
    DISCOVERABLE = "discoverable"
    PUBLIC = "public"


class Temporality(str, Enum):
    EPHEMERAL = "ephemeral"
    PERSISTENT = "persistent"
    PERMANENT = "permanent"


class NamingPolicy(str, Enum):
    SHARED = "shared"
    EXCLUSIVE = "exclusive"


class NamingConflictMode(str, Enum):
    REJECT = "reject"
    SUFFIX = "suffix"


class MembershipState(str, Enum):
    JOINED = "joined"
    ACTIVE = "active"
    IDLE = "idle"
    STALE = "stale"
    LEFT = "left"
    EXPIRED = "expired"


@dataclass(frozen=True)
class Space:
    space_id: str
    name: str
    purpose: str | None
    status: str
    boundary_type: str
    governance: str
    visibility: str
    temporality: str
    naming_policy: str
    naming_conflict_mode: str
    created_by: str
    created_at: str
    pair_key: str | None = None
    metadata: dict[str, Any] | None = None
    last_sequence: int = 0
    last_delta_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SpaceMember:
    agent_name: str
    membership_role: str
    membership_state: str
    joined_at: str | None
    last_active_at: str | None
    renewed_at: str | None
    expires_at: str | None
    participation_name: str | None = None
    left_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SpaceSeat:
    seat_name: str
    binding_mode: str
    occupant_agent: str | None
    assigned_by: str | None
    note: str | None
    created_at: str
    updated_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SpaceEvent:
    sequence: int
    delta_kind: str
    actor: str
    created_at: str
    text: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SpaceSnapshot:
    space: Space
    members: list[SpaceMember]
    deltas: list[SpaceEvent]

    def to_dict(self) -> dict[str, Any]:
        return {
            "space": self.space.to_dict(),
            "members": [member.to_dict() for member in self.members],
            "deltas": [delta.to_dict() for delta in self.deltas],
        }


_SPACE_LISTENERS: list[Callable[[str, dict[str, Any]], None]] = []


_TEMPORALITY_THRESHOLDS = {
    Temporality.EPHEMERAL: {"idle": 120, "stale": 300, "expiry": 900},
    Temporality.PERSISTENT: {"idle": 900, "stale": 3600, "expiry": 86400},
    Temporality.PERMANENT: {"idle": 3600, "stale": 86400, "expiry": 604800},
}


def register_space_listener(listener: Callable[[str, dict[str, Any]], None]) -> None:
    if listener in _SPACE_LISTENERS:
        return
    _SPACE_LISTENERS.append(listener)


def _normalize_boundary_type(value: str | None) -> str:
    return BoundaryType(value or BoundaryType.HARD.value).value


def _normalize_governance(value: str | None) -> str:
    return Governance(value or Governance.DIRECTED.value).value


def _normalize_visibility(value: str | None) -> str:
    return Visibility(value or Visibility.SEALED.value).value


def _normalize_temporality(value: str | None) -> str:
    return Temporality(value or Temporality.PERSISTENT.value).value


def _normalize_naming_policy(value: str | None) -> str:
    return NamingPolicy(value or NamingPolicy.SHARED.value).value


def _normalize_naming_conflict_mode(value: str | None) -> str:
    return NamingConflictMode(value or NamingConflictMode.REJECT.value).value


def _pair_key_for(participants: Iterable[str]) -> str:
    names = sorted({str(name).strip() for name in participants if str(name).strip()})
    if len(names) != 2:
        raise WhispersDBError("Pair spaces require exactly two distinct participants.")
    return "::".join(names)


class SpaceService:
    """Canonical Space domain service.

    Space is the bounded shared context of participation. Membership lifecycle,
    pair-space semantics, and per-space presence all live here.
    """

    def __init__(self, db: WhispersDB, *, on_event: Callable[[str, dict[str, Any]], None] | None = None):
        self.db = db
        self.on_event = on_event

    def _notify(self, event_type: str, payload: dict[str, Any]) -> None:
        if self.on_event:
            self.on_event(event_type, payload)
        for listener in _SPACE_LISTENERS:
            listener(event_type, payload)

    def _thresholds_for(self, temporality: str) -> dict[str, int]:
        return dict(_TEMPORALITY_THRESHOLDS[Temporality(_normalize_temporality(temporality))])

    def _expires_at_for(self, temporality: str) -> str:
        expiry_seconds = self._thresholds_for(temporality)["expiry"]
        return to_utc_iso(utc_now() + timedelta(seconds=expiry_seconds))

    def _coordination_posture_for(self, governance: str) -> str:
        mapping = {
            Governance.DIRECTED.value: "directed",
            Governance.OPEN.value: "open_team",
            Governance.SCOPED.value: "scoped",
        }
        return mapping[governance]

    def _join_policy_for(self, governance: str) -> str:
        return "open" if governance == Governance.OPEN.value else "invite"

    def _row_to_space(self, row: Any) -> Space:
        metadata = row["metadata"] if "metadata" in row.keys() else None
        if metadata:
            try:
                metadata = json.loads(metadata)
            except Exception:
                metadata = None
        return Space(
            space_id=row["workspace_id"],
            name=row["name"] or row["workspace_id"],
            purpose=row["purpose"],
            status=row["status"],
            boundary_type=(row["boundary_type"] if "boundary_type" in row.keys() else None) or BoundaryType.HARD.value,
            governance=(row["governance"] if "governance" in row.keys() else None)
            or Governance.DIRECTED.value,
            visibility=(row["visibility"] if "visibility" in row.keys() else None) or Visibility.SEALED.value,
            temporality=(row["temporality"] if "temporality" in row.keys() else None)
            or Temporality.PERSISTENT.value,
            naming_policy=(row["naming_policy"] if "naming_policy" in row.keys() else None) or NamingPolicy.SHARED.value,
            naming_conflict_mode=(row["naming_conflict_mode"] if "naming_conflict_mode" in row.keys() else None) or NamingConflictMode.REJECT.value,
            created_by=row["created_by"],
            created_at=row["created_at"],
            pair_key=(row["pair_key"] if "pair_key" in row.keys() else None),
            metadata=metadata,
            last_sequence=int(row["last_sequence"] or 0),
            last_delta_at=row["last_delta_at"],
        )

    def _row_to_member(self, row: Any) -> SpaceMember:
        return SpaceMember(
            agent_name=row["agent_name"],
            membership_role=row["membership_role"],
            membership_state=row["membership_state"],
            joined_at=row["joined_at"],
            last_active_at=(row["last_active_at"] if "last_active_at" in row.keys() else None),
            renewed_at=(row["renewed_at"] if "renewed_at" in row.keys() else None),
            expires_at=(row["expires_at"] if "expires_at" in row.keys() else None),
            participation_name=(row["participation_name"] if "participation_name" in row.keys() else None),
            left_at=row["left_at"],
        )

    def _row_to_seat(self, row: Any) -> SpaceSeat:
        return SpaceSeat(
            seat_name=row["seat_name"],
            binding_mode=row["binding_mode"],
            occupant_agent=row["occupant_agent"],
            assigned_by=row["assigned_by"],
            note=row["note"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def _row_to_event(self, row: Any) -> SpaceEvent:
        return SpaceEvent(
            sequence=int(row["sequence"]),
            delta_kind=row["delta_kind"],
            actor=row["actor"],
            created_at=row["created_at"],
            text=row["text"],
        )

    def _space_row(self, conn, space_id: str):
        return conn.execute(
            "SELECT * FROM workspaces WHERE workspace_id = ?",
            (space_id,),
        ).fetchone()

    def _member_row(self, conn, space_id: str, agent_name: str):
        return conn.execute(
            "SELECT * FROM workspace_members WHERE workspace_id = ? AND agent_name = ?",
            (space_id, agent_name),
        ).fetchone()

    def _next_sequence(self, conn, space_id: str, *, created_at: str) -> int:
        row = conn.execute(
            "UPDATE workspaces SET last_sequence = last_sequence + 1, last_delta_at = ? WHERE workspace_id = ? RETURNING last_sequence",
            (created_at, space_id),
        ).fetchone()
        if not row:
            raise WhispersDBError(f"Space {space_id} not found.")
        return int(row["last_sequence"])

    def _append_event(self, conn, space_id: str, *, delta_kind: str, actor: str, text: str | None) -> int:
        created_at = to_utc_iso(utc_now())
        sequence = self._next_sequence(conn, space_id, created_at=created_at)
        conn.execute(
            """
            INSERT INTO workspace_events (
                workspace_id, sequence, delta_kind, actor, created_at, text
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (space_id, sequence, delta_kind, actor, created_at, text),
        )
        return sequence

    def _refresh_membership_lifecycle(self, conn, *, space_id: str | None = None) -> None:
        params: list[Any] = []
        query = "SELECT wm.*, w.temporality FROM workspace_members wm JOIN workspaces w ON w.workspace_id = wm.workspace_id"
        if space_id:
            query += " WHERE wm.workspace_id = ?"
            params.append(space_id)
        rows = conn.execute(query, params).fetchall()
        now = utc_now()
        for row in rows:
            state = MembershipState(str(row["membership_state"]))
            if state in {MembershipState.LEFT, MembershipState.EXPIRED}:
                continue
            expires_at = parse_timestamp(row["expires_at"])
            if expires_at and expires_at <= now:
                conn.execute(
                    "UPDATE workspace_members SET membership_state = 'expired' WHERE workspace_id = ? AND agent_name = ?",
                    (row["workspace_id"], row["agent_name"]),
                )
                continue
            last_active = parse_timestamp(row["last_active_at"])
            if not last_active:
                continue
            thresholds = self._thresholds_for(row["temporality"])
            idle_cutoff = now - timedelta(seconds=thresholds["idle"])
            stale_cutoff = now - timedelta(seconds=thresholds["stale"])
            next_state = state
            if last_active <= stale_cutoff:
                next_state = MembershipState.STALE
            elif last_active <= idle_cutoff:
                next_state = MembershipState.IDLE
            else:
                next_state = MembershipState.ACTIVE
            if next_state != state:
                conn.execute(
                    "UPDATE workspace_members SET membership_state = ? WHERE workspace_id = ? AND agent_name = ?",
                    (next_state.value, row["workspace_id"], row["agent_name"]),
                )

    def create_space(
        self,
        *,
        created_by: str,
        name: str,
        purpose: str | None = None,
        boundary_type: str = BoundaryType.HARD.value,
        governance: str = Governance.DIRECTED.value,
        visibility: str = Visibility.SEALED.value,
        temporality: str = Temporality.PERSISTENT.value,
        naming_policy: str = NamingPolicy.SHARED.value,
        naming_conflict_mode: str = NamingConflictMode.REJECT.value,
        metadata: dict[str, Any] | None = None,
        pair_key: str | None = None,
        initial_members: Iterable[str] | None = None,
    ) -> SpaceSnapshot:
        boundary_type = _normalize_boundary_type(boundary_type)
        governance = _normalize_governance(governance)
        visibility = _normalize_visibility(visibility)
        temporality = _normalize_temporality(temporality)
        naming_policy = _normalize_naming_policy(naming_policy)
        naming_conflict_mode = _normalize_naming_conflict_mode(naming_conflict_mode)
        now = to_utc_iso(utc_now())
        space_id = f"pair_{uuid.uuid4().hex[:12]}" if boundary_type == BoundaryType.PAIR.value else f"space_{uuid.uuid4().hex[:12]}"
        member_names = list(dict.fromkeys([created_by, *(initial_members or [])]))

        with self.db._db_op("Create space") as conn:
            conn.execute(
                """
                INSERT INTO workspaces (
                    workspace_id, name, purpose, status, created_by, created_at,
                    join_policy, last_delta_at, last_sequence, coordination_posture,
                    boundary_type, governance, visibility, temporality,
                    naming_policy, naming_conflict_mode, pair_key, metadata
                ) VALUES (?, ?, ?, 'active', ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    space_id,
                    name,
                    purpose or name,
                    created_by,
                    now,
                    self._join_policy_for(governance),
                    now,
                    self._coordination_posture_for(governance),
                    boundary_type,
                    governance,
                    visibility,
                    temporality,
                    naming_policy,
                    naming_conflict_mode,
                    pair_key,
                    json.dumps(metadata or {}) if metadata else None,
                ),
            )
            self._append_event(conn, space_id, delta_kind="lifecycle", actor=created_by, text="created")
            conn.commit()

        for member_name in member_names:
            role = "lead" if member_name == created_by and governance == Governance.DIRECTED.value else "member"
            self.join_space(space_id, member_name, membership_role=role)

        snapshot = self.get_snapshot(space_id)
        self._notify("space_created", snapshot.to_dict())
        return snapshot

    def ensure_pair_space(self, participant_a: str, participant_b: str) -> SpaceSnapshot:
        pair_key = _pair_key_for([participant_a, participant_b])
        with self.db.get_connection() as conn:
            row = conn.execute(
                """
                SELECT *
                FROM workspaces
                WHERE pair_key = ?
                  AND status = 'active'
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (pair_key,),
            ).fetchone()
        if row:
            snapshot = self.get_snapshot(row["workspace_id"])
        else:
            participants = pair_key.split("::")
            snapshot = self.create_space(
                created_by=participants[0],
                name=f"{participants[0]} ↔ {participants[1]}",
                purpose="direct coordination",
                boundary_type=BoundaryType.PAIR.value,
                governance=Governance.DIRECTED.value,
                visibility=Visibility.SEALED.value,
                temporality=Temporality.EPHEMERAL.value,
                pair_key=pair_key,
                metadata={"pair_participants": participants},
                initial_members=[participants[1]],
            )
        for participant in pair_key.split("::"):
            if not any(member.agent_name == participant for member in snapshot.members):
                self.join_space(snapshot.space.space_id, participant)
        return self.get_snapshot(snapshot.space.space_id)

    def join_space(
        self,
        space_id: str,
        agent_name: str,
        *,
        membership_role: str = "member",
    ) -> SpaceSnapshot:
        now = to_utc_iso(utc_now())
        with self.db._db_op("Join space") as conn:
            space_row = self._space_row(conn, space_id)
            if not space_row:
                raise WhispersDBError(f"Space {space_id} not found.")
            space = self._row_to_space(space_row)
            if space.status != "active":
                raise WhispersDBError(f"Space {space_id} is not active.")
            if space.boundary_type == BoundaryType.PAIR.value:
                participants = ((space.metadata or {}).get("pair_participants") if space.metadata else None) or []
                if participants and agent_name not in participants:
                    raise WhispersDBError(f"{agent_name} is not one of the participants for pair-space {space_id}.")

            existing = self._member_row(conn, space_id, agent_name)
            joined_at = now if not existing or existing["membership_state"] in {MembershipState.LEFT.value, MembershipState.EXPIRED.value} else existing["joined_at"]
            conn.execute(
                """
                INSERT INTO workspace_members (
                    workspace_id, agent_name, membership_role, membership_state,
                    joined_at, last_active_at, renewed_at, expires_at, left_at
                ) VALUES (?, ?, ?, 'joined', ?, NULL, ?, ?, NULL)
                ON CONFLICT(workspace_id, agent_name) DO UPDATE SET
                    membership_role = excluded.membership_role,
                    membership_state = 'joined',
                    joined_at = excluded.joined_at,
                    last_active_at = NULL,
                    renewed_at = excluded.renewed_at,
                    expires_at = excluded.expires_at,
                    left_at = NULL
                """,
                (space_id, agent_name, membership_role, joined_at, now, self._expires_at_for(space.temporality)),
            )
            self._append_event(conn, space_id, delta_kind="lifecycle", actor=agent_name, text="joined")
            conn.commit()
        snapshot = self.get_snapshot(space_id)
        self._notify("space_joined", {"space_id": space_id, "agent_name": agent_name, "snapshot": snapshot.to_dict()})
        return snapshot

    def leave_space(self, space_id: str, agent_name: str, *, reason: str | None = None) -> SpaceSnapshot:
        now = to_utc_iso(utc_now())
        with self.db._db_op("Leave space") as conn:
            member = self._member_row(conn, space_id, agent_name)
            if not member or member["membership_state"] in {MembershipState.LEFT.value, MembershipState.EXPIRED.value}:
                raise WhispersDBError(f"{agent_name} is not an active member of {space_id}.")
            conn.execute(
                """
                UPDATE workspace_members
                SET membership_state = 'left', left_at = ?, renewed_at = ?, expires_at = ?
                WHERE workspace_id = ? AND agent_name = ?
                """,
                (now, now, now, space_id, agent_name),
            )
            text = f"left ({reason})" if reason else "left"
            self._append_event(conn, space_id, delta_kind="lifecycle", actor=agent_name, text=text)
            conn.commit()
        snapshot = self.get_snapshot(space_id)
        self._notify("space_left", {"space_id": space_id, "agent_name": agent_name, "snapshot": snapshot.to_dict()})
        return snapshot

    def touch_member(self, space_id: str, agent_name: str) -> SpaceMember:
        now = to_utc_iso(utc_now())
        with self.db._db_op("Touch member") as conn:
            space_row = self._space_row(conn, space_id)
            if not space_row:
                raise WhispersDBError(f"Space {space_id} not found.")
            space = self._row_to_space(space_row)
            member = self._member_row(conn, space_id, agent_name)
            if not member:
                raise WhispersDBError(f"{agent_name} is not a member of {space_id}.")
            if member["membership_state"] in {MembershipState.LEFT.value, MembershipState.EXPIRED.value}:
                raise WhispersDBError(f"{agent_name} is not currently participating in {space_id}.")
            conn.execute(
                """
                UPDATE workspace_members
                SET membership_state = 'active',
                    last_active_at = ?,
                    renewed_at = ?,
                    expires_at = ?
                WHERE workspace_id = ? AND agent_name = ?
                """,
                (now, now, self._expires_at_for(space.temporality), space_id, agent_name),
            )
            conn.commit()
            row = self._member_row(conn, space_id, agent_name)
            if not row:
                raise WhispersDBError(f"Unable to refresh member state for {agent_name} in {space_id}.")
            return self._row_to_member(row)

    def assert_member(self, space_id: str, agent_name: str) -> None:
        self._refresh_space(space_id)
        with self.db.get_connection() as conn:
            member = self._member_row(conn, space_id, agent_name)
            if not member or member["membership_state"] in {MembershipState.LEFT.value, MembershipState.EXPIRED.value}:
                raise WhispersDBError(f"{agent_name} is not a current member of {space_id}.")

    def _participation_name_taken(
        self,
        conn,
        *,
        space_id: str,
        participation_name: str,
        excluding_agent: str,
    ) -> bool:
        row = conn.execute(
            """
            SELECT 1
            FROM workspace_members
            WHERE workspace_id = ?
              AND agent_name != ?
              AND membership_state NOT IN ('left', 'expired')
              AND lower(COALESCE(participation_name, '')) = lower(?)
            LIMIT 1
            """,
            (space_id, excluding_agent, participation_name),
        ).fetchone()
        return bool(row)

    def _allocate_unique_participation_name(
        self,
        conn,
        *,
        space_id: str,
        requested_name: str,
        agent_name: str,
    ) -> str:
        if not self._participation_name_taken(
            conn,
            space_id=space_id,
            participation_name=requested_name,
            excluding_agent=agent_name,
        ):
            return requested_name
        base = requested_name.rstrip("0123456789") or requested_name
        for n in range(2, 1000):
            candidate = f"{base}{n}"
            if not self._participation_name_taken(
                conn,
                space_id=space_id,
                participation_name=candidate,
                excluding_agent=agent_name,
            ):
                return candidate
        raise WhispersDBError(f"Unable to allocate a unique participation name from {requested_name!r} in {space_id}.")

    def set_participation_name(self, space_id: str, agent_name: str, participation_name: str | None) -> SpaceMember:
        self._refresh_space(space_id)
        with self.db._db_op("Set participation name") as conn:
            member = self._member_row(conn, space_id, agent_name)
            if not member or member["membership_state"] in {MembershipState.LEFT.value, MembershipState.EXPIRED.value}:
                raise WhispersDBError(f"{agent_name} is not a current member of {space_id}.")
            space_row = self._space_row(conn, space_id)
            if not space_row:
                raise WhispersDBError(f"Space {space_id} not found.")
            space = self._row_to_space(space_row)
            normalized = str(participation_name).strip() if participation_name is not None else None
            normalized = normalized or None
            if normalized and space.naming_policy == NamingPolicy.EXCLUSIVE.value:
                if space.naming_conflict_mode == NamingConflictMode.SUFFIX.value:
                    normalized = self._allocate_unique_participation_name(
                        conn,
                        space_id=space_id,
                        requested_name=normalized,
                        agent_name=agent_name,
                    )
                elif self._participation_name_taken(
                    conn,
                    space_id=space_id,
                    participation_name=normalized,
                    excluding_agent=agent_name,
                ):
                    raise WhispersDBError(
                        f"Participation name {normalized!r} is already in use in {space_id}. This space requires unique local names."
                    )
            conn.execute(
                "UPDATE workspace_members SET participation_name = ? WHERE workspace_id = ? AND agent_name = ?",
                (normalized, space_id, agent_name),
            )
            text = f"participates here as {normalized}" if normalized else "cleared participation name"
            self._append_event(conn, space_id, delta_kind="identity", actor=agent_name, text=text)
            conn.commit()
            row = self._member_row(conn, space_id, agent_name)
            if not row:
                raise WhispersDBError(f"Unable to load updated membership for {agent_name} in {space_id}.")
            return self._row_to_member(row)

    def bind_seat(
        self,
        space_id: str,
        seat_name: str,
        *,
        actor: str,
        occupant_agent: str | None = None,
        note: str | None = None,
        binding_mode: str = "exclusive",
    ) -> SpaceSeat:
        self.assert_member(space_id, actor)
        if occupant_agent is not None:
            self.assert_member(space_id, occupant_agent)
        normalized_seat = str(seat_name or "").strip().lower()
        if not normalized_seat:
            raise WhispersDBError("seat_name is required")
        normalized_mode = str(binding_mode or "exclusive").strip().lower() or "exclusive"
        if normalized_mode not in {"exclusive", "shared"}:
            raise WhispersDBError("binding_mode must be 'exclusive' or 'shared'.")
        now = to_utc_iso(utc_now())
        with self.db._db_op("Bind space seat") as conn:
            conn.execute(
                """
                INSERT INTO space_seats (
                    space_id, seat_name, binding_mode, occupant_agent,
                    assigned_by, note, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(space_id, seat_name) DO UPDATE SET
                    binding_mode = excluded.binding_mode,
                    occupant_agent = excluded.occupant_agent,
                    assigned_by = excluded.assigned_by,
                    note = excluded.note,
                    updated_at = excluded.updated_at
                """,
                (space_id, normalized_seat, normalized_mode, occupant_agent, actor, note, now, now),
            )
            text = (
                f"seat {normalized_seat} -> {occupant_agent}"
                if occupant_agent
                else f"seat {normalized_seat} opened"
            )
            self._append_event(conn, space_id, delta_kind="seat", actor=actor, text=text)
            row = conn.execute(
                "SELECT * FROM space_seats WHERE space_id = ? AND seat_name = ?",
                (space_id, normalized_seat),
            ).fetchone()
            conn.commit()
            if not row:
                raise WhispersDBError(f"Unable to load seat {normalized_seat} in {space_id}.")
            return self._row_to_seat(row)

    def claim_seat(self, space_id: str, seat_name: str, agent_name: str, *, note: str | None = None) -> SpaceSeat:
        return self.bind_seat(space_id, seat_name, actor=agent_name, occupant_agent=agent_name, note=note)

    def release_seat(self, space_id: str, seat_name: str, *, actor: str, note: str | None = None) -> SpaceSeat:
        return self.bind_seat(space_id, seat_name, actor=actor, occupant_agent=None, note=note)

    def seats(self, space_id: str) -> list[dict[str, Any]]:
        self._refresh_space(space_id)
        with self.db.get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM space_seats WHERE space_id = ? ORDER BY seat_name ASC",
                (space_id,),
            ).fetchall()
            return [self._row_to_seat(row).to_dict() for row in rows]

    def resolve_participant_reference(self, space_id: str, reference: str) -> str:
        self._refresh_space(space_id)
        reference = str(reference or "").strip()
        if not reference:
            raise WhispersDBError("participant reference is required")
        with self.db.get_connection() as conn:
            member = self._member_row(conn, space_id, reference)
            if member and member["membership_state"] not in {MembershipState.LEFT.value, MembershipState.EXPIRED.value}:
                return str(member["agent_name"])

            if reference.lower().startswith("seat:"):
                seat_name = reference.split(":", 1)[1].strip().lower()
                row = conn.execute(
                    "SELECT * FROM space_seats WHERE space_id = ? AND seat_name = ?",
                    (space_id, seat_name),
                ).fetchone()
                if not row:
                    raise WhispersDBError(f"Seat {seat_name!r} is not defined in {space_id}.")
                occupant = row["occupant_agent"]
                if not occupant:
                    raise WhispersDBError(f"Seat {seat_name!r} is currently unclaimed in {space_id}.")
                self.assert_member(space_id, str(occupant))
                return str(occupant)

            rows = conn.execute(
                """
                SELECT agent_name
                FROM workspace_members
                WHERE workspace_id = ?
                  AND lower(COALESCE(participation_name, '')) = lower(?)
                  AND membership_state NOT IN ('left', 'expired')
                ORDER BY joined_at ASC, agent_name ASC
                """,
                (space_id, reference),
            ).fetchall()
            if len(rows) == 1:
                return str(rows[0]["agent_name"])
            if len(rows) > 1:
                raise WhispersDBError(
                    f"Reference {reference!r} is ambiguous in {space_id}; {len(rows)} participants share that name here."
                )
            resolved = self.db.resolve_callsign(reference, conn=conn)
            if resolved and resolved.get("resolved_callsign"):
                candidate = str(resolved["resolved_callsign"])
                member = self._member_row(conn, space_id, candidate)
                if member and member["membership_state"] not in {MembershipState.LEFT.value, MembershipState.EXPIRED.value}:
                    return candidate
            raise WhispersDBError(f"Reference {reference!r} not found in {space_id}.")

    def _refresh_space(self, space_id: str) -> None:
        with self.db._db_op("Refresh space membership lifecycle") as conn:
            self._refresh_membership_lifecycle(conn, space_id=space_id)
            conn.commit()

    def get_snapshot(self, space_id: str, *, since_sequence: int = 0) -> SpaceSnapshot:
        with self.db.get_connection() as conn:
            self._refresh_membership_lifecycle(conn, space_id=space_id)
            space_row = self._space_row(conn, space_id)
            if not space_row:
                raise WhispersDBError(f"Space {space_id} not found.")
            member_rows = conn.execute(
                "SELECT * FROM workspace_members WHERE workspace_id = ? ORDER BY joined_at ASC, agent_name ASC",
                (space_id,),
            ).fetchall()
            event_rows = conn.execute(
                "SELECT * FROM workspace_events WHERE workspace_id = ? AND sequence > ? ORDER BY sequence ASC",
                (space_id, since_sequence),
            ).fetchall()
            return SpaceSnapshot(
                space=self._row_to_space(space_row),
                members=[self._row_to_member(row) for row in member_rows],
                deltas=[self._row_to_event(row) for row in event_rows],
            )

    def members(self, space_id: str) -> list[dict[str, Any]]:
        snapshot = self.get_snapshot(space_id)
        from .registry import AgentRegistry

        registry = AgentRegistry(self.db)
        seats_by_agent: dict[str, list[str]] = {}
        for seat in self.seats(space_id):
            occupant = seat.get("occupant_agent")
            if not occupant:
                continue
            seats_by_agent.setdefault(str(occupant), []).append(str(seat.get("seat_name") or ""))
        member_rows: list[dict[str, Any]] = []
        for member in snapshot.members:
            row = member.to_dict()
            card = registry.get_agent_by_callsign(member.agent_name)
            row["participant"] = participant_projection(card, fallback_name=member.agent_name)
            row["held_seats"] = sorted(seats_by_agent.get(member.agent_name, []))
            member_rows.append(row)
        return member_rows

    def presence(self, space_id: str) -> list[dict[str, Any]]:
        return [
            {
                "agent_name": member.agent_name,
                "membership_state": member.membership_state,
                "last_active_at": member.last_active_at,
                "renewed_at": member.renewed_at,
                "expires_at": member.expires_at,
            }
            for member in self.get_snapshot(space_id).members
        ]

    def list_spaces_for_agent(self, agent_name: str, *, include_inactive: bool = False) -> list[dict[str, Any]]:
        with self.db.get_connection() as conn:
            self._refresh_membership_lifecycle(conn)
            query = """
                SELECT w.*
                FROM workspaces w
                JOIN workspace_members wm ON wm.workspace_id = w.workspace_id
                WHERE wm.agent_name = ?
            """
            params: list[Any] = [agent_name]
            if not include_inactive:
                query += " AND wm.membership_state NOT IN ('left', 'expired')"
            query += " ORDER BY w.created_at DESC"
            rows = conn.execute(query, params).fetchall()
            return [self._row_to_space(row).to_dict() for row in rows]

    def startup_capsule(
        self,
        agent_name: str,
        *,
        message_summary: dict[str, int] | None = None,
        trust_tier: int | None = None,
        work_summary: dict[str, int] | None = None,
    ) -> str:
        from .registry import AgentRegistry

        card = AgentRegistry(self.db).get_agent_by_callsign(agent_name)
        participant = participant_projection(card, fallback_name=agent_name)
        identity_line = f"You are {agent_name}"
        if participant.get("summary"):
            identity_line += f", {participant['summary']}"
        if trust_tier is not None:
            identity_line += f" (trust tier {int(trust_tier)})"
        identity_line += "."
        projection_line = participant.get("capsule_summary")

        spaces = self.list_spaces_for_agent(agent_name)
        if spaces:
            primary = spaces[0]
            members = self.members(primary["space_id"])
            active_members = [
                member for member in members
                if member["membership_state"] not in {MembershipState.LEFT.value, MembershipState.EXPIRED.value}
            ]
            member_names = ", ".join(member["agent_name"] for member in active_members)
            self_member = next((member for member in active_members if member["agent_name"] == agent_name), None)
            seats = [seat for seat in self.seats(primary["space_id"]) if seat.get("occupant_agent") == agent_name]
            local_bits: list[str] = []
            if self_member and self_member.get("participation_name"):
                local_bits.append(f"here you appear as {self_member['participation_name']}")
            if seats:
                local_bits.append("you hold " + ", ".join(seat["seat_name"] for seat in seats))
            local_clause = f" ({'; '.join(local_bits)})" if local_bits else ""
            location_line = f"You are in {primary['name']} with {member_names or 'no one else'}{local_clause}."
        else:
            location_line = "You are not in any spaces yet."

        attention_bits: list[str] = []
        if message_summary:
            attention_bits.append(
                f"{message_summary.get('unread', 0)} messages waiting. {message_summary.get('urgent', 0)} urgent."
            )
        if work_summary:
            if work_summary.get("incoming_offers", 0):
                attention_bits.append(f"{work_summary['incoming_offers']} work offers waiting.")
            if work_summary.get("blocked", 0):
                attention_bits.append(f"{work_summary['blocked']} blocked work items.")

        return " ".join([identity_line, projection_line or "", location_line, *attention_bits]).strip()
