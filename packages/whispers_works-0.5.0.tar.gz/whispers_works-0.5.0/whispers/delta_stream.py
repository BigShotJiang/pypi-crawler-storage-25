"""Delta event broker + peer-lifecycle event helpers.

Phase 3 Slice 9 keystone. Peers already subscribed to the wake stream
receive structured delta events when other peers bind, disbind, or
change state that matters for team awareness. Closes the "new agent
joined, I had no idea" gap that invalidated the starting-line product
definition.

Event shape (JSON, emitted on the SSE wake stream with event:peer_delta):

    {
      "event_type": "peer_delta",
      "kind": "peer_bound" | "peer_gone" | "peer_tier_changed",
      "callsign": "<callsign>",
      "agent_id": "<agent_id>",
      "trust_tier": <int>,
      "continuity_anchor": "<anchor>",
      "platform_family": "<family>",
      "at": "<ISO-8601-UTC>",
      "...kind-specific fields..."
    }

The broker is a thread-safe pub/sub in a single process. Same process
hosts the HTTP server AND the MCP tool handlers, so both emit via the
same singleton. For a future multi-process deployment a cross-process
bus (Redis, SQLite NOTIFY, etc) replaces the broker without changing
the emission call sites.
"""

from __future__ import annotations

import datetime as _dt
import queue
import threading
from typing import Any


def _utc_now_iso() -> str:
    return _dt.datetime.utcnow().isoformat() + "Z"


class DeltaEventBroker:
    """Thread-safe pub/sub for peer-lifecycle delta events.

    Two emission shapes:
        * publish(agent_name, event) — single-recipient. Same signature
          as the existing _WakeEventBroker so call sites can switch
          freely. Used when a delta is for exactly one peer (e.g. a
          direct tier change applied to a specific agent).
        * broadcast(event, exclude_callsign=None) — fans out to ALL
          currently-subscribed agents. Used for peer_bound / peer_gone
          so every live participant sees the team change.

    Subscribers receive events via queue.Queue (same pattern as
    _WakeEventBroker) so the SSE stream endpoint can drain them with
    blocking gets inside its event loop.
    """

    def __init__(self) -> None:
        self._subscribers: dict[str, list[queue.Queue[dict[str, Any]]]] = {}
        self._lock = threading.Lock()

    def subscribe(self, agent_name: str) -> queue.Queue[dict[str, Any]]:
        subscriber: queue.Queue[dict[str, Any]] = queue.Queue()
        with self._lock:
            self._subscribers.setdefault(agent_name, []).append(subscriber)
        return subscriber

    def unsubscribe(
        self,
        agent_name: str,
        subscriber: queue.Queue[dict[str, Any]],
    ) -> None:
        with self._lock:
            listeners = self._subscribers.get(agent_name)
            if not listeners:
                return
            self._subscribers[agent_name] = [
                item for item in listeners if item is not subscriber
            ]
            if not self._subscribers[agent_name]:
                self._subscribers.pop(agent_name, None)

    def publish(self, agent_name: str, event: dict[str, Any]) -> None:
        """Single-recipient emit."""
        with self._lock:
            listeners = list(self._subscribers.get(agent_name, []))
        for sub in listeners:
            try:
                sub.put_nowait(dict(event))
            except queue.Full:
                pass

    def broadcast(
        self,
        event: dict[str, Any],
        *,
        exclude_callsign: str | None = None,
    ) -> None:
        """Fan out to every subscribed agent, optionally excluding one.

        The exclude_callsign path is for peer_bound — the agent who just
        bound does not need to receive its own arrival event; every
        OTHER subscribed agent does.
        """
        normalized_exclude = (exclude_callsign or "").strip().lower() or None
        with self._lock:
            snapshot = {name: list(subs) for name, subs in self._subscribers.items()}
        for name, subs in snapshot.items():
            if normalized_exclude and name.strip().lower() == normalized_exclude:
                continue
            for sub in subs:
                try:
                    sub.put_nowait(dict(event))
                except queue.Full:
                    pass

    def subscriber_count(self) -> int:
        with self._lock:
            return sum(len(subs) for subs in self._subscribers.values())


# ---------------------------------------------------------------------------
# Event builders
# ---------------------------------------------------------------------------


def build_peer_bound_event(card: dict[str, Any]) -> dict[str, Any]:
    """Shape a peer_bound delta event from an agent_cards row dict."""
    return {
        "event_type": "peer_delta",
        "kind": "peer_bound",
        "callsign": (card.get("callsign") or "").strip().lower(),
        "agent_id": card.get("agent_id"),
        "stable_subject_id": card.get("stable_subject_id"),
        "trust_tier": int(card.get("trust_tier") or 0),
        "continuity_anchor": card.get("continuity_anchor"),
        "platform_family": card.get("platform_family"),
        "registered_at": card.get("registered_at"),
        "at": _utc_now_iso(),
    }


def build_peer_gone_event(
    *,
    callsign: str,
    agent_id: str | None = None,
    reason: str = "session_expired",
) -> dict[str, Any]:
    """Shape a peer_gone delta event."""
    return {
        "event_type": "peer_delta",
        "kind": "peer_gone",
        "callsign": (callsign or "").strip().lower(),
        "agent_id": agent_id,
        "reason": reason,
        "at": _utc_now_iso(),
    }


def build_peer_tier_changed_event(
    *,
    callsign: str,
    old_tier: int,
    new_tier: int,
    agent_id: str | None = None,
) -> dict[str, Any]:
    return {
        "event_type": "peer_delta",
        "kind": "peer_tier_changed",
        "callsign": (callsign or "").strip().lower(),
        "agent_id": agent_id,
        "old_tier": int(old_tier),
        "new_tier": int(new_tier),
        "at": _utc_now_iso(),
    }


# ---------------------------------------------------------------------------
# Emission helpers — hook these into bind / unbind / tier-change paths
# ---------------------------------------------------------------------------


def emit_peer_bound(broker: DeltaEventBroker, card: dict[str, Any]) -> None:
    event = build_peer_bound_event(card)
    broker.broadcast(event, exclude_callsign=event["callsign"])


def emit_peer_gone(
    broker: DeltaEventBroker,
    *,
    callsign: str,
    agent_id: str | None = None,
    reason: str = "session_expired",
) -> None:
    event = build_peer_gone_event(
        callsign=callsign, agent_id=agent_id, reason=reason,
    )
    broker.broadcast(event, exclude_callsign=callsign)


def emit_peer_tier_changed(
    broker: DeltaEventBroker,
    *,
    callsign: str,
    old_tier: int,
    new_tier: int,
    agent_id: str | None = None,
) -> None:
    event = build_peer_tier_changed_event(
        callsign=callsign, old_tier=old_tier, new_tier=new_tier,
        agent_id=agent_id,
    )
    broker.broadcast(event)  # no exclusion — even the affected peer wants to see their own tier change confirmed


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

# Single process serves both HTTP + MCP in the Whispers daemon. Both call
# sites import this singleton so emissions propagate to all subscribers
# regardless of surface.
_DELTA_BROKER_SINGLETON: DeltaEventBroker | None = None
_DELTA_BROKER_LOCK = threading.Lock()


def get_delta_broker() -> DeltaEventBroker:
    """Return the process-wide delta broker, creating it on first call."""
    global _DELTA_BROKER_SINGLETON
    with _DELTA_BROKER_LOCK:
        if _DELTA_BROKER_SINGLETON is None:
            _DELTA_BROKER_SINGLETON = DeltaEventBroker()
        return _DELTA_BROKER_SINGLETON


__all__ = [
    "DeltaEventBroker",
    "build_peer_bound_event",
    "build_peer_gone_event",
    "build_peer_tier_changed_event",
    "emit_peer_bound",
    "emit_peer_gone",
    "emit_peer_tier_changed",
    "get_delta_broker",
]
