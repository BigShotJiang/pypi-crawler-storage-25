from __future__ import annotations

from typing import Any

from .dispatcher import Dispatcher
from .envelope import Envelope, MsgType, Priority
from .frames import format_message_frame
from .spaces import SpaceService
from .storage.db import WhispersDB, WhispersDBError
from .time_utils import to_utc_iso
from .twoack import build_status_envelope, extract_twoack, metadata_mirrors, preflight_decision, preflight_surface


def _frame_message(msg: dict[str, Any]) -> str:
    """Render the canonical operator-visible frame for an inbox message.

    The DB envelope is never modified; this frame is stamped at read time.
    Glyphs and layout live in ``whispers.frames`` — do not inline them here.
    """
    sender = msg.get("from_agent") or msg.get("sender") or "?"
    recipient = msg.get("to_agent") or msg.get("recipient") or "?"
    priority = msg.get("priority") or "routine"
    subject = msg.get("subject") or ""
    body = msg.get("body") or ""
    state: str | None = None
    env = extract_twoack(msg.get("payload"))
    if env:
        pf = preflight_surface(env)
        if pf.get("schema") == "status_update.v1":
            state = (env.get("payload") or {}).get("state")
    return format_message_frame(
        sender, recipient, priority, subject, body=body or None, state=state
    )


class MessagingService:
    """Canonical Messaging domain service.

    Messaging is space-aware. Direct exchanges live in a shared space or an
    ephemeral pair-space. Threading is explicit and lifecycle state is stored in
    the message record instead of being inferred from shell behavior.
    """

    def __init__(
        self,
        db: WhispersDB,
        *,
        spaces: SpaceService | None = None,
        dispatcher: Dispatcher | None = None,
    ):
        self.db = db
        self.spaces = spaces or SpaceService(db)
        self.dispatcher = dispatcher or Dispatcher(db)

    def _resolve_space_for_send(
        self,
        *,
        sender: str,
        recipient: str,
        space_id: str | None,
    ) -> tuple[str, str]:
        if not space_id:
            return self.spaces.ensure_pair_space(sender, recipient).space.space_id, recipient
        self.spaces.assert_member(space_id, sender)
        resolved_recipient = self.spaces.resolve_participant_reference(space_id, recipient)
        self.spaces.assert_member(space_id, resolved_recipient)
        return space_id, resolved_recipient

    def _resolve_thread_id(
        self,
        *,
        message_id: str,
        reply_to: str | None,
        thread_id: str | None,
    ) -> str:
        if thread_id:
            return thread_id
        if reply_to:
            parent = self.db.get_message(reply_to)
            if not parent:
                raise WhispersDBError(f"reply_to message {reply_to} not found.")
            return parent.get("thread_id") or parent.get("message_id") or reply_to
        return message_id

    def send(
        self,
        *,
        sender: str,
        recipient: str,
        subject: str,
        body: str | None = None,
        msg_type: str = MsgType.INFORM.value,
        priority: str = Priority.ROUTINE.value,
        payload: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        reply_to: str | None = None,
        trace_id: str | None = None,
        context_id: str | None = None,
        space_id: str | None = None,
        thread_id: str | None = None,
        sender_session_id: str | None = None,
    ) -> dict[str, Any]:
        requested_recipient = recipient
        resolved = self.db.resolve_callsign(recipient)
        if resolved and resolved.get("resolved_callsign"):
            recipient = str(resolved["resolved_callsign"])

        resolved_space_id, recipient = self._resolve_space_for_send(
            sender=sender,
            recipient=recipient,
            space_id=space_id,
        )

        envelope = Envelope(
            sender=sender,
            recipient=recipient,
            msg_type=MsgType(msg_type),
            subject=subject,
            body=body,
            priority=Priority(priority),
            payload=payload,
            metadata=dict(metadata or {}),
            reply_to=reply_to,
            trace_id=trace_id,
            context_id=context_id,
        )
        thread_id = self._resolve_thread_id(
            message_id=envelope.id,
            reply_to=reply_to,
            thread_id=thread_id,
        )
        if envelope.metadata is None:
            envelope.metadata = {}
        envelope.metadata.setdefault("whispers:space_id", resolved_space_id)
        envelope.metadata.setdefault("whispers:thread_id", thread_id)

        raw_payload = dict(payload or {})
        twoack_envelope = build_status_envelope(
            message_id=envelope.id,
            thread_id=thread_id,
            created_at=to_utc_iso(envelope.created_at),
            state=str(raw_payload.get("state") or "building"),
            readiness=raw_payload.get("readiness"),
            current_task=raw_payload.get("current_task"),
            interruptibility=raw_payload.get("interruptibility"),
            confidence=raw_payload.get("confidence"),
            working_set=raw_payload.get("working_set"),
            in_reply_to=reply_to,
            trace_id=trace_id,
        )
        raw_payload.pop("twoack", None)
        envelope.payload = {"twoack": twoack_envelope, **raw_payload}
        envelope.metadata.update(metadata_mirrors())

        try:
            self.spaces.touch_member(resolved_space_id, sender)
        except WhispersDBError:
            # If the sender just joined and has not become active yet, sending is
            # the activity that promotes them.
            self.spaces.join_space(resolved_space_id, sender)
            self.spaces.touch_member(resolved_space_id, sender)

        if requested_recipient != recipient:
            envelope.metadata.setdefault("whispers:requested_recipient", requested_recipient)

        status = self.dispatcher.dispatch(
            envelope,
            space_id=resolved_space_id,
            thread_id=thread_id,
            context_id=context_id,
            sender_session_id=sender_session_id,
            recipient_alias=requested_recipient if requested_recipient != recipient else None,
        )
        if reply_to and status in {"delivered", "queued"}:
            self.db.mark_message_answered(reply_to)
        return {
            "status": status,
            "message_id": envelope.id,
            "delivery_status": status,
            "space_id": resolved_space_id,
            "thread_id": thread_id,
        }

    def respond(
        self,
        *,
        sender: str,
        message_id: str,
        body: str,
        subject: str | None = None,
        priority: str = Priority.ROUTINE.value,
        msg_type: str = MsgType.REPLY.value,
        sender_session_id: str | None = None,
    ) -> dict[str, Any]:
        original = self.db.get_message(message_id)
        if not original:
            raise WhispersDBError(f"Message {message_id} not found.")
        return self.send(
            sender=sender,
            recipient=original["sender"],
            subject=subject or f"Re: {original['subject']}",
            body=body,
            msg_type=msg_type,
            priority=priority,
            reply_to=message_id,
            trace_id=original.get("trace_id"),
            context_id=original.get("context_id"),
            space_id=original.get("space_id"),
            thread_id=original.get("thread_id"),
            sender_session_id=sender_session_id,
        )

    def replay_dead_letters_for_recipient(
        self,
        agent_name: str,
        *,
        agent_id: str | None = None,
        delivery_session_id: str | None = None,
    ) -> list[str]:
        return self.db.replay_dead_letters_for_recipient(
            agent_name,
            recipient_agent_id=agent_id,
            delivery_session_id=delivery_session_id,
        )

    def replay_dead_letters_for_sender(
        self,
        agent_name: str,
        *,
        agent_id: str | None = None,
        delivery_session_id: str | None = None,
    ) -> list[str]:
        return self.db.replay_dead_letters_for_sender(
            agent_name,
            sender_agent_id=agent_id,
            delivery_session_id=delivery_session_id,
        )

    def inbox(
        self,
        agent_name: str,
        *,
        limit: int = 50,
        mark_seen: bool = True,
        space_id: str | None = None,
        thread_id: str | None = None,
    ) -> list[dict[str, Any]]:
        messages = self.db.read_inbox(
            agent_name,
            limit=limit,
            mark_seen=mark_seen,
            space_id=space_id,
            thread_id=thread_id,
        )
        if mark_seen:
            touched_spaces = {message.get("space_id") for message in messages if message.get("space_id")}
            for touched_space in touched_spaces:
                # Presence refresh is secondary to the read itself; if the
                # caller happens to have a stale / missing membership in a
                # space where a message landed for them (e.g. a pair space
                # whose recipient-side membership expired or wasn't yet
                # created at delivery time), a non-member recipient
                # reading their own inbox should still succeed. Attempt
                # to self-heal by joining; if that fails too, silently
                # skip the touch so the read still returns the messages.
                try:
                    self.spaces.touch_member(str(touched_space), agent_name)
                except WhispersDBError:
                    try:
                        self.spaces.join_space(str(touched_space), agent_name)
                        self.spaces.touch_member(str(touched_space), agent_name)
                    except WhispersDBError:
                        pass
        for msg in messages:
            msg["frame"] = _frame_message(msg)
        return messages

    def outbox(
        self,
        agent_name: str,
        *,
        limit: int = 20,
        space_id: str | None = None,
        thread_id: str | None = None,
    ) -> list[dict[str, Any]]:
        return self.db.read_outbox(agent_name, limit=limit, space_id=space_id, thread_id=thread_id)

    def message_status(self, agent_name: str, message_id: str) -> dict[str, Any]:
        status = self.db.get_message_status(message_id)
        if not status:
            raise WhispersDBError(f"Message {message_id} not found.")
        recipients = {str(item.get("recipient_callsign") or "") for item in status.get("recipients") or []}
        if agent_name not in {str(status.get("sender") or ""), str(status.get("recipient") or ""), *recipients}:
            raise WhispersDBError(f"Message {message_id} is not visible to {agent_name}.")
        return status

    def thread(self, agent_name: str, thread_id: str, *, limit: int = 100) -> list[dict[str, Any]]:
        records = self.db.read_thread(thread_id, limit=limit)
        for record in records:
            record_space_id = record.get("space_id")
            if record_space_id:
                self.spaces.assert_member(record_space_id, agent_name)
        return records

    def preflight_decision(self, msg_row: dict[str, Any]) -> str:
        return preflight_decision(msg_row)

    def summary(self, agent_name: str) -> dict[str, int]:
        return self.db.inbox_summary(agent_name)
