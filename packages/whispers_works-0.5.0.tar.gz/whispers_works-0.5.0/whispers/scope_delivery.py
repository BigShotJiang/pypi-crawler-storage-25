from __future__ import annotations

import contextlib
import json
from dataclasses import dataclass
from typing import Any

from .envelope import Envelope


_EXPLICIT_CROSS_SCOPE_SCHEMAS = {
    "handoff_baton.v1",
    "baton_ack.v1",
    "baton_update.v1",
    "baton_close.v1",
}

# Workspace confidentiality postures control how strict boundary enforcement is.
# open: scope crossings are logged but allowed freely
# standard: scope crossings are logged and the operator is notified
# confidential: scope crossings are blocked unless explicitly approved
WORKSPACE_CONFIDENTIALITY_POSTURES = {"open", "standard", "confidential"}
DEFAULT_CONFIDENTIALITY_POSTURE = "standard"


@dataclass(frozen=True)
class ScopeWideningDecision:
    """Result of evaluating whether a scope crossing should be allowed."""

    allowed: bool
    action: str  # "allow", "notify", "block"
    reason: str
    source_workspace: str | None = None
    target_workspace: str | None = None
    schema: str | None = None
    confidentiality_posture: str = DEFAULT_CONFIDENTIALITY_POSTURE

    def as_security_event_detail(self, *, message_id: str, actor: str) -> dict[str, Any]:
        return {
            "actor": actor,
            "message_id": message_id,
            "action": self.action,
            "reason": self.reason,
            "source_workspace": self.source_workspace,
            "target_workspace": self.target_workspace,
            "schema": self.schema,
            "confidentiality_posture": self.confidentiality_posture,
        }


@dataclass(frozen=True)
class WorkspaceDeliveryRedaction:
    workspace_id: str
    schema: str | None
    redaction_mode: str
    reason: str = "non_member_workspace_delivery"

    def as_detail(self, *, message_id: str, explicit_transfer: bool) -> dict[str, Any]:
        return {
            "workspace_id": self.workspace_id,
            "schema": self.schema,
            "redaction_mode": self.redaction_mode,
            "reason": self.reason,
            "message_id": message_id,
            "explicit_transfer": explicit_transfer,
        }


def _normalize_optional_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _load_jsonish(value: Any) -> Any:
    if isinstance(value, str):
        with contextlib.suppress(Exception):
            return json.loads(value)
    return value


def _linked_workspace_for_baton(db, baton_ref: str | None) -> str | None:
    if not baton_ref:
        return None
    with db.get_readonly_connection() as conn:
        row = conn.execute(
            "SELECT linked_workspace_id FROM baton_projections WHERE baton_ref = ?",
            (baton_ref,),
        ).fetchone()
    if not row:
        return None
    return _normalize_optional_text(row["linked_workspace_id"])


def _get_workspace_confidentiality(db, workspace_id: str) -> str:
    """Return the confidentiality posture for a workspace, defaulting to 'standard'."""
    with db.get_readonly_connection() as conn:
        row = conn.execute(
            "SELECT confidentiality_posture FROM workspaces WHERE workspace_id = ?",
            (workspace_id,),
        ).fetchone()
    if not row or not row["confidentiality_posture"]:
        return DEFAULT_CONFIDENTIALITY_POSTURE
    posture = str(row["confidentiality_posture"]).strip().lower()
    return posture if posture in WORKSPACE_CONFIDENTIALITY_POSTURES else DEFAULT_CONFIDENTIALITY_POSTURE


def _workspace_exists(db, workspace_id: str) -> bool:
    """Check whether a workspace exists and is active."""
    with db.get_readonly_connection() as conn:
        row = conn.execute(
            "SELECT 1 FROM workspaces WHERE workspace_id = ? AND status = 'active'",
            (workspace_id,),
        ).fetchone()
    return row is not None


def evaluate_scope_widening(
    db,
    envelope: Envelope,
    target_workspace_id: str | None,
    schema: str | None,
) -> ScopeWideningDecision | None:
    """Evaluate whether a message constitutes scope widening and decide how to handle it.

    Returns None if no scope widening is detected. Returns a ScopeWideningDecision
    if a workspace boundary crossing is detected.
    """
    if not target_workspace_id:
        return None

    # Only enforce for workspaces that actually exist. A reference to a
    # non-existent workspace is not a scope boundary — there's nothing to protect.
    if not _workspace_exists(db, target_workspace_id):
        return None

    sender = envelope.sender
    is_member = _is_active_workspace_member(db, sender, target_workspace_id)

    if is_member:
        return None

    # Non-member sending into a workspace — this is scope widening.
    posture = _get_workspace_confidentiality(db, target_workspace_id)
    is_handoff_schema = schema in _EXPLICIT_CROSS_SCOPE_SCHEMAS

    if posture == "confidential":
        # Confidential rooms block all non-member scope crossings
        return ScopeWideningDecision(
            allowed=False,
            action="block",
            reason="non_member_delivery_to_confidential_workspace",
            target_workspace=target_workspace_id,
            schema=schema,
            confidentiality_posture=posture,
        )

    if posture == "standard" and is_handoff_schema:
        # Standard rooms block non-member workspace-linked handoffs
        # because silent redaction creates split-brain scope truth
        return ScopeWideningDecision(
            allowed=False,
            action="block",
            reason="non_member_workspace_linked_handoff",
            target_workspace=target_workspace_id,
            schema=schema,
            confidentiality_posture=posture,
        )

    if posture == "standard":
        # Standard rooms notify on non-handoff scope crossings
        return ScopeWideningDecision(
            allowed=True,
            action="notify",
            reason="non_member_workspace_delivery",
            target_workspace=target_workspace_id,
            schema=schema,
            confidentiality_posture=posture,
        )

    # Open rooms allow everything, but still log
    return ScopeWideningDecision(
        allowed=True,
        action="allow",
        reason="open_workspace_permits_cross_scope",
        target_workspace=target_workspace_id,
        schema=schema,
        confidentiality_posture=posture,
    )


def _is_active_workspace_member(db, agent_name: str, workspace_id: str) -> bool:
    with db.get_readonly_connection() as conn:
        row = conn.execute(
            """
            SELECT 1
            FROM workspace_members
            WHERE workspace_id = ?
              AND agent_name = ?
              AND membership_state = 'active'
            """,
            (workspace_id, agent_name),
        ).fetchone()
    return row is not None


def _workspace_scope_info(db, payload: Any, metadata: Any) -> tuple[str | None, str | None, bool]:
    payload_dict = _load_jsonish(payload)
    metadata_dict = _load_jsonish(metadata)
    if not isinstance(metadata_dict, dict):
        metadata_dict = {}

    schema = payload_dict.get("schema") if isinstance(payload_dict, dict) else None
    inner_payload = payload_dict.get("payload") if isinstance(payload_dict, dict) and isinstance(payload_dict.get("payload"), dict) else None

    workspace_id = _normalize_optional_text(metadata_dict.get("whispers:workspace_id"))
    if workspace_id is None and isinstance(payload_dict, dict):
        workspace_id = _normalize_optional_text(payload_dict.get("workspace_id"))
    if workspace_id is None and isinstance(inner_payload, dict):
        workspace_id = _normalize_optional_text(inner_payload.get("workspace_id"))

    baton_payload = inner_payload if isinstance(inner_payload, dict) else payload_dict if isinstance(payload_dict, dict) else None
    if workspace_id is None and schema in _EXPLICIT_CROSS_SCOPE_SCHEMAS and isinstance(baton_payload, dict):
        workspace_id = _linked_workspace_for_baton(
            db,
            _normalize_optional_text(baton_payload.get("baton_ref")),
        )

    if workspace_id is None:
        working_scope = _normalize_optional_text(metadata_dict.get("whispers:working_scope"))
        if working_scope and working_scope.startswith("workspace:"):
            workspace_id = _normalize_optional_text(working_scope.split("workspace:", 1)[1])

    return workspace_id, schema, schema in _EXPLICIT_CROSS_SCOPE_SCHEMAS


def _sanitize_explicit_payload(payload: Any) -> dict[str, Any] | None:
    payload_dict = _load_jsonish(payload)
    if not isinstance(payload_dict, dict):
        return None

    sanitized: dict[str, Any] = {}
    for key in ("wire_v", "schema", "mode", "signal_class"):
        if key in payload_dict:
            sanitized[key] = payload_dict[key]

    trace = payload_dict.get("trace")
    if isinstance(trace, dict):
        sanitized_trace = {
            key: trace[key]
            for key in ("message_id", "trace_id")
            if trace.get(key) not in (None, "")
        }
        if sanitized_trace:
            sanitized["trace"] = sanitized_trace

    if "payload" in payload_dict:
        sanitized["payload"] = payload_dict["payload"]

    return sanitized or None


def sanitize_envelope_for_workspace_recipient(
    db,
    envelope: Envelope,
    recipient: str,
) -> tuple[Envelope, WorkspaceDeliveryRedaction | None]:
    workspace_id, schema, explicit_transfer = _workspace_scope_info(
        db,
        envelope.payload,
        envelope.metadata,
    )
    if not workspace_id or _is_active_workspace_member(db, recipient, workspace_id):
        return envelope, None

    metadata = dict(envelope.metadata or {})
    redaction_mode = "payload_preserved" if explicit_transfer else "full_redaction"
    metadata.update(
        {
            "whispers:scope_redacted": True,
            "whispers:scope_redaction_reason": "non_member_workspace_delivery",
            "whispers:scope_redaction_mode": redaction_mode,
            "whispers:workspace_id": workspace_id,
        }
    )
    if schema:
        metadata["whispers:original_schema"] = schema

    sanitized_envelope = Envelope(
        sender=envelope.sender,
        recipient=envelope.recipient,
        msg_type=envelope.msg_type,
        subject=f"[workspace-scoped {schema}]" if explicit_transfer and schema else "[scope-redacted]",
        priority=envelope.priority,
        audience_scope=envelope.audience_scope,
        visibility_mode=envelope.visibility_mode,
        memory_mode=envelope.memory_mode,
        content_type=envelope.content_type,
        version=envelope.version,
        id=envelope.id,
        body=None,
        payload=_sanitize_explicit_payload(envelope.payload) if explicit_transfer else None,
        trust=envelope.trust,
        summary=envelope.summary,
        authority=envelope.authority,
        authority_proof=envelope.authority_proof,
        policy_hint=envelope.policy_hint,
        context_id=envelope.context_id,
        reply_to=envelope.reply_to,
        trace_id=envelope.trace_id,
        ttl_seconds=envelope.ttl_seconds,
        idempotency_key=envelope.idempotency_key,
        metadata=metadata,
        ephemeral=envelope.ephemeral,
        created_at=envelope.created_at,
    )
    return sanitized_envelope, WorkspaceDeliveryRedaction(
        workspace_id=workspace_id,
        schema=schema,
        redaction_mode=redaction_mode,
    )


def sanitize_message_record_for_workspace_recipient(
    db,
    message: dict[str, Any],
    recipient: str,
) -> tuple[dict[str, Any], WorkspaceDeliveryRedaction | None]:
    payload = _load_jsonish(message.get("payload"))
    metadata = _load_jsonish(message.get("metadata"))
    envelope = Envelope(
        sender=message.get("from_agent") or message.get("sender") or "",
        recipient=message.get("to_agent") or message.get("recipient") or recipient,
        msg_type=message.get("msg_type") or "inform",
        subject=message.get("subject") or "",
        priority=message.get("priority") or "routine",
        audience_scope=message.get("audience_scope"),
        visibility_mode=message.get("visibility_mode") or "normal",
        memory_mode=message.get("memory_mode") or "thread",
        content_type=message.get("content_type") or "text/plain",
        version=message.get("version") or "1.0",
        id=message.get("uuid") or message.get("id") or "",
        body=message.get("body"),
        payload=payload,
        context_id=message.get("context_id"),
        reply_to=message.get("reply_to"),
        trace_id=message.get("trace_id"),
        ttl_seconds=message.get("ttl_seconds"),
        idempotency_key=message.get("idempotency_key"),
        metadata=metadata,
        created_at=message.get("created_at"),
    )
    sanitized_envelope, redaction = sanitize_envelope_for_workspace_recipient(
        db,
        envelope,
        recipient,
    )
    if redaction is None:
        return message, None

    sanitized_message = dict(message)
    sanitized_message["subject"] = sanitized_envelope.subject
    sanitized_message["body"] = sanitized_envelope.body
    sanitized_message["payload"] = sanitized_envelope.payload
    sanitized_message["metadata"] = sanitized_envelope.metadata
    return sanitized_message, redaction
