from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import urlencode

from .envelope import VALID_CONSEQUENCE_SCOPES


PARTICIPANT_PROFILE_DEFINITIONS = {
    "approval_surface": {
        "participant_class": "thin",
        "summary": "Receives approval requests and returns approve, reject, defer, or ack.",
    },
    "status_source": {
        "participant_class": "gatewayed",
        "summary": "Emits state, event, and context updates into Whispers.",
    },
    "human_contact": {
        "participant_class": "thin",
        "summary": "Represents a human-facing contact surface without a full native install.",
    },
    "action_target": {
        "participant_class": "gatewayed",
        "summary": "Receives bounded actions through a bridge or automation path.",
    },
    "sensor": {
        "participant_class": "gatewayed",
        "summary": "Emits observations but does not act.",
    },
    "bridge_gateway": {
        "participant_class": "gatewayed",
        "summary": "Translates another system into Whispers.",
    },
}
PARTICIPANT_PROFILE_NAMES = tuple(PARTICIPANT_PROFILE_DEFINITIONS.keys())
PARTICIPANT_PROFILE_TAGS = frozenset(PARTICIPANT_PROFILE_NAMES)
PARTICIPANT_ARTIFACT_NAMES = (
    "payload",
    "curl",
    "powershell",
    "python",
    "browser_pairing_url",
    "ios_shortcut_recipe",
    "home_assistant_automation",
)
PARTICIPANT_ARTIFACT_FIELDS = frozenset(PARTICIPANT_ARTIFACT_NAMES)
PARTICIPANT_STARTER_ARTIFACT_NAMES = tuple(
    name for name in PARTICIPANT_ARTIFACT_NAMES
    if name != "payload"
)
PARTICIPANT_STARTER_ARTIFACT_FIELDS = frozenset(PARTICIPANT_STARTER_ARTIFACT_NAMES)


def _decode_jsonish_list(raw_value: Any) -> list[Any]:
    if raw_value is None:
        return []
    if isinstance(raw_value, list):
        return [item for item in raw_value if item is not None]
    if isinstance(raw_value, tuple):
        return [item for item in raw_value if item is not None]
    if isinstance(raw_value, set):
        return [item for item in raw_value if item is not None]
    if isinstance(raw_value, str):
        stripped = raw_value.strip()
        if not stripped:
            return []
        if stripped.startswith("["):
            try:
                parsed = json.loads(stripped)
            except json.JSONDecodeError:
                parsed = None
            if isinstance(parsed, list):
                return [item for item in parsed if item is not None]
        return [item.strip() for item in stripped.split(",") if item.strip()]
    return [raw_value]


def normalize_participant_profiles(raw_profiles: Any) -> list[str]:
    normalized: list[str] = []
    seen = set()
    for item in _decode_jsonish_list(raw_profiles):
        text = str(item or "").strip().lower()
        if not text:
            continue
        if text.startswith("profile:"):
            text = text.split(":", 1)[1].strip()
        if text not in PARTICIPANT_PROFILE_TAGS or text in seen:
            continue
        seen.add(text)
        normalized.append(text)
    return normalized


def participant_class_for_profiles(raw_profiles: Any) -> str:
    profiles = normalize_participant_profiles(raw_profiles)
    if any(
        PARTICIPANT_PROFILE_DEFINITIONS[name]["participant_class"] == "thin"
        for name in profiles
    ):
        return "thin"
    return "gatewayed"


def participant_profile_summaries(raw_profiles: Any) -> list[str]:
    profiles = normalize_participant_profiles(raw_profiles)
    return [
        PARTICIPANT_PROFILE_DEFINITIONS[name]["summary"]
        for name in profiles
        if name in PARTICIPANT_PROFILE_DEFINITIONS
    ]


def participant_recommended_path(raw_profiles: Any) -> str:
    profiles = normalize_participant_profiles(raw_profiles)
    if "approval_surface" in profiles or "human_contact" in profiles:
        return "pairing link, browser pane, or phone Shortcut"
    if "action_target" in profiles:
        return "local automation, daemon, or Home Assistant bridge"
    if "sensor" in profiles or "status_source" in profiles:
        return "webhook, script emitter, or lightweight local watcher"
    if "bridge_gateway" in profiles:
        return "gateway daemon or bridge service"
    return "webhook or script bridge"


def participant_comfort_hint(raw_profiles: Any) -> str:
    participant_class = participant_class_for_profiles(raw_profiles)
    if participant_class == "thin":
        return "Start with the easiest human-facing surface first; do not force a full install."
    return "Start with the smallest bridge artifact that can prove arrival into Whispers."


def participant_starter_artifact(raw_profiles: Any) -> str:
    profiles = normalize_participant_profiles(raw_profiles)
    if "approval_surface" in profiles or "human_contact" in profiles:
        return "ios_shortcut_recipe"
    if "bridge_gateway" in profiles:
        return "python"
    return "curl"


def resolve_participant_starter_artifact(
    raw_profiles: Any,
    starter_artifact: str | None = None,
    *,
    available_artifacts: list[str] | tuple[str, ...] | set[str] | None = None,
) -> str:
    fallback = participant_starter_artifact(raw_profiles)
    requested = str(starter_artifact or "").strip()
    if not requested:
        return fallback
    if requested not in PARTICIPANT_STARTER_ARTIFACT_FIELDS:
        raise ValueError(
            "Unknown starter artifact requested: "
            f"{requested}. Valid starter artifacts: {', '.join(PARTICIPANT_STARTER_ARTIFACT_NAMES)}"
        )
    if available_artifacts and requested not in available_artifacts:
        raise ValueError(
            f"Starter artifact '{requested}' is unavailable for this participant. "
            f"Available starter artifacts: {', '.join(item for item in available_artifacts if item in PARTICIPANT_STARTER_ARTIFACT_FIELDS)}"
        )
    return requested


def participant_setup_steps(raw_profiles: Any, *, endpoint: str, starter_artifact: str) -> list[str]:
    profiles = normalize_participant_profiles(raw_profiles)
    participant_class = participant_class_for_profiles(profiles)
    if participant_class == "thin":
        starter_label = {
            "ios_shortcut_recipe": "iOS Shortcut recipe",
            "browser_pairing_url": "browser pairing URL",
            "powershell": "PowerShell script",
            "python": "Python bridge script",
            "curl": "curl command",
        }.get(starter_artifact, starter_artifact.replace("_", " "))
        if starter_artifact == "browser_pairing_url":
            first_step = "Open the generated browser pairing URL on the device that should participate."
        else:
            first_step = f"Use the generated {starter_label} to POST to {endpoint}, or open the browser pairing URL if that is more comfortable."
        return [
            first_step,
            "Keep the participant callsign, display name, and profile tags stable so browser, shortcut, and follow-on replies all refer to the same participant.",
            "Run it once, then use `whispers participant-plan --probe --verify` to confirm the participant appears in Whispers as a thin participant.",
        ]
    starter_label = {
        "curl": "curl or another tiny shell webhook sender",
        "python": "tiny Python watcher or bridge script",
        "powershell": "PowerShell bridge",
    }.get(starter_artifact, starter_artifact)
    return [
        f"Start with {starter_label} and post the generated payload to {endpoint}.",
        "Keep the participant callsign stable and reuse the generated JSON shape; only vary the event-specific fields you actually need.",
        "Fire one real or test event, then use `whispers participant-plan --probe --verify` to confirm arrival before you build a richer bridge.",
    ]


def participant_path_limitations(raw_profiles: Any) -> list[str]:
    participant_class = participant_class_for_profiles(raw_profiles)
    if participant_class == "thin":
        return [
            "Third-party browser origins are not allowed to POST directly to /signal; use the generated same-origin browser pairing URL or a phone Shortcut."
        ]
    return []


def participant_profile_tags(raw_profiles: Any) -> list[str]:
    return [f"profile:{name}" for name in normalize_participant_profiles(raw_profiles)]


def participant_entrypoint_tag_for_artifact(
    starter_artifact: str | None,
    *,
    participant_profiles: Any = None,
) -> str:
    artifact = str(starter_artifact or "").strip()
    if not artifact:
        artifact = participant_starter_artifact(participant_profiles)
    return {
        "browser_pairing_url": "entrypoint:browser",
        "ios_shortcut_recipe": "entrypoint:shortcut",
        "home_assistant_automation": "entrypoint:home_assistant",
        "powershell": "entrypoint:powershell",
        "python": "entrypoint:python",
    }.get(artifact, "entrypoint:signal")


def normalize_participant_artifacts(raw_artifacts: Any) -> list[str]:
    normalized: list[str] = []
    seen = set()
    unknown: list[str] = []
    for item in _decode_jsonish_list(raw_artifacts):
        text = str(item or "").strip()
        if not text or text in seen:
            continue
        if text not in PARTICIPANT_ARTIFACT_FIELDS:
            unknown.append(text)
            continue
        seen.add(text)
        normalized.append(text)
    if unknown:
        raise ValueError(
            "Unknown participant artifacts requested: "
            + ", ".join(unknown)
            + ". Valid artifacts: "
            + ", ".join(PARTICIPANT_ARTIFACT_NAMES)
        )
    return normalized


def available_participant_artifacts(kit: dict[str, Any]) -> set[str]:
    return {
        name
        for name in PARTICIPANT_ARTIFACT_NAMES
        if name == "payload" or kit.get(name) is not None
    }


def ordered_available_participant_artifacts(kit: dict[str, Any]) -> list[str]:
    available = available_participant_artifacts(kit)
    return [name for name in PARTICIPANT_ARTIFACT_NAMES if name in available]


def filter_participant_kit(kit: dict[str, Any], raw_artifacts: Any) -> dict[str, Any]:
    artifacts = normalize_participant_artifacts(raw_artifacts)
    if not artifacts:
        return dict(kit)
    missing = [name for name in artifacts if name not in available_participant_artifacts(kit)]
    if missing:
        raise ValueError(
            "Requested participant artifacts unavailable for this participant: "
            + ", ".join(missing)
        )
    filtered = {
        key: value
        for key, value in kit.items()
        if key not in PARTICIPANT_ARTIFACT_FIELDS or key in artifacts
    }
    payload = kit.get("payload") if isinstance(kit.get("payload"), dict) else {}
    if "payload" not in filtered:
        filtered["participant_sender"] = payload.get("from")
        filtered["participant_recipient"] = payload.get("to")
    filtered["artifacts_requested"] = list(artifacts)
    return filtered


def merge_participant_tags(existing_tags: Any, raw_profiles: Any, extra_tags: Any = None) -> list[str]:
    merged: list[str] = []
    seen = set()
    for item in _decode_jsonish_list(existing_tags):
        text = str(item or "").strip()
        if not text:
            continue
        lowered = text.lower()
        if lowered in seen:
            continue
        seen.add(lowered)
        merged.append(text)
    for tag in participant_profile_tags(raw_profiles):
        if tag in seen:
            continue
        seen.add(tag)
        merged.append(tag)
    for item in _decode_jsonish_list(extra_tags):
        text = str(item or "").strip()
        if not text:
            continue
        lowered = text.lower()
        if lowered in seen:
            continue
        seen.add(lowered)
        merged.append(text)
    return merged


def prepare_signal_participant_card(
    registry: Any,
    sender: str,
    *,
    display_name: str | None = None,
    participant_profiles: Any = None,
    starter_artifact: str | None = None,
) -> dict[str, Any]:
    callsign = str(sender or "").strip()
    if not callsign:
        raise ValueError("Missing participant sender")
    existing = registry.get_agent_by_callsign(callsign)
    if existing and str(existing.get("agent_type") or "").strip().lower() != "ephemeral":
        raise ValueError(
            f"Participant callsign '{callsign}' already belongs to a non-ephemeral participant."
        )
    resolved_artifact = resolve_participant_starter_artifact(
        participant_profiles,
        starter_artifact,
    )
    entrypoint_tag = participant_entrypoint_tag_for_artifact(
        resolved_artifact,
        participant_profiles=participant_profiles,
    )
    tags = merge_participant_tags(
        existing.get("tags") if isinstance(existing, dict) else None,
        participant_profiles,
        extra_tags=[entrypoint_tag],
    )
    registry.register(
        callsign,
        agent_type="ephemeral",
        display_name=display_name,
        tags=tags,
    )
    record = registry.get_agent_by_callsign(callsign) or {
        "callsign": callsign,
        "agent_type": "ephemeral",
        "display_name": display_name,
        "tags": tags,
    }
    prepared = dict(record)
    prepared["starter_artifact"] = resolved_artifact
    prepared["entrypoint_tag"] = entrypoint_tag
    return prepared


def build_signal_participant_payload(
    *,
    sender: str,
    recipient: str,
    subject: str,
    body: str | None = None,
    display_name: str | None = None,
    participant_profiles: Any = None,
    basis: str = "declared",
    consequence_scope: str | None = None,
    origin: str | None = None,
    subject_of: str | None = None,
    principal: str | None = None,
    action_class: str | None = None,
    severity: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "from": sender,
        "to": recipient,
        "subject": subject,
        "basis": basis,
    }
    if body:
        payload["body"] = body
    if display_name:
        payload["display_name"] = display_name
    profiles = normalize_participant_profiles(participant_profiles)
    if profiles:
        payload["participant_profiles"] = profiles
    if consequence_scope:
        if consequence_scope not in VALID_CONSEQUENCE_SCOPES:
            raise ValueError(
                f"Invalid consequence_scope: '{consequence_scope}'. Valid: {sorted(VALID_CONSEQUENCE_SCOPES)}"
            )
        payload["consequence_scope"] = consequence_scope
    if origin:
        payload["origin"] = origin
    if subject_of:
        payload["subject_of"] = subject_of
    if principal:
        payload["principal"] = principal
    if action_class:
        payload["action_class"] = action_class
    if severity:
        payload["severity"] = severity
    return payload


def render_signal_powershell(endpoint: str, payload: dict[str, Any]) -> str:
    body = json.dumps(payload, indent=2)
    return (
        "$body = @'\n"
        f"{body}\n"
        "'@\n"
        f"Invoke-RestMethod -Method Post -Uri '{endpoint}' "
        "-ContentType 'application/json' -Body $body"
    )


def render_signal_curl(endpoint: str, payload: dict[str, Any]) -> str:
    body = json.dumps(payload, indent=2)
    return (
        f"curl -X POST '{endpoint}' \\\n"
        "  -H 'Content-Type: application/json' \\\n"
        "  --data-binary @- <<'JSON'\n"
        f"{body}\n"
        "JSON"
    )


def render_signal_python(endpoint: str, payload: dict[str, Any]) -> str:
    body = json.dumps(payload, indent=2)
    return (
        "import json\n"
        "import urllib.request\n\n"
        f"payload = {body}\n"
        "request = urllib.request.Request(\n"
        f"    '{endpoint}',\n"
        "    data=json.dumps(payload).encode('utf-8'),\n"
        "    headers={'Content-Type': 'application/json'},\n"
        "    method='POST',\n"
        ")\n"
        "with urllib.request.urlopen(request, timeout=10) as response:\n"
        "    print(response.read().decode('utf-8'))"
    )


def build_browser_pairing_url(server: str, payload: dict[str, Any]) -> str:
    base = f"{server.rstrip('/')}/signal/browser"
    query: list[tuple[str, str]] = []
    for key in (
        "from",
        "to",
        "subject",
        "body",
        "display_name",
        "basis",
        "consequence_scope",
        "origin",
        "subject_of",
        "principal",
        "action_class",
        "severity",
    ):
        value = payload.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if not text:
            continue
        query.append((key, text))
    for profile in normalize_participant_profiles(payload.get("participant_profiles")):
        query.append(("participant_profiles", profile))
    encoded = urlencode(query)
    if not encoded:
        return base
    return f"{base}?{encoded}"


def build_ios_shortcut_recipe(
    endpoint: str,
    payload: dict[str, Any],
    *,
    participant_class: str,
    participant_profiles: list[str],
) -> dict[str, Any]:
    sender_label = str(payload.get("display_name") or payload.get("from") or "Whispers Participant").strip()
    return {
        "title": f"{sender_label} -> Whispers",
        "app": "Apple Shortcuts",
        "method": "POST",
        "url": endpoint,
        "headers": {"Content-Type": "application/json"},
        "json_body": payload,
        "participant_class": participant_class,
        "participant_profiles": participant_profiles,
        "steps": [
            "Create a new shortcut.",
            "Add a Get Contents of URL action configured for POST.",
            "Set the URL, Content-Type header, and JSON body from this recipe.",
            "Run the shortcut once to register or refresh the participant in Whispers.",
        ],
    }


def render_home_assistant_automation(endpoint: str, payload: dict[str, Any]) -> str:
    callsign = str(payload.get("from") or "whispers-bridge").strip() or "whispers-bridge"
    service_name = re.sub(r"[^a-z0-9_]+", "_", callsign.lower()).strip("_") or "whispers_signal"
    body = json.dumps(payload, indent=2)
    body_block = "\n".join(f"      {line}" for line in body.splitlines())
    return (
        "rest_command:\n"
        f"  whispers_signal_{service_name}:\n"
        f"    url: '{endpoint}'\n"
        "    method: POST\n"
        "    content_type: application/json\n"
        "    payload: >\n"
        f"{body_block}\n\n"
        "automation:\n"
        f"  - alias: 'Send {callsign} to Whispers'\n"
        "    trigger:\n"
        "      - platform: state\n"
        "        entity_id: sensor.replace_me\n"
        "    action:\n"
        f"      - service: rest_command.whispers_signal_{service_name}\n"
        "    mode: queued"
    )


def build_signal_participant_kit(
    *,
    server: str,
    sender: str,
    recipient: str,
    subject: str,
    body: str | None = None,
    display_name: str | None = None,
    participant_profiles: Any = None,
    basis: str = "declared",
    consequence_scope: str | None = None,
    origin: str | None = None,
    subject_of: str | None = None,
    principal: str | None = None,
    action_class: str | None = None,
    severity: str | None = None,
    starter_artifact: str | None = None,
) -> dict[str, Any]:
    endpoint = f"{server.rstrip('/')}/signal"
    payload = build_signal_participant_payload(
        sender=sender,
        recipient=recipient,
        subject=subject,
        body=body,
        display_name=display_name,
        participant_profiles=participant_profiles,
        basis=basis,
        consequence_scope=consequence_scope,
        origin=origin,
        subject_of=subject_of,
        principal=principal,
        action_class=action_class,
        severity=severity,
    )
    profiles = normalize_participant_profiles(participant_profiles)
    participant_class = participant_class_for_profiles(profiles)
    browser_pairing_url = build_browser_pairing_url(server, payload)
    result = {
        "endpoint": endpoint,
        "path": "/signal",
        "arrival_mode": "unauthenticated_border_router",
        "participant_class": participant_class,
        "participant_profiles": profiles,
        "profile_summaries": participant_profile_summaries(profiles),
        "recommended_path": participant_recommended_path(profiles),
        "comfort_hint": participant_comfort_hint(profiles),
        "payload": payload,
        "curl": render_signal_curl(endpoint, payload),
        "powershell": render_signal_powershell(endpoint, payload),
        "python": render_signal_python(endpoint, payload),
    }
    if participant_class == "thin":
        result["browser_pairing_url"] = browser_pairing_url
        result["ios_shortcut_recipe"] = build_ios_shortcut_recipe(
            endpoint,
            payload,
            participant_class=participant_class,
            participant_profiles=profiles,
        )
    if any(profile in profiles for profile in ("status_source", "action_target", "sensor")):
        result["home_assistant_automation"] = render_home_assistant_automation(endpoint, payload)
    available_artifacts = ordered_available_participant_artifacts(result)
    result["available_artifacts"] = available_artifacts
    resolved_starter_artifact = resolve_participant_starter_artifact(
        profiles,
        starter_artifact,
        available_artifacts=available_artifacts,
    )
    result["starter_artifact"] = resolved_starter_artifact
    result["setup_steps"] = participant_setup_steps(
        profiles,
        endpoint=endpoint,
        starter_artifact=resolved_starter_artifact,
    )
    path_limitations = participant_path_limitations(profiles)
    if path_limitations:
        result["path_limitations"] = path_limitations
    return result
