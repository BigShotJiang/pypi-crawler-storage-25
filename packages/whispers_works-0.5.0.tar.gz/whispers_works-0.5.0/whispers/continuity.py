from __future__ import annotations

import getpass
import hashlib
import json
import os
import socket
from dataclasses import asdict, dataclass
from typing import Any, Optional

from .identity import friendly_callsign_candidates, validate_human_callsign, validate_remote_callsign
from .registry import AgentRegistry
from .storage.db import WhispersDB, WhispersDBError
from .trust import TrustService


class ContinuityConflictError(WhispersDBError):
    def __init__(self, message: str, *, outcome: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.outcome = outcome
        self.details = details or {}


@dataclass(frozen=True)
class ContinuityResolution:
    outcome: str
    agent_id: str
    stable_subject_id: str
    callsign: str
    continuity_anchor: str
    requested_callsign: str
    platform_family: str
    owner_id: str | None = None
    context_hint: str | None = None
    reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ContinuityService:
    """Canonical identity continuity / rebind service.

    Stable identity is separated from ephemeral session. Callsigns are the
    addressable presentation. Continuity anchors explain when a reconnecting
    presentation is the same participant and when it is a sibling or a conflict.
    """

    def __init__(self, db: WhispersDB, registry: AgentRegistry | None = None, trust: TrustService | None = None):
        self.db = db
        self.registry = registry or AgentRegistry(db)
        self.trust = trust or TrustService(db)
        # T4.25 — rename observers. Callbacks fire after a successful
        # rename_presentation commit. Used by PollenService to drive
        # the ONE-path reissue ceremony.
        self._rename_listeners: list = []

    def add_rename_listener(self, callback) -> None:
        """Register a callback to fire after a rename commits.

        Callback signature: (old_callsign: str, new_callsign: str, reason: str | None) -> None
        Exceptions are logged but don't fail the rename — listeners are
        informational-layer.
        """
        self._rename_listeners.append(callback)

    def _emit_rename(
        self,
        old_callsign: str,
        new_callsign: str,
        reason: str | None,
    ) -> None:
        import logging
        _log = logging.getLogger(__name__)
        for cb in list(self._rename_listeners):
            try:
                cb(old_callsign, new_callsign, reason)
            except Exception as exc:
                _log.warning("rename_listener raised: %s", exc)

    def _owner_identity_key(self, owner_id: str | None) -> str:
        if owner_id and str(owner_id).strip():
            return str(owner_id).strip()
        env_owner = str(os.getenv("WHISPERS_CONTINUITY_USER_ID") or "").strip()
        if env_owner:
            return env_owner
        try:
            resolved = str(getpass.getuser() or "").strip()
            if resolved:
                return resolved
        except Exception:
            pass
        return "local-user"

    def _host_identity_key(self) -> str:
        env_host = str(os.getenv("WHISPERS_CONTINUITY_HOST_ID") or "").strip()
        if env_host:
            return env_host
        try:
            resolved = str(socket.gethostname() or "").strip()
            if resolved:
                return resolved
        except Exception:
            pass
        return "local-host"

    def derive_continuity_anchor(
        self,
        *,
        requested_callsign: str,
        platform_family: str,
        owner_id: str | None = None,
        context_hint: str | None = None,
        explicit_anchor: str | None = None,
        sibling_label: str | None = None,
    ) -> str:
        """Derive a stable continuity anchor for a (host, owner, callsign) tuple.

        Slice 9: platform_family is intentionally NOT an input — it's a
        "how", not a "who". A participant is identified by their host,
        their operator, their public callsign, and optionally a sibling
        label for legitimate parallel presentations. Same agent binding
        via claude-code one day and codex another is the SAME
        participant and MUST get the same anchor; prior behavior
        (platform in hash) caused a collision flood that Slice 6's
        envelope merely papered over.
        """
        del context_hint, platform_family
        if explicit_anchor:
            return str(explicit_anchor).strip()
        material_parts = [
            self._host_identity_key(),
            self._owner_identity_key(owner_id),
            str(requested_callsign or "").strip() or requested_callsign,
        ]
        normalized_sibling = str(sibling_label or "").strip().lower()
        if normalized_sibling:
            material_parts.append(f"sibling:{normalized_sibling}")
        digest = hashlib.sha256("|".join(material_parts).encode("utf-8")).hexdigest()[:24]
        return f"anchor:{digest}"

    def _normalize_platform_family(self, platform_family: str | None, agent_type: str) -> str:
        return str(platform_family or agent_type or "script").strip() or "script"

    def _active_sessions_for_agent(self, conn, agent_id: str) -> int:
        row = conn.execute(
            """
            SELECT COUNT(*) AS c
            FROM agent_sessions
            WHERE agent_id = ?
              AND lease_expires_at >= CURRENT_TIMESTAMP
            """,
            (agent_id,),
        ).fetchone()
        return int(row["c"] if row else 0)

    def _cards_for_anchor(self, conn, continuity_anchor: str) -> list[dict[str, Any]]:
        rows = conn.execute(
            "SELECT * FROM agent_cards WHERE continuity_anchor = ? AND deregistered_at IS NULL ORDER BY registered_at ASC",
            (continuity_anchor,),
        ).fetchall()
        return [dict(row) for row in rows]

    def _card_for_callsign(self, conn, callsign: str) -> dict[str, Any] | None:
        row = conn.execute(
            "SELECT * FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
            (callsign,),
        ).fetchone()
        return dict(row) if row else None

    def _validate_public_callsign(self, callsign: str) -> str:
        normalized = str(callsign or "").strip().lower()
        human_error = validate_human_callsign(normalized, allow_internal=True)
        if human_error is None:
            return normalized
        fallback_error = validate_remote_callsign(normalized, allow_internal=True)
        if fallback_error is None:
            return normalized
        raise ContinuityConflictError(human_error, outcome="rejected", details={"requested_callsign": normalized})

    def _validate_human_public_callsign(self, callsign: str) -> str:
        normalized = str(callsign or "").strip().lower()
        error = validate_human_callsign(normalized, allow_internal=True)
        if error:
            raise ContinuityConflictError(error, outcome="rejected", details={"requested_callsign": normalized})
        return normalized

    def _allocate_sibling_callsign(
        self,
        conn,
        *,
        requested_callsign: str,
        context_hint: str | None,
        sibling_label: str | None,
        continuity_anchor: str,
    ) -> str:
        seed_material = "|".join(
            [
                requested_callsign,
                str(context_hint or ""),
                str(sibling_label or ""),
                continuity_anchor,
            ]
        )
        for candidate in friendly_callsign_candidates(seed_material):
            if candidate == requested_callsign:
                continue
            if self._card_for_callsign(conn, candidate):
                continue
            ledger = self.db.get_callsign_ledger_entry(candidate, conn=conn)
            if ledger and str(ledger.get("stable_subject_id")) not in {"", None}:
                continue
            return candidate
        raise ContinuityConflictError(
            f"Unable to allocate a human-friendly sibling presentation for {requested_callsign}.",
            outcome="manual_resolution_required",
            details={"requested_callsign": requested_callsign},
        )

    def _apply_identity_fields(
        self,
        conn,
        *,
        agent_id: str,
        continuity_anchor: str,
        platform_family: str,
        owner_id: str | None,
        participant_kind: str,
        participant_shape: str,
        agency_relation: str | None,
        boundary_provenance: str | None,
        recognition_basis: str | None,
        reachability_mode: str | None,
        interaction_asks_json: str | None,
        capability_claims_json: str | None,
        composition_hints_json: str | None,
    ) -> dict[str, Any]:
        conn.execute(
            """
            UPDATE agent_cards
            SET stable_subject_id = COALESCE(stable_subject_id, agent_id),
                continuity_anchor = ?,
                platform_family = ?,
                owner_id = COALESCE(?, owner_id),
                participant_kind = COALESCE(?, participant_kind),
                participant_shape = COALESCE(?, participant_shape),
                agency_relation = COALESCE(?, agency_relation),
                boundary_provenance = COALESCE(?, boundary_provenance),
                recognition_basis = COALESCE(?, recognition_basis),
                reachability_mode = COALESCE(?, reachability_mode),
                interaction_asks = COALESCE(?, interaction_asks),
                capability_claims = COALESCE(?, capability_claims),
                composition_hints = COALESCE(?, composition_hints)
            WHERE agent_id = ?
            """,
            (
                continuity_anchor,
                platform_family,
                owner_id,
                participant_kind,
                participant_shape,
                agency_relation,
                boundary_provenance,
                recognition_basis,
                reachability_mode,
                interaction_asks_json,
                capability_claims_json,
                composition_hints_json,
                agent_id,
            ),
        )
        row = conn.execute(
            "SELECT * FROM agent_cards WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()
        card = dict(row) if row else {}
        stable_subject_id = str(card.get("stable_subject_id") or agent_id)
        if card.get("callsign"):
            self.db.bind_callsign_ledger(
                callsign=str(card["callsign"]),
                stable_subject_id=stable_subject_id,
                agent_id=agent_id,
                conn=conn,
            )
        self.trust.sync_subject(stable_subject_id, conn=conn)
        row = conn.execute(
            "SELECT * FROM agent_cards WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()
        return dict(row) if row else card

    def _record_event(
        self,
        *,
        event_type: str,
        outcome: str,
        agent_id: str | None,
        callsign: str,
        continuity_anchor: str,
        details: dict[str, Any],
    ) -> None:
        self.db.record_identity_event(
            event_type=event_type,
            outcome=outcome,
            agent_id=agent_id,
            callsign=callsign,
            continuity_anchor=continuity_anchor,
            details=details,
        )

    def connect(
        self,
        *,
        requested_callsign: str,
        agent_type: str = "script",
        model_id: str | None = None,
        display_name: str | None = None,
        owner_id: str | None = None,
        platform_family: str | None = None,
        context_hint: str | None = None,
        continuity_anchor: str | None = None,
        allow_sibling: bool = False,
        sibling_label: str | None = None,
        participant_kind: str = "primary_agent",
        participant_shape: str = "atomic",
        agency_relation: str | None = None,
        boundary_provenance: str | None = None,
        recognition_basis: str | None = None,
        reachability_mode: str | None = None,
        interaction_asks_json: str | None = None,
        capability_claims_json: str | None = None,
        composition_hints_json: str | None = None,
    ) -> ContinuityResolution:
        requested_callsign = self._validate_public_callsign(requested_callsign)
        if not requested_callsign:
            raise ValueError("requested_callsign is required")
        platform_family = self._normalize_platform_family(platform_family, agent_type)
        continuity_anchor = self.derive_continuity_anchor(
            requested_callsign=requested_callsign,
            platform_family=platform_family,
            owner_id=owner_id,
            context_hint=context_hint,
            explicit_anchor=continuity_anchor,
            sibling_label=sibling_label,
        )

        with self.db.get_connection() as conn:
            existing = self._card_for_callsign(conn, requested_callsign)
            if existing:
                if existing.get("continuity_anchor") == continuity_anchor:
                    agent_id = self.registry.register(
                        requested_callsign,
                        agent_type=agent_type,
                        model_id=model_id,
                        display_name=display_name,
                        owner_id=owner_id,
                    )
                    updated = self._apply_identity_fields(
                        conn,
                        agent_id=agent_id,
                        continuity_anchor=continuity_anchor,
                        platform_family=platform_family,
                        owner_id=owner_id,
                        participant_kind=participant_kind,
                        participant_shape=participant_shape,
                        agency_relation=agency_relation,
                        boundary_provenance=boundary_provenance,
                        recognition_basis=recognition_basis,
                        reachability_mode=reachability_mode,
                        interaction_asks_json=interaction_asks_json,
                        capability_claims_json=capability_claims_json,
                        composition_hints_json=composition_hints_json,
                    )
                    conn.commit()
                    resolution = ContinuityResolution(
                        outcome="rebind_accepted",
                        agent_id=agent_id,
                        stable_subject_id=str(updated.get("stable_subject_id") or agent_id),
                        callsign=requested_callsign,
                        continuity_anchor=continuity_anchor,
                        requested_callsign=requested_callsign,
                        platform_family=platform_family,
                        owner_id=owner_id,
                        context_hint=context_hint,
                    )
                    self._record_event(
                        event_type="continuity_connect",
                        outcome=resolution.outcome,
                        agent_id=agent_id,
                        callsign=requested_callsign,
                        continuity_anchor=continuity_anchor,
                        details=resolution.to_dict(),
                    )
                    return resolution

                if sibling_label:
                    allocated_callsign = self._allocate_sibling_callsign(
                        conn,
                        requested_callsign=requested_callsign,
                        context_hint=context_hint,
                        sibling_label=sibling_label,
                        continuity_anchor=continuity_anchor,
                    )
                    agent_id = self.registry.register(
                        allocated_callsign,
                        agent_type=agent_type,
                        model_id=model_id,
                        display_name=display_name,
                        owner_id=owner_id,
                    )
                    updated = self._apply_identity_fields(
                        conn,
                        agent_id=agent_id,
                        continuity_anchor=continuity_anchor,
                        platform_family=platform_family,
                        owner_id=owner_id,
                        participant_kind=participant_kind,
                        participant_shape=participant_shape,
                        agency_relation=agency_relation,
                        boundary_provenance=boundary_provenance,
                        recognition_basis=recognition_basis,
                        reachability_mode=reachability_mode,
                        interaction_asks_json=interaction_asks_json,
                        capability_claims_json=capability_claims_json,
                        composition_hints_json=composition_hints_json,
                    )
                    conn.commit()
                    resolution = ContinuityResolution(
                        outcome="sibling_instance_allocated",
                        agent_id=agent_id,
                        stable_subject_id=str(updated.get("stable_subject_id") or agent_id),
                        callsign=allocated_callsign,
                        continuity_anchor=continuity_anchor,
                        requested_callsign=requested_callsign,
                        platform_family=platform_family,
                        owner_id=owner_id,
                        context_hint=context_hint,
                        reason=f"{requested_callsign} is already bound to another continuity anchor.",
                    )
                    # Slice 9: sibling is a new peer — emit peer_bound.
                    try:
                        from .delta_stream import emit_peer_bound, get_delta_broker
                        emit_peer_bound(get_delta_broker(), {
                            "callsign": allocated_callsign,
                            "agent_id": agent_id,
                            "stable_subject_id": str(updated.get("stable_subject_id") or agent_id),
                            "trust_tier": updated.get("trust_tier"),
                            "continuity_anchor": continuity_anchor,
                            "platform_family": platform_family,
                            "registered_at": updated.get("registered_at"),
                        })
                    except Exception:
                        pass
                    self._record_event(
                        event_type="continuity_connect",
                        outcome=resolution.outcome,
                        agent_id=agent_id,
                        callsign=allocated_callsign,
                        continuity_anchor=continuity_anchor,
                        details=resolution.to_dict(),
                    )
                    return resolution

                details = {
                    "requested_callsign": requested_callsign,
                    "existing_agent_id": existing.get("agent_id"),
                    "existing_continuity_anchor": existing.get("continuity_anchor"),
                    "requested_continuity_anchor": continuity_anchor,
                    "owner_id": owner_id,
                    "platform_family": platform_family,
                    "context_hint": context_hint,
                }
                self._record_event(
                    event_type="continuity_connect",
                    outcome="manual_resolution_required",
                    agent_id=str(existing.get("agent_id")) if existing.get("agent_id") else None,
                    callsign=requested_callsign,
                    continuity_anchor=continuity_anchor,
                    details=details,
                )
                raise ContinuityConflictError(
                    f"Callsign {requested_callsign!r} is already bound to a different continuity anchor.",
                    outcome="manual_resolution_required",
                    details=details,
                )

            reserved = self.db.get_callsign_ledger_entry(requested_callsign, conn=conn)
            anchored = self._cards_for_anchor(conn, continuity_anchor)
            anchored_subjects = {
                str(card.get("stable_subject_id") or card.get("agent_id"))
                for card in anchored
                if card.get("stable_subject_id") or card.get("agent_id")
            }
            if reserved and str(reserved.get("stable_subject_id")) not in anchored_subjects:
                details = {
                    "requested_callsign": requested_callsign,
                    "reserved_stable_subject_id": reserved.get("stable_subject_id"),
                    "reserved_successor_callsign": reserved.get("successor_callsign"),
                    "continuity_anchor": continuity_anchor,
                }
                self._record_event(
                    event_type="continuity_connect",
                    outcome="manual_resolution_required",
                    agent_id=str(reserved.get("agent_id")) if reserved.get("agent_id") else None,
                    callsign=requested_callsign,
                    continuity_anchor=continuity_anchor,
                    details=details,
                )
                raise ContinuityConflictError(
                    f"Callsign {requested_callsign!r} is reserved by another participant history.",
                    outcome="manual_resolution_required",
                    details=details,
                )
            if anchored:
                active_bound = [card for card in anchored if self._active_sessions_for_agent(conn, str(card["agent_id"])) > 0]
                details = {
                    "requested_callsign": requested_callsign,
                    "continuity_anchor": continuity_anchor,
                    "anchored_presentations": [card.get("callsign") for card in anchored],
                    "active_presentations": [card.get("callsign") for card in active_bound],
                }
                outcome = "manual_resolution_required" if active_bound else "rejected"
                self._record_event(
                    event_type="continuity_connect",
                    outcome=outcome,
                    agent_id=str(anchored[0].get("agent_id")) if anchored else None,
                    callsign=requested_callsign,
                    continuity_anchor=continuity_anchor,
                    details=details,
                )
                raise ContinuityConflictError(
                    (
                        f"Continuity anchor {continuity_anchor!r} is already associated with presentation(s) "
                        f"{', '.join(card.get('callsign') or '?' for card in anchored)}."
                    ),
                    outcome=outcome,
                    details=details,
                )

            agent_id = self.registry.register(
                requested_callsign,
                agent_type=agent_type,
                model_id=model_id,
                display_name=display_name,
                owner_id=owner_id,
            )
            updated = self._apply_identity_fields(
                conn,
                agent_id=agent_id,
                continuity_anchor=continuity_anchor,
                platform_family=platform_family,
                owner_id=owner_id,
                participant_kind=participant_kind,
                participant_shape=participant_shape,
                agency_relation=agency_relation,
                boundary_provenance=boundary_provenance,
                recognition_basis=recognition_basis,
                reachability_mode=reachability_mode,
                interaction_asks_json=interaction_asks_json,
                capability_claims_json=capability_claims_json,
                composition_hints_json=composition_hints_json,
            )
            conn.commit()
            resolution = ContinuityResolution(
                outcome="registered",
                agent_id=agent_id,
                stable_subject_id=str(updated.get("stable_subject_id") or agent_id),
                callsign=requested_callsign,
                continuity_anchor=continuity_anchor,
                requested_callsign=requested_callsign,
                platform_family=platform_family,
                owner_id=owner_id,
                context_hint=context_hint,
            )
            self._record_event(
                event_type="continuity_connect",
                outcome=resolution.outcome,
                agent_id=agent_id,
                callsign=requested_callsign,
                continuity_anchor=continuity_anchor,
                details=resolution.to_dict(),
            )
            # Slice 9: peer_bound delta for fresh registrations. Fires
            # once per new card via the process-wide delta broker so
            # existing subscribed peers see the arrival regardless of
            # which surface (MCP tool, HTTP /identity/connect, library
            # WhispersClient) drove the bind.
            try:
                from .delta_stream import emit_peer_bound, get_delta_broker
                emit_peer_bound(get_delta_broker(), {
                    "callsign": requested_callsign,
                    "agent_id": agent_id,
                    "stable_subject_id": str(updated.get("stable_subject_id") or agent_id),
                    "trust_tier": updated.get("trust_tier"),
                    "continuity_anchor": continuity_anchor,
                    "platform_family": platform_family,
                    "registered_at": updated.get("registered_at"),
                })
            except Exception:
                pass
            return resolution

    def _rewrite_pair_spaces_for_rename(self, conn, *, old_callsign: str, new_callsign: str) -> None:
        rows = conn.execute(
            """
            SELECT workspace_id, name, pair_key, metadata
            FROM workspaces
            WHERE boundary_type = 'pair'
              AND status = 'active'
              AND (pair_key LIKE ? OR metadata LIKE ?)
            """,
            (f"%{old_callsign}%", f"%{old_callsign}%"),
        ).fetchall()
        for row in rows:
            metadata: dict[str, Any] = {}
            raw_metadata = row["metadata"]
            if isinstance(raw_metadata, str) and raw_metadata:
                try:
                    decoded = json.loads(raw_metadata)
                    if isinstance(decoded, dict):
                        metadata = decoded
                except Exception:
                    metadata = {}
            participants = metadata.get("pair_participants") if isinstance(metadata.get("pair_participants"), list) else None
            if not participants:
                participants = str(row["pair_key"] or "").split("::") if row["pair_key"] else []
            if old_callsign not in participants:
                continue
            updated_participants = [new_callsign if name == old_callsign else name for name in participants]
            metadata["pair_participants"] = updated_participants
            new_pair_key = "::".join(sorted(updated_participants)) if updated_participants else None
            new_name = row["name"]
            if len(updated_participants) == 2:
                new_name = f"{updated_participants[0]} ↔ {updated_participants[1]}"
            conn.execute(
                "UPDATE workspaces SET pair_key = ?, name = ?, metadata = ? WHERE workspace_id = ?",
                (
                    new_pair_key,
                    new_name,
                    json.dumps(metadata) if metadata else None,
                    row["workspace_id"],
                ),
            )

    def _rename_live_references(self, conn, *, old_callsign: str, new_callsign: str) -> None:
        conn.execute("DELETE FROM presence WHERE agent_name = ?", (new_callsign,))
        conn.execute("UPDATE presence SET agent_name = ? WHERE agent_name = ?", (new_callsign, old_callsign))

        conn.execute("DELETE FROM presence_policy WHERE agent_name = ?", (new_callsign,))
        conn.execute("UPDATE presence_policy SET agent_name = ? WHERE agent_name = ?", (new_callsign, old_callsign))

        conn.execute("UPDATE agent_sessions SET agent_name = ? WHERE agent_name = ?", (new_callsign, old_callsign))
        conn.execute("UPDATE workspace_members SET agent_name = ? WHERE agent_name = ?", (new_callsign, old_callsign))
        conn.execute(
            """
            UPDATE work_items
            SET proposed_owner = CASE WHEN proposed_owner = ? THEN ? ELSE proposed_owner END,
                owner_agent = CASE WHEN owner_agent = ? THEN ? ELSE owner_agent END
            WHERE proposed_owner = ? OR owner_agent = ?
            """,
            (old_callsign, new_callsign, old_callsign, new_callsign, old_callsign, old_callsign),
        )
        conn.execute(
            """
            UPDATE message_recipients
            SET alias_snapshot = COALESCE(alias_snapshot, recipient_callsign),
                recipient_callsign = ?
            WHERE recipient_callsign = ?
              AND read_at IS NULL
              AND archived_at IS NULL
            """,
            (new_callsign, old_callsign),
        )
        self._rewrite_pair_spaces_for_rename(conn, old_callsign=old_callsign, new_callsign=new_callsign)
        self.db._sync_presence_from_sessions(conn, new_callsign)

    def rename_presentation(
        self,
        current_callsign: str,
        new_callsign: str,
        *,
        actor: str | None = None,
        reason: str | None = None,
        display_name: str | None = None,
    ) -> ContinuityResolution:
        current_callsign = str(current_callsign or "").strip().lower()
        new_callsign = self._validate_human_public_callsign(new_callsign)
        if not current_callsign:
            raise WhispersDBError("current_callsign is required")

        with self.db._db_op("Rename presentation") as conn:
            current = self._card_for_callsign(conn, current_callsign)
            if not current:
                raise WhispersDBError(f"Agent {current_callsign} not found.")

            if current_callsign == new_callsign:
                conn.execute(
                    "UPDATE agent_cards SET display_name = COALESCE(?, display_name), last_seen = CURRENT_TIMESTAMP WHERE agent_id = ?",
                    (display_name, current["agent_id"]),
                )
                conn.commit()
                updated = self._card_for_callsign(conn, current_callsign) or current
                resolution = ContinuityResolution(
                    outcome="presentation_unchanged",
                    agent_id=str(updated.get("agent_id")),
                    stable_subject_id=str(updated.get("stable_subject_id") or updated.get("agent_id")),
                    callsign=current_callsign,
                    continuity_anchor=str(updated.get("continuity_anchor") or ""),
                    requested_callsign=new_callsign,
                    platform_family=str(updated.get("platform_family") or updated.get("agent_type") or "script"),
                    owner_id=updated.get("owner_id"),
                    reason="public presentation unchanged",
                )
                return resolution

            stable_subject_id = str(current.get("stable_subject_id") or current.get("agent_id"))
            self.db.assert_callsign_available(new_callsign, ignore_agent_id=str(current["agent_id"]), conn=conn)
            self.db.assert_callsign_reserved_for_subject(
                new_callsign,
                stable_subject_id=stable_subject_id,
                conn=conn,
            )
            rename_reason = reason or f"presentation renamed from {current_callsign} to {new_callsign}"
            rename_actor = actor or current_callsign
            self.db.bind_callsign_ledger(
                callsign=new_callsign,
                stable_subject_id=stable_subject_id,
                agent_id=str(current["agent_id"]),
                actor=rename_actor,
                reason=rename_reason,
                conn=conn,
            )
            self.db.retire_callsign_ledger(
                callsign=current_callsign,
                stable_subject_id=stable_subject_id,
                agent_id=str(current["agent_id"]),
                successor_callsign=new_callsign,
                actor=rename_actor,
                reason=rename_reason,
                conn=conn,
            )
            conn.execute(
                "UPDATE agent_cards SET callsign = ?, display_name = COALESCE(?, display_name), last_seen = CURRENT_TIMESTAMP WHERE agent_id = ?",
                (new_callsign, display_name, current["agent_id"]),
            )
            self._rename_live_references(conn, old_callsign=current_callsign, new_callsign=new_callsign)
            updated = self._apply_identity_fields(
                conn,
                agent_id=str(current["agent_id"]),
                continuity_anchor=str(current.get("continuity_anchor") or ""),
                platform_family=str(current.get("platform_family") or current.get("agent_type") or "script"),
                owner_id=current.get("owner_id"),
                participant_kind=str(current.get("participant_kind") or "primary_agent"),
                participant_shape=str(current.get("participant_shape") or "atomic"),
                agency_relation=(str(current.get("agency_relation")) if current.get("agency_relation") else None),
                boundary_provenance=(str(current.get("boundary_provenance")) if current.get("boundary_provenance") else None),
                recognition_basis=(str(current.get("recognition_basis")) if current.get("recognition_basis") else None),
                reachability_mode=(str(current.get("reachability_mode")) if current.get("reachability_mode") else None),
                interaction_asks_json=current.get("interaction_asks"),
                capability_claims_json=current.get("capability_claims"),
                composition_hints_json=current.get("composition_hints"),
            )
            conn.commit()

        resolution = ContinuityResolution(
            outcome="presentation_renamed",
            agent_id=str(updated.get("agent_id")),
            stable_subject_id=str(updated.get("stable_subject_id") or updated.get("agent_id")),
            callsign=new_callsign,
            continuity_anchor=str(updated.get("continuity_anchor") or ""),
            requested_callsign=new_callsign,
            platform_family=str(updated.get("platform_family") or updated.get("agent_type") or "script"),
            owner_id=updated.get("owner_id"),
            reason=rename_reason,
        )
        self._emit_rename(
            old_callsign=current_callsign,
            new_callsign=new_callsign,
            reason=rename_reason,
        )
        self._record_event(
            event_type="presentation_rename",
            outcome=resolution.outcome,
            agent_id=str(updated.get("agent_id")) if updated.get("agent_id") else None,
            callsign=new_callsign,
            continuity_anchor=str(updated.get("continuity_anchor") or ""),
            details={
                **resolution.to_dict(),
                "previous_callsign": current_callsign,
            },
        )
        return resolution

    def presentation_history(self, callsign: str, *, limit: int = 20) -> list[dict[str, Any]]:
        with self.db.get_connection() as conn:
            resolved = self.db.resolve_callsign(callsign, conn=conn)
            if not resolved:
                raise WhispersDBError(f"Agent {callsign} not found.")
            return self.db.list_callsign_ledger(
                stable_subject_id=str(resolved["stable_subject_id"]),
                limit=limit,
            )
