from __future__ import annotations

import argparse
import json
import time
from typing import Any
from urllib.parse import urlencode
import urllib.error
import urllib.request


class WakeStreamBridge:
    """Forward wake packets from the Whispers SSE stream to a local connector.

    This is the minimal local-consumer layer for prompt-bound hosts that cannot
    consume SSE in-process. It does not decide *whether* to wake; it only fans
    out already-recorded wake events to a loopback HTTP endpoint.
    """

    def __init__(
        self,
        server_base_url: str,
        agent_name: str,
        local_endpoint_url: str,
        *,
        after_event_id: int | None = None,
        read_timeout: float = 10.0,
    ) -> None:
        self.server_base_url = server_base_url.rstrip("/")
        self.agent_name = agent_name
        self.local_endpoint_url = local_endpoint_url
        self.after_event_id = after_event_id
        self.read_timeout = float(read_timeout)
        self.last_event_id: int | None = after_event_id

    def stream_url(self) -> str:
        query = ""
        if self.after_event_id is not None:
            query = "?" + urlencode({"after_event_id": int(self.after_event_id)})
        return f"{self.server_base_url}/wake/{self.agent_name}/stream{query}"

    def _forward_packet(self, packet: dict[str, Any]) -> None:
        body = json.dumps(packet).encode("utf-8")
        request = urllib.request.Request(
            self.local_endpoint_url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=self.read_timeout) as response:
            response.read()

    def run_until_forwarded(self, *, max_events: int = 1) -> int:
        forwarded = 0
        current_event_id: int | None = self.after_event_id
        request = urllib.request.Request(
            self.stream_url(),
            headers={"Accept": "text/event-stream"},
            method="GET",
        )
        with urllib.request.urlopen(request, timeout=self.read_timeout) as response:
            while forwarded < max_events:
                raw_line = response.readline()
                if not raw_line:
                    break
                line = raw_line.decode("utf-8").strip()
                if not line:
                    continue
                if line.startswith("id: "):
                    try:
                        current_event_id = int(line[4:])
                    except ValueError:
                        current_event_id = current_event_id
                    continue
                if not line.startswith("data: "):
                    continue
                event = json.loads(line[6:])
                payload = event.get("payload") or {}
                packet = payload.get("packet") if isinstance(payload, dict) else None
                if not isinstance(packet, dict):
                    continue
                event_id = event.get("event_id")
                if isinstance(event_id, int):
                    current_event_id = event_id
                self._forward_packet(packet)
                forwarded += 1
                self.last_event_id = current_event_id
                self.after_event_id = self.last_event_id
        return forwarded

    def serve_forever(self, *, reconnect_delay: float = 0.5) -> int:
        forwarded = 0
        while True:
            try:
                forwarded += self.run_until_forwarded(max_events=1_000_000)
            except KeyboardInterrupt:
                raise
            except (OSError, ValueError, urllib.error.URLError):
                time.sleep(reconnect_delay)
                continue
            time.sleep(reconnect_delay)
        return forwarded


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Bridge Whispers wake SSE events to a local HTTP connector.")
    parser.add_argument("--server", required=True, help="Whispers server base URL, e.g. http://127.0.0.1:8000")
    parser.add_argument("--agent", required=True, help="Agent callsign to follow on the wake stream")
    parser.add_argument("--local-endpoint", required=True, help="Loopback HTTP endpoint that should receive wake packets")
    parser.add_argument("--after-event-id", type=int, default=None, help="Replay wake events after this event id on connect")
    parser.add_argument("--read-timeout", type=float, default=10.0, help="Socket timeout in seconds")
    parser.add_argument("--max-events", type=int, default=0, help="Forward this many events and exit; 0 means keep running")
    parser.add_argument("--reconnect-delay", type=float, default=0.5, help="Reconnect delay in seconds when running continuously")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    bridge = WakeStreamBridge(
        args.server,
        args.agent,
        args.local_endpoint,
        after_event_id=args.after_event_id,
        read_timeout=args.read_timeout,
    )
    if args.max_events and args.max_events > 0:
        bridge.run_until_forwarded(max_events=args.max_events)
        return 0
    try:
        bridge.serve_forever(reconnect_delay=args.reconnect_delay)
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
