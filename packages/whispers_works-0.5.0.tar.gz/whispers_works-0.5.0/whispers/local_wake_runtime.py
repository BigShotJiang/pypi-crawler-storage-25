from __future__ import annotations

import argparse
import json
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Callable


class LocalWakeRuntime:
    """Small loopback HTTP runtime for direct local wake delivery.

    This is the direct `local_http_connector` path: start a localhost listener,
    register it against an already-bound agent session, and receive wake packets
    over normal server dispatch.
    """

    def __init__(
        self,
        *,
        bind_host: str = "127.0.0.1",
        port: int = 0,
        parent_pid: int | None = None,
        on_packet: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.bind_host = bind_host
        self.port = int(port)
        self.parent_pid = int(parent_pid) if parent_pid else None
        self.on_packet = on_packet
        self._packets: list[dict[str, Any]] = []
        self._packet_event = threading.Event()
        self._server: HTTPServer | None = None
        self._thread: threading.Thread | None = None

    @property
    def endpoint_url(self) -> str:
        if self._server is None:
            raise RuntimeError("LocalWakeRuntime is not running.")
        return f"http://{self.bind_host}:{self._server.server_port}/wake"

    @property
    def packets(self) -> list[dict[str, Any]]:
        return list(self._packets)

    def start(self) -> None:
        runtime = self

        class _Handler(BaseHTTPRequestHandler):
            def do_POST(self):  # noqa: N802
                length = int(self.headers.get("Content-Length") or "0")
                raw = self.rfile.read(length)
                packet = json.loads(raw.decode("utf-8"))
                runtime._packets.append(packet)
                runtime._packet_event.set()
                if runtime.on_packet is not None:
                    runtime.on_packet(packet)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"status":"ok"}')

            def log_message(self, format, *args):  # noqa: A003
                return

        self._server = HTTPServer((self.bind_host, self.port), _Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=2)
        self._server = None
        self._thread = None

    def wait_for_packet(self, *, timeout: float = 2.0) -> dict[str, Any] | None:
        if not self._packet_event.wait(timeout=timeout):
            return None
        return self._packets[-1] if self._packets else None

    def register_adapter(
        self,
        server_base_url: str,
        agent_name: str,
        *,
        supported_actions: list[str] | None = None,
        fallback_action: str = "notify",
        state: str = "supported",
        detail: str | None = None,
        timeout: float = 10.0,
    ) -> dict[str, Any]:
        payload = {
            "adapter_kind": "local_http_connector",
            "supported_actions": list(supported_actions or ["notify"]),
            "fallback_action": fallback_action,
            "state": state,
            "detail": detail,
            "endpoint_url": self.endpoint_url,
        }
        body = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            f"{server_base_url.rstrip('/')}/wake/{agent_name}/adapters",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))

    def _parent_alive(self) -> bool:
        if not self.parent_pid:
            return True
        try:
            import psutil  # type: ignore

            proc = psutil.Process(self.parent_pid)
            return proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE
        except Exception:
            return False

    def run_forever(self) -> None:
        if self._server is None:
            raise RuntimeError("LocalWakeRuntime is not running.")
        try:
            while True:
                if not self._parent_alive():
                    return
                time.sleep(1.0)
        except KeyboardInterrupt:
            return



def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run a local loopback wake listener and auto-register it as local_http_connector.")
    parser.add_argument("--server", required=True, help="Whispers server base URL, e.g. http://127.0.0.1:8000")
    parser.add_argument("--agent", required=True, help="Agent callsign to register the local listener for")
    parser.add_argument("--host", default="127.0.0.1", help="Loopback bind host")
    parser.add_argument("--port", type=int, default=0, help="Loopback port; 0 chooses a free port")
    parser.add_argument("--supported-action", dest="supported_actions", action="append", default=None, help="Supported wake action; can be repeated")
    parser.add_argument("--fallback-action", default="notify", help="Fallback wake action")
    parser.add_argument("--state", default="supported", help="Adapter state to register")
    parser.add_argument("--detail", default=None, help="Optional adapter detail string")
    parser.add_argument("--parent-pid", type=int, default=None, help="Optional host process pid; runtime exits when this parent dies")
    parser.add_argument(
        "--skip-http-register",
        action="store_true",
        default=False,
        help=(
            "Skip the HTTP POST to /wake/<agent>/adapters. Use when the "
            "caller writes the adapter registration directly to the DB "
            "(avoids self-HTTP deadlock when the spawning parent IS the "
            "server process)."
        ),
    )
    return parser



def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    runtime = LocalWakeRuntime(bind_host=args.host, port=args.port, parent_pid=args.parent_pid)
    runtime.start()
    try:
        # Slice 11: emit the startup payload FIRST so the spawning
        # parent's readline() unblocks immediately, BEFORE any HTTP
        # registration attempt. Prevents self-HTTP deadlock when the
        # parent is the Whispers server process itself (bind_seat path).
        print(
            json.dumps({"endpoint_url": runtime.endpoint_url}, sort_keys=True),
            flush=True,
        )
        if not args.skip_http_register:
            try:
                runtime.register_adapter(
                    args.server,
                    args.agent,
                    supported_actions=args.supported_actions,
                    fallback_action=args.fallback_action,
                    state=args.state,
                    detail=args.detail,
                )
            except Exception:
                # Registration failure is non-fatal: the endpoint is
                # already advertised via stdout and the DB-write path
                # (in-server caller) handles adapter persistence.
                pass
        runtime.run_forever()
    finally:
        runtime.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
