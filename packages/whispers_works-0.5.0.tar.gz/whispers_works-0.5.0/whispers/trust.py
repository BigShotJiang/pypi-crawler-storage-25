from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from typing import Any

from .storage.db import WhispersDB, WhispersDBError
from .trust_baseline import baseline_capabilities


@dataclass(frozen=True)
class TrustResolution:
    stable_subject_id: str
    agent_id: str | None
    current_tier: int
    source: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class TrustService:
    """Trust continuity anchored to stable identity.

    Trust belongs to the durable participant substrate, not the ephemeral seat.
    Sessions come and go. Callsigns may eventually evolve. Stable trust must
    remain queryable and auditable by stable_subject_id.
    """

    def __init__(self, db: WhispersDB):
        self.db = db
        # T4.25 — tier-change observers. Callbacks registered here are
        # invoked after set_tier_for_callsign commits. Used by
        # PollenService to drive the ONE-path reissue ceremony. Keeping
        # it as a simple list avoids coupling trust.py to pollen.
        self._tier_change_listeners: list = []

    def add_tier_change_listener(self, callback) -> None:
        """Register a callback to fire after a tier change commits.

        Callback signature: (callsign: str, old_tier: int, new_tier: int, reason: str) -> None
        Exceptions raised by the callback are logged but do not fail
        the tier change — listeners are informational-layer.
        """
        self._tier_change_listeners.append(callback)

    def _emit_tier_change(
        self,
        callsign: str,
        old_tier: int,
        new_tier: int,
        reason: str,
    ) -> None:
        import logging
        _log = logging.getLogger(__name__)
        for cb in list(self._tier_change_listeners):
            try:
                cb(callsign, old_tier, new_tier, reason)
            except Exception as exc:
                _log.warning("tier_change_listener raised: %s", exc)

    def _card_by_callsign(self, conn, callsign: str) -> dict[str, Any] | None:
        row = conn.execute(
            "SELECT * FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
            (callsign,),
        ).fetchone()
        return dict(row) if row else None

    def _cards_for_subject(self, conn, stable_subject_id: str) -> list[dict[str, Any]]:
        rows = conn.execute(
            "SELECT * FROM agent_cards WHERE stable_subject_id = ? AND deregistered_at IS NULL ORDER BY registered_at ASC",
            (stable_subject_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def _resolve_for_card(self, conn, card: dict[str, Any]) -> TrustResolution:
        stable_subject_id = str(card.get("stable_subject_id") or card.get("agent_id"))
        latest_event = self.db.latest_trust_event(stable_subject_id, conn=conn)
        if latest_event:
            return TrustResolution(
                stable_subject_id=stable_subject_id,
                agent_id=str(card.get("agent_id")) if card.get("agent_id") else None,
                current_tier=int(latest_event["new_tier"]),
                source="trust_events",
            )
        return TrustResolution(
            stable_subject_id=stable_subject_id,
            agent_id=str(card.get("agent_id")) if card.get("agent_id") else None,
            current_tier=int(card.get("trust_tier") or 1),
            source="agent_cards",
        )

    def resolve_for_callsign(self, callsign: str) -> TrustResolution:
        with self.db.get_connection() as conn:
            card = self._card_by_callsign(conn, callsign)
            if not card:
                raise WhispersDBError(f"Agent {callsign} not found.")
            return self._resolve_for_card(conn, card)

    def sync_subject(self, stable_subject_id: str, *, conn=None) -> TrustResolution:
        owns_conn = conn is None
        conn = conn or self.db.get_connection()
        try:
            cards = self._cards_for_subject(conn, stable_subject_id)
            if not cards:
                raise WhispersDBError(f"Stable subject {stable_subject_id} not found.")
            latest_event = self.db.latest_trust_event(stable_subject_id, conn=conn)
            target_tier = int(latest_event["new_tier"] if latest_event else cards[0].get("trust_tier") or 1)
            capabilities = baseline_capabilities(target_tier)
            agent_ids = [str(card["agent_id"]) for card in cards if card.get("agent_id")]
            placeholders = ",".join("?" for _ in agent_ids)
            if not placeholders:
                raise WhispersDBError(f"Stable subject {stable_subject_id} has no agent cards.")
            conn.execute(
                f"UPDATE agent_cards SET trust_tier = ?, capabilities_verified = ?, can_send_flash = ? WHERE agent_id IN ({placeholders})",
                [target_tier, json.dumps(capabilities), capabilities.get("can_send_flash", True), *agent_ids],
            )
            if owns_conn:
                conn.commit()
            return TrustResolution(
                stable_subject_id=stable_subject_id,
                agent_id=str(cards[0].get("agent_id")) if cards[0].get("agent_id") else None,
                current_tier=target_tier,
                source="trust_events" if latest_event else "agent_cards",
            )
        finally:
            if owns_conn:
                conn.close()

    def set_tier_for_callsign(self, callsign: str, *, new_tier: int, actor: str, reason: str) -> TrustResolution:
        with self.db._db_op("Set trust tier") as conn:
            card = self._card_by_callsign(conn, callsign)
            if not card:
                raise WhispersDBError(f"Agent {callsign} not found.")
            stable_subject_id = str(card.get("stable_subject_id") or card.get("agent_id"))
            previous = self.resolve_for_callsign(callsign)
            self.db.record_trust_event(
                stable_subject_id=stable_subject_id,
                agent_id=str(card.get("agent_id")) if card.get("agent_id") else None,
                old_tier=previous.current_tier,
                new_tier=int(new_tier),
                actor=actor,
                reason=reason,
                conn=conn,
            )
            capabilities = baseline_capabilities(int(new_tier))
            cards = self._cards_for_subject(conn, stable_subject_id)
            agent_ids = [str(existing["agent_id"]) for existing in cards if existing.get("agent_id")]
            placeholders = ",".join("?" for _ in agent_ids)
            conn.execute(
                f"UPDATE agent_cards SET trust_tier = ?, capabilities_verified = ?, can_send_flash = ? WHERE agent_id IN ({placeholders})",
                [int(new_tier), json.dumps(capabilities), capabilities.get("can_send_flash", True), *agent_ids],
            )
            conn.commit()
            self._emit_tier_change(
                callsign=str(callsign),
                old_tier=int(previous.current_tier),
                new_tier=int(new_tier),
                reason=str(reason or ""),
            )
            return TrustResolution(
                stable_subject_id=stable_subject_id,
                agent_id=str(card.get("agent_id")) if card.get("agent_id") else None,
                current_tier=int(new_tier),
                source="trust_events",
            )
