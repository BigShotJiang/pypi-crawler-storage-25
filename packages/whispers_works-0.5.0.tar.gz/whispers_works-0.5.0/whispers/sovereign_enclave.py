"""Sovereign enclave — ephemeral in-memory agent signing keys.

Implements Gemini/Forge's Principle 5 (Derived In-Memory Keys) from the
constitutional fabric: an agent holds a cryptographically derived Ed25519
signing key IN-MEMORY ONLY. No keys are written to ``.env`` files or the
SQLite ledger. In production the seed phrase is pulled from the OS
Keychain (Windows Credential Manager, macOS Keychain, Linux Secret
Service); development/test paths can generate ephemeral seeds.

Co-located at the top of the ``whispers`` package (not under
``whispers/identity/``) because ``whispers.identity`` is already a
single-file module with callsign/validation helpers; colliding that
module with a package would shadow existing imports.
"""
from __future__ import annotations

import hashlib
from typing import Dict, Optional

import nacl.encoding
import nacl.signing


class SovereignEnclaveError(Exception):
    """Raised when enclave key derivation or signing fails."""


class DerivedSovereignEnclave:
    """Ephemerally derived per-agent identity handler.

    Holds a cryptographically derived Ed25519 signing key in memory only.
    Agents use this to sign payloads and prove identity peer-to-peer
    without querying a central Whispers registry for permission.
    """

    def __init__(self, agent_name: str, seed_phrase: Optional[bytes] = None):
        """Derive an in-memory per-agent enclave.

        Args:
            agent_name: The bound callsign this enclave signs for.
            seed_phrase: Root seed from the OS Keychain. When absent,
                a fresh ephemeral seed is generated (development/test).
        """
        self._agent_name = agent_name
        if seed_phrase is None:
            self._signing_key = nacl.signing.SigningKey.generate()
        else:
            derived_bytes = hashlib.pbkdf2_hmac(
                "sha256",
                seed_phrase,
                agent_name.encode("utf-8"),
                100_000,
            )
            self._signing_key = nacl.signing.SigningKey(derived_bytes[:32])
        self._public_key = self._signing_key.verify_key

    @property
    def public_key_hex(self) -> str:
        """Hex-encoded public key — the on-the-wire identity."""
        return self._public_key.encode(encoder=nacl.encoding.HexEncoder).decode("utf-8")

    def sign_envelope(self, payload: str) -> Dict[str, str]:
        """Produce a cryptographically verifiable signed envelope.

        Proves this exact agent executed the action locally. The payload
        bytes, signature hex, public key hex, and agent name are returned
        as a dict for embedding in a Whispers envelope.
        """
        payload_bytes = payload.encode("utf-8")
        signed = self._signing_key.sign(payload_bytes)
        return {
            "agent_name": self._agent_name,
            "public_key": self.public_key_hex,
            "signature": signed.signature.hex(),
            "payload": payload,
        }

    def zero_out(self) -> None:
        """Manual cryptographic shredding for mechanical forgetfulness.

        Drops references to the derived key material. Python GC is not
        deterministic, so this is a best-effort — kernel memory may
        still hold the key bytes until the page is reused.
        """
        self._signing_key = None  # type: ignore[assignment]
        self._public_key = None  # type: ignore[assignment]
