"""Claude Code statusline for Whispers.

Invoked by Claude Code per the `statusLine.command` in settings.json:
    python -m whispers.statusline

Claude Code sends session info as JSON on stdin. We emit a single status
line to stdout with the bound callsign, model, and live message counts.

Callsign resolution order:
  1. $WHISPERS_CALLSIGN / $WHISPERS_AGENT env var (explicit per-terminal)
  2. Per-session bind file at
     ~/.whispers/claude-sessions/<claude_session_id>.callsign
  3. Fallback placeholder "unbound-<short-session-id>" so terminals are
     still visually distinguishable from each other when nothing is bound.

We intentionally do NOT fall back to "most recent live agent in the DB" —
that causes the status bar to flip every time any agent acts (the rolodex
bug observed in multi-terminal use).

On every tick we also write a breadcrumb at
    ~/.whispers/claude-sessions/_breadcrumbs/<parent_pid>
containing the Claude session id. `whispers adopt` walks up the process
tree to find Claude Code's PID, reads the breadcrumb, and writes the bind
file keyed by the same session id we read here.
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
import time
from pathlib import Path

from .frames import SEPARATOR, signal_line_prefix, urgent_count_chunk

WHISPERS_HOME = Path.home() / ".whispers"
WHISPERS_DB = WHISPERS_HOME / "whispers.db"
PER_SESSION_DIR = WHISPERS_HOME / "claude-sessions"
BREADCRUMB_DIR = PER_SESSION_DIR / "_breadcrumbs"
DEFAULT_PLACEHOLDER = "unbound"


def _model_short(info: dict) -> str:
    m = info.get("model") or {}
    name = m.get("display_name") or m.get("id") or ""
    if not name:
        return ""
    lower = name.lower()
    if "opus" in lower:
        if "4.7" in lower or "4-7" in lower:
            return "opus-4.7"
        if "4.6" in lower or "4-6" in lower:
            return "opus-4.6"
        return "opus"
    if "sonnet" in lower:
        if "4.6" in lower or "4-6" in lower:
            return "sonnet-4.6"
        return "sonnet"
    if "haiku" in lower:
        return "haiku"
    return name.split("-")[0]


def _session_id(info: dict) -> str | None:
    """Return Claude Code's session id for this terminal, from stdin info."""
    for key in ("session_id", "sessionId", "claude_session_id"):
        val = info.get(key)
        if val:
            return str(val)
    for container_key in ("session", "workspace"):
        container = info.get(container_key)
        if isinstance(container, dict):
            for key in ("id", "session_id", "sessionId"):
                val = container.get(key)
                if val:
                    return str(val)
    return None


def _short_id(session_id: str | None) -> str:
    if not session_id:
        return "nosession"
    stripped = session_id.replace("-", "")
    return stripped[:6] if len(stripped) >= 6 else stripped


def _find_claude_pid_in_ancestry() -> int | None:
    """Walk this process's ancestry looking for the Claude Code executable.

    Prefers a process whose executable name starts with 'claude' (the real
    claude.exe / claude binary). Falls back to CLAUDECODE=1 in env only
    when no claude-named process is found — this matters because bash
    shims between the caller and Claude Code inherit CLAUDECODE=1 from
    their parent, so checking env first misidentifies the nearest shell
    as Claude Code.

    Both the statusline and `whispers adopt` use this same lookup so they
    agree on which PID to key breadcrumbs by.
    """
    try:
        import psutil  # type: ignore
    except ImportError:
        return None
    try:
        proc = psutil.Process(os.getpid())
    except Exception:
        return None

    ancestors = []
    for a in proc.parents():
        try:
            ancestors.append((a, (a.name() or "").lower()))
        except Exception:
            continue

    # First pass: real claude.exe / claude binary
    for a, name in ancestors:
        if name.startswith("claude") and "bash" not in name:
            try:
                return a.pid
            except Exception:
                continue

    # Second pass: any process with CLAUDECODE=1 in env (shims included).
    # Use the OLDEST such process — that's the one that set the env, not
    # a descendant that merely inherited it.
    candidates = []
    for a, _name in ancestors:
        try:
            env = a.environ() or {}
            if str(env.get("CLAUDECODE", "")).strip() == "1":
                candidates.append((a.create_time(), a.pid))
        except Exception:
            continue
    if candidates:
        candidates.sort()  # oldest create_time first
        return candidates[0][1]

    return None


def _write_breadcrumb(session_id: str | None) -> None:
    """Let `whispers adopt` discover this Claude session via ancestry lookup.

    We key the breadcrumb by the Claude Code process PID found via ancestry
    walk, not `os.getppid()`, because on some platforms there are shim
    processes between the statusline and Claude Code. The adopt CLI uses
    the same walk, so both sides agree on the key.

    Best-effort; failures are silent.
    """
    if not session_id:
        return
    claude_pid = _find_claude_pid_in_ancestry() or os.getppid()
    try:
        BREADCRUMB_DIR.mkdir(parents=True, exist_ok=True)
        breadcrumb = BREADCRUMB_DIR / str(claude_pid)
        breadcrumb.write_text(session_id, encoding="utf-8")
    except OSError:
        pass


def _read_per_session_callsign(session_id: str | None) -> str | None:
    if not session_id:
        return None
    try:
        bind_file = PER_SESSION_DIR / f"{session_id}.callsign"
        if bind_file.is_file():
            val = bind_file.read_text(encoding="utf-8").strip()
            return val or None
    except OSError:
        return None
    return None


def claim_pending_bind(
    claude_session_id: str | None,
    *,
    whispers_home: Path | None = None,
    db_path: Path | None = None,
    now: float | None = None,
    claim_window_seconds: int = 30,
) -> str | None:
    """Adopt an orphaned MCP bind when the mapping is unambiguous.

    Claude Code's MCP client cannot inject the live Claude session id into
    HTTP headers (no `.mcp.json` template expansion exists for runtime
    context). The bridge therefore can't write the per-Claude-session bind
    file at `bind_seat` time when it doesn't know the Claude session id.
    Instead, `agent_sessions` carries a row per MCP client session without
    a ``metadata.claude_session_id``.

    The statusline is the only process in each Claude window that reliably
    knows that window's Claude session id. On each tick, if the per-session
    bind file is absent, the statusline reads ``agent_sessions`` for recent
    ``mcp_http`` rows that have not yet been paired with any Claude session
    id. If **exactly one** such callsign is not already bound to any Claude
    session (i.e. no other `*.callsign` file already holds it), it is the
    unambiguous match for this window — we adopt it by writing the per-
    session bind file and return the callsign. Any other case (zero, two,
    all claimed elsewhere) returns None, leaving the statusline in its
    honest unbound state until the operator resolves it.

    This is the starting-line fix for Acceptance Test #3 (multi-window
    independence) in single-window and time-staggered multi-window cases.
    Simultaneous multi-window bind degrades honestly — it does NOT silently
    guess.
    """
    if not claude_session_id:
        return None
    effective_home = whispers_home or WHISPERS_HOME
    effective_db_path = db_path if db_path is not None else WHISPERS_DB
    sessions_dir = effective_home / "claude-sessions"
    if not Path(effective_db_path).is_file():
        return None

    try:
        conn = sqlite3.connect(f"file:{effective_db_path}?mode=ro", uri=True)
    except sqlite3.Error:
        return None

    cutoff_time = (now if now is not None else time.time()) - claim_window_seconds
    cutoff_iso = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(cutoff_time))
    try:
        rows = conn.execute(
            "SELECT agent_name, metadata FROM agent_sessions "
            "WHERE session_kind='mcp_http' AND created_at >= ? "
            "AND agent_name IS NOT NULL AND agent_name != ''",
            (cutoff_iso,),
        ).fetchall()
    except sqlite3.Error:
        conn.close()
        return None
    conn.close()

    candidate_callsigns: set[str] = set()
    for agent_name, metadata_str in rows:
        try:
            metadata = json.loads(metadata_str) if metadata_str else {}
        except json.JSONDecodeError:
            metadata = {}
        if metadata.get("claude_session_id"):
            continue  # already synced to a Claude session, not pending
        name = str(agent_name).strip()
        if name:
            candidate_callsigns.add(name)

    already_claimed: set[str] = set()
    if sessions_dir.is_dir():
        for bind_file in sessions_dir.glob("*.callsign"):
            try:
                content = bind_file.read_text(encoding="utf-8").strip()
            except OSError:
                continue
            if content:
                already_claimed.add(content)

    eligible = candidate_callsigns - already_claimed
    if len(eligible) != 1:
        return None

    callsign = next(iter(eligible))
    try:
        sessions_dir.mkdir(parents=True, exist_ok=True)
        (sessions_dir / f"{claude_session_id}.callsign").write_text(
            callsign, encoding="utf-8"
        )
    except OSError:
        return None
    return callsign


def _resolve_callsign(session_id: str | None) -> tuple[str, str]:
    """Return (callsign, source). Source one of: env, per-session, unbound."""
    explicit = os.environ.get("WHISPERS_CALLSIGN") or os.environ.get("WHISPERS_AGENT")
    if explicit and explicit.strip():
        return explicit.strip(), "env"

    per_session = _read_per_session_callsign(session_id)
    if per_session:
        return per_session, "per-session"

    claimed = claim_pending_bind(session_id)
    if claimed:
        return claimed, "per-session"

    return DEFAULT_PLACEHOLDER, "unbound"


def _counts(db: sqlite3.Connection, callsign: str) -> tuple[int, int, int]:
    try:
        unread = db.execute(
            "SELECT COUNT(*) FROM messages WHERE to_agent=? AND seen_at IS NULL "
            "AND status NOT IN ('dead_lettered')",
            (callsign,),
        ).fetchone()[0]
        urgent = db.execute(
            "SELECT COUNT(*) FROM messages WHERE to_agent=? AND seen_at IS NULL "
            "AND priority IN ('flash','priority') AND status NOT IN ('dead_lettered')",
            (callsign,),
        ).fetchone()[0]
        tier_row = db.execute(
            "SELECT trust_tier FROM agent_cards WHERE callsign=?",
            (callsign,),
        ).fetchone()
        tier = tier_row[0] if tier_row else 0
        return unread, urgent, tier
    except sqlite3.Error:
        return 0, 0, 0


def render(info: dict) -> str:
    session_id = _session_id(info)
    _write_breadcrumb(session_id)

    callsign, source = _resolve_callsign(session_id)
    model = _model_short(info)

    display_callsign = callsign
    if source == "unbound":
        display_callsign = f"{callsign}-{_short_id(session_id)}"

    parts: list[str] = [signal_line_prefix(display_callsign)]
    if model:
        parts.append(model)

    if source != "unbound":
        try:
            db = sqlite3.connect(f"file:{WHISPERS_DB}?mode=ro", uri=True)
        except sqlite3.Error:
            db = None
        if db is not None:
            unread, urgent, tier = _counts(db, callsign)
            if tier:
                parts.append(f"tier:{tier}")
            if urgent:
                parts.append(urgent_count_chunk(urgent))
            elif unread:
                parts.append(f"{unread} unread")
            db.close()

    return SEPARATOR.join(parts)


def main() -> int:
    raw = sys.stdin.read()
    info: dict = {}
    if raw.strip():
        try:
            info = json.loads(raw)
        except json.JSONDecodeError:
            info = {}
    sys.stdout.write(render(info))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
