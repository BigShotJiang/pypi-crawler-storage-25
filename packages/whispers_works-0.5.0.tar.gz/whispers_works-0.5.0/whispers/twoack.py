"""2ACK v0 envelope support.

Implements the minimum-viable 2ACK envelope per spec §8 and §22.1, riding
inside Whispers' native Envelope.payload. Level 1 conformance (spec §20.2):
recognize, preserve, forward; no trust/authority/encryption/profile work yet.

See .planning/2ACK-V0-DESIGN-2026-04-17.md for the shipping contract.
See .planning/2ACK-PROTOCOL-SPEC.md for the formal spec draft v0.7.
"""
from __future__ import annotations

from typing import Any, Literal

from .twoack_schemas import StatusUpdate

WIRE_V = 1
DEFAULT_SCHEMA = "status_update.v1"
DEFAULT_SIGNAL_CLASS = "internal"
VALID_STATES = frozenset({
    "idle", "listening", "exploring", "building",
    "blocked", "eureka", "winding_down",
})
DEFAULT_STATE = "building"

_PREFLIGHT_FIELDS = ("wire_v", "schema", "signal_class")


def build_status_envelope(
    *,
    message_id: str,
    thread_id: str,
    created_at: str,
    state: str = DEFAULT_STATE,
    readiness: str | None = None,
    current_task: str | None = None,
    interruptibility: str | None = None,
    confidence: float | None = None,
    working_set: list[str] | tuple[str, ...] | None = None,
    in_reply_to: str | None = None,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Build a valid v0 2ACK envelope carrying a status_update.v1 payload.

    Omission semantics (spec §10): optional fields are included only when set.
    """
    if state not in VALID_STATES:
        raise ValueError(
            f"invalid state {state!r}; must be one of {sorted(VALID_STATES)}"
        )

    trace: dict[str, Any] = {"message_id": message_id, "thread_id": thread_id}
    if in_reply_to is not None:
        trace["in_reply_to"] = in_reply_to
    if trace_id is not None:
        trace["trace_id"] = trace_id

    payload = StatusUpdate(
        state=state,
        readiness=readiness,
        current_task=current_task,
        interruptibility=interruptibility,
        confidence=float(confidence) if confidence is not None else None,
        working_set=tuple(working_set or ()),
    ).to_payload()

    return {
        "wire_v": WIRE_V,
        "schema": DEFAULT_SCHEMA,
        "signal_class": DEFAULT_SIGNAL_CLASS,
        "trace": trace,
        "payload": payload,
        "created_at": created_at,
    }


def validate_envelope(env: dict[str, Any]) -> list[str]:
    """Return validation errors; empty list means valid for v0."""
    errors: list[str] = []
    if not isinstance(env, dict):
        return ["envelope must be a dict"]

    wire_v = env.get("wire_v")
    if wire_v != WIRE_V:
        errors.append(f"wire_v must be {WIRE_V}; got {wire_v!r}")

    schema = env.get("schema")
    if schema != DEFAULT_SCHEMA:
        errors.append(f"v0 only accepts schema {DEFAULT_SCHEMA!r}; got {schema!r}")

    trace = env.get("trace")
    if not isinstance(trace, dict):
        errors.append("trace must be a dict")
    elif not trace.get("message_id"):
        errors.append("trace.message_id is required")

    created_at = env.get("created_at")
    if not created_at or not isinstance(created_at, str):
        errors.append("created_at is required and must be a string")

    signal_class = env.get("signal_class")
    if signal_class != DEFAULT_SIGNAL_CLASS:
        errors.append(f"signal_class must be {DEFAULT_SIGNAL_CLASS!r}; got {signal_class!r}")

    payload = env.get("payload")
    if not isinstance(payload, dict):
        errors.append("payload must be a dict")
    else:
        state = payload.get("state")
        if state not in VALID_STATES:
            errors.append(
                f"payload.state must be one of {sorted(VALID_STATES)}; got {state!r}"
            )
        confidence = payload.get("confidence")
        if confidence is not None:
            if not isinstance(confidence, (int, float)) or not 0.0 <= float(confidence) <= 1.0:
                errors.append("payload.confidence must be a float in [0.0, 1.0]")

    return errors


def preflight_surface(source: dict[str, Any]) -> dict[str, Any]:
    """Extract the preflight surface without touching the inner 2ACK payload.

    Accepts either a raw 2ACK envelope or a delivered message row carrying
    metadata mirrors. For DB rows, the surface is derived from metadata + row
    fields only; payload deserialization is intentionally skipped.
    """
    if not isinstance(source, dict):
        return {}

    metadata = source.get("metadata") or {}
    if isinstance(metadata, str):
        try:
            import json
            metadata = json.loads(metadata)
        except (ValueError, TypeError):
            metadata = {}
    if not isinstance(metadata, dict):
        metadata = {}

    if "wire_v" in source or "schema" in source:
        out: dict[str, Any] = {}
        for key in _PREFLIGHT_FIELDS:
            if key in source:
                out[key] = source[key]
        trace = source.get("trace")
        if isinstance(trace, dict) and "message_id" in trace:
            out["trace.message_id"] = trace["message_id"]
        return out

    schema = metadata.get("whispers:schema")
    signal_class = metadata.get("whispers:signalClass")
    if not schema and not signal_class:
        return {}
    return {
        "wire_v": WIRE_V,
        "schema": schema,
        "signal_class": signal_class,
        "trace.message_id": source.get("message_id") or source.get("uuid"),
    }


def preflight_decision(
    msg_row: dict[str, Any],
    *,
    local_policy: dict[str, Any] | None = None,
) -> Literal["accept", "defer", "reject"]:
    """Decide fate of a message using metadata + preflight surface only.

    MUST NOT deserialize or inspect the inner 2ACK payload — that is the
    Level 1 guarantee. v0 reject conditions:
      - wire_v > 1
      - schema not recognized
      - created_at missing

    v0 has no defer conditions; trust gating lands in the v1 trust pack.
    """
    del local_policy  # v0 has no policy-driven branches

    pf = preflight_surface(msg_row)
    if not pf:
        # Pre-2ACK message from a Level 0 sender — accept as before.
        return "accept"

    wire_v = pf.get("wire_v")
    if not isinstance(wire_v, int) or wire_v > WIRE_V:
        return "reject"

    schema = pf.get("schema")
    if schema != DEFAULT_SCHEMA:
        return "reject"

    if not msg_row.get("created_at"):
        return "reject"

    return "accept"


def extract_twoack(payload: Any) -> dict[str, Any] | None:
    """Return the 2ACK envelope from Envelope.payload, or None if absent.

    Tolerates JSON-string payloads (as some DB rows surface them).
    """
    if payload is None:
        return None
    if isinstance(payload, str):
        try:
            import json
            payload = json.loads(payload)
        except (ValueError, TypeError):
            return None
    if not isinstance(payload, dict):
        return None
    env = payload.get("twoack")
    return env if isinstance(env, dict) else None


def metadata_mirrors(
    *,
    schema: str = DEFAULT_SCHEMA,
    wire_mode: str = "agent-native",
    signal_class: str = "internal",
    profiles: tuple[str, ...] = ("base",),
) -> dict[str, Any]:
    """Return the metadata mirror keys per spec §7.4 for v0."""
    return {
        "whispers:wireMode": wire_mode,
        "whispers:schema": schema,
        "whispers:signalClass": signal_class,
        "whispers:wireProfiles": list(profiles),
    }
