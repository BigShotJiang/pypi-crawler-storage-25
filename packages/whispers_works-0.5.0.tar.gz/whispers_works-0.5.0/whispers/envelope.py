import json
import uuid
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, Dict, Any, Union
from .time_utils import parse_timestamp, to_utc_iso, utc_now

class Priority(str, Enum):
    ROUTINE = "routine"
    PRIORITY = "priority"
    FLASH = "flash"
    SYSTEM = "system"

class MsgType(str, Enum):
    HANDOFF = "handoff"
    HANDOFF_BATON_V1 = "handoff_baton.v1"
    HEADS_UP = "heads_up"
    CHECKPOINT = "checkpoint"
    REPLY = "reply"
    PROPOSE = "propose"     # De Bono Phase 1
    ACCEPT = "accept"       # De Bono Phase 2/3
    REJECT = "reject"       # De Bono Phase 2/3
    REQUEST = "request"
    INFORM = "inform"
    MOVE = "move"              # A sealed move submitted by a FOCUSED agent
    REVEAL = "reveal"          # Orchestrator broadcasting the unsealed moves
    SCORE = "score"            # Evaluation results
    ELIMINATE = "eliminate"    # Bracket removal
    STATUS_UPDATE = "status_update"
    DECISION_REQUEST = "decision_request"
    DECISION_RESPONSE = "decision_response"
    EXTERNAL_ACTION_REQUEST = "external_action_request"
    EXTERNAL_ACTION_RESULT = "external_action_result"
    PARTICIPANT_STATE = "participant_state"
    ACTUATION_LIFECYCLE = "actuation_lifecycle"
    DECISION_SURFACE = "decision_surface"

class QueueClass(str, Enum):
    ACTIONABLE = "actionable"
    CONVERSATION = "conversation"
    SYSTEM = "system"
    REFERENCE = "reference"


class AttentionTier(str, Enum):
    INTERRUPT_NOW = "interrupt_now"
    SURFACE_NOW = "surface_now"
    HOLD_VISIBLE = "hold_visible"


_ACTIONABLE_MSG_TYPES = frozenset({
    "handoff", "handoff_baton.v1", "request", "assignment",
    "decision_request", "external_action_request",
    "actuation_lifecycle", "decision_surface",
})
_ACTIONABLE_SCHEMAS = frozenset({
    "handoff_baton.v1", "decision_request.v1", "external_action_request.v1",
    "actuation_lifecycle.v1", "decision_surface.v1",
})
_REFERENCE_SCHEMAS = frozenset({
    "workspace_delta.v1", "baton_update.v1", "baton_close.v1",
})


def classify_queue_class(
    msg_type: str,
    priority: str,
    sender: str,
    schema: str | None = None,
) -> str:
    """Deterministic queue class from message properties. Computed at store time."""
    if sender == "whispers-server" or priority == "system":
        return QueueClass.SYSTEM
    if msg_type in _ACTIONABLE_MSG_TYPES or schema in _ACTIONABLE_SCHEMAS or priority == "flash":
        return QueueClass.ACTIONABLE
    if schema in _REFERENCE_SCHEMAS or msg_type == "checkpoint":
        return QueueClass.REFERENCE
    return QueueClass.CONVERSATION


def requires_prompt_attention(
    msg_type: str,
    priority: str,
    sender: str,
    *,
    subject: str | None = None,
    schema: str | None = None,
    reply_to: str | None = None,
    is_hot_thread: bool = False,
) -> bool:
    """Return True when a message should actively prompt the recipient."""
    normalized_msg_type = str(msg_type or "inform").strip().lower() or "inform"
    normalized_priority = str(priority or "routine").strip().lower() or "routine"
    normalized_sender = str(sender or "").strip()
    normalized_subject = str(subject or "").strip().lower()

    if is_hot_thread:
        return True
    if normalized_priority in {
        Priority.PRIORITY.value,
        Priority.FLASH.value,
        Priority.SYSTEM.value,
    }:
        return True
    if reply_to:
        return True
    if normalized_msg_type == MsgType.CHECKPOINT.value or normalized_subject.startswith("re:"):
        return True
    return classify_queue_class(
        normalized_msg_type,
        normalized_priority,
        normalized_sender,
        schema=schema,
    ) == QueueClass.ACTIONABLE


def classify_attention_tier(
    msg_type: str,
    priority: str,
    sender: str,
    *,
    subject: str | None = None,
    schema: str | None = None,
    reply_to: str | None = None,
    is_hot_thread: bool = False,
    alert_allowed: bool = True,
) -> str:
    """Map delivery semantics to a simple attention tier."""
    if not alert_allowed:
        return AttentionTier.HOLD_VISIBLE.value
    if requires_prompt_attention(
        msg_type,
        priority,
        sender,
        subject=subject,
        schema=schema,
        reply_to=reply_to,
        is_hot_thread=is_hot_thread,
    ):
        return AttentionTier.INTERRUPT_NOW.value
    return AttentionTier.SURFACE_NOW.value


class AudienceScope(str, Enum):
    DIRECT = "direct"
    ROOM = "room"
    TEAM = "team"
    SWARM = "swarm"


class VisibilityMode(str, Enum):
    QUIET = "quiet"
    NORMAL = "normal"
    ANNOUNCE = "announce"
    BROADCAST = "broadcast"
    CEREMONY = "ceremony"


class MemoryMode(str, Enum):
    EPHEMERAL = "ephemeral"
    THREAD = "thread"
    PIN = "pin"
    LEDGER = "ledger"
    ENGRAM = "engram"


class AcknowledgmentState(str, Enum):
    PROCESSED = "processed"
    INSUFFICIENT_CONTEXT = "insufficient_context"
    ACCEPTED = "accepted"
    DECLINED = "declined"
    DEFERRED = "deferred"


VALID_CONSEQUENCE_SCOPES = {"digital", "physical_reversible", "physical_irreversible"}


_POLICY_METADATA_KEYS = {
    "audience_scope": "whispers_audience_scope",
    "visibility_mode": "whispers_visibility_mode",
    "memory_mode": "whispers_memory_mode",
}


def infer_audience_scope(recipient: Optional[str]) -> AudienceScope:
    if not recipient:
        return AudienceScope.DIRECT
    if recipient.startswith("#"):
        return AudienceScope.ROOM
    if recipient.startswith("pool:") or recipient.startswith("multi:"):
        return AudienceScope.TEAM
    if recipient.startswith("@all") or recipient.startswith("swarm:"):
        return AudienceScope.SWARM
    return AudienceScope.DIRECT


def merge_policy_metadata(
    metadata: Optional[Dict[str, Any]],
    *,
    audience_scope: Union[AudienceScope, str, None],
    visibility_mode: Union[VisibilityMode, str, None],
    memory_mode: Union[MemoryMode, str, None],
) -> Optional[Dict[str, Any]]:
    merged = dict(metadata or {})
    if audience_scope is not None:
        merged[_POLICY_METADATA_KEYS["audience_scope"]] = AudienceScope(audience_scope).value
    if visibility_mode is not None:
        merged[_POLICY_METADATA_KEYS["visibility_mode"]] = VisibilityMode(visibility_mode).value
    if memory_mode is not None:
        merged[_POLICY_METADATA_KEYS["memory_mode"]] = MemoryMode(memory_mode).value
    return merged or None


def hydrate_policy_fields(record: Dict[str, Any]) -> Dict[str, Any]:
    if not record:
        return record
    hydrated = dict(record)
    metadata = hydrated.get("metadata")
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata)
        except Exception:
            metadata = None
    if isinstance(metadata, dict):
        hydrated["metadata"] = metadata
    else:
        metadata = None

    recipient = hydrated.get("recipient") or hydrated.get("to_agent") or hydrated.get("to")
    hydrated["audience_scope"] = AudienceScope(
        hydrated.get("audience_scope")
        or (metadata or {}).get(_POLICY_METADATA_KEYS["audience_scope"])
        or infer_audience_scope(recipient).value
    ).value
    hydrated["visibility_mode"] = VisibilityMode(
        hydrated.get("visibility_mode")
        or (metadata or {}).get(_POLICY_METADATA_KEYS["visibility_mode"])
        or VisibilityMode.NORMAL.value
    ).value
    hydrated["memory_mode"] = MemoryMode(
        hydrated.get("memory_mode")
        or (metadata or {}).get(_POLICY_METADATA_KEYS["memory_mode"])
        or MemoryMode.THREAD.value
    ).value
    return hydrated

@dataclass
class Envelope:
    sender: str
    recipient: str
    msg_type: MsgType
    subject: str
    priority: Priority = Priority.ROUTINE
    audience_scope: AudienceScope = field(default=None)
    visibility_mode: VisibilityMode = VisibilityMode.NORMAL
    memory_mode: MemoryMode = MemoryMode.THREAD
    content_type: str = "text/plain"
    version: str = "1.0"
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    body: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    trust: Optional[Dict[str, Any]] = None
    summary: Optional[Dict[str, Any]] = None
    authority: Optional[Dict[str, Any]] = None
    authority_proof: Optional[Union[str, Dict[str, Any]]] = None
    # Participant roles — who originated, who is the subject, under whose authority
    origin: Optional[str] = None            # who created this signal (may differ from sender if relayed)
    subject_of: Optional[str] = None        # who/what this signal is about (not msg subject line)
    principal: Optional[str] = None         # under whose authority this signal speaks
    # Consequence scope — what class of real-world effect this signal carries
    consequence_scope: Optional[str] = None  # digital | physical_reversible | physical_irreversible
    policy_hint: Optional[Dict[str, Any]] = None
    context_id: Optional[str] = None
    reply_to: Optional[str] = None
    trace_id: Optional[str] = None
    ttl_seconds: Optional[int] = None
    idempotency_key: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    ephemeral: bool = False
    created_at: datetime = field(default_factory=utc_now)

    def __post_init__(self):
        if isinstance(self.msg_type, str):
            self.msg_type = MsgType(self.msg_type)
        if isinstance(self.priority, str):
            self.priority = Priority(self.priority)
        if isinstance(self.created_at, str):
            parsed = parse_timestamp(self.created_at)
            if parsed is not None:
                self.created_at = parsed
        self.audience_scope = AudienceScope(self.audience_scope or infer_audience_scope(self.recipient))
        self.visibility_mode = VisibilityMode(self.visibility_mode)
        self.memory_mode = MemoryMode(self.memory_mode)
        if self.consequence_scope is not None:
            cs = str(self.consequence_scope).strip().lower()
            if cs not in VALID_CONSEQUENCE_SCOPES:
                raise ValueError(
                    f"Unknown consequence_scope: {self.consequence_scope!r}. "
                    f"Valid: {sorted(VALID_CONSEQUENCE_SCOPES)}"
                )
            self.consequence_scope = cs
        self.metadata = merge_policy_metadata(
            self.metadata,
            audience_scope=self.audience_scope,
            visibility_mode=self.visibility_mode,
            memory_mode=self.memory_mode,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize envelope to dictionary for DB or transmission."""
        d = asdict(self)
        if isinstance(d['created_at'], datetime):
            d['created_at'] = to_utc_iso(d['created_at'])
        d['msg_type'] = self.msg_type.value
        d['priority'] = self.priority.value
        d['audience_scope'] = self.audience_scope.value
        d['visibility_mode'] = self.visibility_mode.value
        d['memory_mode'] = self.memory_mode.value
        return d

    def to_json(self) -> str:
        """Serialize envelope as JSON for SSE and HTTP transport."""
        return json.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Envelope":
        """Deserialize and validate from dictionary."""
        # Clean up types explicitly during deserialization
        if data.get("created_at") is not None:
            parsed = parse_timestamp(data["created_at"])
            if parsed is not None:
                data["created_at"] = parsed
        if isinstance(data.get("msg_type"), str):
            data["msg_type"] = MsgType(data["msg_type"])
        if isinstance(data.get("priority"), str):
            data["priority"] = Priority(data["priority"])
        if isinstance(data.get("audience_scope"), str):
            data["audience_scope"] = AudienceScope(data["audience_scope"])
        if isinstance(data.get("visibility_mode"), str):
            data["visibility_mode"] = VisibilityMode(data["visibility_mode"])
        if isinstance(data.get("memory_mode"), str):
            data["memory_mode"] = MemoryMode(data["memory_mode"])
            
        return cls(**data)
