from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


VALID_PARTICIPANT_KINDS = (
    "human",
    "primary_agent",
    "sub_agent",
    "host_bound_agent",
    "device",
    "status_source",
    "gateway",
    "facade",
    "collective",
    "selector",
    "approval_surface",
    "action_target",
)

VALID_PARTICIPANT_SHAPES = (
    "atomic",
    "cored_envelope",
    "federated_facade",
    "drift_anchor",
)

VALID_AGENCY_RELATIONS = (
    "self",
    "delegate",
    "representative",
    "instrument",
)

VALID_BOUNDARY_PROVENANCE = (
    "self_asserted",
    "jointly_asserted",
    "imposed",
    "observer_asserted",
)

VALID_RECOGNITION_BASIS = (
    "handshake",
    "registration",
    "observation",
    "attestation",
    "operator_declaration",
    "temporary_recognition",
)

VALID_INTERACTION_ASKS = (
    "observe",
    "notify",
    "introduce",
    "inform",
    "review",
    "approve",
    "handoff",
    "act",
    "exchange",
    "monitor",
)


def _normalize_choice(value: Any, *, valid: tuple[str, ...], label: str) -> str:
    normalized = str(value or "").strip().lower()
    if normalized not in valid:
        raise ValueError(f"Invalid {label} '{value}'. Expected one of: {', '.join(valid)}.")
    return normalized


@dataclass(frozen=True)
class ParticipantDescriptor:
    presentation_name: str
    participant_kind: str
    participant_shape: str
    agency_relation: str
    boundary_provenance: str
    recognition_basis: str
    what_do_you_do: tuple[str, ...] = field(default_factory=tuple)
    differentiators: tuple[str, ...] = field(default_factory=tuple)
    attached_resources: tuple[str, ...] = field(default_factory=tuple)
    interaction_asks: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if not self.presentation_name.strip():
            raise ValueError("presentation_name is required")
        object.__setattr__(self, "participant_kind", _normalize_choice(self.participant_kind, valid=VALID_PARTICIPANT_KINDS, label="participant_kind"))
        object.__setattr__(self, "participant_shape", _normalize_choice(self.participant_shape, valid=VALID_PARTICIPANT_SHAPES, label="participant_shape"))
        object.__setattr__(self, "agency_relation", _normalize_choice(self.agency_relation, valid=VALID_AGENCY_RELATIONS, label="agency_relation"))
        object.__setattr__(self, "boundary_provenance", _normalize_choice(self.boundary_provenance, valid=VALID_BOUNDARY_PROVENANCE, label="boundary_provenance"))
        object.__setattr__(self, "recognition_basis", _normalize_choice(self.recognition_basis, valid=VALID_RECOGNITION_BASIS, label="recognition_basis"))
        asks = tuple(_normalize_choice(item, valid=VALID_INTERACTION_ASKS, label="interaction_ask") for item in self.interaction_asks)
        object.__setattr__(self, "interaction_asks", asks)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def interrogative_summary(self) -> dict[str, Any]:
        return {
            "what_are_you": {
                "participant_kind": self.participant_kind,
                "participant_shape": self.participant_shape,
                "agency_relation": self.agency_relation,
                "boundary_provenance": self.boundary_provenance,
                "recognition_basis": self.recognition_basis,
            },
            "what_do_you_do": list(self.what_do_you_do),
            "how_are_you_different": list(self.differentiators),
            "what_are_you_attached_to": list(self.attached_resources),
            "what_do_you_want_from_me": list(self.interaction_asks),
        }
