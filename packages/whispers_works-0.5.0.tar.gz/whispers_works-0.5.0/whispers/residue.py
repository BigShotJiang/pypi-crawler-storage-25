from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from datetime import timedelta
from typing import Any

from .storage.db import WhispersDB
from .time_utils import parse_timestamp, to_utc_iso, utc_now


@dataclass(frozen=True)
class ObservationLabel:
    basis: str
    observed_at: str = field(default_factory=lambda: to_utc_iso(utc_now()))
    confidence: float | None = None
    ttl_seconds: int | None = None
    observed_by: str | None = None
    negative_states: tuple[str, ...] = ()
    challengeable: bool = True

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["negative_states"] = list(self.negative_states)
        return payload


@dataclass(frozen=True)
class ResidueGrain:
    axis: str
    subject_refs: tuple[str, ...]
    observation: str
    label: ObservationLabel
    signal_kind: str = "residue"
    grain_id: str = field(default_factory=lambda: f"grain_{uuid.uuid4().hex[:12]}")
    spread: str | None = None
    space_id: str | None = None
    work_id: str | None = None
    source_message_id: str | None = None
    source_artifact_id: str | None = None
    metadata: dict[str, Any] | None = None
    status: str = "active"
    supersedes_grain_id: str | None = None

    def __post_init__(self):
        axis = str(self.axis or "").strip().lower()
        if not axis:
            raise ValueError("axis is required")
        object.__setattr__(self, "axis", axis)

        subject_refs = tuple(str(ref).strip() for ref in self.subject_refs if str(ref).strip())
        if not subject_refs:
            raise ValueError("subject_refs must contain at least one subject reference")
        object.__setattr__(self, "subject_refs", subject_refs)

        observation = str(self.observation or "").strip()
        if not observation:
            raise ValueError("observation is required")
        object.__setattr__(self, "observation", observation)

        signal_kind = str(self.signal_kind or "residue").strip().lower() or "residue"
        if signal_kind not in {"residue", "pollen"}:
            raise ValueError("signal_kind must be 'residue' or 'pollen'")
        object.__setattr__(self, "signal_kind", signal_kind)

        status = str(self.status or "active").strip().lower() or "active"
        if status not in {"active", "retracted", "superseded"}:
            raise ValueError("status must be 'active', 'retracted', or 'superseded'")
        object.__setattr__(self, "status", status)

    @property
    def primary_subject_ref(self) -> str:
        return self.subject_refs[0]

    def computed_expires_at(self) -> str | None:
        ttl_seconds = self.label.ttl_seconds
        if ttl_seconds is None:
            return None
        observed_dt = parse_timestamp(self.label.observed_at) or utc_now()
        return to_utc_iso(observed_dt + timedelta(seconds=max(int(ttl_seconds), 0)))

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["subject_refs"] = list(self.subject_refs)
        payload["label"] = self.label.to_dict()
        payload["expires_at"] = self.computed_expires_at()
        return payload


class ResidueService:
    """Landing surface for future residue/pollen machinery.

    This is intentionally not a full memory system. It provides a truthful local
    ledger for small observation grains so future Pollen functionality has a
    stable place to land without contaminating live identity, presence, or work
    truth.
    """

    def __init__(self, db: WhispersDB):
        self.db = db

    def record(self, grain: ResidueGrain) -> dict[str, Any]:
        expires_at = grain.computed_expires_at()
        self.db.store_residue_grain(
            grain_id=grain.grain_id,
            signal_kind=grain.signal_kind,
            axis=grain.axis,
            primary_subject_ref=grain.primary_subject_ref,
            subject_refs=list(grain.subject_refs),
            observation=grain.observation,
            basis=grain.label.basis,
            confidence=grain.label.confidence,
            observed_at=grain.label.observed_at,
            observed_by=grain.label.observed_by,
            ttl_seconds=grain.label.ttl_seconds,
            expires_at=expires_at,
            negative_states=list(grain.label.negative_states),
            challengeable=grain.label.challengeable,
            spread=grain.spread,
            space_id=grain.space_id,
            work_id=grain.work_id,
            source_message_id=grain.source_message_id,
            source_artifact_id=grain.source_artifact_id,
            metadata=grain.metadata,
            status=grain.status,
            supersedes_grain_id=grain.supersedes_grain_id,
        )
        stored = self.db.get_residue_grain(grain.grain_id)
        return stored or grain.to_dict()

    def list(
        self,
        *,
        signal_kind: str | None = None,
        axis: str | None = None,
        subject_ref: str | None = None,
        space_id: str | None = None,
        work_id: str | None = None,
        include_expired: bool = False,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        return self.db.list_residue_grains(
            signal_kind=signal_kind,
            axis=axis,
            subject_ref=subject_ref,
            space_id=space_id,
            work_id=work_id,
            include_expired=include_expired,
            limit=limit,
        )

    def reap_expired(self) -> int:
        return self.db.reap_expired_residue_grains()


# ---------------------------------------------------------------------------
# Auto-detection layer — plan-Phase-2 Slice 7 follow-on
# ---------------------------------------------------------------------------
#
# detect_residue scans recent message traffic for recurring themes and
# returns them as lightweight residue entries. Complements the storage-
# focused ResidueService above: the service gives you a ledger for
# operator-asserted grains, detect_residue surfaces *observed* patterns
# that have not been explicitly recorded.
#
# Minimal implementation: word + bigram frequency across recent subjects
# and body previews, stopword-filtered, scope-local to the caller.

import re as _re
import sqlite3 as _sqlite3
from collections import Counter as _Counter


# Conservative English stopword list. Small on purpose — we filter noise,
# not meaning. Domain-specific words (e.g., "bind", "wake", "slice") stay
# even though they're frequent in Whispers traffic.
_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "of", "to", "for", "in", "on",
    "at", "by", "with", "from", "up", "about", "into", "over", "after",
    "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
    "do", "does", "did", "will", "would", "should", "could", "may", "might",
    "must", "shall", "can", "cannot", "this", "that", "these", "those",
    "i", "me", "my", "we", "us", "our", "you", "your", "he", "him", "his",
    "she", "her", "it", "its", "they", "them", "their",
    "re", "fw", "fyi",
    "not", "no", "yes", "ok",
    "any", "all", "each", "every", "some", "few",
    "other", "such", "only", "own", "same",
    "just", "very", "more", "most", "much", "less", "least",
    "than", "then", "now", "here", "there", "where", "when", "why", "how",
    "so", "if", "as", "also", "too", "one", "two", "get", "got",
})

_WORD_RE = _re.compile(r"[A-Za-z0-9][A-Za-z0-9\-_]*")


def _tokenize_for_residue(text: str) -> list[str]:
    if not text:
        return []
    tokens = _WORD_RE.findall(text.lower())
    # Keep any token that contains a digit (e.g., "10", "v2") OR is 3+ chars.
    # Stopword filter handles the short-noise case.
    kept: list[str] = []
    for t in tokens:
        if t in _STOPWORDS:
            continue
        if len(t) >= 3 or any(ch.isdigit() for ch in t):
            kept.append(t)
    return kept


def _bigrams_for_residue(tokens: list[str]) -> list[tuple[str, str]]:
    return list(zip(tokens, tokens[1:]))


def detect_residue(
    *,
    db_path: str,
    self_callsign: str,
    window_days: int = 7,
    min_repetitions: int = 3,
    limit: int = 10,
) -> list[dict[str, Any]]:
    """Return residue patterns — phrases/themes repeated across the
    caller's recent messages.

    Args:
        db_path: Path to the Whispers SQLite DB.
        self_callsign: Residue is scope-local to this callsign; only
            messages where self is sender OR recipient contribute.
        window_days: How far back to scan (default 7).
        min_repetitions: Minimum distinct-message occurrences for a
            phrase to surface (default 3).
        limit: Max residue entries returned (default 10).

    Returns:
        List of {pattern, pattern_count, noticed_at, basis, challengeable}
        sorted by count descending.
    """
    normalized_self = (self_callsign or "").strip().lower()
    if not normalized_self:
        return []

    now = utc_now()
    as_of = to_utc_iso(now)
    cutoff_sql = f"datetime('now', '-{int(window_days)} days')"

    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        rows = conn.execute(
            f"SELECT subject, body, from_agent, to_agent, created_at FROM messages "
            f"WHERE created_at >= {cutoff_sql} "
            f"AND (from_agent=? OR to_agent=?)",
            (normalized_self, normalized_self),
        ).fetchall()
    finally:
        conn.close()

    if not rows:
        return []

    word_counts: _Counter[str] = _Counter()
    bigram_counts: _Counter[tuple[str, str]] = _Counter()
    first_seen: dict[str, str] = {}
    for row in rows:
        text = " ".join(filter(None, [row["subject"], (row["body"] or "")[:200]]))
        tokens = _tokenize_for_residue(text)
        created = row["created_at"] or as_of
        for t in set(tokens):
            word_counts[t] += 1
            if t not in first_seen or created < first_seen[t]:
                first_seen[t] = created
        for bg in set(_bigrams_for_residue(tokens)):
            bigram_counts[bg] += 1
            key = f"{bg[0]} {bg[1]}"
            if key not in first_seen or created < first_seen[key]:
                first_seen[key] = created

    residue: list[dict[str, Any]] = []
    # Bigrams first — they carry more meaning than bare words.
    for (w1, w2), count in bigram_counts.most_common():
        if count < min_repetitions:
            continue
        pattern = f"{w1} {w2}"
        residue.append({
            "pattern": pattern,
            "pattern_count": int(count),
            "noticed_at": first_seen.get(pattern) or as_of,
            "basis": "observed",
            "challengeable": True,
        })
        # Suppress single-word dupes now that the bigram covers them.
        word_counts.pop(w1, None)
        word_counts.pop(w2, None)

    for word, count in word_counts.most_common():
        if count < min_repetitions:
            continue
        residue.append({
            "pattern": word,
            "pattern_count": int(count),
            "noticed_at": first_seen.get(word) or as_of,
            "basis": "observed",
            "challengeable": True,
        })

    residue.sort(key=lambda r: (-r["pattern_count"], r["pattern"]))
    return residue[:limit]
