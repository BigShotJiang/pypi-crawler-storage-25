import logging
import uuid
import json
from dataclasses import dataclass
from typing import Optional, Dict, Any

from .capability_provenance import CapabilityClaim
from .composition import CompositionEdge
from .participant_semantics import (
    VALID_AGENCY_RELATIONS,
    VALID_BOUNDARY_PROVENANCE,
    VALID_INTERACTION_ASKS,
    VALID_PARTICIPANT_KINDS,
    VALID_PARTICIPANT_SHAPES,
    VALID_RECOGNITION_BASIS,
)
from .trust_baseline import baseline_trust_tier, _BASELINE_TRUST_TIERS

logger = logging.getLogger(__name__)


# Namespace UUID for baseline anchor agent_ids. Computed once via
# uuid.uuid5(uuid.NAMESPACE_DNS, "whispers.baseline-anchors.v1") and locked
# as a literal so two implementations of provision_baseline_anchors() always
# produce the same agent_id for the same callsign across restarts and across
# independent implementations. DO NOT regenerate this value — that would
# orphan every previously-provisioned baseline anchor row.
#
# See .planning/SLICE-PF9-BUG-A-TRUST-INHERITANCE-2026-04-07.md §1.3.1.
BASELINE_ANCHOR_NS = uuid.UUID("e831ef03-7bc8-50da-93e3-dbb920ddbdff")

VALID_REACHABILITY_MODES = {
    "listener_backed",
    "manual_wake",
    "operator_console",
    "gatewayed",
    "event_emit_only",
    "read_only_status",
    "mixed",
    "unknown",
}

_DESCRIPTOR_JSON_FIELDS = (
    "interaction_asks",
    "capability_claims",
    "composition_hints",
)


def _normalize_optional_choice(value: Any, *, valid: set[str] | tuple[str, ...], label: str) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip().lower()
    valid_set = set(valid)
    if normalized not in valid_set:
        raise ValueError(f"Invalid {label} '{value}'. Expected one of: {', '.join(sorted(valid_set))}.")
    return normalized


def _normalize_interaction_asks(value: list[Any] | tuple[Any, ...] | None) -> str | None:
    if value is None:
        return None
    asks = [str(item).strip().lower() for item in value if str(item).strip()]
    invalid = [item for item in asks if item not in VALID_INTERACTION_ASKS]
    if invalid:
        raise ValueError(
            f"Invalid interaction asks {invalid}. Expected only: {', '.join(VALID_INTERACTION_ASKS)}."
        )
    return json.dumps(asks)


def _normalize_capability_claims(value: list[Any] | None) -> str | None:
    if value is None:
        return None
    claims: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, CapabilityClaim):
            claims.append(item.to_dict())
        elif isinstance(item, dict):
            claims.append(CapabilityClaim(**item).to_dict())
        else:
            raise ValueError("capability_claims entries must be dicts or CapabilityClaim instances")
    return json.dumps(claims)


def _normalize_composition_hints(value: list[Any] | None) -> str | None:
    if value is None:
        return None
    hints: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, CompositionEdge):
            hints.append(item.to_dict())
        elif isinstance(item, dict):
            hints.append(CompositionEdge(**item).to_dict())
        else:
            raise ValueError("composition_hints entries must be dicts or CompositionEdge instances")
    return json.dumps(hints)


def _decode_descriptor_json_fields(card: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(card)
    for field in _DESCRIPTOR_JSON_FIELDS:
        raw = normalized.get(field)
        if raw in {None, ""}:
            normalized[field] = [] if field == "interaction_asks" else []
            continue
        if isinstance(raw, str):
            try:
                normalized[field] = json.loads(raw)
            except Exception:
                normalized[field] = [] if field == "interaction_asks" else []
    return normalized


@dataclass(frozen=True)
class LinkResult:
    """Result of a sibling-instance link attempt.

    tier:  the resulting trust_tier of the new agent if inheritance happened
           (anchor existed AND anchor.trust_tier was not NULL); None otherwise.
    bound: True if the helper wrote new_callsign.instance_group on this call
           (which happens whenever the anchor row exists and is live, regardless
           of tier); False if no writes occurred (anchor row missing or
           tombstoned).

    The four observable outcomes:
      tier=int,  bound=True   → promoted (or no-downgrade kept higher tier)
      tier=None, bound=True   → grouped without tier promotion (anchor tier NULL)
      tier=None, bound=False  → no writes (anchor missing or tombstoned)
      (tier=int, bound=False is not a valid combination — the helper never
       inherits a tier without also setting instance_group)

    See .planning/SLICE-PF9-BUG-A-TRUST-INHERITANCE-2026-04-07.md §2.1.
    """
    tier: Optional[int]
    bound: bool


def provision_baseline_anchors(db) -> None:
    """Ensure every _BASELINE_TRUST_TIERS entry has a LIVE anchor row in agent_cards.

    Handles three cases per entry (callsign, baseline_tier):

    1. Row missing → INSERT a fresh live anchor row.
    2. Row exists but tombstoned (deregistered_at IS NOT NULL) → UPDATE to
       reactivate: SET deregistered_at = NULL, trust_tier = baseline_tier,
       instance_group = callsign, agent_type = COALESCE(agent_type, 'llm').
       Tier and group are explicitly re-asserted because a tombstoned row may
       carry stale values from a prior lifecycle.
    3. Row live (deregistered_at IS NULL) → NO-OP. Operator-managed bumps MUST
       survive the provisioning pass.

    Idempotent: repeated calls across server restarts are safe. Second and
    subsequent calls are no-ops for any entry that reached case 3 on a prior
    pass. Test 15 locks this contract.

    Row shape:
    - agent_id: deterministic UUID via uuid5(BASELINE_ANCHOR_NS, callsign).
      Same callsign always resolves to the same agent_id across restarts.
    - callsign: the _BASELINE_TRUST_TIERS key (e.g. "claude-code")
    - agent_type: "llm" as default for fresh INSERTs; preserved on reactivation.
    - trust_tier: _BASELINE_TRUST_TIERS[callsign]
    - instance_group: the callsign itself (self-reference)
    - lifecycle: "persistent"
    - registered_at: CURRENT_TIMESTAMP via column default on INSERT;
      unchanged on reactivation UPDATE
    - deregistered_at: NULL after provisioning

    See .planning/SLICE-PF9-BUG-A-TRUST-INHERITANCE-2026-04-07.md §1.3.1.
    """
    with db.get_connection() as conn:
        cursor = conn.cursor()
        for callsign, baseline_tier in _BASELINE_TRUST_TIERS.items():
            cursor.execute(
                "SELECT agent_id, deregistered_at FROM agent_cards WHERE callsign = ?",
                (callsign,),
            )
            row = cursor.fetchone()
            anchor_id = str(uuid.uuid5(BASELINE_ANCHOR_NS, callsign))

            if row is None:
                # Case 1: missing → INSERT
                cursor.execute(
                    """INSERT INTO agent_cards
                         (agent_id, callsign, agent_type, trust_tier,
                          instance_group, lifecycle)
                       VALUES (?, ?, 'llm', ?, ?, 'persistent')""",
                    (anchor_id, callsign, baseline_tier, callsign),
                )
                logger.info(
                    "[Whispers] Provisioned baseline anchor '%s' at tier %d",
                    callsign, baseline_tier,
                )
            elif row['deregistered_at'] is not None:
                # Case 2: tombstoned → UPDATE to reactivate
                cursor.execute(
                    """UPDATE agent_cards
                       SET deregistered_at = NULL,
                           trust_tier = ?,
                           instance_group = ?,
                           agent_type = COALESCE(agent_type, 'llm'),
                           lifecycle = 'persistent'
                       WHERE callsign = ?""",
                    (baseline_tier, callsign, callsign),
                )
                logger.info(
                    "[Whispers] Reactivated tombstoned baseline anchor '%s' at tier %d",
                    callsign, baseline_tier,
                )
            # Case 3: live → no-op (operator-managed state preserved)
        conn.commit()


class AgentRegistry:
    """Manages Agent setup, verification, and RBAC via agent_cards."""
    
    def __init__(self, db):
        self.db = db
        
    def get_agent_by_callsign(self, callsign: str) -> Optional[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL", (callsign,))
            row = cursor.fetchone()
            return _decode_descriptor_json_fields(dict(row)) if row else None

    def register(self, callsign: str, agent_type: str = "script", capabilities: list = None,
                 tools: list = None, can_send_system: bool = False,
                 model_id: str = None, display_name: str = None,
                 agent_tier: str = "full", max_receive_rate: int | None = None,
                 tags: list = None, owner_id: str = None) -> str:
        """Registers a new agent into the system or updates existing. Returns agent_id."""
        capabilities = capabilities or []
        tools = tools or []
        tags_json = json.dumps(tags) if tags is not None else None
        baseline_tier = baseline_trust_tier(
            callsign,
            agent_type=agent_type,
            display_name=display_name,
        ) or 1

        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            existing = cursor.execute(
                "SELECT * FROM agent_cards WHERE callsign = ?",
                (callsign,),
            ).fetchone()
            existing_agent_id = (str(existing["agent_id"]).strip() if existing else None)
            self.db.assert_callsign_available(
                callsign,
                ignore_agent_id=existing_agent_id,
                conn=conn,
            )

            if existing and not existing["deregistered_at"]:
                agent_id = existing['agent_id']
                cursor.execute(
                    '''UPDATE agent_cards
                       SET agent_type=?, capabilities=?, tools=?, can_send_system=?,
                           agent_tier=COALESCE(?, agent_tier), max_receive_rate=COALESCE(?, max_receive_rate),
                           model_id=COALESCE(?, model_id), display_name=COALESCE(?, display_name),
                           tags=COALESCE(?, tags), owner_id=COALESCE(?, owner_id),
                           trust_tier=CASE
                               WHEN COALESCE(trust_tier, 1) < ? THEN ?
                               ELSE trust_tier
                           END,
                           last_seen=CURRENT_TIMESTAMP
                       WHERE agent_id=?''',
                    (agent_type, json.dumps(capabilities), json.dumps(tools), can_send_system,
                     agent_tier, max_receive_rate, model_id, display_name, tags_json, owner_id,
                     baseline_tier, baseline_tier, agent_id)
                )
            else:
                if existing:
                    # Re-activate the deregistered agent
                    agent_id = existing['agent_id'] if hasattr(existing, '__getitem__') else existing[0]
                    cursor.execute(
                        '''UPDATE agent_cards
                           SET agent_type=?, capabilities=?, tools=?, can_send_system=?,
                               agent_tier=COALESCE(?, agent_tier), max_receive_rate=COALESCE(?, max_receive_rate),
                               model_id=?, display_name=?, deregistered_at=NULL,
                               owner_id=COALESCE(?, owner_id),
                               trust_tier=CASE
                                   WHEN COALESCE(trust_tier, 1) < ? THEN ?
                                   ELSE trust_tier
                               END,
                               last_seen=CURRENT_TIMESTAMP
                           WHERE callsign=?''',
                        (agent_type, json.dumps(capabilities), json.dumps(tools), can_send_system,
                         agent_tier, max_receive_rate, model_id, display_name, owner_id,
                         baseline_tier, baseline_tier, callsign)
                    )
                else:
                    agent_id = str(uuid.uuid4())
                    cursor.execute(
                        '''INSERT INTO agent_cards (agent_id, callsign, agent_type, trust_tier, agent_tier, max_receive_rate, capabilities, tools, can_send_system, model_id, display_name, tags, owner_id)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (agent_id, callsign, agent_type, baseline_tier, agent_tier, max_receive_rate,
                         json.dumps(capabilities), json.dumps(tools), can_send_system, model_id, display_name, tags_json, owner_id)
                    )
                    # Generate Ed25519 keypair for new agent
                    try:
                        from .identity import generate_and_store_keypair
                        pub_b64, fingerprint = generate_and_store_keypair(agent_id)
                        # Set public key and auto-promote signing enforcement for keyed full-tier agents
                        enforcement = "require" if agent_tier == "full" else "warn_only"
                        cursor.execute(
                            "UPDATE agent_cards SET public_key = ?, signing_enforcement = ? WHERE agent_id = ?",
                            (pub_b64, enforcement, agent_id),
                        )
                        logger.info("Ed25519 identity created for %s: %s (enforcement=%s)", callsign, fingerprint, enforcement)
                    except Exception as exc:
                        logger.warning("Failed to generate Ed25519 key for %s: %s", callsign, exc)

            # T4.11: Populate capabilities_verified from trust-tier baseline
            try:
                from .trust_baseline import baseline_capabilities
                row = cursor.execute(
                    "SELECT trust_tier FROM agent_cards WHERE agent_id = ?",
                    (agent_id,),
                ).fetchone()
                if row:
                    tier = int(row["trust_tier"] if row["trust_tier"] is not None else 1)
                    caps = baseline_capabilities(tier)
                    # Also sync can_send_flash from baseline
                    cursor.execute(
                        "UPDATE agent_cards SET capabilities_verified = ?, can_send_flash = ? WHERE agent_id = ?",
                        (json.dumps(caps), caps.get("can_send_flash", True), agent_id),
                    )
            except Exception as exc:
                logger.warning("capabilities_verified population skipped for %s: %s", callsign, exc)

            # Ensure a presence row exists
            cursor.execute('''INSERT OR IGNORE INTO presence (agent_name) VALUES (?)''', (callsign,))
            conn.commit()
            return agent_id

    def update_descriptor(
        self,
        callsign: str,
        *,
        participant_kind: str | None = None,
        participant_shape: str | None = None,
        agency_relation: str | None = None,
        boundary_provenance: str | None = None,
        recognition_basis: str | None = None,
        reachability_mode: str | None = None,
        interaction_asks: list[Any] | tuple[Any, ...] | None = None,
        capability_claims: list[Any] | None = None,
        composition_hints: list[Any] | None = None,
    ) -> dict[str, Any]:
        participant_kind = _normalize_optional_choice(participant_kind, valid=VALID_PARTICIPANT_KINDS, label="participant_kind")
        participant_shape = _normalize_optional_choice(participant_shape, valid=VALID_PARTICIPANT_SHAPES, label="participant_shape")
        agency_relation = _normalize_optional_choice(agency_relation, valid=VALID_AGENCY_RELATIONS, label="agency_relation")
        boundary_provenance = _normalize_optional_choice(
            boundary_provenance,
            valid=VALID_BOUNDARY_PROVENANCE,
            label="boundary_provenance",
        )
        recognition_basis = _normalize_optional_choice(
            recognition_basis,
            valid=VALID_RECOGNITION_BASIS,
            label="recognition_basis",
        )
        reachability_mode = _normalize_optional_choice(
            reachability_mode,
            valid=VALID_REACHABILITY_MODES,
            label="reachability_mode",
        )
        interaction_asks_json = _normalize_interaction_asks(interaction_asks)
        capability_claims_json = _normalize_capability_claims(capability_claims)
        composition_hints_json = _normalize_composition_hints(composition_hints)

        assignments: list[str] = []
        params: list[Any] = []
        for column, value in (
            ("participant_kind", participant_kind),
            ("participant_shape", participant_shape),
            ("agency_relation", agency_relation),
            ("boundary_provenance", boundary_provenance),
            ("recognition_basis", recognition_basis),
            ("reachability_mode", reachability_mode),
            ("interaction_asks", interaction_asks_json),
            ("capability_claims", capability_claims_json),
            ("composition_hints", composition_hints_json),
        ):
            if value is None:
                continue
            assignments.append(f"{column} = ?")
            params.append(value)

        if not assignments:
            card = self.get_agent_by_callsign(callsign)
            if not card:
                raise ValueError(f"Agent {callsign} not found.")
            return card

        assignments.append("last_seen = CURRENT_TIMESTAMP")
        params.append(callsign)

        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"UPDATE agent_cards SET {', '.join(assignments)} WHERE callsign = ? AND deregistered_at IS NULL",
                params,
            )
            if cursor.rowcount == 0:
                raise ValueError(f"Agent {callsign} not found.")
            row = cursor.execute(
                "SELECT * FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
                (callsign,),
            ).fetchone()
            conn.commit()
            return _decode_descriptor_json_fields(dict(row)) if row else {}

    def can_send_system(self, callsign: str) -> bool:
        agent = self.get_agent_by_callsign(callsign)
        if not agent:
            # Fallback logic for legacy agents if they exist during migration
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                try:
                    cursor.execute("SELECT can_send_system FROM agent_cards WHERE callsign = ?", (callsign,))
                    row = cursor.fetchone()
                    return bool(row[0]) if row else False
                except Exception:
                    pass
            return False
        return bool(agent.get("can_send_system"))

    def link_sibling_instance(
        self,
        new_callsign: str,
        *,
        anchor_callsign: str,
    ) -> LinkResult:
        """Link a new sibling into an instance_group and inherit trust from anchor.

        Called AFTER `register(new_callsign, ...)` has created the new agent_cards
        row at its type baseline. This method performs the sibling-group binding
        and any trust-tier promotion.

        Semantics (locked per stitch round 6 confirmation on v2.5):

        1. Self-link guard: if new_callsign == anchor_callsign, raise ValueError.
        2. Anchor lookup: SELECT trust_tier FROM agent_cards WHERE callsign =
           anchor_callsign AND deregistered_at IS NULL. Deregistered/tombstoned
           anchors are NOT eligible.
        3. Missing/tombstoned anchor → return LinkResult(tier=None, bound=False)
           immediately. NO writes. With v2.1 anchor-row provisioning in place
           (provision_baseline_anchors), this branch only fires for unknown
           agent_type values that have no entry in _BASELINE_TRUST_TIERS.
        4. Pre-bound conflict guard: if new_callsign already has a non-NULL
           instance_group AND it differs from anchor_callsign, raise ValueError.
           (Same-anchor reentry is idempotent and allowed — see Test 11b.)
        5. Set instance_group = anchor_callsign on new_callsign. Binding always
           happens when guards pass, even if trust inheritance does not (NULL
           anchor tier case).
        6. Read anchor's current trust_tier from the SELECT in step 2. If anchor
           tier is not NULL AND new agent's current trust_tier < anchor's:
           UPDATE new agent's trust_tier to anchor's. Never downgrade. Never
           synthesize a fallback tier.
        7. Single transaction: both writes (instance_group + optional
           trust_tier) commit together or roll back together.

        Returns:
            LinkResult(tier=int, bound=True) — anchor row exists AND has a
                non-NULL trust_tier. instance_group is written; trust_tier is
                promoted to anchor's tier OR left at the higher existing value
                in the no-downgrade case. `tier` is the resulting trust_tier.
            LinkResult(tier=None, bound=True) — anchor row exists but has NULL
                trust_tier. instance_group IS written; trust_tier is left at
                baseline (no synthesis).
            LinkResult(tier=None, bound=False) — anchor row missing or
                tombstoned. NO writes occur.

        Raises:
            ValueError if new_callsign == anchor_callsign (self-link guard).
            ValueError if new_callsign does not exist in agent_cards (caller
                must call register() first).
            ValueError if new_callsign already has a non-NULL instance_group
                that differs from anchor_callsign (pre-bound conflict guard).

        See .planning/SLICE-PF9-BUG-A-TRUST-INHERITANCE-2026-04-07.md §2.1.
        """
        # Step 1: self-link guard
        if new_callsign == anchor_callsign:
            raise ValueError(
                f"link_sibling_instance: self-link is not allowed "
                f"(new_callsign and anchor_callsign are both {new_callsign!r})"
            )

        with self.db.get_connection() as conn:
            cursor = conn.cursor()

            # Step 2: anchor lookup (deregistered/tombstoned anchors NOT eligible)
            cursor.execute(
                "SELECT trust_tier FROM agent_cards "
                "WHERE callsign = ? AND deregistered_at IS NULL",
                (anchor_callsign,),
            )
            anchor_row = cursor.fetchone()

            # Step 3: missing/tombstoned anchor → no writes, no inheritance
            if anchor_row is None:
                return LinkResult(tier=None, bound=False)

            anchor_tier = anchor_row['trust_tier']

            # Verify the new agent exists (must have been register()'d first)
            cursor.execute(
                "SELECT trust_tier, instance_group FROM agent_cards "
                "WHERE callsign = ? AND deregistered_at IS NULL",
                (new_callsign,),
            )
            new_row = cursor.fetchone()
            if new_row is None:
                raise ValueError(
                    f"link_sibling_instance: new_callsign {new_callsign!r} "
                    f"does not exist in agent_cards (caller must call "
                    f"register() first)"
                )

            new_tier = new_row['trust_tier']
            existing_group = new_row['instance_group']

            # Step 4: pre-bound conflict guard
            # (Same-anchor reentry is allowed — only DIFFERENT anchor raises.)
            if existing_group is not None and existing_group != anchor_callsign:
                raise ValueError(
                    f"link_sibling_instance: {new_callsign!r} is already bound "
                    f"to instance_group {existing_group!r}, cannot rebind to "
                    f"{anchor_callsign!r}"
                )

            # Step 5: set instance_group (single transaction with optional tier update)
            cursor.execute(
                "UPDATE agent_cards SET instance_group = ? WHERE callsign = ?",
                (anchor_callsign, new_callsign),
            )

            # Step 6: trust_tier inheritance (no downgrade, no synthesis)
            resulting_tier: Optional[int]
            if anchor_tier is None:
                # NULL anchor tier → grouping happened but no tier signal exists
                resulting_tier = None
            else:
                if new_tier is None or new_tier < anchor_tier:
                    # Promote to anchor's tier
                    cursor.execute(
                        "UPDATE agent_cards SET trust_tier = ? WHERE callsign = ?",
                        (anchor_tier, new_callsign),
                    )
                    resulting_tier = anchor_tier
                else:
                    # No-downgrade: keep the higher existing tier
                    resulting_tier = new_tier

            conn.commit()

            return LinkResult(tier=resulting_tier, bound=True)
