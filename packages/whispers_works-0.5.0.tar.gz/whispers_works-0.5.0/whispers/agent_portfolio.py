from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class AgentPortfolioEntry:
    agent: str
    declared_competencies: tuple[str, ...] = field(default_factory=tuple)
    observed_competencies: tuple[str, ...] = field(default_factory=tuple)
    cost_tier: str | None = None  # low, medium, high, or unknown
    latency_tier: str | None = None  # fast, medium, slow, or unknown
    surfaces: tuple[str, ...] = field(default_factory=tuple)
    attached_resources: tuple[str, ...] = field(default_factory=tuple)
    observed_effectiveness: float | None = None


@dataclass(frozen=True)
class PortfolioNoveltyAssessment:
    agent: str
    novelty_kinds: tuple[str, ...]
    differentiators: tuple[str, ...]
    open_questions: tuple[str, ...]


def assess_portfolio_novelty(
    candidate: AgentPortfolioEntry,
    existing: list[AgentPortfolioEntry],
) -> PortfolioNoveltyAssessment:
    novelty: list[str] = []
    differentiators: list[str] = []
    open_questions: list[str] = []

    known_declared = {item for entry in existing for item in entry.declared_competencies}
    known_observed = {item for entry in existing for item in entry.observed_competencies}
    known_surfaces = {item for entry in existing for item in entry.surfaces}
    known_resources = {item for entry in existing for item in entry.attached_resources}

    new_declared = [item for item in candidate.declared_competencies if item not in known_declared]
    new_observed = [item for item in candidate.observed_competencies if item not in known_observed]
    new_surfaces = [item for item in candidate.surfaces if item not in known_surfaces]
    new_resources = [item for item in candidate.attached_resources if item not in known_resources]

    if new_declared or new_observed:
        novelty.append("capability_novelty")
        differentiators.extend(new_declared + new_observed)

    if candidate.cost_tier in {"low", "medium", "high"}:
        existing_costs = {entry.cost_tier for entry in existing if entry.cost_tier}
        if candidate.cost_tier == "low" and "low" not in existing_costs:
            novelty.append("cost_advantage")
            differentiators.append("low_cost_tier")
    else:
        open_questions.append("cost profile unknown")

    if candidate.latency_tier in {"fast", "medium", "slow"}:
        existing_latencies = {entry.latency_tier for entry in existing if entry.latency_tier}
        if candidate.latency_tier == "fast" and "fast" not in existing_latencies:
            novelty.append("latency_advantage")
            differentiators.append("fast_latency_tier")
    else:
        open_questions.append("latency profile unknown")

    if new_surfaces:
        novelty.append("surface_novelty")
        differentiators.extend(f"surface:{item}" for item in new_surfaces)

    if new_resources:
        novelty.append("resource_novelty")
        differentiators.extend(f"resource:{item}" for item in new_resources)

    if candidate.observed_effectiveness is None:
        open_questions.append("effectiveness unproven")
    if not candidate.observed_competencies:
        open_questions.append("observed competencies not established")

    if not novelty and not differentiators:
        novelty.append("no_clear_differentiator_yet")

    return PortfolioNoveltyAssessment(
        agent=candidate.agent,
        novelty_kinds=tuple(dict.fromkeys(novelty)),
        differentiators=tuple(dict.fromkeys(differentiators)),
        open_questions=tuple(dict.fromkeys(open_questions)),
    )
