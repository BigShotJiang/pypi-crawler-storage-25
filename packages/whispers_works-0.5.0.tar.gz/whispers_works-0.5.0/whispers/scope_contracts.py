from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping


VALID_SCOPE_RELATIONSHIPS = {"same", "narrower", "wider", "cross", "unset"}


@dataclass(frozen=True)
class WorkingScopeContract:
    scope_name: str
    description: str | None = None
    parent_scope: str | None = None
    policy_hint: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ScopeRelationship:
    relation: str
    source_scope: str | None
    target_scope: str | None

    def __post_init__(self) -> None:
        if self.relation not in VALID_SCOPE_RELATIONSHIPS:
            raise ValueError(
                f"Invalid scope relationship '{self.relation}'. "
                f"Expected one of: {', '.join(sorted(VALID_SCOPE_RELATIONSHIPS))}."
            )

    @property
    def changed(self) -> bool:
        return self.relation not in {"same", "unset"}

    @property
    def widening(self) -> bool:
        return self.relation in {"wider", "cross"}


def _normalize_optional_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def normalize_working_scope_contract(raw: str | Mapping[str, Any] | WorkingScopeContract | None) -> WorkingScopeContract | None:
    if raw is None:
        return None
    if isinstance(raw, WorkingScopeContract):
        return raw
    if isinstance(raw, str):
        scope_name = _normalize_optional_text(raw)
        if scope_name is None:
            return None
        return WorkingScopeContract(scope_name=scope_name)
    if not isinstance(raw, Mapping):
        raise ValueError("working scope contract must be a string, object, or WorkingScopeContract")

    scope_name = _normalize_optional_text(raw.get("scope_name") or raw.get("name"))
    if scope_name is None:
        raise ValueError("working scope contract requires scope_name")

    return WorkingScopeContract(
        scope_name=scope_name,
        description=_normalize_optional_text(raw.get("description")),
        parent_scope=_normalize_optional_text(raw.get("parent_scope")),
        policy_hint=_normalize_optional_text(raw.get("policy_hint")),
    )


def serialize_working_scope_contract(raw: str | Mapping[str, Any] | WorkingScopeContract | None) -> dict[str, Any] | None:
    contract = normalize_working_scope_contract(raw)
    if contract is None:
        return None
    return contract.to_dict()


def _lineage_map(
    contracts: Mapping[str, WorkingScopeContract | Mapping[str, Any] | str] | None,
) -> dict[str, WorkingScopeContract]:
    normalized: dict[str, WorkingScopeContract] = {}
    if not contracts:
        return normalized
    for key, value in contracts.items():
        contract = normalize_working_scope_contract(value)
        if contract is None:
            continue
        normalized[contract.scope_name] = contract
        normalized[str(key).strip()] = contract
    return normalized


def _has_ancestor(
    scope_name: str,
    ancestor_name: str,
    *,
    contracts: Mapping[str, WorkingScopeContract | Mapping[str, Any] | str] | None = None,
) -> bool:
    registry = _lineage_map(contracts)
    current = registry.get(scope_name)
    seen: set[str] = set()
    while current and current.parent_scope and current.parent_scope not in seen:
        if current.parent_scope == ancestor_name:
            return True
        seen.add(current.parent_scope)
        current = registry.get(current.parent_scope)
    return False


def compare_working_scopes(
    source: str | Mapping[str, Any] | WorkingScopeContract | None,
    target: str | Mapping[str, Any] | WorkingScopeContract | None,
    *,
    contracts: Mapping[str, WorkingScopeContract | Mapping[str, Any] | str] | None = None,
) -> ScopeRelationship:
    source_contract = normalize_working_scope_contract(source)
    target_contract = normalize_working_scope_contract(target)

    source_name = source_contract.scope_name if source_contract else None
    target_name = target_contract.scope_name if target_contract else None

    if source_name is None or target_name is None:
        return ScopeRelationship("unset", source_name, target_name)
    if source_name == target_name:
        return ScopeRelationship("same", source_name, target_name)
    if _has_ancestor(target_name, source_name, contracts=contracts):
        return ScopeRelationship("narrower", source_name, target_name)
    if _has_ancestor(source_name, target_name, contracts=contracts):
        return ScopeRelationship("wider", source_name, target_name)
    return ScopeRelationship("cross", source_name, target_name)
