from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class TaskFitRequest:
    required_strengths: tuple[str, ...] = field(default_factory=tuple)
    preferred_strengths: tuple[str, ...] = field(default_factory=tuple)
    quality_bar: str = "standard"  # standard, high
    urgency: str = "routine"  # routine, priority, flash
    max_cost_tier: str | None = None  # low, medium, high
    preserve_strong_models: bool = False


@dataclass(frozen=True)
class AgentCoordinationProfile:
    agent: str
    strengths: tuple[str, ...] = field(default_factory=tuple)
    cost_tier: str = "medium"  # low, medium, high
    effectiveness: float = 0.5  # 0.0-1.0 observed/supplied fit effectiveness
    current_capacity: float = 1.0  # 0.0-1.0
    context_load: float | None = None  # 0.0-1.0
    quality_risk: str | None = None  # low, medium, high
    interruptibility: str | None = None
    eligible: bool = True
    ineligibility_reason: str | None = None


@dataclass(frozen=True)
class FitAssessment:
    agent: str
    eligible: bool
    score: float
    fit_band: str
    reasons: tuple[str, ...]


_COST_RANK = {"low": 0, "medium": 1, "high": 2}


def _cost_allowed(cost_tier: str, max_cost_tier: str | None) -> bool:
    if max_cost_tier is None:
        return True
    return _COST_RANK[cost_tier] <= _COST_RANK[max_cost_tier]


def assess_agent_fit(profile: AgentCoordinationProfile, request: TaskFitRequest) -> FitAssessment:
    reasons: list[str] = []
    if not profile.eligible:
        reasons.append(profile.ineligibility_reason or "not eligible")
        return FitAssessment(profile.agent, False, 0.0, "blocked", tuple(reasons))

    if not _cost_allowed(profile.cost_tier, request.max_cost_tier):
        reasons.append("exceeds cost tier budget")
        return FitAssessment(profile.agent, False, 0.0, "blocked", tuple(reasons))

    strengths = {item.strip().lower() for item in profile.strengths if item.strip()}
    required = {item.strip().lower() for item in request.required_strengths if item.strip()}
    preferred = {item.strip().lower() for item in request.preferred_strengths if item.strip()}

    missing_required = sorted(required - strengths)
    if missing_required:
        reasons.append(f"missing required strengths: {', '.join(missing_required)}")
        return FitAssessment(profile.agent, False, 0.0, "blocked", tuple(reasons))

    score = 0.0

    if required:
        reasons.append("meets required strengths")
        score += 0.35

    preferred_matches = len(preferred & strengths)
    if preferred and preferred_matches:
        reasons.append(f"matches {preferred_matches} preferred strengths")
        score += min(preferred_matches * 0.12, 0.24)

    effectiveness = max(0.0, min(profile.effectiveness, 1.0))
    score += effectiveness * 0.25
    reasons.append(f"effectiveness={effectiveness:.2f}")

    capacity = max(0.0, min(profile.current_capacity, 1.0))
    score += capacity * 0.1
    reasons.append(f"capacity={capacity:.2f}")

    load = profile.context_load if isinstance(profile.context_load, (int, float)) else None
    if load is not None:
        bounded_load = max(0.0, min(float(load), 1.0))
        score += max(0.0, 0.1 - bounded_load * 0.1)
        reasons.append(f"context_load={bounded_load:.2f}")

    if profile.quality_risk == "high":
        score -= 0.25
        reasons.append("high quality risk")
    elif profile.quality_risk == "medium":
        score -= 0.1
        reasons.append("medium quality risk")

    if request.quality_bar == "high" and profile.cost_tier == "high":
        score += 0.08
        reasons.append("high quality bar justifies strong model")
    elif request.preserve_strong_models and profile.cost_tier == "high":
        score -= 0.12
        reasons.append("preserve strong models for higher-value work")
    elif request.max_cost_tier == "low" and profile.cost_tier == "low":
        score += 0.05
        reasons.append("fits low-cost preference")

    if request.urgency == "flash" and profile.interruptibility == "do_not_interrupt":
        score -= 0.08
        reasons.append("currently expensive to interrupt")

    score = max(0.0, min(score, 1.0))

    if score >= 0.75:
        band = "strong"
    elif score >= 0.5:
        band = "good"
    elif score >= 0.25:
        band = "weak"
    else:
        band = "poor"

    return FitAssessment(profile.agent, True, score, band, tuple(reasons))


def rank_agents_for_task(
    profiles: list[AgentCoordinationProfile],
    request: TaskFitRequest,
) -> list[FitAssessment]:
    assessments = [assess_agent_fit(profile, request) for profile in profiles]
    return sorted(
        assessments,
        key=lambda item: (item.eligible, item.score),
        reverse=True,
    )
