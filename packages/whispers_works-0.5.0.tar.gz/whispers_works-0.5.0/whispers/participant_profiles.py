from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .capability_provenance import CapabilityClaim
from .composition import CompositionEdge


_SELF_BACKED_PROVENANCE = {"native", "embodied"}
_BOUNDARY_DEPENDENT_PROVENANCE = {"delegated", "attached", "borrowed", "reachable"}


_REACHABILITY_PROJECTION = {
    "listener_backed": "reachable through a listener",
    "manual_wake": "reachable by manual wake",
    "operator_console": "reachable through an operator console",
    "gatewayed": "reachable through a gateway",
    "event_emit_only": "emits events but is not directly wakeable",
    "read_only_status": "visible as read-only status",
    "mixed": "reachable through mixed paths",
    "unknown": "with unknown reachability",
}


@dataclass(frozen=True)
class ParticipantBringInProfile:
    name: str
    participant_kind: str
    participant_shape: str
    agency_relation: str
    boundary_provenance: str
    recognition_basis: str
    reachability_mode: str
    interaction_asks: tuple[str, ...] = field(default_factory=tuple)
    capability_claims: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    composition_template: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    summary: str = ""

    def materialize(self, *, source: str) -> dict[str, Any]:
        claims = [CapabilityClaim(**claim).to_dict() for claim in self.capability_claims]
        composition_hints = []
        for item in self.composition_template:
            composition_hints.append(
                CompositionEdge(source=source, **item).to_dict()
            )
        return {
            "participant_kind": self.participant_kind,
            "participant_shape": self.participant_shape,
            "agency_relation": self.agency_relation,
            "boundary_provenance": self.boundary_provenance,
            "recognition_basis": self.recognition_basis,
            "reachability_mode": self.reachability_mode,
            "interaction_asks": list(self.interaction_asks),
            "capability_claims": claims,
            "composition_hints": composition_hints,
            "profile_summary": self.summary,
        }


_PROFILE_DEFINITIONS: dict[str, ParticipantBringInProfile] = {
    "desktop_ide_agent": ParticipantBringInProfile(
        name="desktop_ide_agent",
        participant_kind="host_bound_agent",
        participant_shape="atomic",
        agency_relation="self",
        boundary_provenance="self_asserted",
        recognition_basis="registration",
        reachability_mode="manual_wake",
        interaction_asks=("review", "handoff", "exchange"),
        capability_claims=(
            {"capability": "reason_about_code", "provenance_kind": "native", "basis": "declared"},
            {"capability": "workspace_io", "provenance_kind": "attached", "basis": "declared", "provider": "host:ide"},
        ),
        composition_template=(
            {"relation": "attached_to", "target": "host:ide", "basis": "declared"},
            {"relation": "hosted_by", "target": "host:desktop", "basis": "declared"},
        ),
        summary="Prompt-bound desktop agent with local tools and manual wake posture.",
    ),
    "listener_agent": ParticipantBringInProfile(
        name="listener_agent",
        participant_kind="primary_agent",
        participant_shape="atomic",
        agency_relation="self",
        boundary_provenance="self_asserted",
        recognition_basis="registration",
        reachability_mode="listener_backed",
        interaction_asks=("inform", "exchange", "handoff"),
        capability_claims=(
            {"capability": "continuous_listen", "provenance_kind": "native", "basis": "declared"},
            {"capability": "autonomous_reply", "provenance_kind": "native", "basis": "declared", "durability": "conditional"},
        ),
        composition_template=(
            {"relation": "backed_by", "target": "runtime:listener", "basis": "declared"},
        ),
        summary="Listener-backed local agent able to remain reachable without manual wake.",
    ),
    "gateway_bridge": ParticipantBringInProfile(
        name="gateway_bridge",
        participant_kind="gateway",
        participant_shape="federated_facade",
        agency_relation="representative",
        boundary_provenance="jointly_asserted",
        recognition_basis="registration",
        reachability_mode="gatewayed",
        interaction_asks=("introduce", "exchange", "notify"),
        capability_claims=(
            {"capability": "bridge_external_system", "provenance_kind": "native", "basis": "declared"},
            {"capability": "relay_external_action", "provenance_kind": "delegated", "basis": "declared", "provider": "external:gateway"},
        ),
        composition_template=(
            {"relation": "backed_by", "target": "bridge:external-system", "basis": "declared"},
        ),
        summary="Bridge or gateway translating another system into Whispers.",
    ),
    "status_source": ParticipantBringInProfile(
        name="status_source",
        participant_kind="status_source",
        participant_shape="cored_envelope",
        agency_relation="instrument",
        boundary_provenance="observer_asserted",
        recognition_basis="observation",
        reachability_mode="event_emit_only",
        interaction_asks=("observe", "notify", "monitor"),
        capability_claims=(
            {"capability": "emit_observation", "provenance_kind": "embodied", "basis": "observed"},
        ),
        composition_template=(
            {"relation": "backed_by", "target": "source:status-feed", "basis": "observed"},
        ),
        summary="Status or sensor-like source that emits observations into the fabric.",
    ),
    "approval_surface": ParticipantBringInProfile(
        name="approval_surface",
        participant_kind="approval_surface",
        participant_shape="cored_envelope",
        agency_relation="representative",
        boundary_provenance="jointly_asserted",
        recognition_basis="operator_declaration",
        reachability_mode="operator_console",
        interaction_asks=("approve", "review", "notify"),
        capability_claims=(
            {"capability": "present_decision_request", "provenance_kind": "native", "basis": "declared"},
            {"capability": "human_decision", "provenance_kind": "reachable", "basis": "operator_declared", "provider": "operator"},
        ),
        composition_template=(
            {"relation": "present_within", "target": "surface:operator-console", "basis": "operator_declared"},
        ),
        summary="Human approval surface that can present requests and return operator decisions.",
    ),
}


PARTICIPANT_PROFILE_NAMES = tuple(sorted(_PROFILE_DEFINITIONS.keys()))


def _compact_list_label(values: list[str], *, limit: int = 3) -> str | None:
    normalized = [str(value).strip().replace("_", " ") for value in values if str(value).strip()]
    if not normalized:
        return None
    if len(normalized) <= limit:
        return ", ".join(normalized)
    return ", ".join(normalized[:limit]) + f", +{len(normalized) - limit} more"


def humanize_descriptor_token(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    return text.replace("_", " ")


def build_participant_profile(name: str, *, source: str) -> dict[str, Any]:
    normalized = str(name or "").strip().lower()
    if normalized not in _PROFILE_DEFINITIONS:
        raise ValueError(
            f"Unknown participant profile '{name}'. Expected one of: {', '.join(PARTICIPANT_PROFILE_NAMES)}."
        )
    return _PROFILE_DEFINITIONS[normalized].materialize(source=source)


def capability_posture(raw_claims: list[dict[str, Any]] | None) -> dict[str, Any]:
    claims = [dict(claim) for claim in list(raw_claims or [])]
    self_backed: list[dict[str, Any]] = []
    boundary_dependent: list[dict[str, Any]] = []
    unknown: list[dict[str, Any]] = []
    for claim in claims:
        provenance = str(claim.get("provenance_kind") or "").strip().lower()
        if provenance in _SELF_BACKED_PROVENANCE:
            self_backed.append(claim)
        elif provenance in _BOUNDARY_DEPENDENT_PROVENANCE:
            boundary_dependent.append(claim)
        else:
            unknown.append(claim)
    self_backed_capabilities = sorted({str(claim.get("capability") or "").strip() for claim in self_backed if str(claim.get("capability") or "").strip()})
    boundary_dependent_capabilities = sorted({str(claim.get("capability") or "").strip() for claim in boundary_dependent if str(claim.get("capability") or "").strip()})
    return {
        "self_backed_capabilities": self_backed_capabilities,
        "boundary_dependent_capabilities": boundary_dependent_capabilities,
        "unknown_capabilities": sorted({str(claim.get("capability") or "").strip() for claim in unknown if str(claim.get("capability") or "").strip()}),
        "self_backed_count": len(self_backed_capabilities),
        "boundary_dependent_count": len(boundary_dependent_capabilities),
        "self_backed_summary": _compact_list_label(self_backed_capabilities),
        "boundary_dependent_summary": _compact_list_label(boundary_dependent_capabilities),
    }


def assess_capability_requirements(card: dict[str, Any] | None, required_capabilities: list[str] | tuple[str, ...] | None) -> dict[str, Any]:
    normalized_required = []
    seen = set()
    for item in list(required_capabilities or []):
        capability = str(item or "").strip()
        if not capability or capability in seen:
            continue
        seen.add(capability)
        normalized_required.append(capability)

    claims = [dict(claim) for claim in list((card or {}).get("capability_claims") or [])]
    supported_self_backed: list[str] = []
    supported_with_boundary_dependency: list[dict[str, Any]] = []
    missing: list[str] = []

    for capability in normalized_required:
        matches = [claim for claim in claims if str(claim.get("capability") or "").strip() == capability]
        if any(str(claim.get("provenance_kind") or "").strip().lower() in _SELF_BACKED_PROVENANCE for claim in matches):
            supported_self_backed.append(capability)
            continue
        if matches:
            supported_with_boundary_dependency.append(
                {
                    "capability": capability,
                    "provenance_kinds": sorted(
                        {
                            str(claim.get("provenance_kind") or "").strip().lower()
                            for claim in matches
                            if str(claim.get("provenance_kind") or "").strip()
                        }
                    ),
                    "providers": sorted(
                        {
                            str(claim.get("provider") or "").strip()
                            for claim in matches
                            if str(claim.get("provider") or "").strip()
                        }
                    ),
                }
            )
            continue
        missing.append(capability)

    return {
        "required_capabilities": normalized_required,
        "supported_self_backed": supported_self_backed,
        "external_dependency_capabilities": supported_with_boundary_dependency,
        "missing_capabilities": missing,
        "all_self_backed": not supported_with_boundary_dependency and not missing,
    }


def participant_projection(card: dict[str, Any] | None, *, fallback_name: str | None = None) -> dict[str, Any]:
    record = dict(card or {})
    callsign = str(record.get("callsign") or fallback_name or "").strip() or None
    display_name = str(record.get("display_name") or "").strip() or None
    identity_label = display_name or callsign
    participant_kind = record.get("participant_kind")
    participant_shape = record.get("participant_shape")
    agency_relation = record.get("agency_relation")
    reachability_mode = record.get("reachability_mode")
    interaction_asks = list(record.get("interaction_asks") or [])
    capability_claims = list(record.get("capability_claims") or [])
    composition_hints = list(record.get("composition_hints") or [])
    posture = capability_posture(capability_claims)

    kind_phrase = humanize_descriptor_token(participant_kind)
    shape_phrase = humanize_descriptor_token(participant_shape)
    agency_phrase = humanize_descriptor_token(agency_relation)
    reachability_phrase = _REACHABILITY_PROJECTION.get(str(reachability_mode or "").strip().lower())

    summary_bits: list[str] = []
    if kind_phrase:
        article = "an" if kind_phrase[:1].lower() in {"a", "e", "i", "o", "u"} else "a"
        summary_bits.append(f"{article} {kind_phrase}")
    if reachability_phrase:
        summary_bits.append(reachability_phrase)
    if agency_phrase and agency_phrase != "self":
        summary_bits.append(f"acting as {agency_phrase}")
    if not summary_bits and identity_label:
        summary_bits.append(identity_label)

    asks_summary = _compact_list_label(interaction_asks)
    capsule_bits: list[str] = []
    if asks_summary:
        capsule_bits.append(f"usual asks: {asks_summary}")
    if posture.get("self_backed_summary"):
        capsule_bits.append(f"self-backed capabilities: {posture['self_backed_summary']}")
    if posture.get("boundary_dependent_summary"):
        capsule_bits.append(f"boundary-dependent capabilities: {posture['boundary_dependent_summary']}")

    return {
        "callsign": callsign,
        "display_name": display_name,
        "identity_label": identity_label,
        "participant_kind": participant_kind,
        "participant_shape": participant_shape,
        "agency_relation": agency_relation,
        "reachability_mode": reachability_mode,
        "interaction_asks": interaction_asks,
        "interaction_summary": asks_summary,
        "capability_claims": capability_claims,
        "capability_posture": posture,
        "composition_hints": composition_hints,
        "summary": ", ".join(summary_bits),
        "capsule_summary": "; ".join(capsule_bits),
        "shape_label": shape_phrase,
    }
