from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List

from .envelope import Envelope, Priority


@dataclass(frozen=True)
class DeliveryDecision:
    status: str
    reason: str | None = None



def classify_signal_protection(envelope: Envelope) -> str:
    if envelope.priority in {Priority.FLASH, Priority.SYSTEM}:
        return "protected"
    if envelope.priority == Priority.PRIORITY:
        return "degradable"
    return "deferrable"


class Dispatcher:
    """Minimal crawl-stage routing core.

    Fresh repo rule: only implement the kernel truth needed for the local
    embedded coordination floor.
    """

    def __init__(self, db):
        self.db = db
        self._transports: List[Callable[[Envelope], None]] = []

    def add_transport_listener(self, callback: Callable[[Envelope], None]) -> None:
        self._transports.append(callback)

    def _trust_tiers(self, sender: str, recipient: str) -> tuple[int, int]:
        with self.db.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT
                    ac.callsign,
                    COALESCE(
                        (
                            SELECT te.new_tier
                            FROM trust_events te
                            WHERE te.stable_subject_id = COALESCE(ac.stable_subject_id, ac.agent_id)
                            ORDER BY te.event_id DESC
                            LIMIT 1
                        ),
                        ac.trust_tier,
                        1
                    ) AS effective_trust_tier
                FROM agent_cards ac
                WHERE ac.callsign IN (?, ?)
                  AND ac.deregistered_at IS NULL
                """,
                (sender, recipient),
            ).fetchall()
            mapping = {row["callsign"]: int(row["effective_trust_tier"] if row["effective_trust_tier"] is not None else 1) for row in rows}
        return mapping.get(sender, 1), mapping.get(recipient, 1)

    def _recipient_exists(self, recipient: str) -> tuple[bool, str | None]:
        with self.db.get_connection() as conn:
            row = conn.execute(
                "SELECT agent_id FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
                (recipient,),
            ).fetchone()
            if not row:
                return False, None
            return True, row["agent_id"]

    def dead_letter(
        self,
        envelope: Envelope,
        reason: str,
        *,
        space_id: str | None = None,
        thread_id: str | None = None,
        context_id: str | None = None,
    ) -> DeliveryDecision:
        self.db.record_dead_letter(
            message_id=envelope.id,
            sender=envelope.sender,
            recipient=envelope.recipient,
            subject=envelope.subject,
            body=envelope.body,
            msg_type=envelope.msg_type.value,
            priority=envelope.priority.value,
            payload=envelope.payload,
            metadata=envelope.metadata,
            reason=reason,
            context_id=context_id if context_id is not None else envelope.context_id,
            space_id=space_id,
            thread_id=thread_id,
        )
        return DeliveryDecision(status="dead_lettered", reason=reason)

    def dispatch(
        self,
        envelope: Envelope,
        *,
        space_id: str | None = None,
        thread_id: str | None = None,
        context_id: str | None = None,
        sender_session_id: str | None = None,
        recipient_alias: str | None = None,
    ) -> str:
        resolved = self.db.resolve_callsign(envelope.recipient)
        if resolved and resolved.get("resolved_callsign") and resolved["resolved_callsign"] != envelope.recipient:
            recipient_alias = recipient_alias or envelope.recipient
            envelope.recipient = str(resolved["resolved_callsign"])
        exists, recipient_agent_id = self._recipient_exists(envelope.recipient)
        if not exists:
            return self.dead_letter(
                envelope,
                "recipient_not_found",
                space_id=space_id,
                thread_id=thread_id,
                context_id=context_id,
            ).status

        sender_tier, recipient_tier = self._trust_tiers(envelope.sender, envelope.recipient)
        if sender_tier < recipient_tier - 1:
            return self.dead_letter(
                envelope,
                f"trust_tier_violation:{sender_tier}->{recipient_tier}",
                space_id=space_id,
                thread_id=thread_id,
                context_id=context_id,
            ).status

        sender_card = self.db.get_agent_card(envelope.sender)
        delivery_status = self.db.record_delivery(
            message_id=envelope.id,
            sender=envelope.sender,
            sender_agent_id=sender_card.get("agent_id") if sender_card else None,
            sender_session_id=sender_session_id,
            recipient=envelope.recipient,
            recipient_agent_id=recipient_agent_id,
            subject=envelope.subject,
            body=envelope.body,
            msg_type=envelope.msg_type.value,
            priority=envelope.priority.value,
            payload=envelope.payload,
            metadata=envelope.metadata,
            reply_to=envelope.reply_to,
            trace_id=envelope.trace_id,
            context_id=context_id if context_id is not None else envelope.context_id,
            space_id=space_id,
            thread_id=thread_id,
            alias_snapshot=recipient_alias,
        )
        for callback in self._transports:
            callback(envelope)
        return delivery_status
