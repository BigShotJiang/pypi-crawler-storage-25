from __future__ import annotations

import contextlib
import html
import json
import logging
import os
import queue
import sqlite3
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from typing import Any

import uvicorn
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from .continuity import ContinuityConflictError, ContinuityService
from .coordination import CoordinationService
from .mcp_server import create_mcp
from .messaging import MessagingService
from .participant_kit import normalize_participant_profiles, prepare_signal_participant_card
from .participant_onboarding import build_participant_onboarding_kit, guided_profile_for_signal_profiles, supported_onboarding_profiles
from .participant_profiles import build_participant_profile, participant_projection
from .projection import build_operator_chrome
from .registry import AgentRegistry
from .session_identity import stable_session_id
from .spaces import SpaceService
from .storage.db import WhispersDB, WhispersDBError
from .time_utils import utc_now_iso
from .trust import TrustService
from .twoack import build_status_envelope
from .wake_runtime import build_wake_projection


logger = logging.getLogger(__name__)


class _WakeEventBroker:
    def __init__(self) -> None:
        self._subscribers: dict[str, list[queue.Queue[dict[str, Any]]]] = {}

    def subscribe(self, agent_name: str) -> queue.Queue[dict[str, Any]]:
        subscriber: queue.Queue[dict[str, Any]] = queue.Queue()
        self._subscribers.setdefault(agent_name, []).append(subscriber)
        return subscriber

    def unsubscribe(self, agent_name: str, subscriber: queue.Queue[dict[str, Any]]) -> None:
        listeners = self._subscribers.get(agent_name)
        if not listeners:
            return
        self._subscribers[agent_name] = [item for item in listeners if item is not subscriber]
        if not self._subscribers[agent_name]:
            self._subscribers.pop(agent_name, None)

    def publish(self, agent_name: str, event: dict[str, Any]) -> None:
        for subscriber in list(self._subscribers.get(agent_name, [])):
            subscriber.put_nowait(dict(event))


@dataclass
class RuntimeServices:
    db: WhispersDB
    registry: AgentRegistry
    spaces: SpaceService
    messaging: MessagingService
    coordination: CoordinationService
    continuity: ContinuityService
    trust: TrustService
    pollen: "PollenService | None" = None


class IdentityConnectRequest(BaseModel):
    requested_callsign: str
    agent_type: str = "script"
    model_id: str | None = None
    display_name: str | None = None
    session_name: str | None = None
    owner_id: str | None = None
    platform_family: str | None = None
    context_hint: str | None = None
    continuity_anchor: str | None = None
    allow_sibling: bool = False
    sibling_label: str | None = None
    participant_profile: str | None = None
    participant_kind: str = "primary_agent"
    participant_shape: str = "atomic"
    agency_relation: str | None = None
    boundary_provenance: str | None = None
    recognition_basis: str | None = None
    reachability_mode: str | None = None
    interaction_asks: list[str] = Field(default_factory=list)
    capability_claims: list[dict[str, Any]] = Field(default_factory=list)
    composition_hints: list[dict[str, Any]] = Field(default_factory=list)
    session_id: str | None = None
    session_kind: str = "http_client"
    process_id: int | None = None
    metadata: dict[str, Any] | None = None


class SpaceCreateRequest(BaseModel):
    created_by: str
    name: str
    purpose: str | None = None
    boundary_type: str = "hard"
    governance: str = "directed"
    visibility: str = "sealed"
    temporality: str = "persistent"
    naming_policy: str = "shared"
    naming_conflict_mode: str = "reject"


class SpaceJoinRequest(BaseModel):
    agent_name: str
    membership_role: str = "member"


class SpaceLeaveRequest(BaseModel):
    agent_name: str
    reason: str | None = None


class SpaceIdentityRequest(BaseModel):
    agent_name: str
    participation_name: str | None = None


class SpaceSeatRequest(BaseModel):
    actor: str
    seat_name: str
    occupant_agent: str | None = None
    note: str | None = None
    binding_mode: str = "exclusive"


class MessageSendRequest(BaseModel):
    sender: str
    recipient: str
    subject: str
    body: str | None = None
    msg_type: str = "inform"
    priority: str = "routine"
    payload: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None
    reply_to: str | None = None
    trace_id: str | None = None
    context_id: str | None = None
    space_id: str | None = None
    thread_id: str | None = None
    sender_session_id: str | None = None


class MessageReplyRequest(BaseModel):
    sender: str
    message_id: str
    body: str
    subject: str | None = None
    priority: str = "routine"
    msg_type: str = "reply"
    sender_session_id: str | None = None


class WorkOfferRequest(BaseModel):
    creator: str
    assignee: str
    title: str
    description: str | None = None
    space_id: str | None = None
    metadata: dict[str, Any] | None = None


class WorkActorRequest(BaseModel):
    actor: str
    note: str | None = None


class WorkHandoffRequest(BaseModel):
    actor: str
    new_owner: str
    note: str | None = None


class BatonAckRequest(BaseModel):
    actor: str
    decision: str
    conditions: list[str] = Field(default_factory=list)
    reason: str | None = None


class BatonUpdateRequest(BaseModel):
    actor: str
    state: str
    progress: str | None = None
    artifact_refs: list[str] = Field(default_factory=list)
    branch: str | None = None
    head_commit: str | None = None


class BatonCloseRequest(BaseModel):
    actor: str
    outcome: str
    summary: str | None = None
    artifact_refs: list[str] = Field(default_factory=list)
    branch: str | None = None
    head_commit: str | None = None


class IdentityEventsQuery(BaseModel):
    agent_id: str | None = None
    continuity_anchor: str | None = None
    limit: int = 50


class IdentityRenameRequest(BaseModel):
    new_callsign: str
    actor: str | None = None
    reason: str | None = None
    display_name: str | None = None


class IdentityDescriptorRequest(BaseModel):
    participant_profile: str | None = None
    participant_kind: str | None = None
    participant_shape: str | None = None
    agency_relation: str | None = None
    boundary_provenance: str | None = None
    recognition_basis: str | None = None
    reachability_mode: str | None = None
    interaction_asks: list[str] = Field(default_factory=list)
    capability_claims: list[dict[str, Any]] = Field(default_factory=list)
    composition_hints: list[dict[str, Any]] = Field(default_factory=list)


class ParticipantKitRequest(BaseModel):
    participant_profile: str
    sender: str
    recipient: str
    subject: str
    body: str | None = None
    display_name: str | None = None
    artifacts: list[str] = Field(default_factory=list)
    starter_artifact: str | None = None


class SignalRequest(BaseModel):
    sender: str = Field(alias="from")
    recipient: str = Field(alias="to")
    subject: str
    body: str | None = None
    display_name: str | None = None
    participant_profiles: list[str] = Field(default_factory=list)
    basis: str = "declared"
    consequence_scope: str | None = None
    origin: str | None = None
    subject_of: str | None = None
    principal: str | None = None
    action_class: str | None = None
    severity: str | None = None


class WakeAdapterRegistrationRequest(BaseModel):
    adapter_kind: str
    supported_actions: list[str] = Field(default_factory=list)
    fallback_action: str | None = None
    state: str | None = None
    detail: str | None = None
    endpoint_url: str | None = None


class TrustTierRequest(BaseModel):
    actor: str
    new_tier: int = Field(..., ge=1, le=5)
    reason: str


class AppError(HTTPException):
    pass


def _build_services(db_path: str | None = None) -> RuntimeServices:
    db = WhispersDB(db_path=db_path)
    registry = AgentRegistry(db)
    trust = TrustService(db)
    spaces = SpaceService(db)
    messaging = MessagingService(db, spaces=spaces)
    coordination = CoordinationService(db, spaces=spaces, messaging=messaging)
    continuity = ContinuityService(db, registry=registry, trust=trust)

    # T4.25 — PollenService subscribes to tier/rename events and drives
    # the single reissue path. Identity resolution closure captures
    # the live registry + trust + continuity so resolve_identity returns
    # authoritative current-state.
    pollen = _build_pollen_service(
        registry=registry, trust=trust, continuity=continuity
    )

    return RuntimeServices(
        db=db,
        registry=registry,
        spaces=spaces,
        messaging=messaging,
        coordination=coordination,
        continuity=continuity,
        trust=trust,
        pollen=pollen,
    )


def _build_pollen_service(
    *,
    registry: AgentRegistry,
    trust: TrustService,
    continuity: ContinuityService,
):
    """Wire up the PollenService with observers on trust + continuity.

    Exposed as a module-level helper so tests can build an isolated
    service against test-DB services without bringing up the whole
    FastAPI app.
    """
    from .pollen.keys import load_or_generate_issuer_keypair
    from .pollen.issuance import signer_from_keypair
    from .pollen.service import PollenService

    try:
        signer = signer_from_keypair(load_or_generate_issuer_keypair())
    except Exception:
        # Defensive — Stage A cannot let pollen plumbing failure break
        # service construction. Return None; callers treat missing
        # PollenService as "pollen not available this deployment."
        return None

    def _resolve_identity(callsign: str) -> dict[str, Any] | None:
        card = registry.get_agent_by_callsign(callsign)
        if not card:
            return None
        try:
            resolved_trust = trust.resolve_for_callsign(callsign)
            current_tier = int(resolved_trust.current_tier)
        except Exception:
            current_tier = int(card.get("trust_tier") or 1)
        return {
            "callsign": str(card.get("callsign") or callsign),
            "stable_subject_id": str(
                card.get("stable_subject_id") or card.get("agent_id") or callsign
            ),
            "continuity_anchor": str(card.get("continuity_anchor") or ""),
            "trust_tier": current_tier,
            "agent_id": str(card.get("agent_id") or ""),
        }

    service = PollenService(signer=signer, resolve_identity=_resolve_identity)

    # Observer: tier change → reissue
    def _on_tier_change(callsign, old_tier, new_tier, reason):
        service.reissue_for_callsign(callsign, reason=f"tier_change:{old_tier}->{new_tier}")
    trust.add_tier_change_listener(_on_tier_change)

    # Observer: rename → reissue under the NEW callsign (resolve_identity
    # sees the updated card because rename commits before the observer fires)
    def _on_rename(old_callsign, new_callsign, reason):
        # Clear old-name cache entry and issue under new callsign
        service.clear_for_callsign(old_callsign)
        service.reissue_for_callsign(new_callsign, reason=f"rename:{old_callsign}->{new_callsign}")
    continuity.add_rename_listener(_on_rename)

    return service


def _status_payload(services: RuntimeServices, agent_name: str) -> dict[str, Any]:
    card = services.registry.get_agent_by_callsign(agent_name)
    if not card:
        raise HTTPException(status_code=404, detail=f"Agent {agent_name} not found.")
    message_summary = services.messaging.summary(agent_name)
    work_summary = services.coordination.summary(agent_name)
    active_session = services.db.active_session_for_agent(agent_name)
    active_session_metadata = _decode_session_metadata((active_session or {}).get("metadata"))
    all_sessions = services.db.active_sessions_for_agent(agent_name)
    effective_trust = services.trust.resolve_for_callsign(agent_name)
    projection = participant_projection(card, fallback_name=agent_name)
    spaces = services.spaces.list_spaces_for_agent(agent_name)
    startup_capsule = services.spaces.startup_capsule(
        agent_name,
        message_summary=message_summary,
        trust_tier=effective_trust.current_tier,
        work_summary=work_summary,
    )
    wake_projection = build_wake_projection(
        card=card,
        active_session=active_session,
        message_summary=message_summary,
        work_summary=work_summary,
        all_sessions=all_sessions,
    )
    primary_member = None
    if spaces:
        members = services.spaces.members(spaces[0]["space_id"])
        primary_member = next((member for member in members if member.get("agent_name") == agent_name), None)
    chrome = build_operator_chrome(
        agent_name=agent_name,
        participant_projection=projection,
        effective_trust=effective_trust.to_dict(),
        wake_projection=wake_projection,
        active_session=active_session,
        spaces=spaces,
        primary_member=primary_member,
        message_summary=message_summary,
        work_summary=work_summary,
        startup_capsule=startup_capsule,
    )
    return {
        "healthy": True,
        "agent_name": agent_name,
        "display_name": card.get("display_name"),
        "session_name": (
            active_session_metadata.get("session_name")
            or active_session_metadata.get("display_name")
            or card.get("display_name")
            or agent_name
        ),
        "agent_id": card.get("agent_id"),
        "stable_subject_id": card.get("stable_subject_id"),
        "continuity_anchor": card.get("continuity_anchor"),
        "platform_family": card.get("platform_family") or card.get("agent_type"),
        "participant_kind": card.get("participant_kind"),
        "participant_shape": card.get("participant_shape"),
        "agency_relation": card.get("agency_relation"),
        "boundary_provenance": card.get("boundary_provenance"),
        "recognition_basis": card.get("recognition_basis"),
        "reachability_mode": wake_projection.get("reachability_mode") or card.get("reachability_mode"),
        "interaction_asks": card.get("interaction_asks") or [],
        "capability_claims": card.get("capability_claims") or [],
        "composition_hints": card.get("composition_hints") or [],
        "participant_summary": projection.get("summary"),
        "participant_projection": projection,
        "effective_trust": effective_trust.to_dict(),
        "active_session": active_session,
        "spaces": spaces,
        "message_summary": message_summary,
        "work_summary": work_summary,
        "wake_projection": wake_projection,
        "chrome": chrome,
        "startup_capsule": startup_capsule,
    }


def _decode_session_metadata(raw: Any) -> dict[str, Any]:
    if isinstance(raw, dict):
        return dict(raw)
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return {}
        return dict(parsed) if isinstance(parsed, dict) else {}
    return {}


def _active_session_or_404(services: RuntimeServices, agent_name: str) -> dict[str, Any]:
    session = services.db.active_session_for_agent(agent_name)
    if not session:
        raise HTTPException(status_code=404, detail=f"No active session for {agent_name}.")
    return session


def _replayable_wake_events(
    services: RuntimeServices,
    agent_name: str,
    *,
    after_event_id: int | None,
    limit: int = 200,
) -> list[dict[str, Any]]:
    if after_event_id is None:
        return []
    events = services.db.list_wake_events(agent_name, limit=limit)
    replay = [event for event in reversed(events) if int(event.get("event_id") or 0) > int(after_event_id)]
    return replay



def _format_sse_event(event_type: str, payload: dict[str, Any], *, event_id: int | None = None) -> str:
    lines: list[str] = []
    if event_id is not None:
        lines.append(f"id: {int(event_id)}")
    lines.append(f"event: {event_type}")
    lines.append(f"data: {json.dumps(payload, separators=(',', ':'))}")
    return "\n".join(lines) + "\n\n"



def _build_wake_packet(services: RuntimeServices, agent_name: str, status: dict[str, Any]) -> dict[str, Any]:
    recent_messages = services.messaging.inbox(agent_name, limit=3, mark_seen=False)
    recent_work = services.coordination.list_work(agent_name=agent_name)[:3]
    wake_projection = status["wake_projection"]
    attention_context = wake_projection.get("attention_context") or {}
    recommended_action = wake_projection.get("recommended_action") or {}
    trigger = str(attention_context.get("trigger") or "ambient_update")
    action = str(recommended_action.get("action") or "suppress")
    blocked_count = int((status.get("work_summary") or {}).get("blocked", 0) or 0)

    if blocked_count > 0:
        state = "blocked"
        readiness = "blocked"
    elif action == "infer":
        state = "building"
        readiness = "ready"
    elif action in {"notify", "stage_context"}:
        state = "listening"
        readiness = "ready"
    else:
        state = "idle"
        readiness = "ready"

    packet = build_status_envelope(
        message_id=str(uuid.uuid4()),
        thread_id=f"wake:{agent_name}",
        created_at=utc_now_iso(),
        state=state,
        readiness=readiness,
        current_task=f"wake:{action}:{trigger}",
        interruptibility=attention_context.get("interruptibility"),
        working_set=[
            "wake_packet",
            f"agent:{agent_name}",
            f"action:{action}",
            f"trigger:{trigger}",
        ],
    )
    packet["wake"] = {
        "agent_name": agent_name,
        "chrome": status["chrome"],
        "wake_projection": wake_projection,
        "startup_capsule": status["startup_capsule"],
        "recent_messages": [
            {
                "message_id": item.get("message_id"),
                "sender": item.get("sender"),
                "subject": item.get("subject"),
                "priority": item.get("priority"),
                "space_id": item.get("space_id"),
                "thread_id": item.get("thread_id"),
            }
            for item in recent_messages
        ],
        "recent_work": [
            {
                "work_id": item.get("work_id"),
                "title": item.get("title"),
                "state": item.get("state"),
                "owner_agent": item.get("owner_agent"),
            }
            for item in recent_work
        ],
    }
    return packet


class _Utf8BodyMiddleware:
    """ASGI middleware: returns JSON-RPC -32700 on non-UTF-8 POST bodies.

    json.loads() raises UnicodeDecodeError (not json.JSONDecodeError) on non-UTF-8
    bytes. FastMCP only catches JSONDecodeError, so invalid encodings surface as
    -32603 internal error instead of -32700 parse error. This layer fixes that.
    """

    def __init__(self, app: Any) -> None:
        self._app = app

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        if scope.get("type") != "http" or scope.get("method") != "POST":
            await self._app(scope, receive, send)
            return

        chunks: list[bytes] = []
        more = True
        while more:
            msg = await receive()
            chunks.append(msg.get("body", b""))
            more = msg.get("more_body", False)
        raw_body = b"".join(chunks)

        try:
            raw_body.decode("utf-8")
        except UnicodeDecodeError:
            error_payload = json.dumps({
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": "Parse error: request body is not valid UTF-8"},
            }).encode("utf-8")
            await send({
                "type": "http.response.start",
                "status": 400,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(error_payload)).encode()),
                ],
            })
            await send({"type": "http.response.body", "body": error_payload, "more_body": False})
            return

        replayed = False

        async def _replay() -> dict:
            nonlocal replayed
            if not replayed:
                replayed = True
                return {"type": "http.request", "body": raw_body, "more_body": False}
            return await receive()

        await self._app(scope, _replay, send)


def create_app(db_path: str | None = None) -> FastAPI:
    services = _build_services(db_path=db_path)
    wake_event_broker = _WakeEventBroker()
    listen_host = os.getenv("WHISPERS_HOST", "127.0.0.1")
    try:
        mcp, seat_manager = create_mcp(
            db_path=db_path,
            session_kind="mcp_http",
            listen_host=listen_host,
        )
        mcp_app = mcp.streamable_http_app()
    except Exception:
        logger.exception(
            "Failed to attach mounted Whispers MCP app",
            extra={"db_path": db_path, "listen_host": listen_host},
        )
        raise

    @contextlib.asynccontextmanager
    async def lifespan(_: FastAPI):
        try:
            async with mcp.session_manager.run():
                yield
        except Exception:
            logger.exception("Whispers MCP lifespan failure")
            raise

    app = FastAPI(title="Whispers", version="0.5.0-dev", lifespan=lifespan)
    app.state.services = services
    app.state.mcp = mcp
    app.state.mcp_seat_manager = seat_manager
    app.state.wake_event_broker = wake_event_broker
    app.mount("/mcp", _Utf8BodyMiddleware(mcp_app))

    # T4.23 — extract X-Whispers-Pollen list header on every request
    # and attach the parsed envelope list to request.state.
    # T4.24 — verify each envelope against the local issuer keyring
    # (informational only; does NOT block calls). Verification outcomes
    # are attached to request.state.pollen_verifications and emitted
    # as structured log entries for operator triage.
    from .pollen.presentation import POLLEN_HEADER_NAME, parse_pollen_list_header
    from .pollen.keys import load_or_generate_issuer_keypair
    from .pollen.signing import deserialize_public_key
    from .pollen.verification import verify_presented_pollen

    _pollen_logger = logging.getLogger("whispers.pollen.verification")

    @app.middleware("http")
    async def _pollen_extract_middleware(request, call_next):
        raw = request.headers.get(POLLEN_HEADER_NAME)
        envelopes: list[dict[str, Any]] = []
        parse_error: str | None = None
        if raw:
            try:
                envelopes = parse_pollen_list_header(raw)
            except (ValueError, json.JSONDecodeError) as exc:
                # Stage A: malformed header is logged via request.state
                # but does NOT block the request. T4.24 surfaces the
                # parse_error as a 'parse_error' verification outcome at
                # envelope_index=-1 so a log reader sees one event per
                # request regardless of where the failure lived.
                parse_error = f"pollen_header_parse_failed: {exc}"
        request.state.pollen_envelopes = envelopes
        request.state.pollen_parse_error = parse_error

        # T4.24 — verify every presented envelope. Informational only.
        if envelopes or parse_error:
            try:
                keypair = load_or_generate_issuer_keypair()
                # Single-daemon scope (Stage A): any claimed_issuer maps
                # to the local keypair. Stage E federation widens this.
                daemon_public_key_raw = deserialize_public_key(
                    keypair.public_key_b64u
                )
                daemon_key_id = keypair.key_id

                def _lookup(_issuer_callsign: str) -> bytes | None:
                    return daemon_public_key_raw

                def _has_key_id(key_id: str) -> bool:
                    return key_id == daemon_key_id

                verifications = verify_presented_pollen(
                    envelopes,
                    issuer_key_lookup=_lookup,
                    issuer_keyring_has_key_id=_has_key_id,
                    header_parse_error=parse_error,
                )
            except Exception as exc:  # pragma: no cover — defensive
                # Verification middleware MUST NOT break requests even
                # if the issuer keypair is unreachable. Log and proceed.
                _pollen_logger.warning(
                    "pollen_verification_middleware_error",
                    extra={"detail": f"{type(exc).__name__}: {exc}"},
                )
                verifications = []
            else:
                for outcome in verifications:
                    if outcome.status == "verified":
                        _pollen_logger.info(
                            "pollen_verified", extra=outcome.to_log_dict()
                        )
                    else:
                        _pollen_logger.warning(
                            f"pollen_verification_failed:{outcome.reason}",
                            extra=outcome.to_log_dict(),
                        )
        else:
            verifications = []

        request.state.pollen_verifications = verifications
        return await call_next(request)

    @app.exception_handler(WhispersDBError)
    async def whispers_db_error_handler(_, exc: WhispersDBError):
        return JSONResponse(status_code=400, content={"error": str(exc)})

    @app.exception_handler(ContinuityConflictError)
    async def continuity_conflict_handler(_, exc: ContinuityConflictError):
        return JSONResponse(
            status_code=409,
            content={
                "error": str(exc),
                "outcome": exc.outcome,
                "details": exc.details,
            },
        )

    @app.get("/")
    def root() -> dict[str, Any]:
        return {"service": "whispers", "docs": "/health", "mcp": "/mcp/"}

    @app.get("/health")
    def health() -> dict[str, Any]:
        write_ready, write_error = services.db.check_write_ready()
        return {
            "ok": write_ready,
            "wal": services.db.check_wal_mode(),
            "write_error": write_error,
            "db_path": services.db.db_path,
            "mcp": "/mcp/",
        }

    @app.get("/doctor")
    def doctor() -> dict[str, Any]:
        write_ready, write_error = services.db.check_write_ready()
        return {
            "health": {
                "ok": write_ready,
                "wal": services.db.check_wal_mode(),
                "write_error": write_error,
                "db_path": services.db.db_path,
                "mcp": "/mcp/",
            },
            "jolt_adapters": _jolt_dispatch_loop(db_path=db_path),
        }

    @app.post("/identity/connect")
    def identity_connect(request: IdentityConnectRequest) -> dict[str, Any]:
        profile_defaults = (
            build_participant_profile(request.participant_profile, source=request.requested_callsign)
            if request.participant_profile
            else {}
        )
        participant_kind = (
            request.participant_kind
            if request.participant_kind != "primary_agent"
            else profile_defaults.get("participant_kind", request.participant_kind)
        )
        participant_shape = (
            request.participant_shape
            if request.participant_shape != "atomic"
            else profile_defaults.get("participant_shape", request.participant_shape)
        )
        resolution = services.continuity.connect(
            requested_callsign=request.requested_callsign,
            agent_type=request.agent_type,
            model_id=request.model_id,
            display_name=request.display_name,
            owner_id=request.owner_id,
            platform_family=request.platform_family,
            context_hint=request.context_hint,
            continuity_anchor=request.continuity_anchor,
            allow_sibling=request.allow_sibling,
            sibling_label=request.sibling_label,
            participant_kind=participant_kind,
            participant_shape=participant_shape,
        )
        session_id = request.session_id or stable_session_id(
            continuity_anchor=resolution.continuity_anchor,
            session_kind=request.session_kind,
            process_id=request.process_id,
        ) or str(uuid.uuid4())
        session_metadata = dict(request.metadata or {})
        if request.display_name:
            session_metadata["display_name"] = request.display_name
        session_metadata["session_name"] = (
            request.session_name
            or request.display_name
            or request.requested_callsign
        )
        session_metadata["identity_resolution"] = resolution.to_dict()
        if request.participant_profile:
            session_metadata["participant_profile"] = request.participant_profile
        services.db.upsert_agent_session(
            session_id=session_id,
            agent_name=resolution.callsign,
            agent_id=resolution.agent_id,
            session_kind=request.session_kind,
            process_id=request.process_id,
            metadata=session_metadata,
        )
        services.messaging.replay_dead_letters_for_recipient(
            resolution.callsign,
            agent_id=resolution.agent_id,
            delivery_session_id=session_id,
        )
        services.registry.update_descriptor(
            resolution.callsign,
            participant_kind=participant_kind,
            participant_shape=participant_shape,
            agency_relation=request.agency_relation or profile_defaults.get("agency_relation"),
            boundary_provenance=request.boundary_provenance or profile_defaults.get("boundary_provenance"),
            recognition_basis=request.recognition_basis or profile_defaults.get("recognition_basis"),
            reachability_mode=request.reachability_mode or profile_defaults.get("reachability_mode"),
            interaction_asks=request.interaction_asks or profile_defaults.get("interaction_asks") or None,
            capability_claims=request.capability_claims or profile_defaults.get("capability_claims") or None,
            composition_hints=request.composition_hints or profile_defaults.get("composition_hints") or None,
        )

        # T4.22 — issue identity pollen on every successful bind so the
        # client can present it on subsequent calls. Stage A scope:
        # informational; not yet load-bearing for any read path.
        # Failure here MUST NOT break the bind response — pollen is
        # additive during Stage A.
        pollen_block: dict[str, Any] | None = None
        try:
            from .pollen.issuance import issue_identity_pollen, signer_from_keypair
            from .pollen.keys import load_or_generate_issuer_keypair

            effective_trust_now = services.trust.resolve_for_callsign(resolution.callsign)
            signer = signer_from_keypair(load_or_generate_issuer_keypair())
            identity_envelope = issue_identity_pollen(
                callsign=resolution.callsign,
                stable_subject_id=resolution.stable_subject_id,
                continuity_anchor=resolution.continuity_anchor,
                trust_tier=effective_trust_now.current_tier,
                signer=signer,
            )
            pollen_block = {"identity": identity_envelope}
        except Exception:
            # Stage A is informational. A pollen-issuance failure must
            # not turn into a bind failure. T4.24 will surface
            # verification failures honestly; T4.25 will harden
            # issuance via the reissue ceremony.
            pollen_block = None

        return {
            "resolution": resolution.to_dict(),
            "session_id": session_id,
            "status": _status_payload(services, resolution.callsign),
            "pollen": pollen_block,
        }

    @app.get("/identity/{agent_name}")
    def identity_card(agent_name: str) -> dict[str, Any]:
        card = services.registry.get_agent_by_callsign(agent_name)
        if not card:
            raise HTTPException(status_code=404, detail=f"Agent {agent_name} not found.")
        return card

    @app.get("/identity/events")
    def identity_events(
        agent_id: str | None = Query(default=None),
        continuity_anchor: str | None = Query(default=None),
        limit: int = Query(default=50, ge=1, le=500),
    ) -> dict[str, Any]:
        return {
            "events": services.db.list_identity_events(
                agent_id=agent_id,
                continuity_anchor=continuity_anchor,
                limit=limit,
            )
        }

    @app.get("/identity/{agent_name}/presentations")
    def identity_presentations(agent_name: str, limit: int = Query(default=20, ge=1, le=200)) -> dict[str, Any]:
        return {"presentations": services.continuity.presentation_history(agent_name, limit=limit)}

    @app.get("/pollen/presented")
    def pollen_presented(request: Request) -> dict[str, Any]:
        """T4.23 read-back + T4.24 verification outcomes.

        Returns the parsed pollen list AND the per-envelope verification
        outcomes (one entry per envelope; plus an envelope_index=-1
        'parse_error' outcome when the T4.23 extract middleware hit a
        malformed header). Operators + tests use this to confirm the
        X-Whispers-Pollen header was parsed AND verified correctly.

        Stage A discipline: verification outcomes are informational.
        The endpoint reports them; it does not gate on them.

        Lives under /pollen/ rather than /identity/ to avoid collision
        with the catch-all /identity/{agent_name} route.
        """
        envelopes = getattr(request.state, "pollen_envelopes", []) or []
        parse_error = getattr(request.state, "pollen_parse_error", None)
        verifications = getattr(request.state, "pollen_verifications", []) or []
        return {
            "presented_count": len(envelopes),
            "envelopes": envelopes,
            "parse_error": parse_error,
            "verifications": [outcome.to_log_dict() for outcome in verifications],
        }

    @app.get("/identity/keys/{issuer_callsign}")
    def identity_keys(issuer_callsign: str) -> dict[str, Any]:
        """Pollen verifier endpoint — returns the issuer's public key.

        T4.21 Stage A. Verifiers fetch the public key by issuer callsign,
        decode the b64u-encoded raw 32-byte Ed25519 key, then verify
        signed pollen envelopes against it.

        For v6 single-daemon scope, only one issuer exists per daemon
        (the daemon itself). Cross-daemon federation (Stage E) widens
        this endpoint to multiple issuers; for now, any issuer_callsign
        request resolves to the local daemon's keypair.
        """
        from .pollen.keys import load_or_generate_issuer_keypair

        keypair = load_or_generate_issuer_keypair()
        return {
            "issuer_callsign": issuer_callsign,
            "key_id": keypair.key_id,
            "public_key_b64u": keypair.public_key_b64u,
            "algorithm": "ed25519",
        }

    @app.post("/identity/{agent_name}/rename")
    def identity_rename(agent_name: str, request: IdentityRenameRequest) -> dict[str, Any]:
        resolution = services.continuity.rename_presentation(
            agent_name,
            request.new_callsign,
            actor=request.actor or agent_name,
            reason=request.reason,
            display_name=request.display_name,
        )
        return {
            "resolution": resolution.to_dict(),
            "status": _status_payload(services, resolution.callsign),
            "presentations": services.continuity.presentation_history(resolution.callsign),
        }

    @app.post("/identity/{agent_name}/descriptor")
    def identity_descriptor(agent_name: str, request: IdentityDescriptorRequest) -> dict[str, Any]:
        profile_defaults = (
            build_participant_profile(request.participant_profile, source=agent_name)
            if request.participant_profile
            else {}
        )
        return {
            "card": services.registry.update_descriptor(
                agent_name,
                participant_kind=request.participant_kind or profile_defaults.get("participant_kind"),
                participant_shape=request.participant_shape or profile_defaults.get("participant_shape"),
                agency_relation=request.agency_relation or profile_defaults.get("agency_relation"),
                boundary_provenance=request.boundary_provenance or profile_defaults.get("boundary_provenance"),
                recognition_basis=request.recognition_basis or profile_defaults.get("recognition_basis"),
                reachability_mode=request.reachability_mode or profile_defaults.get("reachability_mode"),
                interaction_asks=request.interaction_asks or profile_defaults.get("interaction_asks") or None,
                capability_claims=request.capability_claims or profile_defaults.get("capability_claims") or None,
                composition_hints=request.composition_hints or profile_defaults.get("composition_hints") or None,
            ),
            "status": _status_payload(services, agent_name),
        }

    @app.get("/participants/profiles")
    def participant_profiles() -> dict[str, Any]:
        return {"profiles": supported_onboarding_profiles()}

    @app.post("/participants/kit")
    def participant_kit(request: ParticipantKitRequest, http_request: Request) -> dict[str, Any]:
        return build_participant_onboarding_kit(
            server=str(http_request.base_url).rstrip("/"),
            participant_profile=request.participant_profile,
            sender=request.sender,
            recipient=request.recipient,
            subject=request.subject,
            body=request.body,
            display_name=request.display_name,
            artifacts=request.artifacts or None,
            starter_artifact=request.starter_artifact,
        )

    @app.post("/signal")
    def signal(request: SignalRequest) -> dict[str, Any]:
        signal_profiles = normalize_participant_profiles(request.participant_profiles)
        prepared = prepare_signal_participant_card(
            services.registry,
            request.sender,
            display_name=request.display_name,
            participant_profiles=signal_profiles,
        )
        guided_profile = guided_profile_for_signal_profiles(signal_profiles)
        if guided_profile:
            descriptor = build_participant_profile(guided_profile, source=request.sender)
            services.registry.update_descriptor(
                request.sender,
                participant_kind=descriptor.get("participant_kind"),
                participant_shape=descriptor.get("participant_shape"),
                agency_relation=descriptor.get("agency_relation"),
                boundary_provenance=descriptor.get("boundary_provenance"),
                recognition_basis=descriptor.get("recognition_basis"),
                reachability_mode=descriptor.get("reachability_mode"),
                interaction_asks=descriptor.get("interaction_asks"),
                capability_claims=descriptor.get("capability_claims"),
                composition_hints=descriptor.get("composition_hints"),
            )
        delivered = services.messaging.send(
            sender=request.sender,
            recipient=request.recipient,
            subject=request.subject,
            body=request.body,
            msg_type="participant_state" if "status_source" in signal_profiles else "inform",
            priority="priority" if str(request.severity or "").strip().lower() in {"high", "urgent", "critical"} else "routine",
            payload={
                "from": request.sender,
                "to": request.recipient,
                "subject": request.subject,
                "body": request.body,
                "display_name": request.display_name,
                "participant_profiles": signal_profiles,
                "basis": request.basis,
                "consequence_scope": request.consequence_scope,
                "origin": request.origin,
                "subject_of": request.subject_of,
                "principal": request.principal,
                "action_class": request.action_class,
                "severity": request.severity,
            },
            metadata={
                "whispers:signal": True,
                "whispers:signal_basis": request.basis,
                "whispers:participant_profiles": signal_profiles,
                "whispers:guided_profile": guided_profile,
                "whispers:origin": request.origin,
                "whispers:subject_of": request.subject_of,
                "whispers:principal": request.principal,
                "whispers:action_class": request.action_class,
                "whispers:severity": request.severity,
            },
        )
        sender_card = services.registry.get_agent_by_callsign(request.sender) or prepared
        return {
            "participant": sender_card,
            "participant_projection": participant_projection(sender_card, fallback_name=request.sender),
            "guided_profile": guided_profile,
            "delivery": delivered,
        }

    @app.get("/signal/browser", response_class=HTMLResponse)
    def signal_browser(http_request: Request) -> HTMLResponse:
        query = http_request.query_params
        profiles = query.getlist("participant_profiles")
        payload = {
            "from": query.get("from", ""),
            "to": query.get("to", ""),
            "subject": query.get("subject", ""),
            "body": query.get("body"),
            "display_name": query.get("display_name"),
            "participant_profiles": profiles,
            "basis": query.get("basis", "declared"),
            "consequence_scope": query.get("consequence_scope"),
            "origin": query.get("origin"),
            "subject_of": query.get("subject_of"),
            "principal": query.get("principal"),
            "action_class": query.get("action_class"),
            "severity": query.get("severity"),
        }
        html = f"""
<!doctype html>
<html>
  <head><meta charset='utf-8'><title>Whispers signal browser</title></head>
  <body>
    <h1>Whispers browser signal</h1>
    <p>This is a thin browser pairing surface for guided participants.</p>
    <pre id='payload'>{json.dumps(payload, indent=2)}</pre>
    <button id='send'>Send to Whispers</button>
    <pre id='result'></pre>
    <script>
      const payload = {json.dumps(payload)};
      document.getElementById('send').onclick = async () => {{
        const response = await fetch('/signal', {{
          method: 'POST',
          headers: {{'Content-Type': 'application/json'}},
          body: JSON.stringify(payload)
        }});
        const text = await response.text();
        document.getElementById('result').textContent = text;
      }};
    </script>
  </body>
</html>
"""
        return HTMLResponse(content=html)

    @app.get("/trust/{agent_name}")
    def trust_status(agent_name: str) -> dict[str, Any]:
        card = services.registry.get_agent_by_callsign(agent_name)
        if not card:
            raise HTTPException(status_code=404, detail=f"Agent {agent_name} not found.")
        resolution = services.trust.resolve_for_callsign(agent_name)
        return {
            "trust": resolution.to_dict(),
            "events": services.db.list_trust_events(stable_subject_id=resolution.stable_subject_id),
        }

    @app.post("/trust/{agent_name}")
    def set_trust(agent_name: str, request: TrustTierRequest) -> dict[str, Any]:
        resolution = services.trust.set_tier_for_callsign(
            agent_name,
            new_tier=request.new_tier,
            actor=request.actor,
            reason=request.reason,
        )
        return {
            "trust": resolution.to_dict(),
            "status": _status_payload(services, agent_name),
        }

    @app.get("/status/{agent_name}")
    def agent_status(agent_name: str) -> dict[str, Any]:
        return _status_payload(services, agent_name)

    @app.get("/doctor/{agent_name}")
    def agent_doctor(agent_name: str) -> dict[str, Any]:
        status = _status_payload(services, agent_name)
        session = services.db.active_session_for_agent(agent_name)
        return {
            "agent_name": agent_name,
            "status": status,
            "active_session": session,
            "wake_events": services.db.list_wake_events(agent_name, limit=10),
            "adapters": _extract_registered_wake_adapters(session.get("metadata") if session else None),
        }

    @app.get("/wake/{agent_name}")
    def wake_status(agent_name: str) -> dict[str, Any]:
        status = _status_payload(services, agent_name)
        return {
            "agent_name": agent_name,
            "wake_projection": status["wake_projection"],
            "chrome": status["chrome"],
        }

    @app.get("/wake/{agent_name}/adapters")
    def wake_adapters(agent_name: str) -> dict[str, Any]:
        session = _active_session_or_404(services, agent_name)
        return {
            "agent_name": agent_name,
            "session_id": session["session_id"],
            "adapters": _extract_registered_wake_adapters(session.get("metadata")),
        }

    @app.post("/wake/{agent_name}/adapters")
    def register_wake_adapter(agent_name: str, request: WakeAdapterRegistrationRequest) -> dict[str, Any]:
        session = _active_session_or_404(services, agent_name)
        adapter_kind = str(request.adapter_kind or "").strip()
        if not adapter_kind:
            raise HTTPException(status_code=422, detail="adapter_kind is required")
        adapter_payload = {
            "supported_actions": list(request.supported_actions or []),
            "fallback_action": request.fallback_action,
            "state": request.state,
            "detail": request.detail,
            "endpoint_url": request.endpoint_url,
        }
        patched = services.db.patch_agent_session_metadata(
            str(session["session_id"]),
            metadata_patch={"adapter_registrations": {adapter_kind: adapter_payload}},
        )
        return {
            "agent_name": agent_name,
            "session_id": patched.get("session_id"),
            "adapters": _extract_registered_wake_adapters(patched.get("metadata")),
            "wake_projection": _status_payload(services, agent_name)["wake_projection"],
        }

    @app.post("/wake/{agent_name}/dispatch")
    def dispatch_wake(agent_name: str) -> dict[str, Any]:
        status = _status_payload(services, agent_name)
        session = _active_session_or_404(services, agent_name)
        packet = _build_wake_packet(services, agent_name, status)
        recommended = status["wake_projection"]["recommended_action"]
        action = str(recommended.get("action") or "suppress")
        adapters = _extract_registered_wake_adapters(session.get("metadata"))
        adapter_choice, adapter_action = _select_registered_wake_adapter(adapters, action=action)
        dispatch_status = "suppressed"
        dispatch_result: dict[str, Any] = {"status": dispatch_status}

        if action != "suppress":
            if not adapter_choice:
                dispatch_status = "staged_no_adapter"
                dispatch_result = {"status": dispatch_status, "reason": "no_registered_adapter"}
            else:
                endpoint_url = str(adapter_choice.get("endpoint_url") or "").strip()
                if adapter_action == "suppress":
                    dispatch_status = "suppressed_by_adapter"
                    dispatch_result = {"status": dispatch_status}
                elif endpoint_url:
                    try:
                        payload = json.dumps(packet).encode("utf-8")
                        http_request = urllib.request.Request(
                            endpoint_url,
                            data=payload,
                            headers={"Content-Type": "application/json"},
                            method="POST",
                        )
                        with urllib.request.urlopen(http_request, timeout=2) as response:
                            body = response.read().decode("utf-8")
                            dispatch_status = "dispatched"
                            dispatch_result = {
                                "status": dispatch_status,
                                "http_status": getattr(response, "status", 200),
                                "body": body,
                            }
                    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
                        dispatch_status = "dispatch_failed"
                        dispatch_result = {"status": dispatch_status, "error": str(exc)}
                else:
                    dispatch_status = "staged"
                    dispatch_result = {"status": dispatch_status, "adapter_action": adapter_action}

        event = services.db.record_wake_event(
            agent_name=agent_name,
            session_id=session.get("session_id"),
            trigger=status["wake_projection"]["attention_context"].get("trigger"),
            recommended_action=action,
            dispatch_status=dispatch_status,
            reachability_mode=status["wake_projection"].get("reachability_mode"),
            wake_model=status["wake_projection"].get("wake_model"),
            adapter_kind=(adapter_choice or {}).get("adapter_kind"),
            adapter_state=(adapter_choice or {}).get("state"),
            adapter_action=adapter_action,
            reasons=status["wake_projection"]["recommended_action"].get("reasons") or [],
            payload={"packet": packet, "dispatch_result": dispatch_result},
        )
        wake_event_broker.publish(agent_name, event)
        return {
            "agent_name": agent_name,
            "packet": packet,
            "event": event,
            "dispatch_result": dispatch_result,
        }

    @app.get("/wake/{agent_name}/events")
    def wake_events(agent_name: str, limit: int = Query(default=20, ge=1, le=200)) -> dict[str, Any]:
        return {"events": services.db.list_wake_events(agent_name, limit=limit)}

    @app.get("/wake/{agent_name}/stream")
    async def wake_stream(
        agent_name: str,
        request: Request,
        after_event_id: int | None = Query(default=None, ge=0),
    ) -> StreamingResponse:
        _status_payload(services, agent_name)

        # Slice 9: subscribe to both the wake event broker (existing) and
        # the delta broker (peer_bound/peer_gone/peer_tier_changed).
        # Delta events are broadcast, so they arrive regardless of
        # per-agent queue routing — the SSE stream emits them with
        # event-type "peer_delta" so clients can distinguish from wake.
        from .delta_stream import get_delta_broker as _get_delta_broker
        delta_broker = _get_delta_broker()

        async def event_source():
            subscriber = wake_event_broker.subscribe(agent_name)
            delta_subscriber = delta_broker.subscribe(agent_name)
            try:
                yield ": connected\n\n"
                for replay_event in _replayable_wake_events(
                    services,
                    agent_name,
                    after_event_id=after_event_id,
                ):
                    yield _format_sse_event(
                        "wake",
                        replay_event,
                        event_id=int(replay_event.get("event_id") or 0),
                    )
                while True:
                    if await request.is_disconnected():
                        break
                    # Poll both brokers. Wake first (priority), then delta.
                    emitted = False
                    try:
                        next_event = await run_in_threadpool(subscriber.get, True, 0.5)
                        yield _format_sse_event(
                            "wake",
                            next_event,
                            event_id=int(next_event.get("event_id") or 0),
                        )
                        emitted = True
                    except queue.Empty:
                        pass
                    try:
                        delta_event = await run_in_threadpool(delta_subscriber.get, False)
                        yield _format_sse_event(
                            "peer_delta",
                            delta_event,
                            event_id=0,
                        )
                        emitted = True
                    except queue.Empty:
                        pass
                    if not emitted:
                        yield ": keepalive\n\n"
            finally:
                wake_event_broker.unsubscribe(agent_name, subscriber)
                delta_broker.unsubscribe(agent_name, delta_subscriber)

        return StreamingResponse(
            event_source(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    @app.get("/chrome/{agent_name}")
    def chrome_status(agent_name: str) -> dict[str, Any]:
        status = _status_payload(services, agent_name)
        return {"agent_name": agent_name, "chrome": status["chrome"]}

    @app.get("/dashboard/{agent_name}", response_class=HTMLResponse)
    def agent_dashboard(agent_name: str) -> HTMLResponse:
        status = _status_payload(services, agent_name)
        packet = _build_wake_packet(services, agent_name, status)
        chrome = status["chrome"]
        wake_context = packet.get("wake") if isinstance(packet.get("wake"), dict) else {}
        recent_messages = wake_context.get("recent_messages") or []
        recent_work = wake_context.get("recent_work") or []
        html_body = f"""
<!doctype html>
<html>
  <head><meta charset='utf-8'><title>Whispers dashboard — {html.escape(agent_name)}</title></head>
  <body>
    <h1>{html.escape(agent_name)}</h1>
    <p><strong>{html.escape(str(chrome['signal_line']))}</strong></p>
    <p>{html.escape(str(chrome['capsule']))}</p>
    <h2>Wake</h2>
    <pre>{html.escape(json.dumps(status['wake_projection'], indent=2))}</pre>
    <h2>Recent messages</h2>
    <pre>{html.escape(json.dumps(recent_messages, indent=2))}</pre>
    <h2>Recent work</h2>
    <pre>{html.escape(json.dumps(recent_work, indent=2))}</pre>
  </body>
</html>
"""
        return HTMLResponse(content=html_body)

    @app.post("/spaces")
    def create_space(request: SpaceCreateRequest) -> dict[str, Any]:
        return services.spaces.create_space(
            created_by=request.created_by,
            name=request.name,
            purpose=request.purpose,
            boundary_type=request.boundary_type,
            governance=request.governance,
            visibility=request.visibility,
            temporality=request.temporality,
            naming_policy=request.naming_policy,
            naming_conflict_mode=request.naming_conflict_mode,
        ).to_dict()

    @app.post("/spaces/{space_id}/join")
    def join_space(space_id: str, request: SpaceJoinRequest) -> dict[str, Any]:
        return services.spaces.join_space(space_id, request.agent_name, membership_role=request.membership_role).to_dict()

    @app.post("/spaces/{space_id}/leave")
    def leave_space(space_id: str, request: SpaceLeaveRequest) -> dict[str, Any]:
        return services.spaces.leave_space(space_id, request.agent_name, reason=request.reason).to_dict()

    @app.get("/spaces/{space_id}/members")
    def space_members(space_id: str) -> dict[str, Any]:
        return {"members": services.spaces.members(space_id)}

    @app.get("/spaces/{space_id}/presence")
    def space_presence(space_id: str) -> dict[str, Any]:
        return {"presence": services.spaces.presence(space_id)}

    @app.post("/spaces/{space_id}/identity")
    def set_space_identity(space_id: str, request: SpaceIdentityRequest) -> dict[str, Any]:
        return {
            "member": services.spaces.set_participation_name(
                space_id,
                request.agent_name,
                request.participation_name,
            ).to_dict()
        }

    @app.get("/spaces/{space_id}/seats")
    def list_space_seats(space_id: str) -> dict[str, Any]:
        return {"seats": services.spaces.seats(space_id)}

    @app.post("/spaces/{space_id}/seats")
    def bind_space_seat(space_id: str, request: SpaceSeatRequest) -> dict[str, Any]:
        return {
            "seat": services.spaces.bind_seat(
                space_id,
                request.seat_name,
                actor=request.actor,
                occupant_agent=request.occupant_agent,
                note=request.note,
                binding_mode=request.binding_mode,
            ).to_dict()
        }

    @app.get("/agents/{agent_name}/spaces")
    def list_agent_spaces(agent_name: str, include_inactive: bool = False) -> dict[str, Any]:
        return {"spaces": services.spaces.list_spaces_for_agent(agent_name, include_inactive=include_inactive)}

    @app.get("/messages/{message_id}")
    def get_message(message_id: str) -> dict[str, Any]:
        message = services.db.get_message(message_id)
        if not message:
            raise HTTPException(status_code=404, detail=f"Message {message_id} not found.")
        if isinstance(message.get("metadata"), str):
            try:
                message["metadata"] = json.loads(message["metadata"])
            except json.JSONDecodeError:
                pass
        return {"message": message}

    @app.post("/messages/send")
    def send_message(request: MessageSendRequest) -> dict[str, Any]:
        return services.messaging.send(
            sender=request.sender,
            recipient=request.recipient,
            subject=request.subject,
            body=request.body,
            msg_type=request.msg_type,
            priority=request.priority,
            payload=request.payload,
            metadata=request.metadata,
            reply_to=request.reply_to,
            trace_id=request.trace_id,
            context_id=request.context_id,
            space_id=request.space_id,
            thread_id=request.thread_id,
            sender_session_id=request.sender_session_id,
        )

    @app.post("/messages/reply")
    def reply_message(request: MessageReplyRequest) -> dict[str, Any]:
        return services.messaging.respond(
            sender=request.sender,
            message_id=request.message_id,
            body=request.body,
            subject=request.subject,
            priority=request.priority,
            msg_type=request.msg_type,
            sender_session_id=request.sender_session_id,
        )

    @app.get("/agents/{agent_name}/inbox")
    def inbox(
        agent_name: str,
        limit: int = Query(default=50, ge=1, le=500),
        mark_seen: bool = True,
        space_id: str | None = None,
        thread_id: str | None = None,
    ) -> dict[str, Any]:
        return {
            "messages": services.messaging.inbox(
                agent_name,
                limit=limit,
                mark_seen=mark_seen,
                space_id=space_id,
                thread_id=thread_id,
            )
        }

    @app.get("/agents/{agent_name}/outbox")
    def outbox(
        agent_name: str,
        limit: int = Query(default=20, ge=1, le=500),
        space_id: str | None = None,
        thread_id: str | None = None,
    ) -> dict[str, Any]:
        return {
            "messages": services.messaging.outbox(
                agent_name,
                limit=limit,
                space_id=space_id,
                thread_id=thread_id,
            )
        }

    @app.get("/threads/{thread_id}")
    def thread(thread_id: str, agent: str = Query(...), limit: int = Query(default=100, ge=1, le=500)) -> dict[str, Any]:
        return {"messages": services.messaging.thread(agent, thread_id, limit=limit)}

    @app.post("/work/offer")
    def offer_work(request: WorkOfferRequest) -> dict[str, Any]:
        return services.coordination.offer_work(
            creator=request.creator,
            assignee=request.assignee,
            title=request.title,
            description=request.description,
            space_id=request.space_id,
            metadata=request.metadata,
        )

    @app.post("/work/{work_id}/accept")
    def accept_work(work_id: str, request: WorkActorRequest) -> dict[str, Any]:
        return services.coordination.accept_work(work_id, actor=request.actor, note=request.note)

    @app.post("/work/{work_id}/start")
    def start_work(work_id: str, request: WorkActorRequest) -> dict[str, Any]:
        return services.coordination.start_work(work_id, actor=request.actor, note=request.note)

    @app.post("/work/{work_id}/block")
    def block_work(work_id: str, request: WorkActorRequest) -> dict[str, Any]:
        if not request.note:
            raise HTTPException(status_code=422, detail="Blocking a work item requires a note.")
        return services.coordination.block_work(work_id, actor=request.actor, note=request.note)

    @app.post("/work/{work_id}/handoff")
    def handoff_work(work_id: str, request: WorkHandoffRequest) -> dict[str, Any]:
        return services.coordination.request_handoff(
            work_id,
            actor=request.actor,
            new_owner=request.new_owner,
            note=request.note,
        )

    @app.post("/work/{work_id}/reject")
    def reject_work(work_id: str, request: WorkActorRequest) -> dict[str, Any]:
        return services.coordination.reject_work(work_id, actor=request.actor, note=request.note)

    @app.post("/work/{work_id}/close")
    def close_work(work_id: str, request: WorkActorRequest) -> dict[str, Any]:
        return services.coordination.close_work(work_id, actor=request.actor, note=request.note)

    @app.get("/work/{work_id}")
    def get_work(work_id: str) -> dict[str, Any]:
        return services.coordination.get_work(work_id)

    @app.get("/work/{work_id}/baton")
    def get_baton(work_id: str) -> dict[str, Any]:
        return services.coordination.handoff_baton(work_id)

    @app.get("/agents/{agent_name}/work")
    def list_work(agent_name: str, space_id: str | None = None, state: str | None = None) -> dict[str, Any]:
        return {
            "work": services.coordination.list_work(
                agent_name=agent_name,
                space_id=space_id,
                state=state,
            )
        }

    @app.post("/batons/{baton_ref}/ack")
    def baton_ack(baton_ref: str, request: BatonAckRequest) -> dict[str, Any]:
        return services.coordination.apply_baton_ack(
            baton_ref,
            actor=request.actor,
            decision=request.decision,
            conditions=request.conditions,
            reason=request.reason,
        )

    @app.post("/batons/{baton_ref}/update")
    def baton_update(baton_ref: str, request: BatonUpdateRequest) -> dict[str, Any]:
        return services.coordination.apply_baton_update(
            baton_ref,
            actor=request.actor,
            state=request.state,
            progress=request.progress,
            artifact_refs=request.artifact_refs,
            branch=request.branch,
            head_commit=request.head_commit,
        )

    @app.post("/batons/{baton_ref}/close")
    def baton_close(baton_ref: str, request: BatonCloseRequest) -> dict[str, Any]:
        return services.coordination.apply_baton_close(
            baton_ref,
            actor=request.actor,
            outcome=request.outcome,
            summary=request.summary,
            artifact_refs=request.artifact_refs,
            branch=request.branch,
            head_commit=request.head_commit,
        )

    return app



def _extract_registered_wake_adapters(metadata: Any) -> list[dict[str, Any]]:
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata)
        except json.JSONDecodeError:
            return []
    if not isinstance(metadata, dict):
        return []

    regs = metadata.get("adapter_registrations")
    if not isinstance(regs, dict):
        return []

    adapters: list[dict[str, Any]] = []
    for key, value in regs.items():
        if not isinstance(value, dict):
            continue
        adapter = dict(value)
        adapter.setdefault("adapter_kind", str(key))
        adapters.append(adapter)
    return adapters


def _select_registered_wake_adapter(
    adapters: list[dict[str, Any]],
    *,
    action: str,
) -> tuple[dict[str, Any] | None, str | None]:
    normalized_action = str(action or "").strip().lower()
    if not normalized_action or normalized_action == "suppress":
        return None, None

    valid_dispatch_actions = {"notify", "stage_context", "infer"}

    def _state_rank(adapter: dict[str, Any]) -> int:
        state = str(adapter.get("state") or "").strip().lower()
        if state in {"ready", "supported"}:
            return 2
        if state == "unsupported":
            return 0
        return 1

    exact_matches: list[tuple[int, int, dict[str, Any], str]] = []
    fallback_matches: list[tuple[int, int, dict[str, Any], str]] = []

    for index, adapter in enumerate(adapters):
        endpoint_url = str(adapter.get("endpoint_url") or "").strip()
        if not endpoint_url or _state_rank(adapter) == 0:
            continue

        supported_actions = [
            str(item).strip().lower()
            for item in list(adapter.get("supported_actions") or [])
            if str(item).strip()
        ]
        fallback_action = str(adapter.get("fallback_action") or "suppress").strip().lower() or "suppress"
        rank = _state_rank(adapter)

        if normalized_action in supported_actions:
            exact_matches.append((rank, index, adapter, normalized_action))
            continue
        if fallback_action in valid_dispatch_actions and fallback_action != "suppress":
            fallback_matches.append((rank, index, adapter, fallback_action))

    if exact_matches:
        _, _, adapter, selected_action = sorted(exact_matches, key=lambda item: (-item[0], item[1]))[0]
        return adapter, selected_action
    if fallback_matches:
        _, _, adapter, selected_action = sorted(fallback_matches, key=lambda item: (-item[0], item[1]))[0]
        return adapter, selected_action
    return None, None


def _jolt_dispatch_loop(db_path: str | None = None) -> list[dict[str, Any]]:
    from whispers.storage.db import WhispersDB
    db = WhispersDB(db_path=db_path)
    discovered: list[dict[str, Any]] = []
    try:
        rows = db.active_jolt_adapters()
        for row in rows:
            for adapter in _extract_registered_wake_adapters(row["metadata"]):
                discovered.append({"agent_name": row["agent_name"], **adapter})
    except Exception as e:
        print("Jolt lookup failed:", e)
    return discovered



def main() -> None:
    db_path = os.getenv("WHISPERS_DB_PATH")
    host = os.getenv("WHISPERS_HOST", "127.0.0.1")
    port = int(os.getenv("WHISPERS_PORT", "8765"))
    uvicorn.run(create_app(db_path=db_path), host=host, port=port)


# Back-compat for older installed console scripts that still import whispers.server:start.
start = main


if __name__ == "__main__":
    main()
