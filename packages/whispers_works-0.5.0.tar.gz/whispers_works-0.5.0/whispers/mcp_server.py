from __future__ import annotations

import argparse
import asyncio
import logging
import os
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from mcp.server.fastmcp import Context, FastMCP
from mcp.server.fastmcp.server import TransportSecuritySettings

from .client import WhispersClient, WhispersConflictError, WhispersException
from .continuity import ContinuityService
from .storage.db import WhispersDB

# Curated pool used by _suggest_unused_callsign. Short, plain-English, monosyllabic
# where possible. The suggester filters out held names and falls back to a
# randomized suffix if the whole pool is exhausted, so the caller always
# ends up with something usable.
_FRIENDLY_CALLSIGN_POOL: tuple[str, ...] = (
    "nova", "sage", "wren", "moss", "pine", "reed", "drift", "kite",
    "slate", "quill", "gale", "vale", "fern", "brook", "clove", "birch",
    "hazel", "linen", "marsh", "thorn", "gust", "dune", "ridge", "loam",
    "quartz", "ember", "spruce", "willow", "iris", "cedar",
)

# Fresh-caller peer discovery is "live" if the peer's session last_seen is
# within this window. Matches the 10-minute convention used elsewhere for
# "online" presence so operator-facing surfaces stay consistent.
_PEER_LIVE_WINDOW_MINUTES = 10


def _classify_conflict_kind(details: Mapping[str, Any]) -> str:
    """Infer the collision kind from ContinuityConflictError.details.

    Returns one of: anchor_mismatch, ledger_reservation,
    anchor_has_presentations, rejected. Used by bind_seat to shape the
    collision envelope returned to the caller.
    """
    if not isinstance(details, Mapping):
        return "anchor_mismatch"
    if "reserved_stable_subject_id" in details:
        return "ledger_reservation"
    if "existing_agent_id" in details or "existing_continuity_anchor" in details:
        return "anchor_mismatch"
    if "anchored_presentations" in details:
        return "anchor_has_presentations"
    return "anchor_mismatch"


logger = logging.getLogger(__name__)

WHISPERS_HOME = Path.home() / ".whispers"
CLAUDE_SESSIONS_DIR = WHISPERS_HOME / "claude-sessions"
CLAUDE_BREADCRUMB_DIR = CLAUDE_SESSIONS_DIR / "_breadcrumbs"


def _header_value(headers: Mapping[str, Any] | None, *names: str) -> str | None:
    if not headers:
        return None
    for name in names:
        value = headers.get(name)
        if value:
            text = str(value).strip()
            if text:
                return text
    return None


def _read_claude_breadcrumb(*, whispers_home: Path | None = None, parent_pid: int | None = None) -> str | None:
    effective_home = whispers_home or WHISPERS_HOME
    effective_parent_pid = parent_pid if parent_pid is not None else os.getppid()
    breadcrumb = effective_home / "claude-sessions" / "_breadcrumbs" / str(effective_parent_pid)
    try:
        if breadcrumb.is_file():
            value = breadcrumb.read_text(encoding="utf-8").strip()
            return value or None
    except OSError:
        return None
    return None


def scan_breadcrumbs_for_live_claude_session(
    *,
    whispers_home: Path | None = None,
) -> str | None:
    """Fallback session-ID resolution via breadcrumb directory scan.

    The MCP bridge is a long-running daemon, not a child of any Claude
    Code window — so `os.getppid()` doesn't identify a Claude process
    and the direct breadcrumb lookup misses. This helper scans the
    breadcrumbs directory and returns the session ID for the single
    alive Claude PID, if exactly one exists.

    Multiple alive PIDs: returns None (can't know which window this
    request came from without per-request routing).
    Zero alive PIDs: returns None.
    Exactly one: returns its breadcrumb content.

    Intended as the last-resort step in `resolve_claude_session_id`
    so fresh `bind_seat(platform_family="claude-code")` calls don't
    uniformly fail with `claude_session_id_unavailable` when Claude
    Code's MCP config doesn't forward the session ID.
    """
    effective_home = whispers_home or WHISPERS_HOME
    bc_dir = effective_home / "claude-sessions" / "_breadcrumbs"
    if not bc_dir.is_dir():
        return None

    try:
        import psutil  # type: ignore
    except ImportError:
        return None

    live_sessions: list[str] = []
    for entry in bc_dir.iterdir():
        if not entry.is_file():
            continue
        name = entry.name
        if not name.isdigit():
            continue
        pid = int(name)
        try:
            alive = psutil.pid_exists(pid)
        except Exception:
            alive = False
        if not alive:
            continue
        try:
            value = entry.read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if value:
            live_sessions.append(value)
        if len(live_sessions) > 1:
            return None  # ambiguous, bail

    if len(live_sessions) == 1:
        return live_sessions[0]
    return None


def resolve_claude_session_id(
    ctx: Context | None = None,
    *,
    env: Mapping[str, str] | None = None,
    whispers_home: Path | None = None,
    parent_pid: int | None = None,
    safe_only: bool = False,
) -> str | None:
    """Resolve the Claude Code session ID of the current MCP request.

    Resolution order (highest confidence first):
      1. HTTP header (x-whispers-claude-session-id and aliases)
      2. Query param (whispers_claude_session_id / claude_session_id)
      3. WHISPERS_CLAUDE_SESSION_ID env var
      4. Direct breadcrumb lookup keyed by this process's PPID
      5. *Scan fallback* — pick the single alive Claude PID from the
         breadcrumbs dir when exactly one exists (single-window case)

    The first four sources are *safe*: each proves the requester IS the
    Claude Code session in question (explicit attestation or direct
    parent-child relationship). The fifth source is an *inference* — it
    just finds the only alive Claude and assumes that must be us. That
    assumption breaks whenever some OTHER process (pytest subprocess,
    unrelated bash script, test harness) runs while a Claude Code
    window is open: the scan returns Claude Code's session ID to a
    caller that has no relationship to that window.

    ``safe_only=True`` disables the scan fallback. Use it for any path
    that performs a USER-LEVEL WRITE keyed by the returned session ID
    (e.g. ``write_statusline_binding``). If the safe sources miss, the
    caller should fall back to graceful-degradation (statusline sync
    warning + operator-run ``whispers adopt``) rather than writing to
    an inferred ID that might belong to another terminal.
    """
    request = None
    if ctx is not None:
        try:
            request = ctx.request_context.request
        except Exception:
            request = None
    if request is not None:
        header_value = _header_value(
            request.headers,
            "x-whispers-claude-session-id",
            "whispers-claude-session-id",
            "x-claude-session-id",
            "claude-session-id",
        )
        if header_value:
            return header_value
        try:
            for name in (
                "whispers_claude_session_id",
                "claude_session_id",
            ):
                value = request.query_params.get(name)
                if value:
                    text = str(value).strip()
                    if text:
                        return text
        except Exception:
            pass
    effective_env = env if env is not None else os.environ
    env_value = str(effective_env.get("WHISPERS_CLAUDE_SESSION_ID", "")).strip()
    if env_value:
        return env_value
    direct = _read_claude_breadcrumb(whispers_home=whispers_home, parent_pid=parent_pid)
    if direct:
        return direct
    if safe_only:
        return None
    # Slice 8 fallback: scan the breadcrumbs dir for the single alive
    # Claude PID. Handles the dominant single-window case post-restart
    # when the bridge's ppid doesn't match any Claude process. Unsafe
    # for user-level writes — see docstring.
    return scan_breadcrumbs_for_live_claude_session(whispers_home=whispers_home)


def resolve_mcp_client_key(ctx: Context) -> str:
    keys = resolve_mcp_client_keys(ctx)
    return keys[0] if keys else "anonymous"


def resolve_mcp_client_keys(ctx: Context) -> list[str]:
    """Return ALL candidate client keys from a ctx, in preference order.

    Stability fix: any single source (claude session id, ctx.client_id,
    mcp-session-id header) can drift or disappear between adjacent
    tool calls. Binding under all candidates and looking up by any of
    them means a request that would otherwise miss the preferred key
    still recovers.
    """
    keys: list[str] = []
    seen: set[str] = set()

    def _add(k: str | None) -> None:
        if not k:
            return
        if k in seen:
            return
        seen.add(k)
        keys.append(k)

    claude_session_id = resolve_claude_session_id(ctx=ctx)
    if claude_session_id:
        _add(f"claude-session:{claude_session_id}")
    if ctx.client_id:
        _add(str(ctx.client_id))
    try:
        request = ctx.request_context.request
        if request is not None:
            session_id = request.headers.get("mcp-session-id")
            if session_id:
                _add(str(session_id))
    except Exception:
        pass
    try:
        session = ctx.request_context.session
        if session is not None:
            _add(f"session-{id(session)}")
    except Exception:
        pass
    if not keys:
        _add("anonymous")
    return keys


def write_statusline_binding(
    *,
    claude_session_id: str,
    callsign: str,
    whispers_home: Path | None = None,
) -> Path:
    effective_home = whispers_home or WHISPERS_HOME
    sessions_dir = effective_home / "claude-sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    bind_file = sessions_dir / f"{claude_session_id}.callsign"
    bind_file.write_text(str(callsign).strip(), encoding="utf-8")
    return bind_file


def clear_statusline_binding(claude_session_id: str, *, whispers_home: Path | None = None) -> None:
    effective_home = whispers_home or WHISPERS_HOME
    bind_file = effective_home / "claude-sessions" / f"{claude_session_id}.callsign"
    try:
        bind_file.unlink(missing_ok=True)
    except TypeError:
        if bind_file.exists():
            bind_file.unlink()


def sync_session_metadata(client: WhispersClient, *, claude_session_id: str | None = None) -> None:
    metadata: dict[str, Any] = {}
    try:
        with client.db.get_connection() as conn:
            row = conn.execute(
                "SELECT metadata FROM agent_sessions WHERE session_id = ?",
                (client.session_id,),
            ).fetchone()
        if row and row["metadata"]:
            metadata = json.loads(row["metadata"])
    except Exception:
        metadata = {}
    if claude_session_id:
        client.extra_session_metadata["claude_session_id"] = claude_session_id
    metadata.update(client._session_metadata())
    client.db.upsert_agent_session(
        session_id=client.session_id,
        agent_name=client.agent_name,
        agent_id=client._agent_id(),
        session_kind=client.session_kind,
        process_id=client.process_id,
        metadata=metadata,
    )


def _build_discoverable_peers(
    *,
    db_path: str,
    budget: int = 5,
    live_window_minutes: int = _PEER_LIVE_WINDOW_MINUTES,
) -> dict[str, Any]:
    """First-touch peer discovery for callers that haven't bound yet.

    Returns up to `budget` peers currently live on the network (an agent_session
    whose last_seen_at is within `live_window_minutes`), ranked by a simple
    salience = trust_tier * activity_weight. Intentionally narrower than
    `orientation.build_peers_section` (which is scope-aware and needs a
    self_callsign) — an unbound caller has no scope yet, so the discovery
    surface is population-wide.

    This is the novel affordance: a fresh agent sees the participants it is
    about to join the fabric alongside, with enough information to pick a
    non-colliding callsign on its first move.

    Each surfaced peer carries only public fields — callsign, participant_shape,
    trust_tier, last_seen_at, presence, salience. Internal identifiers
    (agent_id, continuity_anchor, stable_subject_id) are withheld from
    pre-bind callers because no binding handshake has occurred.
    """
    import datetime as _dt
    import sqlite3 as _sqlite3

    now = _dt.datetime.utcnow()
    cutoff_window_seconds = int(live_window_minutes) * 60
    peers: list[dict[str, Any]] = []
    live_count = 0

    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        rows = conn.execute(
            """
            SELECT
                s.agent_name AS callsign,
                s.last_seen_at AS last_seen_at,
                c.trust_tier AS trust_tier,
                c.participant_shape AS participant_shape
            FROM agent_sessions s
            LEFT JOIN agent_cards c
                ON c.callsign = s.agent_name
               AND c.deregistered_at IS NULL
            WHERE s.lease_expires_at >= CURRENT_TIMESTAMP
              AND s.last_seen_at >= datetime('now', ?)
            """,
            (f"-{cutoff_window_seconds} seconds",),
        ).fetchall()

        # Deduplicate by callsign — one agent may hold multiple sessions.
        seen_callsigns: set[str] = set()
        for row in rows:
            callsign = str(row["callsign"] or "").strip().lower()
            if not callsign or callsign in seen_callsigns:
                continue
            seen_callsigns.add(callsign)
            live_count += 1

            last_seen_raw = row["last_seen_at"]
            try:
                last_seen_dt = _dt.datetime.fromisoformat(str(last_seen_raw).replace("Z", ""))
            except (TypeError, ValueError):
                last_seen_dt = None
            if last_seen_dt is None:
                activity_weight = 0.1
                last_seen_iso: str | None = None
            else:
                minutes_ago = max(1.0, (now - last_seen_dt).total_seconds() / 60.0)
                activity_weight = 1.0 / (1.0 + (minutes_ago / 60.0))
                last_seen_iso = last_seen_dt.isoformat() + "Z"

            trust_tier = int(row["trust_tier"] or 0)
            shape = str(row["participant_shape"] or "atomic")
            salience = activity_weight * max(1, trust_tier)

            peers.append({
                "callsign": callsign,
                "trust_tier": trust_tier,
                "participant_shape": shape,
                "last_seen_at": last_seen_iso,
                "presence": "online",
                "salience": round(salience, 4),
            })
    finally:
        conn.close()

    peers.sort(key=lambda p: (-p["salience"], p["callsign"]))
    kept = peers[:budget]
    return {
        "peers": kept,
        "live_count": live_count,
        "live_window_minutes": live_window_minutes,
        "selection_basis": "network_wide_live_sessions",
    }


def _suggest_unused_callsign(*, db_path: str) -> str:
    """Pick a friendly callsign not currently held in callsign_ledger or agent_cards.

    Walks the curated pool; if every pool entry is taken, falls back to the
    first pool entry with a numeric suffix (`nova-42`) so the caller still
    receives a usable, collision-free suggestion.
    """
    import random
    import sqlite3 as _sqlite3

    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        held: set[str] = set()
        for row in conn.execute(
            "SELECT callsign FROM agent_cards WHERE deregistered_at IS NULL"
        ).fetchall():
            held.add(str(row["callsign"] or "").strip().lower())
        for row in conn.execute(
            "SELECT DISTINCT agent_name FROM agent_sessions "
            "WHERE lease_expires_at >= CURRENT_TIMESTAMP"
        ).fetchall():
            held.add(str(row["agent_name"] or "").strip().lower())
        try:
            for row in conn.execute(
                "SELECT callsign FROM callsign_ledger WHERE released_at IS NULL"
            ).fetchall():
                held.add(str(row["callsign"] or "").strip().lower())
        except _sqlite3.OperationalError:
            # Schema variant where the ledger column is shaped differently.
            # The agent_cards + agent_sessions check is still enough to avoid
            # active collisions; fall through without the ledger layer.
            pass
    finally:
        conn.close()

    candidates = [name for name in _FRIENDLY_CALLSIGN_POOL if name not in held]
    if candidates:
        return random.choice(candidates)

    # Exhausted the pool — tack a random two-digit suffix onto the first pool
    # entry, retrying if that happens to collide. Bounded by a few attempts so
    # we never spin forever.
    base = _FRIENDLY_CALLSIGN_POOL[0]
    for _ in range(8):
        candidate = f"{base}-{random.randint(10, 99)}"
        if candidate not in held:
            return candidate
    # Extremely unlikely path — return a time-stamped fallback.
    import time
    return f"{base}-{int(time.time()) % 10000}"


@dataclass(frozen=True)
class MCPSeatConfig:
    agent_name: str | None = None
    db_path: str | None = None
    owner_id: str | None = None
    platform_family: str | None = None
    context_hint: str | None = None
    participant_profile: str = "desktop_ide_agent"
    allow_sibling: bool = False
    sibling_label: str | None = None
    session_kind: str = "mcp_stdio"


@dataclass(frozen=True)
class WakeAdapterConfig:
    adapter_kind: str
    supported_actions: tuple[str, ...] = ()
    fallback_action: str | None = None
    state: str | None = None
    detail: str | None = None
    endpoint_url: str | None = None


class MCPSeatManager:
    def __init__(
        self,
        config: MCPSeatConfig,
        *,
        default_wake_adapter: WakeAdapterConfig | None = None,
    ):
        self.config = config
        self.default_wake_adapter = default_wake_adapter
        self._lock = threading.RLock()
        self._fixed_client: WhispersClient | None = None
        self._clients: dict[str, WhispersClient] = {}
        # Stability fix: the client_key computed from ctx can drift
        # between calls (breadcrumb scan flips, ctx.client_id absent,
        # mcp-session-id varies). Track a list of alias keys per bound
        # client so lookup by any key hits, and unbind cleans all.
        self._aliases_by_primary: dict[str, list[str]] = {}
        if config.agent_name:
            self._fixed_client = self._make_client(config.agent_name, config=config)

    def _make_client(
        self,
        agent_name: str,
        *,
        config: MCPSeatConfig,
        display_name: str | None = None,
        session_name: str | None = None,
    ) -> WhispersClient:
        client = WhispersClient(
            agent_name,
            db_path=config.db_path,
            display_name=display_name,
            session_name=session_name,
            owner_id=config.owner_id,
            platform_family=config.platform_family,
            context_hint=config.context_hint,
            participant_profile=config.participant_profile,
            allow_sibling=config.allow_sibling,
            sibling_label=config.sibling_label,
            session_kind=config.session_kind,
        )
        if self.default_wake_adapter:
            client.wake_register_adapter(
                adapter_kind=self.default_wake_adapter.adapter_kind,
                supported_actions=list(self.default_wake_adapter.supported_actions),
                fallback_action=self.default_wake_adapter.fallback_action,
                state=self.default_wake_adapter.state,
                detail=self.default_wake_adapter.detail,
                endpoint_url=self.default_wake_adapter.endpoint_url,
            )
        return client

    def bind_client(
        self,
        client_key: str,
        *,
        requested_callsign: str,
        display_name: str | None = None,
        session_name: str | None = None,
        owner_id: str | None = None,
        platform_family: str | None = None,
        context_hint: str | None = None,
        participant_profile: str | None = None,
        allow_sibling: bool = False,
        sibling_label: str | None = None,
        session_kind: str = "mcp_http",
        alias_keys: list[str] | None = None,
    ) -> WhispersClient:
        """Bind a client under `client_key`. Optional `alias_keys` are
        additional lookup keys registered under the same client, so a
        caller whose key-resolution drifts between calls still finds
        the bound client. Passing the same primary key twice returns the
        same client (idempotent).
        """
        with self._lock:
            existing = self._clients.get(client_key)
            if existing:
                if alias_keys:
                    for alias in alias_keys:
                        if alias and alias != client_key and alias not in self._clients:
                            self._clients[alias] = existing
                            self._aliases_by_primary.setdefault(client_key, []).append(alias)
                return existing
            bound = self._make_client(
                requested_callsign,
                config=MCPSeatConfig(
                    agent_name=requested_callsign,
                    db_path=self.config.db_path,
                    owner_id=owner_id,
                    platform_family=platform_family,
                    context_hint=context_hint,
                    participant_profile=participant_profile or self.config.participant_profile,
                    allow_sibling=allow_sibling,
                    sibling_label=sibling_label,
                    session_kind=session_kind,
                ),
                display_name=display_name,
                session_name=session_name,
            )
            self._clients[client_key] = bound
            if alias_keys:
                registered: list[str] = []
                for alias in alias_keys:
                    if alias and alias != client_key:
                        self._clients[alias] = bound
                        registered.append(alias)
                if registered:
                    self._aliases_by_primary[client_key] = registered
            return bound

    def unbind_client(self, client_key: str) -> None:
        with self._lock:
            client = self._clients.pop(client_key, None)
            # Clean aliases: either key_in was the primary (pop all its
            # aliases) or was an alias (find primary and clean everything).
            if client_key in self._aliases_by_primary:
                for alias in self._aliases_by_primary.pop(client_key, []):
                    self._clients.pop(alias, None)
            else:
                for primary, aliases in list(self._aliases_by_primary.items()):
                    if client_key in aliases:
                        self._clients.pop(primary, None)
                        for alias in aliases:
                            self._clients.pop(alias, None)
                        self._aliases_by_primary.pop(primary, None)
                        break
        if client:
            client.close()

    def get_client(self, client_key: str | None = None) -> WhispersClient | None:
        with self._lock:
            if client_key and client_key in self._clients:
                return self._clients[client_key]
            return self._fixed_client

    def require_client(self, client_key: str | None = None) -> WhispersClient:
        client = self.get_client(client_key)
        if not client:
            raise WhispersException(
                "No Whispers seat is bound for this MCP session yet. Call bind_seat first."
            )
        return client

    def require_client_by_candidates(self, candidates: list[str]) -> WhispersClient:
        """Try each candidate key in order, return the first hit.
        Fixes the stability issue where a single ctx-derived key can
        drift between adjacent calls (Slice-8 scan flips, ctx.client_id
        absent, mcp-session-id varies).
        """
        with self._lock:
            for key in candidates:
                if key and key in self._clients:
                    return self._clients[key]
            if self._fixed_client:
                return self._fixed_client
        raise WhispersException(
            "No Whispers seat is bound for this MCP session yet. Call bind_seat first."
        )

    def startup_surface(self, client_key: str | None = None) -> dict[str, Any]:
        client = self.get_client(client_key)
        bound = client is not None
        surface: dict[str, Any] = {
            "bound": bound,
            "fixed_seat": self._fixed_client is not None,
            "client_key": client_key,
            "default_participant_profile": self.config.participant_profile,
            "seat": client.status() if client else None,
        }
        if not bound and self.config.db_path is not None:
            try:
                discovered = _build_discoverable_peers(db_path=self.config.db_path)
            except Exception:  # pragma: no cover — DB errors become empty peers
                logger.exception("discover_peers failed in startup_surface")
                discovered = {
                    "peers": [],
                    "live_count": 0,
                    "live_window_minutes": _PEER_LIVE_WINDOW_MINUTES,
                    "selection_basis": "network_wide_live_sessions",
                }
            try:
                suggested = _suggest_unused_callsign(db_path=self.config.db_path)
            except Exception:  # pragma: no cover
                logger.exception("suggest_callsign failed in startup_surface")
                suggested = _FRIENDLY_CALLSIGN_POOL[0]
            surface["discovered_peers"] = discovered
            surface["recommended_action"] = {
                "action": "bind_seat",
                "suggested_callsign": suggested,
                "reason": (
                    "No seat is bound for this MCP session. Call bind_seat "
                    "with the suggested callsign (or pick your own); "
                    "discovered_peers shows who is already live."
                ),
            }
        return surface



def _env_bool(name: str, default: bool = False) -> bool:
    raw = str(os.getenv(name, "")).strip().lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "on"}



def _env_csv(name: str) -> list[str]:
    raw = str(os.getenv(name, "")).strip()
    if not raw:
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]



def _host_with_wildcard_port(host: str) -> str:
    return host if host.endswith(":*") else f"{host}:*"



def build_transport_security_settings(*, listen_host: str | None = None) -> TransportSecuritySettings:
    dns_rebinding_enabled = _env_bool("WHISPERS_MCP_DNS_REBINDING_PROTECTION", True)
    if "WHISPERS_MCP_ENABLE_DNS_REBINDING_PROTECTION" in os.environ:
        dns_rebinding_enabled = _env_bool("WHISPERS_MCP_ENABLE_DNS_REBINDING_PROTECTION", dns_rebinding_enabled)
    if not dns_rebinding_enabled:
        return TransportSecuritySettings(enable_dns_rebinding_protection=False)

    allowed_hosts = {
        "127.0.0.1",
        "127.0.0.1:*",
        "localhost",
        "localhost:*",
        "[::1]",
        "[::1]:*",
        "testserver",
        "testserver:*",
    }
    allowed_origins = {
        "http://127.0.0.1:*",
        "https://127.0.0.1:*",
        "http://localhost:*",
        "https://localhost:*",
        "http://[::1]:*",
        "https://[::1]:*",
    }

    normalized_host = str(listen_host or "").strip()
    if normalized_host and normalized_host not in {"0.0.0.0", "::"}:
        allowed_hosts.add(normalized_host)
        allowed_hosts.add(_host_with_wildcard_port(normalized_host))
        allowed_origins.add(f"http://{normalized_host}:*")
        allowed_origins.add(f"https://{normalized_host}:*")

    allowed_hosts.update(_env_csv("WHISPERS_MCP_ALLOWED_HOSTS"))
    allowed_origins.update(_env_csv("WHISPERS_MCP_ALLOWED_ORIGINS"))

    return TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=sorted(allowed_hosts),
        allowed_origins=sorted(allowed_origins),
    )



def load_default_wake_adapter_from_env() -> WakeAdapterConfig | None:
    adapter_kind = str(
        os.getenv("WHISPERS_JOLT_ADAPTER_KIND")
        or os.getenv("WHISPERS_ADAPTER_KIND")
        or ""
    ).strip()
    if not adapter_kind:
        return None
    supported_actions: list[str] = []
    if _env_bool("WHISPERS_JOLT_CAN_NOTIFY", True):
        supported_actions.append("notify")
    if _env_bool("WHISPERS_JOLT_CAN_STAGE_CONTEXT", False):
        supported_actions.append("stage_context")
    if _env_bool("WHISPERS_JOLT_CAN_TRIGGER_INFERENCE", False):
        supported_actions.append("infer")
    return WakeAdapterConfig(
        adapter_kind=adapter_kind,
        supported_actions=tuple(supported_actions),
        fallback_action=str(os.getenv("WHISPERS_JOLT_FALLBACK_ACTION") or "").strip() or None,
        state=str(os.getenv("WHISPERS_JOLT_STATE") or "").strip() or None,
        detail=str(os.getenv("WHISPERS_JOLT_DETAIL") or "").strip() or None,
        endpoint_url=str(os.getenv("WHISPERS_JOLT_ENDPOINT_URL") or "").strip() or None,
    )



def config_from_env(*, session_kind: str) -> MCPSeatConfig:
    return MCPSeatConfig(
        agent_name=str(os.getenv("WHISPERS_AGENT_NAME") or "").strip() or None,
        db_path=str(os.getenv("WHISPERS_DB_PATH") or "").strip() or None,
        owner_id=str(os.getenv("WHISPERS_OWNER_ID") or "").strip() or None,
        platform_family=str(os.getenv("WHISPERS_PLATFORM_FAMILY") or "").strip() or None,
        context_hint=str(os.getenv("WHISPERS_CONTEXT_HINT") or "").strip() or None,
        participant_profile=str(os.getenv("WHISPERS_PARTICIPANT_PROFILE") or "desktop_ide_agent").strip() or "desktop_ide_agent",
        allow_sibling=_env_bool("WHISPERS_ALLOW_SIBLING", False),
        sibling_label=str(os.getenv("WHISPERS_SIBLING_LABEL") or "").strip() or None,
        session_kind=session_kind,
    )



def create_mcp(
    *,
    db_path: str | None = None,
    fixed_agent_name: str | None = None,
    owner_id: str | None = None,
    platform_family: str | None = None,
    context_hint: str | None = None,
    participant_profile: str = "desktop_ide_agent",
    allow_sibling: bool = False,
    sibling_label: str | None = None,
    session_kind: str = "mcp_stdio",
    listen_host: str | None = None,
) -> tuple[FastMCP, MCPSeatManager]:
    config = config_from_env(session_kind=session_kind)
    if db_path is not None:
        config = MCPSeatConfig(**{**config.__dict__, "db_path": db_path})
    if fixed_agent_name is not None:
        config = MCPSeatConfig(**{**config.__dict__, "agent_name": fixed_agent_name})
    if owner_id is not None:
        config = MCPSeatConfig(**{**config.__dict__, "owner_id": owner_id})
    if platform_family is not None:
        config = MCPSeatConfig(**{**config.__dict__, "platform_family": platform_family})
    if context_hint is not None:
        config = MCPSeatConfig(**{**config.__dict__, "context_hint": context_hint})
    if participant_profile is not None:
        config = MCPSeatConfig(**{**config.__dict__, "participant_profile": participant_profile})
    if allow_sibling:
        config = MCPSeatConfig(**{**config.__dict__, "allow_sibling": allow_sibling})
    if sibling_label is not None:
        config = MCPSeatConfig(**{**config.__dict__, "sibling_label": sibling_label})

    try:
        manager = MCPSeatManager(config, default_wake_adapter=load_default_wake_adapter_from_env())
        preview_db = WhispersDB(db_path=config.db_path, read_only=True)
        preview_continuity = ContinuityService(preview_db)
        mcp = FastMCP(
            name="Whispers",
            instructions="Bind a Whispers seat, then use ambient tools like whoami, status, send, inbox, wake, and chrome.",
            streamable_http_path="/",
            sse_path="/sse",
            message_path="/messages/",
            transport_security=build_transport_security_settings(listen_host=listen_host),
        )
    except Exception:
        logger.exception(
            "Failed to create Whispers MCP seat runtime",
            extra={
                "db_path": db_path,
                "fixed_agent_name": fixed_agent_name,
                "platform_family": platform_family,
                "session_kind": session_kind,
                "listen_host": listen_host,
            },
        )
        raise

    def _client_key(ctx: Context) -> str:
        return resolve_mcp_client_key(ctx)

    def _client_keys(ctx: Context) -> list[str]:
        return resolve_mcp_client_keys(ctx)

    def _seat(ctx: Context) -> WhispersClient:
        # Stability: try all candidate keys so client_key drift between
        # adjacent calls doesn't manifest as 'No Whispers seat bound.'
        return manager.require_client_by_candidates(_client_keys(ctx))

    def _bind_preview(
        *,
        requested_callsign: str,
        owner_id: str | None,
        platform_family: str | None,
        context_hint: str | None,
        sibling_label: str | None,
    ) -> dict[str, Any]:
        continuity_anchor = preview_continuity.derive_continuity_anchor(
            requested_callsign=requested_callsign,
            platform_family=platform_family or "script",
            owner_id=owner_id,
            context_hint=context_hint,
            sibling_label=sibling_label,
        )
        with preview_db.get_connection() as conn:
            existing = conn.execute(
                "SELECT agent_id, callsign, continuity_anchor FROM agent_cards WHERE callsign = ? AND deregistered_at IS NULL",
                (requested_callsign,),
            ).fetchone()
        existing_payload = dict(existing) if existing else None
        return {
            "requested_callsign": requested_callsign,
            "continuity_anchor": continuity_anchor,
            "same_anchor": bool(existing_payload) and existing_payload.get("continuity_anchor") == continuity_anchor,
            "existing": existing_payload,
        }

    @mcp.tool()
    def startup(ctx: Context) -> dict[str, Any]:
        return manager.startup_surface(_client_key(ctx))

    @mcp.tool()
    def bind_seat(
        ctx: Context,
        requested_callsign: str,
        display_name: str | None = None,
        session_name: str | None = None,
        owner_id: str | None = None,
        platform_family: str | None = None,
        context_hint: str | None = None,
        participant_profile: str | None = None,
        allow_sibling: bool = False,
        sibling_label: str | None = None,
        rebind: bool = False,
        resolve: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        del allow_sibling  # Crawl #3: sibling_label is the sole sibling trigger.

        # Slice 7: sweep agent_sessions rows rooted in dead OS processes
        # before any collision detection runs. Addresses symptom 1 in the
        # overhaul doc — stale sessions from a killed Claude window should
        # not hold anchor locks or inflate live-session counts on the
        # incoming bind.
        try:
            from .orientation import sweep_dead_pid_sessions
            sweep_dead_pid_sessions(
                db_path=config.db_path or str(WhispersDB().db_path),
                actor="bind_seat",
            )
        except Exception as _sweep_exc:
            logger.warning("dead_pid_sweep_failed: %s", _sweep_exc)

        # Slice 6 Phase C: apply the operator's collision-envelope choice
        # before entering the regular bind flow. When `resolve` is passed,
        # the caller is responding to a prior bind_seat call that returned
        # a {bound: false, collision: {...}, choices: [...]} envelope.
        effective_platform_family_for_resolve = (
            platform_family or config.platform_family or "claude-code"
        )
        if resolve is not None:
            from .orientation import apply_collision_resolution
            resolution = apply_collision_resolution(
                db_path=config.db_path or str(WhispersDB().db_path),
                requested_callsign=requested_callsign,
                platform_family=effective_platform_family_for_resolve,
                resolve=resolve,
                actor="bind_seat",
            )
            if not resolution.get("ok"):
                return {
                    "bound": False,
                    "rebind_pending": False,
                    "requested_callsign": requested_callsign,
                    "reason": resolution.get("reason", "resolution_failed"),
                    "resolved": resolution.get("resolved"),
                }
            if resolution["next_step"] == "cancelled":
                return {
                    "bound": False,
                    "rebind_pending": False,
                    "requested_callsign": requested_callsign,
                    "reason": "cancelled",
                    "resolved": "cancel",
                }
            if resolution["next_step"] == "sibling_bind":
                sibling_label = resolution.get("sibling_label")
            # retry_bind falls through to the regular bind flow with
            # sibling_label as-passed (typically None) — release_callsign
            # has already cleared the blockers.

        preview = _bind_preview(
            requested_callsign=requested_callsign,
            owner_id=owner_id,
            platform_family=platform_family,
            context_hint=context_hint,
            sibling_label=sibling_label,
        )
        if preview["same_anchor"] and not rebind:
            return {
                "bound": False,
                "rebind_pending": True,
                "requested_callsign": requested_callsign,
                "callsign": requested_callsign,
                "continuity_anchor": preview["continuity_anchor"],
                "existing_agent_id": (preview.get("existing") or {}).get("agent_id"),
            }
        candidate_keys = _client_keys(ctx)
        client_key = candidate_keys[0] if candidate_keys else "anonymous"
        alias_keys = candidate_keys[1:] if len(candidate_keys) > 1 else None
        # safe_only=True: we'll use this ID to write to the user-level
        # statusline file (~/.whispers/claude-sessions/<id>.callsign).
        # The scan fallback is unsafe for writes — see resolver docstring.
        # If None, the existing statusline_sync_degraded warning fires.
        claude_session_id = resolve_claude_session_id(ctx=ctx, safe_only=True)
        effective_platform_family = platform_family or config.platform_family
        # Slice 8 refinement: when we can't resolve the Claude session ID,
        # degrade the bind (statusline won't auto-sync, operator must run
        # `whispers adopt <callsign>`) but do NOT block. Blocking was worse
        # than the degraded state — the bind is functional without it,
        # statusline is an optional surface. The warning flag gets surfaced
        # in the response so the caller knows the footer won't update
        # automatically.
        statusline_sync_degraded = (
            effective_platform_family == "claude-code" and not claude_session_id
        )
        try:
            client = manager.bind_client(
                client_key,
                requested_callsign=requested_callsign,
                display_name=display_name,
                session_name=session_name,
                owner_id=owner_id,
                platform_family=platform_family,
                context_hint=context_hint,
                participant_profile=participant_profile or config.participant_profile,
                allow_sibling=bool(sibling_label),
                sibling_label=sibling_label,
                session_kind="mcp_http" if config.session_kind != "mcp_stdio" else config.session_kind,
                alias_keys=alias_keys,
            )
        except WhispersConflictError as exc:
            # Slice 6: translate collision into a structured choice
            # envelope the caller (operator) can resolve via a follow-up
            # bind_seat call with resolve={...}. Replaces today's silent
            # sibling_instance_allocated for fail-closed honesty.
            from .orientation import build_collision_envelope
            details = dict(exc.details or {})
            details["kind"] = _classify_conflict_kind(exc.details or {})
            envelope = build_collision_envelope(
                db_path=config.db_path or str(WhispersDB().db_path),
                requested_callsign=requested_callsign,
                platform_family=effective_platform_family_for_resolve,
                conflict=details,
            )
            return envelope
        try:
            sync_session_metadata(client, claude_session_id=claude_session_id)
            if claude_session_id:
                write_statusline_binding(
                    claude_session_id=claude_session_id,
                    callsign=client.agent_name,
                )
        except Exception as exc:
            manager.unbind_client(client_key)
            return {
                "bound": False,
                "rebind_pending": False,
                "requested_callsign": requested_callsign,
                "reason": f"statusline_sync_failed:{exc}",
            }

        # Slice 3: Auto-register wake adapter for claude-code sessions.
        # The seat is identity-bound and statusline-synced but not yet
        # wake-capable. PF-burr-03 fix: either we establish a real wake
        # path under the bound callsign, or we return partial-bind with
        # a specific reason so the operator / agent sees exactly why the
        # seat cannot be woken. Never silently degrades to manual_wake.
        wake_adapter: dict[str, Any] | None = None
        if effective_platform_family == "claude-code":
            from .orientation import (
                OrientationError as _OrientationError,
                ensure_wake_adapter_for_claude_code_session,
            )
            try:
                wake_adapter = ensure_wake_adapter_for_claude_code_session(
                    client=client,
                    parent_pid=os.getppid(),
                    server_url=os.environ.get(
                        "WHISPERS_SERVER_URL", "http://127.0.0.1:8765"
                    ),
                )
            except _OrientationError as exc:
                manager.unbind_client(client_key)
                if claude_session_id:
                    try:
                        clear_statusline_binding(claude_session_id)
                    except Exception:
                        pass
                return {
                    "bound": "partial",
                    "rebind_pending": False,
                    "requested_callsign": requested_callsign,
                    "failed_at": "WAKE_REGISTERED",
                    "reason": exc.reason,
                }

        # Phase 1 completion: assemble and return the four-section
        # orientation capsule so the caller receives structured truth
        # (identity/truths/center/anchors) in a single atomic bind
        # response. Failure here does NOT fail the bind — the seat is
        # already wake-capable; capsule assembly is a best-effort
        # enrichment that degrades gracefully.
        capsule: dict[str, Any] | None = None
        try:
            from .orientation import assemble_bind_capsule
            capsule = assemble_bind_capsule(
                client=client,
                effective_platform_family=effective_platform_family,
                cwd=os.getcwd(),
                owner_id=owner_id,
            )
        except Exception as exc:
            logger.warning("capsule_assembly_failed: %s", exc)

        response: dict[str, Any] = {
            "bound": True,
            "rebind_pending": False,
            "whoami": client.whoami(),
            "status": client.status(),
            "wake_adapter": wake_adapter,
            "capsule": capsule,
        }

        # Slice 9 emission was relocated into continuity.connect so
        # every bind path (MCP / HTTP /identity/connect / library) fires
        # peer_bound once at the protocol level. No emit needed here.

        if statusline_sync_degraded:
            response["warnings"] = response.get("warnings", []) + [
                {
                    "kind": "statusline_sync_degraded",
                    "detail": (
                        "Claude session ID could not be resolved by the bridge. "
                        "Bind succeeded but the terminal footer will not auto-update. "
                        "Run `whispers adopt " + str(client.agent_name) + "` from a "
                        "Claude Code shell to sync the statusline."
                    ),
                }
            ]
        return response

    @mcp.tool()
    def unbind_seat(ctx: Context) -> dict[str, Any]:
        # safe_only=True: clear_statusline_binding deletes the user-level
        # callsign file. The scan fallback could return another
        # terminal's session ID and delete their statusline binding.
        claude_session_id = resolve_claude_session_id(ctx=ctx, safe_only=True)
        manager.unbind_client(_client_key(ctx))
        if claude_session_id:
            clear_statusline_binding(claude_session_id)
        return {"bound": False}

    @mcp.tool()
    def whoami(ctx: Context) -> dict[str, Any] | None:
        return _seat(ctx).whoami()

    @mcp.tool()
    def status(ctx: Context) -> dict[str, Any]:
        return _seat(ctx).status()

    @mcp.tool()
    def chrome(ctx: Context) -> dict[str, Any]:
        return _seat(ctx).chrome_status()

    @mcp.tool()
    def wake(ctx: Context) -> dict[str, Any]:
        return _seat(ctx).wake_status()

    @mcp.tool()
    def wake_register(
        ctx: Context,
        adapter_kind: str,
        supported_actions: list[str] | None = None,
        fallback_action: str | None = None,
        state: str | None = None,
        detail: str | None = None,
        endpoint_url: str | None = None,
    ) -> dict[str, Any]:
        return _seat(ctx).wake_register_adapter(
            adapter_kind=adapter_kind,
            supported_actions=supported_actions,
            fallback_action=fallback_action,
            state=state,
            detail=detail,
            endpoint_url=endpoint_url,
        )

    @mcp.tool()
    def wake_events(ctx: Context, limit: int = 20) -> dict[str, Any]:
        return {"events": _seat(ctx).wake_events(limit=limit)}

    @mcp.tool()
    def send(
        ctx: Context,
        to: str,
        subject: str,
        body: str | None = None,
        msg_type: str = "inform",
        priority: str = "routine",
        space_id: str | None = None,
        thread_id: str | None = None,
    ) -> dict[str, Any]:
        return _seat(ctx).send(
            to,
            subject,
            body=body,
            msg_type=msg_type,
            priority=priority,
            space_id=space_id,
            thread_id=thread_id,
        )

    @mcp.tool()
    def inbox(
        ctx: Context,
        limit: int = 20,
        mark_seen: bool = False,
        space_id: str | None = None,
        thread_id: str | None = None,
    ) -> dict[str, Any]:
        return {
            "messages": _seat(ctx).check_inbox(
                limit=limit,
                mark_seen=mark_seen,
                space_id=space_id,
                thread_id=thread_id,
            )
        }

    @mcp.tool()
    def reply(ctx: Context, message_id: str, body: str, subject: str | None = None) -> dict[str, Any]:
        return _seat(ctx).respond(message_id, body, subject=subject)

    @mcp.tool()
    def message_status(ctx: Context, message_id: str) -> dict[str, Any]:
        return _seat(ctx).message_status(message_id)

    @mcp.tool()
    def server_reload_clients(ctx: Context) -> dict[str, Any]:
        """Evict all in-memory MCP seat bindings so freshly-committed code loads on next bind.

        Trust tier 5 required. Callers at lower tiers are rejected without side effects.
        """
        client = _seat(ctx)
        tier = client.trust.resolve_for_callsign(client.agent_name).current_tier
        if tier < 5:
            return {
                "reloaded": False,
                "error": f"Trust tier 5 required; caller '{client.agent_name}' is tier {tier}",
            }
        with manager._lock:
            # Count UNIQUE bound clients, not alias entries. After the
            # alias-keys stability fix a single client may live under
            # multiple keys.
            count = len({id(c) for c in manager._clients.values()})
            manager._clients.clear()
            manager._aliases_by_primary.clear()
        return {
            "reloaded": True,
            "evicted_sessions": count,
        }

    @mcp.tool()
    def spaces(ctx: Context, include_inactive: bool = False) -> dict[str, Any]:
        return {"spaces": _seat(ctx).spaces_list(include_inactive=include_inactive)}

    @mcp.tool()
    def space_create(ctx: Context, name: str, purpose: str | None = None) -> dict[str, Any]:
        return _seat(ctx).space_create(name, purpose=purpose)

    @mcp.tool()
    def space_join(ctx: Context, space_id: str, membership_role: str = "member") -> dict[str, Any]:
        return _seat(ctx).space_join(space_id, membership_role=membership_role)

    @mcp.tool()
    def space_members(ctx: Context, space_id: str) -> dict[str, Any]:
        return {"members": _seat(ctx).space_members(space_id)}

    @mcp.tool()
    def work_offer(
        ctx: Context,
        to: str,
        title: str,
        description: str | None = None,
        space_id: str | None = None,
        required_capabilities: list[str] | None = None,
        allow_external_capability_dependency: bool = False,
    ) -> dict[str, Any]:
        metadata = None
        if required_capabilities or allow_external_capability_dependency:
            metadata = {
                "whispers:required_capabilities": list(required_capabilities or []),
                "whispers:allow_external_capability_dependency": allow_external_capability_dependency,
            }
        return _seat(ctx).work_offer(
            to,
            title,
            description=description,
            space_id=space_id,
            metadata=metadata,
        )

    @mcp.tool()
    def work_list(ctx: Context, space_id: str | None = None, state: str | None = None) -> dict[str, Any]:
        return {"work": _seat(ctx).work_list(space_id=space_id, state=state)}

    @mcp.tool()
    def work_get(ctx: Context, work_id: str) -> dict[str, Any]:
        return _seat(ctx).work_get(work_id)

    @mcp.tool()
    def work_accept(ctx: Context, work_id: str, note: str | None = None) -> dict[str, Any]:
        return _seat(ctx).work_accept(work_id, note=note)

    @mcp.tool()
    def work_start(ctx: Context, work_id: str, note: str | None = None) -> dict[str, Any]:
        return _seat(ctx).work_start(work_id, note=note)

    @mcp.tool()
    def work_block(ctx: Context, work_id: str, note: str) -> dict[str, Any]:
        return _seat(ctx).work_block(work_id, note=note)

    @mcp.tool()
    def work_handoff(ctx: Context, work_id: str, to: str, note: str | None = None) -> dict[str, Any]:
        return _seat(ctx).work_handoff(work_id, to=to, note=note)

    @mcp.tool()
    def work_close(ctx: Context, work_id: str, note: str | None = None) -> dict[str, Any]:
        return _seat(ctx).work_close(work_id, note=note)

    @mcp.tool()
    def participant_profiles(ctx: Context) -> dict[str, Any]:
        del ctx
        if manager.get_client(None):
            return {"profiles": manager.require_client(None).participant_profiles()}
        temp = WhispersClient("probe", db_path=config.db_path, read_only=True)
        return {"profiles": temp.participant_profiles()}

    @mcp.tool()
    def participant_kit(
        ctx: Context,
        server: str,
        participant_profile: str,
        sender: str,
        recipient: str,
        subject: str,
        body: str | None = None,
        display_name: str | None = None,
    ) -> dict[str, Any]:
        return _seat(ctx).participant_kit(
            server=server,
            participant_profile=participant_profile,
            sender=sender,
            recipient=recipient,
            subject=subject,
            body=body,
            display_name=display_name,
        )

    return mcp, manager



def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Whispers MCP seat")
    parser.add_argument("--agent-name", default=None)
    parser.add_argument("--db", dest="db_path", default=None)
    parser.add_argument("--owner-id", default=None)
    parser.add_argument("--platform-family", default=None)
    parser.add_argument("--context-hint", default=None)
    parser.add_argument("--participant-profile", default="desktop_ide_agent")
    parser.add_argument("--allow-sibling", action="store_true")
    parser.add_argument("--sibling-label", default=None)
    parser.add_argument("--transport", choices=("stdio", "http", "sse"), default="stdio")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8766)
    return parser.parse_args(argv)


async def _run_async(args: argparse.Namespace) -> None:
    session_kind = "mcp_stdio" if args.transport == "stdio" else "mcp_http"
    mcp, _ = create_mcp(
        db_path=args.db_path,
        fixed_agent_name=args.agent_name,
        owner_id=args.owner_id,
        platform_family=args.platform_family,
        context_hint=args.context_hint,
        participant_profile=args.participant_profile,
        allow_sibling=args.allow_sibling,
        sibling_label=args.sibling_label,
        session_kind=session_kind,
        listen_host=args.host,
    )
    if args.transport == "stdio":
        await mcp.run_stdio_async()
        return
    if args.transport == "sse":
        await mcp.run_sse_async(host=args.host, port=args.port)
        return
    # HTTP transport: wrap with UTF-8 body validation before handing to uvicorn
    import json as _json
    import uvicorn

    class _Utf8BodyMiddleware:
        def __init__(self, app: Any) -> None:
            self._app = app

        async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
            if scope.get("type") != "http" or scope.get("method") != "POST":
                await self._app(scope, receive, send)
                return
            chunks: list[bytes] = []
            more = True
            while more:
                msg = await receive()
                chunks.append(msg.get("body", b""))
                more = msg.get("more_body", False)
            raw_body = b"".join(chunks)
            try:
                raw_body.decode("utf-8")
            except UnicodeDecodeError:
                err = _json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error: request body is not valid UTF-8"}}).encode("utf-8")
                await send({"type": "http.response.start", "status": 400, "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(err)).encode())]})
                await send({"type": "http.response.body", "body": err, "more_body": False})
                return
            replayed = False

            async def _replay() -> dict:
                nonlocal replayed
                if not replayed:
                    replayed = True
                    return {"type": "http.request", "body": raw_body, "more_body": False}
                return await receive()

            await self._app(scope, _replay, send)

    starlette_app = mcp.streamable_http_app()
    cfg = uvicorn.Config(_Utf8BodyMiddleware(starlette_app), host=args.host, port=args.port, log_level="warning")
    await uvicorn.Server(cfg).serve()



def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    asyncio.run(_run_async(args))
