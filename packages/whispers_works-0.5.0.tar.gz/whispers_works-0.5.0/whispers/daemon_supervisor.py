"""Daemon supervisor with file-watch auto-restart.

Wraps the Whispers server subprocess so edits to whispers/*.py trigger
a clean daemon restart — eliminating the manual kill-pid + relaunch
loop that's cost 4+ context switches per session during the Phase 2
overhaul.

Usage from the CLI:

    whispers daemon run

Polls the watch paths every `debounce_seconds`. On detected change,
SIGTERMs the subprocess, waits for port release, respawns.

Zero external dependencies — polling via os.path.getmtime is stdlib.
Adds ~1s latency from save to daemon up, which is well below the
~15-30s manual restart cycle it replaces.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Iterable, Sequence

_IGNORED_DIR_PARTS = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".git",
    "node_modules",
    ".venv",
    "venv",
}


class DaemonSupervisor:
    """Polling file-watcher that restarts a subprocess on Python source
    changes in any of the `watch_paths`.

    Args:
        watch_paths: Directories to recursively scan for `*.py` files.
        restart_command: argv list passed to subprocess.Popen when
            (re)spawning the daemon. Inherits env from the supervisor.
        debounce_seconds: Minimum interval between polling cycles.
            Default 1.0s. Also serves as the coalescing window for
            multi-file edits — two edits within the same cycle count
            as one restart trigger.
    """

    def __init__(
        self,
        *,
        watch_paths: Sequence[Path | str],
        restart_command: Sequence[str],
        debounce_seconds: float = 1.0,
        cooldown_seconds: float = 15.0,
    ) -> None:
        self.watch_paths: list[Path] = [Path(p) for p in watch_paths]
        self.restart_command: list[str] = list(restart_command)
        self.debounce_seconds: float = float(debounce_seconds)
        # Cooldown between restarts: even if more files change during
        # this window, we don't restart again. Protects connected MCP
        # clients from session-drop thrashing during rapid edit/commit
        # bursts. Set to 0 to disable.
        self.cooldown_seconds: float = float(cooldown_seconds)
        self.subprocess: subprocess.Popen | None = None
        self._last_snapshot: dict[str, float] = {}
        self._last_restart_time: float = 0.0
        self._stopped = False

    # ---- snapshot / change detection ----

    def _iter_py_files(self) -> Iterable[Path]:
        for root in self.watch_paths:
            if not root.exists():
                continue
            for path in root.rglob("*.py"):
                if any(part in _IGNORED_DIR_PARTS for part in path.parts):
                    continue
                yield path

    def _snapshot(self) -> dict[str, float]:
        """Return {absolute_path_string: mtime} for all watched .py files."""
        snap: dict[str, float] = {}
        for path in self._iter_py_files():
            try:
                snap[str(path.resolve())] = path.stat().st_mtime
            except OSError:
                continue
        return snap

    def _changed_paths(self) -> list[str]:
        current = self._snapshot()
        changed = [p for p, t in current.items() if self._last_snapshot.get(p) != t]
        removed = [p for p in self._last_snapshot if p not in current]
        if changed or removed:
            self._last_snapshot = current
        return changed + removed

    # ---- subprocess lifecycle ----

    def _spawn(self) -> None:
        # Cinder caught this: sibling-resolution path was dropping fresh
        # cards to tier 1 because the daemon's env lacked WHISPERS_TRUSTED_ENV.
        # An operator who ran `whispers daemon run` is by definition in a
        # trusted local-dev context (they're the one invoking the supervisor
        # on their own machine). Promote unless they've explicitly opted out.
        child_env = os.environ.copy()
        if not child_env.get("WHISPERS_TRUSTED_ENV") and not child_env.get(
            "WHISPERS_DEFAULT_TRUST_TIER"
        ):
            if child_env.get("WHISPERS_DISABLE_TRUSTED_ENV") != "1":
                child_env["WHISPERS_TRUSTED_ENV"] = "1"
        self.subprocess = subprocess.Popen(
            self.restart_command,
            env=child_env,
        )

    def _stop_subprocess(self, *, timeout: float = 10.0) -> None:
        proc = self.subprocess
        if proc is None:
            return
        if proc.poll() is not None:
            return
        try:
            if os.name == "nt":
                # Windows: SIGTERM equivalent
                proc.terminate()
            else:
                proc.send_signal(signal.SIGTERM)
        except (ProcessLookupError, OSError):
            return
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except (ProcessLookupError, OSError):
                pass
            try:
                proc.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                pass

    # ---- public API ----

    def start(self) -> None:
        """Spawn the daemon and enter the watch loop. Blocks until
        KeyboardInterrupt or stop() is called from another thread.
        """
        self._spawn()
        self._last_snapshot = self._snapshot()
        try:
            self._watch_loop()
        finally:
            self._stop_subprocess()

    def stop(self) -> None:
        """Request the watch loop to exit on its next iteration."""
        self._stopped = True

    def _watch_loop(self) -> None:
        while not self._stopped:
            time.sleep(self.debounce_seconds)
            # Also detect unexpected daemon death and respawn.
            if self.subprocess is not None and self.subprocess.poll() is not None:
                sys.stderr.write(
                    f"[daemon-supervisor] subprocess exited with code "
                    f"{self.subprocess.returncode}, respawning\n"
                )
                self._spawn()
                self._last_snapshot = self._snapshot()
                continue

            changed = self._changed_paths()
            if changed:
                now = time.time()
                since_last = now - self._last_restart_time
                if since_last < self.cooldown_seconds:
                    remaining = self.cooldown_seconds - since_last
                    short = [p.rsplit(os.sep, 1)[-1] for p in changed[:3]]
                    sys.stderr.write(
                        f"[daemon-supervisor] change detected in {', '.join(short)} "
                        f"but cooldown active ({remaining:.1f}s remaining); skipping restart\n"
                    )
                    continue
                short = [p.rsplit(os.sep, 1)[-1] for p in changed[:5]]
                more = (
                    f" (+{len(changed) - 5} more)" if len(changed) > 5 else ""
                )
                sys.stderr.write(
                    f"[daemon-supervisor] restart: {', '.join(short)}{more}\n"
                )
                self._stop_subprocess()
                self._spawn()
                self._last_restart_time = time.time()
                # After restart, re-snapshot so subsequent changes are
                # measured from the new baseline (avoids firing again
                # immediately on files that changed during the restart).
                self._last_snapshot = self._snapshot()
