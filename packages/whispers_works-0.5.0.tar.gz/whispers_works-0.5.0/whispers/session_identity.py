from __future__ import annotations

import hashlib


def stable_session_id(*, continuity_anchor: str | None, session_kind: str, process_id: int | None) -> str | None:
    """Derive a stable session id for the same local seat across rebinds.

    We only stabilize when we have both a continuity anchor and a host process id.
    That keeps independent processes distinct while preventing one seat from
    accumulating fresh agent_sessions rows on every reconnect.
    """
    if not continuity_anchor or process_id is None:
        return None
    material = "|".join(
        [
            str(continuity_anchor).strip(),
            str(session_kind or "local_client").strip() or "local_client",
            str(process_id),
        ]
    )
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:24]
    return f"session:{digest}"
