"""Whispers Orient — the orientation state machine.

A fresh-bound agent walks through nine named states from UNBOUND to ORIENTED.
Each state corresponds to a surface that must be established truthfully before
the agent can be considered "ready": identity, statusline, wake adapter,
trust tier, peer graph, recent context. Later slices plug real work into the
handler for each state; Slice 0 (this module's initial form) establishes the
mechanism itself.

The contract:
- Transitions advance in canonical STATE_ORDER. The machine never skips or
  reorders.
- A handler may raise OrientationError to signal fail-closed. The machine
  halts at that point and returns an OrientationResult with bound="partial",
  failed_at=<failing state>, and reason=<specific machine-readable reason>.
- After any outcome (success or partial), the machine's .state attribute
  reflects the last state successfully entered — operators can always see
  where orientation got stuck.

Design principle (from plan's §Design Principles #2):
    "Fail closed, never fake. No {bound: true} when any surface is not in
    sync. Partial-bind is an error state, not a default."

See C:/Users/Zachary Turner/.claude/plans/glittery-shimmying-tome.md for the
full design, and .planning/reviews/FIRST-BIND-FRICTION-2026-04-17.md for the
live failure evidence that motivated this module.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional


class OrientationState(str, Enum):
    """Named states in the orientation pipeline.

    The str mixin makes state values directly serializable into JSON/logs
    and comparable to string inputs from external surfaces (status tool,
    chrome line, test fixtures).
    """

    UNBOUND = "UNBOUND"
    BINDING = "BINDING"
    IDENTITY_ESTABLISHED = "IDENTITY_ESTABLISHED"
    STATUSLINE_SYNCED = "STATUSLINE_SYNCED"
    WAKE_REGISTERED = "WAKE_REGISTERED"
    PEERS_RESOLVED = "PEERS_RESOLVED"
    CONTEXT_LOADED = "CONTEXT_LOADED"
    CAPSULE_DELIVERED = "CAPSULE_DELIVERED"
    ORIENTED = "ORIENTED"


STATE_ORDER: list[OrientationState] = [
    OrientationState.UNBOUND,
    OrientationState.BINDING,
    OrientationState.IDENTITY_ESTABLISHED,
    OrientationState.STATUSLINE_SYNCED,
    OrientationState.WAKE_REGISTERED,
    OrientationState.PEERS_RESOLVED,
    OrientationState.CONTEXT_LOADED,
    OrientationState.CAPSULE_DELIVERED,
    OrientationState.ORIENTED,
]


class OrientationError(Exception):
    """Raised by a transition handler to signal fail-closed.

    The state machine catches this and returns an OrientationResult with
    bound="partial", failed_at=<the state whose handler raised>, and
    reason=<the reason argument>. The reason is required — a failure
    without a machine-readable reason is banned by the plan's truth-gate
    principle.
    """

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


@dataclass
class OrientationResult:
    """Return payload from OrientationStateMachine.run().

    Fields:
        bound: True if ORIENTED reached; "partial" if any transition failed.
            (Slice 0 never emits bare False; BINDING-phase failures return
            "partial" with orientation_state="UNBOUND". Later slices may
            introduce a pre-BINDING refusal that returns False — e.g.
            callsign_in_use.)
        orientation_state: the final state the machine actually reached
            (not the state the caller requested).
        failed_at: the state whose handler raised OrientationError, or
            None on success.
        reason: the machine-readable reason string from the raised
            OrientationError, or None on success.
        capsule: the full orientation capsule payload. Slice 0 leaves this
            None; Slice 1 populates identity + truths; subsequent slices
            extend to all six sections.
    """

    bound: Any
    orientation_state: str
    failed_at: Optional[str] = None
    reason: Optional[str] = None
    capsule: Optional[dict] = None


class OrientationStateMachine:
    """Observable, fail-closed state machine for agent orientation.

    Slice 0 form: skeleton. Handlers are registered via set_handler() by
    the callers that plug in real work (Slices 1-5 register identity/truths
    composition, statusline sync, wake registration, peer selection,
    context loading, capsule delivery). With no handlers registered, run()
    advances through every state as a no-op and terminates at ORIENTED —
    this keeps the mechanism testable in isolation.

    Invariants guaranteed to callers and tests:
        1. self.state is always readable. It reflects the last state the
           machine successfully entered. After run() succeeds, it is
           ORIENTED. After a failure, it is the state before the failing
           transition (never the failing state itself).
        2. run() advances in STATE_ORDER. Never skips, never reorders,
           never goes backwards.
        3. Each handler is invoked at most once per run() call, and only
           if its state's transition is attempted (i.e., not after a
           prior failure).
        4. On OrientationError from any handler, run() stops and returns
           a structured partial result; it never propagates the exception
           to the caller.
    """

    def __init__(self) -> None:
        self.state: OrientationState = OrientationState.UNBOUND
        self._handlers: Dict[OrientationState, Callable[[], Any]] = {}

    def set_handler(
        self, state: OrientationState, handler: Callable[[], Any]
    ) -> None:
        """Register a handler to run as the machine transitions into state.

        The handler is called just before self.state is updated to `state`.
        If the handler raises OrientationError, the machine halts with
        failed_at=state.value (i.e., the state it was attempting to enter),
        and self.state remains at the prior successfully-entered state.

        A state without a registered handler is a no-op transition: the
        machine simply advances self.state and continues. This lets Slice 0
        ship without any real work plugged in, and lets later slices plug
        in handlers incrementally.
        """
        self._handlers[state] = handler

    def run(self) -> OrientationResult:
        """Advance through STATE_ORDER from the current state to ORIENTED.

        Returns:
            OrientationResult with bound=True on full success, or
            bound="partial" on any OrientationError from a transition
            handler. On success, capsule is None here — Slice 1+ assembly
            happens in higher-level callers that wire section builders
            to specific states' handlers.
        """
        current_idx = STATE_ORDER.index(self.state)

        for next_state in STATE_ORDER[current_idx + 1:]:
            handler = self._handlers.get(next_state)
            if handler is not None:
                try:
                    handler()
                except OrientationError as e:
                    return OrientationResult(
                        bound="partial",
                        orientation_state=self.state.value,
                        failed_at=next_state.value,
                        reason=e.reason,
                    )
            self.state = next_state

        return OrientationResult(
            bound=True,
            orientation_state=self.state.value,
        )


# ---------------------------------------------------------------------------
# Slice 1 — Section composers (identity + truths)
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    """Return the current time as an ISO-8601 timestamp with Z suffix.

    Matches the convention used in 2ACK envelopes and agent_cards so the
    orientation capsule's freshness markers are visually consistent with
    the rest of the wire surface.
    """
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _decode_metadata(raw: Any) -> Dict[str, Any]:
    """Parse a session.metadata field whether it's a dict or JSON string.

    Duplicates the local helper in whispers/wake_runtime.py:20 deliberately
    — this keeps whispers.orientation as a pure composition module with no
    cross-module import graph during bind-critical code paths.
    """
    if isinstance(raw, dict):
        return dict(raw)
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return {}
        return dict(parsed) if isinstance(parsed, dict) else {}
    return {}


def build_identity_section(
    card: Optional[Dict[str, Any]],
    *,
    as_of: Optional[str] = None,
    session_name: Optional[str] = None,
    trust_tier: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Compose the `identity` section of the orientation capsule.

    Slice 1 (shallow) + Slice 4 (resolved-tier override) form.

    The trust_tier argument lets a bind flow run resolve_trust_tier()
    first (Slice 4 / MI-2 sibling inheritance) and then hand the resolved
    {value, basis} dict in here. Section composers stay pure — they never
    reach into the registry themselves.

    Design principle #9 (unknown is first-class): if no card is provided
    and no resolved tier is given, every field is None / "unknown" and
    the section still builds. Supports the fail-closed contract.

    Args:
        card: An agent_cards row (dict) or None for pre-bind / unknown.
        as_of: Optional ISO-8601 timestamp to pin for deterministic tests
            or replay. Defaults to current UTC time.
        trust_tier: Optional pre-resolved {value, basis} dict. When
            provided, it is used verbatim. When None, the tier is derived
            from card.trust_tier with basis 'declared' or 'unknown' —
            the Slice 1 behavior.

    Returns:
        A dict matching the plan's identity schema. Every call returns
        the same top-level key set; values may be None when unknown.
    """
    record = dict(card or {})

    if trust_tier is not None:
        trust_tier_block = trust_tier
    else:
        trust_tier_value = record.get("trust_tier")
        trust_tier_basis = "declared" if trust_tier_value is not None else "unknown"
        trust_tier_block = {"value": trust_tier_value, "basis": trust_tier_basis}

    return {
        "callsign": record.get("callsign"),
        "display_name": record.get("display_name"),
        "session_name": session_name,
        "agent_id": record.get("agent_id"),
        "continuity_anchor": record.get("continuity_anchor"),
        "platform_family": record.get("platform_family"),
        "participant_kind": record.get("participant_kind"),
        "participant_shape": record.get("participant_shape"),
        "agency_relation": record.get("agency_relation"),
        "recognition_basis": record.get("recognition_basis"),
        "boundary_provenance": record.get("boundary_provenance"),
        "trust_tier": trust_tier_block,
        "claimed_at": record.get("registered_at"),
        "as_of": as_of or _now_iso(),
    }


# ---------------------------------------------------------------------------
# Slice 4 — Trust tier resolution (MI-2 sibling inheritance)
# ---------------------------------------------------------------------------


def find_sibling_agents(
    cards: List[Dict[str, Any]],
    *,
    platform_family: str,
    owner_id: Optional[str] = None,
    host_fingerprint: Optional[str] = None,
    exclude_callsign: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Filter a pool of agent_cards down to siblings of the requesting bind.

    Sibling semantics: another agent on the same (platform_family, owner
    or host) that already exists in the registry and can serve as a trust
    anchor for a new bind. Excludes the requesting callsign itself.

    When owner_id is given it takes precedence over host_fingerprint —
    operator identity is stronger evidence than host-level proximity.

    Args:
        cards: Iterable of agent_card-shaped dicts (typically all cards
            for the platform or the active shard).
        platform_family: Required match key. 'claude-code' agents do not
            inherit from 'pi' agents and vice versa.
        owner_id: Optional narrower match. When given, only agents with
            the same owner_id qualify.
        host_fingerprint: Optional narrower match. Only consulted if
            owner_id is None.
        exclude_callsign: The requesting callsign — excluded so that a
            re-bind never inherits from its own prior card via this path.

    Returns:
        A list (possibly empty) of matching sibling card dicts.
    """
    platform_norm = (platform_family or "").strip().lower()
    results: List[Dict[str, Any]] = []
    for card in cards:
        if not isinstance(card, dict):
            continue
        if (card.get("platform_family") or "").strip().lower() != platform_norm:
            continue
        if exclude_callsign and card.get("callsign") == exclude_callsign:
            continue
        if owner_id is not None:
            if card.get("owner_id") != owner_id:
                continue
        elif host_fingerprint is not None:
            if card.get("host_fingerprint") != host_fingerprint:
                continue
        results.append(card)
    return results


def resolve_trust_tier(
    *,
    card: Optional[Dict[str, Any]],
    siblings: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Resolve a {value, basis} trust tier dict for a bind request.

    The MI-2 resolution order:
        1. If `card` has a numeric trust_tier, return it with basis
           'declared'. Operator intent captured in the card wins, even
           when it is 0.
        2. Otherwise, if any sibling has a numeric trust_tier, inherit
           the highest one and record basis 'inherited_from:<callsign>'
           pointing at the chosen sibling for audit.
        3. Otherwise, return {value: 0, basis: 'unknown_requires_
           authorization'}. The bind flow is expected to surface this
           as a blocked state rather than silently accepting tier 0 and
           being filtered by the dispatcher.

    Slice 4 does not yet know about 'operator_authorized' — that basis
    is produced by the Slice 4 CLI (`whispers authorize-tier`) which
    writes a tier directly onto the card, after which this resolver
    returns it as 'declared' on the next bind. Future slices may
    refine this distinction with an explicit basis marker.

    Args:
        card: The existing agent_card for the requesting callsign, if any.
        siblings: The filtered sibling pool from find_sibling_agents().

    Returns:
        A {value: int|None, basis: str} dict.
    """
    if isinstance(card, dict):
        raw = card.get("trust_tier")
        if isinstance(raw, (int, float)):
            return {"value": int(raw), "basis": "declared"}

    best: Optional[Dict[str, Any]] = None
    best_tier = -1
    for sibling in siblings or []:
        if not isinstance(sibling, dict):
            continue
        tier = sibling.get("trust_tier")
        if not isinstance(tier, (int, float)):
            continue
        tier_int = int(tier)
        if tier_int > best_tier:
            best_tier = tier_int
            best = sibling

    if best is not None:
        return {
            "value": best_tier,
            "basis": f"inherited_from:{best.get('callsign')}",
        }

    return {"value": 0, "basis": "unknown_requires_authorization"}


def _extract_wake_adapter(
    active_session: Optional[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """Return a compact wake_adapter descriptor if one is registered,
    otherwise None.

    Looks up `metadata.adapter_registrations.local_http_connector` first
    (the canonical local wake baseline per STATE-OF-THE-ART memo §4.1),
    then falls back to any adapter_registrations entry if present. A
    None return means the seat is wake-deaf and the truths section must
    explain why via wake_unavailable_reason.
    """
    if not active_session:
        return None
    metadata = _decode_metadata(active_session.get("metadata"))
    registrations = metadata.get("adapter_registrations")
    if not isinstance(registrations, dict) or not registrations:
        return None

    preferred_kind = "local_http_connector"
    kind, entry = (
        (preferred_kind, registrations[preferred_kind])
        if preferred_kind in registrations
        else next(iter(registrations.items()))
    )
    if not isinstance(entry, dict):
        return None

    return {
        "kind": kind,
        "endpoint": entry.get("endpoint_url") or entry.get("endpoint"),
        "adapter_state": entry.get("state") or entry.get("adapter_state"),
        "verified_at": entry.get("verified_at") or entry.get("registered_at"),
    }


def _resolve_reachability(
    card_reachability: Any,
    wake_adapter: Optional[Dict[str, Any]],
) -> str:
    """Return the honest reachability_mode given card + adapter state.

    An adapter registration overrides a stale card label (e.g., a card
    that says `manual_wake` but has a live `local_http_connector`
    registered should be reported as `local_http_connector`). Conversely,
    a card claiming `listener_backed` with no adapter is a lie — but
    Slice 1 preserves the card label and flags the lie via
    wake_unavailable_reason for the operator to see and fix.
    """
    raw = str(card_reachability or "").strip().lower()
    if wake_adapter is not None:
        # Promote to the adapter's kind if the card hasn't caught up.
        return str(wake_adapter.get("kind") or raw or "listener_backed")
    return raw or "unknown"


def _wake_unavailable_reason(
    reachability_mode: str,
    wake_adapter: Optional[Dict[str, Any]],
) -> Optional[str]:
    """Return a non-empty reason string when a seat is not wake-capable,
    otherwise None.

    This is the PF-burr-03 fix: a seat with no adapter must announce WHY
    it cannot be woken. 'manual_wake' without explanation is the silent
    degradation the plan forbids.
    """
    if wake_adapter is not None:
        return None
    if reachability_mode in ("local_http_connector", "listener_backed"):
        # Card claims listener capability but no adapter is live — this
        # is dishonest card state; flag it so the operator sees it.
        return "card_claims_listener_mode_but_no_adapter_registered"
    if reachability_mode == "manual_wake":
        return "no_wake_adapter_registered"
    return "reachability_unknown_no_adapter_registered"


def _can_send_for_tier(trust_tier: Optional[int]) -> Dict[str, bool]:
    """Return a compact can_send block derived from trust tier.

    Slice 1 uses shallow tier-to-capability rules. Slice 4's trust
    inheritance work may refine these when the dispatcher's cross-tier
    rule (whispers/dispatcher.py) is surfaced into the capsule.
    """
    tier = int(trust_tier) if isinstance(trust_tier, (int, float)) else 0
    return {
        "flash": tier >= 4,
        "routine": tier >= 2,
        "system": tier >= 5,
    }


def _authority_ceiling_for_tier(trust_tier: Optional[int]) -> Dict[str, Any]:
    """Derive authority_ceiling from trust tier using dispatcher rules.

    Dispatcher at whispers/dispatcher.py:480 blocks sends where
    sender_tier < recipient_tier - 1. So a tier-N sender can reach
    recipients up to tier N+1. Slice 1 surfaces that ceiling explicitly
    so agents and operators can see it without reading dispatcher code.

    scope_widening_policy is fixed to 'requires_operator' in Slice 1;
    Slice 5's working-scope work may introduce more nuanced policies.
    """
    tier = int(trust_tier) if isinstance(trust_tier, (int, float)) else 0
    return {
        "max_trust_tier_recipient": tier + 1,
        "scope_widening_policy": "requires_operator",
    }


def _default_context_budget() -> Dict[str, Any]:
    """Honest 'unknown' budget for Slice 1.

    Phase 2 may sample actual token load from the session. Today we
    report unknown with the progressive_loading policy so any consumer
    of the capsule knows to lazy-load deep data rather than assume a
    fixed budget.
    """
    return {
        "nominal_limit": None,
        "current_load": "unknown",
        "policy": "progressive_loading",
    }


def _build_jolt_block(
    wake_projection: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Extract the Jolt truth block for a truths section.

    Jolt is not a post-bind addendum — every oriented seat carries the
    Jolt decision engine's current view (host capabilities, budget,
    attention context, recommended action). When a live wake_projection
    is supplied (via build_wake_projection in whispers/wake_runtime.py),
    we use it verbatim. When not supplied, we emit honest no-adapter
    defaults: all capabilities False, recommended_action='suppress' with
    a reason naming the gap. Never fake capability claims.
    """
    if isinstance(wake_projection, dict):
        return {
            "host_capabilities": wake_projection.get("host_capabilities") or {},
            "budget": wake_projection.get("budget") or {},
            "attention_context": wake_projection.get("attention_context") or {},
            "recommended_action": wake_projection.get("recommended_action") or {
                "action": "suppress",
                "reasons": ["no_recommended_action_in_projection"],
                "budget_limited": False,
                "fallback_used": True,
            },
        }
    return {
        "host_capabilities": {
            "host_kind": "unknown",
            "can_notify": False,
            "can_stage_context": False,
            "can_trigger_inference": False,
            "steals_focus": False,
        },
        "budget": {
            "max_inferences_per_hour": 0,
            "inferences_used_last_hour": 0,
            "cooldown_seconds": 0,
            "seconds_since_last_inference": None,
            "autonomous_inference_enabled": False,
        },
        "attention_context": {
            "trigger": "ambient_update",
            "interruptibility": "defer",
            "priority": "routine",
            "explicitly_addressed": False,
            "blocking": False,
            "already_hot": False,
        },
        "recommended_action": {
            "action": "suppress",
            "reasons": ["no_wake_projection_available"],
            "budget_limited": False,
            "fallback_used": True,
        },
    }


def build_truths_section(
    card: Optional[Dict[str, Any]],
    *,
    active_session: Optional[Dict[str, Any]] = None,
    wake_projection: Optional[Dict[str, Any]] = None,
    as_of: Optional[str] = None,
) -> Dict[str, Any]:
    """Compose the `truths` section of the orientation capsule.

    Slice 1 form: shallow. Wraps the existing wake inputs (card
    reachability + session.metadata.adapter_registrations) with the
    plan's basis + wake_unavailable_reason semantics. No authority
    ceiling derivation from dispatcher rules yet (Slice 4+), no live
    context_load sampling (Phase 2).

    Critical invariant (PF-burr-03 fix): if wake_adapter is None,
    wake_unavailable_reason is non-empty. The operator and the agent
    are never left guessing why a seat cannot be woken.

    Args:
        card: The agent_cards row (dict) or None.
        active_session: The agent_sessions row (dict) with metadata that
            may contain adapter_registrations.
        as_of: Optional ISO-8601 timestamp for replay / deterministic tests.

    Returns:
        A dict matching the plan's truths schema.
    """
    record = dict(card or {})
    wake_adapter = _extract_wake_adapter(active_session)
    reachability_mode = _resolve_reachability(record.get("reachability_mode"), wake_adapter)
    wake_unavailable_reason = _wake_unavailable_reason(reachability_mode, wake_adapter)
    capability_claims: List[Dict[str, Any]] = list(record.get("capability_claims") or [])

    return {
        "reachability_mode": reachability_mode,
        "wake_adapter": wake_adapter,
        "wake_unavailable_reason": wake_unavailable_reason,
        "jolt": _build_jolt_block(wake_projection),
        "capability_claims": capability_claims,
        "can_send": _can_send_for_tier(record.get("trust_tier")),
        "authority_ceiling": _authority_ceiling_for_tier(record.get("trust_tier")),
        "context_budget": _default_context_budget(),
        "as_of": as_of or _now_iso(),
    }


# ---------------------------------------------------------------------------
# Slice 5 — Center and anchors section composers
# ---------------------------------------------------------------------------


def _normalize_working_scope(scope: Any) -> Optional[Dict[str, Any]]:
    """Coerce a caller-supplied working_scope value into the canonical
    {name, parent, policy_hint} shape, or None if no usable input.

    Accepts:
      - None → None
      - str  → {name: <str>, parent: None, policy_hint: None}
      - dict → dict with keys normalized; missing keys become None
    """
    if scope is None:
        return None
    if isinstance(scope, str):
        name = scope.strip()
        if not name:
            return None
        return {"name": name, "parent": None, "policy_hint": None}
    if isinstance(scope, dict):
        return {
            "name": scope.get("name"),
            "parent": scope.get("parent"),
            "policy_hint": scope.get("policy_hint"),
        }
    return None


def build_center_section(
    *,
    working_scope: Any = None,
    declared_role: Optional[str] = None,
    declared_task: Optional[str] = None,
    drive_signature: Optional[List[str]] = None,
    as_of: Optional[str] = None,
) -> Dict[str, Any]:
    """Compose the `center` section of the orientation capsule.

    The center answers 'what my center is' — current working scope, role
    in this session, active task, motivational drive signature. All
    fields may be None / []; an agent with no declared center still
    gets a diagnostic section. (Principle #9: unknown is first-class.)

    Args:
        working_scope: Either a scope name string, a
            {name, parent, policy_hint} dict, or None. Normalized to
            the canonical dict shape.
        declared_role: Optional operator-supplied role label (e.g.,
            'designer', 'reviewer', 'executor').
        declared_task: Optional one-line current-task description.
        drive_signature: Optional list of drive labels from the
            DRIVE-SIGNALS vocabulary ('epistemic', 'coordinative', etc.).
        as_of: Optional ISO-8601 freshness pin.

    Returns:
        Dict matching the plan's center schema.
    """
    return {
        "working_scope": _normalize_working_scope(working_scope),
        "declared_role": declared_role,
        "declared_task": declared_task,
        "drive_signature": list(drive_signature or []),
        "as_of": as_of or _now_iso(),
    }


def build_anchors_section(
    *,
    continuity_events: Optional[List[Dict[str, Any]]] = None,
    memory_attachment: Optional[Dict[str, Any]] = None,
    prior_pairs: Optional[List[Dict[str, Any]]] = None,
    pending_residue: Optional[List[Dict[str, Any]]] = None,
    reference_docs: Optional[List[Dict[str, Any]]] = None,
    as_of: Optional[str] = None,
) -> Dict[str, Any]:
    """Compose the `anchors` section of the orientation capsule.

    The anchors answer 'what I'm grounded on' — continuity events
    through the session history, memory attachment pointer, prior pair
    relationships, and reference docs relevant to the current scope.
    Phase 1 leaves pending_residue as a stub ([] by default); Phase 2
    Slice 7 wires real residue capture in whispers/residue.py.

    Every collection field defaults to [] (not None) so consumers can
    iterate without guards. memory_attachment is the only None-able
    scalar — there may be no memory to point at.

    Args:
        continuity_events: List of {kind, at} dicts describing the
            agent's continuity history (first_bind, rebind, reclaim, etc.).
        memory_attachment: {path, kind} pointer, or None. The capsule
            never embeds memory content — too expensive for the
            context budget.
        prior_pairs: List of peer-relationship dicts summarizing active
            pair_spaces this agent is in.
        pending_residue: Stub list (Phase 2).
        reference_docs: List of {path, relevance} pointers to files the
            agent may benefit from reading.
        as_of: ISO-8601 freshness pin.
    """
    return {
        "continuity_events": list(continuity_events or []),
        "memory_attachment": memory_attachment,
        "prior_pairs": list(prior_pairs or []),
        "pending_residue": list(pending_residue or []),
        "reference_docs": list(reference_docs or []),
        "as_of": as_of or _now_iso(),
    }


def resolve_working_scope(
    *,
    explicit: Optional[str] = None,
    cwd: Optional[str] = None,
) -> Dict[str, Any]:
    """Resolve a working scope for a bind request with a basis tag.

    Resolution order:
      1. Explicit arg wins. basis='explicit'.
      2. cwd/.whispers/workspace-scope.json mapping (JSON file with
         'scope', 'parent', 'policy_hint' keys). basis='workspace_registry'.
      3. cwd basename as the scope name. basis='cwd_leaf'.
      4. 'whispers.default'. basis='no_cwd_or_registry'.

    Returns:
        {name, parent, policy_hint, basis} dict. Always returns —
        never None or exception on any input combination.
    """
    if explicit:
        return {
            "name": str(explicit).strip(),
            "parent": None,
            "policy_hint": None,
            "basis": "explicit",
        }

    if cwd:
        import os as _os

        registry_path = _os.path.join(cwd, ".whispers", "workspace-scope.json")
        if _os.path.isfile(registry_path):
            try:
                with open(registry_path, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
            except (OSError, json.JSONDecodeError):
                data = None
            if isinstance(data, dict) and data.get("scope"):
                return {
                    "name": str(data["scope"]),
                    "parent": data.get("parent"),
                    "policy_hint": data.get("policy_hint"),
                    "basis": "workspace_registry",
                }

        leaf = _os.path.basename(_os.path.normpath(cwd))
        if leaf:
            return {
                "name": leaf,
                "parent": None,
                "policy_hint": None,
                "basis": "cwd_leaf",
            }

    return {
        "name": "whispers.default",
        "parent": None,
        "policy_hint": None,
        "basis": "no_cwd_or_registry",
    }


_REFERENCE_DOC_CANDIDATES: List[tuple] = [
    ("README.md", "project_root"),
    (".planning/README.md", "planning_index"),
    ("CLAUDE.md", "project_instructions"),
    ("AGENTS.md", "agent_instructions"),
]


def find_reference_docs(
    *,
    workspace_root: str,
    candidates: Optional[List[tuple]] = None,
) -> List[Dict[str, str]]:
    """Return {path, relevance} pointers to canonical reference docs
    present in a workspace.

    Shallow discovery: checks a fixed candidate list for existence and
    returns pointers. Never loads content; the agent fetches the file
    on demand if its relevance warrants it.

    Args:
        workspace_root: Absolute path to scan.
        candidates: Optional override list of (rel_path, relevance) tuples.

    Returns:
        List of {path, relevance} dicts for the candidate files that
        exist. Order follows the candidate list. Returns [] for an
        empty / missing workspace.
    """
    import os as _os

    check_list = candidates if candidates is not None else _REFERENCE_DOC_CANDIDATES
    results: List[Dict[str, str]] = []
    for rel, relevance in check_list:
        full = _os.path.join(workspace_root, rel)
        if _os.path.isfile(full):
            results.append({"path": rel.replace("\\", "/"), "relevance": relevance})
    return results


# ---------------------------------------------------------------------------
# Slice 3 — Wake auto-registration on Claude Code bind
# ---------------------------------------------------------------------------


# Import the companion spawner lazily at module import time, keeping it
# wrappable at test time without patching the source module. Tests mock
# `whispers.orientation._ensure_local_wake_companion` rather than the
# terminal_actuator path, so refactors to the companion plumbing never
# break the wake-auto-register contract here.
try:
    from .terminal_actuator import _ensure_local_wake_companion  # type: ignore
except ImportError:  # pragma: no cover
    _ensure_local_wake_companion = None  # type: ignore


def ensure_wake_adapter_for_claude_code_session(
    *,
    client: Any,
    parent_pid: int,
    server_url: str,
    supported_actions: Optional[List[str]] = None,
    fallback_action: str = "notify",
    state: str = "ready",
) -> Dict[str, Any]:
    """Register a `local_http_connector` wake adapter for a bound
    claude-code session — the Slice 3 PF-burr-03/04 fix.

    Spawns (or reuses) a `local_wake_runtime` child process tied to the
    caller's Claude PID and writes the adapter_registrations patch
    directly into the agent_sessions row for `client.agent_name`. No
    companion identity is minted — the adapter lives under the bound
    callsign. No HTTP call to the server is made; the DB write goes
    straight through `client.db.patch_agent_session_metadata`, which
    avoids the self-calling-ourselves loop when bind_seat invokes this
    helper from inside the MCP server process.

    On any failure, raises OrientationError with a specific reason so
    bind_seat can translate it into `failed_at="WAKE_REGISTERED"`.

    Args:
        client: A live WhispersClient with an active session row.
        parent_pid: The Claude Code process PID (companion lifecycle is
            tied to this so the runtime dies when Claude Code exits).
        server_url: Base URL for the Whispers server (passed to the
            companion; the companion only uses it for its own identity
            registration / heartbeat path, not for the adapter write).
        supported_actions: Default ['notify']. Override for hosts that
            can stage_context or trigger_inference.
        fallback_action: What the dispatch loop should do if it can't
            reach the adapter. Default 'notify' (best-effort).
        state: Initial adapter state, default 'ready'.

    Returns:
        Dict: {ok, endpoint_url, companion_pid, companion_status, reason}.
        ok=True on success; OrientationError raised on failure (never
        returns ok=False).

    Raises:
        OrientationError: Specific reason strings include
            'no_active_session', 'companion_unavailable', 'runtime_spawn_failed'.
    """
    # Prefer the client's own session_id over "most recent helm session"
    # — a stale test client or prior bind may have left a newer session
    # row that isn't ours. Patching the wrong row silently wedges the
    # jolt dispatch path because the server then can't find adapters for
    # THIS client's session. Fall back to active_session_for_agent only
    # when the client has no session_id (read-only / manual insert cases).
    session_id = client.session_id
    if session_id:
        # Confirm the row exists — patch_agent_session_metadata raises if
        # it doesn't, but fail-closed here with a clearer reason.
        active_session = client.db.active_session_for_agent(client.agent_name)
        if not active_session:
            raise OrientationError("no_active_session_for_wake_adapter_patch")
    else:
        active_session = client.db.active_session_for_agent(client.agent_name)
        if not active_session:
            raise OrientationError("no_active_session_for_wake_adapter_patch")
        session_id = active_session.get("session_id")

    if _ensure_local_wake_companion is None:
        raise OrientationError("companion_unavailable_terminal_actuator_not_importable")

    actions = list(supported_actions or ["notify"])

    try:
        companion_info, companion_status = _ensure_local_wake_companion(
            profile_name=f"bind.{client.agent_name}",
            server_url=server_url,
            agent_name=client.agent_name,
            parent_pid=parent_pid,
            supported_actions=actions,
            fallback_action=fallback_action,
            state=state,
            detail=f"bound:{client.agent_name}",
            # Slice 11: we write the adapter registration into the DB
            # below (patch_agent_session_metadata). The companion does
            # not need to HTTP-POST it back to us — and MUST NOT, because
            # this function runs inside the server process so any
            # synchronous HTTP POST to our own /wake/<agent>/adapters
            # endpoint deadlocks against the bind_seat handler holding
            # the event loop.
            skip_http_register=True,
        )
    except Exception as exc:
        raise OrientationError(
            f"runtime_spawn_failed:{type(exc).__name__}:{exc}"
        ) from exc

    if not companion_info or not isinstance(companion_info, dict):
        raise OrientationError("runtime_spawn_failed:no_companion_info")

    endpoint_url = companion_info.get("endpoint_url")
    if not endpoint_url:
        raise OrientationError("runtime_spawn_failed:no_endpoint_url")

    # session_id was resolved above — prefer client.session_id over
    # active_session_for_agent's "most recent helm session" to avoid
    # patching the wrong session row.
    adapter_payload = {
        "supported_actions": actions,
        "fallback_action": fallback_action,
        "state": state,
        "detail": f"bound:{client.agent_name}",
        "endpoint_url": endpoint_url,
    }
    try:
        client.db.patch_agent_session_metadata(
            str(session_id),
            metadata_patch={"adapter_registrations": {"local_http_connector": adapter_payload}},
        )
    except Exception as exc:
        raise OrientationError(
            f"adapter_registration_db_failed:{type(exc).__name__}:{exc}"
        ) from exc

    return {
        "ok": True,
        "endpoint_url": endpoint_url,
        "companion_pid": companion_info.get("pid"),
        "companion_status": companion_status,
        "reason": None,
    }


# ---------------------------------------------------------------------------
# Phase 1 completion — capsule assembly called by bind_seat
# ---------------------------------------------------------------------------


def _enumerate_siblings_for_bind(
    db: Any,
    *,
    callsign: str,
    platform_family: Optional[str],
    owner_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Enumerate active agent_cards matching (platform_family, owner_id)
    excluding the requesting callsign. Used for MI-2 tier inheritance
    during bind.

    Purpose: let resolve_trust_tier inherit from a named sibling on the
    same platform. Kept narrow — only fields we actually use for the
    inheritance decision. Returns [] on any DB failure rather than
    raising, so a sibling-lookup hiccup cannot break bind; it only
    loses the inheritance opportunity and the resolver falls through
    to 'unknown_requires_authorization'.
    """
    if not platform_family:
        return []
    try:
        with db.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT callsign, trust_tier, platform_family, owner_id
                FROM agent_cards
                WHERE callsign != ?
                  AND platform_family = ?
                  AND deregistered_at IS NULL
                  AND (? IS NULL OR owner_id = ?)
                """,
                (callsign, platform_family, owner_id, owner_id),
            ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def assemble_bind_capsule(
    *,
    client: Any,
    effective_platform_family: Optional[str] = None,
    cwd: Optional[str] = None,
    owner_id: Optional[str] = None,
    memory_attachment: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Compose the four-section orientation capsule at the end of a
    successful bind.

    Called by `bind_seat` after identity + statusline + wake are all
    in place. Returns a dict ready to be included as the `capsule` key
    in the bind_seat response payload.

    Phase 1 sections (identity, truths, center, anchors) are populated
    here. Phase 2 will add `peers` and `context`. This function is the
    single integration point so adding later sections is a single edit.

    Args:
        client: A live WhispersClient that has just been bound (its
            registry + db are consulted for card data, active session
            metadata, and sibling enumeration).
        effective_platform_family: The resolved platform_family (from
            bind_seat's call params or config default). Used for
            sibling lookup + reachability interpretation.
        cwd: Current working directory to use for working_scope
            resolution and reference_docs discovery. bind_seat should
            pass `os.getcwd()`.
        owner_id: Optional owner identity for narrowing sibling lookup.
        memory_attachment: Optional pre-built {path, kind} pointer to
            a memory index (Claude memory file, etc.).

    Returns:
        Dict with keys: identity, truths, center, anchors. Each
        carries basis+as_of where applicable. Phase 2 will add
        'peers' and 'context' keys.
    """
    from .wake_runtime import build_wake_projection  # lazy — avoids circular imports

    card = None
    try:
        card = client.registry.get_agent_by_callsign(client.agent_name)
    except Exception:
        card = None
    card = dict(card) if card else {}

    siblings = _enumerate_siblings_for_bind(
        client.db,
        callsign=client.agent_name,
        platform_family=effective_platform_family or card.get("platform_family"),
        owner_id=owner_id,
    )
    resolved_tier = resolve_trust_tier(card=card, siblings=siblings)

    try:
        active_session = client.db.active_session_for_agent(client.agent_name)
    except Exception:
        active_session = None
    try:
        all_sessions = client.db.active_sessions_for_agent(client.agent_name)
    except Exception:
        all_sessions = None

    message_summary: Dict[str, int] = {}
    work_summary: Dict[str, int] = {}
    try:
        message_summary = client.messaging.summary(client.agent_name) or {}
    except Exception:
        message_summary = {}
    try:
        work_summary = client.coordination.summary(client.agent_name) or {}
    except Exception:
        work_summary = {}

    try:
        wake_projection = build_wake_projection(
            card=card,
            active_session=active_session,
            message_summary=message_summary,
            work_summary=work_summary,
            all_sessions=all_sessions,
        )
    except Exception:
        wake_projection = None

    working_scope = resolve_working_scope(explicit=None, cwd=cwd)
    reference_docs = find_reference_docs(workspace_root=cwd) if cwd else []

    continuity_events = [
        {"kind": "session_bind", "at": _now_iso()},
    ]
    first_bind_at = card.get("registered_at")
    if first_bind_at:
        continuity_events.insert(0, {"kind": "first_bind", "at": first_bind_at})

    session_metadata: dict[str, Any] = {}
    if isinstance(active_session, dict):
        raw_metadata = active_session.get("metadata")
        if isinstance(raw_metadata, dict):
            session_metadata = dict(raw_metadata)
        elif isinstance(raw_metadata, str):
            try:
                parsed_metadata = json.loads(raw_metadata)
            except json.JSONDecodeError:
                parsed_metadata = {}
            if isinstance(parsed_metadata, dict):
                session_metadata = parsed_metadata

    identity = build_identity_section(
        card,
        trust_tier=resolved_tier,
        session_name=(
            session_metadata.get("session_name")
            or session_metadata.get("display_name")
            or card.get("display_name")
            or card.get("callsign")
        ),
    )
    truths = build_truths_section(
        card, active_session=active_session, wake_projection=wake_projection
    )
    center = build_center_section(working_scope=working_scope)
    anchors = build_anchors_section(
        continuity_events=continuity_events,
        memory_attachment=memory_attachment,
        reference_docs=reference_docs,
    )

    peers = None
    context = None
    try:
        db_path = getattr(client.db, "db_path", None)
        if db_path:
            self_cs = str(card.get("callsign") or getattr(client, "agent_name", ""))
            peers = build_peers_section(
                db_path=str(db_path),
                self_callsign=self_cs,
                budget=10,
            )
            context = build_context_section(
                db_path=str(db_path),
                self_callsign=self_cs,
                budget=10,
            )
    except Exception:
        pass

    capsule: Dict[str, Any] = {
        "identity": identity,
        "truths": truths,
        "center": center,
        "anchors": anchors,
    }
    if peers is not None:
        capsule["peers"] = peers
    if context is not None:
        capsule["context"] = context
    return capsule


def build_peers_section(
    *,
    db_path: str,
    self_callsign: str,
    budget: int = 10,
    message_activity_days: int = 7,
    pair_recency_hours: int = 72,
) -> Dict[str, Any]:
    """Build the `peers` capsule section using the four-layer selection
    algorithm specified in glittery-shimmying-tome.md §5.

    Selection layers (union, deduplicated):
        Layer 1: live members of workspaces I also belong to
        Layer 2: peers with whom I share a pair_space active in last 72h
        Layer 3: peers referenced in my continuity anchors / prior-bind memory
        Layer 4: peers who've exchanged messages with me in the last week

    Salience score per peer:
        recent_activity_weight × trust_tier × edge_strength

        * recent_activity_weight: inverse of minutes since last interaction,
          capped so ancient vs. recent still ranks sensibly.
        * trust_tier: the peer's numeric tier (0-6).
        * edge_strength: pair=3, tranche/workspace=2, message-only=1.

    Budget cap: top N unique peers by salience. Remainder surfaces as
    peers_omitted with a discoverable_via pointer.

    Every returned peer carries:
        callsign, participant_shape, trust_tier, presence, last_seen_at,
        collaboration_edge, fit_hint (nullable), shared_spaces, salience.

    Args:
        db_path: Path to the Whispers SQLite DB.
        self_callsign: The requesting agent's callsign (excluded from peers).
        budget: Max peers surfaced in the `peers` array (default 10).
        message_activity_days: Layer-4 window for message activity.
        pair_recency_hours: Layer-2 freshness threshold for pair spaces.

    Returns:
        {peers_selection_basis, peers: [...], peers_omitted: {...}, as_of}
    """
    import datetime as _dt
    import sqlite3 as _sqlite3

    normalized_self = (self_callsign or "").strip().lower()
    now = _dt.datetime.utcnow()
    as_of = now.isoformat() + "Z"

    candidates: Dict[str, Dict[str, Any]] = {}

    def _register(callsign: str, *, edge: str, space_id: Optional[str] = None) -> None:
        cs = (callsign or "").strip().lower()
        if not cs or cs == normalized_self:
            return
        entry = candidates.setdefault(
            cs,
            {
                "callsign": cs,
                "edges": set(),
                "shared_spaces": set(),
                "layer_hits": set(),
            },
        )
        entry["edges"].add(edge)
        if space_id:
            entry["shared_spaces"].add(space_id)

    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        # Layer 1 + 2: workspace co-membership (pair spaces included).
        my_spaces = [
            row["workspace_id"]
            for row in conn.execute(
                "SELECT workspace_id FROM workspace_members "
                "WHERE agent_name=?",
                (normalized_self,),
            ).fetchall()
        ]
        if my_spaces:
            placeholders = ",".join("?" * len(my_spaces))
            rows = conn.execute(
                f"SELECT wm.agent_name, wm.workspace_id, w.boundary_type, "
                f"w.last_delta_at FROM workspace_members wm "
                f"LEFT JOIN workspaces w ON w.workspace_id = wm.workspace_id "
                f"WHERE wm.workspace_id IN ({placeholders}) "
                f"AND wm.agent_name != ?",
                (*my_spaces, normalized_self),
            ).fetchall()
            pair_cutoff = now - _dt.timedelta(hours=pair_recency_hours)
            for row in rows:
                boundary = str(row["boundary_type"] or "").lower()
                if boundary == "pair":
                    last_delta = _parse_ts(row["last_delta_at"])
                    if last_delta is None or last_delta >= pair_cutoff:
                        edge = "pair"
                        layer = "layer_2_pair_72h"
                    else:
                        edge = "tranche_peer"
                        layer = "layer_1_shared_space"
                else:
                    edge = "tranche_peer"
                    layer = "layer_1_shared_space"
                _register(row["agent_name"], edge=edge, space_id=row["workspace_id"])
                candidates[(row["agent_name"] or "").strip().lower()]["layer_hits"].add(layer)

        # Layer 4: message activity in the past N days.
        activity_cutoff_sql = f"datetime('now', '-{int(message_activity_days)} days')"
        msg_rows = conn.execute(
            f"SELECT from_agent, to_agent FROM messages "
            f"WHERE created_at >= {activity_cutoff_sql} "
            f"AND (from_agent=? OR to_agent=?)",
            (normalized_self, normalized_self),
        ).fetchall()
        for row in msg_rows:
            other = row["to_agent"] if row["from_agent"] == normalized_self else row["from_agent"]
            if not other:
                continue
            _register(other, edge="message_partner")
            candidates[(other or "").strip().lower()]["layer_hits"].add(
                "layer_4_message_activity"
            )

        # Enrichment + salience scoring.
        enriched: list[Dict[str, Any]] = []
        for cs, state in candidates.items():
            card = conn.execute(
                "SELECT callsign, trust_tier, participant_shape, continuity_anchor, "
                "last_seen FROM agent_cards WHERE callsign=? AND deregistered_at IS NULL",
                (cs,),
            ).fetchone()
            if not card:
                continue
            trust_tier = int(card["trust_tier"] or 0)
            shape = card["participant_shape"] or "atomic"

            # Most recent message-timestamp with self, if any.
            last_msg_row = conn.execute(
                "SELECT MAX(created_at) AS t FROM messages "
                "WHERE ((from_agent=? AND to_agent=?) OR (from_agent=? AND to_agent=?))",
                (cs, normalized_self, normalized_self, cs),
            ).fetchone()
            last_msg_at = last_msg_row["t"] if last_msg_row else None
            last_msg_dt = _parse_ts(last_msg_at)

            # Session liveness
            session_row = conn.execute(
                "SELECT last_seen_at FROM agent_sessions "
                "WHERE agent_name=? AND lease_expires_at >= CURRENT_TIMESTAMP "
                "ORDER BY last_seen_at DESC LIMIT 1",
                (cs,),
            ).fetchone()
            session_last = _parse_ts(session_row["last_seen_at"]) if session_row else None
            presence_row = conn.execute(
                "SELECT status, last_active FROM presence WHERE agent_name=?",
                (cs,),
            ).fetchone()
            presence_status = (presence_row["status"] if presence_row else None) or "unknown"
            if session_last is not None:
                presence = "online" if (now - session_last).total_seconds() < 600 else "elsewhere"
            else:
                presence = presence_status if presence_status != "unknown" else "offline"

            last_seen_dt = session_last or last_msg_dt or _parse_ts(
                card["last_seen"] if "last_seen" in card.keys() else None
            )
            last_seen_at = last_seen_dt.isoformat() + "Z" if last_seen_dt else None

            # Salience
            edge_strength = 1
            if "pair" in state["edges"]:
                edge_strength = 3
            elif "tranche_peer" in state["edges"]:
                edge_strength = 2
            activity_dt = last_msg_dt or session_last
            if activity_dt is not None:
                minutes_ago = max(1.0, (now - activity_dt).total_seconds() / 60.0)
                activity_weight = 1.0 / (1.0 + (minutes_ago / 60.0))
            else:
                activity_weight = 0.1
            salience = activity_weight * max(1, trust_tier) * edge_strength

            collaboration_edge = (
                "pair" if "pair" in state["edges"]
                else "tranche_peer" if "tranche_peer" in state["edges"]
                else "message_partner"
            )

            fit_hint = None
            if collaboration_edge == "pair" and presence == "online":
                fit_hint = "pair coordination live"
            elif "layer_4_message_activity" in state["layer_hits"] and presence == "online":
                fit_hint = "recently exchanged messages, online now"

            enriched.append({
                "callsign": cs,
                "participant_shape": shape,
                "trust_tier": trust_tier,
                "wag_posture": None,
                "presence": presence,
                "last_seen_at": last_seen_at,
                "collaboration_edge": collaboration_edge,
                "fit_hint": fit_hint,
                "shared_spaces": sorted(state["shared_spaces"]),
                "salience": round(salience, 4),
                "_layer_hits": sorted(state["layer_hits"]),
            })

        enriched.sort(key=lambda p: (-p["salience"], p["callsign"]))
        total = len(enriched)
        kept = enriched[:budget]
        for peer in kept:
            peer.pop("_layer_hits", None)
        omitted_count = max(0, total - len(kept))
    finally:
        conn.close()

    return {
        "peers_selection_basis": "space_scoped + recent_collaboration + message_activity",
        "peers": kept,
        "peers_omitted": {
            "count": omitted_count,
            "reason": "budget_cap" if omitted_count else "none",
            "discoverable_via": "mcp__whispers__presence_who()",
        },
        "as_of": as_of,
    }


_PRIORITY_WEIGHT = {"flash": 3.0, "priority": 2.0, "routine": 1.0}


def build_context_section(
    *,
    db_path: str,
    self_callsign: str,
    budget: int = 10,
    activity_days: int = 7,
) -> Dict[str, Any]:
    """Build the `context` capsule section — "what just happened."

    Spec: glittery-shimmying-tome.md §6. Sources: recent inbox (salience-
    ranked, not chronological), scope-relevant events, pending obligations,
    residue (stubbed), drive signals (stubbed).

    Recent-message salience per entry:
        priority_weight × recency_weight × sender_tier

        * priority_weight: flash=3, priority=2, routine=1
        * recency_weight: inverse of minutes-since-message, decayed so
          a 1-min-old flash still outranks an older flash without
          drowning out older priority traffic.
        * sender_tier: the message sender's agent_cards.trust_tier.

    Pending obligations: unread flash/priority messages addressed to self,
    or messages flagged flash-awaiting (we surface both as kind=
    "flash_awaiting" or "priority_awaiting" for now).

    residue + drive_signals are stubbed to [] per the plan's Phase-1
    contract until the residue capture pipeline lands.

    Args:
        db_path: Path to the Whispers SQLite DB.
        self_callsign: The requesting agent's callsign.
        budget: Max messages surfaced in recent_messages (default 10).
        activity_days: Window for pulling recent traffic (default 7).

    Returns:
        {recent_messages, recent_messages_omitted, recent_scope_events,
         pending_obligations, recent_residue, drive_signals, as_of}
    """
    import datetime as _dt
    import sqlite3 as _sqlite3

    normalized_self = (self_callsign or "").strip().lower()
    now = _dt.datetime.utcnow()
    as_of = now.isoformat() + "Z"
    activity_cutoff_sql = f"datetime('now', '-{int(activity_days)} days')"

    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    recent_messages: list[Dict[str, Any]] = []
    pending: list[Dict[str, Any]] = []
    try:
        rows = conn.execute(
            f"SELECT uuid, from_agent, to_agent, priority, subject, status, "
            f"created_at, seen_at, acked_at FROM messages "
            f"WHERE created_at >= {activity_cutoff_sql} "
            f"AND (from_agent=? OR to_agent=?) "
            f"ORDER BY created_at DESC",
            (normalized_self, normalized_self),
        ).fetchall()

        sender_tiers: dict[str, int] = {}
        def _tier_for(cs: str) -> int:
            cs = (cs or "").strip().lower()
            if not cs:
                return 1
            if cs in sender_tiers:
                return sender_tiers[cs]
            card = conn.execute(
                "SELECT trust_tier FROM agent_cards WHERE callsign=? "
                "AND deregistered_at IS NULL",
                (cs,),
            ).fetchone()
            tier = int(card["trust_tier"]) if card and card["trust_tier"] is not None else 1
            sender_tiers[cs] = tier
            return tier

        candidates: list[Dict[str, Any]] = []
        for row in rows:
            created_dt = _parse_ts(row["created_at"])
            if created_dt is None:
                continue
            age_minutes = max(1.0, (now - created_dt).total_seconds() / 60.0)
            priority = (row["priority"] or "routine").lower()
            priority_weight = _PRIORITY_WEIGHT.get(priority, 1.0)
            recency_weight = 1.0 / (1.0 + (age_minutes / 30.0))
            frm = row["from_agent"] or ""
            sender_tier = _tier_for(frm) if frm != normalized_self else 1
            salience = priority_weight * recency_weight * max(1, sender_tier)
            entry = {
                "uuid": row["uuid"],
                "from": frm,
                "to": row["to_agent"],
                "subject": row["subject"] or "",
                "priority": priority,
                "status": row["status"] or "",
                "at": row["created_at"],
                "age_minutes": round(age_minutes, 1),
                "salience": round(salience, 4),
            }
            candidates.append(entry)

            # Obligation detection: inbound flash/priority, not yet read/acked
            if (
                row["to_agent"] == normalized_self
                and priority in ("flash", "priority")
                and not row["seen_at"]
                and not row["acked_at"]
            ):
                pending.append({
                    "kind": "flash_awaiting" if priority == "flash" else "priority_awaiting",
                    "from": frm,
                    "subject": row["subject"] or "",
                    "at": row["created_at"],
                    "status": row["status"] or "",
                    "uuid": row["uuid"],
                })

        candidates.sort(key=lambda m: -m["salience"])
        total = len(candidates)
        kept = candidates[:budget]
        omitted = max(0, total - len(kept))
        recent_messages = [
            {k: v for k, v in m.items() if k != "salience"}
            for m in kept
        ]

        # Recent scope events (workspace deltas) — best-effort.
        try:
            scope_rows = conn.execute(
                "SELECT workspace_id, delta_kind, actor, text, created_at "
                "FROM workspace_events "
                "WHERE actor=? OR workspace_id IN ("
                "  SELECT workspace_id FROM workspace_members WHERE agent_name=?"
                ") "
                "ORDER BY created_at DESC LIMIT 5",
                (normalized_self, normalized_self),
            ).fetchall()
            recent_scope_events = [
                {
                    "kind": r["delta_kind"],
                    "id": r["workspace_id"],
                    "subject": r["text"] or "",
                    "at": r["created_at"],
                }
                for r in scope_rows
            ]
        except _sqlite3.OperationalError:
            recent_scope_events = []
    finally:
        conn.close()

    # Lazy imports — residue and drive_signals live in sibling modules
    # that may or may not be present in a given install. Degrade silently
    # to [] rather than letting a missing helper fail the whole section.
    residue: list[Dict[str, Any]] = []
    try:
        from .residue import detect_residue as _detect_residue
        residue = _detect_residue(
            db_path=db_path,
            self_callsign=normalized_self,
            window_days=activity_days,
            min_repetitions=3,
            limit=10,
        )
    except Exception:
        residue = []

    # Drive-signal derivation. Uses the primitives we already computed above
    # so there's no second DB pass. Theory basis:
    # .planning/theory/DRIVE-SIGNALS-AND-MOTIVATIONAL-SALIENCE-2026-04-16.md §3.
    # Known-peers set lets the cue derivation flag messages from senders
    # outside the caller's current scope as `investigate` signals.
    drive_signals: list[Dict[str, Any]] = []
    try:
        from .drive_signals import derive_drive_cues as _derive_drive_cues
        known_peers_set: set[str] = set()
        try:
            inner_conn = _sqlite3.connect(db_path, timeout=10)
            inner_conn.row_factory = _sqlite3.Row
            try:
                my_ws_rows = inner_conn.execute(
                    "SELECT workspace_id FROM workspace_members WHERE agent_name=?",
                    (normalized_self,),
                ).fetchall()
                if my_ws_rows:
                    placeholders = ",".join("?" * len(my_ws_rows))
                    peer_rows = inner_conn.execute(
                        f"SELECT DISTINCT agent_name FROM workspace_members "
                        f"WHERE workspace_id IN ({placeholders}) "
                        f"AND agent_name != ?",
                        (*(r["workspace_id"] for r in my_ws_rows), normalized_self),
                    ).fetchall()
                    known_peers_set = {
                        (r["agent_name"] or "").strip().lower()
                        for r in peer_rows
                    }
            finally:
                inner_conn.close()
        except Exception:
            known_peers_set = set()
        drive_signals = _derive_drive_cues(
            recent_messages=recent_messages,
            pending_obligations=pending,
            residue=residue,
            recent_scope_events=recent_scope_events,
            self_callsign=normalized_self,
            known_peers=known_peers_set,
        )
    except Exception:
        drive_signals = []

    return {
        "recent_messages": recent_messages,
        "recent_messages_omitted": {
            "count": omitted,
            "reason": "budget_cap" if omitted else "none",
            "discoverable_via": "mcp__whispers__inbox()",
        },
        "recent_scope_events": recent_scope_events,
        "pending_obligations": pending[:10],
        "recent_residue": residue,
        "drive_signals": drive_signals,
        # Forward-compat placeholder per kiln's inhibition proposal.
        # When inhibition lands, derive_drive_cues will return
        # (surfaced, suppressed); the suppressed list goes here
        # without requiring a capsule-shape change. Consumers that
        # want to render "what was filtered" can read this field
        # today and get [] until the producer ships.
        "drive_signals_suppressed": [],
        "as_of": as_of,
    }


def _parse_ts(raw: Any) -> Optional["datetime.datetime"]:
    """Best-effort parse of a SQLite timestamp string to datetime (UTC-naive)."""
    import datetime as _dt

    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return None
    text = text.replace("T", " ").split(".")[0].rstrip("Z").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return _dt.datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


def authorize_trust_tier(
    *,
    db_path: str,
    callsign: str,
    tier: int,
) -> Dict[str, Any]:
    """Operator-approval path for promoting a tier-0 card to a real tier.

    Writes a new tier_tier onto the named card's `agent_cards` row. This
    is the DB-write side of the MI-2 no-sibling bind path: a fresh agent
    that bound with basis='unknown_requires_authorization' stays at tier
    0 (blocked from cross-tier sends) until an operator runs
    `whispers authorize-tier <callsign> <tier>`. After this runs, the
    next bind's resolver will find the declared tier and report it with
    basis='declared'.

    Side effect: also updates `capabilities_verified` and
    `can_send_flash` on the row so the dispatcher's rate-limit surface
    aligns with the new tier.

    Args:
        db_path: Path to the Whispers SQLite database.
        callsign: The callsign to promote.
        tier: Integer tier 0..6 (0 is a valid demotion target).

    Returns:
        {ok, callsign, tier, reason} dict. On failure, ok=False and
        reason names the specific gap.
    """
    import json as _json
    import sqlite3 as _sqlite3

    if not isinstance(tier, int) or tier < 0 or tier > 6:
        return {"ok": False, "callsign": callsign, "tier": tier, "reason": "invalid_tier_must_be_integer_0_to_6"}

    conn = _sqlite3.connect(db_path, timeout=10)
    try:
        row = conn.execute(
            "SELECT trust_tier FROM agent_cards WHERE callsign=?", (callsign,)
        ).fetchone()
        if row is None:
            return {
                "ok": False,
                "callsign": callsign,
                "tier": tier,
                "reason": f"no_agent_card_for_{callsign}",
            }
        verified = _json.dumps({"trust_tier": tier, "can_send_flash": tier >= 4})
        conn.execute(
            "UPDATE agent_cards SET trust_tier=?, capabilities_verified=?, "
            "can_send_flash=? WHERE callsign=?",
            (tier, verified, 1 if tier >= 4 else 0, callsign),
        )
        conn.commit()
    finally:
        conn.close()

    return {"ok": True, "callsign": callsign, "tier": tier, "reason": None}


def release_callsign(
    *,
    db_path: str,
    callsign: str,
    force: bool = False,
    actor: str | None = None,
    reason: str | None = None,
) -> Dict[str, Any]:
    """Release an orphaned callsign reservation so it can be rebound.

    Solves the "reserved by another participant history" rebind block:
    when a prior agent session closed but its callsign_ledger row remains,
    `continuity.py` rejects new binds for that callsign with no product-level
    recovery path. This is the recovery path.

    Guards (unless force=True):
        * No rows in `agent_sessions` matching `agent_name=callsign` (refuses
          release when a live participant is still bound).

    Effects:
        * DELETE from `callsign_ledger` WHERE callsign=?
        * DELETE from `agent_cards` WHERE callsign=?   (orphan card)
        * DELETE from `presence`     WHERE agent_name=? (stale presence)
        * DELETE from `agent_sessions` WHERE agent_name=? (only when force=True)
        * INSERT an `identity_events` audit row with outcome='released'.

    Does NOT touch `messages`, `workspaces`, or message_recipients — history
    survives the release so the audit trail remains intact when the callsign
    is reissued.

    Args:
        db_path: Path to the Whispers SQLite database.
        callsign: The callsign to release.
        force: Override the live-session guard. Use when a stale session
            row is known to be dead (e.g. Claude Code restart left an
            orphan row with a lease that won't expire for 30 minutes).
        actor: Optional identifier for the operator (written to the
            identity_events audit row).
        reason: Optional free-text reason (written to the audit row).

    Returns:
        {ok, callsign, released: {ledger, card, presence, session}, reason}
    """
    import sqlite3 as _sqlite3

    normalized = (callsign or "").strip().lower()
    if not normalized:
        return {"ok": False, "callsign": callsign, "reason": "empty_callsign"}

    conn = _sqlite3.connect(db_path, timeout=10)
    try:
        live_sessions = conn.execute(
            "SELECT session_id FROM agent_sessions WHERE agent_name=?",
            (normalized,),
        ).fetchall()
        if live_sessions and not force:
            return {
                "ok": False,
                "callsign": normalized,
                "reason": f"live_session_present:{len(live_sessions)}_refuse_without_force",
                "released": {"ledger": 0, "card": 0, "presence": 0, "session": 0},
            }

        released_sessions = 0
        if force and live_sessions:
            cur = conn.execute("DELETE FROM agent_sessions WHERE agent_name=?", (normalized,))
            released_sessions = cur.rowcount or 0

        cur_ledger = conn.execute("DELETE FROM callsign_ledger WHERE callsign=?", (normalized,))
        released_ledger = cur_ledger.rowcount or 0

        cur_card = conn.execute("DELETE FROM agent_cards WHERE callsign=?", (normalized,))
        released_card = cur_card.rowcount or 0

        try:
            cur_presence = conn.execute("DELETE FROM presence WHERE agent_name=?", (normalized,))
            released_presence = cur_presence.rowcount or 0
        except _sqlite3.OperationalError:
            released_presence = 0

        try:
            conn.execute(
                "INSERT INTO identity_events (event_type, outcome, callsign, details, created_at) "
                "VALUES (?, ?, ?, ?, datetime('now'))",
                (
                    "callsign_release",
                    "released",
                    normalized,
                    '{"actor": "' + (actor or "") + '", "reason": "' + (reason or "") + '", '
                    '"released": {"ledger": ' + str(released_ledger) + ', "card": ' + str(released_card) +
                    ', "presence": ' + str(released_presence) + ', "session": ' + str(released_sessions) + "}}",
                ),
            )
        except _sqlite3.OperationalError:
            pass

        conn.commit()
    finally:
        conn.close()

    return {
        "ok": True,
        "callsign": normalized,
        "released": {
            "ledger": released_ledger,
            "card": released_card,
            "presence": released_presence,
            "session": released_sessions,
        },
        "reason": None,
    }


def sweep_dead_pid_sessions(
    *,
    db_path: str,
    idle_threshold_seconds: int = 60,
    actor: str | None = None,
) -> Dict[str, Any]:
    """Delete agent_sessions rows rooted in dead OS processes.

    Addresses symptom 1 from STARTUP-MECHANICS-OVERHAUL §2: after a
    Claude Code window dies, its `agent_sessions` row lingers with a
    30-minute lease. The next bind sees the stale row — in collision
    detection or live-session counts — and misrepresents the seat's
    real state.

    Guards:
        * Skip rows with process_id IS NULL (provenance unknown).
        * Skip rows whose process_id matches a live OS process
          (`psutil.pid_exists` is True).
        * Skip rows whose last_seen_at is within the idle threshold —
          protects against a just-reconnected session whose process_id
          hasn't been updated yet, or races during MCP reconnects.

    Every deleted row writes an `identity_events` audit entry with
    event_type='session_swept'.

    Args:
        db_path: Path to the Whispers SQLite database.
        idle_threshold_seconds: Grace period. Sessions last-seen more
            recently than this are preserved even if their PID is dead.
            Default 60s.
        actor: Operator identifier for the audit rows.

    Returns:
        {swept: N, per_callsign: {callsign: count, ...}, swept_ids: [...]}
    """
    import sqlite3 as _sqlite3

    try:
        import psutil  # type: ignore
    except ImportError:
        return {
            "swept": 0,
            "per_callsign": {},
            "swept_ids": [],
            "reason": "psutil_unavailable",
        }

    swept_ids: list[str] = []
    per_callsign: Dict[str, int] = {}

    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        cutoff_expr = f"datetime('now', '-{int(idle_threshold_seconds)} seconds')"
        rows = conn.execute(
            f"SELECT session_id, agent_name, process_id FROM agent_sessions "
            f"WHERE process_id IS NOT NULL AND last_seen_at < {cutoff_expr}"
        ).fetchall()
        for row in rows:
            pid = int(row["process_id"])
            try:
                alive = psutil.pid_exists(pid)
            except Exception:
                alive = True
            if alive:
                continue
            conn.execute(
                "DELETE FROM agent_sessions WHERE session_id=?",
                (row["session_id"],),
            )
            swept_ids.append(str(row["session_id"]))
            name = str(row["agent_name"] or "")
            if name:
                per_callsign[name] = per_callsign.get(name, 0) + 1
            try:
                conn.execute(
                    "INSERT INTO identity_events (event_type, outcome, callsign, "
                    "details, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
                    (
                        "session_swept",
                        "dead_pid",
                        name,
                        '{"actor":"' + (actor or "") + '","session_id":"'
                        + str(row["session_id"]) + '","pid":' + str(pid) + "}",
                    ),
                )
            except _sqlite3.OperationalError:
                pass
        conn.commit()
    finally:
        conn.close()

    # Slice 9: for each callsign we just swept, fire a peer_gone delta
    # event so currently-subscribed peers see the disappearance in real
    # time. Best-effort — a broker failure never fails the sweep.
    try:
        from .delta_stream import emit_peer_gone, get_delta_broker
        broker = get_delta_broker()
        for callsign in per_callsign.keys():
            emit_peer_gone(
                broker,
                callsign=callsign,
                reason="dead_pid_sweep",
            )
    except Exception:
        pass

    return {
        "swept": len(swept_ids),
        "per_callsign": per_callsign,
        "swept_ids": swept_ids,
    }


def sweep_dead_presence_rows(
    *,
    db_path: str,
    idle_threshold_seconds: int = 60,
    actor: str | None = None,
) -> Dict[str, Any]:
    """Delete presence rows whose session is gone/expired.

    Companion to sweep_dead_pid_sessions (Slice 7) for the `presence`
    table. The agent_sessions sweep fixed anchor-locks; this one stops
    the peers section from showing the same agent multiple times from
    zombie presence rows left by prior-session reconnects.

    Guards (fail-closed on uncertainty):
        * Rows whose session_id matches a LIVE agent_sessions row
          (lease_expires_at >= now) are preserved.
        * Rows with heartbeat within idle_threshold_seconds are preserved
          (protects mid-reconnect races).
        * Rows that pass both guards — either session_id missing/expired,
          or session_id references a gone agent_sessions row — AND are
          older than the grace window are deleted.

    Returns:
        {swept: N, per_callsign: {callsign: count}, swept_session_ids: [...]}
    """
    import sqlite3 as _sqlite3

    per_callsign: Dict[str, int] = {}
    swept_session_ids: list[str] = []

    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        cutoff = f"datetime('now', '-{int(idle_threshold_seconds)} seconds')"
        rows = conn.execute(
            f"SELECT agent_name, session_id, heartbeat_at FROM presence "
            f"WHERE (heartbeat_at IS NULL OR heartbeat_at < {cutoff})"
        ).fetchall()

        for row in rows:
            session_id = row["session_id"]
            if session_id:
                live = conn.execute(
                    "SELECT 1 FROM agent_sessions "
                    "WHERE session_id=? AND lease_expires_at >= CURRENT_TIMESTAMP",
                    (session_id,),
                ).fetchone()
                if live:
                    continue
            name = (row["agent_name"] or "").strip()
            if not name:
                continue
            conn.execute(
                "DELETE FROM presence WHERE agent_name=? AND "
                "(session_id IS ? OR (session_id IS NULL AND ? IS NULL))",
                (name, session_id, session_id),
            )
            if session_id:
                swept_session_ids.append(session_id)
            per_callsign[name] = per_callsign.get(name, 0) + 1
        conn.commit()
    finally:
        conn.close()

    return {
        "swept": sum(per_callsign.values()),
        "per_callsign": per_callsign,
        "swept_session_ids": swept_session_ids,
    }


def build_collision_envelope(
    *,
    db_path: str,
    requested_callsign: str,
    platform_family: str,
    conflict: Dict[str, Any],
) -> Dict[str, Any]:
    """Construct the structured choice envelope returned when bind_seat
    detects a callsign collision.

    Replaces today's silent `sibling_instance_allocated` behavior with an
    honest surface: the operator sees the collision and picks the
    resolution. See SLICE-6-BIND-COLLISION-CHOICE-2026-04-17.md for the
    full schema and rationale.

    Args:
        db_path: Path to the Whispers SQLite DB — used to read the
            colliding card's current state (live sessions, ledger status,
            history counts).
        requested_callsign: What the caller asked for.
        platform_family: Platform of the incoming bind (e.g. claude-code).
        conflict: The ContinuityConflictError.details dict (or an
            equivalent synthesized dict). Must include "kind" set to one
            of {"anchor_mismatch", "ledger_reservation"}.

    Returns:
        Envelope dict with shape:
            {bound: False, reason: "callsign_collision",
             requested_callsign, platform_family, collision: {...},
             choices: [...], operator_hint: str}
    """
    import sqlite3 as _sqlite3

    normalized = (requested_callsign or "").strip().lower()
    kind = str(conflict.get("kind") or "anchor_mismatch")

    colliding_card: Dict[str, Any] | None = None
    live_sessions = 0
    ledger_status = "absent"
    history_summary: Dict[str, int] = {
        "messages_as_sender": 0,
        "messages_as_recipient": 0,
        "workspaces_created": 0,
    }

    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        card_row = conn.execute(
            "SELECT agent_id, callsign, trust_tier, platform_family, "
            "registered_at, last_seen, continuity_anchor "
            "FROM agent_cards WHERE callsign=? AND deregistered_at IS NULL",
            (normalized,),
        ).fetchone()
        if card_row is not None:
            colliding_card = dict(card_row)
            sessions_row = conn.execute(
                "SELECT COUNT(*) AS c FROM agent_sessions "
                "WHERE agent_id=? AND lease_expires_at >= CURRENT_TIMESTAMP",
                (card_row["agent_id"],),
            ).fetchone()
            live_sessions = int(sessions_row["c"] if sessions_row else 0)

        ledger_row = conn.execute(
            "SELECT status FROM callsign_ledger WHERE callsign=?",
            (normalized,),
        ).fetchone()
        if ledger_row is not None:
            ledger_status = str(ledger_row["status"] or "current")

        msg_sender = conn.execute(
            "SELECT COUNT(*) AS c FROM messages WHERE from_agent=?",
            (normalized,),
        ).fetchone()
        msg_recipient = conn.execute(
            "SELECT COUNT(*) AS c FROM messages WHERE to_agent=?",
            (normalized,),
        ).fetchone()
        try:
            ws = conn.execute(
                "SELECT COUNT(*) AS c FROM workspaces WHERE created_by=?",
                (normalized,),
            ).fetchone()
            history_summary["workspaces_created"] = int(ws["c"] if ws else 0)
        except _sqlite3.OperationalError:
            pass
        history_summary["messages_as_sender"] = int(msg_sender["c"] if msg_sender else 0)
        history_summary["messages_as_recipient"] = int(msg_recipient["c"] if msg_recipient else 0)
    finally:
        conn.close()

    collision: Dict[str, Any] = {
        "kind": kind,
        "live_sessions": live_sessions,
        "ledger_status": ledger_status,
        "history_summary": history_summary,
    }
    if colliding_card is not None:
        collision["colliding_card"] = {
            "agent_id": colliding_card.get("agent_id"),
            "callsign": colliding_card.get("callsign"),
            "trust_tier": colliding_card.get("trust_tier"),
            "platform_family": colliding_card.get("platform_family"),
            "registered_at": colliding_card.get("registered_at"),
            "last_seen": colliding_card.get("last_seen"),
        }
        collision["colliding_anchor"] = colliding_card.get("continuity_anchor")

    choices: list[Dict[str, Any]] = []

    # Cinder caught this: platform_family names like "claude-code",
    # "codex", "pi", "script" are NOT bindable session callsigns. Taking
    # over one via the collision envelope reinforces the operator
    # confusion between "what platform am I on" and "what's my session
    # name." Suppress take_over on these; leave sibling + fresh.
    _PLATFORM_FAMILY_RESERVED = frozenset({
        "claude-code", "claude_code", "codex", "pi", "script",
        "browser", "mcp", "cli",
    })
    is_platform_family_reserved = normalized in _PLATFORM_FAMILY_RESERVED

    take_over_ok = (live_sessions == 0) and not is_platform_family_reserved
    take_over_entry: Dict[str, Any] = {
        "id": "take_over",
        "label": f"Take over '{normalized}' (release orphan reservation, bind fresh)",
        "precondition_ok": take_over_ok,
        "effect": (
            "Release the callsign ledger (and orphan card if present), then "
            "bind this session as the new '{name}'. Prior message history "
            "remains attributable to the old agent_id."
        ).format(name=normalized),
        "resolution_payload": {"resolve": "take_over"},
        "risks": [
            "Prior trust tier does NOT carry over; operator must re-authorize.",
        ],
    }
    if is_platform_family_reserved:
        take_over_entry["precondition_reason"] = (
            f"platform_family_not_bindable:{normalized}_is_a_platform_label_not_a_callsign"
        )
        take_over_entry["risks"].append(
            f"'{normalized}' is a platform_family label, not a per-session "
            f"callsign. Taking it over would not produce a coherent identity. "
            f"Pick a different callsign."
        )
    elif not take_over_ok:
        take_over_entry["precondition_reason"] = (
            f"live_session_present:{live_sessions}_sessions_on_colliding_anchor"
        )
        take_over_entry["risks"].append(
            "Colliding callsign has a live session — taking it over would "
            "evict an active peer. Coordinate out-of-band instead."
        )
    choices.append(take_over_entry)

    if kind == "anchor_mismatch":
        choices.append({
            "id": "sibling",
            "label": f"Bind as a '{normalized}-<suffix>' sibling (inherited tier)",
            "precondition_ok": True,
            "effect": (
                "Allocate a sibling callsign under the same instance group, "
                "inheriting trust tier from siblings. Your session gets a "
                "distinct name so there is no confusion with the existing "
                f"'{normalized}'."
            ),
            "resolution_payload": {"resolve": "sibling"},
            "risks": [],
        })

    choices.append({
        "id": "fresh",
        "label": "Cancel and pick a different callsign",
        "precondition_ok": True,
        "effect": "No changes. The caller retries bind_seat with a new requested_callsign.",
        "resolution_payload": {"resolve": "cancel"},
        "risks": [],
    })

    if take_over_ok and history_summary["messages_as_sender"] == 0 and live_sessions == 0:
        operator_hint = (
            f"'{normalized}' has no live session and no recent activity. "
            f"'take_over' is the typical pick if this session meant to "
            f"continue prior work under that name."
        )
    elif live_sessions > 0:
        operator_hint = (
            f"'{normalized}' is live elsewhere ({live_sessions} active "
            f"session{'s' if live_sessions != 1 else ''}). Use 'sibling' "
            f"to join alongside, or 'fresh' to pick a new name."
        )
    else:
        sender = history_summary["messages_as_sender"]
        operator_hint = (
            f"'{normalized}' has {sender} prior outbound message{'s' if sender != 1 else ''} "
            f"attributed to the orphan card. 'take_over' reclaims the name "
            f"for this session; 'sibling' sidesteps the history; 'fresh' cancels."
        )

    return {
        "bound": False,
        "reason": "callsign_collision",
        "requested_callsign": normalized,
        "platform_family": platform_family,
        "collision": collision,
        "choices": choices,
        "operator_hint": operator_hint,
    }


def apply_collision_resolution(
    *,
    db_path: str,
    requested_callsign: str,
    platform_family: str,
    resolve: Dict[str, Any],
    actor: str | None = None,
    reason: str | None = None,
) -> Dict[str, Any]:
    """Apply the operator's choice from a collision envelope.

    Three verbs are supported:
        * take_over  — calls release_callsign() to clear the orphan
                       ledger/card, emits an audit event, returns
                       next_step='retry_bind' so the caller re-invokes
                       bind_seat with the same inputs (now unblocked).
        * sibling    — validates the payload and returns next_step=
                       'sibling_bind' with a sibling_label the caller must
                       pass on the retry bind. No DB side effects here —
                       allocation happens inside connect() on retry.
        * cancel     — pure no-op. Returns next_step='cancelled'.

    Any unknown verb returns ok=False with a specific reason.

    Args:
        db_path: Path to the Whispers SQLite DB.
        requested_callsign: Must match the envelope this resolves.
        platform_family: Must match the envelope this resolves.
        resolve: Resolution payload (copied from choices[].resolution_payload).
            Minimum: {"resolve": "<verb>"}. Sibling may include "label".
        actor: Operator identifier for the identity_events audit row.
        reason: Free-text reason for the audit row.

    Returns:
        {ok: bool, resolved: verb, next_step: str, ...extras} on success.
        {ok: False, reason: "..."} on precondition or verb failure.
    """
    import sqlite3 as _sqlite3

    verb = str((resolve or {}).get("resolve") or "").strip().lower()
    normalized = (requested_callsign or "").strip().lower()

    if verb not in {"take_over", "sibling", "cancel"}:
        return {
            "ok": False,
            "reason": f"unknown_resolve_verb:{verb or 'missing'}",
            "resolved": verb,
        }

    def _audit(outcome: str, details_json: str) -> None:
        conn = _sqlite3.connect(db_path, timeout=10)
        try:
            try:
                conn.execute(
                    "INSERT INTO identity_events (event_type, outcome, callsign, details, created_at) "
                    "VALUES (?, ?, ?, ?, datetime('now'))",
                    ("collision_resolution", outcome, normalized, details_json),
                )
                conn.commit()
            except _sqlite3.OperationalError:
                pass
        finally:
            conn.close()

    if verb == "cancel":
        _audit("cancelled", '{"actor":"' + (actor or "") + '"}')
        return {
            "ok": True,
            "resolved": "cancel",
            "next_step": "cancelled",
            "requested_callsign": normalized,
        }

    if verb == "sibling":
        label = str((resolve or {}).get("label") or "").strip()
        if not label:
            import secrets
            label = secrets.token_hex(2)
        _audit(
            "sibling_requested",
            '{"actor":"' + (actor or "") + '","label":"' + label + '"}',
        )
        return {
            "ok": True,
            "resolved": "sibling",
            "next_step": "sibling_bind",
            "sibling_label": label,
            "requested_callsign": normalized,
        }

    # take_over path
    conn = _sqlite3.connect(db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        card_row = conn.execute(
            "SELECT agent_id FROM agent_cards WHERE callsign=? AND deregistered_at IS NULL",
            (normalized,),
        ).fetchone()
        live_sessions = 0
        if card_row is not None:
            sessions_row = conn.execute(
                "SELECT COUNT(*) AS c FROM agent_sessions "
                "WHERE agent_id=? AND lease_expires_at >= CURRENT_TIMESTAMP",
                (card_row["agent_id"],),
            ).fetchone()
            live_sessions = int(sessions_row["c"] if sessions_row else 0)
    finally:
        conn.close()

    if live_sessions > 0:
        _audit(
            "take_over_blocked",
            '{"actor":"' + (actor or "") + '","live_sessions":'
            + str(live_sessions) + "}",
        )
        return {
            "ok": False,
            "reason": f"live_session_present:{live_sessions}_refuse_take_over",
            "resolved": "take_over",
        }

    release_result = release_callsign(
        db_path=db_path,
        callsign=normalized,
        actor=actor or "collision_resolution",
        reason=reason or "take_over via collision envelope",
    )
    _audit(
        "take_over",
        '{"actor":"' + (actor or "") + '","release":'
        + str(release_result.get("released") or {}).replace("'", '"') + "}",
    )
    return {
        "ok": True,
        "resolved": "take_over",
        "next_step": "retry_bind",
        "requested_callsign": normalized,
        "release": release_result,
    }


__all__ = [
    "OrientationError",
    "OrientationResult",
    "OrientationState",
    "OrientationStateMachine",
    "STATE_ORDER",
    "apply_collision_resolution",
    "assemble_bind_capsule",
    "authorize_trust_tier",
    "build_anchors_section",
    "build_center_section",
    "build_collision_envelope",
    "build_context_section",
    "build_identity_section",
    "build_peers_section",
    "build_truths_section",
    "ensure_wake_adapter_for_claude_code_session",
    "find_reference_docs",
    "find_sibling_agents",
    "release_callsign",
    "resolve_trust_tier",
    "resolve_working_scope",
    "sweep_dead_pid_sessions",
    "sweep_dead_presence_rows",
]
