from __future__ import annotations

import json
import os

import click
import tomllib

from .client import WhispersClient
from .server import main as server_main
from .testing import WhispersTestHarness
from .storage.db import WhispersDB


def _resolve_agent(agent: str | None) -> str:
    """Return the agent name from arg, WHISPERS_AGENT env var, or ~/.whispers/config.toml."""
    if agent:
        return agent
    env = os.environ.get("WHISPERS_AGENT", "").strip()
    if env:
        return env
    config_path = os.path.expanduser("~/.whispers/config.toml")
    if os.path.exists(config_path):
        with open(config_path, "rb") as fh:
            data = tomllib.load(fh)
        name = (data.get("agent") or {}).get("name", "").strip()
        if name:
            return name
    raise click.UsageError(
        "Missing --agent. Set it explicitly, or set the WHISPERS_AGENT env var, "
        "or add [agent]\\nname = \"<callsign>\" to ~/.whispers/config.toml."
    )


@click.group()
def main() -> None:
    """Whispers fresh-start CLI."""


# Back-compat for older installed console scripts that still import whispers.cli:cli.
cli = main


@main.command()
@click.option("--db", "db_path", default=None, help="Path to the Whispers SQLite database.")
def init(db_path: str | None) -> None:
    db = WhispersDB(db_path=db_path)
    click.echo(f"Initialized Whispers DB at {db.db_path}")


def check_adopt_collision(
    *,
    callsign: str,
    db_path: str | None = None,
    live_window_minutes: int = 10,
    force: bool = False,
) -> dict:
    """Decide whether `whispers adopt <callsign>` is safe to proceed.

    Returns a verdict dict shaped as:
        {
            "safe": bool,
            "reason": "no_live_session" | "live_session_present" | "forced_takeover",
            "callsign": <normalized callsign>,
            "message": <operator-facing one-liner>,
            "colliding_session": <session_id or None>,
        }

    An adopt is refused when another agent_session is currently live on the
    callsign (lease valid AND last_seen within `live_window_minutes`). The
    `force=True` path returns safe=True but marks the reason so the caller
    can surface the takeover explicitly.
    """
    import sqlite3 as _sqlite3

    normalized = callsign.strip().lower()
    if not normalized:
        return {
            "safe": False,
            "reason": "empty_callsign",
            "callsign": normalized,
            "message": "Callsign cannot be empty.",
            "colliding_session": None,
        }

    db = WhispersDB(db_path=db_path)
    conn = _sqlite3.connect(db.db_path, timeout=10)
    conn.row_factory = _sqlite3.Row
    try:
        cutoff_seconds = int(live_window_minutes) * 60
        row = conn.execute(
            """
            SELECT session_id, last_seen_at
            FROM agent_sessions
            WHERE lower(agent_name) = ?
              AND lease_expires_at >= CURRENT_TIMESTAMP
              AND last_seen_at >= datetime('now', ?)
            ORDER BY last_seen_at DESC
            LIMIT 1
            """,
            (normalized, f"-{cutoff_seconds} seconds"),
        ).fetchone()
    finally:
        conn.close()

    if row is None:
        return {
            "safe": True,
            "reason": "no_live_session",
            "callsign": normalized,
            "message": f"No live session holds '{normalized}'; safe to adopt.",
            "colliding_session": None,
        }

    session_id = str(row["session_id"] or "")
    if force:
        return {
            "safe": True,
            "reason": "forced_takeover",
            "callsign": normalized,
            "message": (
                f"--force used: overlaying '{normalized}' even though a live "
                f"session ({session_id}) is present. The prior session will "
                f"stay in the DB until its lease expires."
            ),
            "colliding_session": session_id,
        }

    return {
        "safe": False,
        "reason": "live_session_present",
        "callsign": normalized,
        "message": (
            f"Refusing to adopt '{normalized}': another agent_session "
            f"({session_id}) is live on that callsign right now. Use "
            f"'whispers adopt {normalized} --force' to overlay anyway, "
            f"or pick a different callsign."
        ),
        "colliding_session": session_id,
    }


@main.command()
@click.argument("callsign")
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Overlay a callsign even if a live peer already holds it.",
)
@click.option("--db", "db_path", default=None, help="Path to the Whispers SQLite database.")
def adopt(callsign: str, force: bool, db_path: str | None) -> None:
    """Bind this terminal's status bar to a callsign. No relaunch needed.

    Walks up the process tree to find the Claude Code process hosting this
    shell, reads the session-id breadcrumb the statusline wrote, and writes
    a bind file the statusline reads on its next tick. Works across terminal
    emulators and multi-pane setups because the key is Claude Code's own
    session id, not a shared terminal-tab env var.

    Before writing the bind file, checks whether a live peer already holds
    the requested callsign. Refuses unless --force is passed, so operators
    don't silently step on a running agent's identity.
    """
    from pathlib import Path

    from .mcp_server import write_statusline_binding

    normalized = callsign.strip().lower()
    if not normalized:
        raise click.UsageError("callsign cannot be empty")

    verdict = check_adopt_collision(
        callsign=normalized, db_path=db_path, force=force,
    )
    if not verdict["safe"]:
        raise click.ClickException(verdict["message"])
    if verdict["reason"] == "forced_takeover":
        click.echo(verdict["message"])

    sessions_dir = Path.home() / ".whispers" / "claude-sessions"
    breadcrumb_dir = sessions_dir / "_breadcrumbs"
    sessions_dir.mkdir(parents=True, exist_ok=True)

    claude_pid = _find_claude_code_pid_in_ancestry()
    if claude_pid is None:
        raise click.ClickException(
            "Couldn't locate the Claude Code process hosting this shell. "
            "Make sure you're running 'whispers adopt' inside a Claude Code "
            "session (not a detached terminal), then try again."
        )

    breadcrumb = breadcrumb_dir / str(claude_pid)
    if not breadcrumb.is_file():
        raise click.ClickException(
            f"Found Claude Code process {claude_pid} but no statusline "
            f"breadcrumb yet. Wait a second for the status bar to tick, "
            f"then try again."
        )

    try:
        claude_session_id = breadcrumb.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise click.ClickException(f"Could not read breadcrumb: {exc}") from exc

    if not claude_session_id:
        raise click.ClickException(
            "Breadcrumb is empty. Wait for the next statusline tick and retry."
        )

    write_statusline_binding(claude_session_id=claude_session_id, callsign=normalized)
    click.echo(
        f"This terminal is now bound as '{normalized}' "
        f"(claude_session={claude_session_id[:12]}...). "
        f"Status bar will refresh on the next tick."
    )


def _find_claude_code_pid_in_ancestry() -> int | None:
    """Walk ancestors for the Claude Code executable.

    Prefers a process whose name starts with 'claude' (and is not a bash
    shim). Falls back to the OLDEST process with CLAUDECODE=1 in its env
    so we don't misidentify a shell that inherited the flag. Must match
    the statusline's lookup so breadcrumb keys agree.
    """
    try:
        import psutil  # type: ignore
    except ImportError:
        return None
    try:
        proc = psutil.Process(os.getpid())
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None

    ancestors = []
    for a in proc.parents():
        try:
            ancestors.append((a, (a.name() or "").lower()))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    for a, name in ancestors:
        if name.startswith("claude") and "bash" not in name:
            try:
                return a.pid
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

    candidates = []
    for a, _name in ancestors:
        try:
            env = a.environ() or {}
            if str(env.get("CLAUDECODE", "")).strip() == "1":
                candidates.append((a.create_time(), a.pid))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    if candidates:
        candidates.sort()
        return candidates[0][1]

    return None


@main.command()
def serve() -> None:
    server_main()


@main.command()
@click.option("--transport", type=click.Choice(["stdio", "http"], case_sensitive=False), default="stdio")
@click.option("--agent-name", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--server-url", default="http://127.0.0.1:8765/mcp/")
@click.option("--owner-id", default=None)
@click.option("--platform-family", default=None)
@click.option("--context-hint", default=None)
@click.option("--participant-profile", default="desktop_ide_agent")
def mcp_install(
    transport: str,
    agent_name: str | None,
    db_path: str | None,
    server_url: str,
    owner_id: str | None,
    platform_family: str | None,
    context_hint: str | None,
    participant_profile: str,
) -> None:
    if transport == "http":
        click.echo(
            json.dumps(
                {
                    "whispers": {
                        "url": server_url.rstrip("/"),
                        "transport": "streamable_http",
                        "notes": {
                            "bind_seat": "Call the MCP tool bind_seat after the server loads unless you add your own fixed-seat wrapper.",
                            "recommended_defaults": {
                                "owner_id": owner_id,
                                "platform_family": platform_family,
                                "context_hint": context_hint,
                                "participant_profile": participant_profile,
                            },
                        },
                    }
                },
                indent=2,
                sort_keys=True,
            )
        )
        return

    args: list[str] = []
    if agent_name:
        args.extend(["--agent-name", agent_name])
    if db_path:
        args.extend(["--db", db_path])
    if owner_id:
        args.extend(["--owner-id", owner_id])
    if platform_family:
        args.extend(["--platform-family", platform_family])
    if context_hint:
        args.extend(["--context-hint", context_hint])
    if participant_profile:
        args.extend(["--participant-profile", participant_profile])

    click.echo(
        json.dumps(
            {
                "whispers": {
                    "command": "whispers-mcp",
                    "args": args,
                    "transport": "stdio",
                }
            },
            indent=2,
            sort_keys=True,
        )
    )


@main.command()
@click.option("--db", "db_path", default=None)
@click.option("--agent", default=None)
def doctor(db_path: str | None, agent: str | None) -> None:
    db = WhispersDB(db_path=db_path)
    ok, write_error = db.check_write_ready()
    payload: dict[str, object] = {
        "db_path": db.db_path,
        "wal": db.check_wal_mode(),
        "write_ready": ok,
        "write_error": write_error,
    }
    if agent:
        agent = _resolve_agent(agent)
        client = WhispersClient(agent, db_path=db_path, read_only=True)
        payload["whoami"] = client.whoami()
        payload["status"] = client.status()
        payload["wake_events"] = client.wake_events(limit=10)
    click.echo(json.dumps(payload, indent=2, sort_keys=True))


@main.command("authorize-tier")
@click.argument("callsign")
@click.argument("tier", type=int)
@click.option("--db", "db_path", default=None, help="Path to the Whispers SQLite database.")
def authorize_tier(callsign: str, tier: int, db_path: str | None) -> None:
    """Promote an agent_card to the given trust tier (MI-2 operator-approval path).

    Use this after a fresh bind returned {trust_tier: {basis:
    "unknown_requires_authorization"}} — i.e., a new agent with no
    siblings to inherit from. After this runs, the next bind's
    resolver will see the declared tier and report it as 'declared'.

    Tier must be an integer 0..6. Tier 0 is a valid demotion.
    """
    from .orientation import authorize_trust_tier as _authorize
    from .storage.db import WhispersDB

    db = WhispersDB(db_path=db_path)
    result = _authorize(db_path=db.db_path, callsign=callsign, tier=tier)
    click.echo(json.dumps(result, indent=2, sort_keys=True))
    if not result.get("ok"):
        raise SystemExit(1)


@main.group("daemon")
def daemon_group() -> None:
    """Daemon supervisor — run the Whispers server with auto-restart on code edits."""


@daemon_group.command("run")
@click.option(
    "--watch",
    "watch_paths",
    multiple=True,
    default=None,
    help="Directory to recursively watch for .py changes. Repeatable. "
    "Default: the whispers/ package inside the repo the CLI was installed from.",
)
@click.option(
    "--command",
    "command",
    default=None,
    help="Shell command (list-safe) that (re)launches the daemon. "
    "Default: python ~/.whispers/_start.py",
)
@click.option(
    "--debounce",
    "debounce_seconds",
    type=float,
    default=1.0,
    help="Seconds to wait between file-system polls (and coalescing window for rapid edits).",
)
@click.option(
    "--cooldown",
    "cooldown_seconds",
    type=float,
    default=15.0,
    help="Seconds to wait after a restart before restarting again. Protects connected MCP "
    "clients from session-drop thrashing during rapid commit bursts. Set 0 to disable.",
)
def daemon_run(
    watch_paths: tuple[str, ...],
    command: str | None,
    debounce_seconds: float,
    cooldown_seconds: float,
) -> None:
    """Run the Whispers daemon under a file-watch supervisor.

    Every edit to watched .py files triggers a clean restart. Ctrl-C
    shuts both the supervisor and the daemon.
    """
    import os
    import shlex
    from pathlib import Path

    from .daemon_supervisor import DaemonSupervisor

    if not watch_paths:
        package_root = Path(__file__).resolve().parent
        effective_watch = [package_root]
    else:
        effective_watch = [Path(p) for p in watch_paths]

    if command:
        cmd = shlex.split(command)
    else:
        default_start = Path.home() / ".whispers" / "_start.py"
        cmd = [os.sys.executable, str(default_start)]

    click.echo(
        "[daemon-supervisor] watching: "
        + ", ".join(str(p) for p in effective_watch)
    )
    click.echo(f"[daemon-supervisor] command: {' '.join(cmd)}")
    click.echo(f"[daemon-supervisor] debounce: {debounce_seconds}s")

    sup = DaemonSupervisor(
        watch_paths=effective_watch,
        restart_command=cmd,
        debounce_seconds=debounce_seconds,
        cooldown_seconds=cooldown_seconds,
    )
    try:
        sup.start()
    except KeyboardInterrupt:
        click.echo("\n[daemon-supervisor] stopped by Ctrl-C")


@main.group("ledger")
def ledger_group() -> None:
    """Callsign ledger operations."""


@ledger_group.command("release")
@click.argument("callsign")
@click.option("--force", is_flag=True, default=False,
              help="Also remove stale agent_sessions rows blocking release.")
@click.option("--actor", default=None, help="Optional operator identifier for the audit log.")
@click.option("--reason", default=None, help="Optional free-text reason for the audit log.")
@click.option("--db", "db_path", default=None, help="Path to the Whispers SQLite database.")
def ledger_release(
    callsign: str,
    force: bool,
    actor: str | None,
    reason: str | None,
    db_path: str | None,
) -> None:
    """Release an orphaned callsign so it can be rebound.

    Use when `bind_seat` rejects a request with
    "Callsign 'X' is reserved by another participant history." because a
    prior session's ledger row lingers. Refuses to run if a live session
    still holds the callsign; pass --force to override for known-stale rows.
    """
    from .orientation import release_callsign as _release
    from .storage.db import WhispersDB

    db = WhispersDB(db_path=db_path)
    result = _release(
        db_path=db.db_path,
        callsign=callsign,
        force=force,
        actor=actor,
        reason=reason,
    )
    click.echo(json.dumps(result, indent=2, sort_keys=True))
    if not result.get("ok"):
        raise SystemExit(1)


@main.command("echo-peer")
@click.option("--callsign", default="echo", help="Bind under this callsign (default: echo)")
@click.option("--prefix", default="echo: ", help="Reply-body prefix (default: 'echo: ')")
@click.option("--poll-interval", type=float, default=0.5, help="Seconds between inbox checks")
@click.option("--once", is_flag=True, default=False, help="Echo one message then exit")
def echo_peer(callsign: str, prefix: str, poll_interval: float, once: bool) -> None:
    """Bind as a test peer that echoes every incoming whisper.

    Lets external integrators verify their own agent code end-to-end
    without needing a second Claude Code or Codex. Run this in one
    terminal, point your integration at it, watch messages round-trip.
    """
    from .echo_peer import run_echo_peer

    rc = run_echo_peer(
        callsign=callsign,
        prefix=prefix,
        poll_interval=poll_interval,
        once=once,
    )
    raise SystemExit(rc)


@main.command()
def smoke() -> None:
    with WhispersTestHarness() as harness:
        alice = harness.make_client("alice")
        bob = harness.make_client("bob")
        result = alice.send("bob", "Smoke")
        inbox = bob.check_inbox(mark_seen=False)
        ok = result.get("status") in {"delivered", "queued"} and bool(inbox)
        click.echo(json.dumps({"ok": ok, "result": result, "inbox_count": len(inbox)}, indent=2))
        raise SystemExit(0 if ok else 1)


@main.command()
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
def who(agent: str | None, db_path: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.whoami() or {}, indent=2, sort_keys=True))


@main.command()
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
def status(agent: str | None, db_path: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.status(), indent=2, sort_keys=True))


@main.command()
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
def wake(agent: str | None, db_path: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.wake_status(), indent=2, sort_keys=True))


@main.command("wake-register")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--adapter-kind", required=True)
@click.option("--supported-action", "supported_actions", multiple=True)
@click.option("--fallback-action", default=None)
@click.option("--state", default=None)
@click.option("--detail", default=None)
@click.option("--endpoint-url", default=None)
def wake_register(
    agent: str | None,
    db_path: str | None,
    adapter_kind: str,
    supported_actions: tuple[str, ...],
    fallback_action: str | None,
    state: str | None,
    detail: str | None,
    endpoint_url: str | None,
) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(
        json.dumps(
            client.wake_register_adapter(
                adapter_kind=adapter_kind,
                supported_actions=list(supported_actions),
                fallback_action=fallback_action,
                state=state,
                detail=detail,
                endpoint_url=endpoint_url,
            ),
            indent=2,
            sort_keys=True,
        )
    )


@main.command("wake-events")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--limit", default=20, type=int)
def wake_events(agent: str | None, db_path: str | None, limit: int) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps({"events": client.wake_events(limit=limit)}, indent=2, sort_keys=True))


@main.command()
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--line", is_flag=True, default=False,
              help="Print just the one-line signal_line instead of the full JSON chrome payload.")
def chrome(agent: str | None, db_path: str | None, line: bool) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    chrome_payload = client.chrome_status() or {}
    if line:
        inner = chrome_payload.get("chrome") if isinstance(chrome_payload.get("chrome"), dict) else chrome_payload
        signal = (inner or {}).get("signal_line") or ""
        click.echo(signal)
        return
    click.echo(json.dumps(chrome_payload, indent=2, sort_keys=True))


@main.command("describe")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--participant-profile", default=None)
@click.option("--participant-kind", default=None)
@click.option("--participant-shape", default=None)
@click.option("--agency-relation", default=None)
@click.option("--boundary-provenance", default=None)
@click.option("--recognition-basis", default=None)
@click.option("--reachability-mode", default=None)
@click.option("--ask", "interaction_asks", multiple=True)
@click.option("--capability", "capability_claims", multiple=True, help="Format: provenance_kind:capability[:provider]")
@click.option("--composition", "composition_hints", multiple=True, help="Format: relation:target[:basis]")
def describe(
    agent: str | None,
    db_path: str | None,
    participant_profile: str | None,
    participant_kind: str | None,
    participant_shape: str | None,
    agency_relation: str | None,
    boundary_provenance: str | None,
    recognition_basis: str | None,
    reachability_mode: str | None,
    interaction_asks: tuple[str, ...],
    capability_claims: tuple[str, ...],
    composition_hints: tuple[str, ...],
) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    capability_payload = []
    for raw in capability_claims:
        parts = [part.strip() for part in raw.split(":")]
        if len(parts) < 2:
            raise click.ClickException("--capability must be provenance_kind:capability[:provider]")
        item = {"provenance_kind": parts[0], "capability": parts[1]}
        if len(parts) > 2 and parts[2]:
            item["provider"] = parts[2]
        capability_payload.append(item)
    composition_payload = []
    for raw in composition_hints:
        parts = [part.strip() for part in raw.split(":")]
        if len(parts) < 2:
            raise click.ClickException("--composition must be relation:target[:basis]")
        item = {"source": agent, "relation": parts[0], "target": parts[1]}
        if len(parts) > 2 and parts[2]:
            item["basis"] = parts[2]
        composition_payload.append(item)
    click.echo(
        json.dumps(
            client.describe_self(
                participant_profile=participant_profile,
                participant_kind=participant_kind,
                participant_shape=participant_shape,
                agency_relation=agency_relation,
                boundary_provenance=boundary_provenance,
                recognition_basis=recognition_basis,
                reachability_mode=reachability_mode,
                interaction_asks=list(interaction_asks) or None,
                capability_claims=capability_payload or None,
                composition_hints=composition_payload or None,
            ),
            indent=2,
            sort_keys=True,
        )
    )


@main.group("participant")
def participant_group() -> None:
    """Participant onboarding helpers."""


@participant_group.command("profiles")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
def participant_profiles(agent: str | None, db_path: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps({"profiles": client.participant_profiles()}, indent=2, sort_keys=True))


@participant_group.command("kit")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--server", required=True)
@click.option("--profile", "participant_profile", required=True)
@click.option("--sender", required=True)
@click.option("--recipient", required=True)
@click.option("--subject", required=True)
@click.option("--body", default=None)
@click.option("--display-name", default=None)
@click.option("--artifact", "artifacts", multiple=True)
@click.option("--starter-artifact", default=None)
def participant_kit(
    agent: str | None,
    db_path: str | None,
    server: str,
    participant_profile: str,
    sender: str,
    recipient: str,
    subject: str,
    body: str | None,
    display_name: str | None,
    artifacts: tuple[str, ...],
    starter_artifact: str | None,
) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(
        json.dumps(
            client.participant_kit(
                server=server,
                participant_profile=participant_profile,
                sender=sender,
                recipient=recipient,
                subject=subject,
                body=body,
                display_name=display_name,
                artifacts=list(artifacts) or None,
                starter_artifact=starter_artifact,
            ),
            indent=2,
            sort_keys=True,
        )
    )


@main.command()
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--new-callsign", required=True)
@click.option("--reason", default=None)
@click.option("--display-name", default=None)
def rename(agent: str | None, db_path: str | None, new_callsign: str, reason: str | None, display_name: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(
        json.dumps(
            client.rename(new_callsign, reason=reason, display_name=display_name),
            indent=2,
            sort_keys=True,
        )
    )


@main.command()
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--to", required=True)
@click.option("--subject", required=True)
@click.option("--body", default=None)
@click.option("--space", "space_id", default=None, help="Send within an existing space.")
@click.option("--thread", "thread_id", default=None, help="Thread to append to.")
def send(
    agent: str | None,
    db_path: str | None,
    to: str,
    subject: str,
    body: str | None,
    space_id: str | None,
    thread_id: str | None,
) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(
        json.dumps(
            client.send(to, subject, body=body, space_id=space_id, thread_id=thread_id),
            indent=2,
            sort_keys=True,
        )
    )


@main.command()
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--message", "message_id", required=True)
@click.option("--body", required=True)
@click.option("--subject", default=None)
def reply(agent: str | None, db_path: str | None, message_id: str, body: str, subject: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.respond(message_id, body, subject=subject), indent=2, sort_keys=True))


@main.command()
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--limit", default=20, type=int)
@click.option("--space", "space_id", default=None)
def inbox(agent: str | None, db_path: str | None, limit: int, space_id: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(
        json.dumps(
            client.check_inbox(limit=limit, mark_seen=False, space_id=space_id),
            indent=2,
            sort_keys=True,
        )
    )


@main.command("thread")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--thread-id", required=True)
def thread_command(agent: str | None, db_path: str | None, thread_id: str) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.message_thread(thread_id), indent=2, sort_keys=True))


@main.group("space")
def space_group() -> None:
    """Space operations."""


@space_group.command("create")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--name", required=True)
@click.option("--purpose", default=None)
@click.option("--boundary", "boundary_type", default="hard")
@click.option("--governance", default="directed")
@click.option("--visibility", default="sealed")
@click.option("--temporality", default="persistent")
@click.option("--naming-policy", default="shared")
@click.option("--naming-conflict-mode", default="reject")
def space_create(
    agent: str | None,
    db_path: str | None,
    name: str,
    purpose: str | None,
    boundary_type: str,
    governance: str,
    visibility: str,
    temporality: str,
    naming_policy: str,
    naming_conflict_mode: str,
) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(
        json.dumps(
            client.space_create(
                name,
                purpose=purpose,
                boundary_type=boundary_type,
                governance=governance,
                visibility=visibility,
                temporality=temporality,
                naming_policy=naming_policy,
                naming_conflict_mode=naming_conflict_mode,
            ),
            indent=2,
            sort_keys=True,
        )
    )


@space_group.command("join")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
@click.option("--role", "membership_role", default="member")
def space_join(agent: str | None, db_path: str | None, space_id: str, membership_role: str) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.space_join(space_id, membership_role=membership_role), indent=2, sort_keys=True))


@space_group.command("leave")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
@click.option("--reason", default=None)
def space_leave(agent: str | None, db_path: str | None, space_id: str, reason: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.space_leave(space_id, reason=reason), indent=2, sort_keys=True))


@space_group.command("list")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--include-inactive", is_flag=True, default=False)
def space_list(agent: str | None, db_path: str | None, include_inactive: bool) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.spaces_list(include_inactive=include_inactive), indent=2, sort_keys=True))


@space_group.command("members")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
def space_members(agent: str | None, db_path: str | None, space_id: str) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.space_members(space_id), indent=2, sort_keys=True))


@space_group.command("presence")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
def space_presence(agent: str | None, db_path: str | None, space_id: str) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.space_presence(space_id), indent=2, sort_keys=True))


@space_group.command("name-self")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
@click.option("--name", "participation_name", default=None)
def space_name_self(agent: str | None, db_path: str | None, space_id: str, participation_name: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.space_name_self(space_id, participation_name), indent=2, sort_keys=True))


@space_group.command("bind-seat")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
@click.option("--seat", "seat_name", required=True)
@click.option("--occupant", "occupant_agent", default=None)
@click.option("--note", default=None)
def space_bind_seat(agent: str | None, db_path: str | None, space_id: str, seat_name: str, occupant_agent: str | None, note: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(
        json.dumps(
            client.space_bind_seat(space_id, seat_name, occupant_agent=occupant_agent, note=note),
            indent=2,
            sort_keys=True,
        )
    )


@space_group.command("claim-seat")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
@click.option("--seat", "seat_name", required=True)
@click.option("--note", default=None)
def space_claim_seat(agent: str | None, db_path: str | None, space_id: str, seat_name: str, note: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.space_claim_seat(space_id, seat_name, note=note), indent=2, sort_keys=True))


@space_group.command("release-seat")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
@click.option("--seat", "seat_name", required=True)
@click.option("--note", default=None)
def space_release_seat(agent: str | None, db_path: str | None, space_id: str, seat_name: str, note: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.space_release_seat(space_id, seat_name, note=note), indent=2, sort_keys=True))


@space_group.command("seats")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", required=True)
def space_seats(agent: str | None, db_path: str | None, space_id: str) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.space_seats(space_id), indent=2, sort_keys=True))


@main.group("work")
def work_group() -> None:
    """Work / coordination operations."""


@work_group.command("offer")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--to", required=True)
@click.option("--title", required=True)
@click.option("--description", default=None)
@click.option("--space-id", default=None)
@click.option("--require-capability", "required_capabilities", multiple=True)
@click.option("--allow-external-capability-dependency", is_flag=True, default=False)
def work_offer(
    agent: str | None,
    db_path: str | None,
    to: str,
    title: str,
    description: str | None,
    space_id: str | None,
    required_capabilities: tuple[str, ...],
    allow_external_capability_dependency: bool,
) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(
        json.dumps(
            client.work_offer(
                to,
                title,
                description=description,
                space_id=space_id,
                metadata={
                    "whispers:required_capabilities": list(required_capabilities),
                    "whispers:allow_external_capability_dependency": allow_external_capability_dependency,
                }
                if required_capabilities or allow_external_capability_dependency
                else None,
            ),
            indent=2,
            sort_keys=True,
        )
    )


@work_group.command("accept")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--work-id", required=True)
@click.option("--note", default=None)
def work_accept(agent: str | None, db_path: str | None, work_id: str, note: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.work_accept(work_id, note=note), indent=2, sort_keys=True))


@work_group.command("start")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--work-id", required=True)
@click.option("--note", default=None)
def work_start(agent: str | None, db_path: str | None, work_id: str, note: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.work_start(work_id, note=note), indent=2, sort_keys=True))


@work_group.command("block")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--work-id", required=True)
@click.option("--note", required=True)
def work_block(agent: str | None, db_path: str | None, work_id: str, note: str) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.work_block(work_id, note=note), indent=2, sort_keys=True))


@work_group.command("handoff")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--work-id", required=True)
@click.option("--to", required=True)
@click.option("--note", default=None)
def work_handoff(agent: str | None, db_path: str | None, work_id: str, to: str, note: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.work_handoff(work_id, to=to, note=note), indent=2, sort_keys=True))


@work_group.command("reject")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--work-id", required=True)
@click.option("--note", default=None)
def work_reject(agent: str | None, db_path: str | None, work_id: str, note: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.work_reject(work_id, note=note), indent=2, sort_keys=True))


@work_group.command("close")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--work-id", required=True)
@click.option("--note", default=None)
def work_close(agent: str | None, db_path: str | None, work_id: str, note: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.work_close(work_id, note=note), indent=2, sort_keys=True))


@work_group.command("show")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--work-id", required=True)
def work_show(agent: str | None, db_path: str | None, work_id: str) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.work_get(work_id), indent=2, sort_keys=True))


@work_group.command("list")
@click.option("--agent", default=None)
@click.option("--db", "db_path", default=None)
@click.option("--space-id", default=None)
@click.option("--state", default=None)
def work_list(agent: str | None, db_path: str | None, space_id: str | None, state: str | None) -> None:
    agent = _resolve_agent(agent)
    client = WhispersClient(agent, db_path=db_path)
    click.echo(json.dumps(client.work_list(space_id=space_id, state=state), indent=2, sort_keys=True))


@main.group("listener")
def listener_group() -> None:
    """Active-listening daemon (v6) — start, stop, status."""


@listener_group.command("start")
@click.option("--callsign", required=True, help="Callsign to listen for.")
@click.option("--config", "config_path", default=None,
              help="Listener config TOML. Default: ~/.whispers/listeners/<callsign>.toml")
@click.option("--db", "db_path", default=None, help="Override Whispers DB path.")
def listener_start(callsign: str, config_path: str | None, db_path: str | None) -> None:
    """Run the listener daemon in the foreground. Ctrl-C to stop.

    The daemon subscribes to /wake/<callsign>/stream, runs events through
    WakePolicyStack + SafetyGuardrails + CoordinationGate, and dispatches
    allowed wakes to the configured InferenceBackend. Replies are sent
    back to the peer via the Whispers messaging path.
    """
    from .listeners.config import default_config_path, load_config
    from .listeners.daemon import AutonomousDaemon

    resolved_config = config_path or str(default_config_path(callsign))
    cfg = load_config(resolved_config)
    if cfg.callsign != callsign:
        raise click.UsageError(
            f"config.callsign={cfg.callsign!r} does not match --callsign {callsign!r}."
        )

    client = WhispersClient(
        agent_name=callsign,
        db_path=db_path,
        agent_type="infrastructure",
        session_kind="local_listener",
        reachability_mode="listener_backed",
    )
    daemon = AutonomousDaemon.from_config(cfg, client=client)
    click.echo(f"listener: starting for {callsign!r} from {resolved_config}")
    click.echo(f"listener: server={cfg.server_url} backend={cfg.backend.get('kind')}")
    daemon.start()
    try:
        daemon.wait()
    finally:
        daemon.stop()
        click.echo(f"listener: stopped. stats={json.dumps(daemon.stats.__dict__)}")


@listener_group.command("status")
@click.option("--callsign", required=True, help="Callsign to query.")
@click.option("--db", "db_path", default=None, help="Override Whispers DB path.")
def listener_status(callsign: str, db_path: str | None) -> None:
    """Read-only snapshot of the listener's side of the capsule.

    Shows whether a `local_listener` session is active for this callsign
    in the local DB, and the current wake_projection for the callsign
    (which reflects listener_attached and effective wake_model).
    """
    db = WhispersDB(db_path=db_path)
    sessions = db.active_sessions_for_agent(callsign)
    listener_sessions = [s for s in sessions if str(s.get("session_kind") or "").lower() == "local_listener"]

    from .registry import AgentRegistry
    from .wake_runtime import build_wake_projection

    registry = AgentRegistry(db)
    card = registry.get_agent_by_callsign(callsign)
    if not card:
        click.echo(json.dumps({
            "callsign": callsign,
            "error": "agent not found in registry",
        }, indent=2))
        return

    projection = build_wake_projection(
        card=card,
        active_session=sessions[0] if sessions else None,
        message_summary={},
        work_summary={},
        all_sessions=sessions,
    )

    click.echo(json.dumps({
        "callsign": callsign,
        "listener_sessions_active": len(listener_sessions),
        "total_sessions_active": len(sessions),
        "wake_model": projection.get("wake_model"),
        "card_wake_model": projection.get("card_wake_model"),
        "listener_attached": projection.get("listener_attached"),
        "host_capabilities": projection.get("host_capabilities"),
        "recommended_action": projection.get("recommended_action", {}).get("action"),
    }, indent=2, sort_keys=True))


@listener_group.command("stop")
@click.option("--callsign", required=True, help="Callsign to stop.")
@click.option("--db", "db_path", default=None, help="Override Whispers DB path.")
def listener_stop(callsign: str, db_path: str | None) -> None:
    """Revoke the listener session so a running daemon notices + exits.

    The daemon watches its session lease. Revoking the session forces
    the daemon's next presence refresh to return none and the engine's
    next reconnect to fail — both paths terminate the run. For a faster
    stop, send SIGINT (Ctrl-C) to the foreground process instead.
    """
    db = WhispersDB(db_path=db_path)
    sessions = db.active_sessions_for_agent(callsign)
    listener_sessions = [s for s in sessions if str(s.get("session_kind") or "").lower() == "local_listener"]
    if not listener_sessions:
        click.echo(json.dumps({
            "callsign": callsign,
            "stopped": 0,
            "reason": "no listener session active",
        }, indent=2))
        return
    revoked = 0
    with db.get_connection() as conn:
        for session in listener_sessions:
            session_id = session.get("session_id")
            if not session_id:
                continue
            try:
                conn.execute(
                    "DELETE FROM agent_sessions WHERE session_id = ?",
                    (session_id,),
                )
                revoked += 1
            except Exception as exc:  # noqa: BLE001
                click.echo(f"listener: failed to revoke {session_id}: {exc}", err=True)
        conn.commit()
    click.echo(json.dumps({
        "callsign": callsign,
        "stopped": revoked,
    }, indent=2))


cli = main


if __name__ == "__main__":
    main()
