from __future__ import annotations

import json
from typing import Any

from .jolt import (
    HostWakeCapabilities,
    JoltContext,
    conservative_jolt_budget,
    decide_jolt_action,
    host_wake_capabilities_from_dict,
    jolt_adapter_from_dict,
    jolt_budget_from_dict,
)


_INTERRUPTIBILITY_VALUES = {"free", "defer", "urgent_only", "do_not_interrupt"}


def _decode_metadata(raw: Any) -> dict[str, Any]:
    if isinstance(raw, dict):
        return dict(raw)
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return {}
        return dict(parsed) if isinstance(parsed, dict) else {}
    return {}


def _extract_registered_wake_adapter(
    session_metadata: dict[str, Any] | None,
) -> dict[str, Any] | None:
    metadata = dict(session_metadata or {})
    registrations = metadata.get("adapter_registrations")
    if not isinstance(registrations, dict) or not registrations:
        return None

    preferred_kind = "local_http_connector"
    kind, entry = (
        (preferred_kind, registrations[preferred_kind])
        if preferred_kind in registrations
        else next(iter(registrations.items()))
    )
    if not isinstance(entry, dict):
        return None

    adapter = dict(entry)
    adapter.setdefault("adapter_kind", str(kind))
    return adapter


def effective_reachability_mode(
    card_reachability_mode: str | None,
    session_metadata: dict[str, Any] | None = None,
) -> str:
    raw = str(card_reachability_mode or "").strip().lower() or "unknown"
    registered_adapter = _extract_registered_wake_adapter(session_metadata)
    if registered_adapter is not None:
        return str(registered_adapter.get("adapter_kind") or raw or "listener_backed")
    return raw


def wake_model_from_reachability_mode(reachability_mode: str | None) -> str:
    normalized = str(reachability_mode or "").strip().lower()
    if normalized == "listener_backed":
        return "listener_backed"
    if normalized == "mixed":
        return "listener_backed"
    return "manual_wake"


def _listener_sessions_present(all_sessions: list[dict[str, Any]] | None) -> bool:
    """True if any active session is a local_listener session.

    A listener session means an inference-capable daemon is subscribed
    to this callsign's wake stream — so the capsule's effective
    `can_trigger_inference` is True even if the card's reachability_mode
    is the baseline `manual_wake`.
    """
    if not all_sessions:
        return False
    for session in all_sessions:
        if str(session.get("session_kind") or "").strip().lower() == "local_listener":
            return True
    return False


def effective_wake_model(
    card_reachability_mode: str | None,
    all_sessions: list[dict[str, Any]] | None = None,
) -> str:
    """Union of card-declared wake_model and live session reality.

    If the card says manual_wake but a listener session is alive, the
    effective wake model is listener_backed — the agent IS reachable
    autonomously right now, even if the baseline posture is manual.
    """
    card_wake_model = wake_model_from_reachability_mode(card_reachability_mode)
    if card_wake_model in {"listener_backed", "always_on"}:
        return card_wake_model
    if _listener_sessions_present(all_sessions):
        return "listener_backed"
    return card_wake_model


def capabilities_for_reachability_mode(
    reachability_mode: str | None,
    *,
    session_metadata: dict[str, Any] | None = None,
) -> HostWakeCapabilities:
    normalized = str(reachability_mode or "").strip().lower()
    if normalized == "event_emit_only":
        return HostWakeCapabilities(
            host_kind="event_emit_only",
            can_notify=False,
            can_stage_context=False,
            can_trigger_inference=False,
        )
    if normalized == "read_only_status":
        return HostWakeCapabilities(
            host_kind="read_only_status",
            can_notify=False,
            can_stage_context=False,
            can_trigger_inference=False,
        )
    if normalized == "operator_console":
        return HostWakeCapabilities(
            host_kind="operator_console",
            can_notify=True,
            can_stage_context=False,
            can_trigger_inference=False,
        )
    wake_model = wake_model_from_reachability_mode(normalized)
    return host_wake_capabilities_from_dict(wake_model, session_metadata or {})


def build_wake_projection(
    *,
    card: dict[str, Any] | None,
    active_session: dict[str, Any] | None,
    message_summary: dict[str, int] | None,
    work_summary: dict[str, int] | None,
    all_sessions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    card = dict(card or {})
    active_session = dict(active_session or {}) if active_session else None
    session_metadata = _decode_metadata(active_session.get("metadata") if active_session else None)
    card_reachability_mode = str(card.get("reachability_mode") or "unknown").strip().lower() or "unknown"
    registered_adapter = _extract_registered_wake_adapter(session_metadata)
    reachability_mode = effective_reachability_mode(
        card_reachability_mode,
        session_metadata,
    )
    listener_attached = _listener_sessions_present(all_sessions)
    card_wake_model = wake_model_from_reachability_mode(card_reachability_mode)
    wake_model = effective_wake_model(card_reachability_mode, all_sessions)
    adapter_payload = registered_adapter or session_metadata
    capabilities = capabilities_for_reachability_mode(
        reachability_mode,
        session_metadata=adapter_payload,
    )
    if wake_model != card_wake_model and listener_attached and registered_adapter is None:
        # Upgrade capabilities to match the listener-attached reality.
        # The card may still declare manual_wake; the live session tells
        # the honest story.
        capabilities = host_wake_capabilities_from_dict(wake_model, session_metadata)
    adapter = jolt_adapter_from_dict(wake_model, adapter_payload)
    budget = jolt_budget_from_dict(session_metadata) if active_session else conservative_jolt_budget()

    message_summary = dict(message_summary or {})
    work_summary = dict(work_summary or {})
    unread = int(message_summary.get("unread", 0) or 0)
    urgent = int(message_summary.get("urgent", 0) or 0)
    incoming_offers = int(work_summary.get("incoming_offers", 0) or 0)
    blocked = int(work_summary.get("blocked", 0) or 0)

    if urgent > 0:
        trigger = "flash_message"
        priority = "flash"
        explicitly_addressed = True
    elif incoming_offers > 0:
        trigger = "direct_assignment"
        priority = "priority"
        explicitly_addressed = True
    elif unread > 0:
        trigger = "hot_thread"
        priority = "routine"
        explicitly_addressed = True
    else:
        trigger = "ambient_update"
        priority = "routine"
        explicitly_addressed = False

    interruptibility = str(session_metadata.get("interruptibility") or "defer").strip().lower()
    if interruptibility not in _INTERRUPTIBILITY_VALUES:
        interruptibility = "defer"

    context = JoltContext(
        trigger=trigger,  # type: ignore[arg-type]
        wake_model=wake_model,  # type: ignore[arg-type]
        interruptibility=interruptibility,  # type: ignore[arg-type]
        priority=priority,
        explicitly_addressed=explicitly_addressed,
        blocking=blocked > 0,
        operator_requested=False,
        message_size_tier="message",
        estimated_tokens=0,
        already_hot=unread > 1 or urgent > 0,
    )
    decision = decide_jolt_action(context, capabilities, budget)

    return {
        "reachability_mode": reachability_mode,
        "wake_model": wake_model,
        "card_wake_model": card_wake_model,
        "listener_attached": listener_attached,
        "session_kind": active_session.get("session_kind") if active_session else None,
        "session_last_seen_at": active_session.get("last_seen_at") if active_session else None,
        "host_capabilities": capabilities.to_dict(),
        "adapter": adapter.to_dict(),
        "budget": budget.to_dict(),
        "attention_context": {
            "trigger": context.trigger,
            "interruptibility": context.interruptibility,
            "priority": context.priority,
            "explicitly_addressed": context.explicitly_addressed,
            "blocking": context.blocking,
            "already_hot": context.already_hot,
        },
        "recommended_action": decision.to_dict(),
    }
