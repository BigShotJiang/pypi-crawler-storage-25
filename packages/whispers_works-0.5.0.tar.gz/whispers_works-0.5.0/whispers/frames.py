"""Canonical visual-convention glyphs and frame builders for Whispers.

Whispers' operator-visible surfaces speak a single visual language. The
glyphs in this module are the product — every inbox read, statusline
tick, wake banner, dashboard cell, scripted-demo transcript, and future
CLI output stamps from the SAME constants and the SAME frame builders.

# THE SINGLE-SOURCE RULE

Any module that stamps an operator-visible surface MUST import from
this module. Do not inline glyphs. Do not concatenate your own frame
template.  A drift-prevention test (``tests/test_frames_drift_fence``)
fails the build if a raw glyph appears in ``whispers/*.py`` anywhere
except this file.

If you need a shape this module doesn't expose yet, add the builder
HERE (with a docstring that names the surface it serves), then import
it — don't fork the glyph.

# GLYPH SEMANTICS (do not remap)

``⏦⏦⏦``    MARKER             Opens every Whispers-traffic frame.
                              Operator pattern-matches on this glyph to
                              know "this is Whispers, not background
                              prose." If a surface omits this, the
                              operator can't tell protocol traffic from
                              operator-readable output.
``▶``       ARROW              Direction inside a frame header:
                              ``from X ▶ to Y``. Never used as a standalone
                              signal.
``·``       SEPARATOR          Mid-dot joining frame segments. One
                              character of signal, not ``|`` or ``,``.
``⟡``       STATE_MARKER       2ACK state tag. Appears in a message
                              frame when ``payload.twoack.payload.state``
                              is set. Never used for anything else.
``◆``       URGENT_MARKER      Urgent attention in the statusline and
                              priority inbox surfaces. Reserved for
                              ``priority == "flash"`` or operator-ack-due
                              semantics — do not repurpose for generic
                              "important."
``◈``       INBOX_MARKER       New-message / inbound banner on
                              operator-facing inbox surfaces.
``◇``       ARCHIVED_MARKER    Sealed / archived / retired lifecycle
                              state. Used in outbox and work-closed
                              surfaces.

# RESERVED DIRECTIONAL PATTERNS

The brain-context memory and prior design work defines two standalone
directional variants for ambient-narration surfaces (chat previews,
dashboard feeds) where a frame header is too heavy:

``⏦⏦⏦> <text>``    outbound whisper narration (this agent → peer)
``<⏦⏦⏦ <text>``    inbound whisper narration (peer → this agent)

These are NOT currently wired into any code surface. They exist as a
planned vocabulary. If you introduce a surface that needs them, add
``outbound_narration()`` / ``inbound_narration()`` builders here FIRST,
then use them — do not inline ``f"⏦⏦⏦> {msg}"`` at the callsite.

# BUILDERS

For message frames (inbox, delta capsule, any per-message surface):
    :func:`message_frame_header`   — header-only line
    :func:`format_message_frame`   — header plus optional body

For statusline / chrome strip:
    :func:`signal_line_prefix`     — opening ``⏦⏦⏦ <callsign>`` chunk
    :func:`urgent_count_chunk`     — right-side ``◆N urgent`` chunk

For lifecycle / inbox banners (callers expected soon; stable API):
    :func:`inbox_banner`           — prepend ``◈`` to an operator line
    :func:`archived_banner`        — prepend ``◇`` to an operator line
"""
from __future__ import annotations


# ---- Markers ---------------------------------------------------------------
MARKER = "⏦⏦⏦"
ARROW = "▶"
SEPARATOR = " · "
STATE_MARKER = "⟡"
URGENT_MARKER = "◆"
INBOX_MARKER = "◈"
ARCHIVED_MARKER = "◇"

OUTBOUND_PREFIX = "⏦⏦⏦>"
INBOUND_PREFIX = "<⏦⏦⏦"


# ---- Message-frame builders ------------------------------------------------
def message_frame_header(
    sender: str,
    recipient: str,
    priority: str,
    subject: str,
    *,
    state: str | None = None,
) -> str:
    """Canonical message-frame header line.

    Shape: ``⏦⏦⏦ from {sender} ▶ to {recipient} · {priority}[ ⟡ {state}] · {subject}``
    """
    state_tag = f" {STATE_MARKER} {state}" if state else ""
    return (
        f"{MARKER} from {sender} {ARROW} to {recipient}"
        f"{SEPARATOR}{priority}{state_tag}{SEPARATOR}{subject}"
    )


def format_message_frame(
    sender: str,
    recipient: str,
    priority: str,
    subject: str,
    *,
    body: str | None = None,
    state: str | None = None,
) -> str:
    """Full message frame: header, plus an optional body on a second line."""
    header = message_frame_header(
        sender, recipient, priority, subject, state=state
    )
    return f"{header}\n{body}" if body else header


# ---- Statusline / chrome helpers ------------------------------------------
def signal_line_prefix(callsign: str) -> str:
    """Opening chunk of the per-terminal statusline: ``⏦⏦⏦ {callsign}``."""
    return f"{MARKER} {callsign}"


def urgent_count_chunk(count: int) -> str:
    """Right-side statusline chunk for urgent traffic: ``◆{n} urgent``."""
    return f"{URGENT_MARKER}{count} urgent"


# ---- Lifecycle / inbox banner helpers -------------------------------------
def inbox_banner(text: str) -> str:
    """Prepend the inbound banner glyph to an operator-visible line."""
    return f"{INBOX_MARKER} {text}"


def archived_banner(text: str) -> str:
    """Prepend the archived/sealed glyph to an operator-visible line."""
    return f"{ARCHIVED_MARKER} {text}"


# ---- Ambient-narration helpers (reserved — safe to call now) --------------
def outbound_narration(text: str) -> str:
    """Ambient narration of an outbound whisper: ``⏦⏦⏦> {text}``."""
    return f"{OUTBOUND_PREFIX} {text}"


def inbound_narration(text: str) -> str:
    """Ambient narration of an inbound whisper: ``<⏦⏦⏦ {text}``."""
    return f"{INBOUND_PREFIX} {text}"
