from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable, Mapping


VALID_DRIVE_POLARITIES = ("approach", "avoid", "investigate")
VALID_RECOMMENDED_ACTIONS = ("prefer", "caution", "protect", "recoil", "escalate", "monitor")


@dataclass(frozen=True)
class DriveCue:
    polarity: str
    cue_kind: str
    intensity: float  # 0.0 - 1.0
    reason: str
    basis: str | None = None

    def __post_init__(self) -> None:
        polarity = str(self.polarity or "").strip().lower()
        if polarity not in VALID_DRIVE_POLARITIES:
            raise ValueError(
                f"Invalid drive polarity '{self.polarity}'. Expected one of: {', '.join(VALID_DRIVE_POLARITIES)}."
            )
        object.__setattr__(self, "polarity", polarity)
        object.__setattr__(self, "intensity", max(0.0, min(float(self.intensity), 1.0)))


@dataclass(frozen=True)
class DriveAssessment:
    dominant_polarity: str
    recommended_action: str
    reasons: tuple[str, ...]

    def __post_init__(self) -> None:
        action = str(self.recommended_action or "").strip().lower()
        if action not in VALID_RECOMMENDED_ACTIONS:
            raise ValueError(
                f"Invalid recommended_action '{self.recommended_action}'. Expected one of: {', '.join(VALID_RECOMMENDED_ACTIONS)}."
            )
        polarity = str(self.dominant_polarity or "").strip().lower()
        if polarity not in VALID_DRIVE_POLARITIES:
            raise ValueError(
                f"Invalid dominant_polarity '{self.dominant_polarity}'. Expected one of: {', '.join(VALID_DRIVE_POLARITIES)}."
            )
        object.__setattr__(self, "recommended_action", action)
        object.__setattr__(self, "dominant_polarity", polarity)


def summarize_drive_cues(cues: list[DriveCue]) -> DriveAssessment:
    if not cues:
        return DriveAssessment(
            dominant_polarity="investigate",
            recommended_action="monitor",
            reasons=("no salient drive cues",),
        )

    totals = {"approach": 0.0, "avoid": 0.0, "investigate": 0.0}
    for cue in cues:
        totals[cue.polarity] += cue.intensity

    dominant = max(totals, key=totals.get)
    reasons = tuple(cue.reason for cue in cues)

    if dominant == "avoid":
        high_avoid = max((cue.intensity for cue in cues if cue.polarity == "avoid"), default=0.0)
        action = "recoil" if high_avoid >= 0.75 else "protect"
    elif dominant == "approach":
        high_approach = max((cue.intensity for cue in cues if cue.polarity == "approach"), default=0.0)
        action = "prefer" if high_approach >= 0.6 else "monitor"
    else:
        action = "investigate" if "investigate" in VALID_RECOMMENDED_ACTIONS else "monitor"
        action = "monitor"

    if dominant == "investigate":
        action = "escalate" if any(cue.intensity >= 0.7 for cue in cues if cue.polarity == "investigate") else "monitor"

    return DriveAssessment(
        dominant_polarity=dominant,
        recommended_action=action,
        reasons=reasons,
    )


# -----------------------------------------------------------------------------
# Cue derivation — turning context signals into DriveCues.
#
# Design basis: .planning/theory/DRIVE-SIGNALS-AND-MOTIVATIONAL-SALIENCE-
# 2026-04-16.md §3. A Whispers "nervous system" is not neutral; it carries
# approach / avoid / investigate signals back toward decision centers so the
# capsule can say "this looks promising / dangerous / worth learning about"
# instead of listing events and hoping the reader notices.
#
# The derivation takes primitives (recent_messages, pending_obligations,
# residue, recent_scope_events) that build_context_section already computes,
# and returns a list of DriveCue-shaped dicts ready for serialization into
# the capsule. Testable in isolation — no DB handle required.
# -----------------------------------------------------------------------------

# Residue patterns that carry negative salience when they recur. Repeated
# appearance in the caller's recent traffic implies stale/weak truth or
# unresolved failure — the kind of signal the theory doc §3.2 names as
# "stale or weak truth on a hard coordination path."
_AVERSIVE_RESIDUE_WORDS: frozenset[str] = frozenset({
    "error", "errors", "failed", "failing", "failure",
    "broken", "blocked", "blocking",
    "stale", "stalled", "stuck",
    "timeout", "timed",
    "deadlock", "hang", "hanging",
    "crash", "crashed", "crashing",
    "regression", "regressed",
    "conflict", "conflicting",
})

# Residue patterns that carry positive salience — they mark a productive
# coordination rhythm.
_APPETITIVE_RESIDUE_WORDS: frozenset[str] = frozenset({
    "shipped", "landed", "merged", "deployed",
    "green", "passed", "passing",
    "handoff", "handoffs",
    "completed", "complete",
    "resolved", "resolving",
})

# Thresholds (documented so operators can understand why a cue fired).
_PENDING_FLASH_OVERLOAD_THRESHOLD = 3
_PENDING_PRIORITY_OVERLOAD_THRESHOLD = 5
_RESIDUE_AVERSE_INTENSITY_BASE = 0.4
_RESIDUE_APPETITIVE_INTENSITY_BASE = 0.4
_RESIDUE_INTENSITY_PER_REPETITION = 0.1
_NOVEL_SENDER_INVESTIGATE_INTENSITY = 0.6


def derive_drive_cues(
    *,
    recent_messages: Iterable[Mapping[str, Any]] | None = None,
    pending_obligations: Iterable[Mapping[str, Any]] | None = None,
    residue: Iterable[Mapping[str, Any]] | None = None,
    recent_scope_events: Iterable[Mapping[str, Any]] | None = None,
    self_callsign: str | None = None,
    known_peers: Iterable[str] | None = None,
    budget: int = 6,
) -> list[dict[str, Any]]:
    """Derive drive cues from already-computed context primitives.

    Emits cues across three polarities per the theory doc §3:
      - approach: productive flow, clean handoffs, fit opportunities
      - avoid:    overload, stale truth, attention debt
      - investigate: novel participants, unresolved recurring patterns

    Takes primitives instead of querying the DB so it composes cheaply
    with build_context_section (which already has these handy) and can
    be tested in isolation. All iterables may be None for a degraded
    capsule — the function never raises on missing inputs.

    Returns a list of DriveCue-shaped dicts (polarity, cue_kind, intensity,
    reason, basis), sorted by intensity descending, capped at `budget`.
    The capsule consumer is free to call `summarize_drive_cues` on the
    rehydrated DriveCue objects if it wants a single dominant verdict.
    """
    normalized_self = (self_callsign or "").strip().lower()
    known = {str(cs or "").strip().lower() for cs in (known_peers or []) if cs}
    cues: list[DriveCue] = []

    # --- Avoid signals: pending obligation load --------------------------
    pending_list = list(pending_obligations or [])
    flash_pending = [p for p in pending_list if (p.get("kind") or "").lower().startswith("flash")]
    priority_pending = [
        p for p in pending_list
        if (p.get("kind") or "").lower().startswith("priority")
    ]
    if len(flash_pending) >= _PENDING_FLASH_OVERLOAD_THRESHOLD:
        # Scale intensity with count, saturating at 1.0 for very high overload.
        overload_intensity = min(1.0, 0.5 + 0.15 * (len(flash_pending) - _PENDING_FLASH_OVERLOAD_THRESHOLD))
        cues.append(DriveCue(
            polarity="avoid",
            cue_kind="attention_overload",
            intensity=max(0.7, overload_intensity),
            reason=f"{len(flash_pending)} unread flash obligations — interrupt exhaustion risk",
            basis="pending_obligations",
        ))
    elif len(priority_pending) + len(flash_pending) >= _PENDING_PRIORITY_OVERLOAD_THRESHOLD:
        cues.append(DriveCue(
            polarity="avoid",
            cue_kind="priority_backlog",
            intensity=0.55,
            reason=f"{len(priority_pending) + len(flash_pending)} unread priority+ messages accumulating",
            basis="pending_obligations",
        ))

    # --- Avoid / approach signals: residue-driven ------------------------
    residue_list = list(residue or [])
    for r in residue_list:
        pattern = str(r.get("pattern") or "").strip().lower()
        if not pattern:
            continue
        count = int(r.get("pattern_count") or r.get("count") or 0)
        if count < 2:
            continue
        boost = min(0.5, _RESIDUE_INTENSITY_PER_REPETITION * max(0, count - 2))
        # Bigrams: check if either token is a trigger word.
        tokens = pattern.split()
        if any(t in _AVERSIVE_RESIDUE_WORDS for t in tokens):
            cues.append(DriveCue(
                polarity="avoid",
                cue_kind="stale_or_failing_pattern",
                intensity=min(1.0, _RESIDUE_AVERSE_INTENSITY_BASE + boost),
                reason=f"recurring failure/staleness pattern '{pattern}' (×{count})",
                basis="residue",
            ))
        elif any(t in _APPETITIVE_RESIDUE_WORDS for t in tokens):
            cues.append(DriveCue(
                polarity="approach",
                cue_kind="productive_rhythm",
                intensity=min(1.0, _RESIDUE_APPETITIVE_INTENSITY_BASE + boost),
                reason=f"recurring productive pattern '{pattern}' (×{count})",
                basis="residue",
            ))

    # --- Investigate signals: novel senders ------------------------------
    # A novel sender is one who appears in recent_messages but isn't in the
    # known_peers set (the caller's pair-space / workspace peers). Per the
    # theory doc §3.3: "new agent with unclear differentiator."
    if known or normalized_self:
        seen_novel: set[str] = set()
        for msg in (recent_messages or []):
            frm = str(msg.get("from") or "").strip().lower()
            if not frm or frm == normalized_self or frm in seen_novel:
                continue
            if known and frm not in known:
                seen_novel.add(frm)
                cues.append(DriveCue(
                    polarity="investigate",
                    cue_kind="novel_sender",
                    intensity=_NOVEL_SENDER_INVESTIGATE_INTENSITY,
                    reason=f"message from '{frm}' — not a recognized peer in current scope",
                    basis="recent_messages",
                ))

    # --- Approach signals: recent scope activity -------------------------
    # Fresh workspace events involving peers imply active coordination in
    # the caller's rooms — a positive approach signal (§3.1 "clean handoff
    # opportunity").
    scope_events = list(recent_scope_events or [])
    if len(scope_events) >= 2:
        cues.append(DriveCue(
            polarity="approach",
            cue_kind="active_scope",
            intensity=min(0.8, 0.4 + 0.1 * len(scope_events)),
            reason=f"{len(scope_events)} recent scope events — active coordination surface",
            basis="recent_scope_events",
        ))

    # Sort by intensity desc, then stable by polarity for deterministic test output.
    cues.sort(key=lambda c: (-c.intensity, c.polarity, c.cue_kind))
    kept = cues[:budget]
    return [asdict(c) for c in kept]
