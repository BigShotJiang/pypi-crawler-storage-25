"""Whispers test harness — local embedded runtime, no HTTP server required."""

from __future__ import annotations

import gc
import os
import shutil
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from .client import WhispersClient
from .path_utils import resolve_path



def _test_root_dir() -> str:
    override = os.environ.get("WHISPERS_TEST_TMP_ROOT", "").strip()
    if override:
        root = Path(resolve_path(override))
    else:
        root = Path(__file__).resolve().parents[1] / ".tmp"
    root.mkdir(parents=True, exist_ok=True)
    return str(root)



def _make_test_dir() -> str:
    root = _test_root_dir()
    path = os.path.join(root, f"whispers-test-{uuid.uuid4().hex}")
    os.makedirs(path, exist_ok=False)
    return path



def _safe_rmtree(db_path: str, dir_path: str) -> None:
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        conn.close()
    except (sqlite3.Error, OSError):
        pass

    gc.collect()

    for attempt in range(3):
        try:
            shutil.rmtree(dir_path)
            return
        except OSError:
            if attempt < 2:
                time.sleep(0.1 * (attempt + 1))
    shutil.rmtree(dir_path, ignore_errors=True)


class WhispersTestClient(WhispersClient):
    def __init__(
        self,
        agent_name: str,
        *,
        shared_db_path: Optional[str] = None,
        agent_type: str = "script",
        model_id: Optional[str] = None,
        display_name: Optional[str] = None,
        **client_kwargs: Any,
    ):
        self._owns_db = shared_db_path is None
        if shared_db_path:
            self._test_db_path = shared_db_path
            self._test_dir: Optional[str] = None
        else:
            self._test_dir = _make_test_dir()
            self._test_db_path = os.path.join(self._test_dir, "test.db")

        super().__init__(
            agent_name,
            db_path=self._test_db_path,
            agent_type=agent_type,
            model_id=model_id,
            display_name=display_name,
            **client_kwargs,
        )

    @staticmethod
    def create_temp_db() -> str:
        test_dir = _make_test_dir()
        return os.path.join(test_dir, "test.db")

    @staticmethod
    def cleanup_temp_db(db_path: str) -> None:
        test_dir = os.path.dirname(db_path)
        if os.path.isdir(test_dir) and "whispers-test-" in test_dir:
            _safe_rmtree(db_path, test_dir)

    def close(self) -> None:
        super().close()
        if self._owns_db and self._test_dir and os.path.isdir(self._test_dir):
            _safe_rmtree(self._test_db_path, self._test_dir)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class WhispersTestHarness:
    def __init__(self):
        self._test_dir = _make_test_dir()
        self._db_path = os.path.join(self._test_dir, "test.db")
        self._clients: List[WhispersTestClient] = []

    @property
    def db_path(self) -> str:
        return self._db_path

    def make_client(
        self,
        agent_name: str,
        *,
        agent_type: str = "script",
        model_id: Optional[str] = None,
        display_name: Optional[str] = None,
        **client_kwargs: Any,
    ) -> WhispersTestClient:
        client = WhispersTestClient(
            agent_name,
            shared_db_path=self._db_path,
            agent_type=agent_type,
            model_id=model_id,
            display_name=display_name,
            **client_kwargs,
        )
        self._clients.append(client)
        return client

    def close(self) -> None:
        self._clients.clear()
        if os.path.isdir(self._test_dir):
            _safe_rmtree(self._db_path, self._test_dir)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False
