import base64
import hashlib
import logging
import random
import re
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


REMOTE_CALLSIGN_RE = re.compile(r"^[a-z][a-z0-9-]{1,30}[a-z0-9]$")
HUMAN_CALLSIGN_RE = re.compile(r"^[a-z]{3,24}$")

# Friendly single-word public callsigns. These are the human-facing names we
# want peers and operators to carry in their heads. Technical identity lives in
# stable_subject_id / agent_id; public callsigns should stay easy to say.
FRIENDLY_CALLSIGN_POOL = [
    "amber", "apple", "ash", "beacon", "bell", "berry", "birch", "bloom",
    "brook", "cedar", "cinder", "clover", "comet", "coral", "cove", "dawn",
    "dove", "elm", "ember", "fern", "field", "finch", "flint", "flora",
    "frost", "glade", "glen", "golden", "grove", "harbor", "hazel", "heath",
    "heron", "hollow", "iris", "ivy", "jade", "jasper", "jet", "juniper",
    "kestrel", "kiln", "lake", "lark", "linen", "moss", "north", "oak",
    "opal", "otter", "pearl", "pebble", "pine", "plum", "quartz", "raven",
    "reef", "ridge", "river", "rose", "sable", "sage", "sand", "shore",
    "sky", "snow", "sparrow", "spruce", "star", "stone", "stream", "sun",
    "thistle", "umber", "vale", "violet", "wave", "willow", "wren",
]

# Wordlists for auto-generated legacy callsigns: {adjective}-{noun}-{suffix}
_ADJECTIVES = [
    "swift", "calm", "keen", "bold", "warm", "cool", "fast", "pure",
    "bright", "sharp", "quiet", "deep", "clear", "soft", "steady",
    "gentle", "vivid", "eager", "lucid", "nimble",
]
_NOUNS = [
    "river", "spark", "ember", "frost", "cedar", "coral", "flint",
    "maple", "stone", "cloud", "brook", "ridge", "grove", "lark",
    "crane", "raven", "otter", "birch", "sage", "delta",
]
_HANDLE_PART_RE = re.compile(r"[^a-z0-9]+")
RESERVED_CALLSIGNS = frozenset({
    "system",
    "broadcast",
    "all",
    "whispers",
    "admin",
    "root",
})
INTERNAL_IDENTITIES = frozenset({
    "_probe",
    "_health_check",
})
MAX_PUBLIC_KEY_LENGTH = 16384


def validate_remote_callsign(callsign: str, *, allow_internal: bool = True) -> str | None:
    """Validate a public/remote callsign. Returns an error string or None."""
    if allow_internal and callsign in INTERNAL_IDENTITIES:
        return None
    if callsign in RESERVED_CALLSIGNS:
        return f"Callsign '{callsign}' is reserved. Choose a different name."
    if not REMOTE_CALLSIGN_RE.match(callsign):
        return (
            f"Invalid callsign '{callsign}'. Must be 3-32 chars, lowercase letters, "
            f"digits, and hyphens. Must start with a letter and end with a letter or digit."
        )
    return None


def validate_human_callsign(callsign: str, *, allow_internal: bool = True) -> str | None:
    """Validate a human-facing public callsign.

    Human-facing names should be easy to say, easy to remember, and free of
    punctuation fragments or numeric suffixes. Technical identity lives below
    this layer; the public face should remain a clean word.
    """
    normalized = str(callsign or "").strip().lower()
    if allow_internal and normalized in INTERNAL_IDENTITIES:
        return None
    if normalized in RESERVED_CALLSIGNS:
        return f"Callsign '{normalized}' is reserved. Choose a different name."
    if not HUMAN_CALLSIGN_RE.fullmatch(normalized):
        return (
            f"Invalid callsign '{callsign}'. Human-facing callsigns must be a single "
            f"lowercase word of 3-24 letters with no digits, punctuation, or hyphens."
        )
    return None


def friendly_callsign_candidates(seed_material: str) -> list[str]:
    """Return a deterministic rotation of the friendly public callsign pool."""
    seed = hashlib.sha256(str(seed_material or "whispers").encode("utf-8")).hexdigest()
    rng = random.Random(seed)
    pool = list(FRIENDLY_CALLSIGN_POOL)
    rng.shuffle(pool)
    return pool


def normalize_callsign_part(value: str, *, fallback: str = "agent") -> str:
    """Normalize a human label into a valid callsign fragment."""
    normalized = _HANDLE_PART_RE.sub("-", (value or "").strip().lower()).strip("-")
    if not normalized:
        normalized = fallback
    if not normalized[0].isalpha():
        normalized = f"a-{normalized}"
    normalized = normalized.strip("-")
    return normalized or fallback


def suggest_callsign(owner_slug: str, surface: str, *, max_length: int = 32) -> str:
    """Build a deterministic owner-prefixed callsign like `z4rivers-codex`."""
    owner = normalize_callsign_part(owner_slug, fallback="agent")
    surface_part = normalize_callsign_part(surface, fallback="agent")
    candidate = f"{owner}-{surface_part}"
    if len(candidate) <= max_length:
        return candidate

    max_owner = max(3, min(len(owner), max_length - 3))
    owner = owner[:max_owner].rstrip("-")
    remaining = max_length - len(owner) - 1
    surface_part = surface_part[:max(1, remaining)].rstrip("-")
    candidate = f"{owner}-{surface_part}".strip("-")

    if candidate and candidate[-1] == "-":
        candidate = candidate[:-1]
    if candidate and not candidate[-1].isalnum():
        candidate = candidate[:-1] + "x"
    if candidate and candidate[0].isdigit():
        candidate = f"a-{candidate}"[:max_length].rstrip("-")
    return candidate


def suggest_display_name(surface: str) -> str:
    label = normalize_callsign_part(surface, fallback="agent")
    return " ".join(part.capitalize() for part in label.split("-"))


def generate_callsign(*, prefix: str = "") -> str:
    """Generate a friendly random callsign like 'swift-cedar' or 'agent-keen-spark'.

    If prefix is provided, produces '{prefix}-{adjective}-{noun}'.
    Otherwise produces '{adjective}-{noun}'.
    """
    adj = random.choice(_ADJECTIVES)
    noun = random.choice(_NOUNS)
    if prefix:
        return f"{normalize_callsign_part(prefix)}-{adj}-{noun}"
    return f"{adj}-{noun}"


def normalize_public_key(public_key: str) -> str:
    normalized = (public_key or "").strip()
    if not normalized:
        raise ValueError("Missing public key.")
    if len(normalized) > MAX_PUBLIC_KEY_LENGTH:
        raise ValueError(f"Public key is too large. Limit is {MAX_PUBLIC_KEY_LENGTH} characters.")
    return normalized


def fingerprint_public_key(public_key: str | None) -> str | None:
    if not public_key:
        return None
    digest = hashlib.sha256(public_key.encode("utf-8")).hexdigest()
    return f"sha256:{digest[:16]}"


# ─── Ed25519 Cryptographic Identity ──────────────────────────────


def _keys_dir() -> Path:
    """Return the directory for storing agent private keys."""
    keys_dir = Path.home() / ".whispers" / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    return keys_dir


def generate_ed25519_keypair() -> Tuple[bytes, bytes]:
    """Generate an Ed25519 keypair. Returns (private_key_pem, public_key_raw_32_bytes)."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization

    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_raw = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return private_pem, public_raw


def store_private_key(agent_id: str, private_pem: bytes) -> Path:
    """Store a private key PEM file for an agent. Returns the file path."""
    key_path = _keys_dir() / f"{agent_id}.pem"
    key_path.write_bytes(private_pem)
    try:
        key_path.chmod(0o600)
    except OSError:
        pass  # Windows may not support chmod
    logger.info("Stored Ed25519 private key for %s at %s", agent_id, key_path)
    return key_path


def load_private_key(agent_id: str) -> Optional[bytes]:
    """Load a private key PEM for an agent. Returns None if not found."""
    key_path = _keys_dir() / f"{agent_id}.pem"
    if not key_path.exists():
        return None
    return key_path.read_bytes()


def public_key_to_base64(public_raw: bytes) -> str:
    """Encode raw 32-byte Ed25519 public key to base64 for storage in agent_cards."""
    return base64.b64encode(public_raw).decode("ascii")


def public_key_from_base64(encoded: str) -> bytes:
    """Decode base64-encoded public key back to raw 32 bytes."""
    return base64.b64decode(encoded)


def public_key_to_jwk(public_raw: bytes) -> dict:
    """Convert raw 32-byte Ed25519 public key to JWK format (A2A-compatible)."""
    x = base64.urlsafe_b64encode(public_raw).rstrip(b"=").decode("ascii")
    return {
        "kty": "OKP",
        "crv": "Ed25519",
        "x": x,
    }


def fingerprint_ed25519(public_raw: bytes) -> str:
    """Compute SHA-256 fingerprint of raw Ed25519 public key.

    Returns 'sha256:{hex}' format for human display.
    Uses the raw 32-byte key, not a string encoding.
    """
    digest = hashlib.sha256(public_raw).hexdigest()
    return f"sha256:{digest[:16]}"


def generate_and_store_keypair(agent_id: str) -> Tuple[str, str]:
    """Generate an Ed25519 keypair, store the private key, return (public_key_base64, fingerprint).

    This is the high-level function called during agent registration.
    """
    private_pem, public_raw = generate_ed25519_keypair()
    store_private_key(agent_id, private_pem)
    pub_b64 = public_key_to_base64(public_raw)
    fp = fingerprint_ed25519(public_raw)
    logger.info("Generated Ed25519 identity for %s: %s", agent_id, fp)
    return pub_b64, fp
