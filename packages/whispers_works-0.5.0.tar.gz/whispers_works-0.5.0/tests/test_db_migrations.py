from __future__ import annotations

import sqlite3

from whispers.storage.db import WhispersDB


def test_legacy_callsign_ledger_schema_is_migrated(tmp_path):
    db_path = tmp_path / "legacy-whispers.db"
    conn = sqlite3.connect(db_path)
    conn.execute(
        """
        CREATE TABLE callsign_ledger (
            agent_id TEXT,
            old_callsign TEXT,
            new_callsign TEXT,
            changed_at TIMESTAMP
        )
        """
    )
    conn.execute(
        "INSERT INTO callsign_ledger (agent_id, old_callsign, new_callsign, changed_at) VALUES (?, ?, ?, ?)",
        ("agent-1", "alice", "wren", "2026-04-01 10:00:00"),
    )
    conn.commit()
    conn.close()

    db = WhispersDB(db_path=str(db_path))

    with db.get_connection() as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(callsign_ledger)").fetchall()}
        assert {"callsign", "stable_subject_id", "agent_id", "status", "successor_callsign", "last_bound_at"}.issubset(columns)

        migrated = conn.execute(
            "SELECT * FROM callsign_ledger WHERE callsign = ?",
            ("alice",),
        ).fetchone()
        assert migrated is not None
        assert migrated["stable_subject_id"] == "agent-1"
        assert migrated["status"] == "retired"
        assert migrated["successor_callsign"] == "wren"

        backups = conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE 'callsign_ledger_legacy_backup%'"
        ).fetchall()
        assert backups
