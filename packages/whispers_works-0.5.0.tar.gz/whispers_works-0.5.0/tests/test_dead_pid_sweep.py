"""Slice 7 — dead-PID session sweep tests.

When a Claude Code window dies (closed, crashed, OS restart), its MCP
bridge disconnects but the `agent_sessions` row lingers with a
`lease_expires_at` 30 minutes in the future. The next bind for the same
callsign then sees the stale row and either holds an anchor lock, or
miscounts live sessions in the collision envelope's take_over
precondition check.

`sweep_dead_pid_sessions()` scans agent_sessions for rows whose
`process_id` references an OS process that no longer exists AND whose
`last_seen_at` is older than a short idle threshold (guarding against a
freshly-spawned session that hasn't had its heartbeat yet). Matching
rows are deleted with an identity_events audit trail.

Run: pytest tests/test_dead_pid_sweep.py -v
"""

from __future__ import annotations

import os
import sqlite3

import pytest

from whispers.storage.db import WhispersDB


def _insert_session(
    db_path: str,
    *,
    session_id: str,
    agent_name: str,
    process_id: int | None,
    last_seen_delta_seconds: int = 0,
) -> None:
    """Insert an agent_sessions row with controlled last_seen_at."""
    conn = sqlite3.connect(db_path)
    try:
        last_seen_sql = f"datetime('now', '{last_seen_delta_seconds:+d} seconds')"
        lease_sql = f"datetime('now', '+30 minutes')"
        conn.execute(
            f"INSERT INTO agent_sessions (session_id, agent_id, agent_name, "
            f"session_kind, process_id, last_seen_at, created_at, lease_expires_at) "
            f"VALUES (?, ?, ?, 'mcp_http', ?, {last_seen_sql}, {last_seen_sql}, {lease_sql})",
            (session_id, f"agent-{agent_name}", agent_name, process_id),
        )
        conn.commit()
    finally:
        conn.close()


class TestSweepBasics:
    def test_sweep_removes_dead_pid_sessions(self, tmp_path):
        """A session rooted in a PID that no longer exists is swept."""
        from whispers.orientation import sweep_dead_pid_sessions

        db_path = str(tmp_path / "sweep.db")
        WhispersDB(db_path=db_path)
        # PID 999999 is almost certainly dead on any OS (reserved-range).
        _insert_session(
            db_path,
            session_id="stale-session",
            agent_name="burr",
            process_id=999999,
            last_seen_delta_seconds=-300,
        )

        result = sweep_dead_pid_sessions(db_path=db_path)
        assert result["swept"] >= 1

        conn = sqlite3.connect(db_path)
        try:
            remaining = conn.execute(
                "SELECT session_id FROM agent_sessions WHERE session_id=?",
                ("stale-session",),
            ).fetchone()
        finally:
            conn.close()
        assert remaining is None

    def test_sweep_preserves_live_pid_sessions(self, tmp_path):
        """A session whose process_id = current PID must NOT be swept —
        that's us, we're alive.
        """
        from whispers.orientation import sweep_dead_pid_sessions

        db_path = str(tmp_path / "sweep_live.db")
        WhispersDB(db_path=db_path)
        _insert_session(
            db_path,
            session_id="live-session",
            agent_name="burr",
            process_id=os.getpid(),
            last_seen_delta_seconds=-300,
        )

        result = sweep_dead_pid_sessions(db_path=db_path)

        conn = sqlite3.connect(db_path)
        try:
            remaining = conn.execute(
                "SELECT session_id FROM agent_sessions WHERE session_id=?",
                ("live-session",),
            ).fetchone()
        finally:
            conn.close()
        assert remaining is not None, "live PID session must survive"

    def test_sweep_skips_recent_dead_pid_sessions(self, tmp_path):
        """A session whose PID is dead but whose last_seen_at is within
        the idle threshold (< 60s) is preserved. Protects against the
        race where a session just reconnected and hasn't updated its
        process_id yet.
        """
        from whispers.orientation import sweep_dead_pid_sessions

        db_path = str(tmp_path / "sweep_recent.db")
        WhispersDB(db_path=db_path)
        _insert_session(
            db_path,
            session_id="recent-session",
            agent_name="burr",
            process_id=999999,
            last_seen_delta_seconds=-5,  # 5 seconds ago
        )

        sweep_dead_pid_sessions(db_path=db_path, idle_threshold_seconds=60)

        conn = sqlite3.connect(db_path)
        try:
            remaining = conn.execute(
                "SELECT session_id FROM agent_sessions WHERE session_id=?",
                ("recent-session",),
            ).fetchone()
        finally:
            conn.close()
        assert remaining is not None, "recent session must survive grace period"

    def test_sweep_skips_null_process_id(self, tmp_path):
        """Sessions without a process_id cannot be confirmed dead — leave
        them alone. Some session_kinds (library-level uses) may not
        populate process_id.
        """
        from whispers.orientation import sweep_dead_pid_sessions

        db_path = str(tmp_path / "sweep_null.db")
        WhispersDB(db_path=db_path)
        _insert_session(
            db_path,
            session_id="nopid-session",
            agent_name="burr",
            process_id=None,
            last_seen_delta_seconds=-3600,
        )

        sweep_dead_pid_sessions(db_path=db_path)

        conn = sqlite3.connect(db_path)
        try:
            remaining = conn.execute(
                "SELECT session_id FROM agent_sessions WHERE session_id=?",
                ("nopid-session",),
            ).fetchone()
        finally:
            conn.close()
        assert remaining is not None

    def test_sweep_returns_per_callsign_counts(self, tmp_path):
        """Result reports which callsigns lost stale sessions — operators
        want to see what the sweep freed up.
        """
        from whispers.orientation import sweep_dead_pid_sessions

        db_path = str(tmp_path / "sweep_counts.db")
        WhispersDB(db_path=db_path)
        _insert_session(db_path, session_id="s1", agent_name="burr",
                        process_id=999998, last_seen_delta_seconds=-300)
        _insert_session(db_path, session_id="s2", agent_name="spark",
                        process_id=999997, last_seen_delta_seconds=-300)
        _insert_session(db_path, session_id="s3", agent_name="burr",
                        process_id=999996, last_seen_delta_seconds=-300)

        result = sweep_dead_pid_sessions(db_path=db_path)

        assert result["swept"] == 3
        per_callsign = result.get("per_callsign", {})
        assert per_callsign.get("burr") == 2
        assert per_callsign.get("spark") == 1

    def test_sweep_writes_identity_events_audit(self, tmp_path):
        """Every sweep is auditable — writes an identity_events row so
        operators can reconstruct what got cleaned up.
        """
        from whispers.orientation import sweep_dead_pid_sessions

        db_path = str(tmp_path / "sweep_audit.db")
        WhispersDB(db_path=db_path)
        _insert_session(db_path, session_id="s1", agent_name="burr",
                        process_id=999999, last_seen_delta_seconds=-300)

        sweep_dead_pid_sessions(db_path=db_path, actor="test-operator")

        conn = sqlite3.connect(db_path)
        try:
            events = conn.execute(
                "SELECT event_type, outcome, callsign FROM identity_events "
                "WHERE event_type='session_swept' ORDER BY event_id DESC LIMIT 5"
            ).fetchall()
        finally:
            conn.close()
        assert len(events) >= 1

    def test_sweep_with_no_stale_sessions_is_clean_noop(self, tmp_path):
        """Zero-matches sweep succeeds with swept=0 and no side effects."""
        from whispers.orientation import sweep_dead_pid_sessions

        db_path = str(tmp_path / "sweep_empty.db")
        WhispersDB(db_path=db_path)

        result = sweep_dead_pid_sessions(db_path=db_path)
        assert result["swept"] == 0
        assert result.get("per_callsign", {}) == {}
