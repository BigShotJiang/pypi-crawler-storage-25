from __future__ import annotations

import pytest

from whispers.client import WhispersConflictError
from whispers.testing import WhispersTestHarness


class TestPresentationRename:
    def test_rename_preserves_stable_subject_and_trust(self):
        with WhispersTestHarness() as h:
            alice = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claudecode",
                context_hint="mainworktree",
            )
            original_agent_id = alice._agent_id()
            alice.trust_set(new_tier=4, actor="operator", reason="trusted reviewer")

            renamed = alice.rename("wren", reason="human-facing rename")
            assert renamed["resolution"]["outcome"] == "presentation_renamed"
            assert alice.agent_name == "wren"

            who = alice.whoami()
            assert who is not None
            assert who["agent_id"] == original_agent_id
            assert who["stable_subject_id"] == original_agent_id
            assert who["effective_trust"]["current_tier"] == 4

            history = alice.presentation_history()
            by_name = {row["callsign"]: row for row in history}
            assert by_name["wren"]["status"] == "current"
            assert by_name["alice"]["status"] == "retired"
            assert by_name["alice"]["successor_callsign"] == "wren"

    def test_reply_to_old_message_routes_to_new_presentation(self):
        with WhispersTestHarness() as h:
            alice = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claudecode",
                context_hint="mainworktree",
            )
            bob = h.make_client(
                "bob",
                owner_id="zack",
                platform_family="codex",
                context_hint="reviewworktree",
            )

            first = alice.send("bob", "Initial hello", body="before rename")
            inbox = bob.check_inbox(mark_seen=False)
            original = next(message for message in inbox if message["message_id"] == first["message_id"])
            original_space_id = original["space_id"]
            original_thread_id = original["thread_id"]

            alice.rename("wren", reason="public name cleanup")

            reply = bob.respond(original["message_id"], "after rename")
            assert reply["status"] in {"delivered", "queued"}
            assert reply["space_id"] == original_space_id
            assert reply["thread_id"] == original_thread_id

            renamed_inbox = alice.check_inbox(mark_seen=False)
            delivered = next(message for message in renamed_inbox if message["message_id"] == reply["message_id"])
            assert delivered["subject"] == "Re: Initial hello"
            assert delivered["from_agent"] == "bob"
            assert delivered["recipient_callsign"] == "wren"

    def test_old_callsign_stays_reserved_after_rename(self):
        with WhispersTestHarness() as h:
            alice = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claudecode",
                context_hint="mainworktree",
            )
            alice.rename("wren", reason="public name cleanup")

            with pytest.raises(WhispersConflictError):
                h.make_client(
                    "alice",
                    owner_id="other",
                    platform_family="codex",
                    context_hint="otherworktree",
                )

    def test_pair_space_continues_across_rename(self):
        with WhispersTestHarness() as h:
            alice = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claudecode",
                context_hint="mainworktree",
            )
            bob = h.make_client(
                "bob",
                owner_id="zack",
                platform_family="codex",
                context_hint="reviewworktree",
            )

            first = alice.send("bob", "Pair continuity", body="first exchange")
            alice.rename("wren", reason="public name cleanup")
            second = bob.send("wren", "Still same room", body="same pair-space please")

            assert first["space_id"] == second["space_id"]
