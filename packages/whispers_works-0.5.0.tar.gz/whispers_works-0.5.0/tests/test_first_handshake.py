"""First handshake — 60-second proof of core Whispers functionality.

A developer who just ran `pip install whispers-mcp` should be able to run
this test and see Whispers work end-to-end in under 60 seconds:

  pytest tests/test_first_handshake.py -v

No server, no config, no credentials. Two agents, one message.
"""
from __future__ import annotations

import time

import pytest

from whispers.testing import WhispersTestHarness


@pytest.mark.timeout(60)
def test_two_agents_first_handshake():
    """The complete first-use flow in a single test.

    alpha sends one message to beta. beta reads it. The returned message
    has a frame, a subject, a body, and a 2ACK envelope. Done.
    """
    with WhispersTestHarness() as h:
        alpha = h.make_client("alpha")
        beta = h.make_client("beta")

        t0 = time.monotonic()
        receipt = alpha.send("beta", "hello from alpha", body="first message")
        assert receipt.get("status") in ("delivered", "queued"), (
            f"Send failed: {receipt}"
        )

        inbox = beta.check_inbox(mark_seen=True)
        elapsed = time.monotonic() - t0

        assert len(inbox) == 1, f"Expected 1 message, got {len(inbox)}"
        msg = inbox[0]

        # Core envelope fields
        assert msg["from_agent"] == "alpha"
        assert msg["to_agent"] == "beta"
        assert msg["subject"] == "hello from alpha"
        assert msg["body"] == "first message"

        # Frame is stamped at read time
        frame = msg.get("frame", "")
        assert "⏦⏦⏦" in frame, f"No frame header: {frame!r}"
        assert "from alpha" in frame
        assert "to beta" in frame

        # 2ACK envelope rides along
        twoack = (msg.get("payload") or {}).get("twoack")
        assert isinstance(twoack, dict), "No 2ACK envelope in payload"
        assert twoack.get("wire_v") == 1
        assert twoack.get("schema") == "status_update.v1"

        assert elapsed < 60, f"Handshake took {elapsed:.1f}s — exceeds 60s budget"


@pytest.mark.timeout(60)
def test_reply_closes_the_loop():
    """beta replies to alpha's message. alpha reads the reply in outbox."""
    with WhispersTestHarness() as h:
        alpha = h.make_client("alpha")
        beta = h.make_client("beta")

        alpha.send("beta", "ping", body="are you there?")
        inbox = beta.check_inbox(mark_seen=True)
        assert len(inbox) == 1

        beta.respond(inbox[0]["message_id"], "yes, here", subject="pong")

        alpha_inbox = alpha.check_inbox(mark_seen=True)
        assert len(alpha_inbox) == 1, "alpha should have received beta's reply"
        assert alpha_inbox[0]["from_agent"] == "beta"
        assert "pong" in alpha_inbox[0]["subject"]
