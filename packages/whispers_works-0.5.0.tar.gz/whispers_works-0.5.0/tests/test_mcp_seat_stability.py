"""MCPSeatManager stability — multi-key lookup.

Symptom Cinder and Kiln observed: `Session not found` errors between
otherwise-adjacent MCP tool calls. Root cause: the client_key computed
from ctx can be different across calls (Slice-8 breadcrumb scan flips
on alive-count change, ctx.client_id sometimes absent, mcp-session-id
header behavior varies). If the single stored key misses, the client
appears "gone" even though it's still in _clients under a different
key.

Fix: bind_client stores under a list of alias keys; get_client/
require_client try all aliases. First hit wins.

Run: pytest tests/test_mcp_seat_stability.py -v
"""

from __future__ import annotations

import pytest

from whispers.mcp_server import MCPSeatConfig, MCPSeatManager
from whispers.testing import WhispersTestHarness


class TestMultiKeyLookup:
    def test_bind_with_alias_list_stores_under_all_keys(self):
        """bind_client accepts an `alias_keys` list and registers the
        bound client under every key. Lookup by any alias returns the
        same client.
        """
        with WhispersTestHarness() as h:
            m = MCPSeatManager(MCPSeatConfig(
                db_path=h.db_path, participant_profile="desktop_ide_agent",
            ))
            client = m.bind_client(
                "primary-key",
                requested_callsign="gear",
                participant_profile="desktop_ide_agent",
                session_kind="mcp_http",
                alias_keys=["alt-key-1", "alt-key-2"],
            )
            assert m.get_client("primary-key") is client
            assert m.get_client("alt-key-1") is client
            assert m.get_client("alt-key-2") is client

    def test_bind_without_alias_keys_still_works(self):
        """Backwards-compat: existing callers that don't pass
        alias_keys get the single-key behavior.
        """
        with WhispersTestHarness() as h:
            m = MCPSeatManager(MCPSeatConfig(
                db_path=h.db_path, participant_profile="desktop_ide_agent",
            ))
            client = m.bind_client(
                "only-key",
                requested_callsign="gear",
                participant_profile="desktop_ide_agent",
                session_kind="mcp_http",
            )
            assert m.get_client("only-key") is client

    def test_unbind_primary_key_removes_all_aliases(self):
        """Unbinding must clear the alias entries too — otherwise a
        partially-unbound client stays reachable through stale aliases.
        """
        with WhispersTestHarness() as h:
            m = MCPSeatManager(MCPSeatConfig(
                db_path=h.db_path, participant_profile="desktop_ide_agent",
            ))
            m.bind_client(
                "primary",
                requested_callsign="gear",
                participant_profile="desktop_ide_agent",
                session_kind="mcp_http",
                alias_keys=["alt-a", "alt-b"],
            )
            m.unbind_client("primary")
            assert m.get_client("primary") is None
            assert m.get_client("alt-a") is None
            assert m.get_client("alt-b") is None

    def test_require_client_tries_candidates_in_order(self):
        """require_client accepts a candidate list and returns the
        first match. Protects against client_key drift between calls.
        """
        with WhispersTestHarness() as h:
            m = MCPSeatManager(MCPSeatConfig(
                db_path=h.db_path, participant_profile="desktop_ide_agent",
            ))
            bound = m.bind_client(
                "k1",
                requested_callsign="gear",
                participant_profile="desktop_ide_agent",
                session_kind="mcp_http",
                alias_keys=["k2", "k3"],
            )
            # None of the first two candidates are bound, third is.
            client = m.require_client_by_candidates(["k4-missing", "k5-missing", "k3"])
            assert client is bound

    def test_require_client_by_candidates_raises_when_no_match(self):
        from whispers.client import WhispersException

        with WhispersTestHarness() as h:
            m = MCPSeatManager(MCPSeatConfig(
                db_path=h.db_path, participant_profile="desktop_ide_agent",
            ))
            with pytest.raises(WhispersException):
                m.require_client_by_candidates(["not-there"])
