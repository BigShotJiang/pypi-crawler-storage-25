from __future__ import annotations

import json

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client

from whispers.server import create_app
from whispers.testing import WhispersTestHarness


def _tool_json(result):
    assert result
    text = result[0].text
    return json.loads(text)


@pytest.mark.asyncio
async def test_bind_seat_requires_explicit_rebind_for_same_anchor_callsign():
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(transport=transport, base_url="http://127.0.0.1") as http_client:
                async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as first_streams:
                    first_read, first_write, _ = first_streams
                    async with ClientSession(first_read, first_write) as first_session:
                        await first_session.initialize()
                        first = await first_session.call_tool(
                            "bind_seat",
                            {
                                "requested_callsign": "gear",
                                "platform_family": "codex",
                                "context_hint": "mainworktree",
                            },
                        )
                        first_payload = _tool_json(first.content)
                        assert first_payload["bound"] is True

                        async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as second_streams:
                            second_read, second_write, _ = second_streams
                            async with ClientSession(second_read, second_write) as second_session:
                                await second_session.initialize()
                                pending = await second_session.call_tool(
                                    "bind_seat",
                                    {
                                        "requested_callsign": "gear",
                                        "platform_family": "codex",
                                        "context_hint": "mainworktree",
                                    },
                                )
                                pending_payload = _tool_json(pending.content)
                                assert pending_payload["bound"] is False
                                assert pending_payload["rebind_pending"] is True

                                rebound = await second_session.call_tool(
                                    "bind_seat",
                                    {
                                        "requested_callsign": "gear",
                                        "platform_family": "codex",
                                        "context_hint": "mainworktree",
                                        "rebind": True,
                                    },
                                )
                                rebound_payload = _tool_json(rebound.content)
                                assert rebound_payload["bound"] is True
                                assert rebound_payload["rebind_pending"] is False
                                assert rebound_payload["status"]["agent_name"] == "gear"


@pytest.mark.asyncio
async def test_bind_seat_uses_sibling_label_as_only_sibling_trigger():
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(transport=transport, base_url="http://127.0.0.1") as http_client:
                async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as first_streams:
                    first_read, first_write, _ = first_streams
                    async with ClientSession(first_read, first_write) as first_session:
                        await first_session.initialize()
                        await first_session.call_tool(
                            "bind_seat",
                            {
                                "requested_callsign": "gear",
                                "platform_family": "codex",
                                "context_hint": "mainworktree",
                            },
                        )

                async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as second_streams:
                    second_read, second_write, _ = second_streams
                    async with ClientSession(second_read, second_write) as second_session:
                        await second_session.initialize()
                        denied = await second_session.call_tool(
                            "bind_seat",
                            {
                                "requested_callsign": "gear",
                                "platform_family": "codex",
                                "context_hint": "reviewworktree",
                                "allow_sibling": True,
                            },
                        )
                        denied_payload = _tool_json(denied.content)
                        assert denied.isError is False
                        assert denied_payload["bound"] is False
                        assert denied_payload["rebind_pending"] is True

                async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as third_streams:
                    third_read, third_write, _ = third_streams
                    async with ClientSession(third_read, third_write) as third_session:
                        await third_session.initialize()
                        sibling = await third_session.call_tool(
                            "bind_seat",
                            {
                                "requested_callsign": "gear",
                                "platform_family": "codex",
                                "context_hint": "reviewworktree",
                                "sibling_label": "review",
                            },
                        )
                        sibling_payload = _tool_json(sibling.content)
                        assert sibling_payload["bound"] is True
                        assert sibling_payload["status"]["agent_name"] != "gear"
